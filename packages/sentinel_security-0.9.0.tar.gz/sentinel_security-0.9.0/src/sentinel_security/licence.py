"""
Licence validation for Python-only Sentinel users (US-6).

Validates SENTINEL_LICENCE_KEY against the Sentinel licence endpoint.
Users who do not have the OpenClaw plugin use this module to activate
paid features via environment variable or sentinel.configure(licence_key=...).

Security (SOC2):
    - Key is sent as SHA-256 hash, NEVER plaintext
    - HTTPS-only; HTTP URLs are rejected
    - Valid results cached 24h in-memory; invalid cached 5min
    - Offline/air-gapped: returns LicenceResult(valid=False, reason="offline")
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("sentinel_security.licence")

DEFAULT_VERIFY_URL = "https://sentinel-agents.com/api/verify"
_CACHE_TTL_VALID = 86400  # 24 hours
_CACHE_TTL_INVALID = 300  # 5 minutes
_HTTP_TIMEOUT = 10  # seconds


@dataclass(frozen=True)
class LicenceResult:
    """Result of a licence validation check."""

    valid: bool
    email: Optional[str] = None
    scope: Optional[str] = None  # "individual" | "team" | "org"
    expires_at: Optional[str] = None  # ISO 8601
    reason: Optional[str] = None


# Module-level cache: key_hash -> (LicenceResult, timestamp)
_cache: dict = {}


def _hash_key(key: str) -> str:
    """SHA-256 hash a licence key. Never store or send the plaintext."""
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def _validate_url(url: str) -> None:
    """Enforce HTTPS-only for licence validation."""
    if not url.startswith("https://"):
        raise ValueError(
            "Licence validation requires HTTPS. "
            "Refusing to send licence data over insecure connection: %s" % url
        )


def validate_licence(
    key: Optional[str] = None,
    *,
    verify_url: Optional[str] = None,
    _time_fn: Optional[object] = None,
) -> LicenceResult:
    """
    Validate a Sentinel licence key against the licence endpoint.

    Args:
        key: The licence key. If None, reads from SENTINEL_LICENCE_KEY env var
             or the value set via configure(licence_key=...).
        verify_url: Override the verification URL (must be HTTPS).
        _time_fn: Internal testing hook for time.time().

    Returns:
        LicenceResult with validation outcome.
    """
    now_fn = _time_fn or time.time

    # Resolve key from arg -> configure() -> env var
    if key is None:
        from sentinel_security.configure import _global_config

        key = _global_config.get("licence_key") or os.environ.get("SENTINEL_LICENCE_KEY")

    if not key:
        return LicenceResult(valid=False, reason="no_key")

    url = verify_url or DEFAULT_VERIFY_URL
    _validate_url(url)

    key_hash = _hash_key(key)

    # Check cache
    cached = _cache.get(key_hash)
    if cached is not None:
        result, cached_at = cached
        now = now_fn()
        ttl = _CACHE_TTL_VALID if result.valid else _CACHE_TTL_INVALID
        if now - cached_at < ttl:
            return result

    # Call endpoint
    try:
        body = json.dumps({"key_hash": key_hash}).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, OSError, json.JSONDecodeError, ValueError) as exc:
        logger.debug("Licence validation network error: %s", exc)
        result = LicenceResult(valid=False, reason="offline")
        # Do not cache offline results — retry next call
        return result

    result = LicenceResult(
        valid=bool(data.get("valid", False)),
        email=data.get("email"),
        scope=data.get("scope"),
        expires_at=data.get("expires_at"),
        reason=data.get("reason"),
    )

    # Cache the result
    _cache[key_hash] = (result, now_fn())

    if not result.valid:
        logger.warning("Sentinel licence validation failed: %s", result.reason or "invalid key")

    return result


def clear_cache() -> None:
    """Clear the licence validation cache (useful for testing)."""
    _cache.clear()
