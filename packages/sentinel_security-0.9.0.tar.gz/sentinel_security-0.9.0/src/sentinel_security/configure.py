"""
Global configuration for Sentinel middleware.

Configuration precedence (highest first):
1. Per-adapter **config kwargs
2. sentinel_security.configure() call
3. Environment variables (SENTINEL_POLICY, SENTINEL_RISK_THRESHOLD, etc.)
4. Package defaults
"""

from __future__ import annotations

import logging
import os
import threading
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger("sentinel_security.config")

# Package defaults (documented, immutable per version)
_DEFAULTS: Dict[str, Any] = {
    "policy": "warn",
    "risk_threshold": 5,
    "log_content": False,
    "middleware_enabled": True,
    "licence_key": None,
    "event_handler": None,
    "log_level": "WARNING",
    "telemetry": False,
}

# Env var -> (config key, converter)
_ENV_VARS: Dict[str, tuple] = {
    "SENTINEL_POLICY": ("policy", str),
    "SENTINEL_RISK_THRESHOLD": ("risk_threshold", int),
    "SENTINEL_LOG_CONTENT": ("log_content", lambda v: v.lower() in ("true", "1", "yes")),
    "SENTINEL_LICENCE_KEY": ("licence_key", str),
    "SENTINEL_TELEMETRY": ("telemetry", lambda v: v.lower() in ("true", "1", "yes")),
    "SENTINEL_MIDDLEWARE_ENABLED": ("middleware_enabled", lambda v: v.lower() in ("true", "1", "yes")),
}

# Global mutable config dict — populated by configure() and read by DetectionEngine
_global_config: Dict[str, Any] = {}

_configured = False

# RLock protects _global_config and _configured against concurrent access.
# RLock (reentrant) is used instead of Lock because configure() could
# theoretically be called from within an event handler during engine creation.
_config_lock = threading.RLock()


def _read_env() -> Dict[str, Any]:
    """Read config values from environment variables."""
    result: Dict[str, Any] = {}
    for env_var, (key, converter) in _ENV_VARS.items():
        raw = os.environ.get(env_var)
        if raw is not None:
            try:
                result[key] = converter(raw)
                logger.info(
                    "Sentinel config: %s=%r (from %s env var)", key, result[key], env_var
                )
            except (ValueError, TypeError):
                logger.warning(
                    "Sentinel config: invalid value for %s=%r, ignoring", env_var, raw
                )
    return result


def configure(
    *,
    policy: Optional[str] = None,
    risk_threshold: Optional[int] = None,
    log_level: Optional[str] = None,
    event_handler: Optional[Callable[..., Any]] = None,
    telemetry: Optional[bool] = None,
    licence_key: Optional[str] = None,
    middleware_enabled: Optional[bool] = None,
    log_content: Optional[bool] = None,
) -> Dict[str, Any]:
    """
    Set global defaults for Sentinel middleware.

    Values set here override environment variables but are overridden
    by per-adapter config kwargs.

    Returns the resolved configuration snapshot.
    """
    global _configured, _global_config

    with _config_lock:
        # Start from defaults
        resolved: Dict[str, Any] = dict(_DEFAULTS)

        # Layer env vars
        resolved.update(_read_env())

        # Layer explicit kwargs (only non-None)
        kwargs: Dict[str, Any] = {
            "policy": policy,
            "risk_threshold": risk_threshold,
            "log_level": log_level,
            "event_handler": event_handler,
            "telemetry": telemetry,
            "licence_key": licence_key,
            "middleware_enabled": middleware_enabled,
            "log_content": log_content,
        }
        for key, val in kwargs.items():
            if val is not None:
                resolved[key] = val
                log_val = val
                if key == "licence_key" and isinstance(val, str) and len(val) > 8:
                    log_val = val[:8] + "..."
                elif key == "event_handler" and callable(val):
                    log_val = "<callable>"
                logger.info("Sentinel config: %s=%r (from configure() call)", key, log_val)

        # Apply log level
        sentinel_logger = logging.getLogger("sentinel_security")
        level_name = resolved.get("log_level", "WARNING")
        sentinel_logger.setLevel(getattr(logging, str(level_name).upper(), logging.WARNING))

        # Store globally — atomic reference swap (no clear+update race window)
        _global_config = dict(resolved)
        _configured = True

    # Log config snapshot (SOC2 auditability) — redact licence key
    snapshot = dict(resolved)
    if snapshot.get("licence_key"):
        snapshot["licence_key"] = snapshot["licence_key"][:8] + "..."
    # event_handler is not JSON-serialisable; log its presence
    if snapshot.get("event_handler") is not None:
        snapshot["event_handler"] = "<callable>"
    logger.info("Sentinel config snapshot: %s", snapshot)

    result = dict(resolved)
    if result.get("licence_key"):
        result["licence_key"] = result["licence_key"][:8] + "...REDACTED"
    return result


def _reset_global_config() -> None:
    """Reset global config to empty. For testing only."""
    global _global_config, _configured
    with _config_lock:
        _global_config = {}
        _configured = False
