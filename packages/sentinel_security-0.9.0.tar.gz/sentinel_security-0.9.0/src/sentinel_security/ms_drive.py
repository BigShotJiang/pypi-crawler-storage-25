"""
OneDrive/SharePoint metadata scanner via Microsoft Graph API.

Checks drive item metadata for hidden content vectors:
file description, comments, sharing permissions, version history,
and sensitivity labels.

Requires: pip install sentinel-security[microsoft]
"""

import logging
import re
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

from .config import GRAPH_BASE_URL as GRAPH_BASE
from .patterns import CONTENT_INJECTION_PATTERNS

from .sanitiser.scorer import risk_level
from .utils import calculate_threat_risk_score

def scan_ms_drive_item(
    item_id: str,
    drive_id: Optional[str] = None,
    auth=None,
) -> dict:
    """
    Scan a OneDrive/SharePoint drive item's metadata for threats.

    Args:
        item_id: The drive item ID.
        drive_id: Drive ID. If None, uses /me/drive.
        auth: Authenticated requests.Session from ms_auth.get_graph_client().

    Returns:
        dict with keys:
            info (dict): Item metadata.
            threats (list): Detected threats.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.

    Raises:
        ValueError: If auth session is not provided.
    """
    logger.debug("scan_ms_drive_item: start item_id=%s", item_id)
    if auth is None:
        raise ValueError("auth (requests.Session) is required. Use ms_auth.get_graph_client().")

    base = _build_item_url(item_id, drive_id)
    threats: List[Dict[str, Any]] = []

    # 1. File metadata
    try:
        meta_resp = auth.get(base)
        meta_resp.raise_for_status()
        meta = meta_resp.json()

        info = {
            'item_id': item_id,
            'name': meta.get('name', ''),
            'size': meta.get('size', 0),
            'mime_type': meta.get('file', {}).get('mimeType', ''),
            'created': meta.get('createdDateTime', ''),
            'modified': meta.get('lastModifiedDateTime', ''),
            'created_by': meta.get('createdBy', {}).get('user', {}).get('displayName', ''),
            'modified_by': meta.get('lastModifiedBy', {}).get('user', {}).get('displayName', ''),
        }

        # Check description for injection
        desc = meta.get('description', '')
        if desc:
            for pattern in CONTENT_INJECTION_PATTERNS:
                if re.search(pattern, desc, re.IGNORECASE):
                    threats.append({
                        'type': 'injection_in_description',
                        'severity': 'CRITICAL',
                        'detail': 'Injection pattern in file description.',
                        'value_preview': desc[:100],
                    })
                    break

        # Sensitivity label
        sensitivity = meta.get('sensitivityLabel', {})
        if sensitivity:
            info['sensitivity_label'] = sensitivity.get('labelName', '')

    except Exception as e:
        info = {'item_id': item_id, 'error': str(e)}

    # 2. Comments
    try:
        comments_url = f"{base}/comments"
        comments_resp = auth.get(comments_url)
        comments_resp.raise_for_status()
        comments = comments_resp.json().get('value', [])
        info['comment_count'] = len(comments)

        for comment in comments:
            content = comment.get('content', '')
            if content:
                injection_found = False
                for pattern in CONTENT_INJECTION_PATTERNS:
                    if re.search(pattern, content, re.IGNORECASE):
                        threats.append({
                            'type': 'injection_in_comment',
                            'severity': 'CRITICAL',
                            'detail': 'Injection pattern in file comment.',
                            'value_preview': content[:100],
                        })
                        injection_found = True
                        break
                if not injection_found:
                    threats.append({
                        'type': 'comment',
                        'severity': 'LOW',
                        'detail': 'File has a comment.',
                        'value_preview': content[:100],
                    })
    except Exception as e:
        logger.warning("Failed to scan MS Drive item property: %s", e)

    # 3. Sharing permissions (external sharing = risk)
    try:
        perms_url = f"{base}/permissions"
        perms_resp = auth.get(perms_url)
        perms_resp.raise_for_status()
        permissions = perms_resp.json().get('value', [])
        info['permission_count'] = len(permissions)

        for perm in permissions:
            link = perm.get('link', {})
            if link.get('scope') == 'anonymous':
                threats.append({
                    'type': 'anonymous_sharing',
                    'severity': 'HIGH',
                    'detail': f'File has anonymous (anyone) sharing link ({link.get("type", "view")}).',
                })
            elif link.get('scope') == 'organization':
                threats.append({
                    'type': 'org_sharing',
                    'severity': 'LOW',
                    'detail': f'File has organisation-wide sharing link ({link.get("type", "view")}).',
                })

            granted = perm.get('grantedToIdentitiesV2', [])
            for identity in granted:
                if 'application' in identity:
                    threats.append({
                        'type': 'app_access',
                        'severity': 'MEDIUM',
                        'detail': f'Application "{identity["application"].get("displayName", "unknown")}" has access.',
                    })
    except Exception as e:
        logger.warning("Failed to process MS Drive item metadata: %s", e)

    # 4. Version history
    try:
        versions_url = f"{base}/versions"
        versions_resp = auth.get(versions_url)
        versions_resp.raise_for_status()
        versions = versions_resp.json().get('value', [])
        info['version_count'] = len(versions)

        if len(versions) > 50:
            threats.append({
                'type': 'excessive_versions',
                'severity': 'LOW',
                'detail': f'File has {len(versions)} versions (unusually high).',
            })
    except Exception as e:
        logger.warning("Failed to scan MS Drive shared link: %s", e)

    logger.debug("scan_ms_drive_item: end item_id=%s threats=%d", item_id, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_ms_drive_item: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_threat_risk_score(threats)
    return {
        'info': info,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }


def _build_item_url(item_id: str, drive_id: Optional[str]) -> str:
    if drive_id:
        return f"{GRAPH_BASE}/drives/{drive_id}/items/{item_id}"
    return f"{GRAPH_BASE}/me/drive/items/{item_id}"
