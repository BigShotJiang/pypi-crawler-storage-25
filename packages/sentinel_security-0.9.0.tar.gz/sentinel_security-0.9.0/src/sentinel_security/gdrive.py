"""Google Drive metadata scanner for sentinel-security package.

Scans Google Drive files for injection patterns in metadata fields:
- File description
- App properties
- Comments
- Revision counts
- External sharing permissions
"""

import logging
import re
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

from .google_auth import _load_credentials
from .patterns import INJECTION_PATTERNS
from .sanitiser.scorer import risk_level
from .utils import calculate_threat_risk_score


def scan_google_drive_file(
    file_id: str, 
    credentials=None, 
    credentials_path: Optional[str] = None
) -> Dict[str, Any]:
    """Scan a Google Drive file for injection patterns in metadata.
    
    Args:
        file_id: Google Drive file ID
        credentials: Optional pre-loaded google.oauth2.credentials.Credentials
        credentials_path: Optional path to credentials JSON file
        
    Returns:
        Dict with scan results:
        {
            'info': {'file_id': file_id, 'name': ..., 'mime_type': ..., 'owner': ...},
            'threats': [...],
            'threat_count': len(threats),
            'risk_score': 0-10,
            'risk_level': 'CLEAN'|'LOW'|'MEDIUM'|'HIGH'|'CRITICAL',
        }
        
    Raises:
        ImportError: If required packages not installed
        FileNotFoundError: If credentials not found
        googleapiclient.errors.HttpError: For API errors
    """
    
    try:
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Google API client required. Install with: "
            "pip install sentinel-security[google]"
        )

    # Load credentials if not provided
    if credentials is None:
        credentials = _load_credentials(credentials_path)
    
    # Build Drive API service
    service = build('drive', 'v3', credentials=credentials)
    
    logger.debug("scan_google_drive_file: start file_id=%s", file_id)
    threats = []
    
    # 1. Get file metadata
    try:
        file = service.files().get(
            fileId=file_id,
            fields='id,name,mimeType,description,owners,permissions,appProperties,sharingUser'
        ).execute()
    except Exception as e:
        threats.append({
            'type': 'scan_error',
            'severity': 'HIGH',
            'detail': f'Failed to get file metadata: {str(e)}'
        })
        # Return minimal info with error
        return {
            'info': {'file_id': file_id, 'name': 'Unknown', 'mime_type': 'Unknown', 'owner': 'Unknown'},
            'threats': threats,
            'threat_count': len(threats),
            'risk_score': calculate_threat_risk_score(threats),
            'risk_level': risk_level(calculate_threat_risk_score(threats)),
        }

    # Extract file info
    file_info = {
        'file_id': file_id,
        'name': file.get('name', 'Unknown'),
        'mime_type': file.get('mimeType', 'Unknown'),
        'owner': file.get('owners', [{}])[0].get('displayName', 'Unknown') if file.get('owners') else 'Unknown'
    }
    
    # 2. Check file description for injection patterns
    description = file.get('description', '')
    if description:
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, description, re.IGNORECASE):
                threats.append({
                    'type': 'description_injection',
                    'severity': 'MEDIUM',
                    'detail': 'Injection pattern found in file description'
                })
                break
    
    # 3. Check appProperties for injection patterns
    app_props = file.get('appProperties', {})
    for key, value in app_props.items():
        if isinstance(value, str):
            for pattern in INJECTION_PATTERNS:
                if re.search(pattern, value, re.IGNORECASE):
                    threats.append({
                        'type': 'app_property_injection',
                        'severity': 'MEDIUM',
                        'detail': f'Injection pattern found in app property "{key}"'
                    })
                    break
    
    # 4. Check comments for injection patterns
    try:
        comments_response = service.comments().list(
            fileId=file_id,
            fields='comments(content,author/displayName,resolved)'
        ).execute()
        comments = comments_response.get('comments', [])
        
        for comment in comments:
            content = comment.get('content', '')
            if content:
                for pattern in INJECTION_PATTERNS:
                    if re.search(pattern, content, re.IGNORECASE):
                        author = comment.get('author', {}).get('displayName', 'Unknown')
                        threats.append({
                            'type': 'comment_injection',
                            'severity': 'MEDIUM',
                            'detail': f'Injection pattern found in comment by {author}'
                        })
                        break
    except Exception as e:
        threats.append({
            'type': 'scan_error',
            'severity': 'LOW',
            'detail': f'Failed to retrieve comments: {str(e)}'
        })
    
    # 5. Check revision count (potential obfuscation)
    try:
        revisions_response = service.revisions().list(
            fileId=file_id,
            fields='revisions(id,lastModifyingUser/displayName)'
        ).execute()
        revisions = revisions_response.get('revisions', [])
        
        if len(revisions) > 50:
            threats.append({
                'type': 'high_revision_count',
                'severity': 'LOW',
                'detail': f'File has {len(revisions)} revisions (>50), potential obfuscation'
            })
    except Exception as e:
        threats.append({
            'type': 'scan_error',
            'severity': 'LOW',
            'detail': f'Failed to retrieve revisions: {str(e)}'
        })
    
    # 6. Check external sharing permissions
    try:
        permissions_response = service.permissions().list(
            fileId=file_id,
            fields='permissions(id,type,role,emailAddress,domain)'
        ).execute()
        permissions = permissions_response.get('permissions', [])
        
        for perm in permissions:
            perm_type = perm.get('type', '')
            if perm_type in ['anyone', 'domain']:
                role = perm.get('role', 'unknown')
                domain = perm.get('domain', '')
                detail = f'File shared with {perm_type}'
                if domain:
                    detail += f' ({domain})'
                detail += f' with role: {role}'
                
                threats.append({
                    'type': 'external_sharing',
                    'severity': 'HIGH' if perm_type == 'anyone' else 'MEDIUM',
                    'detail': detail
                })
    except Exception as e:
        threats.append({
            'type': 'scan_error',
            'severity': 'LOW',
            'detail': f'Failed to retrieve permissions: {str(e)}'
        })
    
    logger.debug("scan_google_drive_file: end file_id=%s threats=%d", file_id, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_google_drive_file: threats detected count=%d types=%s", len(threats), types)
    # Calculate risk score and level
    risk_score = calculate_threat_risk_score(threats)
    _risk_level = risk_level(risk_score)
    
    return {
        'info': file_info,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': _risk_level,
    }
