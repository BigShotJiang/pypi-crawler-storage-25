"""Rules loader: loads detection patterns from JSON data bundle.

Phase 1: loads from plaintext rule_bundle_data.json (default)
Phase 2+: loads from encrypted bundles via Cloudflare Worker

Feature flag: SENTINEL_USE_ENCRYPTED_RULES=true enables the encrypted path.
"""
import hashlib
import json
import logging
import os
import re
import threading
import time
import warnings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Phase 1 plaintext loader (unchanged from Wave 1)
# ---------------------------------------------------------------------------

_rules_data = None
_compiled_cache = {}


def _default_bundle_path():
    return os.path.join(os.path.dirname(__file__), 'rule_bundle_data.json')


def load_rules(data: dict = None, path: str = None):
    """Load rules from a dict or JSON file path."""
    global _rules_data, _compiled_cache
    if data is not None:
        _rules_data = data
    elif path is not None:
        with open(path, 'r') as f:
            _rules_data = json.load(f)
    else:
        with open(_default_bundle_path(), 'r') as f:
            _rules_data = json.load(f)
    _compiled_cache = {}


def get_rules_data() -> dict:
    """Get the loaded rules data, loading defaults if needed."""
    global _rules_data
    if _rules_data is None:
        if _use_encrypted_rules():
            encrypted_rules = get_rules()
            if encrypted_rules is not None:
                return encrypted_rules
        load_rules()
    return _rules_data


def get_patterns() -> dict:
    """Get the patterns section of the rules data."""
    return get_rules_data().get('patterns', {})


def get_code_detector_patterns() -> dict:
    """Get code detector regex patterns (source strings + flags)."""
    return get_rules_data().get('code_detector_patterns', {})


def get_code_detector_keywords() -> dict:
    """Get code detector keyword sets."""
    return get_rules_data().get('code_detector_keywords', {})


def compile_pattern(name: str) -> 're.Pattern':
    """Compile and cache a named pattern from the bundle."""
    global _compiled_cache
    if name in _compiled_cache:
        return _compiled_cache[name]
    patterns = get_code_detector_patterns()
    if name not in patterns:
        raise KeyError(f"Unknown pattern: {name}")
    entry = patterns[name]
    if isinstance(entry, dict):
        flags = 0
        flag_str = entry.get('flags', '')
        if 'IGNORECASE' in flag_str:
            flags |= re.IGNORECASE
        compiled = re.compile(entry['pattern'], flags)
    else:
        compiled = re.compile(entry)
    _compiled_cache[name] = compiled
    return compiled


def get_keyword_set(name: str) -> frozenset:
    """Get a named keyword set from the bundle."""
    keywords = get_code_detector_keywords()
    if name not in keywords:
        raise KeyError(f"Unknown keyword set: {name}")
    return frozenset(keywords[name])


def get_detector_patterns() -> dict:
    """Get detector patterns (SAFE_IMAGE_DOMAINS, EXFIL_PARAM_NAMES, ENCODED_STRUCT, etc.)."""
    return get_rules_data().get('detector_patterns', {})


def get_scorer_patterns() -> dict:
    """Get scorer regex patterns (SHELL_CMD_RE, EXTERNAL_URL_RE, CREDENTIAL_URGENCY_RE)."""
    return get_rules_data().get('scorer_patterns', {})


def get_risk_weights() -> dict:
    """Get the risk weights dict for threat scoring."""
    return get_rules_data().get('risk_weights', {})


# ---------------------------------------------------------------------------
# Feature flag
# ---------------------------------------------------------------------------

def _use_encrypted_rules() -> bool:
    """Check whether the encrypted rules feature flag is enabled."""
    val = os.environ.get('SENTINEL_USE_ENCRYPTED_RULES', '').lower()
    return val in ('true', '1', 'yes')


# ---------------------------------------------------------------------------
# Custom warning / error classes
# ---------------------------------------------------------------------------

class SentinelDegradedWarning(UserWarning):
    """Emitted when Sentinel operates in degraded mode (offline/expired cache)."""
    pass


class SentinelBundleTamperError(Exception):
    """Raised when bundle signature or integrity check fails."""
    pass


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Ed25519 public key for bundle signature verification (base64-encoded raw bytes).
# This is replaced at release time with the production signing key.
SIGNING_PUBLIC_KEY_B64 = '5hYb2VP0JO5E4MTVlosN99yA62VtN6M/lr0jZHMEJUk='

# PBKDF2 parameters
PBKDF2_ITERATIONS = 100_000
KEY_LENGTH = 32  # 256-bit

# Static salt for encrypting the cached key_component
STATIC_SALT = b'sentinel-key-material-v1'

# HKDF info string for final key derivation
HKDF_INFO = b'sentinel-rules-v1'

# PBKDF2 salt domain separator
PBKDF2_SALT_DOMAIN = b'sentinel-pbkdf2-v1'

# Default API endpoint
DEFAULT_RULES_ENDPOINT = 'https://sentinel-rules.satvoop.workers.dev/api/rules'

# Cache directory
CACHE_DIR_NAME = os.path.join('.sentinel', 'rules-cache')

# TTL defaults
DEFAULT_TTL_SECONDS = 604800  # 7 days
GRACE_WINDOW_SECONDS = 86400  # 1 day

# Minimum bundle version this client supports
MIN_SUPPORTED_BUNDLE_VERSION = '0.9.0'


# ---------------------------------------------------------------------------
# Encrypted Rules Loader
# ---------------------------------------------------------------------------

class EncryptedRulesLoader:
    """Manages encrypted rule bundle lifecycle: fetch, cache, decrypt, expose.

    Thread-safe singleton. Lazy-initialised on first get_rules() call.
    """

    def __init__(self, licence_key: str = None):
        self._licence_key = licence_key or os.environ.get('SENTINEL_LICENCE_KEY')
        self._rules = None
        self._init_lock = threading.Lock()
        self._initialized = False
        self._degraded = False
        self._degraded_reason = None
        self._bg_refresh_failed = False

    @property
    def degraded(self) -> bool:
        return self._degraded

    def get_rules(self) -> dict:
        """Return decrypted rules, initialising on first call. Thread-safe."""
        if self._initialized:
            return self._rules
        with self._init_lock:
            if not self._initialized:
                self._rules = self._load_rules()
                self._initialized = True
        return self._rules

    def clear_cache(self):
        """Clear the local cache directory (for testing / admin use)."""
        import shutil
        cache_dir = self._cache_dir()
        if os.path.isdir(cache_dir):
            shutil.rmtree(cache_dir, ignore_errors=True)

    def _cache_dir(self) -> str:
        return os.path.join(os.path.expanduser('~'), CACHE_DIR_NAME)

    def _key_hash(self) -> str:
        return hashlib.sha256(self._licence_key.encode('utf-8')).hexdigest()

    def _key_hash_prefix(self) -> str:
        return self._key_hash()[:8]

    def _cache_meta_path(self) -> str:
        return os.path.join(self._cache_dir(), f'cache-meta-{self._key_hash_prefix()}.json')

    def _cache_bundle_path(self) -> str:
        return os.path.join(self._cache_dir(), f'bundle-{self._key_hash_prefix()}.enc')

    def _cache_key_material_path(self) -> str:
        return os.path.join(self._cache_dir(), f'key-material-{self._key_hash_prefix()}.enc')

    def _load_rules(self) -> dict:
        """Core loading logic: check cache, fetch if needed, decrypt."""
        if not self._licence_key:
            self._degraded = True
            self._degraded_reason = 'no_licence_key'
            warnings.warn(
                'SENTINEL_LICENCE_KEY not set. Running in degraded mode.',
                SentinelDegradedWarning,
                stacklevel=3,
            )
            return None

        # Try cache first
        cache_result = self._check_cache()
        if cache_result == 'VALID':
            rules = self._decrypt_cached_bundle()
            if rules is not None:
                return rules
            # Cache was tampered or corrupted — fall through to fetch
        elif cache_result == 'REFRESHING':
            rules = self._decrypt_cached_bundle()
            if rules is not None:
                # Background refresh (best-effort)
                self._background_refresh()
                return rules
            # Cache was tampered or corrupted — fall through to fetch

        # Need to fetch (EMPTY, EXPIRED, GRACE, or tampered cache)
        try:
            response = self._fetch_from_server()
            if response is None:
                # Server returned error (licence issue)
                return self._handle_fetch_failure(cache_result)
            return self._process_server_response(response)
        except Exception as exc:
            logger.warning('Failed to fetch rules from server: %s', exc)
            return self._handle_fetch_failure(cache_result)

    def _check_cache(self) -> str:
        """Check cache state. Returns: VALID, REFRESHING, EXPIRED, GRACE, EMPTY."""
        meta_path = self._cache_meta_path()
        if not os.path.exists(meta_path):
            return 'EMPTY'

        try:
            with open(meta_path, 'r') as f:
                meta = json.load(f)
        except (json.JSONDecodeError, OSError):
            return 'EMPTY'

        fetched_at = meta.get('fetched_at', 0)
        ttl = meta.get('ttl_seconds', DEFAULT_TTL_SECONDS)

        # Check for TTL override from env
        ttl_override = os.environ.get('SENTINEL_RULES_TTL_DAYS')
        if ttl_override:
            try:
                override_days = max(1, min(30, int(ttl_override)))
                override_seconds = override_days * 86400
                ttl = min(ttl, override_seconds)
            except ValueError:
                pass

        cache_age = time.time() - fetched_at
        refresh_threshold = ttl - GRACE_WINDOW_SECONDS

        if cache_age < refresh_threshold:
            return 'VALID'
        elif cache_age < ttl:
            return 'REFRESHING'
        elif cache_age < ttl + GRACE_WINDOW_SECONDS:
            return 'GRACE'
        else:
            return 'EXPIRED'

    def _decrypt_cached_bundle(self) -> dict:
        """Decrypt a cached bundle using stored key material."""
        import base64
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            from cryptography.hazmat.primitives.kdf.hkdf import HKDF
            from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        except ImportError:
            warnings.warn(
                'cryptography package not installed. '
                'Install with: pip install sentinel-security[encrypted-rules]',
                ImportWarning,
                stacklevel=2,
            )
            logger.error(
                'cryptography package not installed. '
                'Install with: pip install sentinel-security[encrypted-rules]'
            )
            return None

        try:
            # Read cached files
            with open(self._cache_bundle_path(), 'rb') as f:
                bundle_data = f.read()
            with open(self._cache_key_material_path(), 'rb') as f:
                encrypted_key_material = f.read()
            with open(self._cache_meta_path(), 'r') as f:
                meta = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning('Cache read error: %s', exc)
            return None

        try:
            bundle = json.loads(bundle_data.decode('utf-8'))
            enc = bundle['encryption']
            ciphertext = base64.b64decode(enc['ciphertext'])
            iv = base64.b64decode(enc['iv'])

            # Re-verify Ed25519 signature before decrypting (P0-4)
            cached_sig = meta.get('signature')
            if cached_sig:
                sig_bytes = base64.b64decode(cached_sig)
                signing_input = ciphertext + iv
                pub_key = Ed25519PublicKey.from_public_bytes(
                    base64.b64decode(SIGNING_PUBLIC_KEY_B64)
                )
                pub_key.verify(sig_bytes, signing_input)

            # Step 1: Decrypt the stored key_component
            kek = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=KEY_LENGTH,
                salt=STATIC_SALT,
                iterations=PBKDF2_ITERATIONS,
            ).derive(self._licence_key.encode('utf-8'))

            # encrypted_key_material format: iv (12 bytes) + ciphertext + tag (16 bytes)
            km_iv = encrypted_key_material[:12]
            km_blob = encrypted_key_material[12:]
            aesgcm_kek = AESGCM(kek)
            server_component = aesgcm_kek.decrypt(km_iv, km_blob, None)

            # Step 2: Derive the bundle decryption key
            bundle_id = meta.get('bundle_id', '')
            decryption_key = self._derive_decryption_key(server_component, bundle_id)

            # Step 3: Decrypt the bundle
            auth_tag = base64.b64decode(enc['tag'])
            aesgcm = AESGCM(decryption_key)
            plaintext = aesgcm.decrypt(iv, ciphertext + auth_tag, None)

            return json.loads(plaintext.decode('utf-8'))

        except Exception as exc:
            logger.warning('Cache decryption failed (corrupted or tampered): %s', exc)
            # Corrupted or tampered cache — clear it
            self.clear_cache()
            return None

    def _derive_decryption_key(self, server_component: bytes, bundle_id: str) -> bytes:
        """Derive the AES-256 decryption key from licence_key + server_component."""
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes

        key_hash = self._key_hash()

        # Step 1: PBKDF2 from licence key
        pbkdf2_salt = hashlib.sha256(
            key_hash.encode('utf-8') + PBKDF2_SALT_DOMAIN
        ).digest()
        client_km = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_LENGTH,
            salt=pbkdf2_salt,
            iterations=PBKDF2_ITERATIONS,
        ).derive(self._licence_key.encode('utf-8'))

        # Step 2: XOR with server component
        ikm = bytes(a ^ b for a, b in zip(client_km, server_component))

        # Step 3: HKDF
        decryption_key = HKDF(
            algorithm=hashes.SHA256(),
            length=KEY_LENGTH,
            salt=bundle_id.encode('utf-8'),
            info=HKDF_INFO,
        ).derive(ikm)

        return decryption_key

    def _fetch_from_server(self) -> dict:
        """Fetch rules from the Cloudflare Worker. Returns response dict or None."""
        import urllib.request
        import urllib.error

        endpoint = os.environ.get('SENTINEL_RULES_ENDPOINT', DEFAULT_RULES_ENDPOINT)
        key_hash = self._key_hash()

        payload = json.dumps({
            'key_hash': key_hash,
            'bundle_version_floor': MIN_SUPPORTED_BUNDLE_VERSION,
        }).encode('utf-8')

        req = urllib.request.Request(
            endpoint,
            data=payload,
            headers={'Content-Type': 'application/json'},
            method='POST',
        )

        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                if resp.status == 200:
                    return json.loads(resp.read().decode('utf-8'))
                else:
                    return None
        except urllib.error.HTTPError as exc:
            if exc.code == 402:
                try:
                    body = json.loads(exc.read().decode('utf-8'))
                    error_code = body.get('error', 'licence_invalid')
                except Exception:
                    error_code = 'licence_error'
                logger.warning('Licence validation failed: %s', error_code)
                self._degraded = True
                self._degraded_reason = error_code
                warnings.warn(
                    f'Sentinel licence issue: {error_code}',
                    SentinelDegradedWarning,
                    stacklevel=4,
                )
            return None
        except (urllib.error.URLError, OSError) as exc:
            raise ConnectionError(f'Cannot reach rules server: {exc}') from exc

    def _process_server_response(self, response: dict) -> dict:
        """Verify signature, decrypt bundle, update cache."""
        import base64
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        except ImportError:
            warnings.warn(
                'cryptography package not installed. '
                'Install with: pip install sentinel-security[encrypted-rules]',
                ImportWarning,
                stacklevel=2,
            )
            logger.error(
                'cryptography package not installed. '
                'Install with: pip install sentinel-security[encrypted-rules]'
            )
            return None

        # Decode bundle from base64
        bundle_json = base64.b64decode(response['bundle']).decode('utf-8')
        bundle = json.loads(bundle_json)
        key_component = base64.b64decode(response['key_component'])
        bundle_id = response['bundle_id']
        bundle_version = response['bundle_version']
        ttl_seconds = response.get('ttl_seconds', DEFAULT_TTL_SECONDS)
        tier = response.get('tier', 'individual')

        # Verify Ed25519 signature
        sig_block = bundle.get('signature', {})
        enc_block = bundle.get('encryption', {})

        sig_bytes = base64.b64decode(sig_block['signature'])
        ciphertext_bytes = base64.b64decode(enc_block['ciphertext'])
        iv_bytes = base64.b64decode(enc_block['iv'])

        # Canonical signing input: ciphertext + iv (matches compile-rules.py)
        signing_input = ciphertext_bytes + iv_bytes

        try:
            pub_key = Ed25519PublicKey.from_public_bytes(
                base64.b64decode(SIGNING_PUBLIC_KEY_B64)
            )
            pub_key.verify(sig_bytes, signing_input)
        except Exception as exc:
            raise SentinelBundleTamperError(
                f'Bundle signature verification failed: {exc}'
            ) from exc

        # Derive decryption key
        decryption_key = self._derive_decryption_key(key_component, bundle_id)

        # Decrypt
        auth_tag = base64.b64decode(enc_block['tag'])
        aesgcm = AESGCM(decryption_key)
        plaintext = aesgcm.decrypt(iv_bytes, ciphertext_bytes + auth_tag, None)
        rules = json.loads(plaintext.decode('utf-8'))

        # Write cache (include signature for re-verification on cache read)
        sig_b64 = base64.b64encode(sig_bytes).decode('ascii')
        self._write_cache(bundle_json, key_component, bundle_id, bundle_version, ttl_seconds, tier, sig_b64)

        return rules

    def _write_cache(self, bundle_json: str, key_component: bytes,
                     bundle_id: str, bundle_version: str,
                     ttl_seconds: int, tier: str, signature_b64: str = None):
        """Write encrypted bundle, key material, and metadata to cache."""
        import base64
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
            from cryptography.hazmat.primitives import hashes
        except ImportError:
            warnings.warn(
                'cryptography package not installed. '
                'Install with: pip install sentinel-security[encrypted-rules]',
                ImportWarning,
                stacklevel=2,
            )
            logger.error(
                'cryptography package not installed. '
                'Install with: pip install sentinel-security[encrypted-rules]'
            )
            return

        cache_dir = self._cache_dir()
        os.makedirs(cache_dir, mode=0o700, exist_ok=True)

        # Write bundle (already encrypted ciphertext)
        self._write_file_secure(self._cache_bundle_path(), bundle_json.encode('utf-8'))

        # Encrypt key_component with PBKDF2(licence_key, STATIC_SALT)
        kek = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_LENGTH,
            salt=STATIC_SALT,
            iterations=PBKDF2_ITERATIONS,
        ).derive(self._licence_key.encode('utf-8'))

        iv = os.urandom(12)
        aesgcm = AESGCM(kek)
        encrypted_km = aesgcm.encrypt(iv, key_component, None)

        self._write_file_secure(self._cache_key_material_path(), iv + encrypted_km)

        # Write metadata (includes Ed25519 signature for re-verification on cache read)
        meta = {
            'bundle_version': bundle_version,
            'bundle_id': bundle_id,
            'fetched_at': int(time.time()),
            'ttl_seconds': ttl_seconds,
            'tier': tier,
            'bundle_hash': hashlib.sha256(bundle_json.encode('utf-8')).hexdigest(),
        }
        if signature_b64:
            meta['signature'] = signature_b64
        self._write_file_secure(
            self._cache_meta_path(),
            json.dumps(meta).encode('utf-8'),
        )

    @staticmethod
    def _write_file_secure(path: str, data: bytes):
        """Write data to path with 0o600 permissions (owner-only read/write)."""
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'wb') as f:
            f.write(data)

    def _background_refresh(self):
        """Spawn a background thread to refresh the cache."""
        def _refresh():
            try:
                response = self._fetch_from_server()
                if response is not None:
                    self._process_server_response(response)
                    self._bg_refresh_failed = False
            except Exception as exc:
                if not self._bg_refresh_failed:
                    logger.warning('Background refresh failed: %s', exc)
                    self._bg_refresh_failed = True
                else:
                    logger.debug('Background refresh failed (repeated): %s', exc)

        t = threading.Thread(target=_refresh, daemon=True)
        t.start()

    def _handle_fetch_failure(self, cache_state: str) -> dict:
        """Handle fetch failure based on cache state."""
        if cache_state in ('GRACE', 'REFRESHING'):
            # Use stale cache
            self._degraded = True
            self._degraded_reason = 'offline_stale_cache'
            warnings.warn(
                'Sentinel rules server unreachable. Using stale cached rules.',
                SentinelDegradedWarning,
                stacklevel=4,
            )
            rules = self._decrypt_cached_bundle()
            if rules is not None:
                return rules

        # Fully degraded — no usable rules
        self._degraded = True
        self._degraded_reason = 'rules_unavailable'
        warnings.warn(
            'Sentinel rules unavailable. Running in degraded mode (no detection).',
            SentinelDegradedWarning,
            stacklevel=4,
        )
        return None


# ---------------------------------------------------------------------------
# Module-level singleton and convenience function
# ---------------------------------------------------------------------------

_global_encrypted_loader = None
_global_loader_lock = threading.Lock()


def get_rules() -> dict:
    """Get rules using the encrypted loader (when feature flag is on).

    Returns the decrypted rules dict, or None if unavailable.
    """
    global _global_encrypted_loader
    if _global_encrypted_loader is None:
        with _global_loader_lock:
            if _global_encrypted_loader is None:
                _global_encrypted_loader = EncryptedRulesLoader()
    return _global_encrypted_loader.get_rules()


def is_degraded() -> bool:
    """Check if the loader is in degraded mode."""
    if _global_encrypted_loader is None:
        return False
    return _global_encrypted_loader.degraded
