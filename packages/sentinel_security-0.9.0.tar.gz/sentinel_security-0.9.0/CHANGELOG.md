# Changelog

All notable changes to `sentinel-security` will be documented in this file.

## [0.9.0] - 2026-03-19

### Added

- **Framework middleware support**: drop-in runtime security for AI agent frameworks
  - `SentinelMiddleware` for LangChain v1+ agents (`create_agent()` with `before_model`/`after_model` hooks)
  - `SentinelCallbackHandler` for LangChain legacy, LangGraph, and raw `BaseChatModel` (observation-only via `BaseCallbackHandler`)
  - `sentinel_wrap()` for OpenAI SDK (`OpenAI`, `AsyncOpenAI`) and Anthropic SDK (`Anthropic`, `AsyncAnthropic`)
  - Full streaming support for both OpenAI and Anthropic (buffered scan on completion)
- **DetectionEngine v1**: shared scanning core used by all middleware adapters. Wraps `sanitise_content()` with policy enforcement, risk thresholds, and structured audit logging
- **Global `configure()` function**: set defaults for policy, risk threshold, event handler, licence key, and logging across all middleware instances
- **Python-only licence validation** (`sentinel_security.licence`): validates licence keys via SHA-256 hash over HTTPS. Cached 24h (valid) / 5min (invalid). Offline-safe.
- **Structured audit logging** (`ScanEvent`): every scan emits a structured event to Python's `logging` module with scan ID, risk score, threats, action taken, and timing. SOC2-safe by default (no content in events unless `log_content=True`)
- **`SentinelBlockedError` exception**: raised when `policy="block"` and risk exceeds threshold, includes full `ScanResult` for inspection
- Optional dependency extras: `pip install sentinel-security[langchain]` and `pip install sentinel-security[frameworks]`
- Environment variable configuration: `SENTINEL_POLICY`, `SENTINEL_RISK_THRESHOLD`, `SENTINEL_LOG_CONTENT`, `SENTINEL_LICENCE_KEY`, `SENTINEL_TELEMETRY`
- 741 tests (unit + integration + benchmarks)

## [0.8.0] - 2026-03-15

### Added

- Initial release with `sanitise_content()`, prompt auditing, CLI, and file scanners
- Google Sheets scanning
- Microsoft Office online scanning
- PDF, CSV, email (.eml, .msg), calendar (.ics), image metadata scanning
- Structured data scanning (JSON, YAML, XML)
