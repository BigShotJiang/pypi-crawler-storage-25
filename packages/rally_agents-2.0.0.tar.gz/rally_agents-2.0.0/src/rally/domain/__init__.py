"""Pure Rally runtime contracts."""
