"""Adapter integrations for Rally."""
