from setuptools import setup, find_packages

setup(
    name="pyzero-joystick",
    version="0.1.2",
    packages=find_packages(),
    install_requires=["inputs"],
    author="TuNombre",
    description="Joystick simple estilo Pygame Zero",
)
