# aiogram photo updated
python photo updated for newest telegram api SDK
