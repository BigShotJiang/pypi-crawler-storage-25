from setuptools import setup, find_packages

setup(
    name="aiogram-photo-updater",
    version="1.0.2",
    packages=find_packages(),
    install_requires=["aiogram>=3.0.0"],
)