# ol-anura

Python package for Anura schemas and core utilities.

## Install

```bash
pip install ol-anura
```

## Usage

```python
import ol_anura
```
