"""Library setup file."""

from setuptools import find_packages, setup

install_requires = [
    "pydantic>=2.0.0",
]


def read_version() -> str:
    """Read the package version from _version.py."""
    import os

    version_ns = {}
    here = os.path.abspath(os.path.dirname(__file__))
    version_path = os.path.join(here, "ol_anura", "_version.py")
    with open(version_path, "r", encoding="utf-8") as f:
        exec(f.read(), version_ns)
    return version_ns["__version__"]


def read_long_description() -> str:
    """Read the long description from README.md."""
    import os

    here = os.path.abspath(os.path.dirname(__file__))
    md_path = os.path.join(here, "README.md")
    with open(md_path, "r", encoding="utf-8") as f:
        return f.read()


setup(
    name="ol_anura",
    include_package_data=True,
    version=read_version(),
    description="Schemas and core utilities for Anura projects",
    long_description=read_long_description(),
    long_description_content_type="text/markdown",
    url="https://optilogic.com",
    author="Optilogic",
    packages=find_packages(),
    license="MIT",
    install_requires=install_requires,
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
)
