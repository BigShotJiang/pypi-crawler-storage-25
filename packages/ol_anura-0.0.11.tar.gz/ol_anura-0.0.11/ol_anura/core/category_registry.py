"""
Category registry for Anura table organization.

This module provides a central registry for table categorization and UI ordering.
It avoids duplication of category metadata across individual table schemas.

Design:
- Category names as enum for type safety
- CATEGORY_ORDER: ordered list for UI category display
- TABLE_GRID_ORDER: dict mapping categories to ordered table lists
- VIEWS: registry-only views that are intentionally not yet
  represented as Python schema files
- Utility functions for querying the registry

Maintenance note:
- Category and grid ordering are maintained here.
- Some legacy views may remain in this registry before they are migrated into
  Python schema definitions.
"""

from enum import Enum
from typing import Dict, List, Tuple


class Category(str, Enum):
    """
    Table categories for UI organization.

    These categories group related tables together in the user interface.
    The order of categories is defined in CATEGORY_ORDER.
    """

    MODEL_ELEMENTS = "Model Elements"
    SOURCING = "Sourcing"
    INVENTORY = "Inventory"
    TRANSPORTATION = "Transportation"
    PRODUCTION = "Production"
    DEMAND = "Demand"
    CONSTRAINTS = "Constraints"
    RISK_INPUTS = "Risk Inputs"
    ELEMENT_DETAILS = "Element Details"
    MULTI_TIME_PERIOD = "Multi-Time Period"
    FUNCTIONAL_TABLES = "Functional Tables"
    OUTPUT_SUMMARY_TABLES = "Output Summary Tables"
    OUTPUT_RISK_TABLES = "Output Risk Tables"
    OUTPUT_REPORT_TABLES = "Output Report Tables"
    OUTPUT_QUEUE_TABLES = "Output Queue Tables"
    OUTPUT_REPLICATION_TABLES = "Output Replication Tables"


# Category display order for UI
# Tables are shown in this category order
CATEGORY_ORDER: List[Category] = [
    Category.MODEL_ELEMENTS,
    Category.SOURCING,
    Category.INVENTORY,
    Category.TRANSPORTATION,
    Category.PRODUCTION,
    Category.DEMAND,
    Category.CONSTRAINTS,
    Category.RISK_INPUTS,
    Category.ELEMENT_DETAILS,
    Category.MULTI_TIME_PERIOD,
    Category.FUNCTIONAL_TABLES,
    Category.OUTPUT_SUMMARY_TABLES,
    Category.OUTPUT_RISK_TABLES,
    Category.OUTPUT_REPORT_TABLES,
    Category.OUTPUT_QUEUE_TABLES,
    Category.OUTPUT_REPLICATION_TABLES,
]


# Table ordering within each category
# Key: Category
# Value: List of table names in grid order for that category
TABLE_GRID_ORDER: Dict[Category, List[str]] = {
    Category.MODEL_ELEMENTS: [
        "Customers",
        "Facilities",
        "Suppliers",
        "Products",
        "Periods",
        "Organizations",
    ],
    Category.SOURCING: [
        "CustomerFulfillmentPolicies",
        "ReplenishmentPolicies",
        "ProductionPolicies",
        "ProcurementPolicies",
        "SupplierCapabilities",
        "ReturnPolicies",
        "ReturnRatios",
    ],
    Category.INVENTORY: [
        "InventoryPolicies",
        "UserDefinedForecasts",
        "UserDefinedForecastsData",
        "WarehousingPolicies",
        "OrderFulfillmentPolicies",
        "InventoryPoliciesAdvanced",
    ],
    Category.TRANSPORTATION: [
        "TransportationPolicies",
        "TransportationLaneQueueDetails",
        "TransportationLaneModeQueueDetails",
        "TransportationModes",
        "TransportationAssets",
        "TransportationBandCosting",
        "Tariffs",
        "TransitMatrix",
        "TransportationRates",
        "TransportationStopRates",
        "TransportationDriverRates",
        "TransportationUserDefinedActivities",
        "TransportationUserDefinedResets",
        "TransportationUserDefinedDetours",
        "TransportationRoutePlanners",
        "FixedRoutes",
        "FixedRoutesDefinitions",
        "TransportationDrivers",
        "CompartmentConfigurations",
    ],
    Category.PRODUCTION: [
        "Processes",
        "BillsOfMaterials",
        "WorkCenters",
        "ProductionQueueDetails",
        "WorkCenterQueueDetails",
        "ProductionWheelDetails",
        "ProductionWheelGroupDetails",
        "WorkResources",
        "ChangeoverTimes",
    ],
    Category.DEMAND: [
        "CustomerDemand",
        "FacilityDemand",
        "CustomerOrders",
        "CustomerOrderProfiles",
        "ReplenishmentOrders",
        "ReplenishmentOrderProfiles",
        "ProcurementOrders",
        "ProcurementOrderProfiles",
        "ProductionOrders",
        "ProductionOrderProfiles",
        "OrderedProductSubstitution",
        "OrderProfileProductSelection",
        "OrderProfileProductAffinity",
        "Shipments",
        "TemplateRoutes",
        "LoadBalancingDemand",
        "LoadBalancingSchedules",
    ],
    Category.CONSTRAINTS: [
        "FlowConstraints",
        "InventoryConstraints",
        "ProductionConstraints",
        "FlowCountConstraints",
        "InventoryCountConstraints",
        "ProductionCountConstraints",
        "FacilityCountConstraints",
        "WorkCenterCountConstraints",
        "CustomerDemandOriginConstraints",
        "CustomerTransitConstraints",
        "GreenfieldServiceBands",
        "UserDefinedVariables",
        "UserDefinedConstraints",
        "UserDefinedCosts",
        "SequentialObjectives",
        "RelationshipConstraints",
        "TransportationUserDefinedVariables",
        "IncrementalChangeConstraints",
        "TransportationAssetConstraints",
    ],
    Category.RISK_INPUTS: [
        "RiskRatingConfigurations",
        "RiskSummaryConfigurations",
        "CustomerRiskConfigurations",
        "FacilityRiskConfigurations",
        "SupplierRiskConfigurations",
        "GeographicRiskConfigurations",
        "UtilizationRiskConfigurations",
        "NetworkRiskConfigurations",
        "RiskBandDefinitions",
    ],
    Category.ELEMENT_DETAILS: [
        "AdvancedQueueingDetails",
        "BusinessHours",
        "BusinessCalendars",
        "Groups",
        "UnitsOfMeasure",
        "ProductUnitsOfMeasure",
        "TableFilters",
        "ReviewSchedules",
        "SKULevelOutputMapping",
        "SelectiveTransactionReporting",
    ],
    Category.MULTI_TIME_PERIOD: [
        "CustomersMultiTimePeriod",
        "FacilitiesMultiTimePeriod",
        "SuppliersMultiTimePeriod",
        "ProductsMultiTimePeriod",
        "CustomerFulfillmentPoliciesMultiTimePeriod",
        "ReplenishmentPoliciesMultiTimePeriod",
        "ProductionPoliciesMultiTimePeriod",
        "ProcurementPoliciesMultiTimePeriod",
        "SupplierCapabilitiesMultiTimePeriod",
        "ReturnPoliciesMultiTimePeriod",
        "InventoryPoliciesMultiTimePeriod",
        "WarehousingPoliciesMultiTimePeriod",
        "TransportationPoliciesMultiTimePeriod",
        "TransportationModesMultiTimePeriod",
        "TransportationAssetsMultiTimePeriod",
        "ProcessesMultiTimePeriod",
        "WorkCentersMultiTimePeriod",
        "WorkResourcesMultiTimePeriod",
        "TariffsMultiTimePeriod",
    ],
    Category.FUNCTIONAL_TABLES: [
        "StepCosts",
        "Lookups",
        "Histograms",
        "CategoricalDistributions",
        "GreenfieldSettings",
        "InventorySettings",
        "ModelSettings",
        "ModelRunOptions",
        "Scenarios",
        "ScenarioItems",
        "ScenarioRules",
        "ScenarioRuleItemAssignments",
        "ScenarioItemAssignments",
        "CustomSimulationScripts",
        "InputFactors",
        "OutputFactors",
        "ModelInfo",
        "Maps",
        "Analytics",
        "DetailedRoadNetworks",
        "TerritoryPlanningSettings",
        "TemplateTerritories",
        "UtilityCurves",
    ],
    Category.OUTPUT_SUMMARY_TABLES: [
        "OptimizationNetworkSummary",
        "OptimizationCustomerSummary",
        "OptimizationDemandSummary",
        "OptimizationDemandOriginSummary",
        "OptimizationCostToServeSummary",
        "OptimizationFacilitySummary",
        "OptimizationFacilityDemandSummary",
        "OptimizationFacilityCostToServeSummary",
        "OptimizationSupplierSummary",
        "OptimizationProductionAgeSummary",
        "OptimizationProductionSummary",
        "OptimizationSupplySummary",
        "OptimizationFlowAgeSummary",
        "OptimizationFlowSummary",
        "OptimizationFlowRouteSummary",
        "OptimizationShipmentSummary",
        "OptimizationReturnSummary",
        "OptimizationPathFlowSummary",
        "OptimizationTariffSummary",
        "OptimizationInventoryAgeSummary",
        "OptimizationInventorySummary",
        "OptimizationWarehousingSummary",
        "OptimizationBillsOfMaterialSummary",
        "OptimizationWorkCenterSummary",
        "OptimizationProcessSummary",
        "OptimizationChangeoverSummary",
        "OptimizationDisposalSummary",
        "OptimizationCostToServeParentInformationReport",
        "OptimizationCostToServePathSummary",
        "OptimizationCostToServePathSegmentDetails",
        "OptimizationCO2EmissionsSummary",
        "OptimizationConstraintSummary",
        "OptimizationUserDefinedVariableSummary",
        "OptimizationUserDefinedVariableTermSummary",
        "OptimizationUserDefinedCostSummary",
        "OptimizationSequentialObjectiveSummary",
        "OptimizationIncrementalChangeSummary",
        "OptimizationGreenfieldNetworkSummary",
        "OptimizationGreenfieldCustomerSummary",
        "OptimizationGreenfieldFacilitySummary",
        "OptimizationGreenfieldFlowSummary",
        "OptimizationGreenfieldSupplierSummary",
        "OptimizationGreenfieldServiceBandSummary",
        "SimulationNetworkSummary",
        "SimulationNetworkServiceSummary",
        "SimulationCustomerSummary",
        "SimulationCustomerServiceSummary",
        "SimulationCustomerProductSummary",
        "SimulationCustomerProductServiceSummary",
        "SimulationFacilitySummary",
        "SimulationFacilityServiceSummary",
        "SimulationFacilityProductSummary",
        "SimulationFacilityProductServiceSummary",
        "SimulationSupplierSummary",
        "SimulationSupplierProductSummary",
        "SimulationLaneSummary",
        "SimulationFlowSummary",
        "SimulationWorkCenterSummary",
        "SimulationProcessSummary",
        "SimulationEvolutionaryAlgorithmSummary",
        "SimulationTransportationAssetSummary",
        "TransportationSummary",
        "TransportationRouteSummary",
        "TransportationAssetSummary",
        "TransportationShipmentSummary",
        "TransportationStopSummary",
        "TransportationSegmentSummary",
        "TransportationTourSummary",
        "TransportationRoutesMapLayer",
        "TransportationLoadBalancingSummary",
        "TransportationUserDefinedVariableSummary",
        "TransportationUserDefinedVariableTermSummary",
        "TransportationUserDefinedCostSummary",
        "TransportationTerritoryPlanningSummary",
        "TransportationTerritoryAssignmentSummary",
        "TransportationDriverRateSummary",
        "InventoryDemandClassificationSummary",
        "InventoryPolicyDataSummary",
        "SimulationTariffSummary",
        "InventorySafetyStockSummary",
        "InventoryNetworkSummary",
    ],
    Category.OUTPUT_RISK_TABLES: [
        "OptimizationRiskMetricsSummary",
        "OptimizationCustomerRiskMetrics",
        "OptimizationFacilityRiskMetrics",
        "OptimizationSupplierRiskMetrics",
        "OptimizationGeographicRiskMetrics",
        "OptimizationUtilizationRiskMetrics",
        "OptimizationNetworkRiskMetrics",
        "OptimizationProductRiskMetrics",
        "OptimizationGreenfieldRiskMetricsSummary",
        "OptimizationGreenfieldCustomerRiskMetrics",
        "OptimizationGreenfieldFacilityRiskMetrics",
        "OptimizationGreenfieldSupplierRiskMetrics",
        "OptimizationGreenfieldGeographicRiskMetrics",
        "OptimizationGreenfieldNetworkRiskMetrics",
        "SimulationRiskMetricsSummary",
        "SimulationCustomerRiskMetrics",
        "SimulationFacilityRiskMetrics",
        "SimulationSupplierRiskMetrics",
        "SimulationGeographicRiskMetrics",
        "SimulationNetworkRiskMetrics",
        "SimulationProductRiskMetrics",
    ],
    Category.OUTPUT_REPORT_TABLES: [
        "OptimizationValidationErrorReport",
        "OptimizationGreenfieldValidationErrorReport",
        "OptimizationIncrementalChangeReport",
        "TransportationValidationErrorReport",
        "TransportationActivityReport",
        "TransportationUnroutedShipmentReport",
        "SimulationOrderReport",
        "SimulationShipmentReport",
        "SimulationInventoryOnHandReport",
        "SimulationProductionReport",
        "SimulationProcessReport",
        "SimulationValidationErrorReport",
        "SimulationEvolutionaryAlgorithmInputFactorReport",
        "SimulationEvolutionaryAlgorithmOutputFactorReport",
        "SimulationRouteReport",
        "SimulationRouteSegmentReport",
        "SimulationRouteStopReport",
        "SimulationAwaitingShipmentReport",
        "SimulationShelfLifeExpirationReport",
        "InventoryValidationErrorReport",
    ],
    Category.OUTPUT_QUEUE_TABLES: [
        "SimulationWorkCenterQueueSummary",
        "SimulationWorkCenterQueueDepthReport",
        "SimulationLaneQueueSummary",
        "SimulationLaneQueueDepthReport",
        "SimulationLaneModeQueueSummary",
        "SimulationLaneModeQueueDepthReport",
        "SimulationOrderFulfillmentQueueSummary",
        "SimulationOrderFulfillmentQueueDepthReport",
    ],
    Category.OUTPUT_REPLICATION_TABLES: [
        "SimulationNetworkSummaryReplicationDetail",
        "SimulationNetworkServiceSummaryReplicationDetail",
        "SimulationCustomerSummaryReplicationDetail",
        "SimulationCustomerServiceSummaryReplicationDetail",
        "SimulationCustomerProductSummaryReplicationDetail",
        "SimulationCustomerProductServiceSummaryReplicationDetail",
        "SimulationFacilitySummaryReplicationDetail",
        "SimulationFacilityServiceSummaryReplicationDetail",
        "SimulationFacilityProductSummaryReplicationDetail",
        "SimulationFacilityProductServiceSummaryReplicationDetail",
        "SimulationSupplierSummaryReplicationDetail",
        "SimulationSupplierProductSummaryReplicationDetail",
        "SimulationLaneSummaryReplicationDetail",
        "SimulationFlowSummaryReplicationDetail",
        "SimulationWorkCenterSummaryReplicationDetail",
        "SimulationProcessSummaryReplicationDetail",
        "SimulationRiskMetricsSummaryReplicationDetail",
        "SimulationCustomerRiskMetricsReplicationDetail",
        "SimulationFacilityRiskMetricsReplicationDetail",
        "SimulationSupplierRiskMetricsReplicationDetail",
        "SimulationGeographicRiskMetricsReplicationDetail",
        "SimulationNetworkRiskMetricsReplicationDetail",
        "SimulationProductRiskMetricsReplicationDetail",
        "SimulationWorkCenterQueueSummaryReplicationDetail",
        "SimulationLaneQueueSummaryReplicationDetail",
        "SimulationLaneModeQueueSummaryReplicationDetail",
        "SimulationOrderFulfillmentQueueSummaryReplicationDetail",
        "SimulationTransportationAssetSummaryReplicationDetail",
        "SimulationTariffSummaryReplicationDetail",
    ],
}


# Registry-only views that are intentionally not represented as
# Python schema files. These should not trigger schema mismatch warnings.
VIEWS: set[str] = {
    "TransportationRoutesMapLayer",
}


# Performance cache: Pre-compute table -> category mapping for O(1) lookups
_TABLE_TO_CATEGORY_CACHE: dict[str, Category] = {
    table: category for category, tables in TABLE_GRID_ORDER.items() for table in tables
}

# Case-insensitive lookup cache (lowercase keys -> Category)
_TABLE_TO_CATEGORY_CACHE_LOWER: dict[str, Category] = {
    table.lower(): category
    for category, tables in TABLE_GRID_ORDER.items()
    for table in tables
}

# Canonical table name cache (lowercase -> CamelCase)
_CANONICAL_TABLE_NAMES: dict[str, str] = {
    table.lower(): table for tables in TABLE_GRID_ORDER.values() for table in tables
}


# ============================================================================
# Utility Functions
# ============================================================================


def normalize_table_name(table_name: str) -> str:
    """
    Normalize a table name to its canonical CamelCase form.

    Accepts table names in any case and returns the canonical CamelCase version.

    Args:
        table_name: Table name in any case (e.g., "customers", "CUSTOMERS", "Customers")

    Returns:
        Canonical CamelCase table name (e.g., "Customers")

    Raises:
        ValueError: If table not found in registry

    Example:
        >>> normalize_table_name("customers")
        "Customers"
        >>> normalize_table_name("FACILITIES")
        "Facilities"
    """
    canonical = _CANONICAL_TABLE_NAMES.get(table_name.lower())
    if canonical is None:
        raise ValueError(f"Table '{table_name}' not found in category registry")
    return canonical


def get_table_category(table_name: str) -> Category:
    """
    Look up which category a table belongs to.

    Uses a pre-computed cache for O(1) lookup performance.
    Accepts table names in any case (case-insensitive lookup).

    Args:
        table_name: Name of the table to look up (case-insensitive)

    Returns:
        The category this table belongs to

    Raises:
        ValueError: If table not found in registry

    Example:
        >>> get_table_category("Customers")
        Category.MODEL_ELEMENTS
        >>> get_table_category("customers")  # Case-insensitive
        Category.MODEL_ELEMENTS
    """
    category = _TABLE_TO_CATEGORY_CACHE_LOWER.get(table_name.lower())
    if category is None:
        raise ValueError(f"Table '{table_name}' not found in category registry")
    return category


def get_tables_for_category(category: Category) -> List[str]:
    """
    Get all tables in a category, in grid order.

    Args:
        category: The category to query

    Returns:
        Ordered list of table names in this category

    Example:
        >>> get_tables_for_category(Category.MODEL_ELEMENTS)
        ['Customers', 'Facilities', 'Suppliers', ...]
    """
    return TABLE_GRID_ORDER.get(category, [])


def get_table_position(table_name: str) -> Tuple[Category, int]:
    """
    Get category and position within category for a table.

    Args:
        table_name: Name of the table

    Returns:
        Tuple of (category, zero-based position within category)

    Raises:
        ValueError: If table not found in registry

    Example:
        >>> get_table_position("Customers")
        (Category.MODEL_ELEMENTS, 0)
    """
    category = get_table_category(table_name)
    position = TABLE_GRID_ORDER[category].index(table_name)
    return (category, position)


def get_all_tables_ordered() -> List[Tuple[Category, str]]:
    """
    Get all tables in display order (category order, then grid order).

    Returns:
        List of (category, table_name) tuples in UI display order

    Example:
        >>> tables = get_all_tables_ordered()
        >>> tables[:3]
        [(Category.MODEL_ELEMENTS, 'Customers'),
         (Category.MODEL_ELEMENTS, 'Facilities'),
         (Category.MODEL_ELEMENTS, 'Suppliers')]
    """
    result = []
    for category in CATEGORY_ORDER:
        for table_name in TABLE_GRID_ORDER[category]:
            result.append((category, table_name))
    return result


def validate_table_in_registry(table_name: str) -> bool:
    """
    Check if a table exists in the registry.

    Args:
        table_name: Name of the table to check

    Returns:
        True if table exists in registry, False otherwise

    Example:
        >>> validate_table_in_registry("Customers")
        True
        >>> validate_table_in_registry("NonExistentTable")
        False
    """
    for tables in TABLE_GRID_ORDER.values():
        if table_name in tables:
            return True
    return False


def get_all_table_names() -> List[str]:
    """
    Get a flat list of all table names in the registry.

    Returns:
        List of all table names (unordered)

    Example:
        >>> tables = get_all_table_names()
        >>> "Customers" in tables
        True
    """
    all_tables = []
    for tables in TABLE_GRID_ORDER.values():
        all_tables.extend(tables)
    return all_tables
