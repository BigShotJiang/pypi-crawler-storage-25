"""Tests for Table model."""

import pytest

from ol_anura.core import (
    Column,
    DataType,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


def _simple_table(**kwargs) -> Table:
    """Helper: build a minimal valid Table."""
    defaults = dict(
        table_name="TestTable",
        table_type=TableType.INPUT,
        fields=[],
    )
    defaults.update(kwargs)
    return Table(**defaults)


class TestTableToJsonDict:
    """Test Table serialization to JSON."""

    def test_simple_table(self):
        table = _simple_table(
            fields=[
                Column(
                    column_name="ID",
                    data_type=DataType.STRING,
                    required=True,
                    pk=True,
                    in_database=True,
                )
            ]
        )
        json_dict = table.to_json_dict()
        assert json_dict["tableName"] == "TestTable"
        assert "fields" in json_dict
        assert len(json_dict["fields"]) == 1
        assert json_dict["fields"][0]["columnName"] == "ID"

    def test_includes_metadata(self):
        table = _simple_table(
            in_database=True,
            fields=[
                Column(column_name="Col1", data_type=DataType.STRING, in_database=True)
            ],
        )
        result = table.to_json_dict()
        assert result["appName"] == "cosmicfrog"
        assert result["schemaName"] == "anura"
        assert result["tableName"] == "TestTable"

    def test_excludes_in_database(self):
        table = _simple_table(
            in_database=True,
            fields=[
                Column(column_name="Col1", data_type=DataType.STRING, in_database=True)
            ],
        )
        result = table.to_json_dict()
        assert "inDatabase" not in result
        assert "in_database" not in result

    def test_filters_columns_by_in_database(self):
        table = _simple_table(
            in_database=True,
            fields=[
                Column(
                    column_name="ProdCol", data_type=DataType.STRING, in_database=True
                ),
                Column(
                    column_name="DevCol", data_type=DataType.STRING, in_database=False
                ),
                Column(
                    column_name="AnotherProd",
                    data_type=DataType.INTEGER,
                    in_database=True,
                ),
            ],
        )
        result = table.to_json_dict()
        assert len(result["fields"]) == 2
        field_names = [f["columnName"] for f in result["fields"]]
        assert "ProdCol" in field_names
        assert "AnotherProd" in field_names
        assert "DevCol" not in field_names

    def test_metadata_order(self):
        table = _simple_table(
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
            fields=[
                Column(column_name="Col1", data_type=DataType.STRING, in_database=True)
            ],
        )
        result = table.to_json_dict()
        keys = list(result.keys())
        assert keys[0] == "appName"
        assert keys[1] == "schemaName"
        assert keys[2] == "schemaVersion"
        assert keys[3] == "tableName"
        assert keys.index("fields") > keys.index("tableName")

    def test_table_type_in_json(self):
        table = _simple_table(table_type=TableType.INPUT)
        result = table.to_json_dict()
        assert result["tableType"] == "input"

        table_out = _simple_table(table_type=TableType.OUTPUT)
        result_out = table_out.to_json_dict()
        assert result_out["tableType"] == "output"

    def test_technology_in_json(self):
        table = _simple_table(
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
            }
        )
        result = table.to_json_dict()
        assert result["technology"] == {
            "NEO": "fully-supported",
            "THROG": "in-development",
        }

    def test_unsupported_technology_omitted_from_json(self):
        table = _simple_table(
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.UNSUPPORTED,
            }
        )
        result = table.to_json_dict()
        assert "NEO" in result["technology"]
        assert "THROG" not in result["technology"]

    def test_empty_technology_omitted_from_json(self):
        table = _simple_table()
        result = table.to_json_dict()
        assert "technology" not in result

    def test_basic_mode_in_json(self):
        table = _simple_table(
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            basic_mode=[Technology.NEO],
        )
        result = table.to_json_dict()
        assert result["basicMode"] == ["NEO"]

    def test_empty_basic_mode_omitted_from_json(self):
        table = _simple_table()
        result = table.to_json_dict()
        assert "basicMode" not in result


class TestTableMetadataFields:
    """Test metadata fields on Table model."""

    def test_abbreviated_name(self):
        table = _simple_table(abbreviated_name="TT")
        assert table.abbreviated_name == "TT"

    def test_abbreviated_name_default_none(self):
        table = _simple_table()
        assert table.abbreviated_name is None

    def test_fixed_tags(self):
        table = _simple_table(fixed_tags=["tag1", "tag2"])
        assert table.fixed_tags == ["tag1", "tag2"]

    def test_fixed_tags_default_empty_list(self):
        table = _simple_table()
        assert table.fixed_tags == []

    def test_in_database_flag(self):
        table = _simple_table(in_database=True)
        assert table.in_database is True

    def test_in_database_default_false(self):
        table = _simple_table()
        assert table.in_database is False

    def test_table_type_required(self):
        with pytest.raises(Exception):
            Table(table_name="TestTable", fields=[])


class TestTableTechnologyField:
    """Test the normalized technology mapping on Table."""

    def test_technology_mapping(self):
        table = _simple_table(
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
            }
        )
        assert table.technology[Technology.NEO] == TechnologySupport.FULLY_SUPPORTED
        assert table.technology[Technology.THROG] == TechnologySupport.IN_DEVELOPMENT

    def test_technology_default_empty(self):
        table = _simple_table()
        assert table.technology == {}

    def test_is_fully_supported(self):
        table = _simple_table(
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED}
        )
        assert table.is_fully_supported(Technology.NEO) is True
        assert table.is_fully_supported(Technology.THROG) is False

    def test_is_available(self):
        table = _simple_table(
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
            }
        )
        assert table.is_available(Technology.NEO) is True
        assert table.is_available(Technology.THROG, include_in_dev=True) is True
        assert table.is_available(Technology.THROG, include_in_dev=False) is False
        assert table.is_available(Technology.DENDRO) is False


class TestTableBasicMode:
    """Test the basic_mode list on Table."""

    def test_basic_mode_list(self):
        table = _simple_table(
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            basic_mode=[Technology.NEO],
        )
        assert Technology.NEO in table.basic_mode

    def test_basic_mode_default_empty(self):
        table = _simple_table()
        assert table.basic_mode == []

    def test_basic_mode_must_be_in_technology(self):
        with pytest.raises(ValueError, match="basic_mode"):
            _simple_table(
                technology={},
                basic_mode=[Technology.NEO],
            )

    def test_basic_mode_unsupported_technology_raises(self):
        with pytest.raises(ValueError):
            _simple_table(
                technology={Technology.NEO: TechnologySupport.UNSUPPORTED},
                basic_mode=[Technology.NEO],
            )

    def test_basic_mode_in_development_allowed(self):
        table = _simple_table(
            technology={Technology.NEO: TechnologySupport.IN_DEVELOPMENT},
            basic_mode=[Technology.NEO],
        )
        assert Technology.NEO in table.basic_mode
