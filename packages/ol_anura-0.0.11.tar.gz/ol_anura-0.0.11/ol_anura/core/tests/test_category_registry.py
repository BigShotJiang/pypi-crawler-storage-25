"""Tests for category_registry module."""

import pytest

from ol_anura.core.category_registry import (
    CATEGORY_ORDER,
    TABLE_GRID_ORDER,
    Category,
    get_all_table_names,
    get_all_tables_ordered,
    get_table_category,
    get_table_position,
    get_tables_for_category,
    validate_table_in_registry,
)


class TestCategoryEnum:
    """Test Category enum."""

    def test_category_enum_has_values(self):
        """Test that Category enum has expected categories."""
        # Should have at least some standard categories
        assert hasattr(Category, "MODEL_ELEMENTS")
        assert hasattr(Category, "SOURCING")
        assert hasattr(Category, "INVENTORY")

    def test_category_values_are_strings(self):
        """Test that category values are human-readable strings."""
        assert Category.MODEL_ELEMENTS.value == "Model Elements"
        assert Category.SOURCING.value == "Sourcing"


class TestCategoryOrder:
    """Test CATEGORY_ORDER list."""

    def test_category_order_is_list(self):
        """Test that CATEGORY_ORDER is a list."""
        assert isinstance(CATEGORY_ORDER, list)

    def test_category_order_has_categories(self):
        """Test that CATEGORY_ORDER contains Category enums."""
        assert len(CATEGORY_ORDER) > 0
        for cat in CATEGORY_ORDER:
            assert isinstance(cat, Category)

    def test_category_order_no_duplicates(self):
        """Test that CATEGORY_ORDER has no duplicates."""
        assert len(CATEGORY_ORDER) == len(set(CATEGORY_ORDER))

    def test_model_elements_first(self):
        """Test that Model Elements is the first category."""
        assert CATEGORY_ORDER[0] == Category.MODEL_ELEMENTS


class TestTableGridOrder:
    """Test TABLE_GRID_ORDER dict."""

    def test_table_grid_order_is_dict(self):
        """Test that TABLE_GRID_ORDER is a dict."""
        assert isinstance(TABLE_GRID_ORDER, dict)

    def test_table_grid_order_keys_are_categories(self):
        """Test that all keys are Category enums."""
        for key in TABLE_GRID_ORDER.keys():
            assert isinstance(key, Category)

    def test_table_grid_order_values_are_lists(self):
        """Test that all values are lists of strings."""
        for tables in TABLE_GRID_ORDER.values():
            assert isinstance(tables, list)
            for table in tables:
                assert isinstance(table, str)

    def test_all_categories_in_grid_order(self):
        """Test that all categories from CATEGORY_ORDER are in TABLE_GRID_ORDER."""
        for category in CATEGORY_ORDER:
            assert category in TABLE_GRID_ORDER

    def test_customers_in_model_elements(self):
        """Test that Customers table is in Model Elements category."""
        model_elements_tables = TABLE_GRID_ORDER[Category.MODEL_ELEMENTS]
        assert "Customers" in model_elements_tables

    def test_no_duplicate_tables_within_category(self):
        """Test that no category has duplicate tables."""
        for category, tables in TABLE_GRID_ORDER.items():
            assert len(tables) == len(set(tables)), f"Duplicates in {category}"

    def test_no_duplicate_tables_across_categories(self):
        """Test that no table appears in multiple categories."""
        all_tables = []
        for tables in TABLE_GRID_ORDER.values():
            all_tables.extend(tables)
        assert len(all_tables) == len(set(all_tables))


class TestGetTableCategory:
    """Test get_table_category function."""

    def test_get_category_for_customers(self):
        """Test getting category for Customers table."""
        category = get_table_category("Customers")
        assert category == Category.MODEL_ELEMENTS

    def test_get_category_for_valid_table(self):
        """Test getting category for any valid table."""
        # Get a table from the registry
        first_category = CATEGORY_ORDER[0]
        first_table = TABLE_GRID_ORDER[first_category][0]

        category = get_table_category(first_table)
        assert category == first_category

    def test_get_category_invalid_table_raises_error(self):
        """Test that invalid table name raises ValueError."""
        with pytest.raises(ValueError, match="not found in category registry"):
            get_table_category("NonExistentTable")


class TestGetTablesForCategory:
    """Test get_tables_for_category function."""

    def test_get_tables_for_model_elements(self):
        """Test getting tables for Model Elements category."""
        tables = get_tables_for_category(Category.MODEL_ELEMENTS)
        assert isinstance(tables, list)
        assert len(tables) > 0
        assert "Customers" in tables

    def test_get_tables_returns_list(self):
        """Test that function returns a list."""
        for category in CATEGORY_ORDER:
            tables = get_tables_for_category(category)
            assert isinstance(tables, list)

    def test_get_tables_for_invalid_category_returns_empty(self):
        """Test that getting tables for non-existent category returns empty list."""
        # This would fail if we try Category(fake_category), so we just check the behavior
        # In practice, this won't happen since Category is an enum
        pass  # Skip this test as it's not practically testable with enums


class TestGetTablePosition:
    """Test get_table_position function."""

    def test_get_position_for_customers(self):
        """Test getting position for Customers table."""
        category, position = get_table_position("Customers")
        assert category == Category.MODEL_ELEMENTS
        assert position == 0  # Customers should be first in Model Elements

    def test_get_position_for_valid_table(self):
        """Test getting position for any valid table."""
        # Get a table from the registry
        first_category = CATEGORY_ORDER[0]
        first_table = TABLE_GRID_ORDER[first_category][0]

        category, position = get_table_position(first_table)
        assert category == first_category
        assert position == 0

    def test_get_position_invalid_table_raises_error(self):
        """Test that invalid table name raises ValueError."""
        with pytest.raises(ValueError, match="not found in category registry"):
            get_table_position("NonExistentTable")


class TestGetAllTablesOrdered:
    """Test get_all_tables_ordered function."""

    def test_get_all_tables_returns_list(self):
        """Test that function returns a list."""
        tables = get_all_tables_ordered()
        assert isinstance(tables, list)

    def test_get_all_tables_returns_tuples(self):
        """Test that function returns list of (Category, str) tuples."""
        tables = get_all_tables_ordered()
        assert len(tables) > 0
        for item in tables:
            assert isinstance(item, tuple)
            assert len(item) == 2
            category, table_name = item
            assert isinstance(category, Category)
            assert isinstance(table_name, str)

    def test_get_all_tables_order_matches_category_order(self):
        """Test that tables are ordered by category order."""
        tables = get_all_tables_ordered()

        # First table should be from first category
        first_category = CATEGORY_ORDER[0]
        first_table_name = TABLE_GRID_ORDER[first_category][0]

        assert tables[0] == (first_category, first_table_name)

    def test_get_all_tables_count(self):
        """Test that all tables are included."""
        tables = get_all_tables_ordered()

        # Count total tables in TABLE_GRID_ORDER
        total_tables = sum(len(t) for t in TABLE_GRID_ORDER.values())

        assert len(tables) == total_tables


class TestValidateTableInRegistry:
    """Test validate_table_in_registry function."""

    def test_validate_customers_exists(self):
        """Test that Customers table is in registry."""
        assert validate_table_in_registry("Customers") is True

    def test_validate_nonexistent_table(self):
        """Test that non-existent table returns False."""
        assert validate_table_in_registry("NonExistentTable") is False

    def test_validate_all_tables_in_grid_order(self):
        """Test that all tables in TABLE_GRID_ORDER validate as True."""
        for tables in TABLE_GRID_ORDER.values():
            for table_name in tables:
                assert validate_table_in_registry(table_name) is True


class TestGetAllTableNames:
    """Test get_all_table_names function."""

    def test_get_all_table_names_returns_list(self):
        """Test that function returns a list."""
        tables = get_all_table_names()
        assert isinstance(tables, list)

    def test_get_all_table_names_contains_strings(self):
        """Test that all items are strings."""
        tables = get_all_table_names()
        for table in tables:
            assert isinstance(table, str)

    def test_get_all_table_names_includes_customers(self):
        """Test that Customers is in the list."""
        tables = get_all_table_names()
        assert "Customers" in tables

    def test_get_all_table_names_count(self):
        """Test that count matches TABLE_GRID_ORDER."""
        tables = get_all_table_names()
        total = sum(len(t) for t in TABLE_GRID_ORDER.values())
        assert len(tables) == total
