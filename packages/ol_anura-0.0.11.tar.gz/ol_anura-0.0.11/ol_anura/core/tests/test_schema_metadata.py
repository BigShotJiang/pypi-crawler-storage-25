from ol_anura.core.schema_metadata import APP_NAME, SCHEMA_NAME


def test_app_name_constant():
    """Test that APP_NAME is defined correctly."""
    assert APP_NAME == "cosmicfrog"


def test_schema_name_constant():
    """Test that SCHEMA_NAME is defined correctly."""
    assert SCHEMA_NAME == "anura"
