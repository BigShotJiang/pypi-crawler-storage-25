"""Tests for technology support refactor - new normalized API."""

from ol_anura.core import (
    Column,
    DataType,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


def test_technology_support_enum():
    """TechnologySupport enum has correct values."""
    assert TechnologySupport.UNSUPPORTED.value == "unsupported"
    assert TechnologySupport.IN_DEVELOPMENT.value == "in-development"
    assert TechnologySupport.FULLY_SUPPORTED.value == "fully-supported"


def test_column_technology_dict():
    """Column stores technology support as a dict keyed by Technology enum."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
        },
    )

    assert column.technology[Technology.NEO] == TechnologySupport.FULLY_SUPPORTED
    assert column.technology[Technology.THROG] == TechnologySupport.IN_DEVELOPMENT
    assert Technology.DENDRO not in column.technology


def test_column_basic_mode_list():
    """Column basic_mode is a list of Technology enum values."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
        },
        basic_mode=[Technology.NEO],
    )

    assert Technology.NEO in column.basic_mode
    assert Technology.THROG not in column.basic_mode


def test_column_is_fully_supported():
    """Column.is_fully_supported checks technology dict."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
        },
    )

    assert column.is_fully_supported(Technology.NEO) is True
    assert column.is_fully_supported(Technology.THROG) is False
    assert column.is_fully_supported(Technology.DENDRO) is False


def test_column_is_available():
    """Column.is_available checks technology dict with include_in_dev option."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
        },
    )

    assert column.is_available(Technology.NEO) is True
    assert column.is_available(Technology.THROG, include_in_dev=False) is False
    assert column.is_available(Technology.THROG, include_in_dev=True) is True
    assert column.is_available(Technology.DENDRO, include_in_dev=True) is False


def test_column_json_serialization():
    """Column.to_json_dict emits technology as a mapping and basicMode as a list."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
            Technology.DENDRO: TechnologySupport.UNSUPPORTED,
        },
        basic_mode=[Technology.NEO],
    )

    json_dict = column.to_json_dict()

    # technology is a mapping of tech name -> support level string
    assert json_dict["technology"]["NEO"] == "fully-supported"
    assert json_dict["technology"]["THROG"] == "in-development"
    # UNSUPPORTED is omitted
    assert "DENDRO" not in json_dict["technology"]

    # basicMode is a list of technology name strings
    assert json_dict["basicMode"] == ["NEO"]


def test_column_has_technology_attribute():
    """Column exposes the new 'technology' attribute."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
    )

    assert hasattr(column, "technology")
    assert isinstance(column.technology, dict)


def test_table_technology_dict():
    """Table stores technology support as a dict keyed by Technology enum."""
    table = Table(
        table_name="TestTable",
        table_type=TableType.INPUT,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
        },
        fields=[Column(column_name="Col1", data_type=DataType.STRING)],
    )

    assert table.technology[Technology.NEO] == TechnologySupport.FULLY_SUPPORTED
    assert table.technology[Technology.THROG] == TechnologySupport.IN_DEVELOPMENT
    assert Technology.DENDRO not in table.technology


def test_table_basic_mode_list():
    """Table basic_mode is a list of Technology enum values."""
    table = Table(
        table_name="TestTable",
        table_type=TableType.INPUT,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        },
        basic_mode=[Technology.NEO],
        fields=[Column(column_name="Col1", data_type=DataType.STRING)],
    )

    assert Technology.NEO in table.basic_mode
    assert Technology.THROG not in table.basic_mode


def test_table_is_fully_supported():
    """Table.is_fully_supported checks technology dict."""
    table = Table(
        table_name="TestTable",
        table_type=TableType.INPUT,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
        },
        fields=[Column(column_name="Col1", data_type=DataType.STRING)],
    )

    assert table.is_fully_supported(Technology.NEO) is True
    assert table.is_fully_supported(Technology.THROG) is False


def test_table_is_available():
    """Table.is_available checks technology dict with include_in_dev option."""
    table = Table(
        table_name="TestTable",
        table_type=TableType.INPUT,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.IN_DEVELOPMENT,
        },
        fields=[Column(column_name="Col1", data_type=DataType.STRING)],
    )

    assert table.is_available(Technology.NEO) is True
    assert table.is_available(Technology.THROG, include_in_dev=False) is False
    assert table.is_available(Technology.THROG, include_in_dev=True) is True


def test_table_json_serialization():
    """Table.to_json_dict emits tableType, technology mapping, and basicMode list."""
    table = Table(
        table_name="TestTable",
        table_type=TableType.INPUT,
        technology={
            Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            Technology.THROG: TechnologySupport.UNSUPPORTED,
        },
        basic_mode=[Technology.NEO],
        fields=[
            Column(column_name="Col1", data_type=DataType.STRING, in_database=True)
        ],
    )

    json_dict = table.to_json_dict()

    assert json_dict["tableType"] == "input"
    assert json_dict["technology"]["NEO"] == "fully-supported"
    # UNSUPPORTED is omitted
    assert "THROG" not in json_dict["technology"]
    assert json_dict["basicMode"] == ["NEO"]


def test_basic_mode_must_be_in_technology():
    """basic_mode entries must reference technologies present in technology mapping."""
    import pytest

    with pytest.raises(Exception):
        Table(
            table_name="TestTable",
            table_type=TableType.INPUT,
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            basic_mode=[Technology.THROG],  # THROG not in technology
            fields=[Column(column_name="Col1", data_type=DataType.STRING)],
        )


def test_no_legacy_per_tech_fields_on_column():
    """Column no longer has legacy per-technology attributes (neo, throg, etc.)."""
    column = Column(
        column_name="TestColumn",
        data_type=DataType.STRING,
    )

    assert not hasattr(column, "neo")
    assert not hasattr(column, "throg")
    assert not hasattr(column, "dendro")


def test_no_legacy_basic_mode_booleans_on_table():
    """Table no longer has legacy basic_mode_neo / basic_mode_throg attributes."""
    table = Table(
        table_name="TestTable",
        table_type=TableType.INPUT,
        technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
        fields=[Column(column_name="Col1", data_type=DataType.STRING)],
    )

    assert not hasattr(table, "basic_mode_neo")
    assert not hasattr(table, "basic_mode_throg")
