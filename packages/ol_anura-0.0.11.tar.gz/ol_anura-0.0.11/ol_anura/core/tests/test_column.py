"""Tests for Column model."""

from ol_anura.core import Column, DataType


class TestColumnExtraFields:
    """Test Column class handles extra fields correctly."""

    def test_column_accepts_extra_fields(self):
        """Test that Column accepts fields not defined in schema."""
        col = Column(
            column_name="TestColumn",
            data_type=DataType.STRING,
            custom_field="custom_value",  # Extra field
            another_extra=123,  # Another extra field
        )

        # Extra fields should be accessible as attributes
        assert hasattr(col, "custom_field")
        assert col.custom_field == "custom_value"
        assert col.another_extra == 123

    def test_extra_fields_in_json_output(self):
        """Test that extra fields appear in JSON output."""
        col = Column(
            column_name="TestColumn",
            data_type=DataType.STRING,
            pivot_column=True,  # Extra field
        )

        json_dict = col.to_json_dict()

        # Extra fields should be in JSON output
        assert "pivotColumn" in json_dict or "pivot_column" in json_dict


class TestColumnInDatabaseFlag:
    """Test in_database flag on Column model."""

    def test_in_database_true(self):
        """Test that in_database can be set to True."""
        column = Column(
            column_name="TestColumn", data_type=DataType.STRING, in_database=True
        )
        assert column.in_database is True

    def test_in_database_default_false(self):
        """Test that in_database defaults to False."""
        column = Column(column_name="TestColumn", data_type=DataType.STRING)
        assert column.in_database is False

    def test_in_database_with_alias(self):
        """Test that in_database works with camelCase alias."""
        # Using camelCase alias in dict form
        column_dict = {
            "columnName": "TestColumn",
            "dataType": "String",
            "inDatabase": True,
        }
        column = Column.model_validate(column_dict)
        assert column.in_database is True


class TestColumnJsonSerialization:
    """Test Column JSON serialization behavior."""

    def test_column_to_json_dict_excludes_in_database(self):
        """Test that to_json_dict() excludes inDatabase field from output."""
        column = Column(
            column_name="TestColumn",
            data_type=DataType.STRING,
            explanation="Test column",
            in_database=True,  # This should NOT appear in JSON
        )

        result = column.to_json_dict()

        # Verify inDatabase is NOT in the result
        assert "inDatabase" not in result
        assert "in_database" not in result

        # Verify other fields ARE present
        assert result["columnName"] == "TestColumn"
        assert result["dataType"] == "String"
        assert result["explanation"] == "Test column"

    def test_column_to_json_dict_excludes_in_database_false(self):
        """Test that to_json_dict() excludes inDatabase even when False."""
        column = Column(
            column_name="DevColumn",
            data_type=DataType.INTEGER,
            in_database=False,  # Still should NOT appear in JSON
        )

        result = column.to_json_dict()

        # Verify inDatabase is NOT in the result
        assert "inDatabase" not in result
        assert "in_database" not in result

    def test_column_to_json_dict_preserves_field_order(self):
        """Test that to_json_dict() preserves field order from Pydantic model."""
        column = Column(
            column_name="OrderedColumn",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="Test explanation",
            in_database=True,
        )

        result = column.to_json_dict()

        # Get list of keys in order
        keys = list(result.keys())

        # columnName should come before dataType
        assert keys.index("columnName") < keys.index("dataType")

        # dataType should come before required
        assert keys.index("dataType") < keys.index("required")

        # required should come before pk
        assert keys.index("required") < keys.index("pk")

        # explanation should come after pk (it's defined later in the model)
        assert keys.index("pk") < keys.index("explanation")
