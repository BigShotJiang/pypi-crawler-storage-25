"""Field definition model for Anura schemas."""

from enum import Enum
from typing import Dict, List, Optional, Type, Union

from pydantic import BaseModel, Field, field_validator

from .enums import DataType, Technology, TechnologySupport

# Type aliases for better clarity
TableName = str  # Name of a table (e.g., "Customers", "Products")
ColumnReference = str  # Column reference in format "TableName.ColumnName"


class Column(BaseModel):
    """
    Represents a single field/column in a table schema.

    Uses snake_case in Python code and camelCase for JSON serialization.
    """

    # === Core Properties (always present) ===

    column_name: str = Field(
        ..., alias="columnName", description="The name of the column"
    )

    data_type: Union[Type[Enum], type, str] = Field(
        ...,
        alias="dataType",
        description="Either a primitive type, bool, or an enum class",
    )

    validation_type: Optional[str] = Field(
        default=None,
        alias="validationType",
        description="Validation rules for this field",
    )

    required: Optional[bool] = Field(
        default=False, description="Whether this field is required"
    )

    required_if: Optional[str] = Field(
        default=None, alias="requiredIf", description="Conditional requirement logic"
    )

    pk: Optional[bool] = Field(
        default=False, description="Whether this is a primary key field"
    )

    master_table: List[TableName] = Field(
        default_factory=list,
        alias="masterTable",
        description="Tables this field references",
    )

    expandable: Optional[bool] = Field(
        default=False, description="Whether this field can be expanded"
    )

    technology: Dict[Technology, TechnologySupport] = Field(
        default_factory=dict, description="Technology support mapping"
    )

    basic_mode: List[Technology] = Field(
        default_factory=list,
        alias="basicMode",
        description="Technologies for which this column is available in basic mode",
    )

    allowable_uom_types: List[str] = Field(
        default_factory=list,
        alias="allowableUOMTypes",
        description="Allowed unit of measure types",
    )

    u_o_m_conversion: Optional[str] = Field(
        default=None,
        alias="UOMConversion",
        description="Unit of measure conversion specification",
    )

    relates_to_keys: Optional[str] = Field(
        default=None, alias="relatesToKeys", description="Key relationships"
    )

    default_value: Optional[str] = Field(
        default=None, alias="defaultValue", description="Default value for this field"
    )

    notes: Optional[str] = Field(
        default=None, description="Internal notes about this field"
    )

    explanation: Optional[str] = Field(
        default=None, description="User-facing explanation of this field"
    )

    master_column: List[ColumnReference] = Field(
        default_factory=list,
        alias="masterColumn",
        description="Column references in format 'TableName.ColumnName'",
    )

    # === Common Optional Properties ===

    precision_category: List[str] = Field(
        default_factory=list,
        alias="precisionCategory",
        description="Precision categorization for this field",
    )

    disaggregation_logic: Optional[str] = Field(
        default=None,
        alias="disaggregationLogic",
        description="Logic for disaggregating this field (output tables only)",
    )

    # Lifecycle flag
    in_database: bool = Field(
        default=False,
        alias="inDatabase",
        description="Whether this column exists in the database (False for in-development columns)",
    )

    # === Validators ===

    @field_validator("master_column")
    @classmethod
    def validate_master_column(cls, v: List[ColumnReference]) -> List[ColumnReference]:
        """Validate column references (format: 'TableName.ColumnName')."""
        for col_ref in v:
            if col_ref and "." not in col_ref:
                raise ValueError(f"Invalid column reference format: {col_ref}")
        return v

    @field_validator("technology")
    @classmethod
    def validate_technology(
        cls, v: Dict[Technology, TechnologySupport]
    ) -> Dict[Technology, TechnologySupport]:
        """Ensure technology keys are Technology enum values and values are TechnologySupport."""
        for key, value in v.items():
            if not isinstance(key, Technology):
                raise ValueError(
                    f"technology keys must be Technology enum values, got {type(key)}"
                )
            if not isinstance(value, TechnologySupport):
                raise ValueError(
                    f"technology values must be TechnologySupport enum values, got {type(value)}"
                )
        return v

    # === Configuration ===

    model_config = {
        "populate_by_name": True,  # Allow both snake_case and camelCase
        "arbitrary_types_allowed": True,  # For Enum types and bool
        "extra": "allow",  # Allow column-specific fields
    }

    # === Methods ===

    def to_json_dict(self) -> dict:
        """
        Export to JSON format with camelCase keys.

        Special handling for data_type field:
        - bool → ["True", "False"]
        - DataType enum → "String", "Double", etc.
        - Value enum → ["Value1", "Value2", ...]

        Emits technology as a mapping and basicMode as a list of technology names.

        Note: in_database field is excluded from JSON output (used for filtering only).
        UNSUPPORTED technologies are omitted from the technology mapping.
        """
        # Store data_type before serialization
        dt = self.data_type

        # Get base dict with camelCase keys, excluding data_type, in_database, technology, basic_mode
        result = self.model_dump(
            by_alias=True,
            exclude_none=True,
            exclude={"data_type", "in_database", "technology", "basic_mode"},
            mode="json",
        )

        # Special handling for dataType field - insert in correct position after columnName
        if dt is bool:
            data_type_value = ["True", "False"]
        elif isinstance(dt, DataType):
            data_type_value = dt.value
        elif isinstance(dt, type) and issubclass(dt, Enum):
            data_type_value = [member.value for member in dt]
        elif isinstance(dt, str):
            data_type_value = dt
        else:
            data_type_value = str(dt)

        ordered_result = {}
        for key, value in result.items():
            ordered_result[key] = value
            if key == "columnName":
                ordered_result["dataType"] = data_type_value

        if "dataType" not in ordered_result:
            ordered_result["dataType"] = data_type_value

        result = ordered_result

        # Emit technology as a mapping, omitting UNSUPPORTED entries
        tech_dict = {
            tech.value: support.value
            for tech, support in self.technology.items()
            if support != TechnologySupport.UNSUPPORTED
        }
        if tech_dict:
            result["technology"] = tech_dict

        # Emit basicMode as a list of technology name strings
        if self.basic_mode:
            result["basicMode"] = [tech.value for tech in self.basic_mode]

        return result

    def is_fully_supported(self, tech: Technology) -> bool:
        """Check if column is fully supported for a technology."""
        return self.technology.get(tech) == TechnologySupport.FULLY_SUPPORTED

    def is_available(self, tech: Technology, include_in_dev: bool = False) -> bool:
        """Check if column is available for a technology."""
        support = self.technology.get(tech)
        if support == TechnologySupport.FULLY_SUPPORTED:
            return True
        if include_in_dev and support == TechnologySupport.IN_DEVELOPMENT:
            return True
        return False
