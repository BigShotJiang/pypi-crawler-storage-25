"""Table schema model for Anura schemas."""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from .column import Column
from .enums import TableType, Technology, TechnologySupport


class Table(BaseModel):
    """
    Represents a complete table schema with metadata and fields.

    Pure data container - query methods will be provided by AnuraSchema class.
    Uses snake_case in Python code and camelCase for JSON serialization.
    """

    table_name: str = Field(..., alias="tableName", description="Name of the table")

    table_type: TableType = Field(
        ..., alias="tableType", description="Whether this is an input or output table"
    )

    technology: Dict[Technology, TechnologySupport] = Field(
        default_factory=dict, description="Technology support mapping"
    )

    basic_mode: List[Technology] = Field(
        default_factory=list,
        alias="basicMode",
        description="Technologies for which this table is available in basic mode",
    )

    # Table metadata fields
    abbreviated_name: Optional[str] = Field(
        default=None, alias="abbreviatedName", description="Short name for this table"
    )

    fixed_tags: List[str] = Field(
        default_factory=list, alias="fixedTags", description="Fixed tags for this table"
    )

    # Lifecycle flag
    in_database: bool = Field(
        default=False,
        alias="inDatabase",
        description="Whether this table exists in the database (False for in-development tables)",
    )

    fields: List[Column] = Field(
        ..., description="List of field definitions for this table"
    )

    # === Configuration ===

    model_config = {
        "populate_by_name": True,  # Allow both snake_case and camelCase
    }

    # === Validators ===

    @field_validator("fixed_tags")
    @classmethod
    def validate_fixed_tags(cls, v: List[str]) -> List[str]:
        """Ensure fixed_tags is a list of strings."""
        if not isinstance(v, list):
            raise ValueError("fixed_tags must be a list")
        for tag in v:
            if not isinstance(tag, str):
                raise ValueError(f"All tags must be strings, got {type(tag)}")
        return v

    @field_validator("technology")
    @classmethod
    def validate_technology(
        cls, v: Dict[Technology, TechnologySupport]
    ) -> Dict[Technology, TechnologySupport]:
        """Ensure technology keys are Technology enum values and values are TechnologySupport."""
        for key, value in v.items():
            if not isinstance(key, Technology):
                raise ValueError(
                    f"technology keys must be Technology enum values, got {type(key)}"
                )
            if not isinstance(value, TechnologySupport):
                raise ValueError(
                    f"technology values must be TechnologySupport enum values, got {type(value)}"
                )
        return v

    @model_validator(mode="after")
    def validate_basic_mode_consistency(self) -> "Table":
        """Ensure basic_mode only references technologies present in the technology mapping."""
        for tech in self.basic_mode:
            if tech not in self.technology:
                raise ValueError(
                    f"Invalid configuration for table '{self.table_name}': "
                    f"basic_mode contains {tech} but it is not present in technology mapping."
                )
            if self.technology[tech] == TechnologySupport.UNSUPPORTED:
                raise ValueError(
                    f"Invalid configuration for table '{self.table_name}': "
                    f"basic_mode contains {tech} but its support level is UNSUPPORTED."
                )
        return self

    # === Methods ===

    def to_json_dict(self) -> dict:
        """
        Export to JSON format with camelCase keys.

        Emits:
        - schema metadata (AppName, SchemaName, SchemaVersion, TableName)
        - tableType
        - technology as a mapping of technology name -> support level string
        - basicMode as a list of technology name strings
        - fields filtered to in_database=True columns

        Note: in_database field is excluded from JSON output (used for filtering only).
        UNSUPPORTED technologies are omitted from the technology mapping.
        """
        from .schema_metadata import get_schema_metadata

        result = get_schema_metadata(table_name=self.table_name)

        result["tableType"] = self.table_type.value

        # Emit technology as a mapping, omitting UNSUPPORTED entries
        tech_dict = {
            tech.value: support.value
            for tech, support in self.technology.items()
            if support != TechnologySupport.UNSUPPORTED
        }
        if tech_dict:
            result["technology"] = tech_dict

        # Emit basicMode as a list of technology name strings
        if self.basic_mode:
            result["basicMode"] = [tech.value for tech in self.basic_mode]

        # Filter fields to only include columns where in_database=True
        production_fields = [field for field in self.fields if field.in_database]
        result["fields"] = [field.to_json_dict() for field in production_fields]

        return result

    def get_primary_keys(self) -> List[Column]:
        """Get all primary key fields."""
        return [field for field in self.fields if field.pk]

    def get_required_fields(self) -> List[Column]:
        """Get all required fields."""
        return [field for field in self.fields if field.required]

    def get_field(self, column_name: str) -> Column:
        """
        Get a specific field by column name.

        Args:
            column_name: The name of the column to find

        Returns:
            The field definition

        Raises:
            ValueError: If field not found
        """
        for field in self.fields:
            if field.column_name == column_name:
                return field
        raise ValueError(
            f"Field '{column_name}' not found in table '{self.table_name}'"
        )

    def is_fully_supported(self, tech: Technology) -> bool:
        """Check if table is fully supported for a technology."""
        return self.technology.get(tech) == TechnologySupport.FULLY_SUPPORTED

    def is_available(self, tech: Technology, include_in_dev: bool = False) -> bool:
        """Check if table is available for a technology."""
        support = self.technology.get(tech)
        if support == TechnologySupport.FULLY_SUPPORTED:
            return True
        if include_in_dev and support == TechnologySupport.IN_DEVELOPMENT:
            return True
        return False
