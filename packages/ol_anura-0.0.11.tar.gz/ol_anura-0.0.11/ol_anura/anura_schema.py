"""
AnuraSchema - Comprehensive API for querying Anura schema metadata.

This module provides the AnuraSchema class, which serves as the primary interface
for discovering tables, querying columns, understanding relationships, and accessing
metadata from Python schema files.

All methods are static - do not instantiate this class.

Example:
    >>> from ol_anura.anura_schema import AnuraSchema
    >>> tables = AnuraSchema.get_all_table_names()
    >>> print(tables[:5])
    ['customers', 'facilities', 'suppliers', 'products', 'periods']
"""

from enum import Enum
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple, Type, Union

from .core import (
    CATEGORY_ORDER,
    Category,
    Column,
    DataType,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)
from .core import get_all_table_names as get_registry_table_names
from .core import get_table_category, get_tables_for_category, normalize_table_name


class AnuraSchema:
    """
    Comprehensive API for querying Anura schema metadata.

    This class provides helper methods for discovering tables, querying columns,
    understanding relationships, and accessing metadata from Python schema files.

    The class uses Python schema files from ol_anura.schemas.inputs and
    ol_anura.schemas.outputs as the source of truth, rather than JSON files.

    All methods are static - do not instantiate this class.

    Performance:
        Methods are cached using @lru_cache for optimal performance. Repeated
        calls with the same parameters return cached results in < 1ms.

    Example:
        >>> # Get all table names
        >>> tables = AnuraSchema.get_all_table_names()

        >>> # Get tables supported by an engine
        >>> neo_tables = AnuraSchema.get_fully_supported_tables("neo")

        >>> # Get columns for a table
        >>> columns = AnuraSchema.get_columns("Facilities")

        >>> # Get engine-specific schema
        >>> neo_schema = AnuraSchema.get_engine_schema("neo")

    Note:
        This class maintains backward compatibility with cosmicfrog's AnuraSchema,
        but removes the anura_version parameter (single version only).
    """

    def __init__(self, *args: Any, **kwargs: Any):
        """Compatibility: allow instantiation.

        Legacy cosmicfrog code instantiates AnuraSchema (optionally passing anura_version).
        This implementation is effectively stateless, so we accept and ignore any args.
        """
        # Intentionally no-op
        return

    # =========================================================================
    # INTERNAL HELPER METHODS (Private)
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=None)
    def _load_table_schema(table_name: str) -> Table:
        """
        Get table schema from static registry.

        Uses normalized table name for case-insensitive lookup.

        Args:
            table_name: Name of the table (case-insensitive)

        Returns:
            Table object from the schema registry

        Raises:
            ValueError: If table not found in registry
        """
        # Import registries lazily to avoid circular imports at module load time
        from .schemas.inputs import SCHEMA_REGISTRY as INPUT_SCHEMAS
        from .schemas.outputs import SCHEMA_REGISTRY as OUTPUT_SCHEMAS

        # Normalize table name to canonical CamelCase (handles case-insensitive lookup)
        try:
            canonical_name = normalize_table_name(table_name)
        except ValueError:
            # If we get here, table wasn't found
            raise ValueError(
                f"Table '{table_name}' not found in schema. "
                f"Available tables: {', '.join(get_registry_table_names()[:10])}..."
            )

        # Look up using canonical name
        if canonical_name in INPUT_SCHEMAS:
            return INPUT_SCHEMAS[canonical_name]

        if canonical_name in OUTPUT_SCHEMAS:
            return OUTPUT_SCHEMAS[canonical_name]

        # This shouldn't happen if normalize_table_name worked correctly
        raise ValueError(
            f"Table '{canonical_name}' found in registry but not in schemas"
        )

    @staticmethod
    @lru_cache(maxsize=32)
    def _get_all_table_schemas(
        input_only: bool = False,
        output_only: bool = False,
        in_database: Optional[bool] = True,
    ) -> Dict[str, Table]:
        """
        Load all table schemas based on filters.

        Args:
            input_only: Only load input tables (table_type == TableType.INPUT)
            output_only: Only load output tables (table_type == TableType.OUTPUT)
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database, False = only not in database

        Returns:
            Dict mapping table_name -> Table object
        """
        all_table_names = get_registry_table_names()

        schemas = {}
        for table_name in all_table_names:
            try:
                table = AnuraSchema._load_table_schema(table_name)
            except ValueError:
                continue

            # Filter by table_type
            if input_only and table.table_type != TableType.INPUT:
                continue
            if output_only and table.table_type != TableType.OUTPUT:
                continue

            # Filter by in_database
            if in_database is not None and table.in_database != in_database:
                continue

            schemas[table_name] = table

        return schemas

    @staticmethod
    def _normalize_table_name(table_name: str, lower_case: bool) -> str:
        """
        Normalize table name based on case preference.

        Args:
            table_name: Original table name
            lower_case: Whether to convert to lowercase

        Returns:
            Normalized table name
        """
        return table_name.lower() if lower_case else table_name

    @staticmethod
    def _normalize_column_name(column_name: str, lower_case: bool) -> str:
        """
        Normalize column name based on case preference.

        Args:
            column_name: Original column name
            lower_case: Whether to convert to lowercase

        Returns:
            Normalized column name
        """
        return column_name.lower() if lower_case else column_name

    @staticmethod
    def _validate_technology(technology: str) -> str:
        """
        Validate and normalize technology name.

        Args:
            technology: Technology name (case-insensitive)

        Returns:
            Normalized lowercase technology name

        Raises:
            ValueError: If technology is not valid
        """
        tech_lower = technology.lower()

        # Check against Technology enum values (case-insensitive)
        valid_technologies = {t.value.lower() for t in Technology}

        if tech_lower not in valid_technologies:
            # Get sorted uppercase names for error message
            valid_names = sorted([t.value for t in Technology])
            raise ValueError(
                f"Invalid technology '{technology}'. "
                f"Valid options: {', '.join(valid_names)}"
            )

        return tech_lower

    @staticmethod
    def _tech_enum(technology: str) -> Technology:
        """Convert a validated lowercase technology string to its Technology enum member."""
        return Technology(technology.upper())

    # =========================================================================
    # TABLE DISCOVERY METHODS
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=32)
    def get_all_table_names(
        lower_case: bool = True,
        input_only: bool = False,
        output_only: bool = False,
        in_database: Optional[bool] = True,
    ) -> List[str]:
        """
        Get list of all table names with optional filtering.

        Args:
            lower_case: Return table names in lowercase
            input_only: Only return input tables (exclude output tables)
            output_only: Only return output tables (exclude input tables)
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database (default),
                        False = only tables not in database

        Returns:
            List of table names

        Raises:
            ValueError: If both input_only and output_only are True

        Example:
            >>> tables = AnuraSchema.get_all_table_names()
            >>> print(tables[:5])
            ['customers', 'facilities', 'suppliers', 'products', 'periods']

            >>> input_tables = AnuraSchema.get_all_table_names(input_only=True)
            >>> print(len(input_tables))
            120
        """
        if input_only and output_only:
            raise ValueError("Cannot specify both input_only and output_only")

        schemas = AnuraSchema._get_all_table_schemas(
            input_only, output_only, in_database
        )
        table_names = list(schemas.keys())

        if lower_case:
            return [t.lower() for t in table_names]
        return table_names

    @staticmethod
    def get_input_table_names(
        lower_case: bool = True, in_database: Optional[bool] = True
    ) -> List[str]:
        """
        Get list of input table names only.

        Convenience method that calls get_all_table_names(input_only=True).

        Args:
            lower_case: Return table names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database (default),
                        False = only tables not in database

        Returns:
            List of input table names

        Example:
            >>> input_tables = AnuraSchema.get_input_table_names()
            >>> 'facilities' in input_tables
            True
            >>> 'optimizationnetworksummary' in input_tables
            False
        """
        return AnuraSchema.get_all_table_names(
            lower_case, input_only=True, in_database=in_database
        )

    @staticmethod
    def get_output_table_names(
        lower_case: bool = True, in_database: Optional[bool] = True
    ) -> List[str]:
        """
        Get list of output table names only.

        Convenience method that calls get_all_table_names(output_only=True).

        Args:
            lower_case: Return table names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database (default),
                        False = only tables not in database

        Returns:
            List of output table names

        Example:
            >>> output_tables = AnuraSchema.get_output_table_names()
            >>> 'optimizationnetworksummary' in output_tables
            True
            >>> 'facilities' in output_tables
            False
        """
        return AnuraSchema.get_all_table_names(
            lower_case, output_only=True, in_database=in_database
        )

    @staticmethod
    @lru_cache(maxsize=128)
    def get_tables_by_category(
        category: Union[str, Category],
        lower_case: bool = True,
        in_database: Optional[bool] = True,
    ) -> List[str]:
        """
        Get all tables in a specific category.

        Args:
            category: Category enum or category name string
            lower_case: Return table names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database (default),
                        False = only tables not in database

        Returns:
            List of table names in the category

        Raises:
            ValueError: If category is not valid

        Example:
            >>> tables = AnuraSchema.get_tables_by_category("Model Elements")
            >>> print(tables)
            ['customers', 'facilities', 'suppliers', 'products', 'periods', 'organizations']

            >>> from ol_anura.core import Category
            >>> tables = AnuraSchema.get_tables_by_category(Category.SOURCING)
        """
        # Convert string to Category if needed
        if isinstance(category, str):
            try:
                category = Category(category)
            except ValueError:
                valid_categories = [c.value for c in CATEGORY_ORDER]
                raise ValueError(
                    f"Invalid category '{category}'. "
                    f"Valid options: {', '.join(valid_categories)}"
                )

        tables = get_tables_for_category(category)

        if in_database is not None:
            filtered = []
            for table_name in tables:
                try:
                    table_schema = AnuraSchema._load_table_schema(table_name)
                    if table_schema.in_database == in_database:
                        filtered.append(table_name)
                except ValueError:
                    continue
            tables = filtered

        if lower_case:
            return [t.lower() for t in tables]
        return tables

    @staticmethod
    @lru_cache(maxsize=16)
    def get_abbreviated_table_names(
        input_only: bool = False, in_database: Optional[bool] = True
    ) -> Dict[str, str]:
        """
        Get mapping of abbreviated names to full table names.

        Args:
            input_only: Only include input tables
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database (default),
                        False = only tables not in database

        Returns:
            Dict mapping abbreviated_name (lowercase) -> full_table_name (lowercase)

        Example:
            >>> abbrev = AnuraSchema.get_abbreviated_table_names()
            >>> abbrev['facilities']
            'facilities'
        """
        schemas = AnuraSchema._get_all_table_schemas(
            input_only=input_only, in_database=in_database
        )

        result = {}
        for table_name, table_schema in schemas.items():
            abbreviated = table_schema.abbreviated_name
            if abbreviated:
                result[abbreviated.lower()] = table_name.lower()

        return result

    # =========================================================================
    # TECHNOLOGY SUPPORT METHODS - TABLES
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=128)
    def get_tables_for_technology(
        technology: str,
        support_levels: Optional[tuple] = None,
        lower_case: bool = True,
        in_database: Optional[bool] = None,
    ) -> List[str]:
        """
        Get tables supported by a technology, optionally filtered by support level.

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            support_levels: Optional tuple of TechnologySupport levels to filter by.
                           If None, returns all tables where technology is supported
                           (not None and not UNSUPPORTED).
                           Pass tuple for caching: tuple([TechnologySupport.FULLY_SUPPORTED])
            lower_case: Return table names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database, False = only not in database

        Returns:
            List of table names

        Raises:
            ValueError: If technology is invalid

        Example:
            >>> from ol_anura.core import TechnologySupport
            >>> # Get fully supported tables
            >>> tables = AnuraSchema.get_tables_for_technology(
            ...     "neo", tuple([TechnologySupport.FULLY_SUPPORTED])
            ... )
            >>> print(len(tables))
            120

            >>> # Get fully supported AND in-development tables
            >>> tables = AnuraSchema.get_tables_for_technology(
            ...     "neo", tuple([TechnologySupport.FULLY_SUPPORTED, TechnologySupport.IN_DEVELOPMENT])
            ... )

            >>> # Get all supported tables
            >>> tables = AnuraSchema.get_tables_for_technology("neo")
            >>> 'facilities' in tables
            True
        """
        tech = AnuraSchema._validate_technology(technology)
        tech_enum = AnuraSchema._tech_enum(tech)
        schemas = AnuraSchema._get_all_table_schemas()

        result = []
        for table_name, table_schema in schemas.items():
            # Filter by in_database if specified
            if in_database is not None and table_schema.in_database != in_database:
                continue

            tech_support = table_schema.technology.get(tech_enum)

            if support_levels is not None:
                if tech_support in support_levels:
                    result.append(table_name)
            else:
                if (
                    tech_support is not None
                    and tech_support != TechnologySupport.UNSUPPORTED
                ):
                    result.append(table_name)

        if lower_case:
            return [t.lower() for t in result]
        return result

    @staticmethod
    def get_supported_tables(
        technology: str,
        include_in_development: bool = True,
        lower_case: bool = True,
        in_database: Optional[bool] = None,
    ) -> List[str]:
        """
        Get all supported tables for a technology (convenience method).

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            include_in_development: Include IN_DEVELOPMENT tables along with FULLY_SUPPORTED
            lower_case: Return table names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database, False = only not in database

        Returns:
            List of supported table names

        Raises:
            ValueError: If technology is invalid

        Example:
            >>> tables = AnuraSchema.get_supported_tables("neo", include_in_development=True)
            >>> print(len(tables))
            125

            >>> tables = AnuraSchema.get_supported_tables("neo", include_in_development=False)
            >>> print(len(tables))
            120
        """
        # Build support levels list based on include_in_development flag
        support_levels = [TechnologySupport.FULLY_SUPPORTED]
        if include_in_development:
            support_levels.append(TechnologySupport.IN_DEVELOPMENT)

        return AnuraSchema.get_tables_for_technology(
            technology, tuple(support_levels), lower_case, in_database
        )

    @staticmethod
    def get_fully_supported_tables(
        technology: str, lower_case: bool = True, in_database: Optional[bool] = None
    ) -> List[str]:
        """
        Get only FULLY_SUPPORTED tables for a technology.

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            lower_case: Return table names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only tables in database, False = only not in database

        Returns:
            List of fully supported table names

        Raises:
            ValueError: If technology is invalid

        Example:
            >>> tables = AnuraSchema.get_fully_supported_tables("neo")
            >>> 'facilities' in tables
            True
        """
        return AnuraSchema.get_tables_for_technology(
            technology,
            tuple([TechnologySupport.FULLY_SUPPORTED]),
            lower_case,
            in_database,
        )

    @staticmethod
    def get_table_support_level(
        table_name: str, technology: str
    ) -> Optional[TechnologySupport]:
        """
        Check what support level a specific table has for a technology.

        Args:
            table_name: Name of the table
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")

        Returns:
            TechnologySupport enum or None if not supported

        Raises:
            ValueError: If table or technology is invalid

        Example:
            >>> support = AnuraSchema.get_table_support_level("Facilities", "neo")
            >>> print(support)
            TechnologySupport.FULLY_SUPPORTED

            >>> support = AnuraSchema.get_table_support_level("SomeTable", "dart")
            >>> print(support)
            None
        """
        tech = AnuraSchema._validate_technology(technology)
        table_schema = AnuraSchema._load_table_schema(table_name)
        return table_schema.technology.get(AnuraSchema._tech_enum(tech))

    @staticmethod
    @lru_cache(maxsize=16)
    def get_basic_mode_tables(technology: str, lower_case: bool = True) -> List[str]:
        """
        Get tables available in basic mode for a technology.

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            lower_case: Return table names in lowercase

        Returns:
            List of table names available in basic mode

        Raises:
            ValueError: If technology is invalid

        Example:
            >>> tables = AnuraSchema.get_basic_mode_tables("triad")
            >>> 'facilities' in tables
            True
        """
        tech = AnuraSchema._validate_technology(technology)
        tech_enum = AnuraSchema._tech_enum(tech)
        schemas = AnuraSchema._get_all_table_schemas()

        result = []
        for table_name, table_schema in schemas.items():
            if tech_enum in table_schema.basic_mode:
                result.append(table_name)

        if lower_case:
            return [t.lower() for t in result]
        return result

    # =========================================================================
    # BASIC COLUMN QUERY METHODS
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=256)
    def get_primary_keys(table_name: str, lower_case: bool = True) -> List[str]:
        """
        Get primary key columns for a table.

        Args:
            table_name: Name of the table
            lower_case: Return column names in lowercase

        Returns:
            List of primary key column names

        Raises:
            ValueError: If table not found

        Example:
            >>> pks = AnuraSchema.get_primary_keys("Facilities")
            >>> print(pks)
            ['facilityname']
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        pks = [field.column_name for field in table_schema.fields if field.pk]

        if lower_case:
            return [pk.lower() for pk in pks]
        return pks

    @staticmethod
    @lru_cache(maxsize=256)
    def get_columns(table_name: str, lower_case: bool = True) -> List[str]:
        """
        Get all column names for a table.

        Args:
            table_name: Name of the table
            lower_case: Return column names in lowercase

        Returns:
            List of all column names

        Raises:
            ValueError: If table not found

        Example:
            >>> columns = AnuraSchema.get_columns("Facilities")
            >>> print(columns[:5])
            ['facilityname', 'status', 'facilitystatus', 'initialstate', 'organization']
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        columns = [field.column_name for field in table_schema.fields]

        if lower_case:
            return [col.lower() for col in columns]
        return columns

    @staticmethod
    def get_column_data_type(
        table_name: str, column_name: str
    ) -> Union[Type[Enum], type, str]:
        """
        Get the data type for a specific column.

        Args:
            table_name: Name of the table
            column_name: Name of the column

        Returns:
            The data type (can be Python type, Enum class, or string)

        Raises:
            ValueError: If table or column not found

        Example:
            >>> dtype = AnuraSchema.get_column_data_type("Facilities", "FacilityName")
            >>> print(dtype)
            DataType.STRING
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        # Find the column
        for field in table_schema.fields:
            if field.column_name.lower() == column_name.lower():
                return field.data_type

        raise ValueError(f"Column '{column_name}' not found in table '{table_name}'")

    @staticmethod
    @lru_cache(maxsize=None)
    def is_enum_column(table_name: str, column_name: str) -> bool:
        """Return True if the column has a fixed set of valid string values.

        This is True for domain enum columns (e.g. FacilityStatus → "Open"/"Closed"/"Consider").
        It is False for primitive DataType columns (String, Double, Integer, Boolean, etc.).

        Args:
            table_name: Name of the table (case-insensitive)
            column_name: Name of the column (case-insensitive)

        Returns:
            True if the column is a domain enum; False otherwise

        Raises:
            ValueError: If table or column not found

        Example:
            >>> AnuraSchema.is_enum_column("Facilities", "FacilityStatus")
            True
            >>> AnuraSchema.is_enum_column("Facilities", "FacilityName")
            False
        """
        dt = AnuraSchema.get_column_data_type(table_name, column_name)
        return (
            isinstance(dt, type)
            and issubclass(dt, Enum)
            and not isinstance(dt, DataType)
        )

    @staticmethod
    @lru_cache(maxsize=None)
    def get_enum_values(table_name: str, column_name: str) -> Optional[List[str]]:
        """Return the valid string values for an enum column, or None if not an enum.

        Args:
            table_name: Name of the table (case-insensitive)
            column_name: Name of the column (case-insensitive)

        Returns:
            List of valid string values if the column is a domain enum; None otherwise

        Raises:
            ValueError: If table or column not found

        Example:
            >>> AnuraSchema.get_enum_values("Facilities", "FacilityStatus")
            ['Closed', 'Consider', 'Open']
            >>> AnuraSchema.get_enum_values("Facilities", "FacilityName")
            None
        """
        if not AnuraSchema.is_enum_column(table_name, column_name):
            return None
        dt = AnuraSchema.get_column_data_type(table_name, column_name)
        return [member.value for member in dt]

    @staticmethod
    @lru_cache(maxsize=256)
    def get_enum_columns(table_name: str) -> Dict[str, List[str]]:
        """Return all enum columns in a table and their valid values.

        Returns a mapping of canonical column name → list of valid string values, for every
        column that is a domain enum. Non-enum columns are excluded. This is the
        primary method used by downstream tooling to know which columns require validated values.

        Args:
            table_name: Name of the table (case-insensitive)

        Returns:
            Dict mapping column name (canonical CamelCase) → list of valid string values.
            Empty dict if the table has no enum columns.

        Raises:
            ValueError: If table not found

        Example:
            >>> AnuraSchema.get_enum_columns("Facilities")
            {'FacilityStatus': ['Closed', 'Consider', 'Open'], 'InitialState': ['Existing', 'Potential']}
        """
        columns = AnuraSchema.get_columns(table_name, lower_case=False)
        result: Dict[str, List[str]] = {}
        for col in columns:
            values = AnuraSchema.get_enum_values(table_name, col)
            if values is not None:
                result[col] = values
        return result

    @staticmethod
    def is_column_supported_by_technology(
        table_name: str, column_name: str, technology: str
    ) -> bool:
        """
        Check if a column is supported by a specific technology.

        Args:
            table_name: Name of the table
            column_name: Name of the column
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")

        Returns:
            True if column is supported, False otherwise

        Raises:
            ValueError: If table, column, or technology is invalid

        Example:
            >>> supported = AnuraSchema.is_column_supported_by_technology(
            ...     "Facilities", "Address", "neo"
            ... )
            >>> print(supported)
            True
        """
        tech = AnuraSchema._validate_technology(technology)
        tech_enum = AnuraSchema._tech_enum(tech)
        table_schema = AnuraSchema._load_table_schema(table_name)

        for field in table_schema.fields:
            if field.column_name.lower() == column_name.lower():
                tech_support = field.technology.get(tech_enum)
                return (
                    tech_support is not None
                    and tech_support != TechnologySupport.UNSUPPORTED
                )

        raise ValueError(f"Column '{column_name}' not found in table '{table_name}'")

    @staticmethod
    @lru_cache(maxsize=256)
    def get_required_columns(table_name: str, lower_case: bool = True) -> List[str]:
        """
        Get all required columns for a table.

        Args:
            table_name: Name of the table
            lower_case: Return column names in lowercase

        Returns:
            List of required column names

        Raises:
            ValueError: If table not found

        Example:
            >>> required = AnuraSchema.get_required_columns("Facilities")
            >>> print(required)
            ['facilityname', 'status', 'facilitystatus', 'initialstate']
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        required = [
            field.column_name for field in table_schema.fields if field.required
        ]

        if lower_case:
            return [col.lower() for col in required]
        return required

    @staticmethod
    @lru_cache(maxsize=256)
    def get_columns_by_data_type(
        table_name: str, data_type: Union[Type, str], lower_case: bool = True
    ) -> List[str]:
        """
        Filter columns by data type.

        Args:
            table_name: Name of the table
            data_type: Data type to filter by (can be type, Enum, or string representation)
            lower_case: Return column names in lowercase

        Returns:
            List of column names matching the data type

        Raises:
            ValueError: If table not found

        Example:
            >>> from ol_anura.core import DataType
            >>> string_cols = AnuraSchema.get_columns_by_data_type("Facilities", DataType.STRING)
            >>> print(string_cols[:3])
            ['facilityname', 'organization', 'address']
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        # Convert data_type to string for comparison if needed
        if hasattr(data_type, "__name__"):
            type_str = data_type.__name__
        else:
            type_str = str(data_type)

        matching_cols = []
        for field in table_schema.fields:
            field_type_str = str(field.data_type)
            if (
                type_str.lower() in field_type_str.lower()
                or field.data_type == data_type
            ):
                matching_cols.append(field.column_name)

        if lower_case:
            return [col.lower() for col in matching_cols]
        return matching_cols

    @staticmethod
    @lru_cache(maxsize=256)
    def get_columns_with_validation(
        table_name: str, lower_case: bool = True
    ) -> List[str]:
        """
        Get columns that have validation_type defined.

        Args:
            table_name: Name of the table
            lower_case: Return column names in lowercase

        Returns:
            List of column names with validation

        Raises:
            ValueError: If table not found

        Example:
            >>> validated = AnuraSchema.get_columns_with_validation("Facilities")
            >>> print(validated)
            ['organization', 'map', ...]
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        validated = [
            field.column_name
            for field in table_schema.fields
            if field.validation_type is not None
        ]

        if lower_case:
            return [col.lower() for col in validated]
        return validated

    @staticmethod
    @lru_cache(maxsize=256)
    def get_field_definitions(
        table_name: str, lower_case: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Get field definitions for a table.

        Returns list of dicts with a subset of column metadata in cosmicfrog-compatible format.

        Args:
            table_name: Name of the table
            lower_case: Convert table and column names to lowercase

        Returns:
            List of field definition dicts

        Raises:
            ValueError: If table not found

        Example:
            >>> fields = AnuraSchema.get_field_definitions("Facilities")
            >>> print(fields[0])
            {
                'Column Name': 'facilityname',
                'Data Type': 'STRING',
                'Required': 'Yes',
                'PK': 'Yes',
                'Explanation': 'The name of the Facility',
                ...
            }
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        field_defs = []
        for field in table_schema.fields:
            field_dict = {
                "Column Name": (
                    field.column_name.lower() if lower_case else field.column_name
                ),
                "Data Type": str(field.data_type),
                "Validation Type": field.validation_type or "",
                "Required": "Yes" if field.required else "No",
                "PK": "Yes" if field.pk else "No",
                "Explanation": field.explanation or "",
            }

            # Add optional fields if present
            if field.default_value is not None:
                field_dict["Default Value"] = str(field.default_value)
            if field.master_table:
                field_dict["Master Table"] = field.master_table
            if field.expandable:
                field_dict["Expandable"] = "Yes"

            field_defs.append(field_dict)

        return field_defs

    # =========================================================================
    # TECHNOLOGY SUPPORT METHODS - COLUMNS
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=1024)
    def get_columns_for_technology(
        table_name: str,
        technology: str,
        support_levels: Optional[tuple] = None,
        lower_case: bool = True,
        in_database: Optional[bool] = None,
    ) -> List[str]:
        """
        Get columns in a table that are supported by a specific technology.

        Args:
            table_name: Name of the table
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            support_levels: Optional tuple of TechnologySupport levels to filter by.
                           If None, returns all supported columns (not None and not UNSUPPORTED).
                           Pass tuple for caching: tuple([TechnologySupport.FULLY_SUPPORTED])
            lower_case: Return column names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only columns in database, False = only not in database

        Returns:
            List of supported column names

        Raises:
            ValueError: If table or technology is invalid

        Example:
            >>> from ol_anura.core import TechnologySupport
            >>> # Get fully supported columns
            >>> cols = AnuraSchema.get_columns_for_technology(
            ...     "Facilities", "neo", tuple([TechnologySupport.FULLY_SUPPORTED])
            ... )
            >>> 'facilityname' in cols
            True

            >>> # Get fully supported AND in-development columns
            >>> cols = AnuraSchema.get_columns_for_technology(
            ...     "Facilities", "neo",
            ...     tuple([TechnologySupport.FULLY_SUPPORTED, TechnologySupport.IN_DEVELOPMENT])
            ... )
        """
        tech = AnuraSchema._validate_technology(technology)
        tech_enum = AnuraSchema._tech_enum(tech)
        table_schema = AnuraSchema._load_table_schema(table_name)

        result = []
        for field in table_schema.fields:
            if in_database is not None and field.in_database != in_database:
                continue

            tech_support = field.technology.get(tech_enum)

            if support_levels is not None:
                if tech_support in support_levels:
                    result.append(field.column_name)
            else:
                if (
                    tech_support is not None
                    and tech_support != TechnologySupport.UNSUPPORTED
                ):
                    result.append(field.column_name)

        if lower_case:
            return [col.lower() for col in result]
        return result

    @staticmethod
    def get_supported_columns(
        table_name: str,
        technology: str,
        include_in_development: bool = True,
        lower_case: bool = True,
        in_database: Optional[bool] = None,
    ) -> List[str]:
        """
        Get supported columns for a technology (convenience method).

        Args:
            table_name: Name of the table
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            include_in_development: Include IN_DEVELOPMENT columns along with FULLY_SUPPORTED
            lower_case: Return column names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only columns in database, False = only not in database

        Returns:
            List of supported column names

        Raises:
            ValueError: If table or technology is invalid

        Example:
            >>> cols = AnuraSchema.get_supported_columns("Facilities", "neo")
            >>> 'facilityname' in cols
            True
        """
        # Build support levels list based on include_in_development flag
        support_levels = [TechnologySupport.FULLY_SUPPORTED]
        if include_in_development:
            support_levels.append(TechnologySupport.IN_DEVELOPMENT)

        return AnuraSchema.get_columns_for_technology(
            table_name, technology, tuple(support_levels), lower_case, in_database
        )

    @staticmethod
    def get_column_support_level(
        table_name: str, column_name: str, technology: str
    ) -> Optional[TechnologySupport]:
        """
        Check support level of specific column for a technology.

        Args:
            table_name: Name of the table
            column_name: Name of the column
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")

        Returns:
            TechnologySupport enum or None

        Raises:
            ValueError: If table, column, or technology is invalid

        Example:
            >>> support = AnuraSchema.get_column_support_level("Facilities", "Address", "neo")
            >>> print(support)
            TechnologySupport.FULLY_SUPPORTED
        """
        tech = AnuraSchema._validate_technology(technology)
        tech_enum = AnuraSchema._tech_enum(tech)
        table_schema = AnuraSchema._load_table_schema(table_name)

        for field in table_schema.fields:
            if field.column_name.lower() == column_name.lower():
                return field.technology.get(tech_enum)

        raise ValueError(f"Column '{column_name}' not found in table '{table_name}'")

    @staticmethod
    @lru_cache(maxsize=512)
    def get_basic_mode_columns(
        technology: str,
        table_name: Optional[str] = None,
        lower_case: bool = True,
        in_database: Optional[bool] = None,
        input_only: bool = False,
    ) -> Union[List[str], Dict[str, List[str]]]:
        """
        Get columns marked as basic mode for a technology.

        A column is considered "basic mode" if:
        1. The technology name appears in the column's basic_mode list
        2. The column's support level for that technology is FULLY_SUPPORTED
        3. The column's in_database matches the filter (if specified)

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            table_name: Optional specific table. If None, returns all tables.
            lower_case: Return column names in lowercase
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only columns in database, False = only not in database
            input_only: Only include input tables (ignored if table_name is specified)

        Returns:
            If table_name provided: List of column names marked as basic mode
            If table_name is None: Dict mapping table_name -> list of basic mode column names

        Raises:
            ValueError: If technology or table is invalid

        Example:
            >>> # Get basic mode columns for NEO in Facilities table
            >>> cols = AnuraSchema.get_basic_mode_columns("neo", "Facilities")
            >>> print(cols)
            ['facilityname', 'status', ...]

            >>> # Get all basic mode columns for TRIAD across input tables only
            >>> all_cols = AnuraSchema.get_basic_mode_columns("triad", input_only=True)
            >>> print(all_cols['Facilities'])
            ['facilityname', 'status', 'facilitystatus']
        """
        tech = AnuraSchema._validate_technology(technology)
        tech_enum = AnuraSchema._tech_enum(tech)

        if table_name:
            table_schema = AnuraSchema._load_table_schema(table_name)

            result = []
            for field in table_schema.fields:
                if in_database is not None and field.in_database != in_database:
                    continue

                if tech_enum not in field.basic_mode:
                    continue

                if field.technology.get(tech_enum) != TechnologySupport.FULLY_SUPPORTED:
                    continue

                result.append(field.column_name)

            if lower_case:
                return [col.lower() for col in result]
            return result

        else:
            schemas = AnuraSchema._get_all_table_schemas(input_only=input_only)
            result = {}

            for tbl_name, table_schema in schemas.items():
                columns = []

                for field in table_schema.fields:
                    if in_database is not None and field.in_database != in_database:
                        continue

                    if tech_enum not in field.basic_mode:
                        continue

                    if (
                        field.technology.get(tech_enum)
                        != TechnologySupport.FULLY_SUPPORTED
                    ):
                        continue

                    columns.append(field.column_name)

                if columns:
                    table_key = tbl_name.lower() if lower_case else tbl_name
                    if lower_case:
                        result[table_key] = [col.lower() for col in columns]
                    else:
                        result[table_key] = columns

            return result

    @staticmethod
    @lru_cache(maxsize=1024)
    def get_table_schema_for_technology(
        table_name: str,
        technology: str,
        support_levels: Optional[tuple] = None,
        in_database: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """
        Get complete table schema filtered to only supported columns for an engine.

        Args:
            table_name: Name of the table
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            support_levels: Optional tuple of TechnologySupport levels to filter by.
                           If None, returns all supported columns.
                           Pass tuple for caching: tuple([TechnologySupport.FULLY_SUPPORTED])
            in_database: Optional filter for in_database flag.
                        None = no filter, True = only columns in database, False = only not in database

        Returns:
            Dict with table metadata and filtered column list

        Raises:
            ValueError: If table or technology is invalid

        Example:
            >>> schema = AnuraSchema.get_table_schema_for_technology("Facilities", "neo")
            >>> print(schema['columns'][:3])
            ['FacilityName', 'Status', 'FacilityStatus']
        """
        tech = AnuraSchema._validate_technology(technology)
        table_schema = AnuraSchema._load_table_schema(table_name)

        # Get filtered columns
        columns = AnuraSchema.get_columns_for_technology(
            table_name,
            technology,
            support_levels,
            lower_case=False,
            in_database=in_database,
        )

        # Get primary keys from filtered columns
        pks = [
            col
            for col in columns
            if col in AnuraSchema.get_primary_keys(table_name, lower_case=False)
        ]

        return {
            "table_name": table_schema.table_name,
            "columns": columns,
            "primary_keys": pks,
            "technology_support": table_schema.technology.get(
                AnuraSchema._tech_enum(tech)
            ),
            "category": str(get_table_category(table_name).value),
            "abbreviated_name": table_schema.abbreviated_name,
        }

    # =========================================================================
    # ENGINE-SPECIFIC SCHEMA METHODS
    # =========================================================================

    @staticmethod
    def get_schema_columns(
        schema_type: Optional[str] = None,
        technologies: Optional[List[str]] = None,
        support_levels: Optional[List[TechnologySupport]] = None,
        table_filter: Optional[List[str]] = None,
    ) -> Dict[str, List["Column"]]:
        """
        Get schema as Column objects for external library compatibility.

        Returns Column objects directly instead of column names/metadata.

        Args:
            schema_type: "input", "output", or None (both)
            technologies: List of technology names to include. If None, includes
                        all defined technologies.
            support_levels: List of support levels to include.
                            If None, includes FULLY_SUPPORTED and IN_DEVELOPMENT.
            table_filter: Optional list of table names to include.

        Returns:
            Dict mapping table_name -> list of Column objects

        Raises:
            ValueError: If schema_type or any technology name is invalid
        """
        from ol_anura.core import Technology

        from .schemas.inputs import SCHEMA_REGISTRY as INPUT_SCHEMAS
        from .schemas.outputs import SCHEMA_REGISTRY as OUTPUT_SCHEMAS

        # Default support levels
        if support_levels is None:
            support_levels = (
                TechnologySupport.FULLY_SUPPORTED,
                TechnologySupport.IN_DEVELOPMENT,
            )

        # Default to all technologies defined in enum
        if technologies is None:
            technologies = [t.value for t in Technology]

        # Normalize and validate technology names
        normalized_technologies = [
            AnuraSchema._validate_technology(tech) for tech in technologies
        ]

        # Select schema registry
        if schema_type == "input":
            schemas = INPUT_SCHEMAS
        elif schema_type == "output":
            schemas = OUTPUT_SCHEMAS
        elif schema_type is None:
            schemas = INPUT_SCHEMAS | OUTPUT_SCHEMAS
        else:
            raise ValueError("schema_type must be 'input', 'output', or None")

        tech_enums = [AnuraSchema._tech_enum(t) for t in normalized_technologies]

        result: Dict[str, List["Column"]] = {}

        for table_name, table_schema in schemas.items():
            if table_filter and table_name not in table_filter:
                continue

            supported_columns = [
                field
                for field in table_schema.fields
                if any(
                    field.technology.get(tech_enum) in support_levels
                    for tech_enum in tech_enums
                )
            ]

            if supported_columns:
                result[table_name] = supported_columns

        return result

    @staticmethod
    def get_engine_schema(
        technology: str, support_levels: Optional[List[TechnologySupport]] = None
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get complete schema for an engine: all tables and their supported columns.

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            support_levels: List of support levels to include.
                           If None, includes [FULLY_SUPPORTED, IN_DEVELOPMENT]

        Returns:
            Nested dict structure with table metadata and filtered columns

        Raises:
            ValueError: If technology is invalid

        Example:
            >>> from ol_anura.core import TechnologySupport
            >>> neo_schema = AnuraSchema.get_engine_schema("neo", [TechnologySupport.FULLY_SUPPORTED])
            >>> print(list(neo_schema.keys())[:5])
            ['Customers', 'Facilities', 'Suppliers', 'Products', 'Periods']
            >>> print(neo_schema['Facilities']['columns'][:3])
            ['FacilityName', 'Status', 'FacilityStatus']
        """
        tech = AnuraSchema._validate_technology(technology)

        # Default to FULLY_SUPPORTED and IN_DEVELOPMENT
        if support_levels is None:
            support_levels = [
                TechnologySupport.FULLY_SUPPORTED,
                TechnologySupport.IN_DEVELOPMENT,
            ]

        # Convert to tuple for caching
        support_levels_tuple = tuple(support_levels)

        # Call cached implementation
        return AnuraSchema._get_engine_schema_cached(tech, support_levels_tuple)

    @staticmethod
    @lru_cache(maxsize=64)
    def _get_engine_schema_cached(
        technology: str, support_levels_tuple: tuple
    ) -> Dict[str, Dict[str, Any]]:
        """Cache the result of get_engine_schema."""
        support_levels = list(support_levels_tuple)
        tech_enum = AnuraSchema._tech_enum(technology)
        schemas = AnuraSchema._get_all_table_schemas()
        result = {}

        for table_name, table_schema in schemas.items():
            table_support = table_schema.technology.get(tech_enum)

            if table_support in support_levels:
                columns = AnuraSchema.get_columns_for_technology(
                    table_name, technology, support_levels_tuple, lower_case=False
                )

                all_pks = AnuraSchema.get_primary_keys(table_name, lower_case=False)
                pks = [pk for pk in all_pks if pk in columns]

                result[table_name] = {
                    "columns": columns,
                    "primary_keys": pks,
                    "support_level": table_support,
                    "category": str(get_table_category(table_name).value),
                    "abbreviated_name": table_schema.abbreviated_name,
                    "basic_mode": tech_enum in table_schema.basic_mode,
                }

        return result

    @staticmethod
    def get_engine_table_list(
        technology: str,
        support_levels: Optional[List[TechnologySupport]] = None,
        lower_case: bool = True,
    ) -> List[str]:
        """
        Get table names supported by an engine.

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            support_levels: List of support levels to include.
                           If None, includes [FULLY_SUPPORTED, IN_DEVELOPMENT]
            lower_case: Return table names in lowercase

        Returns:
            List of table names

        Raises:
            ValueError: If technology is invalid

        Example:
            >>> from ol_anura.core import TechnologySupport
            >>> tables = AnuraSchema.get_engine_table_list("neo", [TechnologySupport.FULLY_SUPPORTED])
            >>> print(len(tables))
            120
        """
        schema = AnuraSchema.get_engine_schema(technology, support_levels)
        tables = list(schema.keys())

        if lower_case:
            return [t.lower() for t in tables]
        return tables

    @staticmethod
    def get_engine_column_mapping(
        technology: str,
        support_levels: Optional[List[TechnologySupport]] = None,
        lower_case: bool = True,
    ) -> Dict[str, List[str]]:
        """
        Get table-to-columns mapping for an engine.

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            support_levels: List of support levels to include.
                           If None, includes [FULLY_SUPPORTED, IN_DEVELOPMENT]
            lower_case: Return table and column names in lowercase

        Returns:
            Dict mapping table names to their supported column lists

        Raises:
            ValueError: If technology is invalid

        Example:
            >>> mapping = AnuraSchema.get_engine_column_mapping("neo")
            >>> print(mapping['facilities'][:3])
            ['facilityname', 'status', 'facilitystatus']
        """
        schema = AnuraSchema.get_engine_schema(technology, support_levels)

        result = {}
        for table_name, table_data in schema.items():
            table_key = table_name.lower() if lower_case else table_name
            columns = table_data["columns"]

            if lower_case:
                result[table_key] = [col.lower() for col in columns]
            else:
                result[table_key] = columns

        return result

    @staticmethod
    def export_engine_schema_to_dict(
        technology: str, support_levels: Optional[List[TechnologySupport]] = None
    ) -> Dict[str, Any]:
        """
        Export full engine schema as JSON-serializable dict.

        Args:
            technology: Technology name ("neo", "throg", "dendro", "hopper", "triad", "dart")
            support_levels: List of support levels to include.
                           If None, includes [FULLY_SUPPORTED, IN_DEVELOPMENT]

        Returns:
            Complete schema dict ready for JSON export

        Raises:
            ValueError: If technology is invalid

        Example:
            >>> import json
            >>> schema_dict = AnuraSchema.export_engine_schema_to_dict("neo")
            >>> with open('neo_schema.json', 'w') as f:
            ...     json.dump(schema_dict, f, indent=2)
        """
        schema = AnuraSchema.get_engine_schema(technology, support_levels)

        # Convert TechnologySupport enums to strings for JSON serialization
        serializable_schema = {}
        for table_name, table_data in schema.items():
            serializable_schema[table_name] = {
                "columns": table_data["columns"],
                "primary_keys": table_data["primary_keys"],
                "support_level": (
                    table_data["support_level"].value
                    if table_data["support_level"]
                    else None
                ),
                "category": table_data["category"],
                "abbreviated_name": table_data["abbreviated_name"],
                "basic_mode": table_data["basic_mode"],
            }

        return {
            "technology": technology,
            "support_levels": (
                [level.value for level in support_levels] if support_levels else []
            ),
            "tables": serializable_schema,
            "table_count": len(serializable_schema),
        }

    # =========================================================================
    # RELATIONSHIP METHODS
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=256)
    def get_columns_with_master_table(
        table_name: str, lower_case: bool = True
    ) -> List[str]:
        """
        Get columns that reference other tables (master table relationships).

        Args:
            table_name: Name of the table
            lower_case: Return column names in lowercase

        Returns:
            List of column names with master table references

        Raises:
            ValueError: If table not found

        Example:
            >>> refs = AnuraSchema.get_columns_with_master_table("Facilities")
            >>> print(refs)
            ['organization', 'map']
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        columns_with_refs = [
            field.column_name
            for field in table_schema.fields
            if field.master_table and len(field.master_table) > 0
        ]

        if lower_case:
            return [col.lower() for col in columns_with_refs]
        return columns_with_refs

    @staticmethod
    def get_master_tables(table_name: str, column_name: str) -> List[str]:
        """
        Get which tables a specific column references.

        Args:
            table_name: Name of the table
            column_name: Name of the column

        Returns:
            List of referenced table names

        Raises:
            ValueError: If table or column not found

        Example:
            >>> masters = AnuraSchema.get_master_tables("Facilities", "Organization")
            >>> print(masters)
            ['Organizations']
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        for field in table_schema.fields:
            if field.column_name.lower() == column_name.lower():
                return field.master_table if field.master_table else []

        raise ValueError(f"Column '{column_name}' not found in table '{table_name}'")

    @staticmethod
    def get_master_column_references(table_name: str, column_name: str) -> List[str]:
        """
        Get specific column references (e.g., "Organizations.OrganizationName").

        Args:
            table_name: Name of the table
            column_name: Name of the column

        Returns:
            List of column references in format "TableName.ColumnName"

        Raises:
            ValueError: If table or column not found

        Example:
            >>> refs = AnuraSchema.get_master_column_references("Facilities", "Organization")
            >>> print(refs)
            ['Organizations.OrganizationName']
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        for field in table_schema.fields:
            if field.column_name.lower() == column_name.lower():
                # master_column attribute contains the specific column references
                if hasattr(field, "master_column") and field.master_column:
                    return field.master_column
                return []

        raise ValueError(f"Column '{column_name}' not found in table '{table_name}'")

    @staticmethod
    @lru_cache(maxsize=4)
    def get_all_master_table_mappings() -> Dict[str, Dict[str, List[str]]]:
        """
        Get comprehensive mapping of all master table relationships.

        Returns:
            Dict mapping table_name -> {column_name: [master_tables]}

        Example:
            >>> mappings = AnuraSchema.get_all_master_table_mappings()
            >>> print(mappings['Facilities']['Organization'])
            ['Organizations']
        """
        schemas = AnuraSchema._get_all_table_schemas()
        result = {}

        for table_name, table_schema in schemas.items():
            table_mappings = {}

            for field in table_schema.fields:
                if field.master_table and len(field.master_table) > 0:
                    table_mappings[field.column_name] = field.master_table

            if table_mappings:
                result[table_name] = table_mappings

        return result

    # =========================================================================
    # GROUPS SUPPORT METHODS
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=4)
    def get_group_enabled_columns() -> Dict[str, List[str]]:
        """
        Get all columns that support groups functionality.

        Returns:
            Dict mapping table_name -> [column_names] for group-enabled columns

        Example:
            >>> group_cols = AnuraSchema.get_group_enabled_columns()
            >>> if 'Facilities' in group_cols:
            ...     print(group_cols['Facilities'])
        """
        schemas = AnuraSchema._get_all_table_schemas()
        result = {}

        for table_name, table_schema in schemas.items():
            group_columns = []

            for field in table_schema.fields:
                # Check if column has expandable=True or other group indicators
                if field.expandable:
                    group_columns.append(field.column_name)

            if group_columns:
                result[table_name] = group_columns

        return result

    # =========================================================================
    # METADATA ACCESS METHODS
    # =========================================================================

    @staticmethod
    def get_column_explanation(table_name: str, column_name: str) -> str:
        """
        Get human-readable explanation/description for a column.

        Args:
            table_name: Name of the table
            column_name: Name of the column

        Returns:
            Explanation text

        Raises:
            ValueError: If table or column not found

        Example:
            >>> explanation = AnuraSchema.get_column_explanation("Facilities", "FacilityName")
            >>> print(explanation)
            'The name of the Facility'
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        for field in table_schema.fields:
            if field.column_name.lower() == column_name.lower():
                return field.explanation or ""

        raise ValueError(f"Column '{column_name}' not found in table '{table_name}'")

    @staticmethod
    @lru_cache(maxsize=256)
    def get_table_metadata(table_name: str) -> Dict[str, Any]:
        """
        Get comprehensive metadata for a table.

        Returns table-level metadata plus a 'columns' list where each entry
        contains all fields defined in the Column base class (via get_column_metadata).

        Args:
            table_name: Name of the table

        Returns:
            Dict with table metadata and full column definitions. Column entries
            include all fields from the Column base class — see get_column_metadata
            for the full list of keys.

        Raises:
            ValueError: If table not found

        Example:
            >>> metadata = AnuraSchema.get_table_metadata("Facilities")
            >>> print(metadata['category'])
            'Model Elements'
            >>> print(metadata['technologies']['neo'])
            TechnologySupport.FULLY_SUPPORTED
            >>> print(metadata['columns'][0]['column_name'])
            'FacilityName'
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        columns = [
            AnuraSchema.get_column_metadata(table_name, field.column_name)
            for field in table_schema.fields
        ]

        return {
            "table_name": table_schema.table_name,
            "table_type": table_schema.table_type.value,
            "category": str(get_table_category(table_name).value),
            "abbreviated_name": table_schema.abbreviated_name,
            "technologies": dict(table_schema.technology),
            "basic_mode": list(table_schema.basic_mode),
            "fixed_tags": table_schema.fixed_tags,
            "in_database": table_schema.in_database,
            "columns": columns,
        }

    @staticmethod
    @lru_cache(maxsize=4096)
    def get_column_metadata(table_name: str, column_name: str) -> Dict[str, Any]:
        """
        Get metadata for a specific column.

        Returns a dict containing all fields defined in the Column base class.

        Args:
            table_name: Name of the table (case-insensitive)
            column_name: Name of the column (case-insensitive)

        Returns:
            Dict with all Column base class fields:
                column_name, data_type, validation_type, required, required_if,
                pk, master_table, expandable, technology, basic_mode,
                allowable_uom_types, u_o_m_conversion, relates_to_keys,
                default_value, notes, explanation, master_column,
                precision_category, disaggregation_logic, in_database.

            data_type is serialised as a string (primitive types) or list of
            valid string values (enum/bool columns).
            technology is serialised as {tech_name: support_name}.
            basic_mode is serialised as a list of technology name strings.

        Raises:
            ValueError: If table or column not found

        Example:
            >>> col = AnuraSchema.get_column_metadata("Facilities", "FacilityName")
            >>> print(col['data_type'])
            'STRING'
            >>> print(col['pk'])
            True

            >>> col = AnuraSchema.get_column_metadata("Facilities", "FacilityStatus")
            >>> print(col['data_type'])
            ['Closed', 'Consider', 'Open']
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        for field in table_schema.fields:
            if field.column_name.lower() != column_name.lower():
                continue

            dt = field.data_type
            if isinstance(dt, DataType):
                data_type_value = dt.value
            elif isinstance(dt, type) and issubclass(dt, Enum):
                data_type_value = [member.value for member in dt]
            else:
                data_type_value = str(dt)

            technology_value = {
                tech.value: support.value for tech, support in field.technology.items()
            }

            basic_mode_value = [tech.value for tech in field.basic_mode]

            return {
                "column_name": field.column_name,
                "data_type": data_type_value,
                "validation_type": field.validation_type,
                "required": field.required,
                "required_if": field.required_if,
                "pk": field.pk,
                "master_table": list(field.master_table),
                "expandable": field.expandable,
                "technology": technology_value,
                "basic_mode": basic_mode_value,
                "allowable_uom_types": list(field.allowable_uom_types),
                "u_o_m_conversion": field.u_o_m_conversion,
                "relates_to_keys": field.relates_to_keys,
                "default_value": field.default_value,
                "notes": field.notes,
                "explanation": field.explanation,
                "master_column": list(field.master_column),
                "precision_category": list(field.precision_category),
                "disaggregation_logic": field.disaggregation_logic,
                "in_database": field.in_database,
            }

        raise ValueError(f"Column '{column_name}' not found in table '{table_name}'")

    @staticmethod
    @lru_cache(maxsize=1)
    def get_schema_summary() -> Dict[str, Any]:
        """
        Get high-level overview of entire schema.

        Returns:
            Dict with schema statistics and organization

        Example:
            >>> summary = AnuraSchema.get_schema_summary()
            >>> print(summary['total_tables'])
            200
            >>> print(summary['technologies'])
            ['neo', 'throg', 'dendro', 'hopper', 'triad', 'dart']
        """
        all_tables = get_registry_table_names()
        input_tables = AnuraSchema.get_input_table_names()
        output_tables = AnuraSchema.get_output_table_names()

        tables_by_category = {}
        for category in CATEGORY_ORDER:
            tables = get_tables_for_category(category)
            tables_by_category[category.value] = tables

        return {
            "total_tables": len(all_tables),
            "input_tables_count": len(input_tables),
            "output_tables_count": len(output_tables),
            "categories": [cat.value for cat in CATEGORY_ORDER],
            "technologies": [t.value for t in Technology],
            "tables_by_category": tables_by_category,
        }

    @staticmethod
    def get_table_schema(table_name: str) -> Table:
        """
        Get raw Pydantic Table object for advanced users.

        Args:
            table_name: Name of the table

        Returns:
            Complete Table object

        Raises:
            ValueError: If table not found

        Example:
            >>> table = AnuraSchema.get_table_schema("Facilities")
            >>> print(table.table_name)
            'Facilities'
            >>> print(type(table))
            <class 'ol_anura.core.table.Table'>
        """
        return AnuraSchema._load_table_schema(table_name)

    # =========================================================================
    # VALIDATION METHODS (Deprecated but Implemented)
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=4)
    def get_anura_validations(lower_case: bool = True) -> Dict[str, List[Dict]]:
        """
        Get validation mappings for all tables.

        .. deprecated::
            Do not use in new development. This method is provided for cosmicfrog
            compatibility only. Use get_columns_with_validation() and
            get_field_definitions() instead.

        Args:
            lower_case: Convert table and column names to lowercase

        Returns:
            Dict mapping table_name -> list of validation dicts

        Example:
            >>> validations = AnuraSchema.get_anura_validations()
            >>> 'facilities' in validations
            True
        """
        schemas = AnuraSchema._get_all_table_schemas()
        result = {}

        for table_name, table_schema in schemas.items():
            table_key = table_name.lower() if lower_case else table_name
            validations = []

            for field in table_schema.fields:
                if field.validation_type:
                    validation_entry = {
                        "column": (
                            field.column_name.lower()
                            if lower_case
                            else field.column_name
                        ),
                        "validation_type": field.validation_type,
                        "field_info": {
                            "Column Name": (
                                field.column_name.lower()
                                if lower_case
                                else field.column_name
                            ),
                            "Data Type": str(field.data_type),
                            "Validation Type": field.validation_type,
                            "Required": "Yes" if field.required else "No",
                            "Explanation": field.explanation or "",
                        },
                    }
                    validations.append(validation_entry)

            if validations:
                result[table_key] = validations

        return result

    @staticmethod
    @lru_cache(maxsize=1)
    def get_validation_types() -> Dict[str, int]:
        """
        Get all unique validation types and their frequency.

        .. deprecated::
            Do not use in new development. This method is provided for cosmicfrog
            compatibility only.

        Returns:
            Dict mapping validation_type -> count

        Example:
            >>> types = AnuraSchema.get_validation_types()
            >>> print(types)
            {'ExistsInMasterTable': 150, 'Numeric': 50, ...}
        """
        validation_counts = {}
        mappings = AnuraSchema.get_anura_validations(lower_case=False)

        for table_validations in mappings.values():
            for validation in table_validations:
                val_type = validation["validation_type"]
                validation_counts[val_type] = validation_counts.get(val_type, 0) + 1

        return dict(
            sorted(
                validation_counts.items(),
                key=lambda x: (-x[1], x[0]),
            )
        )

    @staticmethod
    def get_table_validations(table_name: str, lower_case: bool = True) -> List[Dict]:
        """
        Get validations for a specific table.

        .. deprecated::
            Do not use in new development. This method is provided for cosmicfrog
            compatibility only.

        Args:
            table_name: Name of the table
            lower_case: Convert table and column names to lowercase

        Returns:
            List of validation rules for the table

        Example:
            >>> validations = AnuraSchema.get_table_validations("Facilities")
            >>> print(len(validations))
            5
        """
        table_key = table_name.lower() if lower_case else table_name
        mappings = AnuraSchema.get_anura_validations(lower_case)
        return mappings.get(table_key, [])

    # =========================================================================
    # COSMICFROG COMPATIBILITY WRAPPERS
    # =========================================================================

    @staticmethod
    @lru_cache(maxsize=1)
    def get_anura_masterlist() -> List[Dict]:
        """
        Return master list in cosmicfrog format.

        .. deprecated::
            Do not use in new development. This method provides backward compatibility
            with cosmicfrog's AnuraSchema only.

        Returns:
            List of dicts with table metadata in cosmicfrog format

        Example:
            >>> masterlist = AnuraSchema.get_anura_masterlist()
            >>> print(masterlist[0])
            {
                'Table': 'Customers',
                'Category': 'Model Elements',
                'Technology': '[NEO, THROG, DENDRO, TRIAD, DART, HOPPER]',
                ...
            }
        """
        all_tables = get_registry_table_names()
        result = []

        for table_name in all_tables:
            try:
                table_schema = AnuraSchema._load_table_schema(table_name)
                category = get_table_category(table_name)

                # Build technology list
                technologies = [
                    tech.value
                    for tech, support in table_schema.technology.items()
                    if support != TechnologySupport.UNSUPPORTED
                ]

                # Build basic mode list
                basic_mode = [tech.value for tech in table_schema.basic_mode]

                entry = {
                    "Table": table_name,
                    "Category": category.value,
                    "Technology": f"[{', '.join(technologies)}]",
                    "BasicMode": f"[{', '.join(basic_mode)}]" if basic_mode else "",
                    "AbbreviatedName": table_schema.abbreviated_name or table_name,
                }
                result.append(entry)
            except ValueError:
                # Skip tables that can't be loaded
                continue

        return result

    @staticmethod
    def get_anura_table_names(lower_case: bool = True) -> List[str]:
        """
        Get all table names (cosmicfrog compatibility wrapper).

        .. deprecated::
            Do not use in new development. Use get_all_table_names() instead.

        Args:
            lower_case: Return table names in lowercase

        Returns:
            List of table names

        Example:
            >>> tables = AnuraSchema.get_anura_table_names()
            >>> 'facilities' in tables
            True
        """
        return AnuraSchema.get_all_table_names(lower_case)

    @staticmethod
    def get_anura_input_table_names(lower_case: bool = True) -> List[str]:
        """
        Get input table names (cosmicfrog compatibility wrapper).

        .. deprecated::
            Do not use in new development. Use get_input_table_names() instead.

        Args:
            lower_case: Return table names in lowercase

        Returns:
            List of input table names

        Example:
            >>> tables = AnuraSchema.get_anura_input_table_names()
            >>> 'facilities' in tables
            True
        """
        return AnuraSchema.get_all_table_names(lower_case, input_only=True)

    @staticmethod
    def get_anura_output_table_names(lower_case: bool = True) -> List[str]:
        """
        Get output table names (cosmicfrog compatibility wrapper).

        .. deprecated::
            Do not use in new development. Use get_output_table_names() instead.

        Args:
            lower_case: Return table names in lowercase

        Returns:
            List of output table names

        Example:
            >>> tables = AnuraSchema.get_anura_output_table_names()
            >>> 'optimizationnetworksummary' in tables
            True
        """
        return AnuraSchema.get_all_table_names(lower_case, output_only=True)

    @staticmethod
    def get_anura_abbreviated_table_names(input_only: bool = False) -> Dict[str, str]:
        """
        Get abbreviated table names mapping (cosmicfrog compatibility wrapper).

        .. deprecated::
            Do not use in new development. Use get_abbreviated_table_names() instead.

        Args:
            input_only: Only include input tables

        Returns:
            Dict mapping abbreviated_name -> full_table_name

        Example:
            >>> abbrev = AnuraSchema.get_anura_abbreviated_table_names()
            >>> print(abbrev['facilities'])
            'facilities'
        """
        return AnuraSchema.get_abbreviated_table_names(input_only)

    @staticmethod
    def get_anura_keys(table_name: str) -> List[str]:
        """
        Get primary keys for a table (cosmicfrog compatibility wrapper).

        .. deprecated::
            Do not use in new development. Use get_primary_keys() instead.

        Args:
            table_name: Name of the table

        Returns:
            List of primary key column names (lowercase)

        Example:
            >>> keys = AnuraSchema.get_anura_keys("Facilities")
            >>> print(keys)
            ['facilityname']
        """
        return AnuraSchema.get_primary_keys(table_name, lower_case=True)

    @staticmethod
    def get_anura_columns(table_name: str) -> List[str]:
        """
        Get columns for a table (cosmicfrog compatibility wrapper).

        .. deprecated::
            Do not use in new development. Use get_columns() instead.

        Args:
            table_name: Name of the table

        Returns:
            List of column names (lowercase)

        Example:
            >>> columns = AnuraSchema.get_anura_columns("Facilities")
            >>> print(columns[:3])
            ['facilityname', 'status', 'facilitystatus']
        """
        return AnuraSchema.get_columns(table_name, lower_case=True)

    @staticmethod
    @lru_cache(maxsize=4)
    def get_anura_field_definitions(
        lower_case: bool = True, input_only: bool = False
    ) -> Dict[str, List[Dict]]:
        """
        Get field definitions for all tables (cosmicfrog compatibility wrapper).

        .. deprecated::
            Do not use in new development. Use get_field_definitions() instead.

        Args:
            lower_case: Convert table and column names to lowercase
            input_only: Only include input tables

        Returns:
            Dict mapping table_name -> list of field definition dicts

        Example:
            >>> fields = AnuraSchema.get_anura_field_definitions()
            >>> print(list(fields.keys())[:3])
            ['customers', 'facilities', 'suppliers']
        """
        schemas = AnuraSchema._get_all_table_schemas(input_only=input_only)
        result = {}

        for table_name in schemas.keys():
            try:
                table_key = table_name.lower() if lower_case else table_name
                result[table_key] = AnuraSchema.get_field_definitions(
                    table_name, lower_case
                )
            except ValueError:
                # Skip tables that can't be loaded
                continue

        return result

    @staticmethod
    def get_table_field_definitions(
        table_name: str, lower_case: bool = True
    ) -> List[Dict]:
        """
        Get field definitions for a specific table (cosmicfrog compatibility wrapper).

        .. deprecated::
            Do not use in new development. Use get_field_definitions() instead.

        Args:
            table_name: Name of the table
            lower_case: Convert table and column names to lowercase

        Returns:
            List of field definition dicts

        Example:
            >>> fields = AnuraSchema.get_table_field_definitions("Facilities")
            >>> print(len(fields))
            50
        """
        return AnuraSchema.get_field_definitions(table_name, lower_case)

    # =========================================================================
    # LEGACY SCHEMA DICT COMPATIBILITY (get_schema_dict)
    # =========================================================================

    @staticmethod
    def _format_technology_list(technologies: List[str]) -> str:
        """Format a list of technology names as legacy string: "[NEO, THROG]"."""
        # Preserve order as given, but ensure uniqueness
        seen: set[str] = set()
        ordered = []
        for t in technologies:
            t_up = t.upper()
            if t_up not in seen:
                seen.add(t_up)
                ordered.append(t_up)
        return f"[{', '.join(ordered)}]" if ordered else ""

    @staticmethod
    def _get_supported_technologies_for_column(
        table_name: str,
        column_name: str,
        support_levels: Optional[tuple] = None,
    ) -> List[str]:
        """Return list of technologies (uppercase) that support a given column."""
        if support_levels is None:
            support_levels = (
                TechnologySupport.FULLY_SUPPORTED,
                TechnologySupport.IN_DEVELOPMENT,
            )

        table_schema = AnuraSchema._load_table_schema(table_name)
        # Find the column
        field_obj: Optional[Column] = None
        for f in table_schema.fields:
            if f.column_name.lower() == column_name.lower():
                field_obj = f
                break
        if field_obj is None:
            return []

        supported: List[str] = []
        for tech in Technology:
            attr = tech.value.lower()
            if getattr(field_obj, attr, None) in support_levels:
                supported.append(tech.value)
        return supported

    @staticmethod
    def _apply_units_of_measure_speed_patch(
        schema_dict: Dict[str, List[Dict[str, Any]]]
    ) -> None:
        """Legacy patch: add 'Speed' to UnitsOfMeasure.Type Data Type list."""
        # Legacy schema dict uses table key 'UnitsOfMeasure' (CamelCase)
        table_key = None
        for k in schema_dict.keys():
            if k.lower() == "unitsofmeasure":
                table_key = k
                break
        if not table_key:
            return

        for field in schema_dict.get(table_key, []):
            if str(field.get("Column Name", "")).lower() == "type":
                dt = str(field.get("Data Type", ""))
                # Legacy format is like "['Time', 'Distance']"; we do a simple string patch.
                if "Speed" not in dt:
                    if dt.endswith("]"):
                        # Insert before closing bracket
                        if dt == "[]":
                            field["Data Type"] = "['Speed']"
                        else:
                            field["Data Type"] = dt[:-1] + ", 'Speed']"
                    else:
                        # Fallback: append
                        field["Data Type"] = dt + " + Speed"
                break

    @staticmethod
    @lru_cache(maxsize=256)
    def _get_field_definitions_all(table_name: str) -> List[Dict[str, Any]]:
        """
        Get complete field definitions for a table.

        Returns list of dicts with all column metadata in legacy-Anura format.

        Args:
            table_name: Name of the table
            lower_case: Convert table and column names to lowercase

        Returns:
            List of field definition dicts

        Raises:
            ValueError: If table not found

        Example:
            >>> fields = AnuraSchema.get_field_definitions("Facilities")
            >>> print(fields[0])
            {
                'Column Name': 'facilityname',
                'Data Type': 'STRING',
                'Required': 'Yes',
                'PK': 'Yes',
                'Explanation': 'The name of the Facility',
                ...
            }
        """
        table_schema = AnuraSchema._load_table_schema(table_name)

        def stringify_bool(value):
            return "Yes" if value else ""

        def stringify_list(items: list[str]) -> str:
            """
            Convert a list of strings into a bracketed, comma-separated string.

            Example:
                ['A', 'B', 'C'] -> "[A, B, C]"
            """
            return f"[{', '.join(items)}]"

        def stringify_str(value):
            return str(value) if value else ""

        field_defs = []
        for field in table_schema.fields:
            field_dict = {
                "Column Name": stringify_str(field.column_name),
                "Data Type": stringify_str(field.data_type),
                "Validation Type": stringify_str(field.validation_type),
                "Required": stringify_bool(field.required) or "",
                "RequiredIf": stringify_str(field.required_if),
                "PK": stringify_bool(field.pk),
                "Master Table": (
                    ""
                    if field.master_table == []
                    else stringify_list(field.master_table)
                ),
                "Expandable": stringify_bool(field.expandable),
                # Technology is intentionally left out and added later by get_schema_dict
                "AllowableUOMTypes": stringify_str(field.allowable_uom_types),
                "Relates to keys": stringify_str(field.relates_to_keys),
                "Default value": stringify_str(field.default_value),
                "Notes": stringify_str(field.notes),
                "Explanation": stringify_str(field.explanation),
                "PrecisionCategory": stringify_list(field.precision_category),
                "BasicMode": stringify_list(field.basic_mode),
                "MasterColumn": (
                    ""
                    if field.master_column == []
                    else stringify_list(field.master_column)
                ),
            }

            field_defs.append(field_dict)

        return field_defs

    @classmethod
    def get_schema_dict(
        cls,
        schema_type: str,
        engine: Optional[str] = None,
        secondary_filter: str = "",
    ) -> Dict[str, List[Dict[str, Any]]]:
        """Legacy-compatible schema dict.

        .. deprecated::
            Do not use in new development. This method is provided for legacy
            cosmicfrog compatibility only.

        Args:
            schema_type: 'input', 'output', or 'neo_anura'. 'default' is not implemented.
            engine: Optional engine/technology name (e.g., 'NEO'). Case-insensitive.
            secondary_filter: Legacy parameter; not supported (must be empty).

        Returns:
            Dict mapping TableName (CamelCase) -> list of field dicts.
        """
        schema_type_norm = (schema_type or "").lower()
        if schema_type_norm == "default":
            raise NotImplementedError("schema_type='default' is not implemented")

        # Normalize engine/technology
        engine_norm: Optional[str] = None
        if engine is not None:
            engine_norm = cls._validate_technology(engine)

        # Determine which tables to include
        if schema_type_norm in ("input", "output", "neo_anura"):
            if schema_type_norm in ("input", "neo_anura"):
                tables = cls.get_input_table_names(lower_case=False, in_database=None)
            else:
                tables = cls.get_output_table_names(lower_case=False, in_database=None)

            # neo_anura uses explicit support-level filtering; input/output preserve existing defaults
            support_levels: Optional[tuple] = None
            if schema_type_norm == "neo_anura":
                support_levels = (
                    TechnologySupport.FULLY_SUPPORTED,
                    TechnologySupport.IN_DEVELOPMENT,
                )

            result: Dict[str, List[Dict[str, Any]]] = {}
            for table in tables:
                # Base field definitions (CamelCase table, CamelCase columns)
                fields = cls._get_field_definitions_all(table)

                filtered_fields: List[Dict[str, Any]] = []
                for f in fields:
                    col_name = str(f.get("Column Name", ""))

                    supported_techs = cls._get_supported_technologies_for_column(
                        table,
                        col_name,
                        support_levels=support_levels,
                    )

                    # neo_anura: only include columns supported at FULLY_SUPPORTED/IN_DEVELOPMENT
                    if schema_type_norm == "neo_anura" and not supported_techs:
                        continue

                    # Optional engine filter (applies to all schema types)
                    if engine_norm is not None:
                        if engine_norm.upper() not in {
                            t.upper() for t in supported_techs
                        }:
                            continue

                    f = dict(f)  # copy
                    f["Technology"] = cls._format_technology_list(supported_techs)
                    filtered_fields.append(f)

                if filtered_fields:
                    result[table] = filtered_fields

            cls._apply_units_of_measure_speed_patch(result)

            if secondary_filter:
                _filter = secondary_filter.lower()
                result = {
                    k: v for k, v in result.items() if k.lower().startswith(_filter)
                }

            return result

        raise ValueError(
            "schema_type must be one of: 'input', 'output', 'neo_anura', or 'default'"
        )

    # =========================================================================
    # ENGINES COMPATIBILITY WRAPPERS
    # =========================================================================

    @staticmethod
    def get_schema_column_mapping_lower_to_upper() -> dict[str, str]:
        """Return a mapping of lowercased column names to CamelCased equivalents.

        Compatibility method. Returns a mapping of all lowercased column names
        to the CamelCased equivalent specified in the Anura Schema.
        """
        return {
            col.lower(): col
            for table in AnuraSchema.get_all_table_names(
                lower_case=False, in_database=None
            )
            for col in AnuraSchema.get_columns(table, lower_case=False)
        }

    @staticmethod
    def get_schema_column_mapping_lower_to_upper_by_table(
        *args, **kwargs
    ) -> dict[str, dict[str, str]]:
        """Return a mapping of lowercased column names to CamelCased equivalents by table.

        Compatibility method. Returns a mapping of all lowercased column names
        to the CamelCased equivalent specified in the Anura Schema by table.

        Legacy systems may call this function with arbitrary arguments,
        but all input parameters are ignored.
        """
        return {
            table: {
                col.lower(): col
                for col in AnuraSchema.get_columns(table, lower_case=False)
            }
            for table in AnuraSchema.get_all_table_names(
                lower_case=False, in_database=None
            )
        }

    @staticmethod
    def get_tech_table_col(input_only: bool = True) -> List[Tuple[str, str, str]]:
        """Get list of (technology, table, column) tuples.

        Includes only entries where:
        - Technology is FULLY_SUPPORTED for that column
        - Both table and column have in_database=True
        - Technology names are uppercase (e.g., "NEO", "THROG")
        - Table and column names preserve original case
        """
        result: List[Tuple[str, str, str]] = []
        schemas = AnuraSchema._get_all_table_schemas(
            input_only=input_only, in_database=None
        )

        for table_schema in schemas.values():
            if not table_schema.in_database:
                continue

            for field in table_schema.fields:
                if not field.in_database:
                    continue

                for tech in Technology:
                    attr = tech.value.lower()

                    if (
                        getattr(table_schema, attr, None)
                        == TechnologySupport.FULLY_SUPPORTED
                        and getattr(field, attr, None)
                        == TechnologySupport.FULLY_SUPPORTED
                    ):
                        result.append(
                            (tech.value, table_schema.table_name, field.column_name)
                        )

        return result
