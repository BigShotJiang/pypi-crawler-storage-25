"""Anura table schema definitions."""
