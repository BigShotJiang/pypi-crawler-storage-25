"""ProductionWheelGroupDetails table schema definition."""

from ...core import Column, DataType, Status, Table, TableType

# ProductionWheelGroupDetails table schema
production_wheel_group_details = Table(
    table_name="ProductionWheelGroupDetails",
    table_type=TableType.INPUT,
    abbreviated_name="ProductionWheelGroupDetails",
    in_database=True,
    fields=[
        Column(
            column_name="ProductionWheelName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the production wheel for which to specify intra-product-group detail.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="ProductGroupName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Groups"],
            explanation="The name of the product group for which to specify intra-product-group production requirements.",
            precision_category=["NaN"],
            master_column=["Groups.GroupName"],
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            explanation="The products comprising the product group.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True,
        ),
        Column(
            column_name="ProductOrder",
            data_type=DataType.INTEGER,
            explanation="The sequence of products within a product group which occupies a spoke on a production wheel. If no sequence is provided, a product sequence within the group's wheel spoke will not be enforced; production will occur according to the sequence in which production orders were generated.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="SupplementaryProductionTarget",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="For group-based production wheel structures that may result in supplementary production (Duration/Fill or Produce Min wheel types), this field dictates how supplementary production is allocated across products within each product group that occupies a spoke on the wheel. If no targets are provided, supplementary production will be uniformly allocated across products within groups. Targets provided for a product group will be scaled to sum to 1.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether a record is passed into the engine. If Status is set to Exclude, this record will be ignored during the model run.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True,
        ),
    ],
)
