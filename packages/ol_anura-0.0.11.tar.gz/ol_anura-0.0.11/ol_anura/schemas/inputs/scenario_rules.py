"""ScenarioRules table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# ScenarioRules table schema
scenario_rules = Table(
    table_name="ScenarioRules",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
        Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="ScenarioRules",
    in_database=True,
    fields=[
        Column(
            column_name="RuleName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Scenario Rule; Scenario Rules are assigned to Scenarios via the Scenario Item Assignments table.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Description",
            data_type=DataType.STRING,
            explanation="The description of this scenario rule",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Tags",
            data_type=DataType.STRING,
            explanation="The tag of this scenario rule",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Technology",
            data_type=Technology,
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="CreatedDate",
            data_type=DataType.DATETIME,
            explanation="The creation date of this scenario rule",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="LastEditedDate",
            data_type=DataType.DATETIME,
            explanation="The last edit date of this scenario rule",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
