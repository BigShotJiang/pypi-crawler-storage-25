"""Analytics table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# Analytics table schema
analytics = Table(
    table_name="Analytics",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="Analytics",
    in_database=True,
    fields=[
        Column(
            column_name="DashboardName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of this analytics dashboard",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Description",
            data_type=DataType.STRING,
            explanation="The description of this analytics dashboard",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Data",
            data_type=DataType.STRING,
            required=True,
            explanation="The data for this analytics dashboard",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Tags",
            data_type=DataType.STRING,
            explanation="The tags for this analytics dashboard",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="CreatedDate",
            data_type=DataType.DATETIME,
            explanation="The creation date of this analytics dashboard",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="LastEditedDate",
            data_type=DataType.DATETIME,
            explanation="The last edit date of this analytics dashboard",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
