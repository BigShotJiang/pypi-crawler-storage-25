"""RiskBandDefinitions table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# RiskBandDefinitions table schema
risk_band_definitions = Table(
    table_name="RiskBandDefinitions",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="RiskBandDefinitions",
    in_database=True,
    fields=[
        Column(
            column_name="BandName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Risk Band. Risk Bands are referenced by name in all of the Risk Configuration tables. Bands are defined based on a series of levels and associated Risk Scores and when the DART engine is run the corresponding scores will be assigned to all places where the Risk Band is called in the configuration tables.",
            precision_category=["NaN"],
            technology={
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="BandLowerValue",
            data_type=DataType.DOUBLE,
            required=True,
            pk=True,
            explanation="The lower bound of the step that the Risk Score will be applied over.",
            precision_category=["Risk"],
            technology={
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RiskScore",
            data_type=DataType.DOUBLE,
            validation_type="RiskScore",
            required=True,
            pk=True,
            explanation="The Risk Score that will be selected based on the corresponding band's lower value.",
            precision_category=["Risk"],
            technology={
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
