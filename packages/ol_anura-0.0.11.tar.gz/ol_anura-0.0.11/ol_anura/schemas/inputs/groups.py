"""Groups table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class GroupType(str, Enum):
    """GroupType values."""

    BILLSOFMATERIALS = "BillsOfMaterials"
    CUSTOMERS = "Customers"
    DESTINATIONS = "Destinations"
    FACILITIES = "Facilities"
    MODES = "Modes"
    PERIODS = "Periods"
    PROCESSES = "Processes"
    PRODUCTS = "Products"
    SHIPMENTS = "Shipments"
    SOURCES = "Sources"
    SUPPLIERS = "Suppliers"
    TRANSPORTATIONASSETS = "TransportationAssets"
    WORKCENTERS = "WorkCenters"
    WORKRESOURCES = "WorkResources"


# Groups table schema
groups = Table(
    table_name="Groups",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
        Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
        Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="Groups",
    basic_mode=[Technology.NEO, Technology.THROG, Technology.DENDRO, Technology.CYCLO],
    in_database=True,
    fields=[
        Column(
            column_name="GroupName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Group; this value can be referenced in other tables to apply records to members of the Group. Depending on which table the Group is referenced in, treatment of the Group members will either be implied or taken as input in that table. Group behavior types are Aggregate and Enumerate. Items in an Enumerated Group are evaluated individually while items in an Aggregated Group will be evaluated collectively.",
            precision_category=["NaN"],
            basic_mode=[
                Technology.THROG,
                Technology.DENDRO,
                Technology.NEO,
                Technology.CYCLO,
            ],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="GroupType",
            data_type=GroupType,
            required=True,
            pk=True,
            notes="Optimization: Currently supports GroupType = [Products, Customers, Facilities, Suppliers, Sources, Destinations, Periods, Modes, WorkCenters]\n\nSimulation: Currently supports GroupType = [Products, Customers, Facilities, Suppliers, Sources, Destinations]",
            explanation="The type of elements the Group consists of. If Group Type = Source, the Group can contain both Facilities and Suppliers. If Group Type = Destination, the Group can contain both Facilities and Customers. Otherwise, Group Type denotes the table that members may come from.\n\nNEO does not currently support GroupType = WorkResources\n\nTHROG does not currently support GroupType = Periods",
            precision_category=["NaN"],
            basic_mode=[
                Technology.THROG,
                Technology.DENDRO,
                Technology.NEO,
                Technology.CYCLO,
            ],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MemberName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=[
                "Products",
                "Customers",
                "Facilities",
                "Suppliers",
                "Periods",
                "TransportationModes",
                "WorkCenters",
                "WorkResources",
                "Processes",
                "BillsOfMaterials",
                "Shipments",
                "TransportationAssets",
            ],
            notes="Optimization: Currently supports GroupType = [Products, Customers, Facilities, Suppliers, Sources, Destinations, Periods, Modes, WorkCenters]\n\nSimulation: Currently supports GroupType = [Products, Customers, Facilities, Suppliers, Sources, Destinations]",
            explanation="The entity that is being assigned to the Group. The Member Name must have an associated record in the relevant master table.",
            precision_category=["NaN"],
            basic_mode=[
                Technology.THROG,
                Technology.DENDRO,
                Technology.NEO,
                Technology.CYCLO,
            ],
            master_column=[
                "Products.ProductName",
                "Customers.CustomerName",
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Periods.PeriodName",
                "TransportationModes.ModeName",
                "WorkCenters.WorkCenterName",
                "WorkResources.WorkResourceName",
                "Processes.ProcessName",
                "BillsOfMaterials.BOMName",
                "Shipments.ShipmentID",
                "TransportationAssets.AssetName",
            ],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether the specified Member is included in or excluded from the Group during the model run. If Status = Exclude, the specified Member is ignored wherever the Group is referenced.",
            precision_category=["NaN"],
            basic_mode=[
                Technology.THROG,
                Technology.DENDRO,
                Technology.NEO,
                Technology.CYCLO,
            ],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=[
                Technology.THROG,
                Technology.DENDRO,
                Technology.NEO,
                Technology.CYCLO,
            ],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
