"""TemplateTerritories table schema definition."""

from enum import Enum

from ...core import Column, DataType, Status, Table, TableType


class InsertionAllowed(str, Enum):
    """InsertionAllowed values."""

    FALSE = "FALSE"
    TRUE = "TRUE"


# TemplateTerritories table schema
template_territories = Table(
    table_name="TemplateTerritories",
    table_type=TableType.INPUT,
    abbreviated_name="TemplateTerritories",
    in_database=True,
    fields=[
        Column(
            column_name="TemplateTerritoryName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the given template territory.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="TerritoryType",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TerritoryPlanningSettings"],
            explanation="The type for this territory.",
            precision_category=["NaN"],
            master_column=["TerritoryPlanningSettings.TerritoryType"],
            in_database=True,
        ),
        Column(
            column_name="InsertionAllowed",
            data_type=InsertionAllowed,
            default_value="FALSE",
            explanation="Whether a template territory can accept additional shipments.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Line Item exists in the model. If Status is set to Exclude, this record will be ignored during the model run.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True,
        ),
    ],
)
