"""UserDefinedForecastsData table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# UserDefinedForecastsData table schema
user_defined_forecasts_data = Table(
    table_name="UserDefinedForecastsData",
    table_type=TableType.INPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="UserDefinedForecastsData",
    fixed_tags=["Facilities", "Facility", "Forecast"],
    in_database=True,
    fields=[
        Column(
            column_name="ForecastName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["UserDefinedForecasts"],
            explanation="User Defined Forecasts will be used for DOS calculations in the Inventory Policies table for any Facility / Product records that have the DOS Forecast Type set to User-Defined.",
            precision_category=["NaN"],
            master_column=["UserDefinedForecasts.ForecastName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Date",
            data_type=DataType.DATETIME,
            required=True,
            pk=True,
            explanation="The date for the user-defined forecast data",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ForecastedQuantity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The forecasted quantity for the user-defined forecast data",
            precision_category=["Quantity"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ForecastedQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="ForecastedQuantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure for the forecasted quantity",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
