"""ProductionWheelDetails table schema definition."""

from enum import Enum

from ...core import Column, DataType, Status, Table, TableType


class DurationPolicy(str, Enum):
    """DurationPolicy values."""

    ADVANCE = "Advance"
    FILL = "Fill"
    IDLE = "Idle"


class MinProductionPolicy(str, Enum):
    """MinProductionPolicy values."""

    ADVANCE = "Advance"
    PRODUCE_MIN = "Produce Min"


# ProductionWheelDetails table schema
production_wheel_details = Table(
    table_name="ProductionWheelDetails",
    table_type=TableType.INPUT,
    abbreviated_name="ProductionWheelDetails",
    in_database=True,
    fields=[
        Column(
            column_name="ProductionWheelName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the production wheel",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product for which the entry in the production wheel is being defined",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the row of the Production Wheel is passed into the engine. If Status is set to Exclude, this record will be ignored during the model run.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="WheelOrder",
            data_type=DataType.DOUBLE,
            required=True,
            pk=True,
            explanation="The position in the wheel for the given product",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Duration",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The duration of the production wheel element. If the duration is hit while in the middle of processing an order, that order will complete. If the duration is not met and all orders are finished processing, the logic used in the Duration Policy will determine the production activity.",
            precision_category=["Time"],
            in_database=True,
        ),
        Column(
            column_name="DurationUoM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measurement for the duration.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True,
        ),
        Column(
            column_name="DurationPolicy",
            data_type=DurationPolicy,
            explanation="The policy to be used when the existing orders will not fill the entire duration.",
            precision_category=["Time"],
            in_database=True,
        ),
        Column(
            column_name="MinProductionQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="Minimum value to be produced for the defined production wheel slot",
            precision_category=["Time"],
            in_database=True,
        ),
        Column(
            column_name="MaxProductionQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="Maximum value to be produced for the defined production wheel slot",
            precision_category=["Time"],
            in_database=True,
        ),
        Column(
            column_name="ProductionQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            master_table=["UnitsOfMeasure"],
            explanation="The UOM that defines the Min / Max Production Quantities. Quantity, Volume and Weight UOM entries are supported.",
            precision_category=["Time"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True,
        ),
        Column(
            column_name="MinProductionPolicy",
            data_type=MinProductionPolicy,
            explanation="The policy to be used when the existing collection of orders for the product does not meet the Min Production Quantity.",
            precision_category=["NaN"],
            in_database=True,
        ),
    ],
)
