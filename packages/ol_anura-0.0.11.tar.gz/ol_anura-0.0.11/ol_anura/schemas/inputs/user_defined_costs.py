"""UserDefinedCosts table schema definition."""

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)

# UserDefinedCosts table schema
user_defined_costs = Table(
    table_name="UserDefinedCosts",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="UserDefinedCosts",
    in_database=True,
    fields=[
        Column(
            column_name="CostName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name assigned to the Cost. This Cost Name will be automatically indexed to match the indexed (as a result of Enumeration) instances of the relevant Variable Name.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the User-Defined Variable for whose value we wish to incur a cost.",
            precision_category=["NaN"],
            master_column=[
                "UserDefinedVariables.VariableName",
                "TransportationUserDefinedVariables.VariableName",
            ],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts"],
            default_value="0",
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item",
            explanation="The cost associated with each unit of the specified Variable. This cost will be multiplied by the value of the Variable; thus, the unit basis for this cost depends on the units that describe the Variable.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Cost exists. If Status is set to Exclude, this Cost will be ignored in the model solve.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
