"""UtilityCurves table schema definition."""

from enum import Enum

from ...core import Column, DataType, Status, Table, TableType


class UtilityCurveBehavior(str, Enum):
    """UtilityCurveBehavior values."""

    STEPWISE = "Stepwise"
    INCREMENTAL = "Incremental"
    ALL_ITEM = "All Item"


# UtilityCurves table schema
utility_curves = Table(
    table_name="UtilityCurves",
    table_type=TableType.INPUT,
    abbreviated_name="UtilityCurves",
    in_database=True,
    fields=[
        Column(
            column_name="UtilityCurveName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation=(
                "The name given to the Utility Curve. This name may be called in other input "
                "tables where Utility Curve lookups can be used."
            ),
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="UtilityCurveBehavior",
            data_type=UtilityCurveBehavior,
            required=True,
            default_value="All Item",
            explanation=(
                "The behavior of the Utility Curve. Most fields support All Item, Incremental and "
                "Stepwise as well as the combination of Stepwise and All Item. The only exceptions "
                "are: Fixed Startup, Fixed Operating, and Fixed Closing Costs fields will only "
                "support a Utility Curve Behavior of Stepwise; the corresponding Cost value will be "
                "returned as a one-time cost. Incremental behavior will apply Costs to throughput "
                "levels individually. All Item behavior will apply the relevant Cost to the total "
                "throughput."
            ),
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="ThroughputLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            pk=True,
            explanation=(
                "The minimum throughput level at which the relevant Cost is to be applied. All "
                "Utility Curve definitions should start with a throughput level of zero; otherwise, "
                "the lowest throughput interval will be enforced as a minimum requirement."
            ),
            precision_category=["Quantity"],
            in_database=True,
        ),
        Column(
            column_name="ThroughputLevelUOM",
            data_type=DataType.STRING,
            validation_type=(
                "ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time, Distance]"
            ),
            required_if="ThroughputLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time", "Distance"],
            default_value="EA",
            explanation=(
                "The unit of measure that defines Throughput Level. Quantity, Volume, Weight, Time "
                "and Distance units of measure are supported."
            ),
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True,
        ),
        Column(
            column_name="Value",
            data_type=DataType.DOUBLE,
            required=True,
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation=(
                "Status dictates whether or not the table record exists. If Status is set to "
                "Exclude, this record will not be considered when constructing Utility Curves."
            ),
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True,
        ),
    ],
)
