"""TransportationAssetConstraints table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    GroupBehavior,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class ConstraintType(str, Enum):
    """ConstraintType values."""

    FIXED = "Fixed"
    MAX = "Max"
    MIN = "Min"


class SiteType(str, Enum):
    """SiteType values."""

    ANY = "Any"
    DELIVERY = "Delivery"
    PICKUP = "Pickup"


# TransportationAssetConstraints table schema
transportation_asset_constraints = Table(
    table_name="TransportationAssetConstraints",
    table_type=TableType.INPUT,
    technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="TransportationAssetConstraints",
    in_database=True,
    fields=[
        Column(
            column_name="AssetName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["TransportationAssets"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Transportation Asset. Groups are supported.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="AssetNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If AssetName is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the activity in the variable will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SiteName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Facilities", "Customers"],
            expandable=True,
            default_value="ALL",
            explanation="The site(s) (Facilities or Customers). Groups are supported.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SiteType",
            data_type=SiteType,
            pk=True,
            default_value="Any",
            explanation="The activity that is being tracked at the location specified in the SiteName field. This can be one of Pickup, Delivery, or Any.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SiteNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If SiteName is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the activity in the variable will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ShipmentID",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Shipments"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Shipment(s). Groups are supported.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ShipmentIDGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If ShipmentID is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the activity in the variable will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Products"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Product(s). Groups are supported.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ProductNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Product Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the activity in the variable will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ConstraintType",
            data_type=ConstraintType,
            required=True,
            pk=True,
            u_o_m_conversion="",
            explanation="The type of constraint imposed on the flow for the specified Source/Destination/Product/Mode/Period combination. \n\nMin: the flow must be greater than or equal to the Constraint Value.\nMax: the flow must be less than or equal to the Constraint Value.\nFixed: the flow must be equal to the Constraint Value.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ConstraintValue",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            pk=True,
            u_o_m_conversion="",
            explanation="The numeric value that the specified flow will be evaluated against.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            pk=True,
            u_o_m_conversion="",
            default_value="Include",
            explanation="Status dictates whether or not the constraint exists in the model. If Status is set to Exclude, this constraint (or constraints in the case of Enumerated Groups) will be ignored during the model run.",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            u_o_m_conversion="",
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
