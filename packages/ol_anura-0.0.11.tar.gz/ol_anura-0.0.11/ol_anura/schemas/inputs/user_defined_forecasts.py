"""UserDefinedForecasts table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class AggregationStrategy(str, Enum):
    """AggregationStrategy values."""

    DAY = "Day"
    MONTH = "Month"
    WEEK = "Week"
    YEAR = "Year"


class DisaggregationLevel(str, Enum):
    """DisaggregationLevel values."""

    VALUE_5_DAY_WEEK = "5 Day Week"
    VALUE_7_DAY_WEEK = "7 Day Week"


# UserDefinedForecasts table schema
user_defined_forecasts = Table(
    table_name="UserDefinedForecasts",
    table_type=TableType.INPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="UserDefinedForecasts",
    fixed_tags=["Facilities", "Facility", "Forecast"],
    in_database=True,
    fields=[
        Column(
            column_name="ForecastName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="User Defined Forecasts will be used for DOS calculations in the Inventory Policies table for any Facility / Product records that have the DOS Forecast Type set to User-Defined.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Forecast will exist in the model run. If Status is set to Exclude, the Forecast is ignored during the model run.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="AggregationStrategy",
            data_type=AggregationStrategy,
            required=True,
            default_value="Day",
            notes="Simulation: Supports values of Day",
            explanation="Aggregation Strategy will define the level that the Forecast data has been entered in. Forecasts of Daily, Weekly, Monthly or Yearly aggregations will be supported.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DisaggregationLevel",
            data_type=DisaggregationLevel,
            required=True,
            default_value="5 Day Week",
            explanation="Disaggregation Level will determine how the Forecast data will be spread back out into individual order points. Each of the forecasted buckets will be uniformly distributed across the number of days specified in the Disaggregation Level.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
