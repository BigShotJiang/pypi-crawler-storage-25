"""TransportationUserDefinedActivities table schema definition."""

from enum import Enum

from ...core import Column, DataType, Status, Table, TableType


class TriggerBasis(str, Enum):
    """TriggerBasis values."""

    DRIVE = "Drive"
    DUTY = "Duty"


# TransportationUserDefinedActivities table schema
transportation_user_defined_activities = Table(
    table_name="TransportationUserDefinedActivities",
    table_type=TableType.INPUT,
    abbreviated_name="TransportationUserDefActivities",
    fixed_tags=["Transport"],
    in_database=True,
    fields=[
        Column(
            column_name="ActivityName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name assigned to the Activity.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the activity exists.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Duration",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            required=True,
            default_value="0",
            explanation="The amount of time taken by this activity.",
            precision_category=["Time"],
            in_database=True,
        ),
        Column(
            column_name="DurationUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="Duration",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            u_o_m_conversion="Intra",
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines the activity duration.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True,
        ),
        Column(
            column_name="TriggerValue",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            required=True,
            explanation="The time at which the User Defined Activity is triggered. Time will be counted based on the Trigger Basis of Duty or Drive time.",
            precision_category=["Time"],
            in_database=True,
        ),
        Column(
            column_name="TriggerValueUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="TriggerValue",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            u_o_m_conversion="Intra",
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines the Trigger Value.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True,
        ),
        Column(
            column_name="TriggerBasis",
            data_type=TriggerBasis,
            required=True,
            default_value="Duty",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="ResetType",
            data_type=DataType.STRING,
            validation_type="[Restart, Stop, UserDefined]",
            default_value="Restart",
            explanation="The type of reset logic for this activity. A value of Restart will cause the activity to restart its clock when the activity is triggered, a value of Stop will stop the activity clock when the activity is triggered, and a value of User Defined will follow the logic set for the given ResetName as is defined in the TransportationUserDefinedResets table.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="ResetName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationUserDefinedResets"],
            default_value="None",
            explanation="If the ResetType selection is set to UserDefined, this will be the name of the Reset as is defined in the User Defined Resets table.",
            precision_category=["NaN"],
            master_column=["TransportationUserDefinedResets.ResetName"],
            in_database=True,
        ),
        Column(
            column_name="DetourName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationUserDefinedDetours"],
            default_value="None",
            explanation="The relevant Transportation Asset. Groups are supported.",
            precision_category=["NaN"],
            master_column=["TransportationUserDefinedDetours.DetourName"],
            in_database=True,
        ),
        Column(
            column_name="AssetName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationAssets"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Transportation Asset. Groups are supported.",
            precision_category=["NaN"],
            master_column=["TransportationAssets.AssetName"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True,
        ),
    ],
)
