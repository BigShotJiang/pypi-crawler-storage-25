"""OrderProfileProductAffinity table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# OrderProfileProductAffinity table schema
order_profile_product_affinity = Table(
    table_name="OrderProfileProductAffinity",
    table_type=TableType.INPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OrderProfileProductAffinity",
    in_database=True,
    fields=[
        Column(
            column_name="OrderID",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Order ID as specified in any of the Order Profile tables for which the secondary product selection likelihoods will apply. If left empty, the product affinity details will apply over all order profiles.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="PrimaryProduct",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Products"],
            explanation="The Primary Product drawn for multi line order profiles, the selection percentages of the primary product are specified in the Order Profile Product Selection table.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SecondaryProduct",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Products"],
            explanation="Given the selected Primary Product, Secondary Products pairings will specify which additional products would be potentially ordered along on the additional line items. If no secondary products are specified, only the primary product will be ordered.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SecondaryProductSelectionPercentage",
            data_type=DataType.DOUBLE,
            validation_type="Percentage",
            explanation="The likelihood that the secondary product is selected as an additional line item to be ordered with the primary product. If selected, the quantity listed for this product in the Order Profile Product Selection table will be used to determine the line item quantity.",
            precision_category=["Percentage"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
