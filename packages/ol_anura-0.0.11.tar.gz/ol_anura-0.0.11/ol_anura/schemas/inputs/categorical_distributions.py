"""CategoricalDistributions table schema definition."""

from enum import Enum

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport


class DistributionType(str, Enum):
    """DistributionType values."""

    PRODUCTS = "Products"


# CategoricalDistributions table schema
categorical_distributions = Table(
    table_name="CategoricalDistributions",
    table_type=TableType.INPUT,
    abbreviated_name="CategoricalDistributions",
    in_database=True,
    fields=[
        Column(
            column_name="DistributionName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the categorical distribution. If this Distribution Name is used as an input in another table, the populated weights will be used to sample from the distribution and draw a value.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DistributionType",
            data_type=DistributionType,
            required=True,
            pk=True,
            notes="Currently supports DistributionType = [Products]",
            explanation="The type of elements the Distribution consists of.",
            precision_category=["Quantity"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MemberName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            notes="Currently supports DistributionType = [Products]",
            explanation="The entity that is being assigned to the Distribution. The Member Name must have an associated record in the relevant master table.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Products.ProductName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Weight",
            data_type=DataType.DOUBLE,
            explanation="The weight of each outcome.",
            precision_category=["Quantity"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
