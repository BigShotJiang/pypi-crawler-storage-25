"""TransportationUserDefinedVariables table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    GroupBehavior,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class Scope(str, Enum):
    """Scope values."""

    ROUTE = "Route"
    SHIPMENT = "Shipment"
    STOP = "Stop"


class SequencePositionType(str, Enum):
    """SequencePositionType values."""

    ANY = "Any"
    DELIVERY = "Delivery"
    PICKUP = "Pickup"


class SiteType(str, Enum):
    """SiteType values."""

    ANY = "Any"
    DELIVERY = "Delivery"
    PICKUP = "Pickup"


class TermAggregationMethod(str, Enum):
    """TermAggregationMethod values."""

    AVG = "Avg"
    MAX = "Max"
    MIN = "Min"
    SUM = "Sum"


class Type(str, Enum):
    """Type values."""

    CONSTANT = "Constant"
    DISTANCE = "Distance"
    INTEGERVARIABLE = "IntegerVariable"
    PRODUCTCOUNT = "ProductCount"
    QUANTITY = "Quantity"
    ROUTECOUNT = "RouteCount"
    SHIPMENTCOUNT = "ShipmentCount"
    STOPCOUNT = "StopCount"
    TIME = "Time"
    VARIABLE = "Variable"
    VOLUME = "Volume"
    WEIGHT = "Weight"


class VariableAggregationMethod(str, Enum):
    """VariableAggregationMethod values."""

    AVG = "Avg"
    MAX = "Max"
    MIN = "Min"
    SUM = "Sum"


# TransportationUserDefinedVariables table schema
transportation_user_defined_variables = Table(
    table_name="TransportationUserDefinedVariables",
    table_type=TableType.INPUT,
    technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="TransportationUDV",
    in_database=True,
    fields=[
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name assigned to the Variable. Users may define variables in this table to capture behaviors which are not directly supported by other constraint tables. User-Defined Variables are  functions of Terms made of native model variables. User-Defined Variables allow a user to create a detailed expression which is then constrained in the User-Defined Constraints table and/or incurs a cost defined in the User-Defined Costs table.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="TermName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The unique name assigned to the Variable Term being defined. The Terms associated with a Variable Name will be summed to give the final Variable value.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="VariableAggregationMethod",
            data_type=VariableAggregationMethod,
            required=True,
            default_value="Sum",
            explanation="The aggregation method used to collect all the Terms of a Variable. For example, VariableAggregationMethod=Sum will sum the values of all the Variable's Terms to produce the value of the Variable.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Term exists. If Status is set to Exclude, this Term will not be included in the Variable.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Coefficient",
            data_type=DataType.DOUBLE,
            required=True,
            default_value="1",
            explanation="The coefficient by which to scale the Term. The default value is one.",
            precision_category=["Constraint"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Type",
            data_type=Type,
            required=True,
            explanation="The Type of behavior the user wishes to capture via the Term. Terms will be related to each other via their coefficients. If the TermName is referencing a variable which has already been defined (TermName = VariableName) select a type of Variable.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Scope",
            data_type=Scope,
            explanation="The scope that the variable will be iterated over. For example, a Variable with Type=ShipmentCount and Scope=Route will count the number of shipments in a route.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="TermAggregationMethod",
            data_type=TermAggregationMethod,
            required=True,
            default_value="Sum",
            explanation="The aggregation method used to collect all the quantities of a Term. For example, TermAggregationMethod=Sum will sum the values of all of the term's quantities to produce the Term value.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="AssetName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationAssets"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Transportation Asset. Groups are supported.",
            precision_category=["NaN"],
            master_column=["TransportationAssets.AssetName"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="AssetNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If AssetName is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the activity in the variable will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SiteName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Facilities", "Customers"],
            expandable=True,
            default_value="ALL",
            explanation="The site(s) (Facilities or Customers). Groups are supported.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Customers.CustomerName"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SiteType",
            data_type=SiteType,
            default_value="Any",
            explanation="The activity that is being tracked at the location specified in the SiteName field. This can be one of Pickup, Delivery, or Any.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SiteNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If SiteName is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the activity in the variable will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ShipmentID",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Shipments"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Shipment(s). Groups are supported.",
            precision_category=["NaN"],
            master_column=["Shipments.ShipmentID"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ShipmentIDGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If ShipmentID is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the activity in the variable will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["Products"],
            expandable=True,
            default_value="ALL",
            explanation="The relevant Product(s). Groups are supported.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ProductNameGroupBehavior",
            data_type=GroupBehavior,
            default_value="Aggregate",
            explanation="If Product Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this Variable will be created for each member of the Group. If Aggregate is selected, the activity in the variable will be summed over the members of the Group. If you are using multiple terms for a variable, a group behavior entry of enumerate is only supported for one term. Having multiple terms with enumerations is not currently supported.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="MinSequencePosition",
            data_type=DataType.INTEGER,
            explanation="The minimum position in the stop sequence, starting from 1.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="MaxSequencePosition",
            data_type=DataType.INTEGER,
            explanation="The maximum position in the stop sequence. Use negative numbers to count from the end. -1 means last stop in the route",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SequencePositionType",
            data_type=SequencePositionType,
            default_value="Any",
            explanation="If pickup is selected, the min/max positions will only be counted among the pickup stops. Same for Delivery. By default (any) the entire stop sequence is considered.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
