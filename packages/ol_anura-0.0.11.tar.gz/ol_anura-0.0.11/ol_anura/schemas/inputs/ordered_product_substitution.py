"""OrderedProductSubstitution table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# OrderedProductSubstitution table schema
ordered_product_substitution = Table(
    table_name="OrderedProductSubstitution",
    table_type=TableType.INPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OrderedProductSubstitution",
    in_database=True,
    fields=[
        Column(
            column_name="SourceLocation",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Facilities", "Suppliers"],
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName", "Suppliers.SupplierName"],
            in_database=True,
        ),
        Column(
            column_name="OrderCreationLocation",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Customers", "Facilities"],
            explanation="The order creation location for this ordered product substitution",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName", "Facilities.FacilityName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="OrderedProduct",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Products"],
            explanation="The name of the ordered product",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="AllowProductMix",
            data_type=DataType.BOOLEAN,
            master_table=["Products"],
            default_value="True",
            explanation="If Allow Product Mix is set to be True, orders can be made up of a mixture between the ordered and substitute products. If Allow Product Mix is set to False, in the even that a substitute product is used it must fulfill the entire requirement for the ordered product.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SubstituteProduct",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            pk=True,
            master_table=["Products"],
            explanation="The name of the substitute product",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SubstituteProductPriority",
            data_type=DataType.INTEGER,
            explanation="The priority for this substitute product",
            precision_category=["Integer"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
