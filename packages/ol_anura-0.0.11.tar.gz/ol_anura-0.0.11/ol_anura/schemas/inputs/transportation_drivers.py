"""TransportationDrivers table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# TransportationDrivers table schema
transportation_drivers = Table(
    table_name="TransportationDrivers",
    table_type=TableType.INPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="TransportationDrivers",
    fixed_tags=["Transport"],
    in_database=True,
    fields=[
        Column(
            column_name="DriverClass",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Driver Class.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="AvailableUnits",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            explanation="The units of this Driver class that are available at the specified Origin Location. If left blank, this is assumed to be an infinite amount of available drivers.",
            precision_category=["Integer"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DomicileLocation",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            master_table=["Facilities"],
            default_value="ALL",
            explanation="The Facility at which the driver is based.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="AllowedAssets",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationAssets"],
            default_value="ALL",
            explanation="The Assets that this driver class is allowed to operate. This can be a single Asset or a group of Assets, if a group is entered then all Assets in the group can be operated by the driver class.",
            precision_category=["NaN"],
            master_column=["TransportationAssets.AssetName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
