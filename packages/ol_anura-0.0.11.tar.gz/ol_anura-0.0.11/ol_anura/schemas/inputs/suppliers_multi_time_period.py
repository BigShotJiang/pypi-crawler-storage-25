"""SuppliersMultiTimePeriod table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class SupplierStatus(str, Enum):
    """SupplierStatus values."""

    EXCLUDE = "Exclude"
    INCLUDE = "Include"


# SuppliersMultiTimePeriod table schema
suppliers_multi_time_period = Table(
    table_name="SuppliersMultiTimePeriod",
    table_type=TableType.INPUT,
    technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="SuppliersMTP",
    fixed_tags=["Suppliers", "Supplier", "Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SupplierName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Suppliers"],
            expandable=True,
            explanation="The name of the Supplier",
            precision_category=["NaN"],
            master_column=["Suppliers.SupplierName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SupplierStatus",
            data_type=SupplierStatus,
            explanation="Supplier Status dictates whether the Supplier exists in the model for the specified period(s). If Status is set to Exclude, any records for the Supplier in other tables will be ignored.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SupplierCapacity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The maximum amount, across all products, that can be procured from the Supplier during the model solve.",
            precision_category=["Quantity"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SupplierCapacityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="SupplierCapacity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Max Supply Amount. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="QueuePriority",
            data_type=DataType.INTEGER,
            explanation="For any Queues that are evaluated with a Queueing Priority Logic, there can be a By Location component to the priority logic used. If By Location is used, The Queue Priority fields in the Customers, Facilities and Suppliers table will be used to determine how the queues will be ordered",
            precision_category=["Integer"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
