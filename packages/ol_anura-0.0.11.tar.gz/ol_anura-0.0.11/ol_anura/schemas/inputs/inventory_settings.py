"""InventorySettings table schema definition."""

from ...core import (
    Column,
    DataType,
    ServiceType,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)

# InventorySettings table schema
inventory_settings = Table(
    table_name="InventorySettings",
    table_type=TableType.INPUT,
    technology={Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="InventorySettings",
    basic_mode=[Technology.CYCLO],
    in_database=True,
    fields=[
        Column(
            column_name="TargetServiceLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The target Service Level to be met during the CYCLO run.",
            precision_category=["Percentage"],
            basic_mode=[Technology.CYCLO],
            technology={Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ServiceType",
            data_type=ServiceType,
            explanation="The type of service level to be met during the CYCLO run.",
            precision_category=["NaN"],
            basic_mode=[Technology.CYCLO],
            technology={Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
