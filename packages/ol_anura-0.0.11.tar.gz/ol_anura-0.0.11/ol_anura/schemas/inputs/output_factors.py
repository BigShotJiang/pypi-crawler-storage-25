"""OutputFactors table schema definition."""

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)

# OutputFactors table schema
output_factors = Table(
    table_name="OutputFactors",
    table_type=TableType.INPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OutputFactors",
    in_database=True,
    fields=[
        Column(
            column_name="OutputFactorName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Output Factor; Output Factors allow a user to build a utility curve for a selection of simulation metrics which will be used in a genetic algorithm (GA). The GA will iteratively run the simulation and modify certain input parameters (defined in the Input Factors table) to improve the model outcomes according to the Utility Level field of the Output Factors table.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TableName",
            data_type=DataType.STRING,
            validation_type="Valid Table Name",
            required=True,
            explanation="The name of the output table that contains the target Output Factor.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ColumnName",
            data_type=DataType.STRING,
            validation_type="Valid Column Name",
            required=True,
            explanation="The column of the specified table that contains the simulation metric that the genetic algorithm will seek to improve.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Filter",
            data_type=DataType.STRING,
            validation_type="Valid Filter",
            explanation="The filter to apply to the specified column and table (optional).",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UtilityCurve",
            data_type=DataType.STRING,
            required=True,
            explanation="A series of pairings that will build the utility curve for the specified Output Factor. These pairs should be entered as [ Level 1 | Utility Point 1 ][ Level 2 | Utility Point 2 ]â€¦ A piecewise linear utility function of the specified Output Factor will be constructed using the given levels and points; this function will be used to evaluate performance of the genetic algorithm as it makes changes to Input Factors.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="OutputFactorWeight",
            data_type=DataType.DOUBLE,
            default_value="1",
            explanation="The weight that is applied to the Utility Curve when calculating the listed Output Factor's impact on the overall utility function. Weight is used in the case of multiple output factors being specified so that the weight of each factor can be expressed relative to the other factors being considered.",
            precision_category=["Percentage"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            default_value="Include",
            explanation="Status dictates whether or not the Output Factor is considered when running the genetic algorithm.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
