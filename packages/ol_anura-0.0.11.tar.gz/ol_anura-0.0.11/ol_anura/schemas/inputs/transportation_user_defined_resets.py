"""TransportationUserDefinedResets table schema definition."""

from enum import Enum

from ...core import Column, DataType, Status, Table, TableType


class ResetType(str, Enum):
    """ResetType values."""

    RESTART = "Restart"
    STOP = "Stop"


# TransportationUserDefinedResets table schema
transportation_user_defined_resets = Table(
    table_name="TransportationUserDefinedResets",
    table_type=TableType.INPUT,
    abbreviated_name="TransportationUserDefResets",
    fixed_tags=["Transport"],
    in_database=True,
    fields=[
        Column(
            column_name="ResetName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name assigned to the Reset.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="ActivityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["TransportationUserDefinedActivities"],
            explanation="The name of the User Defined Activity that triggers this reset. The reset will be triggered if it is entered in the Reset Name field of the corresponding activity.",
            precision_category=["NaN"],
            master_column=["TransportationUserDefinedActivities.ActivityName"],
            in_database=True,
        ),
        Column(
            column_name="ResetType",
            data_type=ResetType,
            required=True,
            default_value="Restart",
            explanation="The Reset Type determines if the clock will be restarted or stopped.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the reset is included in the solve.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True,
        ),
    ],
)
