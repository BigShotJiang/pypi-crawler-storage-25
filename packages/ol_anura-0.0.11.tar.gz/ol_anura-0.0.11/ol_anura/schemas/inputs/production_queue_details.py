"""ProductionQueueDetails table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    SecondaryQueueingPriorityLogic,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class QueueingPriorityLogic(str, Enum):
    """QueueingPriorityLogic values."""

    BYDAYQUEUEDANDLOCATION = "ByDayQueuedAndLocation"
    BYDUEDATEANDLOCATION = "ByDueDateAndLocation"
    FIFO = "FIFO"
    PRODUCTIONWHEEL = "ProductionWheel"


# ProductionQueueDetails table schema
production_queue_details = Table(
    table_name="ProductionQueueDetails",
    table_type=TableType.INPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="ProductionQueueDetails",
    in_database=True,
    fields=[
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            explanation="The facility that the queue logic is applied for",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ReviewPeriodFirstTime",
            data_type=DataType.DATETIME,
            explanation="The first Date/Time at which to review the queue for the specified production queue. Production queues will be evaluated using the logic specified in the Priority Logic field. After this Date/Time, the review period length will dictate when production queue reviews occur. If NULL, Review Period First Time will be the start of the simulation.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ReviewPeriod",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable",
            master_table=["ReviewSchedules"],
            explanation="The time between production queue reviews. After Review Period First Time, a production queue review will occur each time Review Period has elapsed. For example, if Review Period First Time is 1/1/2022 12:00:00 AM and Review Period is six hours, we will conduct reviews on 1/1/2022 at 12:00:00 AM, 6:00:00 AM, 12:00:00 PM, and 6:00:00 PM, continuing similarly until the simulation ends. A Review Schedule defined in the Review Schedules table can be entered by Review Schedule Name in this field as well. If NULL, continuous review is used.",
            precision_category=["Time"],
            master_column=["ReviewSchedules.ReviewScheduleName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ReviewPeriodUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Review Period length.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="QueueingPriorityLogic",
            data_type=QueueingPriorityLogic,
            default_value="FIFO",
            explanation="The logic used for the production queue when deciding how to arrange orders in the production queue. If a value of By Date And Location is selected, the QueuePriority fields in the Customers, Facilities, and Suppliers will be leveraged. If the Advanced Queueing Details table is populated, the override priorities for the Origin, Destination, Product combination will be used",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="QueueingPriorityLogicValue",
            data_type=DataType.STRING,
            master_table=["ProductionWheelDetails"],
            explanation="The value associated with the given queueing priority logic.  For ProductionWheel this will contain the name of the wheel",
            precision_category=["NaN"],
            master_column=["ProductionWheelDetails.ProductionWheelName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SecondaryQueueingPriorityLogic",
            data_type=SecondaryQueueingPriorityLogic,
            default_value="MinimizeChangeover",
            explanation="The logic used to break ties within the production queue",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the policy exists in the model. If Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TimeInQueueCost",
            data_type=DataType.DOUBLE,
            explanation="The cost associated with an item sitting in a queue. The cost expressed in this field will be charged each time that items sit in a queue for the length of time specified in the Time In Queue Cost UOM field.",
            precision_category=["Cost"],
            in_database=True,
        ),
        Column(
            column_name="TimeInQueueCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="TimeInQueueCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure that time is expressed in terms of.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
