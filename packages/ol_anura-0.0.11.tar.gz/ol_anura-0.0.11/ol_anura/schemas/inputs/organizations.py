"""Organizations table schema definition."""

from ...core import Column, DataType, Table, TableType

# Organizations table schema
organizations = Table(
    table_name="Organizations",
    table_type=TableType.INPUT,
    abbreviated_name="Organizations",
    in_database=True,
    fields=[
        Column(
            column_name="OrganizationName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Organization. If no Organization is specified, all facilities are assumed to belong to one Organization. Facilities are assigned to Organizations in the Facilities table.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="InScope",
            data_type=DataType.BOOLEAN,
            required=True,
            default_value="True",
            notes="Defines whether or not we want the outputs related to the members of this organization to be included in the objective function",
            explanation="If True, costs associated with the Organization are included in the model's objective function (MIP) and cost calculations (SIM). Otherwise, costs associated with the Organization will not be included in the objective function or cost calculations.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            in_database=True,
        ),
    ],
)
