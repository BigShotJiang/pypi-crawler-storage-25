"""WorkCenterCountConstraints table schema definition."""

from enum import Enum

from ...core import (
    Column,
    ConstraintType,
    DataType,
    GroupBehavior,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class CountingRule(str, Enum):
    """CountingRule values."""

    FACILITIES = "Facilities"
    PERIODS = "Periods"
    WORKCENTERS = "WorkCenters"


class PeriodGroupNameBehavior(str, Enum):
    """PeriodGroupNameBehavior values."""

    AGGREGATE = "Aggregate"
    ENUMERATE = "Enumerate"


# WorkCenterCountConstraints table schema
work_center_count_constraints = Table(
    table_name="WorkCenterCountConstraints",
    table_type=TableType.INPUT,
    technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="WorkCenterCountConstraints",
    in_database=True,
    fields=[
        Column(
            column_name="WorkCenterName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["WorkCenters"],
            expandable=True,
            default_value="ALL",
            explanation="The Work Center(s) for which we are counting openings. Groups are supported.",
            precision_category=["NaN"],
            master_column=["WorkCenters.WorkCenterName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="WorkCenterNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Work Center Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            default_value="ALL",
            explanation="The Facility or Facilities at which we are counting openings. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Facilities.FacilityName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="FacilityNameGroupBehavior",
            data_type=GroupBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Facility Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            default_value="ALL",
            explanation="The Period(s) in which we are counting open Work Centers. Groups are supported.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="PeriodGroupNameBehavior",
            data_type=PeriodGroupNameBehavior,
            pk=True,
            default_value="Aggregate",
            explanation="If Period Name is a Group, use this field to specify the Group's behavior. If Enumerate is selected, an instance of this constraint will be created for each member of the Group. If Aggregate is selected, the flow in the constraint will be summed over the members of the Group.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ConstraintType",
            data_type=ConstraintType,
            required=True,
            pk=True,
            explanation="The type of constraint imposed on the count for the specified Work Center/Period combination. \n\nMin: the count must be greater than or equal to the Constraint Value.\nMax: the count must be less than or equal to the Constraint Value.\nFixed: the count must be equal to the Constraint Value.\nFixed With Tolerance: The count must be equal to the Constraint Value * (1 +/- Relative Constraint Tolerance). Relative Constraint Tolerance is specified in the Model Run Options.\nConditional Min: if the count is nonzero, it must be greater than or equal to the Constraint Value.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ConstraintValue",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            required=True,
            pk=True,
            explanation="The numeric value that the specified count will be evaluated against.",
            precision_category=["Integer"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the constraint exists in the model. If Status is set to Exclude, this constraint (or constraints in the case of Enumerated Groups) will be ignored during the model run.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="CountingRule",
            data_type=CountingRule,
            pk=True,
            explanation="WorkCenters: Count the number of unique Work Centers open during the specified Period(s).\nFacilities: Count the number of unique Facilities at which the specified Work Center can be opened.\nPeriods: Count the number of unique Periods in which the specified Work Center(s) are open.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
