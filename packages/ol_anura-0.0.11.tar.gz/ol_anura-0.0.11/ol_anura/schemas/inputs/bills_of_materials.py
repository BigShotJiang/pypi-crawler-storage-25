"""BillsOfMaterials table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class ProductType(str, Enum):
    """ProductType values."""

    BYPRODUCT = "Byproduct"
    COMPONENT = "Component"
    END_PRODUCT = "End Product"


# BillsOfMaterials table schema
bills_of_materials = Table(
    table_name="BillsOfMaterials",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="BillsOfMaterials",
    fixed_tags=["Facilities", "Facility", "Policies", "Production"],
    in_database=True,
    fields=[
        Column(
            column_name="BOMName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Bill of Material (BOM). This value can be referenced in other tables involving BOMs.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            explanation="The name of a Product associated with the BOM.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ProductType",
            data_type=ProductType,
            required=True,
            default_value="Component",
            notes="Optimization: Currently supports ProductType = Component, Byproduct",
            explanation="The role the specified Product plays in the BOM. A Component will be consumed during production. A Byproduct is created as a secondary result of production. An End Product is the finished good associated with the BOM. The Product associated with the BOM via a production policy is the implied End Product. If the implied End Product and an End Product specified in the BOM record differ, the End Product specified in the BOM record will become a Byproduct. Component requirements and Product Quantities in the BOM record will remain unchanged.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required=True,
            default_value="1",
            explanation="The amount of the Product consumed or produced. If NULL, the default value will be one unit.",
            precision_category=["Quantity"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="QuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="Quantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            notes="Simulation: Currently supports a default UOM of EA",
            explanation="The unit of measure that defines Quantity. Quantity, Volume, and Weight units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the BOM record exists. If Status is set to Exclude, this BOM record will be ignored during evaluation of the BOM.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
