"""SequentialObjectives table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class ObjectiveType(str, Enum):
    """ObjectiveType values."""

    CONCENTRATIONRISK = "ConcentrationRisk"
    FACILITYTHROUGHPUTCAPACITYDEVIATION = "FacilityThroughputCapacityDeviation"
    FLOWCONSTRAINTSDEVIATION = "FlowConstraintsDeviation"
    GEOGRAPHICRISK = "GeographicRisk"
    INVENTORYCONSTRAINTSDEVIATION = "InventoryConstraintsDeviation"
    PRODUCTIONCONSTRAINTSDEVIATION = "ProductionConstraintsDeviation"
    SCENARIOARCSDEVIATION = "ScenarioArcsDeviation"
    SCENARIOARCSDEVIATION_CUSTOMERFULFILLMENT = (
        "ScenarioArcsDeviation-CustomerFulfillment"
    )
    SCENARIOARCSDEVIATION_PROCUREMENT = "ScenarioArcsDeviation-Procurement"
    SOURCECOUNTRISK = "SourceCountRisk"
    TOTALCO2COST = "TotalCO2Cost"
    TOTALCO2EMISSIONS = "TotalCO2Emissions"
    TOTALDUTYCOST = "TotalDutyCost"
    TOTALFACILITYTHROUGHPUTQUANTITY = "TotalFacilityThroughputQuantity"
    TOTALFACILITYTHROUGHPUTVOLUME = "TotalFacilityThroughputVolume"
    TOTALFACILITYTHROUGHPUTWEIGHT = "TotalFacilityThroughputWeight"
    TOTALFIXEDCLOSINGCOST = "TotalFixedClosingCost"
    TOTALFIXEDOPERATINGCOST = "TotalFixedOperatingCost"
    TOTALFIXEDSTARTUPCOST = "TotalFixedStartupCost"
    TOTALFUELSURCHARGECOST = "TotalFuelSurchargeCost"
    TOTALINTRANSITHOLDINGCOST = "TotalInTransitHoldingCost"
    TOTALINBOUNDHANDLINGCOST = "TotalInboundHandlingCost"
    TOTALINFEASIBILITYDEVIATION = "TotalInfeasibilityDeviation"
    TOTALMULTISTOPROUTECOST = "TotalMultiStopRouteCost"
    TOTALOUTBOUNDHANDLINGCOST = "TotalOutboundHandlingCost"
    TOTALPREBUILDHOLDINGCOST = "TotalPrebuildHoldingCost"
    TOTALPROCESSCOST = "TotalProcessCost"
    TOTALPRODUCTIONCOST = "TotalProductionCost"
    TOTALPROFIT = "TotalProfit"
    TOTALRETURNCOST = "TotalReturnCost"
    TOTALREVENUE = "TotalRevenue"
    TOTALSHIPMENTCOST = "TotalShipmentCost"
    TOTALSOURCINGCOST = "TotalSourcingCost"
    TOTALSTORAGECOST = "TotalStorageCost"
    TOTALSUPPLYCHAINCOST = "TotalSupplyChainCost"
    TOTALTARIFFCOST = "TotalTariffCost"
    TOTALTRANSPORTATIONCOST = "TotalTransportationCost"
    TOTALTURNESTIMATEDHOLDINGCOST = "TotalTurnEstimatedHoldingCost"
    TOTALUNSERVEDDEMANDPENALTYCOST = "TotalUnservedDemandPenaltyCost"
    TOTALUSERDEFINEDCOST = "TotalUserDefinedCost"
    TOTALWEIGHTEDFLOWDISTANCE = "TotalWeightedFlowDistance"
    TOTALWEIGHTEDFLOWTIME = "TotalWeightedFlowTime"
    TOTALWORKCENTERTHROUGHPUTQUANTITY = "TotalWorkCenterThroughputQuantity"
    TOTALWORKCENTERTHROUGHPUTTIME = "TotalWorkCenterThroughputTime"
    TOTALWORKCENTERTHROUGHPUTVOLUME = "TotalWorkCenterThroughputVolume"
    TOTALWORKCENTERTHROUGHPUTWEIGHT = "TotalWorkCenterThroughputWeight"
    TRANSPORTTIMERISK = "TransportTimeRisk"
    USERDEFINEDCONSTRAINT = "UserDefinedConstraint"
    USERDEFINEDCOST = "UserDefinedCost"
    USERDEFINEDVARIABLE = "UserDefinedVariable"
    WORKCENTERTHROUGHPUTCAPACITYDEVIATION = "WorkCenterThroughputCapacityDeviation"


# SequentialObjectives table schema
sequential_objectives = Table(
    table_name="SequentialObjectives",
    table_type=TableType.INPUT,
    technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="SequentialObjectives",
    in_database=True,
    fields=[
        Column(
            column_name="ObjectiveType",
            data_type=ObjectiveType,
            required=True,
            pk=True,
            explanation="The objective that optimization will solve for. Objectives will correspond to the cost and revenue columns from the Optimization Network Summary table, but specific User Defined Variables and User Defined Costs will also be supported. If the Objective Type = UserDefinedVariable or UserDefinedCost, the specific variable or cost can be specified in the UserDefinedObjectiveName column. Sequential Solves will solve for the objectives marked as Priority = 1 first and use this solution as a base for any subsequent solves for lower Priority values. The solution from Priority 1 can then be relaxed within the specified tolerance for each listed Priority 1 objective to find a solution targeting the Priority 2 objectives. This process will be repeated until the lowest priority objective has been solved for.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="UserDefinedObjectiveName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required_if="ObjectiveType = UserDefinedCost OR UserDefinedVariable OR UserDefinedConstraint OR ScenarioArcsDeviation OR ScenarioArcsDeviation-CustomerFulfillment OR ScenarioArcsDeviation-Procurement",
            pk=True,
            master_table=[
                "UserDefinedCosts",
                "UserDefinedVariables",
                "UserDefinedConstraints",
                "Scenarios",
            ],
            default_value="ALL",
            explanation="If the Objective Type is set as User Defined Variable, User Defined Cost or User Defined Constraint, the specific User Defined Cost, Variable or Constraint can be referenced here. If nothing is specified, All Costs/Variables/Constraints will be considered. If the Objective Type is set as any of the Scenario Arc deviation options, enter the Scenario Name from which flow deviations are being measured.",
            precision_category=["NaN"],
            master_column=[
                "UserDefinedCosts.CostName",
                "UserDefinedVariables.VariableName",
                "UserDefinedConstraints.ConstraintName",
                "Scenarios.ScenarioName",
            ],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Priority",
            data_type=DataType.INTEGER,
            validation_type="NonNegative",
            required=True,
            default_value="1",
            explanation="The numeric value indicating the Objective priority.",
            precision_category=["Integer"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Tolerance",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            default_value="0.1",
            explanation="The Tolerance value of each objective will specify how much that Objective can be relaxed to solve for the Objective(s) in the next Priority. A value of 10 would mean that the solution could be relaxed by 10 percent.",
            precision_category=["Percentage"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status will dictate whether or not the Objective will be considered for the Sequential Solve.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
