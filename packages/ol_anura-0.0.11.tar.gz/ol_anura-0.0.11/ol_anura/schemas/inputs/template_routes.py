"""TemplateRoutes table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class AdditionalShipmentInsertionType(str, Enum):
    """AdditionalShipmentInsertionType values."""

    INSERT_AFTER = "Insert After"
    INSERT_ANYWHERE = "Insert Anywhere"
    INSERT_BEFORE = "Insert Before"
    NO_INSERTION = "No Insertion"


# TemplateRoutes table schema
template_routes = Table(
    table_name="TemplateRoutes",
    table_type=TableType.INPUT,
    technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="TemplateRoutes",
    basic_mode=[Technology.HOPPER],
    in_database=True,
    fields=[
        Column(
            column_name="TemplateRouteName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the given template route. This Template Route Name will appear in the Transportation Route Summary output table.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="AssetName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            master_table=["TransportationAssets"],
            explanation="The Transportation Asset that is used for the specified template route.",
            precision_category=["NaN"],
            master_column=["TransportationAssets.AssetName"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="RouteStartDate",
            data_type=DataType.DATETIME,
            explanation="The date and time at which the template route must start.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="TourID",
            data_type=DataType.STRING,
            explanation="The tour (asset schedule) that the template route must be part of.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="RouteSequenceInTour",
            data_type=DataType.INTEGER,
            explanation="The position of the route in the tour (asset schedule) that it is assigned to.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="AdditionalShipmentInsertionType",
            data_type=AdditionalShipmentInsertionType,
            default_value="No Insertion",
            explanation="If a Template Route can accept additional shipments, the rule for where those shipments can be placed in the drop sequence is specified as one of the following: Insert Anywhere, Insert Before, or Insert After. The default value will be No Insertion, meaning no additional shipments can be added to the Template Route.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Line Item exists in the model. If Status is set to Exclude, this record will be ignored during the model run.",
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
