"""ModelRunOptions table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class UIDisplayCategory(str, Enum):
    """UIDisplayCategory values."""

    ADVANCED = "Advanced"
    BASIC = "Basic"
    NONE = "None"


class UIDisplaySubCategory(str, Enum):
    """UIDisplaySubCategory values."""

    CONFIGURATIONS = "Configurations"
    COST_TO_SERVE = "Cost To Serve"
    INFEASIBILITY = "Infeasibility"
    NETWORK = "Network"
    OUTPUT_REPORTING = "Output Reporting"
    TERMINATION = "Termination"
    TROUBLESHOOTING = "Troubleshooting"


# ModelRunOptions table schema
model_run_options = Table(
    table_name="ModelRunOptions",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
        Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="ModelRunOptions",
    in_database=True,
    fields=[
        Column(
            column_name="Option",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            notes="Validation rules, allowable values to be specified in hash table",
            explanation="Models run using either Optimization or Simulation will have additional run options that can be adjusted. The name of those options will be listed in this field, with the option setting, description, and impacted technology in fields to follow",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Exclude",
            explanation="The Status of the Model Run Options, all will be set to Exclude by default which will allow for the solver-specified defaults to be used. If users wish to use their own settings for runs, they can adjust the status to be Include and set the appropriate Value",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Value",
            data_type=DataType.STRING,
            required=True,
            notes="Validation rules, allowable values to be specified in hash table",
            explanation="This field will specify the value that the solver option is taking",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Technology",
            data_type=DataType.STRING,
            required=True,
            notes="Validation rules, allowable values to be specified in hash table",
            explanation="This field will note which technology the solver option will apply for. This can be quickly filtered against to only show options that are relevant to the technology which you are currently running",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Description",
            data_type=DataType.STRING,
            notes="Validation rules, allowable values to be specified in hash table",
            explanation="This field will offer a description as to the functionality of the run option.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DataType",
            data_type=DataType.STRING,
            explanation="For use in Cosmic Frog, this passes over the Data Type to show which options to render in the UI",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UIDisplayName",
            data_type=DataType.STRING,
            explanation="For use in Cosmic Frog, this passes over the parameter's display name to be shown in the run options splash screen.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UIDisplayCategory",
            data_type=UIDisplayCategory,
            explanation="For use in Cosmic Frog, this is a toggle to show which section of the splash screen, if any, the option should be displayed in.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UIDisplaySubCategory",
            data_type=UIDisplaySubCategory,
            explanation="For use in Cosmic Frog, this is a toggle to show which sub-section of the splash screen, if any, the option should be displayed in.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UIDisplayOrder",
            data_type=DataType.INTEGER,
            explanation="For use in Cosmic Frog, this will control the ordering in which options are displayed.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
