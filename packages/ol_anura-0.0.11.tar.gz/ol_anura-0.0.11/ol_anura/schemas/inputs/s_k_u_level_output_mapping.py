"""SKULevelOutputMapping table schema definition."""

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)

# SKULevelOutputMapping table schema
s_k_u_level_output_mapping = Table(
    table_name="SKULevelOutputMapping",
    table_type=TableType.INPUT,
    technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="SKULevelOutputMapping",
    in_database=True,
    fields=[
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SKUName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the SKU for this Product",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Product exists in the model. If Status is set to Exclude, any records for the Product in other tables will be ignored.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Quantity",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            default_value="0",
            explanation="The quantity of this sku in one unit of this product.",
            precision_category=["Quantity"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
