"""StepCosts table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class StepCostBehavior(str, Enum):
    """StepCostBehavior values."""

    ALL_ITEM = "All Item"
    INCREMENTAL = "Incremental"
    STEPWISE = "Stepwise"


# StepCosts table schema
step_costs = Table(
    table_name="StepCosts",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="StepCosts",
    in_database=True,
    fields=[
        Column(
            column_name="StepCostName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name given to the Step Cost. This name may be called in other input tables where Step Cost lookups can be used.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="StepCostBehavior",
            data_type=StepCostBehavior,
            required=True,
            default_value="All Item",
            explanation="The behavior of the Step Cost. Most fields support All Item, Incremental and Stepwise as well as the combination of Stepwise and All Item. The only exceptions are: Fixed Startup, Fixed Operating, and Fixed Closing Costs fields will only support a Step Cost Behavior of Stepwise; the corresponding Cost value will be returned as a one-time cost. Incremental behavior will apply Costs to throughput levels individually. All Item behavior will apply the relevant Cost to the total throughput.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ThroughputLevel",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            pk=True,
            explanation="The minimum throughput level at which the relevant Cost is to be applied. All step cost definitions should start with a throughput level of zero; otherwise, the lowest throughput interval will be enforced as a minimum requirement.",
            precision_category=["Quantity"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ThroughputLevelUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time, Distance]",
            required_if="ThroughputLevel",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight", "Time", "Distance"],
            default_value="EA",
            explanation="The unit of measure that defines Throughput Level. Quantity, Volume, Weight, Time and Distance units of measure are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Cost",
            data_type=DataType.COST_TIME_EXPRESSION,
            required=True,
            notes="Optimization: Currently supports doubles",
            explanation="The cost value to incur for the specified Throughput Level.",
            precision_category=["Cost"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the table record exists. If Status is set to Exclude, this record will not be considered when constructing Step Costs.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
