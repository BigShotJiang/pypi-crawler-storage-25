"""RelationshipConstraints table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class Entity1Type(str, Enum):
    """Entity1Type values."""

    CUSTOMER = "Customer"
    PRODUCT = "Product"
    SHIPMENT = "Shipment"
    TERRITORYTYPE = "TerritoryType"
    TRANSPORTATIONASSET = "TransportationAsset"


class Entity2Type(str, Enum):
    """Entity2Type values."""

    CUSTOMER = "Customer"
    PRODUCT = "Product"
    SHIPMENT = "Shipment"
    TERRITORYTYPE = "TerritoryType"
    TRANSPORTATIONASSET = "TransportationAsset"


# RelationshipConstraints table schema
relationship_constraints = Table(
    table_name="RelationshipConstraints",
    table_type=TableType.INPUT,
    technology={
        Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="RelationshipConstraints",
    basic_mode=[Technology.HOPPER],
    in_database=True,
    fields=[
        Column(
            column_name="Entity1",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=[
                "TransportationAssets",
                "Products",
                "Shipments",
                "Customers",
                "TerritoryPlanningSettings",
            ],
            expandable=True,
            explanation="The first entity that exists in the relationship. Entity 1 and Entity 2 will be prevented from moving together during the Hopper solve. Groups are supported.",
            precision_category=["NaN"],
            master_column=[
                "TransportationAssets.AssetName",
                "Products.ProductName",
                "Shipments.ShipmentID",
                "Customers.CustomerName",
                "TerritoryPlanningSettings.TerritoryType",
            ],
            technology={
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Entity1Type",
            data_type=Entity1Type,
            required=True,
            pk=True,
            explanation="The type of object that Entity 1 is, one of Transportation Asset, Product, Shipment, Customer or TerritoryType.",
            precision_category=["NaN"],
            technology={
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Entity2",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=[
                "TransportationAssets",
                "Products",
                "Shipments",
                "Customers",
                "TerritoryPlanningSettings",
            ],
            expandable=True,
            explanation="The second entity that exists in the relationship. Entity 1 and Entity 2 will prevented from moving together during the Hopper solve. Groups are supported.",
            precision_category=["NaN"],
            master_column=[
                "TransportationAssets.AssetName",
                "Products.ProductName",
                "Shipments.ShipmentID",
                "Customers.CustomerName",
                "TerritoryPlanningSettings.TerritoryType",
            ],
            technology={
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Entity2Type",
            data_type=Entity2Type,
            required=True,
            pk=True,
            explanation="The type of object that Entity 2 is, one of Transportation Asset, Product, Shipment, Customer or TerritoryType.",
            precision_category=["NaN"],
            technology={
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Line Item exists in the model. If Status is set to Exclude, this record will be ignored during the model run.",
            precision_category=["NaN"],
            technology={
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
