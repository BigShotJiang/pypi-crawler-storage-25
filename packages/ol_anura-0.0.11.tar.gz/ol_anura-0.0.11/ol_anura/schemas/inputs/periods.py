"""Periods table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# Periods table schema
periods = Table(
    table_name="Periods",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="Periods",
    basic_mode=[Technology.NEO, Technology.CYCLO],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Period. Periods allow for the model to be broken down into smaller sections of time, each with its own modeling inputs. Optimization will require periods to divide the model into smaller time buckets other than the model horizon whereas Simulation will have a rolling clock. Simulation can still interpret changes that are made through Multi Time Period records, however this will not be required for Simulation models.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.CYCLO],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="StartDate",
            data_type=DataType.DATETIME,
            required=True,
            explanation="Periods are each defined based on their Start Date value. A Period extends from its Start Date to the soonest Start Date of the other defined Periods. NOTE that for optimization models that will contain cross-period flows (the transportation/production time exceeds that of the period length) then the periods are required to be of equal length.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.CYCLO],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.CYCLO],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
