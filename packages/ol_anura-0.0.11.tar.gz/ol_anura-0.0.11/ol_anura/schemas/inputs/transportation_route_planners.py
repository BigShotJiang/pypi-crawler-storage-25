"""TransportationRoutePlanners table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class RoutePlanningMethod(str, Enum):
    """RoutePlanningMethod values."""

    FIXED = "Fixed"
    HOPPER = "Hopper"


# TransportationRoutePlanners table schema
transportation_route_planners = Table(
    table_name="TransportationRoutePlanners",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="TransportationRoutePlanners",
    fixed_tags=["Transport"],
    in_database=True,
    fields=[
        Column(
            column_name="RoutePlannerName",
            data_type=DataType.STRING,
            explanation="Name of the Route Planner",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RoutePlanningMethod",
            data_type=RoutePlanningMethod,
            required=True,
            default_value="Hopper",
            explanation="The route planning method for this transportation route planner",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ReviewPeriodFirstTime",
            data_type=DataType.DATETIME,
            explanation="The first Date/Time at which the Route Planner reviews available shipments.  After this Date/Time, the review period length will dictate when the Route Planner reviews. If NULL, Review Period First Time will be the start of the simulation.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ReviewPeriod",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable",
            master_table=["ReviewSchedules"],
            explanation="The time between Route Planner reviews. After Review Period First Time, a Route Planner review will occur each time Review Period has elapsed. For example, if Review Period First Time is 1/1/2022 12:00:00 AM and Review Period is six hours, we will conduct reviews on 1/1/2022 at 12:00:00 AM, 6:00:00 AM, 12:00:00 PM, and 6:00:00 PM, continuing similarly until the simulation ends. A Review Schedule defined in the Review Schedules table can be entered by Review Schedule Name in this field as well. A Review Schedule defined in the Review Schedules table can be entered by Review Schedule Name in this field as well. If NULL, continuous review is used.",
            precision_category=["Time"],
            master_column=["ReviewSchedules.ReviewScheduleName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ReviewPeriodUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure (Type = Time) that defines Review Period length.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Route Planner exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
