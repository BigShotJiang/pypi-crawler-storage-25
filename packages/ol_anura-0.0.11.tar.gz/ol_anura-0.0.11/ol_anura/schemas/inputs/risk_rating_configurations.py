"""RiskRatingConfigurations table schema definition."""

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)

# RiskRatingConfigurations table schema
risk_rating_configurations = Table(
    table_name="RiskRatingConfigurations",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="RiskRatingConfigurations",
    in_database=True,
    fields=[
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Risk Rating, Risk Ratings will be a combination of a Risk Profile Name, External Data Source Name, and an External Data Date. Risk Ratings that are included will be run, and a default Opti Risk rating will always be run as well.",
            precision_category=["NaN"],
            technology={
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RiskProfileName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Risk Profile. Risk Profiles have weights and bands assigned for all of the various risk components in each of the risk configuration tables.",
            precision_category=["NaN"],
            technology={
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Risk Rating will be run in the model. If Status is set to Exclude, the Risk Rating is ignored during the model run.",
            precision_category=["NaN"],
            technology={
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
