"""CustomersMultiTimePeriod table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class CustomerStatus(str, Enum):
    """CustomerStatus values."""

    EXCLUDE = "Exclude"
    INCLUDE = "Include"


# CustomersMultiTimePeriod table schema
customers_multi_time_period = Table(
    table_name="CustomersMultiTimePeriod",
    table_type=TableType.INPUT,
    technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="CustomersMTP",
    fixed_tags=["Customers", "Customer", "Multi", "Time", "Period"],
    in_database=True,
    fields=[
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Periods"],
            expandable=True,
            explanation="The period name in which a change is being made. Groups of periods are also supported. Changes that are made in the Multi Time Period table will be applied as overrides for the records of the base table for the specified periods only. Additionally, only the fields that contain information needing to be updated are required to be entered, in the absence of data in the Multi Time Period table the data from the standard table will be persisted",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="CustomerName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Customers"],
            expandable=True,
            explanation="The name of the Customer",
            precision_category=["NaN"],
            master_column=["Customers.CustomerName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the multi-time period record exists in the model. If Status is set to Exclude, the record is ignored during the model run.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="CustomerStatus",
            data_type=CustomerStatus,
            explanation="Customer Status dictates whether or not the Customer exists in the model during the specified period(s).If the Customer is included in the model, all of its demand records are enforced based on the Min QTY/Max QTY specified in the Customer Demand table. If the Customer Status is set to Exclude, then any demand records for this customer in that period are ignored and there are no penalty costs applied for lost demand. If penalty costs need to be enforced, the Customer Demand Status can be leveraged in the Customer Demand table.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SingleSource",
            data_type=DataType.BOOLEAN,
            explanation="If True, all demand records for the Customer must be satisfied by a single source. Otherwise, demand may be satisfied by multiple sources.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SingleSourceOrders",
            data_type=DataType.BOOLEAN,
            explanation="If True, each order record for the Customer must be satisfied by a single source. Otherwise, demand may be satisfied by multiple sources.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="SingleSourceLineItems",
            data_type=DataType.BOOLEAN,
            explanation="If True, each line item in an order must come from a single source. Otherwise, a line item may be satisfied by multiple sources.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="AllowBackorders",
            data_type=DataType.BOOLEAN,
            explanation="If True, the Customer accepts backorders in the event that an order cannot be fulfilled before its Due Date (defined in the Customer Orders table).",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="BackorderTimeLimit",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="This value is the amount of time after which unsatisfied backorders will be cancelled by the Customer. A value of NULL will be interpreted as an infinite time limit, while a value of 0 is equivalent to setting Allow Backorders = False.",
            precision_category=["Time"],
            in_database=True,
        ),
        Column(
            column_name="BackorderTimeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Time]",
            required_if="BackorderTimeLimit",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Time"],
            default_value="{PrimaryTimeUOM}",
            explanation="The unit of measure used to define the Backorder Time Limit. Any of the time units of measure defined in the Units Of Measure table can be used here.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            in_database=True,
        ),
        Column(
            column_name="AllowPartialFillOrders",
            data_type=DataType.BOOLEAN,
            explanation="If True, orders placed by the Customer may be partially filled. Otherwise, orders must be filled in full. The remaining quantity of partially filled orders may be satisfied in the future with additional shipments; if the Backorder Time Limit is reached on a partially filled order, the remaining quantity will be cancelled.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="AllowPartialFillLineItems",
            data_type=DataType.BOOLEAN,
            explanation="If True, line items within orders placed by the Customer may be partially filled. Otherwise, line items must be filled in full. The remaining quantity of partially filled line items may be satisfied in the future with additional shipments; if the Backorder Time Limit is reached on a partially filled line item, the remaining quantity will be cancelled.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="AllowDirectShip",
            data_type=DataType.BOOLEAN,
            explanation="If True, orders placed by the Customer that cannot be filled directly by its fulfillment source(s) will be filled by an alternative source (Supplier or Facility)",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="QueuePriority",
            data_type=DataType.INTEGER,
            explanation="For any Queues that are evaluated with a Queueing Priority Logic, there can be a By Location component to the priority logic used. If By Location is used, The Queue Priority fields in the Customers, Facilities and Suppliers table will be used to determine how the queues will be ordered",
            precision_category=["Integer"],
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
