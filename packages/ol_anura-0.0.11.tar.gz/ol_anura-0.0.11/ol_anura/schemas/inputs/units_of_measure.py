"""UnitsOfMeasure table schema definition."""

from enum import Enum

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport


class Type(str, Enum):
    """Type values."""

    AREA = "Area"
    DAYSOFSUPPLY = "DaysOfSupply"
    DISTANCE = "Distance"
    PROCESSLOT = "ProcessLot"
    QUANTITY = "Quantity"
    SHIPMENT = "Shipment"
    TIME = "Time"
    VOLUME = "Volume"
    WEIGHT = "Weight"


# UnitsOfMeasure table schema
units_of_measure = Table(
    table_name="UnitsOfMeasure",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
        Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="UnitsOfMeasure",
    basic_mode=[Technology.CYCLO],
    in_database=True,
    fields=[
        Column(
            column_name="UnitOfMeasureName",
            data_type=DataType.STRING,
            required=True,
            explanation="The name of the Unit of Measure (UOM). Models should be given a set of default UOMs upon creation. Units of Measure will allow for input data in various tables to be expressed in a variety of units, all of which will be able to be converted to a common unit so that the solvers will be able to interpret them. If units of measure aren't specified in input tables, defaults that have been set in the Model Settings table as Primary UOM will be used for the appropriate measurement type.",
            precision_category=["NaN"],
            basic_mode=[Technology.CYCLO],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Type",
            data_type=Type,
            required=True,
            explanation="The measurement type defining the UOM. UOM Type dictates where the UOM can be referenced in other tables. For example, we will not be able to use UOMs of Type = Weight in table fields requiring Volume UOMs.",
            precision_category=["NaN"],
            basic_mode=[Technology.CYCLO],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Symbol",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The symbol by which the UOM may be referenced in other tables.",
            precision_category=["NaN"],
            basic_mode=[Technology.CYCLO],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Ratio",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required=True,
            default_value="1",
            explanation="Defines the ratio of the UOM to the specified Type's Primary Unit. For example, the default Primary Unit for Type = Quantity will be Each (EA). As the Primary Quantity Unit, EA will have a ratio of 1; if we define Dozen as another Quantity UOM, we should assign it a ratio of 12 (12 EA per Dozen). In the event that Primary Units are adjusted through the Model Settings table, the ratios will also be adjusted accordingly. If you have defined your own unit of measure, be sure to enter the ratio in alignment with the Primary Unit of the appropriate type that is specified in the Model Settings.",
            precision_category=["Percentage"],
            basic_mode=[Technology.CYCLO],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=[Technology.CYCLO],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
