"""TransportationBandCosting table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class DestinationProperty(str, Enum):
    """DestinationProperty values."""

    ADDRESS = "Address"
    CITY = "City"
    COUNTRY = "Country"
    NAME = "Name"
    ORGANIZATION = "Organization"
    POSTALCODE = "PostalCode"
    REGION = "Region"


class OriginProperty(str, Enum):
    """OriginProperty values."""

    ADDRESS = "Address"
    CITY = "City"
    COUNTRY = "Country"
    NAME = "Name"
    ORGANIZATION = "Organization"
    POSTALCODE = "PostalCode"
    REGION = "Region"


# TransportationBandCosting table schema
transportation_band_costing = Table(
    table_name="TransportationBandCosting",
    table_type=TableType.INPUT,
    technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="TransportationBandCosting",
    fixed_tags=["Transport"],
    in_database=True,
    fields=[
        Column(
            column_name="RateName",
            data_type=DataType.STRING,
            required=True,
            pk=True,
            explanation="The name of the Transportation Rate. This value can be referenced in other tables involving Transportation Rates.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="OriginProperty",
            data_type=OriginProperty,
            pk=True,
            default_value="Name",
            notes="Optimization: Organization is not currently supported as an Origin Property.",
            explanation="The property of the Source (Supplier or Facility) that the Rate cost structure has been created for. For example, a Postal Code to Postal Code rate system could be defined; both the Source and Destination Properties would be set to Postal Code and the Source/Destination values would include all allowable Postal Code pairings.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="OriginValue",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Sources"],
            expandable=True,
            explanation="The value to look up in the Source table (either Facilities or Suppliers) Source Property column.",
            precision_category=["NaN"],
            master_column=[
                "Facilities.FacilityName",
                "Facilities.Address",
                "Facilities.City",
                "Facilities.PostalCode",
                "Facilities.Region",
                "Facilities.Country",
                "Facilities.Organization",
                "Suppliers.SupplierName",
                "Suppliers.Address",
                "Suppliers.City",
                "Suppliers.PostalCode",
                "Suppliers.Region",
                "Suppliers.Country",
            ],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="DestinationProperty",
            data_type=DestinationProperty,
            pk=True,
            default_value="Name",
            notes="Optimization: Organization is not currently supported as a Destination Property.",
            explanation="The property of the Destination (Customer or Facility) that the Rate cost structure has been created for. For example, a Postal Code to Postal Code rate system could be defined; both the Source and Destination Properties would be set to Postal Code and the Source/Destination values would include all allowable Postal Code pairings.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="DestinationValue",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Customers", "Facilities", "Destinations"],
            expandable=True,
            explanation="The value to look up in the Destination table (either Customers or Facilities) Destination Property column.",
            precision_category=["NaN"],
            master_column=[
                "Facilities.FacilityName",
                "Facilities.Address",
                "Facilities.City",
                "Facilities.PostalCode",
                "Facilities.Region",
                "Facilities.Country",
                "Facilities.Organization",
                "Customers.CustomerName",
                "Customers.Address",
                "Customers.City",
                "Customers.PostalCode",
                "Customers.Region",
                "Customers.Country",
            ],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="DistanceBand",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            required=True,
            pk=True,
            default_value="0",
            explanation="Distance-dependent piecewise Rates can be modeled using this field; the appropriate Distance Band interval and corresponding Cost will be selected based on the Distance specified in Transportation Policies.",
            precision_category=["Distance"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="DistanceBandUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Distance]",
            required_if="DistanceBand",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Distance"],
            default_value="{PrimaryDistanceUOM}",
            explanation="The unit of measure (Type = Distance) used to define Distance Band.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ShipmentSize",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            pk=True,
            default_value="0",
            explanation="If populated, the shipment size of the transportation policy record where this rate is assigned will be evaluated against the shipment sizes listed in this table for the other matching keys. This will act as a range lookup, similar to how distance bands are evaluated.",
            precision_category=["Quantity"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ShipmentSizeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="ShipmentSize",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that the shipment size is defined in terms of.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Cost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="NonNegative",
            required=True,
            master_table=["StepCosts"],
            explanation="The cost that is to be applied when the Rate is referenced in the Transportation Policies table.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="CostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight, Time, Distance, Quantity-Distance, Volume-Distance, Weight-Distance, Quantity-Time, Volume-Time, Weight-Time]",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=[
                "Quantity",
                "Volume",
                "Weight",
                "Time",
                "Distance",
                "Quantity-Distance",
                "Volume-Distance",
                "Weight-Distance",
                "Quantity-Time",
                "Volume-Time",
                "Weight-Time",
            ],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines Cost. If the Unit Cost UOM field in the Transportation Policies table is populated for records that the listed Transportation Rate is assigned, the value in the Transportation Policies table will be used. If not, the Cost UOM specified in this table will be used along with the cost. UOM Types of Quantity, Volume, Weight, Distance, Time, Quantity-Distance, Quantity-Time, Volume-Distance, Volume-Time, Weight-Distance, and Weight-Time are supported.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the Rate exists in the model. If Status is set to Exclude, the Rate will be ignored during the model run.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
