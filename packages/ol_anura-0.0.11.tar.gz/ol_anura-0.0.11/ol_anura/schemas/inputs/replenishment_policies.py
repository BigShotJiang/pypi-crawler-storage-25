"""ReplenishmentPolicies table schema definition."""

from enum import Enum

from ...core import (
    Column,
    DataType,
    Status,
    Table,
    TableType,
    Technology,
    TechnologySupport,
)


class OptimizationPolicy(str, Enum):
    """OptimizationPolicy values."""

    BY_RATIO_AUTO_SCALE = "By Ratio (Auto Scale)"
    BY_RATIO_NO_SCALE = "By Ratio (No Scale)"
    SINGLE_SOURCE = "Single Source"
    TO_OPTIMIZE = "To Optimize"


class SimulationPolicy(str, Enum):
    """SimulationPolicy values."""

    ALLOCATION = "Allocation"
    BY_DISTANCE = "By Distance"
    BY_PREFERENCE = "By Preference"
    SINGLE_SOURCE = "Single Source"


class SimulationPolicyLogic(str, Enum):
    """SimulationPolicyLogic values."""

    PULL = "Pull"
    PUSH = "Push"


# ReplenishmentPolicies table schema
replenishment_policies = Table(
    table_name="ReplenishmentPolicies",
    table_type=TableType.INPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
        Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="ReplenishmentPolicies",
    fixed_tags=[
        "Facilities",
        "Facility",
        "Suppliers",
        "Supplier",
        "Policies",
        "Replenishment",
    ],
    basic_mode=[Technology.THROG, Technology.DENDRO, Technology.CYCLO],
    in_database=True,
    fields=[
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            explanation="The Facility that the policy record applies to. If Procurement Policies are also defined for the Facility, Replenishment Policies will take priority.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.CYCLO],
            master_column=["Facilities.FacilityName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Products"],
            expandable=True,
            explanation="The Product that the policy record applies to.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.CYCLO],
            master_column=["Products.ProductName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SourceName",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable",
            required=True,
            pk=True,
            master_table=["Facilities"],
            expandable=True,
            explanation="The Facility from which the Product will be sourced under the policy record.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.CYCLO],
            master_column=["Facilities.FacilityName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.CYCLO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="OptimizationPolicy",
            data_type=OptimizationPolicy,
            required=True,
            default_value="To Optimize",
            explanation="The logic that replenishment flows for the Facility, Product, and Source combination(s) must follow. To Optimize selects the lowest cost option. By Ratio (Auto Scale) will enforce a flow split between the specified sources, the defined ratios will apply to flow into the Facility from the listed sources only. By Ratio (No Scale) will enforce a flow split between the specified sources and the defined ratios will be in terms of the total inbound flow into the Facility. Single Source policies force the Facility to receive the Product from one Source. Note that if a group is used in the Facility Name, Product Name, or Source Name field that the groups will be enumerated and the policy logic will be applied over the enumerated entries.",
            precision_category=["NaN"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="OptimizationPolicyValue",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required_if="OptimizationPolicy = By Ratio (Auto Scale) OR By Ratio (No Scale)",
            notes="0",
            explanation="By Ratio (Auto Scale): The Policy Value will define the percentage of flow that must be satisfied from the listed source. The percentage will be calculated based on the total inbound flow for the Facility/Product combination from sources with a policy of By Ratio (Auto Scale).\n\nBy Ratio (No Scale): The Policy Value will define the percentage of flow that must be satisfied from the listed source. The percentage will be calculated based on the total inbound flow for the Facility/Product combination across ALL sources.",
            precision_category=["Percentage"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="SimulationPolicy",
            data_type=SimulationPolicy,
            required=True,
            default_value="By Preference",
            explanation="The logic that replenishment flows for the Facility, Product, and Source combination(s) must follow. By Preference will pick the sources pending product availability in the specified order of preference. Single Source policies force the Facility to receive the Product from one Source. Allocation will source as much as possible from the sources based on availability in the specified order of preference - this is similar to By Preference but the Allocation policy will not attempt to keep orders together from a single source. By Distance will select the closest source using straight-line distances.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SimulationPolicyValue",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            required_if="SimulationPolicy = By Preference",
            explanation="By Preference: Policy Value defines the order of preference in which a source will be selected pending product availability, with the lower numbers representing a higher selection preference. Allocation: Policy value defines the order in which sources will be selected.",
            precision_category=["Percentage"],
            basic_mode=[Technology.THROG],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SimulationPolicyLogic",
            data_type=SimulationPolicyLogic,
            default_value="Pull",
            explanation="Simulation Policy Logic will specify whether the sourcing behavior specified for the Replenishment Policy is a Pull action (Facility selecting a Source) or a Push action (Source selecting a Facility to send surplus inventory). Surplus Level definitions, and a Surplus Review Period will be set in the Inventory Policies table.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Status",
            data_type=Status,
            required=True,
            default_value="Include",
            explanation="Status dictates whether or not the policy exists in the model. If Status is set to Exclude, the policy record is ignored during the model run.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UnitCost",
            data_type=DataType.COST_TIME_EXPRESSION,
            validation_type="ExistsInMasterTable WHERE StepCosts.StepCostBehavior = [All Item, Incremental, Stepwise]",
            master_table=["StepCosts"],
            default_value="0",
            notes="Optimization: Currently supports doubles and named step costs that are defined in the StepCosts table where StepCostBehavior = All Item, Incremental or Stepwise or a combination of Stepwise and All Item\n\nSimulation: Currently supports doubles",
            explanation="The unit cost associated with flow for the specified Source/Facility/Product combination. This field can support a single numeric value, a step cost (either a direct entry or a lookup), or a custom cost function.",
            precision_category=["Cost"],
            master_column=["StepCosts.StepCostName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UnitCostUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="UnitCost",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure used to define flow for the specified Source/Facility/Product combination.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MinimumOrderQuantity",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="The minimum quantity that must move between source and destination in a period for a flow to occur",
            precision_category=["Quantity"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MinimumOrderQuantityUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="MinimumOrderQuantity",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the MOQ for the Source/Facility/Product combination.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="LotSize",
            data_type=DataType.DOUBLE,
            validation_type="PositiveNumeric",
            explanation="Orders placed from the Facility to the specified sources must be filled in multiples of the specified lot size.",
            precision_category=["Quantity"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="LotSizeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Quantity, Volume, Weight]",
            required_if="LotSize",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Quantity", "Volume", "Weight"],
            default_value="{PrimaryQuantityUOM}",
            explanation="The unit of measure that defines the Lot Size for the Source/Facility/Product combination.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MaxSourcingRange",
            data_type=DataType.DOUBLE,
            validation_type="NonNegative",
            explanation="The maximum allowable distance between Customer and Source for the Product(s) specified. This field is intended for use in models with group policies to eliminate excessively long lanes from consideration. If all sources exceed the max sourcing range for a Facility-Product pairing, the closest source will be kept by default - this behavior can be overwritten through the Keep Closest Lane For Max Sourcing Distance run option.",
            precision_category=["Distance"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="MaxSourcingRangeUOM",
            data_type=DataType.STRING,
            validation_type="ExistsInMasterTable WHERE UnitsOfMeasure.Type = [Distance]",
            required_if="MaxSourcingRange",
            master_table=["UnitsOfMeasure"],
            allowable_uom_types=["Distance"],
            default_value="{PrimaryDistanceUOM}",
            explanation="The unit of measure (Type = Distance) that defines Max Delivery Range.",
            precision_category=["NaN"],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="OnlySourceFromSurplus",
            data_type=DataType.BOOLEAN,
            default_value="0",
            explanation="If True, when selecting a source for the Facility / Product combination only sources that have available surplus can be selected to fulfill the order.",
            precision_category=["NaN"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Notes",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=[Technology.THROG],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
