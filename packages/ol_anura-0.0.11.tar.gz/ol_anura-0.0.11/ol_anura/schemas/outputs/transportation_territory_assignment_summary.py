"""TransportationTerritoryAssignmentSummary table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# TransportationTerritoryAssignmentSummary table schema
transportation_territory_assignment_summary = Table(
    table_name="TransportationTerritoryAssignmentSummary",
    table_type=TableType.OUTPUT,
    technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="TransportationTerritoryAssignmentSummary",
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=[Technology.HOPPER],
            master_column=["Scenarios.ScenarioName"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="LocationName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the location.",
            precision_category=["NaN"],
            basic_mode=[Technology.HOPPER],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="TerritoryName",
            data_type=DataType.STRING,
            explanation="A unique identifier for the territory the location is assigned to.",
            precision_category=["NaN"],
            basic_mode=[Technology.HOPPER],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="TerritoryType",
            data_type=DataType.STRING,
            explanation="The type of the territory the location is assigned to.",
            precision_category=["NaN"],
            basic_mode=[Technology.HOPPER],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the location.",
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.HOPPER],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the location.",
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.HOPPER],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
