"""OptimizationNetworkRiskMetrics table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# OptimizationNetworkRiskMetrics table schema
optimization_network_risk_metrics = Table(
    table_name="OptimizationNetworkRiskMetrics",
    table_type=TableType.OUTPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OptNetworkRisk",
    basic_mode=[Technology.NEO, Technology.DART],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.DART],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            basic_mode=[Technology.DART],
            technology={Technology.DART: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="NetworkRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with Network activities in this scenario. This is calculated as the weighted average of the Product Stocking Point Count Risk, Product Make And Supply Count Risk, Transport Time Risk, Time To Import Risk and Time To Export Risk.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ProductStockingPointCountRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the number of Facilities that the Product is stocked in Inventory. This is calculated as the weighted average of all Products Stocking Point Count Risk in the Optimization Product Risk Metrics table. The lower the number of stocking points, the higher the risk score.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ProductMakeAndSupplyCountRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the number of Facilities or Suppliers that the Product is either produced at or supplied from. This is calculated as the weighted average of the Make Adn Supply Count Risk in the Optimization Product Risk Metrics table.  The lower the number of production or supply locations, the higher the risk.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TransportTimeRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how long of a transport time the flows have. This is calculated based off of the weighted average of Transport Time Risk reported in the Optimization Flow Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TimeToImportRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how long it can take imported products to clear customs. This is calculated based off of the weighted average of Time To Import Risk in the Optimization Flow Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TimeToExportRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how long it can take exported products to clear customs. This is calculated based off of the weighted average of Time To Export Risk in the Optimization Flow Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
