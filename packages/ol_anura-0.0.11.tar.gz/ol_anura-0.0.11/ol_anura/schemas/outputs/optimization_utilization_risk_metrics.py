"""OptimizationUtilizationRiskMetrics table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# OptimizationUtilizationRiskMetrics table schema
optimization_utilization_risk_metrics = Table(
    table_name="OptimizationUtilizationRiskMetrics",
    table_type=TableType.OUTPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OptUtilizationRisk",
    basic_mode=[Technology.NEO, Technology.DART],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.DART],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SiteName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.DART],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SiteType",
            data_type=DataType.STRING,
            pk=True,
            explanation="One of Facility or Supplier",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.DART],
            master_column=["Periods.PeriodName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UtilizationRiskScore",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ThroughputUtilizationRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="StorageUtilizationRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="WorkCenterUtilizationRisk",
            data_type=DataType.DOUBLE,
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
