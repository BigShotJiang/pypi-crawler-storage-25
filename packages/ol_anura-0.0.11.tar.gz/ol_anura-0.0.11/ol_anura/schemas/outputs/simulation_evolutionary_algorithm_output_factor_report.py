"""SimulationEvolutionaryAlgorithmOutputFactorReport table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# SimulationEvolutionaryAlgorithmOutputFactorReport table schema
simulation_evolutionary_algorithm_output_factor_report = Table(
    table_name="SimulationEvolutionaryAlgorithmOutputFactorReport",
    table_type=TableType.OUTPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="SimEvoAlgorithmOutputFactorRpt",
    basic_mode=[Technology.THROG, Technology.DENDRO],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The GA-generated scenario name that represents the grouping of genes that make up this scenario.",
            precision_category=["{NaN]"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="OutputFactorName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Output Factor name.",
            precision_category=["{NaN]"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Value",
            data_type=DataType.DOUBLE,
            explanation="The utility value associated with the Output Factor in this GA-scenario. This is the raw value returned based on the Utility Curve that was defined in the Output Factors table.",
            precision_category=["Percentage"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="WeightedScore",
            data_type=DataType.DOUBLE,
            explanation="The weighted utility value associated with the Output Factor in this GA-Scenario. This is the weighted value calculated based on the Output Factor Weight / Utility Curve expressed in the Output Factors table.",
            precision_category=["Percentage"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
