"""OptimizationUserDefinedVariableTermSummary table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# OptimizationUserDefinedVariableTermSummary table schema
optimization_user_defined_variable_term_summary = Table(
    table_name="OptimizationUserDefinedVariableTermSummary",
    table_type=TableType.OUTPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OptUserDefinedVariableTermSmry",
    basic_mode=[Technology.NEO, Technology.DART],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO],
            master_column=["Scenarios.ScenarioName"],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO],
            master_column=[
                "UserDefinedVariables.VariableName",
                "TransportationUserDefinedVariables.VariableName",
            ],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="TermName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the Term in the specified User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO],
            master_column=[
                "UserDefinedVariables.TermName",
                "TransportationUserDefinedVariables.TermName",
            ],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="TermValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Term in the specified User Defined Variable.",
            precision_category=["Quantity"],
            basic_mode=[Technology.NEO],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ScaledTermValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Term in the specified User Defined Variable multiplied by Coefficient.",
            precision_category=["Quantity"],
            basic_mode=[Technology.NEO],
            technology={Technology.NEO: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
