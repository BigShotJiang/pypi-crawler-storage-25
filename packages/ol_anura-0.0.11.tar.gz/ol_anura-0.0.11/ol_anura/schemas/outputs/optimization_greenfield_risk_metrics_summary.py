"""OptimizationGreenfieldRiskMetricsSummary table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# OptimizationGreenfieldRiskMetricsSummary table schema
optimization_greenfield_risk_metrics_summary = Table(
    table_name="OptimizationGreenfieldRiskMetricsSummary",
    table_type=TableType.OUTPUT,
    technology={
        Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OptGreenfieldRiskSmry",
    basic_mode=[Technology.TRIAD, Technology.DART],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this scenario. The Risk Score is the weighted sum of Customer, Facility, Supplier, and Network Risk, and is populated for the Primary Risk Rating that is specified in the Model Settings.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="CustomerRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with Customers in this scenario. More details on the Risk components can be found in the Optimization Greenfield Customer Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="FacilityRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with Facilities in this scenario. More details on the Risk components can be found in the Optimization Greenfield Facility Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SupplierRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with Suppliers in this scenario. More details on the Risk components can be found in the Optimization Greenfield Supplier Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="NetworkRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with Network activities in this scenario. More details on the Risk components can be found in the Optimization Greenfield Flow Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DARTVersion",
            data_type=DataType.STRING,
            explanation="The version of the DART solver that was used for the scenario run.",
            precision_category=["NaN"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
