"""SimulationLaneModeQueueDepthReport table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# SimulationLaneModeQueueDepthReport table schema
simulation_lane_mode_queue_depth_report = Table(
    table_name="SimulationLaneModeQueueDepthReport",
    table_type=TableType.OUTPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="SimLaneModeQDepthRpt",
    basic_mode=[Technology.THROG, Technology.DENDRO],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            precision_category=["Integer"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Products.ProductName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ModeName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["TransportationModes"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["TransportationModes.ModeName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Time",
            data_type=DataType.DATETIME,
            pk=True,
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="QueueDepth",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
