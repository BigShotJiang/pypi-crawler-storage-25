"""SimulationLaneQueueSummary table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# SimulationLaneQueueSummary table schema
simulation_lane_queue_summary = Table(
    table_name="SimulationLaneQueueSummary",
    table_type=TableType.OUTPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="SimLaneQSmry",
    basic_mode=[Technology.THROG, Technology.DENDRO],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="OriginName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DestinationName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Products.ProductName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="StatType",
            data_type=DataType.STRING,
            pk=True,
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="AverageQueueDepth",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MinQueueDepth",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MaxQueueDepth",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="QueueType",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TotalTimeInQueueCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="OriginLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="OriginLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DestinationLatitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="DestinationLongitude",
            data_type=DataType.DOUBLE,
            master_table=["Facilities", "Suppliers", "Customers"],
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=[
                "Facilities.FacilityName",
                "Suppliers.SupplierName",
                "Customers.CustomerName",
            ],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
