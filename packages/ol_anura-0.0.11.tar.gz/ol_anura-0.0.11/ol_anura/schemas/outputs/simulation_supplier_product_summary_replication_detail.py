"""SimulationSupplierProductSummaryReplicationDetail table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# SimulationSupplierProductSummaryReplicationDetail table schema
simulation_supplier_product_summary_replication_detail = Table(
    table_name="SimulationSupplierProductSummaryReplicationDetail",
    table_type=TableType.OUTPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="SimSupplierProductSmryRD",
    basic_mode=[Technology.THROG, Technology.DENDRO],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ReplicationNumber",
            data_type=DataType.INTEGER,
            pk=True,
            precision_category=["Integer"],
            basic_mode=[Technology.THROG, Technology.DENDRO, Technology.DART],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SupplierName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Suppliers"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Suppliers.SupplierName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Products.ProductName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TotalSuppliedQuantity",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SuppliedQuantityUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TotalSuppliedVolume",
            data_type=DataType.DOUBLE,
            precision_category=["Volume"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SuppliedVolumeUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TotalSuppliedWeight",
            data_type=DataType.DOUBLE,
            precision_category=["Weight"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SuppliedWeightUOM",
            data_type=DataType.STRING,
            master_table=["UnitsOfMeasure"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["UnitsOfMeasure.Symbol"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
