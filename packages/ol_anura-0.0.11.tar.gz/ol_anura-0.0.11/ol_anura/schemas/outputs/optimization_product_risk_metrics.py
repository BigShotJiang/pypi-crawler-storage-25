"""OptimizationProductRiskMetrics table schema definition."""

from ...core import Column, DataType, Table, TableType

# OptimizationProductRiskMetrics table schema
optimization_product_risk_metrics = Table(
    table_name="OptimizationProductRiskMetrics",
    table_type=TableType.OUTPUT,
    abbreviated_name="OptProductRisk",
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            master_column=["Scenarios.ScenarioName"],
            in_database=True,
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            in_database=True,
        ),
        Column(
            column_name="PeriodName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Periods"],
            explanation="The time period that the results are reported for.",
            precision_category=["NaN"],
            master_column=["Periods.PeriodName"],
            in_database=True,
        ),
        Column(
            column_name="ProductName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Products"],
            explanation="The name of the Product.",
            precision_category=["NaN"],
            master_column=["Products.ProductName"],
            in_database=True,
        ),
        Column(
            column_name="StockingPointCountRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the number of Facilities that the Product is stocked in Inventory. The lower the number of stocking points, the higher the risk.",
            precision_category=["Risk"],
            in_database=True,
        ),
        Column(
            column_name="MakeAndSupplyCountRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the number of Facilities or Suppliers that the Product is either produced at or supplied from. The lower the number of production or supply locations, the higher the risk.",
            precision_category=["Risk"],
            in_database=True,
        ),
    ],
)
