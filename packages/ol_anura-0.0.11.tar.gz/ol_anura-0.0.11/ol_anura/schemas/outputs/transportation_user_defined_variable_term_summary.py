"""TransportationUserDefinedVariableTermSummary table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# TransportationUserDefinedVariableTermSummary table schema
transportation_user_defined_variable_term_summary = Table(
    table_name="TransportationUserDefinedVariableTermSummary",
    table_type=TableType.OUTPUT,
    technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
    abbreviated_name="TransportUDVTermSmry",
    basic_mode=[Technology.HOPPER],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=[Technology.HOPPER],
            master_column=["Scenarios.ScenarioName"],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="VariableName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=[Technology.HOPPER],
            master_column=[
                "UserDefinedVariables.VariableName",
                "TransportationUserDefinedVariables.VariableName",
            ],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="TermName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["UserDefinedVariables", "TransportationUserDefinedVariables"],
            explanation="The name of the Term in the specified User Defined Variable.",
            precision_category=["NaN"],
            basic_mode=[Technology.HOPPER],
            master_column=[
                "UserDefinedVariables.TermName",
                "TransportationUserDefinedVariables.TermName",
            ],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="TermValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Term in the specified User Defined Variable.",
            precision_category=["Quantity"],
            basic_mode=[Technology.HOPPER],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="ScaledTermValue",
            data_type=DataType.DOUBLE,
            explanation="The value of the Term in the specified User Defined Variable multiplied by Coefficient.",
            precision_category=["Quantity"],
            basic_mode=[Technology.HOPPER],
            technology={Technology.HOPPER: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
    ],
)
