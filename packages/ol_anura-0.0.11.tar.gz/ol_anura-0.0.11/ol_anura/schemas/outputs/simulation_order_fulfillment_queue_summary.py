"""SimulationOrderFulfillmentQueueSummary table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# SimulationOrderFulfillmentQueueSummary table schema
simulation_order_fulfillment_queue_summary = Table(
    table_name="SimulationOrderFulfillmentQueueSummary",
    table_type=TableType.OUTPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="SimOrderFulfillmentQSmry",
    basic_mode=[Technology.THROG, Technology.DENDRO],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Facilities.FacilityName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="StatType",
            data_type=DataType.STRING,
            pk=True,
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="AverageQueueDepth",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MinQueueDepth",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="MaxQueueDepth",
            data_type=DataType.DOUBLE,
            precision_category=["Quantity"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="QueueType",
            data_type=DataType.STRING,
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TotalTimeInQueueCost",
            data_type=DataType.DOUBLE,
            precision_category=["Cost"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
