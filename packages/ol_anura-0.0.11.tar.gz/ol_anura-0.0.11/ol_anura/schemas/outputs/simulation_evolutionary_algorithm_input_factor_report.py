"""SimulationEvolutionaryAlgorithmInputFactorReport table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# SimulationEvolutionaryAlgorithmInputFactorReport table schema
simulation_evolutionary_algorithm_input_factor_report = Table(
    table_name="SimulationEvolutionaryAlgorithmInputFactorReport",
    table_type=TableType.OUTPUT,
    technology={
        Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
        Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="SimEvoAlgorithmInputFactorRpt",
    basic_mode=[Technology.THROG, Technology.DENDRO],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The GA-generated scenario name that represents the grouping of genes that make up this scenario.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="InputFactorName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The name of the Input Factor that is being modified in the GA-Scenario.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="InputFactorValue",
            data_type=DataType.STRING,
            explanation="The value that the Input Factor is using for the listed GA Scenario.",
            precision_category=["NaN"],
            basic_mode=[Technology.THROG, Technology.DENDRO],
            technology={
                Technology.THROG: TechnologySupport.FULLY_SUPPORTED,
                Technology.DENDRO: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
