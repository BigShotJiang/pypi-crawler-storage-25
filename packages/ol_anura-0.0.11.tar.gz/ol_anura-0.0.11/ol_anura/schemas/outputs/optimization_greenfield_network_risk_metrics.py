"""OptimizationGreenfieldNetworkRiskMetrics table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# OptimizationGreenfieldNetworkRiskMetrics table schema
optimization_greenfield_network_risk_metrics = Table(
    table_name="OptimizationGreenfieldNetworkRiskMetrics",
    table_type=TableType.OUTPUT,
    technology={
        Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OptGreenfieldNetworkRisk",
    basic_mode=[Technology.TRIAD, Technology.DART],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="NetworkRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with Network activities in this scenario. This is calculated as the weighted average of the Product Stocking Point Count Risk, Product Make And Supply Count Risk, Transport Time Risk, Time To Import Risk and Time To Export Risk.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TransportTimeRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how long of a transport time the flows have. This is calculated based off of the weighted average of Transport Time Risk reported in the Optimization Flow Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TimeToImportRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how long it can take imported products to clear customs. This is calculated based off of the weighted average of Time To Import Risk in the Optimization Flow Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="TimeToExportRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how long it can take exported products to clear customs. This is calculated based off of the weighted average of Time To Export Risk in the Optimization Flow Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.TRIAD, Technology.DART],
            technology={
                Technology.TRIAD: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
