"""OptimizationFacilityRiskMetrics table schema definition."""

from ...core import Column, DataType, Table, TableType, Technology, TechnologySupport

# OptimizationFacilityRiskMetrics table schema
optimization_facility_risk_metrics = Table(
    table_name="OptimizationFacilityRiskMetrics",
    table_type=TableType.OUTPUT,
    technology={
        Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
        Technology.DART: TechnologySupport.FULLY_SUPPORTED,
    },
    abbreviated_name="OptFacilityRisk",
    basic_mode=[Technology.NEO, Technology.DART],
    in_database=True,
    fields=[
        Column(
            column_name="ScenarioName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Scenarios"],
            explanation="The name of the scenario the results are saved for.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.DART],
            master_column=["Scenarios.ScenarioName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="RiskRatingName",
            data_type=DataType.STRING,
            pk=True,
            explanation="The Risk Rating that risk metrics are reported for.",
            precision_category=["NaN"],
            basic_mode=[Technology.DART],
            technology={Technology.DART: TechnologySupport.FULLY_SUPPORTED},
            in_database=True,
        ),
        Column(
            column_name="FacilityName",
            data_type=DataType.STRING,
            pk=True,
            master_table=["Facilities"],
            explanation="The name of the Facility.",
            precision_category=["NaN"],
            basic_mode=[Technology.NEO, Technology.DART],
            master_column=["Facilities.FacilityName"],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="FacilityRiskScore",
            data_type=DataType.DOUBLE,
            explanation="The risk score associated with this Facility. This is based on a weighted average of the Facility's Concentration, Source Count, Utilization, Geographic and User Defined Risk across the entire model horizon.  The Facility Risk Score is used to calculate the overall Risk Score in the Risk Metrics Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="ConcentrationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the throughput concentration of the Facility. This is reported as a weighted average over all periods based off of the Concentration Risk in the Optimization Facility Summary table.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="SourceCountRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the number of sources that the Facility uses across all products and periods. This is reported as a weighted average based off of the Source Count Risk in the Optimization Facility Summary table.  Using fewer sources results in higher risk.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UtilizationRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with how close to capacity the Facility is during the model solve. This is calculated as the weighted average of Storage Capacity Risk, Throughput Capacity Risk, and the Work Center Capacity Risk. Additional details can be found in the Optimization Capacity Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="GeographicRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the geographic location of the Facility. This is a weighted average of several geographic components that are reported in greater detail in the Optimization Geographic Risk Metrics table.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="UserDefinedRisk",
            data_type=DataType.DOUBLE,
            explanation="The risk associated with the User Defined Risk value entered in the Facilities table.",
            precision_category=["Risk"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Latitude",
            data_type=DataType.DOUBLE,
            explanation="The latitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
        Column(
            column_name="Longitude",
            data_type=DataType.DOUBLE,
            explanation="The longitude of the Facility.",
            precision_category=["GeoCoordinate"],
            basic_mode=[Technology.NEO, Technology.DART],
            technology={
                Technology.NEO: TechnologySupport.FULLY_SUPPORTED,
                Technology.DART: TechnologySupport.FULLY_SUPPORTED,
            },
            in_database=True,
        ),
    ],
)
