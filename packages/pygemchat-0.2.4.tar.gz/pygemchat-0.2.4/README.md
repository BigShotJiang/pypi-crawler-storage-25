﻿# Project Upload

A simple AI chatbot package for OpenAI and Gemini.

## Install

```bash
pip install .
```

To install optional support packages:

```bash
pip install .[openai,gemini,rich]
```

## Run

```bash
python -m project_upload
```

## Build and Upload

```bash
python -m build
python -m twine upload dist/*
```
