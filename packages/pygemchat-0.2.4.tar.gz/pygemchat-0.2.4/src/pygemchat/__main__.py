# src/pygemchat/__main__.py

from .main import Chatbot

if __name__ == "__main__":
    bot = Chatbot(api=None)
    bot.run()