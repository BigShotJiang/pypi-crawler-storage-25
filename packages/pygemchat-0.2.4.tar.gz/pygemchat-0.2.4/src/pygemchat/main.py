import base64
import json
import os
import textwrap
from pathlib import Path

try:
    import openai
except ImportError:
    openai = None

try:
    import google.genai as genai
except ImportError:
    genai = None

HISTORY_FILE = Path(__file__).with_name('chat_history.json')

if not HISTORY_FILE.exists():
    HISTORY_FILE.write_text(json.dumps([]))
    
class Chatbot:
    DEFAULT_MODEL = 'gemini-flash-latest'  # Free Gemini model
    MAX_HISTORY = 20  # Increased for better context
    PROVIDER = 'gemini'  # 'openai' or 'gemini'
    MODES = {
        'general': {
            'role': 'system',
            'content': (
                'You are a helpful AI assistant like ChatGPT. '
                'Provide detailed, accurate, and engaging responses. '
                'Use markdown for formatting when appropriate.'
            ),
        },
        'coding': {
            'role': 'system',
            'content': (
                'You are an expert coding assistant. '
                'Provide code examples, explain concepts clearly, and help with debugging. '
                'Use markdown for code blocks and formatting.'
            ),
        },
        'creative': {
            'role': 'system',
            'content': (
                'You are a creative AI assistant. '
                'Help with writing, brainstorming, and imaginative tasks. '
                'Be inspiring and original.'
            ),
        },
    }

    def __init__(self,api):
        self.openai = openai
        self.genai = genai
        self.history = self.load_history()
        self.current_mode = 'general'
        self.api_key = api

    def encode_image_to_base64(self, image_path):
        """Encode an image file to base64 string."""
        with open(image_path, 'rb') as image_file:
            return base64.standard_b64encode(image_file.read()).decode('utf-8')

    def get_image_media_type(self, image_path):
        """Determine the media type of an image based on file extension."""
        ext = Path(image_path).suffix.lower()
        media_types = {
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.webp': 'image/webp',
        }
        return media_types.get(ext, 'image/jpeg')

    def load_history(self):
        if HISTORY_FILE.exists():
            try:
                with HISTORY_FILE.open('r', encoding='utf-8') as handle:
                    data = json.load(handle)
                    if isinstance(data, list):
                        return data
            except Exception:
                pass
        return []

    def save_history(self):
        try:
            with HISTORY_FILE.open('w', encoding='utf-8') as handle:
                json.dump(self.history, handle, indent=2, ensure_ascii=False)
            return True
        except OSError:
            return False

    def load_api_key(self):
        if self.PROVIDER == 'openai':
            api_key = os.environ.get('OPENAI_API_KEY')
            if api_key:
                return api_key
        elif self.PROVIDER == 'gemini':
            api_key = os.environ.get('GEMINI_API_KEY')
            if api_key:
                return api_key

        apikey_file = Path(__file__).parent / 'apikey'
        if apikey_file.exists():
            try:
                with apikey_file.open('r', encoding='utf-8') as f:
                    content = f.read().strip()
                    first_line = content.split('\n', 1)[0]
                    if first_line.startswith('api key '):
                        api_key = first_line[len('api key '):].strip()
                    else:
                        api_key = first_line.strip()
                    if api_key:
                        return api_key
            except Exception:
                pass
        return None

    def get_api_key(self):
        return self.load_api_key()

    def get_help_text(self):
        return (
            'Commands:\n'
            '  /help    Show this help message\n'
            '  /reset   Clear conversation history\n'
            '  /history Show recent chat history\n'
            '  /mode <type>  Switch mode: general, coding, creative\n'
            '  exit     Quit the chatbot'
        )

    def local_fallback_response(self, user_text):
        text = user_text.lower().strip()
        if not text:
            return 'Say something and I will respond.'
        if any(word in text for word in ['hello', 'hi', 'hey']):
            return 'Hello! I am a local fallback chatbot. Set OPENAI_API_KEY for the full AI experience.'
        if 'time' in text:
            return 'I cannot access the current time, but I can still chat with you.'
        if 'name' in text:
            return 'I am a friendly chatbot running locally.'
        if 'help' in text:
            return 'Try asking me anything or enter /help for commands.'
        return 'I am a local fallback chatbot. Set OPENAI_API_KEY for full AI responses.'

    def get_chat_response(self, history, api_key, current_mode):
        if not api_key or (self.PROVIDER == 'openai' and not self.openai) or (self.PROVIDER == 'gemini' and not self.genai):
            last_msg = history[-1]['content'] if isinstance(history[-1]['content'], str) else history[-1]['content'].get('text', 'Hello')
            return self.local_fallback_response(last_msg)

        system_prompt = self.MODES[current_mode]['content']

        if self.PROVIDER == 'openai':
            client = self.openai.OpenAI(api_key=api_key)
            messages = [{'role': 'system', 'content': system_prompt}]

            for msg in history[-self.MAX_HISTORY:]:
                if isinstance(msg['content'], str):
                    messages.append({'role': msg['role'], 'content': msg['content']})
                elif isinstance(msg['content'], dict) and 'type' in msg['content']:
                    if msg['content']['type'] == 'image':
                        image_path = msg['content']['path']
                        image_data = self.encode_image_to_base64(image_path)
                        media_type = self.get_image_media_type(image_path)
                        messages.append({
                            'role': msg['role'],
                            'content': [
                                {'type': 'text', 'text': msg['content'].get('text', 'Analyze this image')},
                                {'type': 'image_url', 'image_url': {'url': f'data:{media_type};base64,{image_data}'}}
                            ]
                        })
                    else:
                        messages.append({'role': msg['role'], 'content': msg['content'].get('text', '')})
                else:
                    messages.append({'role': msg['role'], 'content': str(msg['content'])})

            try:
                response = client.chat.completions.create(
                    model='gpt-4-vision' if any(isinstance(m.get('content'), list) for m in messages) else 'gpt-3.5-turbo',
                    messages=messages,
                    temperature=0.7,
                    stream=True,
                )
                full_response = ""
                for chunk in response:
                    if chunk.choices and chunk.choices[0].delta.content:
                        full_response += chunk.choices[0].delta.content
                return full_response.strip()
            except Exception:
                last_msg = history[-1]['content'] if isinstance(history[-1]['content'], str) else history[-1]['content'].get('text', 'Hello')
                return self.local_fallback_response(last_msg)

        elif self.PROVIDER == 'gemini':
            client = self.genai.Client(api_key=api_key)
            contents = []

            for msg in history[-self.MAX_HISTORY:]:
                role = 'user' if msg['role'] == 'user' else 'model'
                parts = []

                if isinstance(msg['content'], str):
                    parts.append({'text': msg['content']})
                elif isinstance(msg['content'], dict) and 'type' in msg['content']:
                    if msg['content']['type'] == 'image':
                        image_path = msg['content']['path']
                        image_data = self.encode_image_to_base64(image_path)
                        media_type = self.get_image_media_type(image_path)
                        parts.append({'text': msg['content'].get('text', 'Analyze this image')})
                        parts.append({
                            'inline_data': {
                                'mime_type': media_type,
                                'data': image_data
                            }
                        })
                    else:
                        parts.append({'text': msg['content'].get('text', '')})
                else:
                    parts.append({'text': str(msg['content'])})

                contents.append({'parts': parts, 'role': role})

            try:
                response = client.models.generate_content(
                    model=self.DEFAULT_MODEL,
                    contents=contents,
                    config={
                        'system_instruction': system_prompt,
                        'temperature': 0.7,
                    },
                )
                return response.text
            except Exception:
                last_msg = history[-1]['content'] if isinstance(history[-1]['content'], str) else history[-1]['content'].get('text', 'Hello')
                return self.local_fallback_response(last_msg)

    def answer(self,prompt):           
        self.history.append({'role': 'user', 'content': prompt})
        answer = self.get_chat_response(self.history, self.api_key, self.current_mode)
        self.history.append({'role': 'assistant', 'content': answer})
        self.save_history()
        return answer
        
    def run(self):
        print('AI Chatbot is ready. Type /help for commands.')

        if self.PROVIDER == 'openai' and self.openai is None:
            print('Warning: the openai package is not installed. Install it with: pip install -r requirements.txt')

        self.history = self.load_history()
        self.current_mode = 'general'

        while True:
            prompt = input('You: ')
            ans = self.answer(prompt)
            print(ans)

chatbot = Chatbot(api=None)
run = chatbot.run
