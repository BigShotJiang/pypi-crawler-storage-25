from django.apps import AppConfig


class DrMigrateConfig(AppConfig):
    name = "drmigrate"
    verbose_name = "Migration Doctor"
    default_auto_field = "django.db.models.BigAutoField"
