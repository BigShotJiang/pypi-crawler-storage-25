from __future__ import annotations

import os

from django.db import migrations
from django.db.migrations.writer import MigrationWriter


def generate_merge_migration(
    app_label: str,
    branch_names: list[str],
    migrations_dir: str | None = None,
    dry_run: bool = False,
) -> tuple[str, str]:
    """Generate a merge migration file for conflicting branches.

    Returns (file_path, file_content).
    """
    # Build the merge migration name
    short_names = []
    for name in sorted(branch_names):
        # Strip common prefixes like "0002_"
        parts = name.split("_", 1)
        short = parts[1] if len(parts) > 1 else name
        # Truncate long names
        if len(short) > 20:
            short = short[:20]
        short_names.append(short)
    merge_suffix = "_".join(short_names)

    # Find the next migration number
    if migrations_dir:
        if not os.path.isdir(migrations_dir):
            raise FileNotFoundError(f"Migrations directory does not exist: {migrations_dir}")
        existing = [
            f
            for f in os.listdir(migrations_dir)
            if f.endswith(".py") and f[0].isdigit()
        ]
        numbers = []
        for f in existing:
            try:
                numbers.append(int(f.split("_")[0]))
            except (ValueError, IndexError):
                pass
        next_number = max(numbers, default=0) + 1
    else:
        # Estimate from branch names
        numbers = []
        for name in branch_names:
            try:
                numbers.append(int(name.split("_")[0]))
            except (ValueError, IndexError):
                pass
        next_number = max(numbers, default=0) + 1

    migration_name = f"{next_number:04d}_merge_{merge_suffix}"

    # Create the Migration instance
    merge_migration = migrations.Migration(migration_name, app_label)
    merge_migration.dependencies = [(app_label, name) for name in branch_names]
    merge_migration.operations = []

    # Render using Django's MigrationWriter
    writer = MigrationWriter(merge_migration)
    content = writer.as_string()

    if migrations_dir and not dry_run:
        file_path = os.path.join(migrations_dir, f"{migration_name}.py")
        try:
            with open(file_path, "w") as f:
                f.write(content)
        except OSError as e:
            raise RuntimeError(f"Failed to write merge migration to {file_path}: {e}")
        return file_path, content

    return migration_name + ".py", content
