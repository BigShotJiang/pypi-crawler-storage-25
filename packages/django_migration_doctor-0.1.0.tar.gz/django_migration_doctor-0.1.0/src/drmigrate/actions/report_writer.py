from __future__ import annotations

import json

from drmigrate import __version__
from drmigrate.core.state import AnalysisResult


def generate_report(results: list[AnalysisResult]) -> dict:
    """Generate a structured report from analysis results."""
    overall_status = "pass"
    for r in results:
        if r.status == "fail":
            overall_status = "fail"
            break
        if r.status == "warn" and overall_status != "fail":
            overall_status = "warn"

    return {
        "tool": "django-migration-doctor",
        "version": __version__,
        "status": overall_status,
        "checks": [r.as_dict() for r in results],
        "summary": {
            "total_checks": len(results),
            "passed": sum(1 for r in results if r.status == "pass"),
            "warnings": sum(1 for r in results if r.status == "warn"),
            "failed": sum(1 for r in results if r.status == "fail"),
        },
    }


def write_report(results: list[AnalysisResult], file_path: str) -> None:
    """Write analysis results to a JSON file."""
    report = generate_report(results)
    try:
        with open(file_path, "w") as f:
            json.dump(report, f, indent=2, default=str)
    except OSError as e:
        raise RuntimeError(f"Failed to write report to {file_path}: {e}")
