from __future__ import annotations

import sys

from django.core.management.base import BaseCommand, CommandError

from drmigrate.analyzers.conflicts import ConflictAnalyzer
from drmigrate.analyzers.lint import LintAnalyzer
from drmigrate.analyzers.safety import SafetyAnalyzer
from drmigrate.core.loader import SmartMigrationLoader
from drmigrate.core.state import AnalysisResult
from drmigrate.formatters import text as text_fmt
from drmigrate.formatters import json as json_fmt
from drmigrate.formatters import github as github_fmt
from drmigrate.conf import get_setting


class Command(BaseCommand):
    help = "Analyze Django migrations for conflicts, safety issues, and anti-patterns"

    def add_arguments(self, parser):
        subparsers = parser.add_subparsers(dest="subcommand")

        # --- check ---
        check_parser = subparsers.add_parser(
            "check", help="Run all checks (CI mode)"
        )
        check_parser.add_argument(
            "--fail-level",
            choices=["warning", "error"],
            default=None,
            help="Minimum severity to cause non-zero exit (default from settings)",
        )
        check_parser.add_argument("--app", help="Filter to a specific app")
        check_parser.add_argument(
            "--format",
            choices=["text", "json", "github"],
            default=None,
            dest="output_format",
        )

        # --- conflicts ---
        conflicts_parser = subparsers.add_parser(
            "conflicts", help="Detect migration conflicts"
        )
        conflicts_parser.add_argument(
            "--apply", action="store_true", help="Generate merge migration"
        )
        conflicts_parser.add_argument("--app", help="Filter to a specific app")
        conflicts_parser.add_argument(
            "--format",
            choices=["text", "json", "github"],
            default=None,
            dest="output_format",
        )

        # --- lint ---
        lint_parser = subparsers.add_parser(
            "lint", help="Run migration lint rules"
        )
        lint_parser.add_argument(
            "--rule", help="Run only a specific rule (e.g., SM001)"
        )
        lint_parser.add_argument(
            "--exclude", nargs="*", default=[], help="Exclude rules"
        )
        lint_parser.add_argument("--app", help="Filter to a specific app")
        lint_parser.add_argument(
            "--format",
            choices=["text", "json", "github"],
            default=None,
            dest="output_format",
        )

        # --- safety ---
        safety_parser = subparsers.add_parser(
            "safety", help="Classify migrations by safety level"
        )
        safety_parser.add_argument("--app", help="Filter to a specific app")
        safety_parser.add_argument(
            "--format",
            choices=["text", "json", "github"],
            default=None,
            dest="output_format",
        )

        # --- status ---
        subparsers.add_parser(
            "status", help="Migration health dashboard"
        )

    def handle(self, *args, **options):
        subcommand = options.get("subcommand") or "status"
        handler = getattr(self, f"handle_{subcommand}", None)

        if handler is None:
            raise CommandError(f"Unknown subcommand: {subcommand}")

        try:
            handler(**options)
        except CommandError:
            raise
        except Exception as e:
            raise CommandError(f"Analysis failed: {e}")

    def _get_loader(self, use_db=False) -> SmartMigrationLoader:
        if use_db:
            from django.db import connections

            database = "default"
            return SmartMigrationLoader(connection=connections[database])
        return SmartMigrationLoader(connection=None)

    def _get_format(self, options: dict) -> str:
        return options.get("output_format") or get_setting("DEFAULT_FORMAT")

    def _output_result(self, result: AnalysisResult, fmt: str):
        if fmt == "json":
            self.stdout.write(json_fmt.format_result(result))
        elif fmt == "github":
            output = github_fmt.format_result(result)
            if output:
                self.stdout.write(output)
        else:
            self.stdout.write(text_fmt.format_result(result, style=self.style))

    def _output_results(self, results: list[AnalysisResult], fmt: str):
        if fmt == "json":
            self.stdout.write(json_fmt.format_results(results))
        elif fmt == "github":
            output = github_fmt.format_results(results)
            if output:
                self.stdout.write(output)
        else:
            for result in results:
                self.stdout.write(
                    text_fmt.format_result(result, style=self.style)
                )

    # --- Subcommand handlers ---

    def handle_status(self, **options):
        loader = self._get_loader()
        results = []

        # Run all analyzers for the dashboard
        results.append(ConflictAnalyzer(loader).analyze())
        results.append(SafetyAnalyzer(loader).analyze())
        results.append(LintAnalyzer(loader).analyze())

        self.stdout.write(
            text_fmt.format_status_dashboard(results, style=self.style)
        )

    def handle_check(self, **options):
        loader = self._get_loader()
        fmt = self._get_format(options)
        fail_level = options.get("fail_level") or get_setting("FAIL_LEVEL")
        app = options.get("app")

        results = []
        results.append(ConflictAnalyzer(loader).analyze(app=app))
        results.append(SafetyAnalyzer(loader).analyze(app=app))
        results.append(LintAnalyzer(loader).analyze(app=app))

        self._output_results(results, fmt)

        # Determine exit code
        should_fail = False
        for result in results:
            for finding in result.findings:
                if fail_level == "warning" and finding.severity in (
                    "warning",
                    "error",
                ):
                    should_fail = True
                elif fail_level == "error" and finding.severity == "error":
                    should_fail = True

        if should_fail:
            sys.exit(1)

    def handle_conflicts(self, **options):
        loader = self._get_loader()
        fmt = self._get_format(options)
        app = options.get("app")

        result = ConflictAnalyzer(loader).analyze(app=app)
        self._output_result(result, fmt)

        if options.get("apply") and result.metadata.get("details"):
            self._apply_merge(loader, result)

    def _apply_merge(self, loader: SmartMigrationLoader, result: AnalysisResult):
        import os

        from django.apps import apps

        from drmigrate.actions.merge_writer import generate_merge_migration

        details = result.metadata.get("details", {})

        for app_label, info in details.items():
            if not info.get("auto_mergeable"):
                self.stderr.write(
                    self.style.ERROR(
                        f"  Cannot auto-merge '{app_label}': manual resolution required"
                    )
                )
                continue

            branches = info.get("branches", {})
            if not branches:
                continue
            branch_names = list(branches.keys())

            # Find the migrations directory
            try:
                app_config = apps.get_app_config(app_label)
                migrations_dir = os.path.join(app_config.path, "migrations")
            except LookupError:
                self.stderr.write(
                    self.style.ERROR(
                        f"  Cannot find app '{app_label}'"
                    )
                )
                continue

            file_path, content = generate_merge_migration(
                app_label, branch_names, migrations_dir
            )
            self.stdout.write(
                self.style.SUCCESS(f"  Created merge migration: {file_path}")
            )

    def handle_lint(self, **options):
        loader = self._get_loader()
        fmt = self._get_format(options)

        result = LintAnalyzer(loader).analyze(
            app=options.get("app"),
            rule=options.get("rule"),
            exclude=options.get("exclude", []),
        )
        self._output_result(result, fmt)

    def handle_safety(self, **options):
        loader = self._get_loader()
        fmt = self._get_format(options)

        result = SafetyAnalyzer(loader).analyze(app=options.get("app"))
        self._output_result(result, fmt)

        # Print summary stats
        if fmt == "text":
            stats = result.metadata.get("stats", {})
            self.stdout.write(
                f"  Summary: {stats.get('safe', 0)} safe, "
                f"{stats.get('risky', 0)} risky, "
                f"{stats.get('unsafe', 0)} unsafe "
                f"(total: {result.metadata.get('total_migrations', 0)})"
            )
            self.stdout.write("")
