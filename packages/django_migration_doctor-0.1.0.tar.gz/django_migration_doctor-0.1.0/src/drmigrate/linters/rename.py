from __future__ import annotations

from django.db.migrations.operations.models import RenameModel
from django.db.migrations.operations.fields import RenameField

from drmigrate.linters.base import BaseLintRule, LintViolation


class FieldModelRename(BaseLintRule):
    """SM003: Flags field and model renames as risky operations."""

    id = "SM003"
    name = "rename-detected"
    description = "Renames can break code references, ORM queries, and serialized data"
    severity = "warning"

    def check(self, migration, migration_key: tuple[str, str]) -> list[LintViolation]:
        violations = []

        for i, op in enumerate(migration.operations):
            if isinstance(op, RenameField):
                violations.append(
                    LintViolation(
                        rule_id=self.id,
                        rule_name=self.name,
                        severity=self.severity,
                        message=(
                            f"RenameField '{op.old_name}' -> '{op.new_name}' on "
                            f"'{op.model_name}' in {migration_key[0]}.{migration_key[1]}"
                        ),
                        migration_key=migration_key,
                        operation_index=i,
                        suggestion=(
                            "Ensure all code references, API serializers, and "
                            "fixtures are updated to use the new name"
                        ),
                    )
                )
            elif isinstance(op, RenameModel):
                violations.append(
                    LintViolation(
                        rule_id=self.id,
                        rule_name=self.name,
                        severity=self.severity,
                        message=(
                            f"RenameModel '{op.old_name}' -> '{op.new_name}' "
                            f"in {migration_key[0]}.{migration_key[1]}"
                        ),
                        migration_key=migration_key,
                        operation_index=i,
                        suggestion=(
                            "Ensure all code references, ContentType records, "
                            "and foreign keys are updated"
                        ),
                    )
                )

        return violations
