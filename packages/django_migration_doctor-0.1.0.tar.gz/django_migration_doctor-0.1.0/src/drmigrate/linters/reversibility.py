from __future__ import annotations

from django.db.migrations.operations.special import RunPython, RunSQL

from drmigrate.linters.base import BaseLintRule, LintViolation


class NonReversibleMigration(BaseLintRule):
    """SM001: Detects RunPython/RunSQL without reverse code."""

    id = "SM001"
    name = "non-reversible-migration"
    description = "Migration contains RunPython or RunSQL without reverse code, making rollback impossible"
    severity = "warning"

    def check(self, migration, migration_key: tuple[str, str]) -> list[LintViolation]:
        violations = []

        for i, op in enumerate(migration.operations):
            if isinstance(op, RunPython) and not op.reversible:
                violations.append(
                    LintViolation(
                        rule_id=self.id,
                        rule_name=self.name,
                        severity=self.severity,
                        message=f"RunPython operation without reverse_code in {migration_key[0]}.{migration_key[1]}",
                        migration_key=migration_key,
                        operation_index=i,
                        suggestion="Add a reverse_code function: RunPython(forward, reverse_code=reverse)",
                    )
                )
            elif isinstance(op, RunSQL) and not op.reversible:
                violations.append(
                    LintViolation(
                        rule_id=self.id,
                        rule_name=self.name,
                        severity=self.severity,
                        message=f"RunSQL operation without reverse_sql in {migration_key[0]}.{migration_key[1]}",
                        migration_key=migration_key,
                        operation_index=i,
                        suggestion="Add reverse_sql: RunSQL(sql, reverse_sql=reverse)",
                    )
                )

        return violations
