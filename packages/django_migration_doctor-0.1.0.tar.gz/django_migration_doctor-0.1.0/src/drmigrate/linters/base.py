from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Literal


@dataclass
class LintViolation:
    rule_id: str
    rule_name: str
    severity: Literal["warning", "error"]
    message: str
    migration_key: tuple[str, str]
    operation_index: int | None = None
    suggestion: str | None = None


class BaseLintRule(ABC):
    """Base class for migration lint rules."""

    id: str
    name: str
    description: str
    severity: Literal["warning", "error"] = "warning"

    @abstractmethod
    def check(self, migration, migration_key: tuple[str, str]) -> list[LintViolation]:
        ...
