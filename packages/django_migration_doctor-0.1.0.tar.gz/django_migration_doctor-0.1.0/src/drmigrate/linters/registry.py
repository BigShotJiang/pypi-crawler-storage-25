from __future__ import annotations

import importlib
import warnings

from drmigrate.conf import get_setting
from drmigrate.linters.base import BaseLintRule
from drmigrate.linters.locking import PotentialTableLock
from drmigrate.linters.nullability import NonNullableWithoutDefault
from drmigrate.linters.rename import FieldModelRename
from drmigrate.linters.reversibility import NonReversibleMigration

BUILTIN_RULES: list[type[BaseLintRule]] = [
    NonReversibleMigration,
    NonNullableWithoutDefault,
    FieldModelRename,
    PotentialTableLock,
]


def get_active_rules() -> list[BaseLintRule]:
    """Return instantiated lint rules, excluding disabled ones and including user-defined ones."""
    disabled = set(get_setting("DISABLED_RULES"))
    extra_rule_paths = get_setting("EXTRA_LINT_RULES")

    rules = []

    # Built-in rules
    for rule_cls in BUILTIN_RULES:
        rule = rule_cls()
        if rule.id not in disabled:
            rules.append(rule)

    # User-defined rules (dotted paths)
    for path in extra_rule_paths:
        try:
            module_path, cls_name = path.rsplit(".", 1)
            module = importlib.import_module(module_path)
            rule_cls = getattr(module, cls_name)
            rule = rule_cls()
            if rule.id not in disabled:
                rules.append(rule)
        except (ImportError, AttributeError, ValueError) as e:
            warnings.warn(
                f"Failed to load lint rule '{path}': {e}",
                stacklevel=2,
            )

    return rules
