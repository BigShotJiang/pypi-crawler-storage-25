from __future__ import annotations

from django.db.migrations.operations.fields import AddField

from drmigrate.linters.base import BaseLintRule, LintViolation


class NonNullableWithoutDefault(BaseLintRule):
    """SM002: Detects AddField with non-nullable field and no default."""

    id = "SM002"
    name = "non-nullable-without-default"
    description = "Adding a non-nullable field without a default will fail on existing rows"
    severity = "error"

    def check(self, migration, migration_key: tuple[str, str]) -> list[LintViolation]:
        violations = []

        for i, op in enumerate(migration.operations):
            if not isinstance(op, AddField):
                continue

            field = op.field
            is_nullable = getattr(field, "null", False)
            has_default = field.has_default()
            is_pk = getattr(field, "primary_key", False)

            # Auto fields (AutoField, BigAutoField) always have implicit defaults
            from django.db.models.fields import AutoField, BigAutoField, SmallAutoField

            is_auto = isinstance(field, (AutoField, BigAutoField, SmallAutoField))

            if not is_nullable and not has_default and not is_pk and not is_auto:
                violations.append(
                    LintViolation(
                        rule_id=self.id,
                        rule_name=self.name,
                        severity=self.severity,
                        message=(
                            f"AddField '{op.name}' on '{op.model_name}' is non-nullable "
                            f"without a default in {migration_key[0]}.{migration_key[1]}"
                        ),
                        migration_key=migration_key,
                        operation_index=i,
                        suggestion=(
                            "Add null=True, or provide a default value, "
                            "or use a two-step migration (add nullable -> backfill -> alter to non-null)"
                        ),
                    )
                )

        return violations
