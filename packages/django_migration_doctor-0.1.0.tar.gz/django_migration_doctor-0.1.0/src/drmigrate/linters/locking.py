from __future__ import annotations

from django.db.migrations.operations.models import AddIndex, RemoveField, DeleteModel

from drmigrate.linters.base import BaseLintRule, LintViolation
from drmigrate.conf import get_setting


class PotentialTableLock(BaseLintRule):
    """SM004: Flags operations that may lock tables in production."""

    id = "SM004"
    name = "potential-table-lock"
    description = "Operations that may cause table locks on large tables in production"
    severity = "warning"

    def check(self, migration, migration_key: tuple[str, str]) -> list[LintViolation]:
        violations = []
        large_tables = get_setting("LARGE_TABLES")

        for i, op in enumerate(migration.operations):
            if isinstance(op, AddIndex):
                # Check if it's a concurrent index (from django.contrib.postgres)
                try:
                    from django.contrib.postgres.operations import AddIndexConcurrently

                    if isinstance(op, AddIndexConcurrently):
                        continue
                except ImportError:
                    pass

                violations.append(
                    LintViolation(
                        rule_id=self.id,
                        rule_name=self.name,
                        severity=self.severity,
                        message=(
                            f"AddIndex on '{op.model_name}' may lock the table "
                            f"in {migration_key[0]}.{migration_key[1]}"
                        ),
                        migration_key=migration_key,
                        operation_index=i,
                        suggestion=(
                            "For PostgreSQL, use AddIndexConcurrently from "
                            "django.contrib.postgres.operations to avoid locking"
                        ),
                    )
                )

            # Flag destructive ops on known large tables
            if large_tables:
                model_name = getattr(op, "model_name", None)
                if model_name and model_name.lower() in [
                    t.lower() for t in large_tables
                ]:
                    if isinstance(op, (RemoveField, DeleteModel)):
                        violations.append(
                            LintViolation(
                                rule_id=self.id,
                                rule_name=self.name,
                                severity="error",
                                message=(
                                    f"{type(op).__name__} on large table '{model_name}' "
                                    f"in {migration_key[0]}.{migration_key[1]}"
                                ),
                                migration_key=migration_key,
                                operation_index=i,
                                suggestion=(
                                    "This table is configured as large. "
                                    "Consider running this migration during low-traffic periods"
                                ),
                            )
                        )

        return violations
