from django.conf import settings

DEFAULTS = {
    "DISABLED_RULES": [],
    "EXTRA_LINT_RULES": [],
    "LARGE_TABLES": [],
    "FAIL_LEVEL": "error",
    "DEFAULT_FORMAT": "text",
}


def get_setting(name):
    user_settings = getattr(settings, "MIGRATION_DOCTOR", {})
    return user_settings.get(name, DEFAULTS[name])
