from __future__ import annotations

from django.db import migrations as django_migrations
from django.db.migrations import operations as ops

from drmigrate.core.state import OperationClassification, SafetyLevel


class OperationInspector:
    """Classifies migration operations by safety level."""

    def classify(
        self, operation, migration_key: tuple[str, str]
    ) -> OperationClassification:
        op_type = type(operation).__name__
        field_name = getattr(operation, "name", None)
        if hasattr(operation, "model_name") and not field_name:
            field_name = getattr(operation, "model_name", None)

        level, reason = self._classify_operation(operation)

        return OperationClassification(
            operation_type=op_type,
            level=level,
            reason=reason,
            migration_key=migration_key,
            field_name=field_name,
        )

    def classify_migration(
        self, migration, migration_key: tuple[str, str]
    ) -> list[OperationClassification]:
        return [
            self.classify(op, migration_key) for op in migration.operations
        ]

    def overall_safety(
        self, classifications: list[OperationClassification]
    ) -> SafetyLevel:
        if not classifications:
            return SafetyLevel.SAFE
        worst = SafetyLevel.SAFE
        for c in classifications:
            if c.level > worst:
                worst = c.level
        return worst

    def _classify_operation(self, operation) -> tuple[SafetyLevel, str]:
        # Safe: additive operations
        if isinstance(operation, ops.CreateModel):
            return SafetyLevel.SAFE, "Creates a new table"

        if isinstance(operation, ops.AddField):
            return self._classify_add_field(operation)

        if isinstance(operation, ops.AddIndex):
            return SafetyLevel.SAFE, "Adds an index"

        if isinstance(operation, ops.AddConstraint):
            return SafetyLevel.SAFE, "Adds a constraint"

        if isinstance(operation, ops.AlterModelOptions):
            return SafetyLevel.SAFE, "Changes model Meta options only"

        if isinstance(operation, ops.AlterModelManagers):
            return SafetyLevel.SAFE, "Changes model managers only"

        # Risky: modifications
        if isinstance(operation, ops.AlterField):
            return SafetyLevel.RISKY, "Alters an existing field (may change type or constraints)"

        if isinstance(operation, ops.RenameField):
            return SafetyLevel.RISKY, "Renames a field (may break code references)"

        if isinstance(operation, ops.RenameModel):
            return SafetyLevel.RISKY, "Renames a model (may break code references)"

        if isinstance(operation, ops.AlterModelTable):
            return SafetyLevel.RISKY, "Changes the database table name"

        if isinstance(operation, ops.RemoveIndex):
            return SafetyLevel.RISKY, "Removes an index (may degrade query performance)"

        if isinstance(operation, ops.RemoveConstraint):
            return SafetyLevel.RISKY, "Removes a constraint (may weaken data integrity)"

        if isinstance(operation, ops.AlterUniqueTogether):
            return SafetyLevel.RISKY, "Alters unique_together constraints"

        if isinstance(operation, ops.AlterIndexTogether):
            return SafetyLevel.RISKY, "Alters index_together (deprecated)"

        if isinstance(operation, ops.AlterOrderWithRespectTo):
            return SafetyLevel.RISKY, "Alters ordering (adds/modifies _order field)"

        # Unsafe: destructive or opaque operations
        if isinstance(operation, ops.DeleteModel):
            return SafetyLevel.UNSAFE, "Drops an entire table"

        if isinstance(operation, ops.RemoveField):
            return SafetyLevel.UNSAFE, "Drops a column (data loss)"

        if isinstance(operation, ops.RunPython):
            return SafetyLevel.UNSAFE, "Executes arbitrary Python code"

        if isinstance(operation, ops.RunSQL):
            return SafetyLevel.UNSAFE, "Executes raw SQL"

        # Fallback: unknown operations are unsafe until proven otherwise
        return SafetyLevel.UNSAFE, f"Unknown operation: {type(operation).__name__} — review manually"

    def _classify_add_field(self, operation) -> tuple[SafetyLevel, str]:
        field = operation.field
        is_nullable = getattr(field, "null", False)
        has_default = (
            field.has_default()
            if hasattr(field, "has_default") and callable(field.has_default)
            else getattr(field, "default", None) is not None
        )
        is_pk = getattr(field, "primary_key", False)

        if is_pk:
            return SafetyLevel.SAFE, "Adds a primary key field"

        if is_nullable or has_default:
            return SafetyLevel.SAFE, "Adds a field (nullable or has default)"

        return SafetyLevel.RISKY, "Adds a non-nullable field without a default"
