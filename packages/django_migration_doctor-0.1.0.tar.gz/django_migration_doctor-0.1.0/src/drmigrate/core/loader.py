from __future__ import annotations

from django.db.migrations.loader import MigrationLoader as DjangoMigrationLoader
from django.db.migrations.recorder import MigrationRecorder


class SmartMigrationLoader:
    """Facade around Django's MigrationLoader for read-only analysis."""

    def __init__(self, connection=None):
        self._connection = connection
        self._loader = DjangoMigrationLoader(
            connection,
            replace_migrations=True,
        )

    @property
    def graph(self):
        return self._loader.graph

    def get_conflicts(self) -> dict[str, list[str]]:
        return self._loader.detect_conflicts()

    def get_migration(self, app_label: str, name: str):
        return self._loader.get_migration(app_label, name)

    def get_disk_migrations(self) -> dict[tuple[str, str], object]:
        return dict(self._loader.disk_migrations)

    def get_applied_migrations(self) -> set[tuple[str, str]] | None:
        if self._connection is None:
            return None
        recorder = MigrationRecorder(self._connection)
        return recorder.applied_migrations()

    def get_app_labels(self) -> set[str]:
        return {app for app, _name in self._loader.disk_migrations}

    def get_migrations_for_app(self, app_label: str) -> list[tuple[str, str]]:
        return sorted(
            (key for key in self._loader.disk_migrations if key[0] == app_label),
            key=lambda k: k[1],
        )

    def get_leaf_nodes(self) -> set[tuple[str, str]]:
        return set(self._loader.graph.leaf_nodes())

    def get_leaf_nodes_for_app(self, app_label: str) -> list[tuple[str, str]]:
        return [
            node
            for node in self._loader.graph.leaf_nodes()
            if node[0] == app_label
        ]

    def get_project_state(self, nodes=None):
        return self._loader.project_state(nodes=nodes)
