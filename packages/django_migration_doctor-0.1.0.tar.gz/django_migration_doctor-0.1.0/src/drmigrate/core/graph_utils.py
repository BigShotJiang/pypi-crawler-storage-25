from __future__ import annotations

from collections import defaultdict


def find_common_ancestors(graph, node_a: tuple[str, str], node_b: tuple[str, str]) -> list[tuple[str, str]]:
    """Find common ancestors of two nodes in the migration graph."""
    ancestors_a = _get_all_ancestors(graph, node_a)
    ancestors_b = _get_all_ancestors(graph, node_b)
    common = ancestors_a & ancestors_b
    if not common:
        return []
    # Return only the "deepest" common ancestors (those with no children in common)
    result = []
    for node in common:
        children = set(graph.node_map[node].children)
        child_keys = {child.key for child in children}
        if not (child_keys & common):
            result.append(node)
    return sorted(result)


def _get_all_ancestors(graph, node: tuple[str, str]) -> set[tuple[str, str]]:
    """Get all ancestors of a node by walking parents."""
    visited = set()
    stack = [node]
    while stack:
        current = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        if current in graph.node_map:
            for parent in graph.node_map[current].parents:
                stack.append(parent.key)
    visited.discard(node)
    return visited


def find_cross_app_dependencies(graph) -> dict[str, set[str]]:
    """Build an app-level dependency graph from cross-app migration edges."""
    app_deps = defaultdict(set)
    for node_key, node in graph.node_map.items():
        app = node_key[0]
        for parent in node.parents:
            parent_app = parent.key[0]
            if parent_app != app:
                app_deps[app].add(parent_app)
    return dict(app_deps)


def find_circular_app_dependencies(graph) -> list[list[str]]:
    """Find strongly connected components (cycles) in app-level dependencies using Tarjan's algorithm."""
    app_deps = find_cross_app_dependencies(graph)

    # Collect all apps
    all_apps = set(app_deps.keys())
    for deps in app_deps.values():
        all_apps.update(deps)

    # Tarjan's SCC
    index_counter = [0]
    stack = []
    on_stack = set()
    index = {}
    lowlink = {}
    sccs = []

    def strongconnect(app):
        index[app] = index_counter[0]
        lowlink[app] = index_counter[0]
        index_counter[0] += 1
        stack.append(app)
        on_stack.add(app)

        for dep in app_deps.get(app, set()):
            if dep not in index:
                strongconnect(dep)
                lowlink[app] = min(lowlink[app], lowlink[dep])
            elif dep in on_stack:
                lowlink[app] = min(lowlink[app], index[dep])

        if lowlink[app] == index[app]:
            scc = []
            while True:
                w = stack.pop()
                on_stack.discard(w)
                scc.append(w)
                if w == app:
                    break
            if len(scc) > 1:
                sccs.append(sorted(scc))

    for app in sorted(all_apps):
        if app not in index:
            strongconnect(app)

    return sccs
