from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal


class SafetyLevel(Enum):
    SAFE = 0
    RISKY = 1
    UNSAFE = 2

    def __gt__(self, other):
        return self.value > other.value

    def __ge__(self, other):
        return self.value >= other.value

    def __lt__(self, other):
        return self.value < other.value

    def __le__(self, other):
        return self.value <= other.value

    @property
    def label(self) -> str:
        return self.name.lower()


@dataclass
class Finding:
    severity: Literal["info", "warning", "error"]
    code: str
    message: str
    app_label: str
    migration_name: str | None = None
    suggestion: str | None = None
    fix_available: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
            "app_label": self.app_label,
            "migration_name": self.migration_name,
            "suggestion": self.suggestion,
            "fix_available": self.fix_available,
        }


@dataclass
class AnalysisResult:
    analyzer: str
    status: Literal["pass", "warn", "fail"]
    findings: list[Finding] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "analyzer": self.analyzer,
            "status": self.status,
            "findings": [f.as_dict() for f in self.findings],
            "metadata": self.metadata,
        }


@dataclass
class OperationClassification:
    operation_type: str
    level: SafetyLevel
    reason: str
    migration_key: tuple[str, str]
    field_name: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "operation_type": self.operation_type,
            "level": self.level.label,
            "reason": self.reason,
            "app_label": self.migration_key[0],
            "migration_name": self.migration_key[1],
            "field_name": self.field_name,
        }


@dataclass
class MigrationSnapshot:
    """Serializable snapshot of migration state for an environment."""

    environment: str
    applied: dict[str, list[str]] = field(default_factory=dict)
    on_disk: dict[str, list[str]] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "environment": self.environment,
            "applied": self.applied,
            "on_disk": self.on_disk,
        }
