from __future__ import annotations

import json

from drmigrate.actions.report_writer import generate_report
from drmigrate.core.state import AnalysisResult


def format_result(result: AnalysisResult) -> str:
    """Format a single AnalysisResult as JSON."""
    return json.dumps(result.as_dict(), indent=2)


def format_results(results: list[AnalysisResult]) -> str:
    """Format multiple AnalysisResults as a JSON report."""
    report = generate_report(results)
    return json.dumps(report, indent=2)
