from __future__ import annotations

from drmigrate.core.state import AnalysisResult


SEVERITY_SYMBOLS = {
    "error": "ERROR",
    "warning": "WARN ",
    "info": "INFO ",
}


def format_result(result: AnalysisResult, style=None) -> str:
    """Format an AnalysisResult for terminal output."""
    lines = []

    # Header
    status_label = {
        "pass": "PASS",
        "warn": "WARN",
        "fail": "FAIL",
    }[result.status]

    header = f"[{status_label}] {result.analyzer}"
    if style:
        if result.status == "pass":
            header = style.SUCCESS(header)
        elif result.status == "warn":
            header = style.WARNING(header)
        else:
            header = style.ERROR(header)
    lines.append(header)
    lines.append("-" * 60)

    if not result.findings:
        msg = "  No issues found."
        if style:
            msg = style.SUCCESS(msg)
        lines.append(msg)
    else:
        for finding in result.findings:
            symbol = SEVERITY_SYMBOLS.get(finding.severity, "     ")
            location = finding.app_label
            if finding.migration_name:
                location += f".{finding.migration_name}"

            line = f"  [{symbol}] {finding.code}: {finding.message}"
            if style:
                if finding.severity == "error":
                    line = style.ERROR(line)
                elif finding.severity == "warning":
                    line = style.WARNING(line)
            lines.append(line)

            if finding.suggestion:
                suggestion = f"         -> {finding.suggestion}"
                if style:
                    suggestion = style.NOTICE(suggestion)
                lines.append(suggestion)

    lines.append("")
    return "\n".join(lines)


def format_status_dashboard(results: list[AnalysisResult], style=None) -> str:
    """Format a summary dashboard of all analysis results."""
    lines = []
    lines.append("Migration Health Dashboard")
    lines.append("=" * 60)
    lines.append("")

    total_findings = 0
    errors = 0
    warnings = 0

    for result in results:
        status_label = {
            "pass": "PASS",
            "warn": "WARN",
            "fail": "FAIL",
        }[result.status]

        line = f"  {result.analyzer:<20} [{status_label}]  {len(result.findings)} issue(s)"
        if style:
            if result.status == "pass":
                line = style.SUCCESS(line)
            elif result.status == "warn":
                line = style.WARNING(line)
            else:
                line = style.ERROR(line)
        lines.append(line)

        total_findings += len(result.findings)
        errors += sum(1 for f in result.findings if f.severity == "error")
        warnings += sum(1 for f in result.findings if f.severity == "warning")

    lines.append("")
    lines.append("-" * 60)
    summary = f"  Total: {total_findings} issue(s) ({errors} error(s), {warnings} warning(s))"
    if style:
        if errors > 0:
            summary = style.ERROR(summary)
        elif warnings > 0:
            summary = style.WARNING(summary)
        else:
            summary = style.SUCCESS(summary)
    lines.append(summary)
    lines.append("")

    return "\n".join(lines)
