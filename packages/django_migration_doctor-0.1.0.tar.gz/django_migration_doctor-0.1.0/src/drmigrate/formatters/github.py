from __future__ import annotations

from drmigrate.core.state import AnalysisResult


def format_result(result: AnalysisResult) -> str:
    """Format AnalysisResult as GitHub Actions annotations."""
    lines = []

    for finding in result.findings:
        level = "error" if finding.severity == "error" else "warning"
        location = finding.app_label
        if finding.migration_name:
            location += f"/{finding.migration_name}"

        # GitHub annotation format
        message = f"{finding.code}: {finding.message}"
        if finding.suggestion:
            message += f" ({finding.suggestion})"

        lines.append(f"::{level} ::{message}")

    return "\n".join(lines)


def format_results(results: list[AnalysisResult]) -> str:
    """Format multiple results as GitHub Actions annotations."""
    parts = []
    for result in results:
        formatted = format_result(result)
        if formatted:
            parts.append(formatted)
    return "\n".join(parts)
