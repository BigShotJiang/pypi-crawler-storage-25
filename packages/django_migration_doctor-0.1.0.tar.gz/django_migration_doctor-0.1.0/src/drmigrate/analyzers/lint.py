from __future__ import annotations

from drmigrate.analyzers.base import BaseAnalyzer
from drmigrate.core.state import AnalysisResult, Finding
from drmigrate.linters.registry import get_active_rules


class LintAnalyzer(BaseAnalyzer):
    """Runs all active lint rules against migrations."""

    name = "lint"

    def analyze(self, **options) -> AnalysisResult:
        app_filter = options.get("app")
        rule_filter = options.get("rule")
        exclude_rules = set(options.get("exclude", []))

        rules = get_active_rules()
        if rule_filter:
            rules = [r for r in rules if r.id == rule_filter]
        if exclude_rules:
            rules = [r for r in rules if r.id not in exclude_rules]

        if not rules:
            return AnalysisResult(
                analyzer=self.name,
                status="pass",
                findings=[],
                metadata={"rules_checked": 0, "violations": 0},
            )

        findings = []
        violation_count = 0
        disk_migrations = self.loader.get_disk_migrations()

        for (app_label, mig_name), migration in sorted(disk_migrations.items()):
            if app_filter and app_label != app_filter:
                continue

            for rule in rules:
                violations = rule.check(migration, (app_label, mig_name))
                for v in violations:
                    violation_count += 1
                    findings.append(
                        Finding(
                            severity=v.severity,
                            code=v.rule_id,
                            message=v.message,
                            app_label=app_label,
                            migration_name=mig_name,
                            suggestion=v.suggestion,
                        )
                    )

        has_errors = any(f.severity == "error" for f in findings)
        has_warnings = any(f.severity == "warning" for f in findings)

        return AnalysisResult(
            analyzer=self.name,
            status="fail" if has_errors else "warn" if has_warnings else "pass",
            findings=findings,
            metadata={
                "rules_checked": len(rules),
                "violations": violation_count,
                "rules": [{"id": r.id, "name": r.name} for r in rules],
            },
        )
