from __future__ import annotations

from drmigrate.analyzers.base import BaseAnalyzer
from drmigrate.core.operation_inspector import OperationInspector
from drmigrate.core.state import AnalysisResult, Finding, SafetyLevel


class SafetyAnalyzer(BaseAnalyzer):
    """Classifies all migrations by safety level."""

    name = "safety"

    def analyze(self, **options) -> AnalysisResult:
        app_filter = options.get("app")
        inspector = OperationInspector()
        findings = []
        stats = {"safe": 0, "risky": 0, "unsafe": 0}
        all_classifications = []

        disk_migrations = self.loader.get_disk_migrations()

        for (app_label, mig_name), migration in sorted(disk_migrations.items()):
            if app_filter and app_label != app_filter:
                continue

            classifications = inspector.classify_migration(
                migration, (app_label, mig_name)
            )
            overall = inspector.overall_safety(classifications)
            all_classifications.extend(classifications)
            stats[overall.label] += 1

            if overall == SafetyLevel.UNSAFE:
                ops_desc = ", ".join(
                    c.operation_type for c in classifications if c.level == SafetyLevel.UNSAFE
                )
                findings.append(
                    Finding(
                        severity="error",
                        code="SAFETY_UNSAFE",
                        message=f"{app_label}.{mig_name}: UNSAFE operations ({ops_desc})",
                        app_label=app_label,
                        migration_name=mig_name,
                        suggestion="Review carefully before applying to production",
                    )
                )
            elif overall == SafetyLevel.RISKY:
                ops_desc = ", ".join(
                    c.operation_type for c in classifications if c.level == SafetyLevel.RISKY
                )
                findings.append(
                    Finding(
                        severity="warning",
                        code="SAFETY_RISKY",
                        message=f"{app_label}.{mig_name}: RISKY operations ({ops_desc})",
                        app_label=app_label,
                        migration_name=mig_name,
                        suggestion="Verify these operations won't cause issues in production",
                    )
                )

        has_errors = any(f.severity == "error" for f in findings)
        has_warnings = any(f.severity == "warning" for f in findings)

        return AnalysisResult(
            analyzer=self.name,
            status="fail" if has_errors else "warn" if has_warnings else "pass",
            findings=findings,
            metadata={
                "stats": stats,
                "total_migrations": sum(stats.values()),
                "classifications": [c.as_dict() for c in all_classifications],
            },
        )
