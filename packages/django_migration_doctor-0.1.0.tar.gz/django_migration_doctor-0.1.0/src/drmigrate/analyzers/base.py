from __future__ import annotations

from abc import ABC, abstractmethod

from drmigrate.core.loader import SmartMigrationLoader
from drmigrate.core.state import AnalysisResult


class BaseAnalyzer(ABC):
    """Base class for all migration analyzers."""

    name: str = "base"

    def __init__(self, loader: SmartMigrationLoader):
        self.loader = loader

    @abstractmethod
    def analyze(self, **options) -> AnalysisResult:
        ...
