from __future__ import annotations

from drmigrate.analyzers.base import BaseAnalyzer
from drmigrate.core.graph_utils import find_common_ancestors
from drmigrate.core.operation_inspector import OperationInspector
from drmigrate.core.state import AnalysisResult, Finding, SafetyLevel


class ConflictAnalyzer(BaseAnalyzer):
    """Detects migration conflicts and analyzes merge safety."""

    name = "conflicts"

    def analyze(self, **options) -> AnalysisResult:
        app_filter = options.get("app")
        conflicts = self.loader.get_conflicts()

        if app_filter:
            conflicts = {
                k: v for k, v in conflicts.items() if k == app_filter
            }

        if not conflicts:
            return AnalysisResult(
                analyzer=self.name,
                status="pass",
                findings=[],
                metadata={"conflict_count": 0},
            )

        findings = []
        inspector = OperationInspector()
        conflict_details = {}

        for app_label, migration_names in conflicts.items():
            branch_safety = {}

            for mig_name in migration_names:
                migration = self.loader.get_migration(app_label, mig_name)
                classifications = inspector.classify_migration(
                    migration, (app_label, mig_name)
                )
                overall = inspector.overall_safety(classifications)
                branch_safety[mig_name] = {
                    "safety": overall,
                    "operations": [c.as_dict() for c in classifications],
                }

            # Determine if auto-merge is safe
            worst_safety = SafetyLevel.SAFE
            for info in branch_safety.values():
                if info["safety"] > worst_safety:
                    worst_safety = info["safety"]

            # Check for field conflicts (same field modified in multiple branches)
            field_ops = {}
            has_field_conflict = False
            for mig_name, info in branch_safety.items():
                for op in info["operations"]:
                    if op["field_name"]:
                        key = (op["field_name"], op["operation_type"])
                        if key in field_ops and field_ops[key] != mig_name:
                            has_field_conflict = True
                        field_ops[key] = mig_name

            if has_field_conflict:
                severity = "error"
                status_note = "conflicting operations on the same field"
                suggestion = "Manual resolution required: multiple branches modify the same field"
            elif worst_safety == SafetyLevel.UNSAFE:
                severity = "error"
                status_note = "contains unsafe operations"
                suggestion = "Manual review required before merging (contains data migrations or raw SQL)"
            elif worst_safety == SafetyLevel.RISKY:
                severity = "warning"
                status_note = "contains risky operations"
                suggestion = "Review operations carefully, then run: drmigrate conflicts --apply"
            else:
                severity = "info"
                status_note = "all operations are additive"
                suggestion = "Safe to auto-merge. Run: drmigrate conflicts --apply"

            branch_names = ", ".join(migration_names)
            findings.append(
                Finding(
                    severity=severity,
                    code="CONFLICT",
                    message=f"Conflicting migrations in '{app_label}': {branch_names} ({status_note})",
                    app_label=app_label,
                    suggestion=suggestion,
                    fix_available=(not has_field_conflict),
                )
            )

            # Find common ancestors for metadata
            if len(migration_names) >= 2:
                ancestors = find_common_ancestors(
                    self.loader.graph,
                    (app_label, migration_names[0]),
                    (app_label, migration_names[1]),
                )
            else:
                ancestors = []

            conflict_details[app_label] = {
                "branches": branch_safety,
                "overall_safety": worst_safety.label,
                "has_field_conflict": has_field_conflict,
                "common_ancestors": [
                    f"{a[0]}.{a[1]}" for a in ancestors
                ],
                "auto_mergeable": not has_field_conflict and worst_safety <= SafetyLevel.RISKY,
            }

        has_errors = any(f.severity == "error" for f in findings)
        has_warnings = any(f.severity == "warning" for f in findings)

        return AnalysisResult(
            analyzer=self.name,
            status="fail" if has_errors else "warn" if has_warnings else "pass",
            findings=findings,
            metadata={
                "conflict_count": len(conflicts),
                "details": conflict_details,
            },
        )
