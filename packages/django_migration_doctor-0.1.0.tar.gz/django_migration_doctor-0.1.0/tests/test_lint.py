import pytest
from django.db import models
from django.db.migrations.operations.special import RunPython, RunSQL
from django.db.migrations.operations.fields import AddField, RenameField
from django.db.migrations.operations.models import RenameModel, AddIndex

from drmigrate.linters.reversibility import NonReversibleMigration
from drmigrate.linters.nullability import NonNullableWithoutDefault
from drmigrate.linters.rename import FieldModelRename
from drmigrate.linters.locking import PotentialTableLock


KEY = ("testapp", "0001_test")


def make_migration(operations):
    return type("FakeMigration", (), {"operations": operations})()


class TestNonReversibleMigration:
    def setup_method(self):
        self.rule = NonReversibleMigration()

    def test_run_python_without_reverse(self):
        migration = make_migration([RunPython(lambda a, s: None)])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 1
        assert violations[0].rule_id == "SM001"

    def test_run_python_with_reverse(self):
        migration = make_migration([
            RunPython(lambda a, s: None, reverse_code=lambda a, s: None)
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 0

    def test_run_sql_without_reverse(self):
        migration = make_migration([RunSQL("CREATE TABLE t (id int)")])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 1
        assert violations[0].rule_id == "SM001"

    def test_run_sql_with_reverse(self):
        migration = make_migration([
            RunSQL("CREATE TABLE t (id int)", reverse_sql="DROP TABLE t")
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 0


class TestNonNullableWithoutDefault:
    def setup_method(self):
        self.rule = NonNullableWithoutDefault()

    def test_nonnullable_without_default(self):
        migration = make_migration([
            AddField(
                model_name="mymodel",
                name="required",
                field=models.CharField(max_length=100),
            )
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 1
        assert violations[0].rule_id == "SM002"

    def test_nullable_field_passes(self):
        migration = make_migration([
            AddField(
                model_name="mymodel",
                name="optional",
                field=models.CharField(max_length=100, null=True),
            )
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 0

    def test_field_with_default_passes(self):
        migration = make_migration([
            AddField(
                model_name="mymodel",
                name="status",
                field=models.CharField(max_length=20, default="active"),
            )
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 0

    def test_primary_key_passes(self):
        migration = make_migration([
            AddField(
                model_name="mymodel",
                name="id",
                field=models.BigAutoField(primary_key=True),
            )
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 0


class TestFieldModelRename:
    def setup_method(self):
        self.rule = FieldModelRename()

    def test_rename_field_detected(self):
        migration = make_migration([
            RenameField(
                model_name="mymodel",
                old_name="name",
                new_name="full_name",
            )
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 1
        assert violations[0].rule_id == "SM003"

    def test_rename_model_detected(self):
        migration = make_migration([
            RenameModel(old_name="OldModel", new_name="NewModel")
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 1
        assert violations[0].rule_id == "SM003"

    def test_no_rename_passes(self):
        migration = make_migration([
            AddField(
                model_name="mymodel",
                name="field",
                field=models.CharField(max_length=100, null=True),
            )
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 0


class TestPotentialTableLock:
    def setup_method(self):
        self.rule = PotentialTableLock()

    def test_add_index_flagged(self):
        migration = make_migration([
            AddIndex(
                model_name="mymodel",
                index=models.Index(fields=["name"], name="idx_name"),
            )
        ])
        violations = self.rule.check(migration, KEY)
        assert len(violations) == 1
        assert violations[0].rule_id == "SM004"
