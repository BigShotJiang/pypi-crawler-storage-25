import pytest
from unittest.mock import MagicMock

from drmigrate.core.graph_utils import (
    find_cross_app_dependencies,
    find_circular_app_dependencies,
)


def _build_mock_graph(edges):
    """Build a mock MigrationGraph from a dict of {node: [parent_nodes]}.

    Each node is a (app_label, migration_name) tuple.
    """
    graph = MagicMock()
    node_map = {}

    # Create all nodes first
    all_nodes = set()
    for node, parents in edges.items():
        all_nodes.add(node)
        all_nodes.update(parents)

    for node in all_nodes:
        mock_node = MagicMock()
        mock_node.key = node
        mock_node.parents = []
        mock_node.children = []
        node_map[node] = mock_node

    # Wire up parents
    for node, parents in edges.items():
        for parent in parents:
            parent_mock = MagicMock()
            parent_mock.key = parent
            node_map[node].parents.append(parent_mock)

            child_mock = MagicMock()
            child_mock.key = node
            node_map[parent].children.append(child_mock)

    graph.node_map = node_map
    return graph


class TestCrossAppDependencies:
    def test_no_cross_deps(self):
        graph = _build_mock_graph({
            ("app1", "0002"): [("app1", "0001")],
        })
        deps = find_cross_app_dependencies(graph)
        assert deps == {}

    def test_cross_app_dep(self):
        graph = _build_mock_graph({
            ("app2", "0001"): [("app1", "0001")],
        })
        deps = find_cross_app_dependencies(graph)
        assert "app2" in deps
        assert "app1" in deps["app2"]


class TestCircularDependencies:
    def test_no_cycle(self):
        graph = _build_mock_graph({
            ("app2", "0001"): [("app1", "0001")],
        })
        cycles = find_circular_app_dependencies(graph)
        assert cycles == []

    def test_simple_cycle(self):
        graph = _build_mock_graph({
            ("app1", "0002"): [("app2", "0001")],
            ("app2", "0002"): [("app1", "0001")],
        })
        cycles = find_circular_app_dependencies(graph)
        assert len(cycles) == 1
        assert set(cycles[0]) == {"app1", "app2"}

    def test_no_false_positive(self):
        graph = _build_mock_graph({
            ("app2", "0001"): [("app1", "0001")],
            ("app3", "0001"): [("app2", "0001")],
        })
        cycles = find_circular_app_dependencies(graph)
        assert cycles == []
