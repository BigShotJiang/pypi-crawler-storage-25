import pytest
from django.db import migrations, models
from django.db.migrations.operations.special import RunPython, RunSQL

from drmigrate.core.operation_inspector import OperationInspector
from drmigrate.core.state import SafetyLevel


@pytest.fixture
def inspector():
    return OperationInspector()


KEY = ("testapp", "0001_test")


class TestOperationClassification:
    def test_create_model_is_safe(self, inspector):
        op = migrations.CreateModel(
            name="TestModel",
            fields=[
                ("id", models.BigAutoField(primary_key=True)),
                ("name", models.CharField(max_length=100)),
            ],
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.SAFE

    def test_add_nullable_field_is_safe(self, inspector):
        op = migrations.AddField(
            model_name="testmodel",
            name="age",
            field=models.IntegerField(null=True),
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.SAFE

    def test_add_field_with_default_is_safe(self, inspector):
        op = migrations.AddField(
            model_name="testmodel",
            name="status",
            field=models.CharField(max_length=20, default="active"),
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.SAFE

    def test_add_nonnullable_field_without_default_is_risky(self, inspector):
        op = migrations.AddField(
            model_name="testmodel",
            name="required_field",
            field=models.CharField(max_length=100),
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.RISKY

    def test_alter_field_is_risky(self, inspector):
        op = migrations.AlterField(
            model_name="testmodel",
            name="name",
            field=models.CharField(max_length=200),
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.RISKY

    def test_rename_field_is_risky(self, inspector):
        op = migrations.RenameField(
            model_name="testmodel",
            old_name="name",
            new_name="full_name",
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.RISKY

    def test_delete_model_is_unsafe(self, inspector):
        op = migrations.DeleteModel(name="TestModel")
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.UNSAFE

    def test_remove_field_is_unsafe(self, inspector):
        op = migrations.RemoveField(
            model_name="testmodel",
            name="old_field",
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.UNSAFE

    def test_run_python_is_unsafe(self, inspector):
        op = RunPython(lambda apps, schema: None)
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.UNSAFE

    def test_run_sql_is_unsafe(self, inspector):
        op = RunSQL("SELECT 1")
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.UNSAFE

    def test_add_index_is_safe(self, inspector):
        op = migrations.AddIndex(
            model_name="testmodel",
            index=models.Index(fields=["name"], name="idx_name"),
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.SAFE

    def test_remove_index_is_risky(self, inspector):
        op = migrations.RemoveIndex(
            model_name="testmodel",
            name="idx_name",
        )
        result = inspector.classify(op, KEY)
        assert result.level == SafetyLevel.RISKY


class TestOverallSafety:
    def test_empty_is_safe(self, inspector):
        assert inspector.overall_safety([]) == SafetyLevel.SAFE

    def test_worst_wins(self, inspector):
        migration = type(
            "FakeMigration",
            (),
            {
                "operations": [
                    migrations.CreateModel(
                        name="M",
                        fields=[("id", models.BigAutoField(primary_key=True))],
                    ),
                    migrations.RemoveField(
                        model_name="other", name="field"
                    ),
                ]
            },
        )()
        classifications = inspector.classify_migration(migration, KEY)
        assert inspector.overall_safety(classifications) == SafetyLevel.UNSAFE


class TestSafetyLevelComparison:
    def test_unsafe_gt_risky(self):
        assert SafetyLevel.UNSAFE > SafetyLevel.RISKY

    def test_risky_gt_safe(self):
        assert SafetyLevel.RISKY > SafetyLevel.SAFE

    def test_safe_not_gt_safe(self):
        assert not (SafetyLevel.SAFE > SafetyLevel.SAFE)
