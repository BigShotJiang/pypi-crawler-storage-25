import pytest
from unittest.mock import MagicMock, patch

from django.db import migrations, models

from drmigrate.analyzers.conflicts import ConflictAnalyzer
from drmigrate.core.state import SafetyLevel


def _make_migration(name, app_label, operations):
    m = migrations.Migration(name, app_label)
    m.operations = operations
    return m


class TestConflictAnalyzer:
    def _make_loader(self, conflicts, migration_map):
        loader = MagicMock()
        loader.get_conflicts.return_value = conflicts
        loader.get_migration.side_effect = lambda app, name: migration_map[(app, name)]

        # Mock graph for common ancestors
        mock_graph = MagicMock()
        mock_graph.node_map = {}
        loader.graph = mock_graph

        return loader

    def test_no_conflicts(self):
        loader = self._make_loader({}, {})
        analyzer = ConflictAnalyzer(loader)
        result = analyzer.analyze()

        assert result.status == "pass"
        assert len(result.findings) == 0
        assert result.metadata["conflict_count"] == 0

    def test_safe_conflict_detected(self):
        mig_a = _make_migration("0002_add_age", "myapp", [
            migrations.AddField(
                model_name="user",
                name="age",
                field=models.IntegerField(null=True),
            )
        ])
        mig_b = _make_migration("0002_add_email", "myapp", [
            migrations.AddField(
                model_name="user",
                name="email",
                field=models.EmailField(null=True),
            )
        ])

        loader = self._make_loader(
            {"myapp": ["0002_add_age", "0002_add_email"]},
            {("myapp", "0002_add_age"): mig_a, ("myapp", "0002_add_email"): mig_b},
        )
        analyzer = ConflictAnalyzer(loader)
        result = analyzer.analyze()

        assert result.metadata["conflict_count"] == 1
        assert len(result.findings) == 1
        # Both are safe additive operations, different fields
        assert result.findings[0].severity == "info"
        assert result.findings[0].fix_available is True

    def test_unsafe_conflict_detected(self):
        mig_a = _make_migration("0002_add_age", "myapp", [
            migrations.AddField(
                model_name="user",
                name="age",
                field=models.IntegerField(null=True),
            )
        ])
        mig_b = _make_migration("0002_data_migration", "myapp", [
            migrations.RunPython(lambda apps, schema: None)
        ])

        loader = self._make_loader(
            {"myapp": ["0002_add_age", "0002_data_migration"]},
            {("myapp", "0002_add_age"): mig_a, ("myapp", "0002_data_migration"): mig_b},
        )
        analyzer = ConflictAnalyzer(loader)
        result = analyzer.analyze()

        assert result.status == "fail"
        assert result.findings[0].severity == "error"

    def test_app_filter(self):
        mig_a = _make_migration("0002_a", "app1", [
            migrations.AddField(
                model_name="m", name="f",
                field=models.IntegerField(null=True),
            )
        ])
        mig_b = _make_migration("0002_b", "app1", [
            migrations.AddField(
                model_name="m", name="g",
                field=models.IntegerField(null=True),
            )
        ])

        loader = self._make_loader(
            {"app1": ["0002_a", "0002_b"], "app2": ["0002_x", "0002_y"]},
            {("app1", "0002_a"): mig_a, ("app1", "0002_b"): mig_b},
        )
        analyzer = ConflictAnalyzer(loader)
        result = analyzer.analyze(app="app1")

        assert result.metadata["conflict_count"] == 1
