import pytest
from io import StringIO
from unittest.mock import patch, MagicMock

from django.core.management import call_command

from drmigrate.core.state import AnalysisResult, Finding


class TestSmartMigrateCommand:
    def test_status_runs(self):
        out = StringIO()
        with patch(
            "drmigrate.management.commands.drmigrate.SmartMigrationLoader"
        ) as MockLoader:
            loader_instance = MockLoader.return_value
            loader_instance.get_conflicts.return_value = {}
            loader_instance.get_disk_migrations.return_value = {}
            loader_instance.graph = MagicMock()

            call_command("drmigrate", stdout=out)

        output = out.getvalue()
        assert "Migration Health Dashboard" in output

    def test_check_no_issues(self):
        out = StringIO()
        with patch(
            "drmigrate.management.commands.drmigrate.SmartMigrationLoader"
        ) as MockLoader:
            loader_instance = MockLoader.return_value
            loader_instance.get_conflicts.return_value = {}
            loader_instance.get_disk_migrations.return_value = {}
            loader_instance.graph = MagicMock()

            call_command("drmigrate", "check", stdout=out)

        output = out.getvalue()
        assert "PASS" in output

    def test_conflicts_no_issues(self):
        out = StringIO()
        with patch(
            "drmigrate.management.commands.drmigrate.SmartMigrationLoader"
        ) as MockLoader:
            loader_instance = MockLoader.return_value
            loader_instance.get_conflicts.return_value = {}
            loader_instance.graph = MagicMock()

            call_command("drmigrate", "conflicts", stdout=out)

        output = out.getvalue()
        assert "PASS" in output

    def test_lint_no_issues(self):
        out = StringIO()
        with patch(
            "drmigrate.management.commands.drmigrate.SmartMigrationLoader"
        ) as MockLoader:
            loader_instance = MockLoader.return_value
            loader_instance.get_disk_migrations.return_value = {}

            call_command("drmigrate", "lint", stdout=out)

        output = out.getvalue()
        assert "PASS" in output

    def test_safety_no_issues(self):
        out = StringIO()
        with patch(
            "drmigrate.management.commands.drmigrate.SmartMigrationLoader"
        ) as MockLoader:
            loader_instance = MockLoader.return_value
            loader_instance.get_disk_migrations.return_value = {}

            call_command("drmigrate", "safety", stdout=out)

        output = out.getvalue()
        assert "PASS" in output

    def test_json_output_format(self):
        out = StringIO()
        with patch(
            "drmigrate.management.commands.drmigrate.SmartMigrationLoader"
        ) as MockLoader:
            loader_instance = MockLoader.return_value
            loader_instance.get_conflicts.return_value = {}
            loader_instance.graph = MagicMock()

            call_command(
                "drmigrate", "conflicts",
                output_format="json", stdout=out
            )

        output = out.getvalue()
        assert '"analyzer"' in output
        assert '"conflicts"' in output
