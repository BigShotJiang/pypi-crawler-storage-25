"""
mlpilot/ai/analyst.py
AIAnalyst — Natural language data analysis using local-first LLMs.
Uses Ollama (local) via its API, with Groq as a cloud fallback.
Implements 'Review before Run' for execution safety.
"""

from __future__ import annotations

import os
import re
import sys
from typing import Any, Dict, List, Optional, Union

import pandas as pd

from mlpilot.utils.display import print_step, print_success, print_warning
from mlpilot.utils.imports import get_ds_workspace

# Lazy loading handles for built-in AI
_MODEL_CACHE = {} 


class AIAnalyst:
    """
    AI-powered data analyst companion.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        model: str = "auto",
        engine: str = "auto",
        groq_api_key: Optional[str] = None,
        verbose: bool = False,
    ):
        self.df = df
        self.verbose = verbose
        self.groq_api_key = groq_api_key or os.environ.get("GROQ_API_KEY")
        self.gemini_api_key = os.environ.get("GOOGLE_API_KEY")
        
        # 1. Engine Detection
        if engine == "auto":
            if self._is_ollama_alive():
                self.engine = "ollama"
            else:
                # ZERO-CONFIG: No need for warnings, just use the built-in brain
                self.engine = "builtin"
        else:
            self.engine = engine

        # 2. Model Detection
        if self.engine == "builtin":
            self.model = "Qwen/Qwen2.5-0.5B-Instruct"
        elif model == "auto" and self.engine == "ollama":
            self.model = self._detect_best_ollama_model()
        elif model == "auto" and self.engine == "gemini":
            self.model = "gemini-1.5-flash"
        elif model == "auto" and self.engine == "groq":
            self.model = "llama3-70b-8192"
        else:
            self.model = model

    def ask(self, query: str, auto_run: bool = False) -> Any:
        """
        Ask a natural language question about the data.
        Returns the result of the generated code execution.
        """
        if self.verbose:
            print_step(f"AI Analyst ({self.engine}): Thinking about '{query}'...", "🧠")

        # 1. Build Prompt
        prompt = self._build_prompt(query)

        # 2. Get Code
        code = self._get_llm_code(prompt)
        if not code:
            print_warning("AI could not generate valid code.")
            return None

        # 3. Review before Run
        if not auto_run:
            if not self._user_approval(code):
                print_step("Execution cancelled by user.", "🚫")
                return None

        # 4. Execute
        if self.verbose:
            print_step("Executing analysis...", "⚡")
        
        return self._execute_code(code)

    def _build_prompt(self, query: str) -> str:
        try:
            head_str = self.df.head(3).to_markdown()
        except (ImportError, ModuleNotFoundError):
            head_str = str(self.df.head(3))

        summary = {
            "columns": list(self.df.columns),
            "dtypes": self.df.dtypes.astype(str).to_dict(),
            "head": head_str,
            "shape": self.df.shape
        }
        
        prompt = f"""
You are a world-class Python Data Analyst. Your goal is to write code using pandas to answer questions about a dataframe named 'df'.

DATASET SUMMARY:
- Shape: {summary['shape']}
- Columns: {summary['columns']}
- Sample Data:
{summary['head']}

USER QUESTION:
"{query}"

RULES:
1. Only return the Python code itself. 
2. Do not include markdown '```python' blocks.
3. Use the dataframe variable 'df'.
4. Ensure the last line of the code results in the final answer (or stores it in a variable 'result').
5. Do not perform destructive operations (dropping columns, unless asked).
6. FOR PLOTTING: Always use 'plt.figure(figsize=(10, 6))' before plotting. Use 'sns' or 'plt' functions. Ensure labels and titles are added.
7. Return only the final answer or visual.

CODE:
"""
        return prompt

    def _get_llm_code(self, prompt: str) -> Optional[str]:
        if self.engine == "builtin":
            return self._call_builtin_llm(prompt)
            
        elif self.engine == "ollama":
            try:
                import ollama
                response = ollama.generate(model=self.model, prompt=prompt)
                code = response['response']
                return self._clean_code(code)
            except Exception as e:
                print_error(f"Ollama error: {e}")
                return None
        
        elif self.engine == "gemini":
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.gemini_api_key)
                model = genai.GenerativeModel(self.model)
                response = model.generate_content(prompt)
                return self._clean_code(response.text)
            except Exception as e:
                if self.verbose:
                    print_error(f"Gemini error: {e}")
                # Fallback to builtin if cloud fails
                return self._call_builtin_llm(prompt)

        elif self.engine == "groq":
            try:
                import groq
                client = groq.Groq(api_key=self.groq_api_key)
                completion = client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}]
                )
                code = completion.choices[0].message.content
                return self._clean_code(code)
            except Exception as e:
                print_error(f"Groq error: {e}")
                return None
        
        return None

    def _call_builtin_llm(self, prompt: str) -> Optional[str]:
        """Zero-Config local engine using Transformers."""
        global _MODEL_CACHE
        try:
            import torch
            import transformers
            from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
            
            # Total silence for transformers and HF Hub
            transformers.logging.set_verbosity_error()
            os.environ["TOKENIZERS_PARALLELISM"] = "false"
            os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
            
            from huggingface_hub import logging as hf_logging
            hf_logging.set_verbosity_error()
            
            if "pipeline" not in _MODEL_CACHE:
                if self.verbose:
                    print_step("Initializing built-in AI engine...", "📦")
                
                device = "cuda" if torch.cuda.is_available() else "cpu"
                model_id = "Qwen/Qwen2.5-0.5B-Instruct"
                
                tokenizer = AutoTokenizer.from_pretrained(model_id)
                model = AutoModelForCausalLM.from_pretrained(
                    model_id, 
                    dtype=torch.float32 if device == "cpu" else torch.float16,
                    low_cpu_mem_usage=True
                ).to(device)
                
                _MODEL_CACHE["pipeline"] = pipeline(
                    "text-generation", 
                    model=model, 
                    tokenizer=tokenizer, 
                    device=device
                )

            pipe = _MODEL_CACHE["pipeline"]
            messages = [
                {"role": "system", "content": "You are a Python data analyst. Output ONLY clean Python code. No markdown. No explanations."},
                {"role": "user", "content": prompt},
            ]
            
            p = pipe.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            outputs = pipe(p, max_new_tokens=256, do_sample=False, pad_token_id=pipe.tokenizer.eos_token_id)
            raw = outputs[0]["generated_text"][len(p):]
            return self._clean_code(raw)
        except Exception as e:
            if self.verbose:
                print_error(f"Built-in engine failed: {e}")
            return None

    def _clean_code(self, code: str) -> str:
        # Remove markdown ticks if present
        code = re.sub(r"```python\n?", "", code)
        code = re.sub(r"```\n?", "", code)
        return code.strip()

    def _user_approval(self, code: str) -> bool:
        """Display code with Rich and ask for confirmation."""
        from rich.console import Console
        from rich.panel import Panel
        from rich.syntax import Syntax
        
        console = Console()
        syntax = Syntax(code, "python", theme="monokai", line_numbers=True)
        console.print("\n")
        console.print(Panel(syntax, title="AI Proposed Analysis", subtitle="[y] Run / [n] Cancel", border_style="cyan"))
        
        ans = input("  Run this code? (y/n): ").lower().strip()
        return ans == 'y'

    def _execute_code(self, code: str) -> Any:
        # 1. Prepare Universal Workspace
        workspace = get_ds_workspace(df=self.df.copy())
        
        try:
            # 2. Execution
            exec(code, {}, workspace)
            
            # 3. Intelligent Result Capture
            res = workspace.get("result")
            
            # If AI didn't explicitly set 'result', try to infer it from common vars
            if res is None:
                # We look for 'df_result', 'ans', 'output', etc.
                for candidate in ["df_result", "ans", "output", "summary"]:
                    if candidate in workspace:
                        res = workspace[candidate]
                        break

            # 4. Silent Professional Presentation
            if res is not None:
                print("\n" + "─"*50)
                print(f"  ANSWER: {res}")
                print("─"*50 + "\n")
            
            # 5. Visual Support (Auto-show plots if they were created)
            if workspace.get("plt") and len(workspace["plt"].get_fignums()) > 0:
                workspace["plt"].show()
            
            return res
        except Exception as e:
            if self.verbose:
                print_error(f"Analysis failed: {e}")
            return None

    def _is_ollama_alive(self) -> bool:
        try:
            import ollama
            ollama.list()
            return True
        except Exception:
            return False

    def _detect_best_ollama_model(self) -> str:
        try:
            import ollama
            models = [m['name'] for m in ollama.list()['models']]
            priority = ["llama3:latest", "llama3", "mistral:latest", "mistral", "phi3"]
            for p in priority:
                if p in models:
                    return p
            return models[0] if models else "llama3"
        except Exception:
            return "llama3"


    def _guided_setup_prompt(self):
        """Hidden by default in v0.2.0+. Only for manual debugging."""
        pass


def print_error(msg: str):
    from mlpilot.utils.display import print_error as pe
    pe(msg)
