#!/usr/bin/env python3
"""
GrapeRoot Pro — AST-based graph builder.

Replaces regex symbol extraction with tree-sitter AST parsing for:
- TypeScript / TSX  (.ts, .tsx)
- JavaScript / JSX  (.js, .jsx)
- Python            (.py)

Falls back to regex for unsupported extensions.
Everything else (file walking, keyword extraction, edge parsing, output format)
is identical to the original graph_builder.py so results are directly comparable.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path

# ── Tree-sitter setup ──────────────────────────────────────────────────────────
try:
    import tree_sitter_typescript as _tsts
    import tree_sitter_javascript as _tsjs
    import tree_sitter_python as _tspy
    from tree_sitter import Language, Parser, Node as TSNode

    _LANG_TS  = Language(_tsts.language_typescript())
    _LANG_TSX = Language(_tsts.language_tsx())
    _LANG_JS  = Language(_tsjs.language())
    _LANG_PY  = Language(_tspy.language())
    _AST_AVAILABLE = True
except Exception as e:
    print(f"[warn] tree-sitter not available, falling back to regex: {e}")
    _AST_AVAILABLE = False

# Go support — optional, loaded separately so TS absence doesn't block Go
_LANG_GO = None
try:
    import tree_sitter_go as _tsgo
    if not _AST_AVAILABLE:
        from tree_sitter import Language, Parser, Node as TSNode  # type: ignore[assignment]
    _LANG_GO = Language(_tsgo.language())
except Exception:
    pass


SKIP_DIRS = {
    ".git", ".beads", ".beads-hooks", "node_modules", "vendor",
    "dist", "build", ".next", ".idea", ".vscode", "__pycache__",
    "venv", ".venv", ".dual-graph",
}

MAX_FILE_BYTES   = 300_000
MAX_CONTENT_CHARS = 24_000
SYMBOL_EXTS = {".ts", ".tsx", ".js", ".jsx", ".py", ".php", ".go"}


# ── Data model (identical to original) ────────────────────────────────────────

@dataclass
class Node:
    id: str
    kind: str
    path: str
    ext: str
    size: int
    keywords: list[str]
    content: str = ""
    summary: str = ""
    file_hash: str = ""
    symbol_type: str = ""
    name: str = ""
    line_start: int = 0
    line_end: int = 0
    body_hash: str = ""
    confidence: str = ""
    exported: bool = False

    def as_dict(self) -> dict:
        d = {
            "id": self.id,
            "kind": self.kind,
            "path": self.path,
            "ext": self.ext,
            "size": self.size,
            "keywords": self.keywords,
        }
        if self.kind == "file":
            d["content"]   = self.content
            d["summary"]   = self.summary
            d["file_hash"] = self.file_hash
        else:
            d["symbol_type"] = self.symbol_type
            d["name"]        = self.name
            d["line_start"]  = self.line_start
            d["line_end"]    = self.line_end
            d["body_hash"]   = self.body_hash
            d["confidence"]  = self.confidence
            d["exported"]    = self.exported
        return d


# ── Helpers ────────────────────────────────────────────────────────────────────

def _split_camel(name: str) -> list[str]:
    parts = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", name)
    parts = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", parts)
    return [p.lower() for p in parts.split() if len(p) >= 3]


def _name_keywords(name: str) -> list[str]:
    tokens: list[str] = []
    seen: set[str] = set()
    def add(w: str) -> None:
        w = w.lower().strip("_")
        if len(w) >= 3 and w not in seen:
            seen.add(w); tokens.append(w)
    add(name)
    for p in _split_camel(name): add(p)
    for p in name.split("_"): add(p)
    return tokens[:10]


def _body_hash(lines: list[str], start: int, end: int) -> str:
    body = "\n".join(lines[start:end + 1])
    return hashlib.md5(body.encode()).hexdigest()[:8]


def _node_text(node: "TSNode", src: bytes) -> str:
    return src[node.start_byte:node.end_byte].decode("utf-8", errors="ignore")


# ── AST: TypeScript / JavaScript symbol extraction ────────────────────────────

def _ts_is_exported(node: "TSNode") -> bool:
    """Check if a TS/JS node is exported (has export keyword as sibling or parent)."""
    parent = node.parent
    if parent is None:
        return False
    # export statement wraps the declaration
    if parent.type in ("export_statement", "export_clause"):
        return True
    # export default
    if parent.type == "export_default_declaration":
        return True
    return False


def _classify_ts_name(name: str, exported: bool) -> tuple[str, str]:
    if re.match(r"^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)$", name):
        return "api_route", "high"
    if name.startswith("use") and len(name) > 3 and name[3].isupper():
        return "hook", "high"
    if exported and name[0].isupper():
        return "use_case", "medium"
    if exported:
        return "use_case", "high"
    return "utility", "medium"


def extract_symbols_ts_ast(content: str, file_path: str, ext: str) -> list[dict]:
    """AST-based symbol extraction for TypeScript/JavaScript."""
    if not _AST_AVAILABLE:
        return []

    src = content.encode("utf-8", errors="ignore")
    lines = content.splitlines()

    lang = _LANG_TSX if ext == ".tsx" else (_LANG_JS if ext in {".js", ".jsx"} else _LANG_TS)
    parser = Parser(lang)
    tree = parser.parse(src)

    symbols: list[dict] = []
    seen: set[str] = set()

    def add_sym(name: str, line_start: int, line_end: int, sym_type: str, confidence: str, exported: bool) -> None:
        if not name or name in seen:
            return
        seen.add(name)
        symbols.append({
            "id":          f"{file_path}::{name}",
            "name":        name,
            "symbol_type": sym_type,
            "line_start":  line_start,
            "line_end":    line_end,
            "body_hash":   _body_hash(lines, line_start, line_end),
            "confidence":  confidence,
            "exported":    exported,
            "keywords":    _name_keywords(name),
        })

    def walk(node: "TSNode") -> None:
        t = node.type

        # function_declaration / method_definition
        if t in ("function_declaration", "generator_function_declaration"):
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, src)
                exported = _ts_is_exported(node)
                sym_type, conf = _classify_ts_name(name, exported)
                add_sym(name, node.start_point[0], node.end_point[0], sym_type, conf, exported)

        # arrow / const function: lexical_declaration → variable_declarator → arrow_function
        elif t == "lexical_declaration":
            exported = _ts_is_exported(node)
            for child in node.children:
                if child.type == "variable_declarator":
                    name_node = child.child_by_field_name("name")
                    val_node  = child.child_by_field_name("value")
                    if name_node and val_node and val_node.type in ("arrow_function", "function"):
                        name = _node_text(name_node, src)
                        sym_type, conf = _classify_ts_name(name, exported)
                        add_sym(name, node.start_point[0], node.end_point[0], sym_type, conf, exported)

        # class_declaration
        elif t == "class_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, src)
                exported = _ts_is_exported(node)
                add_sym(name, node.start_point[0], node.end_point[0], "model", "high", exported)

        # interface_declaration / type_alias_declaration
        elif t in ("interface_declaration", "type_alias_declaration"):
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, src)
                exported = _ts_is_exported(node)
                add_sym(name, node.start_point[0], node.end_point[0], "model", "high", exported)

        # enum_declaration
        elif t == "enum_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, src)
                exported = _ts_is_exported(node)
                add_sym(name, node.start_point[0], node.end_point[0], "model", "high", exported)

        # method_definition (class methods)
        elif t == "method_definition":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, src)
                if not name.startswith("#"):  # skip private fields
                    add_sym(name, node.start_point[0], node.end_point[0], "use_case", "medium", False)

        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return symbols


# ── AST: Python symbol extraction ─────────────────────────────────────────────

def extract_symbols_py_ast(content: str, file_path: str) -> list[dict]:
    """AST-based symbol extraction for Python using tree-sitter."""
    if not _AST_AVAILABLE:
        return []

    src = content.encode("utf-8", errors="ignore")
    lines = content.splitlines()
    parser = Parser(_LANG_PY)
    tree = parser.parse(src)

    symbols: list[dict] = []
    seen: set[str] = set()

    # Find route-decorated functions
    route_deco_lines: set[int] = set()
    route_pat = re.compile(
        r"@(?:app|router|blueprint)\.(?:get|post|put|delete|patch)\s*\(",
        re.IGNORECASE,
    )
    for m in route_pat.finditer(content):
        route_deco_lines.add(content[:m.start()].count("\n"))

    def add_sym(name: str, line_start: int, line_end: int, sym_type: str, confidence: str) -> None:
        if not name or name in seen:
            return
        if name.startswith("_") or name.startswith("test_"):
            return
        seen.add(name)
        symbols.append({
            "id":          f"{file_path}::{name}",
            "name":        name,
            "symbol_type": sym_type,
            "line_start":  line_start,
            "line_end":    line_end,
            "body_hash":   _body_hash(lines, line_start, line_end),
            "confidence":  confidence,
            "exported":    not name.startswith("_"),
            "keywords":    _name_keywords(name),
        })

    def walk(node: "TSNode") -> None:
        t = node.type

        if t in ("function_definition", "decorated_definition"):
            # For decorated_definition, get the inner function/class
            target = node
            if t == "decorated_definition":
                for child in node.children:
                    if child.type in ("function_definition", "class_definition"):
                        target = child
                        break

            if target.type == "function_definition":
                name_node = target.child_by_field_name("name")
                if name_node:
                    name = _node_text(name_node, src)
                    is_route = any(abs(node.start_point[0] - dl) <= 3 for dl in route_deco_lines)
                    sym_type = "api_route" if is_route else "use_case"
                    add_sym(name, node.start_point[0], node.end_point[0], sym_type, "high")

        elif t == "class_definition":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, src)
                add_sym(name, node.start_point[0], node.end_point[0], "model", "high")

        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return symbols


# ── AST: Go symbol extraction ─────────────────────────────────────────────────

def extract_symbols_go_ast(content: str, file_path: str) -> list[dict]:
    """AST-based symbol extraction for Go using tree-sitter."""
    if not _LANG_GO:
        return []

    src = content.encode("utf-8", errors="ignore")
    lines = content.splitlines()
    parser = Parser(_LANG_GO)
    tree = parser.parse(src)

    symbols: list[dict] = []
    seen: set[str] = set()

    def add_sym(name: str, line_start: int, line_end: int, sym_type: str,
                confidence: str, exported: bool) -> None:
        if not name or name in seen:
            return
        seen.add(name)
        symbols.append({
            "id":          f"{file_path}::{name}",
            "name":        name,
            "symbol_type": sym_type,
            "line_start":  line_start,
            "line_end":    line_end,
            "body_hash":   _body_hash(lines, line_start, line_end),
            "confidence":  confidence,
            "exported":    exported,
            "keywords":    _name_keywords(name),
        })

    def walk(node: "TSNode") -> None:
        t = node.type

        if t == "function_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, src)
                exported = bool(name) and name[0].isupper()
                add_sym(name, node.start_point[0], node.end_point[0],
                        "use_case", "high", exported)

        elif t == "method_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _node_text(name_node, src)
                exported = bool(name) and name[0].isupper()
                add_sym(name, node.start_point[0], node.end_point[0],
                        "use_case", "high", exported)

        elif t == "type_declaration":
            # Go: type Foo struct { ... }  or  type Bar interface { ... }
            for child in node.children:
                if child.type == "type_spec":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        name = _node_text(name_node, src)
                        if name and name[0].isupper():
                            type_child = child.child_by_field_name("type")
                            sym_type = "model"
                            if type_child and type_child.type == "interface_type":
                                sym_type = "use_case"
                            add_sym(name, node.start_point[0], node.end_point[0],
                                    sym_type, "high", True)

        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return symbols


def extract_imports_go_ast(content: str, file_path: str) -> list[dict]:
    """Extract Go imports using tree-sitter AST."""
    if not _LANG_GO:
        return []

    src = content.encode("utf-8", errors="ignore")
    parser = Parser(_LANG_GO)
    tree = parser.parse(src)
    edges: list[dict] = []

    def walk(node: "TSNode") -> None:
        if node.type == "import_spec":
            # import_spec has a path child (interpreted_string_literal)
            for child in node.children:
                if child.type == "interpreted_string_literal":
                    path = _node_text(child, src).strip('"')
                    if path:
                        edges.append({"from": file_path, "to": path, "rel": "imports"})
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return edges


# ── Import extraction (AST-aware) ──────────────────────────────────────────────

def extract_imports_ts_ast(content: str, file_path: str, ext: str) -> list[dict]:
    """Extract imports using AST — more accurate than regex for complex cases."""
    if not _AST_AVAILABLE:
        return []

    src = content.encode("utf-8", errors="ignore")
    lang = _LANG_TSX if ext == ".tsx" else (_LANG_JS if ext in {".js", ".jsx"} else _LANG_TS)
    parser = Parser(lang)
    tree = parser.parse(src)
    edges: list[dict] = []

    def walk(node: "TSNode") -> None:
        t = node.type
        if t == "import_statement":
            src_node = node.child_by_field_name("source")
            if src_node:
                path = _node_text(src_node, src).strip("'\"")
                edges.append({"from": file_path, "to": path, "rel": "imports"})
        elif t == "call_expression":
            fn = node.child_by_field_name("function")
            args = node.child_by_field_name("arguments")
            if fn and _node_text(fn, src) == "require" and args:
                for child in args.children:
                    if child.type == "string":
                        path = _node_text(child, src).strip("'\"")
                        edges.append({"from": file_path, "to": path, "rel": "requires"})
        # dynamic import()
        elif t == "await_expression":
            pass
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return edges


def extract_imports_py_ast(content: str, file_path: str) -> list[dict]:
    """Extract Python imports using tree-sitter AST."""
    if not _AST_AVAILABLE:
        return []

    src = content.encode("utf-8", errors="ignore")
    parser = Parser(_LANG_PY)
    tree = parser.parse(src)
    edges: list[dict] = []

    def walk(node: "TSNode") -> None:
        t = node.type
        if t == "import_statement":
            for child in node.children:
                if child.type in ("dotted_name", "aliased_import"):
                    name = _node_text(child, src).split(" as ")[0].strip()
                    edges.append({"from": file_path, "to": name, "rel": "imports"})
        elif t == "import_from_statement":
            mod_node = node.child_by_field_name("module_name")
            if mod_node:
                edges.append({"from": file_path, "to": _node_text(mod_node, src), "rel": "imports"})
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return edges


# ── Dispatch: AST or fallback to regex ────────────────────────────────────────

def _extract_symbols(content: str, file_id: str, ext: str) -> list[dict]:
    if _AST_AVAILABLE:
        if ext in {".ts", ".tsx", ".js", ".jsx"}:
            return extract_symbols_ts_ast(content, file_id, ext)
        if ext == ".py":
            return extract_symbols_py_ast(content, file_id)
    if _LANG_GO and ext == ".go":
        return extract_symbols_go_ast(content, file_id)
    # Fallback: import from original graph_builder
    try:
        from src.graperoot.graph_builder import (
            extract_symbols_ts, extract_symbols_py, extract_symbols_php,
        )
        if ext in {".ts", ".tsx", ".js", ".jsx"}:
            return extract_symbols_ts(content, file_id)
        if ext == ".py":
            return extract_symbols_py(content, file_id)
    except ImportError:
        pass
    return []


def _extract_imports(content: str, file_id: str, ext: str, root: Path) -> list[dict]:
    """AST import extraction with regex fallback for unsupported types."""
    if _AST_AVAILABLE:
        if ext in {".ts", ".tsx", ".js", ".jsx"}:
            return extract_imports_ts_ast(content, file_id, ext)
        if ext == ".py":
            return extract_imports_py_ast(content, file_id)
    if _LANG_GO and ext == ".go":
        return extract_imports_go_ast(content, file_id)
    # Fallback: regex
    return _parse_relations_regex(file_id, content)


def _parse_relations_regex(file_id: str, text: str) -> list[dict]:
    edges: list[dict] = []
    for m in re.finditer(r'import\s+\(?\s*"([^"]+)"', text):
        edges.append({"from": file_id, "to": m.group(1), "rel": "imports"})
    for m in re.finditer(r'import\s+.*?\s+from\s+[\'"]([^\'"]+)[\'"]', text):
        edges.append({"from": file_id, "to": m.group(1), "rel": "imports"})
    for m in re.finditer(r'require\([\'"]([^\'"]+)[\'"]\)', text):
        edges.append({"from": file_id, "to": m.group(1), "rel": "requires"})
    for m in re.finditer(r'^\s*import\s+([a-zA-Z0-9_\.]+)', text, re.MULTILINE):
        edges.append({"from": file_id, "to": m.group(1), "rel": "imports"})
    for m in re.finditer(r'^\s*from\s+([a-zA-Z0-9_\.]+)\s+import\s+', text, re.MULTILINE):
        edges.append({"from": file_id, "to": m.group(1), "rel": "imports"})
    return edges


# ── Reuse unchanged helpers from original ─────────────────────────────────────

def _make_summary(content: str, path: str, ext: str) -> str:
    lines = content.splitlines()
    lead = ""
    if ext == ".py":
        m = re.search(r'^\s*(?:\'\'\'|""")([^\'\"]{8,200}?)(?:\'\'\'|""")', content, re.DOTALL)
        if m: lead = " ".join(m.group(1).split())[:120]
    elif ext in {".ts", ".tsx", ".js", ".jsx"}:
        m = re.match(r"\s*/\*\*?\s*(.*?)\*/", content, re.DOTALL)
        if m: lead = " ".join(m.group(1).replace("*", "").split())[:120]
    if not lead:
        for line in lines[:5]:
            s = line.strip().lstrip("#").lstrip("//").strip()
            if len(s) >= 10: lead = s[:120]; break

    names: list[str] = []
    if ext == ".py":
        for m2 in re.finditer(r"^(?:async\s+)?def\s+([A-Za-z_]\w*)|^class\s+([A-Za-z_]\w*)", content, re.MULTILINE):
            name = m2.group(1) or m2.group(2)
            if name and not name.startswith("_") and name not in names:
                names.append(name)
                if len(names) >= 5: break
    elif ext in {".ts", ".tsx", ".js", ".jsx"}:
        for m2 in re.finditer(r"(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_]\w*)|(?:export\s+)?class\s+([A-Za-z_]\w*)", content, re.MULTILINE):
            name = m2.group(1) or m2.group(2)
            if name and name not in names:
                names.append(name)
                if len(names) >= 5: break

    parts = [p for p in re.split(r"[/\\]", path) if p and p != "."]
    domain_parts = [p for p in parts if p.lower() not in {"src", "lib", "app", "pkg", "main", "index"}]
    domain = " ".join(domain_parts[-2:]).replace("_", " ").replace("-", " ") if domain_parts else parts[-1] if parts else ""
    domain = re.sub(r"\.\w+$", "", domain).strip()

    parts_out: list[str] = []
    if lead:
        parts_out.append(lead.rstrip(".") + ".")
    elif domain:
        parts_out.append(f"Handles {domain}.")
    if names:
        n_label = "functions/classes" if len(names) > 1 else "function"
        names_str = ", ".join(names[:4])
        if len(names) >= 5: names_str += ", ..."
        parts_out.append(f"Contains {len(names)} {n_label}: {names_str}.")
    return " ".join(parts_out)[:250]


def extract_keywords(content: str, ext: str) -> list[str]:
    tokens: list[str] = []
    seen: set[str] = set()

    def add(word: str) -> None:
        w = word.lower().strip("_")
        if len(w) >= 3 and w not in seen:
            seen.add(w); tokens.append(w)

    def add_name(name: str) -> None:
        add(name)
        for part in _split_camel(name): add(part)

    route_pat = re.compile(
        r"""(?:app|router|r|mux|api)\s*[.\@]\s*(get|post|put|delete|patch|handle|handlefunc)\s*\(\s*['"/]([^'")\s]+)""",
        re.IGNORECASE,
    )
    for m in route_pat.finditer(content):
        add(m.group(1).upper())
        for seg in m.group(2).strip("/").split("/"):
            seg = re.sub(r"[{}:<>]", "", seg)
            if seg: add(seg)

    if ext in {".ts", ".tsx", ".js", ".jsx"}:
        for m in re.finditer(r"export\s+(?:default\s+)?(?:async\s+)?(?:function|class|const|type|interface|enum)\s+([A-Za-z_]\w*)", content):
            add_name(m.group(1))
        for m in re.finditer(r"export\s*\{([^}]+)\}", content):
            for name in re.split(r"[,\s]+", m.group(1)):
                name = name.strip()
                if name: add_name(name)
    if ext == ".py":
        for m in re.finditer(r"^(?:async\s+)?def\s+([A-Za-z_]\w*)|^class\s+([A-Za-z_]\w*)", content, re.MULTILINE):
            name = m.group(1) or m.group(2)
            if name and not name.startswith("_"):
                add_name(name)
                for part in name.split("_"): add(part)
    if ext == ".go":
        for m in re.finditer(r"^func\s+(?:\([^)]+\)\s+)?([A-Za-z_]\w*)\s*\(", content, re.MULTILINE):
            add_name(m.group(1))
        for m in re.finditer(r"^type\s+([A-Za-z_]\w*)\s+(?:struct|interface)", content, re.MULTILINE):
            add_name(m.group(1))

    return tokens[:80]


# ── File walk ──────────────────────────────────────────────────────────────────

def should_scan(path: Path) -> bool:
    posix = path.as_posix()
    if "/venv/" in posix or "/.venv/" in posix:
        return False
    return path.suffix.lower() in {
        ".go", ".py", ".js", ".jsx", ".ts", ".tsx", ".swift",
        ".json", ".yaml", ".yml", ".md",
    }


def walk_files(root: Path) -> list[Path]:
    files: list[Path] = []
    root_resolved = root.resolve()
    for dirpath, dirnames, filenames in os.walk(root, followlinks=True):
        base = Path(dirpath)
        def _keep_dir(d: str) -> bool:
            if d in SKIP_DIRS: return False
            p = base / d
            try:
                if p.is_symlink() and not p.resolve().is_relative_to(root_resolved):
                    return False
            except Exception:
                return False
            return True
        dirnames[:] = [d for d in dirnames if _keep_dir(d)]
        for name in filenames:
            path = base / name
            try:
                if should_scan(path) and path.is_file():
                    files.append(path)
            except (PermissionError, OSError):
                pass
    return files


def rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return os.path.relpath(path.resolve(), root.resolve())


def dedupe_edges(edges: list[dict]) -> list[dict]:
    seen: set[tuple] = set()
    out: list[dict] = []
    for e in edges:
        key = (e["from"], e["to"], e["rel"])
        if key not in seen:
            seen.add(key)
            out.append(e)
    return out


# ── Structural peer edges ──────────────────────────────────────────────────────
# Convention-based pairs: files in the same directory that serve structurally
# related roles but are never import-linked (so they get zero import edges and
# the graph deprioritizes them).  Works across all languages — detection is
# purely by filename stem, not extension.
#
# Each entry is a frozenset of two stem patterns (regex).  When both match
# files in the same directory, a bidirectional "structural_peer" edge is added.
_PEER_PAIRS: list[tuple[re.Pattern, re.Pattern]] = [
    # routing ↔ middleware / guards / interceptors
    (re.compile(r"^routes?$",       re.I), re.compile(r"^middlewares?$",    re.I)),
    (re.compile(r"^route$",         re.I), re.compile(r"^middlewares?$",    re.I)),
    (re.compile(r"^router$",        re.I), re.compile(r"^middlewares?$",    re.I)),
    (re.compile(r"^routes?$",       re.I), re.compile(r"^guards?$",         re.I)),
    (re.compile(r"^routes?$",       re.I), re.compile(r"^interceptors?$",   re.I)),
    # controller / handler ↔ service / validator / guard
    (re.compile(r"^controllers?$",  re.I), re.compile(r"^services?$",       re.I)),
    (re.compile(r"^handlers?$",     re.I), re.compile(r"^middlewares?$",    re.I)),
    (re.compile(r"^handlers?$",     re.I), re.compile(r"^validators?$",     re.I)),
    # view ↔ serializer / schema (Django/DRF, Rails)
    (re.compile(r"^views?$",        re.I), re.compile(r"^serializers?$",    re.I)),
    (re.compile(r"^views?$",        re.I), re.compile(r"^schemas?$",        re.I)),
    # resolver ↔ guard / interceptor (NestJS GraphQL)
    (re.compile(r"^resolvers?$",    re.I), re.compile(r"^guards?$",         re.I)),
    (re.compile(r"^resolvers?$",    re.I), re.compile(r"^interceptors?$",   re.I)),
    # model ↔ schema / migration
    (re.compile(r"^models?$",       re.I), re.compile(r"^schemas?$",        re.I)),
    (re.compile(r"^models?$",       re.I), re.compile(r"^migrations?$",     re.I)),
    # auth ↔ guards / permissions / policies / middleware
    (re.compile(r"^auth$",          re.I), re.compile(r"^guards?$",         re.I)),
    (re.compile(r"^auth$",          re.I), re.compile(r"^permissions?$",    re.I)),
    (re.compile(r"^auth$",          re.I), re.compile(r"^policies$",        re.I)),
    (re.compile(r"^auth$",          re.I), re.compile(r"^middlewares?$",    re.I)),
    # handler ↔ router (Go, Express, Chi, Gin pattern)
    (re.compile(r"^handlers?$",     re.I), re.compile(r"^routers?$",        re.I)),
    # service ↔ repository / repo (clean architecture — Go, Java, C#, Python)
    (re.compile(r"^services?$",     re.I), re.compile(r"^repositor(?:y|ies)$", re.I)),
    (re.compile(r"^services?$",     re.I), re.compile(r"^repos?$",          re.I)),
    # dependencies / deps ↔ routes (FastAPI pattern)
    (re.compile(r"^routes?$",       re.I), re.compile(r"^dep(endencies)?s?$", re.I)),
]


def _structural_peer_edges(file_ids: list[str]) -> list[dict]:
    """Return bidirectional structural_peer edges between convention-paired files.

    Groups files by directory, then for each pair of files in the same dir
    checks whether their stems match any _PEER_PAIRS entry.  Language-agnostic:
    detection is purely on filename stem, not extension.
    """
    from collections import defaultdict
    by_dir: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for fid in file_ids:
        p = Path(fid)
        by_dir[str(p.parent)].append((fid, p.stem.lower()))

    edges: list[dict] = []
    for dir_files in by_dir.values():
        if len(dir_files) < 2:
            continue
        for i, (fid_a, stem_a) in enumerate(dir_files):
            for fid_b, stem_b in dir_files[i + 1:]:
                for pat_x, pat_y in _PEER_PAIRS:
                    if ((pat_x.match(stem_a) and pat_y.match(stem_b)) or
                            (pat_y.match(stem_a) and pat_x.match(stem_b))):
                        edges.append({"from": fid_a, "to": fid_b, "rel": "structural_peer"})
                        edges.append({"from": fid_b, "to": fid_a, "rel": "structural_peer"})
                        break  # one match per pair is enough
    return edges


def _append_symbol_nodes(nodes: list[Node], edges: list[dict], syms: list[dict], file_id: str, ext: str) -> None:
    for s in syms:
        nodes.append(Node(
            id=s["id"], kind="symbol", path=file_id, ext=ext,
            size=s["line_end"] - s["line_start"] + 1,
            keywords=s["keywords"],
            symbol_type=s["symbol_type"], name=s["name"],
            line_start=s["line_start"], line_end=s["line_end"],
            body_hash=s["body_hash"], confidence=s["confidence"],
            exported=s["exported"],
        ))
        edges.append({"from": file_id, "to": s["id"], "rel": "contains"})


# ── Main scan ──────────────────────────────────────────────────────────────────

def scan(root: Path, existing_nodes: dict | None = None) -> dict:
    nodes: list[Node] = []
    edges: list[dict] = []
    files = walk_files(root)
    prior = existing_nodes or {}

    for path in files:
        try:
            size = path.stat().st_size
            if size > MAX_FILE_BYTES: continue
            content = path.read_text(encoding="utf-8", errors="ignore")
        except (OSError, UnicodeDecodeError):
            continue

        file_id = rel(path, root)
        ext     = path.suffix.lower()
        fhash   = hashlib.md5(content.encode("utf-8", errors="ignore")).hexdigest()[:8]

        # Incremental: reuse unchanged file nodes
        if file_id in prior:
            old = prior[file_id]
            if old.get("file_hash") == fhash:
                nodes.append(Node(
                    id=old["id"], kind=old.get("kind", "file"),
                    path=old.get("path", file_id), ext=old.get("ext", ext),
                    size=old.get("size", size), keywords=old.get("keywords", []),
                    content=old.get("content", content[:MAX_CONTENT_CHARS]),
                    summary=old.get("summary", ""), file_hash=fhash,
                ))
                edges.extend(_extract_imports(content, file_id, ext, root))
                if ext in SYMBOL_EXTS:
                    _append_symbol_nodes(nodes, edges, _extract_symbols(content, file_id, ext), file_id, ext)
                continue

        summary = _make_summary(content, file_id, ext)
        nodes.append(Node(
            id=file_id, kind="file", path=file_id, ext=ext, size=size,
            keywords=extract_keywords(content, ext),
            content=content[:MAX_CONTENT_CHARS], summary=summary, file_hash=fhash,
        ))
        edges.extend(_extract_imports(content, file_id, ext, root))
        if ext in SYMBOL_EXTS:
            _append_symbol_nodes(nodes, edges, _extract_symbols(content, file_id, ext), file_id, ext)

    file_ids = [n.id for n in nodes if n.kind == "file"]
    unique_edges = dedupe_edges(edges + _structural_peer_edges(file_ids))
    symbol_count = sum(1 for n in nodes if n.kind == "symbol")
    return {
        "root":         str(root),
        "node_count":   len(nodes),
        "edge_count":   len(unique_edges),
        "file_count":   len(nodes) - symbol_count,
        "symbol_count": symbol_count,
        "nodes":        [n.as_dict() for n in nodes],
        "edges":        unique_edges,
        "ast_mode":     _AST_AVAILABLE,
    }


# ── Compare vs regex ───────────────────────────────────────────────────────────

def compare(root: Path, ast_out: Path, regex_out: Path) -> None:
    """Run both builders and print a side-by-side comparison."""
    import time

    print(f"\n{'═'*60}")
    print(f"  Comparing AST vs Regex on: {root.name}")
    print(f"{'═'*60}")

    # AST scan
    t0 = time.time()
    ast_graph = scan(root)
    ast_time = time.time() - t0
    ast_out.write_text(json.dumps(ast_graph, indent=2), encoding="utf-8")

    # Regex scan (original graph_builder)
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent / "src"))
        from graperoot.graph_builder import scan as regex_scan
        t0 = time.time()
        regex_graph = regex_scan(root)
        regex_time = time.time() - t0
        regex_out.write_text(json.dumps(regex_graph, indent=2), encoding="utf-8")
    except ImportError:
        print("  [warn] Original graph_builder not found — skipping regex comparison")
        regex_graph = None
        regex_time = 0

    # Print comparison
    print(f"\n{'─'*60}")
    print(f"  {'Metric':<35} {'AST':>10} {'Regex':>10}")
    print(f"{'─'*60}")
    print(f"  {'Scan time (s)':<35} {ast_time:>10.2f} {regex_time:>10.2f}")
    print(f"  {'Files indexed':<35} {ast_graph['file_count']:>10} {regex_graph['file_count'] if regex_graph else '-':>10}")
    print(f"  {'Symbols extracted':<35} {ast_graph['symbol_count']:>10} {regex_graph['symbol_count'] if regex_graph else '-':>10}")
    print(f"  {'Edges (imports/refs)':<35} {ast_graph['edge_count']:>10} {regex_graph['edge_count'] if regex_graph else '-':>10}")

    if regex_graph:
        # Symbol type breakdown
        ast_types: dict[str, int] = {}
        for n in ast_graph["nodes"]:
            if n.get("kind") == "symbol":
                t = n.get("symbol_type", "?")
                ast_types[t] = ast_types.get(t, 0) + 1

        regex_types: dict[str, int] = {}
        for n in regex_graph["nodes"]:
            if n.get("kind") == "symbol":
                t = n.get("symbol_type", "?")
                regex_types[t] = regex_types.get(t, 0) + 1

        all_types = sorted(set(ast_types) | set(regex_types))
        print(f"\n  Symbol breakdown:")
        print(f"  {'Type':<35} {'AST':>10} {'Regex':>10}")
        print(f"  {'─'*55}")
        for st in all_types:
            print(f"  {st:<35} {ast_types.get(st, 0):>10} {regex_types.get(st, 0):>10}")

        # Sample: show 3 symbols only in AST (new finds)
        ast_sym_ids  = {n["id"] for n in ast_graph["nodes"] if n.get("kind") == "symbol"}
        regex_sym_ids = {n["id"] for n in regex_graph["nodes"] if n.get("kind") == "symbol"}
        only_ast   = ast_sym_ids - regex_sym_ids
        only_regex = regex_sym_ids - ast_sym_ids

        print(f"\n  Symbols found ONLY by AST ({len(only_ast)} total): {list(only_ast)[:5]}")
        print(f"  Symbols found ONLY by Regex ({len(only_regex)} total): {list(only_regex)[:5]}")

    print(f"\n  AST graph:   {ast_out}")
    if regex_graph:
        print(f"  Regex graph: {regex_out}")
    print()


def main() -> None:
    parser = argparse.ArgumentParser(description="GrapeRoot Pro AST graph builder")
    parser.add_argument("--root",    default=".", help="Project root to scan")
    parser.add_argument("--out",     default=".dual-graph/info_graph.json", help="Output JSON path")
    parser.add_argument("--compare", action="store_true", help="Compare AST vs regex side-by-side")
    args = parser.parse_args()

    root     = Path(args.root).resolve()
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if args.compare:
        regex_out = out_path.parent / "info_graph_regex.json"
        compare(root, out_path, regex_out)
        return

    # Load existing for incremental scan
    existing_nodes: dict = {}
    if out_path.exists():
        try:
            old = json.loads(out_path.read_text(encoding="utf-8-sig"))
            existing_nodes = {n["id"]: n for n in old.get("nodes", []) if n.get("kind") == "file"}
        except Exception:
            pass

    graph = scan(root, existing_nodes=existing_nodes)
    out_path.write_text(json.dumps(graph, indent=2), encoding="utf-8")

    sym_index = {
        n["id"]: {
            "line_start": n["line_start"], "line_end": n["line_end"],
            "body_hash": n["body_hash"], "confidence": n.get("confidence", ""),
            "path": n["path"],
        }
        for n in graph["nodes"] if n.get("kind") == "symbol"
    }
    sym_index_path = out_path.parent / "symbol_index.json"
    sym_index_path.write_text(json.dumps(sym_index), encoding="utf-8")

    mode = "AST" if graph.get("ast_mode") else "regex-fallback"
    print(f"[{mode}] {graph['file_count']} files, {graph['symbol_count']} symbols, {graph['edge_count']} edges")
    print(f"Wrote: {out_path}")
    print(f"Symbol index: {sym_index_path} ({len(sym_index)} symbols)")


if __name__ == "__main__":
    main()
