# Tribulnation Bitopro SDK

> An SDK to connect Bitopro with the Tribulnation ecosystem.

🚧 Under construction.