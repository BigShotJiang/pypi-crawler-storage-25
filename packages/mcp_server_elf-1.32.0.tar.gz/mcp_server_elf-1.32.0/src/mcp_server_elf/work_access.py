"""Raw access to user's accumulated ELF MAGIC work-examples (W:/00_CAE/ELF_MAGIC).

Bundles 789 text files (.mai .mei .txt .md .py .wls .log .mao etc.)
from ~58 dated project subdirectories (2009-2026), excluding 01_GitHub
and 00_installer.

Categories cover: TEAM problems, vector hysteresis, TSVD, Halbach magnets,
particle accelerators, perm-magnet bearings, harmonic balance, SVD high-order,
homogenization, MMM+EFIE, Mas-file reproduction, and more.

Functions:
    load_work_dump()                                -> dict[str, dict]
    list_work_files(category=None, ext=None)        -> list of metadata
    search_work(query, top_k=10, category=None)     -> ranked snippets
    get_work_file(rel_path, max_chars=...)          -> raw text
"""
from __future__ import annotations

import json
from functools import lru_cache
from importlib import resources
from typing import Any


@lru_cache(maxsize=1)
def load_work_dump() -> dict[str, dict[str, Any]]:
    data = resources.files("mcp_server_elf").joinpath("work_examples_dump.json").read_text(encoding="utf-8")
    return json.loads(data)


def list_work_files(category: str | None = None, ext: str | None = None) -> list[dict[str, Any]]:
    dump = load_work_dump()
    out = []
    for path, meta in sorted(dump.items()):
        if category and meta.get("category", "") != category:
            continue
        if ext and meta.get("ext", "") != ext.lower().lstrip("."):
            continue
        out.append({
            "path": path,
            "category": meta.get("category", ""),
            "ext": meta.get("ext", ""),
            "char_count": meta.get("char_count", 0),
            "truncated": meta.get("truncated", False),
        })
    return out


def search_work(query: str, top_k: int = 10, category: str | None = None,
                ext: str | None = None) -> list[dict[str, Any]]:
    dump = load_work_dump()
    keywords = [k.strip() for k in query.split() if k.strip()]
    if not keywords:
        return []
    e = ext.lower().lstrip(".") if ext else None

    hits = []
    for path, meta in dump.items():
        if category and meta.get("category", "") != category:
            continue
        if e and meta.get("ext", "") != e:
            continue
        text = meta.get("text", "")
        text_lower = text.lower()
        scores = [text_lower.count(kw.lower()) for kw in keywords]
        if not all(s > 0 for s in scores):
            continue
        score = sum(scores)
        first_pos = text_lower.find(keywords[0].lower())
        snip_start = max(0, first_pos - 80)
        snip_end = min(len(text), first_pos + 220)
        snippet = text[snip_start:snip_end].replace("\n", " | ").strip()
        if snip_start > 0:
            snippet = "..." + snippet
        if snip_end < len(text):
            snippet = snippet + "..."
        hits.append({
            "path": path,
            "category": meta.get("category", ""),
            "ext": meta.get("ext", ""),
            "score": score,
            "snippet": snippet,
        })
    hits.sort(key=lambda h: -h["score"])
    return hits[:top_k]


def get_work_file(rel_path: str, max_chars: int = 30000) -> dict[str, Any]:
    dump = load_work_dump()
    meta = dump.get(rel_path)
    if not meta:
        candidates = [p for p in dump if rel_path in p]
        if len(candidates) == 1:
            rel_path = candidates[0]
            meta = dump[rel_path]
        else:
            return {
                "path": rel_path,
                "error": f"not found (similar: {candidates[:5]})" if candidates
                         else "not found in work_examples_dump",
            }
    text = meta.get("text", "")
    truncated = len(text) > max_chars
    if truncated:
        text = text[:max_chars] + f"\n\n[... truncated, full length: {meta.get('char_count', 0)} chars]"
    return {
        "path": rel_path,
        "category": meta.get("category", ""),
        "ext": meta.get("ext", ""),
        "text": text,
        "char_count": meta.get("char_count", 0),
        "truncated": truncated,
        "file_truncated_in_bundle": meta.get("truncated", False),
    }
