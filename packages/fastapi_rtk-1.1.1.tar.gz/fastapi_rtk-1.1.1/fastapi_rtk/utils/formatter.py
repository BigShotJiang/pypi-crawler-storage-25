import math
import typing

__all__ = ["prettify_dict", "prettify_list", "format_file_size"]


def prettify_dict(d: typing.Dict[str, typing.Any], indent=0, increment=2) -> str:
    """
    Prettify a dictionary to a string.

    Args:
        d (Dict[str, Any]): The dictionary to be prettified.
        indent (int, optional): The minimum number of spaces to indent on each row. Defaults to 0.
        increment (int, optional): The number of spaces to increase the indent for nested structures. Defaults to 2.

    Returns:
        str: The prettified dictionary as a string.

    Example:
    ```python
    data = {
        "name": "example",
        "version": "1.0.0",
        "tags": ["web", "api"],
        "dependencies": {
            "library1": "2.0.0",
            "library2": "3.1.4"
        }
    }
    print(prettify_dict(data))
    ```
    Output:
    ```
    name: example
    version: 1.0.0
    tags:
      - web
      - api
    dependencies:
      library1: 2.0.0
      library2: 3.1.4
    ```
    """
    result = ""
    for key, value in d.items():
        if isinstance(value, dict):
            result += (
                " " * indent
                + f"{key}:\n"
                + prettify_dict(value, indent + increment, increment)
            )
        elif isinstance(value, list):
            result += (
                " " * indent
                + f"{key}:\n"
                + prettify_list(value, indent + increment, increment)
            )
        else:
            result += " " * indent + f"{key}:{' ' * (increment - 1)}{value}\n"
    return result


def prettify_list(lst: typing.List[typing.Any], indent=0, increment=2) -> str:
    """
    Prettify a list to a string.

    Args:
        lst (List[Any]): The list to be prettified.
        indent (int, optional): The minimum number of spaces to indent on each row. Defaults to 0.
        increment (int, optional): The number of spaces to increase the indent for nested structures. Defaults to 2.

    Returns:
        str: The prettified list as a string.

    Example:
    ```python
    data = ["web", "api", {"library1": "2.0.0", "library2": "3.1.4"}]
    print(prettify_list(data))
    ```
    Output:
    ```
    - web
    - api
    - library1: 2.0.0
      library2: 3.1.4
    ```
    """
    result = ""
    for item in lst:
        if isinstance(item, dict):
            result += (
                " " * indent
                + "-"
                + " " * (increment - 1)
                + prettify_dict(item, indent + increment, increment).lstrip()
            )
        elif isinstance(item, list):
            result += (
                " " * indent
                + "-"
                + " " * (increment - 1)
                + prettify_list(item, indent + increment, increment).lstrip()
            )
        else:
            result += " " * indent + "-" + " " * (increment - 1) + f"{item}\n"
    return result


def format_file_size(size_bytes: int):
    """
    Format a file size in bytes to a human-readable string.

    Args:
        size_bytes (int): The file size in bytes.

    Returns:
        str: The formatted file size.
    """
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    if s.is_integer():
        s = int(s)
    return f"{s} {size_name[i]}"
