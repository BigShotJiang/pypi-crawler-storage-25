import abc
import json
import logging
import os
import typing

from ..api import BaseApi, ModelRestApi
from ..backends.generic import (
    GenericColumn,
    GenericInterface,
    GenericModel,
    GenericSession,
)
from ..setting import Setting
from ..utils import lazy, prettify_dict


class LicenseParserError(Exception):
    """Custom exception for license parser errors."""

    def __init__(
        self, data: typing.Any, message: str = "Error processing license data"
    ):
        self.data = data
        self.message = message
        super().__init__(prettify_dict({"message": self.message, "data": self.data}))


class LicenseModel(GenericModel):
    id = GenericColumn(int, primary_key=True, auto_increment=True)
    name = GenericColumn(str)
    version = GenericColumn(str)
    license = GenericColumn(str)
    license_text = GenericColumn(str)
    metadata = GenericColumn(typing.Any, default=None)


class LicenseParser(abc.ABC):
    logger = lazy(lambda self: logging.getLogger(f"{self.__class__.__name__}"))

    @abc.abstractmethod
    def process(
        self, license_data: typing.Any
    ) -> tuple[list[LicenseModel], list[LicenseParserError]]:
        """
        Process the license data and return a list of LicenseModel instances.

        Args:
            license_data (typing.Any): The raw license data to be processed.

        Raises:
            NotImplementedError: If the method is not implemented by a subclass.

        Returns:
            tuple[list[LicenseModel], list[LicenseParserError]]: A tuple containing a list of LicenseModel instances and a list of LicenseParserError instances.
        """
        raise NotImplementedError("Subclasses must implement the process method")


class PIPLicenseParser(LicenseParser):
    keys = ["Name", "Version", "License", "LicenseFile", "LicenseText"]

    def process(self, license_data):
        if not isinstance(license_data, list):
            raise LicenseParserError(
                license_data, "License data must be a list of dictionaries"
            )
        models = list[LicenseModel]()
        errors = list[LicenseParserError]()
        for item in license_data:
            if not all(key in item for key in self.keys):
                errors.append(
                    LicenseParserError(item, f"Missing required keys: {self.keys}")
                )
                continue
            model = LicenseModel()
            model.name = item.get("Name", "")
            model.version = item.get("Version", "")
            model.license = item.get("License", "")
            model.license_text = item.get("LicenseText", "")
            model.metadata = item
            models.append(model)
        return models, errors


class NPMLicenseCheckerParser(LicenseParser):
    keys = ["licenses", "path", "licenseFile"]

    def process(self, license_data):
        if not isinstance(license_data, dict):
            raise LicenseParserError(license_data, "License data must be a dictionary")
        models = list[LicenseModel]()
        errors = list[LicenseParserError]()
        for key, value in license_data.items():
            if not all(k in value for k in self.keys):
                errors.append(
                    LicenseParserError(
                        value, f"Missing required keys: {self.keys} for package {key}"
                    )
                )
                continue
            model = LicenseModel()
            if "@" in key:
                model.name, model.version = key.rsplit("@", 1)
            else:
                model.name = key
                model.version = ""
            model.license = value.get("licenses", "")
            license_file = value.get("licenseFile", "")
            if license_file and os.path.exists(license_file):
                try:
                    with open(license_file, "r") as f:
                        model.license_text = f.read()
                except Exception as e:
                    self.logger.error(f"Error reading license file {license_file}: {e}")
                    model.license_text = ""
            else:
                model.license_text = ""
            model.metadata = {"name": model.name, **value}
            models.append(model)
        return models, errors


class LicenseParserRegistry:
    processors = list[LicenseParser]([PIPLicenseParser(), NPMLicenseCheckerParser()])

    @classmethod
    def get_licenses(cls, license_data: typing.Any):
        """
        Get licenses by processing the license data with registered processors.

        Args:
            license_data (typing.Any): The raw license data to be processed.

        Raises:
            LicenseParserError: If all processors fail to process the license data, an error is raised with details of each failure.

        Returns:
            tuple[list[LicenseModel], list[LicenseParserError]]: A tuple containing a list of LicenseModel instances and a list of LicenseParserError instances.
        """
        errors = list[tuple[LicenseParser, LicenseParserError]]()
        for processor in cls.processors:
            try:
                models, processor_errors = processor.process(license_data)
                return models, processor_errors
            except LicenseParserError as e:
                errors.append((processor, e))
        raise LicenseParserError(
            [
                {"processor": p.__class__.__name__, "error": e.message, "data": e.data}
                for p, e in errors
            ],
            "All processors failed to process the license data",
        )

    @classmethod
    def register_processor(cls, processor: LicenseParser):
        cls.processors.append(processor)


class LicenseSession(GenericSession):
    logger = lazy(lambda self: logging.getLogger(f"{self.__class__.__name__}"))
    add_api = False

    def load_data(self):
        folder = Setting.LICENSE_FOLDER
        if os.path.exists(folder):
            self.__class__.add_api = True
            for filename in os.listdir(folder):
                if filename.endswith(".json"):
                    file_path = os.path.join(folder, filename)
                    try:
                        with open(file_path, "r") as f:
                            license_data = json.load(f)
                        licenses, errors = LicenseParserRegistry.get_licenses(
                            license_data
                        )
                        for license in licenses:
                            self.add(license)
                        if errors:
                            self.logger.warning(
                                f"Processed license file {file_path} with some errors:\n{prettify_dict({'errors': [{'message': e.message, 'data': e.data} for e in errors]})}"
                            )
                    except Exception as e:
                        self.logger.error(
                            f"Error processing license file {file_path}:\n{e}"
                        )


if LicenseSession.add_api:

    class LicenseApi(ModelRestApi):
        resource_name = "licenses"
        datamodel = GenericInterface(LicenseModel, LicenseSession)
        routes = ["download", "info", "get", "get_list"]
        exclude_protected_routes = routes
        list_exclude_columns = lazy(
            lambda: [] if Setting.LICENSE_SHOW_METADATA else ["metadata"]
        )
        show_exclude_columns = lazy(lambda self: self.list_exclude_columns)

else:

    class LicenseApi(BaseApi):
        resource_name = "licenses"
