# osdental-library

`osdental-library` centralizes the core components and shared utilities of the ecosystem. Its goal is to ensure technical consistency, reduce code duplication, and accelerate delivery time for our digital products.

## What's new in v3.14.3

## Features

- Implemented access control within the AuditExtension to differentiate between public and private resolvers.
- Public resolvers can be accessed without a token, while private resolvers enforce authentication and apply TenantPolicy logic, ensuring secure and efficient request handling.
- Added a close method to the Blob Storage class to properly release connections and resources after use. Ensures efficient resource management and prevents potential memory leaks or connection exhaustion.
- Added a utility that correctly formats an RSA key.

## Breaking Changes v3.14
- Removed the database execution methods from the connection class.
- Removed internal gRPC connections. Now, these must be injected from the client microservice, allowing greater flexibility and avoiding circular dependencies.
- Classes that connected directly via .env were removed. Access to Azure has been restructured to support Dependency Injection correctly.
- The base structure generation CLI commands have been temporarily removed to adapt them to the new library architecture.
- Improved audit queue handling by centralizing it into a single control point. Added support for decrypting final responses using AES and RSA algorithms.

## What's Next
- Migration plan for all base libraries to their most recent stable versions.
- Refinement of methods for hybrid environments that require switching between Managed Identity and Connection Strings depending on the environment.
- Continuous monitoring to resolve bugs and improve performance in the consumption of Azure resources.

We continue to work to deliver a superior development experience, ensuring our internal infrastructure is robust, secure and easy to deploy.

## Installation

You can easily install `osdental-library` using `pip`:

```bash
pip install osdental-library