NAME = 'energyplus_regressions'
VERSION = '2.1.7'
