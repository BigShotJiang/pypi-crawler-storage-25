import argparse
import importlib
import logging
import os
import sys

from jsrc import __version__


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level, format="%(message)s", stream=sys.stderr, force=True
    )


def _dispatch(module_name: str, func_name: str = "cmd") -> argparse.Action:
    def _runner(args: argparse.Namespace) -> None:
        module = importlib.import_module(module_name)
        getattr(module, func_name)(args)

    return _runner


MODULES = {
    "seq": "jsrc.seq",
    "plot": "jsrc.plot",
    "analyze": "jsrc.analyze",
    "gs": "jsrc.gs",
    "grn": "jsrc.grn",
    "vision": "jsrc.vision",
    "job": "jsrc.job",
}


def _iter_enabled_modules() -> list[str]:
    only = [x.strip() for x in os.getenv("JSRC_MODULES", "").split(",") if x.strip()]
    disabled = {
        x.strip() for x in os.getenv("JSRC_DISABLE_MODULES", "").split(",") if x.strip()
    }
    names = only if only else list(MODULES.keys())
    return [n for n in names if n in MODULES and n not in disabled]


def _register_modules(
    subparsers: argparse.Action, *, debug: bool = False
) -> tuple[list[str], list[str]]:
    loaded: list[str] = []
    errors: list[str] = []
    for name in _iter_enabled_modules():
        try:
            mod = importlib.import_module(MODULES[name])
            reg = getattr(mod, "register_subparser", None)
            if reg is None:
                errors.append(f"{name}: missing register_subparser")
                continue
            reg(subparsers)
            loaded.append(name)
        except (ImportError, AttributeError) as exc:
            if debug:
                raise
            errors.append(f"{name}: {exc}")
    return loaded, errors


def main() -> None:
    debug_mode = "--debug" in sys.argv[1:]
    verbose = "--verbose" in sys.argv[1:] or debug_mode
    setup_logging(verbose=verbose)
    parser = argparse.ArgumentParser(
        prog="jsrc", description="General-purpose bioinformatics and data toolkit"
    )
    parser.add_argument("-v", "--version", action="version", version=__version__)
    parser.add_argument("--verbose", action="store_true", help="Verbose logging")
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Show traceback for module loading and runtime errors",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available modules")

    loaded, errors = _register_modules(subparsers, debug=debug_mode)
    if errors:
        logging.warning("some modules failed to load:")
        for item in errors:
            logging.warning("  - %s", item)
    if not loaded:
        logging.error("no module loaded")
        sys.exit(2)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)
    if hasattr(args, "func"):
        try:
            args.func(args)
        except SystemExit as exc:
            if args.debug:
                raise
            code = exc.code
            if code is None:
                return
            if isinstance(code, int):
                sys.exit(code)
            msg = str(code).strip()
            if not msg.startswith("Error:"):
                msg = f"Error: {msg}"
            logging.error(msg)
            sys.exit(2)
        except (FileNotFoundError, ValueError) as exc:
            if args.debug:
                raise
            logging.error("Error: %s", exc)
            sys.exit(2)
        except Exception as exc:
            if args.debug:
                raise
            logging.error("Error: %s", exc)
            sys.exit(2)
        return
    group_parser = getattr(args, "_group_parser", None)
    if group_parser is not None:
        group_parser.print_help()
    else:
        parser.print_help()
    sys.exit(1)


if __name__ == "__main__":
    main()
