# 今日头条公开内容 MCP Server

## 概述

`Astron-toutiao-mcp` 是一个基于 MCP 协议的今日头条工具服务，直接调用今日头条公开热榜、推荐流、搜索页和移动端详情接口，不依赖额外的 Astron 后端服务。

当前工程形态：
- 使用 `MCP Python SDK`
- 使用单文件 `server.py` 承载工具定义、搜索解析和 HTTP 调用
- 通过独立 `pyproject` 打包
- 支持 `uvx` 一键启动
- 通过环境变量配置超时和 User-Agent

当前提供 6 个原子工具：
- `get_hot_list`
- `get_feed_list`
- `search_content`
- `get_content_detail`
- `get_author_profile`
- `get_author_content_list`


## 工具列表

### 1. 获取热榜 `get_hot_list`
- 描述：读取今日头条热榜。
- 参数：
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 2. 获取推荐流 `get_feed_list`
- 描述：读取今日头条推荐流。
- 参数：
  - `channel`：兼容保留参数，当前未启用
  - `cursor`：分页游标，对应 `max_behot_time`
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 3. 搜索内容 `search_content`
- 描述：搜索今日头条公开内容。
- 参数：
  - `query`：搜索词，必填
  - `cursor`：兼容保留参数，当前未启用
  - `limit`：返回条数，默认 `20`

### 4. 获取内容详情 `get_content_detail`
- 描述：读取今日头条内容详情。
- 参数：
  - `content_id`：内容 ID
  - `url`：内容完整 URL

### 5. 获取作者主页 `get_author_profile`
- 描述：读取作者公开信息。
- 参数：
  - `author_id`：作者检索标识，推荐直接传作者名
  - `url`：作者相关 URL，也支持传文章 URL 让服务自动解析作者

### 6. 获取作者作品列表 `get_author_content_list`
- 描述：读取作者公开作品列表。
- 参数：
  - `author_id`：作者检索标识，推荐直接传作者名
  - `url`：作者相关 URL，也支持传文章 URL 让服务自动解析作者
  - `cursor`：兼容保留参数，当前未启用
  - `limit`：返回条数，默认 `20`


## 环境变量

这个包默认不需要认证信息。

可选环境变量：

```bash
export TOUTIAO_MCP_TIMEOUT_SECONDS="30"
export TOUTIAO_MCP_USER_AGENT="Mozilla/5.0 ..."
export TOUTIAO_MCP_MOBILE_USER_AGENT="Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) ..."
```

说明：
- `TOUTIAO_MCP_TIMEOUT_SECONDS` 控制 API 和页面请求超时。
- `TOUTIAO_MCP_USER_AGENT` 用于覆盖默认桌面请求头。
- `TOUTIAO_MCP_MOBILE_USER_AGENT` 用于覆盖移动端详情接口请求头。


## 安装与启动

### 推荐方式：使用 uvx 一键启动

```bash
uvx --from astron-toutiao-mcp astron-toutiao-mcp
```

如果你还没有安装 `uv` / `uvx`，可先执行：

```bash
curl -fsSL https://install.astral.sh/uv | bash
```

### 使用 pip 安装

```bash
pip install astron-toutiao-mcp
toutiao-mcp
```

### 本地源码运行

```bash
cd MCP/toutiao-mcp
PYTHONPATH=src python3 -m toutiao_mcp.server
```


## 客户端配置

### 使用 uvx

```json
{
  "mcpServers": {
    "toutiao-mcp": {
      "command": "uvx",
      "args": ["--from", "astron-toutiao-mcp", "astron-toutiao-mcp"],
      "env": {
        "TOUTIAO_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```

### 使用本地源码

```json
{
  "mcpServers": {
    "toutiao-mcp": {
      "command": "python3",
      "args": ["-m", "toutiao_mcp.server"],
      "env": {
        "PYTHONPATH": "/path/to/MCP/toutiao-mcp/src",
        "TOUTIAO_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```


## 平台差异说明

1. 这个 MCP 直接请求今日头条公开接口和公开页面，不依赖额外的 Astron 后端服务。
2. 当前仅面向公开内容能力，不包含登录态、私有内容或用户专属数据。
3. 内容详情优先走 `m.toutiao.com/i{gid}/info/`，避免依赖 Playwright 或 PC 壳页渲染。
4. Toutiao 的数字 `media_id` / `creator_uid` 对外复用性较差，所以结果里的 `author_id` 默认更偏向“可继续检索作者”的作者名；底层数字 ID 保留在 `raw`。
5. `get_author_profile` 和 `get_author_content_list` 当前主要通过作者名搜索和详情页作者数据聚合实现；如果头条搜索结构变化，作者相关能力可能需要同步调整。


## 发布说明

```bash
cd MCP/toutiao-mcp
rm -rf build dist src/*.egg-info
python3 -m build --no-isolation
python3 -m twine check dist/*
python3 -m twine upload dist/*
```


## License

Apache License 2.0. See `LICENSE`.
