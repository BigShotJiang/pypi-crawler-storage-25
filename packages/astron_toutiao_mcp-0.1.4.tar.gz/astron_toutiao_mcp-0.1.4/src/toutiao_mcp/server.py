"""Astron Toutiao MCP server."""

from __future__ import annotations

import html as html_lib
import json
import os
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from typing import Any, Iterator
from urllib.parse import parse_qs, quote, urlencode, urlparse

import requests
from mcp.server.fastmcp import FastMCP

from toutiao_mcp import __version__


BASE_URL = "https://www.toutiao.com"
MOBILE_BASE_URL = "https://m.toutiao.com"
HOT_BOARD_API_URL = f"{BASE_URL}/hot-event/hot-board/"
FEED_API_URL = f"{BASE_URL}/api/pc/feed/"
SEARCH_URL = "https://so.toutiao.com/search"
GROUP_URL_TEMPLATE = f"{BASE_URL}/group/{{content_id}}/"
MOBILE_INFO_URL_TEMPLATE = f"{MOBILE_BASE_URL}/i{{content_id}}/info/"

STRUCTURED_MARKERS = (
    "window.__INITIAL_STATE__",
    "window.__PRELOADED_STATE__",
    "__INITIAL_STATE__",
    "__PRELOADED_STATE__",
)

COUNT_RE = re.compile(r"[\d,.]+")
TAG_RE = re.compile(r"<[^>]+>")
ITEM_CACHE: dict[str, dict[str, Any]] = {}

mcp = FastMCP("TOUTIAO_MCP")


def get_timeout_seconds() -> float:
    raw = os.getenv("TOUTIAO_MCP_TIMEOUT_SECONDS", "30").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("TOUTIAO_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("TOUTIAO_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_web_user_agent() -> str:
    value = os.getenv("TOUTIAO_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Toutiao-MCP/{__version__}"
    )


def get_mobile_user_agent() -> str:
    value = os.getenv("TOUTIAO_MCP_MOBILE_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
        f"Mobile/15E148 Safari/604.1 Astron-Toutiao-MCP/{__version__}"
    )


def create_web_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "Accept": "application/json, text/plain, */*",
            "User-Agent": get_web_user_agent(),
        }
    )
    return session


def create_mobile_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "Accept": "application/json, text/plain, */*",
            "User-Agent": get_mobile_user_agent(),
        }
    )
    return session


def _request_json(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> dict[str, Any]:
    try:
        response = session.get(
            url,
            params=params,
            headers=headers,
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

    if response.status_code != 200:
        raise RuntimeError(
            f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
        )

    if not response.text.strip():
        raise RuntimeError(f"调用失败: 响应为空; url={response.url}")

    try:
        payload = response.json()
    except ValueError as exc:
        raise RuntimeError(f"调用失败: 响应不是合法 JSON; url={response.url}") from exc

    if not isinstance(payload, dict):
        raise RuntimeError(f"调用失败: 响应不是对象; url={response.url}")
    return payload


def _request_html(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> str:
    try:
        response = session.get(
            url,
            params=params,
            headers=headers,
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

    if response.status_code != 200:
        raise RuntimeError(
            f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
        )
    return response.text


def clean_text(value: Any) -> str:
    text = html_lib.unescape(str(value or ""))
    return " ".join(text.split())


def strip_tags(value: Any) -> str:
    text = html_lib.unescape(str(value or ""))
    text = TAG_RE.sub(" ", text)
    return clean_text(text)


def _first_text(*values: Any) -> str:
    for value in values:
        text = clean_text(value)
        if text:
            return text
    return ""


def _to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    match = COUNT_RE.search(str(value))
    if not match:
        return None
    try:
        return int(float(match.group(0).replace(",", "")))
    except ValueError:
        return None


def _format_count(value: Any) -> str:
    count = _to_int(value)
    if count is None:
        return clean_text(value)
    if count >= 100000000:
        text = f"{count / 100000000:.1f}".rstrip("0").rstrip(".")
        return f"{text}亿"
    if count >= 10000:
        text = f"{count / 10000:.1f}".rstrip("0").rstrip(".")
        return f"{text}万"
    return str(count)


def _unix_to_iso(value: Any) -> str:
    timestamp = _to_int(value)
    if timestamp is None:
        return ""
    if timestamp > 10**12:
        timestamp //= 1000
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone().isoformat()


def _normalize_limit(limit: int, *, maximum: int = 50) -> int:
    value = _to_int(limit)
    if value is None:
        return 20
    return max(1, min(value, maximum))


def _normalize_url(value: Any) -> str:
    text = clean_text(value)
    if not text:
        return ""
    if text.startswith("sslocal://"):
        content_id = _extract_content_id(text)
        if content_id:
            return _build_group_url(content_id)
        return text
    if text.startswith("//"):
        return f"https:{text}"
    if text.startswith("http://"):
        return f"https://{text[len('http://'):]}"
    if text.startswith("https://"):
        return text
    if text.startswith("/"):
        return f"{BASE_URL}{text}"
    return f"{BASE_URL}/{text.lstrip('/')}"


def _build_group_url(content_id: str) -> str:
    return GROUP_URL_TEMPLATE.format(content_id=content_id.strip())


def _build_mobile_info_url(content_id: str) -> str:
    return MOBILE_INFO_URL_TEMPLATE.format(content_id=content_id.strip())


def _build_search_url(query: str, *, user_tab: bool = False) -> str:
    params = {"dvpf": "pc", "keyword": query.strip()}
    if user_tab:
        params["pd"] = "user"
    return f"{SEARCH_URL}?{urlencode(params)}"


def _build_paging(*, has_more: bool = False, next_cursor: str = "") -> dict[str, Any]:
    return {
        "has_more": bool(has_more),
        "next_cursor": next_cursor if has_more else "",
    }


def _cache_items(items: list[dict[str, Any]]) -> None:
    for item in items:
        if not isinstance(item, dict):
            continue
        item_id = clean_text(item.get("id", "")) or _extract_content_id(item.get("url", ""))
        if not item_id:
            continue
        ITEM_CACHE[item_id] = dict(item)


def _find_cached_item(content_id: str = "", url: str = "") -> dict[str, Any] | None:
    target_id = clean_text(content_id) or _extract_content_id(url)
    if not target_id:
        return None
    cached = ITEM_CACHE.get(target_id)
    if isinstance(cached, dict):
        return dict(cached)
    return None


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    if capability == "search":
        items = [
            item
            for item in items
            if (clean_text(str(item.get("result_type", ""))) or "real") == "real"
            and bool(clean_text(str(item.get("content", ""))))
        ]
    if items:
        _cache_items(items)
    item_types = [clean_text(str(item.get("result_type", ""))) or "real" for item in items]
    status = "empty" if not items else ("ok" if any(item_type == "real" for item_type in item_types) else "degraded")
    result_type = ""
    if item_types:
        if any(item_type == "real" for item_type in item_types):
            result_type = "real"
        else:
            result_type = item_types[0] if len(set(item_types)) == 1 else "mixed"
    result = {
        "platform": "toutiao",
        "capability": capability,
        "status": status,
        "update_time": datetime.now(timezone.utc).astimezone().isoformat(),
        "items": items,
        "paging": _build_paging(has_more=has_more, next_cursor=next_cursor),
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(item.get("result_type", ""))) or "real" if item else ""
    result = {
        "platform": "toutiao",
        "status": "empty" if not item else ("degraded" if result_type != "real" else "ok"),
        "item": item,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(author.get("result_type", ""))) or "real" if author else ""
    result = {
        "platform": "toutiao",
        "status": "empty" if not author else ("degraded" if result_type != "real" else "ok"),
        "author": author,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _normalize_name_key(value: Any) -> str:
    return clean_text(value).lower()


def _extract_content_id(value: Any) -> str:
    text = clean_text(value)
    if not text:
        return ""
    if text.isdigit():
        return text
    if text.startswith("sslocal://"):
        parsed = urlparse(text)
        query = parse_qs(parsed.query)
        for key in ("groupid", "group_id", "item_id", "search_result_id"):
            item = clean_text(query.get(key, [""])[0])
            if item.isdigit():
                return item
        return ""
    normalized = _normalize_url(text)
    parsed = urlparse(normalized)
    match = re.search(r"/(?:group|article|trending)/(\d+)", parsed.path)
    if match:
        return match.group(1)
    query = parse_qs(parsed.query)
    for key in ("groupid", "group_id", "item_id", "search_result_id"):
        item = clean_text(query.get(key, [""])[0])
        if item.isdigit():
            return item
    fallback = clean_text(parsed.path.rstrip("/").rsplit("/", 1)[-1])
    if fallback.isdigit():
        return fallback
    return ""


def _extract_keyword(tag_url: Any) -> str:
    text = clean_text(tag_url)
    if not text:
        return ""
    parsed = urlparse(text if text.startswith(("http://", "https://")) else f"https://x/?{text}")
    return clean_text(parse_qs(parsed.query).get("keyword", [""])[0])


def _normalize_tags(*values: Any) -> list[str]:
    tags: list[str] = []
    for value in values:
        if isinstance(value, list):
            for item in value:
                text = clean_text(item)
                if text and text not in tags:
                    tags.append(text)
            continue
        text = clean_text(value)
        if text and text not in tags:
            tags.append(text)
    return tags


def _pick_image_url(item: dict[str, Any]) -> str:
    for key in ("middle_image", "image_url", "cover", "media_avatar_url", "middle_image_url", "avatar_url"):
        value = item.get(key)
        if isinstance(value, dict):
            url = _normalize_url(value.get("url", ""))
        else:
            url = _normalize_url(value)
        if url:
            return url
    image_list = item.get("image_list")
    if isinstance(image_list, list):
        for image in image_list:
            if isinstance(image, dict):
                url = _normalize_url(image.get("url", ""))
                if url:
                    return url
    return ""


class ToutiaoHTMLCollector(HTMLParser):
    """Collect title and inline scripts from a page."""

    def __init__(self) -> None:
        super().__init__()
        self.title = ""
        self._in_title = False
        self.scripts: list[tuple[dict[str, str], str]] = []
        self._current_attrs: dict[str, str] | None = None
        self._current_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attrs_map = {key: value or "" for key, value in attrs}
        if tag == "title":
            self._in_title = True
            return
        if tag == "script":
            self._current_attrs = attrs_map
            self._current_parts = []

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title += data
        if self._current_attrs is not None:
            self._current_parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self._in_title = False
        if tag == "script" and self._current_attrs is not None:
            self.scripts.append((self._current_attrs, "".join(self._current_parts).strip()))
            self._current_attrs = None
            self._current_parts = []


def _current_title(html: str) -> str:
    collector = ToutiaoHTMLCollector()
    collector.feed(html)
    return clean_text(collector.title)


def _iter_dicts(value: Any) -> Iterator[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for nested in value.values():
            yield from _iter_dicts(nested)
    elif isinstance(value, list):
        for item in value:
            yield from _iter_dicts(item)


def _extract_json_block_from_index(text: str, start: int) -> dict[str, Any] | None:
    depth = 0
    in_string = False
    escaped = False
    for pos in range(start, len(text)):
        char = text[pos]
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                block = text[start : pos + 1]
                try:
                    return json.loads(block)
                except json.JSONDecodeError:
                    return None
    return None


def _extract_json_block(text: str, marker: str) -> dict[str, Any] | None:
    index = text.find(marker)
    if index < 0 and marker.endswith("="):
        index = text.find(marker[:-1])
    if index < 0:
        return None
    start = text.find("{", index)
    if start < 0:
        return None
    return _extract_json_block_from_index(text, start)


def _extract_payloads(html: str) -> list[Any]:
    collector = ToutiaoHTMLCollector()
    collector.feed(html)
    payloads: list[Any] = []
    for attrs, content in collector.scripts:
        if not content:
            continue
        script_type = attrs.get("type", "").lower()
        if script_type in {"application/json", "application/ld+json"}:
            try:
                payloads.append(json.loads(content))
            except json.JSONDecodeError:
                pass
        for marker in STRUCTURED_MARKERS:
            extracted = _extract_json_block(content, marker)
            if extracted is not None:
                payloads.append(extracted)
    return payloads


def _contains_keyword(item: dict[str, Any], keyword: str) -> bool:
    normalized_keyword = clean_text(keyword).lower()
    if not normalized_keyword:
        return False
    haystack = " ".join(
        [
            clean_text(item.get("title", "")),
            clean_text(item.get("summary", "")),
            clean_text(item.get("content", "")),
            clean_text(item.get("author_name", "")),
        ]
    ).lower()
    return normalized_keyword in haystack


def _looks_like_user_card(data: dict[str, Any]) -> bool:
    if not any(key in data for key in ("screen_name", "share_url", "user_id", "avatar_url")):
        return False

    template_key = clean_text(data.get("template_key", ""))
    display_type_ext = clean_text(data.get("display_type_ext", ""))
    return (
        "user_cluster" in template_key
        or display_type_ext.startswith("user")
        or "follow_count" in data
        or "source_url" in data
    )


def _looks_like_content_card(data: dict[str, Any]) -> bool:
    if not any(
        key in data
        for key in (
            "group_id",
            "article_url",
            "source_url",
            "display_url",
            "title",
            "abstract",
            "summary",
            "content",
        )
    ):
        return False
    if "group_id" in data or "article_url" in data or "display_url" in data:
        return True
    display = data.get("display")
    return isinstance(display, dict) and any(key in display for key in ("title", "summary", "info"))


def _extract_card_payloads(html: str) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()
    markers = (
        '"group_id":"',
        '"screen_name":"',
        '"user_id":"',
        '"template_key":"26-user_cluster"',
    )
    search_start = 0
    html_length = len(html)
    while search_start < html_length:
        anchor = -1
        marker_used = ""
        for marker in markers:
            pos = html.find(marker, search_start)
            if pos != -1 and (anchor == -1 or pos < anchor):
                anchor = pos
                marker_used = marker
        if anchor == -1:
            break

        start = html.rfind("{", 0, anchor)
        best: dict[str, Any] | None = None
        lower_bound = max(0, anchor - 12000)
        while start >= lower_bound:
            candidate = _extract_json_block_from_index(html, start)
            if isinstance(candidate, dict) and (
                _looks_like_content_card(candidate) or _looks_like_user_card(candidate)
            ):
                best = candidate
                break
            start = html.rfind("{", 0, start)

        if best is not None:
            key = clean_text(
                str(
                    best.get("group_id")
                    or best.get("user_id")
                    or best.get("screen_name")
                    or best.get("share_url")
                    or best.get("id")
                    or ""
                )
            )
            if key and key not in seen:
                seen.add(key)
                candidates.append(best)
            search_start = anchor + max(1, len(marker_used))
        else:
            search_start = anchor + 1
    return candidates


def _card_payloads_from_html(html: str) -> list[Any]:
    return _extract_payloads(html) + _extract_card_payloads(html)


def _parse_int_field(value: Any) -> int | None:
    if isinstance(value, dict):
        for key in ("value", "count", "text"):
            if key in value:
                parsed = _to_int(value.get(key))
                if parsed is not None:
                    return parsed
    return _to_int(value)


def _normalize_author_id(author_name: Any, fallback: Any = "") -> str:
    return _first_text(author_name, fallback)


def _parse_search_user_card(data: dict[str, Any], rank: int) -> dict[str, Any]:
    title = _first_text(data.get("screen_name"), data.get("name"))
    profile_url = _normalize_url(
        data.get("share_url", "")
        or data.get("source_url", "")
    )
    return {
        "id": title or clean_text(data.get("user_id") or data.get("id") or data.get("search_result_id")),
        "title": title,
        "summary": clean_text(data.get("description", "")),
        "content": "",
        "url": profile_url,
        "cover": _normalize_url(data.get("avatar_url", "") or data.get("avatar_uri", "")),
        "author_name": title,
        "author_id": title,
        "publish_time": _unix_to_iso(data.get("create_time")),
        "rank": rank,
        "hot_value": _parse_int_field(data.get("follow_count")),
        "hot_text": _format_count(data.get("follow_count")),
        "source_type": "search_user",
        "result_type": "preview",
        "tags": [],
    }


def _search_content_url(data: dict[str, Any]) -> str:
    for key in ("group_id", "item_id", "id"):
        content_id = clean_text(data.get(key))
        if content_id.isdigit():
            return _build_group_url(content_id)

    display = data.get("display") if isinstance(data.get("display"), dict) else {}
    info = display.get("info") if isinstance(display, dict) else {}
    candidates = (
        data.get("article_url", ""),
        data.get("open_url", ""),
        data.get("source_url", ""),
        data.get("display_url", ""),
        info.get("url", "") if isinstance(info, dict) else "",
        data.get("item_source_url", ""),
        data.get("share_url", ""),
    )
    for candidate in candidates:
        content_id = _extract_content_id(candidate)
        if content_id:
            return _build_group_url(content_id)
        url = _normalize_url(candidate)
        if url and "toutiao.com" in urlparse(url).netloc:
            return url
    return ""


def _parse_search_content_card(data: dict[str, Any], rank: int) -> dict[str, Any] | None:
    display = data.get("display") if isinstance(data.get("display"), dict) else {}
    display_title = display.get("title") if isinstance(display, dict) else {}
    display_summary = display.get("summary") if isinstance(display, dict) else {}
    info = display.get("info") if isinstance(display, dict) else {}
    title = _first_text(
        display_title.get("text", "") if isinstance(display_title, dict) else "",
        data.get("title", ""),
        data.get("emphasized", {}).get("title", "") if isinstance(data.get("emphasized"), dict) else "",
        data.get("source", ""),
    )
    summary = _first_text(
        display_summary.get("text", "") if isinstance(display_summary, dict) else "",
        data.get("summary", ""),
        data.get("abstract", ""),
        data.get("content", ""),
    )
    url = _search_content_url(data)
    content_id = _extract_content_id(url or data.get("group_id") or data.get("item_id") or data.get("id"))
    if not content_id:
        return None
    canonical_url = _build_group_url(content_id)
    author_name = _first_text(
        data.get("source", ""),
        data.get("media_name", ""),
        data.get("toutiao_auth_info", {}).get("institution", {}).get("auth_info", "")
        if isinstance(data.get("toutiao_auth_info"), dict)
        else "",
    )
    cover = _normalize_url(
        data.get("middle_image_url", "")
        or data.get("image_url", "")
        or data.get("large_image_url", "")
        or (
            data.get("image_list", [{}])[0].get("url")
            if isinstance(data.get("image_list"), list) and data.get("image_list")
            else ""
        )
    )
    if not cover and isinstance(info, dict):
        images = info.get("images")
        if isinstance(images, list) and images and isinstance(images[0], dict):
            cover = _normalize_url(images[0].get("url", ""))
    return {
        "id": content_id,
        "title": title or summary or content_id,
        "summary": summary or title,
        "content": summary or title,
        "url": canonical_url,
        "cover": cover,
        "author_name": author_name,
        "author_id": _normalize_author_id(author_name, data.get("media_creator_id") or data.get("creator_id")),
        "publish_time": _unix_to_iso(
            data.get("publish_time")
            or data.get("display_time")
            or data.get("create_time")
            or data.get("behot_time")
        ),
        "rank": rank,
        "hot_value": _parse_int_field(data.get("read_count") or data.get("comment_count") or data.get("digg_count")),
        "hot_text": _format_count(data.get("read_count") or data.get("comment_count") or data.get("digg_count")),
        "comment_count": _to_int(data.get("comment_count")),
        "like_count": _to_int(data.get("digg_count")),
        "share_count": _to_int(data.get("share_count")),
        "collect_count": _to_int(data.get("repin_count")),
        "view_count": _to_int(data.get("read_count")),
        "source_type": _first_text(data.get("article_sub_type"), data.get("content_schema_type"), "search"),
        "result_type": "real" if clean_text(summary or title) else "preview",
        "tags": _normalize_tags(
            data.get("tag", ""),
            data.get("keyword", ""),
            data.get("media_name", ""),
        ),
    }


def _collect_search_items(
    html: str,
    *,
    limit: int,
    include_users: bool = False,
    include_content: bool = True,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    payloads = _card_payloads_from_html(html)
    user_items: list[dict[str, Any]] = []
    content_items: list[dict[str, Any]] = []
    seen_users: set[str] = set()
    seen_content: set[str] = set()

    for payload in payloads:
        for data in _iter_dicts(payload):
            if not isinstance(data, dict):
                continue
            if include_users and _looks_like_user_card(data):
                item = _parse_search_user_card(data, rank=len(user_items) + 1)
                key = clean_text(item.get("id") or item.get("url") or item.get("title"))
                if key and key not in seen_users:
                    seen_users.add(key)
                    user_items.append(item)
            if include_content and _looks_like_content_card(data):
                item = _parse_search_content_card(data, rank=len(content_items) + 1)
                if item is None:
                    continue
                key = clean_text(item.get("id") or item.get("url") or item.get("title"))
                if key and key not in seen_content:
                    seen_content.add(key)
                    content_items.append(item)
            if len(user_items) >= limit and len(content_items) >= limit:
                break
        if len(user_items) >= limit and len(content_items) >= limit:
            break

    return user_items[:limit], content_items[:limit]


def _match_author_name(item: dict[str, Any], author_name: str) -> bool:
    expected = _normalize_name_key(author_name)
    return expected and _normalize_name_key(item.get("author_name")) == expected


def _has_author_identity(item: dict[str, Any]) -> bool:
    return bool(clean_text(item.get("author_id", "")) or clean_text(item.get("author_name", "")))


def _pick_user_item(user_items: list[dict[str, Any]], author_name: str) -> dict[str, Any] | None:
    expected = _normalize_name_key(author_name)
    if not expected:
        return None
    for item in user_items:
        if _normalize_name_key(item.get("title")) == expected:
            return item
    return None


def _filter_author_items(items: list[dict[str, Any]], author_name: str) -> list[dict[str, Any]]:
    return [item for item in items if _match_author_name(item, author_name)]


def _build_hot_item(item: dict[str, Any], rank: int) -> dict[str, Any]:
    cluster_id = clean_text(item.get("ClusterIdStr") or item.get("ClusterId") or item.get("Id"))
    title = _first_text(item.get("Title"), item.get("QueryWord"), item.get("Label"))
    summary = _first_text(item.get("Label"), item.get("QueryWord"), title)
    image = item.get("Image") if isinstance(item.get("Image"), dict) else {}
    return {
        "id": cluster_id or title,
        "title": title,
        "summary": summary,
        "content": summary,
        "url": _normalize_url(item.get("Url", "") or item.get("url", "")),
        "cover": _normalize_url(image.get("url", "") if isinstance(image, dict) else ""),
        "author_name": clean_text(item.get("Source", "") or item.get("source", "")),
        "author_id": _normalize_author_id(item.get("Source", "") or item.get("source", "")),
        "publish_time": "",
        "rank": rank,
        "hot_value": _to_int(item.get("HotValue") or item.get("hot_value")),
        "hot_text": _format_count(item.get("HotValue") or item.get("hot_text")),
        "comment_count": None,
        "like_count": None,
        "share_count": None,
        "collect_count": None,
        "view_count": None,
        "source_type": "hot_board",
        "result_type": "topic" if not clean_text(summary) else "real",
        "tags": _normalize_tags(
            item.get("InterestCategory"),
            item.get("LabelUri", {}).get("uri", "") if isinstance(item.get("LabelUri"), dict) else "",
        ),
    }


def _build_feed_item(item: dict[str, Any], rank: int | None = None) -> dict[str, Any]:
    content_id = clean_text(item.get("group_id") or item.get("item_id") or item.get("id"))
    title = _first_text(item.get("title"), item.get("summary"), item.get("abstract"))
    summary = _first_text(item.get("abstract"), item.get("summary"), title)
    content = clean_text(item.get("content", "")) or clean_text(summary)
    author_name = _first_text(item.get("source"), item.get("media_name"), item.get("author_name"))
    url = _build_group_url(content_id) if content_id else _normalize_url(item.get("source_url", "") or item.get("url", ""))
    return {
        "id": content_id or url or title,
        "title": title or summary,
        "summary": summary or title,
        "content": content,
        "url": url,
        "cover": _pick_image_url(item),
        "author_name": author_name,
        "author_id": _normalize_author_id(author_name, item.get("media_id") or item.get("source_id")),
        "publish_time": _unix_to_iso(item.get("behot_time") or item.get("publish_time")),
        "rank": rank,
        "hot_value": None,
        "hot_text": "",
        "comment_count": _to_int(item.get("comments_count") or item.get("comment_count")),
        "like_count": _to_int(item.get("digg_count") or item.get("like_count")),
        "share_count": _to_int(item.get("share_count")),
        "collect_count": _to_int(item.get("repin_count")),
        "view_count": _to_int(item.get("read_count") or item.get("view_count")),
        "source_type": _first_text(item.get("article_genre"), "article"),
        "result_type": "real" if content else "preview",
        "tags": _normalize_tags(
            item.get("article_genre", ""),
            item.get("tag", ""),
            _extract_keyword(item.get("tag_url", "")),
        ),
    }


def _summary_from_text(content: str, *, fallback: str = "", max_length: int = 140) -> str:
    text = clean_text(content)
    if not text:
        return clean_text(fallback)
    if len(text) <= max_length:
        return text
    return text[:max_length].rstrip() + "..."


def _extract_author_bio(mobile_data: dict[str, Any]) -> str:
    media_user = mobile_data.get("media_user")
    if not isinstance(media_user, dict):
        return ""
    user_auth_info = media_user.get("user_auth_info")
    if isinstance(user_auth_info, dict):
        return _first_text(
            user_auth_info.get("auth_info", ""),
            user_auth_info.get("other_auth", {}).get("high_quality", "")
            if isinstance(user_auth_info.get("other_auth"), dict)
            else "",
        )
    return ""


def _build_detail_item_from_mobile_data(content_id: str, mobile_data: dict[str, Any]) -> dict[str, Any]:
    media_user = mobile_data.get("media_user") if isinstance(mobile_data.get("media_user"), dict) else {}
    author_name = _first_text(
        media_user.get("screen_name", "") if isinstance(media_user, dict) else "",
        mobile_data.get("source", ""),
        mobile_data.get("detail_source", ""),
    )
    content_text = strip_tags(mobile_data.get("content", ""))
    title = _first_text(mobile_data.get("title", ""), content_id)
    return {
        "id": content_id,
        "title": title,
        "summary": _summary_from_text(content_text, fallback=title),
        "content": content_text,
        "url": _build_group_url(content_id),
        "cover": _normalize_url(mobile_data.get("poster_url", "")),
        "author_name": author_name,
        "author_id": _normalize_author_id(author_name, media_user.get("id") if isinstance(media_user, dict) else ""),
        "publish_time": _unix_to_iso(mobile_data.get("publish_time")),
        "rank": None,
        "hot_value": None,
        "hot_text": "",
        "comment_count": _to_int(mobile_data.get("comment_count")),
        "like_count": _to_int(mobile_data.get("digg_count")),
        "share_count": _to_int(mobile_data.get("repost_count")),
        "collect_count": _to_int(mobile_data.get("repin_count")),
        "view_count": _to_int(mobile_data.get("impression_count")),
        "source_type": _first_text(mobile_data.get("biz_tag"), "article"),
        "result_type": "real" if content_text else "preview",
        "tags": _normalize_tags(mobile_data.get("biz_tag", "")),
    }


def _build_detail_item_from_page_html(content_id: str, html: str, *, request_url: str) -> dict[str, Any]:
    _, content_items = _collect_search_items(
        html,
        limit=10,
        include_users=False,
        include_content=True,
    )
    for item in content_items:
        if _extract_content_id(item.get("id") or item.get("url")) != content_id:
            continue
        normalized = dict(item)
        normalized["id"] = content_id
        if not clean_text(normalized.get("url", "")):
            normalized["url"] = _normalize_url(request_url)
        return normalized
    return {}


def _build_author_from_mobile_data(
    mobile_data: dict[str, Any],
    *,
    author_name: str,
    profile_item: dict[str, Any] | None = None,
) -> dict[str, Any]:
    media_user = mobile_data.get("media_user") if isinstance(mobile_data.get("media_user"), dict) else {}
    final_name = _first_text(
        media_user.get("screen_name", "") if isinstance(media_user, dict) else "",
        profile_item.get("title") if profile_item else "",
        author_name,
    )
    return {
        "id": final_name or author_name,
        "name": final_name or author_name,
        "url": _normalize_url(profile_item.get("url", "") if profile_item else ""),
        "avatar": _first_text(
            _normalize_url(media_user.get("avatar_url", "") if isinstance(media_user, dict) else ""),
            profile_item.get("cover") if profile_item else "",
        ),
        "bio": _first_text(
            _extract_author_bio(mobile_data),
            profile_item.get("summary") if profile_item else "",
        ),
        "follower_count": _to_int(
            media_user.get("follower_count") if isinstance(media_user, dict) else None
        )
        or _to_int(mobile_data.get("follower_count"))
        or _to_int(profile_item.get("hot_value") if profile_item else None),
        "following_count": None,
        "content_count": None,
    }


def _fetch_mobile_info_data(content_id: str) -> dict[str, Any]:
    mobile_session = create_mobile_session()
    payload = _request_json(mobile_session, _build_mobile_info_url(content_id))
    if not payload.get("success") or not isinstance(payload.get("data"), dict):
        raise RuntimeError(f"未能读取今日头条移动端详情: {content_id}")
    return payload["data"]


def _hydrate_items_with_mobile_details(items: list[dict[str, Any]], *, max_items: int = 5) -> list[dict[str, Any]]:
    hydrated: list[dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        if index > max_items:
            hydrated.append(item)
            continue
        content_id = _extract_content_id(str(item.get("id") or item.get("url") or ""))
        if not content_id:
            hydrated.append(item)
            continue
        try:
            mobile_data = _fetch_mobile_info_data(content_id)
            detail_item = _build_detail_item_from_mobile_data(content_id, mobile_data)
        except RuntimeError:
            hydrated.append(item)
            continue
        merged = dict(item)
        for key in (
            "title",
            "summary",
            "content",
            "url",
            "cover",
            "author_name",
            "author_id",
            "publish_time",
            "comment_count",
            "like_count",
            "share_count",
            "collect_count",
            "view_count",
            "source_type",
            "result_type",
            "tags",
        ):
            value = detail_item.get(key)
            if value not in (None, "", []):
                merged[key] = value
        hydrated.append(merged)
    return hydrated


def _fetch_hot_list(limit: int) -> dict[str, Any]:
    session = create_web_session()
    payload = _request_json(
        session,
        HOT_BOARD_API_URL,
        params={"origin": "toutiao_pc"},
    )
    data = payload.get("data", [])
    items: list[dict[str, Any]] = []
    if isinstance(data, list):
        for index, item in enumerate(data[:limit], start=1):
            if isinstance(item, dict):
                items.append(_build_hot_item(item, index))
    items = _hydrate_items_with_mobile_details(items, max_items=min(limit, 5))
    if not items:
        return _build_list_result("hot_list", [], payload, has_more=False, next_cursor="")
    next_data = payload.get("next")
    next_cursor = ""
    if isinstance(next_data, dict):
        next_cursor = clean_text(next_data.get("max_behot_time"))
    return _build_list_result(
        "hot_list",
        items,
        payload,
        has_more=bool(payload.get("has_more")),
        next_cursor=next_cursor,
    )


def _fetch_feed_list(cursor: str, limit: int) -> dict[str, Any]:
    session = create_web_session()
    params: dict[str, Any] = {}
    if clean_text(cursor):
        params["max_behot_time"] = clean_text(cursor)
    payload = _request_json(session, FEED_API_URL, params=params or None)
    data = payload.get("data", [])
    items: list[dict[str, Any]] = []
    if isinstance(data, list):
        for index, item in enumerate(data[:limit], start=1):
            if isinstance(item, dict):
                items.append(_build_feed_item(item, rank=index))
    items = _hydrate_items_with_mobile_details(items, max_items=min(limit, 5))
    if not items:
        return _build_list_result("feed_list", [], payload, has_more=False, next_cursor="")
    next_data = payload.get("next")
    next_cursor = ""
    if isinstance(next_data, dict):
        next_cursor = clean_text(next_data.get("max_behot_time"))
    return _build_list_result(
        "feed_list",
        items,
        payload,
        has_more=bool(payload.get("has_more")),
        next_cursor=next_cursor,
    )


def _fetch_search_content(query: str, limit: int) -> dict[str, Any]:
    session = create_web_session()
    html = _request_html(
        session,
        SEARCH_URL,
        params={"dvpf": "pc", "keyword": query.strip()},
        headers={"Referer": "https://so.toutiao.com/"},
    )
    _, content_items = _collect_search_items(html, limit=max(limit * 3, 30), include_users=False, include_content=True)
    candidate_items = content_items[: max(limit * 3, 12)]
    if candidate_items and not any(_contains_keyword(item, query) for item in candidate_items):
        candidate_items = []
    hydrated_items = _hydrate_items_with_mobile_details(candidate_items, max_items=min(len(candidate_items), max(limit * 3, 12)))
    real_items = [item for item in hydrated_items if clean_text(item.get("result_type", "")) == "real" and clean_text(item.get("content", ""))]
    identified_items = [item for item in real_items if _has_author_identity(item)]
    items = (identified_items or real_items)[:limit]
    for index, item in enumerate(items, start=1):
        item["rank"] = index
    if items and not any(_contains_keyword(item, query) for item in items):
        items = []
    return _build_list_result(
        "search",
        items,
        {
            "query": query,
            "html_title": _current_title(html),
            "content_count": len(content_items),
            "search_url": _build_search_url(query),
        },
    )


def _fetch_content_detail(content_id: str = "", url: str = "") -> dict[str, Any]:
    target_id = clean_text(content_id) or _extract_content_id(url)
    if not target_id:
        return _build_detail_result({}, {"reason": "empty_input"})
    request_url = clean_text(url) or _build_group_url(target_id)
    try:
        mobile_data = _fetch_mobile_info_data(target_id)
        item = _build_detail_item_from_mobile_data(target_id, mobile_data)
        _cache_items([item])
        return _build_detail_result(
            item,
            {
                "content_id": target_id,
                "request_url": request_url,
                "mobile_info_url": _build_mobile_info_url(target_id),
                "mobile_data": mobile_data,
            },
        )
    except RuntimeError as mobile_error:
        mobile_data = {"error": str(mobile_error)}

    cached_item = _find_cached_item(target_id, request_url)
    if cached_item:
        cached_item["id"] = target_id
        if not clean_text(cached_item.get("url", "")):
            cached_item["url"] = request_url
        if not clean_text(cached_item.get("result_type", "")):
            cached_item["result_type"] = "real" if clean_text(cached_item.get("content", "")) else "preview"
        return _build_detail_result(
            cached_item,
            {
                "content_id": target_id,
                "request_url": request_url,
                "mobile_info_url": _build_mobile_info_url(target_id),
                "mobile_data": mobile_data,
                "source": "cache",
            },
        )

    html_item: dict[str, Any] = {}
    html_errors: list[str] = []
    candidate_urls = [
        request_url,
        _build_group_url(target_id),
        f"{BASE_URL}/article/{target_id}/",
        f"{BASE_URL}/w/{target_id}/",
        f"{BASE_URL}/trending/{target_id}/",
    ]
    seen_urls: set[str] = set()
    session = create_web_session()
    for candidate_url in candidate_urls:
        normalized_url = _normalize_url(candidate_url)
        if not normalized_url or normalized_url in seen_urls:
            continue
        seen_urls.add(normalized_url)
        try:
            html = _request_html(session, normalized_url)
        except RuntimeError as exc:
            html_errors.append(f"{normalized_url}: {exc}")
            continue
        html_item = _build_detail_item_from_page_html(target_id, html, request_url=normalized_url)
        if html_item:
            return _build_detail_result(
                html_item,
                {
                    "content_id": target_id,
                    "request_url": request_url,
                    "mobile_info_url": _build_mobile_info_url(target_id),
                    "mobile_data": mobile_data,
                    "html_url": normalized_url,
                },
            )

    return _build_detail_result(
        {},
        {
            "content_id": target_id,
            "request_url": request_url,
            "mobile_info_url": _build_mobile_info_url(target_id),
            "mobile_data": mobile_data,
            "html_errors": html_errors,
        },
    )


def _resolve_author_query(author_id: str = "", url: str = "") -> tuple[str, dict[str, Any] | None]:
    direct_url = clean_text(url)
    if direct_url:
        content_id = _extract_content_id(direct_url)
        if content_id:
            detail = _fetch_content_detail(content_id=content_id, url=direct_url)
            author_name = clean_text(detail["item"].get("author_name"))
            if author_name:
                return author_name, detail

    explicit = clean_text(author_id)
    if explicit.startswith(("http://", "https://", "//", "sslocal://")):
        content_id = _extract_content_id(explicit)
        if content_id:
            detail = _fetch_content_detail(content_id=content_id, url=explicit)
            author_name = clean_text(detail["item"].get("author_name"))
            if author_name:
                return author_name, detail
        raise RuntimeError("当前仅支持通过作者名或文章 URL 解析今日头条作者")

    if not explicit:
        raise RuntimeError("请提供 author_id 或 url")
    return explicit, None


def _search_author_context(author_name: str, *, limit: int) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str]:
    session = create_web_session()
    user_html = _request_html(
        session,
        SEARCH_URL,
        params={"dvpf": "pc", "keyword": author_name, "pd": "user"},
        headers={"Referer": "https://so.toutiao.com/"},
    )
    user_items, user_content_items = _collect_search_items(
        user_html,
        limit=max(limit * 3, 20),
        include_users=True,
        include_content=True,
    )
    profile_item = _pick_user_item(user_items, author_name)
    content_items = _filter_author_items(user_content_items, author_name)

    if len(content_items) < limit:
        search_html = _request_html(
            session,
            SEARCH_URL,
            params={"dvpf": "pc", "keyword": author_name},
            headers={"Referer": "https://so.toutiao.com/"},
        )
        _, general_items = _collect_search_items(
            search_html,
            limit=max(limit * 4, 30),
            include_users=False,
            include_content=True,
        )
        seen: set[str] = {clean_text(item.get("id")) for item in content_items}
        for item in _filter_author_items(general_items, author_name):
            key = clean_text(item.get("id"))
            if key and key not in seen:
                seen.add(key)
                content_items.append(item)

    return profile_item, content_items[:limit], user_html


def _fetch_author_profile(author_id: str = "", url: str = "") -> dict[str, Any]:
    try:
        author_name, seed_detail = _resolve_author_query(author_id=author_id, url=url)
    except RuntimeError:
        return _build_author_result({}, {"reason": "empty_input"})
    profile_item, content_items, user_html = _search_author_context(author_name, limit=5)

    seed_mobile_data: dict[str, Any] | None = None
    if seed_detail is not None and isinstance(seed_detail.get("raw"), dict):
        seed_mobile_data = seed_detail["raw"].get("mobile_data")

    if seed_mobile_data is None:
        for item in content_items:
            content_id = clean_text(item.get("id"))
            if not content_id:
                continue
            try:
                seed_mobile_data = _fetch_mobile_info_data(content_id)
                break
            except RuntimeError:
                continue

    if seed_mobile_data is None and profile_item is None:
        return _build_author_result({}, {"author_query": author_name, "request_url": url})

    if seed_mobile_data is not None:
        author = _build_author_from_mobile_data(
            seed_mobile_data,
            author_name=author_name,
            profile_item=profile_item,
        )
    else:
        author = {
            "id": author_name,
            "name": _first_text(profile_item.get("title") if profile_item else "", author_name),
            "url": _normalize_url(profile_item.get("url") if profile_item else ""),
            "avatar": _first_text(profile_item.get("cover") if profile_item else ""),
            "bio": _first_text(profile_item.get("summary") if profile_item else ""),
            "follower_count": _to_int(profile_item.get("hot_value") if profile_item else None),
            "following_count": None,
            "content_count": None,
            "raw": {
                "profile_item": profile_item or {},
            },
        }

    return _build_author_result(
        author,
        {
            "author_query": author_name,
            "request_url": url,
            "profile_item": profile_item or {},
            "content_sample_count": len(content_items),
            "search_user_title": _current_title(user_html),
            "seed_detail": seed_detail or {},
            "seed_mobile_data": seed_mobile_data or {},
        },
    )


def _fetch_author_content_list(author_id: str = "", url: str = "", limit: int = 20) -> dict[str, Any]:
    try:
        author_name, seed_detail = _resolve_author_query(author_id=author_id, url=url)
    except RuntimeError:
        return _build_list_result("author_content_list", [], {"reason": "empty_input"}, has_more=False, next_cursor="")
    profile_item, content_items, user_html = _search_author_context(author_name, limit=limit)

    if not profile_item and seed_detail is None and not clean_text(url):
        return _build_list_result(
            "author_content_list",
            [],
            {"reason": "invalid_author_query", "author_query": author_name},
            has_more=False,
            next_cursor="",
        )

    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()

    if seed_detail is not None and isinstance(seed_detail.get("item"), dict):
        seed_item = seed_detail["item"]
        key = clean_text(seed_item.get("id") or seed_item.get("url") or seed_item.get("title"))
        if key:
            seen.add(key)
            deduped.append(seed_item)

    for item in content_items:
        key = clean_text(item.get("id") or item.get("url") or item.get("title"))
        if not key or key in seen:
            continue
        seen.add(key)
        deduped.append(item)
        if len(deduped) >= limit:
            break

    if not deduped:
        session = create_web_session()
        search_html = _request_html(
            session,
            SEARCH_URL,
            params={"dvpf": "pc", "keyword": author_name},
            headers={"Referer": "https://so.toutiao.com/"},
        )
        _, general_items = _collect_search_items(
            search_html,
            limit=max(limit * 3, 20),
            include_users=False,
            include_content=True,
        )
        for item in general_items:
            key = clean_text(item.get("id") or item.get("url") or item.get("title"))
            if not key or key in seen:
                continue
            seen.add(key)
            deduped.append(item)
            if len(deduped) >= limit:
                break

    if not deduped:
        return _build_list_result("author_content_list", [], {"author_query": author_name, "request_url": url}, has_more=False, next_cursor="")

    return _build_list_result(
        "author_content_list",
        deduped[:limit],
        {
            "author_query": author_name,
            "request_url": url,
            "profile_item": profile_item or {},
            "search_user_title": _current_title(user_html),
            "seed_detail": seed_detail or {},
        },
    )


@mcp.tool()
def get_hot_list(limit: int = 20, refresh: bool = False) -> dict[str, Any]:
    """获取今日头条热榜。"""
    del refresh
    return _fetch_hot_list(_normalize_limit(limit))


@mcp.tool()
def get_feed_list(
    channel: str = "",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """获取今日头条推荐流。"""
    del refresh
    if clean_text(channel):
        return _build_list_result(
            "feed_list",
            [],
            {"reason": "invalid_channel", "channel": clean_text(channel)},
            has_more=False,
            next_cursor="",
        )
    return _fetch_feed_list(clean_text(cursor), _normalize_limit(limit))


@mcp.tool()
def search_content(query: str, cursor: str = "", limit: int = 20) -> dict[str, Any]:
    """搜索今日头条公开内容。"""
    del cursor
    normalized_query = clean_text(query)
    if not normalized_query:
        return _build_list_result(
            "search",
            [],
            {"query": "", "reason": "empty_query"},
            has_more=False,
            next_cursor="",
        )
    return _fetch_search_content(normalized_query, _normalize_limit(limit))


@mcp.tool()
def get_content_detail(content_id: str = "", url: str = "") -> dict[str, Any]:
    """获取今日头条内容详情。"""
    return _fetch_content_detail(content_id=content_id, url=url)


@mcp.tool()
def get_author_profile(author_id: str = "", url: str = "") -> dict[str, Any]:
    """获取今日头条作者公开信息。"""
    return _fetch_author_profile(author_id=author_id, url=url)


@mcp.tool()
def get_author_content_list(
    author_id: str = "",
    url: str = "",
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """获取今日头条作者公开作品列表。"""
    del cursor
    return _fetch_author_content_list(author_id=author_id, url=url, limit=_normalize_limit(limit))


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
