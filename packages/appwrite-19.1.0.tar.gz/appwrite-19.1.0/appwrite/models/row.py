from typing import Any, Dict, List, Optional, Union, cast, Generic, TypeVar, Type
from pydantic import Field, PrivateAttr

from .base_model import AppwriteModel

T = TypeVar('T')

class Row(AppwriteModel, Generic[T]):
    """
    Row

    Attributes
    ----------
    id : str
        Row ID.
    sequence : str
        Row sequence ID.
    tableid : str
        Table ID.
    databaseid : str
        Database ID.
    createdat : str
        Row creation date in ISO 8601 format.
    updatedat : str
        Row update date in ISO 8601 format.
    permissions : List[Any]
        Row permissions. [Learn more about permissions](https://appwrite.io/docs/permissions).
    """
    id: str = Field(..., alias='$id')
    sequence: str = Field(..., alias='$sequence')
    tableid: str = Field(..., alias='$tableId')
    databaseid: str = Field(..., alias='$databaseId')
    createdat: str = Field(..., alias='$createdAt')
    updatedat: str = Field(..., alias='$updatedAt')
    permissions: List[Any] = Field(..., alias='$permissions')

    @classmethod
    def with_data(cls, data: Dict[str, Any], model_type: Type[T] = dict) -> 'Row[T]':
        """Create Row instance with typed data."""
        internal_aliases = {'$id', '$sequence', '$tableId', '$databaseId', '$createdAt', '$updatedAt', '$permissions'}
        internal_fields = {k: v for k, v in data.items() if k in internal_aliases}
        user_data = {k: v for k, v in data.items() if k not in internal_aliases and k != 'data'}
        nested = data.get('data')
        if isinstance(nested, dict):
            user_data = {**nested, **user_data}
        instance = cls.model_validate(internal_fields)
        instance._data = model_type(**user_data) if model_type is not dict else user_data
        return instance

    _data: Any = PrivateAttr(default_factory=dict)

    @property
    def data(self) -> T:
        return cast(T, self._data)

    @data.setter
    def data(self, value: T) -> None:
        object.__setattr__(self, '_data', value)

    def to_dict(self) -> Dict[str, Any]:
        result = super().to_dict()
        if hasattr(self, '_data'):
            if isinstance(self._data, dict):
                result['data'] = self._data
            elif hasattr(self._data, 'model_dump'):
                result['data'] = self._data.model_dump(mode='json')
            else:
                result['data'] = self._data
        return result
