"""Tests for pane-context-aware features: section dividers, clickable sort, and footer bindings."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


def _make_project_with_templates(tmp_path, monkeypatch):
    """Helper: set up a project dir with 1 session and mock templates."""
    import cctree.core.templates as tpl_mod

    dest = "sess0001-0000-0000-0000-000000000001.jsonl"
    (tmp_path / dest).write_text((FIXTURES / "simple_session.jsonl").read_text())
    old_time = time.time() - 300
    os.utime(tmp_path / dest, (old_time, old_time))

    tpl = {
        "name": "test-tpl",
        "sourceSessionId": "sess0001-0000-0000-0000-000000000001",
        "sourceMessageUuid": "some-uuid",
        "sourceDisplayName": "simple-session",
        "sourceSlug": "simple-session",
        "createdAt": "2026-04-01T00:00:00Z",
        "lastForkedAt": "2026-04-10T00:00:00Z",
        "forkCount": 3,
        "projectDirName": "test",
    }
    monkeypatch.setattr(tpl_mod, "list_templates", lambda *a, **kw: [tpl])
    return tmp_path


# ── Section divider visual separation ──────────────────────────────────


class TestSectionDividers:
    """Templates and Sessions section headers should be visually distinct."""

    @pytest.fixture
    def project_dir(self, tmp_path, monkeypatch):
        return _make_project_with_templates(tmp_path, monkeypatch)

    @pytest.mark.asyncio
    async def test_template_divider_uses_heavy_rule(self, project_dir):
        """Template section header should use heavy box-drawing chars (━) for visibility."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            items = list(lv.children)
            tpl_divider = next(
                (item for item in items if getattr(item, "name", "") == "__tpl_divider__"),
                None,
            )
            assert tpl_divider is not None, "Template divider not found"
            label_text = str(tpl_divider.query_one("Label").render())
            assert "━" in label_text, (
                f"Template divider should use heavy rule (━) for visual separation, got: {label_text}"
            )

    @pytest.mark.asyncio
    async def test_session_divider_uses_heavy_rule(self, project_dir):
        """Session section header should use heavy box-drawing chars (━) for visibility."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            items = list(lv.children)
            sess_divider = next(
                (item for item in items if getattr(item, "name", "") == "__sess_divider__"),
                None,
            )
            assert sess_divider is not None, "Session divider not found"
            label_text = str(sess_divider.query_one("Label").render())
            assert "━" in label_text, (
                f"Session divider should use heavy rule (━) for visual separation, got: {label_text}"
            )

    @pytest.mark.asyncio
    async def test_template_and_session_dividers_look_different(self, project_dir):
        """The two section dividers should be visually distinguishable from each other."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            items = list(lv.children)
            tpl_text = str(
                next(i for i in items if getattr(i, "name", "") == "__tpl_divider__")
                .query_one("Label").render()
            )
            sess_text = str(
                next(i for i in items if getattr(i, "name", "") == "__sess_divider__")
                .query_one("Label").render()
            )
            assert tpl_text != sess_text, (
                "Template and Session dividers should look different"
            )

    @pytest.mark.asyncio
    async def test_template_divider_contains_section_name(self, project_dir):
        """Template divider should contain the word 'Templates'."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            items = list(lv.children)
            tpl_divider = next(i for i in items if getattr(i, "name", "") == "__tpl_divider__")
            label_text = str(tpl_divider.query_one("Label").render())
            assert "Templates" in label_text

    @pytest.mark.asyncio
    async def test_session_divider_contains_section_name(self, project_dir):
        """Session divider should contain the word 'Sessions'."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            items = list(lv.children)
            sess_divider = next(i for i in items if getattr(i, "name", "") == "__sess_divider__")
            label_text = str(sess_divider.query_one("Label").render())
            assert "Sessions" in label_text


# ── Clickable sort mode on dividers ────────────────────────────────────


class TestClickableSortDividers:
    """Clicking (selecting) a section divider should toggle its sort mode."""

    @pytest.fixture
    def project_dir(self, tmp_path, monkeypatch):
        return _make_project_with_templates(tmp_path, monkeypatch)

    @pytest.mark.asyncio
    async def test_selecting_session_divider_toggles_sort(self, project_dir):
        """Pressing enter on the session divider should toggle session sort mode."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            assert app.sort_by == "last_activity"

            # Navigate to the sessions divider
            for _ in range(20):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "")
                    if name == "__sess_divider__":
                        break

            # Confirm we're on the divider
            idx = lv.index if lv.index is not None else 0
            items = list(lv.children)
            assert getattr(items[idx], "name", "") == "__sess_divider__", \
                "Cursor should be on sessions divider"

            # Select (enter) the divider — should toggle sort
            await pilot.press("enter")
            await pilot.pause()

            assert app.sort_by == "started_at", \
                f"Selecting session divider should toggle sort, got: {app.sort_by}"

    @pytest.mark.asyncio
    async def test_selecting_template_divider_toggles_template_sort(self, project_dir):
        """Pressing enter on the template divider should toggle template sort mode."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            assert app.template_sort_by == "last_forked"

            # Template divider should be first item (index 0)
            lv.index = 0
            await pilot.pause()
            items = list(lv.children)
            assert getattr(items[0], "name", "") == "__tpl_divider__"

            # Select it
            await pilot.press("enter")
            await pilot.pause()

            assert app.template_sort_by == "fork_count", \
                f"Selecting template divider should cycle sort, got: {app.template_sort_by}"

    @pytest.mark.asyncio
    async def test_selecting_session_divider_toggles_back(self, project_dir):
        """Selecting session divider twice should cycle back to original sort."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            original = app.sort_by

            # Navigate to sessions divider
            for _ in range(20):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    if getattr(items[idx], "name", "") == "__sess_divider__":
                        break

            # Toggle twice
            await pilot.press("enter")
            await pilot.pause()
            assert app.sort_by != original

            # Navigate back to divider (list was refreshed, find it again)
            for _ in range(20):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    if getattr(items[idx], "name", "") == "__sess_divider__":
                        break

            await pilot.press("enter")
            await pilot.pause()
            assert app.sort_by == original


# ── Context-aware footer bindings ──────────────────────────────────────


class TestContextAwareBindings:
    """Keyboard shortcuts should only be active when the relevant pane is focused."""

    @pytest.fixture
    def project_dir(self, tmp_path, monkeypatch):
        return _make_project_with_templates(tmp_path, monkeypatch)

    # ── Detail-pane-only actions disabled in sessions pane ──

    @pytest.mark.asyncio
    async def test_copy_disabled_in_sessions_pane(self, project_dir):
        """Copy (c) should be disabled when sessions pane is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            assert not app.check_action("copy_node", ())

    @pytest.mark.asyncio
    async def test_copy_all_disabled_in_sessions_pane(self, project_dir):
        """Copy all (C) should be disabled when sessions pane is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            assert not app.check_action("copy_subtree", ())

    @pytest.mark.asyncio
    async def test_fork_disabled_in_sessions_pane(self, project_dir):
        """Fork (f) should be disabled when sessions pane is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            assert not app.check_action("copy_fork", ())

    @pytest.mark.asyncio
    async def test_save_template_disabled_in_sessions_pane(self, project_dir):
        """Save template (T) should be disabled when sessions pane is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            assert not app.check_action("save_template", ())

    @pytest.mark.asyncio
    async def test_fold_levels_disabled_in_sessions_pane(self, project_dir):
        """Fold-level keys (1/2/3) should be disabled when sessions pane is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            for action in ("fold_level_1", "fold_level_2", "fold_level_3"):
                assert not app.check_action(action, ()), \
                    f"{action} should be disabled in sessions pane"

    @pytest.mark.asyncio
    async def test_expand_collapse_disabled_in_sessions_pane(self, project_dir):
        """Expand (E) and Collapse (W) should be disabled when sessions pane is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            assert not app.check_action("expand_all", ())
            assert not app.check_action("collapse_all", ())

    # ── Detail-pane-only actions enabled in detail pane ──

    @pytest.mark.asyncio
    async def test_copy_enabled_in_detail_pane(self, project_dir):
        """Copy (c) should be enabled when detail tree is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            # Load a session and move to detail pane
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert tree.has_focus
            assert app.check_action("copy_node", ())

    @pytest.mark.asyncio
    async def test_fork_enabled_in_detail_pane(self, project_dir):
        """Fork (f) should be enabled when detail tree is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert tree.has_focus
            assert app.check_action("copy_fork", ())

    @pytest.mark.asyncio
    async def test_fold_levels_enabled_in_detail_pane(self, project_dir):
        """Fold-level keys should be enabled when detail tree is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert tree.has_focus
            for action in ("fold_level_1", "fold_level_2", "fold_level_3",
                           "expand_all", "collapse_all"):
                assert app.check_action(action, ()), \
                    f"{action} should be enabled in detail pane"

    # ── Sessions-pane-only actions disabled in detail pane ──

    @pytest.mark.asyncio
    async def test_sort_disabled_in_detail_pane(self, project_dir):
        """Sort (S) should be disabled when detail tree is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert tree.has_focus
            assert not app.check_action("toggle_sort", ())

    # ── Template-specific actions: R and X ──

    @pytest.mark.asyncio
    async def test_rename_tpl_disabled_in_detail_pane(self, project_dir):
        """Rename template (R) should be disabled when detail pane is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert tree.has_focus
            assert not app.check_action("rename_template", ())

    @pytest.mark.asyncio
    async def test_delete_tpl_disabled_in_detail_pane(self, project_dir):
        """Delete template (X) should be disabled when detail pane is focused."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert tree.has_focus
            assert not app.check_action("delete_template", ())

    @pytest.mark.asyncio
    async def test_rename_tpl_disabled_when_cursor_on_session(self, project_dir):
        """Rename template (R) should be disabled when cursor is on a session, not a template."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            assert lv.has_focus

            # Navigate past templates to a session item
            for _ in range(20):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break  # on a real session item

            assert not app.check_action("rename_template", ()), \
                "Rename template should be disabled when cursor is on a session"

    @pytest.mark.asyncio
    async def test_delete_tpl_disabled_when_cursor_on_session(self, project_dir):
        """Delete template (X) should be disabled when cursor is on a session, not a template."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            assert lv.has_focus

            # Navigate past templates to a session item
            for _ in range(20):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            assert not app.check_action("delete_template", ()), \
                "Delete template should be disabled when cursor is on a session"

    @pytest.mark.asyncio
    async def test_rename_tpl_enabled_when_cursor_on_template(self, project_dir):
        """Rename template (R) should be enabled when cursor is on a template item."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            assert lv.has_focus

            # Navigate to a template item (starts with __tpl__ but not __tpl_divider__)
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name.startswith("__tpl__"):
                        break

            idx = lv.index if lv.index is not None else 0
            items = list(lv.children)
            assert getattr(items[idx], "name", "").startswith("__tpl__"), \
                "Should be on a template item for this test"

            assert app.check_action("rename_template", ()), \
                "Rename template should be enabled when cursor is on a template"

    @pytest.mark.asyncio
    async def test_delete_tpl_enabled_when_cursor_on_template(self, project_dir):
        """Delete template (X) should be enabled when cursor is on a template item."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            assert lv.has_focus

            # Navigate to a template item
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name.startswith("__tpl__"):
                        break

            assert app.check_action("delete_template", ()), \
                "Delete template should be enabled when cursor is on a template"

    # ── Template detail: fork (F) enabled from either pane ──

    @pytest.mark.asyncio
    async def test_fork_enabled_in_template_detail_sessions_pane(self, project_dir):
        """Fork (F) should be enabled in template detail even when sessions pane has focus."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)

            # Navigate to the template item to trigger template detail
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name.startswith("__tpl__"):
                        break

            # Verify we're in template detail with sessions pane focused
            assert app._browsing_template is not None, \
                "Should be in template detail view"
            assert app.current_session is None, \
                "current_session should be None in template detail"
            assert lv.has_focus, \
                "Sessions pane should still have focus"

            assert app.check_action("copy_fork", ()), \
                "Fork should be enabled in template detail even from sessions pane"

    @pytest.mark.asyncio
    async def test_fork_enabled_in_template_detail_tree_pane(self, project_dir):
        """Fork (F) should be enabled in template detail when tree has focus."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)

            # Navigate to the template item
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name.startswith("__tpl__"):
                        break

            # Move focus to the tree pane
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert app._browsing_template is not None
            assert tree.has_focus

            assert app.check_action("copy_fork", ()), \
                "Fork should be enabled in template detail from tree pane"

    @pytest.mark.asyncio
    async def test_on_key_handles_f_in_template_detail(self, project_dir, monkeypatch):
        """on_key should explicitly handle 'f' in template detail (not rely on binding system).

        The Textual binding system dispatches correctly in pilot tests but may not
        reach App-level bindings in real terminals when ListView has focus. The on_key
        handler provides a reliable path that doesn't depend on binding dispatch."""
        from cctree.tui.app import CctreeApp
        from textual import events
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)

            # Navigate to the template item
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name.startswith("__tpl__"):
                        break

            assert app._browsing_template is not None
            assert lv.has_focus

            # Mock _fork_from_template to track calls
            fork_called = []
            monkeypatch.setattr(app, "_fork_from_template", lambda: fork_called.append(True))

            # Directly call on_key (bypassing binding system) to verify
            # the handler itself catches "f" in template detail
            # Must handle both "f" and "F" since hints show uppercase [F]
            for key in ("f", "F"):
                fork_called.clear()
                event = events.Key(key, key)
                app.on_key(event)
                assert fork_called, \
                    f"on_key should handle {key!r} in template detail"

    @pytest.mark.asyncio
    async def test_template_detail_hints_show_key_labels(self, project_dir):
        """Template detail header should show literal [F], [S], [R], [X] key labels."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)

            # Navigate to the template item
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name.startswith("__tpl__"):
                        break

            assert app._browsing_template is not None

            header = app.query_one("#session-header", Static)
            rendered = str(header.render())

            for key_label in ("[F]", "[S]", "[R]", "[X]"):
                assert key_label in rendered, \
                    f"Template detail hints should show literal {key_label} but got: {rendered}"

    # ── Global actions always enabled ──

    @pytest.mark.asyncio
    async def test_global_actions_always_enabled(self, project_dir):
        """Global actions (q, /, tab) should be enabled regardless of focus."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            # In sessions pane
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            for action in ("quit", "search", "focus_next_pane"):
                assert app.check_action(action, ()), \
                    f"{action} should be enabled in sessions pane"

            # Move to detail pane
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert tree.has_focus
            for action in ("quit", "search", "focus_next_pane"):
                assert app.check_action(action, ()), \
                    f"{action} should be enabled in detail pane"
