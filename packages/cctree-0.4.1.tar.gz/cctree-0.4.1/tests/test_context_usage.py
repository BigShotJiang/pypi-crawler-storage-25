"""Tests for per-turn context window tracking."""
from __future__ import annotations

from pathlib import Path

import pytest

from cctree.core.context_usage import (
    TurnContext,
    build_turn_context_map,
    build_turn_context_map_for_wake_ups,
    format_delta_label,
    format_mini_bar,
    format_no_data,
    format_status_lines,
    _delta_threshold_color,
    _humanize,
    _stacked_bar,
    _threshold_color,
)
from cctree.core.model import SessionEvent


def _assistant_event(uuid: str, model: str = "claude-opus-4-6",
                     input_tokens: int = 0,
                     cache_creation: int = 0,
                     cache_read: int = 0,
                     output_tokens: int = 100) -> SessionEvent:
    return SessionEvent.model_validate({
        "type": "assistant",
        "uuid": uuid,
        "message": {
            "role": "assistant",
            "model": model,
            "content": "ok",
            "usage": {
                "input_tokens": input_tokens,
                "cache_creation_input_tokens": cache_creation,
                "cache_read_input_tokens": cache_read,
                "output_tokens": output_tokens,
            },
        },
    })


def _user_event(uuid: str, content: str = "hi") -> SessionEvent:
    return SessionEvent.model_validate({
        "type": "user",
        "uuid": uuid,
        "message": {"role": "user", "content": content},
    })


def _compact_event(uuid: str) -> SessionEvent:
    return SessionEvent.model_validate({
        "type": "system",
        "subtype": "compact_boundary",
        "uuid": uuid,
    })


class TestBuildTurnContextMap:

    def test_basic_assistant_user_mapping(self):
        events = [
            _user_event("u1"),
            _assistant_event("a1", input_tokens=3, cache_creation=5_000, cache_read=10_000),
            _user_event("u2"),
            _assistant_event("a2", input_tokens=3, cache_creation=2_000, cache_read=15_000),
        ]
        m = build_turn_context_map(events)
        # Assistant turns have their own context
        assert "a1" in m and "a2" in m
        # u2 maps to prior assistant (a1); u1 has no prior assistant, not in map
        assert m["u2"].total_input == m["a1"].total_input
        assert "u1" not in m

    def test_delta_vs_prior_turn(self):
        events = [
            _assistant_event("a1", cache_read=10_000),
            _assistant_event("a2", cache_read=15_000),
        ]
        m = build_turn_context_map(events)
        assert m["a1"].delta is None
        assert m["a2"].delta == 5_000

    def test_first_turn_delta_none(self):
        events = [_assistant_event("a1", cache_read=5_000)]
        m = build_turn_context_map(events)
        assert m["a1"].delta is None

    def test_synthetic_skipped(self):
        events = [
            _assistant_event("real1", cache_read=10_000),
            _assistant_event("synth", model="<synthetic>", output_tokens=0),
            _user_event("u_after_synth"),
            _assistant_event("real2", cache_read=20_000),
        ]
        m = build_turn_context_map(events)
        assert "synth" not in m
        # user event after synthetic maps to the last REAL turn (real1), not synthetic
        assert m["u_after_synth"].total_input == m["real1"].total_input

    def test_zero_usage_skipped(self):
        events = [
            _assistant_event("real1", cache_read=5_000),
            _assistant_event("empty", input_tokens=0, cache_creation=0, cache_read=0, output_tokens=0),
        ]
        m = build_turn_context_map(events)
        assert "empty" not in m

    def test_first_user_has_no_context(self):
        events = [_user_event("u_first"), _assistant_event("a1", cache_read=5_000)]
        m = build_turn_context_map(events)
        assert "u_first" not in m
        assert "a1" in m

    def test_outer_propagates(self):
        outer = TurnContext(
            input_tokens=0, output_tokens=0, cache_read=40_000,
            cache_creation=0, total_input=40_000, model="claude-opus-4-6",
            model_short="opus-4-6", window_size=1_000_000, percent=4.0,
        )
        events = [_assistant_event("sub_a1", cache_read=10_000)]
        m = build_turn_context_map(events, outer=outer)
        assert m["sub_a1"].outer is outer

    def test_teammate_name_and_color_propagate(self):
        events = [_assistant_event("a1", cache_read=5_000)]
        m = build_turn_context_map(events, teammate_name="alice", teammate_color="blue")
        assert m["a1"].teammate_name == "alice"
        assert m["a1"].teammate_color == "blue"

    def test_compact_boundary_maps_to_prior(self):
        """Codex fix: compact boundary UUID in map → prior turn's TurnContext."""
        events = [
            _assistant_event("a1", cache_read=50_000),
            _compact_event("cpt"),
            _user_event("u2"),
            _assistant_event("a2", cache_read=5_000),
        ]
        m = build_turn_context_map(events)
        assert "cpt" in m
        assert m["cpt"].total_input == m["a1"].total_input


class TestBuildTurnContextMapForWakeUps:

    def test_delta_resets_per_wake_up(self):
        file_a = [_assistant_event("a_t1", cache_read=1_000),
                  _assistant_event("a_t2", cache_read=2_000)]
        file_b = [_assistant_event("b_t1", cache_read=10_000),
                  _assistant_event("b_t2", cache_read=12_000)]
        m = build_turn_context_map_for_wake_ups(
            [file_a, file_b], teammate_name="alice", teammate_color="blue",
        )
        assert m["a_t1"].is_wake_up_start is True
        assert m["a_t1"].delta is None
        assert m["a_t2"].is_wake_up_start is False
        assert m["a_t2"].delta == 1_000
        # b_t1 is the start of a new wake-up — delta resets to None, flagged
        assert m["b_t1"].is_wake_up_start is True
        assert m["b_t1"].delta is None
        assert m["b_t2"].is_wake_up_start is False
        assert m["b_t2"].delta == 2_000

    def test_teammate_metadata_on_all_entries(self):
        file_a = [_assistant_event("a1", cache_read=500)]
        m = build_turn_context_map_for_wake_ups(
            [file_a], teammate_name="bob", teammate_color="green",
        )
        assert m["a1"].teammate_name == "bob"
        assert m["a1"].teammate_color == "green"


class TestStackedBar:

    def _tc(self, total, input_t=0, cache_read=0, cache_create=0, window=1_000_000) -> TurnContext:
        return TurnContext(
            input_tokens=input_t, output_tokens=50,
            cache_read=cache_read, cache_creation=cache_create,
            total_input=total, model="m", model_short="m",
            window_size=window, percent=(total / window * 100) if window else 0.0,
        )

    def test_bar_bounds(self):
        tc = self._tc(total=250_000, cache_read=250_000, window=1_000_000)
        bar = _stacked_bar(tc, width=20)
        assert bar.startswith("▕") and bar.endswith("▏")

    def test_empty_bar_all_dim(self):
        tc = self._tc(total=0, window=1_000_000)
        bar = _stacked_bar(tc, width=10)
        assert "█" not in bar
        assert "░" in bar

    def test_full_bar(self):
        tc = self._tc(total=1_000_000, input_t=500_000, cache_read=500_000, window=1_000_000)
        bar = _stacked_bar(tc, width=10)
        # 10 chars of █, no empty
        assert bar.count("█") == 10
        assert bar.count("░") == 0

    def test_window_zero_returns_empty(self):
        tc = self._tc(total=1_000, window=0)
        bar = _stacked_bar(tc, width=5)
        assert bar == "▕░░░░░▏"


class TestThresholdColors:

    def test_under_50(self):
        assert _threshold_color(4.5) == "white"

    def test_50_to_80(self):
        assert _threshold_color(55.0) == "yellow"

    def test_80_to_95(self):
        assert _threshold_color(82.0) == "orange1"

    def test_95_plus(self):
        assert _threshold_color(98.0) == "red"

    def test_boundaries_exact(self):
        assert _threshold_color(49.9) == "white"
        assert _threshold_color(50.0) == "yellow"
        assert _threshold_color(79.9) == "yellow"
        assert _threshold_color(80.0) == "orange1"
        assert _threshold_color(94.9) == "orange1"
        assert _threshold_color(95.0) == "red"


class TestHumanize:

    def test_under_1k(self):
        assert _humanize(42) == "42"

    def test_thousands(self):
        assert _humanize(1_234) == "1.2K"

    def test_millions(self):
        assert _humanize(1_234_567) == "1.2M"


class TestFormatStatusLines:

    def _tc(self, **kwargs) -> TurnContext:
        defaults = dict(
            input_tokens=3, output_tokens=120, cache_read=10_000, cache_creation=5_000,
            total_input=15_003, model="claude-opus-4-6", model_short="opus-4-6",
            window_size=1_000_000, percent=1.5, delta=2_000,
        )
        defaults.update(kwargs)
        return TurnContext(**defaults)

    def test_normal_wide_returns_2_lines(self):
        lines = format_status_lines(self._tc(), narrow=False)
        assert len(lines) == 2
        assert "opus-4-6" in lines[0]
        assert "in:3" in lines[1]
        assert "+read:" in lines[1]

    def test_normal_narrow_compact(self):
        lines = format_status_lines(self._tc(), narrow=True)
        assert len(lines) == 2
        # Model moved to line 2 in narrow mode
        assert "opus-4-6" in lines[1]
        # Breakdown abbreviated
        assert "r:" in lines[1] and "c:" in lines[1] and "o:" in lines[1]
        assert "+read:" not in lines[1]

    def test_subagent_3_lines_with_parent(self):
        outer = self._tc(total_input=45_000, percent=4.5)
        lines = format_status_lines(self._tc(outer=outer), narrow=False)
        assert len(lines) == 3
        assert "↳ sub" in lines[0]
        assert "from parent turn" in lines[2]

    def test_teammate_color_prefix(self):
        tc = self._tc(teammate_name="alice", teammate_color="blue")
        lines = format_status_lines(tc, narrow=False)
        assert "alice" in lines[0]
        assert "[blue]" in lines[0]

    def test_teammate_without_known_color_falls_back_to_cyan(self):
        tc = self._tc(teammate_name="zed")
        lines = format_status_lines(tc, narrow=False)
        assert "zed" in lines[0]
        assert "[cyan]" in lines[0]

    def test_warn_glyph_at_95_percent(self):
        tc = self._tc(percent=98.0, total_input=980_000)
        lines = format_status_lines(tc, narrow=False)
        assert "⚠" in lines[0]

    def test_no_warn_glyph_at_80_percent(self):
        tc = self._tc(percent=82.0, total_input=820_000)
        lines = format_status_lines(tc, narrow=False)
        assert "⚠" not in lines[0]
        # Still has orange on the percent
        assert "[orange1]" in lines[0]

    def test_delta_none_shows_em_dash(self):
        tc = self._tc(delta=None)
        lines = format_status_lines(tc, narrow=False)
        assert "Δ —" in lines[0]

    def test_delta_wake_up_start_marker(self):
        tc = self._tc(delta=None, is_wake_up_start=True)
        lines = format_status_lines(tc, narrow=False)
        assert "(new wake-up)" in lines[0]

    def test_delta_positive(self):
        tc = self._tc(delta=5_200)
        lines = format_status_lines(tc, narrow=False)
        assert "Δ+5.2K" in lines[0]

    def test_delta_negative(self):
        tc = self._tc(delta=-120_000)
        lines = format_status_lines(tc, narrow=False)
        assert "Δ−120.0K" in lines[0]

    def test_none_tc_returns_unknown_message(self):
        lines = format_status_lines(None)
        assert len(lines) == 1
        assert "no usage data" in lines[0]

    def test_none_tc_with_reason(self):
        lines = format_status_lines(None, no_data_reason="older_session")
        assert "predates per-turn usage logging" in lines[0]

    def test_escapes_teammate_name_brackets(self):
        """Rich markup injection guard: teammate name with brackets stays safe."""
        tc = self._tc(teammate_name="Agent[prod]", teammate_color="blue")
        lines = format_status_lines(tc, narrow=False)
        # Rich's escape turns [ into \[; the raw "Agent[prod]" should NOT appear verbatim
        # in a way that would re-enter markup parsing.
        assert "Agent\\[prod\\]" in lines[0] or "Agent[prod]" not in lines[0].replace("[blue]", "")

    def test_escapes_model_brackets(self):
        tc = self._tc(model_short="custom[v1]")
        lines = format_status_lines(tc, narrow=False)
        # model short is Rich-markup escaped
        assert "custom[v1]" not in " ".join(lines).replace("\\[", "").replace("\\]", "")


class TestFormatNoData:

    @pytest.mark.parametrize("reason,needle", [
        ("older_session", "predates per-turn usage logging"),
        ("synthetic", "synthetic event"),
        ("session_start", "session start"),
        ("teammates_section", "expand to load teammate timeline"),
        ("subagent_placeholder", "expand to load subagent"),
        ("teammate_placeholder", "expand to load teammate timeline"),
        ("teammate_empty", "teammate has no transcripts"),
        ("template", "template metadata"),
        ("unknown", "no usage data"),
    ])
    def test_each_reason_has_correct_message(self, reason, needle):
        lines = format_no_data(reason)
        assert len(lines) == 1
        assert needle in lines[0]

    def test_unknown_reason_falls_back(self):
        lines = format_no_data("nonexistent")
        assert "no usage data" in lines[0]


class TestMergeWakeUpEventsParity:
    """The extracted helper must produce byte-for-byte identical output to the
    existing load_teammate_timeline, when given the same files."""

    def test_order_matches_load_teammate_timeline(self, tmp_path):
        from cctree.core.teammate_sessions import load_teammate_timeline, merge_wake_up_events
        from cctree.core.parser import parse_jsonl

        # Create two tiny JSONL files with events at different timestamps
        f1 = tmp_path / "f1.jsonl"
        f2 = tmp_path / "f2.jsonl"
        f1.write_text(
            '{"type":"user","uuid":"f1-u1","timestamp":"2026-04-10T10:00:00.000Z","message":{"role":"user","content":"a"}}\n'
            '{"type":"assistant","uuid":"f1-a1","timestamp":"2026-04-10T10:00:02.000Z","message":{"role":"assistant","content":"b","model":"claude-opus-4-6"}}\n'
        )
        f2.write_text(
            '{"type":"user","uuid":"f2-u1","timestamp":"2026-04-10T10:01:00.000Z","message":{"role":"user","content":"c"}}\n'
            '{"type":"assistant","uuid":"f2-a1","timestamp":"2026-04-10T10:01:02.000Z","message":{"role":"assistant","content":"d","model":"claude-opus-4-6"}}\n'
        )
        paths = [f1, f2]
        from_loader = load_teammate_timeline(paths)
        from_merger = merge_wake_up_events([parse_jsonl(p) for p in paths])
        assert [e.uuid for e in from_loader] == [e.uuid for e in from_merger]

    def test_empty_inputs(self):
        from cctree.core.teammate_sessions import merge_wake_up_events
        assert merge_wake_up_events([]) == []
        assert merge_wake_up_events([[], []]) == []


class TestFormatMiniBar:
    """Tests for the inline context mini-bar used in tree annotations."""

    def _tc(self, total: int = 10_000, window: int = 200_000, pct: float = 5.0) -> TurnContext:
        return TurnContext(
            input_tokens=total, output_tokens=100,
            cache_read=0, cache_creation=0,
            total_input=total, model="claude-opus-4-6",
            model_short="opus-4-6", window_size=window, percent=pct,
        )

    def test_none_returns_dim_dash(self):
        result = format_mini_bar(None)
        assert "—" in result
        assert "dim" in result

    def test_normal_bar_has_borders(self):
        result = format_mini_bar(self._tc())
        assert "▕" in result
        assert "▏" in result

    def test_normal_bar_has_humanized_total(self):
        result = format_mini_bar(self._tc(total=10_000))
        assert "10.0K" in result

    def test_full_bar_all_filled(self):
        result = format_mini_bar(self._tc(total=200_000, window=200_000, pct=100.0))
        assert "█" * 5 in result

    def test_zero_total_all_empty(self):
        result = format_mini_bar(self._tc(total=0, window=200_000, pct=0.0))
        assert "░" * 5 in result

    def test_threshold_color_white_under_50(self):
        result = format_mini_bar(self._tc(pct=10.0))
        assert "white" in result

    def test_threshold_color_yellow_at_50(self):
        result = format_mini_bar(self._tc(pct=50.0))
        assert "yellow" in result

    def test_threshold_color_red_at_95(self):
        result = format_mini_bar(self._tc(pct=95.0))
        assert "red" in result

    def test_window_zero_graceful(self):
        result = format_mini_bar(self._tc(total=100, window=0, pct=0.0))
        assert "░" in result

    def test_tiny_nonzero_shows_at_least_one_filled(self):
        result = format_mini_bar(self._tc(total=1, window=200_000, pct=0.0005))
        assert "█" in result


class TestDeltaThresholdColor:
    """Threshold colors for per-turn delta values."""

    def test_under_1k(self):
        assert _delta_threshold_color(500) == "white"

    def test_at_1k(self):
        assert _delta_threshold_color(1_000) == "yellow"

    def test_between_1k_and_5k(self):
        assert _delta_threshold_color(3_000) == "yellow"

    def test_at_5k(self):
        assert _delta_threshold_color(5_000) == "orange1"

    def test_over_5k(self):
        assert _delta_threshold_color(8_000) == "orange1"

    def test_negative_uses_abs(self):
        assert _delta_threshold_color(-3_000) == "yellow"

    def test_zero(self):
        assert _delta_threshold_color(0) == "white"


class TestFormatDeltaLabel:
    """Inline delta label for assistant node annotations."""

    def _tc(self, delta: int | None = 1_000, **kwargs) -> TurnContext:
        defaults = dict(
            input_tokens=100, output_tokens=100,
            cache_read=0, cache_creation=0,
            total_input=10_000, model="claude-opus-4-6",
            model_short="opus-4-6", window_size=200_000, percent=5.0,
            delta=delta,
        )
        defaults.update(kwargs)
        return TurnContext(**defaults)

    def test_none_tc_returns_dim_dash(self):
        result = format_delta_label(None)
        assert "—" in result
        assert "dim" in result

    def test_none_delta_returns_dim_dash(self):
        result = format_delta_label(self._tc(delta=None))
        assert "—" in result
        assert "dim" in result

    def test_positive_delta(self):
        result = format_delta_label(self._tc(delta=1_200))
        assert "+1.2K" in result

    def test_negative_delta(self):
        result = format_delta_label(self._tc(delta=-500))
        assert "-500" in result

    def test_zero_delta(self):
        result = format_delta_label(self._tc(delta=0))
        assert "+0" in result

    def test_large_delta(self):
        result = format_delta_label(self._tc(delta=15_000))
        assert "+15.0K" in result

    def test_color_white_under_1k(self):
        result = format_delta_label(self._tc(delta=500))
        assert "white" in result

    def test_color_yellow_1k_to_5k(self):
        result = format_delta_label(self._tc(delta=2_000))
        assert "yellow" in result

    def test_color_orange_over_5k(self):
        result = format_delta_label(self._tc(delta=6_000))
        assert "orange1" in result
