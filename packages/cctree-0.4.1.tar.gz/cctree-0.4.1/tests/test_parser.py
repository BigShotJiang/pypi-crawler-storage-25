"""Tests for cctree.core.parser — JSONL parsing with schema tolerance."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from cctree.core.parser import parse_jsonl, parse_session_id

FIXTURES = Path(__file__).parent / "fixtures"


class TestParseJsonl:
    def test_simple_session(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        assert len(events) == 6  # snapshot + 2 user + 2 assistant + last-prompt

    def test_event_types(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        types = [e.type for e in events]
        assert types == [
            "file-history-snapshot",
            "user", "assistant",
            "user", "assistant",
            "last-prompt",
        ]

    def test_user_message_content(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        user_events = [e for e in events if e.type == "user"]
        assert user_events[0].text_content == "hello world"
        assert user_events[1].text_content == "tell me about python"

    def test_assistant_text_content(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        assistant_events = [e for e in events if e.type == "assistant"]
        assert "Hello! How can I help" in assistant_events[0].text_content

    def test_tool_use_blocks(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        assistant_events = [e for e in events if e.type == "assistant"]
        tools = assistant_events[1].tool_use_blocks
        assert len(tools) == 1
        assert tools[0].name == "Read"
        assert tools[0].input == {"file_path": "/tmp/test.py"}

    def test_tool_result_blocks(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        assistant_events = [e for e in events if e.type == "assistant"]
        results = assistant_events[1].tool_result_blocks
        assert len(results) == 1
        assert results[0].tool_use_id == "toolu_test001"

    def test_uuid_chain(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        msg_events = [e for e in events if e.uuid]
        # First user message has no parent
        assert msg_events[0].parentUuid is None
        # Each subsequent message's parent is the previous message's uuid
        for i in range(1, len(msg_events)):
            assert msg_events[i].parentUuid == msg_events[i - 1].uuid

    def test_session_id_consistent(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session_ids = {e.sessionId for e in events if e.sessionId}
        assert session_ids == {"sess0001-0000-0000-0000-000000000001"}

    def test_slug_consistent(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        slugs = {e.slug for e in events if e.slug}
        assert slugs == {"fuzzy-dancing-penguin"}

    def test_snapshot_message_id_references_user(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        snapshot = events[0]
        first_user = events[1]
        assert snapshot.messageId == first_user.uuid

    def test_empty_file(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
            f.write("")
            f.flush()
            events = parse_jsonl(Path(f.name))
        assert events == []

    def test_file_with_only_newlines(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
            f.write("\n\n\n")
            f.flush()
            events = parse_jsonl(Path(f.name))
        assert events == []

    def test_malformed_json_mid_file(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
            f.write('{"type":"user","uuid":"a","message":{"role":"user","content":"ok"}}\n')
            f.write("THIS IS NOT JSON\n")
            f.write('{"type":"assistant","uuid":"b","parentUuid":"a","message":{"role":"assistant","content":[{"type":"text","text":"hi"}]}}\n')
            f.flush()
            events = parse_jsonl(Path(f.name))
        # Should skip the bad line, keep the other two
        assert len(events) == 2
        assert events[0].type == "user"
        assert events[1].type == "assistant"

    def test_partial_last_line_stripped(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
            f.write('{"type":"user","uuid":"a","message":{"role":"user","content":"ok"}}\n')
            f.write('{"type":"assistant","uuid":"b","parentU')  # truncated
            f.flush()
            events = parse_jsonl(Path(f.name))
        assert len(events) == 1
        assert events[0].type == "user"

    def test_unknown_event_type_preserved(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
            f.write('{"type":"future-event-type","someField":"someValue","uuid":"x"}\n')
            f.flush()
            events = parse_jsonl(Path(f.name))
        assert len(events) == 1
        assert events[0].type == "future-event-type"
        assert events[0].uuid == "x"

    def test_unknown_fields_preserved_via_extra(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
            f.write('{"type":"user","uuid":"a","message":{"role":"user","content":"hi"},"brandNewField":42,"anotherOne":"test"}\n')
            f.flush()
            events = parse_jsonl(Path(f.name))
        assert len(events) == 1
        # Extra fields accessible via model_extra (Pydantic v2)
        assert events[0].model_extra.get("brandNewField") == 42
        assert events[0].model_extra.get("anotherOne") == "test"

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            parse_jsonl(Path("/nonexistent/path.jsonl"))

    def test_binary_garbage_in_line(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="wb", delete=False) as f:
            f.write(b'{"type":"user","uuid":"a","message":{"role":"user","content":"ok"}}\n')
            f.write(b"\x00\xff\xfe\x80garbage\n")
            f.flush()
            # This may raise a UnicodeDecodeError or be handled
            try:
                events = parse_jsonl(Path(f.name))
                # If it handles it, should skip the bad line
                assert len(events) >= 1
            except UnicodeDecodeError:
                # Acceptable — binary in a text file
                pass

    def test_non_dict_json(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
            f.write("[1, 2, 3]\n")
            f.write('"just a string"\n')
            f.write('{"type":"user","uuid":"a","message":{"role":"user","content":"ok"}}\n')
            f.flush()
            events = parse_jsonl(Path(f.name))
        assert len(events) == 1  # only the dict line


class TestParseSessionId:
    def test_from_uuid_filename(self):
        assert parse_session_id(Path("/some/path/46a95dcf-1146-458a-bcd2-54f9ce085866.jsonl")) == "46a95dcf-1146-458a-bcd2-54f9ce085866"

    def test_strips_extension(self):
        assert parse_session_id(Path("foo.jsonl")) == "foo"
