"""Tests for cctree.core.teammate — parsing <teammate-message> tags from user content.

Team-lead session JSONLs inject teammate replies as user messages whose content
is a string containing one or more <teammate-message teammate_id="..." ...> tags.
Some bodies are plain text; others are embedded JSON protocol messages like
{"type": "idle_notification", ...}.
"""
from __future__ import annotations

import pytest


class TestParseTeammateMessages:
    def test_single_tag_with_all_attributes(self):
        from cctree.core.teammate import parse_teammate_messages

        content = (
            '<teammate-message teammate_id="researcher" color="blue" summary="First pass">\n'
            "Here is what I found about the codebase.\n"
            "</teammate-message>"
        )
        blocks = parse_teammate_messages(content)
        assert len(blocks) == 1
        b = blocks[0]
        assert b.teammate_id == "researcher"
        assert b.color == "blue"
        assert b.summary == "First pass"
        assert "Here is what I found" in b.body
        assert b.protocol is None

    def test_multiple_tags_concatenated(self):
        from cctree.core.teammate import parse_teammate_messages

        content = (
            '<teammate-message teammate_id="a" color="blue">first</teammate-message>\n'
            '<teammate-message teammate_id="b" color="green">second</teammate-message>'
        )
        blocks = parse_teammate_messages(content)
        assert [b.teammate_id for b in blocks] == ["a", "b"]
        assert blocks[0].body.strip() == "first"
        assert blocks[1].body.strip() == "second"

    def test_tag_without_summary_or_color(self):
        from cctree.core.teammate import parse_teammate_messages

        content = '<teammate-message teammate_id="x">hi</teammate-message>'
        blocks = parse_teammate_messages(content)
        assert len(blocks) == 1
        assert blocks[0].teammate_id == "x"
        assert blocks[0].color is None
        assert blocks[0].summary is None

    def test_protocol_idle_notification(self):
        from cctree.core.teammate import parse_teammate_messages

        body = (
            '{"type":"idle_notification","from":"x",'
            '"timestamp":"2026-04-16T03:30:51.124Z","idleReason":"available"}'
        )
        content = f'<teammate-message teammate_id="x" color="blue">\n{body}\n</teammate-message>'
        blocks = parse_teammate_messages(content)
        assert len(blocks) == 1
        assert blocks[0].protocol is not None
        assert blocks[0].protocol["type"] == "idle_notification"
        assert blocks[0].protocol["idleReason"] == "available"

    @pytest.mark.parametrize("protocol_type", [
        "shutdown_request",
        "shutdown_response",
        "shutdown_approved",
        "plan_approval_request",
        "plan_approval_response",
        "teammate_terminated",
    ])
    def test_protocol_types_recognized(self, protocol_type):
        from cctree.core.teammate import parse_teammate_messages

        body = f'{{"type":"{protocol_type}","from":"x"}}'
        content = f'<teammate-message teammate_id="x">\n{body}\n</teammate-message>'
        blocks = parse_teammate_messages(content)
        assert len(blocks) == 1
        assert blocks[0].protocol is not None
        assert blocks[0].protocol["type"] == protocol_type

    def test_plain_text_body_has_no_protocol(self):
        from cctree.core.teammate import parse_teammate_messages

        content = (
            '<teammate-message teammate_id="x" summary="Report">\n'
            "plain English text, no JSON at all.\n"
            "</teammate-message>"
        )
        blocks = parse_teammate_messages(content)
        assert blocks[0].protocol is None
        assert "plain English" in blocks[0].body

    def test_content_without_any_tags_returns_empty(self):
        from cctree.core.teammate import parse_teammate_messages

        assert parse_teammate_messages("just a regular user message") == []
        assert parse_teammate_messages("") == []

    def test_malformed_unclosed_tag_handled_gracefully(self):
        from cctree.core.teammate import parse_teammate_messages

        content = '<teammate-message teammate_id="x">no closing tag here'
        blocks = parse_teammate_messages(content)
        # Non-greedy match finds no close => returns empty, does not crash
        assert blocks == []

    def test_nested_angle_brackets_in_body(self):
        """Body may contain <tags> that are not teammate-message tags (e.g. user HTML)."""
        from cctree.core.teammate import parse_teammate_messages

        content = (
            '<teammate-message teammate_id="x">\n'
            "I saw <html> and <div> in the file, attached here.\n"
            "</teammate-message>"
        )
        blocks = parse_teammate_messages(content)
        assert len(blocks) == 1
        assert "<html>" in blocks[0].body
        assert "<div>" in blocks[0].body

    def test_attributes_in_any_order(self):
        """color and summary can appear in either order after teammate_id."""
        from cctree.core.teammate import parse_teammate_messages

        a = '<teammate-message teammate_id="x" summary="s1" color="blue">a</teammate-message>'
        b = '<teammate-message teammate_id="x" color="blue" summary="s1">b</teammate-message>'
        for content in (a, b):
            blocks = parse_teammate_messages(content)
            assert blocks[0].teammate_id == "x"
            assert blocks[0].color == "blue"
            assert blocks[0].summary == "s1"

    def test_teammate_id_with_hyphens(self):
        """Real teammate IDs like code-researcher must parse correctly."""
        from cctree.core.teammate import parse_teammate_messages

        content = '<teammate-message teammate_id="code-researcher" color="blue">ok</teammate-message>'
        blocks = parse_teammate_messages(content)
        assert blocks[0].teammate_id == "code-researcher"

    def test_body_preserves_internal_whitespace(self):
        from cctree.core.teammate import parse_teammate_messages

        content = (
            '<teammate-message teammate_id="x">\n'
            "line one\n"
            "\n"
            "line three\n"
            "</teammate-message>"
        )
        blocks = parse_teammate_messages(content)
        assert "line one" in blocks[0].body
        assert "line three" in blocks[0].body

    def test_json_body_without_type_is_not_protocol(self):
        """Embedded JSON without a 'type' field is not a protocol message."""
        from cctree.core.teammate import parse_teammate_messages

        content = (
            '<teammate-message teammate_id="x">\n'
            '{"result": 42}\n'
            "</teammate-message>"
        )
        blocks = parse_teammate_messages(content)
        assert blocks[0].protocol is None


class TestContainsTeammateMessage:
    def test_true_when_tag_present(self):
        from cctree.core.teammate import contains_teammate_message

        assert contains_teammate_message('<teammate-message teammate_id="x">hi</teammate-message>')

    def test_false_when_absent(self):
        from cctree.core.teammate import contains_teammate_message

        assert not contains_teammate_message("normal text")
        assert not contains_teammate_message("")

    def test_matches_parse_output(self):
        from cctree.core.teammate import contains_teammate_message, parse_teammate_messages

        for sample in [
            "",
            "plain text",
            '<teammate-message teammate_id="x">hi</teammate-message>',
            '<teammate-message teammate_id="x">no closing tag',  # malformed
        ]:
            has = contains_teammate_message(sample)
            parsed = parse_teammate_messages(sample)
            if parsed:
                assert has
