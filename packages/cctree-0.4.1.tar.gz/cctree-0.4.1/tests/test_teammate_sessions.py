"""Tests for cctree.core.teammate_sessions — classify + group teammate JSONL files.

Team teammates and Agent-tool subagents both live in:
  <project-dir>/<session-uuid>/subagents/agent-<hash>.jsonl

with a paired meta file agent-<hash>.meta.json. The two are distinguished by
meta.json shape:

  {"agentType": "Explore", "description": "..."}   -> Agent-tool subagent
  {"agentType": "code-researcher"}                  -> team teammate

A single teammate spans MULTIPLE files (one per turn), all sharing agentType.
"""
from __future__ import annotations

import json
import time

import pytest


def _write_pair(subagents_dir, hash_, meta, events):
    subagents_dir.mkdir(parents=True, exist_ok=True)
    (subagents_dir / f"agent-{hash_}.meta.json").write_text(json.dumps(meta))
    with open(subagents_dir / f"agent-{hash_}.jsonl", "w") as f:
        for evt in events:
            f.write(json.dumps(evt) + "\n")


class TestReadAgentMeta:
    def test_reads_valid_meta(self, tmp_path):
        from cctree.core.teammate_sessions import read_agent_meta

        path = tmp_path / "agent-a1.meta.json"
        path.write_text('{"agentType": "Explore", "description": "x"}')
        assert read_agent_meta(path) == {"agentType": "Explore", "description": "x"}

    def test_missing_meta_returns_none(self, tmp_path):
        from cctree.core.teammate_sessions import read_agent_meta

        assert read_agent_meta(tmp_path / "missing.meta.json") is None

    def test_corrupt_meta_returns_none(self, tmp_path):
        from cctree.core.teammate_sessions import read_agent_meta

        path = tmp_path / "bad.meta.json"
        path.write_text("not json{")
        assert read_agent_meta(path) is None


class TestIsTeammateMeta:
    def test_teammate_without_description(self):
        from cctree.core.teammate_sessions import is_teammate_meta

        assert is_teammate_meta({"agentType": "code-researcher"}) is True

    def test_subagent_with_description(self):
        from cctree.core.teammate_sessions import is_teammate_meta

        assert is_teammate_meta({"agentType": "Explore", "description": "x"}) is False

    def test_subagent_with_generic_type_and_description(self):
        from cctree.core.teammate_sessions import is_teammate_meta

        assert is_teammate_meta(
            {"agentType": "general-purpose", "description": "y"}
        ) is False

    def test_empty_dict_is_not_teammate(self):
        from cctree.core.teammate_sessions import is_teammate_meta

        assert is_teammate_meta({}) is False

    def test_none_is_not_teammate(self):
        from cctree.core.teammate_sessions import is_teammate_meta

        assert is_teammate_meta(None) is False


class TestFindTeammateSessions:
    def test_empty_subagents_dir(self, tmp_path):
        from cctree.core.teammate_sessions import find_teammate_sessions

        sess_dir = tmp_path / "session-uuid"
        sess_dir.mkdir()
        assert find_teammate_sessions(sess_dir) == {}

    def test_missing_subagents_dir(self, tmp_path):
        from cctree.core.teammate_sessions import find_teammate_sessions

        assert find_teammate_sessions(tmp_path / "doesnotexist") == {}

    def test_groups_by_teammate_name(self, tmp_path):
        from cctree.core.teammate_sessions import find_teammate_sessions

        sub_dir = tmp_path / "sess" / "subagents"
        _write_pair(sub_dir, "a1", {"agentType": "researcher"}, [])
        _write_pair(sub_dir, "a2", {"agentType": "researcher"}, [])
        _write_pair(sub_dir, "b1", {"agentType": "writer"}, [])

        result = find_teammate_sessions(tmp_path / "sess")
        assert set(result.keys()) == {"researcher", "writer"}
        assert len(result["researcher"]) == 2
        assert len(result["writer"]) == 1

    def test_excludes_agent_tool_subagents(self, tmp_path):
        from cctree.core.teammate_sessions import find_teammate_sessions

        sub_dir = tmp_path / "sess" / "subagents"
        _write_pair(sub_dir, "t1", {"agentType": "researcher"}, [])
        _write_pair(sub_dir, "s1", {"agentType": "Explore", "description": "x"}, [])
        _write_pair(sub_dir, "s2", {"agentType": "general-purpose", "description": "y"}, [])

        result = find_teammate_sessions(tmp_path / "sess")
        assert set(result.keys()) == {"researcher"}
        assert len(result["researcher"]) == 1

    def test_sorts_by_mtime(self, tmp_path):
        from cctree.core.teammate_sessions import find_teammate_sessions

        sub_dir = tmp_path / "sess" / "subagents"
        _write_pair(sub_dir, "t1", {"agentType": "researcher"}, [])
        time.sleep(0.01)
        _write_pair(sub_dir, "t2", {"agentType": "researcher"}, [])
        time.sleep(0.01)
        _write_pair(sub_dir, "t3", {"agentType": "researcher"}, [])

        result = find_teammate_sessions(tmp_path / "sess")
        paths = result["researcher"]
        # Oldest first
        assert paths[0].name == "agent-t1.jsonl"
        assert paths[-1].name == "agent-t3.jsonl"

    def test_malformed_meta_skipped(self, tmp_path):
        from cctree.core.teammate_sessions import find_teammate_sessions

        sub_dir = tmp_path / "sess" / "subagents"
        sub_dir.mkdir(parents=True)
        # Valid teammate
        _write_pair(sub_dir, "t1", {"agentType": "researcher"}, [])
        # Broken meta (not readable)
        (sub_dir / "agent-bad.meta.json").write_text("broken{")
        (sub_dir / "agent-bad.jsonl").write_text("")

        result = find_teammate_sessions(tmp_path / "sess")
        # Only the good one
        assert set(result.keys()) == {"researcher"}

    def test_jsonl_without_meta_is_skipped(self, tmp_path):
        from cctree.core.teammate_sessions import find_teammate_sessions

        sub_dir = tmp_path / "sess" / "subagents"
        sub_dir.mkdir(parents=True)
        (sub_dir / "agent-orphan.jsonl").write_text('{"type":"user"}\n')

        result = find_teammate_sessions(tmp_path / "sess")
        assert result == {}


class TestLoadTeammateTimeline:
    def test_single_file(self, tmp_path):
        from cctree.core.teammate_sessions import load_teammate_timeline

        sub_dir = tmp_path / "sess" / "subagents"
        _write_pair(sub_dir, "t1", {"agentType": "r"}, [
            {"type": "user", "uuid": "u1", "timestamp": "2026-04-16T00:00:01Z",
             "message": {"role": "user", "content": "hi"}},
            {"type": "assistant", "uuid": "a1", "timestamp": "2026-04-16T00:00:02Z",
             "message": {"role": "assistant", "content": "hello"}},
        ])

        events = load_teammate_timeline([sub_dir / "agent-t1.jsonl"])
        assert len(events) == 2
        assert events[0].uuid == "u1"
        assert events[1].uuid == "a1"

    def test_multiple_files_merged_by_timestamp(self, tmp_path):
        from cctree.core.teammate_sessions import load_teammate_timeline

        sub_dir = tmp_path / "sess" / "subagents"
        # Turn 2 (earlier file content)
        _write_pair(sub_dir, "t2", {"agentType": "r"}, [
            {"type": "user", "uuid": "u2", "timestamp": "2026-04-16T00:00:05Z",
             "message": {"role": "user", "content": "next"}},
        ])
        # Turn 1 (earlier timestamps)
        _write_pair(sub_dir, "t1", {"agentType": "r"}, [
            {"type": "user", "uuid": "u1", "timestamp": "2026-04-16T00:00:01Z",
             "message": {"role": "user", "content": "first"}},
        ])

        events = load_teammate_timeline([
            sub_dir / "agent-t1.jsonl",
            sub_dir / "agent-t2.jsonl",
        ])
        # Should be merged in timestamp order
        assert [e.uuid for e in events] == ["u1", "u2"]

    def test_empty_list_returns_empty(self):
        from cctree.core.teammate_sessions import load_teammate_timeline

        assert load_teammate_timeline([]) == []

    def test_events_without_timestamp_preserved_in_order(self, tmp_path):
        from cctree.core.teammate_sessions import load_teammate_timeline

        sub_dir = tmp_path / "sess" / "subagents"
        _write_pair(sub_dir, "t1", {"agentType": "r"}, [
            {"type": "user", "uuid": "u1"},  # no timestamp
            {"type": "assistant", "uuid": "a1"},
        ])
        events = load_teammate_timeline([sub_dir / "agent-t1.jsonl"])
        # Events without timestamps fall back to file order
        assert [e.uuid for e in events] == ["u1", "a1"]
