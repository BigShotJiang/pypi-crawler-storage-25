"""Tests for fork metadata — sidecar files in ~/.cctree/ for fork provenance."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest
from click.testing import CliRunner

from cctree.cli.main import cli

FIXTURES = Path(__file__).parent / "fixtures"


class TestForkWritesMetadata:
    """Fork should write a .meta.json sidecar in ~/.cctree/projects/<slug>/."""

    @pytest.fixture
    def setup(self, tmp_path, monkeypatch):
        """Set up source project dir + mock CCTREE_DIR."""
        # Source project dir (simulates ~/.claude/projects/<slug>/)
        src_dir = tmp_path / "claude_projects" / "-Users-test-projects-alpha"
        src_dir.mkdir(parents=True)
        src = FIXTURES / "simple_session.jsonl"
        dest = src_dir / "sess0001-0000-0000-0000-000000000001.jsonl"
        dest.write_text(src.read_text())
        old_time = time.time() - 300
        os.utime(dest, (old_time, old_time))

        # Mock cctree dir
        cctree_dir = tmp_path / "cctree"
        monkeypatch.setattr("cctree.core.metadata.CCTREE_DIR", cctree_dir)

        return {"src_dir": src_dir, "cctree_dir": cctree_dir}

    def test_fork_creates_meta_json(self, setup):
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(setup["src_dir"]),
            "--no-launch",
        ])
        assert result.exit_code == 0, result.output

        # Find the new session UUID from output
        for line in result.output.splitlines():
            if line.startswith("Forged session:"):
                new_uuid = line.split(":")[1].strip()
                break
        else:
            pytest.fail("Could not find forged session UUID in output")

        # Meta file should exist in cctree mirror
        meta_dir = setup["cctree_dir"] / "projects" / setup["src_dir"].name
        meta_file = meta_dir / f"{new_uuid}.meta.json"
        assert meta_file.exists(), f"Expected meta file at {meta_file}"

        meta = json.loads(meta_file.read_text())
        assert meta["forkedFrom"]["sessionId"] == "sess0001-0000-0000-0000-000000000001"
        assert meta["forkedFrom"]["messageId"] == "aaa00003-0000-0000-0000-000000000003"
        assert "forgedAt" in meta

    def test_fork_meta_includes_source_session_snapshot(self, setup):
        """Meta file should snapshot the source session's display name, slug,
        project dir, message count, timestamps, and claude version."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(setup["src_dir"]),
            "--no-launch",
        ])
        assert result.exit_code == 0, result.output

        for line in result.output.splitlines():
            if line.startswith("Forged session:"):
                new_uuid = line.split(":")[1].strip()
                break

        meta_dir = setup["cctree_dir"] / "projects" / setup["src_dir"].name
        meta = json.loads((meta_dir / f"{new_uuid}.meta.json").read_text())
        src = meta["forkedFrom"]

        # Must have enriched fields from the source session
        assert src["displayName"] == "fuzzy-dancing-penguin"
        assert src["slug"] == "fuzzy-dancing-penguin"
        assert src["messageCount"] == 4  # 2 user + 2 assistant in simple_session
        assert src["startedAt"] is not None
        assert src["lastActivityAt"] is not None
        assert src["claudeVersion"] == "2.1.77"
        assert src["projectDir"] == str(setup["src_dir"])

    def test_fork_meta_not_in_claude_dir(self, setup):
        """No files should be written inside the Claude project directory except the JSONL."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(setup["src_dir"]),
            "--no-launch",
        ])
        assert result.exit_code == 0

        # Only .jsonl files should be in the Claude project dir
        non_jsonl = [f for f in setup["src_dir"].rglob("*") if f.is_file() and not f.name.endswith(".jsonl")]
        assert non_jsonl == [], f"Non-JSONL files found in Claude dir: {non_jsonl}"


class TestForkDetection:
    """Sessions with a .meta.json sidecar should be detected as forks."""

    def test_is_fork_true_when_meta_exists(self, tmp_path, monkeypatch):
        from cctree.core.metadata import CCTREE_DIR, is_fork, get_fork_metadata

        cctree_dir = tmp_path / "cctree"
        monkeypatch.setattr("cctree.core.metadata.CCTREE_DIR", cctree_dir)

        # Create a meta file
        project_slug = "-Users-test-projects-alpha"
        session_uuid = "sess-fork-0000-0000-000000000000"
        meta_dir = cctree_dir / "projects" / project_slug
        meta_dir.mkdir(parents=True)
        meta = {
            "forkedFrom": {"sessionId": "orig-uuid", "messageId": "msg-uuid"},
            "forgedAt": "2026-04-15T10:00:00Z",
        }
        (meta_dir / f"{session_uuid}.meta.json").write_text(json.dumps(meta))

        assert is_fork(session_uuid, project_slug) is True

        fork_meta = get_fork_metadata(session_uuid, project_slug)
        assert fork_meta is not None
        assert fork_meta["forkedFrom"]["sessionId"] == "orig-uuid"

    def test_is_fork_false_when_no_meta(self, tmp_path, monkeypatch):
        from cctree.core.metadata import is_fork, get_fork_metadata

        cctree_dir = tmp_path / "cctree"
        monkeypatch.setattr("cctree.core.metadata.CCTREE_DIR", cctree_dir)

        assert is_fork("nonexistent-uuid", "-Users-test") is False
        assert get_fork_metadata("nonexistent-uuid", "-Users-test") is None

    def test_original_session_not_fork(self, tmp_path, monkeypatch):
        """A session that was never forked should not have a meta file."""
        from cctree.core.metadata import is_fork

        cctree_dir = tmp_path / "cctree"
        monkeypatch.setattr("cctree.core.metadata.CCTREE_DIR", cctree_dir)
        # cctree dir exists but no meta file for this session
        (cctree_dir / "projects" / "-Users-test").mkdir(parents=True)

        assert is_fork("original-session-uuid", "-Users-test") is False


class TestWriteForkMetadataTemplateName:
    """write_fork_metadata should optionally record the template name in sidecars."""

    @pytest.fixture
    def cctree(self, tmp_path, monkeypatch):
        cctree_dir = tmp_path / "cctree"
        monkeypatch.setattr("cctree.core.metadata.CCTREE_DIR", cctree_dir)
        return cctree_dir

    def test_template_name_written_to_sidecar(self, cctree):
        from cctree.core.metadata import write_fork_metadata

        path = write_fork_metadata(
            "fork-uuid-001", "-Users-test", "src-uuid", "msg-uuid",
            template_name="my-template",
        )
        meta = json.loads(path.read_text())
        assert meta["templateName"] == "my-template"
        assert meta["forkedFrom"]["sessionId"] == "src-uuid"

    def test_template_name_none_omits_field(self, cctree):
        from cctree.core.metadata import write_fork_metadata

        path = write_fork_metadata(
            "fork-uuid-002", "-Users-test", "src-uuid", "msg-uuid",
        )
        meta = json.loads(path.read_text())
        assert "templateName" not in meta

    def test_template_name_explicit_none_omits_field(self, cctree):
        from cctree.core.metadata import write_fork_metadata

        path = write_fork_metadata(
            "fork-uuid-003", "-Users-test", "src-uuid", "msg-uuid",
            template_name=None,
        )
        meta = json.loads(path.read_text())
        assert "templateName" not in meta


class TestFindTemplateForks:
    """find_template_forks should discover sessions forked from a template."""

    @pytest.fixture
    def cctree(self, tmp_path, monkeypatch):
        cctree_dir = tmp_path / "cctree"
        monkeypatch.setattr("cctree.core.metadata.CCTREE_DIR", cctree_dir)
        return cctree_dir

    def _write_sidecar(self, cctree_dir, project_slug, session_uuid, template_name=None, forged_at=None):
        """Helper to write a fork sidecar directly."""
        meta_dir = cctree_dir / "projects" / project_slug
        meta_dir.mkdir(parents=True, exist_ok=True)
        meta = {
            "forkedFrom": {
                "sessionId": "src-uuid",
                "messageId": "msg-uuid",
                "displayName": "Source Session",
                "slug": "source-session",
            },
            "forgedAt": forged_at or "2026-04-15T10:00:00Z",
        }
        if template_name is not None:
            meta["templateName"] = template_name
        path = meta_dir / f"{session_uuid}.meta.json"
        path.write_text(json.dumps(meta))
        return path

    def test_no_forks_returns_empty(self, cctree):
        from cctree.core.metadata import find_template_forks

        result = find_template_forks("nonexistent", "-Users-test")
        assert result == []

    def test_finds_matching_forks(self, cctree):
        from cctree.core.metadata import find_template_forks

        slug = "-Users-test"
        self._write_sidecar(cctree, slug, "fork-aaa", template_name="my-tpl")
        self._write_sidecar(cctree, slug, "fork-bbb", template_name="my-tpl")
        self._write_sidecar(cctree, slug, "fork-ccc", template_name="other-tpl")
        self._write_sidecar(cctree, slug, "fork-ddd")  # ad-hoc fork, no template

        result = find_template_forks("my-tpl", slug)
        assert len(result) == 2
        session_ids = {r["sessionId"] for r in result}
        assert session_ids == {"fork-aaa", "fork-bbb"}

    def test_sorts_by_forged_at_descending(self, cctree):
        from cctree.core.metadata import find_template_forks

        slug = "-Users-test"
        self._write_sidecar(cctree, slug, "older", template_name="tpl", forged_at="2026-04-10T00:00:00Z")
        self._write_sidecar(cctree, slug, "newer", template_name="tpl", forged_at="2026-04-18T00:00:00Z")
        self._write_sidecar(cctree, slug, "middle", template_name="tpl", forged_at="2026-04-14T00:00:00Z")

        result = find_template_forks("tpl", slug)
        ids = [r["sessionId"] for r in result]
        assert ids == ["newer", "middle", "older"]

    def test_ignores_different_template_name(self, cctree):
        from cctree.core.metadata import find_template_forks

        slug = "-Users-test"
        self._write_sidecar(cctree, slug, "fork-1", template_name="alpha")
        self._write_sidecar(cctree, slug, "fork-2", template_name="beta")

        result = find_template_forks("alpha", slug)
        assert len(result) == 1
        assert result[0]["sessionId"] == "fork-1"

    def test_handles_corrupt_sidecar(self, cctree):
        from cctree.core.metadata import find_template_forks

        slug = "-Users-test"
        self._write_sidecar(cctree, slug, "good-fork", template_name="tpl")
        # Write a corrupt sidecar
        meta_dir = cctree / "projects" / slug
        (meta_dir / "bad-fork.meta.json").write_text("{corrupt json!!!")

        result = find_template_forks("tpl", slug)
        assert len(result) == 1
        assert result[0]["sessionId"] == "good-fork"

    def test_result_includes_forked_from_data(self, cctree):
        from cctree.core.metadata import find_template_forks

        slug = "-Users-test"
        self._write_sidecar(cctree, slug, "fork-xyz", template_name="tpl")

        result = find_template_forks("tpl", slug)
        assert len(result) == 1
        r = result[0]
        assert r["sessionId"] == "fork-xyz"
        assert r["forgedAt"] == "2026-04-15T10:00:00Z"
        assert r["forkedFrom"]["sessionId"] == "src-uuid"
        assert r["forkedFrom"]["displayName"] == "Source Session"

    def test_no_project_dir_returns_empty(self, cctree):
        from cctree.core.metadata import find_template_forks

        # Project dir doesn't exist at all
        result = find_template_forks("tpl", "-nonexistent-project")
        assert result == []
