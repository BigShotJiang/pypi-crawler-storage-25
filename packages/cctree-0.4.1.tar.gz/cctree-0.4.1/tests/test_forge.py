"""Tests for the fork/forge functionality — UUID rewriting, chain integrity, edge cases."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest
from click.testing import CliRunner

from cctree.cli.main import cli
from cctree.core.parser import parse_jsonl

FIXTURES = Path(__file__).parent / "fixtures"


class TestForgeViaCliIntegration:
    """End-to-end tests for `cctree fork` using Click's test runner."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        """Set up a temp project dir with a session to fork."""
        src = FIXTURES / "simple_session.jsonl"
        dest = tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl"
        dest.write_text(src.read_text())
        # Make the file old so it's not considered "active"
        old_time = time.time() - 300
        os.utime(dest, (old_time, old_time))
        return tmp_path

    def test_fork_creates_new_session_file(self, project_dir):
        runner = CliRunner()
        # Fork at the second user message
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",  # 2nd user msg
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0, result.output
        assert "Forged session:" in result.output

        # A new JSONL should exist
        jsonls = list(project_dir.glob("*.jsonl"))
        assert len(jsonls) == 2  # original + forged

    def test_forged_session_has_new_uuid(self, project_dir):
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(project_dir),
            "--no-launch",
        ])
        # Find the new file
        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0001" not in f.name]
        assert len(new_files) == 1
        new_path = new_files[0]

        # All sessionIds in the forged file should match the new filename UUID
        expected_id = new_path.stem
        events = parse_jsonl(new_path)
        for evt in events:
            if evt.sessionId:
                assert evt.sessionId == expected_id

    def test_forged_uuid_chain_intact(self, project_dir):
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00004-0000-0000-0000-000000000004",  # 2nd assistant msg (last msg)
            "-p", str(project_dir),
            "--no-launch",
        ])
        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0001" not in f.name]
        events = parse_jsonl(new_files[0])

        # Verify parentUuid chain
        uuids_seen = set()
        for evt in events:
            if evt.uuid:
                if evt.parentUuid is not None:
                    assert evt.parentUuid in uuids_seen, \
                        f"Broken chain: {evt.uuid[:8]} references unseen parent {evt.parentUuid[:8]}"
                uuids_seen.add(evt.uuid)

    def test_forged_uuids_are_all_new(self, project_dir):
        """No UUID from the original session should appear in the forged session."""
        original_events = parse_jsonl(project_dir / "sess0001-0000-0000-0000-000000000001.jsonl")
        original_uuids = {e.uuid for e in original_events if e.uuid}
        original_uuids.add("sess0001-0000-0000-0000-000000000001")  # session ID too

        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00004-0000-0000-0000-000000000004",
            "-p", str(project_dir),
            "--no-launch",
        ])
        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0001" not in f.name]
        forged_events = parse_jsonl(new_files[0])
        forged_uuids = {e.uuid for e in forged_events if e.uuid}
        forged_uuids.add(new_files[0].stem)

        overlap = original_uuids & forged_uuids
        assert not overlap, f"UUID collision between original and forged: {overlap}"

    def test_forged_snapshot_message_id_remapped(self, project_dir):
        """file-history-snapshot messageIds should be remapped too."""
        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00004-0000-0000-0000-000000000004",
            "-p", str(project_dir),
            "--no-launch",
        ])
        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0001" not in f.name]
        events = parse_jsonl(new_files[0])
        snapshots = [e for e in events if e.type == "file-history-snapshot"]
        if snapshots:
            # messageId should NOT be the original
            assert snapshots[0].messageId != "aaa00001-0000-0000-0000-000000000001"

    def test_forged_drops_last_prompt(self, project_dir):
        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00004-0000-0000-0000-000000000004",
            "-p", str(project_dir),
            "--no-launch",
        ])
        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0001" not in f.name]
        events = parse_jsonl(new_files[0])
        assert not any(e.type == "last-prompt" for e in events)

    def test_fork_message_not_found(self, project_dir):
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "nonexistent-message-uuid",
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 2
        assert "not found" in result.output.lower()

    def test_fork_session_not_found(self, project_dir):
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "nonexistent-session-uuid",
            "some-message",
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 2
        assert "not found" in result.output.lower()

    def test_fork_no_active_warning_when_specific_message(self, project_dir):
        """Forking at a specific historical message should NOT warn about active session.
        The user explicitly picked a point in the past — the warning is noise."""
        target = project_dir / "sess0001-0000-0000-0000-000000000001.jsonl"
        target.touch()  # Make it "active" (just-modified)

        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",  # specific historical message
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0
        assert "appears to be currently active" not in result.output  # no warning
        assert "Forged session:" in result.output

    def test_fork_at_first_message(self, project_dir):
        """Forking at the very first user message should produce a minimal session."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00001-0000-0000-0000-000000000001",  # first user msg
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0
        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0001" not in f.name]
        events = parse_jsonl(new_files[0])
        # Should have: snapshot + user (the first user message)
        msg_events = [e for e in events if e.is_message]
        assert len(msg_events) == 1
        assert msg_events[0].type == "user"

    def test_fork_preserves_original_session(self, project_dir):
        """Forging should NOT modify the source session file."""
        original_path = project_dir / "sess0001-0000-0000-0000-000000000001.jsonl"
        original_content = original_path.read_text()
        original_mtime = os.path.getmtime(original_path)

        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(project_dir),
            "--no-launch",
        ])

        assert original_path.read_text() == original_content
        # mtime might change due to reading, but content should be identical


class TestForgeWithCompaction:
    """Test forking sessions that have compact_boundary events."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        src = FIXTURES / "compacted_session.jsonl"
        dest = tmp_path / "sess0002-0000-0000-0000-000000000002.jsonl"
        dest.write_text(src.read_text())
        old_time = time.time() - 300
        os.utime(dest, (old_time, old_time))
        return tmp_path

    def test_fork_before_compact_boundary(self, project_dir):
        """Fork at a message before compaction — compact boundary should not be in the forged output."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0002-0000-0000-0000-000000000002",
            "bbb00004-0000-0000-0000-000000000004",  # last msg before compact
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0
        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0002" not in f.name]
        events = parse_jsonl(new_files[0])
        assert not any(e.is_compact_boundary for e in events)

    def test_fork_after_compact_boundary(self, project_dir):
        """Fork at a message after compaction — compact boundary and logicalParentUuid should be remapped."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0002-0000-0000-0000-000000000002",
            "bbb00007-0000-0000-0000-000000000007",  # last msg after compact
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0
        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0002" not in f.name]
        events = parse_jsonl(new_files[0])

        # Compact boundary should be present with remapped UUIDs
        boundaries = [e for e in events if e.is_compact_boundary]
        assert len(boundaries) == 1
        # logicalParentUuid should be remapped (not the original)
        assert boundaries[0].logicalParentUuid != "bbb00004-0000-0000-0000-000000000004"
        assert boundaries[0].logicalParentUuid is not None


class TestForkWithDest:
    """Tests for fork --dest: writing the forged session to a different project directory."""

    @pytest.fixture
    def source_dir(self, tmp_path):
        """Source project directory with a session to fork."""
        src_dir = tmp_path / "source_project"
        src_dir.mkdir()
        src = FIXTURES / "simple_session.jsonl"
        dest = src_dir / "sess0001-0000-0000-0000-000000000001.jsonl"
        dest.write_text(src.read_text())
        old_time = time.time() - 300
        os.utime(dest, (old_time, old_time))
        return src_dir

    @pytest.fixture
    def dest_dir(self, tmp_path):
        """Destination project directory (may or may not exist)."""
        return tmp_path / "dest_project"

    def test_fork_creates_file_in_dest_dir(self, source_dir, dest_dir):
        dest_dir.mkdir()
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0, result.output
        # New file should be in dest_dir, NOT source_dir
        source_jsonls = list(source_dir.glob("*.jsonl"))
        dest_jsonls = list(dest_dir.glob("*.jsonl"))
        assert len(source_jsonls) == 1  # original only
        assert len(dest_jsonls) == 1    # forged file

    def test_fork_creates_dest_dir_if_missing(self, source_dir, dest_dir):
        assert not dest_dir.exists()
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0, result.output
        assert dest_dir.exists()
        assert len(list(dest_dir.glob("*.jsonl"))) == 1

    def test_fork_dest_original_untouched(self, source_dir, dest_dir):
        dest_dir.mkdir()
        original = source_dir / "sess0001-0000-0000-0000-000000000001.jsonl"
        original_content = original.read_text()
        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        assert original.read_text() == original_content

    def test_fork_dest_uuid_chain_intact(self, source_dir, dest_dir):
        dest_dir.mkdir()
        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00004-0000-0000-0000-000000000004",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        forged_file = list(dest_dir.glob("*.jsonl"))[0]
        with open(forged_file) as f:
            seen = set()
            for line in f:
                obj = json.loads(line)
                uid = obj.get("uuid")
                parent = obj.get("parentUuid")
                if uid:
                    if parent is not None:
                        assert parent in seen, \
                            f"Broken chain: {uid[:8]} references unseen parent {parent[:8]}"
                    seen.add(uid)

    def test_fork_dest_no_uuid_overlap_with_source(self, source_dir, dest_dir):
        dest_dir.mkdir()
        # Collect source UUIDs
        source_uuids = set()
        with open(source_dir / "sess0001-0000-0000-0000-000000000001.jsonl") as f:
            for line in f:
                obj = json.loads(line)
                if obj.get("uuid"): source_uuids.add(obj["uuid"])
                if obj.get("sessionId"): source_uuids.add(obj["sessionId"])

        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00004-0000-0000-0000-000000000004",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        forged_file = list(dest_dir.glob("*.jsonl"))[0]
        forged_uuids = set()
        with open(forged_file) as f:
            for line in f:
                obj = json.loads(line)
                if obj.get("uuid"): forged_uuids.add(obj["uuid"])
                if obj.get("sessionId"): forged_uuids.add(obj["sessionId"])
        forged_uuids.add(forged_file.stem)

        overlap = source_uuids & forged_uuids
        assert not overlap, f"UUID collision: {overlap}"

    def test_fork_dest_preserves_cwd_field(self, source_dir, dest_dir):
        """cwd field is historical data — must NOT be modified."""
        dest_dir.mkdir()
        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        forged_file = list(dest_dir.glob("*.jsonl"))[0]
        with open(forged_file) as f:
            for line in f:
                obj = json.loads(line)
                if "cwd" in obj:
                    assert obj["cwd"] == "/Users/test/project", \
                        f"cwd field was modified to {obj['cwd']}"

    def test_fork_dest_preserves_slug(self, source_dir, dest_dir):
        """slug is session-stable historical data — must be preserved."""
        dest_dir.mkdir()
        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        forged_file = list(dest_dir.glob("*.jsonl"))[0]
        with open(forged_file) as f:
            for line in f:
                obj = json.loads(line)
                if obj.get("slug"):
                    assert obj["slug"] == "fuzzy-dancing-penguin"

    def test_fork_dest_does_not_remap_api_message_ids(self, source_dir, dest_dir):
        """message.id and requestId are API references — must NOT be remapped."""
        dest_dir.mkdir()
        runner = CliRunner()
        runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00004-0000-0000-0000-000000000004",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        forged_file = list(dest_dir.glob("*.jsonl"))[0]
        with open(forged_file) as f:
            for line in f:
                obj = json.loads(line)
                msg = obj.get("message") or {}
                if msg.get("id"):
                    assert msg["id"].startswith("msg_"), \
                        f"API message ID was remapped: {msg['id']}"

    def test_fork_dest_same_as_source_works(self, source_dir):
        """--dest pointing to source dir should work like fork without --dest."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(source_dir),
            "--dest", str(source_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0
        # Should have original + fork
        assert len(list(source_dir.glob("*.jsonl"))) == 2

    def test_fork_dest_refuses_if_file_exists_in_dest(self, source_dir, dest_dir, monkeypatch):
        """If by astronomical chance the UUID collides with an existing file in dest."""
        dest_dir.mkdir()
        # We can't predict the UUID, but we can test the guard by pre-creating
        # a file and monkeypatching uuid4 to return a known value
        import uuid as uuid_mod
        known_uuid = "deadbeef-dead-beef-dead-beefdeadbeef"
        (dest_dir / f"{known_uuid}.jsonl").write_text("exists\n")

        call_count = [0]
        original_uuid4 = uuid_mod.uuid4
        def fake_uuid4():
            call_count[0] += 1
            if call_count[0] == 1:  # first call is for session ID
                return uuid_mod.UUID(known_uuid)
            return original_uuid4()

        monkeypatch.setattr(uuid_mod, "uuid4", fake_uuid4)
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(source_dir),
            "--dest", str(dest_dir),
            "--no-launch",
        ])
        assert result.exit_code == 2
        assert "already exists" in result.output.lower()


class TestForgePreservesRawStructure:
    """Forge must preserve the exact JSON structure of each line — no field inflation.

    The Anthropic API rejects extra fields on content blocks (e.g., thinking blocks
    with text:null). Forge must operate on raw dicts, not Pydantic model_dump output.
    """

    @pytest.fixture
    def project_dir(self, tmp_path):
        src = FIXTURES / "with_thinking.jsonl"
        dest = tmp_path / "sess0005-0000-0000-0000-000000000005.jsonl"
        dest.write_text(src.read_text())
        old_time = time.time() - 300
        os.utime(dest, (old_time, old_time))
        return tmp_path

    def test_thinking_block_has_no_extra_null_fields(self, project_dir):
        """Thinking blocks must only contain the fields from the original JSONL.

        The API rejects thinking blocks with extra fields like text:null.
        This is the regression test for the Pydantic model_dump inflation bug.
        """
        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0005-0000-0000-0000-000000000005",
            "eee00002-0000-0000-0000-000000000002",  # assistant msg with thinking
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0, result.output

        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0005" not in f.name]
        assert len(new_files) == 1

        # Read the raw forged JSON and find the thinking block
        with open(new_files[0]) as f:
            for line in f:
                raw = json.loads(line)
                msg = raw.get("message") or {}
                content = msg.get("content") or []
                if not isinstance(content, list):
                    continue
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "thinking":
                        # Must have ONLY the original fields, no nulls injected
                        assert set(block.keys()) == {"type", "thinking", "signature"}, \
                            f"Thinking block has extra fields: {sorted(block.keys())}"
                        assert "text" not in block, "text field should not exist on thinking block"
                        assert "id" not in block, "id field should not exist on thinking block"
                        assert "name" not in block, "name field should not exist on thinking block"
                        assert "input" not in block, "input field should not exist on thinking block"
                        return

        pytest.fail("No thinking block found in forged output")

    def test_forged_lines_match_original_structure(self, project_dir):
        """Every line in the forged output should have the same keys as the original
        (minus UUID remapping), with no extra null fields added."""
        src = FIXTURES / "with_thinking.jsonl"

        # Parse original keys per line (excluding last-prompt)
        original_keys_per_line = []
        with open(src) as f:
            for line in f:
                raw = json.loads(line)
                if raw.get("type") == "last-prompt":
                    continue
                original_keys_per_line.append(set(raw.keys()))

        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0005-0000-0000-0000-000000000005",
            "eee00002-0000-0000-0000-000000000002",
            "-p", str(project_dir),
            "--no-launch",
        ])
        assert result.exit_code == 0

        new_files = [f for f in project_dir.glob("*.jsonl") if "sess0005" not in f.name]
        forged_keys_per_line = []
        with open(new_files[0]) as f:
            for line in f:
                raw = json.loads(line)
                forged_keys_per_line.append(set(raw.keys()))

        assert len(forged_keys_per_line) == len(original_keys_per_line), \
            f"Line count mismatch: {len(forged_keys_per_line)} vs {len(original_keys_per_line)}"

        for i, (orig, forged) in enumerate(zip(original_keys_per_line, forged_keys_per_line)):
            assert forged == orig, \
                f"Line {i} key mismatch: extra={forged - orig}, missing={orig - forged}"
