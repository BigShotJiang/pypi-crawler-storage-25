"""Tests for the TUI app — startup, CSS validity, basic interactions."""
from __future__ import annotations

import os
import time
from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


class TestTuiStartup:
    """The TUI must launch without CSS errors or import failures."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        """Create a temp project dir with fixture sessions."""
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
            ("titled_session.jsonl", "sess0003-0000-0000-0000-000000000003.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_app_starts_without_css_errors(self, project_dir):
        """App must mount without any CSS parsing errors."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            # If CSS is invalid, Textual raises during mount
            # Just reaching here means CSS parsed OK
            assert app.is_running

    @pytest.mark.asyncio
    async def test_app_shows_sessions_on_mount(self, project_dir):
        """Sessions list should be populated after background loading completes."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.pause(delay=0.5)  # wait for async session loading worker
            lv = app.query_one("#sessions-pane", ListView)
            # 2 template items (divider + hint) + 1 sessions divider + 2 sessions = 5
            assert len(lv.children) == 5
            # Verify sessions are present
            session_items = [c for c in lv.children if hasattr(c, "name") and c.name and not c.name.startswith("__")]
            assert len(session_items) == 2  # two fixture sessions

    @pytest.mark.asyncio
    async def test_app_defaults_to_cwd_project(self, tmp_path, monkeypatch):
        """When no --project given, should auto-detect from cwd."""
        from cctree.tui.app import CctreeApp

        # This just tests construction doesn't crash
        app = CctreeApp()
        assert app.store is not None

    @pytest.mark.asyncio
    async def test_empty_project_shows_no_crash(self, tmp_path):
        """Empty project dir should show empty sessions list, not crash."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            # Empty project still shows template section (divider + hint) + sessions divider
            assert len(lv.children) == 3
            session_items = [c for c in lv.children if hasattr(c, "name") and c.name and not c.name.startswith("__")]
            assert len(session_items) == 0


class TestTuiSessionList:
    """Session list should show size, datetime, and be sorted by recency."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        # Session A: older, smaller
        lines_a = [json.dumps({
            "type": "user", "uuid": "ua", "parentUuid": None,
            "message": {"role": "user", "content": "old session"},
            "sessionId": "sess-old", "slug": "old-session",
            "timestamp": "2026-04-01T10:00:00Z",
        })]
        (tmp_path / "sess-old.jsonl").write_text("\n".join(lines_a) + "\n")

        # Session B: newer, larger
        lines_b = []
        for i in range(20):
            lines_b.append(json.dumps({
                "type": "user" if i % 2 == 0 else "assistant", "uuid": f"ub{i}",
                "parentUuid": f"ub{i-1}" if i > 0 else None,
                "message": {"role": "user" if i % 2 == 0 else "assistant",
                            "content": f"message {i} " + "x" * 100},
                "sessionId": "sess-new", "slug": "new-session",
                "timestamp": f"2026-04-10T10:00:{i:02d}Z",
            }))
        (tmp_path / "sess-new.jsonl").write_text("\n".join(lines_b) + "\n")

        for f in tmp_path.glob("*.jsonl"):
            old_time = time.time() - 300
            os.utime(f, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_session_list_shows_size(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            labels = [str(child.query_one("Label").render()) for child in lv.children]
            # At least one label should contain a size indicator (KB or msgs)
            assert any("msg" in l.lower() or "kb" in l.lower() or "msgs" in l.lower() for l in labels), \
                f"No size indicator in session labels: {labels}"

    @pytest.mark.asyncio
    async def test_session_list_shows_datetime(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            labels = [str(child.query_one("Label").render()) for child in lv.children]
            # Should contain a date like "04-10" or "2026"
            assert any("04-" in l or "2026" in l for l in labels), \
                f"No datetime in session labels: {labels}"

    @pytest.mark.asyncio
    async def test_session_list_sorted_most_recent_first(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            labels = [str(child.query_one("Label").render()) for child in lv.children]
            # Skip template section items — find first session item
            session_labels = [l for l in labels if "new-session" in l or "old-session" in l]
            assert session_labels[0].startswith("new-session"), \
                f"Expected newest session first among sessions, got: {session_labels}"


    @pytest.mark.asyncio
    async def test_sort_toggle_switches_order(self, project_dir):
        """Pressing 'S' should toggle between last-activity and started-at sorting."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            # Navigate past template section to sessions area
            # Find the sessions divider and move past it
            for _ in range(5):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "")
                    if name and not name.startswith("__"):
                        break

            labels_before = [str(child.query_one("Label").render()) for child in lv.children]
            session_labels_before = [l for l in labels_before if "new-session" in l or "old-session" in l]

            # Toggle sort (should affect sessions since cursor is in sessions area)
            await pilot.press("S")
            await pilot.pause()

            labels_after = [str(child.query_one("Label").render()) for child in lv.children]
            session_labels_after = [l for l in labels_after if "new-session" in l or "old-session" in l]

            # The sessions divider label should change (sort indicator)
            sess_divider_before = [l for l in labels_before if "Sessions" in l]
            sess_divider_after = [l for l in labels_after if "Sessions" in l]
            assert sess_divider_before != sess_divider_after, \
                f"Sort toggle didn't change sessions divider. Before: {sess_divider_before}, After: {sess_divider_after}"


class TestTuiKeyboardNav:
    """Full keyboard navigation — user should never need a mouse."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
            ("titled_session.jsonl", "sess0003-0000-0000-0000-000000000003.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_right_arrow_moves_from_sessions_to_detail(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            tree = app.query_one("#session-tree", Tree)

            # Start with sessions focused
            assert lv.has_focus

            # Select a session first
            await pilot.press("enter")
            await pilot.pause()

            # Right arrow should move to detail tree
            await pilot.press("right")
            await pilot.pause()
            assert tree.has_focus, "Right arrow should move focus to detail tree"

    @pytest.mark.asyncio
    async def test_left_arrow_moves_from_detail_to_sessions(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            # Load a session and focus the tree
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)
            assert tree.has_focus

            # Left arrow at the root/collapsed level should go back to sessions
            await pilot.press("left")
            await pilot.pause()

            lv = app.query_one("#sessions-pane", ListView)
            # Either the sessions pane has focus, or we're still in the tree
            # (if the tree consumed the left arrow for collapsing)
            # At minimum, after enough lefts we should get back
            if not lv.has_focus:
                await pilot.press("left")
                await pilot.pause()
            # After 2 lefts from root, we should be in sessions pane
            assert lv.has_focus, "Left arrow should eventually return to sessions pane"

    @pytest.mark.asyncio
    async def test_enter_on_session_loads_and_right_focuses_detail(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree, ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            # Navigate past template section to a session item
            for _ in range(6):
                await pilot.press("down")
                await pilot.pause()
            # Find and select a session item
            idx = lv.index if lv.index is not None else 0
            items = list(lv.children)
            # Navigate until we find a real session
            found_session = False
            for _ in range(len(items)):
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "")
                    if name and not name.startswith("__"):
                        found_session = True
                        break
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0

            await pilot.press("enter")
            await pilot.pause()

            # Session should be loaded
            assert app.current_session is not None, \
                f"Session not loaded. ListView index: {lv.index}, items: {[getattr(c, 'name', '') for c in items]}"

            # Right arrow should move to detail tree which now has content
            await pilot.press("right")
            await pilot.pause()
            tree = app.query_one("#session-tree", Tree)
            assert tree.has_focus
            assert len(tree.root.children) > 0


class TestTuiSearch:
    """Search overlay: arrow nav between input and results, snap-to-match on select."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-search-0000-0000-000000000000"
        lines = [
            json.dumps({"type": "user", "uuid": "su1", "parentUuid": None,
                        "message": {"role": "user", "content": "first message about databases"},
                        "sessionId": session_id, "slug": "search-test",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "sa1", "parentUuid": "su1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "I can help with databases."}]},
                        "sessionId": session_id, "slug": "search-test",
                        "timestamp": "2026-04-01T10:00:05Z"}),
            json.dumps({"type": "user", "uuid": "su2", "parentUuid": "sa1",
                        "message": {"role": "user", "content": "now talk about unique-search-target-xyz"},
                        "sessionId": session_id, "slug": "search-test",
                        "timestamp": "2026-04-01T10:01:00Z"}),
            json.dumps({"type": "assistant", "uuid": "sa2", "parentUuid": "su2",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "Sure, here is info about that topic."}]},
                        "sessionId": session_id, "slug": "search-test",
                        "timestamp": "2026-04-01T10:01:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        old_time = time.time() - 300
        os.utime(tmp_path / f"{session_id}.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_down_arrow_moves_from_search_input_to_results(self, project_dir):
        """Down arrow in search input should move focus to the results list."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Input, ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("slash")
            await pilot.pause()

            # Type a query that will match
            for ch in "database":
                await pilot.press(ch)
            await pilot.pause(delay=0.5)  # wait for debounce

            # Down arrow should move focus to results
            await pilot.press("down")
            await pilot.pause()

            # The search results ListView should have focus
            screen = app.screen
            results = screen.query_one("#search-results", ListView)
            assert results.has_focus, "Down arrow should move focus from search input to results list"

    @pytest.mark.asyncio
    async def test_search_select_snaps_to_matched_message(self, project_dir):
        """Selecting a content-match search result should load the session AND
        expand/highlight the user turn containing the matched message."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("slash")
            await pilot.pause()

            for ch in "unique-search-target":
                await pilot.press(ch)
            await pilot.pause(delay=0.5)

            # Navigate to result and select it
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            # Session should be loaded
            assert app.current_session is not None
            assert app.current_session.uuid == "sess-search-0000-0000-000000000000"

            # The tree should have the matched user turn expanded
            tree = app.query_one("#session-tree", Tree)
            # Find the node containing the matched message
            def find_match(node):
                label = str(node.label)
                if "unique-search-target" in label:
                    return node
                for child in node.children:
                    result = find_match(child)
                    if result:
                        return result
                return None

            matched = find_match(tree.root)
            assert matched is not None, "Matched message node not found in tree after search select"


class TestTuiTreeExpand:
    """Right arrow expands nodes and shows full text content."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        # Session with a long user message
        session_id = "sess-expand-0000-0000-000000000000"
        long_msg = "This is a very long user message that exceeds the 60 character truncation limit and should be fully visible when the node is expanded via right arrow"
        lines = [
            json.dumps({"type": "user", "uuid": "exp-u1", "parentUuid": None,
                        "message": {"role": "user", "content": long_msg},
                        "sessionId": session_id, "slug": "expand-test",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "exp-a1", "parentUuid": "exp-u1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "Got it."},
                        ]},
                        "sessionId": session_id, "slug": "expand-test",
                        "timestamp": "2026-04-01T10:00:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        old_time = time.time() - 300
        os.utime(tmp_path / f"{session_id}.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_user_turn_shows_full_text_when_expanded(self, project_dir):
        """When a user turn node is expanded, the full message text should be
        visible as a child — not truncated to 60 chars."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-expand-0000-0000-000000000000")
            app.load_session(session)

            tree = app.query_one("#session-tree", Tree)
            # Spine has user nodes; asst nests under user
            assert len(tree.root.children) == 1  # User (with Asst nested)
            user_node = tree.root.children[0]
            assert str(user_node.label).startswith("User:")
            label = str(user_node.label)
            assert "..." in label or len(label) < 80  # truncated in spine

            # Expand the node
            user_node.expand()
            await pilot.pause()

            # Find a child that contains the full text (more than 60 chars)
            child_labels = [str(c.label) for c in user_node.children]
            full_text_found = any("exceeds the 60 character" in l for l in child_labels)
            assert full_text_found, \
                f"Full user message text not found in expanded children: {child_labels}"


class TestTuiTreeStructure:
    """Verify the tree-spine model renders correctly."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_tool_result_is_child_of_tool_use_not_sibling(self, project_dir):
        """tool_result blocks must nest under the corresponding tool_use node,
        not appear as siblings at the same level."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)

            tree = app.query_one("#session-tree", Tree)
            # Walk the tree and find tool_result nodes
            def find_results(node, depth=0):
                results = []
                label = str(node.label) if hasattr(node, 'label') else ""
                if label.startswith("→"):
                    # This is a tool_result — its parent should be a tool_use (🔧)
                    parent_label = str(node.parent.label) if node.parent else ""
                    results.append((label, parent_label, depth))
                for child in node.children:
                    results.extend(find_results(child, depth + 1))
                return results

            tool_results = find_results(tree.root)
            for label, parent_label, depth in tool_results:
                assert "🔧" in parent_label or "🤖" in parent_label, \
                    f"tool_result '{label}' is child of '{parent_label}' — should be under a tool_use node"


    @pytest.mark.asyncio
    async def test_tool_result_user_msgs_not_in_spine(self, project_dir):
        """User messages that are purely tool_result blocks (command output auto-sent
        by Claude Code) must NOT appear as top-level spine nodes. They should be
        nested under the preceding user turn's agent activity."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        # Create a session with: user-typed msg → assistant → tool_result user msg → assistant
        import json
        session_id = "sess0010-0000-0000-0000-000000000010"
        lines = [
            json.dumps({"type": "user", "uuid": "u1", "parentUuid": None,
                        "message": {"role": "user", "content": "fix the layout"},
                        "sessionId": session_id, "slug": "test", "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "a1", "parentUuid": "u1",
                        "message": {"role": "assistant", "content": [
                            {"type": "tool_use", "id": "t1", "name": "Bash",
                             "input": {"command": "git status"}},
                        ]},
                        "sessionId": session_id, "slug": "test", "timestamp": "2026-04-01T10:00:05Z"}),
            json.dumps({"type": "user", "uuid": "u2", "parentUuid": "a1",
                        "message": {"role": "user", "content": [
                            {"type": "tool_result", "tool_use_id": "t1",
                             "content": "3 files changed"},
                        ]},
                        "sessionId": session_id, "slug": "test", "timestamp": "2026-04-01T10:00:06Z"}),
            json.dumps({"type": "assistant", "uuid": "a2", "parentUuid": "u2",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "Done, 3 files updated."},
                        ]},
                        "sessionId": session_id, "slug": "test", "timestamp": "2026-04-01T10:00:10Z"}),
            json.dumps({"type": "user", "uuid": "u3", "parentUuid": "a2",
                        "message": {"role": "user", "content": "looks good"},
                        "sessionId": session_id, "slug": "test", "timestamp": "2026-04-01T10:00:15Z"}),
        ]
        (project_dir / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        import os, time
        os.utime(project_dir / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Count spine nodes (direct children of root with "User:" prefix)
            spine_labels = [str(child.label) for child in tree.root.children]
            user_spine = [l for l in spine_labels if l.startswith("User:")]

            # Should be 2 spine nodes ("fix the layout" and "looks good"),
            # NOT 3 (the tool_result "3 files changed" must be nested, not a spine node)
            assert len(user_spine) == 2, \
                f"Expected 2 spine nodes but got {len(user_spine)}: {user_spine}"
            assert any("fix the layout" in l for l in user_spine)
            assert any("looks good" in l for l in user_spine)


class TestTuiSortBindingVisibility:
    """Sort keybinding should only be active/visible when sessions pane is focused."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_sort_disabled_when_detail_focused(self, project_dir):
        """'S' sort action should be disabled when detail tree has focus."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("right")
            await pilot.pause()

            tree = app.query_one("#session-tree")
            assert tree.has_focus
            assert not app.check_action("toggle_sort", ())

    @pytest.mark.asyncio
    async def test_sort_enabled_when_sessions_focused(self, project_dir):
        """'S' sort action should be enabled when sessions pane has focus."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            assert app.check_action("toggle_sort", ())


class TestTuiForkCommand:
    """Verify the fork command copy works on all node types."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        old_time = time.time() - 300
        os.utime(tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_fork_command_walks_up_to_nearest_uuid(self, project_dir):
        """Pressing f on a tool_input or tool_result node should walk up the tree
        to find the nearest ancestor with a message UUID, not fail."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)

            tree = app.query_one("#session-tree", Tree)

            # Find a tool_input or tool_result leaf node
            def find_leaf_without_uuid(node):
                if node.data and node.data.get("type") in ("tool_input", "tool_result"):
                    return node
                for child in node.children:
                    result = find_leaf_without_uuid(child)
                    if result:
                        return result
                return None

            leaf = find_leaf_without_uuid(tree.root)
            assert leaf is not None, "No tool_input/tool_result leaf found in fixture"

            # Test the UUID walk-up logic directly instead of through cursor
            # This tests the data model, not the Textual cursor
            from cctree.tui.app import _find_nearest_uuid
            uuid = _find_nearest_uuid(leaf)
            assert uuid is not None, \
                f"_find_nearest_uuid returned None for {leaf.data.get('type')} node — should walk up to parent"


class TestTuiDragHandle:
    """A drag handle should exist between sessions and detail panes for resizing."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_drag_handle_exists_in_layout(self, project_dir):
        """A drag handle widget should exist between sessions and detail panes."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            handle = app.query_one("#drag-handle")
            assert handle is not None

    @pytest.mark.asyncio
    async def test_resize_sessions_pane(self, project_dir):
        """_resize_sessions_pane should update the pane width."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            sessions = app.query_one("#sessions-pane", ListView)
            app._resize_sessions_pane(40)
            await pilot.pause()
            assert sessions.styles.width is not None
            # Width should be clamped between min/max
            width_val = sessions.styles.width.value
            assert 15 <= width_val <= 80


class TestTuiLoadMore:
    """Sessions picker should support loading more sessions beyond the initial page."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        # Create 210 sessions — more than the default page size of 200
        for i in range(210):
            session_id = f"sess-{i:04d}-0000-0000-000000000000"
            lines = [json.dumps({
                "type": "user", "uuid": f"u{i}", "parentUuid": None,
                "message": {"role": "user", "content": f"session {i}"},
                "sessionId": session_id, "slug": f"session-{i}",
                "timestamp": f"2026-04-{(i % 28) + 1:02d}T{(i % 24):02d}:{(i % 60):02d}:00Z",
            })]
            (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
            old_time = time.time() - 300
            os.utime(tmp_path / f"{session_id}.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_initial_load_shows_load_more_item(self, project_dir):
        """When more sessions exist than the page size, a 'Load more' item should appear."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            children = list(lv.children)
            last_label = str(children[-1].query_one("Label").render())
            assert "more" in last_label.lower(), \
                f"Expected 'Load more' as last item, got: {last_label}"

    @pytest.mark.asyncio
    async def test_no_load_more_when_all_fit(self, tmp_path):
        """When all sessions fit in the page, no 'Load more' item should appear."""
        import json
        for i in range(5):
            sid = f"sess-small-{i:04d}-0000-000000000000"
            lines = [json.dumps({
                "type": "user", "uuid": f"u{i}", "parentUuid": None,
                "message": {"role": "user", "content": f"session {i}"},
                "sessionId": sid, "slug": f"session-{i}",
                "timestamp": f"2026-04-01T10:00:{i:02d}Z",
            })]
            (tmp_path / f"{sid}.jsonl").write_text("\n".join(lines) + "\n")
            old_time = time.time() - 300
            os.utime(tmp_path / f"{sid}.jsonl", (old_time, old_time))

        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            children = list(lv.children)
            for child in children:
                label = str(child.query_one("Label").render())
                assert "more" not in label.lower(), \
                    f"Unexpected 'Load more' item when all sessions fit: {label}"

    @pytest.mark.asyncio
    async def test_load_more_adds_next_page(self, project_dir):
        """Selecting 'Load more' should add more sessions to the list."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            initial_count = len(lv.children)

            # Trigger load more directly
            app._load_more_sessions()
            await pilot.pause()

            new_count = len(lv.children)
            assert new_count > initial_count, \
                f"Expected more sessions after load more, got {new_count} vs {initial_count}"


class TestTuiAssistantNesting:
    """Assistant messages must nest under their User turn as children."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_assistant_messages_nested_under_user(self, project_dir):
        """Asst nodes should be children of User nodes, not spine-level."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Spine should only have User nodes
            spine_labels = [str(child.label) for child in tree.root.children]
            assert all(l.startswith("User:") for l in spine_labels), \
                f"Spine should only have User nodes, got: {spine_labels}"

            # Each user node with a response should have Asst children
            for user_node in tree.root.children:
                child_labels = [str(c.label) for c in user_node.children]
                asst_children = [l for l in child_labels if "Asst:" in l]
                assert len(asst_children) >= 1, \
                    f"User node '{user_node.label}' should have Asst children, got: {child_labels}"

    @pytest.mark.asyncio
    async def test_spine_has_only_user_nodes(self, project_dir):
        """simple_session has user→asst→user→asst; spine must show only 2 User nodes."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            spine_labels = [str(child.label) for child in tree.root.children]
            assert len(spine_labels) == 2, \
                f"Expected 2 spine nodes (2 user turns), got {len(spine_labels)}: {spine_labels}"
            assert spine_labels[0].startswith("User:")
            assert spine_labels[1].startswith("User:")

    @pytest.mark.asyncio
    async def test_assistant_tools_are_direct_children_of_user(self, project_dir):
        """Tool use blocks should be direct children: root → User → 🔧."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Walk: root → User → 🔧 (flat, no Asst: wrapper)
            tool_found = False
            for user_node in tree.root.children:
                for child in user_node.children:
                    if "🔧" in str(child.label):
                        tool_found = True
                        break
            assert tool_found, "Tool use blocks should be direct children: root → User → 🔧"

    @pytest.mark.asyncio
    async def test_asst_labels_are_dimmed(self, project_dir):
        """Assistant labels should be styled with dim via Rich markup."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree
        from rich.text import Text

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Find Asst nodes under User nodes and verify dim style
            for user_node in tree.root.children:
                for child in user_node.children:
                    plain = str(child.label)
                    if "Asst:" in plain:
                        label = child.label
                        assert isinstance(label, Text), \
                            f"Expected Rich Text for Asst label, got {type(label)}"
                        assert label._spans, f"Asst label has no style spans: {plain}"
                        has_dim = any("dim" in str(s.style) for s in label._spans)
                        assert has_dim, f"Asst label not dimmed: {plain}"

    @pytest.mark.asyncio
    async def test_tool_labels_are_dimmed(self, project_dir):
        """Tool call labels should be styled with dim via Rich markup."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree
        from rich.text import Text

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def find_tool_labels(node):
                tools = []
                plain = str(node.label)
                if "🔧" in plain or "🤖" in plain:
                    tools.append(node.label)
                for child in node.children:
                    tools.extend(find_tool_labels(child))
                return tools

            tool_labels = find_tool_labels(tree.root)
            assert len(tool_labels) >= 1, "No tool labels found"
            for label in tool_labels:
                assert isinstance(label, Text), f"Expected Rich Text, got {type(label)}"
                has_dim = any("dim" in str(s.style) for s in label._spans)
                assert has_dim, f"Tool label not dimmed: {label}"

    @pytest.mark.asyncio
    async def test_user_without_response_is_leaf(self, project_dir, tmp_path):
        """A user message with no assistant response should be a leaf node."""
        import json
        session_id = "sess-leaf-0000-0000-000000000000"
        lines = [
            json.dumps({"type": "user", "uuid": "u-leaf", "parentUuid": None,
                        "message": {"role": "user", "content": "just a thought"},
                        "sessionId": session_id, "slug": "leaf-test",
                        "timestamp": "2026-04-01T10:00:00Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))

        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            assert len(tree.root.children) == 1
            user_node = tree.root.children[0]
            assert str(user_node.label).startswith("User:")
            assert len(user_node.children) == 0, \
                f"User without response should be a leaf, but has children: {[str(c.label) for c in user_node.children]}"


class TestTuiClickBlocking:
    """Mouse clicks should be disabled — keyboard-only navigation."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_click_on_session_does_not_load(self, project_dir):
        """Clicking a session in the list should NOT load it."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            assert app.current_session is None
            # Try clicking the first session item
            lv = app.query_one("#sessions-pane", ListView)
            await pilot.click("#sessions-pane")
            await pilot.pause()
            # Session should NOT be loaded
            assert app.current_session is None, \
                "Mouse click should not load a session — keyboard only"

    @pytest.mark.asyncio
    async def test_keyboard_enter_still_loads_session(self, project_dir):
        """Enter key should still load sessions despite click blocking."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            # Navigate to a real session item (wrap-around means we can't blindly press down)
            lv = app.query_one("#sessions-pane", ListView)
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break
            await pilot.press("enter")
            await pilot.pause()
            # Session should be loaded via keyboard
            assert app.current_session is not None, \
                "Enter key should still load sessions"

    @pytest.mark.asyncio
    async def test_drag_handle_still_works(self, project_dir):
        """DragHandle should still respond to mouse despite click blocking."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            handle = app.query_one("#drag-handle")
            assert handle is not None
            # DragHandle uses MouseDown/MouseUp, not Click — should be unaffected
            # Just verify it exists and isn't disabled
            app._resize_sessions_pane(40)
            await pilot.pause()
            sessions = app.query_one("#sessions-pane")
            assert sessions.styles.width is not None


# ── TDD: wrap_text pure function ──────────────────────────────────────────────

class TestWrapText:
    """Tests for the _wrap_text helper — pure function, no TUI needed."""

    def test_short_text_no_wrap(self):
        from cctree.tui.app import _wrap_text
        assert _wrap_text("hello world", 80) == ["hello world"]

    def test_wraps_at_width(self):
        from cctree.tui.app import _wrap_text
        text = "word " * 20  # 100 chars
        lines = _wrap_text(text.strip(), 40)
        assert len(lines) > 1
        assert all(len(line) <= 40 for line in lines)

    def test_preserves_newlines(self):
        from cctree.tui.app import _wrap_text
        lines = _wrap_text("line one\nline two\nline three", 80)
        assert len(lines) == 3
        assert lines[0] == "line one"
        assert lines[2] == "line three"

    def test_strips_trailing_blank_lines(self):
        from cctree.tui.app import _wrap_text
        lines = _wrap_text("hello\n\n\n", 80)
        assert lines == ["hello"]

    def test_empty_string(self):
        from cctree.tui.app import _wrap_text
        lines = _wrap_text("", 80)
        assert lines == [""]

    def test_preserves_blank_lines_between_paragraphs(self):
        from cctree.tui.app import _wrap_text
        lines = _wrap_text("para one\n\npara two", 80)
        assert lines == ["para one", "", "para two"]


# ── TDD: orphaned events after compact boundary ──────────────────────────────

class TestOrphanedEvents:
    """Events after compact boundary and before first user msg must not be lost."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-orphan-0000-0000-000000000000"
        lines = [
            json.dumps({"type": "user", "uuid": "ou1", "parentUuid": None,
                        "message": {"role": "user", "content": "first question"},
                        "sessionId": session_id, "slug": "orphan-test",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "oa1", "parentUuid": "ou1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "first answer"},
                        ]},
                        "sessionId": session_id, "slug": "orphan-test",
                        "timestamp": "2026-04-01T10:00:05Z"}),
            json.dumps({"type": "system", "subtype": "compact_boundary",
                        "uuid": "oc1", "parentUuid": "oa1",
                        "content": "Summary of conversation",
                        "timestamp": "2026-04-01T10:01:00Z",
                        "sessionId": session_id, "isSidechain": False}),
            # Orphaned assistant — after compact, before next user
            json.dumps({"type": "assistant", "uuid": "oa2", "parentUuid": "oc1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "I'll continue with the analysis"},
                        ]},
                        "sessionId": session_id, "slug": "orphan-test",
                        "timestamp": "2026-04-01T10:01:05Z"}),
            json.dumps({"type": "user", "uuid": "ou2", "parentUuid": "oa2",
                        "message": {"role": "user", "content": "second question"},
                        "sessionId": session_id, "slug": "orphan-test",
                        "timestamp": "2026-04-01T10:02:00Z"}),
            json.dumps({"type": "assistant", "uuid": "oa3", "parentUuid": "ou2",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "second answer"},
                        ]},
                        "sessionId": session_id, "slug": "orphan-test",
                        "timestamp": "2026-04-01T10:02:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))
        return tmp_path

    @pytest.mark.asyncio
    async def test_orphaned_asst_after_compact_not_lost(self, project_dir):
        """Assistant message between compact boundary and next user turn must appear."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-orphan-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def all_labels(node):
                labels = [str(node.label)]
                for child in node.children:
                    labels.extend(all_labels(child))
                return labels

            labels = all_labels(tree.root)
            assert any("continue with the analysis" in l for l in labels), \
                f"Orphaned assistant message not found in tree. Labels: {labels}"

    @pytest.mark.asyncio
    async def test_compact_boundary_ordering(self, project_dir):
        """Compact boundary must appear BETWEEN turns before and after it."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-orphan-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            top_labels = [str(c.label) for c in tree.root.children]
            compact_idx = first_user_idx = second_user_idx = None
            for i, label in enumerate(top_labels):
                if "COMPACT" in label:
                    compact_idx = i
                elif "first question" in label:
                    first_user_idx = i
                elif "second question" in label:
                    second_user_idx = i

            assert first_user_idx is not None, f"First user not found: {top_labels}"
            assert compact_idx is not None, f"Compact boundary not found: {top_labels}"
            assert second_user_idx is not None, f"Second user not found: {top_labels}"
            assert first_user_idx < compact_idx < second_user_idx, \
                f"Wrong order: user1@{first_user_idx}, compact@{compact_idx}, user2@{second_user_idx}. Labels: {top_labels}"


# ── TDD: text wrapping (multi-line instead of single-line) ────────────────────

class TestTextWrapping:
    """Full text nodes should wrap into multiple lines, not one scrollable line."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-wrap-0000-0000-000000000000"
        long_msg = ("This is a very long message that should be word-wrapped "
                     "across multiple lines instead of displaying as a single "
                     "horizontal line that requires scrolling to read. ") * 3
        lines = [
            json.dumps({"type": "user", "uuid": "wu1", "parentUuid": None,
                        "message": {"role": "user", "content": long_msg.strip()},
                        "sessionId": session_id, "slug": "wrap-test",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "wa1", "parentUuid": "wu1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "Got it."},
                        ]},
                        "sessionId": session_id, "slug": "wrap-test",
                        "timestamp": "2026-04-01T10:00:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))
        return tmp_path

    @pytest.mark.asyncio
    async def test_full_text_has_multiple_child_nodes(self, project_dir):
        """Full text should be split into multiple child nodes (wrapped lines), not one."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-wrap-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            user_node = tree.root.children[0]
            # Count children that are wrapped text lines (not the assistant)
            text_children = [c for c in user_node.children
                            if c.data and c.data.get("type") in ("full_text", "overflow")]
            assert len(text_children) > 1, \
                f"Expected multiple wrapped lines, got {len(text_children)}. " \
                f"Children: {[str(c.label)[:60] for c in user_node.children]}"

    @pytest.mark.asyncio
    async def test_overflow_node_for_long_text(self, project_dir):
        """Very long text should have an overflow '... (N more lines)' expand node."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-wrap-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            user_node = tree.root.children[0]

            def find_overflow(node):
                if node.data and node.data.get("type") == "overflow":
                    return node
                for child in node.children:
                    found = find_overflow(child)
                    if found:
                        return found
                return None

            overflow = find_overflow(user_node)
            assert overflow is not None, \
                f"No overflow node. Children: {[str(c.label)[:60] for c in user_node.children]}"
            assert "more lines" in str(overflow.label)


# ── TDD: non-string tool_result content ───────────────────────────────────────

class TestNonStringToolResult:
    """Tool results with list content (not string) must still be displayed."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-listresult-0000-0000-000000000000"
        lines = [
            json.dumps({"type": "user", "uuid": "lr-u1", "parentUuid": None,
                        "message": {"role": "user", "content": "check the file"},
                        "sessionId": session_id, "slug": "list-result-test",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "lr-a1", "parentUuid": "lr-u1",
                        "message": {"role": "assistant", "content": [
                            {"type": "tool_use", "id": "lr-t1", "name": "Read",
                             "input": {"file_path": "/tmp/test.py"}},
                            {"type": "tool_result", "tool_use_id": "lr-t1",
                             "content": [{"type": "text", "text": "print('hello world')"}]},
                        ]},
                        "sessionId": session_id, "slug": "list-result-test",
                        "timestamp": "2026-04-01T10:00:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))
        return tmp_path

    @pytest.mark.asyncio
    async def test_list_tool_result_content_visible(self, project_dir):
        """Tool result with list content (not just string) should be rendered."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-listresult-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def all_labels(node):
                labels = [str(node.label)]
                for child in node.children:
                    labels.extend(all_labels(child))
                return labels

            labels = all_labels(tree.root)
            assert any("hello world" in l for l in labels), \
                f"List-type tool result not found. Labels: {labels}"


# ── TDD: copy to clipboard (c / C keys) ──────────────────────────────────────

class TestCopyToClipboard:
    """c copies focused node text, C copies node + all descendants."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        """Session with user, assistant, tool_use, tool_result."""
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.fixture
    def clipboard(self, monkeypatch):
        """Mock pyperclip.copy and return a list that captures copied text."""
        copied = []
        import pyperclip
        monkeypatch.setattr(pyperclip, "copy", lambda text: copied.append(text))
        return copied

    @pytest.mark.asyncio
    async def test_copy_user_message(self, project_dir, clipboard):
        """c on a user node copies the user's message text."""
        from cctree.tui.app import CctreeApp, _extract_copy_text
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Navigate down from root to first user node
            await pilot.press("down")
            await pilot.pause()

            node = tree.cursor_node
            assert node.data and node.data.get("type") == "user"
            assert _extract_copy_text(node) == "hello world"

            await pilot.press("c")
            await pilot.pause()

            assert len(clipboard) == 1
            assert clipboard[0] == "hello world"

    @pytest.mark.asyncio
    async def test_copy_assistant_message(self, project_dir, clipboard):
        """c on an assistant node copies the assistant's response text."""
        from cctree.tui.app import CctreeApp, _extract_copy_text
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # User turns are auto-expanded. down→first user (expanded),
            # down again→first child (assistant).
            tree.focus()
            await pilot.pause()
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("down")
            await pilot.pause()

            node = tree.cursor_node
            assert node.data and node.data.get("type") == "assistant", \
                f"Expected assistant, got {node.data}"
            text = _extract_copy_text(node)
            assert "Hello! How can I help you today?" in text

            await pilot.press("c")
            await pilot.pause()

            assert len(clipboard) == 1
            assert "Hello! How can I help you today?" in clipboard[0]

    @pytest.mark.asyncio
    async def test_copy_tool_use_name_and_result(self, project_dir, clipboard):
        """c on a tool_use node copies tool name and inline result."""
        from cctree.tui.app import CctreeApp, _extract_copy_text
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def find_node_by_type(node, ntype):
                if node.data and node.data.get("type") == ntype:
                    return node
                for child in node.children:
                    found = find_node_by_type(child, ntype)
                    if found:
                        return found
                return None

            tool_node = find_node_by_type(tree.root, "tool_use")
            assert tool_node is not None, "No tool_use node in tree"
            text = _extract_copy_text(tool_node)
            assert "Read" in text
            # Single-line result is inlined → result_text in copy output
            assert "print('hello')" in text

    @pytest.mark.asyncio
    async def test_copy_tool_result_from_subtree(self, project_dir, clipboard):
        """Copy-subtree on user turn includes tool result exactly once."""
        from cctree.tui.app import CctreeApp, _extract_subtree_text
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Find the user turn that has the tool call
            for user_node in tree.root.children:
                text = _extract_subtree_text(user_node)
                if "print('hello')" in text:
                    count = text.count("print('hello')")
                    assert count == 1, (
                        f"Result appears {count} times (expected 1):\n{text}"
                    )
                    return
            pytest.fail("No user turn contains print('hello')")

    @pytest.mark.asyncio
    async def test_copy_nothing_when_no_session(self, project_dir, clipboard):
        """c with no session loaded: disabled in sessions pane, shows flash in detail pane."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            # Copy is disabled in sessions pane (check_action returns False)
            sessions = app.query_one("#sessions-pane")
            assert sessions.has_focus
            assert not app.check_action("copy_node", ())

            # Move to detail pane and try — should flash "Nothing to copy"
            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()
            await pilot.press("c")
            await pilot.pause()

            assert len(clipboard) == 0
            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            assert "Nothing to copy" in rendered or "No message" in rendered

    @pytest.mark.asyncio
    async def test_copy_flashes_status_preview(self, project_dir, clipboard):
        """After copying, status bar shows 'Copied:' preview."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree, Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause()

            # Navigate to first user node
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("c")
            await pilot.pause()

            status = app.query_one("#status-bar", Static)
            assert "Copied:" in str(status.render())

    @pytest.mark.asyncio
    async def test_copy_subtree_includes_descendants(self, project_dir, clipboard):
        """C on a user node copies user text + all nested assistant/tool text."""
        from cctree.tui.app import CctreeApp, _extract_subtree_text
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Second user turn has assistant + tool_use + tool_result
            second_user = tree.root.children[1]
            text = _extract_subtree_text(second_user)
            # Should contain user text, assistant text, and tool content
            assert "tell me about python" in text
            assert "Python" in text or "programming" in text.lower()

    @pytest.mark.asyncio
    async def test_copy_leaf_same_for_c_and_C(self, project_dir, clipboard):
        """On a leaf node, c and C produce the same result."""
        from cctree.tui.app import CctreeApp, _extract_copy_text, _extract_subtree_text
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # First user's assistant is a leaf (short text, no tools)
            user_node = tree.root.children[0]
            asst_node = user_node.children[0]
            single = _extract_copy_text(asst_node)
            subtree = _extract_subtree_text(asst_node)
            assert single == subtree

    @pytest.mark.asyncio
    async def test_c_binding_in_footer(self, project_dir):
        """The BINDINGS list should include a 'c' -> Copy binding."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        binding_keys = [b.key for b in app.BINDINGS]
        assert "c" in binding_keys
        copy_binding = next(b for b in app.BINDINGS if b.key == "c")
        assert "Copy" in copy_binding.description or "copy" in copy_binding.description


class TestCopyCompactBoundary:
    """Copy on non-copyable nodes like compact boundary."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-compact-copy-0000-000000000000"
        lines = [
            json.dumps({"type": "user", "uuid": "cu1", "parentUuid": None,
                        "message": {"role": "user", "content": "before compact"},
                        "sessionId": session_id, "slug": "compact-copy",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "ca1", "parentUuid": "cu1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "answer"},
                        ]},
                        "sessionId": session_id, "slug": "compact-copy",
                        "timestamp": "2026-04-01T10:00:05Z"}),
            json.dumps({"type": "system", "subtype": "compact_boundary",
                        "uuid": "cc1", "parentUuid": "ca1",
                        "content": "Summary",
                        "timestamp": "2026-04-01T10:01:00Z",
                        "sessionId": session_id, "isSidechain": False}),
            json.dumps({"type": "user", "uuid": "cu2", "parentUuid": "cc1",
                        "message": {"role": "user", "content": "after compact"},
                        "sessionId": session_id, "slug": "compact-copy",
                        "timestamp": "2026-04-01T10:02:00Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))
        return tmp_path

    @pytest.fixture
    def clipboard(self, monkeypatch):
        copied = []
        import pyperclip
        monkeypatch.setattr(pyperclip, "copy", lambda text: copied.append(text))
        return copied

    @pytest.mark.asyncio
    async def test_copy_compact_node_does_nothing(self, project_dir, clipboard):
        """c on a compact boundary node should flash 'Nothing to copy', not crash."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree, Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-compact-copy-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Find compact boundary node
            compact_node = None
            for child in tree.root.children:
                if child.data and child.data.get("type") == "compact":
                    compact_node = child
                    break
            assert compact_node is not None, "No compact node found"

            tree.select_node(compact_node)
            await pilot.pause()

            await pilot.press("c")
            await pilot.pause()

            assert len(clipboard) == 0
            status = app.query_one("#status-bar", Static)
            assert "Nothing to copy" in str(status.render())


# ── TDD: dynamic preview width — adapts to terminal size ─────────────────────

def _plain_label(node_or_label) -> str:
    """Get plain label text. Textual already processes Rich markup styling
    into Text style, so str(label) returns the visible plain text."""
    label = node_or_label.label if hasattr(node_or_label, "label") else node_or_label
    return str(label)


def _visible_text_after_prefix(label: str, prefix: str) -> str:
    """Get visible text after prefix (e.g., 'User: ' or 'Asst: ')."""
    if prefix in label:
        return label.split(prefix, 1)[1]
    return label


class TestDynamicPreviewWidth:
    """Preview labels adapt to terminal width: grow wide, wrap narrow.

    On wide terminals, the label expands to fill available width up to full text.
    On narrow terminals, the preview wraps to multiple continuation leaves.
    """

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-dynpreview-0000-0000-00000000000"
        # Three user messages: short, medium, very long
        short_text = "short text"  # 10 chars
        medium_text = "this is a medium length message with about eighty chars of content for testing."  # ~80 chars
        long_text = ("A" * 20 + " " + "B" * 20 + " " + "C" * 20 + " " + "D" * 20 + " "
                     + "E" * 20 + " " + "F" * 20 + " " + "G" * 20 + " " + "H" * 20)  # ~167 chars
        lines = [
            json.dumps({"type": "user", "uuid": "pu1", "parentUuid": None,
                        "message": {"role": "user", "content": short_text},
                        "sessionId": session_id, "slug": "dyn-test",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "user", "uuid": "pu2", "parentUuid": "pu1",
                        "message": {"role": "user", "content": medium_text},
                        "sessionId": session_id, "slug": "dyn-test",
                        "timestamp": "2026-04-01T10:00:10Z"}),
            json.dumps({"type": "user", "uuid": "pu3", "parentUuid": "pu2",
                        "message": {"role": "user", "content": long_text},
                        "sessionId": session_id, "slug": "dyn-test",
                        "timestamp": "2026-04-01T10:00:20Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))
        return tmp_path

    @pytest.mark.asyncio
    async def test_short_text_shows_full_no_ellipsis(self, project_dir):
        """Short text (<preview min) on any terminal: show full text, no '...'."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(200, 40)) as pilot:
            session = app.store.get("sess-dynpreview-0000-0000-00000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            first = tree.root.children[0]
            label = str(first.label)
            assert "short text" in label
            assert "..." not in label

    @pytest.mark.asyncio
    async def test_long_text_expands_on_wide_terminal(self, project_dir):
        """On a wide terminal, a long message's label should show more than 60 chars of text."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        # 300 cols total; tree width ~271 after sessions pane
        async with app.run_test(size=(300, 40)) as pilot:
            session = app.store.get("sess-dynpreview-0000-0000-00000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            long_node = tree.root.children[2]
            label = str(long_node.label)
            visible = _visible_text_after_prefix(label, "User: ")
            # Strip trailing "..." for length check
            core = visible.rstrip(".")
            # Wide terminal should show > 60 chars (min), ideally most of the 167-char text
            assert len(core) > 60, (
                f"Wide terminal should show >60 chars of preview, got {len(core)}: {visible!r}"
            )

    @pytest.mark.asyncio
    async def test_medium_text_fits_fully_on_wide_terminal(self, project_dir):
        """If full text fits on one line at current width, show all without '...'."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(300, 40)) as pilot:
            session = app.store.get("sess-dynpreview-0000-0000-00000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            medium_node = tree.root.children[1]
            label = str(medium_node.label)
            visible = _visible_text_after_prefix(label, "User: ")
            # The 80-char medium message fits easily in 271-col tree; no truncation expected
            assert "eighty chars of content for testing" in label, (
                f"Full medium text should be shown when it fits. Got: {visible!r}"
            )
            assert "..." not in label

    @pytest.mark.asyncio
    async def test_preview_covers_substantial_content_on_narrow(self, project_dir):
        """On a narrower terminal, long messages wrap across continuation leaves —
        the combined preview (label + inline continuations) should cover substantially
        more than 60 source chars (wrap gives many lines of visibility)."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        # 80 col terminal → tree ~51 cols → content ~45 chars per line
        async with app.run_test(size=(80, 40)) as pilot:
            session = app.store.get("sess-dynpreview-0000-0000-00000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            long_node = tree.root.children[2]
            label_text = _visible_text_after_prefix(str(long_node.label), "User: ").rstrip(".")
            wrap_child_texts: list[str] = []
            for child in long_node.children:
                if child.data and child.data.get("type") in ("full_text", "overflow"):
                    wrap_child_texts.append(str(child.label))
            total_visible = len(label_text) + sum(len(t.rstrip(".")) for t in wrap_child_texts)
            assert total_visible >= 60, (
                f"Wrapped preview should cover ≥60 chars (got {total_visible}). "
                f"label={label_text!r}, continuations={wrap_child_texts}"
            )

    @pytest.mark.asyncio
    async def test_narrow_terminal_label_fits_width(self, project_dir):
        """On narrow terminal, the parent label (first line) must fit within terminal width."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        # Very narrow: 50 cols → tree ~21 cols
        async with app.run_test(size=(50, 40)) as pilot:
            session = app.store.get("sess-dynpreview-0000-0000-00000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            long_node = tree.root.children[2]
            label_plain = str(long_node.label)
            tree_width = tree.size.width
            # Label should fit within tree width (allow +2 for tree indent icons, etc.)
            assert len(label_plain) <= tree_width + 2, (
                f"Label should fit terminal width {tree_width}, got {len(label_plain)} chars: {label_plain!r}"
            )

    @pytest.mark.asyncio
    async def test_narrow_terminal_has_wrap_continuation(self, project_dir):
        """On narrow terminal, long text preview wraps to continuation leaves."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(50, 40)) as pilot:
            session = app.store.get("sess-dynpreview-0000-0000-00000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            long_node = tree.root.children[2]
            wrap_children = [
                c for c in long_node.children
                if c.data and c.data.get("type") in ("full_text", "overflow")
            ]
            assert len(wrap_children) >= 1, (
                f"Narrow terminal should produce continuation leaves. "
                f"Children: {[(c.data.get('type') if c.data else '?', str(c.label)[:40]) for c in long_node.children]}"
            )

    @pytest.mark.asyncio
    async def test_assistant_label_also_dynamic(self, project_dir, tmp_path):
        """Assistant labels should also respect dynamic width (grow wide, wrap narrow)."""
        import json
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        # Build a session with a long assistant text
        session_id = "sess-asstdyn-0000-0000-0000-000000000000"
        asst_text = ("This is an assistant response that goes on for quite a while and should "
                     "demonstrate the dynamic width behavior for assistant labels.") * 2
        lines = [
            json.dumps({"type": "user", "uuid": "au1", "parentUuid": None,
                        "message": {"role": "user", "content": "hi"},
                        "sessionId": session_id, "slug": "asst-dyn",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "aa1", "parentUuid": "au1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": asst_text},
                        ]},
                        "sessionId": session_id, "slug": "asst-dyn",
                        "timestamp": "2026-04-01T10:00:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test(size=(300, 40)) as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            user_node = tree.root.children[0]
            asst_node = user_node.children[0]
            label = str(asst_node.label)
            visible = _visible_text_after_prefix(label, "Asst: ").rstrip(".")
            assert len(visible) > 60, (
                f"Assistant label on wide terminal should exceed 60 chars, got {len(visible)}: {visible!r}"
            )


# ── TDD: empty-expandable nodes (e.g. interrupt followed by noise events) ────

class TestEmptyExpandableInterrupt:
    """User nodes followed only by non-renderable events (file-history-snapshot,
    queue-operation, etc.) should be leaves, not empty expandable nodes.

    Real-world trigger: "[Request interrupted by user]" messages are often
    followed by a file-history-snapshot event. Before this fix, the interrupt
    user node got an expand arrow, but expanding revealed nothing — because the
    renderer silently skips event types it doesn't handle.
    """

    def _make_session(self, tmp_path, session_id: str, extra_events: list[dict]):
        """Helper: session = typed user → [Request interrupted] → extra_events."""
        import json
        lines = [
            json.dumps({
                "type": "user", "uuid": "pre1", "parentUuid": None,
                "message": {"role": "user", "content": "please do something"},
                "sessionId": session_id, "slug": "interrupt-test",
                "timestamp": "2026-04-01T10:00:00Z",
            }),
            # Interrupt user message (typed — has text content)
            json.dumps({
                "type": "user", "uuid": "interrupt1", "parentUuid": "pre1",
                "message": {"role": "user", "content": [
                    {"type": "text", "text": "[Request interrupted by user]"}
                ]},
                "sessionId": session_id, "slug": "interrupt-test",
                "timestamp": "2026-04-01T10:00:05Z",
            }),
        ]
        lines.extend(json.dumps(evt) for evt in extra_events)
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))

    def _find_interrupt_node(self, tree):
        """Find the User node whose label contains '[Request interrupted by user]'."""
        for child in tree.root.children:
            if "Request interrupted" in str(child.label):
                return child
        return None

    @pytest.mark.asyncio
    async def test_interrupt_followed_by_file_history_is_leaf(self, tmp_path):
        """A file-history-snapshot after an interrupt must NOT make the user node expandable."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        session_id = "sess-interrupt-fh-0000-0000-000000000000"
        self._make_session(tmp_path, session_id, extra_events=[
            {
                "type": "file-history-snapshot",
                "messageId": "xyz",
                "snapshot": {"trackedFileBackups": {}, "timestamp": "2026-04-01T10:00:06Z"},
                "isSnapshotUpdate": False,
            },
        ])

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            interrupt_node = self._find_interrupt_node(tree)
            assert interrupt_node is not None, "Expected to find the interrupt user node"
            assert len(interrupt_node.children) == 0, (
                f"Interrupt node followed only by file-history-snapshot should have no "
                f"children, got {len(interrupt_node.children)}: "
                f"{[str(c.label)[:40] for c in interrupt_node.children]}"
            )
            assert not interrupt_node.allow_expand, (
                "Interrupt node with no meaningful children should not show expand arrow"
            )

    @pytest.mark.asyncio
    async def test_interrupt_followed_by_queue_operation_is_leaf(self, tmp_path):
        """queue-operation after an interrupt must NOT make the user node expandable."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        session_id = "sess-interrupt-qo-0000-0000-000000000000"
        self._make_session(tmp_path, session_id, extra_events=[
            {"type": "queue-operation", "uuid": "qo1",
             "timestamp": "2026-04-01T10:00:06Z"},
        ])

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            interrupt_node = self._find_interrupt_node(tree)
            assert interrupt_node is not None
            assert len(interrupt_node.children) == 0, (
                f"Interrupt followed by queue-operation should have no children, "
                f"got {[str(c.label)[:40] for c in interrupt_node.children]}"
            )
            assert not interrupt_node.allow_expand

    @pytest.mark.asyncio
    async def test_interrupt_followed_by_custom_title_is_leaf(self, tmp_path):
        """custom-title after an interrupt must NOT make the user node expandable."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        session_id = "sess-interrupt-ct-0000-0000-000000000000"
        self._make_session(tmp_path, session_id, extra_events=[
            {"type": "custom-title", "customTitle": "my-session",
             "timestamp": "2026-04-01T10:00:06Z"},
        ])

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            interrupt_node = self._find_interrupt_node(tree)
            assert interrupt_node is not None
            assert len(interrupt_node.children) == 0
            assert not interrupt_node.allow_expand

    @pytest.mark.asyncio
    async def test_interrupt_followed_by_assistant_stays_expandable(self, tmp_path):
        """If an assistant message DOES follow the interrupt, the node should still be
        expandable — we must not drop legitimate turn content."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        session_id = "sess-interrupt-real-000-0000-000000000000"
        self._make_session(tmp_path, session_id, extra_events=[
            {
                "type": "assistant", "uuid": "aa-resp", "parentUuid": "interrupt1",
                "message": {"role": "assistant", "content": [
                    {"type": "text", "text": "Ok, stopping."}
                ]},
                "sessionId": session_id, "slug": "interrupt-test",
                "timestamp": "2026-04-01T10:00:10Z",
            },
        ])

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            interrupt_node = self._find_interrupt_node(tree)
            assert interrupt_node is not None
            assert len(interrupt_node.children) >= 1, (
                "Interrupt followed by an assistant response should have children"
            )
            labels = [str(c.label) for c in interrupt_node.children]
            assert any("stopping" in l.lower() or "Asst:" in l for l in labels), (
                f"Expected assistant child, got: {labels}"
            )

    @pytest.mark.asyncio
    async def test_interrupt_with_noise_and_assistant_is_expandable(self, tmp_path):
        """Mixed: noise events AND real assistant content → still expandable with only
        the real content shown (noise filtered)."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        session_id = "sess-interrupt-mix-0000-0000-000000000000"
        self._make_session(tmp_path, session_id, extra_events=[
            # Noise
            {"type": "file-history-snapshot", "messageId": "noise1",
             "snapshot": {"trackedFileBackups": {}, "timestamp": "2026-04-01T10:00:06Z"},
             "isSnapshotUpdate": False},
            # Real content
            {
                "type": "assistant", "uuid": "real-asst", "parentUuid": "interrupt1",
                "message": {"role": "assistant", "content": [
                    {"type": "text", "text": "Stopping as requested."}
                ]},
                "sessionId": session_id, "slug": "interrupt-test",
                "timestamp": "2026-04-01T10:00:07Z",
            },
            # More noise
            {"type": "last-prompt", "lastPrompt": "ignore me",
             "timestamp": "2026-04-01T10:00:08Z"},
        ])

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            interrupt_node = self._find_interrupt_node(tree)
            assert interrupt_node is not None
            assert len(interrupt_node.children) >= 1
            # All children should be renderable (assistant), none should be empty placeholders
            for child in interrupt_node.children:
                assert len(str(child.label).strip()) > 0, (
                    f"Empty child label from noise event: {child.label!r}"
                )

    @pytest.mark.asyncio
    async def test_real_interrupt_session_has_no_empty_expandable_nodes(self, tmp_path):
        """Golden test using a JSONL pattern matching the real screenshotted session:
        typed-user → assistant-with-tool → tool-result → interrupt → file-history-snapshot →
        next typed-user. No user node should be expandable-but-empty."""
        import json
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        session_id = "sess-real-int-0000-0000-0000-000000000000"
        events = [
            {"type": "user", "uuid": "r-u1", "parentUuid": None,
             "message": {"role": "user", "content": "search for things"},
             "sessionId": session_id, "slug": "real-int",
             "timestamp": "2026-04-01T10:00:00Z"},
            {"type": "assistant", "uuid": "r-a1", "parentUuid": "r-u1",
             "message": {"role": "assistant", "content": [
                 {"type": "tool_use", "id": "tu1", "name": "Grep",
                  "input": {"pattern": "foo"}}
             ]},
             "sessionId": session_id, "slug": "real-int",
             "timestamp": "2026-04-01T10:00:05Z"},
            # User interrupts
            {"type": "user", "uuid": "r-int", "parentUuid": "r-a1",
             "message": {"role": "user", "content": [
                 {"type": "text", "text": "[Request interrupted by user for tool use]"}
             ]},
             "sessionId": session_id, "slug": "real-int",
             "timestamp": "2026-04-01T10:00:06Z"},
            # Claude Code writes a file-history-snapshot
            {"type": "file-history-snapshot", "messageId": "fh1",
             "snapshot": {"trackedFileBackups": {}, "timestamp": "2026-04-01T10:00:07Z"},
             "isSnapshotUpdate": False},
            # Next user turn
            {"type": "user", "uuid": "r-u2", "parentUuid": "r-int",
             "message": {"role": "user", "content": "actually do something else"},
             "sessionId": session_id, "slug": "real-int",
             "timestamp": "2026-04-01T10:00:08Z"},
        ]
        (tmp_path / f"{session_id}.jsonl").write_text(
            "\n".join(json.dumps(e) for e in events) + "\n"
        )
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def walk(node, path=""):
                path = f"{path}/{str(node.label)[:30]}"
                if node.allow_expand and len(node.children) == 0:
                    return [path]
                offenders: list[str] = []
                for child in node.children:
                    offenders.extend(walk(child, path))
                return offenders

            # tree.root itself is expandable with kids — ignore it
            offenders = []
            for top_child in tree.root.children:
                offenders.extend(walk(top_child))
            assert offenders == [], (
                f"Found expandable nodes with no children: {offenders}"
            )


# ── TDD: terminal resize rebuilds the tree with new wrap widths ──────────────

class TestResizeRebuild:
    """When the terminal resizes, the session tree should re-render so that
    wrap widths adapt — no stale narrow-terminal wrapping on a wide terminal
    (or vice versa)."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-resize-0000-0000-0000-000000000000"
        # Long user text that wraps on 80-col but fits on 300-col
        long_text = (
            "this is a user message that is definitely longer than sixty characters "
            "and will wrap onto continuation leaves on a narrow terminal but fits "
            "comfortably on one line when the terminal is wide"
        )
        lines = [
            json.dumps({
                "type": "user", "uuid": "ru1", "parentUuid": None,
                "message": {"role": "user", "content": long_text},
                "sessionId": session_id, "slug": "resize-test",
                "timestamp": "2026-04-01T10:00:00Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "ra1", "parentUuid": "ru1",
                "message": {"role": "assistant", "content": [
                    {"type": "text", "text": "ok"}
                ]},
                "sessionId": session_id, "slug": "resize-test",
                "timestamp": "2026-04-01T10:00:05Z",
            }),
            json.dumps({
                "type": "user", "uuid": "ru2", "parentUuid": "ra1",
                "message": {"role": "user", "content": long_text + " round two"},
                "sessionId": session_id, "slug": "resize-test",
                "timestamp": "2026-04-01T10:00:10Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "ra2", "parentUuid": "ru2",
                "message": {"role": "assistant", "content": [
                    {"type": "text", "text": "done"}
                ]},
                "sessionId": session_id, "slug": "resize-test",
                "timestamp": "2026-04-01T10:00:15Z",
            }),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))
        return tmp_path

    @pytest.mark.asyncio
    async def test_resize_narrow_to_wide_drops_wrap_children(self, project_dir):
        """Loading on a narrow terminal then resizing wider should re-render the tree
        without the wrap continuation children (since text now fits on one line)."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 40)) as pilot:
            session = app.store.get("sess-resize-0000-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            user_node = tree.root.children[0]
            wrap_before = [c for c in user_node.children
                           if c.data and c.data.get("type") in ("full_text", "overflow")]
            assert len(wrap_before) > 0, (
                "On 80-col terminal, long text should wrap into continuation leaves. "
                f"Got children: {[(c.data, str(c.label)[:40]) for c in user_node.children]}"
            )

            # Resize wider — long text should now fit on one label line
            await pilot.resize_terminal(300, 40)
            await pilot.pause(0.5)  # let debounce + rebuild settle

            tree = app.query_one("#session-tree", Tree)
            user_node = tree.root.children[0]
            wrap_after = [c for c in user_node.children
                          if c.data and c.data.get("type") in ("full_text", "overflow")]
            assert len(wrap_after) == 0, (
                f"On 300-col terminal after resize, text should fit on one line. "
                f"Got {len(wrap_after)} wrap children: "
                f"{[(c.data, str(c.label)[:40]) for c in user_node.children]}"
            )

    @pytest.mark.asyncio
    async def test_resize_wide_to_narrow_adds_wrap_children(self, project_dir):
        """Inverse: wide → narrow must trigger wrapping that wasn't there before."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(300, 40)) as pilot:
            session = app.store.get("sess-resize-0000-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            user_node = tree.root.children[0]
            wrap_before = [c for c in user_node.children
                           if c.data and c.data.get("type") in ("full_text", "overflow")]
            assert len(wrap_before) == 0, "Wide terminal should not wrap"

            await pilot.resize_terminal(80, 40)
            await pilot.pause(0.5)

            tree = app.query_one("#session-tree", Tree)
            user_node = tree.root.children[0]
            wrap_after = [c for c in user_node.children
                          if c.data and c.data.get("type") in ("full_text", "overflow")]
            assert len(wrap_after) > 0, (
                f"After resizing narrow, long text should wrap. Children: "
                f"{[(c.data, str(c.label)[:40]) for c in user_node.children]}"
            )

    @pytest.mark.asyncio
    async def test_resize_preserves_expanded_state(self, project_dir):
        """Nodes expanded before resize should remain expanded after the rebuild."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 40)) as pilot:
            session = app.store.get("sess-resize-0000-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Expand the first user node
            user_node = tree.root.children[0]
            user_uuid = user_node.data.get("uuid") if user_node.data else None
            assert user_uuid is not None
            user_node.expand()
            await pilot.pause()
            assert user_node.is_expanded

            # Resize
            await pilot.resize_terminal(200, 40)
            await pilot.pause(0.5)

            # Find the same user node after rebuild (by uuid)
            tree = app.query_one("#session-tree", Tree)
            rebuilt = None
            for child in tree.root.children:
                if child.data and child.data.get("uuid") == user_uuid:
                    rebuilt = child
                    break
            assert rebuilt is not None, "User node missing after resize rebuild"
            assert rebuilt.is_expanded, (
                "User node should still be expanded after resize. "
                f"is_expanded={rebuilt.is_expanded}"
            )

    @pytest.mark.asyncio
    async def test_resize_without_loaded_session_is_noop(self, project_dir):
        """Resize event when no session is loaded must not crash."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 40)) as pilot:
            # Don't load a session
            await pilot.resize_terminal(200, 40)
            await pilot.pause(0.5)
            # Reaching here without exception is success
            assert app.is_running

    @pytest.mark.asyncio
    async def test_resize_debounces_rapid_events(self, project_dir):
        """Multiple rapid resizes should coalesce into a single rebuild."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 40)) as pilot:
            session = app.store.get("sess-resize-0000-0000-0000-000000000000")
            app.load_session(session)

            # Count how many times load_session gets called after our initial load
            original_load = app.load_session
            call_count = [0]
            def counting_load(sess):
                call_count[0] += 1
                return original_load(sess)
            app.load_session = counting_load  # type: ignore[assignment]

            # Fire several resizes in quick succession — should debounce to 1 rebuild
            for width in (100, 120, 140, 160, 180, 200):
                await pilot.resize_terminal(width, 40)
            await pilot.pause(0.5)  # wait for debounce

            assert call_count[0] <= 6, (
                f"Rapid resize should debounce to ≤6 rebuilds, got {call_count[0]}"
            )
            assert call_count[0] >= 1, "At least one rebuild should happen"


# ── Per-turn context window display in the status bar ──────────────────────


class TestContextStatusBar:
    """The status bar shows per-turn context usage info when a session is open.

    See /Users/tinytim/.claude/plans/hazy-swinging-cocoa.md for the full design.
    """

    @pytest.fixture
    def project_dir(self, tmp_path):
        """Project with a real-usage fixture session."""
        dest_name = "usg0001-0000-0000-0000-000000000001.jsonl"
        (tmp_path / dest_name).write_text((FIXTURES / "with_usage.jsonl").read_text())
        # Also add an older-usage-free session for comparison tests
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        # Normalize mtimes so order is stable
        old_time = time.time() - 300
        for f in tmp_path.glob("*.jsonl"):
            os.utime(f, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_initial_status_bar_populated_on_load(self, project_dir):
        """On session load, status bar shows the first real turn's context — NOT empty."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            # First turn's context should show up — opus-4-6 at small percent
            assert "opus-4-6" in rendered
            # Bar characters present
            assert "█" in rendered or "░" in rendered
            # Some number for tokens
            assert "/" in rendered  # total/window separator

    @pytest.mark.asyncio
    async def test_status_bar_updates_on_arrow_navigation(self, project_dir):
        """Arrowing through turns updates the status bar to each turn's context."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            # Move to first turn in the tree
            await pilot.press("down")
            await pilot.pause(0.1)

            # NodeHighlighted should have fired and populated the bar
            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            # Status should reflect context data, not "no usage"
            assert "no usage data" not in rendered

    @pytest.mark.asyncio
    async def test_status_bar_session_predates_usage(self, project_dir):
        """Older session (no usage data anywhere) shows the 'predates' message."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            assert "predates per-turn usage logging" in rendered

    @pytest.mark.asyncio
    async def test_flash_sets_flashing_class(self, project_dir):
        """Triggering a flash adds the .flashing CSS class to the status bar."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            # Directly invoke the flash path (avoids depending on a specific
            # keypress action's side-effects).
            app._flash_status("Test flash")
            status = app.query_one("#status-bar", Static)
            assert status.has_class("flashing")
            assert app._flash_active is True
            rendered = str(status.render())
            assert "Test flash" in rendered

    @pytest.mark.asyncio
    async def test_flash_restored_via_timer_callback(self, project_dir):
        """After the flash timer fires, the status bar returns to context content.

        We invoke the timer's callback directly instead of waiting for 2 real
        seconds — that would be flaky.
        """
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        # Capture the set_timer callback so we can run it synchronously
        captured = {}
        original_set_timer = None

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            original_set_timer = app.set_timer

            def capture_set_timer(delay, callback):
                captured["callback"] = callback
                return original_set_timer(delay, callback)

            app.set_timer = capture_set_timer  # type: ignore[assignment]

            app._flash_status("TransientMsg")
            status = app.query_one("#status-bar", Static)
            assert "TransientMsg" in str(status.render())

            # Invoke the restore callback manually
            assert "callback" in captured, "flash did not register a timer"
            captured["callback"]()
            # Now bar is restored to context (no .flashing class, no flash text)
            assert not status.has_class("flashing")
            assert app._flash_active is False
            rendered = str(status.render())
            assert "TransientMsg" not in rendered

    @pytest.mark.asyncio
    async def test_placeholder_node_short_circuits_no_data(self, project_dir):
        """Cursor on a node with type 'subagent_placeholder' returns no-data
        reason WITHOUT walking up to the parent turn's context."""
        from cctree.tui.app import CctreeApp
        from cctree.core.context_usage import TurnContext

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            from textual.widgets import Tree
            tree = app.query_one("#session-tree", Tree)
            # Synthesize a placeholder node under the root
            node = tree.root.add_leaf(
                "[placeholder]",
                data={"type": "subagent_placeholder", "sub_path": "/nowhere"},
            )
            tc, reason = app._resolve_context_for_node(node)
            assert tc is None
            assert reason == "subagent_placeholder"

    @pytest.mark.asyncio
    async def test_teammates_section_short_circuits(self, project_dir):
        """Cursor on the Teammates section header shows its contextual message
        (not the lead's most recent context)."""
        from cctree.tui.app import CctreeApp

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            from textual.widgets import Tree
            tree = app.query_one("#session-tree", Tree)
            fake_section = tree.root.add(
                "[bold magenta]Teammates[/bold magenta]",
                data={"type": "teammates_section"},
            )
            # Add a child with a real uuid — short-circuit must prevent walk-up
            fake_section.add_leaf("child", data={"type": "teammate_placeholder", "name": "x", "paths": []})

            tc, reason = app._resolve_context_for_node(fake_section)
            assert tc is None
            assert reason == "teammates_section"

    @pytest.mark.asyncio
    async def test_narrow_mode_toggles_below_80_cols(self, project_dir):
        """On a narrow terminal, status bar enters compact mode (bar ≤ 12 chars,
        abbreviated breakdown with r:/c:/o:)."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(70, 30)) as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            # Narrow mode uses r:/c:/o: abbreviations
            assert " r:" in rendered or "r:" in rendered
            assert "+read:" not in rendered  # wide-mode label is suppressed

    @pytest.mark.asyncio
    async def test_wide_mode_uses_full_breakdown(self, project_dir):
        """On a wide terminal, the full +read:/+create: labels appear."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(140, 30)) as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            assert "+read:" in rendered
            assert "+create:" in rendered

    @pytest.mark.asyncio
    async def test_compact_boundary_node_shows_prior_turn_context(self, tmp_path):
        """A compact_boundary node, when highlighted, shows the pre-compaction turn's context."""
        import json
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        # Build a tiny session with usage data then a compact boundary
        lines = [
            json.dumps({
                "type": "user", "uuid": "u1", "message": {"role": "user", "content": "hi"},
                "sessionId": "compact-ctx", "slug": "compact-ctx", "version": "2.1.77",
                "timestamp": "2026-04-10T10:00:00.000Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "a1",
                "message": {
                    "role": "assistant", "model": "claude-opus-4-6", "content": "ok",
                    "usage": {
                        "input_tokens": 3, "cache_creation_input_tokens": 4_000,
                        "cache_read_input_tokens": 6_000, "output_tokens": 50,
                    },
                },
                "sessionId": "compact-ctx", "slug": "compact-ctx", "version": "2.1.77",
                "timestamp": "2026-04-10T10:00:02.000Z",
            }),
            json.dumps({
                "type": "system", "subtype": "compact_boundary", "uuid": "cpt",
                "sessionId": "compact-ctx",
                "timestamp": "2026-04-10T10:00:10.000Z",
            }),
        ]
        (tmp_path / "compact-ctx-0000-0000-0000-000000000000.jsonl").write_text("\n".join(lines) + "\n")

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get("compact-ctx-0000-0000-0000-000000000000")
            app.load_session(session)
            await pilot.pause(0.1)

            # Compact boundary UUID should be in the turn_context map
            assert "cpt" in app._turn_context
            # And should reference the prior turn's context numbers
            assert app._turn_context["cpt"].total_input == app._turn_context["a1"].total_input

    @pytest.mark.asyncio
    async def test_subagent_context_map_carries_outer(self, tmp_path):
        """When a subagent is lazy-loaded, its turn_context entries carry the
        outer (enclosing assistant's) TurnContext."""
        import json
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        # Parent session with an Agent tool_use, and a matching subagent file
        project_dir = tmp_path
        session_uuid = "sa-outer-0000-0000-0000-000000000000"

        agent_id = "abc123def456"
        # Parent JSONL: user + assistant (with Agent tool_use) + progress event linking to agent_id
        parent_lines = [
            json.dumps({
                "type": "user", "uuid": "u1",
                "message": {"role": "user", "content": "run explorer"},
                "sessionId": session_uuid, "slug": "sa-outer",
                "version": "2.1.77",
                "timestamp": "2026-04-10T10:00:00.000Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "a_outer",
                "message": {
                    "role": "assistant", "model": "claude-opus-4-6",
                    "content": [
                        {"type": "text", "text": "calling agent"},
                        {"type": "tool_use", "id": "toolu_abc", "name": "Agent",
                         "input": {"description": "go", "prompt": "explore"}},
                    ],
                    "usage": {
                        "input_tokens": 3, "cache_creation_input_tokens": 1000,
                        "cache_read_input_tokens": 5000, "output_tokens": 100,
                    },
                },
                "sessionId": session_uuid, "slug": "sa-outer",
                "version": "2.1.77",
                "timestamp": "2026-04-10T10:00:02.000Z",
            }),
            json.dumps({
                "type": "progress", "uuid": "p1",
                "parentToolUseID": "toolu_abc",
                "data": {"agentId": agent_id},
                "sessionId": session_uuid,
                "timestamp": "2026-04-10T10:00:03.000Z",
            }),
        ]
        (project_dir / f"{session_uuid}.jsonl").write_text("\n".join(parent_lines) + "\n")

        # Subagent JSONL (lives under <session-uuid>/subagents/)
        sub_dir = project_dir / session_uuid / "subagents"
        sub_dir.mkdir(parents=True)
        sub_lines = [
            json.dumps({
                "type": "user", "uuid": "sub_u1",
                "message": {"role": "user", "content": "sub prompt"},
                "timestamp": "2026-04-10T10:00:04.000Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "sub_a1",
                "message": {
                    "role": "assistant", "model": "claude-haiku-4-5-20251001",
                    "content": "sub result",
                    "usage": {
                        "input_tokens": 3, "cache_creation_input_tokens": 500,
                        "cache_read_input_tokens": 1500, "output_tokens": 80,
                    },
                },
                "timestamp": "2026-04-10T10:00:05.000Z",
            }),
        ]
        (sub_dir / f"agent-{agent_id}.jsonl").write_text("\n".join(sub_lines) + "\n")

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get(session_uuid)
            app.load_session(session)
            await pilot.pause(0.1)

            # Outer assistant is in the map
            assert "a_outer" in app._turn_context
            outer_tc = app._turn_context["a_outer"]

            # Expand the Agent tool_use node to trigger subagent lazy-load
            tree = app.query_one("#session-tree", Tree)

            # Find the agent node (walk tree)
            def find(node, type_):
                if node.data and node.data.get("type") == type_:
                    return node
                for child in node.children:
                    r = find(child, type_)
                    if r is not None:
                        return r
                return None

            agent_node = find(tree.root, "agent")
            assert agent_node is not None, "agent tool_use node not found in tree"
            agent_node.expand()
            await pilot.pause(0.2)

            # Subagent turn's TurnContext should have outer = the parent assistant's TC
            assert "sub_a1" in app._turn_context
            sub_tc = app._turn_context["sub_a1"]
            assert sub_tc.outer is outer_tc

    # ── Teammate, resize, and subagent layout integration tests ───────────

    def _build_team_session(self, tmp_path, *, teammate_id="alice",
                            teammate_color="blue", teammate_id_in_tag=None,
                            num_files=1, events_per_file=2):
        """Helper: build a team-lead session with teammate wake-up files.

        Returns (project_dir, session_uuid).
        """
        import json

        session_uuid = "tm-ctx-0000-0000-0000-000000000000"
        tag_id = teammate_id_in_tag if teammate_id_in_tag is not None else teammate_id

        # Lead session JSONL
        lead_events = [
            {
                "type": "user", "uuid": "u1", "sessionId": session_uuid,
                "slug": "tm-ctx", "teamName": "demo", "version": "2.1.77",
                "timestamp": "2026-04-10T10:00:00.000Z",
                "message": {"role": "user", "content": "kick off"},
            },
            {
                "type": "user", "uuid": "u2", "parentUuid": "u1",
                "sessionId": session_uuid, "teamName": "demo",
                "timestamp": "2026-04-10T10:00:05.000Z",
                "message": {
                    "role": "user",
                    "content": (
                        f'<teammate-message teammate_id="{tag_id}" '
                        f'color="{teammate_color}" summary="Report">\n'
                        f"Hello from {tag_id}\n"
                        "</teammate-message>"
                    ),
                },
            },
            {
                "type": "assistant", "uuid": "a1", "parentUuid": "u2",
                "sessionId": session_uuid, "teamName": "demo",
                "timestamp": "2026-04-10T10:00:10.000Z",
                "message": {
                    "role": "assistant", "model": "claude-opus-4-6",
                    "content": "got it",
                    "usage": {
                        "input_tokens": 3, "cache_creation_input_tokens": 2000,
                        "cache_read_input_tokens": 4000, "output_tokens": 50,
                    },
                },
            },
        ]
        lead_path = tmp_path / f"{session_uuid}.jsonl"
        with open(lead_path, "w") as f:
            for evt in lead_events:
                f.write(json.dumps(evt) + "\n")
        old_time = time.time() - 300
        os.utime(lead_path, (old_time, old_time))

        # Teammate wake-up files under <session-uuid>/subagents/
        sub_dir = tmp_path / session_uuid / "subagents"
        sub_dir.mkdir(parents=True)

        hashes = ["aaaa1111", "bbbb2222", "cccc3333", "dddd4444"]
        for file_idx in range(num_files):
            h = hashes[file_idx]
            # Meta file — NO "description" field (teammate, not Agent-tool subagent)
            meta = {"agentType": teammate_id}
            (sub_dir / f"agent-{h}.meta.json").write_text(json.dumps(meta))

            lines = []
            for evt_idx in range(events_per_file):
                ts_minute = file_idx * 10 + evt_idx
                lines.append(json.dumps({
                    "type": "user", "uuid": f"tu_{h}_{evt_idx}",
                    "sessionId": session_uuid,
                    "timestamp": f"2026-04-10T10:{ts_minute:02d}:00.000Z",
                    "message": {"role": "user", "content": f"task {evt_idx}"},
                }))
                lines.append(json.dumps({
                    "type": "assistant", "uuid": f"ta_{h}_{evt_idx}",
                    "parentUuid": f"tu_{h}_{evt_idx}",
                    "sessionId": session_uuid,
                    "timestamp": f"2026-04-10T10:{ts_minute:02d}:02.000Z",
                    "message": {
                        "role": "assistant", "model": "claude-opus-4-6",
                        "content": f"result {evt_idx}",
                        "usage": {
                            "input_tokens": 3,
                            "cache_creation_input_tokens": 1000 * (evt_idx + 1),
                            "cache_read_input_tokens": 2000 * (evt_idx + 1),
                            "output_tokens": 40 + evt_idx * 10,
                        },
                    },
                }))
            jsonl_path = sub_dir / f"agent-{h}.jsonl"
            jsonl_path.write_text("\n".join(lines) + "\n")
            os.utime(jsonl_path, (old_time + file_idx, old_time + file_idx))

        return tmp_path, session_uuid

    def _find_node(self, node, type_):
        """Walk tree to find the first node with the given data type."""
        if node.data and node.data.get("type") == type_:
            return node
        for child in node.children:
            r = self._find_node(child, type_)
            if r is not None:
                return r
        return None

    def _find_nodes(self, node, type_):
        """Walk tree to find ALL nodes with the given data type."""
        out = []
        if node.data and node.data.get("type") == type_:
            out.append(node)
        for child in node.children:
            out.extend(self._find_nodes(child, type_))
        return out

    @pytest.mark.asyncio
    async def test_teammate_shows_color_prefix(self, tmp_path):
        """Expanding a teammate node and navigating into it shows the teammate
        name as a color prefix in the status bar."""
        from cctree.tui.app import CctreeApp
        from cctree.core.context_usage import format_status_lines
        from textual.widgets import Tree

        project_dir, session_uuid = self._build_team_session(tmp_path)

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(140, 40)) as pilot:
            session = app.store.get(session_uuid)
            app.load_session(session)
            await pilot.pause(0.2)

            tree = app.query_one("#session-tree", Tree)

            # Find and expand the teammate_root node
            tm_root = self._find_node(tree.root, "teammate_root")
            assert tm_root is not None, "teammate_root node not found"
            tm_root.expand()
            await pilot.pause(0.3)

            # Find an assistant node inside the teammate timeline
            assistant_nodes = self._find_nodes(tm_root, "assistant")
            if not assistant_nodes:
                for child in tm_root.children:
                    if child.data and child.data.get("uuid", "").startswith("ta_"):
                        assistant_nodes.append(child)
                        break

            assert assistant_nodes, "No assistant nodes found inside teammate timeline"

            # Resolve context for this node — should carry teammate_name
            tc, reason = app._resolve_context_for_node(assistant_nodes[0])
            assert tc is not None, f"Expected TurnContext, got reason={reason}"
            assert tc.teammate_name == "alice"

            # Render via format_status_lines (same path on_tree_node_highlighted uses)
            lines = format_status_lines(tc, narrow=False)
            joined = "\n".join(lines)
            assert "alice" in joined, f"Status bar lines should contain 'alice', got: {joined}"

    @pytest.mark.asyncio
    async def test_teammate_color_case_insensitive_fallback(self, tmp_path):
        """When _teammate_colors has 'Alice' (capital A) but the teammate_root's
        name is 'alice' (lowercase from meta agentType), the case-insensitive
        fallback in _add_teammate_timeline still picks up the blue color."""
        import json
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        session_uuid = "tm-case-0000-0000-0000-000000000000"

        # Lead session: two teammate-message tags —
        #   "Alice" with color="blue" (populates _teammate_colors["Alice"])
        #   "alice" without color (creates a reference matching the meta)
        lead_events = [
            {
                "type": "user", "uuid": "u1", "sessionId": session_uuid,
                "slug": "tm-case", "teamName": "demo", "version": "2.1.77",
                "timestamp": "2026-04-10T10:00:00.000Z",
                "message": {"role": "user", "content": "kick off"},
            },
            {
                "type": "user", "uuid": "u2", "parentUuid": "u1",
                "sessionId": session_uuid, "teamName": "demo",
                "timestamp": "2026-04-10T10:00:05.000Z",
                "message": {
                    "role": "user",
                    "content": (
                        '<teammate-message teammate_id="Alice" color="blue" summary="R1">\n'
                        "report from Alice\n"
                        "</teammate-message>\n"
                        '<teammate-message teammate_id="alice" summary="R2">\n'
                        "second report\n"
                        "</teammate-message>"
                    ),
                },
            },
            {
                "type": "assistant", "uuid": "a1", "parentUuid": "u2",
                "sessionId": session_uuid, "teamName": "demo",
                "timestamp": "2026-04-10T10:00:10.000Z",
                "message": {
                    "role": "assistant", "model": "claude-opus-4-6",
                    "content": "got it",
                    "usage": {
                        "input_tokens": 3, "cache_creation_input_tokens": 2000,
                        "cache_read_input_tokens": 4000, "output_tokens": 50,
                    },
                },
            },
        ]
        lead_path = tmp_path / f"{session_uuid}.jsonl"
        with open(lead_path, "w") as f:
            for evt in lead_events:
                f.write(json.dumps(evt) + "\n")
        old_time = time.time() - 300
        os.utime(lead_path, (old_time, old_time))

        # Teammate file — agentType="alice" (lowercase, matches the second tag)
        sub_dir = tmp_path / session_uuid / "subagents"
        sub_dir.mkdir(parents=True)
        meta = {"agentType": "alice"}
        (sub_dir / "agent-casehash.meta.json").write_text(json.dumps(meta))
        tm_lines = [
            json.dumps({
                "type": "user", "uuid": "tu_case_0",
                "sessionId": session_uuid,
                "timestamp": "2026-04-10T10:01:00.000Z",
                "message": {"role": "user", "content": "task"},
            }),
            json.dumps({
                "type": "assistant", "uuid": "ta_case_0",
                "parentUuid": "tu_case_0",
                "sessionId": session_uuid,
                "timestamp": "2026-04-10T10:01:02.000Z",
                "message": {
                    "role": "assistant", "model": "claude-opus-4-6",
                    "content": "done",
                    "usage": {
                        "input_tokens": 3, "cache_creation_input_tokens": 1000,
                        "cache_read_input_tokens": 2000, "output_tokens": 40,
                    },
                },
            }),
        ]
        jsonl_path = sub_dir / "agent-casehash.jsonl"
        jsonl_path.write_text("\n".join(tm_lines) + "\n")
        os.utime(jsonl_path, (old_time, old_time))

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test(size=(140, 40)) as pilot:
            session = app.store.get(session_uuid)
            app.load_session(session)
            await pilot.pause(0.2)

            # _teammate_colors should have "Alice" -> "blue" (from the capital-A tag)
            assert "Alice" in app._teammate_colors, (
                f"Expected 'Alice' in _teammate_colors, got {app._teammate_colors}"
            )
            assert app._teammate_colors["Alice"] == "blue"
            # "alice" (lowercase) should NOT have its own entry (no color on that tag)
            assert "alice" not in app._teammate_colors

            tree = app.query_one("#session-tree", Tree)
            # "alice" (lowercase) matches the meta — should have a teammate_root node
            tm_root = self._find_node(tree.root, "teammate_root")
            assert tm_root is not None, "teammate_root node not found for 'alice'"
            assert tm_root.data["name"] == "alice"

            tm_root.expand()
            await pilot.pause(0.3)

            # After expand, context map should have the teammate's assistant TC
            assert "ta_case_0" in app._turn_context
            tc = app._turn_context["ta_case_0"]
            # Case-insensitive fallback: tm_name="alice" → looks up "alice" → miss →
            # lowered loop finds "Alice" → color="blue"
            assert tc.teammate_color == "blue", (
                f"Expected teammate_color='blue' via case-insensitive lookup, got {tc.teammate_color!r}"
            )

    @pytest.mark.asyncio
    async def test_teammate_wake_up_boundary_shows_reset(self, tmp_path):
        """The first assistant turn in the second wake-up file has
        is_wake_up_start=True and delta=None (context resets per wake-up)."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        project_dir, session_uuid = self._build_team_session(
            tmp_path, num_files=2, events_per_file=2,
        )

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(140, 40)) as pilot:
            session = app.store.get(session_uuid)
            app.load_session(session)
            await pilot.pause(0.2)

            tree = app.query_one("#session-tree", Tree)
            tm_root = self._find_node(tree.root, "teammate_root")
            assert tm_root is not None, "teammate_root node not found"
            tm_root.expand()
            await pilot.pause(0.3)

            # Second file hash is "bbbb2222", first assistant event is ta_bbbb2222_0
            second_file_uuid = "ta_bbbb2222_0"
            assert second_file_uuid in app._turn_context, (
                f"Expected {second_file_uuid} in turn_context after teammate expand"
            )
            tc = app._turn_context[second_file_uuid]
            assert tc.is_wake_up_start is True, (
                "First assistant in second wake-up file should have is_wake_up_start=True"
            )
            assert tc.delta is None, (
                "First assistant in a wake-up file should have delta=None (no prior context)"
            )

    @pytest.mark.asyncio
    async def test_resize_reformats_status_bar(self, project_dir):
        """Resize from wide to narrow reformats: '+read:' (wide) becomes 'r:' (narrow)."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(140, 40)) as pilot:
            session = app.store.get("usg0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause(0.1)

            tree = app.query_one("#session-tree", Tree)
            tree.focus()

            # Navigate until we land on a node with real usage data.
            # The first user node has no prior context; keep pressing down
            # until the status bar shows "+read:" (an assistant node).
            status = app.query_one("#status-bar", Static)
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause(0.1)
                rendered_wide = str(status.render())
                if "+read:" in rendered_wide:
                    break
            else:
                # If the loop exhausted without finding "+read:", fail with info
                rendered_wide = str(status.render())

            assert "+read:" in rendered_wide, (
                f"Wide mode should contain '+read:', got: {rendered_wide}"
            )

            # Shrink terminal below 80 cols to trigger narrow mode
            await pilot.resize_terminal(70, 30)
            await pilot.pause(0.5)

            rendered_narrow = str(status.render())
            assert "r:" in rendered_narrow, (
                f"Narrow mode should contain 'r:', got: {rendered_narrow}"
            )
            assert "+read:" not in rendered_narrow, (
                f"Narrow mode should NOT contain '+read:', got: {rendered_narrow}"
            )

    @pytest.mark.asyncio
    async def test_subagent_shows_sub_on_top(self, tmp_path):
        """Navigating to a subagent assistant node renders the 3-line status bar
        with line 1 containing '\\u21b3 sub' and the output containing 'from parent turn'."""
        import json
        from cctree.tui.app import CctreeApp
        from cctree.core.context_usage import format_status_lines
        from textual.widgets import Tree

        # Reuse the inline subagent fixture pattern from test_subagent_context_map_carries_outer
        project_dir = tmp_path
        session_uuid = "sa-layout-0000-0000-0000-000000000000"
        agent_id = "layoutagent123"

        parent_lines = [
            json.dumps({
                "type": "user", "uuid": "u1",
                "message": {"role": "user", "content": "run explorer"},
                "sessionId": session_uuid, "slug": "sa-layout",
                "version": "2.1.77",
                "timestamp": "2026-04-10T10:00:00.000Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "a_outer",
                "message": {
                    "role": "assistant", "model": "claude-opus-4-6",
                    "content": [
                        {"type": "text", "text": "calling agent"},
                        {"type": "tool_use", "id": "toolu_lay", "name": "Agent",
                         "input": {"description": "go", "prompt": "explore"}},
                    ],
                    "usage": {
                        "input_tokens": 3, "cache_creation_input_tokens": 1000,
                        "cache_read_input_tokens": 5000, "output_tokens": 100,
                    },
                },
                "sessionId": session_uuid, "slug": "sa-layout",
                "version": "2.1.77",
                "timestamp": "2026-04-10T10:00:02.000Z",
            }),
            json.dumps({
                "type": "progress", "uuid": "p1",
                "parentToolUseID": "toolu_lay",
                "data": {"agentId": agent_id},
                "sessionId": session_uuid,
                "timestamp": "2026-04-10T10:00:03.000Z",
            }),
        ]
        (project_dir / f"{session_uuid}.jsonl").write_text("\n".join(parent_lines) + "\n")

        sub_dir = project_dir / session_uuid / "subagents"
        sub_dir.mkdir(parents=True)
        sub_lines = [
            json.dumps({
                "type": "user", "uuid": "sub_u1",
                "message": {"role": "user", "content": "sub prompt"},
                "timestamp": "2026-04-10T10:00:04.000Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "sub_a1",
                "message": {
                    "role": "assistant", "model": "claude-haiku-4-5-20251001",
                    "content": "sub result",
                    "usage": {
                        "input_tokens": 3, "cache_creation_input_tokens": 500,
                        "cache_read_input_tokens": 1500, "output_tokens": 80,
                    },
                },
                "timestamp": "2026-04-10T10:00:05.000Z",
            }),
        ]
        (sub_dir / f"agent-{agent_id}.jsonl").write_text("\n".join(sub_lines) + "\n")

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(140, 40)) as pilot:
            session = app.store.get(session_uuid)
            app.load_session(session)
            await pilot.pause(0.1)

            tree = app.query_one("#session-tree", Tree)

            # Find and expand the agent node to trigger subagent lazy-load
            agent_node = self._find_node(tree.root, "agent")
            assert agent_node is not None, "agent tool_use node not found"
            agent_node.expand()
            await pilot.pause(0.2)

            # Verify the subagent TC was created with outer reference
            assert "sub_a1" in app._turn_context
            sub_tc = app._turn_context["sub_a1"]
            assert sub_tc.outer is not None, "Subagent TurnContext should have outer set"

            # Render status lines for the subagent TC
            lines = format_status_lines(sub_tc, narrow=False)
            assert len(lines) == 3, f"Subagent status should have 3 lines, got {len(lines)}"
            assert "\u21b3 sub" in lines[0], (
                f"Line 1 should contain '\u21b3 sub', got: {lines[0]}"
            )
            assert "from parent turn" in lines[2], (
                f"Line 3 should contain 'from parent turn', got: {lines[2]}"
            )

    @pytest.mark.asyncio
    async def test_teammate_files_parsed_once(self, tmp_path):
        """Expanding a teammate node parses each wake-up file exactly once
        (not doubled for timeline + context map)."""
        from unittest.mock import patch
        from cctree.tui.app import CctreeApp
        import cctree.tui.app as app_mod
        from textual.widgets import Tree

        num_files = 2
        project_dir, session_uuid = self._build_team_session(
            tmp_path, num_files=num_files, events_per_file=2,
        )

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(140, 40)) as pilot:
            original_parse = app_mod.parse_jsonl
            call_count = [0]

            def counting_parse(path):
                call_count[0] += 1
                return original_parse(path)

            with patch.object(app_mod, "parse_jsonl", side_effect=counting_parse):
                session = app.store.get(session_uuid)
                app.load_session(session)
                await pilot.pause(0.2)

                tree = app.query_one("#session-tree", Tree)
                tm_root = self._find_node(tree.root, "teammate_root")
                assert tm_root is not None, "teammate_root node not found"

                # Reset counter — load_session may parse the lead file
                call_count[0] = 0

                tm_root.expand()
                await pilot.pause(0.3)

                assert call_count[0] == num_files, (
                    f"Expected parse_jsonl called exactly {num_files} times "
                    f"(once per wake-up file), got {call_count[0]}"
                )


# ── Integration tests: information density features ────────────────────────────

class TestAutoExpandUserTurns:
    """User turns should be auto-expanded on session load."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        return tmp_path

    @pytest.mark.asyncio
    async def test_user_turns_expanded_on_load(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            user_nodes = [
                n for n in tree.root.children
                if n.data and n.data.get("type") == "user"
            ]
            assert len(user_nodes) > 0, "No user turns in tree"
            for node in user_nodes:
                if node.children:
                    assert node.is_expanded, (
                        f"User turn '{str(node.label)[:40]}' should be auto-expanded"
                    )


class TestToolSummaryOnCollapsedNodes:
    """Collapsed assistant nodes should show tool names, not '(tool calls)'."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        return tmp_path

    @pytest.mark.asyncio
    async def test_collapsed_asst_shows_tool_names(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Find assistant nodes that have tools
            for node in tree.root.children:
                if not node.data or node.data.get("type") != "user":
                    continue
                for child in node.children:
                    if child.data and child.data.get("type") == "assistant":
                        label = str(child.label)
                        # Should NOT say "(tool calls)" if tools exist
                        if "(tool calls)" not in label:
                            # Good — shows actual tool names
                            assert "Asst:" in label


class TestOverflowIsNode:
    """Overflow '...(N more lines)' nodes should be expandable (with children)."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-overflow-0000-0000-000000000000"
        long_text = ("This is a very long message. " * 50).strip()
        lines = [json.dumps({
            "type": "user", "uuid": "ov-u1", "parentUuid": None,
            "message": {"role": "user", "content": long_text},
            "sessionId": session_id, "slug": "overflow-test",
            "timestamp": "2026-04-01T10:00:00Z",
        })]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        return tmp_path

    @pytest.mark.asyncio
    async def test_overflow_node_has_children_and_starts_collapsed(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-overflow-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def find_overflow(node):
                if node.data and node.data.get("type") == "overflow":
                    return node
                for child in node.children:
                    found = find_overflow(child)
                    if found:
                        return found
                return None

            overflow = find_overflow(tree.root)
            assert overflow is not None, "No overflow node found"
            assert len(overflow.children) > 0, (
                "Overflow node should have children (the hidden lines)"
            )
            assert not overflow.is_expanded, (
                "Overflow node should start collapsed"
            )


class TestOverflowExpansion:
    """Expanding an overflow node reveals its children; collapsing hides them."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        import json
        session_id = "sess-ovexp-0000-0000-000000000000"
        # Long user text that will create overflow lines
        long_text = ("This is a very long message that should be word-wrapped "
                     "across multiple lines instead of displaying as a single "
                     "horizontal line that requires scrolling to read. ") * 5
        lines = [
            json.dumps({"type": "user", "uuid": "oe-u1", "parentUuid": None,
                        "message": {"role": "user", "content": long_text.strip()},
                        "sessionId": session_id, "slug": "overflow-expand",
                        "timestamp": "2026-04-01T10:00:00Z"}),
            json.dumps({"type": "assistant", "uuid": "oe-a1", "parentUuid": "oe-u1",
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": "Got it."},
                        ]},
                        "sessionId": session_id, "slug": "overflow-expand",
                        "timestamp": "2026-04-01T10:00:05Z"}),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        os.utime(tmp_path / f"{session_id}.jsonl", (time.time() - 300, time.time() - 300))
        return tmp_path

    @pytest.mark.asyncio
    async def test_overflow_expand_reveals_children_and_persists(self, project_dir):
        """Expanding overflow shows children under it; node stays in tree."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-ovexp-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            user_node = tree.root.children[0]

            def find_overflow(node):
                if node.data and node.data.get("type") == "overflow":
                    return node
                for child in node.children:
                    found = find_overflow(child)
                    if found:
                        return found
                return None

            overflow = find_overflow(user_node)
            assert overflow is not None, "No overflow node found"

            overflow_count = len(overflow.data["overflow_lines"])
            assert overflow_count > 0
            children_before = len(user_node.children)

            # Expand the overflow node (native tree expand)
            overflow.expand()
            await pilot.pause()

            # Overflow node persists — it's not destroyed
            assert find_overflow(user_node) is overflow

            # Overflow is now expanded with children
            assert overflow.is_expanded
            assert len(overflow.children) == overflow_count

            # All children are full_text continuation leaves
            for child in overflow.children:
                assert child.data and child.data.get("type") == "full_text"

            # Parent child count is unchanged (overflow stays in place)
            assert len(user_node.children) == children_before

            # Assistant node is still a sibling, not mixed into overflow children
            asst_children = [c for c in user_node.children
                             if c.data and c.data.get("type") == "assistant"]
            assert asst_children, "Assistant node should still be a sibling"

    @pytest.mark.asyncio
    async def test_overflow_collapse_restores_state(self, project_dir):
        """Collapsing an expanded overflow hides children reversibly."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess-ovexp-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            user_node = tree.root.children[0]

            def find_overflow(node):
                if node.data and node.data.get("type") == "overflow":
                    return node
                for child in node.children:
                    found = find_overflow(child)
                    if found:
                        return found
                return None

            overflow = find_overflow(user_node)
            assert overflow is not None
            overflow_count = len(overflow.children)

            # Expand then collapse
            overflow.expand()
            await pilot.pause()
            assert overflow.is_expanded

            overflow.collapse()
            await pilot.pause()
            assert not overflow.is_expanded

            # Children still exist (just hidden)
            assert len(overflow.children) == overflow_count


class TestThinkingBlockDisplay:
    """Thinking blocks should render as expandable 💭 nodes."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0005-0000-0000-0000-000000000005.jsonl").write_text(
            (FIXTURES / "with_thinking.jsonl").read_text()
        )
        return tmp_path

    @pytest.mark.asyncio
    async def test_thinking_block_shown_with_icon(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0005-0000-0000-0000-000000000005")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def find_thinking(node):
                if node.data and node.data.get("type") == "thinking":
                    return node
                for child in node.children:
                    found = find_thinking(child)
                    if found:
                        return found
                return None

            think = find_thinking(tree.root)
            assert think is not None, "No thinking node found"
            assert "💭" in str(think.label)
            assert think.children, "Thinking node should have children (the text)"


class TestAskUserQuestionDisplay:
    """AskUserQuestion tool calls should render with ❓ and inline answer."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0006-0000-0000-0000-000000000006.jsonl").write_text(
            (FIXTURES / "with_ask_user.jsonl").read_text()
        )
        return tmp_path

    @pytest.mark.asyncio
    async def test_auq_shows_question_icon(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0006-0000-0000-0000-000000000006")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def find_auq(node):
                if node.data and node.data.get("name") == "AskUserQuestion":
                    return node
                for child in node.children:
                    found = find_auq(child)
                    if found:
                        return found
                return None

            auq = find_auq(tree.root)
            assert auq is not None, "No AskUserQuestion node found"
            label = str(auq.label)
            assert "❓" in label, f"Missing ❓ icon in '{label}'"
            assert "database" in label.lower(), f"Missing question text in '{label}'"

    @pytest.mark.asyncio
    async def test_auq_shows_answer_inline(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0006-0000-0000-0000-000000000006")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            def find_auq(node):
                if node.data and node.data.get("name") == "AskUserQuestion":
                    return node
                for child in node.children:
                    found = find_auq(child)
                    if found:
                        return found
                return None

            auq = find_auq(tree.root)
            assert auq is not None
            label = str(auq.label)
            assert "PostgreSQL" in label, (
                f"Answer 'PostgreSQL' should be inline in '{label}'"
            )


class TestFoldLevels:
    """Fold level keybindings should control tree expansion depth."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        return tmp_path

    @pytest.mark.asyncio
    async def test_fold_level_1_collapses_to_spine(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()

            # Initially auto-expanded; press 1 to collapse
            await pilot.press("1")
            await pilot.pause()

            # Spine nodes (root children) should be collapsed
            for node in tree.root.children:
                if node.data and node.data.get("type") == "user" and node.children:
                    assert not node.is_expanded, (
                        f"Node '{str(node.label)[:30]}' should be collapsed after fold level 1"
                    )

    @pytest.mark.asyncio
    async def test_fold_level_2_expands_children(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()

            # Collapse first, then expand to level 2
            await pilot.press("1")
            await pilot.pause()
            await pilot.press("2")
            await pilot.pause()

            # Spine nodes should be expanded
            user_nodes = [
                n for n in tree.root.children
                if n.data and n.data.get("type") == "user" and n.children
            ]
            for node in user_nodes:
                assert node.is_expanded, (
                    f"Node '{str(node.label)[:30]}' should be expanded after fold level 2"
                )


# ── Unit tests: column alignment ─────────────────────────────────────────────

class TestColumnAlignment:
    """Context bars must be right-justified at the same X position across rows."""

    def test_bars_aligned_across_different_content_lengths(self):
        """Labels with different content lengths should have their context
        bars at the same visual position (right-aligned)."""
        from cctree.tui.app import _compose_annotated_label, _visual_len

        short = _compose_annotated_label(
            "User: hi", "", "▕██░░░▏3.2K", 100,
        )
        long = _compose_annotated_label(
            "User: this is a much longer message about something", "", "▕██░░░▏5.0K", 100,
        )
        # Both labels should have the same total visual width
        assert _visual_len(short) == _visual_len(long), (
            f"Short ({_visual_len(short)}) and long ({_visual_len(long)}) "
            f"labels should have the same visual width for column alignment"
        )

    def test_bar_position_is_rightmost(self):
        """The context bar should be the rightmost element in the label."""
        from cctree.tui.app import _compose_annotated_label

        label = _compose_annotated_label(
            "User: hello", "Read,Edit", "▕██░░░▏3.2K", 100,
        )
        # The bar characters should appear near the end of the label
        assert label.rstrip().endswith("3.2K")

    def test_multiple_rows_same_width(self):
        """Parametric: any content length produces the same total visual width."""
        from cctree.tui.app import _compose_annotated_label, _visual_len

        contents = [
            "User: a",
            "User: hello world this is a test",
            "User: x" * 10,
            "User: short",
        ]
        ctx = "▕██░░░▏3.2K"
        widths = []
        for c in contents:
            label = _compose_annotated_label(c, "", ctx, 100)
            widths.append(_visual_len(label))
        assert len(set(widths)) == 1, (
            f"All labels should have the same visual width, got {widths}"
        )

    def test_columns_do_not_exceed_total_width(self):
        """Label visual width should not exceed total_width."""
        from cctree.tui.app import _compose_annotated_label, _visual_len

        label = _compose_annotated_label(
            "User: a very very long message that goes on and on and on and on",
            "Read,Edit,Bash", "▕██░░░▏3.2K", 80,
            subagents_col="🤖3",
        )
        vis_len = _visual_len(label)
        assert vis_len <= 80, (
            f"Label visual width {vis_len} exceeds total_width 80"
        )

    def test_no_columns_when_width_too_narrow(self):
        """At width < 40, no columns should be shown."""
        from cctree.tui.app import _compose_annotated_label

        label = _compose_annotated_label(
            "User: hi", "Read", "▕██░░░▏3.2K", 35,
            subagents_col="🤖3",
        )
        assert "▕" not in label
        assert "Read" not in label


class TestProgressBarOverflow:
    """Progress bar right edge must not extend beyond the tree widget boundary.

    Tree nodes are indented by (depth * 4 + 4) characters. The annotated label
    width must account for this indent so the bar's right edge stays within
    the widget's column budget.
    """

    def test_label_width_subtracts_indent_depth_1(self):
        """Depth 1 (user nodes on spine): indent = 8, available = 72."""
        from cctree.tui.columns import _label_width_for_depth

        assert _label_width_for_depth(80, 1) == 72

    def test_label_width_subtracts_indent_depth_2(self):
        """Depth 2 (assistant nodes under user): indent = 12, available = 68."""
        from cctree.tui.columns import _label_width_for_depth

        assert _label_width_for_depth(80, 2) == 68

    def test_label_width_floor_at_1(self):
        """Extremely narrow or deep: clamp to 1, never go negative."""
        from cctree.tui.columns import _label_width_for_depth

        assert _label_width_for_depth(10, 5) == 1

    def test_label_with_bar_fits_at_depth_1(self):
        """User node label + indent must not exceed tree_width."""
        from cctree.tui.columns import (
            _compose_annotated_label,
            _label_width_for_depth,
            _visual_len,
        )

        tree_width = 80
        depth = 1
        indent = depth * 4 + 4
        available = _label_width_for_depth(tree_width, depth)

        label = _compose_annotated_label(
            "User: hello world testing overflow", "", "▕██░░░▏3.2K", available,
        )
        assert _visual_len(label) + indent <= tree_width, (
            f"Overflow: label({_visual_len(label)}) + indent({indent}) "
            f"= {_visual_len(label) + indent} > tree_width({tree_width})"
        )

    def test_label_with_bar_fits_at_depth_2(self):
        """Assistant node label + indent must not exceed tree_width."""
        from cctree.tui.columns import (
            _compose_annotated_label,
            _label_width_for_depth,
            _visual_len,
        )

        tree_width = 80
        depth = 2
        indent = depth * 4 + 4
        available = _label_width_for_depth(tree_width, depth)

        label = _compose_annotated_label(
            "[dim]Asst: some response text here[/dim]", "", "▕██░░░▏10.0K", available,
        )
        assert _visual_len(label) + indent <= tree_width, (
            f"Overflow: label({_visual_len(label)}) + indent({indent}) "
            f"= {_visual_len(label) + indent} > tree_width({tree_width})"
        )

    def test_all_columns_fit_at_depth_1(self):
        """All three columns enabled — still must not overflow."""
        from cctree.tui.columns import (
            _compose_annotated_label,
            _label_width_for_depth,
            _visual_len,
        )

        tree_width = 120
        depth = 1
        indent = depth * 4 + 4
        available = _label_width_for_depth(tree_width, depth)

        label = _compose_annotated_label(
            "User: a long message about something important",
            "Read,Edit,Bash", "▕██░░░▏3.2K", available,
            subagents_col="🤖3",
        )
        assert _visual_len(label) + indent <= tree_width, (
            f"Overflow: label({_visual_len(label)}) + indent({indent}) "
            f"= {_visual_len(label) + indent} > tree_width({tree_width})"
        )

    def test_parametric_depths_and_widths(self):
        """Sweep of realistic tree_width × depth combos — none may overflow."""
        from cctree.tui.columns import (
            _compose_annotated_label,
            _label_width_for_depth,
            _visual_len,
        )

        ctx_bar = "▕██░░░▏3.2K"
        for tree_width in (60, 80, 100, 120, 200):
            for depth in (1, 2, 3):
                indent = depth * 4 + 4
                available = _label_width_for_depth(tree_width, depth)
                label = _compose_annotated_label(
                    "User: some content", "", ctx_bar, available,
                )
                assert _visual_len(label) + indent <= tree_width, (
                    f"Overflow at tree_width={tree_width}, depth={depth}: "
                    f"label({_visual_len(label)}) + indent({indent}) "
                    f"= {_visual_len(label) + indent}"
                )


class TestForkFromTemplateExitsCleanly:
    """Pressing F on a template should exit the TUI cleanly instead of spawning a subprocess."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        old_time = time.time() - 300
        os.utime(tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_fork_exits_app_with_resume_session_id(self, project_dir, monkeypatch):
        """_fork_from_template should exit the TUI with a return value containing
        the new session ID, so the CLI can launch Claude after clean exit."""
        from cctree.tui.app import CctreeApp
        from cctree.core.forge import ForgeResult

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)

            app._browsing_template = {
                "name": "test-tpl",
                "sourceSessionId": "sess0001-0000-0000-0000-000000000001",
                "sourceMessageUuid": "some-uuid",
                "projectDirName": "test",
            }

            fake_result = ForgeResult(
                new_session_id="forked-0000-0000-0000-000000000001",
                dest_path=project_dir / "forked.jsonl",
                message_count=5,
            )
            import cctree.core.forge as forge_mod
            import cctree.core.metadata as meta_mod
            import cctree.core.templates as tpl_mod
            monkeypatch.setattr(forge_mod, "forge_session", lambda *a, **kw: fake_result)
            monkeypatch.setattr(meta_mod, "write_fork_metadata", lambda *a, **kw: None)
            monkeypatch.setattr(tpl_mod, "record_usage", lambda *a, **kw: None)

            app._fork_from_template()
            await pilot.pause()

        # After the context manager exits, check the return value
        assert app.return_value is not None
        assert app.return_value["resume_session_id"] == "forked-0000-0000-0000-000000000001"

    @pytest.mark.asyncio
    async def test_fork_does_not_spawn_subprocess(self, project_dir, monkeypatch):
        """_fork_from_template must NOT call subprocess.Popen — it should exit
        the TUI and let the CLI launch Claude."""
        import subprocess as subprocess_mod
        from cctree.tui.app import CctreeApp
        from cctree.core.forge import ForgeResult

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)

            app._browsing_template = {
                "name": "test-tpl",
                "sourceSessionId": "sess0001-0000-0000-0000-000000000001",
                "sourceMessageUuid": "some-uuid",
                "projectDirName": "test",
            }

            fake_result = ForgeResult(
                new_session_id="forked-0000-0000-0000-000000000001",
                dest_path=project_dir / "forked.jsonl",
                message_count=5,
            )
            import cctree.core.forge as forge_mod
            import cctree.core.metadata as meta_mod
            import cctree.core.templates as tpl_mod
            monkeypatch.setattr(forge_mod, "forge_session", lambda *a, **kw: fake_result)
            monkeypatch.setattr(meta_mod, "write_fork_metadata", lambda *a, **kw: None)
            monkeypatch.setattr(tpl_mod, "record_usage", lambda *a, **kw: None)

            popen_calls = []
            monkeypatch.setattr(subprocess_mod, "Popen", lambda *a, **kw: popen_calls.append(a))

            app._fork_from_template()
            await pilot.pause()

        assert len(popen_calls) == 0, \
            "subprocess.Popen should not be called — TUI should exit cleanly instead"


class TestBrowseTemplateSourceHeader:
    """Browsing a template source must not crash on header.renderable (AttributeError)."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        old_time = time.time() - 300
        os.utime(tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_browse_template_source_no_attribute_error(self, project_dir, monkeypatch):
        """_browse_template_source should not crash with AttributeError on header.renderable."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static
        import cctree.core.templates as tpl_mod

        tpl = {
            "name": "test-tpl",
            "sourceSessionId": "sess0001-0000-0000-0000-000000000001",
            "sourceMessageUuid": "some-uuid",
            "sourceDisplayName": "simple-session",
            "sourceSlug": "simple-session",
            "createdAt": "2026-04-01T00:00:00Z",
            "forkCount": 0,
            "projectDirName": "test",
        }
        monkeypatch.setattr(tpl_mod, "list_templates", lambda *a, **kw: [tpl])

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            # This should NOT raise AttributeError
            app._browse_template_source("test-tpl")
            await pilot.pause()

            header = app.query_one("#session-header", Static)
            # Header should contain the template browsing indicator
            header_text = str(header.render())
            assert "test-tpl" in header_text

    @pytest.mark.asyncio
    async def test_browse_template_source_appends_template_line(self, project_dir, monkeypatch):
        """The header should show both session info and the template browsing indicator."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Static
        import cctree.core.templates as tpl_mod

        tpl = {
            "name": "my-template",
            "sourceSessionId": "sess0001-0000-0000-0000-000000000001",
            "sourceMessageUuid": "some-uuid",
            "sourceDisplayName": "simple-session",
            "sourceSlug": "simple-session",
            "createdAt": "2026-04-01T00:00:00Z",
            "forkCount": 0,
            "projectDirName": "test",
        }
        monkeypatch.setattr(tpl_mod, "list_templates", lambda *a, **kw: [tpl])

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            app._browse_template_source("my-template")
            await pilot.pause()

            header = app.query_one("#session-header", Static)
            header_text = str(header.render())
            assert "Browsing from template" in header_text
            assert "my-template" in header_text


class TestCLILaunchesClaudeAfterForkExit:
    """The CLI entry point should launch Claude after the TUI exits with fork info."""

    def test_cli_execs_claude_on_fork_result(self, monkeypatch):
        """When app.run() returns a fork result, the CLI should exec into claude --resume."""
        import cctree.cli.main as cli_mod

        class MockApp:
            def __init__(self, **kw):
                pass
            def run(self):
                return {"resume_session_id": "forked-session-123"}

        monkeypatch.setattr("cctree.tui.app.CctreeApp", MockApp)

        exec_calls = []
        monkeypatch.setattr(os, "execvp", lambda *a: exec_calls.append(a))

        from click.testing import CliRunner
        from cctree.cli.main import cli
        runner = CliRunner()
        result = runner.invoke(cli, ["ui"])

        assert len(exec_calls) == 1
        assert exec_calls[0][0] == "claude"
        assert "--resume" in exec_calls[0][1]
        assert "forked-session-123" in exec_calls[0][1]

    def test_cli_no_exec_on_normal_exit(self, monkeypatch):
        """When app.run() returns None (normal quit), no exec should happen."""
        class MockApp:
            def __init__(self, **kw):
                pass
            def run(self):
                return None

        monkeypatch.setattr("cctree.tui.app.CctreeApp", MockApp)

        exec_calls = []
        monkeypatch.setattr(os, "execvp", lambda *a: exec_calls.append(a))

        from click.testing import CliRunner
        from cctree.cli.main import cli
        runner = CliRunner()
        result = runner.invoke(cli, ["ui"])

        assert len(exec_calls) == 0


# ── Copy session ID ──────────────────────────────────────────────────────────

class TestCopySessionId:
    """i copies the full session UUID to clipboard when sessions pane is focused."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
            ("titled_session.jsonl", "sess0003-0000-0000-0000-000000000003.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.fixture
    def clipboard(self, monkeypatch):
        copied = []
        import pyperclip
        monkeypatch.setattr(pyperclip, "copy", lambda text: copied.append(text))
        return copied

    @pytest.mark.asyncio
    async def test_i_copies_full_uuid_on_session(self, project_dir, clipboard):
        """Pressing i on a session item copies its full UUID."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            # Navigate to a real session item (past template section)
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            await pilot.press("i")
            await pilot.pause()

            assert len(clipboard) == 1
            assert clipboard[0].startswith("sess"), f"Expected full UUID, got: {clipboard[0]}"
            # Should be the full UUID, not truncated
            assert len(clipboard[0]) > 12

    @pytest.mark.asyncio
    async def test_i_not_available_on_template_or_divider(self, project_dir, clipboard):
        """i should not copy when cursor is on a template divider or hint."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            # First item is template divider — stay there
            await pilot.press("i")
            await pilot.pause()

            assert len(clipboard) == 0, "Should not copy on non-session item"

    @pytest.mark.asyncio
    async def test_i_not_available_when_tree_focused(self, project_dir, clipboard):
        """i should not copy session ID when detail pane has focus."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            # Navigate to a session
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            await pilot.press("right")  # focus detail pane
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)
            assert tree.has_focus

            await pilot.press("i")
            await pilot.pause()

            assert len(clipboard) == 0, "Should not copy session ID when tree is focused"


# ── OSC 52 clipboard fallback ────────────────────────────────────────────────

class TestOsc52ClipboardFallback:
    """OSC 52 clipboard fallback when pyperclip is unavailable (e.g. SSH)."""

    def test_osc52_copy_writes_correct_escape_sequence(self):
        """_osc52_copy writes the base64-encoded OSC 52 escape to the tty."""
        import base64
        from unittest import mock

        from cctree.tui.app import _osc52_copy

        written = bytearray()
        fake_fd = 99

        with mock.patch("os.ctermid", return_value="/dev/tty"), \
             mock.patch("os.open", return_value=fake_fd), \
             mock.patch("os.write", side_effect=lambda fd, data: written.extend(data)), \
             mock.patch("os.close") as mock_close:
            _osc52_copy("hello")

        expected_b64 = base64.b64encode(b"hello").decode()
        expected_seq = f"\x1b]52;c;{expected_b64}\x07".encode()
        assert bytes(written) == expected_seq
        mock_close.assert_called_once_with(fake_fd)

    def test_copy_to_clipboard_returns_pyperclip_when_available(self, monkeypatch):
        """Primary path: pyperclip succeeds, returns 'pyperclip'."""
        import pyperclip

        from cctree.tui.app import _copy_to_clipboard

        monkeypatch.setattr(pyperclip, "copy", lambda text: None)
        assert _copy_to_clipboard("test") == "pyperclip"

    def test_copy_to_clipboard_falls_back_to_osc52(self, monkeypatch):
        """When pyperclip raises, falls back to OSC 52 and returns 'osc52'."""
        from unittest import mock

        import pyperclip

        from cctree.tui.app import _copy_to_clipboard

        monkeypatch.setattr(pyperclip, "copy", mock.Mock(side_effect=Exception("no display")))

        with mock.patch("os.ctermid", return_value="/dev/tty"), \
             mock.patch("os.open", return_value=99), \
             mock.patch("os.write"), \
             mock.patch("os.close"):
            result = _copy_to_clipboard("test")

        assert result == "osc52"

    def test_copy_to_clipboard_raises_when_both_fail(self, monkeypatch):
        """When pyperclip AND OSC 52 both fail, the exception propagates."""
        from unittest import mock

        import pyperclip

        from cctree.tui.app import _copy_to_clipboard

        monkeypatch.setattr(pyperclip, "copy", mock.Mock(side_effect=Exception("no display")))

        with mock.patch("os.ctermid", side_effect=OSError("no tty")):
            with pytest.raises(OSError, match="no tty"):
                _copy_to_clipboard("test")

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_do_copy_shows_copied_for_pyperclip(self, project_dir, monkeypatch):
        """_do_copy flashes 'Copied:' when pyperclip succeeds."""
        import pyperclip

        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        monkeypatch.setattr(pyperclip, "copy", lambda text: None)

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause()

            app._do_copy("hello world")
            await pilot.pause()

            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            assert "Copied:" in rendered
            assert "terminal" not in rendered.lower()

    @pytest.mark.asyncio
    async def test_do_copy_shows_terminal_for_osc52(self, project_dir, monkeypatch):
        """_do_copy flashes 'Copied (terminal):' when falling back to OSC 52."""
        from unittest import mock

        import pyperclip

        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        monkeypatch.setattr(pyperclip, "copy", mock.Mock(side_effect=Exception("no display")))

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause()

            with mock.patch("os.ctermid", return_value="/dev/tty"), \
                 mock.patch("os.open", return_value=99), \
                 mock.patch("os.write"), \
                 mock.patch("os.close"):
                app._do_copy("hello world")
            await pilot.pause()

            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            assert "Copied (terminal):" in rendered

    @pytest.mark.asyncio
    async def test_do_copy_shows_error_when_both_fail(self, project_dir, monkeypatch):
        """_do_copy flashes actionable error when no clipboard backend works."""
        from unittest import mock

        import pyperclip

        from cctree.tui.app import CctreeApp
        from textual.widgets import Static

        monkeypatch.setattr(pyperclip, "copy", mock.Mock(side_effect=Exception("no display")))

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            await pilot.pause()

            with mock.patch("os.ctermid", side_effect=OSError("no tty")):
                app._do_copy("hello world")
            await pilot.pause()

            status = app.query_one("#status-bar", Static)
            rendered = str(status.render())
            assert "Copy failed" in rendered

    @pytest.mark.asyncio
    async def test_copy_fork_delegates_to_do_copy(self, project_dir):
        """action_copy_fork delegates to _do_copy instead of inline pyperclip."""
        from unittest import mock

        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()
            await pilot.press("down")
            await pilot.pause()

            with mock.patch.object(app, "_do_copy") as mock_do_copy:
                await pilot.press("f")
                await pilot.pause()

            assert mock_do_copy.called, "action_copy_fork should delegate to _do_copy"
            cmd = mock_do_copy.call_args[0][0]
            assert "cctree fork" in cmd


# ── Pane focus management ────────────────────────────────────────────────────

class TestNoAutoFocusOnLoad:
    """Focus stays in sessions pane when session is loaded via Enter or highlight."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
            ("titled_session.jsonl", "sess0003-0000-0000-0000-000000000003.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_enter_keeps_focus_in_sessions_pane(self, project_dir):
        """Pressing Enter on a session loads it but keeps focus in sessions pane."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            # Navigate to a real session
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            await pilot.press("enter")
            await pilot.pause()

            assert app.current_session is not None, "Session should be loaded"
            assert lv.has_focus, "Focus should stay in sessions pane after Enter"

    @pytest.mark.asyncio
    async def test_highlight_keeps_focus_in_sessions_pane(self, project_dir):
        """Auto-loading on highlight should not move focus out of sessions pane."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)

            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            assert lv.has_focus, "Focus should stay in sessions pane during highlight nav"


# ── Auto-load on highlight ───────────────────────────────────────────────────

class TestAutoLoadOnHighlight:
    """Highlighting a session auto-loads it; non-session items clear detail."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
            ("titled_session.jsonl", "sess0003-0000-0000-0000-000000000003.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_highlight_session_auto_loads(self, project_dir):
        """Navigating to a session auto-loads it without pressing Enter."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            tree = app.query_one("#session-tree", Tree)

            # Navigate to a real session item
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            assert app.current_session is not None, "Session should auto-load on highlight"
            assert len(tree.root.children) > 0, "Tree should have content"

    @pytest.mark.asyncio
    async def test_highlight_loads_spine_only(self, project_dir):
        """Auto-loaded session shows spine-only (all expandable nodes collapsed)."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            tree = app.query_one("#session-tree", Tree)

            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            # All expandable spine nodes should be collapsed
            for node in tree.root.children:
                if node.children:
                    assert not node.is_expanded, (
                        f"Spine node '{str(node.label)[:30]}' should be collapsed in spine-only mode"
                    )

    @pytest.mark.asyncio
    async def test_highlight_non_session_clears_detail(self, project_dir):
        """Moving cursor to a non-session item clears the detail pane."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree, Static

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            tree = app.query_one("#session-tree", Tree)

            # First navigate to a session to load it
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            assert app.current_session is not None

            # Now navigate back up to a template divider/hint
            for _ in range(10):
                await pilot.press("up")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and name.startswith("__"):
                        break

            # Detail pane should be cleared
            assert app.current_session is None, "current_session should be cleared on non-session highlight"
            assert len(tree.root.children) == 0, "Tree should be cleared"


# ── Spine expansion on focus switch ──────────────────────────────────────────

class TestSpineExpansionOnFocusSwitch:
    """Entering detail pane expands to spine+children; expansion preserved on return."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        old_time = time.time() - 300
        os.utime(tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_right_arrow_expands_to_spine_children(self, project_dir):
        """Right arrow into detail pane expands tree to spine+children."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            tree = app.query_one("#session-tree", Tree)

            # Navigate to a session (auto-loads in spine-only)
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            # Verify spine-only first
            for node in tree.root.children:
                if node.children:
                    assert not node.is_expanded

            # Right arrow to enter detail pane
            await pilot.press("right")
            await pilot.pause()

            # Spine nodes with children should now be expanded (spine+children)
            user_nodes = [
                n for n in tree.root.children
                if n.data and n.data.get("type") == "user" and n.children
            ]
            assert len(user_nodes) > 0, "Should have user nodes with children"
            for node in user_nodes:
                assert node.is_expanded, (
                    f"User node '{str(node.label)[:30]}' should be expanded after entering detail"
                )

    @pytest.mark.asyncio
    async def test_tab_expands_to_spine_children(self, project_dir):
        """Tab into detail pane also expands tree to spine+children."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            tree = app.query_one("#session-tree", Tree)

            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            # Tab to detail pane
            await pilot.press("tab")
            await pilot.pause()

            user_nodes = [
                n for n in tree.root.children
                if n.data and n.data.get("type") == "user" and n.children
            ]
            assert len(user_nodes) > 0
            for node in user_nodes:
                assert node.is_expanded, (
                    f"User node '{str(node.label)[:30]}' should be expanded after tab to detail"
                )

    @pytest.mark.asyncio
    async def test_return_to_sessions_keeps_expansion(self, project_dir):
        """Going back to sessions pane preserves tree expansion state."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView, Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            tree = app.query_one("#session-tree", Tree)

            # Navigate to session and enter detail pane
            for _ in range(10):
                await pilot.press("down")
                await pilot.pause()
                idx = lv.index if lv.index is not None else 0
                items = list(lv.children)
                if 0 <= idx < len(items):
                    name = getattr(items[idx], "name", "") or ""
                    if name and not name.startswith("__"):
                        break

            await pilot.press("right")
            await pilot.pause()
            assert tree.has_focus

            # Record which nodes are expanded
            expanded_before = {
                id(n) for n in tree.root.children if n.is_expanded
            }

            # Go back via tab
            await pilot.press("tab")
            await pilot.pause()
            assert lv.has_focus

            # Expansion state should be preserved
            expanded_after = {
                id(n) for n in tree.root.children if n.is_expanded
            }
            assert expanded_before == expanded_after, (
                "Tree expansion should be preserved when returning to sessions pane"
            )


# ── Session list wrap-around ─────────────────────────────────────────────────

class TestSessionListWrapAround:
    """Session list wraps in both directions."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
            ("titled_session.jsonl", "sess0003-0000-0000-0000-000000000003.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((FIXTURES / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_down_at_bottom_wraps_to_top(self, project_dir):
        """Pressing down at the last item wraps to the first item."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            item_count = len(lv.children)

            # Navigate to the very bottom (item_count downs from None → 0 → ... → last)
            for _ in range(item_count):
                await pilot.press("down")
                await pilot.pause()

            assert lv.index == item_count - 1, (
                f"Should be at last item (index {item_count - 1}), got {lv.index}"
            )

            # One more down should wrap to top
            await pilot.press("down")
            await pilot.pause()

            assert lv.index == 0, (
                f"Expected wrap to index 0, got {lv.index}"
            )

    @pytest.mark.asyncio
    async def test_up_at_top_wraps_to_bottom(self, project_dir):
        """Pressing up at the first item wraps to the last item."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            await app.workers.wait_for_complete()
            lv = app.query_one("#sessions-pane", ListView)
            item_count = len(lv.children)

            # Move to index 0 first (initial index is None)
            await pilot.press("down")
            await pilot.pause()
            assert lv.index == 0, f"Expected index 0 after first down, got {lv.index}"

            # Up from 0 should wrap to last item
            await pilot.press("up")
            await pilot.pause()

            assert lv.index == item_count - 1, (
                f"Expected wrap to index {item_count - 1}, got {lv.index}"
            )


class TestFlatToolRendering:
    """Tool_use nodes render as direct children of user turns (no Asst: wrapper)."""

    @pytest.fixture
    def _make_session(self, tmp_path):
        """Factory: create a session JSONL from a content blocks list."""
        import json

        def _factory(asst_content, user_text="do stuff"):
            session_id = "sess-flat-0000-0000-000000000001"
            lines = [
                json.dumps({
                    "type": "user", "uuid": "f-u1", "parentUuid": None,
                    "message": {"role": "user", "content": user_text},
                    "sessionId": session_id, "slug": "flat-test",
                    "timestamp": "2026-04-01T10:00:00Z",
                }),
                json.dumps({
                    "type": "assistant", "uuid": "f-a1",
                    "parentUuid": "f-u1",
                    "message": {"role": "assistant", "content": asst_content},
                    "sessionId": session_id, "slug": "flat-test",
                    "timestamp": "2026-04-01T10:00:05Z",
                }),
            ]
            (tmp_path / f"{session_id}.jsonl").write_text(
                "\n".join(lines) + "\n"
            )
            return tmp_path, session_id

        return _factory

    def _load(self, app, session_id):
        from textual.widgets import Tree
        session = app.store.get(session_id)
        app.load_session(session)
        return app.query_one("#session-tree", Tree)

    def _find_nodes(self, root, ntype):
        """Find all tree nodes with data["type"] == ntype."""
        found = []
        if root.data and root.data.get("type") == ntype:
            found.append(root)
        for child in root.children:
            found.extend(self._find_nodes(child, ntype))
        return found

    @pytest.mark.asyncio
    async def test_tool_is_direct_child_of_user(self, _make_session):
        """Tool_use blocks should be direct children of user turn, not nested under Asst:."""
        from cctree.tui.app import CctreeApp

        proj, sid = _make_session([
            {"type": "tool_use", "id": "t1", "name": "Read",
             "input": {"file_path": "/tmp/test.py"}},
            {"type": "tool_result", "tool_use_id": "t1",
             "content": "print('hello')"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            user_node = tree.root.children[0]
            assert user_node.data["type"] == "user"
            # Tool should be a direct child of user, not grandchild
            tool_nodes = [c for c in user_node.children
                          if c.data and c.data.get("type") == "tool_use"]
            assert len(tool_nodes) == 1, (
                f"Expected 1 tool_use direct child, found {len(tool_nodes)}. "
                f"Children types: {[c.data.get('type') for c in user_node.children if c.data]}"
            )

    @pytest.mark.asyncio
    async def test_single_line_result_inlined_on_label(self, _make_session):
        """Single-line tool results should appear on the tool_use label."""
        from cctree.tui.app import CctreeApp

        proj, sid = _make_session([
            {"type": "tool_use", "id": "t1", "name": "TaskCreate",
             "input": {"subject": "Say hi"}},
            {"type": "tool_result", "tool_use_id": "t1",
             "content": "Task #1 created successfully"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            tool_nodes = self._find_nodes(tree.root, "tool_use")
            assert len(tool_nodes) == 1
            label = str(tool_nodes[0].label)
            assert "→" in label, f"Expected inline result with →, got: {label}"
            assert "Task #1 created" in label

    @pytest.mark.asyncio
    async def test_multiline_result_as_child_overflow(self, _make_session):
        """Multi-line results: → on header label, content in child nodes."""
        from cctree.tui.app import CctreeApp

        proj, sid = _make_session([
            {"type": "tool_use", "id": "t1", "name": "Read",
             "input": {"file_path": "/tmp/test.py"}},
            {"type": "tool_result", "tool_use_id": "t1",
             "content": "line1\nline2\nline3"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            tool_nodes = self._find_nodes(tree.root, "tool_use")
            assert len(tool_nodes) == 1
            label = str(tool_nodes[0].label)
            assert "→" in label, f"Header should have → indicator: {label}"
            # Result content should be in child nodes (without → prefix)
            result_nodes = self._find_nodes(tool_nodes[0], "tool_result")
            assert len(result_nodes) >= 1

    @pytest.mark.asyncio
    async def test_no_result_shows_tool_name_only(self, _make_session):
        """Tool_use with no matching result just shows name + key arg."""
        from cctree.tui.app import CctreeApp

        proj, sid = _make_session([
            {"type": "tool_use", "id": "t1", "name": "Read",
             "input": {"file_path": "/tmp/test.py"}},
            # No tool_result — interrupted session
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            tool_nodes = self._find_nodes(tree.root, "tool_use")
            assert len(tool_nodes) == 1
            label = str(tool_nodes[0].label)
            assert "Read" in label
            assert "→" not in label

    @pytest.mark.asyncio
    async def test_empty_input_no_overflow(self, _make_session):
        """Tool_use with empty input should not have tool_input children."""
        from cctree.tui.app import CctreeApp

        proj, sid = _make_session([
            {"type": "tool_use", "id": "t1", "name": "TaskCreate",
             "input": {}},
            {"type": "tool_result", "tool_use_id": "t1",
             "content": "done"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            tool_nodes = self._find_nodes(tree.root, "tool_use")
            assert len(tool_nodes) == 1
            input_nodes = self._find_nodes(tool_nodes[0], "tool_input")
            assert len(input_nodes) == 0

    @pytest.mark.asyncio
    async def test_tool_only_message_no_asst_wrapper(self, _make_session):
        """Assistant message with only tools should not create an Asst: node."""
        from cctree.tui.app import CctreeApp

        proj, sid = _make_session([
            {"type": "tool_use", "id": "t1", "name": "Read",
             "input": {"file_path": "/tmp/a.py"}},
            {"type": "tool_result", "tool_use_id": "t1", "content": "ok"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            user_node = tree.root.children[0]
            asst_nodes = [c for c in user_node.children
                          if c.data and c.data.get("type") == "assistant"]
            assert len(asst_nodes) == 0, (
                f"Tool-only message should not have Asst: wrapper, "
                f"found {len(asst_nodes)}"
            )

    @pytest.mark.asyncio
    async def test_mixed_message_tools_and_text(self, _make_session):
        """Assistant message with tools + text: tools direct, text as Asst: node."""
        from cctree.tui.app import CctreeApp

        proj, sid = _make_session([
            {"type": "text", "text": "Here is the file:"},
            {"type": "tool_use", "id": "t1", "name": "Read",
             "input": {"file_path": "/tmp/a.py"}},
            {"type": "tool_result", "tool_use_id": "t1", "content": "ok"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            user_node = tree.root.children[0]
            child_types = [c.data.get("type") for c in user_node.children if c.data]
            assert "tool_use" in child_types, f"Expected tool_use child, got {child_types}"
            assert "assistant" in child_types, f"Expected assistant text node, got {child_types}"

    @pytest.mark.asyncio
    async def test_copy_flat_tool_no_duplication(self, _make_session):
        """Copy-all on flat tool tree should not duplicate content."""
        from cctree.tui.app import CctreeApp, _extract_subtree_text

        proj, sid = _make_session([
            {"type": "tool_use", "id": "t1", "name": "Read",
             "input": {"file_path": "/tmp/test.py"}},
            {"type": "tool_result", "tool_use_id": "t1",
             "content": "print('hello')"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            user_node = tree.root.children[0]
            text = _extract_subtree_text(user_node)
            # "print('hello')" should appear exactly once
            count = text.count("print('hello')")
            assert count == 1, (
                f"Result 'print(\\'hello\\')' appears {count} times in copy output "
                f"(expected 1). Full text:\n{text}"
            )

    @pytest.mark.asyncio
    async def test_copy_multiline_result_no_duplication(self, _make_session):
        """Multi-line tool result must appear exactly once in copy output.

        Bug: _add_wrapped_content creates N leaves sharing the same full_text
        (complete text). Copy extracts full_text from each → N copies.
        """
        from cctree.tui.app import CctreeApp, _extract_subtree_text

        proj, sid = _make_session([
            {"type": "tool_use", "id": "t1", "name": "TaskList", "input": {}},
            {"type": "tool_result", "tool_use_id": "t1",
             "content": "#1 [pending] Say hi (1)\n#3 [pending] Say hi (3)"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            user_node = tree.root.children[0]
            text = _extract_subtree_text(user_node)
            count = text.count("Say hi (1)")
            assert count == 1, (
                f"'Say hi (1)' appears {count} times (expected 1).\n"
                f"Full copy output:\n{text}"
            )

    @pytest.mark.asyncio
    async def test_copy_assistant_text_no_duplication(self, _make_session):
        """Assistant text must not be duplicated via wrapped content leaves."""
        from cctree.tui.app import CctreeApp, _extract_subtree_text

        proj, sid = _make_session([
            {"type": "text", "text": "Two tasks remaining:\n1. Task A\n2. Task B"},
        ])
        app = CctreeApp(project_dir=str(proj))
        async with app.run_test():
            tree = self._load(app, sid)
            user_node = tree.root.children[0]
            text = _extract_subtree_text(user_node)
            count = text.count("Two tasks remaining")
            assert count == 1, (
                f"'Two tasks remaining' appears {count} times (expected 1).\n"
                f"Full copy output:\n{text}"
            )
