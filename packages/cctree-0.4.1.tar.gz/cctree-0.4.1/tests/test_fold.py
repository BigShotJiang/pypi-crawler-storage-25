"""Regression tests for fold-level logic — must pass before and after extraction."""
from __future__ import annotations

from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


class TestFoldActions:
    """Integration tests for fold actions via TUI key presses."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        (tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl").write_text(
            (FIXTURES / "simple_session.jsonl").read_text()
        )
        return tmp_path

    @pytest.mark.asyncio
    async def test_fold_level_3_expands_all(self, project_dir):
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()

            # Collapse first, then expand all
            await pilot.press("1")
            await pilot.pause()
            await pilot.press("3")
            await pilot.pause()

            # Every node with children should be expanded
            def assert_all_expanded(node):
                if node.children:
                    assert node.is_expanded, (
                        f"Node '{str(node.label)[:30]}' should be expanded after fold level 3"
                    )
                    for child in node.children:
                        assert_all_expanded(child)

            assert_all_expanded(tree.root)

    @pytest.mark.asyncio
    async def test_expand_all_same_as_fold_3(self, project_dir):
        """action_expand_all delegates to action_fold_level_3."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()

            # Collapse, then use expand_all action
            await pilot.press("1")
            await pilot.pause()
            app.action_expand_all()
            await pilot.pause()

            def assert_all_expanded(node):
                if node.children:
                    assert node.is_expanded
                    for child in node.children:
                        assert_all_expanded(child)

            assert_all_expanded(tree.root)

    @pytest.mark.asyncio
    async def test_collapse_all_same_as_fold_1(self, project_dir):
        """action_collapse_all delegates to action_fold_level_1."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()

            app.action_collapse_all()
            await pilot.pause()

            for node in tree.root.children:
                if node.data and node.data.get("type") == "user" and node.children:
                    assert not node.is_expanded, (
                        f"Node '{str(node.label)[:30]}' should be collapsed after collapse_all"
                    )

    @pytest.mark.asyncio
    async def test_fold_roundtrip(self, project_dir):
        """Collapse then expand restores expanded state."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test() as pilot:
            session = app.store.get("sess0001-0000-0000-0000-000000000001")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)
            tree.focus()
            await pilot.pause()

            # Capture initial expansion state of spine nodes
            initial_expanded = {
                id(n): n.is_expanded
                for n in tree.root.children
                if n.data and n.data.get("type") == "user" and n.children
            }
            assert any(initial_expanded.values()), "Fixture should have expanded nodes"

            # Collapse all, then expand to level 2
            await pilot.press("1")
            await pilot.pause()
            await pilot.press("2")
            await pilot.pause()

            # Spine nodes that were expanded should be expanded again
            for node in tree.root.children:
                if id(node) in initial_expanded and initial_expanded[id(node)]:
                    assert node.is_expanded, (
                        f"Node '{str(node.label)[:30]}' should be re-expanded after roundtrip"
                    )


class TestSetFoldLevelUnit:
    """Unit tests for the extracted set_fold_level function."""

    class FakeNode:
        """Minimal TreeNode stand-in for unit testing fold logic."""

        def __init__(self, name: str = "root", children=None):
            self.name = name
            self.children = list(children or [])
            self.is_expanded = True

        def expand(self):
            self.is_expanded = True

        def collapse(self):
            self.is_expanded = False

    @staticmethod
    def _set_fold_level(node, target_depth, current_depth=0):
        from cctree.tui.fold import set_fold_level
        set_fold_level(node, target_depth, current_depth)

    def _build_tree(self):
        """Build a 3-level tree: root -> [A -> [A1, A2], B]."""
        a1 = self.FakeNode("A1")
        a2 = self.FakeNode("A2")
        a = self.FakeNode("A", [a1, a2])
        b = self.FakeNode("B")
        root = self.FakeNode("root", [a, b])
        return root, a, a1, a2, b

    def test_depth_0_collapses_root(self):
        root, a, a1, a2, b = self._build_tree()
        self._set_fold_level(root, target_depth=0)
        assert not root.is_expanded

    def test_depth_1_expands_root_collapses_children(self):
        root, a, a1, a2, b = self._build_tree()
        self._set_fold_level(root, target_depth=1)
        assert root.is_expanded
        assert not a.is_expanded
        assert not b.is_expanded

    def test_depth_2_expands_two_levels(self):
        root, a, a1, a2, b = self._build_tree()
        self._set_fold_level(root, target_depth=2)
        assert root.is_expanded
        assert a.is_expanded
        assert not a1.is_expanded
        assert not a2.is_expanded

    def test_depth_999_expands_everything(self):
        root, a, a1, a2, b = self._build_tree()
        # Collapse everything first
        for n in [root, a, a1, a2, b]:
            n.collapse()
        self._set_fold_level(root, target_depth=999)
        assert root.is_expanded
        assert a.is_expanded
        # Leaf nodes have no children so expand() won't be called,
        # but they should not be collapsed either (they stay collapsed
        # since they have no children to trigger expand)

    def test_collapsed_node_with_children_gets_expanded(self):
        root, a, a1, a2, b = self._build_tree()
        a.collapse()
        self._set_fold_level(root, target_depth=2)
        assert a.is_expanded

    def test_empty_tree(self):
        root = self.FakeNode("root")
        # Should not raise
        self._set_fold_level(root, target_depth=3)
        # Within target depth, childless node is untouched
        assert root.is_expanded
