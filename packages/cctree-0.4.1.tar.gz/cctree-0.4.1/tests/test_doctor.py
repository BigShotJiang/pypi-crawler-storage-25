"""Tests for cctree doctor — version compatibility gate."""
from __future__ import annotations

import pytest
from click.testing import CliRunner

from cctree.cli.main import cli


class TestDoctorVersionGate:
    """Test that doctor parses claude --version and warns on incompatible versions."""

    def test_doctor_runs_without_error(self):
        """Basic smoke test — doctor should not crash."""
        runner = CliRunner()
        result = runner.invoke(cli, ["doctor"])
        assert result.exit_code == 0

    def test_doctor_shows_version(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["doctor"])
        # Should show the Claude Code version somewhere in output
        assert "version" in result.output.lower() or "Version" in result.output

    def test_doctor_shows_session_count(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["doctor"])
        assert "sessions" in result.output.lower()

    def test_parse_claude_version(self):
        """Test the version parsing function directly."""
        from cctree.core.version import parse_claude_version

        assert parse_claude_version("2.1.77 (Claude Code)") == (2, 1, 77)
        assert parse_claude_version("2.1.100 (Claude Code)") == (2, 1, 100)
        assert parse_claude_version("3.0.0 (Claude Code)") == (3, 0, 0)

    def test_parse_claude_version_unexpected_format(self):
        from cctree.core.version import parse_claude_version

        # Should return None for unparseable versions, not crash
        assert parse_claude_version("something unexpected") is None
        assert parse_claude_version("") is None
        assert parse_claude_version("v2.1.77") is None  # wrong format

    def test_check_version_compat_exact_match(self):
        from cctree.core.version import check_version_compat

        result = check_version_compat((2, 1, 77))
        assert result.compatible is True
        assert result.warning is None

    def test_check_version_compat_too_old(self):
        from cctree.core.version import check_version_compat

        result = check_version_compat((1, 0, 0))
        assert result.compatible is False
        assert "minimum" in result.message.lower() or "below" in result.message.lower()

    def test_check_version_compat_unknown_future(self):
        """A version newer than tested should warn but not block."""
        from cctree.core.version import check_version_compat

        result = check_version_compat((2, 1, 78))
        assert result.compatible is True
        assert result.warning is not None

    def test_check_version_compat_far_future(self):
        from cctree.core.version import check_version_compat

        result = check_version_compat((99, 0, 0))
        assert result.compatible is True
        assert result.warning is not None
