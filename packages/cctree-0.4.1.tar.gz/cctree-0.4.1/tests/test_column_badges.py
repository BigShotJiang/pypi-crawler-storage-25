"""Tests for column badge features: icon+count tools, image badges,
image-source suppression, source-path-first image opening, and Tab column cycling."""
from __future__ import annotations

import re

import pytest

from cctree.core.model import ContentBlock, Message, SessionEvent


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_user_evt(text: str, *, uuid: str = "u1") -> SessionEvent:
    """Create a user-typed event with text content."""
    return SessionEvent(
        type="user",
        uuid=uuid,
        message=Message(
            role="user",
            content=[ContentBlock(type="text", text=text)],
        ),
    )


def _make_image_source_evt(*paths: str, uuid: str = "u-img") -> SessionEvent:
    """Create a user event with [Image: source: /path] text blocks."""
    blocks = [
        ContentBlock(type="text", text=f"[Image: source: {p}]")
        for p in paths
    ]
    return SessionEvent(
        type="user",
        uuid=uuid,
        message=Message(role="user", content=blocks),
    )


def _make_image_evt(
    text: str,
    n_images: int = 1,
    *,
    uuid: str = "u-with-img",
) -> SessionEvent:
    """Create a user event with text + N image blocks."""
    blocks = [ContentBlock(type="text", text=text)]
    for i in range(n_images):
        blocks.append(ContentBlock(
            type="image",
            source={"type": "base64", "media_type": "image/png", "data": f"fake{i}"},
        ))
    return SessionEvent(
        type="user",
        uuid=uuid,
        message=Message(role="user", content=blocks),
    )


# ── _format_tool_count ───────────────────────────────────────────────────────

# ── _format_badge (shared helper) ────────────────────────────────────────────

class TestFormatBadge:
    def test_zero_returns_empty(self):
        from cctree.tui.columns import _format_badge
        assert _format_badge("📷", 0) == ""

    def test_single(self):
        from cctree.tui.columns import _format_badge
        assert _format_badge("📷", 1) == "📷1"

    def test_multi_digit(self):
        from cctree.tui.columns import _format_badge
        assert _format_badge("📋", 18) == "📋18"

    def test_different_icons(self):
        from cctree.tui.columns import _format_badge
        assert _format_badge("🔧", 5) == "🔧5"
        assert _format_badge("🤖", 3) == "🤖3"
        assert _format_badge("❓", 2) == "❓2"

    def test_existing_formatters_delegate_to_badge(self):
        """_format_image_col and _format_tool_count should use _format_badge."""
        from cctree.tui.columns import _format_badge, _format_image_col, _format_tool_count
        assert _format_image_col(3) == _format_badge("📷", 3)
        assert _format_tool_count(["a", "b"]) == _format_badge("🔧", 2)


# ── Decomposed agent columns ────────────────────────────────────────────────

class TestDecomposedAgentColumns:
    """📋, 🤖, ❓ must be separate columns, not one monolithic agents column."""

    def test_tasks_col_in_compose(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "", 100,
            tasks_col="📋18",
        )
        assert "📋18" in label

    def test_subagents_col_in_compose(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "", 100,
            subagents_col="🤖3",
        )
        assert "🤖3" in label

    def test_questions_col_in_compose(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "", 100,
            questions_col="❓2",
        )
        assert "❓2" in label

    def test_all_three_in_order(self):
        """📋 before 🤖 before ❓ in the label."""
        from cctree.tui.columns import _compose_annotated_label
        import re as _re
        label = _compose_annotated_label(
            "User: hi", "", "", 120,
            tasks_col="📋5", subagents_col="🤖2", questions_col="❓1",
        )
        stripped = _re.sub(r"\[/?[^\]]*\]", "", label)
        t = stripped.index("📋")
        s = stripped.index("🤖")
        q = stripped.index("❓")
        assert t < s < q, f"Order wrong: 📋={t} 🤖={s} ❓={q}"

    def test_each_column_fixed_width(self):
        """Rows with different counts must have the same column width."""
        from cctree.tui.columns import _compose_annotated_label, _visual_len
        import re as _re
        label_a = _compose_annotated_label(
            "User: hi", "", "", 100,
            tasks_col="📋1",
        )
        label_b = _compose_annotated_label(
            "User: hi", "", "", 100,
            tasks_col="📋18",
        )
        assert _visual_len(label_a) == _visual_len(label_b)

    def test_tasks_aligned_with_and_without_subagents(self):
        """📋 must be at the same CELL position whether 🤖 is present or not."""
        from cctree.tui.columns import _compose_annotated_label, _visual_len
        import re as _re

        def _cell_pos(s: str, target: str) -> int:
            """Cell position of target in string (not codepoint position)."""
            idx = s.index(target)
            return _visual_len(s[:idx])

        with_sub = _compose_annotated_label(
            "User: hi", "", "", 120,
            tasks_col="📋18", subagents_col="🤖3", questions_col="❓2",
        )
        without_sub = _compose_annotated_label(
            "User: hi", "", "", 120,
            tasks_col="📋1", questions_col="❓2",
        )
        s1 = _re.sub(r"\[/?[^\]]*\]", "", with_sub)
        s2 = _re.sub(r"\[/?[^\]]*\]", "", without_sub)
        assert _cell_pos(s1, "📋") == _cell_pos(s2, "📋"), (
            f"📋 cell pos shifted: {_cell_pos(s1, '📋')} vs {_cell_pos(s2, '📋')}"
        )
        assert _cell_pos(s1, "❓") == _cell_pos(s2, "❓"), (
            f"❓ cell pos shifted: {_cell_pos(s1, '❓')} vs {_cell_pos(s2, '❓')}"
        )

    def test_columns_same_position_regardless_of_content_length(self):
        """Short and long content must produce columns at the exact same cell position."""
        from cctree.tui.columns import _compose_annotated_label, _visual_len
        import re as _re

        def _cell_pos(s, target):
            return _visual_len(s[:s.index(target)])

        short = _compose_annotated_label(
            "User: hi", "", "", 120,
            tasks_col="📋18", questions_col="❓2",
        )
        long = _compose_annotated_label(
            "User: a very long message about impoverished conditions in the world today",
            "", "", 120,
            tasks_col="📋18", questions_col="❓2",
        )
        ss = _re.sub(r"\[/?[^\]]*\]", "", short)
        sl = _re.sub(r"\[/?[^\]]*\]", "", long)
        assert _cell_pos(ss, "📋") == _cell_pos(sl, "📋"), (
            f"📋 shifted with content length: {_cell_pos(ss, '📋')} vs {_cell_pos(sl, '📋')}"
        )
        assert _visual_len(short) == _visual_len(long), (
            f"Total width differs: {_visual_len(short)} vs {_visual_len(long)}"
        )

    def test_no_agents_col_param(self):
        """The old agents_col positional parameter must be removed."""
        import inspect
        from cctree.tui.columns import _compose_annotated_label
        sig = inspect.signature(_compose_annotated_label)
        param_names = list(sig.parameters.keys())
        assert "agents_col" not in param_names, (
            "agents_col should be removed — replaced by tasks_col/subagents_col/questions_col"
        )


class TestFormatToolCount:
    def test_empty(self):
        from cctree.tui.columns import _format_tool_count
        assert _format_tool_count([]) == ""

    def test_single_tool(self):
        from cctree.tui.columns import _format_tool_count
        assert _format_tool_count(["Read"]) == "🔧1"

    def test_multiple_tools(self):
        from cctree.tui.columns import _format_tool_count
        result = _format_tool_count(["Read", "Edit", "Bash", "Grep", "Write", "Agent"])
        assert result == "🔧6"

    def test_returns_icon_count_not_names(self):
        """Must NOT return comma-separated names — only icon+count."""
        from cctree.tui.columns import _format_tool_count
        result = _format_tool_count(["Read", "Edit"])
        assert "Read" not in result
        assert "Edit" not in result
        assert result == "🔧2"


# ── _format_tool_summary (unchanged, for backward compat) ───────────────────

class TestFormatToolSummaryUnchanged:
    def test_still_returns_comma_names(self):
        """The original summary function must still work for assistant labels."""
        from cctree.tui.columns import _format_tool_summary
        assert _format_tool_summary(["Read", "Edit"]) == "Read,Edit"

    def test_overflow(self):
        from cctree.tui.columns import _format_tool_summary
        result = _format_tool_summary(["Read", "Edit", "Bash", "Grep", "Write"])
        assert "+3" in result


# ── _format_image_col ────────────────────────────────────────────────────────

class TestFormatImageCol:
    def test_zero(self):
        from cctree.tui.columns import _format_image_col
        assert _format_image_col(0) == ""

    def test_single(self):
        from cctree.tui.columns import _format_image_col
        assert _format_image_col(1) == "📷1"

    def test_multiple(self):
        from cctree.tui.columns import _format_image_col
        assert _format_image_col(5) == "📷5"


# ── _compose_annotated_label with image_col ──────────────────────────────────

class TestAnnotatedLabelImageCol:
    def test_image_col_appears_before_tool(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "🔧3", "", 100,
            image_col="📷2",
        )
        img_pos = label.index("📷")
        tool_pos = label.index("🔧")
        assert img_pos < tool_pos, "Image column must appear before tool column"

    def test_image_col_empty_string_no_column(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "", 100,
            image_col="",
        )
        assert "📷" not in label

    def test_positional_args_without_agents_col(self):
        """New signature: (content, tool_summary, ctx_bar, total_width)."""
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hi", "", "▕██░░░▏3.2K", 100,
        )
        assert "3.2K" in label


# ── _compose_annotated_label with highlight_col ──────────────────────────────

class TestAnnotatedLabelHighlight:
    def test_highlight_tool_adds_reverse(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "🔧3", "", 100,
            image_col="📷2",
            highlight_col="tool",
        )
        assert "[reverse]" in label

    def test_highlight_image_adds_reverse(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "", 100,
            image_col="📷2",
            highlight_col="image",
        )
        assert "[reverse]" in label

    def test_no_highlight_no_reverse(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "🔧3", "", 100,
            image_col="📷2",
        )
        assert "[reverse]" not in label

    def test_highlight_tasks_column(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "", 100,
            tasks_col="📋2",
            highlight_col="task",
        )
        assert "[reverse]" in label

    def test_highlight_subagents_column(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "", 100,
            subagents_col="🤖3",
            highlight_col="subagent",
        )
        assert "[reverse]" in label

    def test_highlight_questions_column(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "", 100,
            questions_col="❓1",
            highlight_col="question",
        )
        assert "[reverse]" in label

    def test_highlight_context(self):
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hello", "", "▕██░░░▏3.2K", 100,
            highlight_col="context",
        )
        assert "[reverse]" in label


# ── _is_image_source_only ────────────────────────────────────────────────────

class TestIsImageSourceOnly:
    def test_single_image_source(self):
        from cctree.tui.app import _is_image_source_only
        evt = _make_user_evt("[Image: source: /tmp/screenshot.png]")
        assert _is_image_source_only(evt) is True

    def test_multiple_image_sources(self):
        from cctree.tui.app import _is_image_source_only
        evt = _make_image_source_evt(
            "/tmp/a.png", "/tmp/b.png", "/tmp/c.png",
        )
        assert _is_image_source_only(evt) is True

    def test_normal_text_is_not(self):
        from cctree.tui.app import _is_image_source_only
        evt = _make_user_evt("fix the bug please")
        assert _is_image_source_only(evt) is False

    def test_mixed_text_and_image_source_is_not(self):
        from cctree.tui.app import _is_image_source_only
        evt = _make_user_evt(
            "look at this\n[Image: source: /tmp/a.png]"
        )
        assert _is_image_source_only(evt) is False

    def test_empty_text_is_not(self):
        from cctree.tui.app import _is_image_source_only
        evt = SessionEvent(
            type="user", uuid="u1",
            message=Message(role="user", content=[ContentBlock(type="text", text="")]),
        )
        assert _is_image_source_only(evt) is False

    def test_no_message_is_not(self):
        from cctree.tui.app import _is_image_source_only
        evt = SessionEvent(type="user", uuid="u1", message=None)
        assert _is_image_source_only(evt) is False


# ── _extract_image_source_paths ──────────────────────────────────────────────

class TestExtractImageSourcePaths:
    def test_single_path(self):
        from cctree.tui.app import _extract_image_source_paths
        evt = _make_user_evt("[Image: source: /tmp/screenshot.png]")
        assert _extract_image_source_paths(evt) == ["/tmp/screenshot.png"]

    def test_multiple_paths(self):
        from cctree.tui.app import _extract_image_source_paths
        evt = _make_image_source_evt(
            "/tmp/a.png", "/var/folders/b.png",
        )
        paths = _extract_image_source_paths(evt)
        assert paths == ["/tmp/a.png", "/var/folders/b.png"]

    def test_path_with_spaces(self):
        from cctree.tui.app import _extract_image_source_paths
        evt = _make_user_evt(
            "[Image: source: /tmp/Screenshot 2026-04-17 at 11.52.11 AM.png]"
        )
        paths = _extract_image_source_paths(evt)
        assert len(paths) == 1
        assert "Screenshot 2026-04-17" in paths[0]

    def test_no_image_sources(self):
        from cctree.tui.app import _extract_image_source_paths
        evt = _make_user_evt("just regular text")
        assert _extract_image_source_paths(evt) == []


# ── Tool budget reduction ────────────────────────────────────────────────────

class TestColumnBudgets:
    def test_tool_budget_reduced(self):
        from cctree.tui.columns import _TOOL_COL_BUDGET
        assert _TOOL_COL_BUDGET <= 8, "Tool budget should be small for icon+count"

    def test_image_budget_exists(self):
        from cctree.tui.columns import _IMAGE_COL_BUDGET
        assert _IMAGE_COL_BUDGET >= 4, "Image budget must fit icon + digits"


# ── Column ordering in annotated labels ──────────────────────────────────────

# ── Keybinding: Enter opens image, o removed ─────────────────────────────────

class TestImageOpenBindings:
    def test_o_binding_removed(self):
        """The 'o' key should no longer be bound to open_image."""
        from cctree.tui.app import CctreeApp
        binding_keys = [b.key for b in CctreeApp.BINDINGS]
        assert "o" not in binding_keys, "'o' binding should be removed"

    def test_enter_handled_in_on_key_for_images(self):
        """Enter on image nodes must be handled in on_key (not a binding),
        because the Tree widget's built-in Enter binding consumes the key
        before App-level bindings fire."""
        import inspect
        from cctree.tui.app import CctreeApp
        source = inspect.getsource(CctreeApp.on_key)
        # on_key should check for enter + image type and open the image
        assert '"enter"' in source, "on_key must handle enter key"
        assert '"image"' in source, "on_key must check for image node type"
        assert "_open_image_node" in source, "on_key must call _open_image_node"


class TestImageColumnAction:
    def test_image_column_jumps_not_opens(self):
        """Enter on image column badge should jump to first image child,
        not open all images (consistent with tool/subagent columns)."""
        import inspect
        from cctree.tui.app import CctreeApp
        source = inspect.getsource(CctreeApp._execute_column_action)
        # The image branch should NOT call _open_turn_images
        assert "_open_turn_images" not in source, (
            "Image column action should not open all images"
        )


class TestDoubleClickImage:
    def test_on_click_allows_tree_double_click(self):
        """on_click should not prevent double-clicks on the tree widget."""
        # This is a structural test — verifying that on_click handles
        # double-clicks specially rather than preventing all clicks.
        import inspect
        from cctree.tui.app import CctreeApp
        source = inspect.getsource(CctreeApp.on_click)
        # The handler should check for double-click (chain >= 2)
        assert "chain" in source or "double" in source, (
            "on_click should handle double-click detection"
        )


# ── _strip_markup ─────────────────────────────────────────────────────────────

class TestStripMarkup:
    """_strip_markup must handle Rich \\[ escape sequences correctly."""

    def test_strips_normal_tags(self):
        from cctree.tui.columns import _strip_markup
        assert _strip_markup("[bold]hello[/bold]") == "hello"

    def test_preserves_escaped_open_bracket(self):
        from cctree.tui.columns import _strip_markup
        # Rich's escape() turns [ into \[  — must NOT be stripped as a tag
        assert _strip_markup("hello \\[world]") == "hello [world]"

    def test_mixed_markup_and_escaped_brackets(self):
        from cctree.tui.columns import _strip_markup
        # [dim] is a real tag, \[ is an escaped bracket
        assert _strip_markup("[dim]hello \\[world][/dim]") == "hello [world]"

    def test_plain_text_unchanged(self):
        from cctree.tui.columns import _strip_markup
        assert _strip_markup("plain text") == "plain text"

    def test_multiple_escaped_brackets(self):
        from cctree.tui.columns import _strip_markup
        assert _strip_markup("\\[a] and \\[b]") == "[a] and [b]"


# ── _visual_len escaped brackets ─────────────────────────────────────────────

class TestVisualLenEscapedBrackets:
    """_visual_len must correctly measure content with escaped brackets."""

    def test_escaped_bracket_not_stripped_as_tag(self):
        from cctree.tui.columns import _visual_len
        from rich.markup import escape
        # "hello [world]" is 13 visible chars
        escaped = escape("hello [world]")  # → "hello \[world]"
        assert _visual_len(escaped) == 13

    def test_escaped_in_markup_wrapper(self):
        from cctree.tui.columns import _visual_len
        from rich.markup import escape
        text = f"[dim]{escape('test [x]')}[/dim]"
        assert _visual_len(text) == 8  # "test [x]" = 8 chars

    def test_bracket_content_width_invariant(self):
        """Content with brackets must maintain width invariant after truncation."""
        from cctree.tui.columns import _compose_annotated_label, _visual_len
        label = _compose_annotated_label(
            "User: check [prod] and [staging] configs " + "x" * 100,
            "🔧3", "", 80,
            tasks_col="📋1",
        )
        assert _visual_len(label) == 80


# ── _visual_len emoji double-width ────────────────────────────────────────────

class TestVisualLenDoubleWidth:
    """_visual_len must count double-width chars (emojis) as 2 columns."""

    def test_plain_ascii(self):
        from cctree.tui.columns import _visual_len
        assert _visual_len("hello") == 5

    def test_single_emoji(self):
        from cctree.tui.columns import _visual_len
        # 🔧 is a double-width character → 2 terminal columns
        assert _visual_len("🔧") == 2

    def test_emoji_plus_digit(self):
        from cctree.tui.columns import _visual_len
        # 🔧 (2) + "6" (1) = 3
        assert _visual_len("🔧6") == 3

    def test_multiple_emojis(self):
        from cctree.tui.columns import _visual_len
        # 📋 (2) + "18" (2) + " " (1) + ❓ (2) = 7
        assert _visual_len("📋18 ❓") == 7

    def test_emoji_with_markup(self):
        from cctree.tui.columns import _visual_len
        # [dim]🔧6[/dim] → strip markup → 🔧6 → 3
        assert _visual_len("[dim]🔧6[/dim]") == 3

    def test_camera_emoji(self):
        from cctree.tui.columns import _visual_len
        assert _visual_len("📷3") == 3


class TestFitToBudget:
    """_fit_to_budget must enforce budget as a hard width limit."""

    def test_short_content_padded(self):
        from cctree.tui.columns import _fit_to_budget, _visual_len
        result = _fit_to_budget("🔧6", 6)
        assert _visual_len(result) == 6

    def test_overflow_truncated(self):
        from cctree.tui.columns import _fit_to_budget, _visual_len
        # 📋18 🤖sub1 = 11 cells, budget 8 → must be truncated to 8
        result = _fit_to_budget("📋18 🤖sub1", 8)
        assert _visual_len(result) == 8

    def test_overflow_has_ellipsis(self):
        from cctree.tui.columns import _fit_to_budget
        result = _fit_to_budget("📋18 🤖sub1 +2 ❓", 10)
        assert "…" in result

    def test_exact_fit_no_truncation(self):
        from cctree.tui.columns import _fit_to_budget, _visual_len
        text = "📋18 ❓"  # 7 cells
        result = _fit_to_budget(text, 7)
        assert "…" not in result
        assert _visual_len(result) == 7

    def test_all_overflows_same_width(self):
        """Different overflowing content, same budget → same visual width."""
        from cctree.tui.columns import _fit_to_budget, _visual_len
        budget = 10
        cases = [
            "📋18 🤖sub1",        # 11 cells
            "📋18 🤖sub1 +2 ❓",  # 17 cells
            "📋2 🤖longname ❓",   # lots
        ]
        widths = [_visual_len(_fit_to_budget(c, budget)) for c in cases]
        assert all(w == budget for w in widths), f"Expected all {budget}, got {widths}"

    def test_different_content_same_budget_aligned(self):
        """Short and long content with same budget → same visual width."""
        from cctree.tui.columns import _fit_to_budget, _visual_len
        budget = 10
        short = _fit_to_budget("❓", budget)
        long = _fit_to_budget("📋18 🤖sub1 +2 ❓", budget)
        assert _visual_len(short) == _visual_len(long) == budget


class TestPadToBudgetWithEmojis:
    """_pad_to_budget must produce consistent visual widths with emojis."""

    def test_emoji_content_pads_correctly(self):
        from cctree.tui.columns import _pad_to_budget, _visual_len
        # 🔧6 is 3 visual columns, budget 6 → 3 spaces padding → 6 visual total
        result = _pad_to_budget("🔧6", 6)
        assert _visual_len(result) == 6

    def test_different_emoji_content_same_budget(self):
        """Two strings with emojis padded to same budget → same visual width."""
        from cctree.tui.columns import _pad_to_budget, _visual_len
        a = _pad_to_budget("📋18 ❓", 8)
        b = _pad_to_budget("📋1", 8)
        assert _visual_len(a) == _visual_len(b) == 8

    def test_agents_with_and_without_question(self):
        """Agents column with/without ❓ must have same visual width."""
        from cctree.tui.columns import _pad_to_budget, _visual_len
        with_q = _pad_to_budget("📋18 ❓", 10)
        without_q = _pad_to_budget("📋18", 10)
        assert _visual_len(with_q) == _visual_len(without_q) == 10


class TestColumnOrdering:
    def test_order_all_columns(self):
        """Columns must appear in order: 📷 🔧 📋 🤖 ❓ ████."""
        from cctree.tui.columns import _compose_annotated_label
        label = _compose_annotated_label(
            "User: hi", "🔧3", "▕██░▏1K", 150,
            image_col="📷2", tasks_col="📋5",
            subagents_col="🤖2", questions_col="❓1",
        )
        stripped = re.sub(r"\[/?[^\]]*\]", "", label)
        positions = {
            "📷": stripped.index("📷"),
            "🔧": stripped.index("🔧"),
            "📋": stripped.index("📋"),
            "🤖": stripped.index("🤖"),
            "❓": stripped.index("❓"),
            "▕": stripped.index("▕"),
        }
        order = sorted(positions, key=positions.get)
        assert order == ["📷", "🔧", "📋", "🤖", "❓", "▕"], (
            f"Column order violated: {order} (positions: {positions})"
        )


class TestAnnotatedLabelWidthInvariant:
    """_visual_len(output) must equal total_width when columns are present."""

    def test_output_width_equals_total_width(self):
        """Every label with columns must be exactly total_width wide."""
        from cctree.tui.columns import _compose_annotated_label, _visual_len
        cases = [
            ("User: hi", "🔧3", "", 100, {"tasks_col": "📋1"}),
            ("User: " + "x" * 200, "🔧3", "", 100, {"tasks_col": "📋1"}),
            ("User: hi", "🔧6", "", 80, {"image_col": "📷3"}),
            ("User: hi", "", "▕██░▏1K", 80, {}),
            ("User: " + "x" * 200, "🔧6", "", 80,
             {"image_col": "📷3", "tasks_col": "📋1", "subagents_col": "🤖2"}),
        ]
        for content, tool, ctx, width, kwargs in cases:
            label = _compose_annotated_label(content, tool, ctx, width, **kwargs)
            vis = _visual_len(label)
            assert vis == width, (
                f"Expected width {width}, got {vis} "
                f"for content={content!r:.40}"
            )

    def test_truncated_and_short_same_total_width(self):
        """Truncated content must produce the same total width as short content."""
        from cctree.tui.columns import _compose_annotated_label, _visual_len
        short = _compose_annotated_label(
            "User: hi", "🔧3", "", 80,
            tasks_col="📋1",
        )
        long = _compose_annotated_label(
            "User: " + "x" * 200, "🔧3", "", 80,
            tasks_col="📋1",
        )
        assert _visual_len(short) == _visual_len(long), (
            f"Width mismatch: short={_visual_len(short)} vs long={_visual_len(long)}"
        )
