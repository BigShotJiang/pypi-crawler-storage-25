"""Tests for per-turn active agent tracking."""
from __future__ import annotations

from cctree.core.active_agents import (
    ActiveAgentsSnapshot,
    build_active_agents_map,
    format_agents_status_line,
)
from cctree.tui.columns import _format_badge
from cctree.core.model import SessionEvent


def _asst(uuid: str, tools: list[dict] | None = None) -> SessionEvent:
    content = tools if tools else "ok"
    return SessionEvent.model_validate({
        "type": "assistant",
        "uuid": uuid,
        "message": {"role": "assistant", "content": content},
    })


def _user(uuid: str, content: str = "hi") -> SessionEvent:
    return SessionEvent.model_validate({
        "type": "user",
        "uuid": uuid,
        "message": {"role": "user", "content": content},
    })


def _tool_use(tool_id: str, name: str, inp: dict | None = None) -> dict:
    return {"type": "tool_use", "id": tool_id, "name": name, "input": inp or {}}


def _tool_result(tool_use_id: str, content: str = "ok") -> dict:
    return {"type": "tool_result", "tool_use_id": tool_use_id, "content": content}


class TestActiveAgentsSnapshot:
    def test_empty_snapshot(self):
        snap = ActiveAgentsSnapshot()
        assert snap.is_empty

    def test_non_empty_with_subagents(self):
        snap = ActiveAgentsSnapshot(subagents=["sub1"])
        assert not snap.is_empty

    def test_non_empty_with_teammates(self):
        snap = ActiveAgentsSnapshot(teammates=["alice"])
        assert not snap.is_empty

    def test_non_empty_with_tasks(self):
        snap = ActiveAgentsSnapshot(tasks=["task1"])
        assert not snap.is_empty


class TestBuildActiveAgentsMap:
    def test_empty_events(self):
        assert build_active_agents_map([]) == {}

    def test_no_agent_calls(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "Read", {"file_path": "main.py"}),
                _tool_result("t1"),
            ]),
        ]
        result = build_active_agents_map(events)
        # No Agent calls → no snapshots (Read is not tracked)
        assert "a1" not in result or result["a1"].is_empty

    def test_agent_span_open_and_close(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "Agent", {"description": "fix tests"}),
            ]),
            _user("u2"),  # Agent is active during this turn
            _asst("a2", [
                _tool_result("t1"),
            ]),
        ]
        result = build_active_agents_map(events)
        # a1 opens the span → a1 has an active agent
        assert "a1" in result
        assert len(result["a1"].subagents) == 1
        assert "fix tests" in result["a1"].subagents[0]
        # u2 also sees the agent as active (content is string, open_agents non-empty)
        assert "u2" in result
        assert len(result["u2"].subagents) == 1
        # a2 closes the span → a2 has no active agents
        assert "a2" not in result or result["a2"].is_empty

    def test_open_span_stays_active_through_end(self):
        """Interrupted session: Agent tool_use with no matching tool_result."""
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "Agent", {"description": "build feature"}),
            ]),
            _user("u2"),
            _asst("a2", [{"type": "text", "text": "Working on it..."}]),
        ]
        result = build_active_agents_map(events)
        # Agent stays active through the end
        assert "a2" in result
        assert len(result["a2"].subagents) == 1
        assert "build feature" in result["a2"].subagents[0]

    def test_overlapping_agents(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "Agent", {"description": "sub1"}),
                _tool_use("t2", "Agent", {"description": "sub2"}),
            ]),
            _user("u2"),
            _asst("a2", [
                _tool_result("t1"),  # close sub1
            ]),
        ]
        result = build_active_agents_map(events)
        # a1 has 2 active agents
        assert len(result["a1"].subagents) == 2
        # u2 still has 2
        assert len(result["u2"].subagents) == 2
        # a2 closed sub1, only sub2 remains
        assert "a2" in result
        assert len(result["a2"].subagents) == 1
        assert "sub2" in result["a2"].subagents[0]

    def test_tool_use_id_none_skipped(self):
        """Agent tool_use with no block.id should not crash."""
        events = [
            _user("u1"),
            _asst("a1", [
                {"type": "tool_use", "id": None, "name": "Agent", "input": {"description": "x"}},
            ]),
        ]
        result = build_active_agents_map(events)
        assert "a1" not in result or result["a1"].is_empty

    def test_task_create_tracked(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "TaskCreate", {"id": "1", "subject": "Setup"}),
            ]),
        ]
        result = build_active_agents_map(events)
        assert "a1" in result
        assert "Setup" in result["a1"].tasks

    def test_send_message_tracked(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "SendMessage", {"to": "alice"}),
            ]),
        ]
        result = build_active_agents_map(events)
        assert "a1" in result
        assert "alice" in result["a1"].teammates

    def test_team_create_tracked(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "TeamCreate", {"team_name": "myteam"}),
            ]),
        ]
        result = build_active_agents_map(events)
        assert "a1" in result
        assert "myteam" in result["a1"].teammates

    def test_non_message_events_skipped(self):
        """Progress, file-history-snapshot, etc. should not produce snapshots."""
        events = [
            SessionEvent.model_validate({
                "type": "progress", "uuid": "p1",
            }),
        ]
        result = build_active_agents_map(events)
        assert result == {}

    def test_user_with_string_content_snapshots_open_agents(self):
        """User events with string content (no structured blocks) should still
        snapshot any currently-open agent spans."""
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "Agent", {"description": "research"}),
            ]),
            _user("u2"),  # string content, but agent t1 is open
        ]
        result = build_active_agents_map(events)
        assert "u2" in result
        assert len(result["u2"].subagents) == 1

    def test_description_truncated(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "Agent", {"description": "a" * 100}),
            ]),
        ]
        result = build_active_agents_map(events)
        assert len(result["a1"].subagents[0]) <= 30


class TestCumulativeTaskTracking:
    """Tasks accumulate across turns (not reset per-event)."""

    def test_tasks_accumulate_across_turns(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "TaskCreate", {"subject": "Task1"}),
                _tool_use("t2", "TaskCreate", {"subject": "Task2"}),
            ]),
            _user("u2"),
            _asst("a2", [
                _tool_use("t3", "TaskCreate", {"subject": "Task3"}),
            ]),
            _user("u3"),
            _asst("a3", [{"type": "text", "text": "Done"}]),
        ]
        result = build_active_agents_map(events)
        assert len(result["a1"].tasks) == 2
        assert len(result["a2"].tasks) == 3
        assert "a3" in result
        assert len(result["a3"].tasks) == 3

    def test_tasks_cumulative_on_user_string_events(self):
        """User events with string content also show cumulative tasks."""
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "TaskCreate", {"subject": "Task1"}),
            ]),
            _user("u2"),  # string content, agent t1 not open but tasks exist
        ]
        result = build_active_agents_map(events)
        assert "u2" in result
        assert len(result["u2"].tasks) == 1

    def test_task_update_also_tracked(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "TaskCreate", {"subject": "Setup"}),
            ]),
            _user("u2"),
            _asst("a2", [
                _tool_use("t2", "TaskUpdate", {"taskId": "1", "status": "in_progress"}),
            ]),
        ]
        result = build_active_agents_map(events)
        # TaskUpdate with non-terminal status should NOT inflate count
        assert len(result["a2"].tasks) == 1

    def test_task_delete_removes_from_count(self):
        """TaskUpdate with status='deleted' removes the task from count."""
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "TaskCreate", {"subject": "Task1"}),
                _tool_use("t2", "TaskCreate", {"subject": "Task2"}),
                _tool_use("t3", "TaskCreate", {"subject": "Task3"}),
            ]),
            _user("u2"),
            _asst("a2", [
                _tool_use("t4", "TaskUpdate", {"taskId": "2", "status": "deleted"}),
            ]),
            _user("u3"),
        ]
        result = build_active_agents_map(events)
        assert len(result["a2"].tasks) == 2
        assert len(result["u3"].tasks) == 2
        assert "Task2" not in result["u3"].tasks

    def test_task_completed_removes_from_count(self):
        """TaskUpdate with status='completed' removes the task from count."""
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "TaskCreate", {"subject": "Task1"}),
                _tool_use("t2", "TaskCreate", {"subject": "Task2"}),
            ]),
            _user("u2"),
            _asst("a2", [
                _tool_use("t3", "TaskUpdate", {"taskId": "1", "status": "completed"}),
            ]),
        ]
        result = build_active_agents_map(events)
        assert len(result["a2"].tasks) == 1
        assert "Task1" not in result["a2"].tasks
        assert "Task2" in result["a2"].tasks

    def test_task_update_unknown_id_no_crash(self):
        """TaskUpdate for unknown taskId should not crash or inflate count."""
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "TaskCreate", {"subject": "Task1"}),
            ]),
            _user("u2"),
            _asst("a2", [
                _tool_use("t2", "TaskUpdate", {"taskId": "99", "status": "deleted"}),
            ]),
        ]
        result = build_active_agents_map(events)
        assert len(result["a2"].tasks) == 1


class TestAskUserQuestionTracking:
    """AskUserQuestion spans tracked as pending questions."""

    def test_pending_question_tracked(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "AskUserQuestion", {"question": "What color?"}),
            ]),
        ]
        result = build_active_agents_map(events)
        assert "a1" in result
        assert len(result["a1"].pending_questions) == 1

    def test_answered_question_cleared(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "AskUserQuestion", {"question": "What?"}),
            ]),
            # User answers — content is a list with tool_result
            _asst("a2", [
                _tool_result("t1", "Blue"),
            ]),
        ]
        result = build_active_agents_map(events)
        assert len(result["a1"].pending_questions) == 1
        assert "a2" not in result or not result.get("a2", ActiveAgentsSnapshot()).pending_questions

    def test_pending_question_visible_on_user_string_events(self):
        events = [
            _user("u1"),
            _asst("a1", [
                _tool_use("t1", "AskUserQuestion", {"question": "What?"}),
            ]),
            _user("u2"),  # string content
        ]
        result = build_active_agents_map(events)
        assert "u2" in result
        assert len(result["u2"].pending_questions) == 1

    def test_snapshot_is_empty_includes_pending_questions(self):
        snap = ActiveAgentsSnapshot(pending_questions=["q1"])
        assert not snap.is_empty


class TestFormatBadgeWithSnapshots:
    """_format_badge renders individual badges from snapshot fields."""

    def test_tasks_shown_as_count(self):
        snap = ActiveAgentsSnapshot(tasks=["t1", "t2", "t3"])
        result = _format_badge("📋", len(snap.tasks))
        assert result == "📋3"

    def test_pending_question_shown(self):
        snap = ActiveAgentsSnapshot(pending_questions=["q1"])
        result = _format_badge("❓", len(snap.pending_questions))
        assert result == "❓1"

    def test_each_field_produces_own_badge(self):
        snap = ActiveAgentsSnapshot(
            subagents=["research"],
            tasks=["t1", "t2"],
            pending_questions=["q1"],
        )
        assert _format_badge("📋", len(snap.tasks)) == "📋2"
        assert _format_badge("🤖", len(snap.subagents)) == "🤖1"
        assert _format_badge("❓", len(snap.pending_questions)) == "❓1"

    def test_empty_field_returns_empty(self):
        snap = ActiveAgentsSnapshot(subagents=["sub1"])
        assert _format_badge("📋", len(snap.tasks)) == ""


class TestFormatAgentsStatusLine:
    """Status bar drill-down line for agent annotations."""

    def test_tasks_listed(self):
        snap = ActiveAgentsSnapshot(tasks=["Fix auth", "Add tests", "Refactor DB"])
        result = format_agents_status_line(snap)
        assert "3 tasks" in result
        assert "Fix auth" in result

    def test_subagents_listed(self):
        snap = ActiveAgentsSnapshot(subagents=["research code"])
        result = format_agents_status_line(snap)
        assert "research code" in result

    def test_pending_questions(self):
        snap = ActiveAgentsSnapshot(pending_questions=["What color?"])
        result = format_agents_status_line(snap)
        assert "pending" in result.lower() or "❓" in result

    def test_none_returns_empty(self):
        result = format_agents_status_line(None)
        assert result == ""

    def test_empty_snapshot_returns_empty(self):
        snap = ActiveAgentsSnapshot()
        result = format_agents_status_line(snap)
        assert result == ""

    def test_combined(self):
        snap = ActiveAgentsSnapshot(
            subagents=["fix tests"],
            tasks=["t1", "t2"],
            pending_questions=["q1"],
        )
        result = format_agents_status_line(snap)
        assert "2 tasks" in result
        assert "fix tests" in result
