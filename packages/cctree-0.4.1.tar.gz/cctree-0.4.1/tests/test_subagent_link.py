"""Tests for subagent linkage — mapping parent tool_use to subagent JSONL files.

The linkage chain is:
  Agent tool_use (tool_use_id) → progress event (parentToolUseID → data.agentId) → agent-{agentId}.jsonl
"""
from __future__ import annotations

from pathlib import Path

import pytest

from cctree.core.parser import parse_jsonl
from cctree.core.model import Session

FIXTURES = Path(__file__).parent / "fixtures"


class TestSubagentLinkDiscovery:
    """Test that we can discover the agentId for each Agent tool_use in a session."""

    def test_finds_agent_id_from_progress_events(self):
        events = parse_jsonl(FIXTURES / "with_subagent.jsonl")
        session = Session(uuid="sess0006", project_slug="test", path="x", events=events)

        # Import the function we're about to write
        from cctree.core.subagent_link import find_agent_links

        links = find_agent_links(session.events)
        # Should find one link: toolu_agent001 → abc123def456
        assert len(links) == 1
        assert links["toolu_agent001"] == "abc123def456"

    def test_returns_empty_for_session_without_agents(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)

        from cctree.core.subagent_link import find_agent_links

        links = find_agent_links(session.events)
        assert links == {}

    def test_multiple_agents_each_linked(self):
        """A session with multiple Agent tool_use calls should map each to its agentId."""
        from cctree.core.subagent_link import find_agent_links

        # Construct events with two Agent calls
        from cctree.core.model import SessionEvent
        events = [
            # Agent tool_use 1
            SessionEvent(
                type="assistant",
                uuid="a1",
                message={"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_first", "name": "Agent",
                     "input": {"description": "first agent", "subagent_type": "Explore"}},
                ]},
            ),
            # Progress linking first agent
            SessionEvent(type="progress", uuid="p1", **{
                "data": {"agentId": "hash_first", "type": "agent_progress"},
                "parentToolUseID": "toolu_first",
            }),
            # Agent tool_use 2
            SessionEvent(
                type="assistant",
                uuid="a2",
                parentUuid="a1",
                message={"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_second", "name": "Agent",
                     "input": {"description": "second agent", "subagent_type": "general-purpose"}},
                ]},
            ),
            # Progress linking second agent
            SessionEvent(type="progress", uuid="p2", **{
                "data": {"agentId": "hash_second", "type": "agent_progress"},
                "parentToolUseID": "toolu_second",
            }),
        ]

        links = find_agent_links(events)
        assert len(links) == 2
        assert links["toolu_first"] == "hash_first"
        assert links["toolu_second"] == "hash_second"


class TestSubagentFileResolution:
    """Test resolving an agentId to its JSONL file path."""

    def test_resolves_existing_file(self, tmp_path):
        # Create a fake subagents dir
        subagents_dir = tmp_path / "sess0006" / "subagents"
        subagents_dir.mkdir(parents=True)
        (subagents_dir / "agent-abc123def456.jsonl").write_text('{"type":"user"}\n')

        from cctree.core.subagent_link import resolve_subagent_path

        path = resolve_subagent_path("abc123def456", str(tmp_path / "sess0006.jsonl"))
        assert path is not None
        assert path.name == "agent-abc123def456.jsonl"

    def test_returns_none_for_missing_file(self, tmp_path):
        from cctree.core.subagent_link import resolve_subagent_path

        path = resolve_subagent_path("nonexistent", str(tmp_path / "sess0006.jsonl"))
        assert path is None

    def test_returns_none_for_no_subagents_dir(self, tmp_path):
        # JSONL exists but no subagents/ dir
        (tmp_path / "sess0006.jsonl").write_text("{}\n")

        from cctree.core.subagent_link import resolve_subagent_path

        path = resolve_subagent_path("abc123", str(tmp_path / "sess0006.jsonl"))
        assert path is None

    def test_resolves_via_fallback_session(self, tmp_path):
        """Forked sessions don't have their own subagents dir. Resolution should
        fall back to checking additional session paths (e.g., the original session)."""
        from cctree.core.subagent_link import resolve_subagent_path

        # Original session has the subagent file
        original_dir = tmp_path / "original-uuid" / "subagents"
        original_dir.mkdir(parents=True)
        (original_dir / "agent-abc123def456.jsonl").write_text('{"type":"user"}\n')

        # Forked session has no subagents dir
        # Primary lookup fails, fallback to original succeeds
        path = resolve_subagent_path(
            "abc123def456",
            str(tmp_path / "forked-uuid.jsonl"),
            fallback_session_paths=[str(tmp_path / "original-uuid.jsonl")],
        )
        assert path is not None
        assert path.name == "agent-abc123def456.jsonl"
        assert "original-uuid" in str(path)

    def test_fallback_not_used_when_primary_exists(self, tmp_path):
        """If the primary session has its own subagents, don't fall back."""
        from cctree.core.subagent_link import resolve_subagent_path

        # Both have the file
        for name in ["primary-uuid", "fallback-uuid"]:
            d = tmp_path / name / "subagents"
            d.mkdir(parents=True)
            (d / "agent-abc123.jsonl").write_text("{}\n")

        path = resolve_subagent_path(
            "abc123",
            str(tmp_path / "primary-uuid.jsonl"),
            fallback_session_paths=[str(tmp_path / "fallback-uuid.jsonl")],
        )
        assert path is not None
        assert "primary-uuid" in str(path)

    def test_fallback_returns_none_when_nobody_has_it(self, tmp_path):
        """Neither primary nor fallback has the file."""
        from cctree.core.subagent_link import resolve_subagent_path

        path = resolve_subagent_path(
            "nonexistent",
            str(tmp_path / "forked-uuid.jsonl"),
            fallback_session_paths=[str(tmp_path / "original-uuid.jsonl")],
        )
        assert path is None


class TestFindTeammateReferences:
    """Discover teammate names mentioned in <teammate-message> tags across events."""

    def test_finds_teammate_names_in_user_content(self):
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import find_teammate_references

        events = [
            SessionEvent(
                type="user",
                uuid="u1",
                message={
                    "role": "user",
                    "content": (
                        '<teammate-message teammate_id="researcher" color="blue">\n'
                        "hi\n</teammate-message>\n"
                        '<teammate-message teammate_id="writer" color="green">\n'
                        "ok\n</teammate-message>"
                    ),
                },
            ),
            SessionEvent(
                type="user",
                uuid="u2",
                message={
                    "role": "user",
                    "content": '<teammate-message teammate_id="researcher">repeat</teammate-message>',
                },
            ),
        ]
        refs = find_teammate_references(events)
        assert refs == {"researcher", "writer"}

    def test_empty_on_non_team_session(self):
        from cctree.core.parser import parse_jsonl
        from cctree.core.subagent_link import find_teammate_references
        from pathlib import Path

        FIXTURES = Path(__file__).parent / "fixtures"
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        assert find_teammate_references(events) == set()

    def test_ignores_content_arrays(self):
        """Content may be a list of ContentBlocks (normal Claude messages).
        Teammate-message tags only appear in string content."""
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import find_teammate_references

        events = [
            SessionEvent(
                type="assistant",
                uuid="a1",
                message={
                    "role": "assistant",
                    "content": [{"type": "text", "text": "no tags here"}],
                },
            ),
        ]
        assert find_teammate_references(events) == set()


class TestResolveTeammatePaths:
    def test_returns_all_files_for_teammate(self, tmp_path):
        import json
        import time
        from cctree.core.subagent_link import resolve_teammate_paths

        sub = tmp_path / "sess" / "subagents"
        sub.mkdir(parents=True)
        for h in ("a1", "a2"):
            (sub / f"agent-{h}.meta.json").write_text(json.dumps({"agentType": "r"}))
            (sub / f"agent-{h}.jsonl").write_text("{}\n")
            time.sleep(0.005)
        # Unrelated teammate
        (sub / "agent-b1.meta.json").write_text(json.dumps({"agentType": "w"}))
        (sub / "agent-b1.jsonl").write_text("{}\n")

        paths = resolve_teammate_paths("r", str(tmp_path / "sess.jsonl"))
        assert len(paths) == 2
        assert all(p.name.startswith("agent-a") for p in paths)

    def test_empty_when_no_subagents(self, tmp_path):
        from cctree.core.subagent_link import resolve_teammate_paths

        assert resolve_teammate_paths("r", str(tmp_path / "sess.jsonl")) == []

    def test_fallback_to_original_session(self, tmp_path):
        import json
        from cctree.core.subagent_link import resolve_teammate_paths

        # Fallback path has the teammate file
        original = tmp_path / "orig" / "subagents"
        original.mkdir(parents=True)
        (original / "agent-a1.meta.json").write_text(json.dumps({"agentType": "r"}))
        (original / "agent-a1.jsonl").write_text("{}\n")

        paths = resolve_teammate_paths(
            "r",
            str(tmp_path / "fork.jsonl"),
            fallback_session_paths=[str(tmp_path / "orig.jsonl")],
        )
        assert len(paths) == 1
        assert "orig" in str(paths[0])

    def test_primary_preferred_over_fallback(self, tmp_path):
        import json
        from cctree.core.subagent_link import resolve_teammate_paths

        for name in ("primary", "fallback"):
            d = tmp_path / name / "subagents"
            d.mkdir(parents=True)
            (d / "agent-a1.meta.json").write_text(json.dumps({"agentType": "r"}))
            (d / "agent-a1.jsonl").write_text("{}\n")

        paths = resolve_teammate_paths(
            "r",
            str(tmp_path / "primary.jsonl"),
            fallback_session_paths=[str(tmp_path / "fallback.jsonl")],
        )
        # Primary only — don't use fallback when primary has the data
        assert all("primary" in str(p) for p in paths)

    def test_teammate_not_found_anywhere(self, tmp_path):
        from cctree.core.subagent_link import resolve_teammate_paths

        paths = resolve_teammate_paths(
            "r",
            str(tmp_path / "fork.jsonl"),
            fallback_session_paths=[str(tmp_path / "orig.jsonl")],
        )
        assert paths == []
