"""Tests for TUI performance — search debouncing and lazy subagent loading."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from unittest.mock import patch

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


class TestSearchPerformance:
    """Search must not block the UI — should debounce or use a worker."""

    @pytest.fixture
    def large_project(self, tmp_path):
        """Create a project with many sessions to make search measurably slow."""
        for i in range(50):
            uuid = f"perf{i:04d}-0000-0000-0000-000000000000"
            lines = []
            # Each session has 20 messages with searchable text
            parent = None
            for j in range(20):
                msg_uuid = f"msg{i:04d}{j:04d}-0000-0000-000000000000"
                if j % 2 == 0:
                    lines.append(json.dumps({
                        "type": "user", "uuid": msg_uuid, "parentUuid": parent,
                        "message": {"role": "user", "content": f"session {i} message {j} unique-text-{i}-{j}"},
                        "sessionId": uuid, "slug": f"test-session-{i}",
                        "timestamp": f"2026-04-01T10:{i:02d}:{j:02d}.000Z",
                    }))
                else:
                    lines.append(json.dumps({
                        "type": "assistant", "uuid": msg_uuid, "parentUuid": parent,
                        "message": {"role": "assistant", "content": [
                            {"type": "text", "text": f"response to session {i} message {j}"}
                        ]},
                        "sessionId": uuid, "slug": f"test-session-{i}",
                        "timestamp": f"2026-04-01T10:{i:02d}:{j:02d}.000Z",
                    }))
                parent = msg_uuid
            (tmp_path / f"{uuid}.jsonl").write_text("\n".join(lines) + "\n")
            old_time = time.time() - 300
            os.utime(tmp_path / f"{uuid}.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_search_does_not_block_on_every_keystroke(self, large_project):
        """Typing fast in search should not call the search function on every character.
        The search should be debounced — only fires after the user pauses typing."""
        from cctree.tui.app import CctreeApp, SearchScreen

        app = CctreeApp(project_dir=str(large_project))
        async with app.run_test() as pilot:
            # Open search
            await pilot.press("slash")
            await pilot.pause()

            # Type quickly — each char fires on_input_changed
            # With debouncing, only the final state should trigger a real search
            search_call_count = 0
            original_search = SearchScreen._do_search if hasattr(SearchScreen, '_do_search') else None

            # Track how many times the actual search runs
            from cctree.tui.app import SearchScreen as SS
            if hasattr(SS, '_do_search'):
                real_search = SS._do_search

                def counting_search(self, query):
                    nonlocal search_call_count
                    search_call_count += 1
                    return real_search(self, query)

                with patch.object(SS, '_do_search', counting_search):
                    await pilot.press("u", "n", "i", "q", "u", "e")
                    await pilot.pause(delay=0.5)  # wait for debounce

                # Should have run the search far fewer times than 6 (one per keystroke)
                assert search_call_count <= 2, \
                    f"Search ran {search_call_count} times for 6 keystrokes — should be debounced"
            else:
                # If _do_search doesn't exist yet, the test should fail
                # to remind us to implement debouncing
                pytest.fail(
                    "SearchScreen._do_search method not found — "
                    "search needs to be refactored with debouncing"
                )


class TestLazySubagentLoading:
    """Subagent transcripts must be loaded lazily, not eagerly on session select."""

    @pytest.fixture
    def project_with_subagents(self, tmp_path):
        """Create a session with Agent tool calls and subagent directories."""
        uuid = "lazy0001-0000-0000-0000-000000000000"
        lines = [
            json.dumps({
                "type": "file-history-snapshot",
                "messageId": "msg-lazy-user1",
                "snapshot": {"messageId": "msg-lazy-user1", "trackedFileBackups": {},
                             "timestamp": "2026-04-01T10:00:00.000Z"},
                "isSnapshotUpdate": False,
            }),
            json.dumps({
                "type": "user", "uuid": "msg-lazy-user1", "parentUuid": None,
                "message": {"role": "user", "content": "research this"},
                "sessionId": uuid, "slug": "lazy-test",
                "timestamp": "2026-04-01T10:00:00.000Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "msg-lazy-asst1", "parentUuid": "msg-lazy-user1",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_lazy1", "name": "Agent",
                     "input": {"description": "research topic", "subagent_type": "Explore"}},
                ]},
                "sessionId": uuid, "slug": "lazy-test",
                "timestamp": "2026-04-01T10:00:05.000Z",
            }),
            # Progress event linking agent
            json.dumps({
                "type": "progress", "uuid": "prog-lazy1", "parentUuid": "msg-lazy-asst1",
                "data": {"agentId": "lazyhash001", "type": "agent_progress"},
                "parentToolUseID": "toolu_lazy1", "toolUseID": "agent_msg1",
                "sessionId": uuid, "slug": "lazy-test",
                "timestamp": "2026-04-01T10:00:06.000Z",
            }),
        ]
        (tmp_path / f"{uuid}.jsonl").write_text("\n".join(lines) + "\n")
        old_time = time.time() - 300
        os.utime(tmp_path / f"{uuid}.jsonl", (old_time, old_time))

        # Create subagent transcript file
        sub_dir = tmp_path / uuid / "subagents"
        sub_dir.mkdir(parents=True)
        sub_lines = [
            json.dumps({
                "type": "user", "uuid": "sub-user1", "parentUuid": None,
                "agentId": "lazyhash001",
                "message": {"role": "user", "content": "research the topic"},
                "sessionId": uuid, "timestamp": "2026-04-01T10:00:06.000Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "sub-asst1", "parentUuid": "sub-user1",
                "agentId": "lazyhash001",
                "message": {"role": "assistant", "content": [
                    {"type": "text", "text": "Found relevant results."},
                ]},
                "sessionId": uuid, "timestamp": "2026-04-01T10:00:10.000Z",
            }),
        ]
        (sub_dir / "agent-lazyhash001.jsonl").write_text("\n".join(sub_lines) + "\n")

        return tmp_path

    @pytest.mark.asyncio
    async def test_subagent_not_parsed_on_session_load(self, project_with_subagents):
        """When a session is selected, subagent JSONL files must NOT be parsed
        immediately. They should only be parsed when the user expands the Agent node."""
        from cctree.tui.app import CctreeApp
        from cctree.core import parser as parser_mod

        app = CctreeApp(project_dir=str(project_with_subagents))
        async with app.run_test() as pilot:
            parse_calls = []
            # Must patch where parse_jsonl is USED (app.py), not where it's defined
            from cctree.tui import app as tui_app_mod
            original_parse = tui_app_mod.parse_jsonl

            def tracking_parse(path):
                parse_calls.append(str(path))
                return original_parse(path)

            with patch.object(tui_app_mod, 'parse_jsonl', tracking_parse):
                session = app.store.get("lazy0001-0000-0000-0000-000000000000")
                app.load_session(session)

            # The subagent JSONL should NOT have been parsed during load_session
            subagent_parses = [p for p in parse_calls if "subagents" in p]
            assert len(subagent_parses) == 0, \
                f"Subagent JSONL was parsed eagerly during load_session: {subagent_parses}"

    @pytest.mark.asyncio
    async def test_subagent_asst_dimmed_and_sub_user_not(self, project_with_subagents):
        """After expanding a subagent node, Sub-User labels should NOT be dimmed
        but Sub-Asst content (text, tools) should be dimmed via _add_assistant_node."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree
        from rich.text import Text

        app = CctreeApp(project_dir=str(project_with_subagents))
        async with app.run_test() as pilot:
            session = app.store.get("lazy0001-0000-0000-0000-000000000000")
            app.load_session(session)
            tree = app.query_one("#session-tree", Tree)

            # Find the Agent tool node and expand it to trigger lazy loading
            def find_agent(node):
                if node.data and node.data.get("type") == "agent":
                    return node
                for child in node.children:
                    result = find_agent(child)
                    if result:
                        return result
                return None

            agent_node = find_agent(tree.root)
            assert agent_node is not None, "Agent node not found"
            agent_node.expand()
            await pilot.pause()

            # After expansion, agent_node should have Sub-User and Sub-Asst children
            sub_user_nodes = [c for c in agent_node.children if "Sub-User:" in str(c.label)]
            assert len(sub_user_nodes) >= 1, "No Sub-User nodes after subagent expand"

            # Sub-User should NOT be dimmed
            for node in sub_user_nodes:
                label = node.label
                if isinstance(label, Text) and label._spans:
                    has_dim = any("dim" in str(s.style) for s in label._spans)
                    assert not has_dim, f"Sub-User label should not be dimmed: {label}"

            # Sub-Asst content should be dimmed (text blocks rendered by _add_assistant_node)
            sub_asst_nodes = [c for c in agent_node.children
                              if "Sub-User:" not in str(c.label)
                              and str(c.label) not in ("", "(expand to load transcript)")]
            for node in sub_asst_nodes:
                label = node.label
                if isinstance(label, Text) and label._spans:
                    has_dim = any("dim" in str(s.style) for s in label._spans)
                    assert has_dim, f"Sub-Asst content should be dimmed: {label}"


class TestAsyncSessionLoading:
    """Session loading must not block the initial UI render."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        """Create a temp project dir with fixture sessions."""
        fixtures = Path(__file__).parent / "fixtures"
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
            ("titled_session.jsonl", "sess0003-0000-0000-0000-000000000003.jsonl"),
        ]:
            (tmp_path / dest_name).write_text((fixtures / src).read_text())
            old_time = time.time() - 300
            os.utime(tmp_path / dest_name, (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_session_list_empty_before_worker_completes(self, project_dir):
        """Immediately after mount, the session list should not yet contain
        session items — loading happens in a background worker."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(120, 40)) as pilot:
            lv = app.query_one("#sessions-pane", ListView)
            # Before worker completes, no real session items should be present.
            # The pane should be empty or show only a loading indicator.
            session_items = [
                c for c in lv.children
                if hasattr(c, "name") and c.name and not c.name.startswith("__")
            ]
            assert len(session_items) == 0, (
                f"Sessions should not be loaded synchronously in on_mount; "
                f"found {len(session_items)} session items immediately"
            )

    @pytest.mark.asyncio
    async def test_session_list_populated_after_worker_completes(self, project_dir):
        """After the background worker finishes, the session list should contain
        all discovered sessions."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import ListView

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(120, 40)) as pilot:
            # Wait for the worker to finish
            await pilot.pause(delay=0.5)
            lv = app.query_one("#sessions-pane", ListView)
            session_items = [
                c for c in lv.children
                if hasattr(c, "name") and c.name and not c.name.startswith("__")
            ]
            assert len(session_items) == 2, (
                f"Expected 2 sessions after worker completes, got {len(session_items)}"
            )
