"""Tests for cctree.core.team_forge — clone the team dir, filter inboxes, replay tasks.

The team-aware fork workflow:
  1. forge_session writes the lead JSONL (existing behavior) + rewrites teamName
  2. team_forge.clone_team_for_fork:
     a. Copies ~/.claude/teams/{old}/ to ~/.claude/teams/{new}/
     b. Rewrites config.json (name, leadSessionId, leadAgentId, members[].agentId)
     c. Filters each inboxes/*.json by timestamp <= cut_timestamp
     d. Replays TaskCreate/Update/Delete events into ~/.claude/tasks/{new}/
     e. Copies + filters teammate JSONL files under the new session's subagents/
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest


def _make_team_fixture(tmp_path: Path):
    """Build a fixture layout.

    Returns a dict with:
      teams_base, tasks_base, original_session_dir, new_session_dir
    """
    teams_base = tmp_path / "teams"
    tasks_base = tmp_path / "tasks"
    original_session_dir = tmp_path / "projects" / "proj" / "sess-old"
    new_session_dir = tmp_path / "projects" / "proj" / "sess-new"

    # Team config + inbox for member "alice"
    team_dir = teams_base / "demo"
    (team_dir / "inboxes").mkdir(parents=True)
    (team_dir / "config.json").write_text(json.dumps({
        "name": "demo",
        "description": "demo team",
        "createdAt": 1776310400000,
        "leadAgentId": "team-lead@demo",
        "leadSessionId": "original-session-uuid",
        "members": [
            {
                "agentId": "team-lead@demo", "name": "team-lead",
                "agentType": "orchestrator", "model": "claude-opus-4-6",
                "joinedAt": 1776310400000, "cwd": "/tmp",
                "subscriptions": [],
            },
            {
                "agentId": "alice@demo", "name": "alice",
                "agentType": "researcher", "model": "claude-sonnet-4-6",
                "joinedAt": 1776310400000, "cwd": "/tmp",
                "subscriptions": [],
            },
        ],
    }))
    (team_dir / "inboxes" / "alice.json").write_text(json.dumps([
        {"from": "team-lead", "text": "start", "summary": "go",
         "timestamp": "2026-04-16T00:00:00Z", "read": True},
        # Post-fork
        {"from": "team-lead", "text": "late",
         "timestamp": "2026-04-16T01:00:00Z", "read": True},
    ]))
    (team_dir / "inboxes" / "team-lead.json").write_text(json.dumps([
        {"from": "alice", "text": "first response",
         "timestamp": "2026-04-16T00:30:00Z", "read": True},
        {"from": "alice", "text": "second response (post-fork)",
         "timestamp": "2026-04-16T01:15:00Z", "read": True},
    ]))

    # Teammate JSONL files under the original session's subagents/
    sub = original_session_dir / "subagents"
    sub.mkdir(parents=True)
    (sub / "agent-a1.meta.json").write_text(json.dumps({"agentType": "alice"}))
    (sub / "agent-a1.jsonl").write_text(
        json.dumps({"type": "user", "uuid": "u-a1",
                    "sessionId": "original-session-uuid",
                    "timestamp": "2026-04-16T00:10:00Z",
                    "message": {"role": "user", "content": "hi"}}) + "\n"
        + json.dumps({"type": "assistant", "uuid": "a-a1",
                      "sessionId": "original-session-uuid",
                      "parentUuid": "u-a1",
                      "timestamp": "2026-04-16T00:20:00Z",
                      "message": {"role": "assistant", "content": "ok"}}) + "\n"
        # Post-fork event in same file (should be filtered out)
        + json.dumps({"type": "user", "uuid": "u-a2",
                      "sessionId": "original-session-uuid",
                      "parentUuid": "a-a1",
                      "timestamp": "2026-04-16T01:30:00Z",
                      "message": {"role": "user", "content": "late"}}) + "\n"
    )
    # Agent-tool subagent (should NOT be copied by team clone)
    (sub / "agent-s1.meta.json").write_text(
        json.dumps({"agentType": "Explore", "description": "research task"})
    )
    (sub / "agent-s1.jsonl").write_text(
        json.dumps({"type": "user", "uuid": "u-s1",
                    "sessionId": "original-session-uuid",
                    "timestamp": "2026-04-16T00:05:00Z",
                    "message": {"role": "user", "content": "explore"}}) + "\n"
    )

    return {
        "teams_base": teams_base,
        "tasks_base": tasks_base,
        "original_session_dir": original_session_dir,
        "new_session_dir": new_session_dir,
    }


class TestDeriveNewTeamName:
    def test_default_pattern(self, tmp_path):
        from cctree.core.team_forge import derive_new_team_name

        name = derive_new_team_name(
            "demo", "abcd1234-xxxx-yyyy", teams_base=tmp_path
        )
        assert name == "demo-fork-abcd1234"

    def test_collision_avoidance(self, tmp_path):
        from cctree.core.team_forge import derive_new_team_name

        (tmp_path / "demo-fork-abcd1234").mkdir()
        name = derive_new_team_name(
            "demo", "abcd1234-xxxx-yyyy", teams_base=tmp_path
        )
        assert name == "demo-fork-abcd1234-1"

        (tmp_path / "demo-fork-abcd1234-1").mkdir()
        name2 = derive_new_team_name(
            "demo", "abcd1234-xxxx-yyyy", teams_base=tmp_path
        )
        assert name2 == "demo-fork-abcd1234-2"


class TestCloneTeamForFork:
    def test_copies_team_dir_with_new_name(self, tmp_path):
        from cctree.core.team_forge import clone_team_for_fork

        fx = _make_team_fixture(tmp_path)
        uuid_map = {"original-session-uuid": "new-session-uuid"}

        result = clone_team_for_fork(
            old_team_name="demo",
            new_team_name="demo-fork-new",
            new_session_id="new-session-uuid",
            uuid_map=uuid_map,
            cut_timestamp="2026-04-16T00:45:00Z",
            prefix_events=[],
            original_session_dir=fx["original_session_dir"],
            new_session_dir=fx["new_session_dir"],
            teams_base=fx["teams_base"],
            tasks_base=fx["tasks_base"],
        )
        assert result.new_team_name == "demo-fork-new"
        assert result.new_team_dir == fx["teams_base"] / "demo-fork-new"
        assert result.new_team_dir.is_dir()
        assert (result.new_team_dir / "config.json").is_file()

    def test_config_rewritten(self, tmp_path):
        from cctree.core.team_forge import clone_team_for_fork

        fx = _make_team_fixture(tmp_path)
        clone_team_for_fork(
            old_team_name="demo",
            new_team_name="forked-team",
            new_session_id="new-session-uuid",
            uuid_map={"original-session-uuid": "new-session-uuid"},
            cut_timestamp="2026-04-16T00:45:00Z",
            prefix_events=[],
            original_session_dir=fx["original_session_dir"],
            new_session_dir=fx["new_session_dir"],
            teams_base=fx["teams_base"],
            tasks_base=fx["tasks_base"],
        )
        cfg = json.loads((fx["teams_base"] / "forked-team" / "config.json").read_text())
        assert cfg["name"] == "forked-team"
        assert cfg["leadSessionId"] == "new-session-uuid"
        assert cfg["leadAgentId"] == "team-lead@forked-team"
        agent_ids = [m["agentId"] for m in cfg["members"]]
        assert "team-lead@forked-team" in agent_ids
        assert "alice@forked-team" in agent_ids
        assert all("@demo" not in a for a in agent_ids)
        # Non-agentId fields preserved
        names = [m["name"] for m in cfg["members"]]
        assert names == ["team-lead", "alice"]
        types = [m["agentType"] for m in cfg["members"]]
        assert types == ["orchestrator", "researcher"]

    def test_inboxes_filtered_by_timestamp(self, tmp_path):
        from cctree.core.team_forge import clone_team_for_fork

        fx = _make_team_fixture(tmp_path)
        clone_team_for_fork(
            old_team_name="demo",
            new_team_name="forked",
            new_session_id="new-session-uuid",
            uuid_map={"original-session-uuid": "new-session-uuid"},
            cut_timestamp="2026-04-16T00:45:00Z",
            prefix_events=[],
            original_session_dir=fx["original_session_dir"],
            new_session_dir=fx["new_session_dir"],
            teams_base=fx["teams_base"],
            tasks_base=fx["tasks_base"],
        )
        alice_inbox = json.loads(
            (fx["teams_base"] / "forked" / "inboxes" / "alice.json").read_text()
        )
        # The 01:00:00 message should be dropped
        assert len(alice_inbox) == 1
        assert alice_inbox[0]["text"] == "start"

        lead_inbox = json.loads(
            (fx["teams_base"] / "forked" / "inboxes" / "team-lead.json").read_text()
        )
        assert len(lead_inbox) == 1
        assert lead_inbox[0]["text"] == "first response"

    def test_tasks_replayed_from_prefix_events(self, tmp_path):
        from cctree.core.team_forge import clone_team_for_fork

        fx = _make_team_fixture(tmp_path)

        prefix_events = [
            # TaskCreate A
            {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": [
                        {"type": "tool_use", "id": "tu1", "name": "TaskCreate",
                         "input": {"id": "A", "subject": "research",
                                   "description": "research now",
                                   "activeForm": "Researching",
                                   "status": "pending"}},
                    ],
                },
            },
            # TaskUpdate A to in_progress
            {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": [
                        {"type": "tool_use", "id": "tu2", "name": "TaskUpdate",
                         "input": {"id": "A", "status": "in_progress"}},
                    ],
                },
            },
            # TaskCreate B
            {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": [
                        {"type": "tool_use", "id": "tu3", "name": "TaskCreate",
                         "input": {"id": "B", "subject": "write",
                                   "status": "pending"}},
                    ],
                },
            },
            # TaskDelete B
            {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": [
                        {"type": "tool_use", "id": "tu4", "name": "TaskDelete",
                         "input": {"id": "B"}},
                    ],
                },
            },
        ]

        clone_team_for_fork(
            old_team_name="demo",
            new_team_name="forked",
            new_session_id="new-session-uuid",
            uuid_map={"original-session-uuid": "new-session-uuid"},
            cut_timestamp="2026-04-16T00:45:00Z",
            prefix_events=prefix_events,
            original_session_dir=fx["original_session_dir"],
            new_session_dir=fx["new_session_dir"],
            teams_base=fx["teams_base"],
            tasks_base=fx["tasks_base"],
        )
        task_dir = fx["tasks_base"] / "forked"
        assert task_dir.is_dir()
        task_files = sorted(task_dir.glob("*.json"))
        assert len(task_files) == 1  # A survived, B deleted
        task = json.loads(task_files[0].read_text())
        assert task["id"] == "A"
        assert task["status"] == "in_progress"
        assert task["subject"] == "research"

    def test_teammate_jsonl_cloned_and_filtered(self, tmp_path):
        from cctree.core.team_forge import clone_team_for_fork

        fx = _make_team_fixture(tmp_path)
        clone_team_for_fork(
            old_team_name="demo",
            new_team_name="forked",
            new_session_id="new-session-uuid",
            uuid_map={
                "original-session-uuid": "new-session-uuid",
                "u-a1": "new-u-a1",
                "a-a1": "new-a-a1",
            },
            cut_timestamp="2026-04-16T00:45:00Z",
            prefix_events=[],
            original_session_dir=fx["original_session_dir"],
            new_session_dir=fx["new_session_dir"],
            teams_base=fx["teams_base"],
            tasks_base=fx["tasks_base"],
        )
        new_sub = fx["new_session_dir"] / "subagents"
        assert new_sub.is_dir()
        # Teammate file cloned with same hash
        assert (new_sub / "agent-a1.jsonl").is_file()
        assert (new_sub / "agent-a1.meta.json").is_file()

        # Agent-tool subagent NOT cloned
        assert not (new_sub / "agent-s1.jsonl").exists()
        assert not (new_sub / "agent-s1.meta.json").exists()

        # Events filtered by timestamp + remapped
        lines = (new_sub / "agent-a1.jsonl").read_text().strip().split("\n")
        assert len(lines) == 2  # the post-fork event was dropped
        for line in lines:
            evt = json.loads(line)
            assert evt["sessionId"] == "new-session-uuid"
        # UUIDs remapped per uuid_map
        events = [json.loads(line) for line in lines]
        assert events[0]["uuid"] == "new-u-a1"
        assert events[1]["uuid"] == "new-a-a1"
        assert events[1]["parentUuid"] == "new-u-a1"

    def test_teammate_file_with_no_surviving_events_dropped(self, tmp_path):
        from cctree.core.team_forge import clone_team_for_fork

        fx = _make_team_fixture(tmp_path)
        # Add another teammate file whose events are all post-fork
        sub = fx["original_session_dir"] / "subagents"
        (sub / "agent-late.meta.json").write_text(json.dumps({"agentType": "alice"}))
        (sub / "agent-late.jsonl").write_text(
            json.dumps({
                "type": "user", "uuid": "u-late",
                "sessionId": "original-session-uuid",
                "timestamp": "2026-04-16T02:00:00Z",
                "message": {"role": "user", "content": "very late"},
            }) + "\n"
        )

        clone_team_for_fork(
            old_team_name="demo",
            new_team_name="forked",
            new_session_id="new-session-uuid",
            uuid_map={"original-session-uuid": "new-session-uuid"},
            cut_timestamp="2026-04-16T00:45:00Z",
            prefix_events=[],
            original_session_dir=fx["original_session_dir"],
            new_session_dir=fx["new_session_dir"],
            teams_base=fx["teams_base"],
            tasks_base=fx["tasks_base"],
        )
        new_sub = fx["new_session_dir"] / "subagents"
        # The all-post-fork file should NOT have been cloned
        assert not (new_sub / "agent-late.jsonl").exists()
        assert not (new_sub / "agent-late.meta.json").exists()

    def test_destination_team_exists_raises(self, tmp_path):
        from cctree.core.team_forge import TeamForgeError, clone_team_for_fork

        fx = _make_team_fixture(tmp_path)
        (fx["teams_base"] / "forked").mkdir()

        with pytest.raises(TeamForgeError):
            clone_team_for_fork(
                old_team_name="demo",
                new_team_name="forked",
                new_session_id="new-session-uuid",
                uuid_map={},
                cut_timestamp="2026-04-16T00:45:00Z",
                prefix_events=[],
                original_session_dir=fx["original_session_dir"],
                new_session_dir=fx["new_session_dir"],
                teams_base=fx["teams_base"],
                tasks_base=fx["tasks_base"],
            )

    def test_source_team_missing_handled(self, tmp_path):
        """If the source team dir doesn't exist (e.g. TeamDelete already ran),
        task replay + teammate clone still run, but no config/inbox copy."""
        from cctree.core.team_forge import clone_team_for_fork

        fx = _make_team_fixture(tmp_path)
        shutil.rmtree(fx["teams_base"] / "demo")

        result = clone_team_for_fork(
            old_team_name="demo",
            new_team_name="forked",
            new_session_id="new-session-uuid",
            uuid_map={"original-session-uuid": "new-session-uuid"},
            cut_timestamp="2026-04-16T00:45:00Z",
            prefix_events=[],
            original_session_dir=fx["original_session_dir"],
            new_session_dir=fx["new_session_dir"],
            teams_base=fx["teams_base"],
            tasks_base=fx["tasks_base"],
        )
        # No crash — returns result with zero inbox cloning
        assert result.new_team_name == "forked"
        # Teammate JSONLs still cloned (they're independent of team dir)
        assert (fx["new_session_dir"] / "subagents" / "agent-a1.jsonl").is_file()


class TestForgeSessionTeamIntegration:
    """forge_session end-to-end: detect team session, delegate to team_forge."""

    def _build_team_lead_jsonl(self, tmp_path, session_id="old-sess-uuid"):
        """Write a minimal team-lead session JSONL + matching subagents/ dir."""
        sess_path = tmp_path / f"{session_id}.jsonl"
        # Raw events. teamName on every event.
        events = [
            {"type": "user", "uuid": "m1",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:10Z",
             "message": {"role": "user", "content": "go"}},
            {"type": "assistant", "uuid": "m2",
             "parentUuid": "m1",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:20Z",
             "message": {"role": "assistant", "content": [
                 {"type": "tool_use", "id": "tu1", "name": "TaskCreate",
                  "input": {"id": "A", "subject": "research", "status": "pending"}}
             ]}},
            {"type": "user", "uuid": "m3",
             "parentUuid": "m2",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:30Z",
             "message": {"role": "user", "content":
                         '<teammate-message teammate_id="alice" color="blue">done</teammate-message>'}},
        ]
        with open(sess_path, "w") as f:
            for e in events:
                f.write(json.dumps(e) + "\n")
        return sess_path

    def test_non_team_session_forges_without_team_clone(self, tmp_path):
        """Regression: forging a non-team session still works, returns team_forge_result=None."""
        from cctree.core.forge import forge_session

        # Use the simple_session fixture
        src = Path(__file__).parent / "fixtures" / "simple_session.jsonl"
        dest = tmp_path / "in.jsonl"
        dest.write_text(src.read_text())
        # Use the 4th user message (aaa00003) as cut
        result = forge_session(dest, "aaa00003-0000-0000-0000-000000000003", tmp_path)
        assert result.team_forge_result is None

    def test_team_session_auto_derives_team_name(self, tmp_path):
        from cctree.core.forge import forge_session

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        # Make the old team dir exist so it gets copied
        (teams_base / "demo" / "inboxes").mkdir(parents=True)
        (teams_base / "demo" / "config.json").write_text(json.dumps({
            "name": "demo", "leadAgentId": "team-lead@demo",
            "leadSessionId": "old-sess-uuid",
            "members": [
                {"agentId": "team-lead@demo", "name": "team-lead",
                 "agentType": "orch", "subscriptions": []}
            ],
        }))

        sess_path = self._build_team_lead_jsonl(tmp_path)
        result = forge_session(
            sess_path,
            "m3",
            tmp_path,
            teams_base=teams_base,
            tasks_base=tasks_base,
        )
        assert result.team_forge_result is not None
        assert result.team_forge_result.new_team_name.startswith("demo-fork-")
        assert result.team_forge_result.new_team_dir.is_dir()

        # The forged JSONL should have the NEW team name, not "demo"
        forged = result.dest_path.read_text().strip().split("\n")
        for line in forged:
            evt = json.loads(line)
            assert evt.get("teamName") != "demo"
            assert evt.get("teamName", "").startswith("demo-fork-")

    def test_team_session_explicit_team_name(self, tmp_path):
        from cctree.core.forge import forge_session

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        (teams_base / "demo" / "inboxes").mkdir(parents=True)
        (teams_base / "demo" / "config.json").write_text(json.dumps({
            "name": "demo", "leadAgentId": "x@demo",
            "leadSessionId": "old-sess-uuid", "members": [],
        }))

        sess_path = self._build_team_lead_jsonl(tmp_path)
        result = forge_session(
            sess_path,
            "m3",
            tmp_path,
            new_team_name="my-fork",
            teams_base=teams_base,
            tasks_base=tasks_base,
        )
        assert result.team_forge_result.new_team_name == "my-fork"

    def test_team_session_rejects_existing_team_name(self, tmp_path):
        from cctree.core.forge import ForgeError, forge_session

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        (teams_base / "demo" / "inboxes").mkdir(parents=True)
        (teams_base / "demo" / "config.json").write_text(json.dumps({
            "name": "demo", "leadAgentId": "x@demo", "members": [],
        }))
        (teams_base / "my-fork").mkdir()  # collision

        sess_path = self._build_team_lead_jsonl(tmp_path)
        with pytest.raises(ForgeError):
            forge_session(
                sess_path,
                "m3",
                tmp_path,
                new_team_name="my-fork",
                teams_base=teams_base,
                tasks_base=tasks_base,
            )

    def test_three_sequential_forks_no_collision(self, tmp_path):
        """Auto-derivation must avoid collisions on repeated forks."""
        from cctree.core.forge import forge_session

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        (teams_base / "demo" / "inboxes").mkdir(parents=True)
        (teams_base / "demo" / "config.json").write_text(json.dumps({
            "name": "demo", "leadAgentId": "x@demo", "members": [],
        }))

        team_names: set[str] = set()
        for i in range(3):
            sess_path = self._build_team_lead_jsonl(tmp_path, session_id=f"s{i}")
            result = forge_session(
                sess_path,
                "m3",
                tmp_path,
                teams_base=teams_base,
                tasks_base=tasks_base,
            )
            team_names.add(result.team_forge_result.new_team_name)
        assert len(team_names) == 3


class TestCliTeamFork:
    """CLI-level tests for `cctree fork` on team sessions."""

    def _setup_project(self, tmp_path, session_id="old-sess-uuid"):
        """Write a minimal team-lead session JSONL in tmp_path."""
        import os
        import time

        sess_path = tmp_path / f"{session_id}.jsonl"
        events = [
            {"type": "user", "uuid": "m1", "slug": "sluggy",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:10Z",
             "message": {"role": "user", "content": "go"}},
            {"type": "assistant", "uuid": "m2", "parentUuid": "m1",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:20Z",
             "message": {"role": "assistant", "content": "ok"}},
        ]
        with open(sess_path, "w") as f:
            for e in events:
                f.write(json.dumps(e) + "\n")
        # Make the file old so it's not considered "active"
        old_time = time.time() - 300
        os.utime(sess_path, (old_time, old_time))
        return sess_path

    def test_fork_cli_on_team_session_autoderives(self, tmp_path, monkeypatch):
        from click.testing import CliRunner

        from cctree.cli.main import cli

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        (teams_base / "demo" / "inboxes").mkdir(parents=True)
        (teams_base / "demo" / "config.json").write_text(json.dumps({
            "name": "demo", "leadAgentId": "team-lead@demo", "members": [],
        }))

        # Redirect team bases in the forge module
        monkeypatch.setattr(
            "cctree.core.forge.DEFAULT_TEAMS_BASE", teams_base
        )
        monkeypatch.setattr(
            "cctree.core.forge.DEFAULT_TASKS_BASE", tasks_base
        )

        self._setup_project(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "old-sess-uuid",
            "m2",
            "-p", str(tmp_path),
            "--no-launch",
        ])
        assert result.exit_code == 0, result.output
        assert "Team-lead session detected" in result.output
        assert "Team cloned:" in result.output
        assert "demo-fork-" in result.output
        # New team dir exists
        new_team_dirs = [d for d in teams_base.iterdir()
                        if d.is_dir() and d.name != "demo"]
        assert len(new_team_dirs) == 1
        assert new_team_dirs[0].name.startswith("demo-fork-")

    def test_fork_cli_explicit_team_name(self, tmp_path, monkeypatch):
        from click.testing import CliRunner

        from cctree.cli.main import cli

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        (teams_base / "demo" / "inboxes").mkdir(parents=True)
        (teams_base / "demo" / "config.json").write_text(json.dumps({
            "name": "demo", "leadAgentId": "team-lead@demo", "members": [],
        }))

        monkeypatch.setattr(
            "cctree.core.forge.DEFAULT_TEAMS_BASE", teams_base
        )
        monkeypatch.setattr(
            "cctree.core.forge.DEFAULT_TASKS_BASE", tasks_base
        )

        self._setup_project(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "old-sess-uuid",
            "m2",
            "-p", str(tmp_path),
            "--no-launch",
            "--team-name", "my-custom",
        ])
        assert result.exit_code == 0, result.output
        assert "my-custom" in result.output
        assert (teams_base / "my-custom").is_dir()

    def test_fork_cli_team_name_collision_errors(self, tmp_path, monkeypatch):
        from click.testing import CliRunner

        from cctree.cli.main import cli

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        (teams_base / "demo" / "inboxes").mkdir(parents=True)
        (teams_base / "demo" / "config.json").write_text(json.dumps({
            "name": "demo", "leadAgentId": "team-lead@demo", "members": [],
        }))
        (teams_base / "my-custom").mkdir()  # collision

        monkeypatch.setattr(
            "cctree.core.forge.DEFAULT_TEAMS_BASE", teams_base
        )
        monkeypatch.setattr(
            "cctree.core.forge.DEFAULT_TASKS_BASE", tasks_base
        )

        self._setup_project(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "old-sess-uuid",
            "m2",
            "-p", str(tmp_path),
            "--no-launch",
            "--team-name", "my-custom",
        ])
        assert result.exit_code != 0
        assert "Error" in result.output

    def test_fork_cli_non_team_session_regression(self, tmp_path):
        """Forking a non-team session via CLI: output must NOT mention teams."""
        import os
        import shutil
        import time
        from click.testing import CliRunner

        from cctree.cli.main import cli

        src = Path(__file__).parent / "fixtures" / "simple_session.jsonl"
        dest = tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl"
        shutil.copy(src, dest)
        old_time = time.time() - 300
        os.utime(dest, (old_time, old_time))

        runner = CliRunner()
        result = runner.invoke(cli, [
            "fork",
            "sess0001-0000-0000-0000-000000000001",
            "aaa00003-0000-0000-0000-000000000003",
            "-p", str(tmp_path),
            "--no-launch",
        ])
        assert result.exit_code == 0, result.output
        assert "Forged session:" in result.output
        assert "Team-lead session detected" not in result.output
        assert "Team cloned:" not in result.output


class TestNonTeamTaskReplay:
    """Non-team sessions must replay tasks into ~/.claude/tasks/{new_session_id}/."""

    def test_non_team_tasks_replayed_on_fork(self, tmp_path):
        """Fork the with_tasks fixture (non-team) and verify task files are created."""
        from cctree.core.forge import forge_session

        tasks_base = tmp_path / "tasks"
        src = Path(__file__).parent / "fixtures" / "with_tasks.jsonl"
        dest = tmp_path / "in.jsonl"
        dest.write_text(src.read_text())

        # Fork at the last message (ddd00003) — includes TaskCreate x2 + TaskUpdate
        result = forge_session(
            dest,
            "ddd00003-0000-0000-0000-000000000003",
            tmp_path,
            tasks_base=tasks_base,
        )

        task_dir = tasks_base / result.new_session_id
        assert task_dir.is_dir(), "Task dir should be created for non-team fork"
        task_files = sorted(task_dir.glob("*.json"))
        assert len(task_files) == 2

        task1 = json.loads((task_dir / "1.json").read_text())
        assert task1["subject"] == "Phase 1: Setup"
        assert task1["status"] == "completed"  # updated by TaskUpdate in prefix

        task2 = json.loads((task_dir / "2.json").read_text())
        assert task2["subject"] == "Phase 2: Implement"
        assert task2["status"] == "pending"  # never updated — still default

    def test_non_team_tasks_partial_prefix(self, tmp_path):
        """Fork before the TaskUpdate — task 1 should still be pending."""
        from cctree.core.forge import forge_session

        tasks_base = tmp_path / "tasks"
        src = Path(__file__).parent / "fixtures" / "with_tasks.jsonl"
        dest = tmp_path / "in.jsonl"
        dest.write_text(src.read_text())

        # Fork at ddd00002 — only the two TaskCreate events, not the TaskUpdate
        result = forge_session(
            dest,
            "ddd00002-0000-0000-0000-000000000002",
            tmp_path,
            tasks_base=tasks_base,
        )

        task_dir = tasks_base / result.new_session_id
        assert task_dir.is_dir()
        task1 = json.loads((task_dir / "1.json").read_text())
        assert task1["status"] == "pending"  # no update yet

    def test_non_team_no_tasks_no_empty_dir(self, tmp_path):
        """Fork a session with no tasks — no task dir should be created."""
        from cctree.core.forge import forge_session

        tasks_base = tmp_path / "tasks"
        src = Path(__file__).parent / "fixtures" / "simple_session.jsonl"
        dest = tmp_path / "in.jsonl"
        dest.write_text(src.read_text())

        result = forge_session(
            dest,
            "aaa00003-0000-0000-0000-000000000003",
            tmp_path,
            tasks_base=tasks_base,
        )

        task_dir = tasks_base / result.new_session_id
        assert not task_dir.exists(), "No tasks → no task dir should be created"


class TestSubagentCopyOnFork:
    """Agent-tool subagent files must be copied during fork for all session types."""

    def _build_session_with_subagents(self, tmp_path, session_id="old-sess",
                                       team_name=None):
        """Write a session JSONL + Agent-tool subagent files under subagents/.

        Returns the session JSONL path.
        """
        sess_path = tmp_path / f"{session_id}.jsonl"
        events = [
            {"type": "user", "uuid": "m1",
             "sessionId": session_id,
             "timestamp": "2026-04-16T00:00:10Z",
             "message": {"role": "user", "content": "go"}},
            {"type": "assistant", "uuid": "m2", "parentUuid": "m1",
             "sessionId": session_id,
             "timestamp": "2026-04-16T00:00:20Z",
             "message": {"role": "assistant", "content": [
                 {"type": "tool_use", "id": "tu1", "name": "Agent",
                  "input": {"prompt": "explore stuff"}}
             ]}},
            {"type": "progress", "uuid": "p1",
             "sessionId": session_id,
             "parentToolUseID": "tu1",
             "data": {"agentId": "abc123hash"},
             "timestamp": "2026-04-16T00:00:25Z"},
            {"type": "user", "uuid": "m3", "parentUuid": "m2",
             "sessionId": session_id,
             "timestamp": "2026-04-16T00:00:30Z",
             "message": {"role": "user", "content": "thanks"}},
        ]
        if team_name:
            for e in events:
                e["teamName"] = team_name
        with open(sess_path, "w") as f:
            for e in events:
                f.write(json.dumps(e) + "\n")

        # Create Agent-tool subagent files (meta HAS description → not a teammate)
        sub_dir = tmp_path / session_id / "subagents"
        sub_dir.mkdir(parents=True)
        (sub_dir / "agent-abc123hash.meta.json").write_text(
            json.dumps({"agentType": "Explore", "description": "explore stuff"})
        )
        (sub_dir / "agent-abc123hash.jsonl").write_text(
            json.dumps({"type": "user", "uuid": "s1",
                        "sessionId": session_id,
                        "timestamp": "2026-04-16T00:00:22Z",
                        "message": {"role": "user", "content": "exploring"}}) + "\n"
            + json.dumps({"type": "assistant", "uuid": "s2",
                          "parentUuid": "s1",
                          "sessionId": session_id,
                          "timestamp": "2026-04-16T00:00:24Z",
                          "message": {"role": "assistant", "content": "found it"}}) + "\n"
            # Post-fork event (should be filtered out)
            + json.dumps({"type": "user", "uuid": "s3",
                          "parentUuid": "s2",
                          "sessionId": session_id,
                          "timestamp": "2026-04-16T01:00:00Z",
                          "message": {"role": "user", "content": "late"}}) + "\n"
        )
        return sess_path

    def test_non_team_agent_subagents_copied(self, tmp_path):
        """Agent-tool subagent files must be copied when forking a non-team session."""
        from cctree.core.forge import forge_session

        sess_path = self._build_session_with_subagents(tmp_path)
        result = forge_session(sess_path, "m3", tmp_path)

        new_sub = tmp_path / result.new_session_id / "subagents"
        assert new_sub.is_dir(), "Subagents dir should be created"
        assert (new_sub / "agent-abc123hash.jsonl").is_file()
        assert (new_sub / "agent-abc123hash.meta.json").is_file()

        # Events filtered by timestamp — post-fork event dropped
        lines = (new_sub / "agent-abc123hash.jsonl").read_text().strip().split("\n")
        assert len(lines) == 2

    def test_non_team_agent_subagents_uuid_remapped(self, tmp_path):
        """Subagent events should have sessionId remapped to the new session."""
        from cctree.core.forge import forge_session

        sess_path = self._build_session_with_subagents(tmp_path)
        result = forge_session(sess_path, "m3", tmp_path)

        new_sub = tmp_path / result.new_session_id / "subagents"
        lines = (new_sub / "agent-abc123hash.jsonl").read_text().strip().split("\n")
        for line in lines:
            evt = json.loads(line)
            assert evt["sessionId"] == result.new_session_id

    def test_team_fork_also_copies_agent_subagents(self, tmp_path):
        """Team forks must copy Agent-tool subagents too (not just teammates)."""
        from cctree.core.forge import forge_session

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        (teams_base / "demo" / "inboxes").mkdir(parents=True)
        (teams_base / "demo" / "config.json").write_text(json.dumps({
            "name": "demo", "leadAgentId": "x@demo",
            "leadSessionId": "old-sess", "members": [],
        }))

        sess_path = self._build_session_with_subagents(
            tmp_path, team_name="demo"
        )
        result = forge_session(
            sess_path, "m3", tmp_path,
            teams_base=teams_base, tasks_base=tasks_base,
        )

        new_sub = tmp_path / result.new_session_id / "subagents"
        assert (new_sub / "agent-abc123hash.jsonl").is_file(), \
            "Agent-tool subagents must be copied even for team forks"
        assert (new_sub / "agent-abc123hash.meta.json").is_file()

    def test_no_subagents_no_dir_created(self, tmp_path):
        """Session with no subagents dir — fork should not create an empty one."""
        from cctree.core.forge import forge_session

        src = Path(__file__).parent / "fixtures" / "simple_session.jsonl"
        dest = tmp_path / "in.jsonl"
        dest.write_text(src.read_text())

        result = forge_session(
            dest,
            "aaa00003-0000-0000-0000-000000000003",
            tmp_path,
        )

        new_sub = tmp_path / result.new_session_id / "subagents"
        assert not new_sub.exists(), "No subagents → no dir should be created"


class TestRealFormatTaskReplay:
    """Claude Code's real wire format: TaskCreate has no 'id' in input (ID is
    server-assigned and returned in tool_result text), TaskUpdate uses 'taskId'
    not 'id'.  Regression test for the fork-loses-tasks bug."""

    def test_replay_tasks_real_format(self):
        """replay_tasks must handle the real Claude Code format where TaskCreate
        has no id and the server-assigned ID is in the tool_result text."""
        from cctree.core.team_forge import replay_tasks

        prefix_events = [
            # TaskCreate — no 'id' in input
            {
                "type": "assistant",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_1",
                     "name": "TaskCreate",
                     "input": {"subject": "Setup", "description": "set up"}},
                    {"type": "tool_use", "id": "toolu_2",
                     "name": "TaskCreate",
                     "input": {"subject": "Implement", "description": "code"}},
                ]},
            },
            # tool_results with server-assigned IDs
            {
                "type": "user",
                "message": {"role": "user", "content": [
                    {"type": "tool_result", "tool_use_id": "toolu_1",
                     "content": "Task #1 created successfully: Setup"},
                    {"type": "tool_result", "tool_use_id": "toolu_2",
                     "content": "Task #2 created successfully: Implement"},
                ]},
            },
            # TaskUpdate with 'taskId' (not 'id')
            {
                "type": "assistant",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_3",
                     "name": "TaskUpdate",
                     "input": {"taskId": "1", "status": "in_progress"}},
                ]},
            },
        ]
        tasks = replay_tasks(prefix_events)
        assert len(tasks) == 2
        assert tasks["1"]["subject"] == "Setup"
        assert tasks["1"]["status"] == "in_progress"
        assert tasks["2"]["subject"] == "Implement"
        assert tasks["2"]["status"] == "pending"

    def test_replay_tasks_delete_via_status(self):
        """TaskUpdate with status='deleted' should remove the task (matching
        Claude Code's behavior where deleted tasks have no file on disk)."""
        from cctree.core.team_forge import replay_tasks

        prefix_events = [
            {
                "type": "assistant",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_1",
                     "name": "TaskCreate",
                     "input": {"subject": "One"}},
                    {"type": "tool_use", "id": "toolu_2",
                     "name": "TaskCreate",
                     "input": {"subject": "Two"}},
                ]},
            },
            {
                "type": "user",
                "message": {"role": "user", "content": [
                    {"type": "tool_result", "tool_use_id": "toolu_1",
                     "content": "Task #1 created successfully: One"},
                    {"type": "tool_result", "tool_use_id": "toolu_2",
                     "content": "Task #2 created successfully: Two"},
                ]},
            },
            # Delete task 2 via status update
            {
                "type": "assistant",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_3",
                     "name": "TaskUpdate",
                     "input": {"taskId": "2", "status": "deleted"}},
                ]},
            },
        ]
        tasks = replay_tasks(prefix_events)
        assert len(tasks) == 1
        assert "1" in tasks
        assert "2" not in tasks

    def test_real_format_fixture_fork(self, tmp_path):
        """End-to-end: fork the with_tasks_real fixture and verify task files."""
        from cctree.core.forge import forge_session

        tasks_base = tmp_path / "tasks"
        src = Path(__file__).parent / "fixtures" / "with_tasks_real.jsonl"
        dest = tmp_path / "in.jsonl"
        dest.write_text(src.read_text())

        # Fork at last message — includes 3 creates + 1 delete
        result = forge_session(
            dest,
            "eee00005-0000-0000-0000-000000000005",
            tmp_path,
            tasks_base=tasks_base,
        )

        task_dir = tasks_base / result.new_session_id
        assert task_dir.is_dir(), "Task dir should be created"
        task_files = sorted(task_dir.glob("*.json"))
        assert len(task_files) == 2, f"Expected 2 tasks (1,3), got {[f.name for f in task_files]}"

        task1 = json.loads((task_dir / "1.json").read_text())
        assert task1["subject"] == "Phase 1: Setup"
        assert task1["status"] == "pending"

        task3 = json.loads((task_dir / "3.json").read_text())
        assert task3["subject"] == "Phase 3: Test"
        assert task3["status"] == "pending"

        # Task 2 was deleted — no file
        assert not (task_dir / "2.json").exists()

    def test_tool_result_content_as_list(self):
        """tool_result content can be a list of text blocks, not just a string."""
        from cctree.core.team_forge import replay_tasks

        prefix_events = [
            {
                "type": "assistant",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_1",
                     "name": "TaskCreate",
                     "input": {"subject": "Task A"}},
                ]},
            },
            {
                "type": "user",
                "message": {"role": "user", "content": [
                    {"type": "tool_result", "tool_use_id": "toolu_1",
                     "content": [{"type": "text",
                                  "text": "Task #42 created successfully: Task A"}]},
                ]},
            },
        ]
        tasks = replay_tasks(prefix_events)
        assert "42" in tasks
        assert tasks["42"]["subject"] == "Task A"
