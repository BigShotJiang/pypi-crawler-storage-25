"""Tests for message-group navigation — cursor skips continuation lines."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest


FIXTURES = Path(__file__).parent / "fixtures"


async def _load_session_into_tree(pilot, app):
    """Navigate past template items, auto-load the session, focus the tree."""
    from textual.widgets import ListView
    lv = app.query_one("#sessions-pane", ListView)
    # Navigate down until we land on a real session item
    for _ in range(10):
        await pilot.press("down")
        await pilot.pause()
        idx = lv.index if lv.index is not None else 0
        items = list(lv.children)
        if 0 <= idx < len(items):
            name = getattr(items[idx], "name", "")
            if name and not name.startswith("__"):
                break
    # on_list_view_highlighted auto-loads; now focus the tree
    assert app.current_session is not None, "Session should be auto-loaded"
    await pilot.press("right")
    await pilot.pause()


class TestMessageGroupNavigation:
    """Cursor should skip continuation lines and highlight them as a group."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        session_id = "sess-group-0000-0000-000000000000"
        # 200 words → guaranteed to wrap into multiple continuation lines
        long_text = " ".join(["word"] * 200)
        lines = [
            json.dumps({
                "type": "user", "uuid": "u1", "parentUuid": None,
                "message": {"role": "user", "content": long_text},
                "sessionId": session_id, "slug": "group-test",
                "timestamp": "2026-04-01T10:00:00Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "a1", "parentUuid": "u1",
                "message": {"role": "assistant", "content": "Short reply."},
                "sessionId": session_id,
                "timestamp": "2026-04-01T10:00:01Z",
            }),
            json.dumps({
                "type": "user", "uuid": "u2", "parentUuid": "a1",
                "message": {"role": "user", "content": "Second question"},
                "sessionId": session_id,
                "timestamp": "2026-04-01T10:00:02Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "a2", "parentUuid": "u2",
                "message": {"role": "assistant", "content": "Second reply."},
                "sessionId": session_id,
                "timestamp": "2026-04-01T10:00:03Z",
            }),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        old_time = time.time() - 300
        os.utime(tmp_path / f"{session_id}.jsonl", (old_time, old_time))
        return tmp_path

    @pytest.mark.asyncio
    async def test_down_skips_continuation_lines(self, project_dir):
        """Down arrow from a user node should skip over full_text / overflow leaves."""
        from cctree.tui.app import CctreeApp, _CONTINUATION_TYPES
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)
            assert tree.has_focus

            # Navigate from root to first user node
            await pilot.press("down")
            await pilot.pause()

            cursor = tree.cursor_node
            assert cursor is not None and cursor.data is not None
            assert cursor.data.get("type") == "user", (
                f"Expected 'user', got '{cursor.data.get('type')}'"
            )

            # Verify the long message produced continuation children
            cont = [
                c for c in cursor.children
                if c.data and c.data.get("type") in _CONTINUATION_TYPES
            ]
            assert len(cont) > 0, "Fixture message should produce continuation lines"

            # Press down — should skip all continuations
            await pilot.press("down")
            await pilot.pause()

            new_cursor = tree.cursor_node
            assert new_cursor is not None and new_cursor.data is not None
            assert new_cursor.data.get("type") not in _CONTINUATION_TYPES, (
                f"Down should skip continuation; landed on '{new_cursor.data.get('type')}'"
            )

    @pytest.mark.asyncio
    async def test_up_skips_continuation_lines(self, project_dir):
        """Up arrow should skip back over continuation leaves."""
        from cctree.tui.app import CctreeApp, _CONTINUATION_TYPES
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)

            # root → user → (skip continuations) → beyond
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("down")
            await pilot.pause()
            after_down = tree.cursor_node
            assert after_down is not None and after_down.data is not None
            assert after_down.data.get("type") not in _CONTINUATION_TYPES

            # Now press up — should skip back over continuations
            await pilot.press("up")
            await pilot.pause()

            back = tree.cursor_node
            assert back is not None and back.data is not None
            assert back.data.get("type") not in _CONTINUATION_TYPES, (
                f"Up should skip continuation; landed on '{back.data.get('type')}'"
            )

    @pytest.mark.asyncio
    async def test_group_highlight_applied(self, project_dir):
        """When cursor is on a node with continuations, they should be group-highlighted."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)

            # Navigate to first user node (which has continuation children)
            await pilot.press("down")
            await pilot.pause()

            cursor = tree.cursor_node
            assert cursor is not None and cursor.data is not None
            assert cursor.data.get("type") == "user"

            # Group highlight tracking should be populated for continuation children
            assert len(app._group_highlight_children) > 0, (
                "Expected group highlight entries for continuation children"
            )

    @pytest.mark.asyncio
    async def test_group_highlight_cleared_on_move(self, project_dir):
        """Group highlight should clear when cursor moves to a node without continuations."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)

            # root → user (has continuations) → skip to beyond
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("down")
            await pilot.pause()

            cursor = tree.cursor_node
            # If the cursor is on a node with no continuation children,
            # group highlight should be empty
            if cursor and (not cursor.children or not any(
                c.data and c.data.get("type") in ("full_text", "text", "thinking_text", "overflow")
                for c in cursor.children
            )):
                assert len(app._group_highlight_children) == 0, (
                    "Group highlight should be cleared when cursor is on "
                    "a node without continuation children"
                )
