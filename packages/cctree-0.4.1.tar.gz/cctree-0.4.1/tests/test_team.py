"""Tests for cctree.core.team — reading external team state.

External team state lives outside ~/.claude/projects/:
  - ~/.claude/teams/{name}/config.json      — member roster
  - ~/.claude/teams/{name}/inboxes/{m}.json — per-member message log
  - ~/.claude/tasks/{team-name}/{N}.json    — per-task state
"""
from __future__ import annotations

import json

import pytest


def _write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj))


class TestReadTeamConfig:
    def test_missing_dir_returns_none(self, tmp_path):
        from cctree.core.team import read_team_config

        cfg = read_team_config("nonexistent", teams_base=tmp_path)
        assert cfg is None

    def test_valid_config_parses(self, tmp_path):
        from cctree.core.team import read_team_config

        _write(tmp_path / "demo" / "config.json", {
            "name": "demo",
            "description": "A demo team",
            "createdAt": 1776310400404,
            "leadAgentId": "team-lead@demo",
            "leadSessionId": "sess-uuid",
            "members": [
                {
                    "agentId": "team-lead@demo",
                    "name": "team-lead",
                    "agentType": "orchestrator",
                    "model": "claude-opus-4-6",
                    "joinedAt": 1776310400404,
                    "cwd": "/tmp",
                    "subscriptions": [],
                }
            ],
        })

        cfg = read_team_config("demo", teams_base=tmp_path)
        assert cfg is not None
        assert cfg.name == "demo"
        assert cfg.description == "A demo team"
        assert cfg.leadAgentId == "team-lead@demo"
        assert cfg.leadSessionId == "sess-uuid"
        assert len(cfg.members) == 1
        assert cfg.members[0].name == "team-lead"
        assert cfg.members[0].agentType == "orchestrator"
        assert cfg.members[0].model == "claude-opus-4-6"

    def test_corrupt_json_returns_none(self, tmp_path, caplog):
        from cctree.core.team import read_team_config

        (tmp_path / "demo").mkdir()
        (tmp_path / "demo" / "config.json").write_text("not json{")
        cfg = read_team_config("demo", teams_base=tmp_path)
        assert cfg is None

    def test_extra_fields_preserved(self, tmp_path):
        from cctree.core.team import read_team_config

        _write(tmp_path / "demo" / "config.json", {
            "name": "demo",
            "leadAgentId": "x",
            "members": [],
            "futureField": "preserved",
        })
        cfg = read_team_config("demo", teams_base=tmp_path)
        assert cfg is not None
        assert cfg.model_extra is not None
        assert cfg.model_extra.get("futureField") == "preserved"


class TestReadInbox:
    def test_missing_inbox_returns_empty(self, tmp_path):
        from cctree.core.team import read_inbox

        msgs = read_inbox("demo", "alice", teams_base=tmp_path)
        assert msgs == []

    def test_populated_inbox(self, tmp_path):
        from cctree.core.team import read_inbox

        _write(tmp_path / "demo" / "inboxes" / "alice.json", [
            {"from": "team-lead", "text": "start", "timestamp": "2026-04-16T00:00:00Z",
             "summary": "kick off", "read": True},
            {"from": "bob", "text": "ack", "timestamp": "2026-04-16T00:01:00Z",
             "color": "green", "read": False},
        ])
        msgs = read_inbox("demo", "alice", teams_base=tmp_path)
        assert len(msgs) == 2
        # from is a reserved word — verify alias works
        assert msgs[0].from_ == "team-lead"
        assert msgs[0].text == "start"
        assert msgs[0].summary == "kick off"
        assert msgs[0].read is True
        assert msgs[1].from_ == "bob"
        assert msgs[1].color == "green"

    def test_corrupt_inbox_returns_empty(self, tmp_path):
        from cctree.core.team import read_inbox

        (tmp_path / "demo" / "inboxes").mkdir(parents=True)
        (tmp_path / "demo" / "inboxes" / "alice.json").write_text("bad{")
        msgs = read_inbox("demo", "alice", teams_base=tmp_path)
        assert msgs == []


class TestReadAllInboxes:
    def test_missing_dir_returns_empty(self, tmp_path):
        from cctree.core.team import read_all_inboxes

        assert read_all_inboxes("demo", teams_base=tmp_path) == {}

    def test_aggregates_all_member_inboxes(self, tmp_path):
        from cctree.core.team import read_all_inboxes

        _write(tmp_path / "demo" / "inboxes" / "a.json", [
            {"from": "x", "text": "1", "timestamp": "2026-04-16T00:00:00Z", "read": False},
        ])
        _write(tmp_path / "demo" / "inboxes" / "b.json", [
            {"from": "y", "text": "2", "timestamp": "2026-04-16T00:00:00Z", "read": False},
        ])
        all_inboxes = read_all_inboxes("demo", teams_base=tmp_path)
        assert set(all_inboxes.keys()) == {"a", "b"}
        assert len(all_inboxes["a"]) == 1
        assert all_inboxes["a"][0].from_ == "x"


class TestReadTasks:
    def test_missing_dir_returns_empty(self, tmp_path):
        from cctree.core.team import read_tasks

        assert read_tasks("demo", tasks_base=tmp_path) == []

    def test_populated_tasks(self, tmp_path):
        from cctree.core.team import read_tasks

        tasks_dir = tmp_path / "demo"
        tasks_dir.mkdir()
        _write(tasks_dir / "1.json", {
            "id": "1",
            "subject": "research",
            "description": "do research",
            "activeForm": "researching",
            "status": "in_progress",
            "blocks": [],
            "blockedBy": [],
        })
        _write(tasks_dir / "2.json", {
            "id": "2",
            "subject": "write",
            "status": "pending",
        })
        tasks = read_tasks("demo", tasks_base=tmp_path)
        assert len(tasks) == 2
        by_id = {t.id: t for t in tasks}
        assert by_id["1"].subject == "research"
        assert by_id["1"].status == "in_progress"
        assert by_id["2"].status == "pending"

    def test_skips_non_json_files(self, tmp_path):
        from cctree.core.team import read_tasks

        tasks_dir = tmp_path / "demo"
        tasks_dir.mkdir()
        _write(tasks_dir / "1.json", {"id": "1", "subject": "x", "status": "pending"})
        (tasks_dir / ".lock").write_text("")
        (tasks_dir / "README.txt").write_text("not a task")
        tasks = read_tasks("demo", tasks_base=tmp_path)
        assert len(tasks) == 1

    def test_corrupt_task_file_skipped(self, tmp_path):
        from cctree.core.team import read_tasks

        tasks_dir = tmp_path / "demo"
        tasks_dir.mkdir()
        _write(tasks_dir / "1.json", {"id": "1", "subject": "x", "status": "pending"})
        (tasks_dir / "2.json").write_text("bad{")
        tasks = read_tasks("demo", tasks_base=tmp_path)
        assert len(tasks) == 1
        assert tasks[0].id == "1"


class TestPathHelpers:
    def test_team_dir(self, tmp_path):
        from cctree.core.team import team_dir

        p = team_dir("my-team", teams_base=tmp_path)
        assert p == tmp_path / "my-team"

    def test_task_dir(self, tmp_path):
        from cctree.core.team import task_dir

        p = task_dir("my-team", tasks_base=tmp_path)
        assert p == tmp_path / "my-team"
