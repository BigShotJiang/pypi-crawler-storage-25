"""Tests for fork templates — save, load, list, delete, rename, import, usage tracking."""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from cctree.core.templates import (
    TemplateCorruptError,
    TemplateExistsError,
    TemplateNotFoundError,
    delete_template,
    import_from_forks,
    list_templates,
    load_template,
    record_usage,
    rename_template,
    save_template,
    update_fork_point,
    validate_template_name,
)


@pytest.fixture(autouse=True)
def _isolate_cctree_dir(tmp_path, monkeypatch):
    """Redirect CCTREE_DIR and TEMPLATES_DIR to a temp directory for all tests."""
    import cctree.core.templates as tpl_mod
    import cctree.core.metadata as meta_mod

    monkeypatch.setattr(tpl_mod, "CCTREE_DIR", tmp_path)
    monkeypatch.setattr(tpl_mod, "TEMPLATES_DIR", tmp_path / "templates")
    monkeypatch.setattr(meta_mod, "CCTREE_DIR", tmp_path)


PROJECT = "-Users-test-projects-MyProject"


class TestValidateTemplateName:
    def test_valid_names(self):
        assert validate_template_name("refactor-base") == "refactor-base"
        assert validate_template_name("auth_cleanup") == "auth_cleanup"
        assert validate_template_name("my-template-2") == "my-template-2"

    def test_spaces_to_dashes(self):
        assert validate_template_name("my template") == "my-template"

    def test_strips_whitespace(self):
        assert validate_template_name("  foo  ") == "foo"

    def test_empty_name(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            validate_template_name("")

    def test_path_traversal(self):
        with pytest.raises(ValueError, match="Invalid template name"):
            validate_template_name("../../etc/passwd")

    def test_too_long(self):
        with pytest.raises(ValueError, match="Invalid template name"):
            validate_template_name("a" * 101)

    def test_special_chars(self):
        with pytest.raises(ValueError, match="Invalid template name"):
            validate_template_name("foo/bar")


class TestSaveTemplate:
    def test_save_and_load(self):
        path = save_template(
            name="test-tpl",
            project_dir_name=PROJECT,
            source_session_id="sess-123",
            source_message_uuid="msg-456",
            source_display_name="My Session",
        )
        assert path.exists()
        data = json.loads(path.read_text())
        assert data["name"] == "test-tpl"
        assert data["sourceSessionId"] == "sess-123"
        assert data["sourceMessageUuid"] == "msg-456"
        assert data["forkCount"] == 0
        assert data["lastForkedAt"] is None

    def test_name_collision(self):
        save_template("dup", PROJECT, "s1", "m1")
        with pytest.raises(TemplateExistsError, match="already exists"):
            save_template("dup", PROJECT, "s2", "m2")

    def test_invalid_name(self):
        with pytest.raises(ValueError):
            save_template("", PROJECT, "s1", "m1")


class TestLoadTemplate:
    def test_not_found(self):
        with pytest.raises(TemplateNotFoundError, match="not found"):
            load_template("nonexistent", PROJECT)

    def test_corrupt_json(self, tmp_path):
        tpl_dir = tmp_path / "templates" / PROJECT
        tpl_dir.mkdir(parents=True)
        (tpl_dir / "corrupt.json").write_text("{invalid json")
        with pytest.raises(TemplateCorruptError, match="corrupt JSON"):
            load_template("corrupt", PROJECT)

    def test_load_valid(self):
        save_template("loadme", PROJECT, "s1", "m1")
        tpl = load_template("loadme", PROJECT)
        assert tpl["name"] == "loadme"
        assert tpl["sourceSessionId"] == "s1"


class TestListTemplates:
    def test_empty(self):
        assert list_templates(PROJECT) == []

    def test_list_sorted_by_name(self):
        save_template("beta", PROJECT, "s1", "m1")
        save_template("alpha", PROJECT, "s2", "m2")
        save_template("gamma", PROJECT, "s3", "m3")
        result = list_templates(PROJECT, sort_by="name")
        names = [t["name"] for t in result]
        assert names == ["alpha", "beta", "gamma"]

    def test_corrupt_skipped(self, tmp_path):
        save_template("good", PROJECT, "s1", "m1")
        tpl_dir = tmp_path / "templates" / PROJECT
        (tpl_dir / "bad.json").write_text("{broken")
        result = list_templates(PROJECT)
        assert len(result) == 1
        assert result[0]["name"] == "good"

    def test_sort_by_fork_count(self):
        save_template("few", PROJECT, "s1", "m1")
        save_template("many", PROJECT, "s2", "m2")
        # Manually set fork counts
        tpl_dir = Path(save_template("dummy", PROJECT, "s3", "m3")).parent
        delete_template("dummy", PROJECT)

        for name, count in [("few", 1), ("many", 5)]:
            path = tpl_dir / f"{name}.json"
            data = json.loads(path.read_text())
            data["forkCount"] = count
            path.write_text(json.dumps(data))

        result = list_templates(PROJECT, sort_by="fork_count")
        assert result[0]["name"] == "many"
        assert result[1]["name"] == "few"


class TestDeleteTemplate:
    def test_delete(self):
        save_template("del-me", PROJECT, "s1", "m1")
        delete_template("del-me", PROJECT)
        assert list_templates(PROJECT) == []

    def test_delete_not_found(self):
        with pytest.raises(TemplateNotFoundError):
            delete_template("ghost", PROJECT)


class TestRenameTemplate:
    def test_rename(self):
        save_template("old-name", PROJECT, "s1", "m1")
        rename_template("old-name", "new-name", PROJECT)
        result = list_templates(PROJECT)
        assert len(result) == 1
        assert result[0]["name"] == "new-name"

    def test_rename_not_found(self):
        with pytest.raises(TemplateNotFoundError):
            rename_template("ghost", "new", PROJECT)

    def test_rename_collision(self):
        save_template("a", PROJECT, "s1", "m1")
        save_template("b", PROJECT, "s2", "m2")
        with pytest.raises(TemplateExistsError):
            rename_template("a", "b", PROJECT)


class TestRecordUsage:
    def test_increments(self):
        save_template("used", PROJECT, "s1", "m1")
        record_usage("used", PROJECT)
        record_usage("used", PROJECT)
        tpl = load_template("used", PROJECT)
        assert tpl["forkCount"] == 2
        assert tpl["lastForkedAt"] is not None

    def test_missing_template_no_crash(self):
        # Should warn but not crash
        record_usage("gone", PROJECT)


class TestUpdateForkPoint:
    def test_update(self):
        save_template("updatable", PROJECT, "s1", "m1")
        update_fork_point("updatable", PROJECT, "m2", "new preview")
        tpl = load_template("updatable", PROJECT)
        assert tpl["sourceMessageUuid"] == "m2"
        assert tpl["sourceMessagePreview"] == "new preview"

    def test_not_found(self):
        with pytest.raises(TemplateNotFoundError):
            update_fork_point("ghost", PROJECT, "m1")


class TestImportFromForks:
    def test_empty(self):
        result = import_from_forks(PROJECT)
        assert result == []

    def test_discovers_fork_sidecars(self, tmp_path):
        # Create a fake fork sidecar
        proj_dir = tmp_path / "projects" / PROJECT
        proj_dir.mkdir(parents=True)
        sidecar = {
            "forkedFrom": {
                "sessionId": "src-sess",
                "messageId": "src-msg",
                "displayName": "My Source Session",
                "slug": "my-source",
            },
            "forgedAt": "2026-04-15T10:00:00Z",
        }
        (proj_dir / "fork-uuid.meta.json").write_text(json.dumps(sidecar))

        result = import_from_forks(PROJECT)
        assert len(result) == 1
        assert result[0]["sourceSessionId"] == "src-sess"
        assert result[0]["sourceMessageUuid"] == "src-msg"
        assert result[0]["suggestedName"] is not None

    def test_ignores_non_fork_files(self, tmp_path):
        proj_dir = tmp_path / "projects" / PROJECT
        proj_dir.mkdir(parents=True)
        (proj_dir / "other.meta.json").write_text(json.dumps({"notAFork": True}))
        result = import_from_forks(PROJECT)
        assert result == []


class TestForgeExtraction:
    """Verify the extracted forge module works correctly."""

    def test_forge_creates_new_session(self, tmp_path):
        from cctree.core.forge import ForgeError, forge_session

        # Create a minimal source session
        source = tmp_path / "source.jsonl"
        events = [
            {"type": "user", "uuid": "msg-1", "sessionId": "sess-1", "message": {"role": "user", "content": "hello"}},
            {"type": "assistant", "uuid": "msg-2", "sessionId": "sess-1", "parentUuid": "msg-1", "message": {"role": "assistant", "content": "hi"}},
        ]
        source.write_text("\n".join(json.dumps(e) for e in events))

        result = forge_session(source, "msg-2", tmp_path / "dest")
        assert result.dest_path.exists()
        assert result.new_session_id != "sess-1"
        assert result.message_count == 2

        # Verify UUIDs were remapped
        lines = result.dest_path.read_text().strip().split("\n")
        forged = [json.loads(l) for l in lines]
        assert forged[0]["uuid"] != "msg-1"
        assert forged[0]["sessionId"] == result.new_session_id

    def test_forge_message_not_found(self, tmp_path):
        from cctree.core.forge import ForgeError, forge_session

        source = tmp_path / "source.jsonl"
        source.write_text(json.dumps({"type": "user", "uuid": "msg-1", "sessionId": "s1"}))

        with pytest.raises(ForgeError, match="not found"):
            forge_session(source, "nonexistent", tmp_path / "dest")
