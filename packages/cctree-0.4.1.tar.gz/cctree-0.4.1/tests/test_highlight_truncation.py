"""Tests for search highlight preservation through label truncation.

Bug A: _compose_annotated_label strips [reverse] highlights during truncation.
Bug B: _rebuild_user_label missing _escape_markup before _highlight_term.
"""
from __future__ import annotations


# ─── Bug A: Truncation must preserve [reverse] highlights ──────────────────

# Tool column requires total_width >= 40 and has budget of 6 visual cells.
# With total_width=50 and tool_summary present:
#   right_vis ≈ 6, content_max ≈ 43
# So content must be > 43 visual chars to trigger truncation.
_WIDE = 50  # total_width that enables tool column and forces truncation


class TestTruncationPreservesHighlights:
    """Verify _compose_annotated_label preserves [reverse] markup on truncation."""

    def test_highlight_preserved_when_truncated(self):
        """A highlighted term within the truncated portion must keep [reverse]."""
        from cctree.tui.columns import _compose_annotated_label

        content = "User: say [reverse]hello[/reverse] world and this is extra text beyond the limit"
        result = _compose_annotated_label(
            content, "🔧 3", "", total_width=_WIDE,
        )
        assert "…" in result, "Content should have been truncated"
        assert "[reverse]" in result, "Highlight lost during truncation"
        assert "hello" in result

    def test_highlight_at_start_preserved(self):
        """Highlight at the start of content survives truncation."""
        from cctree.tui.columns import _compose_annotated_label

        content = "[reverse]User[/reverse]: this is a long label that will definitely truncate at this width"
        result = _compose_annotated_label(
            content, "🔧 1", "", total_width=_WIDE,
        )
        assert "…" in result, "Content should have been truncated"
        assert "[reverse]" in result

    def test_multiple_highlights_preserved(self):
        """Multiple [reverse] spans within the truncated region all survive."""
        from cctree.tui.columns import _compose_annotated_label

        content = "[reverse]foo[/reverse] bar [reverse]baz[/reverse] extra padding text that is definitely long enough"
        result = _compose_annotated_label(
            content, "🔧 2", "", total_width=_WIDE,
        )
        assert "…" in result, "Content should have been truncated"
        assert result.count("[reverse]") >= 1

    def test_highlight_beyond_truncation_point_omitted(self):
        """Highlight entirely past the truncation point doesn't appear."""
        from cctree.tui.columns import _compose_annotated_label

        # Highlight is far into the text, truncation will cut before it
        content = "User: short text " + "x" * 100 + " [reverse]far[/reverse]"
        result = _compose_annotated_label(
            content, "🔧 1", "", total_width=_WIDE,
        )
        assert "…" in result, "Content should have been truncated"
        assert "[reverse]far[/reverse]" not in result

    def test_partial_highlight_truncated(self):
        """Highlight that gets cut mid-way still wraps the visible portion."""
        from cctree.tui.columns import _compose_annotated_label

        # Put a long highlighted word where truncation will cut through it
        content = "AB " + "[reverse]" + "C" * 80 + "[/reverse]" + " rest"
        result = _compose_annotated_label(
            content, "🔧 1", "", total_width=_WIDE,
        )
        assert "…" in result, "Content should have been truncated"
        assert "[reverse]" in result, (
            "Partial highlight should still be wrapped in [reverse]"
        )

    def test_no_highlight_truncation_unchanged(self):
        """Without highlights, truncation works exactly as before."""
        from cctree.tui.columns import _compose_annotated_label

        content = "User: this is a plain long label without any highlights and it extends past the limit"
        result = _compose_annotated_label(
            content, "🔧 1", "", total_width=_WIDE,
        )
        assert "[reverse]" not in result
        assert "…" in result

    def test_dim_wrapper_preserved_with_highlight(self):
        """[dim] wrapper preserved when content has both [dim] and [reverse]."""
        from cctree.tui.columns import _compose_annotated_label

        content = "[dim]Asst: say [reverse]hello[/reverse] world and this is extra text beyond the limit here[/dim]"
        result = _compose_annotated_label(
            content, "", "████", total_width=60,
        )
        assert "…" in result, "Content should have been truncated"
        assert "[dim]" in result
        assert "[reverse]" in result

    def test_non_truncated_highlight_passthrough(self):
        """Short highlighted content that doesn't need truncation passes through."""
        from cctree.tui.columns import _compose_annotated_label

        content = "[reverse]hi[/reverse]"
        result = _compose_annotated_label(
            content, "", "", total_width=200,
        )
        assert "[reverse]hi[/reverse]" in result


# ─── Bug B: _escape_markup in _rebuild_user_label ──────────────────────────


class TestHighlightEscaping:
    """_highlight_term must receive escaped text to avoid Rich markup injection."""

    def test_highlight_term_on_escaped_text(self):
        """_highlight_term called on escaped text finds matches correctly."""
        from rich.markup import escape as _escape_markup
        from cctree.tui.columns import _highlight_term

        raw_text = "User: check [config] value"
        escaped = _escape_markup(raw_text)
        result = _highlight_term(escaped, _escape_markup("check"))
        assert "[reverse]check[/reverse]" in result
        # Escaped brackets should still be present
        assert "\\[" in result

    def test_highlight_term_on_unescaped_text_has_raw_brackets(self):
        """Without escaping, brackets in text become raw Rich markup — bad."""
        from cctree.tui.columns import _highlight_term

        raw_text = "User: check [config] value"
        result = _highlight_term(raw_text, "check")
        # [config] is raw — Rich will try to interpret it as a tag
        # This test documents the bug: unescaped text + _highlight_term = broken
        assert "[config]" in result  # raw bracket, not escaped
