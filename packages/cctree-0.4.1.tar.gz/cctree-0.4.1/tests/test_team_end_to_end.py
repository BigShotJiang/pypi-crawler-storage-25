"""End-to-end fork → parse roundtrip for team sessions.

Simulates a realistic team-lead session + teammate turn file + team config +
inboxes + tasks in a tmpdir, then forks it via the public API, then reads
back every piece of forked state to verify full structural validity.
"""
from __future__ import annotations

import json
from pathlib import Path


def _build_team_session(tmp_path: Path, session_id: str = "old-sess-uuid"):
    """Create a full team-lead session in tmp_path.

    Layout:
      tmp_path/{session_id}.jsonl
      tmp_path/{session_id}/subagents/agent-a1.{jsonl,meta.json}
      tmp_path/teams/demo/{config.json,inboxes/*}
      tmp_path/tasks/demo/...
    """
    teams_base = tmp_path / "teams"
    tasks_base = tmp_path / "tasks"

    sess_path = tmp_path / f"{session_id}.jsonl"

    # Lead session events with:
    # - TeamCreate
    # - TaskCreate A (pre-fork)
    # - SendMessage to alice
    # - <teammate-message> from alice (the fork point is at this message)
    # - TaskUpdate A (POST fork, should not appear in forked tasks)
    events = [
        {"type": "user", "uuid": "u1", "slug": "team-demo",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:00:10Z", "version": "2.1.77",
         "message": {"role": "user", "content": "do the thing"}},
        {"type": "assistant", "uuid": "a1", "parentUuid": "u1",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:00:20Z",
         "message": {"role": "assistant", "content": [
             {"type": "tool_use", "id": "tu1", "name": "TeamCreate",
              "input": {"team_name": "demo", "description": "demo team"}},
         ]}},
        {"type": "assistant", "uuid": "a2", "parentUuid": "a1",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:00:30Z",
         "message": {"role": "assistant", "content": [
             {"type": "tool_use", "id": "tu2", "name": "TaskCreate",
              "input": {"id": "A", "subject": "research", "status": "pending"}},
         ]}},
        {"type": "assistant", "uuid": "a3", "parentUuid": "a2",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:00:40Z",
         "message": {"role": "assistant", "content": [
             {"type": "tool_use", "id": "tu3", "name": "SendMessage",
              "input": {"to": "alice", "message": "research",
                        "summary": "research"}},
         ]}},
        # Fork point (cut inclusive): alice's reply
        {"type": "user", "uuid": "u2", "parentUuid": "a3",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:01:00Z",
         "message": {"role": "user", "content":
                     '<teammate-message teammate_id="alice" color="blue" summary="Done">\n'
                     "done researching\n</teammate-message>"}},
        # POST-FORK: a TaskUpdate + another teammate message; neither should
        # appear in the forged session.
        {"type": "assistant", "uuid": "a4", "parentUuid": "u2",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:01:30Z",
         "message": {"role": "assistant", "content": [
             {"type": "tool_use", "id": "tu4", "name": "TaskUpdate",
              "input": {"id": "A", "status": "completed"}},
         ]}},
    ]
    with open(sess_path, "w") as f:
        for e in events:
            f.write(json.dumps(e) + "\n")

    # Teammate JSONL for alice (with a pre-fork + post-fork event)
    sub = tmp_path / session_id / "subagents"
    sub.mkdir(parents=True)
    (sub / "agent-a1hash.meta.json").write_text(json.dumps({"agentType": "alice"}))
    (sub / "agent-a1hash.jsonl").write_text(
        json.dumps({"type": "user", "uuid": "ta-u1", "sessionId": session_id,
                    "timestamp": "2026-04-16T00:00:35Z",
                    "message": {"role": "user", "content":
                                '<teammate-message teammate_id="team-lead" summary="Assign">'
                                "research</teammate-message>"}}) + "\n"
        + json.dumps({"type": "assistant", "uuid": "ta-a1", "parentUuid": "ta-u1",
                      "sessionId": session_id,
                      "timestamp": "2026-04-16T00:00:45Z",
                      "message": {"role": "assistant", "content": "on it"}}) + "\n"
        # Post-fork event (should be filtered out)
        + json.dumps({"type": "user", "uuid": "ta-u2", "parentUuid": "ta-a1",
                      "sessionId": session_id,
                      "timestamp": "2026-04-16T00:02:00Z",
                      "message": {"role": "user", "content": "late"}}) + "\n"
    )

    # Team config + inboxes
    (teams_base / "demo" / "inboxes").mkdir(parents=True)
    (teams_base / "demo" / "config.json").write_text(json.dumps({
        "name": "demo",
        "description": "demo team",
        "createdAt": 1776310400000,
        "leadAgentId": "team-lead@demo",
        "leadSessionId": session_id,
        "members": [
            {"agentId": "team-lead@demo", "name": "team-lead",
             "agentType": "orchestrator", "model": "claude-opus-4-6",
             "subscriptions": []},
            {"agentId": "alice@demo", "name": "alice",
             "agentType": "researcher", "model": "claude-sonnet-4-6",
             "subscriptions": []},
        ],
    }))
    (teams_base / "demo" / "inboxes" / "alice.json").write_text(json.dumps([
        {"from": "team-lead", "text": "research",
         "timestamp": "2026-04-16T00:00:30Z", "read": True},
        # Post-fork
        {"from": "team-lead", "text": "late ping",
         "timestamp": "2026-04-16T00:01:30Z", "read": True},
    ]))

    # Fork point: timestamp of u2 = "2026-04-16T00:01:00Z"
    return {
        "session_id": session_id,
        "sess_path": sess_path,
        "teams_base": teams_base,
        "tasks_base": tasks_base,
        "cut_timestamp": "2026-04-16T00:01:00Z",
        "cut_message_uuid": "u2",
    }


class TestEndToEndTeamFork:
    def test_full_fork_roundtrip(self, tmp_path):
        from cctree.core.forge import forge_session
        from cctree.core.parser import parse_jsonl
        from cctree.core.model import Session
        from cctree.core.team import read_all_inboxes, read_tasks, read_team_config

        fx = _build_team_session(tmp_path)

        result = forge_session(
            fx["sess_path"],
            fx["cut_message_uuid"],
            tmp_path,
            teams_base=fx["teams_base"],
            tasks_base=fx["tasks_base"],
        )

        # 1. Forged JSONL exists + parses
        assert result.dest_path.is_file()
        forged_events = parse_jsonl(result.dest_path)
        assert len(forged_events) > 0

        # 2. New session is still a team-lead session, with NEW team name
        forged_session = Session(
            uuid=result.new_session_id,
            project_slug="test",
            path=str(result.dest_path),
            events=forged_events,
        )
        assert forged_session.is_team_lead is True
        new_team = forged_session.team_name
        assert new_team is not None
        assert new_team != "demo"
        assert new_team.startswith("demo-fork-")

        # 3. Team dir was cloned + renamed
        tr = result.team_forge_result
        assert tr is not None
        assert tr.new_team_dir == fx["teams_base"] / new_team
        assert tr.new_team_dir.is_dir()

        # 4. Config was rewritten (name, leadSessionId, leadAgentId, members[].agentId)
        cfg = read_team_config(new_team, teams_base=fx["teams_base"])
        assert cfg is not None
        assert cfg.name == new_team
        assert cfg.leadSessionId == result.new_session_id
        assert cfg.leadAgentId == f"team-lead@{new_team}"
        for m in cfg.members:
            assert m.agentId.endswith(f"@{new_team}")
            # Original "@demo" suffix (exact match) must not survive
            assert not m.agentId.endswith("@demo")

        # 5. Inbox for alice was filtered to only pre-fork messages
        inboxes = read_all_inboxes(new_team, teams_base=fx["teams_base"])
        assert "alice" in inboxes
        assert len(inboxes["alice"]) == 1
        assert inboxes["alice"][0].text == "research"

        # 6. Tasks replayed: task A exists with status "pending" (the post-fork
        #    "completed" TaskUpdate was not in the prefix).
        tasks = read_tasks(new_team, tasks_base=fx["tasks_base"])
        assert len(tasks) == 1
        assert tasks[0].id == "A"
        assert tasks[0].status == "pending"

        # 7. Teammate JSONLs cloned under the forged session's subagents/ dir
        #    (same hash filename, but contents UUID-remapped + timestamp-filtered)
        new_sub_dir = result.dest_path.parent / result.new_session_id / "subagents"
        assert new_sub_dir.is_dir()
        teammate_jsonl = new_sub_dir / "agent-a1hash.jsonl"
        assert teammate_jsonl.is_file()
        meta = json.loads((new_sub_dir / "agent-a1hash.meta.json").read_text())
        assert meta["agentType"] == "alice"

        lines = teammate_jsonl.read_text().strip().split("\n")
        assert len(lines) == 2  # post-fork event dropped
        for line in lines:
            evt = json.loads(line)
            assert evt["sessionId"] == result.new_session_id

        # 8. Original session + team dir untouched
        assert fx["sess_path"].is_file()
        original_events = parse_jsonl(fx["sess_path"])
        original_uuids = {e.uuid for e in original_events if e.uuid}
        forged_uuids = {e.uuid for e in forged_events if e.uuid}
        # Forged should have all-new UUIDs
        assert original_uuids.isdisjoint(forged_uuids)

        original_cfg = read_team_config("demo", teams_base=fx["teams_base"])
        assert original_cfg is not None
        assert original_cfg.name == "demo"
        assert original_cfg.leadSessionId == fx["session_id"]

    def test_regression_non_team_session_unaffected(self, tmp_path):
        """Forking a simple fixture session must work exactly as before —
        no team-related fields appear in the forged JSONL, no team dir created."""
        import os
        import time

        from cctree.core.forge import forge_session
        from cctree.core.parser import parse_jsonl

        src = Path(__file__).parent / "fixtures" / "simple_session.jsonl"
        sess_path = tmp_path / "sess0001-0000-0000-0000-000000000001.jsonl"
        sess_path.write_text(src.read_text())
        old_time = time.time() - 300
        os.utime(sess_path, (old_time, old_time))

        teams_base = tmp_path / "teams"
        tasks_base = tmp_path / "tasks"
        teams_base.mkdir()
        tasks_base.mkdir()

        result = forge_session(
            sess_path,
            "aaa00003-0000-0000-0000-000000000003",
            tmp_path,
            teams_base=teams_base,
            tasks_base=tasks_base,
        )

        # No team result
        assert result.team_forge_result is None

        # No team dir created
        assert list(teams_base.iterdir()) == []
        assert list(tasks_base.iterdir()) == []

        # Parse forged session — should have no teamName field
        for evt in parse_jsonl(result.dest_path):
            assert evt.teamName is None
