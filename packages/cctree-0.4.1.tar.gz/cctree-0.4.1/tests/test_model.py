"""Tests for cctree.core.model — Session metadata derivation and edge cases."""
from __future__ import annotations

from pathlib import Path

from cctree.core.model import Session, SessionEvent, EventType
from cctree.core.parser import parse_jsonl

FIXTURES = Path(__file__).parent / "fixtures"


class TestSession:
    def test_display_name_prefers_custom_title(self):
        events = parse_jsonl(FIXTURES / "titled_session.jsonl")
        session = Session(uuid="sess0003", project_slug="test", path="x", events=events)
        # Last custom-title event wins
        assert session.display_name == "auth-refactor-final"
        assert session.custom_title == "auth-refactor-final"

    def test_display_name_falls_back_to_slug(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        assert session.display_name == "fuzzy-dancing-penguin"

    def test_display_name_falls_back_to_short_uuid(self):
        # A session with no slug and no custom title
        events = [SessionEvent(type="user", uuid="abc12345-xxxx", message={"role": "user", "content": "hi"})]
        session = Session(uuid="abc12345-xxxx-yyyy-zzzz", project_slug="test", path="x", events=events)
        assert session.display_name == "abc12345-xxx"

    def test_message_count(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        assert session.message_count == 4  # 2 user + 2 assistant

    def test_first_user_message(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        assert session.first_user_message == "hello world"

    def test_started_at_and_last_activity(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        assert session.started_at is not None
        assert session.last_activity_at is not None
        assert session.started_at <= session.last_activity_at

    def test_compaction_detected(self):
        events = parse_jsonl(FIXTURES / "compacted_session.jsonl")
        session = Session(uuid="sess0002", project_slug="test", path="x", events=events)
        assert session.has_compaction is True
        assert session.compact_boundary_count == 1

    def test_no_compaction(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        assert session.has_compaction is False
        assert session.compact_boundary_count == 0

    def test_events_before_compact(self):
        events = parse_jsonl(FIXTURES / "compacted_session.jsonl")
        session = Session(uuid="sess0002", project_slug="test", path="x", events=events)
        pre = session.events_before_compact(0)
        # Should include everything before the compact boundary
        types = [e.type for e in pre]
        assert "system" not in types  # boundary itself not included
        assert "user" in types
        assert "assistant" in types
        # Pre-compact messages should be the first 4 message events + snapshot
        assert len(pre) == 5

    def test_events_before_compact_no_compaction_returns_all(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        pre = session.events_before_compact(0)
        assert len(pre) == len(events)

    def test_messages_filter(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        msgs = session.messages()
        assert all(e.is_message for e in msgs)
        assert len(msgs) == 4

    def test_claude_version(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        assert session.claude_version == "2.1.77"

    def test_empty_session(self):
        session = Session(uuid="empty", project_slug="test", path="x", events=[])
        assert session.message_count == 0
        assert session.first_user_message == ""
        assert session.slug is None
        assert session.custom_title is None
        assert session.has_compaction is False
        assert session.display_name == "empty"


class TestSessionEvent:
    def test_is_message(self):
        user = SessionEvent(type="user")
        assistant = SessionEvent(type="assistant")
        system = SessionEvent(type="system")
        assert user.is_message is True
        assert assistant.is_message is True
        assert system.is_message is False

    def test_is_compact_boundary(self):
        boundary = SessionEvent(type="system", subtype="compact_boundary")
        regular_system = SessionEvent(type="system", subtype="init")
        assert boundary.is_compact_boundary is True
        assert regular_system.is_compact_boundary is False

    def test_is_custom_title(self):
        title = SessionEvent(type="custom-title", customTitle="my-session")
        user = SessionEvent(type="user")
        assert title.is_custom_title is True
        assert user.is_custom_title is False

    def test_text_content_string_message(self):
        evt = SessionEvent(type="user", message={"role": "user", "content": "hello"})
        assert evt.text_content == "hello"

    def test_text_content_array_message(self):
        evt = SessionEvent(
            type="assistant",
            message={"role": "assistant", "content": [
                {"type": "text", "text": "part one"},
                {"type": "tool_use", "id": "t1", "name": "Read", "input": {}},
                {"type": "text", "text": "part two"},
            ]},
        )
        assert evt.text_content == "part one\npart two"

    def test_text_content_tool_result_user_message(self):
        """User messages in Claude Code are often tool_result blocks wrapping tool output.
        text_content must extract content from these, not return empty string."""
        evt = SessionEvent(
            type="user",
            message={"role": "user", "content": [
                {"type": "tool_result", "tool_use_id": "toolu_123",
                 "content": "git status output: 3 files changed"},
            ]},
        )
        assert evt.text_content != "", "tool_result user message should not be empty"
        assert "git status" in evt.text_content

    def test_text_content_mixed_text_and_tool_result(self):
        """A user message with both text and tool_result blocks."""
        evt = SessionEvent(
            type="user",
            message={"role": "user", "content": [
                {"type": "tool_result", "tool_use_id": "toolu_123",
                 "content": "command output here"},
                {"type": "text", "text": "looks good, continue"},
            ]},
        )
        assert "command output" in evt.text_content
        assert "looks good" in evt.text_content

    def test_text_content_strips_whitespace_string(self):
        """String content with leading/trailing whitespace should be stripped."""
        evt = SessionEvent(type="user", message={"role": "user", "content": "\n\nhello\n"})
        assert evt.text_content == "hello"

    def test_text_content_strips_whitespace_array(self):
        """Array content blocks with leading/trailing whitespace should be stripped."""
        evt = SessionEvent(
            type="assistant",
            message={"role": "assistant", "content": [
                {"type": "text", "text": "\n\nYes. Point me at the handoff."},
                {"type": "text", "text": "  trailing spaces  "},
            ]},
        )
        assert evt.text_content == "Yes. Point me at the handoff.\ntrailing spaces"

    def test_text_content_strips_whitespace_tool_result(self):
        """tool_result content with leading/trailing whitespace should be stripped."""
        evt = SessionEvent(
            type="user",
            message={"role": "user", "content": [
                {"type": "tool_result", "tool_use_id": "x",
                 "content": "\n  some output\n\n"},
            ]},
        )
        assert evt.text_content == "some output"

    def test_text_content_no_message(self):
        evt = SessionEvent(type="system")
        assert evt.text_content == ""

    def test_tool_use_blocks_empty_for_non_assistant(self):
        evt = SessionEvent(type="user", message={"role": "user", "content": "hi"})
        assert evt.tool_use_blocks == []

    def test_tool_use_blocks_extracted(self):
        evt = SessionEvent(
            type="assistant",
            message={"role": "assistant", "content": [
                {"type": "text", "text": "thinking..."},
                {"type": "tool_use", "id": "t1", "name": "Bash", "input": {"command": "ls"}},
                {"type": "tool_use", "id": "t2", "name": "Read", "input": {"file_path": "/tmp/x"}},
            ]},
        )
        tools = evt.tool_use_blocks
        assert len(tools) == 2
        assert tools[0].name == "Bash"
        assert tools[1].name == "Read"


class TestSessionEventTeamFields:
    """teamName is promoted to a typed optional field (was previously in model_extra)."""

    def test_team_name_typed_field(self):
        evt = SessionEvent(type="assistant", teamName="my-team")
        assert evt.teamName == "my-team"

    def test_team_name_none_when_absent(self):
        evt = SessionEvent(type="assistant")
        assert evt.teamName is None

    def test_team_name_parsed_from_raw(self):
        """Ensure model_validate still picks up teamName from raw dict."""
        evt = SessionEvent.model_validate({"type": "assistant", "teamName": "my-team"})
        assert evt.teamName == "my-team"

    def test_unknown_fields_still_in_model_extra(self):
        """Regression: promoting teamName to typed must not break extra=allow."""
        evt = SessionEvent.model_validate({
            "type": "assistant",
            "teamName": "my-team",
            "someFutureField": "foo",
        })
        assert evt.teamName == "my-team"
        assert evt.model_extra is not None
        assert evt.model_extra.get("someFutureField") == "foo"


class TestSessionTeamLead:
    """Session-level detection of team-lead sessions."""

    def test_team_name_derived_from_events(self):
        events = [
            SessionEvent(type="user", uuid="u1", teamName="my-team",
                         message={"role": "user", "content": "hi"}),
        ]
        session = Session(uuid="s1", project_slug="test", path="x", events=events)
        assert session.team_name == "my-team"
        assert session.is_team_lead is True

    def test_no_team_name_on_regular_session(self):
        events = [
            SessionEvent(type="user", uuid="u1",
                         message={"role": "user", "content": "hi"}),
        ]
        session = Session(uuid="s1", project_slug="test", path="x", events=events)
        assert session.team_name is None
        assert session.is_team_lead is False

    def test_team_name_first_seen_wins(self):
        events = [
            SessionEvent(type="user", uuid="u1", teamName="first",
                         message={"role": "user", "content": "hi"}),
            SessionEvent(type="assistant", uuid="a1", teamName="second",
                         message={"role": "assistant", "content": "ok"}),
        ]
        session = Session(uuid="s1", project_slug="test", path="x", events=events)
        assert session.team_name == "first"

    def test_empty_session_not_team_lead(self):
        session = Session(uuid="empty", project_slug="test", path="x", events=[])
        assert session.team_name is None
        assert session.is_team_lead is False


class TestSessionForkSlug:
    """Fork-suffixed slugs: model-layer override so forked sessions get unique slugs."""

    def test_fork_suffix_applied_to_slug(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x",
                          events=events, fork_suffix="a3b2c1d4")
        assert session.slug == "fuzzy-dancing-penguin-fork-a3b2c1d4"

    def test_fork_suffix_display_name(self):
        """display_name should reflect the suffixed slug."""
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x",
                          events=events, fork_suffix="a3b2c1d4")
        assert session.display_name == "fuzzy-dancing-penguin-fork-a3b2c1d4"

    def test_fork_suffix_custom_title_takes_precedence(self):
        """customTitle still wins over suffixed slug."""
        events = parse_jsonl(FIXTURES / "titled_session.jsonl")
        session = Session(uuid="sess0003", project_slug="test", path="x",
                          events=events, fork_suffix="a3b2c1d4")
        assert session.display_name == "auth-refactor-final"
        # But slug itself is still suffixed
        assert session.slug == "brave-coding-falcon-fork-a3b2c1d4"

    def test_fork_suffix_no_slug_is_noop(self):
        """If session has no slug, fork_suffix has nothing to suffix."""
        events = [SessionEvent(type="user", uuid="u1",
                               message={"role": "user", "content": "hi"})]
        session = Session(uuid="noslugsess", project_slug="test", path="x",
                          events=events, fork_suffix="a3b2c1d4")
        assert session.slug is None
        assert session.display_name == "noslugsess"

    def test_fork_suffix_none_by_default(self):
        """Existing behavior: no fork_suffix means slug is unchanged."""
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)
        assert session.slug == "fuzzy-dancing-penguin"


class TestUsage:
    """Typed Usage model (was previously silently preserved via extra='allow')."""

    def test_usage_parses_from_message(self):
        from cctree.core.model import Message
        msg = Message.model_validate({
            "role": "assistant",
            "content": "hi",
            "model": "claude-opus-4-6",
            "usage": {
                "input_tokens": 3,
                "output_tokens": 120,
                "cache_creation_input_tokens": 5000,
                "cache_read_input_tokens": 10000,
                "service_tier": "standard",
            },
        })
        assert msg.usage is not None
        assert msg.usage.input_tokens == 3
        assert msg.usage.output_tokens == 120
        assert msg.usage.cache_creation_input_tokens == 5000
        assert msg.usage.cache_read_input_tokens == 10000
        assert msg.usage.service_tier == "standard"

    def test_total_input(self):
        from cctree.core.model import Usage
        u = Usage(input_tokens=3, cache_creation_input_tokens=5000,
                  cache_read_input_tokens=10000, output_tokens=120)
        assert u.total_input == 15003

    def test_is_empty_zero(self):
        from cctree.core.model import Usage
        assert Usage().is_empty is True

    def test_is_empty_false_with_output(self):
        from cctree.core.model import Usage
        assert Usage(output_tokens=1).is_empty is False

    def test_is_empty_false_with_input(self):
        from cctree.core.model import Usage
        assert Usage(input_tokens=1).is_empty is False

    def test_usage_extra_allowed(self):
        """Future fields like `inference_geo` must survive the model."""
        from cctree.core.model import Usage
        u = Usage.model_validate({
            "input_tokens": 5,
            "inference_geo": "us-east",
            "new_future_field": 42,
        })
        assert u.input_tokens == 5
        assert u.model_extra is not None
        assert u.model_extra.get("inference_geo") == "us-east"
        assert u.model_extra.get("new_future_field") == 42

    def test_usage_none_when_absent_on_message(self):
        from cctree.core.model import Message
        msg = Message.model_validate({"role": "user", "content": "hi"})
        assert msg.usage is None


class TestWindowSizeForModel:
    """window_size_for_model: deterministic lookup with auto-extend fallback."""

    def test_opus_46_is_1m(self):
        from cctree.core.model import window_size_for_model
        assert window_size_for_model("claude-opus-4-6") == 1_000_000

    def test_sonnet_46_is_1m(self):
        from cctree.core.model import window_size_for_model
        assert window_size_for_model("claude-sonnet-4-6") == 1_000_000

    def test_haiku_is_200k(self):
        from cctree.core.model import window_size_for_model
        assert window_size_for_model("claude-haiku-4-5-20251001") == 200_000

    def test_date_stamped_sonnet_4_is_200k(self):
        from cctree.core.model import window_size_for_model
        assert window_size_for_model("claude-sonnet-4-20250514") == 200_000

    def test_none_defaults_to_200k(self):
        from cctree.core.model import window_size_for_model
        assert window_size_for_model(None) == 200_000

    def test_unknown_model_defaults_to_200k(self):
        from cctree.core.model import window_size_for_model
        assert window_size_for_model("claude-mystery-9") == 200_000

    def test_synthetic_defaults_to_200k(self):
        from cctree.core.model import window_size_for_model
        assert window_size_for_model("<synthetic>") == 200_000

    def test_auto_extend_on_overflow(self):
        """Unknown model with >200K observed usage auto-extends to 1M."""
        from cctree.core.model import window_size_for_model, _observed_overflow
        _observed_overflow.clear()  # isolate this test
        assert window_size_for_model("claude-future-x", observed_total=850_000) == 1_000_000

    def test_auto_extend_cached(self):
        """After first auto-extend, subsequent calls (even without observed_total) use the cached value."""
        from cctree.core.model import window_size_for_model, _observed_overflow
        _observed_overflow.clear()
        window_size_for_model("claude-future-y", observed_total=850_000)
        assert window_size_for_model("claude-future-y") == 1_000_000

    def test_auto_extend_picks_next_common_window(self):
        """observed=2.1M should bump to 2M (or higher if added) — not leave at 1M."""
        from cctree.core.model import window_size_for_model, _observed_overflow
        _observed_overflow.clear()
        size = window_size_for_model("claude-huge-z", observed_total=2_100_000)
        assert size >= 2_100_000

    def test_known_model_never_auto_extended(self):
        """claude-opus-4-6 always returns 1M regardless of observed_total."""
        from cctree.core.model import window_size_for_model
        assert window_size_for_model("claude-opus-4-6", observed_total=9_999_999) == 1_000_000


class TestShortModelName:
    """short_model_name: strips claude- prefix and trailing date suffix."""

    def test_opus_46(self):
        from cctree.core.model import short_model_name
        assert short_model_name("claude-opus-4-6") == "opus-4-6"

    def test_sonnet_46(self):
        from cctree.core.model import short_model_name
        assert short_model_name("claude-sonnet-4-6") == "sonnet-4-6"

    def test_haiku_dated(self):
        from cctree.core.model import short_model_name
        assert short_model_name("claude-haiku-4-5-20251001") == "haiku-4-5"

    def test_synthetic(self):
        from cctree.core.model import short_model_name
        assert short_model_name("<synthetic>") == "synthetic"

    def test_none(self):
        from cctree.core.model import short_model_name
        assert short_model_name(None) == "?"

    def test_empty(self):
        from cctree.core.model import short_model_name
        assert short_model_name("") == "?"

    def test_non_claude_prefix_passthrough(self):
        """Third-party proxy may send non-claude model IDs; don't mangle them."""
        from cctree.core.model import short_model_name
        assert short_model_name("gpt-5-super") == "gpt-5-super"


class TestParseModelParts:
    """_parse_model_parts: splits model ID into (family, version)."""

    def test_opus_46(self):
        from cctree.core.model import _parse_model_parts
        assert _parse_model_parts("claude-opus-4-6") == ("opus", "4.6")

    def test_sonnet_46(self):
        from cctree.core.model import _parse_model_parts
        assert _parse_model_parts("claude-sonnet-4-6") == ("sonnet", "4.6")

    def test_haiku_dated(self):
        from cctree.core.model import _parse_model_parts
        assert _parse_model_parts("claude-haiku-4-5-20251001") == ("haiku", "4.5")

    def test_none(self):
        from cctree.core.model import _parse_model_parts
        assert _parse_model_parts(None) == ("?", "")

    def test_empty(self):
        from cctree.core.model import _parse_model_parts
        assert _parse_model_parts("") == ("?", "")

    def test_synthetic(self):
        from cctree.core.model import _parse_model_parts
        assert _parse_model_parts("<synthetic>") == ("synthetic", "")

    def test_non_claude_with_digits(self):
        """Regex captures digits-only version; non-digit suffix is ignored."""
        from cctree.core.model import _parse_model_parts
        assert _parse_model_parts("gpt-5-super") == ("gpt", "5")


class TestFormatWindow:
    """_format_window: human-friendly token window display."""

    def test_one_million(self):
        from cctree.core.model import _format_window
        assert _format_window(1_000_000) == "1M"

    def test_two_million(self):
        from cctree.core.model import _format_window
        assert _format_window(2_000_000) == "2M"

    def test_200k(self):
        from cctree.core.model import _format_window
        assert _format_window(200_000) == "200K"

    def test_500k(self):
        from cctree.core.model import _format_window
        assert _format_window(500_000) == "500K"

    def test_non_round(self):
        from cctree.core.model import _format_window
        assert _format_window(150_000) == "150K"

    def test_zero(self):
        from cctree.core.model import _format_window
        assert _format_window(0) == "0"


class TestFormatModelBadge:
    """format_model_badge: full Rich-markup badge for user turn labels."""

    def test_opus_1m(self):
        from cctree.core.model import format_model_badge
        result = format_model_badge("claude-opus-4-6", 1_000_000)
        assert result == "[blue]\\[opus 4.6 1M][/blue]"

    def test_sonnet_1m(self):
        from cctree.core.model import format_model_badge
        result = format_model_badge("claude-sonnet-4-6", 1_000_000)
        assert result == "[green]\\[sonnet 4.6 1M][/green]"

    def test_haiku_200k(self):
        from cctree.core.model import format_model_badge
        result = format_model_badge("claude-haiku-4-5-20251001", 200_000)
        assert result == "[bright_yellow]\\[haiku 4.5 200K][/bright_yellow]"

    def test_unknown_model(self):
        from cctree.core.model import format_model_badge
        result = format_model_badge("claude-future-9-0", 200_000)
        assert result == "[dim]\\[future 9.0 200K][/dim]"

    def test_no_window(self):
        from cctree.core.model import format_model_badge
        result = format_model_badge("claude-opus-4-6", 0)
        assert result == "[blue]\\[opus 4.6][/blue]"

    def test_none_returns_empty(self):
        from cctree.core.model import format_model_badge
        assert format_model_badge(None) == ""

    def test_synthetic_returns_empty(self):
        from cctree.core.model import format_model_badge
        assert format_model_badge("<synthetic>") == ""


class TestFormatModelBadgeShort:
    """format_model_badge_short: compact badge for narrow terminals."""

    def test_opus(self):
        from cctree.core.model import format_model_badge_short
        assert format_model_badge_short("claude-opus-4-6") == "[blue]\\[opus][/blue]"

    def test_haiku(self):
        from cctree.core.model import format_model_badge_short
        result = format_model_badge_short("claude-haiku-4-5-20251001")
        assert result == "[bright_yellow]\\[haiku][/bright_yellow]"

    def test_none_returns_empty(self):
        from cctree.core.model import format_model_badge_short
        assert format_model_badge_short(None) == ""

    def test_synthetic_returns_empty(self):
        from cctree.core.model import format_model_badge_short
        assert format_model_badge_short("<synthetic>") == ""


class TestModelBadgeColor:
    """model_badge_color: color lookup by model family."""

    def test_opus_blue(self):
        from cctree.core.model import model_badge_color
        assert model_badge_color("claude-opus-4-6") == "blue"

    def test_sonnet_green(self):
        from cctree.core.model import model_badge_color
        assert model_badge_color("claude-sonnet-4-6") == "green"

    def test_haiku_bright_yellow(self):
        from cctree.core.model import model_badge_color
        assert model_badge_color("claude-haiku-4-5-20251001") == "bright_yellow"

    def test_unknown_dim(self):
        from cctree.core.model import model_badge_color
        assert model_badge_color("claude-future-9-0") == "dim"


class TestImageBlocks:
    """image_blocks property extracts image content blocks from messages."""

    def test_image_blocks_from_user_message(self):
        evt = SessionEvent(
            type="user",
            message={"role": "user", "content": [
                {"type": "text", "text": "here's the screenshot"},
                {"type": "image", "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": "iVBORw0KGgo=",
                }},
            ]},
        )
        images = evt.image_blocks
        assert len(images) == 1
        assert images[0].type == "image"

    def test_no_image_blocks_for_text_only(self):
        evt = SessionEvent(
            type="user",
            message={"role": "user", "content": "hello"},
        )
        assert evt.image_blocks == []

    def test_no_image_blocks_for_tool_use_only(self):
        evt = SessionEvent(
            type="assistant",
            message={"role": "assistant", "content": [
                {"type": "tool_use", "id": "t1", "name": "Read", "input": {}},
            ]},
        )
        assert evt.image_blocks == []

    def test_multiple_image_blocks(self):
        evt = SessionEvent(
            type="user",
            message={"role": "user", "content": [
                {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": "abc="}},
                {"type": "text", "text": "two screenshots"},
                {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": "def="}},
            ]},
        )
        assert len(evt.image_blocks) == 2

    def test_image_block_media_type_accessible(self):
        """Media type is accessible via model_extra since ContentBlock uses extra='allow'."""
        evt = SessionEvent(
            type="user",
            message={"role": "user", "content": [
                {"type": "image", "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": "iVBORw0KGgo=",
                }},
            ]},
        )
        img = evt.image_blocks[0]
        source = img.model_extra.get("source", {})
        assert source.get("media_type") == "image/png"

    def test_no_message_returns_empty(self):
        evt = SessionEvent(type="system")
        assert evt.image_blocks == []
