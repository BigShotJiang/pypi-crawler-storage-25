"""Test that tool input containing Rich markup brackets doesn't crash the TUI tree."""
from __future__ import annotations

import pytest
from rich.markup import escape as rich_escape
from rich.text import Text


class TestMarkupEscapeInTreeLabels:
    """Content with Rich markup syntax like [green], [/dim] must be escaped
    before being wrapped in [dim]...[/dim] tags for Textual Tree labels."""

    def test_unescaped_markup_in_dim_wrapper_crashes(self):
        """Prove the bug: wrapping content that contains [/] in [dim]...[/dim] raises."""
        # This is what the session data looks like — tool input JSON with Rich markup
        line = 'src/auth.py[/]    (yellow)\\n│   │   │   └── [dim]→ class AuthHandler[/]    (dim)'
        label = f"[dim]{line}[/dim]"
        with pytest.raises(Exception):
            Text.from_markup(label)

    def test_escaped_markup_in_dim_wrapper_succeeds(self):
        """After escaping, the same content renders fine inside [dim] tags."""
        line = 'src/auth.py[/]    (yellow)\\n│   │   │   └── [dim]→ class AuthHandler[/]    (dim)'
        escaped = rich_escape(line)
        label = f"[dim]{escaped}[/dim]"
        # Should not raise
        result = Text.from_markup(label)
        assert "src/auth.py" in result.plain

    def test_content_with_square_brackets_but_not_tags(self):
        """Normal bracket content like JSON should also be safe after escaping."""
        line = '{"key": "[value]", "nested": {"a": "[b]"}}'
        escaped = rich_escape(line)
        label = f"[dim]{escaped}[/dim]"
        result = Text.from_markup(label)
        assert '{"key": "[value]"' in result.plain
