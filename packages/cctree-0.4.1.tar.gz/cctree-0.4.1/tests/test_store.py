"""Tests for cctree.core.store — session discovery, lookup, and disambiguation."""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path

import pytest

from cctree.core.store import SessionStore, project_dir_to_slug


class TestProjectDirToSlug:
    def test_synapse(self):
        assert project_dir_to_slug(Path("-Users-tinytim-projects-Synapse")) == "Synapse"

    def test_calchas_redteam(self):
        assert project_dir_to_slug(Path("-Users-tinytim-projects-calchas-redteam")) == "redteam"

    def test_simple_name(self):
        assert project_dir_to_slug(Path("myproject")) == "myproject"

    def test_leading_dashes(self):
        assert project_dir_to_slug(Path("---foo")) == "foo"


class TestSessionStore:
    @pytest.fixture
    def store_dir(self, tmp_path):
        """Create a temp project dir with fixture sessions."""
        fixtures = Path(__file__).parent / "fixtures"
        # Copy fixtures into temp dir with proper UUID filenames
        for src, dest_name in [
            ("simple_session.jsonl", "sess0001-0000-0000-0000-000000000001.jsonl"),
            ("compacted_session.jsonl", "sess0002-0000-0000-0000-000000000002.jsonl"),
            ("titled_session.jsonl", "sess0003-0000-0000-0000-000000000003.jsonl"),
            ("with_tasks.jsonl", "sess0004-0000-0000-0000-000000000004.jsonl"),
        ]:
            src_path = fixtures / src
            dest_path = tmp_path / dest_name
            dest_path.write_text(src_path.read_text())
        return tmp_path

    @pytest.fixture
    def store(self, store_dir):
        return SessionStore(project_dir=store_dir)

    def test_discovers_all_sessions(self, store):
        assert len(store.sessions) == 4

    def test_list_sessions_sorted_by_activity(self, store):
        sessions = store.list_sessions(limit=10)
        # All sessions should be returned
        assert len(sessions) == 4
        # Should be sorted by last_activity descending
        for i in range(len(sessions) - 1):
            if sessions[i].last_activity_at and sessions[i + 1].last_activity_at:
                assert sessions[i].last_activity_at >= sessions[i + 1].last_activity_at

    def test_list_sessions_respects_limit(self, store):
        sessions = store.list_sessions(limit=2)
        assert len(sessions) == 2

    def test_get_by_uuid(self, store):
        s = store.get("sess0001-0000-0000-0000-000000000001")
        assert s is not None
        assert s.slug == "fuzzy-dancing-penguin"

    def test_get_nonexistent_returns_none(self, store):
        assert store.get("nonexistent-uuid") is None

    def test_resolve_by_uuid(self, store):
        s = store.resolve("sess0001-0000-0000-0000-000000000001")
        assert s.slug == "fuzzy-dancing-penguin"

    def test_resolve_by_slug(self, store):
        s = store.resolve("fuzzy-dancing-penguin")
        assert s.uuid == "sess0001-0000-0000-0000-000000000001"

    def test_resolve_by_custom_title(self, store):
        s = store.resolve("auth-refactor-final")
        assert s.uuid == "sess0003-0000-0000-0000-000000000003"

    def test_resolve_not_found_raises(self, store):
        with pytest.raises(ValueError, match="not found"):
            store.resolve("nonexistent-identifier")

    def test_resolve_ambiguous_raises(self, store_dir):
        """Two non-fork sessions with the same slug should raise ValueError."""
        # Create a 5th session with the same slug as session 1
        dup = store_dir / "sess0005-0000-0000-0000-000000000005.jsonl"
        dup.write_text(json.dumps({
            "type": "user", "uuid": "dup1", "parentUuid": None,
            "message": {"role": "user", "content": "duplicate slug"},
            "sessionId": "sess0005-0000-0000-0000-000000000005",
            "slug": "fuzzy-dancing-penguin",
            "timestamp": "2026-04-01T12:00:00.000Z",
        }) + "\n")
        store = SessionStore(project_dir=store_dir)
        with pytest.raises(ValueError, match="Ambiguous"):
            store.resolve("fuzzy-dancing-penguin")

    def test_resolve_fork_no_ambiguity(self, store_dir, monkeypatch):
        """A forked session with metadata gets a suffixed slug — no ambiguity."""
        import cctree.core.metadata as metadata_mod
        import cctree.core.store as store_mod

        # Point metadata sidecar dir to temp
        cctree_dir = store_dir.parent / ".cctree"
        monkeypatch.setattr(metadata_mod, "CCTREE_DIR", cctree_dir)

        # Create a fork session with same JSONL slug as session 1
        fork_uuid = "fork0005-0000-0000-0000-000000000005"
        fork_file = store_dir / f"{fork_uuid}.jsonl"
        fork_file.write_text(json.dumps({
            "type": "user", "uuid": "dup1", "parentUuid": None,
            "message": {"role": "user", "content": "forked session"},
            "sessionId": fork_uuid,
            "slug": "fuzzy-dancing-penguin",
            "timestamp": "2026-04-01T12:00:00.000Z",
        }) + "\n")

        # Write fork metadata sidecar (store_dir.name is the project slug)
        project_slug = store_mod.project_dir_to_slug(store_dir)
        meta_dir = cctree_dir / "projects" / project_slug
        meta_dir.mkdir(parents=True)
        meta_file = meta_dir / f"{fork_uuid}.meta.json"
        meta_file.write_text(json.dumps({"forkedFrom": {"sessionId": "sess0001"}}))

        store = SessionStore(project_dir=store_dir)

        # Original slug resolves to original session
        original = store.resolve("fuzzy-dancing-penguin")
        assert original.uuid == "sess0001-0000-0000-0000-000000000001"

        # Fork resolves by its suffixed slug
        fork = store.resolve("fuzzy-dancing-penguin-fork-fork0005")
        assert fork.uuid == fork_uuid

    def test_resolve_fork_slug_unique_per_fork(self, store_dir, monkeypatch):
        """Multiple forks of the same session each get distinct suffixed slugs."""
        import cctree.core.metadata as metadata_mod
        import cctree.core.store as store_mod

        cctree_dir = store_dir.parent / ".cctree"
        monkeypatch.setattr(metadata_mod, "CCTREE_DIR", cctree_dir)
        project_slug = store_mod.project_dir_to_slug(store_dir)
        meta_dir = cctree_dir / "projects" / project_slug
        meta_dir.mkdir(parents=True)

        # Create two forks with same JSONL slug
        for i, fork_id in enumerate(["forkAAAA-0000-0000-0000-00000000000A",
                                      "forkBBBB-0000-0000-0000-00000000000B"]):
            f = store_dir / f"{fork_id}.jsonl"
            f.write_text(json.dumps({
                "type": "user", "uuid": f"dup{i}", "parentUuid": None,
                "message": {"role": "user", "content": f"fork {i}"},
                "sessionId": fork_id,
                "slug": "fuzzy-dancing-penguin",
                "timestamp": "2026-04-01T12:00:00.000Z",
            }) + "\n")
            (meta_dir / f"{fork_id}.meta.json").write_text(
                json.dumps({"forkedFrom": {"sessionId": "sess0001"}}))

        store = SessionStore(project_dir=store_dir)

        # Each fork has a distinct slug
        fork_a = store.resolve("fuzzy-dancing-penguin-fork-forkAAAA")
        fork_b = store.resolve("fuzzy-dancing-penguin-fork-forkBBBB")
        assert fork_a.uuid == "forkAAAA-0000-0000-0000-00000000000A"
        assert fork_b.uuid == "forkBBBB-0000-0000-0000-00000000000B"

        # Original still resolves cleanly
        original = store.resolve("fuzzy-dancing-penguin")
        assert original.uuid == "sess0001-0000-0000-0000-000000000001"

    def test_is_active_recent_file(self, store_dir):
        """A file modified in the last 60s should be considered active."""
        store = SessionStore(project_dir=store_dir)
        # Touch the first session file to make it "active"
        target = store_dir / "sess0001-0000-0000-0000-000000000001.jsonl"
        target.touch()
        assert store.is_active("sess0001-0000-0000-0000-000000000001") is True

    def test_is_active_old_file(self, store_dir):
        """A file not recently modified should not be considered active."""
        store = SessionStore(project_dir=store_dir)
        target = store_dir / "sess0001-0000-0000-0000-000000000001.jsonl"
        # Set mtime to 5 minutes ago
        old_time = time.time() - 300
        os.utime(target, (old_time, old_time))
        assert store.is_active("sess0001-0000-0000-0000-000000000001") is False

    def test_non_jsonl_files_ignored(self, store_dir):
        """Non-.jsonl files in the project dir should be ignored."""
        (store_dir / "readme.txt").write_text("not a session")
        (store_dir / "data.json").write_text("{}")
        store = SessionStore(project_dir=store_dir)
        assert len(store.sessions) == 4  # Only the .jsonl fixtures

    def test_empty_project_dir(self, tmp_path):
        store = SessionStore(project_dir=tmp_path)
        assert len(store.sessions) == 0
        assert store.list_sessions() == []
