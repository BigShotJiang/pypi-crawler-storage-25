"""TUI tests for team-lead session rendering.

Covers:
  - Session header shows team name for team-lead sessions
  - User messages containing <teammate-message> tags render as distinct nodes
  - SendMessage / TeamCreate / TeamDelete tools use team icons
  - Lazy-loaded Teammates subtree at the bottom of the session tree
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest


def _walk_labels(node) -> list[str]:
    """Flatten the tree into a list of stringified labels."""
    out: list[str] = []
    out.append(str(node.label))
    for child in node.children:
        out.extend(_walk_labels(child))
    return out


def _write_session(path: Path, events: list[dict]) -> None:
    with open(path, "w") as f:
        for evt in events:
            f.write(json.dumps(evt) + "\n")
    old_time = time.time() - 300
    os.utime(path, (old_time, old_time))


@pytest.fixture
def team_project(tmp_path):
    """Team-lead session with TeamCreate, SendMessage, teammate-messages,
    and one teammate turn file under subagents/."""
    session_id = "sess0100-0000-0000-0000-000000000001"
    sess_path = tmp_path / f"{session_id}.jsonl"

    events = [
        {"type": "user", "uuid": "u1", "sessionId": session_id,
         "slug": "team-demo", "teamName": "demo",
         "timestamp": "2026-04-16T00:00:10Z", "version": "2.1.77",
         "message": {"role": "user", "content": "kick off the team"}},
        # TeamCreate tool use
        {"type": "assistant", "uuid": "a1", "parentUuid": "u1",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:00:20Z",
         "message": {"role": "assistant", "content": [
             {"type": "text", "text": "creating the team"},
             {"type": "tool_use", "id": "tu1", "name": "TeamCreate",
              "input": {"team_name": "demo", "description": "a demo"}},
         ]}},
        # SendMessage tool use
        {"type": "assistant", "uuid": "a2", "parentUuid": "a1",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:00:30Z",
         "message": {"role": "assistant", "content": [
             {"type": "tool_use", "id": "tu2", "name": "SendMessage",
              "input": {"to": "alice", "message": "please research",
                        "summary": "research task"}},
         ]}},
        # Teammate-message back from alice
        {"type": "user", "uuid": "u2", "parentUuid": "a2",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:00:40Z",
         "message": {"role": "user", "content":
                     '<teammate-message teammate_id="alice" color="blue" summary="Report">\n'
                     "researched: found 5 options\n"
                     "</teammate-message>"}},
        # TeamDelete
        {"type": "assistant", "uuid": "a3", "parentUuid": "u2",
         "sessionId": session_id, "teamName": "demo",
         "timestamp": "2026-04-16T00:00:50Z",
         "message": {"role": "assistant", "content": [
             {"type": "tool_use", "id": "tu3", "name": "TeamDelete", "input": {}},
         ]}},
    ]
    _write_session(sess_path, events)

    # Add a teammate session file (alice)
    sub = tmp_path / session_id / "subagents"
    sub.mkdir(parents=True)
    (sub / "agent-alicehash.meta.json").write_text(json.dumps({"agentType": "alice"}))
    (sub / "agent-alicehash.jsonl").write_text(
        json.dumps({"type": "user", "uuid": "ta1", "sessionId": session_id,
                    "timestamp": "2026-04-16T00:00:35Z",
                    "message": {"role": "user", "content":
                                '<teammate-message teammate_id="team-lead" summary="Assign">'
                                'please research</teammate-message>'}}) + "\n"
        + json.dumps({"type": "assistant", "uuid": "ta2", "parentUuid": "ta1",
                      "sessionId": session_id,
                      "timestamp": "2026-04-16T00:00:38Z",
                      "message": {"role": "assistant", "content": "on it"}}) + "\n"
    )
    return tmp_path, session_id


class TestTeamHeader:
    @pytest.mark.asyncio
    async def test_header_includes_team_name(self, team_project):
        from textual.widgets import Static

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = team_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            header = app.query_one("#session-header", Static)
            assert "team: demo" in str(header.render()).lower()

    @pytest.mark.asyncio
    async def test_header_omits_team_for_non_team(self, tmp_path):
        from textual.widgets import Static

        from cctree.tui.app import CctreeApp

        # Use the simple fixture
        src = Path(__file__).parent / "fixtures" / "simple_session.jsonl"
        session_id = "sess0001-0000-0000-0000-000000000001"
        dest = tmp_path / f"{session_id}.jsonl"
        dest.write_text(src.read_text())
        old_time = time.time() - 300
        os.utime(dest, (old_time, old_time))

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            header = app.query_one("#session-header", Static)
            assert "team:" not in str(header.render()).lower()


class TestTeammateMessageRender:
    @pytest.mark.asyncio
    async def test_teammate_message_rendered_as_distinct_node(self, team_project):
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = team_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)
            # Should contain a teammate-message indicator (💬 or alice) separated
            # from the raw <teammate-message> string
            assert "alice" in joined
            # The raw tag syntax should NOT appear as leaf text
            assert "<teammate-message" not in joined


class TestTeamToolIcons:
    @pytest.mark.asyncio
    async def test_team_tools_have_team_icon(self, team_project):
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = team_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)
            # TeamCreate, SendMessage, TeamDelete each render with a team/message icon
            assert "TeamCreate" in joined
            assert "SendMessage" in joined
            assert "TeamDelete" in joined


class TestTeammateSubtree:
    @pytest.mark.asyncio
    async def test_teammates_section_present_for_team_lead(self, team_project):
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = team_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)
            # A "Teammates" section or at least a reference to alice's timeline
            # The word "alice" appears because she was referenced; we also expect
            # the top-level Teammates label
            assert "Teammates" in joined or "teammates" in joined

    @pytest.mark.asyncio
    async def test_teammates_section_absent_for_non_team(self, tmp_path):
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        src = Path(__file__).parent / "fixtures" / "simple_session.jsonl"
        session_id = "sess0001-0000-0000-0000-000000000001"
        dest = tmp_path / f"{session_id}.jsonl"
        dest.write_text(src.read_text())
        old_time = time.time() - 300
        os.utime(dest, (old_time, old_time))

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)
            assert "Teammates" not in joined

    @pytest.mark.asyncio
    async def test_teammate_subtree_lazy_loads(self, team_project):
        """Opening the teammate subtree should parse the teammate JSONL only
        on expand (mirror of the existing subagent lazy-load test)."""
        from unittest.mock import patch

        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = team_project

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            # Patch parse_jsonl inside the tui module to count calls to teammate JSONLs.
            import cctree.tui.app as app_mod
            original = app_mod.parse_jsonl
            call_log = []

            def wrapped(path):
                call_log.append(Path(path).name)
                return original(path)

            with patch.object(app_mod, "parse_jsonl", side_effect=wrapped):
                session = app.store.get(session_id)
                app.load_session(session)
                await pilot.pause()
                # Teammate JSONL should NOT be parsed yet
                assert not any("alicehash" in n for n in call_log)


class TestMultipleTeammateBlocks:
    """A single user event whose content contains multiple <teammate-message>
    blocks must render one tree node per block."""

    @pytest.mark.asyncio
    async def test_multiple_blocks_produce_multiple_nodes(self, tmp_path):
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        session_id = "sess0200-0000-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"
        events = [
            {"type": "user", "uuid": "u1", "sessionId": session_id,
             "teamName": "demo", "slug": "x", "version": "2.1.77",
             "timestamp": "2026-04-16T00:00:10Z",
             "message": {"role": "user", "content": "kick off"}},
            # One user event with THREE teammate-message blocks
            {"type": "user", "uuid": "u2", "parentUuid": "u1",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:20Z",
             "message": {"role": "user", "content":
                         '<teammate-message teammate_id="alice" color="blue" summary="A1">'
                         "first</teammate-message>\n"
                         '<teammate-message teammate_id="bob" color="green" summary="B1">'
                         "second</teammate-message>\n"
                         '<teammate-message teammate_id="carol" summary="C1">'
                         "third</teammate-message>"}},
        ]
        _write_session(sess_path, events)

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)
            # All three teammate names appear distinctly
            for name in ("alice", "bob", "carol"):
                assert name in joined
            # And the raw tag string should not leak
            assert "<teammate-message" not in joined


class TestProtocolMessageIcons:
    """Structured JSON protocol messages inside <teammate-message> bodies
    must render with distinct icons (not as plain text previews)."""

    @pytest.mark.asyncio
    async def test_idle_notification_renders_with_icon(self, tmp_path):
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        session_id = "sess0201-0000-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"
        events = [
            {"type": "user", "uuid": "u1", "sessionId": session_id,
             "teamName": "demo", "slug": "x", "version": "2.1.77",
             "timestamp": "2026-04-16T00:00:10Z",
             "message": {"role": "user", "content": "go"}},
            {"type": "user", "uuid": "u2", "parentUuid": "u1",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:20Z",
             "message": {"role": "user", "content":
                         '<teammate-message teammate_id="alice" color="blue">\n'
                         '{"type":"idle_notification","from":"alice",'
                         '"timestamp":"2026-04-16T00:00:20Z","idleReason":"available"}\n'
                         "</teammate-message>"}},
        ]
        _write_session(sess_path, events)

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)
            # Icon + protocol type should appear; raw JSON should not dominate the label
            assert "🔕" in joined
            assert "idle_notification" in joined

    @pytest.mark.asyncio
    async def test_shutdown_and_approval_icons(self, tmp_path):
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        session_id = "sess0202-0000-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"
        events = [
            {"type": "user", "uuid": "u1", "sessionId": session_id,
             "teamName": "demo", "slug": "x", "version": "2.1.77",
             "timestamp": "2026-04-16T00:00:10Z",
             "message": {"role": "user", "content": "go"}},
            {"type": "user", "uuid": "u2", "parentUuid": "u1",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:20Z",
             "message": {"role": "user", "content":
                         '<teammate-message teammate_id="alice">\n'
                         '{"type":"shutdown_approved","from":"alice",'
                         '"requestId":"r1","timestamp":"2026-04-16T00:00:20Z"}\n'
                         "</teammate-message>\n"
                         '<teammate-message teammate_id="bob">\n'
                         '{"type":"plan_approval_request","from":"bob","requestId":"r2"}\n'
                         "</teammate-message>\n"
                         '<teammate-message teammate_id="carol">\n'
                         '{"type":"teammate_terminated","from":"carol"}\n'
                         "</teammate-message>"}},
        ]
        _write_session(sess_path, events)

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)
            assert "⏻" in joined  # shutdown_approved icon
            assert "📋" in joined  # plan_approval_request icon
            assert "💤" in joined  # teammate_terminated icon


class TestMarkupEscapeInTeammateContent:
    """Regression against Rich MarkupError. If teammate body contains [/], it must not crash."""

    @pytest.mark.asyncio
    async def test_teammate_body_with_brackets_does_not_crash(self, tmp_path):
        from cctree.tui.app import CctreeApp

        session_id = "sess0101-0000-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"
        events = [
            {"type": "user", "uuid": "u1", "sessionId": session_id,
             "teamName": "demo", "slug": "x", "version": "2.1.77",
             "timestamp": "2026-04-16T00:00:10Z",
             "message": {"role": "user", "content": "kick off"}},
            {"type": "user", "uuid": "u2", "parentUuid": "u1",
             "sessionId": session_id, "teamName": "demo",
             "timestamp": "2026-04-16T00:00:20Z",
             "message": {"role": "user", "content":
                         '<teammate-message teammate_id="alice" color="blue">\n'
                         "I saw [/] and [dim]markup[/] in the file.\n"
                         "</teammate-message>"}},
        ]
        _write_session(sess_path, events)

        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()
            # No exception means markup escape worked
            assert app.is_running
