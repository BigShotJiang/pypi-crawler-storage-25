# cctree

Personal Claude Code session browser, fork-from-message tool, and history navigator.

## Status

Phase 0: scaffolded. Implementation pending `/plan-eng-review`.

## What it does

`cctree` reads your existing Claude Code session JSONL files in `~/.claude/projects/` and gives you what the built-in TUI doesn't:

- **Browse all sessions** across all projects, including ones the resume picker hides (50-cap, custom-titled, etc.)
- **Read pre-compaction history** that the TUI stops showing after `/compact` (the data is in the JSONL — we just render it)
- **Hierarchical navigation** of tool calls and subagent transcripts (collapsible, drillable)
- **Task evolution scrubbing** — watch your task list change over the course of a session
- **Fork from any message** — not just the session HEAD like `claude --fork-session` — start a fresh Claude Code session from any historical point in any conversation
- **Search** across all sessions by keyword/phrase
- **Tags, stars, custom names** in a local SQLite metadata layer

Phase 1 ships a CLI. Phase 2 adds a Textual TUI sharing the same core.

## Why

The Claude Code TUI access layer has gaps tracked in [#27242](https://github.com/anthropics/claude-code/issues/27242) and related issues. The data layer is intact — JSONLs are append-only and crash-safe — but the TUI doesn't expose it. `cctree` is the missing reading lamp.

See `docs/ceo-plan.md` for the full strategic plan and rationale.

## Install

```bash
pipx install -e ~/projects/cctree
```

## Layout

```
cctree/
├── pyproject.toml
├── README.md
├── cctree/
│   ├── __init__.py
│   ├── core/         # JSONL parser, model, tree, forge, tasks, search, export
│   ├── cli/          # Phase 1 — Click-based subcommands
│   └── storage/      # SQLite metadata layer
├── tests/
└── docs/
    └── ceo-plan.md   # Full CEO plan from /plan-ceo-review
```

## License

Personal use.
