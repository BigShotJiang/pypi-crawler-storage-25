"""cctree CLI — Claude Code session browser and fork tool."""
from __future__ import annotations

import sys
from pathlib import Path

import click

from ..core.store import SessionStore


def get_store(project: str | None, all_projects: bool) -> SessionStore:
    """Create a SessionStore from CLI options."""
    if all_projects:
        return SessionStore(all_projects=True)
    if project:
        return SessionStore(project_dir=Path(project))
    return SessionStore()


@click.group()
@click.version_option(package_name="cctree")
def cli() -> None:
    """cctree — Claude Code session browser, history navigator, and fork tool."""
    pass


@cli.command("ui")
@click.option("--project", "-p", default=None, help="Project directory path")
@click.option("--all-projects", "-a", is_flag=True, help="Scan all Claude Code projects")
def ui(project: str | None, all_projects: bool) -> None:
    """Launch the interactive TUI session browser."""
    import os
    from ..tui.app import CctreeApp
    app = CctreeApp(project_dir=project, all_projects=all_projects)
    result = app.run()
    if isinstance(result, dict) and "resume_session_id" in result:
        os.execvp("claude", ["claude", "--resume", result["resume_session_id"]])


@cli.command("list")
@click.option("--project", "-p", default=None, help="Project directory path")
@click.option("--all-projects", "-a", is_flag=True, help="Scan all Claude Code projects")
@click.option("--limit", "-n", default=50, help="Max sessions to show")
@click.option("--show-uuid", is_flag=True, help="Show full UUIDs")
def list_sessions(project: str | None, all_projects: bool, limit: int, show_uuid: bool) -> None:
    """List Claude Code sessions, sorted by last activity."""
    try:
        from rich.console import Console
        from rich.table import Table

        store = get_store(project, all_projects)
        sessions = store.list_sessions(limit=limit)

        if not sessions:
            click.echo("No sessions found.")
            return

        console = Console()
        table = Table(show_header=True, header_style="bold")
        if show_uuid:
            table.add_column("UUID", style="dim")
        table.add_column("Name", style="cyan")
        table.add_column("Msgs", justify="right")
        table.add_column("Project", style="green")
        table.add_column("Last Activity")
        table.add_column("Compact", justify="center")

        for s in sessions:
            last = s.last_activity_at.strftime("%Y-%m-%d %H:%M") if s.last_activity_at else "—"
            compact = "●" if s.has_compaction else ""
            row = []
            if show_uuid:
                row.append(s.uuid)
            row.extend([
                s.display_name,
                str(s.message_count),
                s.project_slug,
                last,
                compact,
            ])
            table.add_row(*row)

        console.print(table)
        console.print(f"\n[dim]{len(sessions)} sessions shown (of {len(store.sessions)} total)[/dim]")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command("show")
@click.argument("identifier")
@click.option("--project", "-p", default=None, help="Project directory path")
@click.option("--all-projects", "-a", is_flag=True, help="Scan all projects")
@click.option("--depth", "-d", default=1, type=int, help="Content depth: 0=text only, 1=+tool summaries, 2=+tool inputs, 3=+tool outputs")
@click.option("--before-compact", "-b", default=None, type=int, help="Show messages before Nth compaction (0=most recent)")
def show_session(identifier: str, project: str | None, all_projects: bool, depth: int, before_compact: int | None) -> None:
    """Show a session transcript."""
    try:
        from rich.console import Console
        from rich.markdown import Markdown
        from rich.panel import Panel
        from rich.text import Text

        store = get_store(project, all_projects)
        session = store.resolve(identifier)

        console = Console()
        console.print(Panel(
            f"[bold]{session.display_name}[/bold]\n"
            f"UUID: {session.uuid}\n"
            f"Slug: {session.slug or '—'}\n"
            f"Messages: {session.message_count}\n"
            f"Compactions: {session.compact_boundary_count}\n"
            f"Claude: {session.claude_version or '—'}",
            title="Session",
        ))

        events = (
            session.events_before_compact(before_compact)
            if before_compact is not None
            else session.events
        )

        for evt in events:
            if evt.type == "user":
                console.print(f"\n[bold blue]{'─' * 60}[/bold blue]")
                console.print(f"[bold blue]User[/bold blue]  [dim]{evt.timestamp or ''}[/dim]")
                console.print(evt.text_content)

            elif evt.type == "assistant":
                console.print(f"\n[bold green]{'─' * 60}[/bold green]")
                console.print(f"[bold green]Assistant[/bold green]  [dim]{evt.timestamp or ''}[/dim]")

                if depth >= 1 and evt.tool_use_blocks:
                    for tool in evt.tool_use_blocks:
                        console.print(f"  [yellow]🔧 {tool.name}[/yellow]", end="")
                        if depth >= 2 and tool.input:
                            import json
                            input_str = json.dumps(tool.input, indent=2)
                            if len(input_str) > 500:
                                input_str = input_str[:500] + "..."
                            console.print(f"\n    [dim]{input_str}[/dim]")
                        else:
                            console.print()

                text = evt.text_content
                if text:
                    console.print(text[:2000] if len(text) > 2000 else text)

            elif evt.is_compact_boundary:
                console.print(f"\n[bold red]{'═' * 60}[/bold red]")
                console.print("[bold red]═══ COMPACT BOUNDARY ═══[/bold red]")
                console.print(f"[dim]{evt.timestamp or ''}[/dim]")

    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command("find")
@click.argument("pattern")
@click.option("--project", "-p", default=None, help="Project directory path")
@click.option("--all-projects", "-a", is_flag=True, help="Search all projects")
@click.option("--limit", "-n", default=50, help="Max results")
def find_sessions(pattern: str, project: str | None, all_projects: bool, limit: int) -> None:
    """Search for a keyword/phrase across all sessions."""
    import re

    try:
        from rich.console import Console
        from rich.text import Text

        store = get_store(project, all_projects)
        console = Console()

        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error as e:
            click.echo(f"Invalid regex: {e}", err=True)
            sys.exit(2)

        results: list[tuple[str, str, str, str]] = []  # (session_name, uuid, role, excerpt)

        for session in store.sessions.values():
            # Search display name
            if regex.search(session.display_name):
                results.append((session.display_name, session.uuid, "name", session.display_name))
                if len(results) >= limit:
                    break

            # Search message content
            for evt in session.events:
                if evt.is_message:
                    text = evt.text_content
                    match = regex.search(text)
                    if match:
                        # Extract context around match
                        start = max(0, match.start() - 40)
                        end = min(len(text), match.end() + 40)
                        excerpt = text[start:end].replace("\n", " ")
                        results.append((session.display_name, session.uuid, evt.type, f"...{excerpt}..."))
                        if len(results) >= limit:
                            break
            if len(results) >= limit:
                break

        if not results:
            console.print(f"[dim]No matches for '{pattern}'[/dim]")
            return

        for name, uid, role, excerpt in results:
            console.print(f"[cyan]{name}[/cyan] [dim]({uid[:8]})[/dim] [{role}]")
            console.print(f"  {excerpt}")
            console.print()

        console.print(f"[dim]{len(results)} matches shown[/dim]")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command("tree")
@click.argument("identifier")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
def show_tree(identifier: str, project: str | None, all_projects: bool) -> None:
    """Show the fork tree (message parentUuid chain) for a session."""
    try:
        from rich.console import Console
        from rich.tree import Tree

        store = get_store(project, all_projects)
        session = store.resolve(identifier)
        console = Console()

        # Build tree from messages
        messages = session.messages()
        children: dict[str | None, list] = {}
        for msg in messages:
            parent = msg.parentUuid
            children.setdefault(parent, []).append(msg)

        tree = Tree(f"[bold]{session.display_name}[/bold] ({session.message_count} messages)")

        def add_children(parent_uuid: str | None, tree_node: Tree, depth: int = 0) -> None:
            if depth > 100:  # cycle protection
                return
            for msg in children.get(parent_uuid, []):
                label = f"[{'blue' if msg.type == 'user' else 'green'}]{msg.type}[/]"
                text = msg.text_content[:80].replace("\n", " ")
                if text:
                    label += f" {text}"
                child_node = tree_node.add(f"[dim]{msg.uuid[:8]}[/dim] {label}")
                add_children(msg.uuid, child_node, depth + 1)

        add_children(None, tree)
        console.print(tree)

    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)


@cli.command("fork")
@click.argument("identifier")
@click.argument("message_uuid")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
@click.option("--dest", default=None, help="Destination project directory (default: same as source)")
@click.option("--no-launch", is_flag=True, help="Create the fork but don't launch Claude Code")
@click.option("--team-name", default=None,
              help="Override the new team name for team-lead forks (default: auto-derived).")
def fork_session(
    identifier: str,
    message_uuid: str,
    project: str | None,
    all_projects: bool,
    dest: str | None,
    no_launch: bool,
    team_name: str | None,
) -> None:
    """Fork a session at a specific message, creating a new resumable session."""
    import subprocess

    try:
        from ..core.forge import ForgeError, forge_session as do_forge
        from ..core.metadata import write_fork_metadata

        store = get_store(project, all_projects)
        session = store.resolve(identifier)

        dest_dir = Path(dest) if dest else Path(session.path).parent

        if session.is_team_lead:
            click.echo(f"Team-lead session detected (team: {session.team_name}).")

        result = do_forge(
            Path(session.path),
            message_uuid,
            dest_dir,
            new_team_name=team_name,
        )

        project_slug = dest_dir.name
        write_fork_metadata(result.new_session_id, project_slug, session.uuid, message_uuid, source_session=session)

        click.echo(f"Forged session: {result.new_session_id}")
        click.echo(f"File: {result.dest_path}")
        click.echo(f"Forked from: {session.display_name} at message {message_uuid[:8]}")

        if result.team_forge_result is not None:
            tr = result.team_forge_result
            click.echo(f"Team cloned: {tr.new_team_name}")
            click.echo(f"Team dir: {tr.new_team_dir}")
            click.echo(
                f"  teammate JSONLs: {tr.cloned_teammate_jsonl_count}  "
                f"tasks: {tr.cloned_task_count}  "
                f"inbox messages kept: {tr.filtered_inbox_count}"
            )
            if not tr.team_source_existed:
                click.echo(
                    "  (source team dir was missing; config/inboxes not cloned)"
                )

        if no_launch:
            click.echo(f"\nTo resume: claude --resume {result.new_session_id}")
        else:
            click.echo("\nLaunching Claude Code...")
            subprocess.Popen(["claude", "--resume", result.new_session_id])

    except ForgeError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command("tasks")
@click.argument("identifier")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
@click.option("--evolution", "-e", is_flag=True, help="Show task state changes over time")
def show_tasks(identifier: str, project: str | None, all_projects: bool, evolution: bool) -> None:
    """Show tasks from a session."""
    try:
        from rich.console import Console
        from rich.table import Table

        store = get_store(project, all_projects)
        session = store.resolve(identifier)
        console = Console()

        # Extract task events from tool_use blocks
        task_events = []
        for evt in session.events:
            for tool in evt.tool_use_blocks:
                if tool.name in ("TaskCreate", "TaskUpdate", "TaskDelete"):
                    task_events.append((evt.timestamp, tool.name, tool.input or {}))

        if not task_events:
            console.print("[dim]No task events in this session.[/dim]")
            return

        if evolution:
            # Show timeline
            for ts, action, data in task_events:
                subject = data.get("subject", data.get("id", "?"))
                status = data.get("status", "")
                console.print(f"[dim]{ts or '?':25s}[/dim] [yellow]{action:12s}[/yellow] {subject}")
                if status:
                    console.print(f"  → status: {status}")
        else:
            # Show final state by replaying events
            tasks: dict[str, dict] = {}
            for ts, action, data in task_events:
                if action == "TaskCreate":
                    task_id = data.get("id", str(len(tasks)))
                    tasks[task_id] = {
                        "subject": data.get("subject", "?"),
                        "status": "pending",
                        "description": data.get("description", ""),
                    }
                elif action == "TaskUpdate":
                    task_id = data.get("id", "")
                    if task_id in tasks:
                        tasks[task_id].update({k: v for k, v in data.items() if v is not None})

            table = Table(show_header=True)
            table.add_column("ID", style="dim")
            table.add_column("Subject")
            table.add_column("Status")
            for tid, task in tasks.items():
                status_style = "green" if task["status"] == "completed" else "yellow"
                table.add_row(tid, task["subject"], f"[{status_style}]{task['status']}[/{status_style}]")
            console.print(table)

    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)


@cli.command("export")
@click.argument("identifier")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
@click.option("--format", "fmt", default="md", type=click.Choice(["md", "json"]))
@click.option("--output", "-o", default=None, help="Output file (default: stdout)")
def export_session(identifier: str, project: str | None, all_projects: bool, fmt: str, output: str | None) -> None:
    """Export a session as markdown or JSON."""
    import json as json_mod

    try:
        store = get_store(project, all_projects)
        session = store.resolve(identifier)

        if fmt == "json":
            data = [evt.model_dump() for evt in session.events]
            content = json_mod.dumps(data, indent=2, ensure_ascii=False)
        else:
            lines = [f"# {session.display_name}", f"UUID: {session.uuid}", ""]
            for evt in session.events:
                if evt.type == "user":
                    lines.append(f"## User\n{evt.text_content}\n")
                elif evt.type == "assistant":
                    text = evt.text_content
                    tools = evt.tool_use_blocks
                    lines.append("## Assistant")
                    if tools:
                        for t in tools:
                            lines.append(f"- Tool: {t.name}")
                    if text:
                        lines.append(f"\n{text}\n")
                    else:
                        lines.append("")
                elif evt.is_compact_boundary:
                    lines.append("---\n**[COMPACT BOUNDARY]**\n---\n")
            content = "\n".join(lines)

        if output:
            Path(output).write_text(content)
            click.echo(f"Exported to {output}")
        else:
            click.echo(content)

    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)


@cli.command("save-template")
@click.argument("identifier")
@click.argument("message_uuid")
@click.argument("name")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
def save_template_cmd(identifier: str, message_uuid: str, name: str, project: str | None, all_projects: bool) -> None:
    """Save a named fork template at a specific message."""
    try:
        from ..core.templates import TemplateExistsError, save_template

        store = get_store(project, all_projects)
        session = store.resolve(identifier)

        # Validate message exists
        msg_found = any(e.uuid == message_uuid for e in session.events if e.is_message)
        if not msg_found:
            click.echo(f"Error: Message {message_uuid} not found in session.", err=True)
            sys.exit(2)

        # Get message preview
        preview = ""
        for e in session.events:
            if e.uuid == message_uuid:
                preview = e.text_content[:100]
                break

        project_dir_name = Path(session.path).parent.name
        path = save_template(
            name=name,
            project_dir_name=project_dir_name,
            source_session_id=session.uuid,
            source_message_uuid=message_uuid,
            source_display_name=session.display_name,
            source_slug=session.slug,
            source_message_preview=preview,
        )
        click.echo(f"Template '{name}' saved at {path}")

    except TemplateExistsError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command("fork-template")
@click.argument("name")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
@click.option("--no-launch", is_flag=True, help="Create the fork but don't launch Claude Code")
@click.option("--preview", is_flag=True, help="Show template preview instead of forking")
def fork_template_cmd(name: str, project: str | None, all_projects: bool, no_launch: bool, preview: bool) -> None:
    """Fork from a saved template."""
    import subprocess

    try:
        from ..core.forge import ForgeError, forge_session as do_forge
        from ..core.metadata import write_fork_metadata
        from ..core.templates import TemplateNotFoundError, load_template, record_usage

        store = get_store(project, all_projects)

        # Determine project dir name
        project_dir_name = _detect_project_dir_name(store)
        if not project_dir_name:
            click.echo("Error: Could not detect project directory.", err=True)
            sys.exit(1)

        tpl = load_template(name, project_dir_name)

        if preview:
            _show_template_preview(tpl, store)
            return

        # Validate source session still exists
        session = store.get(tpl["sourceSessionId"])
        if session is None:
            click.echo(
                f"Error: Source session no longer exists.\n"
                f"  Session ID: {tpl['sourceSessionId']}\n"
                f"  Template may be stale — the source session may have been deleted.",
                err=True,
            )
            sys.exit(2)

        dest_dir = Path(session.path).parent
        result = do_forge(Path(session.path), tpl["sourceMessageUuid"], dest_dir)

        write_fork_metadata(result.new_session_id, project_dir_name, session.uuid, tpl["sourceMessageUuid"], source_session=session, template_name=name)
        record_usage(name, project_dir_name)

        click.echo(f"Forged from template '{name}': {result.new_session_id}")
        click.echo(f"File: {result.dest_path}")

        if no_launch:
            click.echo(f"\nTo resume: claude --resume {result.new_session_id}")
        else:
            click.echo("\nLaunching Claude Code...")
            subprocess.Popen(["claude", "--resume", result.new_session_id])

    except (TemplateNotFoundError, ForgeError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command("list-templates")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
@click.option("--sort", "sort_by", default="last_forked", type=click.Choice(["last_forked", "fork_count", "created", "name"]))
def list_templates_cmd(project: str | None, all_projects: bool, sort_by: str) -> None:
    """List saved fork templates."""
    try:
        from rich.console import Console
        from rich.table import Table

        from ..core.templates import list_templates

        store = get_store(project, all_projects)
        project_dir_name = _detect_project_dir_name(store)
        if not project_dir_name:
            click.echo("Error: Could not detect project directory.", err=True)
            sys.exit(1)

        templates = list_templates(project_dir_name, sort_by=sort_by)

        if not templates:
            click.echo("No templates saved. Use 'cctree save-template' to create one.")
            return

        console = Console()
        table = Table(show_header=True, header_style="bold")
        table.add_column("Name", style="magenta")
        table.add_column("Source", style="cyan")
        table.add_column("Forks", justify="right")
        table.add_column("Last Forked")
        table.add_column("Created")

        for t in templates:
            last_forked = t.get("lastForkedAt", "")[:10] if t.get("lastForkedAt") else "—"
            created = t.get("createdAt", "")[:10] if t.get("createdAt") else "—"
            source = t.get("sourceDisplayName") or t.get("sourceSlug") or t.get("sourceSessionId", "?")[:12]
            table.add_row(
                f"★ {t['name']}",
                source,
                str(t.get("forkCount", 0)),
                last_forked,
                created,
            )

        console.print(table)
        console.print(f"\n[dim]{len(templates)} templates (sorted by {sort_by})[/dim]")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command("delete-template")
@click.argument("name")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def delete_template_cmd(name: str, project: str | None, all_projects: bool, yes: bool) -> None:
    """Delete a saved fork template."""
    try:
        from ..core.templates import TemplateNotFoundError, delete_template

        store = get_store(project, all_projects)
        project_dir_name = _detect_project_dir_name(store)
        if not project_dir_name:
            click.echo("Error: Could not detect project directory.", err=True)
            sys.exit(1)

        if not yes:
            if not click.confirm(f"Delete template '{name}'?"):
                click.echo("Cancelled.")
                return

        delete_template(name, project_dir_name)
        click.echo(f"Template '{name}' deleted.")

    except TemplateNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command("rename-template")
@click.argument("old_name")
@click.argument("new_name")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
def rename_template_cmd(old_name: str, new_name: str, project: str | None, all_projects: bool) -> None:
    """Rename a saved fork template."""
    try:
        from ..core.templates import TemplateExistsError, TemplateNotFoundError, rename_template

        store = get_store(project, all_projects)
        project_dir_name = _detect_project_dir_name(store)
        if not project_dir_name:
            click.echo("Error: Could not detect project directory.", err=True)
            sys.exit(1)

        rename_template(old_name, new_name, project_dir_name)
        click.echo(f"Template renamed: '{old_name}' → '{new_name}'")

    except (TemplateNotFoundError, TemplateExistsError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)


@cli.command("import-templates")
@click.option("--project", "-p", default=None)
@click.option("--all-projects", "-a", is_flag=True)
def import_templates_cmd(project: str | None, all_projects: bool) -> None:
    """Import existing fork sidecars as named templates."""
    try:
        from ..core.templates import TemplateExistsError, import_from_forks, save_template

        store = get_store(project, all_projects)
        project_dir_name = _detect_project_dir_name(store)

        discovered = import_from_forks(project_dir_name)
        if not discovered:
            click.echo("No fork metadata found in ~/.cctree/")
            return

        click.echo(f"Found {len(discovered)} fork(s):\n")
        imported = 0
        for d in discovered:
            src_name = d.get("sourceDisplayName") or d.get("sourceSlug") or "?"
            suggested = d["suggestedName"]
            click.echo(f"  Source: {src_name}")
            click.echo(f"  Suggested name: {suggested}")

            name = click.prompt("  Template name (empty to skip)", default=suggested, show_default=False)
            if not name or name.strip() == "":
                click.echo("  Skipped.\n")
                continue

            try:
                save_template(
                    name=name,
                    project_dir_name=d["projectDirName"],
                    source_session_id=d["sourceSessionId"],
                    source_message_uuid=d["sourceMessageUuid"],
                    source_display_name=d.get("sourceDisplayName"),
                    source_slug=d.get("sourceSlug"),
                )
                imported += 1
                click.echo(f"  Imported as '{name}'.\n")
            except TemplateExistsError:
                click.echo(f"  Template '{name}' already exists — skipped.\n")

        click.echo(f"\nImported {imported} template(s).")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


def _detect_project_dir_name(store: SessionStore) -> str | None:
    """Get the full directory name of the current project."""
    if store._project_dirs:
        return store._project_dirs[0].name
    return None


def _show_template_preview(tpl: dict, store: SessionStore) -> None:
    """Show a template preview: first 3 + last 3 messages at the fork point."""
    from rich.console import Console

    console = Console()
    console.print(f"\n[bold magenta]★ {tpl['name']}[/bold magenta]")
    source_name = tpl.get("sourceDisplayName") or tpl.get("sourceSlug") or tpl.get("sourceSessionId", "?")[:12]
    console.print(f"Source: [bold]{source_name}[/bold]")
    console.print(f"Fork point: {tpl.get('sourceMessageUuid', '?')[:12]}")
    console.print(f"Forks: {tpl.get('forkCount', 0)}  |  Created: {(tpl.get('createdAt') or '?')[:10]}")

    session = store.get(tpl.get("sourceSessionId", ""))
    if session is None:
        console.print("\n[yellow]⚠ Source session not found — session may have been deleted.[/yellow]")
        return

    # Collect messages up to the fork point
    messages = []
    for evt in session.events:
        if evt.is_message:
            messages.append(evt)
        if evt.uuid == tpl.get("sourceMessageUuid"):
            break

    if not messages:
        console.print("\n[dim]No messages found.[/dim]")
        return

    def _fmt_msg(evt) -> str:
        role = "[blue]User[/blue]" if evt.type == "user" else "[green]Asst[/green]"
        text = evt.text_content[:80].replace("\n", " ")
        return f"  {role}: {text}"

    console.print()
    if len(messages) <= 6:
        console.print("[bold]── Messages ──[/bold]")
        for m in messages:
            console.print(_fmt_msg(m))
    else:
        console.print("[bold]── First 3 messages ──[/bold]")
        for m in messages[:3]:
            console.print(_fmt_msg(m))
        console.print(f"\n[dim]  ⋮ {len(messages) - 6} messages in between[/dim]\n")
        console.print("[bold]── Last 3 messages (fork point) ──[/bold]")
        for m in messages[-3:]:
            console.print(_fmt_msg(m))

    console.print(f"                     [bold cyan]◄ FORK POINT[/bold cyan]")


@cli.command("doctor")
def doctor() -> None:
    """Check Claude Code installation and compatibility."""
    import shutil
    import subprocess

    from rich.console import Console
    console = Console()

    # Check claude binary
    claude_path = shutil.which("claude")
    if claude_path:
        console.print(f"[green]✓[/green] Claude Code found: {claude_path}")
        try:
            result = subprocess.run(["claude", "--version"], capture_output=True, text=True, timeout=5)
            version_str = result.stdout.strip()
            console.print(f"  Version: {version_str}")

            from ..core.version import parse_claude_version, check_version_compat
            parsed = parse_claude_version(version_str)
            if parsed:
                compat = check_version_compat(parsed)
                if not compat.compatible:
                    console.print(f"  [red]✗ {compat.message}[/red]")
                elif compat.warning:
                    console.print(f"  [yellow]⚠ {compat.warning}[/yellow]")
                else:
                    console.print(f"  [green]✓ Version compatible[/green]")
            else:
                console.print(f"  [yellow]⚠ Could not parse version string[/yellow]")
        except Exception:
            console.print("  [yellow]Could not determine version[/yellow]")
    else:
        console.print("[red]✗[/red] Claude Code not found on PATH")

    # Check projects directory
    from ..core.store import CLAUDE_PROJECTS_DIR
    if CLAUDE_PROJECTS_DIR.exists():
        project_count = len(list(CLAUDE_PROJECTS_DIR.iterdir()))
        console.print(f"[green]✓[/green] Projects dir: {CLAUDE_PROJECTS_DIR} ({project_count} projects)")
    else:
        console.print(f"[red]✗[/red] Projects dir not found: {CLAUDE_PROJECTS_DIR}")

    # Count total sessions
    total = 0
    for d in CLAUDE_PROJECTS_DIR.iterdir():
        if d.is_dir():
            total += len(list(d.glob("*.jsonl")))
    console.print(f"  Total sessions across all projects: {total}")

    # Team state summary
    from ..core.team import DEFAULT_TASKS_BASE, DEFAULT_TEAMS_BASE
    if DEFAULT_TEAMS_BASE.is_dir():
        team_count = sum(1 for p in DEFAULT_TEAMS_BASE.iterdir() if p.is_dir())
        inbox_count = 0
        for team_dir in DEFAULT_TEAMS_BASE.iterdir():
            if team_dir.is_dir():
                inbox_dir = team_dir / "inboxes"
                if inbox_dir.is_dir():
                    inbox_count += sum(1 for _ in inbox_dir.glob("*.json"))
        console.print(
            f"[green]✓[/green] Teams dir: {DEFAULT_TEAMS_BASE} "
            f"({team_count} teams, {inbox_count} inbox files)"
        )
    else:
        console.print(f"  [dim]Teams dir: {DEFAULT_TEAMS_BASE} (not present)[/dim]")
    if DEFAULT_TASKS_BASE.is_dir():
        task_dir_count = sum(1 for p in DEFAULT_TASKS_BASE.iterdir() if p.is_dir())
        console.print(
            f"[green]✓[/green] Tasks dir: {DEFAULT_TASKS_BASE} "
            f"({task_dir_count} task lists)"
        )


