"""cctree.cli - CLI subcommands.

Subcommands to be implemented after /plan-eng-review:
    list      - browse sessions across projects
    tree      - show fork tree for a session
    show      - render a session transcript with depth control
    find      - keyword/phrase search
    fork      - forge a fork-from-message and launch claude --resume
    export    - export session as markdown
    subagents - list and drill into subagent transcripts
    tasks     - show task list with --at <message> and --evolution
    rename    - write a custom-title event into a session JSONL
"""
