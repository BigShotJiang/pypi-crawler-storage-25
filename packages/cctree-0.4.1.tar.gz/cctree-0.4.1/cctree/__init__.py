"""cctree - Claude Code session browser, history navigator, and fork tool."""

__version__ = "0.4.1"
