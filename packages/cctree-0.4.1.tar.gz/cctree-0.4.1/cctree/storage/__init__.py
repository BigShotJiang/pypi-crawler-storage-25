"""cctree.storage - SQLite metadata layer.

Stores cctree-owned metadata at ~/.cctree/meta.db:
    - tags, stars, custom names (separate from in-JSONL customTitle)
    - last-viewed timestamps
    - forge lineage: forged_session_id -> (original_session_id, original_message_id)

Modules to be implemented after /plan-eng-review:
    meta_db  - SQLite wrapper with WAL mode and migrations
"""
