"""JSON loader with optional orjson acceleration.

Exposes ``loads()`` and ``USING_ORJSON: bool``.  When orjson is installed
(``pip install cctree[fast]``), parsing is ~5-8x faster than stdlib json.
Falls back transparently to ``json.loads`` when orjson is absent.
"""
from __future__ import annotations

try:
    import orjson

    def loads(s: str | bytes) -> dict:  # type: ignore[type-arg]
        return orjson.loads(s)

    USING_ORJSON: bool = True

except ImportError:
    import json as _json

    def loads(s: str | bytes) -> dict:  # type: ignore[type-arg]
        return _json.loads(s)

    USING_ORJSON: bool = False
