"""cctree.core - JSONL parsing, session model, fork forge, task replay.

Phase 1 modules to be implemented after /plan-eng-review:
    parser    - JSONL events from session files
    model     - Session, Message, ContentBlock, Task dataclasses
    tree      - parentUuid -> fork tree builder
    subagents - link parent tool_use to child subagent JSONL
    tasks     - replay TaskCreate/Update/Delete -> state-at-T
    compact   - detect compact_boundary events
    forge     - fork-from-message JSONL forge
    search    - keyword/phrase search across sessions
    export    - markdown rendering
    lookup    - resolve UUID / slug / customTitle -> Session
"""
