"""Forge engine — create new sessions by forking from a specific message.

Reads raw JSONL (bypassing Pydantic), collects the prefix up to the target
message, remaps all UUIDs, and performs an atomic write. Used by both
`cctree fork` and `cctree fork-template`.

    source JSONL ──▶ prefix up to msg ──▶ remap UUIDs ──▶ atomic write

For team-lead sessions (any event has `teamName`), the forge also clones the
associated team dir + inboxes + tasks + teammate JSONLs. See `team_forge.py`.
"""
from __future__ import annotations

import json
import os
import uuid as uuid_mod
from dataclasses import dataclass
from pathlib import Path

from .team import DEFAULT_TASKS_BASE, DEFAULT_TEAMS_BASE
from .team_forge import (
    TeamForgeError,
    TeamForgeResult,
    clone_agent_tool_jsonls,
    clone_team_for_fork,
    derive_new_team_name,
    replay_tasks,
    write_tasks,
)


@dataclass
class ForgeResult:
    """Result of a forge operation."""
    new_session_id: str
    dest_path: Path
    message_count: int  # number of messages in the forged prefix
    team_forge_result: TeamForgeResult | None = None


class ForgeError(Exception):
    """Raised when a forge operation fails."""


def forge_session(
    source_path: Path,
    message_uuid: str,
    dest_dir: Path,
    *,
    new_team_name: str | None = None,
    teams_base: Path | None = None,
    tasks_base: Path | None = None,
) -> ForgeResult:
    """Fork a session at a specific message, creating a new resumable JSONL.

    Reads raw JSON lines from source (bypasses Pydantic to preserve exact field
    structure — Pydantic's model_dump inflates content blocks with null fields
    that the API rejects). Collects the prefix up to and including the target
    message, remaps all UUIDs, and writes atomically to dest_dir.

    If the source is a team-lead session (any event has `teamName`), the team
    dir, inboxes, tasks, and teammate JSONLs are also cloned — the forked
    session is independently resumable with its own team.

    Args:
        source_path: Path to the source session JSONL file.
        message_uuid: UUID of the message to fork at (inclusive).
        dest_dir: Directory to write the new session JSONL into.
        new_team_name: Optional override for the cloned team's name.
            Default: auto-derive from original name + new session ID prefix.
            Ignored if the source is not a team-lead session.
        teams_base: Override for ~/.claude/teams (used in tests).
        tasks_base: Override for ~/.claude/tasks (used in tests).

    Returns:
        ForgeResult with the new session ID, destination path, message count,
        and (for team sessions) team_forge_result.

    Raises:
        ForgeError: If the message is not found, the destination already exists,
            or team cloning fails.
    """
    # Resolve defaults lazily so test monkeypatches take effect.
    if teams_base is None:
        teams_base = DEFAULT_TEAMS_BASE
    if tasks_base is None:
        tasks_base = DEFAULT_TASKS_BASE

    # Read raw JSON lines
    raw_lines: list[dict] = []
    with open(source_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                raw_lines.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    # Find the message and collect the prefix
    found = False
    prefix_raws: list[dict] = []
    for raw in raw_lines:
        prefix_raws.append(raw)
        if raw.get("uuid") == message_uuid:
            found = True
            break

    if not found:
        raise ForgeError(f"Message {message_uuid} not found in session {source_path.name}")

    # Detect the original session ID from the first event
    original_session_id = None
    for raw in prefix_raws:
        if "sessionId" in raw and raw["sessionId"]:
            original_session_id = raw["sessionId"]
            break

    # Detect team name (first teamName found)
    original_team_name: str | None = None
    cut_timestamp: str = ""
    for raw in prefix_raws:
        if original_team_name is None and raw.get("teamName"):
            original_team_name = raw["teamName"]
        # Cut timestamp = timestamp of the target message
        if raw.get("uuid") == message_uuid and raw.get("timestamp"):
            cut_timestamp = raw["timestamp"]

    # Resolve new team name (only if source was a team session)
    resolved_new_team_name: str | None = None
    if original_team_name is not None:
        resolved_new_team_name = new_team_name or derive_new_team_name(
            original_team_name, str(uuid_mod.uuid4()), teams_base=teams_base
        )

    # Generate new session UUID and build UUID mapping
    new_session_id = str(uuid_mod.uuid4())
    uuid_map: dict[str, str] = {}
    if original_session_id:
        uuid_map[original_session_id] = new_session_id

    def remap(old: str | None) -> str | None:
        if old is None:
            return None
        if old not in uuid_map:
            uuid_map[old] = str(uuid_mod.uuid4())
        return uuid_map[old]

    # Forge the prefix — operate on raw dicts to preserve original structure
    forged_lines: list[str] = []
    msg_count = 0
    for raw in prefix_raws:
        # Skip last-prompt events
        if raw.get("type") == "last-prompt":
            continue

        # Remap UUIDs (only touch fields that exist in the original)
        if "sessionId" in raw:
            raw["sessionId"] = new_session_id
        if "uuid" in raw and raw["uuid"]:
            raw["uuid"] = remap(raw["uuid"])
        if "parentUuid" in raw:
            raw["parentUuid"] = remap(raw["parentUuid"])
        if "promptId" in raw and raw["promptId"]:
            raw["promptId"] = remap(raw["promptId"])
        if "messageId" in raw and raw["messageId"]:
            raw["messageId"] = remap(raw["messageId"])
        if "logicalParentUuid" in raw and raw["logicalParentUuid"]:
            raw["logicalParentUuid"] = remap(raw["logicalParentUuid"])
        if "snapshot" in raw and isinstance(raw["snapshot"], dict):
            if "messageId" in raw["snapshot"] and raw["snapshot"]["messageId"]:
                raw["snapshot"]["messageId"] = remap(raw["snapshot"]["messageId"])

        # Rewrite teamName if this is a team session
        if (
            resolved_new_team_name is not None
            and original_team_name is not None
            and raw.get("teamName") == original_team_name
        ):
            raw["teamName"] = resolved_new_team_name

        if raw.get("type") in ("user", "assistant"):
            msg_count += 1

        forged_lines.append(json.dumps(raw, ensure_ascii=False))

    # Ensure dest directory exists
    dest_dir.mkdir(parents=True, exist_ok=True)

    # Atomic write — dest is always a new UUID, but check anyway
    dest_path = dest_dir / f"{new_session_id}.jsonl"
    tmp_path = dest_dir / f"{new_session_id}.jsonl.tmp"

    if dest_path.exists() or tmp_path.exists():
        raise ForgeError(f"Destination already exists (UUID collision?): {dest_path}")

    with open(tmp_path, "w") as f:
        for line in forged_lines:
            f.write(line + "\n")
    os.rename(str(tmp_path), str(dest_path))

    # Session dirs for subagent + task handling
    original_session_dir: Path | None = None
    if original_session_id:
        original_session_dir = source_path.parent / original_session_id
    new_session_dir = dest_path.parent / new_session_id

    # Team clone (after main write so the forged JSONL is safe if this raises)
    team_result: TeamForgeResult | None = None
    if resolved_new_team_name is not None and original_team_name is not None:
        try:
            team_result = clone_team_for_fork(
                old_team_name=original_team_name,
                new_team_name=resolved_new_team_name,
                new_session_id=new_session_id,
                uuid_map=uuid_map,
                cut_timestamp=cut_timestamp,
                prefix_events=prefix_raws,
                original_session_dir=original_session_dir,
                new_session_dir=new_session_dir,
                teams_base=teams_base,
                tasks_base=tasks_base,
            )
        except TeamForgeError as e:
            raise ForgeError(f"Team clone failed: {e}") from e
    else:
        # Non-team: replay tasks into tasks_base/{new_session_id}/
        task_state = replay_tasks(prefix_raws)
        if task_state:
            write_tasks(task_state, tasks_base / new_session_id)

    # Agent-tool subagent copy (all session types — teammates are handled
    # separately inside clone_team_for_fork for team sessions)
    if original_session_dir is not None:
        clone_agent_tool_jsonls(
            original_session_dir=original_session_dir,
            new_session_dir=new_session_dir,
            cut_timestamp=cut_timestamp,
            uuid_map=uuid_map,
            new_session_id=new_session_id,
        )

    return ForgeResult(
        new_session_id=new_session_id,
        dest_path=dest_path,
        message_count=msg_count,
        team_forge_result=team_result,
    )
