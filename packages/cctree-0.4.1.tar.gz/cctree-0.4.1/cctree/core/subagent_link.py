"""Subagent linkage: map parent Agent tool_use blocks to subagent JSONL files.

The linkage chain discovered from real Claude Code sessions:
  1. Parent session has an Assistant message with a tool_use block (name="Agent")
     → tool_use_id = "toolu_XXXXX"
  2. Subsequent progress events in the parent session have:
     → parentToolUseID = "toolu_XXXXX"  (links back to the Agent tool_use)
     → data.agentId = "abc123def456"    (the subagent's ID)
  3. The subagent's transcript lives at:
     → <project-dir>/<session-uuid>/subagents/agent-<agentId>.jsonl

Team teammates use a different discovery path: their names appear inside
<teammate-message teammate_id="NAME"> tags within user-message content, and
their transcripts are classified by meta.json shape (see teammate_sessions.py).
"""
from __future__ import annotations

from pathlib import Path

from .model import EventType, SessionEvent
from .teammate import contains_teammate_message, parse_teammate_messages
from .teammate_sessions import find_teammate_sessions


def find_agent_links(events: list[SessionEvent]) -> dict[str, str]:
    """Discover tool_use_id → agentId mappings from progress events.

    Returns a dict mapping Agent tool_use IDs to their subagent file hashes.
    """
    links: dict[str, str] = {}

    for evt in events:
        if evt.type != "progress":
            continue

        # Progress events store the link in model_extra (since data, parentToolUseID,
        # toolUseID aren't declared fields on SessionEvent)
        data = evt.model_extra.get("data") if evt.model_extra else None
        if not isinstance(data, dict):
            continue

        agent_id = data.get("agentId")
        if not agent_id:
            continue

        parent_tool_use_id = evt.model_extra.get("parentToolUseID")
        if not parent_tool_use_id:
            continue

        # First occurrence wins (subsequent progress events for the same agent
        # will have the same mapping)
        if parent_tool_use_id not in links:
            links[parent_tool_use_id] = agent_id

    return links


def resolve_subagent_path(
    agent_id: str,
    session_jsonl_path: str,
    fallback_session_paths: list[str] | None = None,
) -> Path | None:
    """Resolve an agentId to its subagent JSONL file path.

    Checks the primary session's subagents directory first. If not found,
    checks each fallback session path (e.g., the original session that a
    fork was created from — subagent files live under the original UUID).

    Args:
        agent_id: The agentId hash (e.g., "abc123def456")
        session_jsonl_path: Path to the primary session's JSONL file
        fallback_session_paths: Additional session JSONL paths to check

    Returns:
        Path to the subagent JSONL if found, None otherwise.
    """
    paths_to_check = [session_jsonl_path]
    if fallback_session_paths:
        paths_to_check.extend(fallback_session_paths)

    for jsonl_path in paths_to_check:
        session_path = Path(jsonl_path)
        session_uuid = session_path.stem
        project_dir = session_path.parent

        subagent_file = project_dir / session_uuid / "subagents" / f"agent-{agent_id}.jsonl"
        if subagent_file.exists():
            return subagent_file

    return None


def find_teammate_references(events: list[SessionEvent]) -> set[str]:
    """Distinct teammate_ids referenced in <teammate-message> tags across events.

    Only scans user-message events whose `content` is a string (teammate
    messages never appear in content-array form).
    """
    names: set[str] = set()
    for evt in events:
        if evt.type != EventType.USER:
            continue
        if evt.message is None:
            continue
        content = evt.message.content
        if not isinstance(content, str):
            continue
        if not contains_teammate_message(content):
            continue
        for block in parse_teammate_messages(content):
            names.add(block.teammate_id)
    return names


def resolve_teammate_paths(
    teammate_name: str,
    session_jsonl_path: str,
    fallback_session_paths: list[str] | None = None,
) -> list[Path]:
    """List of teammate JSONL turn files for the given teammate name.

    Searches the primary session's subagents/ dir first (matching the existing
    `resolve_subagent_path` precedence). If the primary has any files for this
    teammate, fallback dirs are NOT consulted — if empty, each fallback is
    tried in order. Returned paths are sorted by mtime (oldest first).
    """
    paths_to_check = [session_jsonl_path]
    if fallback_session_paths:
        paths_to_check.extend(fallback_session_paths)

    for jsonl_path in paths_to_check:
        session_path = Path(jsonl_path)
        session_uuid = session_path.stem
        project_dir = session_path.parent
        parent_session_dir = project_dir / session_uuid

        grouped = find_teammate_sessions(parent_session_dir)
        if teammate_name in grouped:
            return grouped[teammate_name]

    return []
