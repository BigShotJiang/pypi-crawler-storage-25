"""Session store: discovers and loads sessions from Claude Code's project directories.

This is the central API used by both CLI and TUI. All session access
goes through SessionStore — no direct filesystem access elsewhere.
"""
from __future__ import annotations

import logging
import os
import threading
from pathlib import Path

from .metadata import is_fork
from .model import Session
from .parser import extract_session_metadata, parse_jsonl, parse_session_id

logger = logging.getLogger("cctree.store")

# Claude Code stores sessions here
CLAUDE_PROJECTS_DIR = Path.home() / ".claude" / "projects"


def discover_project_dirs() -> list[Path]:
    """Find all project directories under ~/.claude/projects/."""
    if not CLAUDE_PROJECTS_DIR.exists():
        logger.warning("Claude projects directory not found: %s", CLAUDE_PROJECTS_DIR)
        return []
    return sorted(
        [d for d in CLAUDE_PROJECTS_DIR.iterdir() if d.is_dir() and not d.name.startswith(".")],
        key=lambda d: d.name,
    )


def project_dir_to_slug(project_dir: Path) -> str:
    """Convert a project directory name to a display slug.

    Claude Code uses a mangled path as the directory name, e.g.:
    '-Users-tinytim-projects-Synapse' → 'Synapse'
    """
    name = project_dir.name
    # Strip leading '-' and split by '-'
    parts = name.lstrip("-").split("-")
    # Return the last meaningful part (usually the project name)
    return parts[-1] if parts else name


class SessionStore:
    """Discovers and loads sessions from one or more project directories."""

    def __init__(self, project_dir: Path | None = None, all_projects: bool = False) -> None:
        """Initialize the store.

        Args:
            project_dir: Specific project directory to scan. If None, auto-detect
                from cwd.
            all_projects: If True, scan ALL project directories.
        """
        if all_projects:
            self._project_dirs = discover_project_dirs()
        elif project_dir:
            self._project_dirs = [project_dir]
        else:
            self._project_dirs = self._detect_project_dir()

        self._sessions: dict[str, Session] | None = None  # lazy-loaded
        self._load_lock = threading.Lock()

    def _detect_project_dir(self) -> list[Path]:
        """Auto-detect the project directory from the current working directory."""
        cwd = os.getcwd()
        # Claude Code mangles the path: /Users/tinytim/projects/Synapse → -Users-tinytim-projects-Synapse
        mangled = cwd.replace("/", "-")
        candidate = CLAUDE_PROJECTS_DIR / mangled
        if candidate.exists():
            return [candidate]
        logger.warning(
            "Could not detect project directory for cwd=%s (tried %s)",
            cwd,
            candidate,
        )
        return []

    def _load_sessions(self) -> dict[str, Session]:
        """Scan project directories and parse all session JSONLs."""
        sessions: dict[str, Session] = {}
        for project_dir in self._project_dirs:
            slug = project_dir_to_slug(project_dir)
            for jsonl_path in sorted(project_dir.glob("*.jsonl")):
                session_id = parse_session_id(jsonl_path)
                try:
                    meta = extract_session_metadata(jsonl_path)
                    fork_suffix = session_id[:8] if is_fork(session_id, slug) else None
                    session = Session(
                        uuid=session_id,
                        project_slug=slug,
                        path=str(jsonl_path),
                        _metadata=meta,
                        fork_suffix=fork_suffix,
                    )
                    sessions[session_id] = session
                except (FileNotFoundError, PermissionError):
                    continue
                except Exception:
                    logger.warning("Failed to parse session %s", jsonl_path.name, exc_info=True)
                    continue
        return sessions

    @property
    def sessions(self) -> dict[str, Session]:
        """All sessions, keyed by UUID. Lazy-loaded on first access.

        Thread-safe: the background TUI worker and main thread may both
        access this property concurrently during startup.
        """
        if self._sessions is None:
            with self._load_lock:
                if self._sessions is None:
                    self._sessions = self._load_sessions()
        return self._sessions

    def list_sessions(
        self,
        limit: int = 50,
        sort_by: str = "last_activity",
    ) -> list[Session]:
        """List sessions sorted by last activity (most recent first)."""
        all_sessions = list(self.sessions.values())
        if sort_by == "last_activity":
            all_sessions.sort(
                key=lambda s: s.last_activity_at or s.started_at or __import__("datetime").datetime.min,
                reverse=True,
            )
        return all_sessions[:limit]

    def get(self, session_id: str) -> Session | None:
        """Get a session by exact UUID."""
        return self.sessions.get(session_id)

    def resolve(self, identifier: str) -> Session:
        """Resolve a session by UUID, slug, or customTitle.

        Lookup precedence (per Issue 4A):
          1. Exact UUID match (always unique)
          2. Slug match within project
          3. customTitle match within project
          4. If multiple matches, raise ValueError with candidates

        Raises:
            ValueError: If identifier is ambiguous or not found.
        """
        # 1. Exact UUID
        if identifier in self.sessions:
            return self.sessions[identifier]

        # 2. Slug match
        slug_matches = [s for s in self.sessions.values() if s.slug == identifier]
        if len(slug_matches) == 1:
            return slug_matches[0]

        # 3. customTitle match
        title_matches = [s for s in self.sessions.values() if s.custom_title == identifier]
        if len(title_matches) == 1:
            return title_matches[0]

        # Combine all matches for disambiguation
        all_matches = list({s.uuid: s for s in slug_matches + title_matches}.values())
        if len(all_matches) > 1:
            candidates = "\n".join(
                f"  {s.uuid}  ({s.display_name})" for s in all_matches
            )
            raise ValueError(
                f"Ambiguous identifier '{identifier}' matches {len(all_matches)} sessions:\n{candidates}\n"
                f"Use the full UUID to disambiguate."
            )

        if not all_matches:
            raise ValueError(f"Session not found: '{identifier}'")

        return all_matches[0]

    def is_active(self, session_id: str) -> bool:
        """Heuristic: is this session currently being written by Claude Code?

        Checks if the JSONL file was modified in the last 60 seconds.
        """
        session = self.get(session_id)
        if session is None:
            return False
        try:
            mtime = os.path.getmtime(session.path)
            import time
            return (time.time() - mtime) < 60
        except OSError:
            return False
