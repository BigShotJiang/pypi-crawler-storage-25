"""Fork metadata — sidecar files in ~/.cctree/ for fork provenance.

All cctree metadata lives outside ~/.claude/ to avoid any footprint
in Claude Code's territory. The mirror structure:

  ~/.cctree/
    projects/
      -Users-tinytim-projects-Synapse/
        <session-uuid>.meta.json       ← fork provenance, tags, etc.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

CCTREE_DIR = Path.home() / ".cctree"


def _meta_path(session_uuid: str, project_slug: str) -> Path:
    """Path to the metadata sidecar file for a session."""
    return CCTREE_DIR / "projects" / project_slug / f"{session_uuid}.meta.json"


def write_fork_metadata(
    forged_session_uuid: str,
    project_slug: str,
    original_session_uuid: str,
    cut_message_uuid: str,
    source_session: object | None = None,
    template_name: str | None = None,
) -> Path:
    """Write fork provenance metadata for a forged session.

    Args:
        source_session: Optional Session object from which to snapshot metadata
            (display name, slug, project, message count, timestamps, etc.)

    Returns the path to the created meta file.
    """
    source_info: dict = {
        "sessionId": original_session_uuid,
        "messageId": cut_message_uuid,
    }

    # Snapshot source session metadata so it's readable even if the
    # original session is in a different project or gets deleted
    if source_session is not None:
        s = source_session
        source_info.update({
            "displayName": getattr(s, "display_name", None),
            "slug": getattr(s, "slug", None),
            "customTitle": getattr(s, "custom_title", None),
            "projectSlug": getattr(s, "project_slug", None),
            "projectDir": str(Path(getattr(s, "path", "")).parent) if getattr(s, "path", None) else None,
            "messageCount": getattr(s, "message_count", None),
            "startedAt": getattr(s, "started_at", None).isoformat() if getattr(s, "started_at", None) else None,
            "lastActivityAt": getattr(s, "last_activity_at", None).isoformat() if getattr(s, "last_activity_at", None) else None,
            "claudeVersion": getattr(s, "claude_version", None),
        })

    meta: dict = {
        "forkedFrom": source_info,
        "forgedAt": datetime.now(timezone.utc).isoformat(),
    }
    if template_name is not None:
        meta["templateName"] = template_name

    path = _meta_path(forged_session_uuid, project_slug)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(meta, indent=2))
    return path


def is_fork(session_uuid: str, project_slug: str) -> bool:
    """Check if a session was created by cctree fork."""
    return _meta_path(session_uuid, project_slug).exists()


def find_template_forks(template_name: str, project_slug: str) -> list[dict]:
    """Find all sessions forked from a given template.

    Scans *.meta.json sidecars for matching templateName.
    Returns list of dicts with sessionId, forgedAt, and forkedFrom,
    sorted by forgedAt descending (most recent first).
    """
    proj_dir = CCTREE_DIR / "projects" / project_slug
    if not proj_dir.exists():
        return []

    results: list[dict] = []
    for meta_path in proj_dir.glob("*.meta.json"):
        try:
            data = json.loads(meta_path.read_text())
        except (json.JSONDecodeError, OSError):
            continue

        if data.get("templateName") != template_name:
            continue

        # Extract session UUID from filename: {uuid}.meta.json
        session_id = meta_path.name.removesuffix(".meta.json")
        results.append({
            "sessionId": session_id,
            "forgedAt": data.get("forgedAt", ""),
            "forkedFrom": data.get("forkedFrom", {}),
        })

    results.sort(key=lambda r: r["forgedAt"], reverse=True)
    return results


def get_fork_metadata(session_uuid: str, project_slug: str) -> dict | None:
    """Read fork metadata for a session. Returns None if not a fork."""
    path = _meta_path(session_uuid, project_slug)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None
