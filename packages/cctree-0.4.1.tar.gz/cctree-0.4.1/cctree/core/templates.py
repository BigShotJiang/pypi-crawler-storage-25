"""Fork templates — named, reusable fork points stored as JSON sidecars.

Templates are stored at:
  ~/.cctree/templates/{project-dir-name}/{name}.json

The project-dir-name is the FULL mangled directory name (e.g.,
"-Users-tinytim-projects-Synapse") to avoid collisions between projects
with the same basename.

Template JSON schema:
  {
    "name": "refactor-base",
    "projectDirName": "-Users-tinytim-projects-Synapse",
    "sourceSessionId": "abc123...",
    "sourceMessageUuid": "def456...",
    "sourceDisplayName": "session name at save time",
    "sourceSlug": "three-word-slug",
    "sourceMessagePreview": "First line of fork-point message...",
    "createdAt": "2026-04-15T14:30:00Z",
    "forkCount": 0,
    "lastForkedAt": null
  }
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path

from .metadata import CCTREE_DIR

logger = logging.getLogger("cctree.templates")

TEMPLATES_DIR = CCTREE_DIR / "templates"

# Template name validation: alphanumeric, dashes, underscores only
_VALID_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$")


class TemplateExistsError(Exception):
    """Raised when a template with the given name already exists."""


class TemplateNotFoundError(Exception):
    """Raised when a template is not found."""


class TemplateCorruptError(Exception):
    """Raised when a template JSON file is corrupt."""


def _templates_dir(project_dir_name: str) -> Path:
    """Path to the templates directory for a project."""
    return TEMPLATES_DIR / project_dir_name


def _template_path(name: str, project_dir_name: str) -> Path:
    """Path to a specific template JSON file."""
    return _templates_dir(project_dir_name) / f"{name}.json"


def validate_template_name(name: str) -> str:
    """Sanitize and validate a template name.

    Converts spaces to dashes, strips leading/trailing whitespace.
    Returns the sanitized name.

    Raises:
        ValueError: If the name is invalid after sanitization.
    """
    name = name.strip().replace(" ", "-")
    if not name:
        raise ValueError("Template name cannot be empty")
    if not _VALID_NAME_RE.match(name):
        raise ValueError(
            f"Invalid template name: '{name}'. "
            "Use only letters, numbers, dashes, and underscores (max 100 chars)."
        )
    return name


def save_template(
    name: str,
    project_dir_name: str,
    source_session_id: str,
    source_message_uuid: str,
    *,
    source_display_name: str | None = None,
    source_slug: str | None = None,
    source_message_preview: str | None = None,
) -> Path:
    """Save a named fork template.

    Returns the path to the created template file.

    Raises:
        TemplateExistsError: If a template with this name already exists.
        ValueError: If the name is invalid.
    """
    name = validate_template_name(name)
    path = _template_path(name, project_dir_name)

    if path.exists():
        raise TemplateExistsError(f"Template '{name}' already exists")

    template = {
        "name": name,
        "projectDirName": project_dir_name,
        "sourceSessionId": source_session_id,
        "sourceMessageUuid": source_message_uuid,
        "sourceDisplayName": source_display_name,
        "sourceSlug": source_slug,
        "sourceMessagePreview": source_message_preview,
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "forkCount": 0,
        "lastForkedAt": None,
    }

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(template, indent=2))
    return path


def load_template(name: str, project_dir_name: str) -> dict:
    """Load a template by name.

    Raises:
        TemplateNotFoundError: If the template doesn't exist.
        TemplateCorruptError: If the JSON is invalid.
    """
    path = _template_path(name, project_dir_name)
    if not path.exists():
        available = [t["name"] for t in list_templates(project_dir_name)]
        available_str = ", ".join(available[:10]) if available else "(none)"
        raise TemplateNotFoundError(
            f"Template '{name}' not found. Available: {available_str}"
        )
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError as e:
        raise TemplateCorruptError(f"Template '{name}' has corrupt JSON: {e}") from e


def list_templates(
    project_dir_name: str,
    sort_by: str = "last_forked",
) -> list[dict]:
    """List all templates for a project, sorted.

    sort_by: "last_forked" | "fork_count" | "created" | "name"
    Corrupt templates are skipped with a log warning.
    """
    tpl_dir = _templates_dir(project_dir_name)
    if not tpl_dir.exists():
        return []

    templates: list[dict] = []
    for path in tpl_dir.glob("*.json"):
        try:
            tpl = json.loads(path.read_text())
            templates.append(tpl)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Skipping corrupt template %s: %s", path, e)
            continue

    # Sort
    if sort_by == "fork_count":
        templates.sort(key=lambda t: t.get("forkCount", 0), reverse=True)
    elif sort_by == "created":
        templates.sort(key=lambda t: t.get("createdAt", ""), reverse=True)
    elif sort_by == "name":
        templates.sort(key=lambda t: t.get("name", ""))
    else:  # last_forked (default)
        def _last_forked_key(t: dict) -> str:
            lf = t.get("lastForkedAt")
            if lf:
                return lf
            return t.get("createdAt", "")
        templates.sort(key=_last_forked_key, reverse=True)

    return templates


def delete_template(name: str, project_dir_name: str) -> None:
    """Delete a template by name.

    Raises:
        TemplateNotFoundError: If the template doesn't exist.
    """
    path = _template_path(name, project_dir_name)
    if not path.exists():
        raise TemplateNotFoundError(f"Template '{name}' not found")
    path.unlink()


def rename_template(old_name: str, new_name: str, project_dir_name: str) -> Path:
    """Rename a template.

    Raises:
        TemplateNotFoundError: If the old template doesn't exist.
        TemplateExistsError: If the new name already exists.
        ValueError: If the new name is invalid.
    """
    new_name = validate_template_name(new_name)
    old_path = _template_path(old_name, project_dir_name)
    new_path = _template_path(new_name, project_dir_name)

    if not old_path.exists():
        raise TemplateNotFoundError(f"Template '{old_name}' not found")
    if new_path.exists():
        raise TemplateExistsError(f"Template '{new_name}' already exists")

    # Update the name field inside the JSON too
    tpl = json.loads(old_path.read_text())
    tpl["name"] = new_name
    new_path.write_text(json.dumps(tpl, indent=2))
    old_path.unlink()
    return new_path


def record_usage(name: str, project_dir_name: str) -> None:
    """Increment forkCount and update lastForkedAt for a template.

    Best-effort: last-write-wins on concurrent forks. Acceptable for single-user tool.
    """
    path = _template_path(name, project_dir_name)
    if not path.exists():
        logger.warning("Cannot record usage — template '%s' not found", name)
        return
    try:
        tpl = json.loads(path.read_text())
        tpl["forkCount"] = tpl.get("forkCount", 0) + 1
        tpl["lastForkedAt"] = datetime.now(timezone.utc).isoformat()
        path.write_text(json.dumps(tpl, indent=2))
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to record usage for template '%s': %s", name, e)


def update_fork_point(
    name: str,
    project_dir_name: str,
    new_message_uuid: str,
    new_message_preview: str | None = None,
) -> None:
    """Update the fork point of an existing template.

    Raises:
        TemplateNotFoundError: If the template doesn't exist.
    """
    path = _template_path(name, project_dir_name)
    if not path.exists():
        raise TemplateNotFoundError(f"Template '{name}' not found")

    tpl = json.loads(path.read_text())
    tpl["sourceMessageUuid"] = new_message_uuid
    if new_message_preview is not None:
        tpl["sourceMessagePreview"] = new_message_preview
    path.write_text(json.dumps(tpl, indent=2))


def import_from_forks(project_dir_name: str | None = None) -> list[dict]:
    """Scan ~/.cctree/projects/ for fork metadata sidecars and return them.

    Each returned dict has the fork metadata plus a suggested template name.
    Scans ~/.cctree/projects/**/*.meta.json, filtering for files that contain
    a "forkedFrom" key (confirmed fork sidecars).

    Args:
        project_dir_name: If provided, only scan this project's sidecars.
            If None, scan all projects.

    Returns:
        List of dicts with fork metadata + "suggestedName" field.
    """
    projects_dir = CCTREE_DIR / "projects"
    if not projects_dir.exists():
        return []

    if project_dir_name:
        scan_dirs = [projects_dir / project_dir_name]
    else:
        scan_dirs = [d for d in projects_dir.iterdir() if d.is_dir()]

    discovered: list[dict] = []
    for scan_dir in scan_dirs:
        if not scan_dir.exists():
            continue
        for meta_path in scan_dir.glob("*.meta.json"):
            try:
                data = json.loads(meta_path.read_text())
            except (json.JSONDecodeError, OSError):
                continue

            # Only process fork sidecars (have a "forkedFrom" key)
            if "forkedFrom" not in data:
                continue

            src = data.get("forkedFrom", {})
            # Build a suggested name from the source display name
            src_name = src.get("displayName") or src.get("slug") or ""
            suggested = re.sub(r"[^a-zA-Z0-9_-]", "-", src_name)[:50].strip("-") or "imported-fork"

            # Check if this fork already has a template
            existing_names = {
                t["name"]
                for t in list_templates(scan_dir.name)
            }

            # Auto-suffix to avoid collision
            final_name = suggested
            counter = 2
            while final_name in existing_names:
                final_name = f"{suggested}-{counter}"
                counter += 1

            discovered.append({
                "forkedFrom": src,
                "forgedAt": data.get("forgedAt"),
                "metaPath": str(meta_path),
                "projectDirName": scan_dir.name,
                "suggestedName": final_name,
                "sourceSessionId": src.get("sessionId", ""),
                "sourceMessageUuid": src.get("messageId", ""),
                "sourceDisplayName": src.get("displayName"),
                "sourceSlug": src.get("slug"),
            })

    return discovered
