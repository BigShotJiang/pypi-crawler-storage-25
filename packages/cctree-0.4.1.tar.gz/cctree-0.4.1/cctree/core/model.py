"""Domain models for Claude Code session data.

All models use Pydantic v2 with extra='allow' for schema tolerance —
unknown fields from future Claude Code versions are silently preserved,
never rejected.
"""
from __future__ import annotations

import logging
import re
import threading
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .parser import SessionMetadata

from pydantic import BaseModel, Field

logger = logging.getLogger("cctree.model")


class EventType(str, Enum):
    """Known JSONL event types. Unknown types are stored as raw dicts."""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    PROGRESS = "progress"
    FILE_HISTORY_SNAPSHOT = "file-history-snapshot"
    QUEUE_OPERATION = "queue-operation"
    CUSTOM_TITLE = "custom-title"
    LAST_PROMPT = "last-prompt"


class ContentBlock(BaseModel, extra="allow"):
    """A content block within a message (text, tool_use, tool_result, etc.)."""
    type: str
    text: str | None = None
    # tool_use fields
    id: str | None = None
    name: str | None = None
    input: dict[str, Any] | None = None
    # tool_result fields
    tool_use_id: str | None = None
    content: Any = None  # can be str or list of blocks


class Usage(BaseModel, extra="allow"):
    """Token usage reported by the API for an assistant response.

    total_input = input_tokens + cache_creation_input_tokens + cache_read_input_tokens.
    This equals what Claude Code's /context command reports for that turn.
    """
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    service_tier: str | None = None

    @property
    def total_input(self) -> int:
        return self.input_tokens + self.cache_creation_input_tokens + self.cache_read_input_tokens

    @property
    def is_empty(self) -> bool:
        """True for synthetic events / zero-usage stubs (API errors, cancellations)."""
        return self.total_input == 0 and self.output_tokens == 0


class Message(BaseModel, extra="allow"):
    """The message payload within a user or assistant event."""
    role: str
    content: str | list[ContentBlock] = ""
    model: str | None = None
    id: str | None = None  # API message ID (e.g., "msg_014me...")
    type: str | None = None  # "message" for assistant
    usage: Usage | None = None  # present on assistant events with API response data


# ─── Context window helpers ─────────────────────────────────────────────────

# Known model windows. Update when Anthropic ships new model IDs.
# Fallback baseline is 200K; auto-extended at runtime via observed_total when
# usage exceeds the baseline (see window_size_for_model below).
_WINDOW_SIZES: dict[str, int] = {
    "claude-opus-4-6": 1_000_000,
    "claude-sonnet-4-6": 1_000_000,
}
_DEFAULT_WINDOW = 200_000
_COMMON_WINDOWS_ASCENDING: tuple[int, ...] = (200_000, 500_000, 1_000_000, 2_000_000)

# Runtime overrides for models we observed exceeding their assumed window.
# Populated the first time build_turn_context_map sees an overflow for a given
# model. Lives for the lifetime of the process (fine for interactive use).
_observed_overflow: dict[str, int] = {}


def window_size_for_model(model: str | None, observed_total: int = 0) -> int:
    """Return context window size in tokens for a model ID.

    Resolution order:
      1. Exact match in _WINDOW_SIZES
      2. Date-suffix stripped match (e.g. `claude-haiku-4-5-20251001` → base)
      3. Cached override from a prior overflow observation
      4. observed_total > 200K → auto-extend to next common window + log warning
      5. Fall back to 200K

    Passing observed_total lets unknown new models degrade gracefully: if we
    see them processing >200K tokens, we upgrade the assumption so the percent
    display stays sensible.
    """
    if not model:
        return _DEFAULT_WINDOW
    if model in _WINDOW_SIZES:
        return _WINDOW_SIZES[model]
    base = re.sub(r"-\d{8}$", "", model)
    if base in _WINDOW_SIZES:
        return _WINDOW_SIZES[base]
    if model in _observed_overflow:
        return _observed_overflow[model]
    if observed_total > _DEFAULT_WINDOW:
        bumped = next(
            (w for w in _COMMON_WINDOWS_ASCENDING if w >= observed_total),
            observed_total,
        )
        _observed_overflow[model] = bumped
        logger.warning(
            "unknown model %r: observed usage %d > assumed window %d; "
            "inferring window = %d",
            model, observed_total, _DEFAULT_WINDOW, bumped,
        )
        return bumped
    return _DEFAULT_WINDOW


def short_model_name(model: str | None) -> str:
    """Human-friendly short name for status-bar display.

    Strips `claude-` prefix and trailing -YYYYMMDD date stamps.
    Returns 'synthetic' for the `<synthetic>` marker and '?' for None/empty.
    """
    if not model:
        return "?"
    if model == "<synthetic>":
        return "synthetic"
    name = model[7:] if model.startswith("claude-") else model
    return re.sub(r"-\d{8}$", "", name)


# ─── Model badge formatters ────────────────────────────────────────────────

_MODEL_FAMILY_RE = re.compile(r"([a-z]+(?:-[a-z]+)*)-(\d+(?:-\d+)*)")

_MODEL_COLORS: dict[str, str] = {
    "opus": "blue",
    "sonnet": "green",
    "haiku": "bright_yellow",
}


def _parse_model_parts(model: str | None) -> tuple[str, str]:
    """Split a model ID into (family, version).

    >>> _parse_model_parts("claude-opus-4-6")
    ('opus', '4.6')
    >>> _parse_model_parts("claude-haiku-4-5-20251001")
    ('haiku', '4.5')
    """
    stripped = short_model_name(model)
    if stripped in ("?", "synthetic"):
        return stripped, ""
    m = _MODEL_FAMILY_RE.match(stripped)
    if m:
        return m.group(1), m.group(2).replace("-", ".")
    return stripped, ""


def _format_window(tokens: int) -> str:
    """Human-friendly context window: 1_000_000 → '1M', 200_000 → '200K'."""
    if tokens >= 1_000_000 and tokens % 1_000_000 == 0:
        return f"{tokens // 1_000_000}M"
    if tokens >= 1_000 and tokens % 1_000 == 0:
        return f"{tokens // 1_000}K"
    return str(tokens)


def model_badge_color(model: str) -> str:
    """Rich color name for a model family."""
    family, _ = _parse_model_parts(model)
    return _MODEL_COLORS.get(family, "dim")


def format_model_badge(model: str | None, window_size: int = 0) -> str:
    """Full Rich-markup badge: ``[blue]\\[opus 4.6 1M][/blue]``.

    Returns empty string for None or ``<synthetic>``.
    """
    if not model or model == "<synthetic>":
        return ""
    family, version = _parse_model_parts(model)
    color = _MODEL_COLORS.get(family, "dim")
    parts = [family]
    if version:
        parts.append(version)
    if window_size > 0:
        parts.append(_format_window(window_size))
    inner = " ".join(parts)
    return f"[{color}]\\[{inner}][/{color}]"


def format_model_badge_short(model: str | None) -> str:
    """Short Rich-markup badge: ``[blue]\\[opus][/blue]``.

    Returns empty string for None or ``<synthetic>``.
    """
    if not model or model == "<synthetic>":
        return ""
    family, _ = _parse_model_parts(model)
    color = _MODEL_COLORS.get(family, "dim")
    return f"[{color}]\\[{family}][/{color}]"


class SessionEvent(BaseModel, extra="allow"):
    """A single line/event from a session JSONL file.

    This is the universal event model. Known fields are typed;
    unknown fields are preserved via extra='allow'.
    """
    type: str
    uuid: str | None = None
    parentUuid: str | None = None
    sessionId: str | None = None
    timestamp: str | None = None
    isSidechain: bool | None = None

    # Message events (user/assistant)
    message: Message | None = None
    promptId: str | None = None
    requestId: str | None = None
    slug: str | None = None
    cwd: str | None = None
    gitBranch: str | None = None
    version: str | None = None
    entrypoint: str | None = None
    userType: str | None = None
    permissionMode: str | None = None

    # file-history-snapshot
    messageId: str | None = None
    snapshot: dict[str, Any] | None = None
    isSnapshotUpdate: bool | None = None

    # custom-title
    customTitle: str | None = None

    # compact_boundary (system subtype)
    subtype: str | None = None
    logicalParentUuid: str | None = None
    compactMetadata: dict[str, Any] | None = None
    content: Any = None  # compact summary text

    # last-prompt
    lastPrompt: str | None = None

    # teams
    teamName: str | None = None

    @property
    def is_message(self) -> bool:
        return self.type in (EventType.USER, EventType.ASSISTANT)

    @property
    def is_compact_boundary(self) -> bool:
        return self.type == EventType.SYSTEM and self.subtype == "compact_boundary"

    @property
    def is_custom_title(self) -> bool:
        return self.type == EventType.CUSTOM_TITLE

    @property
    def text_content(self) -> str:
        """Extract plain text from message content."""
        if self.message is None:
            return ""
        if isinstance(self.message.content, str):
            return self.message.content.strip()
        if isinstance(self.message.content, list):
            parts = []
            for block in self.message.content:
                if isinstance(block, ContentBlock):
                    if block.type == "text" and block.text:
                        parts.append(block.text.strip())
                    elif block.type == "tool_result" and isinstance(block.content, str) and block.content:
                        parts.append(block.content.strip())
            return "\n".join(parts)
        return ""

    @property
    def tool_use_blocks(self) -> list[ContentBlock]:
        """Extract tool_use content blocks."""
        if self.message is None or not isinstance(self.message.content, list):
            return []
        return [b for b in self.message.content if isinstance(b, ContentBlock) and b.type == "tool_use"]

    @property
    def tool_result_blocks(self) -> list[ContentBlock]:
        """Extract tool_result content blocks."""
        if self.message is None or not isinstance(self.message.content, list):
            return []
        return [b for b in self.message.content if isinstance(b, ContentBlock) and b.type == "tool_result"]

    @property
    def image_blocks(self) -> list[ContentBlock]:
        """Extract image content blocks (media_type etc. in model_extra.source)."""
        if self.message is None or not isinstance(self.message.content, list):
            return []
        return [b for b in self.message.content if isinstance(b, ContentBlock) and b.type == "image"]


class Session:
    """A parsed Claude Code session with metadata.

    This is NOT a Pydantic model — it's a plain class built by the parser
    from a list of SessionEvents. Keeps memory low by not duplicating the
    full event list (events are loaded on demand via the parser).

    Two construction paths:
      - **Eager** (tests): ``Session(uuid, slug, path, events=[...])``
      - **Lazy** (production): ``Session(uuid, slug, path, _metadata=meta)``
        Events stay None until ``.events`` is accessed.
    """

    def __init__(
        self,
        uuid: str,
        project_slug: str,
        path: str,
        events: list[SessionEvent] | None = None,
        *,
        fork_suffix: str | None = None,
        _metadata: SessionMetadata | None = None,
    ) -> None:
        self.uuid = uuid
        self.project_slug = project_slug
        self.path = path
        self._fork_suffix = fork_suffix
        self._events_lock = threading.Lock()

        # Derived metadata defaults
        self.slug: str | None = None
        self.custom_title: str | None = None
        self.message_count: int = 0
        self.first_user_message: str = ""
        self.started_at: datetime | None = None
        self.last_activity_at: datetime | None = None
        self.has_compaction: bool = False
        self.compact_boundary_count: int = 0
        self.claude_version: str | None = None
        self.team_name: str | None = None

        if _metadata is not None:
            # Lazy path: populate from pre-extracted metadata, events stay None
            self._events = None
            self.slug = _metadata.slug
            self.custom_title = _metadata.custom_title
            self.message_count = _metadata.message_count
            self.first_user_message = _metadata.first_user_message
            self.started_at = _metadata.started_at
            self.last_activity_at = _metadata.last_activity_at
            self.has_compaction = _metadata.has_compaction
            self.compact_boundary_count = _metadata.compact_boundary_count
            self.claude_version = _metadata.claude_version
            self.team_name = _metadata.team_name
        elif events is not None:
            # Eager path: derive metadata from events
            self._events = events
            self._derive_metadata()
        else:
            # Neither provided — empty session
            self._events = []

        # Model-layer slug override for forks — JSONL is untouched
        if fork_suffix and self.slug:
            self.slug = f"{self.slug}-fork-{fork_suffix}"

    def _derive_metadata(self) -> None:
        """Extract metadata from the event stream."""
        first_user_seen = False
        for evt in self._events:
            # Slug (first seen wins — it's session-stable)
            if self.slug is None and evt.slug:
                self.slug = evt.slug

            # Custom title (last seen wins)
            if evt.is_custom_title and evt.customTitle:
                self.custom_title = evt.customTitle

            # Message count
            if evt.is_message:
                self.message_count += 1

            # First user message
            if not first_user_seen and evt.type == EventType.USER:
                self.first_user_message = evt.text_content[:200]
                first_user_seen = True

            # Timestamps
            if evt.timestamp:
                try:
                    ts = datetime.fromisoformat(evt.timestamp.replace("Z", "+00:00"))
                    if self.started_at is None:
                        self.started_at = ts
                    self.last_activity_at = ts
                except ValueError:
                    pass

            # Compaction
            if evt.is_compact_boundary:
                self.has_compaction = True
                self.compact_boundary_count += 1

            # Claude version
            if self.claude_version is None and evt.version:
                self.claude_version = evt.version

            # Team name (first seen wins — it's session-stable)
            if self.team_name is None and evt.teamName:
                self.team_name = evt.teamName

    def _load_events(self) -> None:
        """Lazy-load events from disk. Thread-safe, called at most once."""
        from .parser import parse_jsonl

        with self._events_lock:
            if self._events is not None:
                return
            self._events = parse_jsonl(Path(self.path))
            # Re-derive metadata from actual events (authoritative source)
            self.slug = None
            self.custom_title = None
            self.message_count = 0
            self.first_user_message = ""
            self.started_at = None
            self.last_activity_at = None
            self.has_compaction = False
            self.compact_boundary_count = 0
            self.claude_version = None
            self.team_name = None
            self._derive_metadata()
            # Re-apply fork suffix
            if self._fork_suffix and self.slug:
                self.slug = f"{self.slug}-fork-{self._fork_suffix}"

    @property
    def events(self) -> list[SessionEvent]:
        if self._events is None:
            self._load_events()
        return self._events

    @property
    def is_team_lead(self) -> bool:
        """True iff any event carries a teamName (session is a team lead)."""
        return self.team_name is not None

    @property
    def display_name(self) -> str:
        """Best available name: customTitle > slug > short UUID."""
        if self.custom_title:
            return self.custom_title
        if self.slug:
            return self.slug
        return self.uuid[:12]

    def messages(self) -> list[SessionEvent]:
        """Return only user/assistant message events."""
        return [e for e in self.events if e.is_message]

    def events_before_compact(self, boundary_index: int = 0) -> list[SessionEvent]:
        """Return events before the Nth compact boundary (0 = most recent)."""
        evts = self.events
        boundaries = [i for i, e in enumerate(evts) if e.is_compact_boundary]
        if not boundaries:
            return evts[:]
        # boundary_index=0 means most recent (last in list)
        target_idx = len(boundaries) - 1 - boundary_index
        if target_idx < 0:
            return evts[:]
        return evts[:boundaries[target_idx]]

    def __repr__(self) -> str:
        return f"Session(uuid={self.uuid[:8]!r}, name={self.display_name!r}, msgs={self.message_count})"
