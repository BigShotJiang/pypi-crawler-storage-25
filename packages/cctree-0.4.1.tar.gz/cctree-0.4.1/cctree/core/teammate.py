"""Parse <teammate-message> tags from team-lead user-message content.

When a team-lead session receives messages from teammates, those messages are
injected into the lead's JSONL as user events whose `content` is a string
containing one or more tags:

    <teammate-message teammate_id="NAME" [color="..."] [summary="..."]>
    body text or embedded JSON protocol
    </teammate-message>

Some bodies are plain prose; others are structured protocol JSON such as
`{"type": "idle_notification", ...}` or `{"type": "shutdown_request", ...}`.

This module is pure (no I/O, no logging side effects in the happy path) so it
can be used freely by TUI renderers, fork filters, and tests.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

# Non-greedy body match with DOTALL so \n inside the body is preserved.
_TAG_RE = re.compile(
    r"<teammate-message\s+(?P<attrs>[^>]*?)>(?P<body>.*?)</teammate-message>",
    re.DOTALL,
)

# Attribute extraction — values are double-quoted in the real format.
_ATTR_RE = re.compile(r'(\w+)\s*=\s*"([^"]*)"')


@dataclass(frozen=True)
class TeammateMessageBlock:
    """One parsed <teammate-message> block."""

    teammate_id: str
    color: str | None
    summary: str | None
    body: str
    protocol: dict[str, Any] | None


def _parse_attrs(attrs_str: str) -> dict[str, str]:
    return dict(_ATTR_RE.findall(attrs_str))


def _maybe_protocol(body: str) -> dict[str, Any] | None:
    """Return parsed JSON dict iff body is a valid JSON object with a 'type' field."""
    stripped = body.strip()
    if not stripped.startswith("{"):
        return None
    try:
        parsed = json.loads(stripped)
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(parsed, dict):
        return None
    if "type" not in parsed:
        return None
    return parsed


def parse_teammate_messages(content: str) -> list[TeammateMessageBlock]:
    """Extract all <teammate-message> blocks from a user-message content string.

    Returns them in the order they appear. Malformed (unclosed) tags are silently
    omitted — this function never raises.
    """
    if not content:
        return []

    blocks: list[TeammateMessageBlock] = []
    for match in _TAG_RE.finditer(content):
        attrs = _parse_attrs(match.group("attrs"))
        teammate_id = attrs.get("teammate_id")
        if not teammate_id:
            continue
        body = match.group("body")
        blocks.append(
            TeammateMessageBlock(
                teammate_id=teammate_id,
                color=attrs.get("color"),
                summary=attrs.get("summary"),
                body=body,
                protocol=_maybe_protocol(body),
            )
        )
    return blocks


def contains_teammate_message(content: str) -> bool:
    """Cheap pre-check: does content appear to contain a teammate-message tag?

    Uses substring match (O(n)) before running the real regex.
    """
    if not content:
        return False
    return "<teammate-message" in content
