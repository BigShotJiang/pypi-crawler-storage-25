"""Claude Code version parsing and compatibility checking."""
from __future__ import annotations

import re
from dataclasses import dataclass

# Known-good version range for cctree
# Pinned to the exact version we've tested and verified against
MIN_VERSION = (2, 1, 77)
MAX_TESTED_VERSION = (2, 1, 77)


@dataclass
class VersionCheckResult:
    """Result of a version compatibility check."""
    compatible: bool
    warning: str | None = None
    message: str = ""


def parse_claude_version(version_string: str) -> tuple[int, int, int] | None:
    """Parse a Claude Code version string like '2.1.77 (Claude Code)'.

    Returns (major, minor, patch) or None if unparseable.
    """
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)", version_string)
    if not match:
        return None
    return (int(match.group(1)), int(match.group(2)), int(match.group(3)))


def check_version_compat(version: tuple[int, int, int]) -> VersionCheckResult:
    """Check whether a Claude Code version is compatible with cctree.

    - Below MIN_VERSION: incompatible (JSONL schema may differ)
    - Between MIN and MAX_TESTED: compatible, no warnings
    - Above MAX_TESTED: compatible but warn (untested territory)
    """
    if version < MIN_VERSION:
        return VersionCheckResult(
            compatible=False,
            message=f"Claude Code {_fmt(version)} is below minimum supported version {_fmt(MIN_VERSION)}. "
                    f"JSONL schema may be incompatible.",
        )

    if version > MAX_TESTED_VERSION:
        return VersionCheckResult(
            compatible=True,
            warning=f"Claude Code {_fmt(version)} is newer than the latest tested version "
                    f"{_fmt(MAX_TESTED_VERSION)}. cctree may encounter unknown event types.",
            message="",
        )

    return VersionCheckResult(compatible=True, message="")


def _fmt(v: tuple[int, int, int]) -> str:
    return f"{v[0]}.{v[1]}.{v[2]}"
