"""Per-turn active agent tracking — subagents, teammates, tasks.

Scans the event stream and tracks which agents/tasks were active at each
turn by following tool_use → tool_result spans.

Data flow:

    events → build_active_agents_map → dict[event.uuid, ActiveAgentsSnapshot]
                                              │
                                              ▼
    TreeNode (rendering) → lookup by uuid → ActiveAgentsSnapshot | None
                                              │
                                              ▼
                           format column text → "🤖sub1 +2" (Rich markup)

Span tracking:
  - Agent tool_use (block.id) → opens a span (agent becomes "active")
  - Agent tool_result (block.tool_use_id) → closes the span
  - Open spans (no matching result — session interrupted) stay active
    through the end of the session (correct semantic)
  - TaskCreate/TaskUpdate/SendMessage/TeamCreate tool_use blocks are
    noted per-event (point events, not spans)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from .model import EventType, SessionEvent

logger = logging.getLogger("cctree.active_agents")


@dataclass
class ActiveAgentsSnapshot:
    """What agents/tasks/teams were active at a given turn."""

    subagents: list[str] = field(default_factory=list)
    teammates: list[str] = field(default_factory=list)
    tasks: list[str] = field(default_factory=list)
    pending_questions: list[str] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        return (not self.subagents and not self.teammates
                and not self.tasks and not self.pending_questions)


def build_active_agents_map(
    events: list[SessionEvent],
) -> dict[str, ActiveAgentsSnapshot]:
    """Build UUID→ActiveAgentsSnapshot for a session's event stream.

    Tracks Agent tool_use→tool_result spans to determine which subagents
    were running at each turn. Also notes TaskCreate/TaskUpdate and
    SendMessage/TeamCreate as point events.
    """
    # Active Agent spans: tool_use_id → description
    open_agents: dict[str, str] = {}
    # Active tasks: auto-assigned task_id → label
    task_map: dict[str, str] = {}
    task_counter = 0
    # Open AskUserQuestion spans: tool_use_id → question text
    open_questions: dict[str, str] = {}
    ctx_map: dict[str, ActiveAgentsSnapshot] = {}

    for evt in events:
        if evt.type not in (EventType.USER, EventType.ASSISTANT):
            continue
        if evt.message is None or not isinstance(evt.message.content, list):
            # User events or events with no structured content — snapshot current state
            if evt.uuid and (open_agents or task_map or open_questions):
                ctx_map[evt.uuid] = ActiveAgentsSnapshot(
                    subagents=list(open_agents.values()),
                    tasks=list(task_map.values()),
                    pending_questions=list(open_questions.values()),
                )
            continue

        turn_teammates: list[str] = []

        for block in evt.message.content:
            if not hasattr(block, "type"):
                continue

            if block.type == "tool_use" and block.name == "Agent":
                # Open a new agent span
                if block.id:
                    desc = (block.input or {}).get("description", "")[:30]
                    open_agents[block.id] = desc

            elif block.type == "tool_use" and block.name == "SendMessage":
                to = (block.input or {}).get("to", "")[:20]
                if to:
                    turn_teammates.append(to)

            elif block.type == "tool_use" and block.name == "TaskCreate":
                task_counter += 1
                subj = (block.input or {}).get("subject", "")[:20]
                explicit_id = (block.input or {}).get("id", "")
                key = explicit_id or str(task_counter)
                task_map[key] = subj or "task"

            elif block.type == "tool_use" and block.name == "TaskUpdate":
                tid = (block.input or {}).get("taskId", "")
                status = (block.input or {}).get("status", "")
                if tid and status in ("deleted", "completed"):
                    task_map.pop(tid, None)

            elif block.type == "tool_use" and block.name == "AskUserQuestion":
                if block.id:
                    q = (block.input or {}).get("question", "")[:30]
                    open_questions[block.id] = q or "question"

            elif block.type == "tool_use" and block.name in (
                "TeamCreate", "TeamDelete",
            ):
                team = (block.input or {}).get("team_name", "")[:20]
                if team:
                    turn_teammates.append(team)

            elif block.type == "tool_result" and block.tool_use_id:
                if block.tool_use_id in open_agents:
                    del open_agents[block.tool_use_id]
                if block.tool_use_id in open_questions:
                    del open_questions[block.tool_use_id]

        # Snapshot active state for this event
        if evt.uuid:
            snap = ActiveAgentsSnapshot(
                subagents=list(open_agents.values()),
                teammates=turn_teammates,
                tasks=list(task_map.values()),
                pending_questions=list(open_questions.values()),
            )
            if not snap.is_empty:
                ctx_map[evt.uuid] = snap

    return ctx_map


def format_agents_status_line(snap: ActiveAgentsSnapshot | None) -> str:
    """Format agent snapshot for status bar drill-down.

    Returns a Rich-markup line like '📋 3 tasks: Fix auth, Add tests, Refactor DB · 🤖 research code'
    or '' if no annotations.
    """
    if snap is None or snap.is_empty:
        return ""
    parts: list[str] = []
    if snap.tasks:
        task_list = ", ".join(snap.tasks[:5])
        suffix = f" +{len(snap.tasks) - 5}" if len(snap.tasks) > 5 else ""
        parts.append(f"📋 {len(snap.tasks)} tasks: {task_list}{suffix}")
    if snap.subagents:
        agent_list = ", ".join(snap.subagents[:3])
        suffix = f" +{len(snap.subagents) - 3}" if len(snap.subagents) > 3 else ""
        parts.append(f"🤖 {agent_list}{suffix}")
    if snap.teammates:
        tm_list = ", ".join(snap.teammates[:3])
        parts.append(f"👥 {tm_list}")
    if snap.pending_questions:
        parts.append(f"❓ {len(snap.pending_questions)} pending")
    return " · ".join(parts)
