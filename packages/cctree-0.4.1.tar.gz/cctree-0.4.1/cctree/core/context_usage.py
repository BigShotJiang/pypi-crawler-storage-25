"""Per-turn context window tracking — lead sessions, subagents, teammates.

Surfaces the accumulated context at each turn exactly as Claude Code's
`/context` command would have reported it, by reading the `usage` field that's
already present on every assistant event in the JSONL.

Data flow:

    events → build_turn_context_map → dict[event.uuid, TurnContext]
                                            │
                                            ▼
    TreeNode (highlighted) → lookup by uuid → TurnContext | None
                                            │
                                            ▼
                            format_status_lines → list[str] (1-3 Rich lines)

Variants:
  - build_turn_context_map(events)               — main lead session
  - build_turn_context_map(events, outer=TC)     — Agent-tool subagent
  - build_turn_context_map_for_wake_ups(files,…) — teammate (multi-wake-up,
                                                    resets Δ per file)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from rich.markup import escape as _escape_markup

from .model import EventType, SessionEvent, short_model_name, window_size_for_model

logger = logging.getLogger("cctree.context_usage")


@dataclass
class TurnContext:
    """Context snapshot for a single turn.

    `delta` is None for the first turn of a stream (nothing to compare against).
    `outer` is set only for turns inside an Agent-tool subagent — drives the
    3-line "parent + sub" status-bar layout.
    `is_wake_up_start` is True for the first real assistant turn of a teammate
    wake-up file, so the UI can show `Δ —  (new wake-up)`.
    """
    input_tokens: int
    output_tokens: int
    cache_read: int
    cache_creation: int
    total_input: int
    model: str
    model_short: str
    window_size: int
    percent: float
    delta: int | None = None
    outer: "TurnContext | None" = None
    teammate_name: str | None = None
    teammate_color: str | None = None
    is_wake_up_start: bool = False


def build_turn_context_map(
    events: list[SessionEvent],
    *,
    outer: TurnContext | None = None,
    teammate_name: str | None = None,
    teammate_color: str | None = None,
    mark_wake_up_start: bool = False,
) -> dict[str, TurnContext]:
    """Build UUID→TurnContext for a single event stream.

    - Assistant UUIDs → context at that response.
    - User UUIDs      → prior assistant's context (what was visible when the
                        user typed, including teammate-message user events and
                        tool-result-only user events).
    - Compact-boundary UUIDs → prior assistant's context (the moment the user
                        watched the conversation shrink — informative, not "no
                        data").
    - Synthetic / zero-usage assistant events are SKIPPED. Prior real turn's
      context stays "sticky" for any following user-event mappings.
    """
    ctx_map: dict[str, TurnContext] = {}
    last_tc: TurnContext | None = None
    first_real_emitted = False

    for evt in events:
        if evt.type == EventType.USER and evt.uuid and last_tc is not None:
            ctx_map[evt.uuid] = last_tc
        elif evt.is_compact_boundary and evt.uuid and last_tc is not None:
            ctx_map[evt.uuid] = last_tc
        elif evt.type == EventType.ASSISTANT and evt.message is not None:
            usage = evt.message.usage
            model = evt.message.model or ""
            if usage is None or usage.is_empty or model == "<synthetic>":
                continue
            total = usage.total_input
            window = window_size_for_model(model, observed_total=total)
            delta = (total - last_tc.total_input) if last_tc is not None else None
            tc = TurnContext(
                input_tokens=usage.input_tokens,
                output_tokens=usage.output_tokens,
                cache_read=usage.cache_read_input_tokens,
                cache_creation=usage.cache_creation_input_tokens,
                total_input=total,
                model=model,
                model_short=short_model_name(model),
                window_size=window,
                percent=(total / window * 100) if window else 0.0,
                delta=delta,
                outer=outer,
                teammate_name=teammate_name,
                teammate_color=teammate_color,
                is_wake_up_start=(mark_wake_up_start and not first_real_emitted),
            )
            if evt.uuid:
                ctx_map[evt.uuid] = tc
            last_tc = tc
            first_real_emitted = True
    return ctx_map


def build_turn_context_map_for_wake_ups(
    per_file_events: list[list[SessionEvent]],
    *,
    teammate_name: str,
    teammate_color: str | None,
) -> dict[str, TurnContext]:
    """Process each wake-up file independently so delta resets per wake-up.

    Each wake-up file is a fresh agent process with its own context window
    baseline — running one context map across the merged timeline would show
    misleading negative deltas at file boundaries. Instead, we build per-file
    maps and union them. The first real assistant turn of each file is
    flagged with `is_wake_up_start=True` so the UI can render the reset.
    """
    out: dict[str, TurnContext] = {}
    for events in per_file_events:
        out.update(build_turn_context_map(
            events,
            teammate_name=teammate_name,
            teammate_color=teammate_color,
            mark_wake_up_start=True,
        ))
    return out


# ─── Rendering ──────────────────────────────────────────────────────────────

_BAR_WIDTH = 20


def _stacked_bar(tc: TurnContext, width: int = _BAR_WIDTH) -> str:
    """Render a stacked progress bar.

    Segments (left to right): input tokens (white), cache-read tokens (blue),
    cache-creation tokens (magenta). Unfilled region is dim ░. This palette
    is INDEPENDENT from the tree-widget palette — see the plan's "Color system
    notes" for why cross-widget color reuse is OK here.
    """
    if tc.window_size == 0:
        return "▕" + "░" * width + "▏"
    total_chars = int(round(tc.total_input / tc.window_size * width))
    if total_chars == 0 and tc.total_input > 0:
        total_chars = 1
    total_chars = min(total_chars, width)

    # Proportional split of the filled portion by component
    t = max(tc.total_input, 1)
    input_chars = int(round(tc.input_tokens / t * total_chars))
    read_chars = int(round(tc.cache_read / t * total_chars))
    create_chars = max(0, total_chars - input_chars - read_chars)
    empty_chars = width - total_chars

    return (
        "▕"
        + f"[white]{'█' * input_chars}[/white]"
        + f"[blue]{'█' * read_chars}[/blue]"
        + f"[magenta]{'█' * create_chars}[/magenta]"
        + f"[dim]{'░' * empty_chars}[/dim]"
        + "▏"
    )


def _threshold_color(pct: float) -> str:
    """Percent-number color by severity (bar fill colors unchanged)."""
    if pct >= 95:
        return "red"
    if pct >= 80:
        return "orange1"
    if pct >= 50:
        return "yellow"
    return "white"


def _humanize(n: int) -> str:
    """Format a token count compactly: 1234 → '1.2K', 1234567 → '1.2M'."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def _delta_threshold_color(delta: int) -> str:
    """Color for per-turn delta values: white <1K, yellow 1-5K, orange ≥5K."""
    abs_delta = abs(delta)
    if abs_delta >= 5_000:
        return "orange1"
    if abs_delta >= 1_000:
        return "yellow"
    return "white"


def format_delta_label(tc: TurnContext | None) -> str:
    """Inline delta label for assistant node annotations.

    Returns e.g. '[yellow]+1.2K[/yellow]' showing only the context added
    by this specific turn, or '[dim]—[/dim]' if no data.
    """
    if tc is None or tc.delta is None:
        return "[dim]—[/dim]"
    sign = "+" if tc.delta >= 0 else "-"
    c = _delta_threshold_color(tc.delta)
    return f"[{c}]{sign}{_humanize(abs(tc.delta))}[/{c}]"


_MINI_BAR_WIDTH = 5
_MINI_NUM_WIDTH = 6  # fixed width for the number label (e.g. "184.6K")


def format_mini_bar(tc: TurnContext | None) -> str:
    """Inline mini context bar for tree node annotations.

    Returns e.g. '▕░░░██▏ 3.2K' with single-color threshold fill growing
    right-to-left, or '[dim]—[/dim]' if tc is None (no data).

    The number label is right-justified to a fixed width so the bar column
    has a constant visual width across all rows, preventing misalignment.
    """
    if tc is None:
        return "[dim]—[/dim]"
    w = _MINI_BAR_WIDTH
    num = _humanize(tc.total_input).rjust(_MINI_NUM_WIDTH)
    if tc.window_size == 0:
        return num + "▕" + "░" * w + "▏"
    filled = int(round(tc.total_input / tc.window_size * w))
    if filled == 0 and tc.total_input > 0:
        filled = 1
    filled = min(filled, w)
    empty = w - filled
    c = _threshold_color(tc.percent)
    return f"{num}▕[dim]{'░' * empty}[/dim][{c}]{'█' * filled}[/{c}]▏"


def _delta_str(tc: TurnContext) -> str:
    if tc.is_wake_up_start:
        return "Δ —  (new wake-up)"
    if tc.delta is None:
        return "Δ —"
    if tc.delta >= 0:
        return f"Δ+{_humanize(tc.delta)}"
    return f"Δ−{_humanize(-tc.delta)}"


_NO_DATA_MESSAGES = {
    "older_session":        "ctx: — (this session predates per-turn usage logging)",
    "synthetic":            "ctx: — (synthetic event; no context delta)",
    "session_start":        "ctx: — (session start)",
    "teammates_section":    "ctx: — (expand to load teammate timeline)",
    "subagent_placeholder": "ctx: — (expand to load subagent)",
    "teammate_placeholder": "ctx: — (expand to load teammate timeline)",
    "teammate_empty":       "ctx: — (teammate has no transcripts)",
    "template":             "ctx: — (template metadata; no turn context)",
    "unknown":              "ctx: — (no usage data)",
}


def format_no_data(reason: str = "unknown") -> list[str]:
    msg = _NO_DATA_MESSAGES.get(reason, _NO_DATA_MESSAGES["unknown"])
    return [f"[dim]{msg}[/dim]"]


def format_status_lines(
    tc: TurnContext | None,
    *,
    narrow: bool = False,
    no_data_reason: str = "unknown",
) -> list[str]:
    """Return 1-3 Rich-markup lines for the status bar.

    Layout:
      normal (2 lines):   [bar + total/window + % + Δ + model]
                          [in:N +read:N +create:N out:N]

      subagent (3 lines): [↳ sub  bar + … + Δ + model]
                          [in:N +read:N +create:N out:N]
                          [from parent turn: total/window (%) · model]  (dim)

      teammate (2 lines): [name·  bar + … + Δ + model]   (name in teammate color)
                          [in:N +read:N +create:N out:N]

      narrow (compact):   bar width 12, model moved to line 2,
                          breakdown abbreviated (r:/c:/o:).

      no data:            single dim line with contextual reason.
    """
    if tc is None:
        return format_no_data(no_data_reason)

    bar_width = 12 if narrow else _BAR_WIDTH

    c = _threshold_color(tc.percent)
    warn = "[red]⚠[/red] " if tc.percent >= 95 else ""
    prefix = ""
    if tc.teammate_name:
        color = tc.teammate_color or "cyan"
        # teammate_name comes from meta.agentType (user-controllable); escape
        # to prevent Rich markup injection like "Agent[prod]".
        safe_name = _escape_markup(tc.teammate_name)
        prefix = f"[{color}]{safe_name} ·[/{color}] "
    elif tc.outer is not None:
        prefix = " ↳ sub  "

    # Model IDs from third-party proxies could also contain brackets.
    safe_model = _escape_markup(tc.model_short)

    # ── Line 1: primary (this turn's bar) ───────────────────────────────────
    line1_tail = (
        f"[bold]{_humanize(tc.total_input)}[/bold]/{_humanize(tc.window_size)} "
        f"([{c}]{tc.percent:.1f}%[/{c}])  {_delta_str(tc)}"
    )
    if not narrow:
        line1_tail += f"  [dim]· {safe_model}[/dim]"
    lines: list[str] = [f"{warn}{prefix}{_stacked_bar(tc, width=bar_width)} {line1_tail}"]

    # ── Line 2: breakdown (+ model if narrow) ───────────────────────────────
    if narrow:
        line2 = (
            f"in:{tc.input_tokens}  "
            f"r:{_humanize(tc.cache_read)}  "
            f"c:{_humanize(tc.cache_creation)}  "
            f"o:{tc.output_tokens}  "
            f"[dim]· {safe_model}[/dim]"
        )
    else:
        line2 = (
            f"in:{tc.input_tokens}  "
            f"+read:{_humanize(tc.cache_read)}  "
            f"+create:{_humanize(tc.cache_creation)}  "
            f"out:{tc.output_tokens}"
        )
    lines.append(line2)

    # ── Line 3: parent context (subagent mode only, dim) ────────────────────
    if tc.outer is not None:
        outer = tc.outer
        lines.append(
            f"[dim]from parent turn: "
            f"{_humanize(outer.total_input)}/{_humanize(outer.window_size)} "
            f"({outer.percent:.1f}%) · {_escape_markup(outer.model_short)}[/dim]"
        )
    return lines
