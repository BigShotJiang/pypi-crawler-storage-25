"""Team-aware fork cloning.

When a team-lead session is forked, this module clones the associated team
state so the forked session is fully self-contained and independently resumable:

  - team dir:  ~/.claude/teams/{old}/  →  ~/.claude/teams/{new}/
    · config.json rewritten (name, leadSessionId, leadAgentId, members[].agentId)
    · inboxes/*.json filtered to timestamp ≤ cut
  - task dir:  ~/.claude/tasks/{new}/  built from TaskCreate/Update/Delete replay
                of the forged prefix events (no file copy — state is derived)
  - teammate JSONLs: <old-session-dir>/subagents/*  →  <new-session-dir>/subagents/*
    · events filtered to timestamp ≤ cut
    · UUIDs + sessionId remapped via the uuid_map passed in from forge
    · Agent-tool subagent files are NOT copied (the existing fallback
      resolution in subagent_link handles those)

Failure of the team clone never nukes the forged JSONL that forge_session
already wrote — the caller is responsible for ordering.
"""
from __future__ import annotations

import json
import logging
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from .team import DEFAULT_TASKS_BASE, DEFAULT_TEAMS_BASE
from .teammate_sessions import is_teammate_meta, read_agent_meta

logger = logging.getLogger("cctree.team_forge")


class TeamForgeError(Exception):
    """Raised when team cloning fails before any writes."""


@dataclass
class TeamForgeResult:
    new_team_name: str
    new_team_dir: Path
    cloned_teammate_jsonl_count: int = 0
    cloned_task_count: int = 0
    filtered_inbox_count: int = 0
    team_source_existed: bool = True
    cloned_teammate_paths: list[Path] = field(default_factory=list)


_AGENT_ID_TEAM_SUFFIX_RE = re.compile(r"^(.+?)@(.+)$")


def derive_new_team_name(
    original_name: str,
    new_session_id: str,
    teams_base: Path = DEFAULT_TEAMS_BASE,
) -> str:
    """Build a collision-free fork name: '{original}-fork-{session_prefix}[-{n}]'."""
    session_prefix = new_session_id.split("-")[0][:8] or new_session_id[:8]
    base = f"{original_name}-fork-{session_prefix}"
    candidate = base
    i = 1
    while (teams_base / candidate).exists():
        candidate = f"{base}-{i}"
        i += 1
    return candidate


def _rewrite_agent_id(agent_id: str, old_team: str, new_team: str) -> str:
    """Rewrite '{role}@{old_team}' to '{role}@{new_team}'. Non-matching passes through."""
    match = _AGENT_ID_TEAM_SUFFIX_RE.match(agent_id)
    if not match or match.group(2) != old_team:
        return agent_id
    return f"{match.group(1)}@{new_team}"


def _rewrite_team_config(
    config_path: Path, old_team: str, new_team: str, new_session_id: str
) -> None:
    """In-place edit of the cloned config.json."""
    raw = json.loads(config_path.read_text())
    raw["name"] = new_team
    raw["leadSessionId"] = new_session_id
    if "leadAgentId" in raw and isinstance(raw["leadAgentId"], str):
        raw["leadAgentId"] = _rewrite_agent_id(raw["leadAgentId"], old_team, new_team)
    if "members" in raw and isinstance(raw["members"], list):
        for m in raw["members"]:
            if isinstance(m, dict) and "agentId" in m and isinstance(m["agentId"], str):
                m["agentId"] = _rewrite_agent_id(m["agentId"], old_team, new_team)
    config_path.write_text(json.dumps(raw, indent=2))


def _filter_inbox(inbox_path: Path, cut_timestamp: str) -> int:
    """In-place filter of inbox JSON: drop entries with timestamp > cut.

    Returns the number of messages kept.
    """
    raw = json.loads(inbox_path.read_text())
    if not isinstance(raw, list):
        return 0
    kept = [e for e in raw if isinstance(e, dict)
            and e.get("timestamp", "") <= cut_timestamp]
    inbox_path.write_text(json.dumps(kept, indent=2))
    return len(kept)


_TASK_ID_RE = re.compile(r"Task #(\d+)")


def _extract_tool_result_text(block: dict) -> str:
    """Extract text from a tool_result block (string or list-of-text format)."""
    content = block.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                return item.get("text", "")
    return ""


def _build_task(task_id: str, inp: dict) -> dict:
    """Build a task dict from a TaskCreate input + assigned ID."""
    task: dict = {
        "id": task_id,
        "subject": inp.get("subject", ""),
        "status": inp.get("status", "pending"),
        "blocks": inp.get("blocks", []),
        "blockedBy": inp.get("blockedBy", []),
    }
    for k in ("description", "activeForm"):
        if k in inp:
            task[k] = inp[k]
    for k, v in inp.items():
        if k not in task:
            task[k] = v
    return task


def replay_tasks(prefix_events: list[dict]) -> dict[str, dict]:
    """Scan prefix_events for Task tool_use blocks and build final task state.

    Handles two wire formats:
    - Legacy: TaskCreate input contains ``id`` directly.
    - Real Claude Code: TaskCreate input has NO ``id``; the server assigns one
      and returns it in the tool_result text ("Task #N created successfully").
      TaskUpdate/TaskDelete use ``taskId`` instead of ``id``.
    """
    tasks: dict[str, dict] = {}
    # Pending TaskCreate tool_uses waiting for their tool_result with the
    # server-assigned ID.
    pending_creates: dict[str, dict] = {}

    for raw in prefix_events:
        ev_type = raw.get("type")
        message = raw.get("message") or {}
        content = message.get("content")
        if not isinstance(content, list):
            continue

        if ev_type == "assistant":
            for block in content:
                if not isinstance(block, dict) or block.get("type") != "tool_use":
                    continue
                name = block.get("name")
                inp = block.get("input") or {}
                if not isinstance(inp, dict):
                    continue

                if name == "TaskCreate":
                    task_id = inp.get("id")
                    if task_id:
                        # Legacy format — id is in the input
                        tasks[task_id] = _build_task(task_id, inp)
                    else:
                        # Real format — stash until we see the tool_result
                        tool_use_id = block.get("id")
                        if tool_use_id:
                            pending_creates[tool_use_id] = dict(inp)

                elif name == "TaskUpdate":
                    task_id = inp.get("taskId") or inp.get("id")
                    if not task_id or task_id not in tasks:
                        continue
                    if inp.get("status") == "deleted":
                        tasks.pop(task_id, None)
                    else:
                        for k, v in inp.items():
                            if k != "taskId" and v is not None:
                                tasks[task_id][k] = v

                elif name == "TaskDelete":
                    task_id = inp.get("taskId") or inp.get("id")
                    if task_id:
                        tasks.pop(task_id, None)

        elif ev_type == "user" and pending_creates:
            for block in content:
                if not isinstance(block, dict) or block.get("type") != "tool_result":
                    continue
                tool_use_id = block.get("tool_use_id")
                if tool_use_id not in pending_creates:
                    continue
                result_text = _extract_tool_result_text(block)
                match = _TASK_ID_RE.search(result_text)
                if not match:
                    continue
                task_id = match.group(1)
                inp = pending_creates.pop(tool_use_id)
                tasks[task_id] = _build_task(task_id, inp)

    return tasks


def write_tasks(tasks: dict[str, dict], out_dir: Path) -> int:
    out_dir.mkdir(parents=True, exist_ok=True)
    for task in tasks.values():
        task_id = task["id"]
        (out_dir / f"{task_id}.json").write_text(json.dumps(task, indent=2))
    return len(tasks)


def _remap_line(raw: dict, uuid_map: dict[str, str], new_session_id: str) -> dict:
    """Apply uuid_map to the standard UUID fields + sessionId."""
    if "sessionId" in raw:
        raw["sessionId"] = new_session_id

    def remap(val):
        if isinstance(val, str) and val in uuid_map:
            return uuid_map[val]
        return val

    for k in ("uuid", "parentUuid", "promptId", "messageId",
              "logicalParentUuid"):
        if k in raw and raw[k]:
            raw[k] = remap(raw[k])
    if isinstance(raw.get("snapshot"), dict):
        snap = raw["snapshot"]
        if "messageId" in snap and snap["messageId"]:
            snap["messageId"] = remap(snap["messageId"])
    return raw


def _clone_teammate_jsonls(
    original_session_dir: Path,
    new_session_dir: Path,
    cut_timestamp: str,
    uuid_map: dict[str, str],
    new_session_id: str,
) -> list[Path]:
    """Copy teammate JSONLs (not Agent-tool subagents), filter, UUID-remap.

    Returns list of cloned JSONL paths.
    """
    sub_src = original_session_dir / "subagents"
    if not sub_src.is_dir():
        return []

    sub_dest = new_session_dir / "subagents"
    sub_dest.mkdir(parents=True, exist_ok=True)

    cloned: list[Path] = []
    for meta_path in sub_src.glob("agent-*.meta.json"):
        meta = read_agent_meta(meta_path)
        if not is_teammate_meta(meta):
            continue
        jsonl_src = meta_path.with_suffix("").with_suffix(".jsonl")
        if not jsonl_src.is_file():
            continue

        kept_lines: list[str] = []
        with open(jsonl_src, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError:
                    continue
                ts = raw.get("timestamp") or ""
                if ts and ts > cut_timestamp:
                    continue
                raw = _remap_line(raw, uuid_map, new_session_id)
                kept_lines.append(json.dumps(raw, ensure_ascii=False))

        if not kept_lines:
            # All events were post-cut; drop the file entirely
            continue

        jsonl_dest = sub_dest / jsonl_src.name
        meta_dest = sub_dest / meta_path.name
        with open(jsonl_dest, "w", encoding="utf-8") as f:
            for line in kept_lines:
                f.write(line + "\n")
        shutil.copy2(meta_path, meta_dest)
        cloned.append(jsonl_dest)

    return cloned


def clone_agent_tool_jsonls(
    original_session_dir: Path,
    new_session_dir: Path,
    cut_timestamp: str,
    uuid_map: dict[str, str],
    new_session_id: str,
) -> list[Path]:
    """Copy Agent-tool subagent JSONLs, filter by timestamp, UUID-remap.

    Agent-tool subagents are distinguished from team teammates by having a
    ``description`` field in their meta.json. This function copies them so
    that forked sessions are fully self-contained.

    Returns list of cloned JSONL paths.
    """
    sub_src = original_session_dir / "subagents"
    if not sub_src.is_dir():
        return []

    sub_dest = new_session_dir / "subagents"

    cloned: list[Path] = []
    for meta_path in sub_src.glob("agent-*.meta.json"):
        meta = read_agent_meta(meta_path)
        # Agent-tool subagents HAVE a description field; teammates do NOT.
        if meta is None or not meta.get("agentType") or "description" not in meta:
            continue
        jsonl_src = meta_path.with_suffix("").with_suffix(".jsonl")
        if not jsonl_src.is_file():
            continue

        kept_lines: list[str] = []
        with open(jsonl_src, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError:
                    continue
                ts = raw.get("timestamp") or ""
                if ts and ts > cut_timestamp:
                    continue
                raw = _remap_line(raw, uuid_map, new_session_id)
                kept_lines.append(json.dumps(raw, ensure_ascii=False))

        if not kept_lines:
            continue

        sub_dest.mkdir(parents=True, exist_ok=True)
        jsonl_dest = sub_dest / jsonl_src.name
        meta_dest = sub_dest / meta_path.name
        with open(jsonl_dest, "w", encoding="utf-8") as f:
            for line in kept_lines:
                f.write(line + "\n")
        shutil.copy2(meta_path, meta_dest)
        cloned.append(jsonl_dest)

    return cloned


def clone_team_for_fork(
    old_team_name: str,
    new_team_name: str,
    new_session_id: str,
    uuid_map: dict[str, str],
    cut_timestamp: str,
    prefix_events: list[dict],
    original_session_dir: Path | None,
    new_session_dir: Path,
    teams_base: Path = DEFAULT_TEAMS_BASE,
    tasks_base: Path = DEFAULT_TASKS_BASE,
) -> TeamForgeResult:
    """Clone team dir + inbox + tasks + teammate JSONLs for a fork.

    Raises TeamForgeError if the destination team dir already exists.
    If the source team dir doesn't exist (e.g. TeamDelete previously ran),
    config/inbox cloning is skipped but task replay + teammate JSONL cloning
    still run — fork proceeds with a warning.
    """
    new_team_dir = teams_base / new_team_name
    if new_team_dir.exists():
        raise TeamForgeError(
            f"Destination team dir already exists: {new_team_dir}"
        )

    old_team_dir = teams_base / old_team_name
    team_source_existed = old_team_dir.is_dir()

    filtered_inbox_count = 0

    if team_source_existed:
        # Copy, then rewrite in place
        shutil.copytree(old_team_dir, new_team_dir)
        config_path = new_team_dir / "config.json"
        if config_path.is_file():
            _rewrite_team_config(config_path, old_team_name, new_team_name, new_session_id)
        inboxes_dir = new_team_dir / "inboxes"
        if inboxes_dir.is_dir():
            for inbox_path in inboxes_dir.glob("*.json"):
                filtered_inbox_count += _filter_inbox(inbox_path, cut_timestamp)
    else:
        logger.warning(
            "Source team dir missing for '%s' — skipping config/inbox clone",
            old_team_name,
        )
        new_team_dir.mkdir(parents=True)

    # Task replay from prefix events (independent of team dir presence)
    task_state = replay_tasks(prefix_events)
    task_dest = tasks_base / new_team_name
    cloned_task_count = write_tasks(task_state, task_dest)

    # Teammate JSONL clone
    cloned_teammate_paths: list[Path] = []
    if original_session_dir is not None:
        cloned_teammate_paths = _clone_teammate_jsonls(
            original_session_dir=original_session_dir,
            new_session_dir=new_session_dir,
            cut_timestamp=cut_timestamp,
            uuid_map=uuid_map,
            new_session_id=new_session_id,
        )

    return TeamForgeResult(
        new_team_name=new_team_name,
        new_team_dir=new_team_dir,
        cloned_teammate_jsonl_count=len(cloned_teammate_paths),
        cloned_task_count=cloned_task_count,
        filtered_inbox_count=filtered_inbox_count,
        team_source_existed=team_source_existed,
        cloned_teammate_paths=cloned_teammate_paths,
    )
