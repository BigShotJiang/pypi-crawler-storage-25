"""Classify + group teammate JSONL files.

Team teammates and Agent-tool subagents both live under:
  <project-dir>/<session-uuid>/subagents/agent-<hash>.jsonl
with a paired meta file agent-<hash>.meta.json.

A single teammate spans MULTIPLE turn files — each wakeup creates a new
agent-<hash>.jsonl that shares the same `agentType` (= teammate name) in its
meta. This module scans the directory and groups them.

Distinguishing rule:
  - Agent-tool subagent meta has a `description` field
  - Team teammate meta does not
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from .model import SessionEvent
from .parser import parse_jsonl

logger = logging.getLogger("cctree.teammate_sessions")


def read_agent_meta(meta_path: Path) -> dict | None:
    """Read and parse agent-<hash>.meta.json. Returns None if missing/corrupt."""
    try:
        with open(meta_path, encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return None
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to read %s: %s", meta_path, e)
        return None
    if not isinstance(data, dict):
        return None
    return data


def is_teammate_meta(meta: dict | None) -> bool:
    """Teammate iff agentType is set and description is absent.

    Agent-tool subagents store their description in meta, teammates do not.
    """
    if not isinstance(meta, dict):
        return False
    if not meta.get("agentType"):
        return False
    return "description" not in meta


def find_teammate_sessions(parent_session_dir: Path) -> dict[str, list[Path]]:
    """Scan <parent_session_dir>/subagents/ for teammate JSONLs.

    Returns {teammate_name: [jsonl_path, ...]} where teammate_name is the
    `agentType` from the meta file. Paths within each list are sorted by
    file mtime (oldest first) so timeline reconstruction is deterministic.

    Files without a meta pair, with corrupt meta, or whose meta indicates a
    regular Agent-tool subagent (has `description`) are excluded.
    """
    subagents_dir = parent_session_dir / "subagents"
    if not subagents_dir.is_dir():
        return {}

    grouped: dict[str, list[tuple[float, Path]]] = {}
    for meta_path in subagents_dir.glob("agent-*.meta.json"):
        meta = read_agent_meta(meta_path)
        if not is_teammate_meta(meta):
            continue
        # agent-<hash>.meta.json -> agent-<hash>.jsonl
        jsonl_path = meta_path.with_suffix("").with_suffix(".jsonl")
        if not jsonl_path.is_file():
            continue
        try:
            mtime = jsonl_path.stat().st_mtime
        except OSError:
            mtime = 0.0
        name = meta["agentType"]
        grouped.setdefault(name, []).append((mtime, jsonl_path))

    return {
        name: [p for _, p in sorted(entries, key=lambda x: x[0])]
        for name, entries in grouped.items()
    }


def merge_wake_up_events(per_file_events: list[list[SessionEvent]]) -> list[SessionEvent]:
    """Same chronological merge as load_teammate_timeline, but on pre-parsed events.

    Callers that need both the merged timeline AND per-file access (e.g. for
    building per-wake-up context maps) can parse each file once and feed the
    result here instead of reparsing via load_teammate_timeline.
    """
    if not per_file_events:
        return []

    merged: list[tuple[int, int, SessionEvent]] = []
    for file_idx, events in enumerate(per_file_events):
        for evt_idx, evt in enumerate(events):
            merged.append((file_idx, evt_idx, evt))

    def sort_key(triple: tuple[int, int, SessionEvent]) -> tuple[int, str, int, int]:
        file_idx, evt_idx, evt = triple
        ts = evt.timestamp or ""
        # Events with timestamp sort by timestamp; timestamped events come first
        has_ts = 0 if ts else 1
        return (has_ts, ts, file_idx, evt_idx)

    merged.sort(key=sort_key)
    return [evt for _, _, evt in merged]


def load_teammate_timeline(paths: list[Path]) -> list[SessionEvent]:
    """Parse all teammate turn files and merge into a single chronological list.

    Events with a parseable ISO timestamp are sorted by timestamp. Events
    without timestamps retain their original file-order position.
    """
    if not paths:
        return []
    return merge_wake_up_events([parse_jsonl(p) for p in paths])
