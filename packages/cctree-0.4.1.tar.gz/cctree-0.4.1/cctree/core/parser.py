"""JSONL session file parser.

Schema-tolerant by design: unknown event types are preserved as raw
SessionEvent objects (extra='allow' accepts unknown fields). Malformed
lines are skipped with a warning. Partial last lines (from active sessions)
are silently stripped.
"""
from __future__ import annotations

import dataclasses
import json
import logging
from datetime import datetime
from pathlib import Path

from pydantic import ValidationError

from . import json_loader
from .model import SessionEvent

logger = logging.getLogger("cctree.parser")


@dataclasses.dataclass(slots=True)
class SessionMetadata:
    """Lightweight metadata extracted from raw JSONL dicts — no Pydantic."""

    slug: str | None = None
    custom_title: str | None = None
    message_count: int = 0
    first_user_message: str = ""
    started_at: datetime | None = None
    last_activity_at: datetime | None = None
    has_compaction: bool = False
    compact_boundary_count: int = 0
    claude_version: str | None = None
    team_name: str | None = None


def _text_from_raw_message(raw: dict) -> str:
    """Extract plain text from a raw message dict (mirrors SessionEvent.text_content)."""
    msg = raw.get("message")
    if not msg:
        return ""
    content = msg.get("content", "")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = []
        for block in content:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text" and block.get("text"):
                parts.append(block["text"].strip())
            elif btype == "tool_result" and isinstance(block.get("content"), str) and block["content"]:
                parts.append(block["content"].strip())
        return "\n".join(parts)
    return ""


def extract_session_metadata(path: Path) -> SessionMetadata:
    """Extract metadata from a JSONL file without Pydantic validation.

    Reads each line as a raw dict and pulls out the ~10 metadata fields
    the sidebar needs.  Much faster than full parse_jsonl + _derive_metadata.
    """
    meta = SessionMetadata()
    lines: list[str] = []

    try:
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()
    except (FileNotFoundError, PermissionError):
        return meta

    first_user_seen = False
    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue

        try:
            raw = json_loader.loads(line)
        except Exception:
            continue

        if not isinstance(raw, dict):
            continue

        etype = raw.get("type")

        # Slug (first seen wins)
        if meta.slug is None and raw.get("slug"):
            meta.slug = raw["slug"]

        # Custom title (last seen wins)
        if etype == "custom-title" and raw.get("customTitle"):
            meta.custom_title = raw["customTitle"]

        # Message count
        if etype in ("user", "assistant"):
            meta.message_count += 1

        # First user message
        if not first_user_seen and etype == "user":
            meta.first_user_message = _text_from_raw_message(raw)[:200]
            first_user_seen = True

        # Timestamps
        ts_str = raw.get("timestamp")
        if ts_str:
            try:
                ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                if meta.started_at is None:
                    meta.started_at = ts
                meta.last_activity_at = ts
            except (ValueError, AttributeError):
                pass

        # Compaction
        if etype == "system" and raw.get("subtype") == "compact_boundary":
            meta.has_compaction = True
            meta.compact_boundary_count += 1

        # Claude version (first seen wins)
        if meta.claude_version is None and raw.get("version"):
            meta.claude_version = raw["version"]

        # Team name (first seen wins)
        if meta.team_name is None and raw.get("teamName"):
            meta.team_name = raw["teamName"]

    return meta


def parse_jsonl(path: Path) -> list[SessionEvent]:
    """Parse a session JSONL file into a list of SessionEvents.

    - Skips malformed JSON lines (logs warning)
    - Strips partial last line from active sessions
    - Never crashes on unknown fields or event types
    """
    events: list[SessionEvent] = []
    lines: list[str] = []

    try:
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        logger.error("Session file not found: %s", path)
        raise
    except PermissionError:
        logger.error("Permission denied reading: %s", path)
        raise

    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue

        try:
            raw = json_loader.loads(line)
        except (json.JSONDecodeError, ValueError):
            if i == len(lines) - 1:
                # Partial last line from an active session — silently skip
                logger.debug("Stripped partial last line from %s", path.name)
            else:
                logger.warning(
                    "Malformed JSON at line %d in %s: skipping",
                    i + 1,
                    path.name,
                )
            continue

        if not isinstance(raw, dict):
            logger.warning("Non-dict JSON at line %d in %s: skipping", i + 1, path.name)
            continue

        try:
            event = SessionEvent.model_validate(raw)
            events.append(event)
        except ValidationError as e:
            logger.warning(
                "Schema validation failed at line %d in %s: %s",
                i + 1,
                path.name,
                e,
            )
            continue

    return events


def parse_session_id(path: Path) -> str:
    """Extract session UUID from a JSONL filename."""
    return path.stem  # e.g., "46a95dcf-1146-458a-bcd2-54f9ce085866"
