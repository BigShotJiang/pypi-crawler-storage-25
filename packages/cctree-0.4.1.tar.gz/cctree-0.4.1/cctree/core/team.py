"""External team state: config, inboxes, tasks.

Claude Code's agent teams feature persists state outside ~/.claude/projects/:

  ~/.claude/teams/{name}/config.json       — member roster + lead references
  ~/.claude/teams/{name}/inboxes/{m}.json  — per-member JSON array of messages
  ~/.claude/tasks/{team-name}/{N}.json     — per-task state

This module parses and models that state. All reads are tolerant of missing
files and corrupt JSON (log a warning, return empty). Models use
`extra="allow"` so unknown future fields are preserved.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from pydantic import BaseModel, Field, ValidationError

logger = logging.getLogger("cctree.team")

DEFAULT_TEAMS_BASE = Path.home() / ".claude" / "teams"
DEFAULT_TASKS_BASE = Path.home() / ".claude" / "tasks"


class TeamMember(BaseModel, extra="allow"):
    """One member of a team, as stored in config.json#members[]."""

    agentId: str
    name: str
    agentType: str
    model: str | None = None
    joinedAt: int | None = None
    tmuxPaneId: str | None = None
    cwd: str | None = None
    subscriptions: list[str] = []


class TeamConfig(BaseModel, extra="allow"):
    """Contents of ~/.claude/teams/{name}/config.json."""

    name: str
    description: str | None = None
    createdAt: int | None = None
    leadAgentId: str
    leadSessionId: str | None = None
    members: list[TeamMember] = []


class InboxMessage(BaseModel, extra="allow"):
    """One entry in ~/.claude/teams/{name}/inboxes/{member}.json.

    `from` is a Python reserved word — aliased to `from_`.
    """

    from_: str = Field(alias="from")
    text: str
    summary: str | None = None
    timestamp: str
    color: str | None = None
    read: bool = False


class TeamTask(BaseModel, extra="allow"):
    """One entry in ~/.claude/tasks/{team-name}/{N}.json."""

    id: str
    subject: str
    description: str | None = None
    activeForm: str | None = None
    status: str
    blocks: list[str] = []
    blockedBy: list[str] = []


def team_dir(team_name: str, teams_base: Path = DEFAULT_TEAMS_BASE) -> Path:
    return teams_base / team_name


def task_dir(team_name: str, tasks_base: Path = DEFAULT_TASKS_BASE) -> Path:
    return tasks_base / team_name


def _read_json(path: Path) -> object | None:
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to read %s: %s", path, e)
        return None


def read_team_config(
    team_name: str,
    teams_base: Path = DEFAULT_TEAMS_BASE,
) -> TeamConfig | None:
    """Parse ~/.claude/teams/{name}/config.json. Returns None if missing or corrupt."""
    config_path = team_dir(team_name, teams_base) / "config.json"
    raw = _read_json(config_path)
    if raw is None:
        return None
    if not isinstance(raw, dict):
        logger.warning("Team config at %s is not an object", config_path)
        return None
    try:
        return TeamConfig.model_validate(raw)
    except ValidationError as e:
        logger.warning("Team config at %s failed validation: %s", config_path, e)
        return None


def read_inbox(
    team_name: str,
    member_name: str,
    teams_base: Path = DEFAULT_TEAMS_BASE,
) -> list[InboxMessage]:
    """Parse ~/.claude/teams/{name}/inboxes/{member}.json. Empty list on missing/corrupt."""
    inbox_path = team_dir(team_name, teams_base) / "inboxes" / f"{member_name}.json"
    raw = _read_json(inbox_path)
    if raw is None:
        return []
    if not isinstance(raw, list):
        logger.warning("Inbox at %s is not a list", inbox_path)
        return []
    msgs: list[InboxMessage] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        try:
            msgs.append(InboxMessage.model_validate(entry))
        except ValidationError as e:
            logger.warning("Inbox entry in %s failed validation: %s", inbox_path, e)
            continue
    return msgs


def read_all_inboxes(
    team_name: str,
    teams_base: Path = DEFAULT_TEAMS_BASE,
) -> dict[str, list[InboxMessage]]:
    """Return {member_name: [InboxMessage, ...]} for every inbox file.

    Empty dict if the inboxes dir is missing.
    """
    inboxes_dir = team_dir(team_name, teams_base) / "inboxes"
    if not inboxes_dir.is_dir():
        return {}
    result: dict[str, list[InboxMessage]] = {}
    for path in sorted(inboxes_dir.glob("*.json")):
        member = path.stem
        result[member] = read_inbox(team_name, member, teams_base)
    return result


def read_tasks(
    team_name: str,
    tasks_base: Path = DEFAULT_TASKS_BASE,
) -> list[TeamTask]:
    """Parse all tasks for a team. Skips corrupt files with warnings."""
    tdir = task_dir(team_name, tasks_base)
    if not tdir.is_dir():
        return []
    tasks: list[TeamTask] = []
    for path in sorted(tdir.glob("*.json")):
        raw = _read_json(path)
        if not isinstance(raw, dict):
            continue
        try:
            tasks.append(TeamTask.model_validate(raw))
        except ValidationError as e:
            logger.warning("Task at %s failed validation: %s", path, e)
            continue
    return tasks
