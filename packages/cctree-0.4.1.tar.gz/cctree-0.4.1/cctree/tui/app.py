"""cctree TUI application — tree-spine session browser."""
from __future__ import annotations

import base64
import json
import os
import re
import textwrap
from pathlib import Path

from rich.markup import escape as _escape_markup
from textual import events
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.events import Click, MouseDown, MouseMove, MouseUp
from textual.screen import ModalScreen
from textual.widgets import Footer, Header, Input, Label, ListItem, ListView, Static, Tree
from textual.widgets.tree import TreeNode

from ..core.active_agents import (
    ActiveAgentsSnapshot,
    build_active_agents_map,
    format_agents_status_line,
)
from ..core.context_usage import (
    TurnContext,
    build_turn_context_map,
    build_turn_context_map_for_wake_ups,
    format_delta_label,
    format_mini_bar,
    format_status_lines,
)
from ..core.model import (
    ContentBlock, EventType, Session, SessionEvent,
    format_model_badge, format_model_badge_short, window_size_for_model,
)
from ..core.parser import parse_jsonl
from ..core.json_loader import USING_ORJSON
from ..core.store import SessionStore
from ..core.subagent_link import (
    find_agent_links,
    find_teammate_references,
    resolve_subagent_path,
    resolve_teammate_paths,
)
from ..core.team import read_team_config
from ..core.teammate import TeammateMessageBlock, contains_teammate_message, parse_teammate_messages
from ..core.teammate_sessions import merge_wake_up_events

# ─── Extracted modules (re-exported for backwards compatibility) ───────────
from .columns import (  # noqa: F401
    _KEY_ARG_KEYS,
    _collect_turn_tools,
    _compose_annotated_label,
    _format_badge,
    _format_image_col,
    _format_tool_count,
    _format_tool_summary,
    _highlight_term,
    _label_width_for_depth,
    _tool_preview,
    _visual_len,
)
from .fold import set_fold_level  # noqa: F401
from .modals import InputModal, SearchScreen  # noqa: F401
from .widgets import DragHandle  # noqa: F401

_TEAM_TOOL_ICONS = {
    "TeamCreate": "👥",
    "TeamDelete": "👥",
    "SendMessage": "📨",
}

_PROTOCOL_ICONS = {
    "idle_notification": "🔕",
    "shutdown_request": "⏻",
    "shutdown_response": "⏻",
    "shutdown_approved": "⏻",
    "plan_approval_request": "📋",
    "plan_approval_response": "📋",
    "teammate_terminated": "💤",
}


MAX_INLINE_LINES = 5

# Node types that are pure display continuations (wrapped lines).
# Navigation skips these; group-highlight uses _GROUP_HIGHLIGHT_TYPES instead.
_CONTINUATION_TYPES = frozenset({"full_text", "text", "thinking_text"})

# Superset used by group-highlight: includes overflow so it gets painted
# when the parent message is selected, even though it's now navigable.
_GROUP_HIGHLIGHT_TYPES = _CONTINUATION_TYPES | {"overflow"}


def _extract_auq_answer(
    tool_use_id: str | None,
    content_blocks: list,
) -> str:
    """Find the AskUserQuestion answer from a matching tool_result block."""
    if not tool_use_id:
        return ""
    for block in content_blocks:
        if not hasattr(block, "type"):
            continue
        if block.type != "tool_result" or block.tool_use_id != tool_use_id:
            continue
        result_text = ""
        if isinstance(block.content, str):
            result_text = block.content
        elif isinstance(block.content, list):
            for sub in block.content:
                if isinstance(sub, dict) and sub.get("type") == "text":
                    result_text = sub.get("text", "")
                    break
                if hasattr(sub, "type") and sub.type == "text":
                    result_text = sub.text or ""
                    break
        if result_text:
            # Extract the first answer line (usually "User has answered...")
            first_line = result_text.split("\n")[0]
            # Try to find the answer after the = sign
            if "=" in first_line:
                answer = first_line.split("=", 1)[1].strip().strip('"').strip("'")
                return answer[:40]
            return first_line[:40]
    return ""


def _wrap_text(text: str, width: int) -> list[str]:
    """Word-wrap text preserving existing newlines."""
    if not text:
        return [""]
    lines: list[str] = []
    for paragraph in text.split("\n"):
        stripped = paragraph.strip()
        if stripped:
            wrapped = textwrap.wrap(stripped, width=width)
            lines.extend(wrapped if wrapped else [""])
        else:
            lines.append("")
    # Remove trailing blank lines
    while lines and not lines[-1].strip():
        lines.pop()
    return lines or [""]


def _compose_wrapped_preview(
    text: str,
    prefix: str,
    label_width: int,
    cont_width: int,
    max_inline: int = MAX_INLINE_LINES,
) -> tuple[str, list[str], list[str]]:
    """Wrap a message into a dynamic-width tree preview.

    Adapts to available horizontal space:
    - Wide terminals: full text fits on the label line (no continuation)
    - Narrow terminals: wraps across continuation leaves + optional overflow

    Args:
        text: the full message text
        prefix: e.g. "User: " / "Asst: " — prepended to the label line
        label_width: columns available for the label line (including prefix)
        cont_width: columns per continuation line (one tree-indent deeper)
        max_inline: cap on continuation leaves shown before falling into overflow

    Returns:
        (label_line, inline_lines, overflow_lines) where:
        - label_line is the tree node's own label (includes prefix)
        - inline_lines are continuation leaves shown when the node is expanded
        - overflow_lines are extra lines hidden behind a "... (N more)" expand node
    """
    if not text:
        return prefix.rstrip(), [], []

    first_width = max(1, label_width - len(prefix))

    # Wrap the head of the text at first_width to get the first line
    head_wrapped = _wrap_text(text, first_width)
    if not head_wrapped or not head_wrapped[0]:
        return f"{prefix}{text[:first_width]}", [], []
    first_line = head_wrapped[0]

    # Remainder is wrapped at cont_width (usually narrower due to deeper indent)
    remainder = text[len(first_line):].lstrip()
    rest_lines = _wrap_text(remainder, cont_width) if remainder else []

    inline = rest_lines[:max_inline]
    overflow = rest_lines[max_inline:]

    return f"{prefix}{first_line}", inline, overflow


# ── Role prefix colorization ─────────────────────────────────────
_USER_ROLE = "[bold cyan]User:[/bold cyan]"
_ASST_ROLE = "[bold yellow]Asst:[/bold yellow]"


def _apply_role_color(label: str) -> str:
    """Apply color to User:/Asst: role prefixes in tree labels."""
    if label.startswith("User:"):
        return _USER_ROLE + label[5:]
    if label.startswith("[dim]Asst:"):
        return f"{_ASST_ROLE} [dim]" + label[10:]
    return label


_IMAGE_SOURCE_RE = re.compile(r'^\[Image: source: .+\]$')


def _is_image_source_only(evt: SessionEvent) -> bool:
    """True if the user event's text content is entirely [Image: source: ...] lines."""
    text = evt.text_content
    if not text:
        return False
    lines = [l.strip() for l in text.strip().splitlines() if l.strip()]
    if not lines:
        return False
    return all(_IMAGE_SOURCE_RE.match(line) for line in lines)


def _extract_image_source_paths(evt: SessionEvent) -> list[str]:
    """Extract file paths from [Image: source: /path] text blocks."""
    text = evt.text_content
    paths: list[str] = []
    for line in text.strip().splitlines():
        line = line.strip()
        m = re.match(r'^\[Image: source: (.+)\]$', line)
        if m:
            paths.append(m.group(1))
    return paths


def _responding_model(events: list[SessionEvent]) -> str | None:
    """Return the model ID from the first non-synthetic assistant event."""
    for evt in events:
        if (evt.type == EventType.ASSISTANT
                and evt.message and evt.message.model
                and evt.message.model != "<synthetic>"):
            return evt.message.model
    return None


def _is_user_typed(evt: SessionEvent) -> bool:
    """Is this a user message the human actually typed (vs tool output auto-sent by Claude Code)?

    User-typed: content is a string, or content list contains a 'text' block.
    Tool-result-only: content list contains ONLY 'tool_result' blocks.
    """
    if evt.message is None:
        return False
    content = evt.message.content
    if isinstance(content, str):
        return True  # plain text = user typed it
    if isinstance(content, list):
        return any(
            hasattr(block, "type") and block.type == "text"
            for block in content
        )
    return False


def _find_nearest_uuid(node: TreeNode) -> str | None:
    """Walk up the tree from a node to find the nearest ancestor with a message UUID."""
    current = node
    while current is not None:
        if current.data and current.data.get("uuid"):
            return current.data["uuid"]
        current = current.parent
    return None


def _extract_copy_text(node: TreeNode) -> str | None:
    """Extract copyable text from a tree node based on its data type.

    Only "primary" node types emit text.  Display leaves (wrapped lines,
    overflow, tool_input, etc.) return None — their parent already carries
    the complete content, so extracting from both would duplicate.
    """
    data = node.data
    if not data:
        return None
    node_type = data.get("type")
    # ── Primary types: emit content ─────────────────────────────────
    if node_type in ("user", "sub_user"):
        return data.get("full_text")
    if node_type == "assistant":
        full = data.get("full_text")
        if full:
            return full
        evt = data.get("event")
        if evt:
            return evt.text_content
        return None
    if node_type in ("tool_use", "agent"):
        name = data.get("name", "?")
        inp = data.get("input")
        result = data.get("result_text", "")
        parts = [name]
        if inp:
            parts.append(json.dumps(inp, indent=2, ensure_ascii=False))
        if result:
            parts.append(f"→ {result}")
        return "\n".join(parts)
    if node_type == "thinking":
        return data.get("full_text")
    # ── Display leaves: parent covers it ────────────────────────────
    # "full_text", "text", "tool_input", "tool_result", "thinking_text",
    # "overflow", "image", etc.
    return None


def _extract_subtree_text(node: TreeNode) -> str:
    """Recursively extract copyable text from a node and all descendants."""
    parts: list[str] = []
    text = _extract_copy_text(node)
    if text:
        parts.append(text)
    for child in node.children:
        parts.append(_extract_subtree_text(child))
    return "\n".join(p for p in parts if p)


def _osc52_copy(text: str) -> None:
    """Write an OSC 52 escape sequence to the controlling terminal."""
    b64 = base64.b64encode(text.encode()).decode()
    seq = f"\x1b]52;c;{b64}\x07"
    fd = os.open(os.ctermid(), os.O_WRONLY)
    try:
        os.write(fd, seq.encode())
    finally:
        os.close(fd)


def _copy_to_clipboard(text: str) -> str:
    """Copy *text* to clipboard. Returns the method used: 'pyperclip' or 'osc52'.

    Tries pyperclip first (works when a display server / clipboard tool is
    available).  Falls back to OSC 52, which pushes text through the terminal
    stream to the local clipboard — works over SSH in Ghostty, iTerm2,
    WezTerm, Kitty, Alacritty, and recent Windows Terminal.

    Raises if both mechanisms fail.
    """
    try:
        import pyperclip

        pyperclip.copy(text)
        return "pyperclip"
    except Exception:
        pass
    _osc52_copy(text)
    return "osc52"


class CctreeApp(App):
    """Main TUI application — 2-pane: sessions list + detail tree."""

    CSS = """
    #sessions-pane {
        width: 28;
        overflow-y: auto;
    }
    #detail-pane {
        width: 1fr;
        overflow-y: auto;
    }
    #session-header {
        height: auto;
        max-height: 8;
        padding: 0 1;
        background: $surface;
    }
    #session-tree {
        width: 100%;
    }
    #search-container {
        width: 80%;
        height: 60%;
        margin: 4 10;
        background: $surface;
        border: solid $primary;
        padding: 1;
    }
    #search-input {
        margin-bottom: 1;
    }
    #input-modal-container {
        width: 60%;
        height: auto;
        margin: 8 20;
        background: $surface;
        border: solid $primary;
        padding: 1;
    }
    #input-modal-title {
        margin-bottom: 1;
    }
    #status-bar {
        height: auto;
        min-height: 1;
        dock: bottom;
        background: $surface;
        padding: 0 1;
        opacity: 1.0;
    }
    #status-bar.flashing {
        opacity: 0.35;
        transition: opacity 500ms out_cubic;
    }
    #sessions-pane ListItem {
        height: 3;
        padding: 0 1;
    }
    ListView > ListItem.--highlight {
        background: $accent;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("slash", "search", "Search"),
        Binding("tab", "focus_next_pane", "Switch pane", priority=True),
        Binding("i", "copy_session_id", "Copy ID"),
        Binding("c", "copy_node", "Copy"),
        Binding("C", "copy_subtree", "Copy all"),
        Binding("f", "copy_fork", "Fork"),
        Binding("S", "toggle_sort", "Sort by"),
        Binding("T", "save_template", "Save template"),
        Binding("R", "rename_template", "Rename tpl"),
        Binding("X", "delete_template", "Delete tpl"),
        Binding("S", "jump_to_source", "Source session"),
        Binding("B", "back_to_template", "Back to tpl"),
        Binding("1", "fold_level_1", "Spine"),
        Binding("2", "fold_level_2", "+Children"),
        Binding("3", "fold_level_3", "Expand all"),
        Binding("E", "expand_all", "Expand"),
        Binding("W", "collapse_all", "Collapse"),
    ]

    def __init__(self, project_dir: str | None = None, all_projects: bool = False) -> None:
        super().__init__()
        self.store = SessionStore(
            project_dir=Path(project_dir) if project_dir else None,
            all_projects=all_projects,
        )
        self.current_session: Session | None = None
        self.sort_by: str = "last_activity"  # or "started_at"
        self.template_sort_by: str = "last_forked"
        self._page_size: int = 200
        self._max_display: int = 200
        self._browsing_template: dict | None = None  # set when viewing template detail
        self._returned_from_template: dict | None = None  # for back-navigation to template
        self._tree_rebuild_timer = None  # debounces tree rebuild on terminal resize
        self._last_tree_width: int = 0  # skip rebuild if width unchanged (height-only resize)

        # Per-turn context window tracking (status bar)
        self._turn_context: dict[str, TurnContext] = {}
        self._active_agents: dict[str, ActiveAgentsSnapshot] = {}
        self._teammate_colors: dict[str, str] = {}  # teammate_id → color from <teammate-message>
        self._context_lines: list[str] = []

        # Column focus mode (Tab cycling on user turns)
        self._col_focus_index: int | None = None
        self._col_focus_columns: list[str] = []
        self._col_focus_node_id: int | None = None
        self._flash_active: bool = False
        self._flash_timer = None
        self._manually_collapsed: set[str] = set()  # UUIDs the user explicitly collapsed
        self._refreshing_list: bool = False

        # Search highlight state (browser find-in-page model)
        self._search_term: str | None = None

        # Group highlight: tracks (child_node, original_label) so we can restore
        self._group_highlight_children: list[tuple] = []

        self.title = "cctree"

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal():
            yield ListView(id="sessions-pane")
            yield DragHandle()
            with Vertical(id="detail-pane"):
                yield Static("Select a session", id="session-header")
                yield Tree("Session", id="session-tree")
        yield Static("", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        self.run_worker(self._load_sessions_async, exclusive=True)

    async def _load_sessions_async(self) -> None:
        """Load sessions in a background thread, then populate the UI."""
        import asyncio

        await asyncio.to_thread(lambda: self.store.sessions)
        self._refresh_session_list()
        if not USING_ORJSON and self.current_session is None:
            self._flash_status("pip install orjson for ~2x faster startup")

    async def _on_resize(self, event: events.Resize) -> None:
        """Override to schedule a debounced tree rebuild after the terminal resizes.

        App's base _on_resize calls event.stop(), so we hook here rather than
        letting a public on_resize handler fire.
        """
        await super()._on_resize(event)
        if self.current_session is None:
            return
        new_width = int(event.size.width)
        if new_width == self._last_tree_width:
            return
        self._last_tree_width = new_width
        if self._tree_rebuild_timer is not None:
            self._tree_rebuild_timer.stop()
        self._tree_rebuild_timer = self.set_timer(0.15, self._rebuild_tree_for_resize)

    def _rebuild_tree_for_resize(self) -> None:
        """Rebuild the tree at the current terminal width, preserving expansion state."""
        self._tree_rebuild_timer = None
        if self.current_session is None:
            return
        try:
            tree = self.query_one("#session-tree", Tree)
        except Exception:
            return
        expanded_uuids = self._collect_expanded_uuids(tree.root)
        scroll_y = getattr(tree, "scroll_y", 0)
        self.load_session(self.current_session)
        try:
            tree = self.query_one("#session-tree", Tree)
        except Exception:
            return
        self._restore_expanded(tree.root, expanded_uuids)
        # Respect manual collapses — auto-expand won't override user intent
        self._apply_manual_collapses(tree.root)
        try:
            tree.scroll_to(y=scroll_y, animate=False)
        except Exception:
            pass

        # Status bar: re-format for the currently-highlighted node so the
        # narrow/wide mode switches when the terminal crosses the 80-col
        # threshold. Falls back to the initial-turn state if no cursor.
        cursor = getattr(tree, "cursor_node", None)
        if cursor is not None and cursor is not tree.root:
            tc, reason = self._resolve_context_for_node(cursor)
            narrow = self._detail_is_narrow()
            self._context_lines = format_status_lines(
                tc, narrow=narrow, no_data_reason=reason,
            )
            if not self._flash_active:
                self._write_status_bar()

    def _collect_expanded_uuids(self, node: TreeNode) -> set[str]:
        """Collect UUIDs of currently-expanded nodes, for restoration after rebuild."""
        uuids: set[str] = set()
        if node.is_expanded and node.data:
            uuid = node.data.get("uuid")
            if uuid:
                uuids.add(uuid)
        for child in node.children:
            uuids |= self._collect_expanded_uuids(child)
        return uuids

    def _restore_expanded(self, node: TreeNode, uuids: set[str]) -> None:
        """Re-expand nodes whose UUIDs were expanded pre-rebuild."""
        if node.data and node.allow_expand:
            uuid = node.data.get("uuid")
            if uuid and uuid in uuids and not node.is_expanded:
                node.expand()
        for child in node.children:
            self._restore_expanded(child, uuids)

    def _apply_manual_collapses(self, node: TreeNode) -> None:
        """Collapse nodes the user manually collapsed, overriding auto-expand."""
        if node.data and node.is_expanded:
            uuid = node.data.get("uuid")
            if uuid and uuid in self._manually_collapsed:
                node.collapse()
        for child in node.children:
            self._apply_manual_collapses(child)

    def _get_project_dir_name(self) -> str:
        """Get the full directory name for the current project (for template storage)."""
        if self.store._project_dirs:
            return self.store._project_dirs[0].name
        return ""

    def _refresh_session_list(self) -> None:
        """Populate the sessions pane: templates section at top, then sessions."""
        import datetime as _dt

        from ..core.metadata import is_fork
        from ..core.templates import list_templates

        lv = self.query_one("#sessions-pane", ListView)
        self._refreshing_list = True
        lv.clear()

        project_dir_name = self._get_project_dir_name()

        # ── Templates section ──
        templates = list_templates(project_dir_name, sort_by=self.template_sort_by) if project_dir_name else []
        sort_labels = {"last_forked": "recent", "fork_count": "forks ↓", "created": "created", "name": "A-Z"}
        sort_indicator = sort_labels.get(self.template_sort_by, self.template_sort_by)

        if templates:
            lv.append(ListItem(
                Label(
                    f"[bold magenta]━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold magenta]\n"
                    f"[bold magenta] ★ Templates[/bold magenta] [dim magenta]({sort_indicator})[/dim magenta]",
                    markup=True,
                ),
                name="__tpl_divider__",
            ))
            for t in templates[:10]:
                fork_count = t.get("forkCount", 0)
                forks_str = f"{fork_count} fork{'s' if fork_count != 1 else ''}"
                src = t.get("sourceDisplayName") or t.get("sourceSlug") or "?"
                lf = t.get("lastForkedAt")
                dtm = lf[:10] if lf else (t.get("createdAt", "")[:10] if t.get("createdAt") else "—")
                label = (
                    f"[bold magenta]★[/bold magenta] {t['name']}    [dim]{forks_str}[/dim]\n"
                    f"[dim]{src[:20]}  {dtm}[/dim]"
                )
                lv.append(ListItem(Label(label, markup=True), name=f"__tpl__{t['name']}"))
            if len(templates) > 10:
                lv.append(ListItem(
                    Label(f"[dim]  + {len(templates) - 10} more templates[/dim]", markup=True),
                    name="__tpl_more__",
                ))
        else:
            lv.append(ListItem(
                Label(
                    f"[bold magenta]━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold magenta]\n"
                    f"[bold magenta] ★ Templates[/bold magenta]",
                    markup=True,
                ),
                name="__tpl_divider__",
            ))
            lv.append(ListItem(
                Label("[dim]No templates — T to save[/dim]", markup=True),
                name="__tpl_hint__",
            ))

        # ── Sessions section ──
        sessions = list(self.store.sessions.values())
        if self.sort_by == "started_at":
            sessions.sort(key=lambda s: s.started_at or _dt.datetime.min, reverse=True)
        else:
            sessions.sort(key=lambda s: s.last_activity_at or s.started_at or _dt.datetime.min, reverse=True)
        self._all_sorted_sessions = sessions
        displayed = sessions[:self._max_display]

        sort_labels_s = {"last_activity": "active", "started_at": "started"}
        s_indicator = sort_labels_s.get(self.sort_by, self.sort_by)
        lv.append(ListItem(
            Label(
                f"[bold]━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold]\n"
                f"[bold] Sessions[/bold] [dim]({s_indicator} ↓)[/dim]",
                markup=True,
            ),
            name="__sess_divider__",
        ))

        for s in displayed:
            if self.sort_by == "started_at":
                dtm = s.started_at.strftime("%m-%d %H:%M") if s.started_at else "—"
            else:
                dtm = s.last_activity_at.strftime("%m-%d %H:%M") if s.last_activity_at else "—"
            sort_label = "started" if self.sort_by == "started_at" else "active"
            project_slug = Path(s.path).parent.name if s.path else ""
            fork_badge = " [bold cyan]fork[/bold cyan]" if is_fork(s.uuid, project_slug) else ""
            label = f"{s.display_name}{fork_badge}\n[dim]{s.message_count} msgs  {sort_label} {dtm}[/dim]"
            lv.append(ListItem(Label(label, markup=True), name=s.uuid))

        remaining = len(sessions) - self._max_display
        if remaining > 0:
            lv.append(ListItem(
                Label(f"[dim]▾ Load more ({remaining} remaining)[/dim]", markup=True),
                name="__load_more__",
            ))

        # Only auto-focus the list when no session is displayed — avoids
        # stealing focus from the tree during async background refresh.
        if not lv.has_focus and self.current_session is None:
            lv.focus()

        self.call_after_refresh(self._end_refresh)

    def _end_refresh(self) -> None:
        # Re-highlight current session before dropping the guard so that
        # on_list_view_highlighted won't load a different session.
        if self.current_session:
            try:
                lv = self.query_one("#sessions-pane", ListView)
                for idx, item in enumerate(lv.children):
                    if getattr(item, "name", None) == self.current_session.uuid:
                        lv.index = idx
                        break
            except Exception:
                pass
        self._refreshing_list = False

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Auto-load highlighted session (spine-only) or clear detail for non-sessions."""
        if event.list_view.id == "sessions-pane":
            try:
                self.refresh_bindings()
            except Exception:
                pass  # screen not yet mounted during init
            if getattr(self, "_refreshing_list", False):
                return
            sessions = event.list_view
            if event.item:
                item_name = getattr(event.item, "name", "") or ""
                if item_name.startswith("__tpl__"):
                    tpl_name = item_name[7:]
                    # Only refresh if not already showing this template
                    if not self._browsing_template or self._browsing_template.get("name") != tpl_name:
                        self._returned_from_template = None
                        self._show_template_detail(tpl_name)
                        self.call_after_refresh(sessions.focus)
                elif item_name and not item_name.startswith("__"):
                    session = self.store.get(item_name)
                    if session and (self.current_session is None or session.uuid != self.current_session.uuid):
                        self._browsing_template = None
                        self._returned_from_template = None
                        self.load_session(session)
                        tree = self.query_one("#session-tree", Tree)
                        set_fold_level(tree.root, target_depth=1)
                        # Re-assert sessions focus — tree rebuilds can steal it async
                        self.call_after_refresh(sessions.focus)
                elif self.current_session is not None:
                    # Non-session item: clear the detail pane
                    self.current_session = None
                    self._browsing_template = None
                    tree = self.query_one("#session-tree", Tree)
                    tree.clear()
                    header = self.query_one("#session-header", Static)
                    header.update("Select a session")

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Handle selection from the sessions pane — sessions or templates."""
        if event.list_view.id != "sessions-pane":
            return
        item_name = event.item.name
        if not item_name:
            return
        # Skip non-interactive items
        if item_name in ("__tpl_hint__", "__tpl_more__"):
            return
        # Dividers toggle sort mode when selected
        if item_name == "__tpl_divider__":
            cycle = ["last_forked", "fork_count", "created", "name"]
            cur = cycle.index(self.template_sort_by) if self.template_sort_by in cycle else 0
            self.template_sort_by = cycle[(cur + 1) % len(cycle)]
            self._flash_status(f"Template sort: {self.template_sort_by}")
            self._refresh_session_list()
            return
        if item_name == "__sess_divider__":
            if self.sort_by == "last_activity":
                self.sort_by = "started_at"
            else:
                self.sort_by = "last_activity"
            self._flash_status(f"Session sort: {self.sort_by}")
            self._refresh_session_list()
            return
        if item_name == "__load_more__":
            self._load_more_sessions()
            return
        # Template selected
        if item_name.startswith("__tpl__"):
            tpl_name = item_name[7:]  # strip "__tpl__" prefix
            self._show_template_detail(tpl_name)
            return
        # Session selected — load but keep focus in sessions pane
        session = self.store.get(item_name)
        if session:
            self._browsing_template = None
            self.load_session(session)
            tree = self.query_one("#session-tree", Tree)
            set_fold_level(tree.root, target_depth=1)
            sessions = self.query_one("#sessions-pane", ListView)
            self.call_after_refresh(sessions.focus)

    def _load_more_sessions(self) -> None:
        """Increase the display limit and refresh the session list."""
        self._max_display += self._page_size
        self._refresh_session_list()

    def on_click(self, event: Click) -> None:
        """Disable mouse click selection — except double-click on tree images.

        DragHandle is unaffected (uses MouseDown/MouseMove/MouseUp, not Click).
        Scroll is unaffected (uses MouseScrollDown/MouseScrollUp, not Click).
        """
        # Double-click on tree → open image if cursor is on one
        if getattr(event, "chain", 1) >= 2:
            tree = self.query_one("#session-tree", Tree)
            if tree.has_focus:
                node = tree.cursor_node
                if node and node.data and node.data.get("type") == "image":
                    self._open_image_node(node)
                    return
        event.prevent_default()
        event.stop()

    def on_key(self, event) -> None:
        """Handle left/right arrow for cross-pane navigation."""
        # Key events bubble from ModalScreen to App — ignore them so
        # arrow keys in the search modal don't affect background widgets.
        if isinstance(self.screen, ModalScreen):
            return

        sessions = self.query_one("#sessions-pane", ListView)
        tree = self.query_one("#session-tree", Tree)

        # Column focus mode: Escape exits, Enter activates
        if tree.has_focus and self._col_focus_index is not None:
            if event.key == "escape":
                self._exit_col_focus()
                event.prevent_default()
                return
            if event.key == "enter":
                col = self._col_focus_columns[self._col_focus_index]
                cursor = tree.cursor_node
                if cursor:
                    self._execute_column_action(cursor, col)
                event.prevent_default()
                return

        # Search highlight: Escape clears, n/N navigate matches
        # Works from either pane so user can stay in sessions list after search.
        if self._search_term is not None and (tree.has_focus or sessions.has_focus):
            if event.key == "escape":
                self._clear_search()
                event.prevent_default()
                return
            if event.key == "n":
                self._next_search_match()
                event.prevent_default()
                return
            if event.key == "N":
                self._prev_search_match()
                event.prevent_default()
                return

        # Template detail: F to fork from template (from either pane)
        in_template_detail = self._browsing_template is not None and self.current_session is None
        if in_template_detail and event.key in ("f", "F"):
            self._fork_from_template()
            event.prevent_default()
            return

        # Template detail: Enter/right on fork row → jump to that session
        if in_template_detail and event.key in ("enter", "right") and tree.has_focus:
            cursor = tree.cursor_node
            if cursor and cursor.data and cursor.data.get("type") == "template_fork":
                self._jump_to_fork_session()
                event.prevent_default()
                return

        # Left arrow in tree when we came from a template → back to template
        if event.key == "left" and tree.has_focus and getattr(self, "_returned_from_template", None):
            self._back_to_template()
            event.prevent_default()
            return

        # Enter on image node → open it (must be in on_key because
        # the Tree widget's built-in Enter binding would consume it
        # before any App-level binding fires)
        if event.key == "enter" and tree.has_focus:
            cursor = tree.cursor_node
            if cursor and cursor.data and cursor.data.get("type") == "image":
                self._open_image_node(cursor)
                event.prevent_default()
                return
            # Enter on overflow node → toggle expand/collapse
            if cursor and cursor.data and cursor.data.get("type") == "overflow":
                if cursor.is_expanded:
                    cursor.collapse()
                else:
                    cursor.expand()
                event.prevent_default()
                return

        if event.key == "right" and sessions.has_focus:
            # Check if a template is highlighted — show template detail (forks list)
            idx = sessions.index if sessions.index is not None else 0
            items = list(sessions.children)
            if 0 <= idx < len(items):
                item_name = getattr(items[idx], "name", "") or ""
                if item_name.startswith("__tpl__"):
                    tpl_name = item_name[7:]
                    self._show_template_detail(tpl_name)
                    tree.focus()
                    event.prevent_default()
                    return

            # Right from sessions → detail tree (load if needed)
            if self.current_session is None and len(sessions.children) > 0:
                if 0 <= idx < len(items) and hasattr(items[idx], "name") and items[idx].name:
                    name = items[idx].name
                    if name and not name.startswith("__"):
                        s = self.store.get(name)
                        if s:
                            self.load_session(s)
            tree.focus()
            # Expand to spine+children when entering detail pane
            if self.current_session is not None:
                set_fold_level(tree.root, target_depth=2)
            event.prevent_default()

        elif event.key == "right" and tree.has_focus:
            # Right in tree = expand current node, or move to first child if already expanded
            cursor = tree.cursor_node
            if cursor is not None:
                if not cursor.is_expanded and cursor.children:
                    cursor.expand()
                    event.prevent_default()
                elif cursor.is_expanded and cursor.children:
                    # Move to first child
                    tree.action_cursor_down()
                    event.prevent_default()

        elif event.key == "left" and tree.has_focus:
            # Left in tree = collapse current node, or move to parent
            # At root level with collapsed node → go back to sessions pane
            cursor = tree.cursor_node
            if cursor is None or cursor == tree.root:
                sessions.focus()
                event.prevent_default()
            elif cursor.is_expanded:
                cursor.collapse()
                # Track manual collapse for resize preservation
                if cursor.data and cursor.data.get("uuid"):
                    self._manually_collapsed.add(cursor.data["uuid"])
                event.prevent_default()
            elif cursor.parent == tree.root:
                sessions.focus()
                event.prevent_default()
            elif cursor.parent is not None:
                tree.select_node(cursor.parent)
                cursor.parent.collapse()
                if cursor.parent.data and cursor.parent.data.get("uuid"):
                    self._manually_collapsed.add(cursor.parent.data["uuid"])
                event.prevent_default()

        # Up/down in tree: skip continuation lines (message-group navigation)
        elif event.key in ("down", "up") and tree.has_focus:
            safe = tree.cursor_node  # fallback if we run off the edge
            action = tree.action_cursor_down if event.key == "down" else tree.action_cursor_up
            action()
            # Skip past continuation-type leaves
            while (
                tree.cursor_node is not None
                and tree.cursor_node.data
                and tree.cursor_node.data.get("type") in _CONTINUATION_TYPES
            ):
                prev = tree.cursor_node
                action()
                if tree.cursor_node is prev:
                    # Hit boundary — return to last non-continuation position
                    if safe and (not safe.data or safe.data.get("type") not in _CONTINUATION_TYPES):
                        tree.select_node(safe)
                    break
            event.prevent_default()

        # Wrap-around navigation in sessions pane
        elif event.key == "down" and sessions.has_focus:
            item_count = len(sessions.children)
            idx = sessions.index if sessions.index is not None else 0
            if item_count > 0 and idx >= item_count - 1:
                sessions.index = 0
                event.prevent_default()

        elif event.key == "up" and sessions.has_focus:
            idx = sessions.index if sessions.index is not None else 0
            item_count = len(sessions.children)
            if item_count > 0 and idx <= 0:
                sessions.index = item_count - 1
                event.prevent_default()

    def _tree_width(self) -> int:
        """Current tree widget width in columns, falling back to 80."""
        try:
            tree = self.query_one("#session-tree", Tree)
            width = tree.size.width
        except Exception:
            width = 0
        return width or 80

    def _get_wrap_width(self, node: TreeNode) -> int:
        """Calculate available wrap width based on tree width and node depth."""
        tree_width = self._tree_width()
        depth = 0
        current = node
        while current.parent is not None:
            depth += 1
            current = current.parent
        indent = depth * 4 + 4
        return max(40, tree_width - indent)

    def _preview_widths_for_child(self, parent: TreeNode) -> tuple[int, int]:
        """Return (label_width, cont_width) for a new child of parent.

        label_width: columns available for the new child's own label line.
        cont_width: columns available for continuation leaves under that child
            (one tree-indent deeper than the label).
        """
        tree_width = self._tree_width()
        parent_depth = 0
        current = parent
        while current.parent is not None:
            parent_depth += 1
            current = current.parent
        new_depth = parent_depth + 1
        label_indent = new_depth * 4 + 4
        cont_indent = (new_depth + 1) * 4 + 4
        return max(1, tree_width - label_indent), max(1, tree_width - cont_indent)

    # ── Fold level + expand/collapse all ─────────────────────────────────

    def action_fold_level_1(self) -> None:
        """Collapse to spine only."""
        tree = self.query_one("#session-tree", Tree)
        set_fold_level(tree.root, target_depth=1)
        self._flash_status("Fold: spine only")

    def action_fold_level_2(self) -> None:
        """Show spine + first-level children."""
        tree = self.query_one("#session-tree", Tree)
        set_fold_level(tree.root, target_depth=2)
        self._flash_status("Fold: +children")

    def action_fold_level_3(self) -> None:
        """Expand everything (triggers lazy loads)."""
        tree = self.query_one("#session-tree", Tree)
        self._flash_status("Loading subagents...")
        set_fold_level(tree.root, target_depth=999)
        self._flash_status("Fold: expand all")

    def action_expand_all(self) -> None:
        """Expand all nodes."""
        self.action_fold_level_3()

    def action_collapse_all(self) -> None:
        """Collapse all nodes to spine."""
        self.action_fold_level_1()

    def _add_preview_continuations(
        self,
        parent: TreeNode,
        inline_lines: list[str],
        overflow_lines: list[str],
        *,
        uuid: str | None,
        full_text: str,
        dim: bool = False,
    ) -> None:
        """Add wrap continuation leaves (and optional overflow node) under a node.

        inline_lines appear directly under the parent when expanded.
        overflow_lines are hidden behind a "... (N more lines)" expand node.
        """
        data = {"type": "full_text", "uuid": uuid, "full_text": full_text}
        for line in inline_lines:
            safe = _escape_markup(line)
            if self._search_term:
                safe = _highlight_term(safe, _escape_markup(self._search_term))
            label = f"[dim]{safe}[/dim]" if dim else safe
            parent.add_leaf(label, data=data)
        if overflow_lines:
            # Overflow is an expandable node (▸/▾ arrow). Right-arrow,
            # Enter, or fold-level-3 expands; left-arrow collapses.
            overflow_node = parent.add(
                f"[dim]... ({len(overflow_lines)} more lines)[/dim]",
                data={
                    "type": "overflow",
                    "full_text": full_text,
                    "overflow_lines": overflow_lines,
                    "dim": dim,
                },
            )
            leaf_data = {"type": "full_text", "uuid": uuid, "full_text": full_text}
            for line in overflow_lines:
                safe = _escape_markup(line)
                if self._search_term:
                    safe = _highlight_term(safe, _escape_markup(self._search_term))
                label = f"[dim]{safe}[/dim]" if dim else safe
                overflow_node.add_leaf(label, data=leaf_data)
            overflow_node.collapse()

    def _add_wrapped_content(
        self,
        parent: TreeNode,
        text: str,
        *,
        dim: bool = True,
        node_type: str = "text",
        uuid: str | None = None,
        max_lines: int = MAX_INLINE_LINES,
    ) -> None:
        """Add word-wrapped text as inline tree nodes with overflow expand."""
        if not text or not text.strip():
            return
        wrap_width = self._get_wrap_width(parent)
        lines = _wrap_text(text, wrap_width)
        if not lines:
            return
        data = {"type": node_type, "uuid": uuid, "full_text": text}
        shown = lines[:max_lines]
        remaining = lines[max_lines:]
        for line in shown:
            safe = _escape_markup(line)
            if self._search_term:
                safe = _highlight_term(safe, _escape_markup(self._search_term))
            label = f"[dim]{safe}[/dim]" if dim else safe
            parent.add_leaf(label, data=data)
        if remaining:
            overflow_node = parent.add(
                f"[dim]... ({len(remaining)} more lines)[/dim]",
                data={
                    "type": "overflow",
                    "full_text": text,
                    "overflow_lines": remaining,
                    "dim": dim,
                },
            )
            leaf_data = {"type": node_type, "uuid": uuid, "full_text": text}
            for line in remaining:
                safe = _escape_markup(line)
                if self._search_term:
                    safe = _highlight_term(safe, _escape_markup(self._search_term))
                label = f"[dim]{safe}[/dim]" if dim else safe
                overflow_node.add_leaf(label, data=leaf_data)
            overflow_node.collapse()

    @staticmethod
    def _extract_result_text(block: ContentBlock) -> str:
        """Extract text from a tool_result content block."""
        result_content = block.content
        if isinstance(result_content, str):
            return result_content
        if isinstance(result_content, list):
            parts = []
            for sub in result_content:
                if isinstance(sub, dict) and sub.get("type") == "text":
                    parts.append(sub.get("text", ""))
                elif hasattr(sub, "type") and sub.type == "text":
                    parts.append(sub.text or "")
            return "\n".join(parts)
        return ""

    def _render_flat_assistant(
        self,
        parent: TreeNode,
        evt: SessionEvent,
        agent_links: dict[str, str],
        session: Session,
    ) -> None:
        """Render assistant message blocks as direct children of parent (flat).

        Tool_use blocks become direct children of parent (no Asst: wrapper).
        Text blocks get their own Asst: wrapper.  Results are inlined on the
        tool_use label when single-line, or rendered as child overflow nodes.
        """
        if evt.message is None:
            return

        content = evt.message.content

        # String content → simple Asst: text node
        if isinstance(content, str):
            if content.strip():
                label_width, cont_width = self._preview_widths_for_child(parent)
                label_line, inline, overflow = _compose_wrapped_preview(
                    content, "Asst: ", label_width, cont_width,
                )
                asst_label = f"[dim]{_escape_markup(label_line)}[/dim]"
                tc = self._turn_context.get(evt.uuid) if evt.uuid else None
                ctx_bar = format_delta_label(tc) if tc else ""
                if ctx_bar and label_width >= 60:
                    asst_label = _compose_annotated_label(
                        asst_label, "", ctx_bar, label_width,
                    )
                asst_label = _apply_role_color(asst_label)
                data = {"type": "assistant", "uuid": evt.uuid, "event": evt,
                        "full_text": content}
                if inline or overflow:
                    node = parent.add(asst_label, data=data)
                    self._add_preview_continuations(
                        node, inline, overflow,
                        uuid=evt.uuid, full_text=content, dim=True,
                    )
                else:
                    parent.add_leaf(asst_label, data=data)
            return

        if not isinstance(content, list):
            return

        # ── First pass: build result map ────────────────────────────────
        result_map: dict[str, str] = {}
        for block in content:
            if (hasattr(block, "type") and block.type == "tool_result"
                    and block.tool_use_id):
                text = self._extract_result_text(block)
                if text.strip():
                    result_map[block.tool_use_id] = text

        # ── Second pass: render blocks in order ─────────────────────────
        tool_nodes: dict[str, TreeNode] = {}
        label_width, cont_width = self._preview_widths_for_child(parent)
        tc = self._turn_context.get(evt.uuid) if evt.uuid else None
        ctx_bar = format_delta_label(tc) if tc else ""

        for block in content:
            if not hasattr(block, "type"):
                continue

            # ── Thinking ────────────────────────────────────────────
            if block.type == "thinking":
                thinking_text = block.text or getattr(block, "thinking", None) or ""
                data = {"type": "thinking", "uuid": evt.uuid,
                        "full_text": thinking_text}
                if thinking_text.strip():
                    think_node = parent.add(
                        "[dim]💭 thinking[/dim]", data=data,
                    )
                    self._add_wrapped_content(
                        think_node, thinking_text,
                        node_type="thinking_text", uuid=evt.uuid,
                    )
                else:
                    parent.add_leaf("[dim]💭 thinking[/dim]", data=data)

            # ── Text → Asst: wrapper ────────────────────────────────
            elif block.type == "text" and block.text:
                lbl, inline, overflow = _compose_wrapped_preview(
                    block.text, "Asst: ", label_width, cont_width,
                )
                safe_lbl = _escape_markup(lbl)
                if self._search_term:
                    safe_lbl = _highlight_term(safe_lbl, _escape_markup(self._search_term))
                asst_label = f"[dim]{safe_lbl}[/dim]"
                if ctx_bar and label_width >= 60:
                    asst_label = _compose_annotated_label(
                        asst_label, "", ctx_bar, label_width,
                    )
                    ctx_bar = ""  # only annotate first text node
                asst_label = _apply_role_color(asst_label)
                data = {"type": "assistant", "uuid": evt.uuid, "event": evt,
                        "full_text": block.text}
                if inline or overflow:
                    node = parent.add(asst_label, data=data)
                    self._add_preview_continuations(
                        node, inline, overflow,
                        uuid=evt.uuid, full_text=block.text, dim=True,
                    )
                else:
                    parent.add_leaf(asst_label, data=data)

            # ── Tool_use → direct child ─────────────────────────────
            elif block.type == "tool_use":
                tool_name = block.name or "?"

                # AskUserQuestion: keep existing pattern
                if tool_name == "AskUserQuestion":
                    questions = (block.input or {}).get("questions", [])
                    q_text = (questions[0].get("question", "")[:60]
                              if questions else "")
                    safe_q = _escape_markup(q_text)
                    answer = _extract_auq_answer(block.id, content)
                    safe_a = _escape_markup(answer)
                    auq_label = (
                        f"[dim]❓ \"{safe_q}\" → {safe_a}[/dim]"
                        if safe_a
                        else f"[dim]❓ \"{safe_q}\"[/dim]"
                    )
                    tool_node = parent.add(
                        auq_label,
                        data={"type": "tool_use", "uuid": evt.uuid,
                              "tool_use_id": block.id,
                              "name": tool_name, "input": block.input},
                    )
                    if block.input:
                        inp = json.dumps(block.input, indent=2,
                                         ensure_ascii=False)
                        self._add_wrapped_content(
                            tool_node, f"input: {inp}",
                            node_type="tool_input",
                        )
                    if block.id:
                        tool_nodes[block.id] = tool_node
                    continue

                # Agent: keep existing pattern
                if tool_name == "Agent":
                    desc = (block.input or {}).get("description", "")[:40]
                    agent_type = (block.input or {}).get("subagent_type", "")
                    tool_label = (
                        f"[dim]🤖 {agent_type}: \"{desc}\"[/dim]"
                        if agent_type
                        else f"[dim]🤖 Agent: \"{desc}\"[/dim]"
                    )
                    # Pre-expand model badge from Agent input
                    agent_input_model = (block.input or {}).get("model")
                    if agent_input_model:
                        badge = format_model_badge_short(
                            f"claude-{agent_input_model}")
                        tool_label = tool_label.replace(
                            "[/dim]", f" {badge}[/dim]", 1)
                    tool_node = parent.add(
                        tool_label,
                        data={"type": "agent", "uuid": evt.uuid,
                              "tool_use_id": block.id,
                              "name": tool_name, "input": block.input},
                    )
                    if session is not None:
                        agent_id = agent_links.get(block.id)
                        if agent_id:
                            sub_path = resolve_subagent_path(
                                agent_id, session.path,
                            )
                            if sub_path:
                                placeholder = tool_node.add_leaf(
                                    "[dim](expand to load transcript)[/dim]",
                                )
                                placeholder.data = {
                                    "type": "subagent_placeholder",
                                    "sub_path": str(sub_path),
                                }
                            else:
                                tool_node.add_leaf(
                                    "[dim](transcript not found)[/dim]",
                                )
                    if block.id:
                        tool_nodes[block.id] = tool_node
                    continue

                # ── Standard tool: flat rendering ───────────────────
                key_arg = ""
                if block.input:
                    for k in _KEY_ARG_KEYS:
                        if k in block.input:
                            val = str(block.input[k])[:40]
                            key_arg = f"  {val}"
                            break

                icon = _TEAM_TOOL_ICONS.get(tool_name, "🔧")
                result_text = result_map.get(block.id, "")
                has_input = bool(block.input)

                # Decide: inline result vs child result
                if result_text and "\n" not in result_text:
                    # Single-line result → inline on label
                    preview = result_text[:50]
                    if len(result_text) > 50:
                        preview += "…"
                    safe_r = _escape_markup(preview)
                    tool_label = (
                        f"[dim]{icon} {tool_name}{key_arg}"
                        f" → {safe_r}[/dim]"
                    )
                    node_data = {
                        "type": "tool_use", "uuid": evt.uuid,
                        "tool_use_id": block.id,
                        "name": tool_name, "input": block.input,
                        "result_text": result_text,
                    }
                    if has_input:
                        tool_node = parent.add(tool_label, data=node_data)
                        inp = json.dumps(block.input, indent=2,
                                         ensure_ascii=False)
                        self._add_wrapped_content(
                            tool_node, f"input: {inp}",
                            node_type="tool_input",
                        )
                    else:
                        tool_node = parent.add_leaf(
                            tool_label, data=node_data,
                        )
                else:
                    # No result or multi-line
                    arrow = " →" if result_text else ""
                    tool_label = (
                        f"[dim]{icon} {tool_name}{key_arg}{arrow}[/dim]"
                    )
                    node_data = {
                        "type": "tool_use", "uuid": evt.uuid,
                        "tool_use_id": block.id,
                        "name": tool_name, "input": block.input,
                        "result_text": result_text,
                    }
                    needs_children = bool(result_text) or has_input
                    if needs_children:
                        tool_node = parent.add(tool_label, data=node_data)
                        if result_text:
                            self._add_wrapped_content(
                                tool_node, result_text,
                                node_type="tool_result",
                            )
                        if has_input:
                            inp = json.dumps(block.input, indent=2,
                                             ensure_ascii=False)
                            self._add_wrapped_content(
                                tool_node, f"input: {inp}",
                                node_type="tool_input",
                            )
                    else:
                        tool_node = parent.add_leaf(
                            tool_label, data=node_data,
                        )

                if block.id:
                    tool_nodes[block.id] = tool_node

            # ── Tool_result: already handled via result_map ─────────
            elif block.type == "tool_result":
                # Only render if not matched to a tool_use in this message
                if block.tool_use_id and block.tool_use_id not in tool_nodes:
                    text = self._extract_result_text(block)
                    if text.strip():
                        self._add_wrapped_content(
                            parent, f"→ {text}",
                            node_type="tool_result", uuid=evt.uuid,
                        )

    def _render_assistant_event(
        self,
        parent: TreeNode,
        evt: SessionEvent,
        agent_links: dict[str, str],
        session: Session,
    ) -> TreeNode | None:
        """Render an assistant event as a tree node. Returns expandable node or None."""
        asst_text = evt.text_content
        label_width, cont_width = self._preview_widths_for_child(parent)

        if asst_text:
            label_line, inline_lines, overflow_lines = _compose_wrapped_preview(
                asst_text, "Asst: ", label_width, cont_width
            )
            asst_label = f"[dim]{_escape_markup(label_line)}[/dim]"
        else:
            inline_lines = []
            overflow_lines = []
            # Show tool names instead of generic "(tool calls)"
            tool_previews = [_tool_preview(b) for b in evt.tool_use_blocks]
            if tool_previews:
                summary = _format_tool_summary(
                    [_escape_markup(t) for t in tool_previews], max_shown=3,
                )
                asst_label = f"[dim]Asst: {summary}[/dim]"
            else:
                asst_label = "[dim]Asst: (tool calls)[/dim]"

        # Add context delta annotation on assistant nodes (diff, not cumulative)
        tc = self._turn_context.get(evt.uuid) if evt.uuid else None
        ctx_bar = format_delta_label(tc) if tc else ""
        if ctx_bar and label_width >= 60:
            asst_label = _compose_annotated_label(
                asst_label, "", ctx_bar, label_width,
            )
        asst_label = _apply_role_color(asst_label)

        has_tools = (
            evt.message
            and isinstance(evt.message.content, list)
            and any(
                hasattr(b, "type") and b.type == "tool_use"
                for b in evt.message.content
            )
        )
        has_thinking = (
            evt.message
            and isinstance(evt.message.content, list)
            and any(
                hasattr(b, "type") and b.type == "thinking"
                for b in evt.message.content
            )
        )
        needs_children = bool(
            has_tools or has_thinking or inline_lines or overflow_lines
        )

        if needs_children:
            asst_node = parent.add(
                asst_label,
                data={"type": "assistant", "uuid": evt.uuid, "event": evt},
            )
            self._add_preview_continuations(
                asst_node, inline_lines, overflow_lines,
                uuid=evt.uuid, full_text=asst_text or "", dim=True,
            )
            self._add_assistant_node(asst_node, evt, agent_links, session, skip_text=True)
            return asst_node
        else:
            parent.add_leaf(
                asst_label,
                data={"type": "assistant", "uuid": evt.uuid, "event": evt},
            )
            return None

    def load_session(self, session: Session) -> None:
        self._exit_col_focus()
        self.current_session = session

        # Update header
        from ..core.metadata import get_fork_metadata
        project_slug = Path(session.path).parent.name if session.path else ""
        fork_meta = get_fork_metadata(session.uuid, project_slug)

        header_lines = (
            f"[bold]{session.display_name}[/bold]  ({session.uuid[:12]})\n"
            f"{session.message_count} msgs  |  {session.claude_version or '?'}  |  "
            f"{'Compacted' if session.has_compaction else 'No compact'}  |  "
            f"{session.started_at.strftime('%Y-%m-%d %H:%M') if session.started_at else '?'}"
            f" → "
            f"{session.last_activity_at.strftime('%Y-%m-%d %H:%M') if session.last_activity_at else '?'}"
        )
        if session.is_team_lead:
            team_line = f"\n[bold magenta]team: {_escape_markup(session.team_name)}[/bold magenta]"
            cfg = read_team_config(session.team_name)
            if cfg and cfg.members:
                roster = ", ".join(
                    f"{_escape_markup(m.name)} ({_escape_markup(m.agentType)})"
                    for m in cfg.members
                )
                team_line += f"  —  {roster}"
            header_lines += team_line
        if fork_meta:
            src = fork_meta.get("forkedFrom", {})
            src_name = src.get("displayName") or src.get("sessionId", "?")[:12]
            src_project = src.get("projectSlug") or "?"
            src_msgs = src.get("messageCount")
            src_started = src.get("startedAt", "")[:10] if src.get("startedAt") else ""
            fork_line = f"\n[cyan]fork[/cyan] of [bold]{src_name}[/bold] in {src_project}"
            if src_msgs:
                fork_line += f" ({src_msgs} msgs"
                if src_started:
                    fork_line += f", started {src_started}"
                fork_line += ")"
            header_lines += fork_line

        header = self.query_one("#session-header", Static)
        header.update(header_lines)
        self._header_text = header_lines

        # Build the tree
        tree = self.query_one("#session-tree", Tree)
        tree.clear()
        tree.root.expand()

        # Get agent links for subagent resolution
        agent_links = find_agent_links(session.events)

        # Build spine: ordered list preserving event order
        spine: list[dict] = []
        current_user: SessionEvent | None = None
        current_turn_events: list[SessionEvent] = []
        orphaned_events: list[SessionEvent] = []
        pending_source_paths: list[str] = []

        def _flush_turn() -> dict:
            """Build a turn dict including any pending source paths."""
            nonlocal pending_source_paths
            turn = {
                "type": "turn", "user": current_user,
                "events": current_turn_events,
                "source_paths": pending_source_paths[:],
            }
            pending_source_paths = []
            return turn

        for evt in session.events:
            # Suppress [Image: source: ...]-only user events — merge paths
            # into the current turn instead of creating a new spine entry.
            if (evt.type == EventType.USER and _is_user_typed(evt)
                    and _is_image_source_only(evt)):
                if current_user is not None:
                    pending_source_paths.extend(_extract_image_source_paths(evt))
                continue

            if evt.type == EventType.USER and _is_user_typed(evt):
                if orphaned_events:
                    spine.append({"type": "orphan", "events": orphaned_events})
                    orphaned_events = []
                if current_user is not None:
                    spine.append(_flush_turn())
                current_user = evt
                current_turn_events = []
            elif evt.type == EventType.USER and not _is_user_typed(evt):
                if current_user is not None:
                    current_turn_events.append(evt)
                else:
                    orphaned_events.append(evt)
            elif evt.is_compact_boundary:
                if current_user is not None:
                    spine.append(_flush_turn())
                    current_user = None
                    current_turn_events = []
                if orphaned_events:
                    spine.append({"type": "orphan", "events": orphaned_events})
                    orphaned_events = []
                spine.append({"type": "compact", "event": evt})
            elif evt.type == EventType.ASSISTANT:
                # Assistant events belong to the current turn (or orphaned if before
                # any typed-user message).
                if current_user is not None:
                    current_turn_events.append(evt)
                else:
                    orphaned_events.append(evt)
            # Other event types (file-history-snapshot, queue-operation, custom-title,
            # last-prompt, progress, unknown) are not renderable inside a turn —
            # drop them so they don't turn a user node into an empty expandable.

        if current_user is not None:
            spine.append(_flush_turn())
        if orphaned_events:
            spine.append({"type": "orphan", "events": orphaned_events})

        # ── Build context + active-agents maps BEFORE rendering ──────────
        # (needed for inline annotations during label construction)
        self._turn_context = build_turn_context_map(session.events)
        self._active_agents = build_active_agents_map(session.events)
        tree_width = self._tree_width()

        # Render the spine in order
        prev_model: str | None = None
        for item in spine:
            if item["type"] == "compact":
                evt = item["event"]
                tree.root.add_leaf(
                    "[dim]══ COMPACT BOUNDARY ══[/dim]",
                    data={"type": "compact", "uuid": evt.uuid},
                )
                prev_model = None  # reset so next turn shows badge

            elif item["type"] == "orphan":
                for evt in item["events"]:
                    if evt.type == EventType.ASSISTANT:
                        self._render_flat_assistant(tree.root, evt, agent_links, session)

            elif item["type"] == "turn":
                user_evt = item["user"]
                agent_events = item["events"]
                full_text = user_evt.text_content or ""
                label_width, cont_width = self._preview_widths_for_child(tree.root)

                # Teammate-message content: replace raw text display with
                # one distinct sub-node per block.
                teammate_blocks = (
                    parse_teammate_messages(full_text)
                    if isinstance(user_evt.message.content if user_evt.message else None, str)
                    and contains_teammate_message(full_text)
                    else []
                )

                # Detect image blocks in user content
                image_blocks = user_evt.image_blocks

                if teammate_blocks:
                    user_label = f"User: [{len(teammate_blocks)} teammate message{'s' if len(teammate_blocks) > 1 else ''}]"
                    inline_lines = []
                    overflow_lines = []
                elif full_text:
                    user_label, inline_lines, overflow_lines = _compose_wrapped_preview(
                        full_text, "User: ", label_width, cont_width
                    )
                else:
                    user_label = "User: (empty)"
                    inline_lines = []
                    overflow_lines = []

                # ── Annotate user turn label with columns ──────────────────
                source_paths = item.get("source_paths", [])
                turn_tools = _collect_turn_tools(agent_events)
                tool_summary = _format_tool_count(turn_tools)
                image_col = _format_image_col(len(image_blocks))
                agents_snap = self._active_agents.get(user_evt.uuid)
                tasks_col = _format_badge("📋", len(agents_snap.tasks)) if agents_snap else ""
                subagents_col = _format_badge("🤖", len(agents_snap.subagents)) if agents_snap else ""
                questions_col = _format_badge("❓", len(agents_snap.pending_questions)) if agents_snap else ""
                tc = self._turn_context.get(user_evt.uuid)
                ctx_bar = format_mini_bar(tc) if tc else ""

                # ── Model badge: show on first turn, model change, after compact ──
                turn_model = _responding_model(agent_events)
                turn_window = window_size_for_model(turn_model) if turn_model else 0
                show_model_badge = turn_model is not None and (
                    prev_model is None or turn_model != prev_model
                )
                if turn_model is not None:
                    prev_model = turn_model

                base_label = user_label  # save before annotation

                # Build column list for Tab cycling
                columns: list[str] = []
                if image_col:
                    columns.append("image")
                if tool_summary:
                    columns.append("tool")
                if tasks_col:
                    columns.append("task")
                if subagents_col:
                    columns.append("subagent")
                if questions_col:
                    columns.append("question")
                if ctx_bar:
                    columns.append("context")

                user_data = {
                    "type": "user", "uuid": user_evt.uuid, "event": user_evt,
                    "full_text": full_text, "columns": columns,
                    "base_label": base_label,
                    "tool_summary_raw": tool_summary,
                    "image_col_raw": image_col,
                    "tasks_col_raw": tasks_col,
                    "subagents_col_raw": subagents_col,
                    "questions_col_raw": questions_col,
                    "ctx_bar_raw": ctx_bar,
                    "source_paths": source_paths,
                    "model_badge_model": turn_model,
                    "model_badge_window": turn_window,
                    "show_model_badge": show_model_badge,
                }

                needs_expansion = bool(
                    agent_events or inline_lines or overflow_lines
                    or teammate_blocks or image_blocks
                )

                if needs_expansion:
                    user_node = tree.root.add(base_label, data=user_data)
                    for block in teammate_blocks:
                        self._add_teammate_block_node(user_node, block, user_evt.uuid)
                    for i, img_block in enumerate(image_blocks):
                        source = img_block.model_extra.get("source", {})
                        media = source.get("media_type", "image/*")
                        src_path = source_paths[i] if i < len(source_paths) else None
                        user_node.add_leaf(
                            f"[dim]📷 Image ({_escape_markup(media)})[/dim]",
                            data={"type": "image", "uuid": user_evt.uuid,
                                  "block": img_block, "source_path": src_path},
                        )
                    self._add_preview_continuations(
                        user_node, inline_lines, overflow_lines,
                        uuid=user_evt.uuid, full_text=full_text, dim=False,
                    )

                    for evt in agent_events:
                        if evt.type == EventType.ASSISTANT:
                            self._render_flat_assistant(
                                user_node, evt, agent_links, session,
                            )
                        elif evt.type == EventType.USER:
                            result_text = evt.text_content
                            if result_text:
                                self._add_wrapped_content(
                                    user_node, f"→ {result_text}",
                                    node_type="tool_result", uuid=evt.uuid,
                                )
                        elif evt.type == "progress":
                            pass

                    # Auto-expand user turns so assistant lines are visible
                    user_node.expand()
                else:
                    user_node = tree.root.add_leaf(base_label, data=user_data)
                self._rebuild_user_label(user_node)

        # Team-lead-only: top-level Teammates section with lazy-loaded subtrees.
        if session.is_team_lead:
            self._add_teammates_section(tree.root, session)

        # Collect teammate colors from <teammate-message> blocks in user events
        # so we can color-accent the status bar when navigating inside a
        # teammate's transcript.
        self._teammate_colors = {}
        for evt in session.events:
            if evt.type == EventType.USER and evt.message is not None:
                content = evt.message.content
                if isinstance(content, str) and contains_teammate_message(content):
                    for block in parse_teammate_messages(content):
                        if block.color and block.teammate_id not in self._teammate_colors:
                            self._teammate_colors[block.teammate_id] = block.color

        # Paint initial status bar state immediately — don't wait for the user
        # to press an arrow key.
        self._initialize_status_bar_for_session(session)

        tree.focus()

    def _add_assistant_node(
        self,
        parent: TreeNode,
        evt: SessionEvent,
        agent_links: dict[str, str],
        session: Session,
        skip_text: bool = False,
    ) -> None:
        """Add an assistant message's content as tree nodes."""
        if evt.message is None:
            return

        content = evt.message.content
        if isinstance(content, str):
            if content.strip():
                self._add_wrapped_content(
                    parent, content, node_type="text", uuid=evt.uuid,
                )
            return

        if not isinstance(content, list):
            return

        # Track tool_use nodes by their ID so tool_results can nest under them
        tool_nodes: dict[str, TreeNode] = {}

        for block in content:
            if not hasattr(block, "type"):
                continue

            if block.type == "thinking":
                # Thinking text may be in block.text or block.thinking (extra field).
                # In production, Claude Code stores an empty string + signature
                # (thinking content is ephemeral and not persisted to JSONL).
                thinking_text = block.text or getattr(block, "thinking", None) or ""
                data = {"type": "thinking", "uuid": evt.uuid, "full_text": thinking_text}
                if thinking_text.strip():
                    think_node = parent.add("[dim]💭 thinking[/dim]", data=data)
                    self._add_wrapped_content(
                        think_node, thinking_text,
                        node_type="thinking_text", uuid=evt.uuid,
                    )
                else:
                    # No content available — show as a leaf (no empty expandable)
                    parent.add_leaf("[dim]💭 thinking[/dim]", data=data)
                continue

            if block.type == "text" and skip_text:
                continue

            if block.type == "text" and block.text:
                self._add_wrapped_content(
                    parent, block.text, node_type="text", uuid=evt.uuid,
                )

            elif block.type == "tool_use":
                tool_name = block.name or "?"

                # ── AskUserQuestion: first-class display ──────────────
                if tool_name == "AskUserQuestion":
                    questions = (block.input or {}).get("questions", [])
                    q_text = questions[0].get("question", "")[:60] if questions else ""
                    safe_q = _escape_markup(q_text)
                    answer = _extract_auq_answer(block.id, content)
                    safe_a = _escape_markup(answer)
                    if safe_a:
                        auq_label = f"[dim]❓ \"{safe_q}\" → {safe_a}[/dim]"
                    else:
                        auq_label = f"[dim]❓ \"{safe_q}\"[/dim]"
                    tool_node = parent.add(
                        auq_label,
                        data={"type": "tool_use", "uuid": evt.uuid,
                              "tool_use_id": block.id,
                              "name": tool_name, "input": block.input},
                    )
                    if block.input:
                        input_str = json.dumps(block.input, indent=2, ensure_ascii=False)
                        self._add_wrapped_content(
                            tool_node, f"input: {input_str}",
                            node_type="tool_input",
                        )
                    if block.id:
                        tool_nodes[block.id] = tool_node
                    continue

                # ── Standard tool_use rendering ───────────────────────
                key_arg = ""
                if block.input:
                    for k in _KEY_ARG_KEYS:
                        if k in block.input:
                            val = str(block.input[k])[:40]
                            key_arg = f"  {val}"
                            break

                icon = _TEAM_TOOL_ICONS.get(tool_name, "🔧")
                tool_label = f"[dim]{icon} {tool_name}{key_arg}[/dim]"

                if tool_name == "Agent":
                    desc = (block.input or {}).get("description", "")[:40]
                    agent_type = (block.input or {}).get("subagent_type", "")
                    tool_label = f"[dim]🤖 {agent_type}: \"{desc}\"[/dim]" if agent_type else f"[dim]🤖 Agent: \"{desc}\"[/dim]"
                    # Pre-expand model badge from Agent input
                    agent_input_model = (block.input or {}).get("model")
                    if agent_input_model:
                        badge = format_model_badge_short(
                            f"claude-{agent_input_model}")
                        tool_label = tool_label.replace(
                            "[/dim]", f" {badge}[/dim]", 1)

                    tool_node = parent.add(
                        tool_label,
                        data={"type": "agent", "uuid": evt.uuid, "tool_use_id": block.id,
                              "name": tool_name, "input": block.input},
                    )

                    # Defer subagent loading — store path for lazy load on expand
                    if session is not None:
                        agent_id = agent_links.get(block.id)
                        if agent_id:
                            sub_path = resolve_subagent_path(agent_id, session.path)
                            if sub_path:
                                placeholder = tool_node.add_leaf("[dim](expand to load transcript)[/dim]")
                                placeholder.data = {"type": "subagent_placeholder", "sub_path": str(sub_path)}
                            else:
                                tool_node.add_leaf("[dim](transcript not found)[/dim]")
                else:
                    tool_node = parent.add(
                        tool_label,
                        data={"type": "tool_use", "uuid": evt.uuid, "tool_use_id": block.id,
                              "name": tool_name, "input": block.input},
                    )
                    if block.input:
                        input_str = json.dumps(block.input, indent=2, ensure_ascii=False)
                        self._add_wrapped_content(
                            tool_node, f"input: {input_str}",
                            node_type="tool_input",
                        )

                # Track this tool_use node for matching tool_results
                if block.id:
                    tool_nodes[block.id] = tool_node

            elif block.type == "tool_result":
                result_content = block.content
                result_text = ""
                if isinstance(result_content, str):
                    result_text = result_content
                elif isinstance(result_content, list):
                    parts = []
                    for sub in result_content:
                        if isinstance(sub, dict) and sub.get("type") == "text":
                            parts.append(sub.get("text", ""))
                        elif hasattr(sub, "type") and sub.type == "text":
                            parts.append(sub.text or "")
                    result_text = "\n".join(parts)

                if result_text.strip():
                    result_parent = tool_nodes.get(block.tool_use_id) if block.tool_use_id else None
                    if result_parent is not None:
                        # Move → indicator to tool header label
                        old_label = str(result_parent.label)
                        idx = old_label.rfind("[/dim]")
                        if idx >= 0:
                            result_parent.label = old_label[:idx] + " →[/dim]"
                        self._add_wrapped_content(
                            result_parent, result_text,
                            node_type="tool_result",
                        )
                    else:
                        self._add_wrapped_content(
                            parent, f"→ {result_text}",
                            node_type="tool_result",
                        )

    def _add_teammate_block_node(
        self,
        parent: TreeNode,
        block: "TeammateMessageBlock",
        user_uuid: str | None,
    ) -> None:
        """Render one <teammate-message> block as a tree node."""
        if block.protocol is not None:
            icon = _PROTOCOL_ICONS.get(block.protocol.get("type"), "📡")
            proto_type = block.protocol.get("type", "?")
            label = f"[dim]{icon} {_escape_markup(block.teammate_id)}: {_escape_markup(proto_type)}[/dim]"
        else:
            preview = (block.summary or block.body.strip().split("\n")[0])[:80]
            color_tag = ""
            color_end = ""
            if block.color:
                # Rich supports common color names directly (blue, green, etc.)
                color_tag = f"[{block.color}]"
                color_end = f"[/{block.color}]"
            label = (
                f"💬 {color_tag}{_escape_markup(block.teammate_id)}{color_end}: "
                f"{_escape_markup(preview)}"
            )

        node = parent.add(
            label,
            data={
                "type": "teammate_message",
                "uuid": user_uuid,
                "teammate_id": block.teammate_id,
                "summary": block.summary,
                "full_text": block.body,
            },
        )
        # Expandable body shows the raw body text
        if block.body.strip():
            self._add_wrapped_content(
                node, block.body, node_type="teammate_body", uuid=user_uuid,
            )

    def _add_teammates_section(self, root: TreeNode, session: Session) -> None:
        """Add the bottom-of-tree Teammates section for team-lead sessions."""
        # Union of teammate names referenced in content + roster from team config
        names: set[str] = set(find_teammate_references(session.events))
        cfg = read_team_config(session.team_name) if session.team_name else None
        if cfg:
            for m in cfg.members:
                # Exclude the lead itself from the Teammates list — it's this session
                if cfg.leadAgentId and m.agentId == cfg.leadAgentId:
                    continue
                names.add(m.name)

        if not names:
            return

        section = root.add(
            "[bold magenta]Teammates[/bold magenta]",
            data={"type": "teammates_section"},
        )

        for name in sorted(names):
            paths = resolve_teammate_paths(name, session.path)
            label = f"[bold]{_escape_markup(name)}[/bold]"
            if not paths:
                label += "  [dim](no transcripts)[/dim]"
                section.add_leaf(label, data={"type": "teammate_empty", "name": name})
                continue
            label += f"  [dim]({len(paths)} turn file{'s' if len(paths) > 1 else ''})[/dim]"
            tm_node = section.add(
                label,
                data={
                    "type": "teammate_root",
                    "name": name,
                    "paths": [str(p) for p in paths],
                },
            )
            tm_node.add_leaf(
                "[dim](expand to load transcript)[/dim]",
                data={
                    "type": "teammate_placeholder",
                    "name": name,
                    "paths": [str(p) for p in paths],
                },
            )

    def _add_teammate_timeline(self, parent: TreeNode, paths: list[Path]) -> None:
        """Parse + render a teammate's full timeline under parent.

        Each wake-up file is parsed ONCE — the per-file events feed both the
        context-window map (with per-wake-up delta resets) and the merged
        chronological timeline used for rendering.
        """
        # Resolve teammate name from the enclosing teammate_root node
        tm_name: str | None = None
        n = parent
        while n is not None:
            if n.data and n.data.get("type") == "teammate_root":
                tm_name = n.data.get("name")
                break
            n = n.parent

        try:
            per_file_events = [parse_jsonl(p) for p in paths]
        except Exception:
            parent.add_leaf("(failed to parse teammate transcript)")
            return

        if tm_name:
            # teammate_id in <teammate-message> (lead-side) may not match the
            # teammate's meta.agentType exactly (case drift). Try direct, then
            # case-insensitive. Fall back to None → cyan accent.
            color = self._teammate_colors.get(tm_name)
            if color is None:
                lowered = tm_name.lower()
                for k, v in self._teammate_colors.items():
                    if k.lower() == lowered:
                        color = v
                        break
            self._turn_context.update(build_turn_context_map_for_wake_ups(
                per_file_events,
                teammate_name=tm_name,
                teammate_color=color,
            ))

        # Merged chronological timeline for rendering (no re-parse)
        events = merge_wake_up_events(per_file_events)

        for evt in events:
            if evt.type == EventType.USER:
                text = evt.text_content
                if not text:
                    continue
                # Teammate turn user messages often contain <teammate-message>
                # from the lead — render as nested teammate blocks if present.
                content = evt.message.content if evt.message else ""
                if isinstance(content, str) and contains_teammate_message(content):
                    for block in parse_teammate_messages(content):
                        self._add_teammate_block_node(parent, block, evt.uuid)
                else:
                    self._add_wrapped_content(
                        parent, f"Sub-User: {text}", dim=False,
                        node_type="sub_user", uuid=evt.uuid,
                    )
            elif evt.type == EventType.ASSISTANT:
                self._add_assistant_node(parent, evt, {}, None)

    def _add_subagent_nodes(self, parent: TreeNode, sub_path: Path) -> str | None:
        """Load a subagent transcript and add its turns as nested tree nodes.

        Returns the subagent's model ID if found, for post-expand badge update.
        """
        try:
            events = parse_jsonl(sub_path)
        except Exception:
            parent.add_leaf("(failed to parse subagent transcript)")
            return None

        # Find the outer assistant's TurnContext so subagent turns can render
        # the nested "parent + sub" 3-line status bar.
        # Walk up looking for an assistant or agent node with a uuid in the
        # turn context map (flat rendering puts agent nodes under user, not
        # under an assistant wrapper).
        outer_tc: TurnContext | None = None
        walk = parent
        while walk is not None:
            if walk.data and walk.data.get("type") in ("assistant", "agent"):
                outer_uuid = walk.data.get("uuid")
                if outer_uuid and outer_uuid in self._turn_context:
                    outer_tc = self._turn_context[outer_uuid]
                    break
            walk = walk.parent
        self._turn_context.update(build_turn_context_map(events, outer=outer_tc))

        sub_agent_links = find_agent_links(events)
        sub_model: str | None = None

        for evt in events:
            if (evt.type == EventType.ASSISTANT and sub_model is None
                    and evt.message and evt.message.model
                    and evt.message.model != "<synthetic>"):
                sub_model = evt.message.model
            if evt.type == EventType.USER:
                text = evt.text_content
                if text:
                    self._add_wrapped_content(
                        parent, f"Sub-User: {text}", dim=False,
                        node_type="sub_user", uuid=evt.uuid,
                    )
            elif evt.type == EventType.ASSISTANT:
                self._add_assistant_node(parent, evt, sub_agent_links, None)

        return sub_model

    def on_tree_node_expanded(self, event: Tree.NodeExpanded) -> None:
        """Lazy-load subagent / teammate transcripts when their node is expanded."""
        node = event.node
        # Check if any child is a subagent or teammate placeholder
        subagent_placeholders = []
        teammate_placeholders = []
        for child in node.children:
            if not child.data:
                continue
            kind = child.data.get("type")
            if kind == "subagent_placeholder":
                subagent_placeholders.append(child)
            elif kind == "teammate_placeholder":
                teammate_placeholders.append(child)

        for placeholder in subagent_placeholders:
            sub_path = Path(placeholder.data["sub_path"])
            placeholder.remove()
            sub_model = self._add_subagent_nodes(node, sub_path)
            # Post-expand: update 🤖 node label if subagent model differs
            if sub_model:
                outer_tc: TurnContext | None = None
                walk: TreeNode | None = node
                while walk is not None:
                    if walk.data and walk.data.get("type") in (
                        "assistant", "agent",
                    ):
                        outer_uuid = walk.data.get("uuid")
                        if outer_uuid and outer_uuid in self._turn_context:
                            outer_tc = self._turn_context[outer_uuid]
                            break
                    walk = walk.parent
                parent_model = outer_tc.model if outer_tc else None
                if sub_model != parent_model:
                    sub_window = window_size_for_model(sub_model)
                    badge = format_model_badge(sub_model, sub_window)
                    old_label = str(node.label)
                    idx = old_label.rfind("[/dim]")
                    if idx >= 0:
                        node.set_label(old_label[:idx] + f" {badge}[/dim]")

        for placeholder in teammate_placeholders:
            paths = [Path(p) for p in placeholder.data["paths"]]
            placeholder.remove()
            self._add_teammate_timeline(node, paths)

    def action_search(self) -> None:
        def handle_result(result: str | None) -> None:
            if not result:
                return
            parts = result.split("|", 2)
            session_uuid = parts[0]
            msg_uuid = parts[1] if len(parts) > 1 and parts[1] else None
            query = parts[2] if len(parts) > 2 and parts[2] else None

            session = self.store.get(session_uuid)
            if session:
                # Set search term BEFORE load_session so highlights are injected
                self._search_term = query
                self.load_session(session)
                # Highlight in sessions list
                lv = self.query_one("#sessions-pane", ListView)
                for i, item in enumerate(lv.children):
                    if hasattr(item, "name") and item.name == session_uuid:
                        lv.index = i
                        break

                tree = self.query_one("#session-tree", Tree)

                # Expand to spine+children so highlighted content is visible
                set_fold_level(tree.root, target_depth=2)

                # Snap to the matched message in the tree
                if msg_uuid:
                    self._snap_to_message(tree, msg_uuid)

                # Jump to first highlighted node if we have a search term
                if query:
                    self._snap_to_first_match(tree)

                self._update_match_count()

        self.push_screen(SearchScreen(self.store), handle_result)

    def _snap_to_message(self, tree: Tree, msg_uuid: str) -> None:
        """Find and expand the tree node containing msg_uuid, scroll to it."""
        def find_node(node: TreeNode) -> TreeNode | None:
            if node.data and node.data.get("uuid") == msg_uuid:
                return node
            for child in node.children:
                result = find_node(child)
                if result:
                    return result
            return None

        target = find_node(tree.root)
        if target:
            # Expand all ancestors so the node is visible
            current = target.parent
            while current is not None and current != tree.root:
                current.expand()
                current = current.parent
            # If target is a user turn spine node, expand it too
            if target.children:
                target.expand()
            tree.select_node(target)
            tree.scroll_to_node(target)

    # ── Search highlight navigation ──────────────────────────────────────

    def _collect_highlighted_nodes(self, root: TreeNode) -> list[TreeNode]:
        """DFS walk collecting all nodes with search-highlight [reverse] markup."""
        found: list[TreeNode] = []

        def walk(node: TreeNode) -> None:
            label = node.label
            markup = label.markup if hasattr(label, "markup") else str(label)
            if "[reverse]" in markup:
                found.append(node)
            for child in node.children:
                walk(child)

        walk(root)
        return found

    def _snap_to_first_match(self, tree: Tree) -> None:
        """Select and scroll to the first highlighted node in the tree."""
        nodes = self._collect_highlighted_nodes(tree.root)
        if nodes:
            target = nodes[0]
            # Expand ancestors so node is visible
            current = target.parent
            while current is not None and current != tree.root:
                current.expand()
                current = current.parent
            tree.select_node(target)
            tree.scroll_to_node(target)

    def _next_search_match(self) -> None:
        """Jump to the next highlighted node after the current cursor."""
        tree = self.query_one("#session-tree", Tree)
        nodes = self._collect_highlighted_nodes(tree.root)
        if not nodes:
            return
        cursor = tree.cursor_node
        # Find cursor position in the list
        idx = -1
        for i, n in enumerate(nodes):
            if n is cursor:
                idx = i
                break
        # If cursor is on a highlighted node, go to next; otherwise go to first
        target_idx = (idx + 1) % len(nodes) if idx >= 0 else 0
        target = nodes[target_idx]
        # Expand ancestors
        current = target.parent
        while current is not None and current != tree.root:
            current.expand()
            current = current.parent
        tree.select_node(target)
        tree.scroll_to_node(target)
        tree.focus()
        self._update_match_count()

    def _prev_search_match(self) -> None:
        """Jump to the previous highlighted node before the current cursor."""
        tree = self.query_one("#session-tree", Tree)
        nodes = self._collect_highlighted_nodes(tree.root)
        if not nodes:
            return
        cursor = tree.cursor_node
        idx = -1
        for i, n in enumerate(nodes):
            if n is cursor:
                idx = i
                break
        target_idx = (idx - 1) % len(nodes) if idx >= 0 else len(nodes) - 1
        target = nodes[target_idx]
        current = target.parent
        while current is not None and current != tree.root:
            current.expand()
            current = current.parent
        tree.select_node(target)
        tree.scroll_to_node(target)
        tree.focus()
        self._update_match_count()

    def _update_match_count(self) -> None:
        """Show match count in status bar: '3/7 matches for "term"'."""
        if not self._search_term:
            return
        tree = self.query_one("#session-tree", Tree)
        nodes = self._collect_highlighted_nodes(tree.root)
        total = len(nodes)
        cursor = tree.cursor_node
        current = 0
        for i, n in enumerate(nodes):
            if n is cursor:
                current = i + 1
                break
        term = self._search_term
        if total > 0:
            self._flash_status(f"{current}/{total} matches for \"{term}\"")
        else:
            self._flash_status(f"0 matches for \"{term}\"")

    def _clear_search(self) -> None:
        """Clear search highlights and rebuild the tree."""
        self._search_term = None
        if self.current_session:
            self.load_session(self.current_session)

    def _show_template_detail(self, tpl_name: str) -> None:
        """Show template detail: list of forks spawned from this template."""
        from ..core.metadata import find_template_forks
        from ..core.templates import list_templates

        project_dir_name = self._get_project_dir_name()
        templates = list_templates(project_dir_name)
        tpl = next((t for t in templates if t["name"] == tpl_name), None)
        if not tpl:
            self._flash_status(f"Template '{tpl_name}' not found")
            return

        self._browsing_template = tpl
        self.current_session = None

        # Discover forks spawned from this template
        forks = find_template_forks(tpl_name, project_dir_name)

        # Update header with template info + template-specific hints
        header = self.query_one("#session-header", Static)
        fork_count = tpl.get("forkCount", 0)
        src_name = tpl.get("sourceDisplayName") or tpl.get("sourceSlug") or tpl.get("sourceSessionId", "?")[:12]
        created = (tpl.get("createdAt") or "?")[:10]
        header.update(
            f"[bold magenta]★ {tpl['name']}[/bold magenta]\n"
            f"Source: [bold]{src_name}[/bold]  ({tpl.get('sourceSessionId', '?')[:12]})\n"
            f"Created: {created}  |  Forks: {fork_count}\n"
            f"[dim]\\[F] New fork  \\[Enter/→] Open fork  \\[S] Source session  \\[R] Rename  \\[X] Delete[/dim]"
        )

        # Populate tree with fork list
        tree = self.query_one("#session-tree", Tree)
        tree.clear()
        tree.root.expand()

        if not forks:
            tree.root.add_leaf(
                "[dim]No forks yet — press F to create one[/dim]",
                data={"type": "info"},
            )
            return

        tree.root.add_leaf(
            f"[bold]── Forks ({len(forks)}) ──[/bold]",
            data={"type": "label"},
        )

        for f in forks:
            sid = f["sessionId"]
            forged_at = f.get("forgedAt", "")[:10]
            session = self.store.get(sid)
            if session:
                name = session.display_name
                msgs = session.message_count
                tree.root.add_leaf(
                    f"  {name}    [dim]{msgs} msgs  {forged_at}[/dim]",
                    data={"type": "template_fork", "session_id": sid},
                )
            else:
                tree.root.add_leaf(
                    f"  [dim](deleted) {sid[:12]}…  {forged_at}[/dim]",
                    data={"type": "template_fork_deleted", "session_id": sid},
                )

    def _jump_to_fork_session(self) -> None:
        """Jump from template detail to the highlighted fork session."""
        tree = self.query_one("#session-tree", Tree)
        node = tree.cursor_node
        if not node or not node.data:
            return
        if node.data.get("type") != "template_fork":
            return

        session_id = node.data.get("session_id")
        if not session_id:
            return

        session = self.store.get(session_id)
        if session is None:
            self._flash_status("Session not found")
            return

        # Remember which template we came from for back-navigation
        self._returned_from_template = self._browsing_template
        self._browsing_template = None
        self.load_session(session)
        tree.focus()

    def _jump_to_source_session(self) -> None:
        """Jump from template detail to the source session at the fork point."""
        tpl = self._browsing_template
        if not tpl:
            return

        session = self.store.get(tpl.get("sourceSessionId", ""))
        if session is None:
            self._flash_status("Source session not found")
            return

        # Remember which template we came from for back-navigation
        self._returned_from_template = tpl
        self._browsing_template = None
        self.load_session(session)

        # Snap to the fork point message
        fork_uuid = tpl.get("sourceMessageUuid")
        if fork_uuid:
            tree = self.query_one("#session-tree", Tree)
            self._snap_to_message(tree, fork_uuid)
            tree.focus()

    def _back_to_template(self) -> None:
        """Navigate back to the template detail from a fork/source session."""
        tpl = getattr(self, "_returned_from_template", None)
        if not tpl:
            return
        self._returned_from_template = None
        self._show_template_detail(tpl["name"])
        # Re-highlight the template in the sessions pane
        lv = self.query_one("#sessions-pane", ListView)
        for idx, item in enumerate(lv.children):
            if getattr(item, "name", None) == f"__tpl__{tpl['name']}":
                lv.index = idx
                break

    def action_copy_session_id(self) -> None:
        """Copy the UUID of the highlighted session to clipboard (i key)."""
        sessions = self.query_one("#sessions-pane", ListView)
        idx = sessions.index if sessions.index is not None else 0
        items = list(sessions.children)
        if 0 <= idx < len(items):
            name = getattr(items[idx], "name", "") or ""
            if name and not name.startswith("__"):
                self._do_copy(name)
                return
        self._flash_status("No session selected")

    def _do_copy(self, text: str) -> None:
        """Copy text to clipboard and flash a preview."""
        preview = text[:60].replace("\n", " ")
        suffix = "..." if len(text) > 60 else ""
        try:
            method = _copy_to_clipboard(text)
        except Exception:
            self._flash_status(
                "Copy failed: no clipboard backend"
                " (install xclip/xsel or use an OSC 52 terminal)"
            )
            return
        if method == "osc52":
            self._flash_status(f"Copied (terminal): {preview}{suffix}")
        else:
            self._flash_status(f"Copied: {preview}{suffix}")

    def action_copy_node(self) -> None:
        """Copy the focused tree node's text to clipboard (c key)."""
        tree = self.query_one("#session-tree", Tree)
        node = tree.cursor_node
        if not node or not self.current_session:
            self._flash_status("Nothing to copy")
            return
        text = _extract_copy_text(node)
        if not text:
            self._flash_status("Nothing to copy")
            return
        self._do_copy(text)

    def action_copy_subtree(self) -> None:
        """Copy the focused node + all descendants to clipboard (C key)."""
        tree = self.query_one("#session-tree", Tree)
        node = tree.cursor_node
        if not node or not self.current_session:
            self._flash_status("Nothing to copy")
            return
        text = _extract_subtree_text(node)
        if not text:
            self._flash_status("Nothing to copy")
            return
        self._do_copy(text)

    def _open_image_node(self, node) -> bool:
        """Open a single image node. Returns True if opened successfully."""
        import subprocess
        from pathlib import Path as _Path

        # Try source file path first
        source_path = node.data.get("source_path") if node.data else None
        if source_path:
            p = _Path(source_path)
            if p.exists():
                subprocess.Popen(["open", str(p)])
                self._flash_status(f"Opened: {p.name}")
                return True
            else:
                self._flash_status(f"Source not found: {p.name}, trying base64...")

        # Fall back to base64 temp file
        block = node.data.get("block") if node.data else None
        if block is None:
            return False
        source = block.model_extra.get("source", {})
        data_b64 = source.get("data")
        if not data_b64:
            self._flash_status("Image has no inline data or source path")
            return False
        media_type = source.get("media_type", "image/png")
        ext = media_type.split("/")[-1] if "/" in media_type else "png"
        import base64
        import tempfile
        try:
            with tempfile.NamedTemporaryFile(
                suffix=f".{ext}", delete=False, prefix="cctree-img-",
            ) as f:
                f.write(base64.b64decode(data_b64))
                path = f.name
            subprocess.Popen(["open", path])
            self._flash_status(f"Opened: {path}")
            return True
        except Exception as e:
            self._flash_status(f"Failed to open image: {e}")
            return False

    def action_open_image(self) -> None:
        """Open highlighted image node, or fall through to default tree behavior."""
        tree = self.query_one("#session-tree", Tree)
        node = tree.cursor_node
        if node is not None and node.data and node.data.get("type") == "image":
            self._open_image_node(node)
            return
        # Not an image node — do default tree expand/collapse
        if node is not None and node.children:
            if node.is_expanded:
                node.collapse()
            else:
                node.expand()

    def action_copy_fork(self) -> None:
        # If browsing a template, fork from it
        if self._browsing_template:
            self._fork_from_template()
            return

        tree = self.query_one("#session-tree", Tree)
        node = tree.cursor_node
        if not node or not self.current_session:
            self._flash_status("No message selected")
            return

        msg_uuid = _find_nearest_uuid(node)
        if not msg_uuid:
            self._flash_status("No message UUID at this node")
            return

        session = self.current_session
        project_dir = Path(session.path).parent
        cmd = f"cctree fork {session.uuid} {msg_uuid} -p {project_dir} --no-launch"
        self._do_copy(cmd)

    def _fork_from_template(self) -> None:
        """Fork from the currently browsing template."""
        tpl = self._browsing_template
        if not tpl:
            return

        session = self.store.get(tpl.get("sourceSessionId", ""))
        if session is None:
            self._flash_status("Source session not found — cannot fork")
            return

        try:
            from ..core.forge import forge_session as do_forge
            from ..core.metadata import write_fork_metadata
            from ..core.templates import record_usage

            dest_dir = Path(session.path).parent
            project_dir_name = self._get_project_dir_name()
            result = do_forge(Path(session.path), tpl["sourceMessageUuid"], dest_dir)
            write_fork_metadata(result.new_session_id, project_dir_name, session.uuid, tpl["sourceMessageUuid"], source_session=session, template_name=tpl["name"])
            record_usage(tpl["name"], project_dir_name)

            self.exit(result={"resume_session_id": result.new_session_id})
        except Exception as e:
            self._flash_status(f"Fork failed: {e}")

    def action_save_template(self) -> None:
        """Save a template from the currently selected message (T key)."""
        tree = self.query_one("#session-tree", Tree)
        node = tree.cursor_node

        # If browsing source from a template, T updates the fork point
        if self._browsing_template and self.current_session:
            msg_uuid = _find_nearest_uuid(node) if node else None
            if msg_uuid:
                self._update_template_fork_point(msg_uuid)
            else:
                self._flash_status("No message selected")
            return

        if not node or not self.current_session:
            self._flash_status("No message selected")
            return

        msg_uuid = _find_nearest_uuid(node)
        if not msg_uuid:
            self._flash_status("No message UUID at this node")
            return

        session = self.current_session
        # Get message preview
        preview = ""
        for e in session.events:
            if e.uuid == msg_uuid:
                preview = e.text_content[:100]
                break

        def handle_name(name: str | None) -> None:
            if not name:
                return
            try:
                from ..core.templates import TemplateExistsError, save_template

                project_dir_name = self._get_project_dir_name()
                save_template(
                    name=name,
                    project_dir_name=project_dir_name,
                    source_session_id=session.uuid,
                    source_message_uuid=msg_uuid,
                    source_display_name=session.display_name,
                    source_slug=session.slug,
                    source_message_preview=preview,
                )
                self._flash_status(f"Template '{name}' saved ★")
                self._refresh_session_list()
            except TemplateExistsError:
                self._flash_status(f"Template '{name}' already exists")
            except ValueError as e:
                self._flash_status(str(e))

        self.push_screen(
            InputModal("★ Save Template", "Template name..."),
            handle_name,
        )

    def _update_template_fork_point(self, msg_uuid: str) -> None:
        """Update the browsing template's fork point to the given message."""
        tpl = self._browsing_template
        if not tpl:
            return
        try:
            from ..core.templates import update_fork_point

            preview = ""
            if self.current_session:
                for e in self.current_session.events:
                    if e.uuid == msg_uuid:
                        preview = e.text_content[:100]
                        break

            project_dir_name = self._get_project_dir_name()
            update_fork_point(tpl["name"], project_dir_name, msg_uuid, preview)
            tpl["sourceMessageUuid"] = msg_uuid
            self._flash_status(f"Template '{tpl['name']}' updated to message {msg_uuid[:8]}")
            self._show_template_detail(tpl["name"])
        except Exception as e:
            self._flash_status(f"Update failed: {e}")

    def action_rename_template(self) -> None:
        """Rename the selected template (R key)."""
        lv = self.query_one("#sessions-pane", ListView)
        if not lv.has_focus:
            return
        idx = lv.index
        if idx is None:
            return
        items = list(lv.children)
        if not (0 <= idx < len(items)):
            return
        item_name = items[idx].name or ""
        if not item_name.startswith("__tpl__"):
            return
        old_name = item_name[7:]

        def handle_new_name(new_name: str | None) -> None:
            if not new_name:
                return
            try:
                from ..core.templates import rename_template
                project_dir_name = self._get_project_dir_name()
                rename_template(old_name, new_name, project_dir_name)
                self._flash_status(f"Renamed: '{old_name}' → '{new_name}'")
                self._refresh_session_list()
            except Exception as e:
                self._flash_status(str(e))

        self.push_screen(
            InputModal("Rename Template", "New name...", default=old_name),
            handle_new_name,
        )

    def action_delete_template(self) -> None:
        """Delete the selected template (X key) with confirmation."""
        lv = self.query_one("#sessions-pane", ListView)
        if not lv.has_focus:
            return
        idx = lv.index
        if idx is None:
            return
        items = list(lv.children)
        if not (0 <= idx < len(items)):
            return
        item_name = items[idx].name or ""
        if not item_name.startswith("__tpl__"):
            return
        tpl_name = item_name[7:]

        def handle_confirm(result: str | None) -> None:
            if result and result.lower() in ("y", "yes", tpl_name):
                try:
                    from ..core.templates import delete_template
                    project_dir_name = self._get_project_dir_name()
                    delete_template(tpl_name, project_dir_name)
                    self._flash_status(f"Template '{tpl_name}' deleted")
                    self._browsing_template = None
                    self._refresh_session_list()
                except Exception as e:
                    self._flash_status(str(e))
            else:
                self._flash_status("Delete cancelled")

        self.push_screen(
            InputModal(f"Delete template '{tpl_name}'?", "Type 'y' to confirm"),
            handle_confirm,
        )

    def check_action(self, action: str, parameters: tuple) -> bool | None:
        """Conditionally enable actions based on focus and cursor position."""
        # Global actions — always available
        if action in ("quit", "search", "focus_next_pane"):
            return True

        sessions = self.query_one("#sessions-pane", ListView)
        tree = self.query_one("#session-tree", Tree)

        # Sessions-pane-only: sort toggle
        if action == "toggle_sort":
            return sessions.has_focus

        # Sessions-pane + cursor on session: copy session ID
        if action == "copy_session_id":
            if not sessions.has_focus:
                return False
            idx = sessions.index
            if idx is None:
                return False
            items = list(sessions.children)
            if 0 <= idx < len(items):
                item_name = getattr(items[idx], "name", "") or ""
                return bool(item_name) and not item_name.startswith("__")
            return False

        # Sessions-pane + cursor on template: rename / delete
        if action in ("rename_template", "delete_template"):
            if not sessions.has_focus:
                return False
            idx = sessions.index
            if idx is None:
                return False
            items = list(sessions.children)
            if 0 <= idx < len(items):
                item_name = getattr(items[idx], "name", "") or ""
                return item_name.startswith("__tpl__")
            return False

        # Template detail context: only template-specific actions
        in_template_detail = self._browsing_template is not None and self.current_session is None

        # jump_to_source: only in template detail
        if action == "jump_to_source":
            return in_template_detail

        # back_to_template: only when we jumped away from a template
        if action == "back_to_template":
            return getattr(self, "_returned_from_template", None) is not None

        # In template detail, allow fork from either pane
        if in_template_detail and action == "copy_fork":
            return True

        # In template detail, disable session-only tree actions
        if in_template_detail and action in (
            "copy_node", "copy_subtree", "save_template",
            "fold_level_1", "fold_level_2", "fold_level_3",
            "expand_all", "collapse_all", "open_image",
        ):
            return False

        # Detail-pane-only actions (session context)
        if action in (
            "copy_node", "copy_subtree", "copy_fork", "save_template",
            "fold_level_1", "fold_level_2", "fold_level_3",
            "expand_all", "collapse_all", "open_image",
        ):
            return tree.has_focus

        return True

    def _browse_template_source(self, tpl_name: str) -> None:
        """Browse into the source session of a template, snapping to the fork point."""
        from ..core.templates import list_templates

        project_dir_name = self._get_project_dir_name()
        templates = list_templates(project_dir_name)
        tpl = next((t for t in templates if t["name"] == tpl_name), None)
        if not tpl:
            self._flash_status(f"Template '{tpl_name}' not found")
            return

        session = self.store.get(tpl.get("sourceSessionId", ""))
        if session is None:
            self._flash_status("Source session not found")
            return

        self._browsing_template = tpl
        self.load_session(session)

        # Snap to the fork point message
        fork_uuid = tpl.get("sourceMessageUuid")
        if fork_uuid:
            tree = self.query_one("#session-tree", Tree)
            self._snap_to_message(tree, fork_uuid)

        # Update header to show we're browsing from a template
        header = self.query_one("#session-header", Static)
        current_text = getattr(self, "_header_text", "")
        header.update(
            f"{current_text}\n"
            f"[magenta]Browsing from template: [bold]{tpl_name}[/bold] — T to update fork point[/magenta]"
        )

    def action_jump_to_source(self) -> None:
        """Jump to the source session of the browsing template (S key)."""
        if self._browsing_template:
            self._jump_to_source_session()

    def action_back_to_template(self) -> None:
        """Navigate back to the template detail (B key)."""
        self._back_to_template()

    def action_toggle_sort(self) -> None:
        """Toggle sort for whichever section has focus."""
        sessions = self.query_one("#sessions-pane", ListView)
        if not sessions.has_focus:
            return

        # Check if cursor is in templates section or sessions section
        idx = sessions.index if sessions.index is not None else 0
        items = list(sessions.children)
        in_templates = False
        if 0 <= idx < len(items):
            item_name = getattr(items[idx], "name", "") or ""
            in_templates = item_name.startswith("__tpl")

        if in_templates:
            cycle = ["last_forked", "fork_count", "created", "name"]
            cur = cycle.index(self.template_sort_by) if self.template_sort_by in cycle else 0
            self.template_sort_by = cycle[(cur + 1) % len(cycle)]
            self._flash_status(f"Template sort: {self.template_sort_by}")
        else:
            if self.sort_by == "last_activity":
                self.sort_by = "started_at"
            else:
                self.sort_by = "last_activity"
            self._flash_status(f"Session sort: {self.sort_by}")

        self._refresh_session_list()

    def action_focus_next_pane(self) -> None:
        sessions = self.query_one("#sessions-pane", ListView)
        tree = self.query_one("#session-tree", Tree)

        # Tab on a user turn with columns → enter/cycle column focus mode
        if tree.has_focus:
            cursor = tree.cursor_node
            if cursor and cursor.data and cursor.data.get("type") == "user":
                columns = cursor.data.get("columns", [])
                if columns:
                    if (self._col_focus_index is None
                            or self._col_focus_node_id != id(cursor)):
                        # Enter column mode on this node
                        self._col_focus_index = 0
                        self._col_focus_columns = columns
                        self._col_focus_node_id = id(cursor)
                    else:
                        # Advance (wrap around)
                        self._col_focus_index = (
                            (self._col_focus_index + 1) % len(columns)
                        )
                    self._highlight_column(cursor)
                    return

        # Default: switch panes
        self._exit_col_focus()
        if sessions.has_focus:
            tree.focus()
            # Expand to spine+children when entering detail pane
            if self.current_session is not None:
                set_fold_level(tree.root, target_depth=2)
        else:
            sessions.focus()

    # ── Column focus mode helpers ────────────────────────────────────

    def _exit_col_focus(self) -> None:
        """Exit column focus mode, restoring the original label."""
        if self._col_focus_index is None:
            return
        node_id = self._col_focus_node_id
        self._col_focus_index = None
        self._col_focus_columns = []
        self._col_focus_node_id = None
        # Re-render label without highlight
        tree = self.query_one("#session-tree", Tree)
        cursor = tree.cursor_node
        if cursor and id(cursor) == node_id:
            self._rebuild_user_label(cursor)

    def _highlight_column(self, node) -> None:
        """Re-render user turn label with the focused column highlighted."""
        if self._col_focus_index is None or not self._col_focus_columns:
            return
        focused = self._col_focus_columns[self._col_focus_index]
        self._flash_status(f"Column: {focused}")
        self._rebuild_user_label(node, highlight_col=focused)

    def _rebuild_user_label(self, node, highlight_col: str | None = None) -> None:
        """Re-compose user turn label, optionally highlighting a column."""
        data = node.data
        if not data or data.get("type") != "user":
            return
        base_label = data.get("base_label")
        if base_label is None:
            return
        # Inject search highlight into the base label text
        if self._search_term:
            base_label = _highlight_term(
                _escape_markup(base_label), _escape_markup(self._search_term),
            )
        else:
            base_label = _escape_markup(base_label)
        label_width, _ = self._preview_widths_for_child(node.parent)
        # Inject model badge after escaping (badge has its own Rich markup)
        if data.get("show_model_badge"):
            badge_model = data.get("model_badge_model")
            badge_window = data.get("model_badge_window", 0)
            if badge_model:
                badge = (format_model_badge(badge_model, badge_window)
                         if label_width >= 60
                         else format_model_badge_short(badge_model))
                if base_label.startswith("User: "):
                    base_label = f"User: {badge} {base_label[6:]}"
                elif base_label.startswith(_escape_markup("User: ")):
                    base_label = f"User: {badge} {base_label[6:]}"
                else:
                    base_label = f"{badge} {base_label}"
        tool_summary = data.get("tool_summary_raw", "")
        image_col = data.get("image_col_raw", "")
        tasks_col = data.get("tasks_col_raw", "")
        subagents_col = data.get("subagents_col_raw", "")
        questions_col = data.get("questions_col_raw", "")
        ctx_bar = data.get("ctx_bar_raw", "")
        user_label = _compose_annotated_label(
            base_label, tool_summary, ctx_bar, label_width,
            image_col=image_col,
            tasks_col=tasks_col, subagents_col=subagents_col,
            questions_col=questions_col,
            highlight_col=highlight_col,
        )
        user_label = _apply_role_color(user_label)
        node.set_label(user_label)

    def _execute_column_action(self, node, col: str) -> None:
        """Execute the action associated with a focused column."""
        if col == "image":
            self._jump_to_first_child(node, "image")
        elif col == "tool":
            self._jump_to_first_child(node, "tool_use")
        elif col == "task":
            self._jump_to_first_child(
                node, "tool_use", name_filter=("TaskCreate", "TaskUpdate"),
            )
        elif col == "subagent":
            self._jump_to_first_child(node, "agent")
        elif col == "question":
            self._jump_to_first_child(node, "tool_use", name_filter=("AskUserQuestion",))
        elif col == "context":
            uuid = node.data.get("uuid") if node.data else None
            if uuid:
                tc = self._turn_context.get(uuid)
                if tc:
                    lines = format_status_lines(tc, narrow=False)
                    self._flash_status(" | ".join(lines))

    def _open_turn_images(self, node) -> None:
        """Open all image nodes under a user turn."""
        opened = 0
        for child in node.children:
            if child.data and child.data.get("type") == "image":
                if self._open_image_node(child):
                    opened += 1
        if opened:
            self._flash_status(f"Opened {opened} image{'s' if opened > 1 else ''}")
        else:
            self._flash_status("No images to open")

    def _jump_to_first_child(self, node, target_type: str,
                              name_filter: tuple[str, ...] | None = None) -> None:
        """Expand node and move cursor to first child matching type."""
        if not node.is_expanded:
            node.expand()
        tree = self.query_one("#session-tree", Tree)
        for child in node.children:
            if child.data and child.data.get("type") == target_type:
                if name_filter and child.data.get("name") not in name_filter:
                    continue
                tree.select_node(child)
                self._exit_col_focus()
                return
        self._flash_status(f"No {target_type} child found")

    def _resize_sessions_pane(self, width: int) -> None:
        """Resize the sessions pane to the given width (clamped to 15–80)."""
        width = max(15, min(width, 80))
        sessions = self.query_one("#sessions-pane", ListView)
        sessions.styles.width = width

    # ── Status bar: context display + dual-purpose flash ──────────────────

    # Node types that must SHORT-CIRCUIT — never walk up to steal a parent
    # turn's context. These represent placeholders / section headers where
    # "no data" is the honest answer.
    _SHORT_CIRCUIT_NODE_TYPES = {
        "teammates_section":     "teammates_section",
        "teammate_root":         "teammate_placeholder",
        "teammate_placeholder":  "teammate_placeholder",
        "subagent_placeholder":  "subagent_placeholder",
        "teammate_empty":        "teammate_empty",
        "label":                 "template",
        "separator":             "template",
        "warning":               "template",
        "info":                  "template",
    }

    def _detail_is_narrow(self) -> bool:
        """App total width < 80 cols → enter compact status-bar mode.

        The status bar spans the full app width (docked bottom), so we measure
        the app, not the detail pane. 80 cols is the same threshold used by
        tui-design.md to auto-hide the sessions pane.
        """
        try:
            return self.size.width < 80
        except Exception:
            return False

    def _resolve_context_for_node(
        self, node: TreeNode
    ) -> tuple[TurnContext | None, str]:
        """Walk from a highlighted tree node to its TurnContext (if any).

        Returns (TurnContext, reason) — `reason` is the no-data key used when
        the TurnContext is None.

        Short-circuit node types (placeholders, section headers) return
        (None, contextual-reason) IMMEDIATELY without walking up — otherwise
        we'd show the enclosing turn's context and mislead the user about
        the placeholder's state.
        """
        if node is not None and node.data:
            ntype = node.data.get("type")
            if ntype in self._SHORT_CIRCUIT_NODE_TYPES:
                return (None, self._SHORT_CIRCUIT_NODE_TYPES[ntype])

        walk = node
        while walk is not None:
            if walk.data:
                uuid = walk.data.get("uuid")
                if uuid and uuid in self._turn_context:
                    return (self._turn_context[uuid], "unknown")
            walk = walk.parent

        # Walked off the top — finalize reason
        if self.current_session is None:
            return (None, "unknown")
        if not self._turn_context:
            return (None, "older_session")
        return (None, "session_start")

    def _initialize_status_bar_for_session(self, session: Session) -> None:
        """Populate status bar on session load so it's useful immediately.

        Policy: show the first real assistant turn's context. Falls back to
        the session-start / older-session no-data message if the session has
        no usage data at all.
        """
        first_tc: TurnContext | None = None
        for evt in session.events:
            if evt.type == EventType.ASSISTANT and evt.uuid:
                tc = self._turn_context.get(evt.uuid)
                if tc is not None:
                    first_tc = tc
                    break
        narrow = self._detail_is_narrow()
        if first_tc is not None:
            self._context_lines = format_status_lines(first_tc, narrow=narrow)
        else:
            reason = "older_session" if not self._turn_context else "session_start"
            self._context_lines = format_status_lines(
                None, narrow=narrow, no_data_reason=reason,
            )
        self._write_status_bar()

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted) -> None:
        """Update status bar with the highlighted turn's context + agent info."""
        if event.control.id != "session-tree":
            return
        # Exit column focus if cursor moved to a different node
        if (self._col_focus_index is not None
                and id(event.node) != self._col_focus_node_id):
            self._exit_col_focus()
        tc, reason = self._resolve_context_for_node(event.node)
        narrow = self._detail_is_narrow()
        self._context_lines = format_status_lines(
            tc, narrow=narrow, no_data_reason=reason,
        )
        # Append agent/task drill-down line if available
        if event.node.data:
            uuid = event.node.data.get("uuid")
            if uuid and uuid in self._active_agents:
                agent_line = format_agents_status_line(self._active_agents[uuid])
                if agent_line:
                    self._context_lines.append(f"[dim]{agent_line}[/dim]")
        if not self._flash_active:
            self._write_status_bar()
        # Group highlight: paint continuation children when parent is selected
        self._apply_group_highlight(event.node)

    # ── Message-group highlight ──────────────────────────────────────────

    def _apply_group_highlight(self, node: TreeNode) -> None:
        """Highlight continuation children so the whole message looks selected."""
        self._clear_group_highlight()
        if not node.children:
            return
        try:
            tree = self.query_one("#session-tree", Tree)
            cursor_style = tree.get_component_rich_style("tree--cursor")
        except Exception:
            return
        from rich.style import Style
        bg = Style(bgcolor=cursor_style.bgcolor) if cursor_style.bgcolor else None
        if bg is None:
            return
        for child in node.children:
            if child.data and child.data.get("type") in _GROUP_HIGHLIGHT_TYPES:
                original = child.label.copy()
                self._group_highlight_children.append((child, original))
                new_label = child.label.copy()
                new_label.stylize(bg, 0, len(new_label))
                child.set_label(new_label)

    def _clear_group_highlight(self) -> None:
        """Restore original labels for previously highlighted continuation lines."""
        for child, original in self._group_highlight_children:
            try:
                child.set_label(original)
            except Exception:
                pass  # node may have been removed during tree rebuild
        self._group_highlight_children.clear()

    def _write_status_bar(self) -> None:
        """Paint the persistent context lines into the status bar."""
        try:
            status = self.query_one("#status-bar", Static)
        except Exception:
            return  # widget not mounted yet — ignore
        status.remove_class("flashing")
        status.update("\n".join(self._context_lines))

    def _flash_status(self, msg: str) -> None:
        """Temporarily show a flash message that fades over 2s, then restore.

        Distinct style (reverse-video dim cyan) + opacity transition via CSS
        class make clear the message is temporary and not part of the context
        readout.
        """
        try:
            status = self.query_one("#status-bar", Static)
        except Exception:
            return
        self._flash_active = True
        if self._flash_timer is not None:
            self._flash_timer.stop()
        status.update(f"[reverse][dim cyan]{_escape_markup(msg)}[/dim cyan][/reverse]")
        status.add_class("flashing")

        def _end_flash() -> None:
            self._flash_active = False
            self._write_status_bar()

        self._flash_timer = self.set_timer(2.0, _end_flash)
