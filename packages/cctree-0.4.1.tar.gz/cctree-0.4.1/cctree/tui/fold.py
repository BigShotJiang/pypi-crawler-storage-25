"""Fold-level helpers for tree expansion/collapse."""
from __future__ import annotations

from textual.widgets.tree import TreeNode


def set_fold_level(node: TreeNode, target_depth: int, current_depth: int = 0) -> None:
    """Recursively expand/collapse tree to target depth.

    Triggers lazy loads when expanding past placeholders (fold level 3).
    """
    if current_depth < target_depth:
        if not node.is_expanded and node.children:
            node.expand()  # triggers on_tree_node_expanded → lazy loads
        for child in list(node.children):
            set_fold_level(child, target_depth, current_depth + 1)
    else:
        if node.is_expanded:
            node.collapse()
