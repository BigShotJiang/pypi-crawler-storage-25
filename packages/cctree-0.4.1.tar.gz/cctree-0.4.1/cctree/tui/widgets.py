"""Standalone TUI widgets."""
from __future__ import annotations

from textual.events import MouseDown, MouseMove, MouseUp
from textual.widgets import Static


class DragHandle(Static):
    """Vertical drag handle for resizing the sessions/detail split."""

    DEFAULT_CSS = """
    DragHandle {
        width: 1;
        height: 100%;
        background: $primary-background;
    }
    DragHandle:hover {
        background: $accent;
    }
    """

    def __init__(self) -> None:
        super().__init__("┃", id="drag-handle")
        self._dragging = False

    def on_mouse_down(self, event: MouseDown) -> None:
        self._dragging = True
        self.capture_mouse()
        event.stop()

    def on_mouse_move(self, event: MouseMove) -> None:
        if self._dragging:
            self.app._resize_sessions_pane(event.screen_x)
            event.stop()

    def on_mouse_up(self, event: MouseUp) -> None:
        if self._dragging:
            self._dragging = False
            self.release_mouse()
            event.stop()
