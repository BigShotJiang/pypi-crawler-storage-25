"""cctree TUI — Textual-based session browser with tree-spine navigation."""
