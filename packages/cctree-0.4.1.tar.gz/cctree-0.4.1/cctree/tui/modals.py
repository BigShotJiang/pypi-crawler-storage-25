"""Modal screen widgets (search overlay, input prompt)."""
from __future__ import annotations

from rich.markup import escape as _escape_markup
from textual.app import ComposeResult
from textual.binding import Binding
from textual.events import Click
from textual.screen import ModalScreen
from textual.widgets import Input, Label, ListItem, ListView
from textual.containers import Vertical

from ..core.store import SessionStore
from .columns import _highlight_term


class SearchScreen(ModalScreen[str | None]):
    """Search overlay — type a query, see matching sessions + messages."""

    BINDINGS = [Binding("escape", "dismiss(None)", "Close")]

    def __init__(self, store: SessionStore) -> None:
        super().__init__()
        self.store = store
        self._search_timer = None
        self._last_query: str = ""

    def compose(self) -> ComposeResult:
        yield Vertical(
            Input(placeholder="Search sessions (text, slug, UUID)...", id="search-input"),
            ListView(id="search-results"),
            id="search-container",
        )

    def on_mount(self) -> None:
        self.query_one("#search-input", Input).focus()

    def on_click(self, event: Click) -> None:
        """Disable mouse click selection in search overlay."""
        event.prevent_default()
        event.stop()

    def on_key(self, event) -> None:
        """Down arrow from input → results. Up arrow from results → input."""
        search_input = self.query_one("#search-input", Input)
        results = self.query_one("#search-results", ListView)

        if event.key == "down" and search_input.has_focus:
            if len(results.children) > 0:
                results.focus()
                results.index = 0
                event.prevent_default()
        elif event.key == "up" and results.has_focus:
            if results.index == 0 or results.index is None:
                search_input.focus()
                event.prevent_default()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Debounce search — wait 300ms after last keystroke before searching."""
        if self._search_timer is not None:
            self._search_timer.stop()
        query = event.value.strip()
        if len(query) < 2:
            self.query_one("#search-results", ListView).clear()
            return
        self._search_timer = self.set_timer(0.3, lambda: self._do_search(query))

    def _build_matches(self, query: str) -> list[tuple[str, str, str]]:
        """Build the list of (label, session_uuid, msg_uuid) matches.

        Uniform format: ``[type] session — context`` with the matched term
        highlighted via Rich ``[reverse]`` markup.  Content excerpts use 60 chars
        of context on each side.
        """
        query_lower = query.lower()
        escaped_query = _escape_markup(query)
        matches: list[tuple[str, str, str]] = []

        for session in self.store.sessions.values():
            name = _escape_markup(session.display_name)

            if session.uuid.lower().startswith(query_lower):
                ctx = _highlight_term(_escape_markup(session.uuid[:12]), escaped_query, markup="reverse")
                matches.append((f"\\[uuid] {name} — {ctx}", session.uuid, ""))
                continue

            if session.slug and query_lower in session.slug.lower():
                ctx = _highlight_term(_escape_markup(session.slug), escaped_query, markup="reverse")
                matches.append((f"\\[slug] {name} — {ctx}", session.uuid, ""))
                continue

            if session.custom_title and query_lower in session.custom_title.lower():
                ctx = _highlight_term(_escape_markup(session.custom_title), escaped_query, markup="reverse")
                matches.append((f"\\[title] {name} — {ctx}", session.uuid, ""))
                continue

            for evt in session.events:
                if evt.is_message:
                    text = evt.text_content.lower()
                    idx = text.find(query_lower)
                    if idx >= 0:
                        start = max(0, idx - 60)
                        end = min(len(text), idx + len(query_lower) + 60)
                        excerpt = evt.text_content[start:end].replace("\n", " ")
                        safe_excerpt = _escape_markup(excerpt)
                        highlighted = _highlight_term(safe_excerpt, escaped_query, markup="reverse")
                        matches.append(
                            (f"\\[content] {name} — ...{highlighted}...", session.uuid, evt.uuid or ""),
                        )
                        break

            if len(matches) >= 50:
                break

        return matches

    def _do_search(self, query: str) -> None:
        """Execute the actual search — called after debounce delay."""
        self._last_query = query
        results = self.query_one("#search-results", ListView)
        results.clear()

        matches = self._build_matches(query)
        for label, s_uuid, m_uuid in matches:
            results.append(ListItem(Label(label, markup=True), name=f"{s_uuid}|{m_uuid}"))

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        name = event.item.name or ""
        # Append the search query as third field
        self.dismiss(f"{name}|{self._last_query}")


class InputModal(ModalScreen[str | None]):
    """Generic input modal — prompts for a string and returns it."""

    BINDINGS = [Binding("escape", "dismiss(None)", "Close")]

    def __init__(self, title: str, placeholder: str, default: str = "") -> None:
        super().__init__()
        self._title = title
        self._placeholder = placeholder
        self._default = default

    def compose(self) -> ComposeResult:
        yield Vertical(
            Label(self._title, id="input-modal-title"),
            Input(placeholder=self._placeholder, value=self._default, id="input-modal-field"),
            id="input-modal-container",
        )

    def on_mount(self) -> None:
        self.query_one("#input-modal-field", Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        value = event.value.strip()
        self.dismiss(value if value else None)
