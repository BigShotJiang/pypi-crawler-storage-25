# cctree TODOS

Generated from /plan-eng-review on 2026-04-13.

## Phase 2 — TUI + Metadata

### Migrate fork templates to SQLite
**What:** When meta.db ships, migrate templates from JSON sidecars
(`~/.cctree/templates/{dir}/{name}.json`) to a `templates` table in SQLite.
**Why:** Enables richer queries (all templates pointing at session X, cross-project
template search) and consolidates metadata storage into a single system.
**Effort:** S (human: ~1h / CC: ~10min)
**Priority:** P2 — only when meta.db ships.
**Depends on:** SQLite metadata DB (below).
**Migration path:** Read each JSON file, INSERT into `templates` table, keep JSON files
as read-only backup.

### SQLite metadata DB
**What:** `~/.cctree/meta.db` with tables for tags, stars, custom names (NOT written to JSONL),
last-viewed timestamps, and forge lineage mapping.
**Why:** TUI needs persistent metadata. Tags/stars/rename require storage outside Claude's files.
**Effort:** S (human: ~1h / CC: ~15min)
**Priority:** P1 for Phase 2 — build as first Phase 2 task.
**Depends on:** Phase 1 model types must be final.

### Configurable column visibility
**What:** Add config flags to permanently hide individual annotation columns
(`columns.tools=true`, `columns.agents=false`, `columns.context=true`).
**Why:** Power users may want to hide columns they don't care about, independent of
terminal width (which controls responsive hiding).
**Effort:** XS (human: ~30min / CC: ~5min)
**Priority:** P3 — polish after core column system is proven.
**Depends on:** Information density features.

### Fix literal `\n` in tool input/output display
**What:** Tool inputs (TaskCreate, etc.) are rendered via `json.dumps(block.input, indent=2)`
in `app.py` (~5 call sites: lines 1022, 1101, 1130, 1534, 1583). `json.dumps` escapes real
newlines in string values as literal `\n`, and the rendering pipeline (`_add_wrapped_content`
→ `_wrap_text`) never unescapes them — so long fields like task descriptions show ugly `\n`
instead of line breaks.
**Options:**
- **(A) Custom value-aware formatter** — Walk the dict; for string values containing `\n`,
  render as indented blocks (YAML `|`-style) instead of inline JSON. Short single-line
  values stay inline. Moderate effort, good readability.
- **(B) Per-field tree nodes** — Don't dump the entire input as one JSON blob. Render each
  key/value as its own tree node; long/multi-line values get an expandable sub-node with
  properly rendered text. Most polished UX, bigger change.
**Effort:** S–M depending on option
**Priority:** P2 — cosmetic but affects daily readability of task/tool output.

### Semantic leaf node grouping + cross-wrap-boundary highlighting
**What:** `_add_wrapped_content` splits a single message into individual selectable
leaf nodes (one per wrapped line). This breaks the semantic unit — you can't select
"the full assistant response" as one thing. Additionally, when a search term spans
a line-wrap boundary (e.g. "database migration" wraps between the two words), neither
line contains the full term, so it doesn't get highlighted.
**Why:** The leaf-per-line model was the simplest initial approach but creates two
problems: (1) cursor navigation moves line-by-line instead of message-by-message,
(2) search highlighting misses cross-wrap matches.
**Options:**
- **(A) Single rich-text node** — Render each message as a single tree node with
  multi-line Rich `Text`. Solves both problems. Requires Tree widget to support
  multi-line node labels or a custom widget.
- **(B) Post-process adjacent lines** — After wrapping, check if concatenating
  adjacent lines produces a search match. Highlight the term across both lines.
  Keeps the current leaf-per-line model but fixes highlighting only.
**Effort:** M (human: ~4h / CC: ~30min)
**Priority:** P2 — affects search UX and general navigation ergonomics.
**Depends on:** Search highlight feature (shipped).

## Phase 3 — Advanced Features

### Timeline swimlane view
**What:** Side panel showing agents as horizontal bars on a time axis (like a Gantt chart),
synchronized with the tree cursor. Uses the `build_active_agents_map()` data as foundation.
**Why:** Visualizes concurrent agent activity across the conversation timeline — when agents
overlapped, how long each ran, which turns had the most parallel activity.
**Effort:** L (human: ~1 week / CC: ~1-2h)
**Priority:** P3 — after Phase 2 TUI and information density features are stable.
**Depends on:** `active_agents.py` module (ships with information density features).

### Semantic search via embeddings
**What:** Embed all user + assistant message text, build a local vector index (ChromaDB or
similar), enable `cctree find --semantic "that conversation about karaoke quota"`.
**Why:** Keyword search covers ~70% of session-finding needs. Semantic search covers the rest —
especially for "I remember discussing X but don't remember the exact words."
**Effort:** L (human: ~2 days / CC: ~2-3h)
**Priority:** P2 — after Phase 2 ships and proves the TUI.
**Depends on:** Phase 1 parser + Phase 2 TUI.
**Open question:** Local embedding model (Sentence Transformers) vs API (Anthropic embeddings)?
Local = no network dependency, slower indexing. API = faster indexing, network dependency.

### Cross-project search index
**What:** Build an inverted index or SQLite FTS5 index for cross-project keyword search when
session count exceeds ~200.
**Why:** Linear scan across all `~/.claude/projects/*/` degrades past ~200 sessions; TUI
needs sub-second search to feel instant.
**Effort:** M (human: ~4h / CC: ~30min)
**Priority:** P2 — only if TUI search feels slow in practice.
**Depends on:** Phase 2 TUI.
**Trigger:** Profile cross-project search latency. If >1s at typical session count, build index.
