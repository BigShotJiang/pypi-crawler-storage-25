from setuptools import setup
setup(
    name="kruxos-sdk",
    version="0.0.1",
    description="Python SDK for KruxOS — coming soon",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://kruxos.com",
    author="samelldev",
    py_modules=["kruxos_sdk"],
)
