# adapter-engine-execution

对内使用的 **单据引擎执行适配层**：根据已构建的 `ExecutionPlan`，连接 EdgeDB、拉取 DeepModel 元数据，用 Polars 执行计划并返回行数据（可选返回列 schema）。

- **PyPI 包名**：`adapter-engine-execution`
- **导入包名**：`adapter_execution`
- **Python**：>= 3.11

## 安装

```bash
pip install adapter-engine-execution
```

本地安装：

```bash
pip install -e .
```

## 主要 API

从包入口可导入：

```python
from adapter_execution import execute_plan
```
