import enum
import functools
import inspect
from typing import (
    Dict, Any, Literal, Optional, List, Union, get_origin,
    TypeVar, Type, get_args, Callable,
    Container, Tuple
)

import orjson
from orjson import dumps as _orjson_dumps, loads as orjson_loads
from pydantic import (
    BaseModel as PydanticBaseModel, Field, validator,
    ValidationError, parse_obj_as
)
from pydantic.errors import MissingError, ListMinLengthError, AnyStrMinLengthError
# noinspection PyProtectedMember
from typing_extensions import Annotated

__all__ = [
    "BaseModel",
    "SubclassAwareModel",
    "DescribableEnum",
]

T = TypeVar('T')


def orjson_dumps(*args, **kwargs):
    return _orjson_dumps(
        *args, **kwargs,
        option=orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_NON_STR_KEYS
    ).decode()


def _scalar_to_tuple(v):
    if isinstance(v, BaseModel):
        return v.as_tuple()
    return v


class BaseModel(PydanticBaseModel):
    class Config:
        json_dumps = orjson_dumps
        json_loads = orjson_loads

    def __init__(__pydantic_self__, **data: Any) -> None:
        try:
            PydanticBaseModel.__init__(__pydantic_self__, **data)
        except ValidationError as e:
            e.__data__ = data
            raise

    def __getattr__(self, attr):
        if attr not in self.__fields__:
            raise AttributeError(attr)

        field = self.__fields__[attr]
        if (
            get_origin(field.type_)
            or not issubclass(field.type_, BaseModel)
        ):
            raise AttributeError(attr)

        val = field.type_.construct()
        object.__setattr__(self, attr, val)
        return val

    @classmethod
    def construct_from(
        cls,
        *models: "BaseModel",
        include_default: bool = False,
        **extra
    ):
        """
        基于PydanticBaseModel.contruct，删除不在_fields_set中的属性
        """
        target_fields = set(cls.__fields__.keys())
        attrs = {}

        for m in models:
            for k in target_fields.intersection(m.__fields__):
                attrs[k] = getattr(m, k)

        attrs.update({
            k: extra[k] for
            k in (target_fields & extra.keys())
        })

        return cls.construct(target_fields, **attrs)

    def as_tuple(self) -> Tuple[Tuple[str, Any], ...]:
        tup = []
        for k, val in self._iter(exclude_unset=True, exclude_defaults=True):
            if isinstance(val, list):
                v = [_scalar_to_tuple(el) for el in val]
            else:
                v = _scalar_to_tuple(val)
            tup.append((k, v))
        return tuple(tup)

    @staticmethod
    def required_on(*fields, condition: Callable[[Dict], bool]):
        def inner(cls, v, values):
            if v is None and condition(values):
                raise MissingError()
            return v

        inner.__qualname__ = str(id(inner))
        inner.__name__ = str(id(inner))
        return validator(*fields, pre=True, always=True, check_fields=False)(inner)

    @staticmethod
    def min_item_on(*fields, condition: Callable[[Dict], bool], min_item: int):
        def inner(cls, v, values):
            if condition(values) and isinstance(v, list) and len(v) < min_item:
                raise ListMinLengthError(limit_value=min_item)
            return v

        inner.__qualname__ = str(id(inner))
        inner.__name__ = str(id(inner))
        return validator(*fields, pre=True, always=True, check_fields=False)(inner)

    @staticmethod
    def min_length_on(*fields, condition: Callable[[Dict], bool], min_length: int):
        def inner(cls, v, values):
            if condition(values) and isinstance(v, str) and len(v) < min_length:
                raise AnyStrMinLengthError(limit_value=min_length)
            return v

        inner.__qualname__ = str(id(inner))
        inner.__name__ = str(id(inner))
        return validator(*fields, pre=True, always=True, check_fields=False)(inner)

    @staticmethod
    def set_default(field: str, sub_field: str, value: Any):
        def inner(cls, v):
            if isinstance(v, dict):
                v.setdefault(sub_field, value)
            elif isinstance(v, BaseModel):
                if sub_field in v.__fields__ and not hasattr(v, sub_field):
                    setattr(v, sub_field, value)
            return v

        inner.__qualname__ = str(id(inner))
        inner.__name__ = str(id(inner))
        return validator(field, pre=True)(inner)

    @staticmethod
    def as_model_on(*fields, condition: Callable[[Dict], bool], as_):
        def inner(cls, v, values):
            if condition(values):
                if v is None:
                    raise MissingError()
                return parse_obj_as(as_, v)
            return v

        inner.__qualname__ = str(id(inner))
        inner.__name__ = str(id(inner))
        return validator(*fields, pre=True, always=True)(inner)


class SubclassAwareModel(BaseModel):
    __subclasses_map__ = {}

    def __init_subclass__(
        cls,
        collect_subclass: bool = False,
        abstract: bool = False,
        ignores: Container[Type] = (),
        **kwargs
    ):
        if cls.__module__ == "pydantic.main":
            return super().__init_subclass__()

        if collect_subclass:
            SubclassAwareModel.__subclasses_map__[cls] = []
        elif not abstract:
            for base in cls.__mro__:
                if base in ignores:
                    continue
                if base in SubclassAwareModel.__subclasses_map__:
                    SubclassAwareModel.__subclasses_map__[base].append(cls)
        return super().__init_subclass__()

    @classmethod
    def get_subclasses(cls: T) -> List[T]:
        return SubclassAwareModel.__subclasses_map__.get(cls, [])

    @classmethod
    def get_subclasses_typehints(cls: T) -> T:
        return Union.__getitem__(tuple(cls.get_subclasses()))

    @classmethod
    def create_discriminated_union(cls: T, discriminator: str, description: str = None) -> T:
        return Annotated[
            cls.get_subclasses_typehints(),
            Field(discriminator=discriminator, description=description)
        ]

    @classmethod
    @functools.cache
    def get_field_literal(cls, field: str) -> str:
        ft_type = cls.__fields__[field].type_
        if not get_origin(ft_type) is Literal:
            raise ValueError(f'{field!r} field for {cls} must be annotated with Literal.')
        return get_args(ft_type)[0]

    @classmethod
    @functools.cache
    def get_field_description(cls, field: str) -> Optional[str]:
        return cls.__fields__[field].field_info.description


class DescribableEnum(str, enum.Enum):
    @classmethod
    def describe(cls) -> str:
        annotations = inspect.get_annotations(cls)
        descriptions = []
        for mbr in cls.__members__.values():
            if anno := annotations.get(mbr):
                if get_origin(anno) is Literal:
                    desc, *_ = get_args(anno)
                else:
                    desc = str(anno)
            else:
                desc = None

            if desc is None:
                descriptions.append(mbr.value)
            else:
                descriptions.append(f"{mbr.value}:{desc}")

        return "`" + " | ".join(descriptions) + "`"
