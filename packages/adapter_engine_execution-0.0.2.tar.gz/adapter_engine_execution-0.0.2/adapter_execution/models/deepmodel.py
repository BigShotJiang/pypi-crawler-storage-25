import enum
from typing import Optional, ForwardRef, Union, Annotated, List

from pydantic import Field

from adapter_execution.models.base import BaseModel, DescribableEnum


class DeepModelType(str, enum.Enum):
    str = "str"
    int = "int"
    bool = "bool"
    float = "float"
    decimal = "decimal"
    datetime = "datetime"
    datetime_tz = "datetime_tz"
    enum = "enum"
    json = "json"
    file = "file"
    uuid = "uuid"
    multilingual = "multilingual"

    def to_edb_type(self) -> str:
        return {
            'str': 'str',
            'int': 'int64',
            # 'bool': 'bool',
            'float': 'float64',
            # 'decimal': 'decimal',
            'datetime': 'cal::local_datetime',
            'datetime_tz': 'datetime',
            'enum': 'str',
            # 'json': 'json',
            'file': 'json',
            # 'uuid': 'uuid',
            'multilingual': 'json',
        }.get(self.value, self.value)


class ObjectTypeRef(BaseModel):
    name: str = Field(..., description="对象名", min_length=1)
    module: Optional[str] = Field(None, description="模块名，如果是当前模块传null")
    description: Optional[str] = Field(None, description="对象描述")

    @property
    def qualname(self):
        if self.module:
            if self.module.startswith("app"):
                module = self.module
            else:
                module = f"app{self.module}"
            return f'{module}::{self.name}'
        else:
            return self.name

    def __str__(self):
        return self.qualname


class CollectionType(DescribableEnum):
    ARRAY = "ARRAY"
    OPTIONAL = "OPTIONAL"


class CompoundType(BaseModel):
    container: CollectionType = Field(..., description="容器类型")
    item: ForwardRef("FieldValueType") = Field(..., description="成员类型")

    def __str__(self):
        return f"{self.container}[{self.item}]"


AnyFieldValueType = Union[DeepModelType, CompoundType, ObjectTypeRef]
FieldValueType = Annotated[AnyFieldValueType, Field(..., description="字段类型")]
CompoundType.update_forward_refs()


class ParamElement(BaseModel):
    # 规则参数类型为SEQUENCE时使用
    sequenceCode: Optional[str] = None
    # 规则参数类型为SEQUENCE时使用
    sequenceKeyType: Optional[str] = None
    # 规则参数类型为SEQUENCE时使用
    valueFormat: Optional[str] = None
    # 规则参数类型为SEQUENCE时使用
    sequenceId: Optional[str] = None
    # 规则参数类型为RANDOM_CHARACTER/SEQUENCE时使用
    length: Optional[int] = None
    # 规则参数类型为CURRENT_TIME时使用
    dateFormat: Optional[str] = None
    # 规则参数类型为OBJECT_PROPERTY时使用
    propertyLinkId: Optional[str] = None
    # 规则参数类型为OBJECT_PROPERTY时使用
    propertyLinkCode: Optional[str] = None
    sequenceKeys: Optional[List[str]] = None


class RuleParam(BaseModel):
    #: 规则名称
    code: str
    #: 规则参数编号
    id: Optional[str] = None
    #: 参数内容
    paramContent: Optional[ParamElement] = None
    #: 规则编号
    ruleId: Optional[str] = None
    #: 规则参数类型 [ "CURRENT_TIME", "OBJECT_PROPERTY", "RANDOM_CHARACTER", "SEQUENCE"]
    ruleParamType: str
    #: 排序
    sort: Optional[int] = None


class RuleInfoRes(BaseModel):
    #: 规则编号
    id: Optional[str] = None
    #: 规则所属对象id
    objectCode: str
    #: 赋值内容
    valueContent: Optional[str] = None
    #: 规则参数
    ruleParams: Optional[List[RuleParam]] = None


class SequenceInstance(BaseModel):
    #: 当前值
    currentValue: Optional[int] = None
    #: 序列编号
    sequenceId: Optional[str] = None
    #: 序列主键
    sequenceKey: Optional[str] = None
    #: 序列名称
    sequenceName: Optional[str] = None
