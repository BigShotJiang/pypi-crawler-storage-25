from typing import List

from pydantic import Field
from .base import BaseModel
from adapter_execution.execution.edb2polars import PolarsType


class FieldSchema(BaseModel):
    name: str = Field(..., description="字段名")
    type: str | List["FieldSchema"] = Field(..., description="字段类型")

    @classmethod
    def from_polars_type(cls, name: str, plt: PolarsType) -> "FieldSchema":
        if plt.inner is None:
            return cls(name=name, type=plt.clsname)

        if plt.inner.clsname == "List":
            return cls.from_polars_type(name, plt.inner.inner)

        if plt.inner.clsname == "Struct":
            assert isinstance(plt.inner.inner, dict)
            tp = []
            for fname, inner in plt.inner.inner.items():
                tp.append(cls.from_polars_type(fname, inner))

            return cls(name=name, type=tp)

        if isinstance(plt.inner, PolarsType):
            inner = cls.from_polars_type(name, plt.inner)
            return cls(name=name, type=f"{plt.clsname}[{inner.type}]")

        raise ValueError(f"cannot convert {plt} to FieldSchema")
