from typing import Dict, List, Any, Tuple

from .execution import (
    ExecutionPlan,
    DeepModelAPIProtocol,
    PolarsType,
    EdgeQLQuery
)
from .models import FieldSchema

__version__ = '0.0.2'
__version_tuple__ = (0, 0, 2)

DataPayload = List[Dict[str, Any]]


def execute_plan(
    exec_plan: ExecutionPlan,
    edgedb_dsn: str,
    edgedb_dbname: str,
    default_module: str,
    enable_lazy_frame: bool,
    header: Dict,
    deepmodel_api: DeepModelAPIProtocol,
    advance_sequence: bool = True,
    with_schema: bool = False,
    eql_result: Any = None,
    params: Dict[str, Any] = None,
    with_globals: Dict[str, Any] = None,
    without_globals: List[str] = None,
) -> Tuple[DataPayload, List[FieldSchema], Dict[str, Dict]] | DataPayload:
    from .execution import ExecutionContext
    exec_ctx = ExecutionContext(
        edgedb_dsn=edgedb_dsn,
        edgedb_dbname=edgedb_dbname,
        default_module=default_module,
        plans=exec_plan.extract_subplan(),
        enable_lazy_frame=enable_lazy_frame,
        eql_result=eql_result,
        headers=header,
        advance_sequence=advance_sequence,
        deepmodel_api=deepmodel_api,
        params=params,
        with_globals=with_globals,
        without_globals=without_globals,
    )

    df = exec_plan.execute(exec_ctx)
    if exec_ctx.enable_lazy_frame:
        df = df.collect()

    if not with_schema:
        return df.to_dicts()

    schema = {
        k: PolarsType.from_pltype(v)
        for k, v in df.schema.items()
    }
    human_readable_schema = [
        FieldSchema.from_polars_type(name, plt)
        for name, plt in schema.items()
    ]
    ser_schema = {
        k: v.dict(exclude_unset=True, exclude_defaults=True)
        for k, v in schema.items()
    }
    return df.to_dicts(), human_readable_schema, ser_schema

