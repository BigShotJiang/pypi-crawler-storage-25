import functools
from typing import Any, Type, Dict

import polars as pl

from adapter_execution.models.deepmodel import (
    DeepModelType, ObjectTypeRef, CompoundType, CollectionType
)

PolarsType = pl.DataType | Type[pl.DataType]
_ScalarToPolarsType = {
    DeepModelType.str: pl.Utf8,
    DeepModelType.int: pl.Int64,
    DeepModelType.bool: pl.Boolean,
    DeepModelType.float: pl.Float64,
    DeepModelType.decimal: pl.Float64,
    DeepModelType.datetime: pl.Datetime,
    DeepModelType.datetime_tz: pl.Datetime,
    DeepModelType.enum: pl.Utf8,
    DeepModelType.json: pl.Utf8,
    DeepModelType.file: pl.Utf8,
    DeepModelType.uuid: pl.Utf8,
    DeepModelType.multilingual: pl.Utf8,
}


@functools.singledispatch
def convert(tp: Any) -> PolarsType:
    raise NotImplementedError


@convert.register(ObjectTypeRef)
def convert_ObjectTypeRef(tp: ObjectTypeRef) -> PolarsType:
    return pl.Utf8


@convert.register(DeepModelType)
def convert_ScalarType(tp: DeepModelType) -> PolarsType:
    return _ScalarToPolarsType[tp]


@convert.register(CompoundType)
def convert_CompoundType(tp: CompoundType) -> PolarsType:
    if tp.container is CollectionType.OPTIONAL:
        return convert(tp.item)

    if tp.container is CollectionType.ARRAY:
        return pl.List(convert(tp.item))


@convert.register(dict)
def convert_dict(tp: Dict[str, Any]) -> PolarsType:
    if not tp:
        return pl.Null

    schema = {
        str(k): convert(v)
        for k, v in tp.items()
    }
    return pl.Struct(schema)
