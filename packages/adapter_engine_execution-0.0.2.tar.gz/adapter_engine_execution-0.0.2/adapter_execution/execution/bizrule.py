from __future__ import annotations

import abc
import calendar
import enum
import math
import random
import re
import string
from datetime import datetime
from typing import (
    Type, Union, Dict, List, Mapping, Pattern, Final, Match, Optional,
    ContextManager, TYPE_CHECKING, Any
)

import polars as pl

from adapter_execution.models.deepmodel import RuleParam, RuleInfoRes

if TYPE_CHECKING:
    from adapter_execution.execution.plan import DeepModelAPIProtocol

try:
    import tzlocal
except ImportError:
    tzlocal = None


StringChoices = string.ascii_letters + string.digits


def _ensure_tzinfo(dt: datetime) -> datetime:
    if dt.tzinfo is not None:
        return dt
    if tzlocal is None:
        raise RuntimeError("tzlocal is not installed")
    return dt.astimezone(tz=tzlocal.get_localzone())


class ArgType(str, enum.Enum):
    CurrentTime = "CURRENT_TIME"
    Property = "OBJECT_PROPERTY"
    Sequence = "SEQUENCE"
    RandomChars = "RANDOM_CHARACTER"

    @property
    def into_class(self) -> Type[Argument]:
        return {
            ArgType.Sequence: ModelSequence,
            ArgType.CurrentTime: CurrentTime,
            ArgType.Property: Property,
            ArgType.RandomChars: RandomChars
        }[self]


class IntoExpr(abc.ABC):
    @abc.abstractmethod
    def _into_expr(self) -> Union[pl.Expr, pl.Series]:
        return NotImplemented


class Argument(IntoExpr, abc.ABC):
    def __init__(
        self,
        obj: str,
        spec: RuleParam,
        data_len: int,
        aliases: Dict[str, str],
        **kwargs
    ):
        self._obj = obj
        self._spec = spec.paramContent
        self._id = spec.id
        self._materialized = False
        self._data_len = data_len
        self._aliases = aliases

    @property
    def materialized(self) -> bool:
        return self._materialized

    @property
    def spec_id(self) -> str:
        return self._id

    def materialize(self, data: pl.DataFrame) -> pl.DataFrame:
        self._materialized = True
        return data.with_columns(self._into_expr().alias(self._id))

    def into_expr(self) -> Union[pl.Expr, pl.Series]:
        if self._materialized:
            return pl.col(self._id)
        return self._into_expr()

    def on_enter(self):
        return self

    def on_exit(self, **kwargs):
        pass

    def on_error(self, **kwargs):
        pass


class DateTimeFormatter:
    _FORMAT_RE: Final[Pattern[str]] = re.compile(
        r"""(
            '(?:''|[^'])*'    # single quoted literal: 'word', 'o''clock'
            | G+              # Era designator: AD
            | y+              # Year: 1996; 96
            | Y+              # Week year: 2009; 09
            | M+              # Month in year (context sensitive): July; Jul; 07
            | L+              # Month in year (standalone form): July; Jul; 07
            | w+              # Week in year: 27
            | W+              # Week in month: 2
            | D+              # Day in year: 189
            | d+              # Day in month: 10
            | F+              # Day of week in month: 2
            | E+              # Day name in week: Tuesday; Tue
            | u+              # Day number of week (1 = Monday, ..., 7 = Sunday): 1
            | a+              # Am/pm marker: PM
            | H+              # Hour in day (0-23): 0
            | k+              # Hour in day (1-24): 24
            | K+              # Hour in am/pm (0-11): 0
            | h+              # Hour in am/pm (1-12): 12
            | m+              # Minute in hour: 30
            | s+              # Second in minute: 55
            | S+              # Millisecond: 978
            | z+              # General time zone: Pacific Standard Time; PST; GMT-08:00
            | Z+              # RFC 822 time zone: -0800
            | X+              # ISO 8601 time zone:  -08; -0800; -08:00
            | '               # single opened quote, this is an error
        )""", re.VERBOSE
    )
    _FORAMT_MAP = {
        "w": "%U",  # 年中第几周
        "D": "%j",  # 年中第几天
        "d": "%d",  # 日
        "u": "%u",  # ISO 星期几
        "a": "%p",  # AM/PM
        "H": "%H",  # 小时(0–23)
        "k": "%H",  # 小时(1–24)（近似）
        "K": "%I",  # 小时(0–11)
        "h": "%I",  # 小时(1–12)
        "m": "%M",  # 分钟
        "s": "%S",  # 秒
        "S": "%f",  # 毫秒/微秒（近似）
        "z": "%Z",  # 时区名
        "Z": "%z",  # 时区偏移
        "X": "%z",  # ISO 8601 偏移
    }


    @staticmethod
    def _format_token(dt: datetime, match: Match) -> str:
        token: str = match.group(0)

        if token == "'":
            raise ValueError(f"Unterminated quote at position {match.start()}")

        if token.startswith("'") and token.endswith("'"):
            token = token.replace("''", "'")
            if len(token) == 1:
                return token
            return token[1:-1]

        if (token_len := len(token)) == 1:
            def zfill(i: int) -> str:
                return str(i)
        else:
            def zfill(i: int) -> str:
                return ("{:0%d}" % token_len).format(i)

        if token.startswith('G'):
            return 'AD'

        if token.startswith('y'):
            if token_len == 2:
                return f"{dt.year}"[-2:]
            else:
                return zfill(dt.year)

        if token.startswith('Y'):
            if token_len == 2:
                return f"{dt.isocalendar().year}"[-2:]
            else:
                return zfill(dt.isocalendar().year)

        if token.startswith('M') or token.startswith('L'):
            if token_len >= 4:
                return calendar.month_name[dt.month]
            if token_len == 3:
                return calendar.month_abbr[dt.month]
            else:
                return zfill(dt.month)

        if token.startswith('w'):
            return zfill(dt.isocalendar().week)
        if token.startswith('W'):
            first_day = dt.replace(day=1)
            adjusted_dom = dt.day + first_day.weekday()
            return zfill(int(math.ceil(adjusted_dom / 7)))

        if token.startswith('D'):
            return zfill(dt.timetuple().tm_yday)
        if token.startswith('d'):
            return zfill(dt.day)

        if token.startswith('F'):
            return zfill(int(math.ceil(dt.day / 7)))
        if token.startswith('E'):
            if token_len >= 4:
                return calendar.day_name[dt.weekday()]
            else:
                return calendar.day_abbr[dt.weekday()]
        if token.startswith('u'):
            return zfill(dt.isoweekday())

        if token.startswith('a'):
            return 'AM' if dt.hour < 12 else 'PM'

        if token.startswith('H'):
            return zfill(dt.hour)
        if token.startswith('k'):
            return zfill(24 if dt.hour == 0 else dt.hour)
        if token.startswith('K'):
            return zfill(dt.hour if 0 <= dt.hour < 12 else abs(dt.hour - 12))
        if token.startswith('h'):
            return zfill(dt.hour if 0 < dt.hour < 13 else abs(dt.hour - 12))

        if token.startswith('m'):
            return zfill(dt.minute)

        if token.startswith('s'):
            return zfill(dt.second)

        if token.startswith("S"):
            if token_len < 6:
                return zfill(dt.microsecond // (10 ** (6 - token_len)))
            else:
                return zfill(dt.microsecond)

        if token.startswith('z'):
            return _ensure_tzinfo(dt).tzname()
        if token.startswith('Z') or token.startswith('X'):
            offset = int(_ensure_tzinfo(dt).utcoffset().total_seconds())
            hours, remain_seconds = divmod(offset, 3600)
            minutes = remain_seconds // 60
            sign = '-' if offset < 0 else '+'
            if token.startswith('Z'):
                return f"{sign}{hours:02}{minutes:02}"
            else:
                if token_len == 1:
                    return f"{sign}{hours:02}"
                elif token_len == 2:
                    return f"{sign}{hours:02}{minutes:02}"
                else:
                    return f"{sign}{hours:02}:{minutes:02}"

        raise ValueError(f"Unexpected token '{token}' at {match.span()}")

    @classmethod
    def format_datetime(cls, dt: datetime, formatter: str) -> str:
        return cls._FORMAT_RE.sub(
            lambda m: cls._format_token(dt, m),
            formatter
        )

    @classmethod
    def _replace_token(cls, match: Match) -> str:
        token: str = match.group(0)

        if token == "'":
            raise ValueError(f"Unterminated quote at position {match.start()}")

        if token.startswith("'") and token.endswith("'"):
            token = token.replace("''", "'")
            if len(token) == 1:
                return token
            return token[1:-1]

        token_len = len(token)

        if token.startswith('G'):
            return 'AD'

        if token.startswith('y'):
            if token_len == 2:
                return "%y"
            else:
                return "%Y"

        if token.startswith('Y'):
            if token_len == 2:
                return "%g"
            else:
                return "%G"

        if token.startswith('M') or token.startswith('L'):
            if token_len >= 4:
                return "%B"
            if token_len == 3:
                return "%b"
            else:
                return "%m"

        if token.startswith('E'):
            if token_len >= 4:
                return "%A"
            else:
                return "%a"

        if (
            len(token) > 1
            and (first_char := token[0]) in cls._FORAMT_MAP
        ):
            return cls._FORAMT_MAP[first_char]

        raise ValueError(f"Unexpected token '{token}' at {match.span()}")

    @classmethod
    def convert(cls, formatter: str) -> str:
        return cls._FORMAT_RE.sub(cls._replace_token, formatter)


class CurrentTime(Argument):
    def _into_expr(self) -> Union[pl.Expr, pl.Series]:
        current_time = DateTimeFormatter.format_datetime(
            datetime.now(),
            self._spec.dateFormat
        )
        return pl.lit(current_time)


class RandomChars(Argument):
    def _into_expr(self) -> Union[pl.Expr, pl.Series]:
        n = self._spec.length
        random_chars = lambda: ''.join(random.choices(StringChoices, k=n))
        return pl.Series(values=(random_chars() for _ in range(self._data_len)))


class Property(Argument):
    def _into_expr(self) -> Union[pl.Expr, pl.Series]:
        prop = self._spec.propertyLinkCode.split('-', 1)[0]
        col = pl.col(self._aliases.get(prop, prop))
        if formatter := self._spec.dateFormat:
            col = col.cast(pl.Datetime).dt.strftime(DateTimeFormatter.convert(formatter))
        return col


class ModelSequence(Argument):
    def __init__(
        self,
        *args,
        api,
        headers: Dict[str, str] = None,
        advance_sequence: bool = False,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self._currval = None
        self._seq_code = self._spec.sequenceCode
        self._seq_id = self._spec.sequenceId
        self._api = api
        self._headers = headers
        self._advance_sequence = advance_sequence
        self._seq_upd = []

    @property
    def referred_keys(self) -> List[str]:
        return self._spec.sequenceKeys or []

    def materialize(self, data: pl.DataFrame) -> pl.DataFrame:
        if (
            self._data_len == 0
            or not self.referred_keys
        ):
            return data

        self._materialized = True
        ref_cols = [
            pl.coalesce(pl.col(k), pl.lit("null"))
            for k in self.referred_keys
        ]
        col_seqkey = "~COL~SEQ~KEY~"
        col_currval = "~COL~CURRVAL~"
        template = "{}" * len(self.referred_keys)
        data = data.with_columns(
            pl.format(template, *ref_cols).alias(col_seqkey)
        )
        seq_keys = data.select(col_seqkey).unique()[col_seqkey].to_list()
        resp = self._api.seq.get_keys_curvalue(
            self._seq_code,
            seq_keys
        )
        if not resp:
            seqvals = pl.DataFrame(
                [],
                schema={col_currval: pl.Int64, "sequenceKey": pl.String}
            )
        else:
            seqvals = pl.DataFrame(resp).rename({"currentValue": col_currval})
        data = (
            data
            .join(seqvals, left_on=col_seqkey, right_on="sequenceKey", how="left")
            .with_columns(
                pl.coalesce(pl.col(col_currval), 0).alias(col_currval),
            )
        )
        expr = pl.col(col_currval) + pl.int_range(1, pl.len() + 1).over(col_seqkey)

        self._seq_upd = (
            data
            .group_by(pl.col(col_seqkey).alias("sequenceKey"))
            .agg((pl.len() + pl.col(col_currval).first()).alias("currentValue"))
            .to_dicts()
        )
        return (
            data
            .with_columns(self._maybe_zfill(expr).alias(self._id))
            .drop(col_seqkey, col_currval)
        )

    def _maybe_zfill(self, expr: Union[pl.Expr, pl.Series]) -> Union[pl.Expr, pl.Series]:
        if self._spec.valueFormat == 'FIX':
            return expr.cast(str).str.zfill(self._spec.length)
        return expr

    def _into_expr(self) -> Union[pl.Expr, pl.Series]:
        seq_key = f"{self._obj}_default"
        seq = self._api.seq.list(self._seq_id, seq_key)
        if seq:
            currval = seq[0].currentValue
        else:
            currval = self._api.seq.next_value(self._seq_code, seq_key) - 1

        self._seq_upd.append({
            "sequenceKey": seq_key,
            "currentValue": currval + self._data_len,
        })
        expr = pl.arange(currval + 1, currval + self._data_len + 1)
        return self._maybe_zfill(expr)

    def on_exit(self, **kwargs):
        if self._advance_sequence and self._seq_upd:
            self._api.seq.batch_update_seqval(
                self._seq_code,
                self._seq_upd
            )


class DictMimic(Mapping):
    def __init__(self):
        self.fields: List[str] = []

    def __getitem__(self, item: str):
        self.fields.append(item)
        return '{}'

    def __iter__(self):
        return iter(self.fields)

    def __len__(self):
        return len(self.fields)


class ArgumentStack(ContextManager):
    def __init__(
        self,
        data: pl.DataFrame,
        template: str,
        colname: str,
        args: List[Argument],
    ):
        self.__data = data
        self._template = template
        self._colname = colname
        self._args = args
        self._aux_data = {}

    def set_aux_data(self, key: str, value: Any):
        self._aux_data[key] = value

    @property
    def data(self) -> pl.DataFrame:
        return self.__data

    def __enter__(self) -> ArgumentStack:
        exprs = [
            pl.coalesce(cm.on_enter().into_expr(), pl.lit("null"))
            for cm in self._args
        ]
        self.__data = self.__data.with_columns(
            pl.format(self._template, *exprs).alias(self._colname))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> Optional[bool]:
        if exc_type is not None:
            for cm in self._args:
                cm.on_error(**self._aux_data)
            return False

        for cm in self._args:
            cm.on_exit(**self._aux_data)


class ColumnGenerator:
    def __init__(self, rule: RuleInfoRes, aliases: Dict[str, str]):
        dm = DictMimic()
        self._template = string.Template(rule.valueContent).substitute(dm)
        self._fields = dm.fields
        self._arg_specs = rule.ruleParams or []
        self._obj = rule.objectCode
        self._aliases = aliases

    def attach(
        self,
        data: pl.DataFrame,
        colname: str,
        headers: Dict[str, str],
        advance_sequence: bool,
        deepmodel_api: DeepModelAPIProtocol
    ) -> pl.DataFrame:
        args: List[Argument | None] = [None] * len(self._fields)
        id_to_arg = {}
        seqs: List[ModelSequence] = []

        for spec in self._arg_specs:
            arg = ArgType(spec.ruleParamType).into_class(
                self._obj, spec, len(data), self._aliases,
                api=deepmodel_api,
                headers=headers,
                advance_sequence=advance_sequence,
            )
            id_to_arg[arg.spec_id] = arg

            if isinstance(arg, ModelSequence):
                seqs.append(arg)

            try:
                idx = self._fields.index(spec.code)
                args[idx] = arg
            except ValueError:
                continue

        visited = set()
        for arg_seq in seqs:
            for key in arg_seq.referred_keys:
                if key in visited:
                    continue
                data = id_to_arg[key].materialize(data)
                visited.add(key)

        for arg_seq in seqs:
            data = arg_seq.materialize(data)

        with ArgumentStack(data, self._template, colname, args) as cm:
            data = cm.data

        drops = []
        for spec_id, arg in id_to_arg.items():
            if arg.materialized:
                drops.append(spec_id)

        if drops:
            data = data.drop(drops)

        return data

