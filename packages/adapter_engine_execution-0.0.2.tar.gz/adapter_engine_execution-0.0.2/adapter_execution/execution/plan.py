from __future__ import annotations

import abc
import dataclasses
import itertools
import uuid
from typing import (
    Any, Dict, List, Optional, Self, Literal, Type, TypeVar, Protocol,
)

import edgedb
import orjson
import polars as pl
import polars.selectors as cs
from polars.datatypes import classes, DataTypeClass
from polars._typing import PolarsDataType  # noqa
from pydantic import Field, validator, PrivateAttr, parse_raw_as, BaseModel

from .eql import AnyExpr, AutoClassNameModel
from .bizrule import ColumnGenerator
from ..lib import serutils
from ..models.base import SubclassAwareModel
from ..models.deepmodel import RuleInfoRes, SequenceInstance

T = TypeVar("T")
AuxColumn = '~aux!l1ary~'


class PolarsType(BaseModel):
    clsname: str
    inner: Optional["PolarsType" | Dict[str, "PolarsType"]] = None

    @classmethod
    def from_pltype(cls: Type[Self], tp: PolarsDataType) -> Self:
        if not tp.is_nested():
            if tp.__class__ is DataTypeClass:
                clsname = str(tp)
            else:
                clsname = str(tp.__class__)
            return PolarsType(clsname=clsname)
        clsname = str(tp.__class__)

        if isinstance(tp, pl.List):
            inner = PolarsType.from_pltype(tp.inner)
        elif isinstance(tp, pl.Struct):
            inner = {
                field.name: PolarsType.from_pltype(field.dtype)
                for field in tp.fields
            }
        else:
            raise NotImplementedError(f"Type {type(tp)} not supported")
        return PolarsType(clsname=clsname, inner=inner)

    def to_pltype(self) -> PolarsDataType:
        cls = getattr(classes, self.clsname)
        if self.inner is None:
            return cls
        elif isinstance(self.inner, PolarsType):
            return cls(self.inner.to_pltype())
        elif isinstance(self.inner, dict):
            schema = {
                k: v.to_pltype()
                for k, v in self.inner.items()
            }
            return cls(schema)
        raise NotImplementedError(f"Type {self.inner} not supported")


class SeqAPIProtocol(Protocol):
    def edit(
        self,
        current_value: int = None,
        seq_id: str = None,
        seq_key: str = None,
        seq_name: str = None,
    ) -> None: ...

    def next_value(self, code: str = None, seq_key: str = None) -> int: ...

    def list(
        self,
        id: str = None, filter_value: str = None
    ) -> List[SequenceInstance]: ...

    def get_keys_curvalue(self, seq_code: str, key_list: List[str]) -> Any: ...

    def batch_update_seqval(self, seq_code: str, inst_list: List[dict]) -> Any: ...


class DeepModelAPIProtocol(Protocol):
    """供依赖注入与类型标注使用的 DeepModel 组件接口协议。"""

    @property
    def seq(self) -> SeqAPIProtocol: ...


@dataclasses.dataclass
class ExecutionContext:
    edgedb_dsn: str
    edgedb_dbname: str
    deepmodel_api: DeepModelAPIProtocol
    default_module: str = None
    respect_cache: bool = True
    enable_lazy_frame: bool = True
    plans: Dict[str, ExecutionPlan] = dataclasses.field(default_factory=dict)
    headers: Dict[str, str] = dataclasses.field(default_factory=dict)
    advance_sequence: bool = False
    eql_result: Any = None
    params: Dict[str, Any] = None
    with_globals: Dict[str, Any] = None
    without_globals: List[str] = None

    def get_plan_or_die(self, key: str) -> ExecutionPlan:
        try:
            return self.plans[key]
        except KeyError:
            raise KeyError(f'No execution plan named "{key}"') from None


class SerializableModel(
    SubclassAwareModel,
    metaclass=AutoClassNameModel,
):
    class Config:
        arbitrary_types_allowed = True
        json_encoders = {
            pl.Expr: lambda obj: obj.meta.serialize(format="json")
        }


class AbstractExecutionPlan(
    SerializableModel,
    abstract=True,
    collect_subclass=True,
):
    id: Optional[str] = None
    _result_cache: Optional[pl.LazyFrame] = PrivateAttr(default=None)
    _optimized: bool = PrivateAttr(default=False)

    def as_subplan(self: Self, ident: str) -> Self:
        if self.id is None:
            self.id = ident
        elif self.id != ident:
            raise ValueError(f'Cannot change id {self.id} to {ident}')
        return self

    def execute(self, ctx: ExecutionContext) -> pl.LazyFrame:
        if ctx.respect_cache and self._result_cache is not None:
            return self._result_cache

        data = self._execute(ctx)
        if self.id is not None:
            if isinstance(data, pl.LazyFrame):
                data = data.collect().lazy()
            self._result_cache = data
        return data

    @abc.abstractmethod
    def _execute(self, ctx: ExecutionContext) -> pl.LazyFrame:
        raise NotImplementedError

    def optimize(self: Self) -> Self:
        fields = {}
        optimizable = False
        for field, value in self._iter():
            if (
                isinstance(value, AbstractExecutionPlan)
                and value._result_cache is None
                and not value._optimized
            ):
                optimizable = True
                value = value.optimize()
            elif isinstance(value, list):
                new_values = []
                for sub_value in value:
                    if (
                        isinstance(sub_value, AbstractExecutionPlan)
                        and sub_value._result_cache is None
                        and not sub_value._optimized
                    ):
                        optimizable = True
                        new_values.append(sub_value.optimize())
                value = new_values

            fields[field] = value
        if optimizable:
            new_plan = self.__class__(**fields)
        else:
            new_plan = self
        new_plan._optimized = True
        return new_plan

    def transform(self, transformer: Transformer) -> Transform:
        return Transform(
            source=self,
            transformer=transformer,
        )

    def attach_const(self, column: str, value: Any) -> Transform:
        return self.transform(AttachConst(column=column, value=value))

    def attach_column(self, column: str, expr: pl.Expr) -> Transform:
        return self.transform(AttachColumn(column=column, expr=expr))

    def extract_subplan(self) -> Dict[str, ExecutionPlan]:
        subplans = {}
        if self.id is not None:
            subplans[self.id] = self

        for field, value in self._iter():
            if isinstance(value, AbstractExecutionPlan):
                subplans.update(value.extract_subplan())
            elif isinstance(value, list):
                for sub_v in value:
                    if isinstance(sub_v, AbstractExecutionPlan):
                        subplans.update(sub_v.extract_subplan())
        return subplans

    def create_reference(self) -> Reference:
        if self.id is None:
            raise ValueError(f"{self} is not a subplan. call .as_subplan first.")
        return Reference(plan_id=self.id)

    def find_plan_of_type(self, tp: Type[T]) -> Optional[T]:
        for field, value in self._iter():
            if isinstance(value, AbstractExecutionPlan):
                if isinstance(value, tp):
                    return value
                elif plan := value.find_plan_of_type(tp):
                    return plan
            elif isinstance(value, list):
                for sub_v in value:
                    if isinstance(sub_v, AbstractExecutionPlan):
                        if isinstance(sub_v, tp):
                            return sub_v
                        if plan := sub_v.find_plan_of_type(tp):
                            return plan
        return None


class EdgeQLQuery(AbstractExecutionPlan):
    query: AnyExpr
    arguments: Dict[str, str] = Field(default_factory=dict)
    pl_schema: Optional[Dict[str, PolarsType]] = Field(None)

    def _execute(self, ctx: ExecutionContext) -> pl.LazyFrame:
        if ctx.eql_result is None:
            ql = self.query.dump_edgeql()
            with edgedb.create_client(
                dsn=ctx.edgedb_dsn,
                database=ctx.edgedb_dbname,
                tls_security='insecure'
            ) as cli:
                cli = cli.with_default_module(ctx.default_module)
                if ctx.with_globals:
                    cli = cli.with_globals(**ctx.with_globals)
                if ctx.without_globals:
                    cli = cli.without_globals(*ctx.without_globals)
                objs = cli.query(ql, **self.arguments, **(ctx.params or {}))
                result = serutils.serialize(
                    objs,
                    ctx=serutils.Context(query_df=True, uuid_as_str=True)
                )
        else:
            result = ctx.eql_result

        if self.pl_schema is not None:
            schema = {
                name: tp.to_pltype()
                for name, tp in self.pl_schema.items()
            }
        else:
            schema = None

        if not result:
            data = pl.DataFrame(schema=schema)
        else:
            # N.B. strict=False 是为了处理polars初始化List[Struct]类型时的缺陷带入的。
            # schema = {'col': pl.List(pl.Struct({'a': pl.Float64}))}
            # pl.DataFrame([{'col': [{'a': 12.0}, {'a': 2}]}], schema=schema)
            # 以上两行代码会抛出异常
            # TypeError: unexpected value while building Series of type Float64;
            # found value of type Int64: 2
            # 即便指定schema，但是polars无法成功cast，只能指定strict=False以避免报错。
            # 根据文档 strict=False 会带来一个副作用，对于无法进行类型cast的值，会被替换为
            # null，考虑到这里的值其实是由edgeql查询出的，含有严格的类型一致性，
            # 这个副作用可以忽略，使用 strict=False 应当是安全的
            data = pl.DataFrame(result, strict=False).cast(schema)
        if ctx.enable_lazy_frame:
            return data.lazy()
        else:
            # for debug
            return data # noqa


class AbstractTransformer(
    SerializableModel,
    abstract=True,
    collect_subclass=True,
):
    @abc.abstractmethod
    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        raise NotImplementedError


class AttachConst(AbstractTransformer):
    column: str
    value: Any

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        return data.with_columns(pl.lit(self.value).alias(self.column))


class WithRowIndex(AbstractTransformer):
    column: str
    offset: int = 0

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        return data.with_row_index(name=self.column, offset=self.offset)


class Rename(AbstractTransformer):
    mapping: Dict[str, str]

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        return data.rename(lambda c: self.mapping.get(c, c))


class WithCumCount(AbstractTransformer):
    over: str
    alias: str
    offset: int = 0

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        return data.with_columns(
            pl.cum_count(self.over).over(self.over).alias(self.alias),
        )


class ConcatUnnest(AbstractTransformer):
    columns: List[str]
    keeps: List[str]

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        alias = str(uuid.uuid4())
        return (
            data.select(
                *self.keeps,
                pl.concat_list(self.columns).alias(alias)
            )
            .explode(alias)
            .unnest(alias)
        )


class AttachColumn(AbstractTransformer):
    column: str
    expr: pl.Expr

    @validator('expr', pre=True)
    def validate_expr(cls, v):
        if isinstance(v, str):
            return pl.Expr.deserialize(v.encode(), format="json")
        return v

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        return data.with_columns(self.expr.alias(self.column))


class PolarsExpr(BaseModel):
    def to_expr(self, ctx: ExecutionContext) -> pl.Expr:
        raise NotImplementedError


class ApplyBusinessRule(AbstractTransformer):
    column: str
    rule: RuleInfoRes
    aliases: Dict[str, str]

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        if ctx.enable_lazy_frame:
            data = data.collect()

        data = ColumnGenerator(self.rule, self.aliases).attach(
            data, self.column, ctx.headers, ctx.advance_sequence, ctx.deepmodel_api
        )
        return data.lazy()


class ReStruct(AbstractTransformer):
    exclude: List[str]
    alias: str

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        return data.select(
            *self.exclude,
            pl.struct(cs.exclude(self.exclude)).alias(self.alias)
        )


class ArrayAgg(AbstractTransformer):
    group_by: str
    sorted: bool = False

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        if self.sorted:
            by = pl.col(self.group_by).set_sorted()
        else:
            by = self.group_by
        return data.group_by(by).agg(cs.exclude(self.group_by))


class Drop(AbstractTransformer):
    columns: List[str]

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        return data.drop(self.columns)


class Sort(AbstractTransformer):
    columns: List[str]

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        return data.sort(*self.columns)


class UnnestStruct(AbstractTransformer):
    column: str
    keeps: List[str]

    def __call__(self, data: pl.LazyFrame, ctx: ExecutionContext) -> pl.LazyFrame:
        data = data.select(self.column, *self.keeps)
        coltype = data.collect_schema()[self.column]
        if not coltype.is_nested():
            return data.drop(self.column)
        elif isinstance(coltype, pl.List):
            data = data.explode(self.column)
        return data.unnest(self.column)


Transformer = AbstractTransformer.create_discriminated_union("cls")


class Transform(AbstractExecutionPlan):
    source: ExecutionPlan
    transformer: Transformer

    def _execute(self, ctx: ExecutionContext) -> pl.LazyFrame:
        data = self.source.execute(ctx)
        return self.transformer(data, ctx)

    def optimize(self: Self) -> Self:
        source = self.source
        transformers = [self.transformer]
        while isinstance(source, self.__class__):
            transformers.append(source.transformer)
            source = source.source

        plan = Pipeline(
            source=source.optimize(),
            transformers=list(reversed(transformers)),
        )
        plan._optimized = True
        return plan


class Pipeline(AbstractExecutionPlan):
    source: ExecutionPlan
    transformers: List[Transformer]

    def _execute(self, ctx: ExecutionContext) -> pl.LazyFrame:
        data = self.source.execute(ctx)
        for trans in self.transformers:
            data = trans(data, ctx)
        return data


class Reference(AbstractExecutionPlan):
    plan_id: str

    def _execute(self, ctx: ExecutionContext) -> pl.LazyFrame:
        return ctx.get_plan_or_die(self.plan_id).execute(ctx)


class Concat(AbstractExecutionPlan):
    plans: List[ExecutionPlan]
    how: Literal['horizontal', 'vertical'] = 'horizontal'

    def _execute(self, ctx: ExecutionContext) -> pl.LazyFrame:
        dfs = [plan.execute(ctx) for plan in self.plans]
        if len(dfs) == 1:
            return dfs[0]
        if self.how == 'horizontal':
            return pl.concat(dfs, how=self.how)

        align_cols = dfs[0].collect_schema().names()
        return pl.concat(
            itertools.chain(dfs[:1], [s.select(align_cols) for s in dfs[1:]]),
            how=self.how
        )


ExecutionPlan = AbstractExecutionPlan.create_discriminated_union("cls")
for _cls in AbstractExecutionPlan.get_subclasses():
    _cls.update_forward_refs()
del _cls


def deserialize(ser: str):
    return parse_raw_as(ExecutionPlan, ser)
