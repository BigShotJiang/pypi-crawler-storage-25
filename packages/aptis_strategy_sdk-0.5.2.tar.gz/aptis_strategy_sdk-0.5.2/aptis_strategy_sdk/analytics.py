"""
Strategy analytics helpers — pure computation, no HTTP.

All functions accept the typed models returned by AptisClient and return
plain dicts or floats so results are easy to log, serialise, or feed into
a dashboard.

Usage:
    from aptis_strategy_sdk.analytics import StrategyAnalytics

    analytics = StrategyAnalytics(client, account="Theme",
                                  strategy_name="CITADEL Strategy")
    diag = analytics.diagnostics(start_date, end_date)
    print(diag.win_rate, diag.fill_rate, diag.total_pnl)

Author: Richard Chung
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import List, Optional, Dict, Any, TYPE_CHECKING

from aptis_strategy_sdk.models import (
    TradeFill, Position, ExecutionReport, SignalResult, StrategyDiagnostics,
)

if TYPE_CHECKING:
    from aptis_strategy_sdk.client import AptisClient


class StrategyAnalytics:
    """Analytics facade for a single strategy.

    Fetches data via AptisClient and computes all metrics locally so the
    backend needs no changes.  Swap in a live-broker client later without
    touching this class.
    """

    def __init__(self, client: "AptisClient", account: str, strategy_name: str):
        self.client = client
        self.account = account
        self.strategy_name = strategy_name

    # ── High-level entry point ─────────────────────────────────────────────────

    def diagnostics(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> StrategyDiagnostics:
        """Compute a full diagnostics snapshot for the strategy.

        Fetches fills, positions, and PnL in parallel-ish calls then
        delegates to the pure helper functions below.

        Returns:
            StrategyDiagnostics with all metrics populated.
        """
        _start = start_date or (date.today() - timedelta(days=30))
        _end   = end_date   or date.today()

        fills     = self.client.get_trade_fills(
            self.account, self.strategy_name, _start, _end)
        positions = self.client.get_positions(self.account, self.strategy_name)
        pnl_summary = self.client.get_pnl(
            self.account, _start, _end, self.strategy_name)

        exposure = exposure_summary(positions)

        return StrategyDiagnostics(
            strategy=self.strategy_name,
            account=self.account,
            period_start=_start.isoformat(),
            period_end=_end.isoformat(),
            fill_rate=fill_rate(fills),
            avg_slippage_bps=average_slippage_bps(fills),
            total_realized_pnl=float(pnl_summary.get("total_realized_pnl", 0)),
            total_unrealized_pnl=sum(p.unrealized_pnl for p in positions),
            total_pnl=(
                float(pnl_summary.get("total_realized_pnl", 0))
                + sum(p.unrealized_pnl for p in positions)
            ),
            win_rate=win_rate(fills),
            signal_hit_rate=signal_hit_rate(fills),
            long_exposure_usd=exposure["long_usd"],
            short_exposure_usd=exposure["short_usd"],
            gross_exposure_usd=exposure["gross_usd"],
            net_exposure_usd=exposure["net_usd"],
            position_count=len(positions),
            fills=fills,
            positions=positions,
        )

    # ── Convenience wrappers ───────────────────────────────────────────────────

    def fill_rate(self, start_date: Optional[date] = None,
                  end_date: Optional[date] = None) -> float:
        """Fraction of submitted signals that resulted in a fill. 0–1."""
        fills = self.client.get_trade_fills(
            self.account, self.strategy_name, start_date, end_date)
        return fill_rate(fills)

    def average_slippage_bps(self, start_date: Optional[date] = None,
                             end_date: Optional[date] = None) -> Optional[float]:
        """Mean slippage in basis points across all fills. None if unavailable."""
        fills = self.client.get_trade_fills(
            self.account, self.strategy_name, start_date, end_date)
        return average_slippage_bps(fills)

    def win_rate(self, start_date: Optional[date] = None,
                 end_date: Optional[date] = None) -> Optional[float]:
        """Fraction of closed trades with realized_pnl > 0. None if no closed trades."""
        fills = self.client.get_trade_fills(
            self.account, self.strategy_name, start_date, end_date)
        return win_rate(fills)

    def signal_hit_rate(self, start_date: Optional[date] = None,
                        end_date: Optional[date] = None) -> Optional[float]:
        """Fraction of ENTRY fills that closed with positive P&L."""
        fills = self.client.get_trade_fills(
            self.account, self.strategy_name, start_date, end_date)
        return signal_hit_rate(fills)

    def realized_vs_unrealized(self) -> Dict[str, float]:
        """Return realized and unrealized P&L for the strategy."""
        positions = self.client.get_positions(self.account, self.strategy_name)
        pnl = self.client.get_pnl(
            self.account,
            date.today() - timedelta(days=365),
            date.today(),
            self.strategy_name,
        )
        realized   = float(pnl.get("total_realized_pnl", 0))
        unrealized = sum(p.unrealized_pnl for p in positions)
        return {
            "realized_pnl":   round(realized, 4),
            "unrealized_pnl": round(unrealized, 4),
            "total_pnl":      round(realized + unrealized, 4),
        }

    def exposure(self) -> Dict[str, float]:
        """Return current long/short/gross/net exposure in USD."""
        positions = self.client.get_positions(self.account, self.strategy_name)
        return exposure_summary(positions)


# ── Pure analytics functions ───────────────────────────────────────────────────
# These accept plain lists and return scalars / dicts.
# They can be used independently of StrategyAnalytics.

def fill_rate(fills: List[TradeFill]) -> float:
    """Fraction of fills with a filled status (APPROVED / SUBMITTED / CLOSED).

    Returns 0.0 when fills is empty.
    """
    if not fills:
        return 0.0
    _FILLED = {"APPROVED", "SUBMITTED", "CLOSED"}
    filled = sum(1 for f in fills if f.status.upper() in _FILLED)
    return round(filled / len(fills), 4)


def average_slippage_bps(fills: List[TradeFill]) -> Optional[float]:
    """Mean slippage in basis points across fills that have slippage data.

    Returns None when no fill has slippage_bps populated (e.g. paper trading
    without an arrival price).
    """
    values = [f.slippage_bps for f in fills if f.slippage_bps is not None]
    if not values:
        return None
    return round(sum(values) / len(values), 2)


def win_rate(fills: List[TradeFill]) -> Optional[float]:
    """Fraction of closed trades (direction=EXIT or status=CLOSED) with pnl > 0.

    Returns None when there are no closed trades with P&L data.
    """
    closed = [
        f for f in fills
        if f.realized_pnl is not None
        and (f.direction.upper() == "EXIT" or f.status.upper() == "CLOSED")
    ]
    if not closed:
        return None
    winners = sum(1 for f in closed if f.realized_pnl > 0)
    return round(winners / len(closed), 4)


def signal_hit_rate(fills: List[TradeFill]) -> Optional[float]:
    """Fraction of ENTRY fills that eventually closed with positive P&L.

    A signal "hits" when the corresponding ENTRY trade has a positive
    realized_pnl (set when the position is closed via an EXIT trade).

    Returns None when there are no ENTRY fills with P&L data.
    """
    entries = [
        f for f in fills
        if f.direction.upper() == "ENTRY" and f.realized_pnl is not None
    ]
    if not entries:
        return None
    hits = sum(1 for f in entries if f.realized_pnl > 0)
    return round(hits / len(entries), 4)


def realized_vs_unrealized_pnl(
    fills: List[TradeFill],
    positions: List[Position],
) -> Dict[str, float]:
    """Compute realized and unrealized P&L from fills and open positions.

    Args:
        fills:     Trade fills (used for realized P&L).
        positions: Open positions (used for unrealized P&L).

    Returns:
        Dict with keys: realized_pnl, unrealized_pnl, total_pnl.
    """
    realized   = sum(f.realized_pnl for f in fills if f.realized_pnl is not None)
    unrealized = sum(p.unrealized_pnl for p in positions)
    return {
        "realized_pnl":   round(realized, 4),
        "unrealized_pnl": round(unrealized, 4),
        "total_pnl":      round(realized + unrealized, 4),
    }


def exposure_summary(positions: List[Position]) -> Dict[str, float]:
    """Compute long/short/gross/net exposure in USD from open positions.

    Exposure = abs(quantity) * current_price per position.
    Long positions (quantity > 0) contribute to long_usd.
    Short positions (quantity < 0) contribute to short_usd.

    Returns:
        Dict with keys: long_usd, short_usd, gross_usd, net_usd,
                        position_count, long_count, short_count.
    """
    long_usd  = 0.0
    short_usd = 0.0
    long_count  = 0
    short_count = 0

    for p in positions:
        notional = abs(p.quantity) * p.current_price
        if p.quantity > 0:
            long_usd  += notional
            long_count += 1
        elif p.quantity < 0:
            short_usd  += notional
            short_count += 1

    return {
        "long_usd":       round(long_usd, 2),
        "short_usd":      round(short_usd, 2),
        "gross_usd":      round(long_usd + short_usd, 2),
        "net_usd":        round(long_usd - short_usd, 2),
        "position_count": len(positions),
        "long_count":     long_count,
        "short_count":    short_count,
    }


def summarise_signal_results(results: List[SignalResult]) -> Dict[str, Any]:
    """Aggregate a list of SignalResults into a dashboard-ready summary dict.

    Returns:
        Dict with keys: total, accepted, rejected, pending, skipped,
                        fill_rate, win_rate, avg_realized_pnl.
    """
    from aptis_strategy_sdk.models import SignalStatus
    total    = len(results)
    accepted = sum(1 for r in results if r.status == SignalStatus.ACCEPTED)
    rejected = sum(1 for r in results if r.status == SignalStatus.REJECTED)
    pending  = sum(1 for r in results if r.status == SignalStatus.PENDING)
    skipped  = sum(1 for r in results if r.status == SignalStatus.SKIPPED)

    pnl_values = [r.realized_pnl for r in results if r.realized_pnl is not None]
    winners    = [p for p in pnl_values if p > 0]

    return {
        "total":            total,
        "accepted":         accepted,
        "rejected":         rejected,
        "pending":          pending,
        "skipped":          skipped,
        "fill_rate":        round(accepted / total, 4) if total else 0.0,
        "win_rate":         round(len(winners) / len(pnl_values), 4) if pnl_values else None,
        "avg_realized_pnl": round(sum(pnl_values) / len(pnl_values), 4) if pnl_values else None,
    }
