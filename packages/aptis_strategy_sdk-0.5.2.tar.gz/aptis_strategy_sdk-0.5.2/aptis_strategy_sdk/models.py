"""Data models for Aptis SDK"""
from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any, List
from datetime import datetime
from enum import Enum
import os

from aptis_strategy_sdk.exceptions import ConfigurationError, ValidationError


class Urgency(str, Enum):
    LOW = "LOW"
    NORMAL = "NORMAL"
    HIGH = "HIGH"


class ExecutionStyle(str, Enum):
    MANUAL = "MANUAL"
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    VWAP = "VWAP"
    TWAP = "TWAP"
    POV = "POV"


@dataclass
class RegimeMetadata:
    """Market regime context for analytics and AI explanations."""
    label: str                              # e.g. "BULL", "BEAR", "STRESS", "CHOP"
    confidence: Optional[float] = None      # 0–1
    indicators: Optional[Dict[str, Any]] = None  # e.g. {"adx": 28.4, "vix": 18.2}

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class FactorScoreMetadata:
    """Factor scores driving the signal — for dashboard attribution."""
    momentum: Optional[float] = None
    value: Optional[float] = None
    quality: Optional[float] = None
    volatility: Optional[float] = None
    sentiment: Optional[float] = None
    extra: Optional[Dict[str, float]] = None  # any additional factors

    def to_dict(self) -> Dict[str, Any]:
        d = {k: v for k, v in asdict(self).items() if v is not None and k != "extra"}
        if self.extra:
            d.update(self.extra)
        return d


@dataclass
class RiskSnapshotMetadata:
    """Risk metrics at signal time — for risk dashboard and AI context."""
    portfolio_var_1d: Optional[float] = None   # 1-day VaR (fraction of NAV)
    position_var_1d: Optional[float] = None
    max_drawdown: Optional[float] = None
    sharpe_trailing: Optional[float] = None
    beta: Optional[float] = None
    volatility_30d: Optional[float] = None
    extra: Optional[Dict[str, float]] = None

    def to_dict(self) -> Dict[str, Any]:
        d = {k: v for k, v in asdict(self).items() if v is not None and k != "extra"}
        if self.extra:
            d.update(self.extra)
        return d


@dataclass
class Signal:
    """
    Trading signal — used for both execution and analytics.

    Required fields are unchanged for backward compatibility.
    All institutional fields are optional and omitted from the payload when unset.
    """
    # ── Core (required, unchanged) ────────────────────────────────────────────
    symbol: str
    asset_class: str
    quantity: float
    side: str                               # BUY | SELL
    signal_type: str                        # ENTRY | EXIT | ADJUST

    # ── Existing optional (unchanged) ────────────────────────────────────────
    order_parameters: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None

    # ── Institutional execution fields ────────────────────────────────────────
    notional_usd: Optional[float] = None
    portfolio_weight: Optional[float] = None    # fraction of NAV, e.g. 0.05
    confidence: Optional[float] = None          # 0–1
    urgency: Optional[Urgency] = None
    time_in_force: Optional[str] = None         # DAY | GTC | IOC | FOK
    max_slippage_bps: Optional[float] = None    # basis points
    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    execution_style: Optional[ExecutionStyle] = None
    broker_route: Optional[str] = None
    reduce_only: Optional[bool] = None
    tags: Optional[List[str]] = None

    def __post_init__(self):
        if self.quantity <= 0:
            raise ValidationError(
                f"Signal.quantity must be > 0, got {self.quantity}. "
                "Use abs(position.quantity) when sizing exits."
            )
        if self.confidence is not None and not (0.0 <= self.confidence <= 1.0):
            raise ValidationError(
                f"Signal.confidence must be in [0, 1], got {self.confidence}."
            )
        if self.max_slippage_bps is not None and self.max_slippage_bps < 0:
            raise ValidationError(
                f"Signal.max_slippage_bps must be >= 0, got {self.max_slippage_bps}."
            )
        if self.side not in ("BUY", "SELL"):
            raise ValidationError(
                f"Signal.side must be 'BUY' or 'SELL', got {self.side!r}."
            )
        if self.signal_type not in ("ENTRY", "EXIT", "ADJUST"):
            raise ValidationError(
                f"Signal.signal_type must be 'ENTRY', 'EXIT', or 'ADJUST', got {self.signal_type!r}."
            )

    def to_dict(self) -> Dict[str, Any]:
        """Return JSON-safe dict, omitting all unset optional fields."""
        d: Dict[str, Any] = {
            "symbol": self.symbol,
            "asset_class": self.asset_class,
            "quantity": self.quantity,
            "side": self.side,
            "signal_type": self.signal_type,
        }
        optional_fields = [
            "order_parameters", "metadata",
            "notional_usd", "portfolio_weight", "confidence",
            "time_in_force", "max_slippage_bps", "limit_price", "stop_price",
            "broker_route", "reduce_only", "tags",
        ]
        for f in optional_fields:
            v = getattr(self, f)
            if v is not None:
                d[f] = v
        if self.urgency is not None:
            d["urgency"] = self.urgency.value
        if self.execution_style is not None:
            d["execution_style"] = self.execution_style.value
        return d


@dataclass
class AptisConfig:
    """SDK configuration — validated at construction time.

    Prefer AptisConfig.from_env() over constructing directly.
    """
    api_key: str
    base_url: str = "http://localhost:8082"
    account: Optional[str] = None
    timeout: int = 30           # seconds per request
    max_retries: int = 3        # attempts for 429 / 5xx / connection errors
    backoff_factor: float = 0.5 # seconds; actual wait = backoff_factor * 2^(attempt-1)

    def __post_init__(self):
        if not self.api_key or not self.api_key.strip():
            raise ConfigurationError(
                "APTIS_API_KEY is missing or empty. "
                "Set it via the APTIS_API_KEY environment variable or pass api_key= directly."
            )
        self.base_url = self.base_url.rstrip("/")
        if not self.base_url.startswith(("http://", "https://")):
            raise ConfigurationError(
                f"APTIS_API_URL must start with http:// or https://, got {self.base_url!r}."
            )
        if self.timeout <= 0:
            raise ConfigurationError(f"timeout must be > 0, got {self.timeout}.")
        if self.max_retries < 0:
            raise ConfigurationError(f"max_retries must be >= 0, got {self.max_retries}.")
        if self.backoff_factor < 0:
            raise ConfigurationError(f"backoff_factor must be >= 0, got {self.backoff_factor}.")

    @classmethod
    def from_env(cls) -> "AptisConfig":
        """Build config from environment variables.

        Required:
            APTIS_API_KEY   — API key
        Optional:
            APTIS_API_URL   — backend URL (default: http://localhost:8082)
            APTIS_ACCOUNT   — account name (default: None)
            APTIS_TIMEOUT   — request timeout in seconds (default: 30)
            APTIS_MAX_RETRIES — retry attempts (default: 3)
        """
        api_key = os.getenv("APTIS_API_KEY", "").strip()
        if not api_key:
            raise ConfigurationError(
                "APTIS_API_KEY environment variable is not set. "
                "Export it before running your strategy: export APTIS_API_KEY=your_key"
            )
        return cls(
            api_key=api_key,
            base_url=os.getenv("APTIS_API_URL", "http://localhost:8082"),
            account=os.getenv("APTIS_ACCOUNT") or None,
            timeout=int(os.getenv("APTIS_TIMEOUT", "30")),
            max_retries=int(os.getenv("APTIS_MAX_RETRIES", "3")),
        )


@dataclass
class Position:
    """Current position"""
    symbol: str
    asset_class: str
    quantity: float
    avg_entry_price: float
    current_price: float
    unrealized_pnl: float
    realized_pnl: float


@dataclass
class Bar:
    """OHLCV bar"""
    symbol: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass
class Quote:
    """Market quote"""
    symbol: str
    timestamp: datetime
    bid: float
    ask: float
    last: float
    volume: float


# ── Execution feedback models ──────────────────────────────────────────────────

class SignalStatus(str, Enum):
    ACCEPTED  = "ACCEPTED"   # signal received and a trade record created
    REJECTED  = "REJECTED"   # signal rejected by backend validation or risk
    PENDING   = "PENDING"    # signal received, trade not yet processed
    SKIPPED   = "SKIPPED"    # duplicate or disabled — silently ignored
    ERROR     = "ERROR"      # unexpected backend error


@dataclass
class TradeFill:
    """A single executed (or paper-executed) trade fill.

    Maps to one row in trade_strategy_trade with direction=ENTRY or EXIT.
    For paper trading, entry_price is the last market price at signal time.
    For live trading, entry_price is the actual fill price from the broker.
    """
    trade_id: int
    symbol: str
    strategy: str
    account: str
    side: str                           # BUY | SELL
    direction: str                      # ENTRY | EXIT | ADJUSTMENT
    quantity: float
    fill_price: float                   # entry_price from trade record
    status: str                         # maps to trade_strategy_trade.status
    trade_date: str                     # ISO date string
    realized_pnl: Optional[float] = None
    exit_price: Optional[float] = None
    commission: Optional[float] = None
    fees: Optional[float] = None
    slippage_bps: Optional[float] = None        # computed: (fill - arrival) / arrival * 10000
    execution_latency_ms: Optional[float] = None  # ms from signal to fill
    rejection_reason: Optional[str] = None     # populated when status=REJECTED
    signal_confidence: Optional[float] = None  # from signal metadata if stored

    @classmethod
    def from_trade_row(cls, row: Dict[str, Any]) -> "TradeFill":
        """Construct from a trade dict returned by GET /api/v1/strategy/trades."""
        return cls(
            trade_id=row.get("id", 0),
            symbol=row.get("symbol", ""),
            strategy=row.get("strategy", ""),
            account=row.get("account", ""),
            side=row.get("side", ""),
            direction=row.get("direction", "ENTRY"),
            quantity=float(row.get("quantity", 0)),
            fill_price=float(row.get("entry_price", 0)),
            status=row.get("status", "UNKNOWN"),
            trade_date=row.get("created", "")[:10] if row.get("created") else "",
            realized_pnl=float(row["realized_pnl"]) if row.get("realized_pnl") is not None else None,
            exit_price=float(row["exit_price"]) if row.get("exit_price") is not None else None,
            commission=float(row["commission"]) if row.get("commission") is not None else None,
            fees=float(row["fees"]) if row.get("fees") is not None else None,
            rejection_reason=row.get("error") or None,
        )


@dataclass
class ExecutionReport:
    """Aggregated execution quality summary for a strategy over a date range.

    Designed to be broker-agnostic: works for paper trading today and
    live broker fills tomorrow without changing the interface.
    """
    strategy: str
    account: str
    period_start: str
    period_end: str
    total_signals: int              # signals submitted in the period
    total_fills: int                # trades with status APPROVED/SUBMITTED/CLOSED
    total_rejections: int           # trades with status REJECTED/ERROR
    fill_rate: float                # total_fills / total_signals, 0–1
    avg_slippage_bps: Optional[float] = None    # mean slippage across fills
    avg_execution_latency_ms: Optional[float] = None
    total_commission: Optional[float] = None
    total_fees: Optional[float] = None
    fills: Optional[List["TradeFill"]] = None   # individual fills if requested


@dataclass
class SignalResult:
    """Outcome of a single submitted signal — links signal intent to trade result.

    Populated from trade_strategy_trade rows matched by strategy + ticker + date.
    """
    symbol: str
    strategy: str
    signal_date: str
    side: str
    signal_type: str                # ENTRY | EXIT | ADJUST
    requested_quantity: float
    status: SignalStatus
    fill: Optional[TradeFill] = None        # None if rejected or pending
    rejection_reason: Optional[str] = None
    realized_pnl: Optional[float] = None   # available after position is closed
    signal_confidence: Optional[float] = None


@dataclass
class StrategyDiagnostics:
    """Full analytics snapshot for a strategy — powers the feedback loop.

    Computed by StrategyAnalytics.diagnostics() from fills + positions + pnl.
    """
    strategy: str
    account: str
    period_start: str
    period_end: str
    # Execution quality
    fill_rate: float                # fraction of signals that filled
    avg_slippage_bps: Optional[float]
    # P&L
    total_realized_pnl: float
    total_unrealized_pnl: float
    total_pnl: float
    # Signal quality
    win_rate: Optional[float]       # fraction of closed trades with pnl > 0
    signal_hit_rate: Optional[float]  # fraction of ENTRY signals that became profitable
    # Risk / exposure
    long_exposure_usd: float
    short_exposure_usd: float
    gross_exposure_usd: float
    net_exposure_usd: float
    position_count: int
    # Raw data for further analysis
    fills: List[TradeFill]
    positions: List[Position]
