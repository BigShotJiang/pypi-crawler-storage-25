"""Base strategy class"""
import logging
import json
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from datetime import date

from aptis_strategy_sdk.client import AptisClient
from aptis_strategy_sdk.models import Signal
from aptis_strategy_sdk.exceptions import ValidationError


class Strategy(ABC):
    """Base class for plugin trading strategies.

    Subclass this and implement generate_signals(run_date).

    Lifecycle (called by run()):
        before_run  → generate_signals → submit_signals → after_run
                                                ↓ (on any exception)
                                            on_error

    Dry-run mode (dry_run=True):
        Signals are validated and logged but never submitted to the API.
        Safe to use in CI, backtests, and staging environments.

    Enabled guard:
        run() fetches strategy config from the platform and skips execution
        when enabled=False, so operators can disable a strategy without
        redeploying code.

    Backward compatibility:
        All existing constructor signatures and method calls continue to work
        unchanged.  New parameters are keyword-only with safe defaults.
    """

    def __init__(self, name: str, client: AptisClient, account: str,
                 dry_run: bool = False):
        self.name = name
        self.client = client
        self.account = account
        self.dry_run = dry_run
        self.logger = logging.getLogger(f"aptis.strategy.{name}")
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(
                "%(asctime)s [%(levelname)s] %(name)s — %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            ))
            self.logger.addHandler(handler)
        if not self.logger.level:
            self.logger.setLevel(logging.INFO)

    # ── Abstract ───────────────────────────────────────────────────────────────

    @abstractmethod
    def generate_signals(self, run_date: date) -> List[Signal]:
        """Generate trading signals for run_date.

        Override this method with your strategy logic.

        Returns:
            List of Signal objects to execute (or validate in dry-run mode).
        """

    # ── Lifecycle hooks (override as needed) ──────────────────────────────────

    def before_run(self, run_date: date) -> None:
        """Called at the start of run(), before generate_signals.

        Use for pre-flight checks, data validation, or warming caches.
        Default implementation does nothing.
        """

    def after_run(self, run_date: date, results: Dict[str, Any]) -> None:
        """Called at the end of run() after all signals are submitted.

        Args:
            run_date: The date passed to run().
            results:  The dict returned by run() — includes signals_generated,
                      submitted, skipped, and results.
        Default implementation does nothing.
        """

    def on_error(self, run_date: date, exc: Exception) -> None:
        """Called when an unhandled exception occurs inside run().

        The exception is re-raised after this hook returns, so the caller
        still sees it.  Override to add alerting, metrics, or cleanup.

        Default implementation logs the error at ERROR level.
        """
        self.logger.error("Unhandled error on %s: %s", run_date, exc, exc_info=True)

    # ── Main entry point ───────────────────────────────────────────────────────

    def run(self, run_date: date) -> Dict[str, Any]:
        """Run the strategy for run_date.

        Steps:
          1. before_run hook
          2. Check is_enabled() — skip if disabled
          3. generate_signals
          4. Validate each signal
          5. submit_signals (skipped in dry-run mode)
          6. after_run hook

        Returns a result dict with keys:
            date, strategy, dry_run, enabled,
            signals_generated, submitted, skipped, results
        """
        result: Dict[str, Any] = {
            "date": run_date.isoformat(),
            "strategy": self.name,
            "dry_run": self.dry_run,
            "enabled": True,
            "signals_generated": 0,
            "submitted": 0,
            "skipped": 0,
            "results": [],
        }

        try:
            self.before_run(run_date)

            if not self.is_enabled():
                self.logger.info(
                    "Strategy '%s' is disabled — skipping run for %s.",
                    self.name, run_date,
                )
                result["enabled"] = False
                return result

            if self.dry_run:
                self.logger.info(
                    "DRY-RUN: strategy '%s' for %s — signals will not be submitted.",
                    self.name, run_date,
                )

            signals = self.generate_signals(run_date)
            result["signals_generated"] = len(signals)

            submitted, skipped, responses = self.submit_signals(signals)
            result["submitted"] = submitted
            result["skipped"] = skipped
            result["results"] = responses

        except Exception as exc:
            self.on_error(run_date, exc)
            raise

        self.after_run(run_date, result)
        return result

    # ── Helper methods ─────────────────────────────────────────────────────────

    def get_config(self) -> Dict[str, Any]:
        """Fetch this strategy's config from the platform (NAV, funds, enabled, etc.)."""
        return self.client.get_config(self.name)

    def is_enabled(self) -> bool:
        """Return True if the strategy is enabled in the platform config.

        Falls back to True on any API error so a transient failure does not
        silently suppress trading.
        """
        try:
            return bool(self.get_config().get("enabled", True))
        except Exception as exc:
            self.logger.warning(
                "Could not fetch config for '%s' (will proceed): %s", self.name, exc
            )
            return True

    def get_account(self) -> str:
        """Return the account this strategy is trading under."""
        return self.account

    def submit_signals(self, signals: List[Signal]) -> tuple:
        """Validate and submit a list of signals.

        In dry-run mode signals are validated and logged but not submitted.

        Returns:
            (submitted_count, skipped_count, responses)
            where responses is a list of API response dicts (empty in dry-run).

        Raises:
            ValidationError for the first invalid signal encountered.
        """
        submitted = 0
        skipped = 0
        responses: List[Dict[str, Any]] = []

        for signal in signals:
            try:
                _validate_signal(signal)
            except ValidationError as exc:
                self.logger.error(
                    "Signal validation failed — skipping %s %s %s: %s",
                    signal.side, signal.quantity, signal.symbol, exc,
                )
                skipped += 1
                continue

            if self.dry_run:
                self.logger.info(
                    "DRY-RUN signal: %s",
                    json.dumps(signal.to_dict(), default=str),
                )
                skipped += 1
                continue

            response = self.client.submit_signal(signal, self.name, self.account)
            responses.append(response)
            submitted += 1
            self.logger.debug(
                "Submitted %s %s %s → %s",
                signal.side, signal.quantity, signal.symbol,
                response.get("status", "?"),
            )

        if signals:
            self.logger.info(
                "%s | %s: %d signal(s) — %d submitted, %d skipped%s.",
                run_date_label(), self.name, len(signals), submitted, skipped,
                " [DRY-RUN]" if self.dry_run else "",
            )

        return submitted, skipped, responses

    # ── Existing helpers (unchanged) ───────────────────────────────────────────

    def get_features(self, symbols: List[str], run_date: date,
                     features: List[str]) -> Dict[str, Dict[str, float]]:
        """Get Dagster-calculated features."""
        return self.client.get_features(symbols, run_date, features)

    def get_positions(self) -> List:
        """Get current positions for this strategy."""
        return self.client.get_positions(self.account, self.name)

    def get_pnl(self, start_date: date, end_date: date) -> Dict[str, Any]:
        """Get P&L for this strategy."""
        return self.client.get_pnl(self.account, start_date, end_date, self.name)


# ── Internal helpers ───────────────────────────────────────────────────────────

def _validate_signal(signal: Signal) -> None:
    """Re-run Signal field checks at submission time.

    Signal.__post_init__ already validates on construction, but signals can be
    mutated after creation, so we check again before submitting.
    """
    if not signal.symbol or not signal.symbol.strip():
        raise ValidationError("Signal.symbol is empty.")
    if not signal.asset_class or not signal.asset_class.strip():
        raise ValidationError("Signal.asset_class is empty.")
    if signal.quantity <= 0:
        raise ValidationError(
            f"Signal.quantity must be > 0, got {signal.quantity}. "
            "Use abs(position.quantity) when sizing exits."
        )
    if signal.side not in ("BUY", "SELL"):
        raise ValidationError(
            f"Signal.side must be 'BUY' or 'SELL', got {signal.side!r}."
        )
    if signal.signal_type not in ("ENTRY", "EXIT", "ADJUST"):
        raise ValidationError(
            f"Signal.signal_type must be 'ENTRY', 'EXIT', or 'ADJUST', "
            f"got {signal.signal_type!r}."
        )
    if signal.confidence is not None and not (0.0 <= signal.confidence <= 1.0):
        raise ValidationError(
            f"Signal.confidence must be in [0, 1], got {signal.confidence}."
        )
    if signal.max_slippage_bps is not None and signal.max_slippage_bps < 0:
        raise ValidationError(
            f"Signal.max_slippage_bps must be >= 0, got {signal.max_slippage_bps}."
        )


def run_date_label() -> str:
    """Return today's date as a compact label for log lines."""
    return date.today().isoformat()
