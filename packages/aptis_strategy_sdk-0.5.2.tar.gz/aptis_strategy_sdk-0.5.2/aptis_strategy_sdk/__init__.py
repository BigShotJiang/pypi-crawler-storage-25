"""
Aptis Strategy SDK - Build trading strategies on Aptis platform

Author: Richard Chung
"""
from aptis_strategy_sdk.client import AptisClient
from aptis_strategy_sdk.strategy import Strategy
from aptis_strategy_sdk.models import (
    Signal, Position, Bar, Quote,
    AptisConfig,
    Urgency, ExecutionStyle,
    RegimeMetadata, FactorScoreMetadata, RiskSnapshotMetadata,
    # Execution feedback
    SignalStatus,
    TradeFill,
    ExecutionReport,
    SignalResult,
    StrategyDiagnostics,
)
from aptis_strategy_sdk.analytics import (
    StrategyAnalytics,
    fill_rate,
    average_slippage_bps,
    win_rate,
    signal_hit_rate,
    realized_vs_unrealized_pnl,
    exposure_summary,
    summarise_signal_results,
)
from aptis_strategy_sdk.exceptions import (
    AptisError, AptisAPIError,
    AuthenticationError, ConfigurationError,
    ValidationError, APIError,
    RateLimitError, ServerError,
)

__version__ = "0.5.0"

__all__ = [
    # Client & config
    "AptisClient",
    "AptisConfig",
    # Strategy base
    "Strategy",
    # Core models
    "Signal",
    "Position",
    "Bar",
    "Quote",
    # Signal enums
    "Urgency",
    "ExecutionStyle",
    # Metadata helpers
    "RegimeMetadata",
    "FactorScoreMetadata",
    "RiskSnapshotMetadata",
    # Execution feedback models
    "SignalStatus",
    "TradeFill",
    "ExecutionReport",
    "SignalResult",
    "StrategyDiagnostics",
    # Analytics
    "StrategyAnalytics",
    "fill_rate",
    "average_slippage_bps",
    "win_rate",
    "signal_hit_rate",
    "realized_vs_unrealized_pnl",
    "exposure_summary",
    "summarise_signal_results",
    # Exceptions
    "AptisError",
    "AptisAPIError",
    "AuthenticationError",
    "ConfigurationError",
    "ValidationError",
    "APIError",
    "RateLimitError",
    "ServerError",
]
