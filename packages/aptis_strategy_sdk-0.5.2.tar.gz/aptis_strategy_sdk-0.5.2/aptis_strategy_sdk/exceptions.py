"""SDK exceptions"""


class AptisError(Exception):
    """Base exception for all Aptis SDK errors."""


# ── Backward-compatible alias ──────────────────────────────────────────────────
AptisAPIError = AptisError


class AuthenticationError(AptisError):
    """API key missing, invalid, or not authorised for the requested account.

    Fix: check APTIS_API_KEY and APTIS_ACCOUNT environment variables.
    """


class ConfigurationError(AptisError):
    """SDK or environment misconfiguration.

    Fix: ensure APTIS_API_KEY, APTIS_API_URL, and APTIS_ACCOUNT are set.
    """


class ValidationError(AptisError):
    """Signal or request payload failed validation.

    The error message describes the exact field and constraint violated.
    """


class APIError(AptisError):
    """Non-retryable HTTP error returned by the Aptis backend (4xx except 401/429).

    Attributes:
        status_code: HTTP status code.
        response_body: Raw response text for debugging.
    """

    def __init__(self, message: str, status_code: int = 0, response_body: str = ""):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class RateLimitError(AptisError):
    """HTTP 429 — rate limit exceeded.  Request was retried up to the configured limit."""


class ServerError(AptisError):
    """HTTP 5xx — backend error that persisted after all retries.

    Attributes:
        status_code: HTTP status code.
    """

    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code
