"""Aptis API client"""
import time
import random
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from typing import List, Dict, Any, Optional
from datetime import date

from aptis_strategy_sdk.models import (
    Signal, Position, Bar, Quote, AptisConfig,
    TradeFill, ExecutionReport, SignalResult, SignalStatus,
)
from aptis_strategy_sdk.exceptions import (
    AptisAPIError, AuthenticationError, ConfigurationError,
    ValidationError, APIError, RateLimitError, ServerError,
)

# Status codes that warrant a retry
_RETRY_STATUSES = frozenset({429, 500, 502, 503, 504})


def _build_session(config: AptisConfig) -> requests.Session:
    """Attach a retry-capable HTTPAdapter to a new session."""
    retry = Retry(
        total=config.max_retries,
        backoff_factor=config.backoff_factor,
        status_forcelist=_RETRY_STATUSES,
        allowed_methods={"GET", "POST", "PATCH", "DELETE"},
        raise_on_status=False,  # we handle status ourselves
    )
    adapter = HTTPAdapter(max_retries=retry)
    session = requests.Session()
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update({"Authorization": f"Bearer {config.api_key}"})
    return session


class AptisClient:
    """Client for the Aptis platform API.

    Preferred construction:
        client = AptisClient.from_env()

    Direct construction (backward compatible):
        client = AptisClient(api_key="...", base_url="http://...")
    """

    def __init__(self, api_key: str = "", base_url: str = "http://localhost:8082",
                 timeout: int = 30, max_retries: int = 3, backoff_factor: float = 0.5,
                 _config: Optional[AptisConfig] = None):
        if _config is not None:
            self._config = _config
        else:
            # Validate via AptisConfig so errors are consistent
            self._config = AptisConfig(
                api_key=api_key,
                base_url=base_url,
                timeout=timeout,
                max_retries=max_retries,
                backoff_factor=backoff_factor,
            )
        self.api_key = self._config.api_key          # backward compat attribute
        self.base_url = self._config.base_url        # backward compat attribute
        self.session = _build_session(self._config)
        self._config_cache: Dict[str, Any] = {}

    @classmethod
    def from_env(cls) -> "AptisClient":
        """Create a client from environment variables.

        Reads: APTIS_API_KEY, APTIS_API_URL, APTIS_ACCOUNT,
               APTIS_TIMEOUT, APTIS_MAX_RETRIES

        Raises ConfigurationError if APTIS_API_KEY is missing.
        """
        config = AptisConfig.from_env()
        return cls(_config=config)

    # ── Internal request handler ───────────────────────────────────────────────

    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Execute an API request with timeout, retry, and structured error handling."""
        url = f"{self._config.base_url}{endpoint}"
        kwargs.setdefault("timeout", self._config.timeout)

        try:
            response = self.session.request(method, url, **kwargs)
        except requests.exceptions.ConnectionError as e:
            raise ServerError(
                f"Could not connect to Aptis backend at {self._config.base_url}. "
                f"Check APTIS_API_URL and that the backend is running. Detail: {e}"
            ) from e
        except requests.exceptions.Timeout:
            raise ServerError(
                f"Request to {url} timed out after {self._config.timeout}s. "
                "Increase APTIS_TIMEOUT or check backend health."
            )
        except requests.exceptions.RequestException as e:
            raise AptisAPIError(f"Unexpected request error: {e}") from e

        status = response.status_code

        if status == 200:
            return response.json()
        if status == 401:
            raise AuthenticationError(
                "Authentication failed (HTTP 401). "
                "Check APTIS_API_KEY and that the key is authorised for the target account."
            )
        if status == 403:
            raise AuthenticationError(
                f"Access denied (HTTP 403). "
                "The API key is not authorised for the requested account. "
                "Check APTIS_ACCOUNT matches the key's authorised accounts."
            )
        if status == 422:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise ValidationError(
                f"Request payload rejected by server (HTTP 422): {detail}"
            )
        if status == 429:
            raise RateLimitError(
                "Rate limit exceeded (HTTP 429). "
                "The request was retried but the limit persisted. "
                "Reduce request frequency or contact Richard Chung to review limits."
            )
        if status >= 500:
            raise ServerError(
                f"Aptis backend returned HTTP {status}. "
                "The request was retried. Check backend logs for details.",
                status_code=status,
            )
        # Other 4xx
        try:
            body = response.text
        except Exception:
            body = ""
        raise APIError(
            f"API returned HTTP {status}: {body}",
            status_code=status,
            response_body=body,
        )

    # ── Strategy config ────────────────────────────────────────────────────────

    def get_config(self, strategy_name: str) -> Dict[str, Any]:
        """Get strategy configuration.

        Returns allocated_capital (the PM-assigned capital for this strategy),
        portfolio_weight, max_position_size, and enabled flag.

        The 'nav' key in the response is a backward-compat alias for
        allocated_capital. Use allocated_capital for new code.
        """
        if strategy_name in self._config_cache:
            return self._config_cache[strategy_name]
        response = self._request("GET", "/api/v1/strategy/config",
                                 params={"strategy_name": strategy_name})
        config = response.get("config", {})
        self._config_cache[strategy_name] = config
        return config

    def register_strategy(self, strategy_name: str, allocated_capital: float = 1000000,
                          portfolio_weight: float = 0.25,
                          max_position_size: float = 250000, enabled: bool = True,
                          # backward-compat aliases
                          nav: Optional[float] = None,
                          funds: Optional[float] = None) -> Dict[str, Any]:
        """Register or update a strategy config.

        Args:
            allocated_capital: Capital assigned to this strategy by the PM.
                               Stored as strategy_config.nav in the database.
            nav:               Deprecated alias for allocated_capital.
            funds:             Deprecated. Ignored. Kept for backward compat.
        """
        self._config_cache.pop(strategy_name, None)
        capital = nav or allocated_capital  # nav alias takes precedence if passed
        return self._request("POST", "/api/v1/strategy/config", json={
            "strategy_name":    strategy_name,
            "nav":              capital,
            "funds":            capital,  # kept for DB compat, mirrors allocated_capital
            "portfolio_weight": portfolio_weight,
            "max_position_size": max_position_size,
            "enabled":          enabled,
        })

    def get_universe(self, strategy_name: str) -> List[str]:
        """Get symbol universe for a strategy."""
        response = self._request("GET", "/api/v1/strategy/universe",
                                 params={"strategy_name": strategy_name})
        return response.get("symbols", [])

    def set_universe(self, strategy_name: str, symbols: List[str],
                     asset_class: Optional[str] = None) -> Dict[str, Any]:
        """Set symbol universe for a strategy (creates or replaces)."""
        return self._request("POST", "/api/v1/strategy/universe", json={
            "strategy_name": strategy_name,
            "symbols": symbols,
            "asset_class": asset_class,
        })

    def request_data_load(self, strategy_name: str,
                          daily_days: int = 60,
                          intraday_days: int = 5) -> Dict[str, Any]:
        """Trigger background data load for a strategy's universe.
        Backend checks what's already in DB and only loads missing data.
        Returns immediately — load runs in background on the server.

        Call this once after set_universe on first deployment.
        Safe to call repeatedly — skips data that already exists.
        """
        return self._request("POST", "/api/v1/strategy/data-load", json={
            "strategy_name": strategy_name,
            "daily_days": daily_days,
            "intraday_days": intraday_days,
        })

    # ── Signal submission ──────────────────────────────────────────────────────

    def submit_signal(self, signal: Signal = None, strategy_name: str = None,
                      account: str = None, symbol: str = None, asset_class: str = None,
                      quantity: float = None, side: str = None, signal_type: str = None,
                      order_parameters: dict = None, metadata: dict = None) -> Dict[str, Any]:
        """Submit a trading signal.

        Accepts a Signal object or individual keyword arguments (backward compatible).
        Raises ValidationError if required fields are missing.
        """
        if signal is None:
            if symbol is None or asset_class is None or quantity is None \
                    or side is None or signal_type is None:
                raise ValidationError(
                    "submit_signal requires either a Signal object or all of: "
                    "symbol, asset_class, quantity, side, signal_type."
                )
            signal = Signal(symbol=symbol, asset_class=asset_class, quantity=quantity,
                            side=side, signal_type=signal_type,
                            order_parameters=order_parameters, metadata=metadata)
        payload = signal.to_dict()
        payload["strategy_name"] = strategy_name
        payload["account"] = account
        return self._request("POST", "/api/v1/strategy/signals/submit", json=payload)

    # ── Market data ────────────────────────────────────────────────────────────

    def get_features(self, symbols: List[str], date: date,
                     features: List[str]) -> Dict[str, Dict[str, float]]:
        """Get Dagster-calculated features."""
        params = {
            "symbols": ",".join(symbols),
            "date": date.isoformat(),
            "features": ",".join(features),
        }
        response = self._request("GET", "/api/v1/strategy/features", params=params)
        return response.get("data", {})

    def get_quotes(self, symbols: List[str],
                   asset_class: Optional[str] = None) -> List[Dict]:
        """Get market quotes."""
        params = {"symbols": ",".join(symbols)}
        if asset_class:
            params["asset_class"] = asset_class
        response = self._request("GET", "/api/v1/strategy/market-data/quotes", params=params)
        return response.get("data", [])

    def get_bars(self, symbol: str, asset_class: str, timeframe: str,
                 start: str, end: str, limit: int = 1000) -> List[Bar]:
        """Get OHLCV bars."""
        params = {
            "symbol": symbol,
            "asset_class": asset_class,
            "timeframe": timeframe,
            "start": start,
            "end": end,
            "limit": limit,
        }
        response = self._request("GET", "/api/v1/strategy/market-data/bars", params=params)
        return response.get("bars", [])

    def get_positions(self, account: str,
                      strategy_name: Optional[str] = None) -> List[Position]:
        """Get current positions."""
        params = {"account": account}
        if strategy_name:
            params["strategy_name"] = strategy_name
        response = self._request("GET", "/api/v1/strategy/positions", params=params)
        return [Position(**p) for p in response.get("positions", [])]

    def get_pnl(self, account: str, start_date: date, end_date: date,
                strategy_name: Optional[str] = None) -> Dict[str, Any]:
        """Get P&L summary."""
        params = {
            "account": account,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
        }
        if strategy_name:
            params["strategy_name"] = strategy_name
        response = self._request("GET", "/api/v1/strategy/pnl", params=params)
        return response.get("summary", {})

    # ── Parameters management ──────────────────────────────────────────────────

    def get_tickers(self) -> Dict[str, Any]:
        """Get all active ticker lists (merger, internal_ban, restricted)."""
        return self._request("GET", "/api/monitors/parameters/tickers")

    def add_merger_tickers(self, tickers: List[str]) -> Dict[str, Any]:
        """Add tickers to the merger list."""
        return self._request("POST", "/api/monitors/parameters/tickers/merger",
                             json={"tickers": tickers})

    def remove_merger_tickers(self, tickers: List[str], end_date: date) -> Dict[str, Any]:
        """Remove tickers from the merger list."""
        return self._request("DELETE", "/api/monitors/parameters/tickers/merger",
                             json={"tickers": tickers, "end_date": end_date.isoformat()})

    def add_internal_ban_tickers(self, tickers: List[str]) -> Dict[str, Any]:
        """Add tickers to the internal ban list."""
        return self._request("POST", "/api/monitors/parameters/tickers/internal-ban",
                             json={"tickers": tickers})

    def remove_internal_ban_tickers(self, tickers: List[str], end_date: date) -> Dict[str, Any]:
        """Remove tickers from the internal ban list."""
        return self._request("DELETE", "/api/monitors/parameters/tickers/internal-ban",
                             json={"tickers": tickers, "end_date": end_date.isoformat()})

    def add_restricted_tickers(self, tickers: List[str], account: str,
                               restricted_type: str) -> Dict[str, Any]:
        """Add tickers to the restricted list. restricted_type: ABSOLUTE, LONG, or SHORT."""
        return self._request("POST", "/api/monitors/parameters/tickers/restricted",
                             json={"tickers": tickers, "account": account,
                                   "restricted_type": restricted_type})

    def remove_restricted_tickers(self, tickers: List[str], account: str, end_date: date,
                                  restricted_type: Optional[str] = None) -> Dict[str, Any]:
        """Remove tickers from the restricted list."""
        payload = {"tickers": tickers, "account": account, "end_date": end_date.isoformat()}
        if restricted_type:
            payload["restricted_type"] = restricted_type
        return self._request("DELETE", "/api/monitors/parameters/tickers/restricted",
                             json=payload)

    def reset_strategy(self, strategy_name: str) -> Dict[str, Any]:
        """Reset a strategy: close all open trades, clear signals and PM rows."""
        self._config_cache.pop(strategy_name, None)
        return self._request(
            "POST",
            f"/api/v1/strategy/reset/{requests.utils.quote(strategy_name, safe='')}"
        )

    def set_optimizer_overrides(self, strategy_name: str,
                                overrides: Dict[str, Any]) -> Dict[str, Any]:
        """Set optimizer parameter overrides for a strategy."""
        return self._request("POST", "/api/v1/strategy/optimizer-overrides",
                             json={"strategy_name": strategy_name, "overrides": overrides})

    def get_optimizer_overrides(self, strategy_name: str) -> Dict[str, Any]:
        """Get current optimizer overrides for a strategy."""
        response = self._request("GET", "/api/v1/strategy/optimizer-overrides",
                                 params={"strategy_name": strategy_name})
        return response.get("overrides", {})

    def get_optimizer_config(self, strategy_name: str) -> Dict[str, Any]:
        """Get optimizer config (nav, funds, portfolio_weight, enabled) for a strategy."""
        return self._request("GET",
                             f"/api/monitors/parameters/optimizers/{strategy_name}")

    def update_optimizer_config(self, strategy_name: str,
                                allocated_capital: Optional[float] = None,
                                portfolio_weight: Optional[float] = None,
                                max_position_size: Optional[float] = None,
                                enabled: Optional[bool] = None,
                                # backward-compat aliases
                                nav: Optional[float] = None,
                                funds: Optional[float] = None) -> Dict[str, Any]:
        """Update strategy config fields. Only provided fields are changed.

        Args:
            allocated_capital: Capital assigned to this strategy by the PM.
            nav:               Deprecated alias for allocated_capital.
            funds:             Deprecated. Ignored.
        """
        capital = nav or allocated_capital
        payload = {k: v for k, v in {
            "nav":              capital,
            "funds":            capital if capital is not None else None,
            "portfolio_weight": portfolio_weight,
            "max_position_size": max_position_size,
            "enabled":          enabled,
        }.items() if v is not None}
        return self._request("PATCH",
                             f"/api/monitors/parameters/optimizers/{strategy_name}",
                             json=payload)

    # ── Execution feedback ─────────────────────────────────────────────────────

    def get_trade_fills(
        self,
        account: str,
        strategy_name: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        limit: int = 500,
    ) -> List[TradeFill]:
        """Return individual trade fills for a strategy.

        Backed by GET /api/v1/strategy/trades (existing endpoint).
        Each row in trade_strategy_trade becomes one TradeFill.

        Args:
            account:       Account name (e.g. "Theme").
            strategy_name: Filter to one strategy.  None = all strategies.
            start_date:    Inclusive start.  Defaults to 30 days ago.
            end_date:      Inclusive end.    Defaults to today.
            limit:         Max rows returned.

        Returns:
            List of TradeFill, newest first.
        """
        params: Dict[str, Any] = {"account": account, "limit": limit}
        if start_date:
            params["start_date"] = start_date.isoformat()
        if strategy_name:
            params["strategy_name"] = strategy_name
        # TODO: add end_date param once backend supports it
        response = self._request("GET", "/api/v1/strategy/trades", params=params)
        rows = response.get("trades", [])
        fills = [TradeFill.from_trade_row(r) for r in rows]
        if end_date:
            fills = [f for f in fills if f.trade_date <= end_date.isoformat()]
        if strategy_name:
            fills = [f for f in fills if f.strategy == strategy_name]
        return fills

    def get_execution_reports(
        self,
        account: str,
        strategy_name: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        include_fills: bool = False,
    ) -> ExecutionReport:
        """Return an aggregated execution quality report for a strategy.

        Computes fill rate, rejection count, slippage, and commission totals
        from the fills returned by get_trade_fills().

        Args:
            account:        Account name.
            strategy_name:  Strategy to report on.  None = all strategies.
            start_date:     Report period start.
            end_date:       Report period end.
            include_fills:  If True, attach the raw TradeFill list to the report.

        Returns:
            ExecutionReport with aggregated metrics.

        Note:
            slippage_bps per fill is only populated when the backend stores
            an arrival price alongside the fill price.  Currently None for
            paper trading — will be populated automatically once live broker
            fills are available.
            # TODO: expose dedicated GET /api/v1/strategy/execution-reports
            #       endpoint on the backend for server-side aggregation.
        """
        from datetime import date as date_type, timedelta
        _start = start_date or (date_type.today() - timedelta(days=30))
        _end   = end_date   or date_type.today()

        fills = self.get_trade_fills(
            account=account,
            strategy_name=strategy_name,
            start_date=_start,
            end_date=_end,
        )

        _FILLED = {"APPROVED", "SUBMITTED", "CLOSED"}
        _REJECTED = {"REJECTED", "ERROR"}

        total_fills      = sum(1 for f in fills if f.status.upper() in _FILLED)
        total_rejections = sum(1 for f in fills if f.status.upper() in _REJECTED)
        total_signals    = len(fills)
        fill_rate        = total_fills / total_signals if total_signals else 0.0

        slippages = [f.slippage_bps for f in fills if f.slippage_bps is not None]
        avg_slippage = sum(slippages) / len(slippages) if slippages else None

        latencies = [f.execution_latency_ms for f in fills
                     if f.execution_latency_ms is not None]
        avg_latency = sum(latencies) / len(latencies) if latencies else None

        commissions = [f.commission for f in fills if f.commission is not None]
        fees_list   = [f.fees      for f in fills if f.fees      is not None]

        return ExecutionReport(
            strategy=strategy_name or "(all)",
            account=account,
            period_start=_start.isoformat(),
            period_end=_end.isoformat(),
            total_signals=total_signals,
            total_fills=total_fills,
            total_rejections=total_rejections,
            fill_rate=round(fill_rate, 4),
            avg_slippage_bps=round(avg_slippage, 2) if avg_slippage is not None else None,
            avg_execution_latency_ms=round(avg_latency, 1) if avg_latency is not None else None,
            total_commission=round(sum(commissions), 4) if commissions else None,
            total_fees=round(sum(fees_list), 4) if fees_list else None,
            fills=fills if include_fills else None,
        )

    def get_signal_results(
        self,
        account: str,
        strategy_name: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        limit: int = 500,
    ) -> List[SignalResult]:
        """Return per-signal outcomes linking signal intent to trade result.

        Each SignalResult represents one submitted signal and its fill outcome.
        Useful for computing signal hit rate and per-signal P&L attribution.

        Args:
            account:       Account name.
            strategy_name: Filter to one strategy.
            start_date:    Inclusive start.
            end_date:      Inclusive end.
            limit:         Max rows.

        Returns:
            List of SignalResult, newest first.

        Note:
            # TODO: expose GET /api/v1/strategy/signal-results on the backend
            #       to join trade_signal_output with trade_strategy_trade
            #       server-side for richer signal-level attribution.
            Currently derived from trade fills — one fill = one SignalResult.
        """
        fills = self.get_trade_fills(
            account=account,
            strategy_name=strategy_name,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
        )

        _FILLED = {"APPROVED", "SUBMITTED", "CLOSED"}
        _REJECTED = {"REJECTED", "ERROR"}

        results: List[SignalResult] = []
        for fill in fills:
            status_upper = fill.status.upper()
            if status_upper in _FILLED:
                status = SignalStatus.ACCEPTED
            elif status_upper in _REJECTED:
                status = SignalStatus.REJECTED
            elif status_upper == "PENDING":
                status = SignalStatus.PENDING
            elif status_upper == "SKIPPED":
                status = SignalStatus.SKIPPED
            else:
                status = SignalStatus.ERROR

            results.append(SignalResult(
                symbol=fill.symbol,
                strategy=fill.strategy,
                signal_date=fill.trade_date,
                side=fill.side,
                signal_type=fill.direction,
                requested_quantity=fill.quantity,
                status=status,
                fill=fill if status == SignalStatus.ACCEPTED else None,
                rejection_reason=fill.rejection_reason,
                realized_pnl=fill.realized_pnl,
                signal_confidence=fill.signal_confidence,
            ))
        return results
