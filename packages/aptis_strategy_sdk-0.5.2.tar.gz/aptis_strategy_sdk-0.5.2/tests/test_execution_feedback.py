"""Tests: Execution feedback models, client methods, and analytics helpers."""
import pytest
from datetime import date, timedelta
from unittest.mock import patch, MagicMock

from aptis_strategy_sdk.models import (
    TradeFill, ExecutionReport, SignalResult, SignalStatus,
)
from aptis_strategy_sdk.analytics import (
    StrategyAnalytics,
    fill_rate, win_rate, signal_hit_rate,
    average_slippage_bps, realized_vs_unrealized_pnl,
    exposure_summary, summarise_signal_results,
)
from tests.conftest import bare_client, mock_client, mock_response, make_fill, make_position


# ── TradeFill.from_trade_row ───────────────────────────────────────────────────

class TestTradeFillFromRow:

    def _row(self, **kwargs):
        base = {
            "id": 42, "symbol": "AAPL", "strategy": "TEST", "account": "Theme",
            "side": "BUY", "direction": "ENTRY", "quantity": 100,
            "entry_price": 150.0, "status": "CLOSED",
            "created": "2024-06-01T10:00:00", "realized_pnl": 250.0,
            "exit_price": 152.5, "commission": 1.5, "fees": 0.5, "error": None,
        }
        base.update(kwargs)
        return base

    def test_basic_fields_mapped(self):
        f = TradeFill.from_trade_row(self._row())
        assert f.trade_id == 42
        assert f.symbol == "AAPL"
        assert f.fill_price == 150.0
        assert f.status == "CLOSED"
        assert f.trade_date == "2024-06-01"

    def test_realized_pnl_mapped(self):
        f = TradeFill.from_trade_row(self._row(realized_pnl=300.0))
        assert f.realized_pnl == 300.0

    def test_none_realized_pnl_stays_none(self):
        f = TradeFill.from_trade_row(self._row(realized_pnl=None))
        assert f.realized_pnl is None

    def test_rejection_reason_from_error_field(self):
        f = TradeFill.from_trade_row(self._row(error="ticker not found"))
        assert f.rejection_reason == "ticker not found"

    def test_missing_created_gives_empty_date(self):
        f = TradeFill.from_trade_row(self._row(created=None))
        assert f.trade_date == ""

    def test_commission_and_fees_mapped(self):
        f = TradeFill.from_trade_row(self._row(commission=2.0, fees=0.25))
        assert f.commission == 2.0
        assert f.fees == 0.25


# ── Client: get_trade_fills ────────────────────────────────────────────────────

class TestGetTradeFills:

    def _trades_response(self, rows):
        return {"status": "success", "trades": rows, "total_count": len(rows)}

    def _row(self, symbol="AAPL", strategy="TEST", status="CLOSED",
             created="2024-06-01T10:00:00"):
        return {
            "id": 1, "symbol": symbol, "strategy": strategy, "account": "Theme",
            "side": "BUY", "direction": "ENTRY", "quantity": 100,
            "entry_price": 150.0, "status": status,
            "created": created, "realized_pnl": 100.0,
            "exit_price": None, "commission": None, "fees": None, "error": None,
        }

    def test_returns_list_of_trade_fills(self):
        client = bare_client()
        resp = mock_response(200, self._trades_response([self._row()]))
        with patch.object(client.session, "request", return_value=resp):
            fills = client.get_trade_fills("Theme", "TEST")
        assert len(fills) == 1
        assert isinstance(fills[0], TradeFill)

    def test_filters_by_strategy_name(self):
        client = bare_client()
        rows = [self._row(strategy="TEST"), self._row(strategy="OTHER")]
        resp = mock_response(200, self._trades_response(rows))
        with patch.object(client.session, "request", return_value=resp):
            fills = client.get_trade_fills("Theme", strategy_name="TEST")
        assert all(f.strategy == "TEST" for f in fills)

    def test_filters_by_end_date(self):
        client = bare_client()
        rows = [
            self._row(created="2024-06-01T10:00:00"),
            self._row(created="2024-06-15T10:00:00"),
        ]
        resp = mock_response(200, self._trades_response(rows))
        with patch.object(client.session, "request", return_value=resp):
            fills = client.get_trade_fills(
                "Theme", end_date=date(2024, 6, 10))
        assert len(fills) == 1
        assert fills[0].trade_date == "2024-06-01"

    def test_empty_trades_returns_empty_list(self):
        client = bare_client()
        resp = mock_response(200, self._trades_response([]))
        with patch.object(client.session, "request", return_value=resp):
            fills = client.get_trade_fills("Theme")
        assert fills == []


# ── Client: get_execution_reports ─────────────────────────────────────────────

class TestGetExecutionReports:

    def _make_client_with_fills(self, fills):
        client = bare_client()
        client.get_trade_fills = MagicMock(return_value=fills)
        return client

    def test_fill_rate_all_closed(self):
        fills = [make_fill(status="CLOSED") for _ in range(4)]
        client = self._make_client_with_fills(fills)
        report = client.get_execution_reports("Theme", "TEST")
        assert report.fill_rate == 1.0
        assert report.total_fills == 4
        assert report.total_rejections == 0

    def test_fill_rate_mixed(self):
        fills = [
            make_fill(status="CLOSED"),
            make_fill(status="CLOSED"),
            make_fill(status="REJECTED"),
        ]
        client = self._make_client_with_fills(fills)
        report = client.get_execution_reports("Theme", "TEST")
        assert report.total_fills == 2
        assert report.total_rejections == 1
        assert round(report.fill_rate, 4) == round(2 / 3, 4)

    def test_empty_fills_zero_fill_rate(self):
        client = self._make_client_with_fills([])
        report = client.get_execution_reports("Theme", "TEST")
        assert report.fill_rate == 0.0
        assert report.total_signals == 0

    def test_avg_slippage_computed(self):
        fills = [
            make_fill(status="CLOSED", slippage_bps=5.0),
            make_fill(status="CLOSED", slippage_bps=15.0),
        ]
        client = self._make_client_with_fills(fills)
        report = client.get_execution_reports("Theme", "TEST")
        assert report.avg_slippage_bps == 10.0

    def test_avg_slippage_none_when_unavailable(self):
        client = self._make_client_with_fills([make_fill(status="CLOSED")])
        report = client.get_execution_reports("Theme", "TEST")
        assert report.avg_slippage_bps is None

    def test_include_fills_attaches_list(self):
        fills = [make_fill(status="CLOSED")]
        client = self._make_client_with_fills(fills)
        report = client.get_execution_reports("Theme", "TEST", include_fills=True)
        assert report.fills is not None
        assert len(report.fills) == 1

    def test_exclude_fills_is_none(self):
        client = self._make_client_with_fills([make_fill(status="CLOSED")])
        report = client.get_execution_reports("Theme", "TEST", include_fills=False)
        assert report.fills is None

    def test_commission_totalled(self):
        fills = [make_fill(status="CLOSED"), make_fill(status="CLOSED")]
        fills[0].commission = 1.5
        fills[1].commission = 2.5
        client = self._make_client_with_fills(fills)
        report = client.get_execution_reports("Theme", "TEST")
        assert report.total_commission == 4.0

    def test_report_fields_populated(self):
        client = self._make_client_with_fills([])
        report = client.get_execution_reports(
            "Theme", "TEST",
            start_date=date(2024, 1, 1), end_date=date(2024, 1, 31),
        )
        assert isinstance(report, ExecutionReport)
        assert report.strategy == "TEST"
        assert report.account == "Theme"
        assert report.period_start == "2024-01-01"
        assert report.period_end == "2024-01-31"


# ── Client: get_signal_results ─────────────────────────────────────────────────

class TestGetSignalResults:

    def _make_client_with_fills(self, fills):
        client = bare_client()
        client.get_trade_fills = MagicMock(return_value=fills)
        return client

    def test_closed_fill_becomes_accepted(self):
        client = self._make_client_with_fills([make_fill(status="CLOSED")])
        results = client.get_signal_results("Theme", "TEST")
        assert results[0].status == SignalStatus.ACCEPTED
        assert results[0].fill is not None

    def test_rejected_fill_becomes_rejected(self):
        client = self._make_client_with_fills(
            [make_fill(status="REJECTED", rejection_reason="risk limit")])
        results = client.get_signal_results("Theme", "TEST")
        assert results[0].status == SignalStatus.REJECTED
        assert results[0].fill is None
        assert results[0].rejection_reason == "risk limit"

    def test_pending_fill_becomes_pending(self):
        client = self._make_client_with_fills([make_fill(status="PENDING")])
        results = client.get_signal_results("Theme", "TEST")
        assert results[0].status == SignalStatus.PENDING

    def test_skipped_fill_becomes_skipped(self):
        client = self._make_client_with_fills([make_fill(status="SKIPPED")])
        results = client.get_signal_results("Theme", "TEST")
        assert results[0].status == SignalStatus.SKIPPED

    def test_empty_fills_returns_empty_list(self):
        client = self._make_client_with_fills([])
        assert client.get_signal_results("Theme", "TEST") == []

    def test_realized_pnl_propagated(self):
        client = self._make_client_with_fills(
            [make_fill(status="CLOSED", realized_pnl=350.0)])
        results = client.get_signal_results("Theme", "TEST")
        assert results[0].realized_pnl == 350.0


# ── Analytics: pure functions ──────────────────────────────────────────────────

class TestFillRate:

    def test_all_closed(self):
        fills = [make_fill(status="CLOSED") for _ in range(3)]
        assert fill_rate(fills) == 1.0

    def test_all_rejected(self):
        fills = [make_fill(status="REJECTED") for _ in range(3)]
        assert fill_rate(fills) == 0.0

    def test_mixed(self):
        fills = [make_fill(status="CLOSED"), make_fill(status="REJECTED")]
        assert fill_rate(fills) == 0.5

    def test_approved_and_submitted_count_as_filled(self):
        fills = [make_fill(status="APPROVED"), make_fill(status="SUBMITTED")]
        assert fill_rate(fills) == 1.0

    def test_empty_returns_zero(self):
        assert fill_rate([]) == 0.0


class TestWinRate:

    def test_all_winners(self):
        fills = [make_fill(direction="EXIT", realized_pnl=100.0) for _ in range(3)]
        assert win_rate(fills) == 1.0

    def test_all_losers(self):
        fills = [make_fill(direction="EXIT", realized_pnl=-50.0) for _ in range(3)]
        assert win_rate(fills) == 0.0

    def test_mixed(self):
        fills = [
            make_fill(direction="EXIT", realized_pnl=100.0),
            make_fill(direction="EXIT", realized_pnl=-50.0),
        ]
        assert win_rate(fills) == 0.5

    def test_no_closed_trades_returns_none(self):
        fills = [make_fill(direction="ENTRY", realized_pnl=None)]
        assert win_rate(fills) is None

    def test_empty_returns_none(self):
        assert win_rate([]) is None


class TestSignalHitRate:

    def test_all_hits(self):
        fills = [make_fill(direction="ENTRY", realized_pnl=100.0) for _ in range(4)]
        assert signal_hit_rate(fills) == 1.0

    def test_no_hits(self):
        fills = [make_fill(direction="ENTRY", realized_pnl=-20.0) for _ in range(2)]
        assert signal_hit_rate(fills) == 0.0

    def test_mixed(self):
        fills = [
            make_fill(direction="ENTRY", realized_pnl=50.0),
            make_fill(direction="ENTRY", realized_pnl=-10.0),
            make_fill(direction="ENTRY", realized_pnl=30.0),
        ]
        assert round(signal_hit_rate(fills), 4) == round(2 / 3, 4)

    def test_no_entry_fills_returns_none(self):
        fills = [make_fill(direction="EXIT", realized_pnl=100.0)]
        assert signal_hit_rate(fills) is None

    def test_entry_without_pnl_excluded(self):
        fills = [make_fill(direction="ENTRY", realized_pnl=None)]
        assert signal_hit_rate(fills) is None


class TestAverageSlippageBps:

    def test_computes_mean(self):
        fills = [make_fill(slippage_bps=4.0), make_fill(slippage_bps=8.0)]
        assert average_slippage_bps(fills) == 6.0

    def test_none_when_no_slippage_data(self):
        fills = [make_fill(slippage_bps=None)]
        assert average_slippage_bps(fills) is None

    def test_empty_returns_none(self):
        assert average_slippage_bps([]) is None

    def test_partial_slippage_data_uses_available(self):
        fills = [make_fill(slippage_bps=10.0), make_fill(slippage_bps=None)]
        assert average_slippage_bps(fills) == 10.0


class TestRealizedVsUnrealizedPnl:

    def test_sums_correctly(self):
        fills = [make_fill(realized_pnl=200.0), make_fill(realized_pnl=100.0)]
        positions = [make_position(unrealized_pnl=50.0)]
        result = realized_vs_unrealized_pnl(fills, positions)
        assert result["realized_pnl"] == 300.0
        assert result["unrealized_pnl"] == 50.0
        assert result["total_pnl"] == 350.0

    def test_no_fills_no_positions(self):
        result = realized_vs_unrealized_pnl([], [])
        assert result == {"realized_pnl": 0.0, "unrealized_pnl": 0.0, "total_pnl": 0.0}

    def test_fills_without_pnl_excluded(self):
        fills = [make_fill(realized_pnl=None), make_fill(realized_pnl=100.0)]
        result = realized_vs_unrealized_pnl(fills, [])
        assert result["realized_pnl"] == 100.0


class TestExposureSummary:

    def test_long_only(self):
        positions = [make_position(quantity=100, current_price=150.0)]
        exp = exposure_summary(positions)
        assert exp["long_usd"] == 15_000.0
        assert exp["short_usd"] == 0.0
        assert exp["gross_usd"] == 15_000.0
        assert exp["net_usd"] == 15_000.0

    def test_short_only(self):
        positions = [make_position(quantity=-50, current_price=200.0)]
        exp = exposure_summary(positions)
        assert exp["short_usd"] == 10_000.0
        assert exp["long_usd"] == 0.0
        assert exp["net_usd"] == -10_000.0

    def test_long_short_combined(self):
        positions = [
            make_position(quantity=100, current_price=100.0),
            make_position(quantity=-50, current_price=100.0),
        ]
        exp = exposure_summary(positions)
        assert exp["long_usd"] == 10_000.0
        assert exp["short_usd"] == 5_000.0
        assert exp["gross_usd"] == 15_000.0
        assert exp["net_usd"] == 5_000.0

    def test_empty_positions(self):
        exp = exposure_summary([])
        assert exp["gross_usd"] == 0.0
        assert exp["position_count"] == 0

    def test_counts_correct(self):
        positions = [
            make_position(quantity=100),
            make_position(quantity=200),
            make_position(quantity=-50),
        ]
        exp = exposure_summary(positions)
        assert exp["long_count"] == 2
        assert exp["short_count"] == 1
        assert exp["position_count"] == 3


class TestSummariseSignalResults:

    def _result(self, status, pnl=None):
        return SignalResult(
            symbol="AAPL", strategy="TEST", signal_date="2024-06-01",
            side="BUY", signal_type="ENTRY", requested_quantity=100,
            status=status, realized_pnl=pnl,
        )

    def test_counts_all_statuses(self):
        results = [
            self._result(SignalStatus.ACCEPTED, pnl=100.0),
            self._result(SignalStatus.ACCEPTED, pnl=-20.0),
            self._result(SignalStatus.REJECTED),
            self._result(SignalStatus.PENDING),
            self._result(SignalStatus.SKIPPED),
        ]
        s = summarise_signal_results(results)
        assert s["total"] == 5
        assert s["accepted"] == 2
        assert s["rejected"] == 1
        assert s["pending"] == 1
        assert s["skipped"] == 1

    def test_fill_rate(self):
        results = [
            self._result(SignalStatus.ACCEPTED),
            self._result(SignalStatus.REJECTED),
        ]
        s = summarise_signal_results(results)
        assert s["fill_rate"] == 0.5

    def test_win_rate_from_pnl(self):
        results = [
            self._result(SignalStatus.ACCEPTED, pnl=100.0),
            self._result(SignalStatus.ACCEPTED, pnl=-50.0),
        ]
        s = summarise_signal_results(results)
        assert s["win_rate"] == 0.5

    def test_empty_returns_zeros(self):
        s = summarise_signal_results([])
        assert s["total"] == 0
        assert s["fill_rate"] == 0.0
        assert s["win_rate"] is None


# ── StrategyAnalytics facade ───────────────────────────────────────────────────

class TestStrategyAnalytics:

    def _analytics(self, fills=None, positions=None, pnl=None):
        client = mock_client()
        client.get_trade_fills.return_value = fills or []
        client.get_positions.return_value = positions or []
        client.get_pnl.return_value = pnl or {"total_realized_pnl": 0.0}
        return StrategyAnalytics(client, "Theme", "TEST"), client

    def test_diagnostics_returns_correct_type(self):
        from aptis_strategy_sdk.models import StrategyDiagnostics
        analytics, _ = self._analytics()
        diag = analytics.diagnostics()
        assert isinstance(diag, StrategyDiagnostics)

    def test_diagnostics_fill_rate(self):
        fills = [make_fill(status="CLOSED"), make_fill(status="REJECTED")]
        analytics, _ = self._analytics(fills=fills)
        diag = analytics.diagnostics()
        assert diag.fill_rate == 0.5

    def test_diagnostics_total_pnl(self):
        fills = [make_fill(status="CLOSED", realized_pnl=200.0)]
        positions = [make_position(unrealized_pnl=50.0)]
        analytics, _ = self._analytics(
            fills=fills, positions=positions,
            pnl={"total_realized_pnl": 200.0},
        )
        diag = analytics.diagnostics()
        assert diag.total_realized_pnl == 200.0
        assert diag.total_unrealized_pnl == 50.0
        assert diag.total_pnl == 250.0

    def test_diagnostics_exposure(self):
        positions = [make_position(quantity=100, current_price=100.0)]
        analytics, _ = self._analytics(positions=positions)
        diag = analytics.diagnostics()
        assert diag.long_exposure_usd == 10_000.0
        assert diag.gross_exposure_usd == 10_000.0

    def test_fill_rate_convenience(self):
        fills = [make_fill(status="CLOSED") for _ in range(3)]
        analytics, _ = self._analytics(fills=fills)
        assert analytics.fill_rate() == 1.0

    def test_win_rate_convenience(self):
        fills = [make_fill(direction="EXIT", realized_pnl=100.0)]
        analytics, _ = self._analytics(fills=fills)
        assert analytics.win_rate() == 1.0

    def test_exposure_convenience(self):
        positions = [make_position(quantity=50, current_price=200.0)]
        analytics, _ = self._analytics(positions=positions)
        exp = analytics.exposure()
        assert exp["long_usd"] == 10_000.0
