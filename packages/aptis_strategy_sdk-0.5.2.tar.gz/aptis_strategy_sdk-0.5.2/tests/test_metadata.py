"""Tests: Metadata helpers — RegimeMetadata, FactorScoreMetadata, RiskSnapshotMetadata."""
import json
import pytest
from aptis_strategy_sdk.models import (
    RegimeMetadata, FactorScoreMetadata, RiskSnapshotMetadata, Signal,
)
from aptis_strategy_sdk import Urgency, ExecutionStyle
from tests.conftest import good_signal


class TestRegimeMetadata:

    def test_all_fields_present(self):
        r = RegimeMetadata(label="BULL", confidence=0.78,
                           indicators={"adx": 31.2, "vix": 14.8})
        d = r.to_dict()
        assert d["label"] == "BULL"
        assert d["confidence"] == 0.78
        assert d["indicators"] == {"adx": 31.2, "vix": 14.8}

    def test_none_fields_stripped(self):
        r = RegimeMetadata(label="BEAR")
        d = r.to_dict()
        assert "confidence" not in d
        assert "indicators" not in d

    def test_all_label_values(self):
        for label in ("BULL", "BEAR", "STRESS", "CHOP"):
            d = RegimeMetadata(label=label).to_dict()
            assert d["label"] == label

    def test_json_serialisable(self):
        r = RegimeMetadata(label="BULL", confidence=0.8,
                           indicators={"adx": 28.0})
        json.dumps(r.to_dict())  # must not raise

    def test_confidence_zero_included(self):
        r = RegimeMetadata(label="CHOP", confidence=0.0)
        assert r.to_dict()["confidence"] == 0.0


class TestFactorScoreMetadata:

    def test_known_fields_present(self):
        f = FactorScoreMetadata(momentum=0.84, quality=0.61, volatility=0.45)
        d = f.to_dict()
        assert d["momentum"] == 0.84
        assert d["quality"] == 0.61
        assert d["volatility"] == 0.45

    def test_none_fields_stripped(self):
        f = FactorScoreMetadata(momentum=0.7)
        d = f.to_dict()
        assert "quality" not in d
        assert "volatility" not in d
        assert "sentiment" not in d
        assert "value" not in d

    def test_extra_dict_merged_into_output(self):
        f = FactorScoreMetadata(momentum=0.5, extra={"carry": 0.33, "size": 0.21})
        d = f.to_dict()
        assert d["carry"] == 0.33
        assert d["size"] == 0.21
        assert "extra" not in d

    def test_extra_none_not_in_output(self):
        f = FactorScoreMetadata(momentum=0.5)
        d = f.to_dict()
        assert "extra" not in d

    def test_json_serialisable(self):
        f = FactorScoreMetadata(momentum=0.84, extra={"carry": 0.3})
        json.dumps(f.to_dict())

    def test_zero_value_included(self):
        f = FactorScoreMetadata(momentum=0.0)
        assert f.to_dict()["momentum"] == 0.0


class TestRiskSnapshotMetadata:

    def test_populated_fields_present(self):
        r = RiskSnapshotMetadata(
            portfolio_var_1d=0.0082,
            max_drawdown=-0.043,
            sharpe_trailing=1.74,
        )
        d = r.to_dict()
        assert d["portfolio_var_1d"] == 0.0082
        assert d["max_drawdown"] == -0.043
        assert d["sharpe_trailing"] == 1.74

    def test_none_fields_stripped(self):
        r = RiskSnapshotMetadata(sharpe_trailing=1.5)
        d = r.to_dict()
        assert "portfolio_var_1d" not in d
        assert "beta" not in d
        assert "volatility_30d" not in d

    def test_extra_dict_merged(self):
        r = RiskSnapshotMetadata(sharpe_trailing=1.5, extra={"calmar": 0.9})
        d = r.to_dict()
        assert d["calmar"] == 0.9
        assert "extra" not in d

    def test_json_serialisable(self):
        r = RiskSnapshotMetadata(portfolio_var_1d=0.008, sharpe_trailing=1.6)
        json.dumps(r.to_dict())

    def test_negative_drawdown_preserved(self):
        r = RiskSnapshotMetadata(max_drawdown=-0.15)
        assert r.to_dict()["max_drawdown"] == -0.15


class TestSignalMetadataSerialization:

    def test_flat_metadata_dict_round_trips(self):
        s = good_signal(metadata={"rsi": 28.4, "reason": "oversold"})
        d = s.to_dict()
        assert d["metadata"] == {"rsi": 28.4, "reason": "oversold"}

    def test_nested_metadata_round_trips(self):
        regime = RegimeMetadata(label="BULL", confidence=0.78).to_dict()
        s = good_signal(metadata={"regime": regime, "rationale": "test"})
        d = s.to_dict()
        assert d["metadata"]["regime"]["label"] == "BULL"
        assert d["metadata"]["rationale"] == "test"

    def test_full_metadata_payload_is_json_safe(self):
        regime  = RegimeMetadata(label="BULL", confidence=0.78,
                                 indicators={"adx": 31.2}).to_dict()
        factors = FactorScoreMetadata(momentum=0.84, extra={"carry": 0.3}).to_dict()
        risk    = RiskSnapshotMetadata(portfolio_var_1d=0.008,
                                       sharpe_trailing=1.74).to_dict()
        s = good_signal(metadata={
            "rationale":        "Test rationale under 300 chars.",
            "regime":           regime,
            "factor_scores":    factors,
            "risk_metrics":     risk,
            "execution_context": {"trigger": "daily_close", "spread_bps": 4.2},
            "model_version":    "test-v1.0",
            "feature_snapshot": {"rsi_14": 28.4, "momentum_20d": 0.034},
            "annotations":      ["high-conviction"],
        })
        payload = json.dumps(s.to_dict())  # must not raise
        parsed  = json.loads(payload)
        assert parsed["metadata"]["regime"]["label"] == "BULL"
        assert parsed["metadata"]["factor_scores"]["momentum"] == 0.84

    def test_metadata_none_omitted_from_payload(self):
        s = good_signal()  # no metadata
        assert "metadata" not in s.to_dict()

    def test_institutional_enums_serialised_as_strings(self):
        s = Signal(
            symbol="AAPL", asset_class="equity",
            quantity=100, side="BUY", signal_type="ENTRY",
            urgency=Urgency.HIGH,
            execution_style=ExecutionStyle.TWAP,
        )
        d = s.to_dict()
        assert d["urgency"] == "HIGH"
        assert d["execution_style"] == "TWAP"

    def test_tags_list_round_trips(self):
        s = good_signal(tags=["momentum", "regime:bull", "factor:quality"])
        d = s.to_dict()
        assert d["tags"] == ["momentum", "regime:bull", "factor:quality"]

    def test_all_institutional_fields_in_payload(self):
        s = Signal(
            symbol="BTC/USD", asset_class="crypto",
            quantity=0.5, side="BUY", signal_type="ENTRY",
            notional_usd=18_500.0,
            portfolio_weight=0.06,
            confidence=0.82,
            urgency=Urgency.HIGH,
            execution_style=ExecutionStyle.TWAP,
            time_in_force="DAY",
            max_slippage_bps=15.0,
            limit_price=37_200.0,
            stop_price=36_000.0,
            broker_route="PRIME",
            reduce_only=False,
            tags=["momentum"],
        )
        d = s.to_dict()
        assert d["notional_usd"] == 18_500.0
        assert d["portfolio_weight"] == 0.06
        assert d["confidence"] == 0.82
        assert d["urgency"] == "HIGH"
        assert d["execution_style"] == "TWAP"
        assert d["time_in_force"] == "DAY"
        assert d["max_slippage_bps"] == 15.0
        assert d["limit_price"] == 37_200.0
        assert d["stop_price"] == 36_000.0
        assert d["broker_route"] == "PRIME"
        assert d["reduce_only"] is False
        assert d["tags"] == ["momentum"]
        json.dumps(d)  # must be JSON-safe

    def test_unset_institutional_fields_absent(self):
        s = good_signal()
        d = s.to_dict()
        for field in ("notional_usd", "portfolio_weight", "confidence", "urgency",
                      "execution_style", "time_in_force", "max_slippage_bps",
                      "limit_price", "stop_price", "broker_route",
                      "reduce_only", "tags"):
            assert field not in d, f"{field} should be absent when unset"
