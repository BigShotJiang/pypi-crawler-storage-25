"""
Unit tests for SDK hardening: validation, retry logic, config loading,
and Strategy base class lifecycle.

No backend required — all HTTP calls are mocked.

Author: Richard Chung

Run:
    cd /home/richard/theme/sdk
    python -m pytest tests/test_hardening.py -v
"""
import os
import pytest
from datetime import date
from unittest.mock import patch, MagicMock
from requests.exceptions import ConnectionError as RequestsConnectionError, Timeout

from aptis_strategy_sdk.models import Signal, AptisConfig
from aptis_strategy_sdk.client import AptisClient
from aptis_strategy_sdk.strategy import Strategy, _validate_signal
from aptis_strategy_sdk.exceptions import (
    AuthenticationError, ConfigurationError, ValidationError,
    APIError, RateLimitError, ServerError, AptisAPIError,
)


# ── Shared helpers ─────────────────────────────────────────────────────────────

def _mock_response(status_code: int, json_body: dict = None, text: str = ""):
    resp = MagicMock()
    resp.status_code = status_code
    resp.text = text
    resp.json.return_value = json_body or {}
    return resp


def _client(max_retries: int = 0) -> AptisClient:
    """Return a client that won't actually retry (keeps tests fast)."""
    return AptisClient(api_key="test_key", base_url="http://localhost:8082",
                       max_retries=max_retries)


def _good_signal(**kwargs):
    defaults = dict(symbol="AAPL", asset_class="equity",
                    quantity=100, side="BUY", signal_type="ENTRY")
    defaults.update(kwargs)
    return Signal(**defaults)


def _strategy_client(config=None, submit_ok=True):
    """Return a mock AptisClient pre-configured for Strategy tests."""
    c = MagicMock(spec=AptisClient)
    c.get_config.return_value = config or {
        "enabled": True, "nav": 1_000_000,
        "funds": 1_000_000, "portfolio_weight": 0.05,
    }
    c.get_positions.return_value = []
    if submit_ok:
        c.submit_signal.return_value = {"status": "success"}
    return c


class _SimpleStrategy(Strategy):
    """Minimal concrete strategy for testing."""

    def __init__(self, client, account="Theme", signals=None, dry_run=False):
        super().__init__("Test Strategy", client, account, dry_run=dry_run)
        self._signals = signals or []

    def generate_signals(self, run_date):
        return list(self._signals)


# ══════════════════════════════════════════════════════════════════════════════
# 1. Signal validation
# ══════════════════════════════════════════════════════════════════════════════

class TestSignalValidation:

    def test_valid_signal_constructs(self):
        s = Signal(symbol="AAPL", asset_class="equity",
                   quantity=100, side="BUY", signal_type="ENTRY")
        assert s.symbol == "AAPL"

    def test_quantity_zero_raises(self):
        with pytest.raises(ValidationError, match="quantity must be > 0"):
            Signal(symbol="X", asset_class="equity",
                   quantity=0, side="BUY", signal_type="ENTRY")

    def test_quantity_negative_raises(self):
        with pytest.raises(ValidationError, match="quantity must be > 0"):
            Signal(symbol="X", asset_class="equity",
                   quantity=-5, side="BUY", signal_type="ENTRY")

    def test_confidence_above_one_raises(self):
        with pytest.raises(ValidationError, match="confidence must be in"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="BUY", signal_type="ENTRY", confidence=1.1)

    def test_confidence_below_zero_raises(self):
        with pytest.raises(ValidationError, match="confidence must be in"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="BUY", signal_type="ENTRY", confidence=-0.1)

    def test_confidence_boundary_values_ok(self):
        Signal(symbol="X", asset_class="equity",
               quantity=1, side="BUY", signal_type="ENTRY", confidence=0.0)
        Signal(symbol="X", asset_class="equity",
               quantity=1, side="BUY", signal_type="ENTRY", confidence=1.0)

    def test_max_slippage_negative_raises(self):
        with pytest.raises(ValidationError, match="max_slippage_bps must be"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="BUY", signal_type="ENTRY", max_slippage_bps=-1)

    def test_max_slippage_zero_ok(self):
        Signal(symbol="X", asset_class="equity",
               quantity=1, side="BUY", signal_type="ENTRY", max_slippage_bps=0)

    def test_invalid_side_raises(self):
        with pytest.raises(ValidationError, match="side must be"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="LONG", signal_type="ENTRY")

    def test_invalid_signal_type_raises(self):
        with pytest.raises(ValidationError, match="signal_type must be"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="BUY", signal_type="OPEN")

    def test_unset_optionals_omitted_from_dict(self):
        s = Signal(symbol="AAPL", asset_class="equity",
                   quantity=100, side="BUY", signal_type="ENTRY")
        d = s.to_dict()
        for f in ("confidence", "urgency", "reduce_only", "tags",
                  "notional_usd", "broker_route", "metadata"):
            assert f not in d, f"{f} should be absent when unset"

    def test_backward_compat_metadata_dict(self):
        s = Signal(symbol="AAPL", asset_class="equity",
                   quantity=100, side="BUY", signal_type="ENTRY",
                   metadata={"rsi": 28.4, "reason": "oversold"})
        assert s.to_dict()["metadata"] == {"rsi": 28.4, "reason": "oversold"}


# ══════════════════════════════════════════════════════════════════════════════
# 2. AptisConfig validation
# ══════════════════════════════════════════════════════════════════════════════

class TestAptisConfig:

    def test_valid_config(self):
        cfg = AptisConfig(api_key="key123", base_url="http://localhost:8082")
        assert cfg.api_key == "key123"
        assert cfg.base_url == "http://localhost:8082"

    def test_trailing_slash_stripped(self):
        cfg = AptisConfig(api_key="k", base_url="http://localhost:8082/")
        assert cfg.base_url == "http://localhost:8082"

    def test_empty_api_key_raises(self):
        with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
            AptisConfig(api_key="")

    def test_whitespace_api_key_raises(self):
        with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
            AptisConfig(api_key="   ")

    def test_invalid_url_raises(self):
        with pytest.raises(ConfigurationError, match="APTIS_API_URL"):
            AptisConfig(api_key="k", base_url="localhost:8082")

    def test_zero_timeout_raises(self):
        with pytest.raises(ConfigurationError, match="timeout"):
            AptisConfig(api_key="k", timeout=0)

    def test_negative_retries_raises(self):
        with pytest.raises(ConfigurationError, match="max_retries"):
            AptisConfig(api_key="k", max_retries=-1)

    def test_from_env_reads_variables(self):
        env = {
            "APTIS_API_KEY": "env_key",
            "APTIS_API_URL": "http://prod:8082",
            "APTIS_ACCOUNT": "Theme",
            "APTIS_TIMEOUT": "60",
            "APTIS_MAX_RETRIES": "5",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = AptisConfig.from_env()
        assert cfg.api_key == "env_key"
        assert cfg.base_url == "http://prod:8082"
        assert cfg.account == "Theme"
        assert cfg.timeout == 60
        assert cfg.max_retries == 5

    def test_from_env_missing_key_raises(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
                AptisConfig.from_env()

    def test_from_env_empty_account_becomes_none(self):
        with patch.dict(os.environ, {"APTIS_API_KEY": "k", "APTIS_ACCOUNT": ""},
                        clear=False):
            cfg = AptisConfig.from_env()
        assert cfg.account is None


# ══════════════════════════════════════════════════════════════════════════════
# 3. AptisClient construction
# ══════════════════════════════════════════════════════════════════════════════

class TestClientConstruction:

    def test_direct_construction_backward_compat(self):
        client = AptisClient(api_key="k", base_url="http://localhost:8082")
        assert client.api_key == "k"
        assert client.base_url == "http://localhost:8082"

    def test_missing_api_key_raises(self):
        with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
            AptisClient(api_key="")

    def test_from_env(self):
        with patch.dict(os.environ, {"APTIS_API_KEY": "env_key",
                                     "APTIS_API_URL": "http://host:8082"}):
            client = AptisClient.from_env()
        assert client.api_key == "env_key"

    def test_from_env_missing_key_raises(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
                AptisClient.from_env()


# ══════════════════════════════════════════════════════════════════════════════
# 4. HTTP error mapping
# ══════════════════════════════════════════════════════════════════════════════

class TestHTTPErrorMapping:

    def test_200_returns_json(self):
        client = _client()
        resp = _mock_response(200, {"data": "ok"})
        with patch.object(client.session, "request", return_value=resp):
            result = client._request("GET", "/test")
        assert result == {"data": "ok"}

    def test_401_raises_authentication_error(self):
        client = _client()
        with patch.object(client.session, "request",
                          return_value=_mock_response(401)):
            with pytest.raises(AuthenticationError, match="APTIS_API_KEY"):
                client._request("GET", "/test")

    def test_403_raises_authentication_error(self):
        client = _client()
        with patch.object(client.session, "request",
                          return_value=_mock_response(403)):
            with pytest.raises(AuthenticationError, match="APTIS_ACCOUNT"):
                client._request("GET", "/test")

    def test_422_raises_validation_error(self):
        client = _client()
        resp = _mock_response(422, {"detail": "quantity must be positive"})
        with patch.object(client.session, "request", return_value=resp):
            with pytest.raises(ValidationError, match="422"):
                client._request("POST", "/test")

    def test_429_raises_rate_limit_error(self):
        client = _client()
        with patch.object(client.session, "request",
                          return_value=_mock_response(429)):
            with pytest.raises(RateLimitError):
                client._request("GET", "/test")

    def test_500_raises_server_error(self):
        client = _client()
        with patch.object(client.session, "request",
                          return_value=_mock_response(500)):
            with pytest.raises(ServerError) as exc_info:
                client._request("GET", "/test")
            assert exc_info.value.status_code == 500

    def test_503_raises_server_error(self):
        client = _client()
        with patch.object(client.session, "request",
                          return_value=_mock_response(503)):
            with pytest.raises(ServerError):
                client._request("GET", "/test")

    def test_404_raises_api_error(self):
        client = _client()
        with patch.object(client.session, "request",
                          return_value=_mock_response(404, text="not found")):
            with pytest.raises(APIError) as exc_info:
                client._request("GET", "/test")
            assert exc_info.value.status_code == 404

    def test_connection_error_raises_server_error(self):
        client = _client()
        with patch.object(client.session, "request",
                          side_effect=RequestsConnectionError("refused")):
            with pytest.raises(ServerError, match="connect"):
                client._request("GET", "/test")

    def test_timeout_raises_server_error(self):
        client = _client()
        with patch.object(client.session, "request", side_effect=Timeout()):
            with pytest.raises(ServerError, match="timed out"):
                client._request("GET", "/test")

    def test_aptis_api_error_is_base_alias(self):
        """AptisAPIError backward-compat alias catches all SDK errors."""
        client = _client()
        with patch.object(client.session, "request",
                          return_value=_mock_response(500)):
            with pytest.raises(AptisAPIError):
                client._request("GET", "/test")


# ══════════════════════════════════════════════════════════════════════════════
# 5. Retry configuration
# ══════════════════════════════════════════════════════════════════════════════

class TestRetryConfiguration:

    def test_retry_adapter_mounted(self):
        client = AptisClient(api_key="k", max_retries=3)
        http_adapter = client.session.get_adapter("http://")
        assert http_adapter.max_retries.total == 3

    def test_zero_retries_mounted(self):
        client = AptisClient(api_key="k", max_retries=0)
        http_adapter = client.session.get_adapter("http://")
        assert http_adapter.max_retries.total == 0

    def test_timeout_passed_to_request(self):
        client = AptisClient(api_key="k", timeout=45)
        resp = _mock_response(200, {})
        with patch.object(client.session, "request", return_value=resp) as mock_req:
            client._request("GET", "/test")
        _, kwargs = mock_req.call_args
        assert kwargs.get("timeout") == 45

    def test_custom_timeout_not_overridden_if_caller_provides(self):
        client = AptisClient(api_key="k", timeout=30)
        resp = _mock_response(200, {})
        with patch.object(client.session, "request", return_value=resp) as mock_req:
            client._request("GET", "/test", timeout=5)
        _, kwargs = mock_req.call_args
        assert kwargs.get("timeout") == 5


# ══════════════════════════════════════════════════════════════════════════════
# 6. submit_signal validation
# ══════════════════════════════════════════════════════════════════════════════

class TestSubmitSignalValidation:

    def test_missing_kwargs_raises_validation_error(self):
        client = _client()
        with pytest.raises(ValidationError, match="symbol, asset_class"):
            client.submit_signal(symbol="AAPL")

    def test_signal_object_accepted(self):
        client = _client()
        sig = Signal(symbol="AAPL", asset_class="equity",
                     quantity=100, side="BUY", signal_type="ENTRY")
        resp = _mock_response(200, {"status": "success"})
        with patch.object(client.session, "request", return_value=resp) as mock_req:
            client.submit_signal(sig, strategy_name="TEST", account="Theme")
        payload = mock_req.call_args.kwargs["json"]
        assert payload["symbol"] == "AAPL"
        assert payload["strategy_name"] == "TEST"
        assert payload["account"] == "Theme"

    def test_kwargs_form_accepted(self):
        client = _client()
        resp = _mock_response(200, {"status": "success"})
        with patch.object(client.session, "request", return_value=resp):
            result = client.submit_signal(
                symbol="MSFT", asset_class="equity",
                quantity=50, side="SELL", signal_type="EXIT",
                strategy_name="TEST", account="Theme",
            )
        assert result == {"status": "success"}


# ══════════════════════════════════════════════════════════════════════════════
# 7. Strategy lifecycle
# ══════════════════════════════════════════════════════════════════════════════

class TestStrategyLifecycle:

    def test_run_returns_expected_keys(self):
        s = _SimpleStrategy(_strategy_client(), signals=[_good_signal()])
        result = s.run(date.today())
        for key in ("date", "strategy", "dry_run", "enabled",
                    "signals_generated", "submitted", "skipped", "results"):
            assert key in result

    def test_run_submits_valid_signal(self):
        client = _strategy_client()
        sig = _good_signal()
        s = _SimpleStrategy(client, signals=[sig])
        result = s.run(date.today())
        assert result["submitted"] == 1
        assert result["skipped"] == 0
        client.submit_signal.assert_called_once_with(sig, "Test Strategy", "Theme")

    def test_run_skips_when_disabled(self):
        client = _strategy_client(config={"enabled": False})
        s = _SimpleStrategy(client, signals=[_good_signal()])
        result = s.run(date.today())
        assert result["enabled"] is False
        assert result["submitted"] == 0
        client.submit_signal.assert_not_called()

    def test_run_dry_run_does_not_submit(self):
        client = _strategy_client()
        s = _SimpleStrategy(client, signals=[_good_signal()], dry_run=True)
        result = s.run(date.today())
        assert result["dry_run"] is True
        assert result["submitted"] == 0
        assert result["skipped"] == 1
        client.submit_signal.assert_not_called()

    def test_before_run_called(self):
        s = _SimpleStrategy(_strategy_client())
        s.before_run = MagicMock()
        s.run(date.today())
        s.before_run.assert_called_once()

    def test_after_run_called_with_results(self):
        s = _SimpleStrategy(_strategy_client(), signals=[_good_signal()])
        s.after_run = MagicMock()
        result = s.run(date.today())
        s.after_run.assert_called_once()
        _, call_result = s.after_run.call_args[0]
        assert call_result is result

    def test_on_error_called_and_exception_reraised(self):
        s = _SimpleStrategy(_strategy_client())
        s.generate_signals = MagicMock(side_effect=RuntimeError("boom"))
        s.on_error = MagicMock()
        with pytest.raises(RuntimeError, match="boom"):
            s.run(date.today())
        s.on_error.assert_called_once()

    def test_invalid_signal_skipped_not_raised(self):
        """A signal that fails pre-submit validation is skipped; run() completes."""
        client = _strategy_client()
        bad = _good_signal()
        bad.quantity = -1   # mutate after construction to bypass __post_init__
        s = _SimpleStrategy(client, signals=[bad])
        result = s.run(date.today())
        assert result["skipped"] == 1
        assert result["submitted"] == 0
        client.submit_signal.assert_not_called()

    def test_mixed_valid_and_invalid_signals(self):
        client = _strategy_client()
        good = _good_signal()
        bad = _good_signal(symbol="BAD")
        bad.quantity = 0    # mutate to make invalid
        s = _SimpleStrategy(client, signals=[good, bad])
        result = s.run(date.today())
        assert result["submitted"] == 1
        assert result["skipped"] == 1

    def test_multiple_signals_all_submitted(self):
        client = _strategy_client()
        signals = [_good_signal(symbol=sym) for sym in ["AAPL", "MSFT", "GOOGL"]]
        s = _SimpleStrategy(client, signals=signals)
        result = s.run(date.today())
        assert result["submitted"] == 3
        assert result["skipped"] == 0
        assert client.submit_signal.call_count == 3


# ══════════════════════════════════════════════════════════════════════════════
# 8. Strategy helpers
# ══════════════════════════════════════════════════════════════════════════════

class TestStrategyHelpers:

    def test_get_config_delegates_to_client(self):
        client = _strategy_client()
        s = _SimpleStrategy(client)
        cfg = s.get_config()
        assert cfg["enabled"] is True
        client.get_config.assert_called_once_with("Test Strategy")

    def test_is_enabled_true(self):
        assert _SimpleStrategy(_strategy_client(config={"enabled": True})).is_enabled() is True

    def test_is_enabled_false(self):
        assert _SimpleStrategy(_strategy_client(config={"enabled": False})).is_enabled() is False

    def test_is_enabled_defaults_true_on_api_error(self):
        client = _strategy_client()
        client.get_config.side_effect = ServerError("unreachable")
        assert _SimpleStrategy(client).is_enabled() is True

    def test_get_account(self):
        s = _SimpleStrategy(_strategy_client(), account="Theme")
        assert s.get_account() == "Theme"

    def test_logger_attached(self):
        import logging
        s = _SimpleStrategy(_strategy_client())
        assert isinstance(s.logger, logging.Logger)
        assert "Test Strategy" in s.logger.name

    def test_dry_run_flag_propagates(self):
        s = _SimpleStrategy(_strategy_client(), dry_run=True)
        assert s.dry_run is True

    def test_get_positions_delegates_to_client(self):
        client = _strategy_client()
        s = _SimpleStrategy(client)
        s.get_positions()
        client.get_positions.assert_called_once_with("Theme", "Test Strategy")

    def test_get_features_delegates_to_client(self):
        client = _strategy_client()
        client.get_features.return_value = {}
        s = _SimpleStrategy(client)
        today = date.today()
        s.get_features(["AAPL"], today, ["rsi_14"])
        client.get_features.assert_called_once_with(["AAPL"], today, ["rsi_14"])


# ══════════════════════════════════════════════════════════════════════════════
# 9. _validate_signal helper
# ══════════════════════════════════════════════════════════════════════════════

class TestValidateSignalHelper:

    def test_valid_signal_passes(self):
        _validate_signal(_good_signal())  # must not raise

    def test_empty_symbol_raises(self):
        s = _good_signal()
        s.symbol = ""
        with pytest.raises(ValidationError, match="symbol"):
            _validate_signal(s)

    def test_whitespace_symbol_raises(self):
        s = _good_signal()
        s.symbol = "   "
        with pytest.raises(ValidationError, match="symbol"):
            _validate_signal(s)

    def test_empty_asset_class_raises(self):
        s = _good_signal()
        s.asset_class = "  "
        with pytest.raises(ValidationError, match="asset_class"):
            _validate_signal(s)

    def test_zero_quantity_raises(self):
        s = _good_signal()
        s.quantity = 0
        with pytest.raises(ValidationError, match="quantity"):
            _validate_signal(s)

    def test_negative_quantity_raises(self):
        s = _good_signal()
        s.quantity = -10
        with pytest.raises(ValidationError, match="quantity"):
            _validate_signal(s)

    def test_bad_side_raises(self):
        s = _good_signal()
        s.side = "LONG"
        with pytest.raises(ValidationError, match="side"):
            _validate_signal(s)

    def test_bad_signal_type_raises(self):
        s = _good_signal()
        s.signal_type = "OPEN"
        with pytest.raises(ValidationError, match="signal_type"):
            _validate_signal(s)

    def test_confidence_out_of_range_raises(self):
        s = _good_signal()
        s.confidence = 1.5
        with pytest.raises(ValidationError, match="confidence"):
            _validate_signal(s)

    def test_negative_slippage_raises(self):
        s = _good_signal()
        s.max_slippage_bps = -1
        with pytest.raises(ValidationError, match="max_slippage_bps"):
            _validate_signal(s)
