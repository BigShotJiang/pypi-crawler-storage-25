"""Tests: Strategy lifecycle, helpers, and _validate_signal."""
import logging
import pytest
from datetime import date
from unittest.mock import MagicMock

from aptis_strategy_sdk.strategy import _validate_signal
from aptis_strategy_sdk.exceptions import ValidationError, ServerError
from tests.conftest import good_signal, mock_client, SimpleStrategy


class TestStrategyLifecycle:

    def test_run_returns_expected_keys(self):
        s = SimpleStrategy(mock_client(), signals=[good_signal()])
        result = s.run(date.today())
        for key in ("date", "strategy", "dry_run", "enabled",
                    "signals_generated", "submitted", "skipped", "results"):
            assert key in result

    def test_run_submits_valid_signal(self):
        client = mock_client()
        sig = good_signal()
        s = SimpleStrategy(client, signals=[sig])
        result = s.run(date.today())
        assert result["submitted"] == 1
        assert result["skipped"] == 0
        client.submit_signal.assert_called_once_with(sig, "Test Strategy", "Theme")

    def test_run_skips_when_disabled(self):
        client = mock_client(config={"enabled": False})
        s = SimpleStrategy(client, signals=[good_signal()])
        result = s.run(date.today())
        assert result["enabled"] is False
        assert result["submitted"] == 0
        client.submit_signal.assert_not_called()

    def test_run_dry_run_does_not_submit(self):
        client = mock_client()
        s = SimpleStrategy(client, signals=[good_signal()], dry_run=True)
        result = s.run(date.today())
        assert result["dry_run"] is True
        assert result["submitted"] == 0
        assert result["skipped"] == 1
        client.submit_signal.assert_not_called()

    def test_before_run_called(self):
        s = SimpleStrategy(mock_client())
        s.before_run = MagicMock()
        s.run(date.today())
        s.before_run.assert_called_once()

    def test_after_run_called_with_result_dict(self):
        s = SimpleStrategy(mock_client(), signals=[good_signal()])
        s.after_run = MagicMock()
        result = s.run(date.today())
        s.after_run.assert_called_once()
        _, call_result = s.after_run.call_args[0]
        assert call_result is result

    def test_on_error_called_and_exception_reraised(self):
        s = SimpleStrategy(mock_client())
        s.generate_signals = MagicMock(side_effect=RuntimeError("boom"))
        s.on_error = MagicMock()
        with pytest.raises(RuntimeError, match="boom"):
            s.run(date.today())
        s.on_error.assert_called_once()

    def test_invalid_signal_skipped_run_completes(self):
        client = mock_client()
        bad = good_signal()
        bad.quantity = -1       # mutate past __post_init__
        s = SimpleStrategy(client, signals=[bad])
        result = s.run(date.today())
        assert result["skipped"] == 1
        assert result["submitted"] == 0
        client.submit_signal.assert_not_called()

    def test_mixed_valid_and_invalid_signals(self):
        client = mock_client()
        bad = good_signal(symbol="BAD")
        bad.quantity = 0
        s = SimpleStrategy(client, signals=[good_signal(), bad])
        result = s.run(date.today())
        assert result["submitted"] == 1
        assert result["skipped"] == 1

    def test_multiple_signals_all_submitted(self):
        client = mock_client()
        signals = [good_signal(symbol=sym) for sym in ["AAPL", "MSFT", "GOOGL"]]
        s = SimpleStrategy(client, signals=signals)
        result = s.run(date.today())
        assert result["submitted"] == 3
        assert client.submit_signal.call_count == 3


class TestStrategyHelpers:

    def test_get_config_delegates_to_client(self):
        client = mock_client()
        s = SimpleStrategy(client)
        cfg = s.get_config()
        assert cfg["enabled"] is True
        client.get_config.assert_called_once_with("Test Strategy")

    def test_is_enabled_true(self):
        assert SimpleStrategy(mock_client(config={"enabled": True})).is_enabled() is True

    def test_is_enabled_false(self):
        assert SimpleStrategy(mock_client(config={"enabled": False})).is_enabled() is False

    def test_is_enabled_defaults_true_on_api_error(self):
        client = mock_client()
        client.get_config.side_effect = ServerError("unreachable")
        assert SimpleStrategy(client).is_enabled() is True

    def test_get_account(self):
        assert SimpleStrategy(mock_client(), account="Theme").get_account() == "Theme"

    def test_logger_attached(self):
        s = SimpleStrategy(mock_client())
        assert isinstance(s.logger, logging.Logger)
        assert "Test Strategy" in s.logger.name

    def test_dry_run_flag_propagates(self):
        assert SimpleStrategy(mock_client(), dry_run=True).dry_run is True

    def test_get_positions_delegates_to_client(self):
        client = mock_client()
        SimpleStrategy(client).get_positions()
        client.get_positions.assert_called_once_with("Theme", "Test Strategy")

    def test_get_features_delegates_to_client(self):
        client = mock_client()
        client.get_features.return_value = {}
        today = date.today()
        SimpleStrategy(client).get_features(["AAPL"], today, ["rsi_14"])
        client.get_features.assert_called_once_with(["AAPL"], today, ["rsi_14"])


class TestValidateSignalHelper:

    def test_valid_signal_passes(self):
        _validate_signal(good_signal())

    def test_empty_symbol_raises(self):
        s = good_signal(); s.symbol = ""
        with pytest.raises(ValidationError, match="symbol"):
            _validate_signal(s)

    def test_whitespace_symbol_raises(self):
        s = good_signal(); s.symbol = "   "
        with pytest.raises(ValidationError, match="symbol"):
            _validate_signal(s)

    def test_empty_asset_class_raises(self):
        s = good_signal(); s.asset_class = "  "
        with pytest.raises(ValidationError, match="asset_class"):
            _validate_signal(s)

    def test_zero_quantity_raises(self):
        s = good_signal(); s.quantity = 0
        with pytest.raises(ValidationError, match="quantity"):
            _validate_signal(s)

    def test_negative_quantity_raises(self):
        s = good_signal(); s.quantity = -10
        with pytest.raises(ValidationError, match="quantity"):
            _validate_signal(s)

    def test_bad_side_raises(self):
        s = good_signal(); s.side = "LONG"
        with pytest.raises(ValidationError, match="side"):
            _validate_signal(s)

    def test_bad_signal_type_raises(self):
        s = good_signal(); s.signal_type = "OPEN"
        with pytest.raises(ValidationError, match="signal_type"):
            _validate_signal(s)

    def test_confidence_out_of_range_raises(self):
        s = good_signal(); s.confidence = 1.5
        with pytest.raises(ValidationError, match="confidence"):
            _validate_signal(s)

    def test_negative_slippage_raises(self):
        s = good_signal(); s.max_slippage_bps = -1
        with pytest.raises(ValidationError, match="max_slippage_bps"):
            _validate_signal(s)
