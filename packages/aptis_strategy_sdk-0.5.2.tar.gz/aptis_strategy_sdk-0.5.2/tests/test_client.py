"""Tests: AptisClient construction, HTTP error mapping, retry, submit_signal."""
import os
import pytest
from unittest.mock import patch
from requests.exceptions import ConnectionError as RequestsConnectionError, Timeout

from aptis_strategy_sdk.client import AptisClient
from aptis_strategy_sdk.models import Signal
from aptis_strategy_sdk.exceptions import (
    AuthenticationError, ConfigurationError, ValidationError,
    APIError, RateLimitError, ServerError, AptisAPIError,
)
from tests.conftest import bare_client, mock_response


class TestClientConstruction:

    def test_direct_construction_backward_compat(self):
        client = AptisClient(api_key="k", base_url="http://localhost:8082")
        assert client.api_key == "k"
        assert client.base_url == "http://localhost:8082"

    def test_missing_api_key_raises(self):
        with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
            AptisClient(api_key="")

    def test_from_env(self):
        with patch.dict(os.environ, {"APTIS_API_KEY": "env_key",
                                     "APTIS_API_URL": "http://host:8082"}):
            client = AptisClient.from_env()
        assert client.api_key == "env_key"

    def test_from_env_missing_key_raises(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
                AptisClient.from_env()


class TestHTTPErrorMapping:

    def test_200_returns_json(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(200, {"data": "ok"})):
            assert client._request("GET", "/test") == {"data": "ok"}

    def test_401_raises_authentication_error(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(401)):
            with pytest.raises(AuthenticationError, match="APTIS_API_KEY"):
                client._request("GET", "/test")

    def test_403_raises_authentication_error(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(403)):
            with pytest.raises(AuthenticationError, match="APTIS_ACCOUNT"):
                client._request("GET", "/test")

    def test_422_raises_validation_error(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(422, {"detail": "bad qty"})):
            with pytest.raises(ValidationError, match="422"):
                client._request("POST", "/test")

    def test_429_raises_rate_limit_error(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(429)):
            with pytest.raises(RateLimitError):
                client._request("GET", "/test")

    def test_500_raises_server_error_with_status_code(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(500)):
            with pytest.raises(ServerError) as exc_info:
                client._request("GET", "/test")
        assert exc_info.value.status_code == 500

    def test_503_raises_server_error(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(503)):
            with pytest.raises(ServerError):
                client._request("GET", "/test")

    def test_404_raises_api_error_with_status_code(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(404, text="not found")):
            with pytest.raises(APIError) as exc_info:
                client._request("GET", "/test")
        assert exc_info.value.status_code == 404

    def test_connection_error_raises_server_error(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          side_effect=RequestsConnectionError("refused")):
            with pytest.raises(ServerError, match="connect"):
                client._request("GET", "/test")

    def test_timeout_raises_server_error(self):
        client = bare_client()
        with patch.object(client.session, "request", side_effect=Timeout()):
            with pytest.raises(ServerError, match="timed out"):
                client._request("GET", "/test")

    def test_aptis_api_error_alias_catches_all(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(500)):
            with pytest.raises(AptisAPIError):
                client._request("GET", "/test")


class TestRetryConfiguration:

    def test_retry_adapter_mounted(self):
        client = AptisClient(api_key="k", max_retries=3)
        assert client.session.get_adapter("http://").max_retries.total == 3

    def test_zero_retries_mounted(self):
        client = AptisClient(api_key="k", max_retries=0)
        assert client.session.get_adapter("http://").max_retries.total == 0

    def test_timeout_passed_to_request(self):
        client = AptisClient(api_key="k", timeout=45)
        with patch.object(client.session, "request",
                          return_value=mock_response(200, {})) as mock_req:
            client._request("GET", "/test")
        assert mock_req.call_args.kwargs.get("timeout") == 45

    def test_caller_timeout_not_overridden(self):
        client = AptisClient(api_key="k", timeout=30)
        with patch.object(client.session, "request",
                          return_value=mock_response(200, {})) as mock_req:
            client._request("GET", "/test", timeout=5)
        assert mock_req.call_args.kwargs.get("timeout") == 5


class TestSubmitSignal:

    def test_missing_kwargs_raises_validation_error(self):
        client = bare_client()
        with pytest.raises(ValidationError, match="symbol, asset_class"):
            client.submit_signal(symbol="AAPL")

    def test_signal_object_serialised_correctly(self):
        client = bare_client()
        sig = Signal(symbol="AAPL", asset_class="equity",
                     quantity=100, side="BUY", signal_type="ENTRY")
        with patch.object(client.session, "request",
                          return_value=mock_response(200, {"status": "success"})) as mock_req:
            client.submit_signal(sig, strategy_name="TEST", account="Theme")
        payload = mock_req.call_args.kwargs["json"]
        assert payload["symbol"] == "AAPL"
        assert payload["strategy_name"] == "TEST"
        assert payload["account"] == "Theme"

    def test_kwargs_form_accepted(self):
        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=mock_response(200, {"status": "success"})):
            result = client.submit_signal(
                symbol="MSFT", asset_class="equity",
                quantity=50, side="SELL", signal_type="EXIT",
                strategy_name="TEST", account="Theme",
            )
        assert result == {"status": "success"}
