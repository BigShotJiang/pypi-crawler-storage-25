"""
Integration tests: end-to-end flows with fully mocked HTTP.

Call order inside run():
  1. is_enabled() → GET /config          (always first)
  2. generate_signals() → any HTTP calls
  3. submit_signals() → POST /signals/submit × N

get_config() inside generate_signals() is served from the client's
_config_cache, so it does NOT produce a second HTTP call.

Author: Richard Chung
"""
import json
import pytest
from datetime import date
from unittest.mock import patch, MagicMock

from aptis_strategy_sdk import (
    AptisClient, Strategy, Signal,
    RegimeMetadata, FactorScoreMetadata,
    StrategyAnalytics,
)
from aptis_strategy_sdk.exceptions import (
    AptisError, AuthenticationError, ServerError,
)
from tests.conftest import bare_client, mock_response, make_fill, make_position


# ── Helpers ────────────────────────────────────────────────────────────────────

def _ok(body: dict):
    return mock_response(200, body)


def _config(enabled=True, nav=1_000_000, weight=0.05):
    return _ok({"config": {"enabled": enabled, "nav": nav,
                            "portfolio_weight": weight}})


def _features(**symbols_momentum):
    return _ok({"data": {sym: {"momentum_20d": mom}
                          for sym, mom in symbols_momentum.items()}})


def _positions(*rows):
    return _ok({"positions": list(rows)})


def _submit(trade_id=1):
    return _ok({"status": "success", "trade_id": trade_id})


def _pos_row(symbol, qty, price=150.0, upnl=0.0):
    return {"symbol": symbol, "asset_class": "equity", "quantity": qty,
            "avg_entry_price": price, "current_price": price,
            "unrealized_pnl": upnl, "realized_pnl": 0.0}


# ── Concrete strategy for integration tests ────────────────────────────────────

class _MomentumStrategy(Strategy):
    """
    Minimal momentum strategy using a real AptisClient.

    HTTP call order per run():
      1. GET /config          ← is_enabled() inside run()
      2. GET /features        ← generate_signals
      3. GET /positions       ← generate_signals
      (GET /config cached — no extra call)
      4. POST /signals/submit × N
    """

    def __init__(self, client, account="Theme", dry_run=False):
        super().__init__("Momentum Strategy", client, account, dry_run=dry_run)

    def generate_signals(self, run_date: date):
        features  = self.get_features(["AAPL", "MSFT"], run_date, ["momentum_20d"])
        positions = self.get_positions()
        open_syms = {p.symbol for p in positions}
        config    = self.get_config()          # served from cache — no HTTP call
        nav       = config.get("nav", 1_000_000)
        weight    = config.get("portfolio_weight", 0.05)

        signals = []
        for symbol, data in features.items():
            mom = data.get("momentum_20d", 0)
            if mom > 0.02 and symbol not in open_syms:
                signals.append(Signal(
                    symbol=symbol, asset_class="equity",
                    quantity=round(nav * weight / 150, 2),
                    side="BUY", signal_type="ENTRY",
                    confidence=min(mom / 0.08, 1.0),
                    metadata={
                        "rationale": f"{symbol} momentum {mom:.2%}",
                        "regime": RegimeMetadata(label="BULL").to_dict(),
                        "feature_snapshot": {"momentum_20d": mom},
                    },
                ))
        return signals


class _ExitStrategy(Strategy):
    """
    Strategy that exits every open position.

    HTTP call order per run():
      1. GET /config          ← is_enabled()
      2. GET /positions       ← generate_signals
      3. POST /signals/submit × N
    """

    def __init__(self, client, account="Theme", dry_run=False):
        super().__init__("Exit Strategy", client, account, dry_run=dry_run)

    def generate_signals(self, run_date: date):
        return [
            Signal(
                symbol=p.symbol, asset_class="equity",
                quantity=abs(p.quantity), side="SELL",
                signal_type="EXIT",
                metadata={"reason": "momentum_reversal"},
            )
            for p in self.get_positions()
        ]


# ══════════════════════════════════════════════════════════════════════════════
# 1. ENTRY cycle
# ══════════════════════════════════════════════════════════════════════════════

class TestEntryCycle:

    def test_two_entry_signals_submitted(self):
        client = bare_client()
        # config → features → positions → submit × 2
        client.session.request = MagicMock(side_effect=[
            _config(),
            _features(AAPL=0.05, MSFT=0.03),
            _positions(),
            _submit(101),
            _submit(102),
        ])

        result = _MomentumStrategy(client).run(date.today())

        assert result["submitted"] == 2
        assert result["skipped"]   == 0

    def test_entry_payload_is_correct(self):
        client = bare_client()
        client.session.request = MagicMock(side_effect=[
            _config(),
            _features(AAPL=0.05),
            _positions(),
            _submit(101),
        ])

        _MomentumStrategy(client).run(date.today())

        submit_calls = [c for c in client.session.request.call_args_list
                        if "/signals/submit" in str(c)]
        payload = submit_calls[0].kwargs["json"]
        assert payload["signal_type"]                    == "ENTRY"
        assert payload["side"]                           == "BUY"
        assert payload["confidence"]                     > 0
        assert payload["metadata"]["regime"]["label"]    == "BULL"
        assert payload["metadata"]["feature_snapshot"]["momentum_20d"] == 0.05

    def test_entry_skipped_when_already_in_position(self):
        client = bare_client()
        # AAPL already open → only MSFT submitted
        client.session.request = MagicMock(side_effect=[
            _config(),
            _features(AAPL=0.05, MSFT=0.03),
            _positions(_pos_row("AAPL", 100)),
            _submit(103),
        ])

        result = _MomentumStrategy(client).run(date.today())

        assert result["submitted"] == 1

    def test_no_signals_when_momentum_below_threshold(self):
        client = bare_client()
        client.session.request = MagicMock(side_effect=[
            _config(),
            _features(AAPL=0.005, MSFT=-0.01),
            _positions(),
        ])

        result = _MomentumStrategy(client).run(date.today())

        assert result["submitted"]         == 0
        assert result["signals_generated"] == 0


# ══════════════════════════════════════════════════════════════════════════════
# 2. EXIT cycle
# ══════════════════════════════════════════════════════════════════════════════

class TestExitCycle:

    def test_exit_uses_position_quantity(self):
        client = bare_client()
        # config → positions → submit
        client.session.request = MagicMock(side_effect=[
            _config(),
            _positions(_pos_row("AAPL", 75, price=152.0, upnl=300.0)),
            _submit(201),
        ])

        result = _ExitStrategy(client).run(date.today())

        assert result["submitted"] == 1
        submit_calls = [c for c in client.session.request.call_args_list
                        if "/signals/submit" in str(c)]
        payload = submit_calls[0].kwargs["json"]
        assert payload["signal_type"] == "EXIT"
        assert payload["quantity"]    == 75
        assert payload["side"]        == "SELL"

    def test_exit_metadata_included(self):
        client = bare_client()
        client.session.request = MagicMock(side_effect=[
            _config(),
            _positions(_pos_row("MSFT", 50, price=295.0, upnl=-250.0)),
            _submit(202),
        ])

        _ExitStrategy(client).run(date.today())

        submit_calls = [c for c in client.session.request.call_args_list
                        if "/signals/submit" in str(c)]
        assert submit_calls[0].kwargs["json"]["metadata"]["reason"] == "momentum_reversal"

    def test_no_exit_when_no_positions(self):
        client = bare_client()
        client.session.request = MagicMock(side_effect=[
            _config(),
            _positions(),
        ])

        result = _ExitStrategy(client).run(date.today())

        assert result["submitted"]         == 0
        assert result["signals_generated"] == 0


# ══════════════════════════════════════════════════════════════════════════════
# 3. Dry-run mode
# ══════════════════════════════════════════════════════════════════════════════

class TestDryRunMode:

    def test_dry_run_makes_no_submit_calls(self):
        client = bare_client()
        # config → features → positions  (no submit calls)
        client.session.request = MagicMock(side_effect=[
            _config(),
            _features(AAPL=0.05, MSFT=0.04),
            _positions(),
        ])

        result = _MomentumStrategy(client, dry_run=True).run(date.today())

        assert result["dry_run"]   is True
        assert result["submitted"] == 0
        assert result["skipped"]   == 2
        submit_calls = [c for c in client.session.request.call_args_list
                        if "/signals/submit" in str(c)]
        assert len(submit_calls) == 0

    def test_dry_run_validates_and_skips_invalid_signals(self):
        class BadSignalStrategy(Strategy):
            def generate_signals(self, run_date):
                s = Signal(symbol="AAPL", asset_class="equity",
                           quantity=100, side="BUY", signal_type="ENTRY")
                s.quantity = -1   # corrupt after construction
                return [s]

        client = bare_client()
        client.session.request = MagicMock(return_value=_config())

        result = BadSignalStrategy("Bad", client, "Theme", dry_run=True).run(date.today())

        assert result["skipped"]   == 1
        assert result["submitted"] == 0


# ══════════════════════════════════════════════════════════════════════════════
# 4. Disabled guard
# ══════════════════════════════════════════════════════════════════════════════

class TestDisabledGuard:

    def test_disabled_strategy_skips_generate_and_submit(self):
        client = bare_client()
        client.session.request = MagicMock(return_value=_config(enabled=False))

        generate_called = []

        class TrackedStrategy(Strategy):
            def generate_signals(self, run_date):
                generate_called.append(run_date)
                return []

        result = TrackedStrategy("T", client, "Theme").run(date.today())

        assert result["enabled"]   is False
        assert result["submitted"] == 0
        assert generate_called     == []
        submit_calls = [c for c in client.session.request.call_args_list
                        if "/signals/submit" in str(c)]
        assert len(submit_calls) == 0


# ══════════════════════════════════════════════════════════════════════════════
# 5. Error propagation
# ══════════════════════════════════════════════════════════════════════════════

class TestErrorPropagation:

    def test_401_from_submit_raises_authentication_error(self):
        client = bare_client()
        # config → features → positions → submit (401)
        client.session.request = MagicMock(side_effect=[
            _config(),
            _features(AAPL=0.05),
            _positions(),
            mock_response(401),
        ])

        with pytest.raises(AuthenticationError):
            _MomentumStrategy(client).run(date.today())

    def test_500_from_submit_raises_server_error(self):
        client = bare_client()
        # config → features → positions → submit (500)
        client.session.request = MagicMock(side_effect=[
            _config(),
            _features(AAPL=0.05),
            _positions(),
            mock_response(500),
        ])

        with pytest.raises(ServerError):
            _MomentumStrategy(client).run(date.today())

    def test_on_error_hook_receives_exception(self):
        client = bare_client()
        client.session.request = MagicMock(return_value=_config())

        received = []

        class HookedStrategy(Strategy):
            def generate_signals(self, run_date):
                raise RuntimeError("data unavailable")

            def on_error(self, run_date, exc):
                received.append(exc)

        with pytest.raises(RuntimeError, match="data unavailable"):
            HookedStrategy("H", client, "Theme").run(date.today())

        assert len(received) == 1
        assert isinstance(received[0], RuntimeError)

    def test_aptis_error_base_catches_all_sdk_errors(self):
        client = bare_client()
        client.session.request = MagicMock(return_value=mock_response(401))

        with pytest.raises(AptisError):
            client._request("GET", "/test")


# ══════════════════════════════════════════════════════════════════════════════
# 6. StrategyAnalytics end-to-end
# ══════════════════════════════════════════════════════════════════════════════

class TestStrategyAnalyticsIntegration:

    def _analytics_client(self, fills=None, positions=None, pnl=None):
        client = MagicMock(spec=AptisClient)
        client.get_trade_fills.return_value = fills     or []
        client.get_positions.return_value   = positions or []
        client.get_pnl.return_value         = pnl       or {"total_realized_pnl": 0.0}
        return client

    def test_diagnostics_fill_rate_and_pnl(self):
        fills = [
            make_fill(status="CLOSED", realized_pnl=200.0),
            make_fill(status="CLOSED", realized_pnl=-50.0),
            make_fill(status="REJECTED"),
        ]
        client    = self._analytics_client(
            fills=fills,
            positions=[make_position(unrealized_pnl=100.0)],
            pnl={"total_realized_pnl": 150.0},
        )
        diag = StrategyAnalytics(client, "Theme", "TEST").diagnostics()

        assert round(diag.fill_rate, 4)   == round(2 / 3, 4)
        assert diag.total_realized_pnl    == 150.0
        assert diag.total_unrealized_pnl  == 100.0
        assert diag.total_pnl             == 250.0

    def test_diagnostics_win_rate(self):
        fills = [
            make_fill(direction="EXIT", realized_pnl=100.0),
            make_fill(direction="EXIT", realized_pnl=50.0),
            make_fill(direction="EXIT", realized_pnl=-30.0),
        ]
        diag = StrategyAnalytics(
            self._analytics_client(fills=fills), "Theme", "TEST"
        ).diagnostics()

        assert round(diag.win_rate, 4) == round(2 / 3, 4)

    def test_diagnostics_exposure(self):
        positions = [
            make_position(symbol="AAPL", quantity=100,  current_price=150.0),
            make_position(symbol="MSFT", quantity=-50,  current_price=300.0),
        ]
        diag = StrategyAnalytics(
            self._analytics_client(positions=positions), "Theme", "TEST"
        ).diagnostics()

        assert diag.long_exposure_usd  == 15_000.0
        assert diag.short_exposure_usd == 15_000.0
        assert diag.gross_exposure_usd == 30_000.0
        assert diag.net_exposure_usd   == 0.0
        assert diag.position_count     == 2

    def test_diagnostics_no_data_safe_defaults(self):
        diag = StrategyAnalytics(
            self._analytics_client(), "Theme", "TEST"
        ).diagnostics()

        assert diag.fill_rate          == 0.0
        assert diag.win_rate           is None
        assert diag.signal_hit_rate    is None
        assert diag.total_pnl          == 0.0
        assert diag.gross_exposure_usd == 0.0


# ══════════════════════════════════════════════════════════════════════════════
# 7. Metadata round-trip through HTTP payload
# ══════════════════════════════════════════════════════════════════════════════

class TestMetadataRoundTrip:

    def test_structured_metadata_survives_json_serialisation(self):
        sig = Signal(
            symbol="AAPL", asset_class="equity",
            quantity=100, side="BUY", signal_type="ENTRY",
            metadata={
                "rationale":     "Test rationale.",
                "regime":        RegimeMetadata(label="BULL", confidence=0.78,
                                                indicators={"adx": 31.2}).to_dict(),
                "factor_scores": FactorScoreMetadata(momentum=0.84).to_dict(),
                "model_version": "test-v1.0",
            },
        )

        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=_ok({"status": "success"})) as mock_req:
            client.submit_signal(sig, strategy_name="TEST", account="Theme")

        raw     = mock_req.call_args.kwargs["json"]
        parsed  = json.loads(json.dumps(raw))   # round-trip must not raise

        assert parsed["metadata"]["regime"]["label"]           == "BULL"
        assert parsed["metadata"]["factor_scores"]["momentum"] == 0.84
        assert parsed["metadata"]["model_version"]             == "test-v1.0"

    def test_signal_without_metadata_omits_key(self):
        sig = Signal(symbol="AAPL", asset_class="equity",
                     quantity=100, side="BUY", signal_type="ENTRY")

        client = bare_client()
        with patch.object(client.session, "request",
                          return_value=_ok({"status": "success"})) as mock_req:
            client.submit_signal(sig, strategy_name="TEST", account="Theme")

        assert "metadata" not in mock_req.call_args.kwargs["json"]
