"""Tests: Signal validation and AptisConfig — no HTTP, no backend."""
import os
import pytest
from unittest.mock import patch

from aptis_strategy_sdk.models import Signal, AptisConfig
from aptis_strategy_sdk.exceptions import ConfigurationError, ValidationError


class TestSignalValidation:

    def test_valid_signal_constructs(self):
        s = Signal(symbol="AAPL", asset_class="equity",
                   quantity=100, side="BUY", signal_type="ENTRY")
        assert s.symbol == "AAPL"

    def test_quantity_zero_raises(self):
        with pytest.raises(ValidationError, match="quantity must be > 0"):
            Signal(symbol="X", asset_class="equity",
                   quantity=0, side="BUY", signal_type="ENTRY")

    def test_quantity_negative_raises(self):
        with pytest.raises(ValidationError, match="quantity must be > 0"):
            Signal(symbol="X", asset_class="equity",
                   quantity=-5, side="BUY", signal_type="ENTRY")

    def test_confidence_above_one_raises(self):
        with pytest.raises(ValidationError, match="confidence must be in"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="BUY", signal_type="ENTRY", confidence=1.1)

    def test_confidence_below_zero_raises(self):
        with pytest.raises(ValidationError, match="confidence must be in"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="BUY", signal_type="ENTRY", confidence=-0.1)

    def test_confidence_boundary_values_ok(self):
        Signal(symbol="X", asset_class="equity",
               quantity=1, side="BUY", signal_type="ENTRY", confidence=0.0)
        Signal(symbol="X", asset_class="equity",
               quantity=1, side="BUY", signal_type="ENTRY", confidence=1.0)

    def test_max_slippage_negative_raises(self):
        with pytest.raises(ValidationError, match="max_slippage_bps must be"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="BUY", signal_type="ENTRY", max_slippage_bps=-1)

    def test_max_slippage_zero_ok(self):
        Signal(symbol="X", asset_class="equity",
               quantity=1, side="BUY", signal_type="ENTRY", max_slippage_bps=0)

    def test_invalid_side_raises(self):
        with pytest.raises(ValidationError, match="side must be"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="LONG", signal_type="ENTRY")

    def test_invalid_signal_type_raises(self):
        with pytest.raises(ValidationError, match="signal_type must be"):
            Signal(symbol="X", asset_class="equity",
                   quantity=1, side="BUY", signal_type="OPEN")

    def test_unset_optionals_omitted_from_dict(self):
        s = Signal(symbol="AAPL", asset_class="equity",
                   quantity=100, side="BUY", signal_type="ENTRY")
        d = s.to_dict()
        for f in ("confidence", "urgency", "reduce_only", "tags",
                  "notional_usd", "broker_route", "metadata"):
            assert f not in d, f"{f} should be absent when unset"

    def test_backward_compat_metadata_dict(self):
        s = Signal(symbol="AAPL", asset_class="equity",
                   quantity=100, side="BUY", signal_type="ENTRY",
                   metadata={"rsi": 28.4, "reason": "oversold"})
        assert s.to_dict()["metadata"] == {"rsi": 28.4, "reason": "oversold"}


class TestAptisConfig:

    def test_valid_config(self):
        cfg = AptisConfig(api_key="key123", base_url="http://localhost:8082")
        assert cfg.api_key == "key123"
        assert cfg.base_url == "http://localhost:8082"

    def test_trailing_slash_stripped(self):
        cfg = AptisConfig(api_key="k", base_url="http://localhost:8082/")
        assert cfg.base_url == "http://localhost:8082"

    def test_empty_api_key_raises(self):
        with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
            AptisConfig(api_key="")

    def test_whitespace_api_key_raises(self):
        with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
            AptisConfig(api_key="   ")

    def test_invalid_url_raises(self):
        with pytest.raises(ConfigurationError, match="APTIS_API_URL"):
            AptisConfig(api_key="k", base_url="localhost:8082")

    def test_zero_timeout_raises(self):
        with pytest.raises(ConfigurationError, match="timeout"):
            AptisConfig(api_key="k", timeout=0)

    def test_negative_retries_raises(self):
        with pytest.raises(ConfigurationError, match="max_retries"):
            AptisConfig(api_key="k", max_retries=-1)

    def test_from_env_reads_variables(self):
        env = {
            "APTIS_API_KEY": "env_key",
            "APTIS_API_URL": "http://prod:8082",
            "APTIS_ACCOUNT": "Theme",
            "APTIS_TIMEOUT": "60",
            "APTIS_MAX_RETRIES": "5",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = AptisConfig.from_env()
        assert cfg.api_key == "env_key"
        assert cfg.base_url == "http://prod:8082"
        assert cfg.account == "Theme"
        assert cfg.timeout == 60
        assert cfg.max_retries == 5

    def test_from_env_missing_key_raises(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ConfigurationError, match="APTIS_API_KEY"):
                AptisConfig.from_env()

    def test_from_env_empty_account_becomes_none(self):
        with patch.dict(os.environ, {"APTIS_API_KEY": "k", "APTIS_ACCOUNT": ""},
                        clear=False):
            cfg = AptisConfig.from_env()
        assert cfg.account is None
