# Cookiecutter Service Starter

Generate a FastAPI service with composable feature toggles (database, delegates, workers, caching, structured logging).

## Generate a service

```bash
uvx cookiecutter . --directory starters/cookiecutter-service
```

Key prompts:

- `service_name`
- `service_description`
- `has_database` + `database` (`sqlite`, `maria`, `postgres`)
- `has_delegates` + `upstreams`
- `has_workers` + `broker` (`redis`, `rabbitmq`)
- `has_caching`
- `has_structured_logging`
- `port`
- `model_name`

## Notes

- Adapter imports remain explicit via `from csrd.repository import ...`.
- Feature-specific files are conditionally included using template sections.
- `hooks/post_gen_project.py` validates incompatible feature combinations.
- This template is the Phase 1 baseline for `docs/TEMPLATING_COMPREHENSIVE_PLAN.md`.

## Example combinations

```bash
# DB-only SQLite service
uvx cookiecutter . --directory starters/cookiecutter-service \
  --no-input service_name=inventory has_database=true database=sqlite \
  has_delegates=false has_workers=false has_caching=false

# Postgres + delegates + caching
uvx cookiecutter . --directory starters/cookiecutter-service \
  --no-input service_name=pricing has_database=true database=postgres \
  has_delegates=true upstreams=http://inventory:8081 \
  has_workers=false has_caching=true

# Worker-focused service with RabbitMQ and no DB
uvx cookiecutter . --directory starters/cookiecutter-service \
  --no-input service_name=jobs has_database=false has_workers=true broker=rabbitmq \
  has_delegates=false has_caching=false
```

## Next phase

- Phase 2 introduces standalone feature augmentation via `tools/add-service-feature/`.
- See `docs/TEMPLATING_COMPREHENSIVE_PLAN.md` for the Phase 2 roadmap and constraints.
