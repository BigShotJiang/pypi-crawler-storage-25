from fastapi import FastAPI

from . import health_view
{%- if cookiecutter.has_database %}
from . import items_view
{%- endif %}

unversioned_app = FastAPI(title="{{ cookiecutter.service_name }}")

unversioned_app.include_router(health_view.router)
{%- if cookiecutter.has_database %}
unversioned_app.include_router(items_view.router)
{%- endif %}

__all__ = ("unversioned_app",)
