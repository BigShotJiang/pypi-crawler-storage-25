from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # [INSERT: fields]

    app_name: str = "{{ cookiecutter.service_name }}"
    port: int = {{ cookiecutter.port }}
    has_structured_logging: bool = {{ "True" if cookiecutter.has_structured_logging else "False" }}

    {%- if cookiecutter.has_database %}
    has_database: bool = True
    db_kind: str = "{{ cookiecutter.database }}"
    db_path: str = "./sandbox.db"
    db_host: str = "localhost"
    db_port: int = {{ "3306" if cookiecutter.database == "maria" else "5432" }}
    db_user: str = "sandbox"
    db_password: str = "sandbox"
    db_name: str = "sandbox"
    {%- else %}
    has_database: bool = False
    {%- endif %}

    {%- if cookiecutter.has_delegates %}
    has_delegates: bool = True
    upstreams: str = "{{ cookiecutter.upstreams }}"
    {%- else %}
    has_delegates: bool = False
    {%- endif %}

    {%- if cookiecutter.has_workers %}
    has_workers: bool = True
    worker_broker: str = "{{ cookiecutter.broker }}"
    {%- if cookiecutter.broker == "redis" %}
    worker_broker_url: str = "redis://localhost:6380/1"
    {%- else %}
    worker_broker_url: str = "amqp://guest:guest@localhost:5672/"
    {%- endif %}
    {%- else %}
    has_workers: bool = False
    {%- endif %}

    {%- if cookiecutter.has_caching %}
    has_caching: bool = True
    cache_backend: str = "{{ cookiecutter.cache_backend }}"
    cache_url: str = "redis://localhost:6379/0"
    {%- else %}
    has_caching: bool = False
    {%- endif %}


settings = Settings()
