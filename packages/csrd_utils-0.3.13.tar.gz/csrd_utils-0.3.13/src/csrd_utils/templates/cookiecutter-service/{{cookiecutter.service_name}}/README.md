# {{ cookiecutter.service_name }}

{{ cookiecutter.service_description }}

## Enabled Features

- Database: `{{ cookiecutter.has_database }}`
{%- if cookiecutter.has_database %}
  - Adapter: `{{ cookiecutter.database }}`
  - Model: `{{ cookiecutter.model_name }}`
  - Collection route: `/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}`
{%- endif %}
- Delegates: `{{ cookiecutter.has_delegates }}`
{%- if cookiecutter.has_delegates %}
  - Upstreams: `{{ cookiecutter.upstreams }}`
{%- endif %}
- Workers: `{{ cookiecutter.has_workers }}`
{%- if cookiecutter.has_workers %}
  - Broker: `{{ cookiecutter.broker }}`
{%- endif %}
- Caching: `{{ cookiecutter.has_caching }}`
- Structured logging: `{{ cookiecutter.has_structured_logging }}`

## Run locally

```bash
pip install -r requirements.txt
PYTHONPATH=src uvicorn app:build_app --factory --reload --port {{ cookiecutter.port }}
```

## Run with compose

```bash
docker compose up --build
```

## Endpoints

- `GET /health`
{%- if cookiecutter.has_database %}
- `POST /api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}`
- `GET /api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}`
- `GET /api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{entity_id}`
- `PUT /api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{entity_id}`
- `DELETE /api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{entity_id}`
{%- endif %}

## Generated tests

- Acceptance tests live under `tests/acceptance/`
- Unit tests live under `tests/unit/`
- Feature-dependent tests are generated only when corresponding dependencies are enabled:
  - database -> `tests/unit/test_database_settings.py`
  - delegates -> `tests/unit/test_delegates.py`
  - workers -> `tests/unit/test_worker_broker.py`
  - caching -> `tests/unit/test_cache.py`
  - structured logging -> `tests/acceptance/test_logging_middleware.py`
