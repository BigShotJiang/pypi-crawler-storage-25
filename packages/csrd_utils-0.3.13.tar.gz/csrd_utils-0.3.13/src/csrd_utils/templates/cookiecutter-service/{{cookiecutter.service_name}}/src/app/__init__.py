from fastapi import FastAPI

from csrd.versioning import (
    UNVERSIONED,
    VersionedApiConfig,
    VersionedAppComposeConfig,
    compose_versioned_apps,
)

from .settings import settings
from .views import unversioned_app


def build_app() -> FastAPI:
    app = compose_versioned_apps(
        version_mapping={UNVERSIONED: unversioned_app},
        config=VersionedAppComposeConfig(
            title="{{ cookiecutter.service_name }}",
            api=VersionedApiConfig(prefix="/", include_actuator_endpoints=True),
        ),
    )

    {%- if cookiecutter.has_structured_logging %}
    from .middleware.logging import RequestLogMiddleware

    app.add_middleware(RequestLogMiddleware)
    {%- endif %}

    return app


__all__ = ("build_app",)
