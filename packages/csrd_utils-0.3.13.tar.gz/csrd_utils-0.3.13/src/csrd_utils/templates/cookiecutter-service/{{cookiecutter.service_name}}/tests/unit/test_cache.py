"""Unit tests for cache dependency wiring."""

from app.cache import build_cache_client


def test_cache_client_uses_configured_host() -> None:
    cache_client = build_cache_client()
    host = cache_client.connection_pool.connection_kwargs.get("host")
    assert host in {"localhost", "redis"}
