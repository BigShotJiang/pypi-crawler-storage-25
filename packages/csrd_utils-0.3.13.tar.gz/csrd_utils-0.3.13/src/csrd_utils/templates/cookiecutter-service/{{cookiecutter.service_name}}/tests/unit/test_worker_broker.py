"""Unit tests for worker broker dependency wiring."""

from app.dependencies.worker_broker import get_worker_broker_url


def test_worker_broker_url_uses_expected_scheme() -> None:
    broker_url = get_worker_broker_url()
    assert broker_url.startswith(("redis://", "amqp://"))
