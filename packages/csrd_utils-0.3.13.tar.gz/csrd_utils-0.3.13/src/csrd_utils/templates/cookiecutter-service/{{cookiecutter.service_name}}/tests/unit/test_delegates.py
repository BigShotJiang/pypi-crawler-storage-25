"""Unit tests for delegate dependency wiring."""

import asyncio

from app.dependencies.delegates import upstream_delegate_factory


async def _collect_upstreams() -> list[str]:
    async for upstreams in upstream_delegate_factory():
        return upstreams
    return []


def test_upstream_delegate_factory_returns_urls() -> None:
    upstreams = asyncio.run(_collect_upstreams())
    assert upstreams
    assert all(url.startswith("http") for url in upstreams)
