from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...dependencies import RepositoryDep

router = APIRouter(prefix="/api", tags=["{{ cookiecutter.model_name_plural }} Endpoints"])


class Create{{ cookiecutter.model_name }}Request(BaseModel):
    name: str


class Update{{ cookiecutter.model_name }}Request(BaseModel):
    name: str


@router.post("/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}")
async def create_{{ cookiecutter.model_name | lower }}(
    repo: RepositoryDep, payload: Create{{ cookiecutter.model_name }}Request
) -> dict[str, str]:
    return await repo.create(payload.name)


@router.get("/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}")
async def list_{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}(
    repo: RepositoryDep,
) -> dict[str, list[dict[str, str]]]:
    return {"{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}": await repo.list()}


@router.get("/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{entity_id}")
async def get_{{ cookiecutter.model_name | lower }}(
    entity_id: str, repo: RepositoryDep
) -> dict[str, str]:
    item = await repo.get(entity_id)
    if item is None:
        raise HTTPException(status_code=404, detail="{{ cookiecutter.model_name | lower }} not found")
    return item


@router.put("/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{entity_id}")
async def update_{{ cookiecutter.model_name | lower }}(
    entity_id: str,
    repo: RepositoryDep,
    payload: Update{{ cookiecutter.model_name }}Request,
) -> dict[str, object]:
    rows = await repo.update(entity_id, payload.name)
    if rows == 0:
        raise HTTPException(status_code=404, detail="{{ cookiecutter.model_name | lower }} not found")
    return {"id": entity_id, "name": payload.name, "updated": True}


@router.put("/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{entity_id}/upsert")
async def upsert_{{ cookiecutter.model_name | lower }}(
    entity_id: str,
    repo: RepositoryDep,
    payload: Update{{ cookiecutter.model_name }}Request,
) -> dict[str, object]:
    rows = await repo.upsert(entity_id, payload.name)
    return {"id": entity_id, "name": payload.name, "rows_affected": rows}


@router.delete("/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{entity_id}")
async def delete_{{ cookiecutter.model_name | lower }}(
    entity_id: str, repo: RepositoryDep
) -> dict[str, object]:
    rows = await repo.delete(entity_id)
    if rows == 0:
        raise HTTPException(status_code=404, detail="{{ cookiecutter.model_name | lower }} not found")
    return {"id": entity_id, "deleted": True}
