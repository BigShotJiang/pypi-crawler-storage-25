"""Resource helpers for bundled templates and feature manifests."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import AbstractContextManager, contextmanager
from importlib.resources import as_file, files
from pathlib import Path


@contextmanager
def _package_path(subdir: str) -> Iterator[Path]:
    """Yield a temporary filesystem path to package data."""
    resource = files("csrd_utils").joinpath(subdir)
    with as_file(resource) as resolved:
        yield resolved


def features_path() -> AbstractContextManager[Path]:
    """Yield filesystem path to bundled feature manifests/fragments."""
    return _package_path("features")


def templates_path() -> AbstractContextManager[Path]:
    """Yield filesystem path to bundled templates."""
    return _package_path("templates")
