"""Example worker tasks."""

from __future__ import annotations

from .celery_app import celery_app


@celery_app.task(name="tasks.example_task")
def example_task(x: int, y: int) -> int:
    """
    Example task that adds two numbers.

    Can be called with:
        task = example_task.apply_async(args=[1, 2])
        task.get()  # => 3

    Parameters
    ----------
    x : int
        First number
    y : int
        Second number

    Returns
    -------
    int
        Sum of x and y
    """
    return x + y
