# nlsql-coder

nlsql-coder is NLSQL's coding agent, a privacy & security focused, tool-driven, workspace-aware AI system designed to help with both personal and client-based development tasks.

# Features

- User-friendly command line interface.
- Wide array of LLM/provider support acorss many cloud ecosystems, including locally hosted model support (local support not yet implemented).
- Primary privacy & security focus.
- Full MCP support (stdio, sse and streamable-http supported).

# How it Works

The agent operates using a ReAct-style loop. A user submits a prompt, and the agent processes it by reasoning about the task, performing actions using available tools, and evaluating the results.

If the outcome is insufficient or incomplete, the agent continues this cycle, refining its approach and taking further actions until it can produce a final response.

# Usage

To get started, you'll need an NLSQL API key, simply sign up to NLSQL to obtain your free API key.

You'll also need your own LLM instance from one of the following providers:
- AWS Bedrock
- Azure AI
- Google Cloud (GCP)
- AWS SageMaker (_Not yet implemented_)
- Or select a locally hosted [Hugging Face](https://huggingface.co/) model. (_Not yet implemented_)

nlsql-coder is available for download via PyPI, follow the steps below to get it running on your system:

1. run `pip install nlsql-coder`
2. use the command `nlsql-coder init` to run from your CWD.

for other options or extended usage, see Arguments section below.

## Arguments

Use the `init` command to start the application from the current working directory.

| Short | Long | Description | Defaults to |
|-|-|-|-|
| `-w` | `--workspace` | The root directory of the project you want to work on. | `.` |
| `-u` | `--usage` | Displays usage data after each conversation turn (input & output tokens) | `False` |

## Modes

The agent has three modes:
- Plan mode
- Code (manual) mode
- Auto mode

Use Shift+Tab to switch between the modes.

Plan mode means the agent has read-only access and is configured to plan a task or project with the user. When a sufficent plan has been created the user can choose to proceed with the plan in either Auto or Manual mode, give feedback and amend the plan, or discard the plan.

Manual mode means the user will have to actively confirm tool calls.

Auto mode means only certain tool calls will need to be confirmed by the user (e.g. delete, git commands...)

## Tools

By default the agent has access to several tools:

- read_file
- edit_file
- write_file
- delete (for files and directories in the CWD)
- execute_bash_command (can execute bash command on an internally supplied whitelist only)
- search_the_web (allows for both search engine results and URL content extraction)

The agent also has MCP support (add MCP servers via mcp.json)


# Feedback and Issues

To provide feedback or report an issue please email info@nlsql.com

**Please note: nlsql-coder is under active development**