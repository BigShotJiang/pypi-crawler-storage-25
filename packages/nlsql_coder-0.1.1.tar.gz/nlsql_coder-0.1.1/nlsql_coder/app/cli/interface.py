from nlsql_coder.app.agent.helpers.get_agent import get_conf
from nlsql_coder.app.cli.tool_calling import call_tools
from nlsql_coder.app.cli.arg_parsing import args
from nlsql_coder.data.create_agent_md import create_md

from rich.console import Console
from rich.markdown import Markdown
from rich.align import Align

from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings

from itertools import cycle
import threading
import requests
import random
import uuid
import time
import sys
import os

# from dotenv import load_dotenv

KEY_ENV = str(uuid.uuid4())

def _in_code_block(text: str) -> bool:
    return text.count("```") % 2 == 1

def _split_at_markdown_break(buffer: str) -> tuple[str, str]:
    """Split into (completed_markdown, still_streaming) at the last paragraph break."""
    if _in_code_block(buffer):
        return "", buffer
    last_break = buffer.rfind("\n\n")
    if last_break == -1:
        return "", buffer
    return buffer[: last_break + 2], buffer[last_break + 2 :]

_SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
_SPINNER_LABELS = ["Firing transistors", "Summoning electrons", "Rearranging atoms", "Byte-ing bits", "Quantum computing", "Splitting the atom",
                    "Connecting nodes", "Switching logic gates", "Dodging bullets", "Juggling molecules", "Dividing by zero", "Summoning the daemon",
                    "Folding spacetime", "Consulting the Oracle", "Collapsing the wave function", "One-zero-ing", "Optimizing entropy", ]
class _ToolSpinner:
    """Animates a spinner on a new line while the model builds tool-call JSON.

    start() writes a newline and begins a background thread.
    stop() joins the thread, clears the spinner line, then steps the cursor
    back up over the newline — leaving the cursor exactly where it was before
    start() was called, so _erase_dim_text / console.print work as normal.
    """
    def __init__(self) -> None:
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        sys.stdout.write("\n")
        sys.stdout.flush()
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()

    def _spin(self) -> None:
        i = 0
        label = random.choice(_SPINNER_LABELS)
        for frame in cycle(_SPINNER_FRAMES):
            if self._stop_event.is_set():
                break

            if i == 45:
                label = random.choice(_SPINNER_LABELS)
                i = 0

            sys.stdout.write("\r\033[2K") 
            sys.stdout.write(f"\r\033[2m{frame} {label}...\033[0m")
            sys.stdout.flush()
            time.sleep(0.08)
            i += 1

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=0.5)
            self._thread = None
        # Clear spinner line, then step back up over the \n we added in start()
        sys.stdout.write("\r\033[K\033[1A")
        sys.stdout.flush()


def _erase_dim_text(text: str, width: int) -> None:
    """Erase dim text written directly to stdout, resetting cursor to where it started."""
    if not text:
        return
    rows, col = 1, 0
    for ch in text:
        if ch == "\n":
            rows += 1
            col = 0
        else:
            col += 1
            if col >= width:
                rows += 1
                col = 0
    if rows > 1:
        sys.stdout.write(f"\033[{rows - 1}A")
    sys.stdout.write("\r\033[J")
    sys.stdout.flush()


modes = cycle(["Code", "Plan", "Auto"])
state = {
    "mode": next(modes)
}

# Key bindings - for changing agent modes (code, plan, auto)
keys = KeyBindings()

@keys.add("s-tab")
def change_mode(event):
    state["mode"] = next(modes)
    event.app.invalidate()
    

console = Console()

def get_envs():
    console.clear()

    console.input("""\n
[bold green]Thanks for installing nlsql-coder!
                  
You'll need two things to get started:
 
  1. A free NLSQL API token
     → Generate yours at https://nlsql.com/signup/
 
  2. Your own LLM instance from one of these providers:
     • AWS Bedrock
     • Azure AI
     • Google Cloud (GCP)
     • AWS SageMaker
     • Or a locally hosted Hugging Face model from https://huggingface.co
 
Loving nlsql-coder and need more? For enterprise plans,
reach out at info@nlsql.com — we'd love to chat.
 
Once you have both, press Enter to start! ▶[/bold green] """)
    # Soft gate to encourage onboarding
    while True:
        api_key = console.input("\n\n[bold blue][NLSQL API key]:[/bold blue] ").strip()

        headers = {
            "Authorization": f"Token {api_key}"
        }

        response = requests.get(
            "https://api.nlsql.com/v1/data-source/",
            headers=headers
        )

        if response.status_code == 200:
            console.print("[bold green]API key is valid[/bold green]")
            os.environ[KEY_ENV] = api_key
            break
        else:
            console.print(f"[bold red] Request failed: {response.status_code}[/bold red]")
            console.print("Regiser at https://nlsql.com/signup/ to get your free NLSQL API key.")

    if os.getenv("MODEL_PROVIDER", "") and os.getenv("MODEL_NAME", ""):
        console.print("\n\n[bold green]System environment variables detected.[/bold green]")
        return

    # if Path(args.workspace, ".env").exists():
    #     while True:
    #         env = console.input(
    #             "\n\n[bold blue].env file detected, would you like to use this? (y/n):[/bold blue] "
    #         )

    #         if env.lower() == "y":
    #             load_dotenv(Path(args.workspace, ".env"))
    #             console.clear()

    #             agent, _ = get_conf()

    #             if not agent:
    #                 console.print(
    #                     "\n\n[bold red]✕ Incorrect configuration, please enter manually...[/bold red]"
    #                 )
    #                 console.clear()
    #                 break

    #             return agent

    #         elif env.lower() == "n":
    #             console.clear()
    #             break

    provider = console.input(
        "\n\n[bold blue][Provider (aws/azure/gcp)]:[/bold blue] "
    ).strip().lower()

    console.clear()

    os.environ["MODEL_PROVIDER"] = provider

    QUESTIONS = {
        "aws": [
            ("MODEL_NAME", "\n[bold blue][Model name]:[/bold blue] "),
            ("AWS_ACCESS_KEY_ID", "[bold blue][Access Key ID]:[/bold blue] "),
            ("AWS_SECRET_ACCESS_KEY", "[bold blue][Secret Access Key]:[/bold blue] "),
            ("AWS_DEFAULT_REGION", "[bold blue][Region]:[/bold blue] "),
        ],

        "azure": [
            ("MODEL_NAME", "\n[bold blue][Deployment name]:[/bold blue] "),
            ("AZURE_OPENAI_API_KEY", "[bold blue][API Key]:[/bold blue] "),
            ("AZURE_OPENAI_ENDPOINT", "[bold blue][Endpoint]:[/bold blue] "),
            ("AZURE_OPENAI_API_VERSION", "[bold blue][API Version]:[/bold blue] "),
        ],

        "gcp": [
            ("MODEL_NAME", "\n[bold blue][Model name]:[/bold blue] "),
            ("GEMINI_API_KEY", "[bold blue][Gemini API Key]:[/bold blue] "),
        ]
    }

    questions = QUESTIONS.get(provider)

    if not questions:
        console.print(f"[bold red]✕ Unknown provider: {provider}[/bold red]")
        return None

    answers = {}

    end = "\n\n"
    end_flag = False

    for key, prompt in questions:

        console.print(
            "\n\n[bold]To start, we need to set up your environment variables...[/bold]",
            end=end if end_flag else "\n"
        )

        value = console.input(prompt)

        console.clear()

        answers[key] = value

        end_flag = True

    console.clear()

    for key, value in answers.items():
        os.environ[key] = value

    agent, _ = get_conf()

    if agent:
        console.print(
            "\n\n[bold green]✓ Model configured successfully.[/bold green]"
        )
        time.sleep(2)
        console.clear()
        return agent

    console.print(
        "\n\n[bold red]✕ Incorrect configuration, please try again...[/bold red]"
    )

    time.sleep(2)

    console.clear()

    return None


def create_agents_md():
    console.print("\n")
    with console.status("[bold]Creating AGENTS.md file...[/bold]", spinner="dots"):
        success = create_md()
    if success == "created":
        console.print("[bold]AGENTS.md file created at project root.[/bold]")
    elif success == "exists":
        console.print("[bold]AGENTS.md file already exists at project root.[/bold]")
    elif success == "empty":
        console.print("[bold]Starting from scratch![/bold]")
    else:
        console.print("[bold]Failed to create AGENTS.md file.[/bold]")
    time.sleep(2)
    console.clear()


WELCOME_MESSAGE = """[blue bold]\n
Welcome      _   _  _      ____   ___  _     
            | \ | || |    / ___| / _ \| |    
       to   |  \| || |    \___ \| | | | |    
            | |\  || |___  ___) | |_| | |___ 
            |_| \_||_____||____/ \__\_\_____|   Coder\n\n[/blue bold]
"""

def main_loop():
    try:
        # Initial setup
        while True:
            agent = get_envs()
            if agent:
                break
        
        # Create AGENTS.md
        create_agents_md()

        #  Welcome message
        console.print(Align.center(WELCOME_MESSAGE))

        session = PromptSession(key_bindings=keys)
        def get_prompt():
            return HTML(f"\n<ansicyan>[Mode: {state['mode']}]</ansicyan><style fg='#00ff00'><b>[You]: </b></style>")
        
        # Conversation loop
        plan_confirmed = False
        usage_data = {}
        while True:

            # Print last turn's usage data tables if -u flag given
            if args.usage and usage_data:
                core_table = (
                    "| Metric | Value |\n"
                    "|--------|-------|\n"
                    f"| Input Tokens | {usage_data.get('input_tokens', 0)} |\n"
                    f"| Output Tokens | {usage_data.get('output_tokens', 0)} |\n"
                    f"| Total Tokens | {usage_data.get('total_tokens', 0)} |\n"
                    f"| Cache Read Tokens | {usage_data.get('cache_read_tokens', 0)} |\n"
                    f"| Cache Write Tokens | {usage_data.get('cache_write_tokens', 0)} |\n"
                )
                cache_details = usage_data.get("cache_details", {})
                cache_table = (
                    "| Cache TTL | Tokens |\n"
                    "|-----------|--------|\n"
                )
                if cache_details:
                    for ttl, tokens in cache_details.items():
                        cache_table += f"| {ttl} | {tokens} |\n"
                else:
                    cache_table += "| - | 0 |\n"
                console.print("[bold]\n\nUsage Data[/bold]")

                console.print(Markdown(core_table))
                console.print(Markdown(cache_table))

            message = ""
            if not plan_confirmed:
                message = session.prompt(get_prompt)
            else:
                plan_confirmed = False
            if message.lower() in ["quit", "exit"]:
                console.print("\n\n[bold purple]Goodbye[/bold purple]\n")
                break

            # AI model loop
            usage_data = {}
            if message:
                console.print("\n[bold cyan][Assistant]:[/bold cyan]")
            while True:
                if not message:
                    plan_confirmed = False
                    break
                found_tool_calls = False
                buffer = ""
                committed = ""  # portion already printed as Markdown
                spinner: _ToolSpinner | None = None

                for chunk in agent.chat(message, state["mode"]):
                    if isinstance(chunk, str):
                        buffer += chunk
                        if chunk == "":
                            # Model is building tool-call JSON — show spinner
                            if spinner is None:
                                spinner = _ToolSpinner()
                                spinner.start()
                            continue

                        # More text arrived after spinner (rare) — tear it down cleanly
                        if spinner is not None:
                            spinner.stop()
                            spinner = None

                        # Write this chunk as dim text — no redraws, cursor only moves forward
                        sys.stdout.write(f"\033[2m{chunk}\033[0m")
                        sys.stdout.flush()

                        completed, streaming = _split_at_markdown_break(buffer)
                        new_md = completed[len(committed):]
                        if new_md:
                            # Erase all dim text since last commit, re-render as Markdown
                            _erase_dim_text(buffer[len(committed):], console.width)
                            console.print(Markdown(new_md))
                            committed = completed
                            # Re-write any text that follows the paragraph break as dim
                            if streaming:
                                sys.stdout.write(f"\033[2m{streaming}\033[0m")
                                sys.stdout.flush()

                    elif isinstance(chunk, list):
                        if spinner is not None:
                            spinner.stop()
                            spinner = None
                        found_tool_calls = True
                        remaining = buffer[len(committed):]
                        if remaining:
                            _erase_dim_text(remaining, console.width)
                            if remaining.strip():
                                console.print(Markdown(remaining))
                        tool_results = call_tools(chunk, state["mode"], console)
                        feedback_result = next(
                            (result for result in tool_results if "User gave feedback:" in result["result"]),
                            None
                        )
                        if feedback_result:
                            message = tool_results
                            break
                        confirm_result = next(
                            (result for result in tool_results if result["name"] == "ask_user_to_confirm_plan"),
                            None
                        )
                        if confirm_result:
                            action = confirm_result.get("result", "")
                        else:
                            action = ""
                        confirm_msg = (
                            "The user has confirmed the plan. "
                            "Proceed with completing the task automatically."
                            "STOP AS SOON AS YOU HAVE COMPLETED THE PLAN."
                        )
                        if action == "_auto":
                            state["mode"] = "Auto"
                            confirm_result["result"] = confirm_msg
                            plan_confirmed = True
                        if action == "_manual":
                            state["mode"] = "Code"
                            confirm_result["result"] = confirm_msg
                            plan_confirmed = True
                        if action == "_discard":
                            agent.delete_plan()
                            confirm_result["result"] = "The user has discarded the plan."

                        message = tool_results

                    elif isinstance(chunk, dict):
                        if args.usage:
                            if not usage_data:
                                usage_data["input_tokens"] = chunk["input_tokens"]
                                usage_data["output_tokens"] = chunk["output_tokens"]
                                usage_data["total_tokens"] = chunk["total_tokens"]
                                usage_data["cache_read_tokens"] = chunk["cache_read_tokens"]
                                usage_data["cache_write_tokens"] = chunk["cache_write_tokens"]
                                usage_data["cache_details"] = {}
                                for detail in chunk.get("cache_details", []):
                                    ttl = detail["ttl"]
                                    tokens = detail["inputTokens"]
                                    usage_data["cache_details"][ttl] = (
                                        usage_data["cache_details"].get(ttl, 0) + tokens
                                    )
                            else:
                                usage_data["input_tokens"] += chunk["input_tokens"]
                                usage_data["output_tokens"] += chunk["output_tokens"]
                                usage_data["total_tokens"] += chunk["total_tokens"]
                                usage_data["cache_read_tokens"] += chunk["cache_read_tokens"]
                                usage_data["cache_write_tokens"] += chunk["cache_write_tokens"]
                                for detail in chunk.get("cache_details", []):
                                    ttl = detail["ttl"]
                                    tokens = detail["inputTokens"]
                                    usage_data["cache_details"][ttl] = (
                                        usage_data["cache_details"].get(ttl, 0) + tokens
                                    )

                if not found_tool_calls:
                    if spinner is not None:
                        spinner.stop()
                        spinner = None
                    # Stream ended — erase dim text, render remaining as Markdown
                    remaining = buffer[len(committed):]
                    if remaining:
                        _erase_dim_text(remaining, console.width)
                        if remaining.strip():
                            console.print(Markdown(remaining))
                    break
    except KeyboardInterrupt:
        console.print("\n\n[bold purple]Goodbye[/bold purple]\n")
    except Exception as e:
        console.print(f"\n\n[bold red]Oh no! Something went wrong. Here's the error:\n\n{e}[/bold red]\n")
