from nlsql_coder.app.providers.base import BaseProvider, Message
from typing import Iterator
from nlsql_coder.app.providers.config import AzureOpenAIConfig
from nlsql_coder.app.agent.tools.tool_specs import ToolSpecification, tool_azure_openai
from openai import AzureOpenAI
import json
import os
from nlsql_coder.app.cli.interface import KEY_ENV

class AzureOpenAIProvider(BaseProvider):

    def __init__(self, model_id: str):
        config = AzureOpenAIConfig()

        self.model_id = model_id

        self.client = AzureOpenAI(
            api_key=config.api_key,
            api_version=config.api_version,
            azure_endpoint=config.endpoint,
            timeout=1200
        )

    def form_message(self, message: Message | list[dict]) -> dict | None:

        if isinstance(message, Message):
            if isinstance(message.content, str):
                return {
                    "role": message.role,
                    "content": [
                        {
                            "type": "input_text" if message.role == "user" else "output_text",
                            "text": message.content
                        }
                    ]
                }


            # Tool call
            if isinstance(message.content, list):
                # Returns None (OpenAI types want exact output to be reappended (check Agent - open_ai_type))
                return None
            
        else:
            return [
                        {
                            "type": "function_call_output",
                            "call_id": m["toolUseId"],
                            "output": m["result"]
                        }
                        for m in message
                    ]

        
    def stream_chat(
        self,
        messages: list[Message],
        max_tokens: int = 32000,
        temperature: float = 0.7,
        system_prompt: str = "",
        tools: list[ToolSpecification] | None = None
    ) -> Iterator[str]:
        
        if not os.getenv(KEY_ENV):
            raise ValueError("Missing NLSQL API token. Please set it before using chat.")
        
        formatted_messages = []

        if system_prompt:
            formatted_messages.append({
                "role": "system",
                "content": system_prompt
            })

        formatted_messages.extend(messages)

        kwargs = {
            "model": self.model_id,
            "input": formatted_messages,
            "stream": True,
            "max_output_tokens": max_tokens,
            # "temperature": temperature
        }

        if tools:
            formatted_tools = [tool_azure_openai(tool) for tool in tools]

            kwargs["tools"] = formatted_tools
            kwargs["tool_choice"] = "auto"

        response = self.client.responses.create(**kwargs)

        tool_calls = {}
        usage_data = {}

        for event in response:

            if event.type == "response.output_item.added":
                item = event.item

                if item.type == "function_call":
                    tool_calls[item.id] = {
                        "id": item.id,
                        "toolUseId": item.call_id,
                        "name": item.name,
                        "input": "",
                        "type": "tool_use"
                    }
                    yield ""

            # Text output stream
            elif event.type == "response.output_text.delta":
                if event.delta:
                    yield event.delta

            # Tool argument stream
            elif event.type == "response.function_call_arguments.delta":
                idx = event.item_id
                delta = event.delta

                if idx in tool_calls and delta:
                    tool_calls[idx]["input"] += delta

            # Tool finalization
            elif event.type in (
                "response.function_call_arguments.done",
                "response.output_item.done"
            ):
                if tool_calls:
                    for v in tool_calls.values():
                        if isinstance(v.get("input"), str):
                            raw_val = v["input"].strip()

                            if raw_val:
                                try:
                                    v["input"] = json.loads(raw_val)
                                except json.JSONDecodeError:
                                    v["input"] = {}
                            else:
                                v["input"] = {}
            
            # Reasoning
            # elif event.type == "response.reasoning_summary_text.delta":
            #     print(event.delta)

            # Usage metadata
            elif event.type == "response.completed":
                resp_obj = event.response

                if hasattr(resp_obj, "usage") and resp_obj.usage:
                    usage = resp_obj.usage

                    cache_read = 0

                    if hasattr(usage, "input_tokens_details") and usage.input_tokens_details:
                        cache_read = getattr(usage.input_tokens_details, "cached_tokens", 0)

                    usage_data = {
                        "input_tokens": usage.input_tokens,
                        "output_tokens": usage.output_tokens,
                        "total_tokens": usage.total_tokens,
                        "cache_read_tokens": cache_read,
                        "cache_write_tokens": 0,
                        "cache_details": []
                    }

                yield {"response_output": event.response.output} # Responseoutput for messages list (agent level)

        if tool_calls:
            yield tool_calls
        if usage_data:
            yield usage_data