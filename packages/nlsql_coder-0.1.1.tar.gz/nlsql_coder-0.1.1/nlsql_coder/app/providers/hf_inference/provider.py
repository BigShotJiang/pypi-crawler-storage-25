# from nlsql_coder.app.providers.base import BaseProvider, Message
# from typing import Iterator
# from nlsql_coder.app.providers.config import GeminiConfig
# from nlsql_coder.app.agent.tools.tool_specs import ToolSpecification, tool_custom
# from huggingface_hub import InferenceClient
# import os
# from nlsql_coder.app.cli.interface import KEY_ENV

# TODO

# class HuggingFaceProvider(BaseProvider):

#     def __init__(self, model_id: str):
#         config = HFConfig
#         self.client = InferenceClient(
#             model=model_id,
#             token=config.token
#         )
#         # self.model_id = model_id

#     def form_message(self, message: Message | list[dict]) -> dict | None:
#         if isinstance(message, Message):
#             if isinstance(message.content, str):
#                 return {"role": message.role, "content": message.content}

#             if isinstance(message.content, list):  # Tool call message from model
#                 parts = []
#                 for tool in message.content:
#                     if "_raw_part" in tool:
#                         parts.append(tool["_raw_part"])
#                     else:
#                         parts.append({
#                             "function_call": {
#                                 "name": tool.get("name"),
#                                 "args": tool.get("input", {})
#                             }
#                         })
#                 return {"role": "model", "parts": parts}
#         else:
#             return {
#                 "role": "user",
#                 "parts": [
#                     {
#                         "function_response": {
#                             "name": m.get("name", m.get("toolUseId")),
#                             "response": {"result": m.get("result", "")}
#                         }
#                     }
#                     for m in message
#                 ]
#             }
#         return None

#     def stream_chat(
#         self,
#         messages: list[Message],
#         max_tokens: int = 32000,
#         temperature: float = 0.7,
#         system_prompt: str = "",
#         tools: list[ToolSpecification] | None = None
#     ) -> Iterator[str | dict]:

#         if not os.getenv(KEY_ENV):
#             raise ValueError("Missing NLSQL API token. Please set it before using chat.")
        
#         contents = []
#         for m in messages:
#             if isinstance(m, dict):
#                 # Already Gemini-formatted by form_message — pass through directly
#                 contents.append(m)
#             else:
#                 role = "model" if m.role == "assistant" else m.role
#                 parts = []
#                 if isinstance(m.content, str):
#                     parts.append({"text": m.content})
#                 if parts:
#                     contents.append({"role": role, "parts": parts})

#         gemini_tools = None
#         if tools:
#             gemini_tools = [types.Tool(function_declarations=[
#                 types.FunctionDeclaration(**tool_gemini(tool)) for tool in tools
#             ])]

#         config = types.GenerateContentConfig(
#             system_instruction=system_prompt if system_prompt else None,
#             max_output_tokens=max_tokens,
#             temperature=temperature,
#             tools=gemini_tools
#         )

#         response = self.client.models.generate_content_stream(
#             model=self.model_id,
#             contents=contents,
#             config=config
#         )

#         tool_calls = {}
#         usage_data = {}

#         for chunk in response:
#             if chunk.candidates:
#                 for part in chunk.candidates[0].content.parts:
#                     if part.text:
#                         yield part.text
#                     elif part.function_call:
#                         fc = part.function_call
#                         call_id = fc.id or f"call_{len(tool_calls)}"
#                         tool_calls[call_id] = {
#                             "toolUseId": call_id,
#                             "name": fc.name,
#                             "input": dict(fc.args) if fc.args else {},
#                             "type": "tool_use",
#                             "_raw_part": part.model_dump(exclude_none=True)
#                         }
#                         yield ""

#             if chunk.usage_metadata and chunk.usage_metadata.total_token_count:
#                 usage = chunk.usage_metadata
#                 usage_data = {
#                     "input_tokens": usage.prompt_token_count or 0,
#                     "output_tokens": usage.candidates_token_count or 0,
#                     "total_tokens": usage.total_token_count or 0,
#                     "cache_read_tokens": usage.cached_content_token_count or 0,
#                     "cache_write_tokens": 0,
#                     "cache_details": []
#                 }

#         if tool_calls:
#             yield tool_calls
#         if usage_data:
#             yield usage_data
