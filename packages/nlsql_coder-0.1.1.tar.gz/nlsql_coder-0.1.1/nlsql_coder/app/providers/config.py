"""
Provider configuration.
"""
from dataclasses import dataclass
import os

# Provider & Model config
@dataclass
class ProviderConfig:
    model_provider: str = ""
    model_name: str = ""

    def __post_init__(self):
        self.model_provider = os.getenv("MODEL_PROVIDER", "")
        self.model_name = os.getenv("MODEL_NAME", "")


# AWS Config
@dataclass
class AWSConfig:
    access_key_id: str = ""
    secret_access_key: str = ""
    region: str = ""

    def __post_init__(self):
        self.access_key_id = os.getenv("AWS_ACCESS_KEY_ID", "")
        self.secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY", "")
        self.region = os.getenv("AWS_DEFAULT_REGION", "")


# Azure OpenAI Config
@dataclass
class AzureOpenAIConfig:
    api_key: str = ""
    endpoint: str = ""
    api_version: str = ""

    def __post_init__(self):
        self.api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
        self.endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
        self.api_version = os.getenv("AZURE_OPENAI_API_VERSION", "")


# GCP / Gemini Config
@dataclass
class GeminiConfig:
    api_key: str = ""

    def __post_init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "")