"""
Planner agent class.
Implements the functionallity for the planner agent.
"""
from nlsql_coder.app.providers.base import BaseProvider, Message
from typing import Type, Iterator
from pathlib import Path
import os

from nlsql_coder.app.agent.tools.tool_specs import ToolSpecification
from nlsql_coder.app.cli.interface import KEY_ENV

MAX_TOOL_CALLS = 6
MAX_WORDS = 32_000

class Agent:
    """
    Main agent class, highest level class - first point of call for user messages.
    Responsible for planning the steps involved in completing the give task and invoking other agents if needed.
    """
    def __init__(self, provider_class: Type[BaseProvider], system_prompt: str, tools: list[ToolSpecification] = None):
        self.llm = provider_class
        self.messages = []
        self.summary = ""

        self.system_prompt = system_prompt
        self.tools = tools

        self.kwargs = {
            "system_prompt": system_prompt,
            "tools": tools
        }
        if not tools:
            self.kwargs.pop("tools")


    def chat(self, message: str | list, mode: str) -> Iterator[str | dict]:
        if not os.
        if not message:
            raise ValueError("Message is empty.")
        
        if isinstance(message, str):
            user_message = Message(role="user", content=message)
            self.messages.append(self.llm.form_message(user_message))
        elif isinstance(message, list):
            tool_result_messages = self.llm.form_message(message)
            if isinstance(tool_result_messages, list):
                results = [t for t in tool_result_messages]
                self.messages.extend(results)
            else:
                self.messages.append(tool_result_messages)

        # If in plan mode, change to read only tools and set new system prompt
        if mode == "Plan":
            from nlsql_coder.app.agent.tools.tool_specs import read_file_spec, get_project_tree_spec, confirm_plan_spec
            from nlsql_coder.app.agent.tools.tool_registry import TOOL_REGISTRY
            from nlsql_coder.app.cli.arg_parsing import args
            root = Path(args.workspace)
            agents_md_path = Path(root, "AGENTS.md")
            agents_md = ""
            if agents_md_path.exists():
                agents_md = agents_md_path.read_text()
            # tools_list = [t for t in TOOL_REGISTRY.keys()]
            # available_tools = [f"- {tool}\n" for tool in tools_list]
            self.kwargs["tools"] = [read_file_spec, get_project_tree_spec, confirm_plan_spec]
            self.kwargs["system_prompt"] = "MODE: PLAN.\n" \
                        "You are a professional planner agent.\n" \
                        "You must analyse the user's request and form a step-by-step plan on how the coder agent will complete the task.\n" \
                        "You must amend the plan accordingly based on the user's input, or stop the planning task by calling the 'ask_user_to_confirm_plan' tool if the user is satisfied with the plan, or has asked you to do so.\n\n" \
                        "Relevant context for the user's project and its current state are below:\n" \
                        f"# Project Details\n{agents_md if agents_md else 'Empty project or no project details.'}\n\n" \
                        "After you have created a plan use the ask_user_to_confirm_plan tool immidiately, do NOT ask the user for feedback - the tool will do this automatically."
                        # f"# Available Tools\n{''.join(available_tools) if available_tools else 'No tools available.'}" \
            added_summary = self.add_summary_to_system(self.kwargs["system_prompt"])
            if added_summary:
                self.kwargs["system_prompt"] = added_summary
        else:
            added_summary = self.add_summary_to_system(self.system_prompt)
            if added_summary:
                self.system_prompt = added_summary
            self.kwargs["system_prompt"] = self.system_prompt
            self.kwargs["tools"] = self.tools

        response = self.llm.stream_chat(self.messages, **self.kwargs)

        accumulated = ""
        tools_used = []
        usage_data = None
        open_ai_type = None
        for chunk in response:
            if isinstance(chunk, str):
                if not "**Using tool:**" in chunk:
                    accumulated += chunk
                yield chunk
            elif isinstance(chunk, dict):
                if chunk.get("response_output"):
                    open_ai_type = chunk["response_output"]
                else:
                    if chunk.get("input_tokens"):
                        usage_data = chunk
                    else:
                        for v in chunk.values():
                            tools_used.append(v)
        
        if accumulated:
            assistant_message = Message(role="assistant", content=accumulated.strip())
            self.messages.append(self.llm.form_message(assistant_message))
        if tools_used:
            if open_ai_type:
                self.messages += open_ai_type
            else:
                tool_message = Message(role="assistant", content=tools_used)
                if tool_message.content:
                    self.messages.append(self.llm.form_message(tool_message))
            yield tools_used

        if usage_data:
            yield usage_data

    
    def delete_plan(self):
        def extract_text(msg):
            content = msg.get("content")
            if isinstance(content, dict):
                return content.get("text", "")
            if isinstance(content, str):
                return content
            return msg.get("text", "")

        self.messages = [
            msg for msg in self.messages
            if "PLAN MODE\n" not in extract_text(msg)
        ]

    
    def add_summary_to_system(self, system_prompt):
        if not self.summary:
            return
        if "# Conversation Summary:" in system_prompt:
            system_prompt = system_prompt.split("\n\n# Conversation Summary:\n")[0].rstrip()
        system_prompt = system_prompt + "\n\n# Conversation Summary:\n" + self.summary
        return system_prompt


    def estimate_words(self):
        return sum(len(m.content.split()) for m in self.messages)


    def manage_context_window(self):
        if self.estimate_words(self.messages) < MAX_WORDS:
            return

        snapshot = self.messages.copy()
        
        if self.summary:
            msg = self.llm.form_message(Message(role="user", content=f"Last Conversation Summary:\n{self.summary}"))
            snapshot.append(msg)

        system_prompt = (
            "Summarise the following conversation. "
            "Preserve key facts, decisions, and open tasks. "
            "Do NOT include instructions or system text."
        )

        response = self.llm.stream_chat(
            snapshot,
            system_prompt=system_prompt
        )

        self.summary = "".join(chunk for chunk in response)

        self.messages = self.messages[-5:]