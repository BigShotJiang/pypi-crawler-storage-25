from nlsql_coder.app.providers.config import ProviderConfig
from nlsql_coder.app.agent.model.agent import Agent
from nlsql_coder.app.agent.tools.tool_specs import read_file_spec, write_file_spec, get_project_tree_spec, edit_file_spec, execute_bash_command_spec, delete_spec, web_search_spec
from nlsql_coder.app.agent.helpers.system_prompt import construct_system_prompt
from nlsql_coder.app.agent.tools.tool_registry import TOOL_REGISTRY
from nlsql_coder.app.cli.interface import KEY_ENV
import os


def _init_mcp(tools: list) -> None:
    """Load mcp.json, connect to servers, extend tools list and TOOL_REGISTRY in-place."""
    try:
        from nlsql_coder.app.agent.tools.mcp_manager import MCPManager, load_mcp_config
    except ImportError:
        print("[MCP] 'mcp' package not installed — skipping MCP support. Run: pip install mcp")
        return

    config = load_mcp_config()
    if not config:
        return

    manager = MCPManager()
    manager.start(config)

    mcp_specs = manager.get_tool_specs()
    mcp_registry = manager.get_registry()

    if mcp_specs:
        print(f"[MCP] Loaded {len(mcp_specs)} tool(s): {', '.join(s.name for s in mcp_specs)}")

    tools.extend(mcp_specs)
    TOOL_REGISTRY.update(mcp_registry)


def get_conf():
    if not os.getenv(KEY_ENV):
        raise ValueError("Missing NLSQL API token. Please set it before using chat.")
    agent = None
    llm = None
    provider_config = ProviderConfig()
    system_prompt = construct_system_prompt()
    tools = [read_file_spec, write_file_spec, get_project_tree_spec, edit_file_spec, execute_bash_command_spec, delete_spec, web_search_spec]

    _init_mcp(tools)

    if provider_config.model_provider == "aws":
        from nlsql_coder.app.providers.aws.provider import AWSBedrockProvider
        model_id = provider_config.model_name
        llm = AWSBedrockProvider(model_id)
        agent = Agent(llm, system_prompt, tools)
        return agent, llm

    if provider_config.model_provider == "azure":
        from nlsql_coder.app.providers.azure.provider import AzureOpenAIProvider
        model_id = provider_config.model_name
        llm = AzureOpenAIProvider(model_id)
        agent = Agent(llm, system_prompt, tools)
        return agent, llm

    if provider_config.model_provider == "gcp":
        from nlsql_coder.app.providers.gcp.provider import GeminiProvider
        model_id = provider_config.model_name
        llm = GeminiProvider(model_id)
        agent = Agent(llm, system_prompt, tools)
        return agent, llm

    return None, None