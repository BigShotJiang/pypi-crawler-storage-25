from nlsql_coder.app.agent.model.agent import Agent
from nlsql_coder.app.agent.helpers.get_agent import get_conf
from nlsql_coder.app.cli.arg_parsing import args
from pathlib import Path
from nlsql_coder.app.agent.tools.tool_specs import read_file_spec, get_project_tree_spec
from nlsql_coder.app.agent.tools.tool_registry import TOOL_REGISTRY

# agent creates plan with user
# user asks to add or says theyre happy
# user gets asked if they want to keep the plan

# "stop" command should work for user in planning mode to stop planning at any point

def plan(console, first_message: str) -> str:
    """Creates a plan for the project/task via iteration with the user."""
    root = Path(args.workspace)
    agents_md_path = Path(root, "AGENTS.md")
    agents_md = ""
    if agents_md_path.exists():
        agents_md = agents_md_path.read_text()

    tools_list = [t for t in TOOL_REGISTRY.keys()]
    available_tools = [f"- {tool}\n" for tool in tools_list]

    planner_system_prompt = "You are a professional planner agent.\n" \
    "You must analyse the user's request, use the 'get_project_tree' and 'read_file' tools if necessary, and form a step-by-step plan on how the coder agent will complete the task with the below listed tools.\n" \
    "You must amend the plan accordingly based on the user's input, or stop the planning task by calling the 'stop_planning' tool if the user is satisfied with the plan or has asked you to do so.\n\n" \
    "Relevant context for the user's project and its current state are below:\n" \
    f"# Project Details\n{agents_md if agents_md else 'Empty project or no project details.'}\n\n" \
    f"# Available Tools\n{''.join(available_tools) if available_tools else 'No tools available.'}"

    _, llm = get_conf()

    tools = [read_file_spec, get_project_tree_spec]

    planner = Agent(llm, planner_system_prompt, tools)

    message = ""
    console.print("[slate_blue1 bold]Planning Mode[/slate_blue1 bold]")
    console.print("[slate_blue1]say 'stop' to stop planning.\n[/slate_blue1]")
    while True:
        message = console.input("\n[purple][Planning mode][/purple][green bold][You]:[/green bold] ")
        if message.lower() in ["stop"]:
            break
        for chunk in planner.chat(message):
            console.print(chunk, end="")