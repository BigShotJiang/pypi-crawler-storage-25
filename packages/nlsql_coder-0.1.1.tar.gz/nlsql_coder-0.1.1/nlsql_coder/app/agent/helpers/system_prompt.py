from datetime import datetime
from pathlib import Path
from nlsql_coder.app.cli.arg_parsing import args


def construct_system_prompt():
    custom_system_prompt = ""
    agents_md = ""

    date_time = datetime.now()

    custom_system_prompt_path = Path(args.workspace, "SYSTEM_PROMPT.md").resolve()
    agents_md_path = Path(args.workspace, "AGENTS.md").resolve()

    custom_system_prompt = custom_system_prompt_path.read_text() if custom_system_prompt_path.exists() else ""
    agents_md = agents_md_path.read_text() if agents_md_path.exists() else ""

    if not custom_system_prompt:
        prompt = "MODE: CODE" \
        "You are an expert coding assistant operating inside nlsql-coder, a coding agent harness. You help users by reading files, executing commands, editing code, and writing new files." \
        "\nGuidelines:\n- Be concise in your response.\n- Plan tasks in your response before executing tools.\n- Use the bash tool to test code snippets or scripts." \
        "\n- Always create virtual environments for package installation and code execution.\n- You may only create ONE .md (or other text based information file) per project unless explicitly asked to create one by the user." \
        "\n- Refer to the project context section of the system prompt to learn about the project, only read more files if asked to or you need to for making changes to the codebase." \
        "\n- If a tool use has been declined by the user NEVER try a different approach, instead ask the user how they would like you to proceed." \
        "\n- NEVER create any summary, overview, guide or other informational documents unless explicitly asked to by the user.\n- When verifying code, read the entire file rather than snippets. Check for syntax errors above anything else." \
        
        if agents_md:
            prompt += f"\n\n# Project Context\n\nProject-specific instructions and guidelines:\n\n{agents_md}"
    
    else:
        prompt = custom_system_prompt
        if "<AGENTS.md>" in custom_system_prompt:
            prompt = custom_system_prompt.replace("<AGENTS.md>", agents_md)

    prompt += f"\n\nCurrent date: {date_time}"
    prompt += f"\n\nCurrent Working Directory: {args.workspace}"

    return prompt
