from nlsql_coder.app.agent.tools.file_tools import FILE_TOOL_REGISTRY
from nlsql_coder.app.agent.tools.bash_tool import BASH_TOOL_REGISTRY
from nlsql_coder.app.agent.tools.planner_tools import PLANNER_TOOL_REGISTRY
from nlsql_coder.app.agent.tools.web_tools import WEB_TOOL_REGISTRY

TOOL_REGISTRY = {
    **FILE_TOOL_REGISTRY,
    **BASH_TOOL_REGISTRY,
    **PLANNER_TOOL_REGISTRY,
    **WEB_TOOL_REGISTRY,
}