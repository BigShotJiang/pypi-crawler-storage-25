from __future__ import annotations

import ast
import difflib
import shutil
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from rich import box as rich_box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from nlsql_coder.app.agent.helpers.project_details import Project
from nlsql_coder.app.agent.tools.helpers import guard_access
from pathlib import Path
from nlsql_coder.app.cli.arg_parsing import args


FILE_TOOL_REGISTRY = {}

project = Project(args.workspace)

def get_project_tree():
    """
    Get's the current project's file tree
    """
    return project.generate_tree()


def read_file(file_path: str, from_line: int = 1, to_line: int = 1000):
    """
    Reads a given file starting at from_line ending at to_line and returns its contents.
    """
    READ_LIMIT = 30_000 # characters (not tokens)
    try:
        root_path = Path(project.root).resolve()
        target_path = (root_path / file_path).resolve()

        if not str(target_path).startswith(str(root_path)):
            return "error: access outside workspace is not allowed."
        
        blocked, reason = guard_access(file_path)
        if blocked:
            return reason

        if from_line > to_line:
            return "error: from_line must be less than or equal to to_line."
        
        contents = []
        with open(target_path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f, start=1):
                if i > to_line:
                    break
                if i >= from_line:
                    contents.append(line)
        
        joined = "".join(contents)
        if len(joined) <= READ_LIMIT:
            return joined

        cut = joined[:READ_LIMIT]
        safe_breaks = ["\n", ";", "}", ")", "]", " "]

        last_break = -1
        for b in safe_breaks:
            pos = cut.rfind(b)
            if pos > last_break:
                last_break = pos

        if last_break > int(READ_LIMIT * 0.7):
            cut = cut[:last_break]

        return cut.rstrip() + "...truncated..."
    except FileNotFoundError:
        return "error: the file does not exist."
    except IsADirectoryError:
        return f"error: {file_path} is a directory."
    except PermissionError:
        return "error: you do not have permission to read this file."
    

def write_file(file_path: str, content: str):
    """
    Writes the given content to a new file at the specified file path.
    """
    try:
        if not file_path:
            return "error: file_path not given."
        if not content:
            return "error: no content given."
        root_path = Path(project.root).resolve()
        target_path = (root_path / file_path).resolve()
        if not str(target_path).startswith(str(root_path)):
            return "error: access outside workspace is not allowed."
        with open(target_path, "w") as f:
            f.write(content)
        return "success"
    except PermissionError:
        return "error: you do not have permission to write to this file."
    except Exception as e:
        return f"error: there was an error writing the file: {e}"


def delete(file_path: str):
    root = Path(project.root).resolve()
    target = (root / file_path).resolve()

    if not target.is_relative_to(root):
        return "error: outside workspace"
    if not target.exists():
        return "error: path does not exist"

    protected = {".git", "node_modules", ".venv", "__pycache__", ".env"}
    if any(part in protected for part in target.relative_to(root).parts):
        return "error: protected path"

    if target.is_file():
        target.unlink()
    else:
        shutil.rmtree(target)

    return f"deleted {file_path}"
        

"""
Comprehensive code editing tool for AI agents.

Supports five operations: replace, insert_before, insert_after, append, prepend.
Targets can be: line number, line range, content match, or AST node (function/class/method).
Always renders a colorized unified diff before writing changes.
"""


_console = Console(highlight=False)


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class Operation(str, Enum):
    REPLACE       = "replace"
    INSERT_BEFORE = "insert_before"
    INSERT_AFTER  = "insert_after"
    APPEND        = "append"
    PREPEND       = "prepend"


class TargetType(str, Enum):
    LINE       = "line"        # single line number (1-indexed)
    LINE_RANGE = "line_range"  # inclusive start..end (1-indexed)
    CONTENT    = "content"     # exact string match (first occurrence)
    AST_FUNC   = "ast_func"    # top-level or nested function by name
    AST_CLASS  = "ast_class"   # class by name
    AST_METHOD = "ast_method"  # method inside a named class


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class Target:
    """Describes what to target in a file."""
    type: TargetType

    # LINE / LINE_RANGE
    line: Optional[int] = None        # 1-indexed; used for LINE
    start_line: Optional[int] = None  # 1-indexed; used for LINE_RANGE
    end_line: Optional[int] = None    # 1-indexed inclusive; used for LINE_RANGE

    # CONTENT
    pattern: Optional[str] = None    # exact multi-line string to locate

    # AST_FUNC / AST_CLASS / AST_METHOD
    node_name: Optional[str] = None  # function, class, or method name
    class_name: Optional[str] = None # owning class for AST_METHOD


@dataclass
class Edit:
    """A single edit instruction."""
    operation: Operation
    content: str
    target: Optional[Target] = None  # not required for APPEND / PREPEND
    description: Optional[str] = None  # human-readable label shown in diff header


# ---------------------------------------------------------------------------
# Diff rendering
# ---------------------------------------------------------------------------
class DiffRenderer:
    """Beautiful side-by-side diff renderer."""

    @staticmethod
    def render(
        original: list[str],
        modified: list[str],
        filename: str = "<file>",
        context: int = 3,
    ) -> str:
        """Return unified diff text."""
        return "".join(
            difflib.unified_diff(
                original,
                modified,
                fromfile=f"a/{filename}",
                tofile=f"b/{filename}",
                n=context,
            )
        )

    @classmethod
    def _build_table(cls, diff_text: str) -> Panel:
        import re

        BG = "#3D3D3D"
        BORDER = "#c0c0c0"

        table = Table(
            box=rich_box.SIMPLE_HEAVY,
            expand=True,
            show_lines=False,
            pad_edge=False,
            padding=(0, 1),
            style=f"on {BG}",
            border_style=BORDER,
        )
        table.add_column("Old", width=6, justify="right", style="bold #ff7b72")
        table.add_column("- Original", ratio=1, overflow="fold", style=f"on {BG}")
        table.add_column("New", width=6, justify="right", style="bold #56d364")
        table.add_column("+ Modified", ratio=1, overflow="fold", style=f"on {BG}")

        old_num = 0
        new_num = 0
        diff_lines = diff_text.splitlines()
        i = 0

        while i < len(diff_lines):
            line = diff_lines[i]

            # File headers
            if not line or line.startswith(("---", "+++")):
                i += 1
                continue

            # Hunk header — parse actual file line numbers
            if line.startswith("@@"):
                m = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", line)
                if m:
                    old_num = int(m.group(1))
                    new_num = int(m.group(2))
                i += 1
                continue

            # Contiguous block of +/- lines — collect then pair with SequenceMatcher
            # scoped to this block only so cross-hunk lines never interfere.
            if line[0] in ("-", "+"):
                removed: list[str] = []
                added: list[str] = []
                while i < len(diff_lines) and diff_lines[i] and diff_lines[i][0] in ("-", "+"):
                    if diff_lines[i][0] == "-":
                        removed.append(diff_lines[i][1:].rstrip("\n"))
                    else:
                        added.append(diff_lines[i][1:].rstrip("\n"))
                    i += 1

                matcher = difflib.SequenceMatcher(None, removed, added, autojunk=False)
                for tag, a1, a2, b1, b2 in matcher.get_opcodes():
                    if tag == "equal":
                        for k in range(a2 - a1):
                            content = removed[a1 + k]
                            table.add_row(
                                Text(str(old_num + a1 + k), style="dim"),
                                Text(f"  {content}", style=f"white on {BG}"),
                                Text(str(new_num + b1 + k), style="dim"),
                                Text(f"  {content}", style=f"white on {BG}"),
                            )
                    elif tag == "replace":
                        for k in range(max(a2 - a1, b2 - b1)):
                            left = removed[a1 + k] if a1 + k < a2 else ""
                            right = added[b1 + k] if b1 + k < b2 else ""
                            left_num = str(old_num + a1 + k) if a1 + k < a2 else ""
                            right_num = str(new_num + b1 + k) if b1 + k < b2 else ""
                            table.add_row(
                                Text(left_num, style="bold #ff7b72"),
                                Text(f"- {left}", style=f"bold #ff7b72 on #2d1117"),
                                Text(right_num, style="bold #56d364"),
                                Text(f"+ {right}", style=f"bold #56d364 on #1e4832"),
                            )
                    elif tag == "delete":
                        for k in range(a1, a2):
                            table.add_row(
                                Text(str(old_num + k), style="bold #ff7b72"),
                                Text(f"- {removed[k]}", style=f"bold #ff7b72 on #431922"),
                                "",
                                Text("", style=f"on {BG}"),
                            )
                    elif tag == "insert":
                        for k in range(b1, b2):
                            table.add_row(
                                "",
                                Text("", style=f"on {BG}"),
                                Text(str(new_num + k), style="bold #56d364"),
                                Text(f"+ {added[k]}", style=f"bold #56d364 on #0f2419"),
                            )

                old_num += len(removed)
                new_num += len(added)
                continue

            # Context line
            if line[0] == " ":
                content = line[1:].rstrip("\n")
                table.add_row(
                    Text(str(old_num), style="dim"),
                    Text(f"  {content}", style=f"white on {BG}"),
                    Text(str(new_num), style="dim"),
                    Text(f"  {content}", style=f"white on {BG}"),
                )
                old_num += 1
                new_num += 1

            i += 1

        return Panel(
            table,
            title="[bold #58a6ff]Diff Preview[/bold #58a6ff]",
            border_style=BORDER,
            padding=(0, 1),
            style=f"on {BG}",
        )

    @classmethod
    def print_diff(
        cls,
        original: list[str],
        modified: list[str],
        filename: str = "<file>",
        label: Optional[str] = None,
    ) -> bool:
        """Print a side-by-side diff panel. Returns True when there are changes."""
        diff = cls.render(original, modified, filename)
        if not diff:
            _console.print("\n[yellow]  (no changes)[/yellow]\n")
            return False

        title = Text()
        if label:
            title.append(label, style="bold white")
            title.append("  ")
        title.append(filename, style="bold cyan")

        _console.print(
            Panel(
                cls._build_table(diff),
                title=title,
                border_style="bright_black",
                padding=(0, 0),
            )
        )
        return True


# ---------------------------------------------------------------------------
# AST-aware location
# ---------------------------------------------------------------------------

class ASTLocator:
    """Locates source ranges for Python AST nodes (1-indexed, inclusive)."""

    @staticmethod
    def _parse(source: str) -> Optional[ast.Module]:
        try:
            return ast.parse(source)
        except SyntaxError:
            return None

    @classmethod
    def find_function(cls, source: str, name: str) -> Optional[tuple[int, int]]:
        tree = cls._parse(source)
        if tree is None:
            return None
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name == name:
                    return node.lineno, node.end_lineno
        return None

    @classmethod
    def find_class(cls, source: str, name: str) -> Optional[tuple[int, int]]:
        tree = cls._parse(source)
        if tree is None:
            return None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == name:
                return node.lineno, node.end_lineno
        return None

    @classmethod
    def find_method(
        cls, source: str, class_name: str, method_name: str
    ) -> Optional[tuple[int, int]]:
        tree = cls._parse(source)
        if tree is None:
            return None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == class_name:
                for item in ast.walk(node):
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        if item.name == method_name:
                            return item.lineno, item.end_lineno
        return None

    @staticmethod
    def find_content(
        lines: list[str], pattern: str
    ) -> Optional[tuple[int, int]]:
        """
        Scan lines for the first exact multi-line match of *pattern*.
        Returns (start, end) 1-indexed inclusive, or None.
        """
        pattern_lines = pattern.splitlines()
        if not pattern_lines:
            return None
        stripped_lines = [ln.rstrip("\n") for ln in lines]
        stripped_pat = [pl.rstrip("\n") for pl in pattern_lines]
        span = len(stripped_pat)

        for i in range(len(stripped_lines) - span + 1):
            if stripped_lines[i : i + span] == stripped_pat:
                return i + 1, i + span
        return None


# ---------------------------------------------------------------------------
# Core editor
# ---------------------------------------------------------------------------

class FileEditor:
    """
    Applies structured edits to a file with diff preview.

    Usage (single edit)::

        editor = FileEditor("myfile.py")
        editor.apply(Edit(
            operation=Operation.REPLACE,
            target=Target(type=TargetType.AST_FUNC, node_name="old_fn"),
            content="def old_fn():\\n    pass\\n",
        ))

    Usage (batch)::

        editor.apply_all([edit1, edit2, edit3], confirm=True)
    """

    def __init__(self, filepath: str, mode: str) -> None:
        self.filepath = Path(args.workspace) / filepath
        self.filename = self.filepath.name
        self._reload()
        self.mode = mode

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _reload(self) -> None:
        with open(self.filepath, "r", encoding="utf-8") as fh:
            self.content = fh.read()
        self.lines: list[str] = self.content.splitlines(keepends=True)

    def _norm(self, text: str) -> list[str]:
        """Return text as a list of newline-terminated lines."""
        if not text.endswith("\n"):
            text += "\n"
        return text.splitlines(keepends=True)

    def _resolve(self, target: Target, lines: list[str], content: str) -> tuple[int, int]:
        """Resolve a Target → (start_line, end_line) 1-indexed inclusive."""
        t = target

        if t.type == TargetType.LINE:
            if t.line is None:
                raise ValueError("Target.line is required for TargetType.LINE")
            return t.line, t.line

        if t.type == TargetType.LINE_RANGE:
            if t.start_line is None or t.end_line is None:
                raise ValueError("start_line and end_line required for LINE_RANGE")
            return t.start_line, t.end_line

        if t.type == TargetType.CONTENT:
            if t.pattern is None:
                raise ValueError("Target.pattern is required for TargetType.CONTENT")
            result = ASTLocator.find_content(lines, t.pattern)
            if result is None:
                raise LookupError(f"Pattern not found in file:\n{t.pattern}")
            return result

        if t.type == TargetType.AST_FUNC:
            if t.node_name is None:
                raise ValueError("Target.node_name is required for AST_FUNC")
            result = ASTLocator.find_function(content, t.node_name)
            if result is None:
                raise LookupError(f"Function '{t.node_name}' not found")
            return result

        if t.type == TargetType.AST_CLASS:
            if t.node_name is None:
                raise ValueError("Target.node_name is required for AST_CLASS")
            result = ASTLocator.find_class(content, t.node_name)
            if result is None:
                raise LookupError(f"Class '{t.node_name}' not found")
            return result

        if t.type == TargetType.AST_METHOD:
            if t.node_name is None or t.class_name is None:
                raise ValueError("node_name and class_name required for AST_METHOD")
            result = ASTLocator.find_method(content, t.class_name, t.node_name)
            if result is None:
                raise LookupError(
                    f"Method '{t.node_name}' in class '{t.class_name}' not found"
                )
            return result

        raise ValueError(f"Unknown TargetType: {t.type}")

    def _simulate(self, edit: Edit, lines: list[str], content: str) -> list[str]:
        """Return what *lines* looks like after applying *edit* (no I/O)."""
        new = list(lines)
        added = self._norm(edit.content)

        if edit.operation == Operation.PREPEND:
            return added + new

        if edit.operation == Operation.APPEND:
            return new + added

        start, end = self._resolve(edit.target, lines, content)
        s = start - 1   # 0-indexed start
        e = end         # 0-indexed exclusive end

        if edit.operation == Operation.REPLACE:
            new[s:e] = added

        elif edit.operation == Operation.INSERT_BEFORE:
            new[s:s] = added

        elif edit.operation == Operation.INSERT_AFTER:
            new[e:e] = added

        return new

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def diff(self, edit: Edit) -> str:
        """Return the rendered diff string for a single edit (no I/O)."""
        modified = self._simulate(edit, self.lines, self.content)
        return DiffRenderer.render(self.lines, modified, self.filename)

    def apply(
        self,
        edit: Edit,
        show_diff: bool = True,
        confirm: bool = False,
    ) -> bool:
        """
        Apply a single edit to the file.

        Args:
            edit:      The edit to apply.
            show_diff: Print a colorized diff to stdout before writing.
            confirm:   Prompt the user for [y/n] confirmation before writing.

        Returns:
            True if the file was written, False if cancelled or no changes.
        """
        modified = self._simulate(edit, self.lines, self.content)

        if show_diff:
            has_changes = DiffRenderer.print_diff(
                self.lines, modified, self.filename, edit.description
            )
            if not has_changes:
                return False

        if confirm:
            while True:
                if self.mode == "Auto":
                    break
                answer = _console.input("\n[bold]Apply changes?[/bold] [dim]\\[y] Yes / \\[n] No / or type feedback to revise:[/dim] ").strip().lower()
                if answer in ["y", "yes"]:
                    break
                if answer in ["n", "no"]:
                    _console.print("[yellow]Aborted.[/yellow]")
                    return False
                else:
                    _console.print(f"[cyan]Feedback recorded:[/cyan] {answer}")

                    return {
                        "apply": False,
                        "feedback": answer
                    }

        self._write(modified)
        _console.print(f"[green]✓ Applied to {self.filename}\n[/green]")
        return True

    def apply_all(
        self,
        edits: list[Edit],
        show_diff: bool = True,
        confirm: bool = False,
    ) -> bool:
        """
        Apply a sequence of edits atomically (all or nothing).

        The combined diff of all edits is shown before any write occurs.
        """
        original_lines = list(self.lines)
        current_lines = list(self.lines)
        current_content = self.content

        for edit in edits:
            current_lines = self._simulate(edit, current_lines, current_content)
            current_content = "".join(current_lines)

        if show_diff:
            has_changes = DiffRenderer.print_diff(
                original_lines, current_lines, self.filename, "batch edits"
            )
            if not has_changes:
                return False

        if confirm:
            answer = _console.input("\n[bold]Apply all changes?[/bold] [dim]\[y/N][/dim] ").strip().lower()
            if answer != "y":
                _console.print("[yellow]Aborted.[/yellow]")
                return False

        self._write(current_lines)
        n = len(edits)
        _console.print(f"[green]✓ Applied {n} edit(s) to {self.filename}[/green]")
        return True

    def _write(self, lines: list[str]) -> None:
        with open(self.filepath, "w", encoding="utf-8") as fh:
            fh.writelines(lines)
        self.lines = lines
        self.content = "".join(lines)


def dispatch_edit(
    filepath: str,
    operation: str,
    content: str,
    mode: str,
    target_type: Optional[str] = None,
    line: Optional[int] = None,
    start_line: Optional[int] = None,
    end_line: Optional[int] = None,
    pattern: Optional[str] = None,
    node_name: Optional[str] = None,
    class_name: Optional[str] = None,
    description: Optional[str] = None,
) -> str:
    """
    Entry point called by the agent framework via tool_function(**tool_input).
    Returns a plain-text result string to send back as tool_result.
    """
    op = Operation(operation)
    desc = description

    target: Target | None = None
    tt = target_type

    if tt is not None:
        target = Target(
            type=TargetType(tt),
            line=line,
            start_line=start_line,
            end_line=end_line,
            pattern=pattern,
            node_name=node_name,
            class_name=class_name,
        )
    elif op not in (Operation.PREPEND, Operation.APPEND):
        return "Edit failed: 'target_type' is required for this operation. Provide one of: line, line_range, content, ast_func, ast_class, ast_method."

    edit = Edit(operation=op, content=content, target=target, description=desc)

    try:
        editor = FileEditor(filepath, mode)
        if not editor.diff(edit):
            return "No changes — the file already matches the requested content."
        applied = editor.apply(edit, show_diff=True, confirm=True)

        if applied is True:
            return f"Edit applied successfully to {filepath}."
        if applied is False:
            return "Edit declined by the user. Do not retry — ask the user how to proceed."
        if isinstance(applied, dict):
            feedback = applied.get("feedback", "")
            return (
                "User requested changes before applying the edit. "
                f"Feedback: {feedback}"
            )
    except (LookupError, ValueError) as exc:
        return f"Edit failed: {exc}"



FILE_TOOL_REGISTRY["read_file"] = read_file
FILE_TOOL_REGISTRY["write_file"] = write_file
FILE_TOOL_REGISTRY["get_project_tree"] = get_project_tree
FILE_TOOL_REGISTRY["edit_file"] = dispatch_edit
FILE_TOOL_REGISTRY["delete"] = delete
