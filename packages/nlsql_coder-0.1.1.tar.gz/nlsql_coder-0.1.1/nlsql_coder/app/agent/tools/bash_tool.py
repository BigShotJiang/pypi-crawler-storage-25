import subprocess
import os
from nlsql_coder.app.cli.arg_parsing import args
from nlsql_coder.app.agent.tools.helpers import guard_access
import shlex

BASH_TOOL_REGISTRY = {}

ALLOWED_COMMANDS = {
    "ls",
    "pwd",
    "cat",
    "grep",
    "python3",
    "python",
    "pip",
    "npm",
    "mkdir",
    "git"
}

ALLOWED_NPM_SUBCOMMANDS = {
    "install",
    "run",
    "test",
    "build",
    "start"
}

def execute_bash_command(command: str) -> dict[str, str]:
    """Executes the given bash command from the root of the current workspace"""
    sensetive, reason = guard_access(command)
    if sensetive:
        return {"error": reason}
    
    parts = shlex.split(command)

    if not parts:
        return {"error": "Empty command"}

    base_command = parts[0]

    if base_command not in ALLOWED_COMMANDS:
        return {"error": f"Command '{base_command}' not allowed"}
    
    if parts[0] == "npm":
        if len(parts) < 2:
            return {"error": "npm subcommand required"}

        if parts[1] not in ALLOWED_NPM_SUBCOMMANDS:
            return {"error": "npm subcommand not allowed"}

    process = subprocess.Popen(
        command,
        env=os.environ.copy(),
        shell=True,
        cwd=args.workspace,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )

    try:
        output, error = process.communicate(timeout=30)
    except Exception as e:
        return {"error": str(e)}
    return {"output": output.decode("utf-8") if output else "success" if process.returncode == 0 else "", "error": error.decode("utf-8"), "return_code": str(process.returncode)}

BASH_TOOL_REGISTRY["execute_bash_command"] = execute_bash_command