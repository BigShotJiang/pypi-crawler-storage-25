"""
OAuth 2.0 + PKCE flow for remote MCP servers.

When a url-based MCP server returns 401, the mcp SDK calls:
  1. redirect_handler(auth_url)  → we open the system browser (non-blocking)
  2. callback_handler()          → we start a local HTTP server, wait for the
                                   browser to redirect back with ?code=...&state=...
                                   then return (code, state) to the SDK

The SDK handles everything else: OAuth metadata discovery, PKCE generation, and
token exchange.

--- Dynamic vs. pre-registered clients ---

By default the mcp SDK performs Dynamic Client Registration (RFC 7591) to
register a new client with a randomly-chosen callback port.  Azure AD / Entra
and many other enterprise OAuth servers do NOT allow DCR — apps must be
pre-registered in the portal.

If your server requires a pre-registered client, add an "oauth" block to
mcp.json:

  {
    "mcpServers": {
      "my-server": {
        "url": "https://...",
        "oauth": {
          "client_id": "<app registration client id>",
          "redirect_uri": "http://localhost:8080/callback"   ← must match portal
        }
      }
    }
  }

With client_id set, we skip DCR and use the supplied client_id directly.
redirect_uri must be pre-approved in your Azure app registration.

--- Token persistence ---

Tokens are cached under ~/.nlsql-coder/tokens/ and reused on subsequent runs.
The browser only re-opens when the access token has expired and the refresh
token is also gone.
"""
import asyncio
import socket
import webbrowser
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from mcp.client.auth import OAuthClientProvider
from mcp.shared.auth import OAuthClientInformationFull, OAuthClientMetadata, OAuthToken


# ------------------------------------------------------------------ #
# Token storage                                                       #
# ------------------------------------------------------------------ #

class CLITokenStorage:
    """
    File-backed TokenStorage.

    If preset_client_info is given it is returned from get_client_info() when
    no saved file exists — this skips the SDK's Dynamic Client Registration step
    for servers that require pre-registered clients (e.g. Azure AD).
    """

    def __init__(
        self,
        server_name: str,
        preset_client_info: OAuthClientInformationFull | None = None,
    ) -> None:
        base = Path.home() / ".nlsql-coder" / "tokens"
        base.mkdir(parents=True, exist_ok=True)
        self._tokens_path = base / f"{server_name}_tokens.json"
        self._client_path = base / f"{server_name}_client.json"
        self._preset = preset_client_info

    async def get_tokens(self) -> OAuthToken | None:
        if not self._tokens_path.exists():
            return None
        try:
            return OAuthToken.model_validate_json(self._tokens_path.read_text())
        except Exception:
            return None

    async def set_tokens(self, tokens: OAuthToken) -> None:
        self._tokens_path.write_text(tokens.model_dump_json())

    async def get_client_info(self) -> OAuthClientInformationFull | None:
        if self._client_path.exists():
            try:
                return OAuthClientInformationFull.model_validate_json(
                    self._client_path.read_text()
                )
            except Exception:
                pass
        return self._preset  # None if not preset → SDK will do DCR

    async def set_client_info(self, client_info: OAuthClientInformationFull) -> None:
        self._client_path.write_text(client_info.model_dump_json())


# ------------------------------------------------------------------ #
# Local callback HTTP server                                          #
# ------------------------------------------------------------------ #

def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


async def _wait_for_callback(port: int) -> tuple[str, str | None]:
    """Spin up a temporary async HTTP server and block until the OAuth callback arrives."""
    loop = asyncio.get_running_loop()
    code_future: asyncio.Future[tuple[str, str | None]] = loop.create_future()

    async def _handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        code: str | None = None
        state: str | None = None
        error: str | None = None

        try:
            data = await asyncio.wait_for(reader.read(4096), timeout=10)
            request_line = data.decode(errors="replace").split("\r\n")[0]
            parts = request_line.split(" ")
            if len(parts) >= 2:
                params = parse_qs(urlparse(parts[1]).query)
                code = params.get("code", [None])[0]
                state = params.get("state", [None])[0]
                error = params.get(
                    "error_description", params.get("error", [None])
                )[0]

            html = (
                f"<h2>Authentication failed</h2><p>{error}</p>"
                "<p>You can close this tab.</p>"
            ).encode() if error else (
                b"<h2>Authentication successful!</h2>"
                b"<p>You can close this tab.</p>"
            )
            writer.write(
                b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n"
                b"Connection: close\r\n\r\n" + html
            )
            await writer.drain()
        except Exception:
            pass
        finally:
            try:
                writer.close()
            except Exception:
                pass

        if not code_future.done():
            if error:
                code_future.set_exception(RuntimeError(f"OAuth error: {error}"))
            elif code:
                code_future.set_result((code, state))

    server = await asyncio.start_server(_handle, "127.0.0.1", port)
    try:
        return await asyncio.wait_for(code_future, timeout=300.0)
    finally:
        server.close()
        await server.wait_closed()


# ------------------------------------------------------------------ #
# Public factory                                                      #
# ------------------------------------------------------------------ #

def build_oauth_auth(
    server_name: str,
    server_url: str,
    client_id: str | None = None,
    redirect_uri: str | None = None,
) -> OAuthClientProvider:
    """
    Return an OAuthClientProvider for the given remote MCP server.

    client_id     — supply this when DCR is not supported (e.g. Azure AD).
                    Must match an app registration in the OAuth server.
    redirect_uri  — the callback URL registered in the OAuth server.
                    Defaults to http://localhost:<random-port>/callback.
                    Only needed when client_id is set (and must match the portal).
    """
    # Resolve the callback port
    if redirect_uri:
        parsed = urlparse(redirect_uri)
        port = parsed.port or 80
        callback_uri = redirect_uri
    else:
        port = _find_free_port()
        callback_uri = f"http://localhost:{port}/callback"

    # Build preset client info to skip DCR when client_id is pre-supplied
    preset_client_info: OAuthClientInformationFull | None = None
    if client_id:
        preset_client_info = OAuthClientInformationFull(
            client_id=client_id,
            redirect_uris=[callback_uri],
            grant_types=["authorization_code", "refresh_token"],
            response_types=["code"],
            token_endpoint_auth_method="none",
        )

    storage = CLITokenStorage(server_name, preset_client_info=preset_client_info)

    client_metadata = OAuthClientMetadata(
        client_name="nlsql-coder",
        redirect_uris=[callback_uri],
        grant_types=["authorization_code", "refresh_token"],
        response_types=["code"],
        token_endpoint_auth_method="none",
    )

    async def redirect_handler(url: str) -> None:
        print(f"\n[MCP OAuth] Authenticating with '{server_name}'...")
        print(
            f"[MCP OAuth] Opening browser — if it doesn't open, paste this URL:\n  {url}\n"
        )
        webbrowser.open(url)

    async def callback_handler() -> tuple[str, str | None]:
        return await _wait_for_callback(port)

    return OAuthClientProvider(
        server_url=server_url,
        client_metadata=client_metadata,
        storage=storage,
        redirect_handler=redirect_handler,
        callback_handler=callback_handler,
    )
