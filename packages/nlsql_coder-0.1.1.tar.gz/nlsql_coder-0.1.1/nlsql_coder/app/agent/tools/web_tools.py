from ddgs import DDGS
from bs4 import BeautifulSoup
import requests
import json

WEB_TOOL_REGISTRY = {}

def extract_text_from_url(url: str) -> str:
    headers = {"User-Agent": "Mozilla/5.0"}

    response = requests.get(url, headers=headers, timeout=10)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "lxml")

    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    text = soup.get_text(separator=" ")

    return " ".join(text.split())


def search_the_web(text: str, results: int = 5):
    """
    Search the web for results OR extact content for a URL
    """
    if text.startswith("https://"):
        return extract_text_from_url(text)
    else:
        with DDGS() as ddg:
            results = ddg.text(query=text, max_results=results)
            return json.dumps(results)
        

WEB_TOOL_REGISTRY["search_the_web"] = search_the_web