from pathlib import Path
import re
import shlex

######################### Sensetive file protection #################################################

SENSITIVE_FILE_PATTERNS = [
    r"^\.env",    
    r"\.pem$",                
    r"\.key$",               
    r"id_rsa$",               
    r"\.p12$",                
    r"\.pfx$",
    r"\.secret",
    r"credentials",
    r"service_account",
]

SENSITIVE_EXACT_NAMES = {
    ".env",
    ".env.local",
    ".env.production",
    ".env.development",
    "id_rsa",
    "id_ed25519",
}

def is_sensitive(string: str) -> tuple[bool, str]:
    tokens = shlex.split(string)

    for token in tokens:
        if token in SENSITIVE_EXACT_NAMES:
            return True, f"blocked: '{token}' is a protected secret file"

        for pattern in SENSITIVE_FILE_PATTERNS:
            if re.search(pattern, token, re.IGNORECASE):
                return True, f"blocked: '{token}' matches sensitive pattern '{pattern}'"

    return False, ""


def guard_access(string: str):
    sensitive, reason = is_sensitive(string)
    if sensitive:
        return True, reason
    return False, ""

###################################################################################################