"""
MCP (Model Context Protocol) server manager.

Reads mcp.json from the project root or ~/.nlsql-coder/mcp.json.

Config format (same as Claude Desktop):
  {
    "mcpServers": {
      "local-server": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
        "env": {}
      },
      "remote-sse": {
        "url": "https://api.example.com/mcp",
        "transport": "sse",
        "headers": { "Authorization": "Bearer sk-..." }
      },
      "remote-http": {
        "url": "https://api.example.com/mcp",
        "headers": { "Authorization": "Bearer sk-..." }
      }
    }
  }

Transports:
  - command present           → stdio (local subprocess)
  - url + transport="sse"     → SSE (legacy HTTP servers)
  - url (default)             → Streamable HTTP (modern servers)
"""
import asyncio
import json
import threading
from pathlib import Path
from typing import Optional

from nlsql_coder.app.providers.base import ToolSpecification, ToolSchema, ToolProperty


class MCPManager:
    def __init__(self) -> None:
        self._sessions: dict[str, object] = {}
        self._tools: dict[str, list] = {}        # server_name → [mcp.Tool]
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._all_ready = threading.Event()
        self._stop_event: Optional[asyncio.Event] = None

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    def start(self, config: dict) -> None:
        """Connect to all servers in *config* (blocks until ready or timeout)."""
        if not config:
            self._all_ready.set()
            return
        self._thread = threading.Thread(
            target=self._run_loop, args=(config,), daemon=True
        )
        self._thread.start()
        self._all_ready.wait(timeout=30)

    def get_tool_specs(self) -> list[ToolSpecification]:
        specs = []
        for tools in self._tools.values():
            for tool in tools:
                specs.append(self._mcp_tool_to_spec(tool))
        return specs

    def get_registry(self) -> dict[str, callable]:
        """Return {tool_name: callable} for every MCP tool discovered."""
        registry = {}
        for server_name, tools in self._tools.items():
            for tool in tools:
                registry[tool.name] = self._make_callable(server_name, tool.name)
        return registry

    def stop(self) -> None:
        if self._loop and self._stop_event:
            self._loop.call_soon_threadsafe(self._stop_event.set)

    # ------------------------------------------------------------------ #
    # Background event loop                                               #
    # ------------------------------------------------------------------ #

    def _run_loop(self, config: dict) -> None:
        asyncio.run(self._main(config))

    async def _main(self, config: dict) -> None:
        self._loop = asyncio.get_running_loop()
        self._stop_event = asyncio.Event()

        ready_events = []
        tasks = []
        for server_name, server_config in config.items():
            ready = asyncio.Event()
            ready_events.append(ready)
            tasks.append(
                asyncio.create_task(
                    self._connect_server(server_name, server_config, ready)
                )
            )

        try:
            await asyncio.wait_for(
                asyncio.gather(*[e.wait() for e in ready_events]),
                timeout=15,
            )
        except asyncio.TimeoutError:
            pass

        self._all_ready.set()
        await self._stop_event.wait()

    async def _connect_server(
        self, name: str, config: dict, ready: asyncio.Event
    ) -> None:
        try:
            if "command" in config:
                await self._connect_stdio(name, config, ready)
            elif "url" in config:
                transport = config.get("transport", "http")
                if transport == "sse":
                    await self._connect_sse(name, config, ready)
                else:
                    await self._connect_http(name, config, ready)
            else:
                print(f"[MCP] '{name}': config must have 'command' or 'url'")
                ready.set()
        except Exception as e:
            print(f"[MCP] Failed to connect to '{name}': {e}")
            ready.set()

    async def _connect_stdio(
        self, name: str, config: dict, ready: asyncio.Event
    ) -> None:
        from mcp import ClientSession
        from mcp.client.stdio import stdio_client, StdioServerParameters

        params = StdioServerParameters(
            command=config["command"],
            args=config.get("args", []),
            env=config.get("env") or None,
        )
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                self._sessions[name] = session
                self._tools[name] = result.tools
                ready.set()
                await self._stop_event.wait()

    async def _connect_sse(
        self, name: str, config: dict, ready: asyncio.Event
    ) -> None:
        from mcp import ClientSession
        from mcp.client.sse import sse_client
        from nlsql_coder.app.agent.tools.mcp_oauth import build_oauth_auth

        url = config["url"]
        headers = config.get("headers", {})
        auth = None if "Authorization" in headers else build_oauth_auth(name, url, **_oauth_kwargs(config))
        async with sse_client(url, headers=headers, auth=auth) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                self._sessions[name] = session
                self._tools[name] = result.tools
                ready.set()
                await self._stop_event.wait()

    async def _connect_http(
        self, name: str, config: dict, ready: asyncio.Event
    ) -> None:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client
        from nlsql_coder.app.agent.tools.mcp_oauth import build_oauth_auth

        url = config["url"]
        headers = config.get("headers", {})
        auth = None if "Authorization" in headers else build_oauth_auth(name, url, **_oauth_kwargs(config))
        async with streamablehttp_client(url, headers=headers, auth=auth) as (read, write, _):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                self._sessions[name] = session
                self._tools[name] = result.tools
                ready.set()
                await self._stop_event.wait()

    # ------------------------------------------------------------------ #
    # Tool calling                                                        #
    # ------------------------------------------------------------------ #

    def _make_callable(self, server_name: str, tool_name: str) -> callable:
        def call(**kwargs):
            if not self._loop:
                return "error: MCP manager not started"
            future = asyncio.run_coroutine_threadsafe(
                self._call_tool(server_name, tool_name, kwargs),
                self._loop,
            )
            try:
                return future.result(timeout=60)
            except Exception as e:
                return f"error calling MCP tool '{tool_name}': {e}"

        return call

    async def _call_tool(
        self, server_name: str, tool_name: str, args: dict
    ) -> str:
        session = self._sessions.get(server_name)
        if not session:
            return f"error: no active session for server '{server_name}'"
        result = await session.call_tool(tool_name, args)
        parts = []
        for block in result.content:
            if hasattr(block, "text"):
                parts.append(block.text)
            else:
                parts.append(str(block))
        return "\n".join(parts) if parts else "ok"

    # ------------------------------------------------------------------ #
    # Schema conversion                                                   #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _mcp_tool_to_spec(tool) -> ToolSpecification:
        input_schema = tool.inputSchema or {}
        raw_props = input_schema.get("properties") or {}
        required = input_schema.get("required") or []

        properties = {
            name: MCPManager._json_schema_to_property(schema)
            for name, schema in raw_props.items()
        }

        return ToolSpecification(
            name=tool.name,
            description=tool.description or "",
            schema=ToolSchema(
                type="object",
                properties=properties,
                required=required,
            ),
        )

    @staticmethod
    def _json_schema_to_property(schema: dict) -> ToolProperty:
        prop_type = schema.get("type", "string")
        description = schema.get("description", "")
        default = schema.get("default")

        items = None
        if prop_type == "array" and "items" in schema:
            items = MCPManager._json_schema_to_property(schema["items"])

        nested_props = None
        nested_required = None
        if prop_type == "object" and "properties" in schema:
            nested_props = {
                k: MCPManager._json_schema_to_property(v)
                for k, v in schema["properties"].items()
            }
            nested_required = schema.get("required", [])

        return ToolProperty(
            type=prop_type,
            description=description,
            default=default,
            items=items,
            properties=nested_props,
            required=nested_required,
        )


# ------------------------------------------------------------------ #
# Helpers                                                             #
# ------------------------------------------------------------------ #

def _oauth_kwargs(config: dict) -> dict:
    """Extract optional client_id / redirect_uri from the 'oauth' config block."""
    oauth = config.get("oauth")
    if not isinstance(oauth, dict):
        return {}
    return {k: oauth[k] for k in ("client_id", "redirect_uri") if k in oauth}


# ------------------------------------------------------------------ #
# Config loading                                                      #
# ------------------------------------------------------------------ #

def load_mcp_config() -> dict:
    """Return mcpServers dict from mcp.json in project root or ~/.nlsql-coder/mcp.json."""
    candidates = [
        Path.cwd() / "mcp.json",
        Path.home() / ".nlsql-coder" / "mcp.json",
    ]
    for path in candidates:
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                return data.get("mcpServers", {})
            except Exception as e:
                print(f"[MCP] Failed to parse {path}: {e}")
    return {}
