"""GoXLRClient – high-level async API for the GoXLR Utility daemon."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from typing import Any

from goxlrutil_api.colour import Colour, ColourLike, as_hex
from goxlrutil_api.events import ButtonEvent, ButtonEventType
from goxlrutil_api.exceptions import CommandError
from goxlrutil_api.protocol.commands import DaemonRequest, GoXLRCommand
from goxlrutil_api.protocol.responses import DaemonResponse, DaemonStatus, MixerStatus
from goxlrutil_api.protocol.types import (
    AnimationMode,
    Button,
    ButtonColourGroups,
    ButtonColourOffStyle,
    ChannelName,
    CompressorAttackTime,
    CompressorRatio,
    CompressorReleaseTime,
    DisplayMode,
    DisplayModeComponents,
    EchoStyle,
    EffectBankPresets,
    EncoderColourTargets,
    EqFrequencies,
    FaderDisplayStyle,
    FaderName,
    GateTimes,
    GenderStyle,
    HardTuneSource,
    HardTuneStyle,
    InputDevice,
    MegaphoneStyle,
    MicrophoneType,
    MiniEqFrequencies,
    Mix,
    MuteFunction,
    MuteState,
    OutputDevice,
    PitchStyle,
    ReverbStyle,
    RobotRange,
    RobotStyle,
    SampleBank,
    SampleButtons,
    SamplePlaybackMode,
    SamplePlayOrder,
    SamplerColourTargets,
    SimpleColourTargets,
    VodMode,
    WaterfallDirection,
)
from goxlrutil_api.state import DaemonState
from goxlrutil_api.transport.base import Transport

_log = logging.getLogger(__name__)

PatchListener = Callable[[DaemonStatus], Awaitable[None]]
ButtonListener = Callable[[ButtonEvent], Awaitable[None]]
ConnectListener = Callable[[], Awaitable[None]]
DisconnectListener = Callable[[], Awaitable[None]]


class GoXLRClient:
    """
    Async client for the GoXLR Utility daemon.

    Usage::

        async with GoXLRClient(transport) as client:
            status = await client.get_status()
            serial = next(iter(status.mixers))
            await client.set_volume(serial, ChannelName.Mic, 200)

    To receive live state updates (requires WebSocketTransport)::

        async def on_update(status: DaemonStatus) -> None:
            print(status.mixers)

        async with GoXLRClient(transport, on_state_update=on_update) as client:
            ...

    To receive button press / release / long-press events (requires WebSocketTransport)::

        async def on_button(event: ButtonEvent) -> None:
            print(event.button, event.event_type, event.held_seconds)

        async with GoXLRClient(transport, on_button_event=on_button) as client:
            ...

    To react to connection loss and reconnection (useful for Home Assistant and similar)::

        async def on_connect() -> None:
            print("GoXLR daemon connected")

        async def on_disconnect() -> None:
            print("GoXLR daemon disconnected – marking entities unavailable")

        async with GoXLRClient(
            transport,
            on_connect=on_connect,
            on_disconnect=on_disconnect,
        ) as client:
            ...

    When the transport reconnects the client will automatically re-fetch the full
    daemon status so the internal state cache is immediately up to date.
    """

    def __init__(
        self,
        transport: Transport,
        on_state_update: PatchListener | None = None,
        on_button_event: ButtonListener | None = None,
        on_connect: ConnectListener | None = None,
        on_disconnect: DisconnectListener | None = None,
        long_press_threshold: float = 0.5,
    ) -> None:
        self._transport = transport
        self._state = DaemonState()
        self._on_state_update = on_state_update
        self._on_button_event_cb = on_button_event
        self._on_connect_cb = on_connect
        self._on_disconnect_cb = on_disconnect
        self._long_press_threshold = long_press_threshold
        # {serial: {button_name: monotonic press time}}
        self._button_press_times: dict[str, dict[str, float]] = {}
        # {serial: {button_name: pending long-press Task}}
        self._long_press_tasks: dict[str, dict[str, asyncio.Task[None]]] = {}

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> GoXLRClient:
        await self._transport.connect()
        await self._transport.subscribe(self._on_patch)
        await self._transport.subscribe_connect(self._on_reconnected)
        await self._transport.subscribe_disconnect(self._on_disconnected)
        return self

    async def __aexit__(self, *_: object) -> None:
        self._cancel_all_long_press_tasks()
        await self._transport.disconnect()

    # ------------------------------------------------------------------
    # Core methods
    # ------------------------------------------------------------------

    async def ping(self) -> bool:
        """Return True if the daemon responds to a ping."""
        resp = await self._transport.send(DaemonRequest.ping())
        return resp.ok

    async def get_status(self) -> DaemonStatus:
        """Fetch full daemon status and update internal state cache."""
        resp = await self._send_checked(DaemonRequest.get_status())
        if resp.raw_status is not None:
            self._state.set_raw(resp.raw_status)
        return self._state.status

    async def get_mic_level(self, serial: str) -> float:
        """Return the current microphone level (0.0–1.0) for the given mixer."""
        resp = await self._send_checked(DaemonRequest.get_mic_level(serial))
        if resp.mic_level is None:
            return 0.0
        return resp.mic_level

    async def command(self, serial: str, cmd: GoXLRCommand) -> None:
        """Send a GoXLR command to a specific mixer."""
        await self._send_checked(DaemonRequest.command(serial, cmd))

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    @property
    def serials(self) -> list[str]:
        """Return the list of connected mixer serial numbers from the state cache.

        Call ``get_status()`` at least once to populate the cache.
        """
        return list(self._state.status.mixers.keys())

    def get_mixer(self, serial: str) -> MixerStatus | None:
        """Return the cached ``MixerStatus`` for *serial*, or ``None`` if not found.

        This is a synchronous, zero-latency read from the in-memory state cache.
        It is the recommended way for Home Assistant (and similar) to access
        individual mixer state without issuing a network request on every poll.
        """
        return self._state.status.mixers.get(serial)

    async def set_volume(self, serial: str, channel: ChannelName, volume: int) -> None:
        """Set channel volume (0–255)."""
        await self.command(serial, GoXLRCommand.set_volume(channel, volume))

    async def set_volume_pct(self, serial: str, channel: ChannelName, percent: float) -> None:
        """Set channel volume as a percentage (0–100 → 0–255).

        Values outside 0–100 are clamped silently.
        """
        volume = round(max(0.0, min(100.0, percent)) / 100 * 255)
        await self.command(serial, GoXLRCommand.set_volume(channel, volume))

    async def set_fader_mute_state(self, serial: str, fader: FaderName, state: MuteState) -> None:
        await self.command(serial, GoXLRCommand.set_fader_mute_state(fader, state))

    async def set_fx_enabled(self, serial: str, enabled: bool) -> None:
        """Enable or disable all effects."""
        await self.command(serial, GoXLRCommand.set_fx_enabled(enabled))

    async def toggle_fx(self, serial: str) -> bool:
        """Toggle FX on/off. Reads fresh state, returns the new enabled state."""
        status = await self.get_status()
        mixer = status.mixers.get(serial)
        current = mixer.effects.is_enabled if mixer and mixer.effects else False
        new_state = not current
        await self.set_fx_enabled(serial, new_state)
        return new_state

    # ------------------------------------------------------------------
    # Effects – presets
    # ------------------------------------------------------------------

    async def set_active_effect_preset(
        self, serial: str, preset: EffectBankPresets
    ) -> None:
        """Switch the active effect bank preset (Preset1–Preset6)."""
        await self.command(serial, GoXLRCommand.set_active_effect_preset(preset))

    # ------------------------------------------------------------------
    # Effects – individual voices
    # ------------------------------------------------------------------

    async def set_megaphone_enabled(self, serial: str, enabled: bool) -> None:
        """Enable or disable the Megaphone voice effect."""
        await self.command(serial, GoXLRCommand.set_megaphone_enabled(enabled))

    async def set_megaphone_style(self, serial: str, style: MegaphoneStyle) -> None:
        await self.command(serial, GoXLRCommand.set_megaphone_style(style))

    async def set_megaphone_amount(self, serial: str, amount: int) -> None:
        """Set megaphone amount (0–100)."""
        await self.command(serial, GoXLRCommand.set_megaphone_amount(amount))

    async def set_megaphone_post_gain(self, serial: str, gain: int) -> None:
        """Set megaphone post gain (-20..20 dB)."""
        await self.command(serial, GoXLRCommand.set_megaphone_post_gain(gain))

    async def toggle_megaphone(self, serial: str) -> bool:
        """Toggle Megaphone on/off. Reads fresh state, returns the new enabled state."""
        status = await self.get_status()
        mixer = status.mixers.get(serial)
        current = (
            mixer.effects.current.megaphone.is_enabled
            if mixer and mixer.effects
            else False
        )
        new_state = not current
        await self.set_megaphone_enabled(serial, new_state)
        return new_state

    async def set_robot_enabled(self, serial: str, enabled: bool) -> None:
        """Enable or disable the Robot voice effect."""
        await self.command(serial, GoXLRCommand.set_robot_enabled(enabled))

    async def set_robot_style(self, serial: str, style: RobotStyle) -> None:
        await self.command(serial, GoXLRCommand.set_robot_style(style))

    async def set_robot_gain(self, serial: str, range_: RobotRange, gain: int) -> None:
        await self.command(serial, GoXLRCommand.set_robot_gain(range_, gain))

    async def set_robot_freq(self, serial: str, range_: RobotRange, freq: int) -> None:
        await self.command(serial, GoXLRCommand.set_robot_freq(range_, freq))

    async def set_robot_width(self, serial: str, range_: RobotRange, width: int) -> None:
        await self.command(serial, GoXLRCommand.set_robot_width(range_, width))

    async def set_robot_waveform(self, serial: str, waveform: int) -> None:
        await self.command(serial, GoXLRCommand.set_robot_waveform(waveform))

    async def set_robot_pulse_width(self, serial: str, width: int) -> None:
        await self.command(serial, GoXLRCommand.set_robot_pulse_width(width))

    async def set_robot_threshold(self, serial: str, threshold: int) -> None:
        await self.command(serial, GoXLRCommand.set_robot_threshold(threshold))

    async def set_robot_dry_mix(self, serial: str, mix: int) -> None:
        await self.command(serial, GoXLRCommand.set_robot_dry_mix(mix))

    async def toggle_robot(self, serial: str) -> bool:
        """Toggle Robot on/off. Reads fresh state, returns the new enabled state."""
        status = await self.get_status()
        mixer = status.mixers.get(serial)
        current = (
            mixer.effects.current.robot.is_enabled
            if mixer and mixer.effects
            else False
        )
        new_state = not current
        await self.set_robot_enabled(serial, new_state)
        return new_state

    async def set_hard_tune_enabled(self, serial: str, enabled: bool) -> None:
        """Enable or disable the Hard Tune voice effect."""
        await self.command(serial, GoXLRCommand.set_hard_tune_enabled(enabled))

    async def set_hard_tune_style(self, serial: str, style: HardTuneStyle) -> None:
        await self.command(serial, GoXLRCommand.set_hard_tune_style(style))

    async def set_hard_tune_amount(self, serial: str, amount: int) -> None:
        await self.command(serial, GoXLRCommand.set_hard_tune_amount(amount))

    async def set_hard_tune_rate(self, serial: str, rate: int) -> None:
        await self.command(serial, GoXLRCommand.set_hard_tune_rate(rate))

    async def set_hard_tune_window(self, serial: str, window: int) -> None:
        await self.command(serial, GoXLRCommand.set_hard_tune_window(window))

    async def set_hard_tune_source(self, serial: str, source: HardTuneSource) -> None:
        await self.command(serial, GoXLRCommand.set_hard_tune_source(source))

    async def toggle_hard_tune(self, serial: str) -> bool:
        """Toggle Hard Tune on/off. Reads fresh state, returns the new enabled state."""
        status = await self.get_status()
        mixer = status.mixers.get(serial)
        current = (
            mixer.effects.current.hard_tune.is_enabled
            if mixer and mixer.effects
            else False
        )
        new_state = not current
        await self.set_hard_tune_enabled(serial, new_state)
        return new_state

    # ------------------------------------------------------------------
    # Sampler
    # ------------------------------------------------------------------

    async def play_sample(
        self, serial: str, bank: SampleBank, button: SampleButtons
    ) -> None:
        """Trigger playback of the sample assigned to a bank+button slot."""
        await self.command(serial, GoXLRCommand.play_next_sample(bank, button))

    async def stop_sample(
        self, serial: str, bank: SampleBank, button: SampleButtons
    ) -> None:
        """Stop playback for the given bank+button slot."""
        await self.command(serial, GoXLRCommand.stop_sample_playback(bank, button))

    async def set_sampler_function(
        self, serial: str, bank: SampleBank, button: SampleButtons, mode: SamplePlaybackMode
    ) -> None:
        await self.command(serial, GoXLRCommand.set_sampler_function(bank, button, mode))

    async def set_sampler_order(
        self, serial: str, bank: SampleBank, button: SampleButtons, order: SamplePlayOrder
    ) -> None:
        await self.command(serial, GoXLRCommand.set_sampler_order(bank, button, order))

    async def add_sample(
        self, serial: str, bank: SampleBank, button: SampleButtons, path: str
    ) -> None:
        await self.command(serial, GoXLRCommand.add_sample(bank, button, path))

    async def remove_sample_by_index(
        self, serial: str, bank: SampleBank, button: SampleButtons, index: int
    ) -> None:
        await self.command(serial, GoXLRCommand.remove_sample_by_index(bank, button, index))

    async def set_sample_start_percent(
        self, serial: str, bank: SampleBank, button: SampleButtons, index: int, percent: float
    ) -> None:
        await self.command(
            serial, GoXLRCommand.set_sample_start_percent(bank, button, index, percent)
        )

    async def set_sample_stop_percent(
        self, serial: str, bank: SampleBank, button: SampleButtons, index: int, percent: float
    ) -> None:
        await self.command(
            serial, GoXLRCommand.set_sample_stop_percent(bank, button, index, percent)
        )

    async def set_sampler_fade_duration(self, serial: str, ms: int) -> None:
        await self.command(serial, GoXLRCommand.set_sampler_fade_duration(ms))

    async def set_sampler_reset_on_clear(self, serial: str, reset: bool) -> None:
        await self.command(serial, GoXLRCommand.set_sampler_reset_on_clear(reset))

    # ------------------------------------------------------------------
    # Profiles
    # ------------------------------------------------------------------

    async def list_profiles(self, serial: str) -> list[str]:
        """Return the list of available profile names."""
        status = await self.get_status()
        _ = status.mixers.get(serial)  # validate serial exists
        return list(status.files.profiles)

    async def get_current_profile(self, serial: str) -> str:
        """Return the name of the currently loaded profile."""
        status = await self.get_status()
        mixer = status.mixers.get(serial)
        return mixer.profile_name if mixer else ""

    async def load_profile(self, serial: str, name: str) -> None:
        """Load a profile by name. Pass ``persist=False`` to skip saving."""
        await self.command(serial, GoXLRCommand.load_profile(name))

    async def list_mic_profiles(self, serial: str) -> list[str]:
        """Return the list of available mic profile names."""
        status = await self.get_status()
        _ = status.mixers.get(serial)
        return list(status.files.mic_profiles)

    async def get_current_mic_profile(self, serial: str) -> str:
        """Return the name of the currently loaded mic profile."""
        status = await self.get_status()
        mixer = status.mixers.get(serial)
        return mixer.mic_profile_name if mixer else ""

    async def load_mic_profile(self, serial: str, name: str) -> None:
        """Load a mic profile by name."""
        await self.command(serial, GoXLRCommand.load_mic_profile(name))

    async def save_profile(self, serial: str) -> None:
        """Save the current settings to the active profile."""
        await self.command(serial, GoXLRCommand.save_profile())

    async def save_profile_as(self, serial: str, name: str) -> None:
        """Save the current settings as a new profile."""
        await self.command(serial, GoXLRCommand.save_profile_as(name))

    async def save_mic_profile(self, serial: str) -> None:
        """Save the current mic settings to the active mic profile."""
        await self.command(serial, GoXLRCommand.save_mic_profile())

    async def save_mic_profile_as(self, serial: str, name: str) -> None:
        """Save the current mic settings as a new mic profile."""
        await self.command(serial, GoXLRCommand.save_mic_profile_as(name))

    async def load_profile_colours(self, serial: str, name: str) -> None:
        """Load only the colour settings from a profile."""
        await self.command(serial, GoXLRCommand.load_profile_colours(name))

    async def rename_active_preset(self, serial: str, name: str) -> None:
        """Rename the currently active effect preset."""
        await self.command(serial, GoXLRCommand.rename_active_preset(name))

    # ------------------------------------------------------------------
    # Routing matrix
    # ------------------------------------------------------------------

    async def set_router(
        self, serial: str, input: InputDevice, output: OutputDevice, enabled: bool
    ) -> None:
        """Enable or disable a routing matrix cross-point (input → output)."""
        await self.command(serial, GoXLRCommand.set_router(input, output, enabled))

    # ------------------------------------------------------------------
    # Fader assignment
    # ------------------------------------------------------------------

    async def set_fader(self, serial: str, fader: FaderName, channel: ChannelName) -> None:
        """Assign a channel to a fader slot."""
        await self.command(serial, GoXLRCommand.set_fader(fader, channel))

    async def set_fader_mute_function(
        self, serial: str, fader: FaderName, mute_function: MuteFunction
    ) -> None:
        """Set how the mute button on a fader behaves (which outputs it mutes)."""
        await self.command(serial, GoXLRCommand.set_fader_mute_function(fader, mute_function))

    async def set_cough_mute_state(self, serial: str, state: MuteState) -> None:
        """Set the mute state of the Cough button."""
        await self.command(serial, GoXLRCommand.set_cough_mute_state(state))

    async def set_cough_mute_function(self, serial: str, mute: MuteFunction) -> None:
        """Set the mute function for the cough button."""
        await self.command(serial, GoXLRCommand.set_cough_mute_function(mute))

    async def set_cough_is_hold(self, serial: str, hold: bool) -> None:
        """Set whether the cough button acts as hold (True) or toggle (False)."""
        await self.command(serial, GoXLRCommand.set_cough_is_hold(hold))

    # ------------------------------------------------------------------
    # Effect parameters
    # ------------------------------------------------------------------

    async def set_reverb_style(self, serial: str, style: ReverbStyle) -> None:
        """Set the reverb effect style."""
        await self.command(serial, GoXLRCommand.set_reverb_style(style))

    async def set_reverb_amount(self, serial: str, amount: int) -> None:
        """Set the reverb send amount (0–100)."""
        await self.command(serial, GoXLRCommand.set_reverb_amount(amount))

    async def set_reverb_decay(self, serial: str, ms: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_decay(ms))

    async def set_reverb_early_level(self, serial: str, level: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_early_level(level))

    async def set_reverb_tail_level(self, serial: str, level: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_tail_level(level))

    async def set_reverb_pre_delay(self, serial: str, ms: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_pre_delay(ms))

    async def set_reverb_low_colour(self, serial: str, colour: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_low_colour(colour))

    async def set_reverb_high_colour(self, serial: str, colour: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_high_colour(colour))

    async def set_reverb_high_factor(self, serial: str, factor: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_high_factor(factor))

    async def set_reverb_diffuse(self, serial: str, diffuse: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_diffuse(diffuse))

    async def set_reverb_mod_speed(self, serial: str, speed: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_mod_speed(speed))

    async def set_reverb_mod_depth(self, serial: str, depth: int) -> None:
        await self.command(serial, GoXLRCommand.set_reverb_mod_depth(depth))

    async def set_echo_style(self, serial: str, style: EchoStyle) -> None:
        """Set the echo effect style."""
        await self.command(serial, GoXLRCommand.set_echo_style(style))

    async def set_echo_amount(self, serial: str, amount: int) -> None:
        """Set the echo send amount (0–100)."""
        await self.command(serial, GoXLRCommand.set_echo_amount(amount))

    async def set_echo_feedback(self, serial: str, feedback: int) -> None:
        await self.command(serial, GoXLRCommand.set_echo_feedback(feedback))

    async def set_echo_tempo(self, serial: str, bpm: int) -> None:
        await self.command(serial, GoXLRCommand.set_echo_tempo(bpm))

    async def set_echo_delay_left(self, serial: str, ms: int) -> None:
        await self.command(serial, GoXLRCommand.set_echo_delay_left(ms))

    async def set_echo_delay_right(self, serial: str, ms: int) -> None:
        await self.command(serial, GoXLRCommand.set_echo_delay_right(ms))

    async def set_echo_feedback_left(self, serial: str, feedback: int) -> None:
        await self.command(serial, GoXLRCommand.set_echo_feedback_left(feedback))

    async def set_echo_feedback_right(self, serial: str, feedback: int) -> None:
        await self.command(serial, GoXLRCommand.set_echo_feedback_right(feedback))

    async def set_echo_xfb_l_to_r(self, serial: str, feedback: int) -> None:
        await self.command(serial, GoXLRCommand.set_echo_xfb_l_to_r(feedback))

    async def set_echo_xfb_r_to_l(self, serial: str, feedback: int) -> None:
        await self.command(serial, GoXLRCommand.set_echo_xfb_r_to_l(feedback))

    async def set_pitch_style(self, serial: str, style: PitchStyle) -> None:
        """Set the pitch shift style."""
        await self.command(serial, GoXLRCommand.set_pitch_style(style))

    async def set_pitch_amount(self, serial: str, amount: int) -> None:
        """Set the pitch shift amount (-24–24 semitones)."""
        await self.command(serial, GoXLRCommand.set_pitch_amount(amount))

    async def set_pitch_character(self, serial: str, character: int) -> None:
        """Set pitch character (0–100)."""
        await self.command(serial, GoXLRCommand.set_pitch_character(character))

    async def set_gender_style(self, serial: str, style: GenderStyle) -> None:
        """Set the gender shift style."""
        await self.command(serial, GoXLRCommand.set_gender_style(style))

    async def set_gender_amount(self, serial: str, amount: int) -> None:
        """Set the gender shift amount (-12–12)."""
        await self.command(serial, GoXLRCommand.set_gender_amount(amount))

    # ------------------------------------------------------------------
    # Mic settings
    # ------------------------------------------------------------------

    async def set_microphone_type(self, serial: str, mic_type: MicrophoneType) -> None:
        """Set the microphone type (Dynamic / Condenser / Jack)."""
        await self.command(serial, GoXLRCommand.set_microphone_type(mic_type))

    async def set_gate_threshold(self, serial: str, threshold: int) -> None:
        """Set the noise gate threshold (-59–0 dB)."""
        await self.command(serial, GoXLRCommand.set_gate_threshold(threshold))

    async def set_gate_active(self, serial: str, active: bool) -> None:
        """Enable or disable the noise gate."""
        await self.command(serial, GoXLRCommand.set_gate_active(active))

    async def set_gate_attenuation(self, serial: str, attenuation: int) -> None:
        await self.command(serial, GoXLRCommand.set_gate_attenuation(attenuation))

    async def set_gate_attack(self, serial: str, attack: GateTimes) -> None:
        await self.command(serial, GoXLRCommand.set_gate_attack(attack))

    async def set_gate_release(self, serial: str, release: GateTimes) -> None:
        await self.command(serial, GoXLRCommand.set_gate_release(release))

    async def set_microphone_gain(self, serial: str, mic_type: MicrophoneType, gain: int) -> None:
        """Set the microphone gain (0–72 dB)."""
        await self.command(serial, GoXLRCommand.set_microphone_gain(mic_type, gain))

    # ------------------------------------------------------------------
    # EQ
    # ------------------------------------------------------------------

    async def set_eq_gain(self, serial: str, freq: EqFrequencies, gain: int) -> None:
        await self.command(serial, GoXLRCommand.set_eq_gain(freq, gain))

    async def set_eq_freq(self, serial: str, freq: EqFrequencies, value: float) -> None:
        await self.command(serial, GoXLRCommand.set_eq_freq(freq, value))

    async def set_eq_mini_gain(self, serial: str, freq: MiniEqFrequencies, gain: int) -> None:
        await self.command(serial, GoXLRCommand.set_eq_mini_gain(freq, gain))

    async def set_eq_mini_freq(self, serial: str, freq: MiniEqFrequencies, value: float) -> None:
        await self.command(serial, GoXLRCommand.set_eq_mini_freq(freq, value))

    # ------------------------------------------------------------------
    # Compressor
    # ------------------------------------------------------------------

    async def set_compressor_threshold(self, serial: str, threshold: int) -> None:
        await self.command(serial, GoXLRCommand.set_compressor_threshold(threshold))

    async def set_compressor_ratio(self, serial: str, ratio: CompressorRatio) -> None:
        await self.command(serial, GoXLRCommand.set_compressor_ratio(ratio))

    async def set_compressor_attack(self, serial: str, attack: CompressorAttackTime) -> None:
        await self.command(serial, GoXLRCommand.set_compressor_attack(attack))

    async def set_compressor_release(self, serial: str, release: CompressorReleaseTime) -> None:
        await self.command(serial, GoXLRCommand.set_compressor_release(release))

    async def set_compressor_makeup_gain(self, serial: str, gain: int) -> None:
        await self.command(serial, GoXLRCommand.set_compressor_makeup_gain(gain))

    async def set_deeser(self, serial: str, amount: int) -> None:
        """Set the de-esser amount (0–100)."""
        await self.command(serial, GoXLRCommand.set_deeser(amount))

    # ------------------------------------------------------------------
    # Scribble strips
    # ------------------------------------------------------------------

    async def set_scribble_text(self, serial: str, fader: FaderName, text: str) -> None:
        await self.command(serial, GoXLRCommand.set_scribble_text(fader, text))

    async def set_scribble_icon(self, serial: str, fader: FaderName, icon: str | None) -> None:
        await self.command(serial, GoXLRCommand.set_scribble_icon(fader, icon))

    async def set_scribble_number(self, serial: str, fader: FaderName, number: str) -> None:
        await self.command(serial, GoXLRCommand.set_scribble_number(fader, number))

    async def set_scribble_invert(self, serial: str, fader: FaderName, invert: bool) -> None:
        await self.command(serial, GoXLRCommand.set_scribble_invert(fader, invert))

    # ------------------------------------------------------------------
    # Mix & monitor
    # ------------------------------------------------------------------

    async def set_swear_button_volume(self, serial: str, volume: float) -> None:
        """Set the duck volume used by the bleep/swear button (-34–0 dB).

        Values are rounded to the nearest integer and clamped silently.
        """
        clamped = max(-34, min(0, round(volume)))
        await self.command(serial, GoXLRCommand.set_swear_button_volume(clamped))

    async def set_swear_button_volume_pct(self, serial: str, percent: float) -> None:
        """Set the duck volume used by the bleep/swear button as a percentage (0–100).

        0 % maps to -34 dB (minimum), 100 % maps to 0 dB (no ducking).
        Values outside 0–100 are clamped silently.
        """
        pct = max(0.0, min(100.0, percent))
        volume = round(-34 + pct / 100 * 34)
        await self.command(serial, GoXLRCommand.set_swear_button_volume(volume))

    async def set_monitor_with_fx(self, serial: str, enabled: bool) -> None:
        """Route monitor mix through effects (True) or bypass effects (False)."""
        await self.command(serial, GoXLRCommand.set_monitor_with_fx(enabled))

    async def set_vod_mode(self, serial: str, mode: VodMode) -> None:
        """Set the VOD (stream-safe music) mode."""
        await self.command(serial, GoXLRCommand.set_vod_mode(mode))

    # ------------------------------------------------------------------
    # Submix
    # ------------------------------------------------------------------

    async def set_submix_enabled(self, serial: str, enabled: bool) -> None:
        """Enable or disable the submix system."""
        await self.command(serial, GoXLRCommand.set_submix_enabled(enabled))

    async def set_submix_volume(
        self, serial: str, channel: ChannelName, volume: int
    ) -> None:
        """Set the submix B volume for a channel (0–255)."""
        await self.command(serial, GoXLRCommand.set_submix_volume(channel, volume))

    async def set_monitor_mix(self, serial: str, output: OutputDevice) -> None:
        """Set which output is used as the headphone monitor mix source."""
        await self.command(serial, GoXLRCommand.set_monitor_mix(output))

    async def set_submix_linked(self, serial: str, channel: ChannelName, linked: bool) -> None:
        """Link a channel's submix B volume to its main volume."""
        await self.command(serial, GoXLRCommand.set_submix_linked(channel, linked))

    async def set_submix_output_mix(self, serial: str, output: OutputDevice, mix: Mix) -> None:
        """Set which mix (A or B) is sent to an output device."""
        await self.command(serial, GoXLRCommand.set_submix_output_mix(output, mix))

    async def set_button_colour(
        self,
        serial: str,
        button: Button,
        colour_on: ColourLike,
        colour_off: ColourLike | None = None,
    ) -> None:
        """Set the active (and optionally inactive) LED colour for a button.

        ``colour_off`` defaults to a dimmed version of ``colour_on`` when
        omitted.
        """
        on_hex = as_hex(colour_on)
        off_hex = (
            as_hex(colour_off) if colour_off is not None
            else str(Colour.from_hex(on_hex).dimmed())
        )
        await self.command(serial, GoXLRCommand.set_button_colours(button, on_hex, off_hex))

    async def set_button_off_style(
        self,
        serial: str,
        button: Button,
        off_style: ButtonColourOffStyle,
        colour_two: ColourLike = Colour.BLACK,
    ) -> None:
        """Set how a button appears when it is in the 'off' state."""
        await self.command(
            serial,
            GoXLRCommand.set_button_off_style(button, off_style, as_hex(colour_two)),
        )

    async def set_button_group_colour(
        self,
        serial: str,
        group: ButtonColourGroups,
        colour_one: ColourLike,
        colour_two: ColourLike,
    ) -> None:
        """Set LED colours for all buttons in a named group simultaneously."""
        await self.command(
            serial,
            GoXLRCommand.set_button_group_colours(group, as_hex(colour_one), as_hex(colour_two)),
        )

    async def set_fader_colour(
        self,
        serial: str,
        fader: FaderName,
        colour_top: ColourLike,
        colour_bottom: ColourLike,
    ) -> None:
        """Set the two LED colours for a fader channel strip."""
        await self.command(
            serial,
            GoXLRCommand.set_fader_colours(fader, as_hex(colour_top), as_hex(colour_bottom)),
        )

    async def set_fader_display_style(
        self,
        serial: str,
        fader: FaderName,
        style: FaderDisplayStyle,
    ) -> None:
        """Set the display style (gradient, meter, etc.) for a fader."""
        await self.command(serial, GoXLRCommand.set_fader_display_style(fader, style))

    async def set_all_fader_display_style(
        self, serial: str, style: FaderDisplayStyle
    ) -> None:
        """Apply the same display style to all four faders."""
        await self.command(serial, GoXLRCommand.set_all_fader_display_style(style))

    async def set_global_colour(self, serial: str, colour: ColourLike) -> None:
        """Set the global accent colour used by animations and unassigned LEDs."""
        await self.command(serial, GoXLRCommand.set_global_colour(as_hex(colour)))

    async def set_simple_colour(
        self, serial: str, target: SimpleColourTargets, colour: ColourLike
    ) -> None:
        """Set the colour for a simple single-colour target (Global, Accent, ScribbleBack)."""
        await self.command(serial, GoXLRCommand.set_simple_colour(target, as_hex(colour)))

    async def set_encoder_colour(
        self,
        serial: str,
        target: EncoderColourTargets,
        colour_left: ColourLike,
        colour_right: ColourLike,
        colour_knob: ColourLike,
    ) -> None:
        """Set the three LED zones of an encoder (left arc, right arc, knob)."""
        await self.command(
            serial,
            GoXLRCommand.set_encoder_colour(
                target, as_hex(colour_left), as_hex(colour_right), as_hex(colour_knob)
            ),
        )

    async def set_sampler_colour(
        self,
        serial: str,
        target: SamplerColourTargets,
        colour_one: ColourLike,
        colour_two: ColourLike,
        colour_three: ColourLike,
    ) -> None:
        """Set the three LED states for a sampler bank selector button."""
        await self.command(
            serial,
            GoXLRCommand.set_sampler_colour(
                target,
                as_hex(colour_one),
                as_hex(colour_two),
                as_hex(colour_three),
            ),
        )

    async def set_animation_mode(
        self,
        serial: str,
        mode: AnimationMode,
        colour_one: ColourLike = Colour.BLACK,
        colour_two: ColourLike = Colour.BLACK,
        waterfall: WaterfallDirection = WaterfallDirection.Down,
    ) -> None:
        """Set the global LED animation mode and parameters."""
        await self.command(
            serial,
            GoXLRCommand.set_animation_mode(
                mode, as_hex(colour_one), as_hex(colour_two), waterfall
            ),
        )

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    async def set_lock_faders(self, serial: str, locked: bool) -> None:
        """Lock or unlock all faders."""
        await self.command(serial, GoXLRCommand.set_lock_faders(locked))

    async def set_vc_mute_also_mute_cm(self, serial: str, enabled: bool) -> None:
        """When enabled, muting VC also mutes the CM channel."""
        await self.command(serial, GoXLRCommand.set_vc_mute_also_mute_cm(enabled))

    async def set_mute_hold_duration(self, serial: str, ms: int) -> None:
        """Set the mute hold duration (ms)."""
        await self.command(serial, GoXLRCommand.set_mute_hold_duration(ms))

    async def set_element_display_mode(
        self, serial: str, component: DisplayModeComponents, mode: DisplayMode
    ) -> None:
        """Set the display mode for a UI component."""
        await self.command(serial, GoXLRCommand.set_element_display_mode(component, mode))

    async def set_all_fader_colours(
        self, serial: str, colour_one: ColourLike, colour_two: ColourLike
    ) -> None:
        """Set the two LED colours for all four fader strips simultaneously."""
        await self.command(
            serial,
            GoXLRCommand.set_all_fader_colours(as_hex(colour_one), as_hex(colour_two)),
        )

    # ------------------------------------------------------------------
    # State access
    # ------------------------------------------------------------------

    @property
    def state(self) -> DaemonState:
        """Access the cached daemon state directly."""
        return self._state

    # ------------------------------------------------------------------
    # Internal: patch handling
    # ------------------------------------------------------------------

    async def _send_checked(self, request: DaemonRequest) -> DaemonResponse:
        resp = await self._transport.send(request)
        if resp.error is not None:
            raise CommandError(resp.error)
        return resp

    async def _on_reconnected(self) -> None:
        """Called by the transport after a successful reconnect.

        Re-fetches the full daemon status so the state cache is immediately
        up to date, then fires the user-supplied on_connect callback.
        """
        try:
            await self.get_status()
        except Exception as exc:
            _log.warning("Failed to refresh status after reconnect: %s", exc)

        if self._on_connect_cb is not None:
            try:
                await self._on_connect_cb()
            except Exception as exc:
                _log.warning("on_connect callback raised: %s", exc)

    async def _on_disconnected(self) -> None:
        """Called by the transport when the connection is lost."""
        if self._on_disconnect_cb is not None:
            try:
                await self._on_disconnect_cb()
            except Exception as exc:
                _log.warning("on_disconnect callback raised: %s", exc)

    async def _on_patch(self, ops: list[Any]) -> None:
        """Called by the transport when a live Patch event arrives."""
        # Snapshot button states before applying patch so we can diff them.
        old_button_down = {
            serial: dict(mixer.button_down)
            for serial, mixer in self._state.status.mixers.items()
        }

        self._state.apply_patch(ops)

        if self._on_state_update is not None:
            try:
                await self._on_state_update(self._state.status)
            except Exception as exc:
                _log.warning("on_state_update callback raised: %s", exc)

        if self._on_button_event_cb is not None:
            await self._handle_button_changes(old_button_down)

    # ------------------------------------------------------------------
    # Internal: button event detection
    # ------------------------------------------------------------------

    async def _handle_button_changes(
        self, old_bd: dict[str, dict[str, bool]]
    ) -> None:
        now = asyncio.get_running_loop().time()
        for serial, mixer in self._state.status.mixers.items():
            serial_times = self._button_press_times.setdefault(serial, {})
            serial_tasks = self._long_press_tasks.setdefault(serial, {})
            old = old_bd.get(serial, {})
            for btn_name, is_down in mixer.button_down.items():
                was_down = old.get(btn_name, False)
                if is_down and not was_down:
                    serial_times[btn_name] = now
                    serial_tasks[btn_name] = asyncio.create_task(
                        self._long_press_timer(serial, btn_name, now),
                        name=f"goxlr-longpress-{serial}-{btn_name}",
                    )
                    await self._fire_button_event(
                        serial, btn_name, ButtonEventType.pressed, 0.0
                    )
                elif not is_down and was_down:
                    if task := serial_tasks.pop(btn_name, None):
                        task.cancel()
                    held = now - serial_times.pop(btn_name, now)
                    await self._fire_button_event(
                        serial, btn_name, ButtonEventType.released, held
                    )

    async def _long_press_timer(
        self, serial: str, btn_name: str, press_time: float
    ) -> None:
        """Wait for long_press_threshold, then fire a long_pressed event if still held."""
        try:
            await asyncio.sleep(self._long_press_threshold)
        except asyncio.CancelledError:
            return
        mixer = self._state.status.mixers.get(serial)
        if mixer and mixer.button_down.get(btn_name, False):
            held = asyncio.get_running_loop().time() - press_time
            await self._fire_button_event(serial, btn_name, ButtonEventType.long_pressed, held)

    async def _fire_button_event(
        self,
        serial: str,
        btn_name: str,
        event_type: ButtonEventType,
        held_seconds: float,
    ) -> None:
        if self._on_button_event_cb is None:
            return
        event = ButtonEvent.from_raw(serial, btn_name, event_type, held_seconds)
        try:
            await self._on_button_event_cb(event)
        except Exception as exc:
            _log.warning("on_button_event callback raised: %s", exc)

    def _cancel_all_long_press_tasks(self) -> None:
        for serial_tasks in self._long_press_tasks.values():
            for task in serial_tasks.values():
                task.cancel()
        self._long_press_tasks.clear()
        self._button_press_times.clear()

