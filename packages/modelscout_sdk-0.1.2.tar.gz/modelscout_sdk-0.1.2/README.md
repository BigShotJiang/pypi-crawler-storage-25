# ModelScout Python SDK

**Find the best LLM for your product.** Run benchmarks across multiple models on your own data to see which performs best for quality, cost, and latency.

## Installation

```bash
pip install modelscout-sdk
```

## Quick Start

```python
from modelscout import Benchmark

# Set MODELSCOUT_API_KEY in your environment, or pass api_key="ms_..."
# Models are selected at checkout and locked to your purchase
results = Benchmark().run(
    purchased_benchmark_id="trial",  # free trial, or "pb_..." from dashboard
    prompts=["Write a SQL query to find active users", "Explain quantum computing"],
)

print(results.best_model_for("quality"))  # Best quality model
print(results.best_model_for("cost"))     # Cheapest model
```

## Features

### Benchmarking
Compare LLMs side-by-side on your evaluation data. Get quality scores, cost analysis, latency metrics, and statistical significance.

### Data Generation

Need synthetic test data? Generate evaluation datasets from the [dashboard](https://modelscout.co/dashboard/datasets) — describe your use case and get representative prompts in minutes.

### Dataset Upload
Upload your own evaluation data:

```python
dataset_id = benchmark.upload_dataset(
    name="My Test Data",
    samples=[
        {"input": "What is machine learning?"},
        {"input": "Explain neural networks"},
    ],
)
```

### Agentic Evaluation
Test tool-calling capabilities with multi-turn evaluation (SDK-only):

```python
from modelscout import Benchmark, AgenticConfig, ToolDefinition

def my_search_function(query: str) -> str:
    return f"Results for: {query}"

config = AgenticConfig(tools=[
    ToolDefinition(
        name="search",
        description="Search the web",
        parameters={"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
        implementation=my_search_function,
    )
])

# Models are locked to your purchase — selected at checkout
results = Benchmark().run(
    name="Agent Eval",
    purchased_benchmark_id="pb_...",
    prompts=["Find information about quantum computing"],
    agentic_config=config,
)
```

## Supported Models

23 models across 8 providers:

| Provider | Models |
|----------|--------|
| OpenAI | gpt-5.4, gpt-5.4-mini, gpt-5.4-nano, gpt-5-mini, gpt-5-nano |
| Anthropic | claude-opus-4-6, claude-sonnet-4-6, claude-haiku-4-5-20251001 |
| Google | gemini-3.1-pro, gemini-3-flash, gemini-3.1-flash-lite, gemini-2.5-flash-lite |
| DeepSeek | deepseek-v3.2, deepseek-v3.2-speciale, deepseek-r1 |
| Qwen | qwen3.5-397b-a17b, qwen3.5-flash-02-23, qwen3-235b-a22b |
| Meta | llama-4-maverick, llama-4-scout |
| Mistral | mistral-large-2512, mistral-small-2603 |
| xAI | grok-4, grok-4.1-fast |

## Pricing

**Free trial:** Every new organization gets one free benchmark (10 samples, 2 standard models).

**Pay-as-you-go:** Purchase benchmarks from the [dashboard](https://modelscout.co/dashboard). Price depends on selected models, sample count, and judge tier. Starting from $4.99.

## Documentation

Full documentation: [modelscout.co/docs/sdk](https://modelscout.co/docs/sdk)

---

## License

Proprietary. See [LICENSE](LICENSE) for details.
