"""SDK Benchmark class for personalized LLM evaluation.

Runs benchmarks locally using a provisioned OpenRouter API key. User data
(prompts and responses) never touches ModelScout servers. Only aggregated
scores are submitted to the backend for analysis and dashboard display.

Privacy guarantees:
- Prompts go directly from user machine -> OpenRouter -> LLM provider
- LLM calls go directly from user machine -> OpenRouter -> LLM provider
- Per-sample data (truncated to 2000 chars) is sent to backend for
  aggregation and dashboard display

Quick Start:
    >>> from modelscout import Benchmark, ModelConfig
    >>>
    >>> results = Benchmark(api_key="ms_...").run(
    ...     name="My Benchmark",
    ...     models=[
    ...         ModelConfig(provider="openai", model="gpt-4o"),
    ...         ModelConfig(provider="anthropic", model="claude-sonnet-4-5-20250929"),
    ...     ],
    ...     samples=Benchmark.load_dataset("my_data.jsonl"),
    ... )
    >>> print(results.best_model_for("quality"))
    >>> print(results.summary())

"""

import base64
import concurrent.futures
import csv
import hashlib
import io
import json
import logging
import os
import re
import threading
import time
import urllib.request
import urllib.error
import warnings
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Union

logger = logging.getLogger(__name__)

DEFAULT_API_URL = "https://api.modelscout.co"

# OpenRouter base URL for LLM calls
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

# Max dataset file size in bytes (100 MB)
MAX_DATASET_FILE_SIZE = 100 * 1024 * 1024

# ---------------------------------------------------------------------------
# Benchmark limits — validated client-side for fast feedback, server is
# the authoritative source of truth.
# ---------------------------------------------------------------------------
MIN_MODELS = 2
MAX_MODELS = 10
MIN_SAMPLES = 5
MAX_SAMPLES = 500
PACK_LIMITS: dict = {}  # Empty — no longer used for client-side validation

LEGACY_PACK_IDS = {"advanced", "trial", "starter", "basic", "standard", "agentic"}

# Reasoning models that need reasoning_effort="low" to prevent
# token budget exhaustion. Without it, these models consume all
# max_tokens on internal chain-of-thought, leaving nothing for content.
REASONING_MODELS = {
    "openai/gpt-5.4",
    "openai/gpt-5.4-mini",
    "openai/gpt-5.4-nano",
    "openai/gpt-5-mini",
    "openai/gpt-5-nano",
    "openai/o3",
    "openai/o3-mini",
    "openai/o4-mini",
    "deepseek/deepseek-r1",
}

PREMIUM_MODELS = {
    "anthropic/claude-opus-4-6",
    "anthropic/claude-sonnet-4-6",
    "openai/gpt-5.4",
    "openai/gpt-5.4-mini",
    "google/gemini-3.1-pro",
    "x-ai/grok-4",
}

# Aliases for premium detection (subset of backend MODEL_ALIASES)
_MODEL_ALIASES = {
    "openai": {"gpt-5": "gpt-5.4", "gpt-5.2": "gpt-5.4", "gpt-5.1": "gpt-5.4"},
    "anthropic": {
        "claude-opus": "claude-opus-4-6", "claude-opus-4": "claude-opus-4-6",
        "claude-sonnet": "claude-sonnet-4-6", "claude-sonnet-4": "claude-sonnet-4-6",
    },
    "deepseek": {
        "deepseek-chat": "deepseek-v3.2", "deepseek-v3": "deepseek-v3.2",
        "deepseek-reasoner": "deepseek-r1",
    },
}


def _sanitize_error_msg(msg: str) -> str:
    """Redact potential API keys and secrets from error messages."""
    msg = re.sub(r'(ms_[a-zA-Z0-9]{3})[a-zA-Z0-9_-]+', r'\1...', msg)
    msg = re.sub(r'(sk-[a-zA-Z0-9]{3})[a-zA-Z0-9_-]+', r'\1...', msg)
    msg = re.sub(r'(sk-ant-[a-zA-Z0-9]{3})[a-zA-Z0-9_-]+', r'\1...', msg)
    msg = re.sub(r'(Bearer\s+)[^\s"\']+', r'\1[REDACTED]', msg)
    msg = re.sub(
        r'(Authorization["\']?\s*:\s*["\']?)[^\s"\']+',
        r'\1[REDACTED]', msg, flags=re.IGNORECASE,
    )
    msg = re.sub(r'(?<![a-zA-Z0-9])[a-zA-Z0-9]{40,}(?![a-zA-Z0-9])', '[REDACTED]', msg)
    return msg[:500]


# JSON Schema type mapping for lightweight validation
_JSON_SCHEMA_TYPES = {
    "string": str,
    "number": (int, float),
    "integer": int,
    "boolean": bool,
    "array": list,
    "object": dict,
}


def _validate_tool_arguments(
    arguments: Dict[str, Any],
    schema: Dict[str, Any],
) -> Optional[str]:
    """Validate LLM-generated tool arguments against a JSON Schema.

    Lightweight validation covering the most common JSON Schema fields
    (type, required, properties) without pulling in the ``jsonschema``
    dependency. Returns ``None`` if valid, or an error string.
    """
    if not isinstance(arguments, dict):
        return f"Expected object, got {type(arguments).__name__}"

    schema_type = schema.get("type")
    if schema_type and schema_type != "object":
        return f"Expected schema type 'object', got '{schema_type}'"

    # Check required fields
    required = schema.get("required", [])
    for field in required:
        if field not in arguments:
            return f"Missing required argument: '{field}'"

    # Check property types
    properties = schema.get("properties", {})
    for key, value in arguments.items():
        if key not in properties:
            # Extra arguments from the LLM — allow if additionalProperties
            # is not explicitly False
            if schema.get("additionalProperties") is False:
                return f"Unexpected argument: '{key}'"
            continue

        prop_schema = properties[key]
        expected_type_name = prop_schema.get("type")
        if not expected_type_name:
            continue

        expected_types = _JSON_SCHEMA_TYPES.get(expected_type_name)
        if expected_types and value is not None and not isinstance(value, expected_types):
            return (
                f"Argument '{key}' expected type '{expected_type_name}', "
                f"got '{type(value).__name__}'"
            )

        # Validate enum constraints
        enum_values = prop_schema.get("enum")
        if enum_values is not None and value not in enum_values:
            return (
                f"Argument '{key}' must be one of {enum_values}, "
                f"got {value!r}"
            )

    return None


# =============================================================================
# Agentic evaluation data classes
# =============================================================================

@dataclass
class ToolDefinition:
    """A tool the LLM can call during agentic evaluation.

    Users provide tool definitions (OpenAI function calling format) and
    Python callable implementations. The SDK sends tool schemas to the LLM,
    then executes the callable locally when the LLM requests a tool call.

    Example:
        >>> tool = ToolDefinition(
        ...     name="search_db",
        ...     description="Search the database for records",
        ...     parameters={
        ...         "type": "object",
        ...         "properties": {"query": {"type": "string"}},
        ...         "required": ["query"],
        ...     },
        ...     implementation=my_search_function,
        ... )
    """
    name: str
    description: str
    parameters: Dict[str, Any]       # JSON Schema (OpenAI function calling format)
    implementation: Callable[..., Any]  # User's Python callable

    def to_openai_schema(self) -> Dict[str, Any]:
        """Convert to OpenAI function calling format for the API request."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


@dataclass
class ToolCallRecord:
    """Record of a single tool invocation during an agentic turn."""
    tool_name: str
    arguments: Dict[str, Any]
    result: Optional[str] = None
    error: Optional[str] = None
    duration_ms: float = 0.0
    turn: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "arguments": self.arguments,
            "result": self.result,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "turn": self.turn,
        }


@dataclass
class AgentTurn:
    """One LLM interaction turn in the agentic loop."""
    turn_number: int
    response_text: Optional[str] = None
    tool_calls: List[ToolCallRecord] = field(default_factory=list)
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    is_final: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "turn_number": self.turn_number,
            "response_text": self.response_text,
            "tool_calls": [tc.to_dict() for tc in self.tool_calls],
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cost_usd": self.cost_usd,
            "latency_ms": self.latency_ms,
            "is_final": self.is_final,
        }


@dataclass
class AgentTrace:
    """Complete trace for one sample's agentic evaluation."""
    turns: List[AgentTurn] = field(default_factory=list)
    final_output: Optional[str] = None
    total_turns: int = 0
    total_tool_calls: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cost_usd: float = 0.0
    total_latency_ms: float = 0.0
    termination_reason: str = "final_answer"  # final_answer | max_turns | timeout | error | spending_limit

    def to_dict(self) -> Dict[str, Any]:
        return {
            "turns": [t.to_dict() for t in self.turns],
            "final_output": self.final_output,
            "total_turns": self.total_turns,
            "total_tool_calls": self.total_tool_calls,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_cost_usd": self.total_cost_usd,
            "total_latency_ms": self.total_latency_ms,
            "termination_reason": self.termination_reason,
        }


@dataclass
class AgenticConfig:
    """Configuration for the agentic evaluation loop.

    When provided to ``Benchmark.run()``, this triggers agentic evaluation
    (multi-turn tool-use loop). At least one tool must be supplied.

    Evaluation limits (set internally, not user-configurable):
        - Conversation turns: 3
        - Output tokens per turn: 1,024
        - Max 10 tool definitions, max 5,000 chars total
        - Total tool result budget: 10,000 chars per sample (across all calls)
        - Max 5 tool calls per turn
        - Per-sample timeout: 120 seconds
        - Per-tool timeout: 30 seconds

    Args:
        tools: Tool definitions the LLM can call. At least one required, max 10.
        stop_on_tool_error: If True, terminate the loop on tool error.
    """
    tools: List[ToolDefinition] = field(default_factory=list)
    stop_on_tool_error: bool = False

    # Internal limits — NOT user-configurable.
    # These control cost and are baked into our pricing model.
    _MAX_TURNS: int = field(default=3, init=False, repr=False)
    _MAX_TOKENS_PER_TURN: int = field(default=1024, init=False, repr=False)
    _TIMEOUT_SECONDS: float = field(default=120.0, init=False, repr=False)
    _TOOL_TIMEOUT_SECONDS: float = field(default=30.0, init=False, repr=False)

    # Enforced limits
    MAX_TOOLS = 10
    MAX_TOOL_DEFINITIONS_CHARS = 5_000
    TOOL_RESULT_BUDGET_CHARS = 10_000  # total across all calls per sample

    def validate(self) -> None:
        """Validate agentic config limits. Raises ValueError on violation."""
        if not self.tools:
            raise ValueError("AgenticConfig requires at least one tool definition.")
        if len(self.tools) > self.MAX_TOOLS:
            raise ValueError(
                f"Too many tools: {len(self.tools)} (max {self.MAX_TOOLS}). "
                f"Reduce the number of tool definitions."
            )
        import json
        total_chars = 0
        for tool in self.tools:
            tool_dict = {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters,
            }
            total_chars += len(json.dumps(tool_dict))
        if total_chars > self.MAX_TOOL_DEFINITIONS_CHARS:
            raise ValueError(
                f"Tool definitions too large: {total_chars:,} characters "
                f"(max {self.MAX_TOOL_DEFINITIONS_CHARS:,}). "
                f"Reduce tool descriptions or parameter schemas."
            )

    def __post_init__(self) -> None:
        if not self.tools:
            raise ValueError("AgenticConfig requires at least one tool in 'tools'")


# =============================================================================
# Result data classes
# =============================================================================

@dataclass
class ModelRecommendation:
    """A model recommendation for a specific criterion."""
    provider: str
    model: str
    model_id: str
    score: float  # The metric value (quality, cost, latency)

    def __str__(self) -> str:
        return self.model_id


class BenchmarkError(Exception):
    """Error during benchmark execution."""

    def __init__(self, message: str, code: str = "", status_code: int = 0):
        self.code = code
        self.status_code = status_code
        super().__init__(message)


@dataclass
class ExtraMetricStat:
    """Aggregated statistics for an extra metric (e.g., BLEU, toxicity)."""
    name: str
    display_name: str
    unit: str
    group_id: Optional[str] = None
    mean: float = 0.0
    median: float = 0.0
    std: float = 0.0
    min: float = 0.0
    max: float = 0.0

    def __str__(self) -> str:
        if self.unit in ("percentage", "%"):
            return f"{self.display_name}: {self.mean * 100:.1f}%"
        return f"{self.display_name}: {self.mean:.4f} ({self.unit})"

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a dict for JSON upload/save."""
        return {
            "name": self.name,
            "display_name": self.display_name,
            "unit": self.unit,
            "group_id": self.group_id,
            "mean": self.mean,
            "median": self.median,
            "std": self.std,
            "min": self.min,
            "max": self.max,
        }


@dataclass
class BenchmarkProgress:
    """Progress update during benchmark execution.

    Passed to the ``on_progress`` callback of :meth:`Benchmark.run`.
    May be called from multiple threads during the ``evaluating`` phase.
    """
    phase: str  # "evaluating", "judging", "aggregating", "uploading"
    completed: int
    total: int
    current_model: Optional[str] = None


@dataclass
class ModelResult:
    """Aggregate metrics for a single model."""
    provider: str
    model: str
    model_id: str
    avg_quality_score: Optional[float] = None
    avg_latency_ms: float = 0.0
    avg_cost_usd: float = 0.0
    total_cost_usd: float = 0.0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    samples_evaluated: int = 0
    samples_failed: int = 0
    extra_metrics: List["ExtraMetricStat"] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "provider": self.provider,
            "model": self.model,
            "model_id": self.model_id,
            "avg_quality_score": self.avg_quality_score,
            "avg_latency_ms": self.avg_latency_ms,
            "avg_cost_usd": self.avg_cost_usd,
            "total_cost_usd": self.total_cost_usd,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "samples_evaluated": self.samples_evaluated,
            "samples_failed": self.samples_failed,
        }
        if self.extra_metrics:
            result["extra_metrics"] = [em.to_dict() for em in self.extra_metrics]
        return result


@dataclass
class SampleModelResponse:
    """A single model's response to a single sample."""
    response_text: Optional[str]
    latency_ms: float
    cost_usd: float
    input_tokens: int
    output_tokens: int
    quality_score: Optional[int]  # 1-5 from judge
    judge_reasoning: Optional[str]
    error: Optional[str]
    agent_trace: Optional[AgentTrace] = None  # Present for agentic benchmarks
    answer_relevancy: Optional[int] = None  # 1-5 sub-score
    coherence: Optional[int] = None  # 1-5 sub-score
    hallucination: Optional[int] = None  # 1-5 sub-score (1=best, 5=worst)


@dataclass
class SampleResult:
    """Results for a single sample across all models."""
    sample_index: int
    input_text: str
    expected_output: Optional[str]
    model_responses: Dict[str, Optional[SampleModelResponse]]  # model_id -> response


@dataclass
class BenchmarkResult:
    """Result of a benchmark run."""
    benchmark_id: str
    name: str
    status: str
    created_at: str

    # Per-model aggregates
    models: List[ModelResult]

    # Recommendations
    best_quality: Optional[ModelRecommendation]
    best_value: Optional[ModelRecommendation]
    best_speed: Optional[ModelRecommendation]

    # Per-sample data (kept locally, never auto-uploaded)
    per_sample: List[SampleResult]

    # Embeddings (for training, kept locally)
    embeddings: Optional[List[List[float]]] = None

    # Upload state
    uploaded: bool = False
    backend_benchmark_id: Optional[str] = None

    # Warnings surfaced during the run
    warnings: List[str] = field(default_factory=list)

    # Raw quality scores for training
    _quality_scores: Dict[str, List[float]] = field(default_factory=dict, repr=False)
    _costs: Dict[str, List[float]] = field(default_factory=dict, repr=False)
    _latencies: Dict[str, List[float]] = field(default_factory=dict, repr=False)

    @property
    def recommendation(self) -> str:
        """Get a one-line recommendation for the best overall model."""
        if not self.models:
            return "No results available."

        scored = [r for r in self.models if r.avg_quality_score is not None]
        if scored:
            best = max(scored, key=lambda r: r.avg_quality_score)
            return (
                f"Use {best.model_id} for your use case "
                f"(quality: {best.avg_quality_score:.1f}/5, "
                f"cost: ${best.avg_cost_usd:.4f}/request, "
                f"latency: {best.avg_latency_ms:.0f}ms)"
            )

        cheapest = min(self.models, key=lambda r: r.avg_cost_usd)
        return (
            f"Use {cheapest.model_id} — cheapest option at "
            f"${cheapest.avg_cost_usd:.4f}/request"
        )

    def best_model_for(self, criterion: str) -> str:
        """Get the best model for a criterion ('quality', 'cost', 'value', 'speed').

        Args:
            criterion: One of 'quality', 'cost' (cheapest), 'value' (best quality/$),
                'speed' or 'latency' (fastest).

        Returns:
            Model ID string (e.g., "openai/gpt-4o").
        """
        if criterion == "quality" and self.best_quality:
            return self.best_quality.model_id
        elif criterion == "cost" and self.models:
            return min(self.models, key=lambda r: r.total_cost_usd).model_id
        elif criterion == "value" and self.best_value:
            return self.best_value.model_id
        elif criterion in ("speed", "latency") and self.best_speed:
            return self.best_speed.model_id
        raise ValueError(f"No recommendation for criterion: {criterion}")

    def best_model(self, metric: str = "quality") -> Optional[ModelResult]:
        """Get the best ModelResult for a given metric."""
        if not self.models:
            return None

        if metric == "quality":
            scored = [r for r in self.models if r.avg_quality_score is not None]
            return max(scored, key=lambda r: r.avg_quality_score) if scored else None
        elif metric == "cost":
            return min(self.models, key=lambda r: r.avg_cost_usd)
        elif metric == "latency":
            return min(self.models, key=lambda r: r.avg_latency_ms)
        return None

    def pareto_frontier(
        self, x: str = "cost", y: str = "quality",
    ) -> List[ModelResult]:
        """Get models on the Pareto frontier (optimal tradeoffs).

        A model is Pareto-optimal if no other model is strictly better on
        both axes.

        Args:
            x: Metric for x-axis ('cost' or 'latency'). Lower is better.
            y: Metric for y-axis ('quality', 'cost', or 'latency').
                Higher is better for 'quality'; lower for 'cost'/'latency'.

        Returns:
            List of Pareto-optimal ModelResult objects, sorted by x ascending.
        """
        axis_map = {
            "cost": ("avg_cost_usd", True),       # (attr, minimize)
            "latency": ("avg_latency_ms", True),
            "quality": ("avg_quality_score", False),
        }
        if x not in axis_map:
            raise ValueError(f"Unknown x axis: {x!r}. Choose from {list(axis_map)}")
        if y not in axis_map:
            raise ValueError(f"Unknown y axis: {y!r}. Choose from {list(axis_map)}")

        x_attr, x_minimize = axis_map[x]
        y_attr, y_minimize = axis_map[y]

        # Filter models with valid values for both axes
        candidates = [
            m for m in self.models
            if getattr(m, x_attr) is not None and getattr(m, y_attr) is not None
        ]
        if len(candidates) <= 1:
            return list(candidates)

        frontier = []
        for m in candidates:
            mx, my = getattr(m, x_attr), getattr(m, y_attr)
            dominated = False
            for other in candidates:
                if other is m:
                    continue
                ox, oy = getattr(other, x_attr), getattr(other, y_attr)

                # other must be at least as good on both axes
                x_ok = (ox <= mx) if x_minimize else (ox >= mx)
                y_ok = (oy <= my) if y_minimize else (oy >= my)
                # and strictly better on at least one
                x_strict = (ox < mx) if x_minimize else (ox > mx)
                y_strict = (oy < my) if y_minimize else (oy > my)

                if x_ok and y_ok and (x_strict or y_strict):
                    dominated = True
                    break
            if not dominated:
                frontier.append(m)

        frontier.sort(key=lambda m: getattr(m, x_attr))
        return frontier

    def summary(self) -> str:
        """Generate a rich text summary of the benchmark results."""
        if not self.models:
            return "No results available."

        lines = [
            f"Benchmark: {self.name}",
            f"Status: {self.status}",
            "",
            f"{'Model':<40} {'Quality':>8} {'Latency':>10} {'Cost':>10} {'Success':>9}",
            "-" * 81,
        ]
        for m in sorted(self.models, key=lambda x: x.avg_quality_score or 0, reverse=True):
            q = f"{m.avg_quality_score:.2f}" if m.avg_quality_score is not None else "N/A"
            total = m.samples_evaluated + m.samples_failed
            success = f"{m.samples_evaluated}/{total}" if total > 0 else "N/A"
            lines.append(
                f"{m.model_id:<40} {q:>8} {m.avg_latency_ms:>8.0f}ms "
                f"${m.total_cost_usd:>8.4f} {success:>9}"
            )
        lines.append("-" * 81)
        if self.best_quality:
            lines.append(f"Best Quality: {self.best_quality.model_id}")
        if self.best_value:
            lines.append(f"Best Value:   {self.best_value.model_id}")
        if self.best_speed:
            lines.append(f"Best Speed:   {self.best_speed.model_id}")
        metric_names = self.available_metrics()
        if metric_names:
            lines.append(f"\nExtra Metrics: {', '.join(metric_names)}")
        return "\n".join(lines)

    def get_metric(self, metric_name: str) -> Dict[str, Optional["ExtraMetricStat"]]:
        """Get a specific extra metric across all models.

        Args:
            metric_name: Metric identifier (e.g., "bleu", "toxicity").

        Returns:
            Dict mapping model_id to ExtraMetricStat (or None if not available).
        """
        result = {}
        for m in self.models:
            match = next((em for em in m.extra_metrics if em.name == metric_name), None)
            result[m.model_id] = match
        return result

    def available_metrics(self) -> List[str]:
        """Get list of all extra metric names across all models.

        Returns:
            Sorted, deduplicated list of metric names.
        """
        names: set = set()
        for m in self.models:
            for em in m.extra_metrics:
                names.add(em.name)
        return sorted(names)

    def _train_route(self, alpha: float = 0.76):
        """Train a routing config locally from these benchmark results.

        .. note:: Routing is shelved in this release. This method will be
           re-enabled in a future version.
        """
        raise NotImplementedError(
            "Routing is shelved in this release. "
            "This feature will be available in a future version."
        )
        # -- preserved for re-enablement --
        from modelscout_core import TrainerCore

        trainer = TrainerCore()

        validation = trainer.validate_training_data(
            embeddings=self.embeddings or [],
            model_ids=[m.model_id for m in self.models],
            quality_scores=self._quality_scores,
        )

        if not validation.is_valid:
            raise ValueError(
                f"Training data validation failed: {'; '.join(validation.errors)}"
            )

        if validation.warnings:
            for w in validation.warnings:
                logger.warning(f"Training warning: {w}")

        return trainer.train(
            embeddings=self.embeddings or [],
            model_ids=[m.model_id for m in self.models],
            quality_scores=self._quality_scores,
            costs=self._costs,
            latencies=self._latencies,
            alpha=alpha,
        )


# Backward-compatible alias
BenchmarkResults = BenchmarkResult


# =============================================================================
# Benchmark class
# =============================================================================

class Benchmark:
    """Run personalized LLM benchmarks with privacy-preserving local execution.

    All LLM calls run locally on your machine via a provisioned OpenRouter key.
    Your prompts never touch ModelScout servers. Judge evaluation runs locally
    via modelscout-core. Results auto-upload to the dashboard (aggregates only,
    opt-out available).

    Args:
        api_key: ModelScout API key (or set MODELSCOUT_API_KEY env var).
        api_url: API base URL (or set MODELSCOUT_API_URL env var).
        org_slug: Organization slug (or set MODELSCOUT_ORG_SLUG env var).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        org_slug: Optional[str] = None,
    ):
        self.api_key = api_key or os.environ.get("MODELSCOUT_API_KEY", "")
        if not self.api_key:
            raise BenchmarkError(
                "API key required. Pass api_key or set MODELSCOUT_API_KEY env var.",
                code="AUTH_REQUIRED",
            )

        self.api_url = (
            api_url or os.environ.get("MODELSCOUT_API_URL", DEFAULT_API_URL)
        ).rstrip("/")
        if not self.api_url.startswith("https://"):
            import urllib.parse as _urlparse
            _parsed = _urlparse.urlparse(self.api_url)
            _hostname = _parsed.hostname or ""
            _is_local = (
                _hostname in ("localhost", "127.0.0.1", "0.0.0.0")
                or _hostname.startswith("192.168.")
                or _hostname.startswith("10.")
            )
            if not _is_local:
                logger.warning(
                    "api_url uses HTTP instead of HTTPS. "
                    "API keys will be sent unencrypted."
                )
        self.org_slug = org_slug or os.environ.get("MODELSCOUT_ORG_SLUG", "")

    # =========================================================================
    # Checkpointing
    # =========================================================================

    # Hardcoded evaluation parameters (matching backend defaults).
    # These are NOT exposed to users — the SDK handles them internally.
    # These are locked to match backend pricing and ensure consistent evaluation.
    # Users cannot override them — ModelConfig temperature/max_tokens are for
    # direct LLM usage, not benchmark evaluation.
    _TEMPERATURE = 0.1
    _MAX_TOKENS = 2048

    # How often (in evaluations) to write a checkpoint
    _CHECKPOINT_INTERVAL = 10

    # Checkpoint format version
    _CHECKPOINT_VERSION = 2

    @staticmethod
    def _checkpoint_dir() -> str:
        """Return (and create) the checkpoint directory."""
        d = os.path.join(os.path.expanduser("~"), ".cache", "modelscout", "checkpoints")
        os.makedirs(d, mode=0o700, exist_ok=True)
        return d

    @staticmethod
    def _checkpoint_path_for_id(benchmark_id: str, benchmark_name: str) -> str:
        """Return deterministic checkpoint path using benchmark_id."""
        safe_name = re.sub(r"[^\w\-]", "_", benchmark_name)[:80]
        d = os.path.join(os.path.expanduser("~"), ".cache", "modelscout", "checkpoints")
        os.makedirs(d, mode=0o700, exist_ok=True)
        return os.path.join(d, f"{safe_name}_{benchmark_id}.json")

    def _checkpoint_path(self, benchmark_name: str) -> str:
        """Return checkpoint file path for a benchmark run (legacy, timestamp-based)."""
        safe_name = re.sub(r"[^\w\-]", "_", benchmark_name)[:80]
        ts = datetime.now().strftime("%Y%m%dT%H%M%S")
        return os.path.join(self._checkpoint_dir(), f"{safe_name}_{ts}.json")

    @staticmethod
    def _compute_config_hash(
        model_configs: List[Dict[str, Any]],
        sample_inputs: List[str],
    ) -> str:
        """Deterministic hash of benchmark configuration for checkpoint matching."""
        canonical = json.dumps({
            "models": sorted(
                [{"provider": c["provider"], "model": c["model"]} for c in model_configs],
                key=lambda x: (x["provider"], x["model"]),
            ),
            "samples": sorted(sample_inputs),
        }, sort_keys=True)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    @staticmethod
    def _write_checkpoint(
        path: str,
        per_sample_results: "List[SampleResult]",
        benchmark_name: str,
        benchmark_id: str = "",
        config_hash: str = "",
        model_configs: Optional[List[Dict[str, Any]]] = None,
        is_agentic: bool = False,
        dataset_id: Optional[str] = None,
    ) -> None:
        """Atomically write per-sample results to a checkpoint file."""
        data: Dict[str, Any] = {
            "checkpoint_version": 2,
            "benchmark_name": benchmark_name,
            "benchmark_id": benchmark_id,
            "config_hash": config_hash,
            "model_configs": model_configs or [],
            "sample_count": len(per_sample_results),
            "is_agentic": is_agentic,
            "dataset_id": dataset_id,
            "timestamp": datetime.now().isoformat() + "Z",
            "per_sample_results": [
                {
                    "sample_index": sr.sample_index,
                    "input_text": sr.input_text,
                    "expected_output": sr.expected_output,
                    "model_responses": {
                        mid: (
                            {
                                "response_text": resp.response_text,
                                "latency_ms": resp.latency_ms,
                                "cost_usd": resp.cost_usd,
                                "input_tokens": resp.input_tokens,
                                "output_tokens": resp.output_tokens,
                                "quality_score": resp.quality_score,
                                "judge_reasoning": resp.judge_reasoning,
                                "error": resp.error,
                            }
                            if resp is not None
                            else None
                        )
                        for mid, resp in sr.model_responses.items()
                    },
                }
                for sr in per_sample_results
            ],
        }
        tmp_path = path + ".tmp"
        try:
            fd = os.open(tmp_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp_path, path)
        except OSError:
            logger.debug("Failed to write checkpoint to %s", path, exc_info=True)

    @staticmethod
    def _delete_checkpoint(path: str) -> None:
        """Delete a checkpoint file if it exists."""
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass

    @staticmethod
    def list_checkpoints() -> List[str]:
        """List all existing checkpoint files.

        Returns:
            List of absolute paths to checkpoint JSON files, sorted newest first.
        """
        d = os.path.join(os.path.expanduser("~"), ".cache", "modelscout", "checkpoints")
        if not os.path.isdir(d):
            return []
        files = [
            os.path.join(d, f) for f in os.listdir(d)
            if f.endswith(".json") and not f.endswith(".tmp")
        ]
        files.sort(key=os.path.getmtime, reverse=True)
        return files

    @staticmethod
    def cleanup_checkpoints(max_age_days: int = 7) -> int:
        """Remove checkpoint files older than *max_age_days*.

        Returns:
            Number of checkpoint files removed.
        """
        d = os.path.join(os.path.expanduser("~"), ".cache", "modelscout", "checkpoints")
        if not os.path.isdir(d):
            return 0
        cutoff = time.time() - max_age_days * 86400
        removed = 0
        for fname in os.listdir(d):
            if not fname.endswith(".json") or fname.endswith(".tmp"):
                continue
            fpath = os.path.join(d, fname)
            try:
                if os.path.getmtime(fpath) < cutoff:
                    os.remove(fpath)
                    removed += 1
            except OSError:
                pass
        if removed:
            logger.debug("Cleaned up %d stale checkpoint(s) older than %d days.", removed, max_age_days)
        return removed

    @staticmethod
    def load_checkpoint(path: str) -> Dict[str, Any]:
        """Load a checkpoint file and return its contents.

        Args:
            path: Absolute path to the checkpoint JSON file.

        Returns:
            Dict with checkpoint data including per_sample_results.
        """
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _find_matching_checkpoint(
        self,
        benchmark_name: str,
        config_hash: str,
    ) -> Optional[Dict[str, Any]]:
        """Search for a resumable checkpoint matching name + config_hash.

        Returns:
            Checkpoint data dict if found, None otherwise.
        """
        for path in self.list_checkpoints():
            try:
                data = self.load_checkpoint(path)
                if (
                    data.get("checkpoint_version", 1) >= 2
                    and data.get("benchmark_name") == benchmark_name
                    and data.get("config_hash") == config_hash
                    and data.get("benchmark_id")
                ):
                    data["_checkpoint_path"] = path
                    return data
            except (json.JSONDecodeError, OSError, KeyError):
                logger.debug("Skipping unreadable checkpoint: %s", path)
                continue
        return None

    def _resume_key(self, benchmark_id: str) -> Dict[str, Any]:
        """Re-provision an OpenRouter key for a resuming benchmark."""
        resp = self._api_request("POST", f"/api/v1/benchmarks/{benchmark_id}/resume-key")
        return resp.get("data", resp)

    @staticmethod
    def _build_completed_set(
        checkpoint_data: Dict[str, Any],
    ) -> "set[tuple[int, str]]":
        """Build set of (sample_index, model_id) pairs already completed."""
        completed = set()
        for sr in checkpoint_data.get("per_sample_results", []):
            idx = sr.get("sample_index", -1)
            for model_id, resp in sr.get("model_responses", {}).items():
                if resp is not None and resp.get("response_text") is not None and not resp.get("error"):
                    completed.add((idx, model_id))
        return completed

    @staticmethod
    def _restore_per_sample_results(
        checkpoint_data: Dict[str, Any],
        all_model_ids: List[str],
    ) -> "List[SampleResult]":
        """Reconstruct SampleResult objects from checkpoint data."""
        results = []
        for sr_data in checkpoint_data.get("per_sample_results", []):
            model_responses: Dict[str, Optional[SampleModelResponse]] = {
                mid: None for mid in all_model_ids
            }
            for mid, resp_data in sr_data.get("model_responses", {}).items():
                if resp_data is not None:
                    model_responses[mid] = SampleModelResponse(
                        response_text=resp_data.get("response_text"),
                        latency_ms=resp_data.get("latency_ms", 0),
                        cost_usd=resp_data.get("cost_usd", 0),
                        input_tokens=resp_data.get("input_tokens", 0),
                        output_tokens=resp_data.get("output_tokens", 0),
                        quality_score=resp_data.get("quality_score"),
                        judge_reasoning=resp_data.get("judge_reasoning"),
                        error=resp_data.get("error"),
                    )
            results.append(SampleResult(
                sample_index=sr_data.get("sample_index", 0),
                input_text=sr_data.get("input_text", ""),
                expected_output=sr_data.get("expected_output"),
                model_responses=model_responses,
            ))
        return results

    def run(
        self,
        name: Optional[str] = None,
        purchased_benchmark_id: Optional[str] = None,
        prompts: Optional[List[str]] = None,
        samples: Optional[List[Dict[str, Any]]] = None,
        dataset_id: Optional[str] = None,
        dataset_ids: Optional[List[str]] = None,
        sample_size: int = 100,
        use_case: Optional[str] = None,
        ignore_sample_mismatch: bool = False,
        upload: bool = True,
        save_local: Optional[str] = None,
        on_progress: Optional[Callable[[BenchmarkProgress], None]] = None,
        agentic_config: Optional[AgenticConfig] = None,
        resume: bool = True,
        eval_guidance: Optional[str] = None,
        # Deprecated — kept for backwards compatibility
        tools: Optional[List[ToolDefinition]] = None,
        pack: Optional[str] = None,
    ) -> BenchmarkResult:
        """Run a benchmark comparing multiple LLM models on your data.

        Models are determined by your purchase — they are locked at checkout
        and returned by the server during provisioning. You do not need to
        (and cannot) specify models here.

        Evaluations run via a provisioned OpenRouter key. Prompts are sent
        to LLM providers through OpenRouter. Results are uploaded to
        ModelScout for analysis and dashboard display.

        Args:
            name: Benchmark name.
            purchased_benchmark_id: Purchased benchmark ID.
                Get this from the ModelScout dashboard after purchasing
                a benchmark.
            prompts: List of prompt strings to evaluate.
            samples: List of {"input": "...", "expected_output": "..."} dicts.
                Alternative to prompts. Mutually exclusive with dataset_id.
            dataset_id: Existing dataset ID on the platform. Mutually
                exclusive with prompts/samples and dataset_ids.
            dataset_ids: List of dataset IDs to combine (max 5). Mutually
                exclusive with prompts/samples and dataset_id.
            sample_size: Number of samples to evaluate per model.
            ignore_sample_mismatch: When True, proceed even if the number
                of samples doesn't match the purchase limit. If more samples
                than allowed, deterministically subsample (seed=42). If fewer,
                proceed with the available samples. Default False — errors
                on mismatch to prevent accidental over/under-use.
            upload: Upload per-sample results to dashboard (default True).
                Backend runs the same aggregation as remote benchmarks.
            save_local: Optional file path to save full results locally as JSON.
            on_progress: Optional callback for progress updates. Receives a
                BenchmarkProgress object. May be called from multiple threads
                during the "evaluating" phase.
            agentic_config: Optional AgenticConfig with tools and loop settings.
                When provided, the SDK orchestrates a multi-turn tool-use loop
                for each sample, testing how well each LLM uses the tools.
            resume: When True (default), automatically resume from a checkpoint
                if one exists for the same name and configuration. Set to False
                to always start fresh.
            eval_guidance: Optional guidance for the AI judge (max 500 chars).
                Shapes what the judge prioritizes when scoring quality. E.g.,
                "Responses should be concise, use professional tone, and cite sources."

        Deprecated Args:
            tools: Use ``agentic_config=AgenticConfig(tools=[...])`` instead.
            pack: Use ``purchased_benchmark_id`` instead.

        Returns:
            BenchmarkResult with per-model scores, recommendations, and
            per-sample data for local training.
        """
        # Housekeeping: clean up stale checkpoints (fire-and-forget)
        try:
            self.cleanup_checkpoints(max_age_days=30)
        except Exception:
            pass

        # ----- Deprecation bridges -----
        if tools is not None:
            warnings.warn(
                "'tools' parameter is deprecated and will be removed in a "
                "future version. Use agentic_config=AgenticConfig(tools=[...]) "
                "instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            if agentic_config is not None:
                raise BenchmarkError(
                    "Cannot specify both 'tools' and 'agentic_config'. "
                    "Pass tools inside AgenticConfig.",
                    code="INVALID_ARGS",
                )
            agentic_config = AgenticConfig(tools=tools)

        # Deprecated 'pack' alias → purchased_benchmark_id
        if pack is not None:
            warnings.warn(
                "'pack' is deprecated. "
                "Use the 'purchased_benchmark_id' parameter instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            if purchased_benchmark_id is None:
                purchased_benchmark_id = pack

        if purchased_benchmark_id is None:
            raise BenchmarkError(
                "'purchased_benchmark_id' is required. Pass the ID ('pb_...') you received "
                "after purchasing a benchmark at https://modelscout.co/dashboard.",
                code="MISSING_PURCHASED_BENCHMARK_ID",
            )

        # Auto-generate name if not provided
        if not name:
            from datetime import datetime as _dt
            name = f"Benchmark {_dt.now().strftime('%Y-%m-%d %H:%M')}"

        is_agentic = agentic_config is not None
        if is_agentic:
            agentic_config.validate()

        # Models come from the purchase config — resolved after provisioning
        model_configs: List[Dict[str, Any]] = []

        # Validate mutually exclusive data params.
        # Exactly one source allowed: prompts, samples, dataset_id, or dataset_ids.
        # (samples is okay alone — prompts are extracted from samples.)
        has_inline = bool(prompts) or bool(samples)
        has_platform = bool(dataset_id) or bool(dataset_ids)
        if has_inline and has_platform:
            raise BenchmarkError(
                "Cannot specify both inline data (prompts/samples) and platform datasets "
                "(dataset_id/dataset_ids). Choose one data source.",
                code="CONFLICTING_DATA_SOURCES",
            )
        if dataset_id and dataset_ids:
            raise BenchmarkError(
                "Cannot specify both 'dataset_id' and 'dataset_ids'. "
                "Use dataset_id for a single dataset or dataset_ids to combine multiple.",
                code="CONFLICTING_DATA_SOURCES",
            )
        if prompts and samples:
            raise BenchmarkError(
                "Cannot specify both 'prompts' and 'samples'. "
                "Use prompts for simple inputs, or samples for input + expected_output pairs.",
                code="CONFLICTING_DATA_SOURCES",
            )

        # Resolve prompts from samples if provided
        if samples and not prompts:
            prompts = [s["input"] for s in samples]
        elif not prompts and not samples:
            # Fetch from platform datasets
            fetch_ids = dataset_ids or ([dataset_id] if dataset_id else [])
            if fetch_ids:
                all_samples = []
                for did in fetch_ids:
                    resp = self._api_request("GET", f"/api/v1/datasets/{did}/samples")
                    data = resp.get("data", resp)
                    fetched = data.get("samples", data) if isinstance(data, dict) else data
                    all_samples.extend(fetched)
                samples = all_samples
                prompts = [s.get("input", s.get("prompt", "")) for s in all_samples]
            else:
                raise BenchmarkError(
                    "'prompts', 'samples', 'dataset_id', or 'dataset_ids' must be provided.",
                    code="MISSING_DATA",
                )

        # Filter out empty/None prompts (and their corresponding samples)
        original_count = len(prompts) if prompts else 0
        if prompts:
            valid = [
                (i, p) for i, p in enumerate(prompts)
                if p and isinstance(p, str) and p.strip()
            ]
            if len(valid) < original_count:
                dropped = original_count - len(valid)
                logger.warning(
                    "Dropped %d empty/invalid prompt(s) out of %d total.",
                    dropped, original_count,
                )
                indices_kept = [i for i, _ in valid]
                prompts = [p for _, p in valid]
                if samples:
                    samples = [samples[i] for i in indices_kept]

        if not prompts:
            raise BenchmarkError(
                "'prompts' or 'samples' must be provided.",
                code="MISSING_DATA",
            )

        # ----- Sample size validation -----
        if sample_size > MAX_SAMPLES:
            raise BenchmarkError(
                f"Maximum {MAX_SAMPLES} samples per benchmark. "
                f"You requested {sample_size}.",
                code="TOO_MANY_SAMPLES",
            )

        # ----- Sample count mismatch check -----
        num_available = len(prompts)

        if num_available != sample_size:
            if num_available > sample_size:
                # More samples than requested — need to subsample
                if not ignore_sample_mismatch:
                    raise BenchmarkError(
                        f"Dataset has {num_available} samples but sample_size is {sample_size}. "
                        f"Pass ignore_sample_mismatch=True to subsample automatically.",
                        code="SAMPLE_MISMATCH",
                    )
                logger.warning(
                    "Subsampling %d samples to %d (deterministic, seed=42).",
                    num_available, sample_size,
                )
                import random as _random
                rng = _random.Random(42)
                indices = rng.sample(range(num_available), sample_size)
                indices.sort()
                prompts = [prompts[i] for i in indices]
                if samples:
                    samples = [samples[i] for i in indices]
            else:
                # Fewer samples than requested
                if not ignore_sample_mismatch:
                    raise BenchmarkError(
                        f"Dataset has {num_available} samples but sample_size is {sample_size}. "
                        f"Pass ignore_sample_mismatch=True to proceed with fewer samples.",
                        code="SAMPLE_MISMATCH",
                    )
                logger.warning(
                    "Running %d samples (sample_size allows up to %d).",
                    num_available, sample_size,
                )

        # Build samples list if we only have prompts
        if samples is None:
            samples = [{"input": p} for p in prompts]

        # Effective sample size is the actual number of prompts after adjustment
        effective_sample_size = len(prompts)

        # Resolve pack name → purchased benchmark ID
        resolved_pack_id = self._resolve_pack_id(purchased_benchmark_id)

        # Auto-upload inline samples as a dataset when no platform dataset provided
        if not dataset_id and not dataset_ids and samples:
            dataset_id = self.upload_dataset(
                name=f"{name} — auto-uploaded",
                samples=samples,
                description="Auto-uploaded by SDK for benchmark execution",
            )
            logger.info("Auto-uploaded %d samples as dataset %s", len(samples), dataset_id)

        # Compute config hash for checkpoint matching
        config_hash = self._compute_config_hash(model_configs, prompts)

        # ----- Resume detection -----
        checkpoint_data = None
        completed_evals: Optional[set] = None
        provision_resp: Dict[str, Any] = {}

        if resume:
            checkpoint_data = self._find_matching_checkpoint(name, config_hash)

        if checkpoint_data is not None:
            # Resume from checkpoint
            benchmark_id = checkpoint_data["benchmark_id"]
            completed_evals = self._build_completed_set(checkpoint_data)
            n_completed = len(completed_evals)
            n_total = len(prompts) * len(model_configs)
            logger.info(
                "Resuming benchmark %s from checkpoint (%d/%d evaluations completed)",
                benchmark_id, n_completed, n_total,
            )

            try:
                resume_resp = self._resume_key(benchmark_id)
                openrouter_key = resume_resp.get("openrouter_key")
                spending_limit = resume_resp.get("spending_limit_usd")
                if not openrouter_key:
                    raise BenchmarkError(
                        "Resume failed: server did not return an OpenRouter key. "
                        "Try starting a new benchmark.",
                        code="RESUME_FAILED",
                    )
                # Build a provision_resp-like dict for judge evaluation
                provision_resp = {
                    "benchmark_id": benchmark_id,
                    "openrouter_key": openrouter_key,
                    "spending_limit_usd": spending_limit,
                    "expires_at": resume_resp.get("expires_at"),
                    "judge_model": resume_resp.get("judge_model", "google/gemini-3.1-pro"),
                    "is_free_tier": resume_resp.get("is_free_tier", False),
                }
            except BenchmarkError as e:
                logger.warning(
                    "Failed to resume benchmark %s: %s — starting fresh",
                    benchmark_id, e,
                )
                checkpoint_data = None
                completed_evals = None

        if checkpoint_data is None:
            # Fresh benchmark — provision new key
            provision_resp = self._provision_key(
                name=name,
                dataset_id=dataset_id,
                dataset_ids=dataset_ids,
                model_configs=model_configs,
                sample_size=effective_sample_size,
                purchased_benchmark_id=resolved_pack_id,
                use_case=use_case,
                is_agentic=is_agentic,
                agentic_config=agentic_config,
                eval_guidance=eval_guidance,
            )

            benchmark_id = provision_resp["benchmark_id"]
            openrouter_key = provision_resp["openrouter_key"]
            spending_limit = provision_resp["spending_limit_usd"]

            # Models come from the server (purchase config is the source of truth)
            server_models = provision_resp.get("models")
            if server_models:
                model_configs = server_models
                logger.info("Using %d models from purchase config", len(model_configs))

        # Store key expiry for safety checks in _call_openrouter
        expires_at_str = provision_resp.get("expires_at")
        if expires_at_str:
            try:
                self._key_expires_at = datetime.fromisoformat(
                    expires_at_str.replace("Z", "+00:00")
                )
            except (ValueError, TypeError):
                self._key_expires_at = None
        else:
            self._key_expires_at = None

        logger.info(
            "OpenRouter key ready for benchmark %s (limit: $%.2f)",
            benchmark_id,
            spending_limit,
        )

        # Checkpoint file keyed by benchmark_id (deterministic, no stale files)
        ckpt_path = self._checkpoint_path_for_id(benchmark_id, name)
        logger.debug("Checkpoint file: %s", ckpt_path)

        per_sample_results: list = []  # Pre-init for checkpoint write on crash

        try:
            # Step 2: Run LLM evaluations locally via OpenRouter
            start_time = time.time()
            if is_agentic:
                model_results_raw, per_sample_results, total_evaluated, total_failed = (
                    self._run_agentic_evaluations(
                        prompts=prompts,
                        samples=samples,
                        model_configs=model_configs,
                        openrouter_key=openrouter_key,
                        tools=agentic_config.tools,
                        agentic_config=agentic_config,
                        spending_limit=spending_limit,
                        on_progress=on_progress,
                        checkpoint_path=ckpt_path,
                        benchmark_name=name,
                        benchmark_id=benchmark_id,
                        config_hash=config_hash,
                        is_agentic=True,
                        completed_evals=completed_evals,
                        dataset_id=dataset_id,
                    )
                )
            else:
                model_results_raw, per_sample_results, total_evaluated, total_failed = (
                    self._run_evaluations(
                        prompts=prompts,
                        samples=samples,
                        model_configs=model_configs,
                        openrouter_key=openrouter_key,
                        spending_limit=spending_limit,
                        on_progress=on_progress,
                        checkpoint_path=ckpt_path,
                        benchmark_name=name,
                        benchmark_id=benchmark_id,
                        config_hash=config_hash,
                        is_agentic=False,
                        completed_evals=completed_evals,
                        dataset_id=dataset_id,
                    )
                )
            execution_time = time.time() - start_time

            # Step 3: Embed prompts locally (for training)
            run_warnings: List[str] = []
            embeddings = self._embed_prompts(samples)
            if not embeddings:
                run_warnings.append(
                    "Embedding failed — routing training will not be available. "
                    "Install onnxruntime to enable: pip install onnxruntime"
                )

            # Step 4: Judge evaluation via provisioned key
            if on_progress:
                # Count judge tasks for progress total
                judge_count = sum(
                    1
                    for sr in per_sample_results
                    for resp in sr.model_responses.values()
                    if resp and not resp.error and resp.response_text
                )
                on_progress(BenchmarkProgress(
                    phase="judging", completed=0, total=judge_count,
                ))
            try:
                self._run_judge_evaluation(
                    per_sample_results=per_sample_results,
                    model_configs=model_configs,
                    openrouter_key=openrouter_key,
                    provision_data=provision_resp,
                    tools=agentic_config.tools if is_agentic else None,
                )
            except BenchmarkError:
                raise  # Re-raise SDK errors as-is (e.g. SPENDING_LIMIT)
            except Exception as e:
                logger.error("Judge evaluation failed: %s", e)
                self._write_checkpoint(
                    ckpt_path, per_sample_results, name,
                    benchmark_id=benchmark_id, config_hash=config_hash,
                    model_configs=model_configs, is_agentic=is_agentic,
                    dataset_id=dataset_id,
                )
                raise BenchmarkError(
                    f"Judging failed after LLM evaluations completed successfully: {e}. "
                    "Run with resume=True to retry judging without re-running LLM calls.",
                    code="JUDGE_FAILED",
                )

            # Step 5: Aggregate metrics
            if on_progress:
                on_progress(BenchmarkProgress(
                    phase="aggregating", completed=0, total=0,
                ))
            model_results, quality_scores, costs_dict, latencies_dict = (
                self._aggregate_metrics(
                    per_sample_results, model_configs,
                    tools=agentic_config.tools if is_agentic else None,
                )
            )

            # Step 6: Generate recommendations
            best_quality, best_value, best_speed = self._generate_recommendations(
                model_results,
            )

            # Build result
            result = BenchmarkResult(
                benchmark_id=benchmark_id,
                name=name,
                status="completed",
                created_at=datetime.utcnow().isoformat() + "Z",
                models=model_results,
                best_quality=best_quality,
                best_value=best_value,
                best_speed=best_speed,
                per_sample=per_sample_results,
                embeddings=embeddings,
                warnings=run_warnings,
                _quality_scores=quality_scores,
                _costs=costs_dict,
                _latencies=latencies_dict,
            )

            # Step 7: Save locally if requested
            if save_local:
                self._save_local(result, save_local)
                logger.info(f"Full results saved to {save_local}")

            # Step 8: Submit results to backend (with per-sample data for
            # full dashboard parity when upload=True)
            if upload and on_progress:
                on_progress(BenchmarkProgress(
                    phase="uploading", completed=0, total=0,
                ))
            if upload:
                judge_model_id = provision_resp.get("judge_model", "google/gemini-3.1-pro")
                self._submit_results(
                    benchmark_id=benchmark_id,
                    per_sample_results=per_sample_results,
                    total_evaluated=total_evaluated,
                    total_failed=total_failed,
                    execution_seconds=execution_time,
                    judge_model=judge_model_id,
                    is_agentic=is_agentic,
                    agentic_config=agentic_config if is_agentic else None,
                )
            result.uploaded = upload
            result.backend_benchmark_id = benchmark_id

            # Results submitted successfully — remove checkpoint
            self._delete_checkpoint(ckpt_path)

            return result

        except BaseException:
            # Write a final checkpoint so partial results are recoverable.
            # Using BaseException to catch KeyboardInterrupt (Ctrl+C) too.
            try:
                self._write_checkpoint(
                    ckpt_path, per_sample_results, name,
                    benchmark_id=benchmark_id, config_hash=config_hash,
                    model_configs=model_configs, is_agentic=is_agentic,
                    dataset_id=dataset_id,
                )
            except Exception as e:
                logger.warning("Failed to write checkpoint: %s", e)
            logger.info("Benchmark failed — checkpoint preserved at %s", ckpt_path)
            self._notify_failure(benchmark_id)
            raise

    def resume(
        self,
        checkpoint_path: str,
        purchased_benchmark_id: Optional[str] = None,
        on_progress: Optional[Callable[[BenchmarkProgress], None]] = None,
        upload: bool = True,
        save_local: Optional[str] = None,
        agentic_config: Optional[AgenticConfig] = None,
    ) -> BenchmarkResult:
        """Resume a benchmark from a specific checkpoint file.

        Use this when you have the checkpoint path from ``list_checkpoints()``
        and want to explicitly resume rather than rely on auto-detection.

        Args:
            checkpoint_path: Path to checkpoint JSON file.
            purchased_benchmark_id: Must match the original (validated against checkpoint).
            on_progress: Optional callback for progress updates.
            upload: Auto-upload results to dashboard (default True).
            save_local: Optional file path to save full results locally.
            agentic_config: Required for agentic benchmarks (tools not
                stored in checkpoint). Pass the same AgenticConfig used
                in the original run.

        Returns:
            BenchmarkResult with per-model scores and recommendations.
        """
        data = self.load_checkpoint(checkpoint_path)

        if data.get("checkpoint_version", 1) < 2:
            raise BenchmarkError(
                "Cannot resume from v1 checkpoint (missing benchmark_id). "
                "Please start a fresh benchmark.",
                code="CHECKPOINT_TOO_OLD",
            )

        name = data["benchmark_name"]
        model_configs = data.get("model_configs", [])
        if not model_configs:
            raise BenchmarkError(
                "Checkpoint missing model_configs — cannot resume.",
                code="INVALID_CHECKPOINT",
            )

        if data.get("is_agentic") and agentic_config is None:
            raise BenchmarkError(
                "This is an agentic benchmark checkpoint. Pass the same "
                "agentic_config used in the original run.",
                code="AGENTIC_CONFIG_REQUIRED",
            )

        # Reconstruct prompts from checkpoint
        prompts = [
            sr.get("input_text", "")
            for sr in data.get("per_sample_results", [])
        ]
        samples = [
            {
                "input": sr.get("input_text", ""),
                **({"expected_output": sr["expected_output"]} if sr.get("expected_output") else {}),
            }
            for sr in data.get("per_sample_results", [])
        ]

        # Restore dataset_id so re-provisioning succeeds
        checkpoint_dataset_id = data.get("dataset_id")

        return self.run(
            name=name,
            purchased_benchmark_id=purchased_benchmark_id,
            prompts=prompts,
            samples=samples,
            dataset_id=checkpoint_dataset_id,
            models=model_configs,
            sample_size=len(prompts),
            upload=upload,
            save_local=save_local,
            on_progress=on_progress,
            agentic_config=agentic_config,
            resume=True,
        )

    # -----------------------------------------------------------------
    # Discovery methods
    # -----------------------------------------------------------------

    def list_models(self) -> List[Dict[str, Any]]:
        """List available LLM models with pricing and premium status.

        Returns a list of dicts with keys like ``provider``, ``model``,
        ``input_price_per_1m``, ``output_price_per_1m``, ``is_premium``.
        """
        resp = self._api_request("GET", "/api/v1/billing/pricing/models")
        models = resp.get("models", [])
        result = []
        for m in models:
            provider = m.get("provider", "")
            # Skip internal-only providers
            if provider in ("openrouter_paid",):
                continue
            model_id = f"{provider}/{m.get('model', '')}"
            m["is_premium"] = model_id in PREMIUM_MODELS
            result.append(m)
        return result

    def list_datasets(self) -> List[Dict[str, Any]]:
        """List your datasets on the platform."""
        resp = self._api_request("GET", "/api/v1/datasets")
        data = resp.get("data", resp)
        return data.get("datasets", data) if isinstance(data, dict) else data

    def _upload_route(self, train_result: Any, name: Optional[str] = None) -> str:
        """Upload a locally-trained routing config to ModelScout backend.

        .. note:: Routing is shelved in this release. This method will be
           re-enabled in a future version.
        """
        raise NotImplementedError(
            "Routing is shelved in this release. "
            "This feature will be available in a future version."
        )
        # -- preserved for re-enablement --
        config_json = json.dumps(train_result.config_data).encode("utf-8")
        config_b64 = base64.b64encode(config_json).decode("ascii")

        body = {
            "name": name or f"Local Training ({datetime.utcnow().strftime('%Y-%m-%d')})",
            "source": "local_training",
            "config_data": config_b64,
            "metadata": {
                "n_segments": train_result.n_segments,
                "segment_distribution": train_result.segment_distribution,
                "training_accuracy": train_result.training_accuracy,
                "matching_method": train_result.matching_method,
                "sdk_version": self._get_sdk_version(),
            },
        }

        resp = self._api_request("POST", "/api/v1/routing-configs/upload-local", body)
        return resp.get("data", resp).get("config_id", resp.get("id", ""))

    # =========================================================================
    # Sample loading
    # =========================================================================

    @staticmethod
    def load_dataset(path: str) -> List[Dict[str, Any]]:
        """Load samples from a local file (JSON, JSONL, or CSV).

        Args:
            path: Path to the dataset file.

        Returns:
            List of sample dicts with "input" and optional "expected_output".
        """
        if not os.path.exists(path):
            raise FileNotFoundError(f"Dataset file not found: {path}")

        file_size = os.path.getsize(path)
        if file_size > MAX_DATASET_FILE_SIZE:
            raise ValueError(
                f"Dataset file is {file_size / (1024*1024):.1f} MB, "
                f"exceeds {MAX_DATASET_FILE_SIZE // (1024*1024)} MB limit."
            )

        ext = os.path.splitext(path)[1].lower()

        if ext == ".json":
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
            raise ValueError("JSON file must contain a list of sample objects")

        elif ext == ".jsonl":
            samples = []
            parse_errors = 0
            with open(path, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        samples.append(json.loads(line))
                    except json.JSONDecodeError:
                        parse_errors += 1
                        logger.warning("Skipping malformed JSONL line %d in %s", line_num, path)
            total_lines = len(samples) + parse_errors
            if total_lines > 0 and parse_errors / total_lines > 0.1:
                raise ValueError(
                    f"Too many malformed lines in {path}: {parse_errors}/{total_lines} "
                    f"({parse_errors/total_lines:.0%}) failed to parse."
                )
            if parse_errors > 0:
                logger.warning(
                    "%d of %d lines in %s could not be parsed and were skipped.",
                    parse_errors, total_lines, path,
                )
            if not samples:
                raise ValueError(f"No valid samples found in {path}")
            return samples

        elif ext == ".csv":
            samples = []
            with open(path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames or "input" not in reader.fieldnames:
                    found = list(reader.fieldnames) if reader.fieldnames else []
                    raise ValueError(
                        f"CSV file must have an 'input' column. "
                        f"Found columns: {found}"
                    )
                for row in reader:
                    sample = {"input": row.get("input", "")}
                    if "expected_output" in row:
                        sample["expected_output"] = row["expected_output"]
                    samples.append(sample)
            return samples

        else:
            raise ValueError(f"Unsupported file format: {ext}. Use .json, .jsonl, or .csv")

    # =========================================================================
    # Dataset upload and generation
    # =========================================================================

    def upload_dataset(
        self,
        name: str,
        samples: List[Dict[str, Any]],
        description: str = "",
        dataset_type: str = "prompts_only",
        system_prompt: Optional[str] = None,
    ) -> str:
        """Upload a dataset to the ModelScout platform.

        Args:
            name: Dataset name.
            samples: List of sample dicts, each must have an "input" key.
                For prompts_with_expected_outputs: also include "expected_output".
            description: Optional description.
            dataset_type: One of "prompts_only", "prompts_with_expected_outputs".
            system_prompt: Optional system prompt prepended to all samples.

        Returns:
            Dataset ID (ds_...) on the platform.

        Raises:
            BenchmarkError: If validation fails or upload errors.
        """
        valid_types = {"prompts_only", "prompts_with_expected_outputs"}
        if dataset_type not in valid_types:
            raise BenchmarkError(
                f"Invalid dataset_type: {dataset_type}. Must be one of: {valid_types}",
                code="INVALID_DATASET_TYPE",
            )

        if not samples:
            raise BenchmarkError("samples must be a non-empty list.", code="MISSING_DATA")

        # Validate samples
        for i, s in enumerate(samples):
            if not isinstance(s, dict) or "input" not in s:
                raise BenchmarkError(
                    f"samples[{i}] must be a dict with an 'input' key.",
                    code="INVALID_SAMPLE",
                )

        # Check payload size (~50MB limit)
        payload_str = json.dumps(samples)
        if len(payload_str) > 50 * 1024 * 1024:
            raise BenchmarkError(
                "Dataset payload exceeds 50MB limit. Reduce sample count or content size.",
                code="PAYLOAD_TOO_LARGE",
            )

        # Convert samples to JSONL format with "prompt" key (backend convention)
        lines = []
        has_expected = any("expected_output" in s for s in samples)
        for s in samples:
            row: Dict[str, Any] = {"prompt": s["input"]}
            if "expected_output" in s:
                row["expected_output"] = s["expected_output"]
            if "metadata" in s and "context" in s["metadata"]:
                row["context"] = s["metadata"]["context"]
            lines.append(json.dumps(row))
        jsonl_content = "\n".join(lines).encode("utf-8")

        # Auto-detect dataset_type from samples if caller used default
        if dataset_type == "prompts_only" and has_expected:
            dataset_type = "prompts_with_expected_outputs"

        # Build multipart form data
        boundary = f"----ModelScoutSDK{id(samples):016x}"
        parts: list[bytes] = []

        def _add_field(field_name: str, value: str) -> None:
            parts.append(f"--{boundary}\r\n".encode())
            parts.append(f'Content-Disposition: form-data; name="{field_name}"\r\n\r\n'.encode())
            parts.append(f"{value}\r\n".encode())

        def _add_file(field_name: str, filename: str, content: bytes, content_type: str) -> None:
            parts.append(f"--{boundary}\r\n".encode())
            parts.append(
                f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"\r\n'
                f'Content-Type: {content_type}\r\n\r\n'.encode()
            )
            parts.append(content)
            parts.append(b"\r\n")

        _add_field("name", name)
        _add_field("description", description)
        _add_field("dataset_type", dataset_type)
        _add_field("input_field", "prompt")
        if has_expected:
            _add_field("output_field", "expected_output")
        if system_prompt:
            _add_field("system_prompt", system_prompt)
        _add_file("file", "dataset.jsonl", jsonl_content, "application/jsonl")
        parts.append(f"--{boundary}--\r\n".encode())

        body_bytes = b"".join(parts)
        content_type = f"multipart/form-data; boundary={boundary}"

        resp = self._api_request(
            "POST", "/api/v1/datasets/upload",
            body=None,
            raw_body=body_bytes,
            content_type=content_type,
        )
        data = resp.get("data", resp)
        dataset_id = data.get("id", data.get("dataset_id", ""))
        logger.info("Dataset uploaded: %s (%d samples)", dataset_id, len(samples))
        return dataset_id

    def generate_dataset(self, *args, **kwargs):
        """Deprecated: Data generation is now a paid feature available through the dashboard.

        Create datasets at https://modelscout.co/dashboard/datasets
        Then use the dataset_id in benchmark.run(dataset_id="ds_...").
        """
        raise NotImplementedError(
            "generate_dataset() has been removed. "
            "Data generation is now available through the ModelScout dashboard. "
            "Create datasets at https://modelscout.co/dashboard/datasets, "
            "then use benchmark.run(dataset_id='ds_...')."
        )

    # =========================================================================
    # Model resolution
    # =========================================================================

    # ----- Pack validation helpers -----

    def _validate_pack_limits(
        self,
        pack: str,
        model_configs: List[Dict[str, Any]],
        num_samples: int,
        sample_size: int,
        allow_sampling: bool,
        is_agentic: bool = False,
    ) -> int:
        """Validate model/sample counts against pack limits.

        With PAYG pricing, limits are set dynamically at purchase time and
        stored in the purchased benchmark document. The server validates
        all limits. Client-side validation is no longer performed.

        Returns the effective sample size.
        """
        return min(sample_size, num_samples)

    def _resolve_pack_id(self, pack: str) -> str:
        """Resolve a pack name to a purchased benchmark ID.

        If ``pack`` is already a ``pb_...`` ID or a UUID, return it directly.
        ``"trial"`` is passed through directly — the backend claims it
        atomically during provision.
        Otherwise look up the user's unused packs of that type.
        """
        if pack.startswith("pb_"):
            return pack

        if pack == "trial":
            return "trial"

        # Accept raw UUIDs or any ID that looks like a purchased benchmark ID
        # (contains digits, dashes, or is long enough to not be a pack type name)
        import re as _re
        if _re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", pack):
            return pack
        if len(pack) > 16 or "-" in pack:
            return pack  # Looks like an ID, not a pack type name

        resp = self._api_request("GET", "/api/v1/billing/purchased-benchmarks")
        data = resp.get("data", resp)
        purchased = data.get("purchased_benchmarks", [])

        for p in purchased:
            if p.get("pack_type") == pack and not p.get("used"):
                return p["id"]

        raise BenchmarkError(
            f"No unused '{pack}' benchmark pack found. "
            f"Purchase one at your ModelScout dashboard.",
            code="NO_PACK",
        )

    @staticmethod
    def _is_premium(model_config: Dict[str, Any]) -> bool:
        """Check if a model config refers to a premium model."""
        provider = model_config.get("provider", "")
        model = model_config.get("model", "")
        # Resolve aliases
        aliases = _MODEL_ALIASES.get(provider, {})
        resolved = aliases.get(model, model)
        return f"{provider}/{resolved}" in PREMIUM_MODELS

    # ----- Model resolution -----

    def _resolve_models(
        self,
        models: Union[str, List[Dict[str, Any]]],
    ) -> List[Dict[str, Any]]:
        """Resolve model specification to concrete model configs."""
        if models == "auto":
            return [
                {"provider": "deepseek", "model": "deepseek-v3.2"},
                {"provider": "openai", "model": "gpt-5-mini"},
                {"provider": "google", "model": "gemini-3.1-pro"},
                {"provider": "openai", "model": "gpt-5.4"},
            ]

        if not isinstance(models, list) or not models:
            raise BenchmarkError(
                "models must be 'auto' or a non-empty list of model configs.",
                code="INVALID_MODELS",
            )
        for i, mc in enumerate(models):
            if not isinstance(mc, dict):
                raise BenchmarkError(
                    f"models[{i}] must be a dict with 'provider' and 'model' keys, got {type(mc).__name__}.",
                    code="INVALID_MODELS",
                )
            if "provider" not in mc or "model" not in mc:
                raise BenchmarkError(
                    f"models[{i}] missing required key(s): "
                    f"{'provider' if 'provider' not in mc else ''}"
                    f"{' and ' if 'provider' not in mc and 'model' not in mc else ''}"
                    f"{'model' if 'model' not in mc else ''}. "
                    f"Expected {{'provider': '...', 'model': '...'}}.",
                    code="INVALID_MODELS",
                )
            if not mc["provider"] or not isinstance(mc["provider"], str):
                raise BenchmarkError(
                    f"models[{i}]['provider'] must be a non-empty string.",
                    code="INVALID_MODELS",
                )
            if not mc["model"] or not isinstance(mc["model"], str):
                raise BenchmarkError(
                    f"models[{i}]['model'] must be a non-empty string.",
                    code="INVALID_MODELS",
                )

        return models

    # =========================================================================
    # OpenRouter key provisioning
    # =========================================================================

    def _provision_key(
        self,
        name: str,
        dataset_id: Optional[str],
        dataset_ids: Optional[List[str]] = None,
        model_configs: Optional[List[Dict[str, Any]]] = None,
        sample_size: int = 100,
        purchased_benchmark_id: Optional[str] = None,
        use_case: Optional[str] = None,
        is_agentic: bool = False,
        agentic_config: Optional[AgenticConfig] = None,
        eval_guidance: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Provision an OpenRouter key from the backend."""
        body: Dict[str, Any] = {
            "name": name,
            "config": {
                "models": model_configs or [],
                "sample_size": sample_size,
                "judge_config": {"enabled": True},
            },
        }
        if dataset_ids:
            body["dataset_ids"] = dataset_ids
        elif dataset_id:
            body["dataset_id"] = dataset_id
        if purchased_benchmark_id:
            body["purchased_benchmark_id"] = purchased_benchmark_id
        if use_case:
            body["use_case_description"] = use_case
        if eval_guidance:
            body["evaluation_guidance"] = eval_guidance
        if is_agentic and agentic_config:
            body["is_agentic"] = True
            body["agentic_config"] = {
                "max_turns": agentic_config._MAX_TURNS,
                "max_tokens_per_turn": agentic_config._MAX_TOKENS_PER_TURN,
                "timeout_seconds": agentic_config._TIMEOUT_SECONDS,
            }

        resp = self._api_request("POST", "/api/v1/benchmarks/provision-key", body=body)
        return resp.get("data", resp)

    # =========================================================================
    # LLM evaluation via OpenRouter
    # =========================================================================

    def _run_evaluations(
        self,
        prompts: List[str],
        samples: List[Dict[str, Any]],
        model_configs: List[Dict[str, Any]],
        openrouter_key: str,
        spending_limit: float = 0.0,
        on_progress: Optional[Callable[[BenchmarkProgress], None]] = None,
        checkpoint_path: Optional[str] = None,
        benchmark_name: str = "",
        benchmark_id: str = "",
        config_hash: str = "",
        is_agentic: bool = False,
        completed_evals: Optional[set] = None,
        dataset_id: Optional[str] = None,
    ) -> tuple:
        """Run LLM evaluations locally via OpenRouter.

        Args:
            completed_evals: Optional set of (sample_index, model_id) tuples
                to skip (already completed in a previous run).

        Returns:
            (model_results_raw, per_sample_results, total_evaluated, total_failed)
        """
        from modelscout.llm_client import PRICING, MODEL_ALIASES

        spending_limit_event = threading.Event()
        cumulative_cost_lock = threading.Lock()
        cumulative_cost = [0.0]  # Mutable for closure access

        # Thread-safe progress tracking
        progress_total = len(prompts) * len(model_configs)
        progress_completed = [0]  # mutable container for closure
        progress_lock = threading.Lock()
        checkpoint_counter = [0]  # evaluations since last checkpoint

        # Pre-count completed evals for progress offset
        n_already_done = len(completed_evals) if completed_evals else 0
        if n_already_done > 0:
            progress_completed[0] = n_already_done

        def _fire_progress(model_id: str) -> None:
            should_checkpoint = False
            if on_progress or checkpoint_path:
                with progress_lock:
                    progress_completed[0] += 1
                    completed = progress_completed[0]
                    checkpoint_counter[0] += 1
                    if checkpoint_path and checkpoint_counter[0] >= self._CHECKPOINT_INTERVAL:
                        checkpoint_counter[0] = 0
                        should_checkpoint = True
            else:
                return
            if on_progress:
                on_progress(BenchmarkProgress(
                    phase="evaluating",
                    completed=completed,
                    total=progress_total,
                    current_model=model_id,
                ))
            if should_checkpoint:
                self._write_checkpoint(
                    checkpoint_path, per_sample_results, benchmark_name,
                    benchmark_id=benchmark_id, config_hash=config_hash,
                    model_configs=model_configs, is_agentic=is_agentic,
                    dataset_id=dataset_id,
                )

        # Pre-allocate per-sample result structures with all model keys so each
        # thread writes to a distinct key — safe without locks even on GIL-free runtimes.
        all_model_ids = [f"{c['provider']}/{c['model']}" for c in model_configs]

        # If resuming, restore per_sample_results from checkpoint
        if completed_evals:
            # Find the checkpoint data from the path
            checkpoint_data_for_restore = None
            if checkpoint_path and os.path.exists(checkpoint_path):
                try:
                    checkpoint_data_for_restore = self.load_checkpoint(checkpoint_path)
                except (json.JSONDecodeError, OSError) as e:
                    logger.warning("Could not load checkpoint %s: %s. Starting fresh.", checkpoint_path, e)
            if checkpoint_data_for_restore:
                per_sample_results = self._restore_per_sample_results(
                    checkpoint_data_for_restore, all_model_ids,
                )
                # Restore cumulative cost from completed evaluations
                for sr in per_sample_results:
                    for resp in sr.model_responses.values():
                        if resp is not None and resp.cost_usd:
                            cumulative_cost[0] += resp.cost_usd
            else:
                # Checkpoint file gone — cannot restore, clear completed_evals
                completed_evals = None
                per_sample_results = []

        if not completed_evals:
            per_sample_results = []
            for i, sample in enumerate(samples):
                per_sample_results.append(SampleResult(
                    sample_index=i,
                    input_text=sample.get("input", prompts[i] if i < len(prompts) else ""),
                    expected_output=sample.get("expected_output"),
                    model_responses={mid: None for mid in all_model_ids},
                ))

        def _evaluate_model(config: Dict[str, Any]) -> ModelResult:
            provider = config["provider"]
            model = config["model"]
            model_id = f"{provider}/{model}"

            if spending_limit_event.is_set():
                return ModelResult(
                    provider=provider, model=model, model_id=model_id,
                    samples_failed=len(prompts),
                )

            latencies: List[float] = []
            costs: List[float] = []
            input_tokens_total = 0
            output_tokens_total = 0
            evaluated = 0
            failed = 0

            for idx, prompt in enumerate(prompts):
                if spending_limit_event.is_set():
                    failed += len(prompts) - evaluated - failed
                    break

                # Skip already-completed evaluations (resume)
                if completed_evals and (idx, model_id) in completed_evals:
                    existing = per_sample_results[idx].model_responses.get(model_id)
                    if existing and existing.cost_usd:
                        costs.append(existing.cost_usd)
                    if existing and existing.latency_ms:
                        latencies.append(existing.latency_ms)
                    if existing:
                        input_tokens_total += existing.input_tokens or 0
                        output_tokens_total += existing.output_tokens or 0
                    evaluated += 1
                    continue

                try:
                    resp = self._call_openrouter(
                        openrouter_key=openrouter_key,
                        provider=provider,
                        model=model,
                        messages=[{"role": "user", "content": prompt}],
                        max_tokens=self._MAX_TOKENS,
                        temperature=self._TEMPERATURE,
                    )

                    latency_ms = resp.get("latency_ms", 0)
                    latencies.append(latency_ms)
                    usage = resp.get("usage", {})
                    in_tok = usage.get("prompt_tokens", 0)
                    out_tok = usage.get("completion_tokens", 0)
                    input_tokens_total += in_tok
                    output_tokens_total += out_tok

                    resolved = MODEL_ALIASES.get(provider, {}).get(model, model)
                    pricing = PRICING.get(provider, {}).get(resolved)
                    if pricing:
                        cost = (
                            in_tok * pricing["input"] / 1_000_000
                            + out_tok * pricing["output"] / 1_000_000
                        )
                    else:
                        cost = 0.0
                    costs.append(cost)
                    evaluated += 1

                    # Track cumulative cost across all models (90% soft cap)
                    if spending_limit > 0:
                        with cumulative_cost_lock:
                            cumulative_cost[0] += cost
                            if cumulative_cost[0] >= spending_limit * 0.90:
                                spending_limit_event.set()
                                logger.warning(
                                    "Client-side spending limit 90%% reached "
                                    "($%.4f of $%.2f)",
                                    cumulative_cost[0], spending_limit,
                                )

                    per_sample_results[idx].model_responses[model_id] = (
                        SampleModelResponse(
                            response_text=resp.get("content", ""),
                            latency_ms=latency_ms,
                            cost_usd=cost,
                            input_tokens=in_tok,
                            output_tokens=out_tok,
                            quality_score=None,
                            judge_reasoning=None,
                            error=None,
                        )
                    )
                    _fire_progress(model_id)

                except BenchmarkError as e:
                    if e.code == "SPENDING_LIMIT":
                        spending_limit_event.set()
                        logger.warning(
                            "Spending limit reached for %s after %d/%d prompts",
                            model_id, evaluated, len(prompts),
                        )
                        failed += len(prompts) - evaluated
                        break
                    logger.warning("Failed to evaluate %s on prompt: %s", model_id, e)
                    failed += 1
                    per_sample_results[idx].model_responses[model_id] = (
                        SampleModelResponse(
                            response_text=None, latency_ms=0, cost_usd=0,
                            input_tokens=0, output_tokens=0,
                            quality_score=None, judge_reasoning=None,
                            error=str(e),
                        )
                    )
                    _fire_progress(model_id)

                except Exception as e:
                    logger.warning("Failed to evaluate %s on prompt: %s", model_id, e)
                    failed += 1
                    per_sample_results[idx].model_responses[model_id] = (
                        SampleModelResponse(
                            response_text=None, latency_ms=0, cost_usd=0,
                            input_tokens=0, output_tokens=0,
                            quality_score=None, judge_reasoning=None,
                            error=str(e),
                        )
                    )
                    _fire_progress(model_id)

            return ModelResult(
                provider=provider,
                model=model,
                model_id=model_id,
                avg_latency_ms=sum(latencies) / len(latencies) if latencies else 0,
                avg_cost_usd=sum(costs) / len(costs) if costs else 0,
                total_cost_usd=sum(costs),
                total_input_tokens=input_tokens_total,
                total_output_tokens=output_tokens_total,
                samples_evaluated=evaluated,
                samples_failed=failed,
            )

        results: List[ModelResult] = []
        total_evaluated = 0
        total_failed = 0

        max_workers = min(len(model_configs), 4)
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_config = {
                executor.submit(_evaluate_model, config): config
                for config in model_configs
            }
            for future in concurrent.futures.as_completed(future_to_config):
                result = future.result()
                results.append(result)
                total_evaluated += result.samples_evaluated
                total_failed += result.samples_failed

        return results, per_sample_results, total_evaluated, total_failed

    # =========================================================================
    # Agentic evaluation via OpenRouter
    # =========================================================================

    def _run_agentic_evaluations(
        self,
        prompts: List[str],
        samples: List[Dict[str, Any]],
        model_configs: List[Dict[str, Any]],
        openrouter_key: str,
        tools: List[ToolDefinition],
        agentic_config: AgenticConfig,
        spending_limit: float,
        on_progress: Optional[Callable[[BenchmarkProgress], None]] = None,
        checkpoint_path: Optional[str] = None,
        benchmark_name: str = "",
        benchmark_id: str = "",
        config_hash: str = "",
        is_agentic: bool = True,
        completed_evals: Optional[set] = None,
        dataset_id: Optional[str] = None,
    ) -> tuple:
        """Run agentic LLM evaluations locally via OpenRouter with tool support.

        Returns:
            (model_results_raw, per_sample_results, total_evaluated, total_failed)
        """
        from modelscout.llm_client import PRICING, MODEL_ALIASES

        spending_limit_event = threading.Event()
        cumulative_cost_lock = threading.Lock()
        cumulative_cost = [0.0]  # Mutable for closure access

        # Thread-safe progress tracking
        progress_total = len(prompts) * len(model_configs)
        progress_completed = [0]
        progress_lock = threading.Lock()
        checkpoint_counter = [0]

        n_already_done = len(completed_evals) if completed_evals else 0
        if n_already_done > 0:
            progress_completed[0] = n_already_done

        tool_schemas = [t.to_openai_schema() for t in tools]
        tool_impls = {t.name: t.implementation for t in tools}
        tool_params_schemas = {t.name: t.parameters for t in tools}

        def _fire_progress(model_id: str) -> None:
            should_checkpoint = False
            if on_progress or checkpoint_path:
                with progress_lock:
                    progress_completed[0] += 1
                    completed = progress_completed[0]
                    checkpoint_counter[0] += 1
                    if checkpoint_path and checkpoint_counter[0] >= self._CHECKPOINT_INTERVAL:
                        checkpoint_counter[0] = 0
                        should_checkpoint = True
            else:
                return
            if on_progress:
                on_progress(BenchmarkProgress(
                    phase="evaluating",
                    completed=completed,
                    total=progress_total,
                    current_model=model_id,
                ))
            if should_checkpoint:
                self._write_checkpoint(
                    checkpoint_path, per_sample_results, benchmark_name,
                    benchmark_id=benchmark_id, config_hash=config_hash,
                    model_configs=model_configs, is_agentic=is_agentic,
                    dataset_id=dataset_id,
                )

        # Pre-allocate per-sample result structures
        all_model_ids = [f"{c['provider']}/{c['model']}" for c in model_configs]

        if completed_evals:
            checkpoint_data_for_restore = None
            if checkpoint_path and os.path.exists(checkpoint_path):
                try:
                    checkpoint_data_for_restore = self.load_checkpoint(checkpoint_path)
                except (json.JSONDecodeError, OSError) as e:
                    logger.warning("Could not load checkpoint %s: %s. Starting fresh.", checkpoint_path, e)
            if checkpoint_data_for_restore:
                per_sample_results = self._restore_per_sample_results(
                    checkpoint_data_for_restore, all_model_ids,
                )
                for sr in per_sample_results:
                    for resp in sr.model_responses.values():
                        if resp is not None and resp.cost_usd:
                            cumulative_cost[0] += resp.cost_usd
            else:
                completed_evals = None
                per_sample_results = []

        if not completed_evals:
            per_sample_results = []
            for i, sample in enumerate(samples):
                per_sample_results.append(SampleResult(
                    sample_index=i,
                    input_text=sample.get("input", prompts[i] if i < len(prompts) else ""),
                    expected_output=sample.get("expected_output"),
                    model_responses={mid: None for mid in all_model_ids},
                ))

        def _execute_tool(
            tool_name: str,
            arguments: Dict[str, Any],
            turn_num: int,
            tool_result_budget: List[int],
        ) -> ToolCallRecord:
            """Execute a single tool call safely with timeout and budget tracking."""
            start = time.time()
            impl = tool_impls.get(tool_name)
            if not impl:
                return ToolCallRecord(
                    tool_name=tool_name,
                    arguments=arguments,
                    error=f"Unknown tool: {tool_name}",
                    duration_ms=(time.time() - start) * 1000,
                    turn=turn_num,
                )

            # Validate LLM-generated arguments against the tool's JSON Schema
            # before passing them to user code.
            schema = tool_params_schemas.get(tool_name)
            if schema:
                validation_error = _validate_tool_arguments(arguments, schema)
                if validation_error:
                    return ToolCallRecord(
                        tool_name=tool_name,
                        arguments=arguments,
                        error=f"Argument validation failed: {validation_error}",
                        duration_ms=(time.time() - start) * 1000,
                        turn=turn_num,
                    )

            try:
                # Execute with timeout using a thread
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(impl, **arguments)
                    result = future.result(timeout=agentic_config._TOOL_TIMEOUT_SECONDS)
                result_str = str(result) if result is not None else ""
                # Apply tool result budget (10K total across all calls per sample)
                budget = tool_result_budget
                if budget[0] <= 0:
                    logger.warning(
                        "Tool '%s' result omitted — context budget exhausted",
                        tool_name,
                    )
                    result_str = (
                        "[ERROR: Tool result omitted because the conversation "
                        "context budget (10,000 chars) has been exceeded. "
                        "Previous tool results consumed the budget. "
                        "This is a system limit, not a tool failure.]"
                    )
                elif len(result_str) > budget[0]:
                    logger.warning(
                        "Tool '%s' result truncated from %d to %d chars (budget remaining)",
                        tool_name, len(result_str), budget[0],
                    )
                    result_str = result_str[:budget[0]] + "... (truncated)"
                    budget[0] = 0
                else:
                    budget[0] -= len(result_str)
                return ToolCallRecord(
                    tool_name=tool_name,
                    arguments=arguments,
                    result=result_str,
                    duration_ms=(time.time() - start) * 1000,
                    turn=turn_num,
                )
            except concurrent.futures.TimeoutError:
                return ToolCallRecord(
                    tool_name=tool_name,
                    arguments=arguments,
                    error=f"Tool execution timed out after {agentic_config._TOOL_TIMEOUT_SECONDS}s",
                    duration_ms=(time.time() - start) * 1000,
                    turn=turn_num,
                )
            except Exception as e:
                logger.warning(
                    "Tool '%s' raised %s: %s",
                    tool_name, type(e).__name__, e, exc_info=True,
                )
                return ToolCallRecord(
                    tool_name=tool_name,
                    arguments=arguments,
                    error=str(e),
                    duration_ms=(time.time() - start) * 1000,
                    turn=turn_num,
                )

        def _run_agentic_sample(
            provider: str,
            model: str,
            sample: Dict[str, Any],
            system_prompt: Optional[str],
        ) -> tuple:
            """Run the agentic loop for a single sample.

            Returns:
                (SampleModelResponse, AgentTrace) or (error_response, None)
            """
            messages: List[Dict[str, Any]] = []
            max_turns = agentic_config._MAX_TURNS
            tool_limit_note = (
                f"You have a maximum of {max_turns} tool-calling turns to complete this task. "
                f"Use tools efficiently and provide your final answer before running out of turns. "
                f"Do not keep searching — synthesize your answer from the results you have."
            )
            if system_prompt:
                messages.append({"role": "system", "content": f"{system_prompt}\n\n{tool_limit_note}"})
            else:
                messages.append({"role": "system", "content": tool_limit_note})
            messages.append({"role": "user", "content": sample.get("input", "")})

            # Tool result budget: 10K chars total across all tool calls for this sample
            tool_result_budget = [AgenticConfig.TOOL_RESULT_BUDGET_CHARS]

            trace_turns: List[AgentTurn] = []
            total_in_tokens = 0
            total_out_tokens = 0
            total_cost = 0.0
            total_latency = 0.0
            total_tool_calls_count = 0
            termination_reason = "final_answer"
            final_output = None

            sample_start = time.time()

            for turn_num in range(1, agentic_config._MAX_TURNS + 1):
                # Check per-sample timeout
                elapsed = time.time() - sample_start
                if elapsed >= agentic_config._TIMEOUT_SECONDS:
                    termination_reason = "timeout"
                    break

                # Check spending limit (90% threshold)
                with cumulative_cost_lock:
                    if cumulative_cost[0] >= spending_limit * 0.90:
                        spending_limit_event.set()
                        termination_reason = "spending_limit"
                        break

                try:
                    resp = self._call_openrouter(
                        openrouter_key=openrouter_key,
                        provider=provider,
                        model=model,
                        messages=messages,
                        max_tokens=agentic_config._MAX_TOKENS_PER_TURN,
                        temperature=self._TEMPERATURE,
                        tools=tool_schemas,
                    )
                except BenchmarkError as e:
                    if e.code == "SPENDING_LIMIT":
                        spending_limit_event.set()
                        termination_reason = "spending_limit"
                        break
                    logger.warning(
                        "Agentic turn %d failed for %s/%s: [%s] %s",
                        turn_num, provider, model, e.code, e,
                    )
                    termination_reason = "error"
                    break

                usage = resp.get("usage", {})
                in_tok = usage.get("prompt_tokens", 0)
                out_tok = usage.get("completion_tokens", 0)
                latency_ms = resp.get("latency_ms", 0)

                pricing = PRICING.get(provider, {}).get(model)
                turn_cost = 0.0
                if pricing:
                    turn_cost = (
                        in_tok * pricing["input"] / 1_000_000
                        + out_tok * pricing["output"] / 1_000_000
                    )

                total_in_tokens += in_tok
                total_out_tokens += out_tok
                total_cost += turn_cost
                total_latency += latency_ms

                # Update cumulative cost for spending tracker
                with cumulative_cost_lock:
                    cumulative_cost[0] += turn_cost

                response_tool_calls = resp.get("tool_calls")
                content = resp.get("content", "")
                raw_message = resp.get("message", {})

                turn_tool_records: List[ToolCallRecord] = []

                if response_tool_calls:
                    # LLM wants to call tools
                    # Add the assistant message with tool calls to conversation
                    assistant_msg: Dict[str, Any] = {"role": "assistant"}
                    if content:
                        assistant_msg["content"] = content
                    assistant_msg["tool_calls"] = response_tool_calls
                    messages.append(assistant_msg)

                    MAX_TOOL_CALLS_PER_TURN = 5
                    for tc in response_tool_calls[:MAX_TOOL_CALLS_PER_TURN]:
                        tc_func = tc.get("function", {})
                        tc_name = tc_func.get("name", "")
                        tc_id = tc.get("id", "")

                        # Parse arguments
                        raw_args = tc_func.get("arguments", "{}")
                        try:
                            tc_args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                        except json.JSONDecodeError:
                            tc_args = {"raw": raw_args}

                        record = _execute_tool(tc_name, tc_args, turn_num, tool_result_budget)
                        turn_tool_records.append(record)
                        total_tool_calls_count += 1

                        # Add tool result to conversation
                        tool_content = record.result if record.result is not None else f"Error: {record.error}"
                        messages.append({
                            "role": "tool",
                            "tool_call_id": tc_id,
                            "content": tool_content,
                        })

                        # Check if we should stop on tool error
                        if record.error and agentic_config.stop_on_tool_error:
                            termination_reason = "error"
                            break

                    turn = AgentTurn(
                        turn_number=turn_num,
                        response_text=content or None,
                        tool_calls=turn_tool_records,
                        input_tokens=in_tok,
                        output_tokens=out_tok,
                        cost_usd=turn_cost,
                        latency_ms=latency_ms,
                        is_final=False,
                    )
                    trace_turns.append(turn)

                    if termination_reason == "error":
                        break

                else:
                    # No tool calls — this is the final answer
                    final_output = content
                    turn = AgentTurn(
                        turn_number=turn_num,
                        response_text=content,
                        tool_calls=[],
                        input_tokens=in_tok,
                        output_tokens=out_tok,
                        cost_usd=turn_cost,
                        latency_ms=latency_ms,
                        is_final=True,
                    )
                    trace_turns.append(turn)
                    termination_reason = "final_answer"
                    break
            else:
                # max_turns exhausted — model kept calling tools without a final answer.
                # Force a synthesis turn: call the model WITHOUT tools so it must produce text.
                termination_reason = "max_turns"
                if not final_output:
                    try:
                        synthesis_prompt = {
                            "role": "user",
                            "content": "Based on the tool results above, provide your final answer now. Do not call any more tools.",
                        }
                        synth_resp = self._call_openrouter(
                            openrouter_key=openrouter_key,
                            provider=provider,
                            model=model,
                            messages=messages + [synthesis_prompt],
                            max_tokens=agentic_config._MAX_TOKENS_PER_TURN,
                            temperature=self._TEMPERATURE,
                            # No tools parameter — forces text response
                        )
                        synth_content = synth_resp.get("content", "")
                        if synth_content and synth_content.strip():
                            final_output = synth_content
                            termination_reason = "max_turns_synthesized"
                    except Exception:
                        pass  # Fall through to existing fallback
                # Fallback: use last content as final output if available
                if not final_output and trace_turns and trace_turns[-1].response_text:
                    final_output = trace_turns[-1].response_text

            trace = AgentTrace(
                turns=trace_turns,
                final_output=final_output,
                total_turns=len(trace_turns),
                total_tool_calls=total_tool_calls_count,
                total_input_tokens=total_in_tokens,
                total_output_tokens=total_out_tokens,
                total_cost_usd=total_cost,
                total_latency_ms=total_latency,
                termination_reason=termination_reason,
            )

            response = SampleModelResponse(
                response_text=final_output,
                latency_ms=total_latency,
                cost_usd=total_cost,
                input_tokens=total_in_tokens,
                output_tokens=total_out_tokens,
                quality_score=None,
                judge_reasoning=None,
                error=None if final_output else f"No final output (terminated: {termination_reason})",
                agent_trace=trace,
            )

            return response, trace

        def _evaluate_model_agentic(config: Dict[str, Any]) -> ModelResult:
            provider = config["provider"]
            model = config["model"]
            model_id = f"{provider}/{model}"
            system_prompt = config.get("system_prompt")

            if spending_limit_event.is_set():
                return ModelResult(
                    provider=provider, model=model, model_id=model_id,
                    samples_failed=len(prompts),
                )

            latencies: List[float] = []
            costs: List[float] = []
            input_tokens_total = 0
            output_tokens_total = 0
            evaluated = 0
            failed = 0

            for idx, sample in enumerate(samples):
                if spending_limit_event.is_set():
                    failed += len(samples) - evaluated - failed
                    break

                # Skip already-completed evaluations (resume)
                if completed_evals and (idx, model_id) in completed_evals:
                    existing = per_sample_results[idx].model_responses.get(model_id)
                    if existing and existing.cost_usd:
                        costs.append(existing.cost_usd)
                    if existing and existing.latency_ms:
                        latencies.append(existing.latency_ms)
                    if existing:
                        input_tokens_total += existing.input_tokens or 0
                        output_tokens_total += existing.output_tokens or 0
                    evaluated += 1
                    continue

                try:
                    response, trace = _run_agentic_sample(
                        provider=provider,
                        model=model,
                        sample=sample,
                        system_prompt=system_prompt,
                    )

                    if response.error:
                        failed += 1
                    else:
                        evaluated += 1
                        latencies.append(response.latency_ms)
                        costs.append(response.cost_usd)
                        input_tokens_total += response.input_tokens
                        output_tokens_total += response.output_tokens

                    per_sample_results[idx].model_responses[model_id] = response
                    _fire_progress(model_id)

                except Exception as e:
                    logger.warning("Failed agentic evaluation %s on sample %d: %s", model_id, idx, e)
                    failed += 1
                    per_sample_results[idx].model_responses[model_id] = SampleModelResponse(
                        response_text=None, latency_ms=0, cost_usd=0,
                        input_tokens=0, output_tokens=0,
                        quality_score=None, judge_reasoning=None,
                        error=str(e),
                    )
                    _fire_progress(model_id)

            return ModelResult(
                provider=provider,
                model=model,
                model_id=model_id,
                avg_latency_ms=sum(latencies) / len(latencies) if latencies else 0,
                avg_cost_usd=sum(costs) / len(costs) if costs else 0,
                total_cost_usd=sum(costs),
                total_input_tokens=input_tokens_total,
                total_output_tokens=output_tokens_total,
                samples_evaluated=evaluated,
                samples_failed=failed,
            )

        results: List[ModelResult] = []
        total_evaluated = 0
        total_failed = 0

        # Lower parallelism for agentic benchmarks (more tokens per sample)
        max_workers = min(len(model_configs), 2)
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_config = {
                executor.submit(_evaluate_model_agentic, config): config
                for config in model_configs
            }
            for future in concurrent.futures.as_completed(future_to_config):
                result = future.result()
                results.append(result)
                total_evaluated += result.samples_evaluated
                total_failed += result.samples_failed

        return results, per_sample_results, total_evaluated, total_failed

    def _call_openrouter(
        self,
        openrouter_key: str,
        provider: str,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: int,
        temperature: float,
        max_retries: int = 2,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Call an LLM through OpenRouter.

        Retries on transient errors (5xx, timeouts) with exponential backoff.

        When tools is provided, the response may contain tool_calls instead of
        (or alongside) text content. The raw message is returned under "message".
        """
        # Check key expiry before making the call
        if getattr(self, "_key_expires_at", None):
            remaining = (self._key_expires_at - datetime.now(timezone.utc)).total_seconds()
            if remaining < 300:  # <5 minutes remaining
                raise BenchmarkError(
                    "OpenRouter API key is expiring soon (<%d seconds remaining). "
                    "Run with resume=True to continue with a fresh key." % max(int(remaining), 0),
                    code="KEY_EXPIRED",
                )

        openrouter_model = f"{provider}/{model}"

        payload: Dict[str, Any] = {
            "model": openrouter_model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        # Reasoning models: use minimal reasoning effort for fastest responses.
        # "minimal" allocates ~10% of tokens to reasoning (vs "low" at 20%).
        # This dramatically reduces TTFT for reasoning models like GPT-5 Nano.
        if openrouter_model in REASONING_MODELS:
            payload["reasoning_effort"] = "minimal"

        if tools:
            payload["tools"] = tools

        data = json.dumps(payload).encode()
        last_error: Optional[Exception] = None

        for attempt in range(1 + max_retries):
            start_time = time.time()

            req = urllib.request.Request(
                f"{OPENROUTER_BASE_URL}/chat/completions",
                data=data,
                headers={
                    "Authorization": f"Bearer {openrouter_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://modelscout.co",
                    "X-Title": "ModelScout Benchmark",
                },
                method="POST",
            )

            try:
                with urllib.request.urlopen(req, timeout=120) as response:
                    raw_body = response.read().decode()
                try:
                    result = json.loads(raw_body)
                except json.JSONDecodeError as je:
                    raise BenchmarkError(
                        f"OpenRouter returned invalid JSON: {raw_body[:200]}",
                        code="OPENROUTER_ERROR",
                    ) from je
            except BenchmarkError:
                raise
            except urllib.error.HTTPError as e:
                error_body = e.read().decode() if e.fp else ""
                if e.code == 402:
                    raise BenchmarkError(
                        "There was an issue with the LLM provider or potential abuse was detected. "
                        "Please contact support at hello@modelscout.co",
                        code="SPENDING_LIMIT",
                        status_code=402,
                    )
                # Retry on 429 rate limit
                if e.code == 429 and attempt < max_retries:
                    retry_after = int(e.headers.get("Retry-After", 2 ** attempt)) if e.headers else 2 ** attempt
                    last_error = e
                    time.sleep(min(retry_after, 30))
                    continue
                if e.code == 429:
                    raise BenchmarkError(
                        "Rate limited by LLM provider. Try again shortly.",
                        code="OPENROUTER_ERROR",
                        status_code=429,
                    )
                # Retry on 5xx server errors
                if e.code >= 500 and attempt < max_retries:
                    last_error = e
                    time.sleep(2 ** attempt)
                    continue
                raise BenchmarkError(
                    _sanitize_error_msg(
                        f"OpenRouter API error ({e.code}): {error_body}"
                    ),
                    code="OPENROUTER_ERROR",
                    status_code=e.code,
                )
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                # Retry on connection/timeout errors
                if attempt < max_retries:
                    last_error = e
                    time.sleep(2 ** attempt)
                    continue
                raise BenchmarkError(
                    _sanitize_error_msg(f"OpenRouter connection error: {e}"),
                    code="OPENROUTER_ERROR",
                ) from e

            # Check for error responses wrapped in HTTP 200
            if "error" in result:
                err = result["error"]
                err_msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
                raise BenchmarkError(
                    f"OpenRouter error: {err_msg}",
                    code="OPENROUTER_ERROR",
                )

            latency_ms = (time.time() - start_time) * 1000

            message = result.get("choices", [{}])[0].get("message", {})
            return {
                "content": message.get("content", ""),
                "message": message,  # Raw message (may contain tool_calls)
                "tool_calls": message.get("tool_calls"),  # None if no tool calls
                "usage": result.get("usage", {}),
                "latency_ms": latency_ms,
                "model": result.get("model", openrouter_model),
            }

        # Should not reach here, but just in case
        raise BenchmarkError(
            f"OpenRouter call failed after {max_retries + 1} attempts: {last_error}",
            code="OPENROUTER_ERROR",
        )

    # =========================================================================
    # Embedding
    # =========================================================================

    def _embed_prompts(self, samples: List[Dict[str, Any]]) -> List[List[float]]:
        """Embed all sample prompts locally using BGE-small."""
        try:
            from modelscout.local_embeddings import LocalEmbedder
            embedder = LocalEmbedder("bge-small-en-v1.5")
            prompts = [s.get("input", "") for s in samples]
            return embedder.embed_batch(prompts)
        except Exception as e:
            logger.warning(f"Embedding failed (training will not be available): {e}")
            return []

    # =========================================================================
    # Judge evaluation
    # =========================================================================

    @staticmethod
    def _format_tool_trace_for_judge(
        trace: AgentTrace,
        tools: List[ToolDefinition],
    ) -> str:
        """Format an agent trace as readable text for the judge prompt."""
        lines = []

        # List available tools
        tool_names = ", ".join(f"{t.name} ({t.description})" for t in tools)
        lines.append(f"Available tools: {tool_names}")
        lines.append("")
        lines.append("Execution trace:")

        for turn in trace.turns:
            if turn.tool_calls:
                for tc in turn.tool_calls:
                    args_str = ", ".join(f'{k}="{v}"' for k, v in tc.arguments.items())
                    if tc.error:
                        lines.append(
                            f"Turn {turn.turn_number}: LLM called {tc.tool_name}({args_str}) "
                            f"→ ERROR: {tc.error}"
                        )
                    else:
                        result_preview = (tc.result or "")[:200]
                        lines.append(
                            f"Turn {turn.turn_number}: LLM called {tc.tool_name}({args_str}) "
                            f'→ "{result_preview}"'
                        )
            if turn.is_final and turn.response_text:
                lines.append(f"Turn {turn.turn_number}: LLM produced final answer")

        lines.append("")
        lines.append(f"Termination: {trace.termination_reason}")
        lines.append(f"Total turns: {trace.total_turns}, Total tool calls: {trace.total_tool_calls}")

        return "\n".join(lines)

    def _run_judge_evaluation(
        self,
        per_sample_results: List[SampleResult],
        model_configs: List[Dict[str, Any]],
        openrouter_key: str,
        provision_data: Dict[str, Any],
        tools: Optional[List[ToolDefinition]] = None,
    ) -> None:
        """Run judge evaluation using the provisioned OpenRouter key."""
        from modelscout_core.judge import JudgeCore

        judge_tasks = []
        for sample_result in per_sample_results:
            for model_id, response in sample_result.model_responses.items():
                if not response or response.error or not response.response_text:
                    continue
                judge_tasks.append((sample_result, model_id, response))

        if not judge_tasks:
            logger.warning("No successful responses to judge")
            return

        judge_model = provision_data.get("judge_model", "google/gemini-3.1-pro")
        is_free_tier = provision_data.get("is_free_tier", False)

        judge = JudgeCore(
            openrouter_key=openrouter_key,
            judge_model=judge_model,
            is_free_tier=is_free_tier,
        )

        judge_samples = []
        for sample_result, model_id, response in judge_tasks:
            sample_data: Dict[str, Any] = {
                "input": sample_result.input_text,
                "expected_output": sample_result.expected_output,
                "response_text": response.response_text,
                "sample_index": sample_result.sample_index,
                "model_id": model_id,
            }
            # For agentic benchmarks, include tool trace context
            if tools and response.agent_trace:
                tool_trace_text = self._format_tool_trace_for_judge(
                    response.agent_trace, tools,
                )
                sample_data["tool_trace"] = tool_trace_text
            judge_samples.append(sample_data)

        logger.info(f"Running {len(judge_samples)} judge evaluations...")
        judged_results = judge.judge_all(
            samples=judge_samples,
            system_prompt=None,
            rubric="agentic" if tools else None,
            max_workers=5,
        )

        for (sample_result, model_id, response), judge_result in zip(
            judge_tasks, judged_results
        ):
            if judge_result.get("score") is not None:
                response.quality_score = judge_result["score"]
                response.judge_reasoning = judge_result.get("reasoning")
                response.answer_relevancy = judge_result.get("answer_relevancy")
                response.coherence = judge_result.get("coherence")
                response.hallucination = judge_result.get("hallucination")

    # =========================================================================
    # Metrics aggregation
    # =========================================================================

    def _aggregate_metrics(
        self,
        per_sample_results: List[SampleResult],
        model_configs: List[Dict[str, Any]],
        tools: Optional[List[ToolDefinition]] = None,
    ) -> tuple:
        """Aggregate per-sample results into per-model metrics."""
        import numpy as np

        model_results = []
        quality_scores: Dict[str, List[float]] = {}
        costs_dict: Dict[str, List[float]] = {}
        latencies_dict: Dict[str, List[float]] = {}
        num_tools_available = len(tools) if tools else 0

        for config in model_configs:
            mid = f"{config['provider']}/{config['model']}"
            scores = []
            latencies = []
            model_costs = []
            successes = 0
            failures = 0
            total_input = 0
            total_output = 0

            # Judge sub-score accumulators
            relevancy_scores: List[float] = []
            coherence_scores: List[float] = []
            hallucination_scores: List[float] = []

            # Tool metrics accumulators
            tool_call_counts: List[float] = []
            turns_to_completion: List[float] = []
            tool_error_counts: List[float] = []
            tool_total_counts: List[float] = []
            tool_diversity_ratios: List[float] = []
            tokens_per_turn: List[float] = []
            tool_latencies: List[float] = []

            for sample in per_sample_results:
                resp = sample.model_responses.get(mid)
                if not resp:
                    continue

                if resp.error:
                    failures += 1
                else:
                    successes += 1
                    scores.append(float(resp.quality_score) if resp.quality_score else 0.0)
                    model_costs.append(resp.cost_usd)
                    latencies.append(resp.latency_ms)
                    total_input += resp.input_tokens
                    total_output += resp.output_tokens

                    # Collect judge sub-scores
                    if resp.answer_relevancy is not None:
                        relevancy_scores.append(float(resp.answer_relevancy))
                    if resp.coherence is not None:
                        coherence_scores.append(float(resp.coherence))
                    if resp.hallucination is not None:
                        hallucination_scores.append(float(resp.hallucination))

                    # Collect tool metrics from agent trace
                    if resp.agent_trace:
                        trace = resp.agent_trace
                        tool_call_counts.append(float(trace.total_tool_calls))
                        turns_to_completion.append(float(trace.total_turns))

                        # Tool error rate components
                        errors = sum(
                            1 for turn in trace.turns
                            for tc in turn.tool_calls if tc.error
                        )
                        total_calls = trace.total_tool_calls
                        tool_error_counts.append(float(errors))
                        tool_total_counts.append(float(total_calls))

                        # Tool diversity
                        unique_tools = set(
                            tc.tool_name for turn in trace.turns
                            for tc in turn.tool_calls
                        )
                        if num_tools_available > 0:
                            tool_diversity_ratios.append(
                                len(unique_tools) / num_tools_available
                            )

                        # Tokens per turn
                        if trace.total_turns > 0:
                            total_tok = trace.total_input_tokens + trace.total_output_tokens
                            tokens_per_turn.append(total_tok / trace.total_turns)

                        # Tool execution latencies
                        for turn in trace.turns:
                            for tc in turn.tool_calls:
                                if tc.duration_ms > 0:
                                    tool_latencies.append(tc.duration_ms)

            quality_scores[mid] = scores
            costs_dict[mid] = model_costs
            latencies_dict[mid] = latencies

            valid_scores = [s for s in scores if s > 0]
            valid_latencies = [l for l in latencies if l > 0]
            valid_costs = [c for c in model_costs if c > 0]

            # Build extra metrics
            extra_metrics: List[ExtraMetricStat] = []

            # Reference metrics (BLEU, ROUGE, semantic similarity) when expected output available
            ref_metrics = self._compute_reference_metrics(
                per_sample_results=per_sample_results,
                model_id=mid,
                np=np,
            )
            extra_metrics.extend(ref_metrics)

            # Judge sub-scores (answer relevancy, coherence, hallucination)
            for sub_name, sub_display, sub_vals in [
                ("answer_relevancy", "Answer Relevancy", relevancy_scores),
                ("coherence", "Coherence", coherence_scores),
                ("hallucination", "Hallucination Resistance", hallucination_scores),
            ]:
                if sub_vals:
                    extra_metrics.append(ExtraMetricStat(
                        name=sub_name,
                        display_name=sub_display,
                        unit="score",
                        mean=float(np.mean(sub_vals)),
                        median=float(np.median(sub_vals)),
                        std=float(np.std(sub_vals)) if len(sub_vals) > 1 else 0.0,
                        min=float(np.min(sub_vals)),
                        max=float(np.max(sub_vals)),
                    ))

            if tool_call_counts:  # Only add tool metrics for agentic benchmarks
                extra_metrics.extend(self._compute_tool_metrics(
                    tool_call_counts=tool_call_counts,
                    turns_to_completion=turns_to_completion,
                    tool_error_counts=tool_error_counts,
                    tool_total_counts=tool_total_counts,
                    tool_diversity_ratios=tool_diversity_ratios,
                    tokens_per_turn=tokens_per_turn,
                    tool_latencies=tool_latencies,
                    per_sample_results=per_sample_results,
                    model_id=mid,
                    np=np,
                ))

            model_results.append(ModelResult(
                provider=config["provider"],
                model=config["model"],
                model_id=mid,
                avg_quality_score=float(np.mean(valid_scores)) if valid_scores else None,
                avg_latency_ms=float(np.mean(valid_latencies)) if valid_latencies else 0.0,
                avg_cost_usd=float(np.mean(valid_costs)) if valid_costs else 0.0,
                total_cost_usd=float(sum(model_costs)),
                total_input_tokens=total_input,
                total_output_tokens=total_output,
                samples_evaluated=successes,
                samples_failed=failures,
                extra_metrics=extra_metrics,
            ))

        return model_results, quality_scores, costs_dict, latencies_dict

    @staticmethod
    def _compute_reference_metrics(
        per_sample_results: list,
        model_id: str,
        np,
    ) -> List[ExtraMetricStat]:
        """Compute BLEU, ROUGE, and semantic similarity for samples with expected output.

        These are only computed when the dataset includes expected_output.
        All calculations are local (no LLM calls).
        """
        import statistics as _stats

        predictions = []
        references = []

        for sample in per_sample_results:
            if not sample.expected_output:
                continue
            resp = sample.model_responses.get(model_id)
            if not resp or resp.error or not resp.response_text:
                continue
            predictions.append(resp.response_text.strip())
            references.append(sample.expected_output.strip())

        if not predictions:
            return []

        metrics: List[ExtraMetricStat] = []

        # BLEU (sacrebleu)
        try:
            import sacrebleu
            bleu_scores = []
            for pred, ref in zip(predictions, references):
                score = sacrebleu.sentence_bleu(pred, [ref])
                bleu_scores.append(score.score)
            if bleu_scores:
                metrics.append(ExtraMetricStat(
                    name="bleu",
                    display_name="BLEU Score",
                    unit="score",
                    group_id="text_similarity",
                    mean=float(np.mean(bleu_scores)),
                    median=float(np.median(bleu_scores)),
                    std=float(np.std(bleu_scores)) if len(bleu_scores) > 1 else 0.0,
                    min=float(np.min(bleu_scores)),
                    max=float(np.max(bleu_scores)),
                ))
        except ImportError:
            pass  # sacrebleu not installed

        # ROUGE (rouge-score)
        try:
            from rouge_score import rouge_scorer
            scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)
            rouge_scores = []
            for pred, ref in zip(predictions, references):
                result = scorer.score(ref, pred)
                rouge_scores.append(result["rougeL"].fmeasure)
            if rouge_scores:
                metrics.append(ExtraMetricStat(
                    name="rouge",
                    display_name="ROUGE-L",
                    unit="score",
                    group_id="text_similarity",
                    mean=float(np.mean(rouge_scores)),
                    median=float(np.median(rouge_scores)),
                    std=float(np.std(rouge_scores)) if len(rouge_scores) > 1 else 0.0,
                    min=float(np.min(rouge_scores)),
                    max=float(np.max(rouge_scores)),
                ))
        except ImportError:
            pass  # rouge-score not installed

        # Semantic Similarity (sentence-transformers via local embeddings)
        try:
            from modelscout.local_embeddings import get_default_embedder
            embedder = get_default_embedder()
            pred_embs = np.array([embedder.embed(t) for t in predictions])
            ref_embs = np.array([embedder.embed(t) for t in references])
            if pred_embs is not None and ref_embs is not None:
                # Cosine similarity per pair
                sim_scores = []
                for p_emb, r_emb in zip(pred_embs, ref_embs):
                    p_norm = p_emb / (np.linalg.norm(p_emb) + 1e-8)
                    r_norm = r_emb / (np.linalg.norm(r_emb) + 1e-8)
                    sim = float(np.dot(p_norm, r_norm))
                    sim_scores.append(max(0.0, min(1.0, sim)))
                if sim_scores:
                    metrics.append(ExtraMetricStat(
                        name="semantic_similarity",
                        display_name="Semantic Similarity",
                        unit="score",
                        group_id="text_similarity",
                        mean=float(np.mean(sim_scores)),
                        median=float(np.median(sim_scores)),
                        std=float(np.std(sim_scores)) if len(sim_scores) > 1 else 0.0,
                        min=float(np.min(sim_scores)),
                        max=float(np.max(sim_scores)),
                    ))
        except (ImportError, RuntimeError, OSError) as e:
            logger.debug("Semantic similarity unavailable: %s", e)

        return metrics

    @staticmethod
    def _compute_tool_metrics(
        tool_call_counts: List[float],
        turns_to_completion: List[float],
        tool_error_counts: List[float],
        tool_total_counts: List[float],
        tool_diversity_ratios: List[float],
        tokens_per_turn: List[float],
        tool_latencies: List[float],
        per_sample_results: List[SampleResult],
        model_id: str,
        np: Any,
    ) -> List[ExtraMetricStat]:
        """Compute tool usage metrics from agentic traces."""
        metrics: List[ExtraMetricStat] = []

        def _stat(values: List[float]) -> tuple:
            if not values:
                return 0.0, 0.0, 0.0, 0.0, 0.0
            arr = np.array(values)
            return (
                float(np.mean(arr)),
                float(np.median(arr)),
                float(np.std(arr)),
                float(np.min(arr)),
                float(np.max(arr)),
            )

        # Observational metrics
        mean, med, std, mn, mx = _stat(tool_call_counts)
        metrics.append(ExtraMetricStat(
            name="tool_call_count", display_name="Tool Calls",
            unit="count", group_id="tool_usage",
            mean=mean, median=med, std=std, min=mn, max=mx,
        ))

        mean, med, std, mn, mx = _stat(turns_to_completion)
        metrics.append(ExtraMetricStat(
            name="turns_to_completion", display_name="Turns to Completion",
            unit="count", group_id="tool_usage",
            mean=mean, median=med, std=std, min=mn, max=mx,
        ))

        # Tool error rate
        total_errors = sum(tool_error_counts)
        total_calls = sum(tool_total_counts)
        error_rate = total_errors / total_calls if total_calls > 0 else 0.0
        metrics.append(ExtraMetricStat(
            name="tool_error_rate", display_name="Tool Error Rate",
            unit="percentage", group_id="tool_usage",
            mean=error_rate, median=error_rate, std=0.0,
            min=error_rate, max=error_rate,
        ))

        if tool_diversity_ratios:
            mean, med, std, mn, mx = _stat(tool_diversity_ratios)
            metrics.append(ExtraMetricStat(
                name="tool_diversity", display_name="Tool Diversity",
                unit="percentage", group_id="tool_usage",
                mean=mean, median=med, std=std, min=mn, max=mx,
            ))

        if tokens_per_turn:
            mean, med, std, mn, mx = _stat(tokens_per_turn)
            metrics.append(ExtraMetricStat(
                name="avg_tokens_per_turn", display_name="Avg Tokens/Turn",
                unit="count", group_id="tool_usage",
                mean=mean, median=med, std=std, min=mn, max=mx,
            ))

        if tool_latencies:
            mean, med, std, mn, mx = _stat(tool_latencies)
            metrics.append(ExtraMetricStat(
                name="avg_tool_latency_ms", display_name="Avg Tool Latency",
                unit="ms", group_id="tool_usage",
                mean=mean, median=med, std=std, min=mn, max=mx,
            ))

        # Expected-value metrics (when dataset provides expected_tools)
        precision_values: List[float] = []
        recall_values: List[float] = []

        for sample in per_sample_results:
            resp = sample.model_responses.get(model_id)
            if not resp or resp.error or not resp.agent_trace:
                continue

            expected_tools = None
            # Check if the original sample has expected_tools metadata
            if hasattr(sample, 'expected_output') and sample.expected_output:
                pass  # expected_output is just text, not tool info

            # expected_tools come from sample metadata (set during dataset load)
            metadata = getattr(sample, '_metadata', None)
            if metadata and isinstance(metadata, dict):
                expected_tools = metadata.get("expected_tools")

            if not expected_tools:
                continue

            # Compute precision and recall
            actual_tools = [
                tc.tool_name for turn in resp.agent_trace.turns
                for tc in turn.tool_calls
            ]
            actual_set = set(actual_tools)
            expected_set = set(expected_tools)

            if actual_tools:
                precision = len(actual_set & expected_set) / len(actual_set)
                precision_values.append(precision)
            if expected_tools:
                recall = len(actual_set & expected_set) / len(expected_set)
                recall_values.append(recall)

        if precision_values:
            mean, med, std, mn, mx = _stat(precision_values)
            metrics.append(ExtraMetricStat(
                name="tool_call_precision", display_name="Tool Call Precision",
                unit="percentage", group_id="tool_usage",
                mean=mean, median=med, std=std, min=mn, max=mx,
            ))

        if recall_values:
            mean, med, std, mn, mx = _stat(recall_values)
            metrics.append(ExtraMetricStat(
                name="tool_call_recall", display_name="Tool Call Recall",
                unit="percentage", group_id="tool_usage",
                mean=mean, median=med, std=std, min=mn, max=mx,
            ))

        return metrics

    def _generate_recommendations(
        self,
        model_results: List[ModelResult],
    ) -> tuple:
        """Generate best-of recommendations."""
        quality_models = [m for m in model_results if m.avg_quality_score is not None]
        best_quality = None
        if quality_models:
            best = max(quality_models, key=lambda m: m.avg_quality_score or 0)
            best_quality = ModelRecommendation(
                provider=best.provider, model=best.model,
                model_id=best.model_id, score=best.avg_quality_score or 0,
            )

        best_value = None
        value_models = [
            m for m in model_results
            if m.avg_quality_score and m.avg_cost_usd and m.avg_cost_usd > 0
        ]
        if value_models:
            best = max(value_models, key=lambda m: (m.avg_quality_score or 0) / m.avg_cost_usd)
            best_value = ModelRecommendation(
                provider=best.provider, model=best.model,
                model_id=best.model_id,
                score=(best.avg_quality_score or 0) / best.avg_cost_usd,
            )

        speed_models = [m for m in model_results if m.avg_latency_ms > 0]
        best_speed = None
        if speed_models:
            best = min(speed_models, key=lambda m: m.avg_latency_ms)
            best_speed = ModelRecommendation(
                provider=best.provider, model=best.model,
                model_id=best.model_id, score=best.avg_latency_ms,
            )

        return best_quality, best_value, best_speed

    # =========================================================================
    # Result submission
    # =========================================================================

    def _submit_results(
        self,
        benchmark_id: str,
        per_sample_results: List[SampleResult],
        total_evaluated: int,
        total_failed: int,
        execution_seconds: float,
        judge_model: str = "google/gemini-3.1-pro",
        is_agentic: bool = False,
        agentic_config: Optional[AgenticConfig] = None,
    ) -> None:
        """Submit per-sample results to the backend.

        The backend stores per-sample data and calls finalize_benchmark()
        for full parity with remote benchmarks.
        """
        # Parse judge_model into provider/model
        judge_parts = judge_model.split("/", 1)
        judge_provider = judge_parts[0] if len(judge_parts) > 1 else "unknown"
        judge_model_name = judge_parts[1] if len(judge_parts) > 1 else judge_model

        samples_payload = []
        truncated_count = 0
        for sr in per_sample_results:
            model_responses = {}
            for mid, resp in sr.model_responses.items():
                if not resp:
                    continue
                response_text = resp.response_text or ""
                if len(response_text) > 2000:
                    truncated_count += 1
                resp_data: Dict[str, Any] = {
                    "response_text": response_text[:2000],
                    "latency_ms": resp.latency_ms,
                    "cost_usd": resp.cost_usd,
                    "input_tokens": resp.input_tokens,
                    "output_tokens": resp.output_tokens,
                    "quality_score": resp.quality_score,
                    "judge_reasoning": resp.judge_reasoning,
                    "error": resp.error,
                }
                # Include judge scores with actual judge model info
                if resp.quality_score is not None:
                    resp_data["judge_scores"] = [{
                        "judge_provider": judge_provider,
                        "judge_model": judge_model_name,
                        "score": resp.quality_score,
                        "reasoning": resp.judge_reasoning or "",
                        "answer_relevancy": resp.answer_relevancy,
                        "coherence": resp.coherence,
                        "hallucination": resp.hallucination,
                    }]
                if resp.agent_trace:
                    resp_data["agent_trace"] = resp.agent_trace.to_dict()
                model_responses[mid] = resp_data
            samples_payload.append({
                "input": sr.input_text[:2000],
                "expected_output": (sr.expected_output or "")[:2000] or None,
                "model_responses": model_responses,
            })

        if truncated_count > 0:
            logger.warning(
                "%d response(s) truncated from >2000 chars for dashboard upload. "
                "Use save_local=True to preserve full responses.",
                truncated_count,
            )

        body: Dict[str, Any] = {
            "per_sample": samples_payload,
            "total_samples_evaluated": total_evaluated,
            "total_samples_failed": total_failed,
            "execution_duration_seconds": execution_seconds,
            "sdk_version": self._get_sdk_version(),
            "is_agentic": is_agentic,
        }

        if is_agentic and agentic_config:
            body["tool_definitions"] = [
                {"name": t.name, "description": t.description, "parameters": t.parameters}
                for t in agentic_config.tools
            ]

        self._api_request("POST", f"/api/v1/benchmarks/{benchmark_id}/sdk-results", body=body)

    def _notify_failure(self, benchmark_id: str) -> None:
        """Tell the backend to cancel a failed SDK benchmark (revokes OpenRouter key)."""
        try:
            self._api_request("POST", f"/api/v1/benchmarks/{benchmark_id}/cancel")
        except Exception as e:
            logger.warning("Failed to notify backend of benchmark failure: %s", e)

    # =========================================================================
    # Upload
    # =========================================================================

    def _upload_results(
        self,
        result: BenchmarkResult,
        include_samples: bool,
        system_prompt: Optional[str],
    ) -> str:
        """Upload aggregate results to backend dashboard."""
        import statistics as _stats

        models_payload = []
        for m in result.models:
            # Compute latency percentiles and quality std from per-sample data
            latencies: List[float] = []
            quality_scores: List[float] = []
            for sr in result.per_sample:
                resp = sr.model_responses.get(m.model_id)
                if resp and not resp.error:
                    if resp.latency_ms > 0:
                        latencies.append(resp.latency_ms)
                    if resp.quality_score is not None:
                        quality_scores.append(float(resp.quality_score))

            sorted_lat = sorted(latencies)
            n = len(sorted_lat)

            payload: Dict[str, Any] = {
                "provider": m.provider,
                "model": m.model,
                "avg_quality_score": m.avg_quality_score,
                "avg_latency_ms": m.avg_latency_ms,
                "total_cost_usd": m.total_cost_usd,
                "samples_evaluated": m.samples_evaluated,
                "samples_failed": m.samples_failed,
                "total_input_tokens": m.total_input_tokens,
                "total_output_tokens": m.total_output_tokens,
                "avg_cost_per_request": m.avg_cost_usd,
                "p50_latency_ms": sorted_lat[int(n * 0.5)] if n > 0 else None,
                "p95_latency_ms": sorted_lat[min(int(n * 0.95), n - 1)] if n > 0 else None,
                "p99_latency_ms": sorted_lat[min(int(n * 0.99), n - 1)] if n > 0 else None,
                "quality_score_std": (
                    _stats.stdev(quality_scores) if len(quality_scores) > 1 else None
                ),
            }
            if m.extra_metrics:
                payload["extra_metrics"] = [em.to_dict() for em in m.extra_metrics]
            models_payload.append(payload)

        recommendations = {}
        if result.best_quality:
            recommendations["best_quality"] = {
                "provider": result.best_quality.provider,
                "model": result.best_quality.model,
                "score": result.best_quality.score,
            }
        if result.best_value:
            recommendations["best_value"] = {
                "provider": result.best_value.provider,
                "model": result.best_value.model,
                "score": result.best_value.score,
            }
        if result.best_speed:
            recommendations["best_speed"] = {
                "provider": result.best_speed.provider,
                "model": result.best_speed.model,
                "score": result.best_speed.score,
            }

        body: Dict[str, Any] = {
            "name": result.name,
            "models": models_payload,
            "recommendations": recommendations,
            "config": {
                "sample_count": len(result.per_sample),
                "model_count": len(result.models),
                "judge_model": "google/gemini-3.1-pro",
                "system_prompt_hash": (
                    hashlib.sha256(system_prompt.encode()).hexdigest()[:16]
                    if system_prompt else None
                ),
            },
        }

        if include_samples:
            samples_payload = []
            for sr in result.per_sample:
                model_responses = {}
                for mid, resp in sr.model_responses.items():
                    if not resp:
                        continue
                    resp_data: Dict[str, Any] = {
                        "response_text": (resp.response_text or "")[:2000],
                        "quality_score": resp.quality_score,
                        "latency_ms": resp.latency_ms,
                        "cost_usd": resp.cost_usd,
                        "input_tokens": resp.input_tokens,
                        "output_tokens": resp.output_tokens,
                    }
                    if resp.agent_trace:
                        resp_data["agent_trace"] = resp.agent_trace.to_dict()
                    model_responses[mid] = resp_data
                samples_payload.append({
                    "input": sr.input_text[:200],
                    "expected_output": (sr.expected_output or "")[:2000],
                    "model_responses": model_responses,
                })
            body["samples"] = samples_payload

        resp = self._api_request("POST", "/api/v1/benchmarks/upload-local", body)
        data = resp.get("data", resp)
        return data.get("id", data.get("benchmark_id", ""))

    # =========================================================================
    # Local save
    # =========================================================================

    def _save_local(self, result: BenchmarkResult, path: str) -> None:
        """Save full untruncated results to a local JSON file."""
        data = {
            "benchmark_id": result.benchmark_id,
            "name": result.name,
            "status": result.status,
            "created_at": result.created_at,
            "models": [
                {
                    "model_id": m.model_id,
                    "provider": m.provider,
                    "model": m.model,
                    "avg_quality_score": m.avg_quality_score,
                    "avg_latency_ms": m.avg_latency_ms,
                    "avg_cost_usd": m.avg_cost_usd,
                    "total_cost_usd": m.total_cost_usd,
                    "samples_evaluated": m.samples_evaluated,
                    "samples_failed": m.samples_failed,
                    "extra_metrics": [em.to_dict() for em in m.extra_metrics],
                }
                for m in result.models
            ],
            "per_sample": [
                {
                    "sample_index": sr.sample_index,
                    "input": sr.input_text,
                    "expected_output": sr.expected_output,
                    "model_responses": {
                        mid: {
                            "response_text": resp.response_text,
                            "latency_ms": resp.latency_ms,
                            "cost_usd": resp.cost_usd,
                            "quality_score": resp.quality_score,
                            "judge_reasoning": resp.judge_reasoning,
                            "error": resp.error,
                            **({"agent_trace": resp.agent_trace.to_dict()} if resp.agent_trace else {}),
                        }
                        for mid, resp in sr.model_responses.items()
                        if resp is not None
                    },
                }
                for sr in result.per_sample
            ],
        }

        from pathlib import Path
        resolved = Path(path).resolve()
        resolved.parent.mkdir(parents=True, exist_ok=True)
        with open(resolved, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    # =========================================================================
    # API helpers
    # =========================================================================

    def _api_request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        raw_body: Optional[bytes] = None,
        content_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Make an authenticated API request to the ModelScout backend."""
        url = f"{self.api_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": content_type or "application/json",
            "User-Agent": "ModelScout-SDK/0.1.0",
        }
        if self.org_slug:
            headers["X-Org-Slug"] = self.org_slug

        if raw_body is not None:
            data = raw_body
        else:
            data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        # Scale timeout with payload size: 60s base + 30s per MB, capped at 5 min
        payload_mb = len(data) / (1024 * 1024) if data else 0
        timeout = min(300, max(60, int(60 + payload_mb * 30)))

        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else ""
            try:
                error_data = json.loads(error_body)
                detail = error_data.get("detail", {})
                if isinstance(detail, dict):
                    msg = detail.get("message", error_body)
                    code = detail.get("code", "")
                else:
                    msg = str(detail)
                    code = ""
            except (json.JSONDecodeError, AttributeError):
                msg = error_body or str(e)
                code = ""
            raise BenchmarkError(
                _sanitize_error_msg(msg), code=code, status_code=e.code,
            ) from e
        except urllib.error.URLError as e:
            raise BenchmarkError(
                _sanitize_error_msg(f"Connection error: {e.reason}"),
                code="CONNECTION_ERROR",
            ) from e

    @staticmethod
    def _get_sdk_version() -> str:
        try:
            from modelscout import __version__
            return __version__
        except ImportError:
            return "unknown"
