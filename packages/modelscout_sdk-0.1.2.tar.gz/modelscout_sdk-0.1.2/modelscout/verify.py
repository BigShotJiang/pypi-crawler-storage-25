"""Verification script for modelscout-core security boundary.

Run with: python -m modelscout.verify

Checks that the installed modelscout-core package does NOT import any
network-capable modules, confirming it cannot exfiltrate API keys or data.
"""

import importlib
import inspect
import sys
import types
from pathlib import Path
from typing import Dict, List, Set, Tuple


# Modules that would enable network access or process spawning
FORBIDDEN_MODULES = {
    # Network
    "socket", "ssl",
    "urllib", "urllib.request", "urllib.parse", "urllib.error",
    "http", "http.client", "http.server",
    "requests", "httpx", "aiohttp",
    "xmlrpc", "ftplib", "smtplib", "imaplib", "poplib",
    # Process spawning
    "subprocess",
    # Low-level OS exec
    "ctypes",
}

# Modules that are acceptable despite being in os/sys
ALLOWED_MODULES = {
    "os", "os.path",  # Needed for ONNX model cache filesystem access
    "sys",
    "json", "msgpack",  # Serialization
    "re", "math", "threading", "logging",  # Standard utilities
    "dataclasses", "typing", "pathlib", "enum",
    "collections", "functools", "itertools",
    "warnings", "abc", "io", "struct", "hashlib",
    "numpy", "onnxruntime", "transformers", "tokenizers",
    "torch",  # Optional, for MIRT-BERT
}


def _get_source_file(module: types.ModuleType) -> str:
    """Get source file path for a module."""
    try:
        return inspect.getfile(module)
    except (TypeError, OSError):
        return "<built-in>"


def check_imports(verbose: bool = False) -> Tuple[bool, List[str]]:
    """Check modelscout-core for forbidden imports.

    Returns:
        Tuple of (passed, list of violation messages)
    """
    violations: List[str] = []

    try:
        import modelscout_core
    except ImportError:
        return False, ["modelscout-core is not installed"]

    # Get the core package path
    core_path = Path(modelscout_core.__file__).parent
    if verbose:
        print(f"Checking modelscout-core at: {core_path}")

    # Method 1: Static analysis of source files (if available)
    source_violations = _check_source_files(core_path, verbose)
    violations.extend(source_violations)

    # Method 2: Runtime import analysis
    runtime_violations = _check_runtime_imports(verbose)
    violations.extend(runtime_violations)

    return len(violations) == 0, violations


def _check_source_files(core_path: Path, verbose: bool) -> List[str]:
    """Statically check .py source files for forbidden imports."""
    violations = []

    py_files = list(core_path.glob("**/*.py"))
    if not py_files:
        if verbose:
            print("  No .py source files found (may be Cython-compiled)")
        return []

    for py_file in py_files:
        if py_file.name == "setup.py":
            continue  # Build script, not runtime code

        try:
            source = py_file.read_text()
        except Exception:
            continue

        for line_num, line in enumerate(source.splitlines(), 1):
            stripped = line.strip()

            # Skip comments and empty lines
            if stripped.startswith("#") or not stripped:
                continue

            # Check import statements
            if stripped.startswith("import ") or stripped.startswith("from "):
                for forbidden in FORBIDDEN_MODULES:
                    # Match: import socket, from socket import ..., import urllib.request
                    if (
                        f"import {forbidden}" in stripped
                        or f"from {forbidden}" in stripped
                    ):
                        violations.append(
                            f"FORBIDDEN import in {py_file.name}:{line_num}: {stripped}"
                        )

    if verbose and not violations:
        print(f"  Source check: {len(py_files)} files scanned, no forbidden imports")

    return violations


def _check_runtime_imports(verbose: bool) -> List[str]:
    """Check what modules modelscout-core actually loads at runtime."""
    violations = []

    # Record modules before importing core
    before = set(sys.modules.keys())

    # Force import of the core matcher
    try:
        import modelscout_core.matcher
        # Trigger initialization by creating an instance
        # (don't load config - just check what the import itself pulls in)
    except ImportError as e:
        return [f"Cannot import modelscout_core.matcher: {e}"]

    # Check what new modules were loaded
    after = set(sys.modules.keys())
    new_modules = after - before

    for mod_name in sorted(new_modules):
        # Check against forbidden list
        for forbidden in FORBIDDEN_MODULES:
            if mod_name == forbidden or mod_name.startswith(forbidden + "."):
                violations.append(
                    f"FORBIDDEN runtime import: {mod_name}"
                )

    if verbose:
        print(f"  Runtime check: {len(new_modules)} new modules loaded")
        if violations:
            print(f"  VIOLATIONS: {len(violations)}")
        else:
            print("  No forbidden runtime imports detected")

    return violations


def main():
    """Run verification and print results."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Verify modelscout-core security boundary"
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Show detailed output"
    )
    args = parser.parse_args()

    print("=" * 60)
    print("ModelScout Core Security Verification")
    print("=" * 60)
    print()

    passed, violations = check_imports(verbose=args.verbose)

    if passed:
        print("PASSED: modelscout-core has no forbidden network/process imports")
        print()
        print("The core matching engine:")
        print("  - Cannot make network connections")
        print("  - Cannot spawn subprocesses")
        print("  - Cannot exfiltrate API keys or data")
        print()
        print("Your API keys are safe. The open-source modelscout wrapper")
        print("is the only code that accesses network and API keys.")
        sys.exit(0)
    else:
        print("FAILED: Security violations detected!")
        print()
        for v in violations:
            print(f"  ! {v}")
        print()
        print("modelscout-core should NOT import network or process modules.")
        print("Please report this issue.")
        sys.exit(1)


if __name__ == "__main__":
    main()
