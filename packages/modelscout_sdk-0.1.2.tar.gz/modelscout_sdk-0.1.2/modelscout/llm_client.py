"""Unified LLM client for model-agnostic agent code.

This module provides a unified interface for interacting with multiple LLM providers
(OpenAI, Anthropic, Google) using a consistent API. Users write model-agnostic agent
code and the SDK handles provider-specific differences.

Example:
    >>> from modelscout import LLMClient, ModelConfig
    >>>
    >>> # Create client for a specific model
    >>> client = LLMClient(ModelConfig(provider="openai", model="gpt-4o"))
    >>>
    >>> # Use unified API
    >>> response = client.complete([{"role": "user", "content": "Hello!"}])
    >>> print(response.content)

For benchmarking, users don't create LLMClient directly - the Benchmark class
handles this, allowing the same agent code to run against multiple models:

    >>> def my_agent(llm_client, prompt):
    ...     return llm_client.complete([{"role": "user", "content": prompt}]).content
    >>>
    >>> results = benchmark.run_comparison(
    ...     agent_factory=my_agent,
    ...     models=[ModelConfig(provider="openai", model="gpt-4o"), ...]
    ... )
"""

import logging
import os
import threading

logger = logging.getLogger(__name__)
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Generator, Iterator, List, Literal, Optional, Union, AsyncIterator

from modelscout.exceptions import ProviderError

# Thread lock for Google API key configuration (genai.configure is not thread-safe)
_google_api_lock = threading.Lock()


# Pricing per 1M tokens (USD) — synced from backend/app/llm/pricing.py.
# Must match exactly. Run backend/tests/test_pricing_sync.py to verify.
PRICING: Dict[str, Dict[str, Dict[str, float]]] = {
    "openai": {
        "gpt-5.4": {"input": 2.50, "output": 15.00},
        "gpt-5.4-mini": {"input": 0.75, "output": 4.50},
        "gpt-5.4-nano": {"input": 0.20, "output": 1.25},
        "gpt-5-mini": {"input": 0.25, "output": 2.00},
        "gpt-5-nano": {"input": 0.05, "output": 0.40},
    },
    "anthropic": {
        "claude-opus-4-6": {"input": 5.00, "output": 25.00},
        "claude-sonnet-4-6": {"input": 3.00, "output": 15.00},
        "claude-haiku-4-5-20251001": {"input": 1.00, "output": 5.00},
    },
    "google": {
        "gemini-3.1-pro": {"input": 2.00, "output": 12.00},
        "gemini-3-flash": {"input": 0.50, "output": 3.00},
        "gemini-3.1-flash-lite": {"input": 0.25, "output": 1.50},
        "gemini-2.5-flash-lite": {"input": 0.10, "output": 0.40},
    },
    "deepseek": {
        "deepseek-v3.2": {"input": 0.26, "output": 0.38},
        "deepseek-v3.2-speciale": {"input": 0.40, "output": 1.20},
        "deepseek-r1": {"input": 0.70, "output": 2.50},
    },
    "qwen": {
        "qwen3.5-397b-a17b": {"input": 0.39, "output": 2.34},
        "qwen3.5-flash-02-23": {"input": 0.065, "output": 0.26},
        "qwen3-235b-a22b": {"input": 0.071, "output": 0.10},
    },
    "meta-llama": {
        "llama-4-maverick": {"input": 0.15, "output": 0.60},
        "llama-4-scout": {"input": 0.08, "output": 0.30},
    },
    "mistralai": {
        "mistral-large-2512": {"input": 0.50, "output": 1.50},
        "mistral-small-2603": {"input": 0.15, "output": 0.60},
    },
    "x-ai": {
        "grok-4": {"input": 3.00, "output": 15.00},
        "grok-4.1-fast": {"input": 0.20, "output": 0.50},
    },
}

# Model aliases — synced from backend/app/llm/pricing.py MODEL_ALIASES.
MODEL_ALIASES: Dict[str, Dict[str, str]] = {
    "openai": {
        "chatgpt-5.4": "gpt-5.4",
        "gpt-5": "gpt-5.4",
        "gpt-5.2": "gpt-5.4",
        "gpt-5.1": "gpt-5.4",
    },
    "anthropic": {
        "claude-opus": "claude-opus-4-6",
        "claude-opus-4": "claude-opus-4-6",
        "claude-opus-4.6": "claude-opus-4-6",
        "claude-sonnet": "claude-sonnet-4-6",
        "claude-sonnet-4": "claude-sonnet-4-6",
        "claude-sonnet-4.6": "claude-sonnet-4-6",
        "claude-haiku": "claude-haiku-4-5-20251001",
        "claude-haiku-4": "claude-haiku-4-5-20251001",
        "claude-haiku-4.5": "claude-haiku-4-5-20251001",
        "claude-opus-4.5": "claude-opus-4-6",
        "claude-opus-4-5-20251101": "claude-opus-4-6",
        "claude-sonnet-4.5": "claude-sonnet-4-6",
        "claude-sonnet-4-5-20250929": "claude-sonnet-4-6",
        "claude-3-opus": "claude-opus-4-6",
        "claude-3-5-sonnet": "claude-sonnet-4-6",
        "claude-3-5-sonnet-20241022": "claude-sonnet-4-6",
        "claude-3-haiku": "claude-haiku-4-5-20251001",
        "claude-3-5-haiku": "claude-haiku-4-5-20251001",
        "claude-3-5-haiku-20241022": "claude-haiku-4-5-20251001",
    },
    "google": {
        "gemini-pro": "gemini-3.1-pro",
        "gemini-flash": "gemini-3-flash",
        "gemini-flash-lite": "gemini-3.1-flash-lite",
    },
    "deepseek": {
        "deepseek-chat": "deepseek-v3.2",
        "deepseek-v3": "deepseek-v3.2",
        "deepseek-v3.1": "deepseek-v3.2",
        "deepseek-reasoner": "deepseek-r1",
    },
    "qwen": {
        "qwen3-235b": "qwen3-235b-a22b",
        "qwen3.5": "qwen3.5-397b-a17b",
        "qwen3.5-flash": "qwen3.5-flash-02-23",
    },
}

# Environment variable names for API keys
API_KEY_ENV_VARS: Dict[str, str] = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "google": "GOOGLE_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "deepinfra": "DEEPINFRA_API_KEY",
    "qwen": "QWEN_API_KEY",
    "meta-llama": "META_API_KEY",
    "mistralai": "MISTRAL_API_KEY",
    "x-ai": "XAI_API_KEY",
}


def _get_api_key(provider: str, explicit_key: Optional[str] = None) -> str:
    """Get API key from explicit param, env var, or raise error.

    Args:
        provider: Provider name (openai, anthropic, google)
        explicit_key: Explicitly provided API key (takes precedence)

    Returns:
        API key string

    Raises:
        ValueError: If no API key is found
    """
    if explicit_key:
        return explicit_key

    env_var = API_KEY_ENV_VARS.get(provider.lower())
    if not env_var:
        raise ValueError(f"Unknown provider: {provider}")

    key = os.environ.get(env_var, "")
    if not key:
        raise ValueError(
            f"No API key found for {provider}. "
            f"Set {env_var} environment variable or pass api_key explicitly."
        )
    return key


def _resolve_model_alias(provider: str, model: str) -> str:
    """Resolve model alias to canonical model name."""
    provider_aliases = MODEL_ALIASES.get(provider.lower(), {})
    return provider_aliases.get(model, model)


def _calculate_cost(
    provider: str, model: str, input_tokens: int, output_tokens: int
) -> float:
    """Calculate cost in USD for given token counts.

    Args:
        provider: Provider name
        model: Model identifier
        input_tokens: Number of input/prompt tokens
        output_tokens: Number of output/completion tokens

    Returns:
        Total cost in USD, or 0.0 if pricing not available
    """
    provider = provider.lower()
    resolved_model = _resolve_model_alias(provider, model)

    provider_pricing = PRICING.get(provider, {})
    model_pricing = provider_pricing.get(resolved_model)

    if not model_pricing:
        # Unknown model - log warning and return 0
        # Unknown model — use conservative default to prevent silent undercharging.
        # $10/$30 per 1M tokens is high enough to flag cost anomalies.
        logger.warning(
            f"No pricing found for {provider}/{resolved_model}, using conservative "
            f"default ($10/$30 per 1M tokens). Add pricing to PRICING dict to fix."
        )
        return (
            input_tokens * 10.0 / 1_000_000
            + output_tokens * 30.0 / 1_000_000
        )

    return (
        input_tokens * model_pricing["input"] / 1_000_000
        + output_tokens * model_pricing["output"] / 1_000_000
    )


@dataclass
class ModelConfig:
    """Configuration for an LLM model.

    Attributes:
        provider: LLM provider (openai, anthropic, google)
        model: Model identifier (e.g., gpt-4o, claude-sonnet-4-20250514)
        temperature: Sampling temperature (0.0 - 2.0)
        max_tokens: Maximum tokens to generate
        api_key: API key (if not set, uses environment variable)
    """

    provider: Literal["openai", "anthropic", "google", "deepseek", "deepinfra"]
    model: str
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    api_key: Optional[str] = None

    @property
    def model_id(self) -> str:
        """Get unique identifier for this model configuration."""
        return f"{self.provider}/{self.model}"

    def __hash__(self) -> int:
        return hash(self.model_id)

    def __repr__(self) -> str:
        key_display = "'***'" if self.api_key else "None"
        return (
            f"ModelConfig(provider='{self.provider}', model='{self.model}', "
            f"temperature={self.temperature}, max_tokens={self.max_tokens}, "
            f"api_key={key_display})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ModelConfig):
            return False
        return self.model_id == other.model_id


@dataclass
class LLMToolCall:
    """A tool call from an LLM response.

    Attributes:
        id: Unique identifier for this tool call.
        type: The type of tool call (always "function").
        function_name: Name of the function to call.
        function_arguments: JSON string of function arguments.
    """

    id: str
    type: str
    function_name: str
    function_arguments: str


@dataclass
class LLMResponse:
    """Response from an LLM completion request.

    Attributes:
        content: The generated text content
        input_tokens: Number of input/prompt tokens
        output_tokens: Number of output/completion tokens
        latency_ms: Request latency in milliseconds
        cost_usd: Estimated cost in USD
        model: Model that generated the response
        provider: Provider that served the request
        finish_reason: Why the model stopped generating (stop, length, tool_calls, etc.)
        tool_calls: List of tool calls requested by the model (if any)
        raw_response: Raw response object from the provider (for debugging)
    """

    content: str
    input_tokens: int
    output_tokens: int
    latency_ms: float
    cost_usd: float
    model: str
    provider: str
    finish_reason: Optional[str] = None
    tool_calls: Optional[List[LLMToolCall]] = None
    raw_response: Optional[Any] = field(default=None, repr=False)


@dataclass
class StreamChunk:
    """A single chunk in a streaming response.

    Attributes:
        content: The text content of this chunk (may be empty string).
        finish_reason: Set on the final chunk (stop, length, etc.).
        is_first: True for the first chunk in the stream.
        is_last: True for the last chunk in the stream.
    """
    content: str
    finish_reason: Optional[str] = None
    is_first: bool = False
    is_last: bool = False


@dataclass
class _CircuitState:
    """Tracks circuit breaker state for a provider."""
    failures: int = 0
    open_until: float = 0.0


class LLMClient:
    """Unified LLM client for model-agnostic agent code.

    Provides a consistent interface for interacting with OpenAI, Anthropic,
    and Google LLMs. Messages use OpenAI format as the standard.

    Args:
        config: Model configuration specifying provider, model, and parameters

    Example:
        >>> client = LLMClient(ModelConfig(provider="anthropic", model="claude-sonnet-4-20250514"))
        >>> response = client.complete([
        ...     {"role": "system", "content": "You are a helpful assistant."},
        ...     {"role": "user", "content": "Hello!"}
        ... ])
        >>> print(response.content)
    """

    # Default timeout in seconds for vendor API calls
    DEFAULT_TIMEOUT = 60

    # Circuit breaker settings
    _CIRCUIT_FAILURE_THRESHOLD = 5
    _CIRCUIT_COOLDOWN_SECONDS = 30

    # Circuit breaker state per provider (class-level, shared across instances)
    _circuit_state: Dict[str, _CircuitState] = {}
    _circuit_lock = threading.Lock()

    # DeepInfra uses HuggingFace-style model IDs in API calls
    _DEEPINFRA_MODEL_MAP = {
        "qwen3-235b-a22b": "Qwen/Qwen3-235B-A22B-Instruct-2507",
    }

    def __init__(self, config: ModelConfig):
        self.config = config
        self._api_key = _get_api_key(config.provider, config.api_key)
        self._client: Any = None  # Lazy initialization

    def _check_circuit(self) -> None:
        """Check if circuit breaker is open for this provider.

        Raises:
            ProviderError: If circuit is open (too many consecutive failures).
        """
        provider = self.config.provider
        with self._circuit_lock:
            state = self._circuit_state.get(provider)
            if state and state.failures >= self._CIRCUIT_FAILURE_THRESHOLD:
                if time.time() < state.open_until:
                    raise ProviderError(
                        f"Circuit breaker open for {provider} "
                        f"({state.failures} consecutive failures, "
                        f"retry in {state.open_until - time.time():.0f}s)",
                        provider=provider,
                        model=self.config.model,
                        is_retryable=False,
                    )
                # Cooldown expired — allow a probe request (half-open)
                state.failures = 0

    def _record_success(self) -> None:
        """Record a successful call, resetting the circuit breaker."""
        provider = self.config.provider
        with self._circuit_lock:
            state = self._circuit_state.get(provider)
            if state:
                state.failures = 0

    def _record_failure(self) -> None:
        """Record a failed call, potentially opening the circuit breaker."""
        provider = self.config.provider
        with self._circuit_lock:
            if provider not in self._circuit_state:
                self._circuit_state[provider] = _CircuitState()
            state = self._circuit_state[provider]
            state.failures += 1
            if state.failures >= self._CIRCUIT_FAILURE_THRESHOLD:
                state.open_until = time.time() + self._CIRCUIT_COOLDOWN_SECONDS

    def _wrap_provider_error(self, e: Exception) -> ProviderError:
        """Wrap a vendor-specific exception into a ProviderError."""
        provider = self.config.provider
        model = self.config.model
        status_code = getattr(e, "status_code", None)
        retry_after = getattr(e, "retry_after", None)

        # Classify by exception type name for vendor-agnostic detection
        exc_type_name = type(e).__name__.lower()
        exc_module = type(e).__module__ or ""

        # Auth errors (not retryable)
        if "authentication" in exc_type_name or "permission" in exc_type_name:
            return ProviderError(
                str(e), provider=provider, model=model,
                status_code=status_code or 401,
                is_retryable=False, original_error=e,
            )

        # Rate limit errors (retryable)
        if "ratelimit" in exc_type_name or "rate_limit" in exc_type_name:
            return ProviderError(
                str(e), provider=provider, model=model,
                status_code=status_code or 429,
                retry_after=retry_after,
                is_retryable=True, original_error=e,
            )

        # Timeout errors (retryable)
        if "timeout" in exc_type_name or isinstance(e, (TimeoutError,)):
            return ProviderError(
                str(e), provider=provider, model=model,
                status_code=status_code or 408,
                is_retryable=True, original_error=e,
            )

        # Status-code based classification
        if status_code:
            if status_code == 401 or status_code == 403:
                return ProviderError(
                    str(e), provider=provider, model=model,
                    status_code=status_code,
                    is_retryable=False, original_error=e,
                )

        # Default: retryable
        return ProviderError(
            str(e), provider=provider, model=model,
            status_code=status_code,
            is_retryable=True, original_error=e,
        )

    @property
    def _api_model_name(self) -> str:
        """Get the model name as expected by the provider's API."""
        if self.config.provider == "deepinfra":
            return self._DEEPINFRA_MODEL_MAP.get(
                self.config.model, self.config.model
            )
        return self.config.model

    def _get_client(self) -> Any:
        """Get or create the provider-specific client."""
        if self._client is not None:
            return self._client

        if self.config.provider == "openai":
            try:
                from openai import OpenAI
            except ImportError:
                raise ImportError(
                    "OpenAI SDK not installed. Install with: pip install modelscout[openai]"
                )
            self._client = OpenAI(api_key=self._api_key, timeout=self.DEFAULT_TIMEOUT)

        elif self.config.provider == "anthropic":
            try:
                from anthropic import Anthropic
            except ImportError:
                raise ImportError(
                    "Anthropic SDK not installed. Install with: pip install modelscout[anthropic]"
                )
            self._client = Anthropic(api_key=self._api_key, timeout=self.DEFAULT_TIMEOUT)

        elif self.config.provider == "google":
            try:
                import google.generativeai as genai
            except ImportError:
                raise ImportError(
                    "Google Generative AI SDK not installed. "
                    "Install with: pip install modelscout[google]"
                )
            # Note: We store the genai module reference but configure API key
            # per-call with thread lock to avoid race conditions.
            # See _complete_google and _complete_google_async for thread-safe usage.
            self._client = genai

        elif self.config.provider == "deepseek":
            # DeepSeek uses OpenAI-compatible API
            try:
                from openai import OpenAI
            except ImportError:
                raise ImportError(
                    "OpenAI SDK not installed. Install with: pip install openai"
                )
            self._client = OpenAI(
                api_key=self._api_key,
                base_url="https://api.deepseek.com",
                timeout=self.DEFAULT_TIMEOUT,
            )

        elif self.config.provider == "deepinfra":
            # DeepInfra uses OpenAI-compatible API
            try:
                from openai import OpenAI
            except ImportError:
                raise ImportError(
                    "OpenAI SDK not installed. Install with: pip install openai"
                )
            self._client = OpenAI(
                api_key=self._api_key,
                base_url="https://api.deepinfra.com/v1/openai",
                timeout=self.DEFAULT_TIMEOUT,
            )

        else:
            raise ValueError(f"Unknown provider: {self.config.provider}")

        return self._client

    def complete(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Send completion request to configured provider.

        Messages use OpenAI format:
        [
            {"role": "system", "content": "..."},
            {"role": "user", "content": "..."},
            {"role": "assistant", "content": "..."},
        ]

        Args:
            messages: List of message dicts with "role" and "content"
            temperature: Override config temperature
            max_tokens: Override config max_tokens
            **kwargs: Additional provider-specific parameters

        Returns:
            LLMResponse with content and usage information
        """
        self._check_circuit()
        start_time = time.time()

        temp = temperature if temperature is not None else self.config.temperature
        max_tok = max_tokens if max_tokens is not None else self.config.max_tokens

        # Providers using OpenAI-compatible API
        openai_compatible = ["openai", "deepseek", "deepinfra"]

        try:
            if self.config.provider in openai_compatible:
                response = self._complete_openai(messages, temp, max_tok, **kwargs)
            elif self.config.provider == "anthropic":
                response = self._complete_anthropic(messages, temp, max_tok, **kwargs)
            elif self.config.provider == "google":
                response = self._complete_google(messages, temp, max_tok, **kwargs)
            else:
                raise ValueError(f"Unknown provider: {self.config.provider}")
        except ProviderError:
            self._record_failure()
            raise
        except (ValueError, ImportError):
            raise
        except Exception as e:
            self._record_failure()
            raise self._wrap_provider_error(e)

        self._record_success()
        response.latency_ms = (time.time() - start_time) * 1000
        response.cost_usd = _calculate_cost(
            self.config.provider,
            self.config.model,
            response.input_tokens,
            response.output_tokens,
        )

        return response

    def _complete_openai(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> LLMResponse:
        """Execute completion using OpenAI API."""
        client = self._get_client()

        params: Dict[str, Any] = {
            "model": self._api_model_name,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        params.update(kwargs)

        response = client.chat.completions.create(**params)

        # Extract tool calls if present
        tool_calls: Optional[List[LLMToolCall]] = None
        msg_tool_calls = response.choices[0].message.tool_calls
        if msg_tool_calls:
            tool_calls = [
                LLMToolCall(
                    id=tc.id,
                    type=tc.type,
                    function_name=tc.function.name,
                    function_arguments=tc.function.arguments,
                )
                for tc in msg_tool_calls
            ]

        return LLMResponse(
            content=response.choices[0].message.content or "",
            input_tokens=response.usage.prompt_tokens if response.usage else 0,
            output_tokens=response.usage.completion_tokens if response.usage else 0,
            latency_ms=0,  # Will be set by caller
            cost_usd=0,  # Will be set by caller
            model=self.config.model,
            provider=self.config.provider,
            finish_reason=response.choices[0].finish_reason,
            tool_calls=tool_calls,
            raw_response=response,
        )

    def _complete_anthropic(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> LLMResponse:
        """Execute completion using Anthropic API."""
        client = self._get_client()

        # Extract system message if present (Anthropic handles it separately)
        system_content: Optional[str] = None
        conversation_messages: List[Dict[str, str]] = []

        for msg in messages:
            if msg["role"] == "system":
                system_content = msg["content"]
            else:
                conversation_messages.append(msg)

        params: Dict[str, Any] = {
            "model": self._api_model_name,
            "messages": conversation_messages,
            "max_tokens": max_tokens or 4096,  # Anthropic requires max_tokens
            "temperature": temperature,
        }
        if system_content:
            params["system"] = system_content
        params.update(kwargs)

        response = client.messages.create(**params)

        # Extract text content and tool calls
        content = ""
        tool_calls: Optional[List[LLMToolCall]] = None

        for block in response.content:
            if hasattr(block, "text"):
                content += block.text
            elif block.type == "tool_use":
                # Anthropic tool_use block
                if tool_calls is None:
                    tool_calls = []
                import json
                tool_calls.append(LLMToolCall(
                    id=block.id,
                    type="function",
                    function_name=block.name,
                    function_arguments=json.dumps(block.input),
                ))

        return LLMResponse(
            content=content,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            latency_ms=0,  # Will be set by caller
            cost_usd=0,  # Will be set by caller
            model=self.config.model,
            provider=self.config.provider,
            finish_reason=response.stop_reason,
            tool_calls=tool_calls,
            raw_response=response,
        )

    def _complete_google(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> LLMResponse:
        """Execute completion using Google Generative AI API.

        Uses thread lock for API key configuration to ensure thread safety.
        """
        genai = self._get_client()

        # Convert messages to Google format
        # Google uses "parts" and has different role names
        history: List[Dict[str, Any]] = []
        system_instruction: Optional[str] = None

        for msg in messages:
            if msg["role"] == "system":
                system_instruction = msg["content"]
            elif msg["role"] == "user":
                history.append({"role": "user", "parts": [msg["content"]]})
            elif msg["role"] == "assistant":
                history.append({"role": "model", "parts": [msg["content"]]})

        # Thread-safe API key configuration and model creation
        # genai.configure() sets module-level state, so we protect it
        with _google_api_lock:
            genai.configure(api_key=self._api_key)

            # Create model with configuration
            generation_config = genai.GenerationConfig(
                temperature=temperature,
                max_output_tokens=max_tokens,
            )

            model = genai.GenerativeModel(
                model_name=self.config.model,
                generation_config=generation_config,
                system_instruction=system_instruction,
            )

            # Start chat if there's history, otherwise just generate
            if len(history) > 1:
                chat = model.start_chat(history=history[:-1])
                response = chat.send_message(history[-1]["parts"][0])
            else:
                response = model.generate_content(
                    history[-1]["parts"][0] if history else ""
                )

        # Extract token counts from usage metadata
        input_tokens = 0
        output_tokens = 0
        if hasattr(response, "usage_metadata"):
            input_tokens = getattr(response.usage_metadata, "prompt_token_count", 0)
            output_tokens = getattr(
                response.usage_metadata, "candidates_token_count", 0
            )

        return LLMResponse(
            content=response.text if hasattr(response, "text") else "",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=0,  # Will be set by caller
            cost_usd=0,  # Will be set by caller
            model=self.config.model,
            provider=self.config.provider,
            finish_reason=None,  # Google doesn't provide this consistently
            raw_response=response,
        )

    async def complete_async(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Async version of complete.

        Args:
            messages: List of message dicts with "role" and "content"
            temperature: Override config temperature
            max_tokens: Override config max_tokens
            **kwargs: Additional provider-specific parameters

        Returns:
            LLMResponse with content and usage information
        """
        self._check_circuit()
        start_time = time.time()

        temp = temperature if temperature is not None else self.config.temperature
        max_tok = max_tokens if max_tokens is not None else self.config.max_tokens

        # Providers using OpenAI-compatible API
        openai_compatible = ["openai", "deepseek", "deepinfra"]

        try:
            if self.config.provider in openai_compatible:
                response = await self._complete_openai_async(
                    messages, temp, max_tok, **kwargs
                )
            elif self.config.provider == "anthropic":
                response = await self._complete_anthropic_async(
                    messages, temp, max_tok, **kwargs
                )
            elif self.config.provider == "google":
                response = await self._complete_google_async(
                    messages, temp, max_tok, **kwargs
                )
            else:
                raise ValueError(f"Unknown provider: {self.config.provider}")
        except ProviderError:
            self._record_failure()
            raise
        except (ValueError, ImportError):
            raise
        except Exception as e:
            self._record_failure()
            raise self._wrap_provider_error(e)

        self._record_success()
        response.latency_ms = (time.time() - start_time) * 1000
        response.cost_usd = _calculate_cost(
            self.config.provider,
            self.config.model,
            response.input_tokens,
            response.output_tokens,
        )

        return response

    async def _complete_openai_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> LLMResponse:
        """Execute async completion using OpenAI-compatible API."""
        try:
            from openai import AsyncOpenAI
        except ImportError:
            raise ImportError(
                "OpenAI SDK not installed. Install with: pip install openai"
            )

        # Provider-specific base URLs
        base_urls = {
            "openai": None,  # Use default
            "deepseek": "https://api.deepseek.com",
            "deepinfra": "https://api.deepinfra.com/v1/openai",
        }

        base_url = base_urls.get(self.config.provider)
        client = AsyncOpenAI(api_key=self._api_key, base_url=base_url, timeout=self.DEFAULT_TIMEOUT)

        params: Dict[str, Any] = {
            "model": self._api_model_name,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        params.update(kwargs)

        response = await client.chat.completions.create(**params)

        return LLMResponse(
            content=response.choices[0].message.content or "",
            input_tokens=response.usage.prompt_tokens if response.usage else 0,
            output_tokens=response.usage.completion_tokens if response.usage else 0,
            latency_ms=0,
            cost_usd=0,
            model=self.config.model,
            provider=self.config.provider,
            finish_reason=response.choices[0].finish_reason,
            raw_response=response,
        )

    async def _complete_anthropic_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> LLMResponse:
        """Execute async completion using Anthropic API."""
        try:
            from anthropic import AsyncAnthropic
        except ImportError:
            raise ImportError(
                "Anthropic SDK not installed. Install with: pip install modelscout[anthropic]"
            )

        client = AsyncAnthropic(api_key=self._api_key, timeout=self.DEFAULT_TIMEOUT)

        # Extract system message if present
        system_content: Optional[str] = None
        conversation_messages: List[Dict[str, str]] = []

        for msg in messages:
            if msg["role"] == "system":
                system_content = msg["content"]
            else:
                conversation_messages.append(msg)

        params: Dict[str, Any] = {
            "model": self._api_model_name,
            "messages": conversation_messages,
            "max_tokens": max_tokens or 4096,
            "temperature": temperature,
        }
        if system_content:
            params["system"] = system_content
        params.update(kwargs)

        response = await client.messages.create(**params)

        content = ""
        for block in response.content:
            if hasattr(block, "text"):
                content += block.text

        return LLMResponse(
            content=content,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            latency_ms=0,
            cost_usd=0,
            model=self.config.model,
            provider=self.config.provider,
            finish_reason=response.stop_reason,
            raw_response=response,
        )

    async def _complete_google_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> LLMResponse:
        """Execute async completion using Google Generative AI API.

        Uses thread lock for API key configuration to ensure thread safety.
        """
        try:
            import google.generativeai as genai
        except ImportError:
            raise ImportError(
                "Google Generative AI SDK not installed. "
                "Install with: pip install modelscout[google]"
            )

        # Convert messages to Google format
        history: List[Dict[str, Any]] = []
        system_instruction: Optional[str] = None

        for msg in messages:
            if msg["role"] == "system":
                system_instruction = msg["content"]
            elif msg["role"] == "user":
                history.append({"role": "user", "parts": [msg["content"]]})
            elif msg["role"] == "assistant":
                history.append({"role": "model", "parts": [msg["content"]]})

        # Thread-safe API key configuration and model creation
        # genai.configure() sets module-level state, so we protect it
        with _google_api_lock:
            genai.configure(api_key=self._api_key)

            generation_config = genai.GenerationConfig(
                temperature=temperature,
                max_output_tokens=max_tokens,
            )

            model = genai.GenerativeModel(
                model_name=self.config.model,
                generation_config=generation_config,
                system_instruction=system_instruction,
            )

        # Google's async API (can run outside lock - model is created)
        if len(history) > 1:
            chat = model.start_chat(history=history[:-1])
            response = await chat.send_message_async(history[-1]["parts"][0])
        else:
            response = await model.generate_content_async(
                history[-1]["parts"][0] if history else ""
            )

        input_tokens = 0
        output_tokens = 0
        if hasattr(response, "usage_metadata"):
            input_tokens = getattr(response.usage_metadata, "prompt_token_count", 0)
            output_tokens = getattr(
                response.usage_metadata, "candidates_token_count", 0
            )

        return LLMResponse(
            content=response.text if hasattr(response, "text") else "",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=0,
            cost_usd=0,
            model=self.config.model,
            provider=self.config.provider,
            finish_reason=None,
            raw_response=response,
        )

    # =========================================================================
    # Streaming Methods
    # =========================================================================

    def stream(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> Iterator[StreamChunk]:
        """Stream completion tokens from configured provider.

        Yields StreamChunk objects as tokens are generated.

        Args:
            messages: List of message dicts with "role" and "content"
            temperature: Override config temperature
            max_tokens: Override config max_tokens
            **kwargs: Additional provider-specific parameters

        Yields:
            StreamChunk objects with content and finish_reason

        Example:
            >>> for chunk in client.stream([{"role": "user", "content": "Hello!"}]):
            ...     print(chunk.content, end="", flush=True)
        """
        self._check_circuit()
        temp = temperature if temperature is not None else self.config.temperature
        max_tok = max_tokens if max_tokens is not None else self.config.max_tokens

        # Providers using OpenAI-compatible API
        openai_compatible = ["openai", "deepseek", "deepinfra"]

        try:
            if self.config.provider in openai_compatible:
                yield from self._stream_openai(messages, temp, max_tok, **kwargs)
            elif self.config.provider == "anthropic":
                yield from self._stream_anthropic(messages, temp, max_tok, **kwargs)
            elif self.config.provider == "google":
                yield from self._stream_google(messages, temp, max_tok, **kwargs)
            else:
                raise ValueError(f"Unknown provider: {self.config.provider}")
            self._record_success()
        except Exception:
            self._record_failure()
            raise

    def _stream_openai(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> Iterator[StreamChunk]:
        """Stream from OpenAI or OpenAI-compatible API."""
        client = self._get_client()

        params: Dict[str, Any] = {
            "model": self._api_model_name,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        params.update(kwargs)

        response = client.chat.completions.create(**params)

        is_first = True
        for chunk in response:
            if chunk.choices and len(chunk.choices) > 0:
                delta = chunk.choices[0].delta
                content = delta.content if delta.content else ""
                finish_reason = chunk.choices[0].finish_reason

                yield StreamChunk(
                    content=content,
                    finish_reason=finish_reason,
                    is_first=is_first,
                    is_last=finish_reason is not None,
                )
                is_first = False

    def _stream_anthropic(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> Iterator[StreamChunk]:
        """Stream from Anthropic API."""
        client = self._get_client()

        # Extract system message if present
        system_content: Optional[str] = None
        conversation_messages: List[Dict[str, str]] = []

        for msg in messages:
            if msg["role"] == "system":
                system_content = msg["content"]
            else:
                conversation_messages.append(msg)

        params: Dict[str, Any] = {
            "model": self._api_model_name,
            "messages": conversation_messages,
            "max_tokens": max_tokens or 4096,
            "temperature": temperature,
        }
        if system_content:
            params["system"] = system_content
        params.update(kwargs)

        is_first = True
        with client.messages.stream(**params) as stream:
            for text in stream.text_stream:
                yield StreamChunk(
                    content=text,
                    finish_reason=None,
                    is_first=is_first,
                    is_last=False,
                )
                is_first = False

            # Final chunk with finish reason
            message = stream.get_final_message()
            yield StreamChunk(
                content="",
                finish_reason=message.stop_reason if message else "stop",
                is_first=False,
                is_last=True,
            )

    def _stream_google(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> Iterator[StreamChunk]:
        """Stream from Google Generative AI API.

        Uses thread lock for API key configuration to ensure thread safety.
        """
        genai = self._get_client()

        # Convert messages to Google format
        history: List[Dict[str, Any]] = []
        system_instruction: Optional[str] = None

        for msg in messages:
            if msg["role"] == "system":
                system_instruction = msg["content"]
            elif msg["role"] == "user":
                history.append({"role": "user", "parts": [msg["content"]]})
            elif msg["role"] == "assistant":
                history.append({"role": "model", "parts": [msg["content"]]})

        # Thread-safe API key configuration and model creation
        with _google_api_lock:
            genai.configure(api_key=self._api_key)

            generation_config = genai.GenerationConfig(
                temperature=temperature,
                max_output_tokens=max_tokens,
            )

            model = genai.GenerativeModel(
                model_name=self.config.model,
                generation_config=generation_config,
                system_instruction=system_instruction,
            )

            # Start the streaming request inside lock (model uses configured API key)
            if len(history) > 1:
                chat = model.start_chat(history=history[:-1])
                response = chat.send_message(
                    history[-1]["parts"][0],
                    stream=True,
                )
            else:
                response = model.generate_content(
                    history[-1]["parts"][0] if history else "",
                    stream=True,
                )

        is_first = True
        for chunk in response:
            if hasattr(chunk, "text") and chunk.text:
                yield StreamChunk(
                    content=chunk.text,
                    finish_reason=None,
                    is_first=is_first,
                    is_last=False,
                )
                is_first = False

        # Final chunk
        yield StreamChunk(
            content="",
            finish_reason="stop",
            is_first=False,
            is_last=True,
        )

    async def stream_async(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Async version of stream.

        Yields StreamChunk objects as tokens are generated.

        Args:
            messages: List of message dicts with "role" and "content"
            temperature: Override config temperature
            max_tokens: Override config max_tokens
            **kwargs: Additional provider-specific parameters

        Yields:
            StreamChunk objects with content and finish_reason
        """
        self._check_circuit()
        temp = temperature if temperature is not None else self.config.temperature
        max_tok = max_tokens if max_tokens is not None else self.config.max_tokens

        # Providers using OpenAI-compatible API
        openai_compatible = ["openai", "deepseek", "deepinfra"]

        try:
            if self.config.provider in openai_compatible:
                async for chunk in self._stream_openai_async(messages, temp, max_tok, **kwargs):
                    yield chunk
            elif self.config.provider == "anthropic":
                async for chunk in self._stream_anthropic_async(messages, temp, max_tok, **kwargs):
                    yield chunk
            elif self.config.provider == "google":
                # Google's async streaming is limited - fall back to sync in thread
                import asyncio
                for chunk in self._stream_google(messages, temp, max_tok, **kwargs):
                    yield chunk
                    await asyncio.sleep(0)  # Yield control
            else:
                raise ValueError(f"Unknown provider: {self.config.provider}")
            self._record_success()
        except Exception:
            self._record_failure()
            raise

    async def _stream_openai_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Async stream from OpenAI or OpenAI-compatible API."""
        from openai import AsyncOpenAI

        # Create async client
        if self.config.provider == "openai":
            client = AsyncOpenAI(api_key=self._api_key, timeout=self.DEFAULT_TIMEOUT)
        elif self.config.provider == "deepseek":
            client = AsyncOpenAI(api_key=self._api_key, base_url="https://api.deepseek.com", timeout=self.DEFAULT_TIMEOUT)
        elif self.config.provider == "deepinfra":
            client = AsyncOpenAI(api_key=self._api_key, base_url="https://api.deepinfra.com/v1/openai", timeout=self.DEFAULT_TIMEOUT)
        else:
            raise ValueError(f"Unknown provider: {self.config.provider}")

        params: Dict[str, Any] = {
            "model": self._api_model_name,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        params.update(kwargs)

        response = await client.chat.completions.create(**params)

        is_first = True
        async for chunk in response:
            if chunk.choices and len(chunk.choices) > 0:
                delta = chunk.choices[0].delta
                content = delta.content if delta.content else ""
                finish_reason = chunk.choices[0].finish_reason

                yield StreamChunk(
                    content=content,
                    finish_reason=finish_reason,
                    is_first=is_first,
                    is_last=finish_reason is not None,
                )
                is_first = False

    async def _stream_anthropic_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Async stream from Anthropic API."""
        from anthropic import AsyncAnthropic

        client = AsyncAnthropic(api_key=self._api_key, timeout=self.DEFAULT_TIMEOUT)

        # Extract system message if present
        system_content: Optional[str] = None
        conversation_messages: List[Dict[str, str]] = []

        for msg in messages:
            if msg["role"] == "system":
                system_content = msg["content"]
            else:
                conversation_messages.append(msg)

        params: Dict[str, Any] = {
            "model": self._api_model_name,
            "messages": conversation_messages,
            "max_tokens": max_tokens or 4096,
            "temperature": temperature,
        }
        if system_content:
            params["system"] = system_content
        params.update(kwargs)

        is_first = True
        async with client.messages.stream(**params) as stream:
            async for text in stream.text_stream:
                yield StreamChunk(
                    content=text,
                    finish_reason=None,
                    is_first=is_first,
                    is_last=False,
                )
                is_first = False

            # Final chunk with finish reason
            message = await stream.get_final_message()
            yield StreamChunk(
                content="",
                finish_reason=message.stop_reason if message else "stop",
                is_first=False,
                is_last=True,
            )
