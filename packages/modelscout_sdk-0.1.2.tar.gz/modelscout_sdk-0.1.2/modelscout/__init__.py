"""ModelScout Python SDK - Personalized LLM Evaluation.

Find the best LLM for your product with privacy-first benchmarking.

Quick Start - Benchmark:
    >>> from modelscout import Benchmark, ModelConfig
    >>>
    >>> results = Benchmark(api_key="ms_...").run(
    ...     name="My Benchmark",
    ...     models=[
    ...         ModelConfig(provider="openai", model="gpt-5.4"),
    ...         ModelConfig(provider="anthropic", model="claude-sonnet-4-6"),
    ...     ],
    ...     samples=Benchmark.load_dataset("my_data.jsonl"),
    ... )
    >>> print(results.best_model_for("quality"))

Quick Start - Agentic Benchmark:
    >>> from modelscout import Benchmark, ModelConfig, AgenticConfig, ToolDefinition
    >>>
    >>> results = Benchmark(api_key="ms_...").run(
    ...     name="Agent Eval",
    ...     models=[ModelConfig(provider="openai", model="gpt-5.4")],
    ...     agentic=AgenticConfig(max_turns=3, tools=[...]),
    ... )
"""

# =============================================================================
# Supporting Types
# =============================================================================

# Model configuration
from modelscout.llm_client import ModelConfig

# =============================================================================
# Benchmark - Privacy-first local benchmarking
# =============================================================================
from modelscout.benchmark import (
    Benchmark,
    BenchmarkProgress,
    BenchmarkResult,
    BenchmarkResults,
    BenchmarkError,
    ModelRecommendation,
    ExtraMetricStat,
    AgenticConfig,
    ToolDefinition,
    PACK_LIMITS,
)

# Exceptions
from modelscout.exceptions import (
    ModelScoutError,
    APIError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
    TimeoutError,
    RateLimitError,
    ProviderError,
    AllProvidersFailedError,
    ConcurrencyLimitError,
    TierRestrictionError,
    # Billing exceptions
    BillingConfigurationError,
    QuotaExceededError,
    BillingError,
    # Configuration & state exceptions
    ConfigNotLoadedError,
    ConfigParseError,
    EmbeddingError,
)

__version__ = "0.1.2"

__all__ = [
    # Benchmark
    "Benchmark",
    "BenchmarkProgress",
    "BenchmarkResult",
    "BenchmarkResults",
    "BenchmarkError",
    "ModelRecommendation",
    "ExtraMetricStat",
    "AgenticConfig",
    "ToolDefinition",
    "PACK_LIMITS",
    # Supporting types
    "ModelConfig",
    # Exceptions
    "ModelScoutError",
    "APIError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "TimeoutError",
    "RateLimitError",
    "ProviderError",
    "AllProvidersFailedError",
    "ConcurrencyLimitError",
    "TierRestrictionError",
    # Billing exceptions
    "BillingConfigurationError",
    "QuotaExceededError",
    "BillingError",
    # Configuration & state exceptions
    "ConfigNotLoadedError",
    "ConfigParseError",
    "EmbeddingError",
]
