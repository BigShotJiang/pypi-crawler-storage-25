"""Prompt complexity feature extraction for enriched routing.

Extracts domain-agnostic structural features from prompt text that capture
difficulty signals for routing. These features complement semantic embeddings
which encode topic but not reasoning complexity.

**Version 1** (17 base features):
- Length & Structure (5): char_count, word_count, sentence_count, avg_word_length, vocabulary_richness
- Syntactic Complexity (5): conditional_count, negation_count, comparison_count, multi_part, which_of_following
- Technical Content (4): numeric_count, numeric_density, formula_present, code_present
- Reasoning Demand (3): calculation_demanded, explanation_demanded, factual_lookup
- Choice Structure (3, optional): choice_count, avg_choice_len, max_choice_len

**Version 2** (15 base features — length-invariant):
Removes raw length features (char_count, word_count, sentence_count) and raw
counts (conditional_count, negation_count, comparison_count, numeric_count)
which scale with pasted content length and confound difficulty with input size.
Replaces them with density-normalized and reasoning-intent features.

- Ratios (2): avg_word_length, vocabulary_richness
- Density features (4): conditional_density, negation_density, comparison_density, numeric_density
- Binary structure (2): multi_part, which_of_following
- Technical content (2): formula_present, code_present
- Reasoning demand (3): calculation_demanded, explanation_demanded, factual_lookup
- New intent features (2): task_verb_complexity, output_constraint_count
- Choice Structure (3, optional): choice_count, avg_choice_len, max_choice_len

Pure Python implementation — no numpy or sklearn dependencies.
"""

import re
from typing import List, Optional


# --- Feature version 1 (original) ---

FEATURE_NAMES_V1 = [
    "char_count",
    "word_count",
    "sentence_count",
    "avg_word_length",
    "vocabulary_richness",
    "conditional_count",
    "negation_count",
    "comparison_count",
    "multi_part",
    "which_of_following",
    "numeric_count",
    "numeric_density",
    "formula_present",
    "code_present",
    "calculation_demanded",
    "explanation_demanded",
    "factual_lookup",
]

# --- Feature version 2 (length-invariant) ---

FEATURE_NAMES_V2 = [
    "avg_word_length",
    "vocabulary_richness",
    "conditional_density",
    "negation_density",
    "comparison_density",
    "numeric_density",
    "multi_part",
    "which_of_following",
    "formula_present",
    "code_present",
    "calculation_demanded",
    "explanation_demanded",
    "factual_lookup",
    "task_verb_complexity",
    "output_constraint_count",
]

# --- Feature version 3 (v2 + 12 structural complexity features = 27 total) ---

FEATURE_NAMES_V3 = FEATURE_NAMES_V2 + [
    # Structural complexity (5)
    "entity_introduction_count",
    "reference_chain_length",
    "logical_connective_density",
    "clause_depth_proxy",
    "question_count",
    # Reasoning demand (4)
    "step_indicator_count",
    "constraint_count",
    "domain_jargon_density",
    "proof_demand",
    # Format complexity (3)
    "has_examples",
    "has_structured_input",
    "prompt_length_bucket",
]

# Backward-compatible aliases
FEATURE_NAMES_BASE = FEATURE_NAMES_V1

FEATURE_NAMES_CHOICES = [
    "choice_count",
    "avg_choice_len",
    "max_choice_len",
]

# Latest version
LATEST_FEATURE_VERSION = 3


def _extract_v1(text: str) -> List[float]:
    """Extract v1 features (original 17, length-dependent)."""
    words = text.split()
    unique_words = set(w.lower() for w in words)

    # --- Length & Structure (5) ---
    char_count = float(len(text))
    word_count = float(len(words))
    sentence_count = float(len([s for s in re.split(r"[.!?]+", text) if s.strip()]))
    avg_word_length = (
        sum(len(w) for w in words) / len(words) if words else 0.0
    )
    vocabulary_richness = len(unique_words) / max(len(words), 1)

    # --- Syntactic Complexity (5) ---
    conditional_count = float(
        len(
            re.findall(
                r"\bif\b|\bgiven\b|\bassuming\b|\bsuppose\b|\bconsider\b"
                r"|\bwhen\b|\bwhere\b|\bsuch\s+that\b",
                text,
                re.I,
            )
        )
    )
    negation_count = float(
        len(
            re.findall(
                r"\bnot\b|\bnever\b|\bexcept\b|\bunless\b|\bnone\b"
                r"|\bneither\b|\bwithout\b",
                text,
                re.I,
            )
        )
    )
    comparison_count = float(
        len(
            re.findall(
                r"\bcompar\w*\b|\bdiffer\w*\b|\bsimilar\b|\bversus\b"
                r"|\bvs\.?\b|\bbetween\b",
                text,
                re.I,
            )
        )
    )
    multi_part = (
        1.0
        if re.search(
            r"\(a\)|\(b\)|\(i\)|\(ii\)|part\s+[a-d]|first.*then|step\s+\d",
            text,
            re.I,
        )
        else 0.0
    )
    which_of_following = (
        1.0
        if re.search(
            r"which\s+of\s+the\s+following|statement\s+\d",
            text,
            re.I,
        )
        else 0.0
    )

    # --- Technical Content (4) ---
    numeric_count = float(len(re.findall(r"\d+\.?\d*", text)))
    numeric_density = numeric_count / max(word_count, 1.0)
    formula_present = (
        1.0
        if re.search(
            r"[\^_]|\\frac|\\int|\\sum|\\text|\\lambda|\\sigma|\\delta|\$.*\$",
            text,
        )
        else 0.0
    )
    code_present = (
        1.0
        if re.search(
            r"```|def\s+\w+\(|class\s+\w+:|import\s+\w+"
            r"|function\s+\w+|\bvar\b\s+\w+|=>|\{.*\}",
            text,
        )
        else 0.0
    )

    # --- Reasoning Demand (3) ---
    calculation_demanded = (
        1.0
        if re.search(
            r"calculat|comput|determin|find\s+the|solve|evaluat"
            r"|what\s+is\s+the\s+value",
            text,
            re.I,
        )
        else 0.0
    )
    explanation_demanded = (
        1.0
        if re.search(
            r"\bexplain\b|\bdescribe\b|\bwhy\b|\bhow\s+does\b|\bjustify\b",
            text,
            re.I,
        )
        else 0.0
    )
    factual_lookup = (
        1.0
        if re.search(
            r"^(what\s+is|who\s+is|when\s+did|where\s+is|name\s+the)\b",
            text,
            re.I,
        )
        else 0.0
    )

    return [
        char_count,
        word_count,
        sentence_count,
        avg_word_length,
        vocabulary_richness,
        conditional_count,
        negation_count,
        comparison_count,
        multi_part,
        which_of_following,
        numeric_count,
        numeric_density,
        formula_present,
        code_present,
        calculation_demanded,
        explanation_demanded,
        factual_lookup,
    ]


def _extract_v2(text: str) -> List[float]:
    """Extract v2 features (15, length-invariant).

    All features are either ratios, densities, or binary flags — none scale
    with raw input length. This makes the classifier robust to prompts that
    embed long context (documents, articles, code blocks) alongside a short
    instruction.
    """
    words = text.split()
    unique_words = set(w.lower() for w in words)
    word_count = float(max(len(words), 1))
    sentences = [s for s in re.split(r"[.!?]+", text) if s.strip()]
    sentence_count = float(max(len(sentences), 1))

    # --- Ratios (2) — already length-invariant ---
    avg_word_length = (
        sum(len(w) for w in words) / len(words) if words else 0.0
    )
    vocabulary_richness = len(unique_words) / word_count

    # --- Density features (4) — counts normalized by sentence_count ---
    conditional_count = float(
        len(
            re.findall(
                r"\bif\b|\bgiven\b|\bassuming\b|\bsuppose\b|\bconsider\b"
                r"|\bwhen\b|\bwhere\b|\bsuch\s+that\b",
                text,
                re.I,
            )
        )
    )
    conditional_density = conditional_count / sentence_count

    negation_count = float(
        len(
            re.findall(
                r"\bnot\b|\bnever\b|\bexcept\b|\bunless\b|\bnone\b"
                r"|\bneither\b|\bwithout\b",
                text,
                re.I,
            )
        )
    )
    negation_density = negation_count / sentence_count

    comparison_count = float(
        len(
            re.findall(
                r"\bcompar\w*\b|\bdiffer\w*\b|\bsimilar\b|\bversus\b"
                r"|\bvs\.?\b|\bbetween\b",
                text,
                re.I,
            )
        )
    )
    comparison_density = comparison_count / sentence_count

    numeric_count = float(len(re.findall(r"\d+\.?\d*", text)))
    numeric_density = numeric_count / word_count

    # --- Binary structure (2) ---
    multi_part = (
        1.0
        if re.search(
            r"\(a\)|\(b\)|\(i\)|\(ii\)|part\s+[a-d]|first.*then|step\s+\d",
            text,
            re.I,
        )
        else 0.0
    )
    which_of_following = (
        1.0
        if re.search(
            r"which\s+of\s+the\s+following|statement\s+\d",
            text,
            re.I,
        )
        else 0.0
    )

    # --- Technical content (2) ---
    formula_present = (
        1.0
        if re.search(
            r"[\^_]|\\frac|\\int|\\sum|\\text|\\lambda|\\sigma|\\delta|\$.*\$",
            text,
        )
        else 0.0
    )
    code_present = (
        1.0
        if re.search(
            r"```|def\s+\w+\(|class\s+\w+:|import\s+\w+"
            r"|function\s+\w+|\bvar\b\s+\w+|=>|\{.*\}",
            text,
        )
        else 0.0
    )

    # --- Reasoning demand (3) ---
    calculation_demanded = (
        1.0
        if re.search(
            r"calculat|comput|determin|find\s+the|solve|evaluat"
            r"|what\s+is\s+the\s+value",
            text,
            re.I,
        )
        else 0.0
    )
    explanation_demanded = (
        1.0
        if re.search(
            r"\bexplain\b|\bdescribe\b|\bwhy\b|\bhow\s+does\b|\bjustify\b",
            text,
            re.I,
        )
        else 0.0
    )
    factual_lookup = (
        1.0
        if re.search(
            r"^(what\s+is|who\s+is|when\s+did|where\s+is|name\s+the)\b",
            text,
            re.I,
        )
        else 0.0
    )

    # --- New intent features (2) ---

    # task_verb_complexity: classify the main imperative verb
    # 0 = simple (define, list, translate, convert, name, state)
    # 1 = moderate (explain, compare, write, implement, summarize, create, describe)
    # 2 = complex (prove, design, evaluate, analyze, critique, derive, synthesize, debate)
    task_verb_complexity = 0.0
    if re.search(
        r"\b(prove|design|evaluat\w*|analy[zs]\w*|critiqu\w*|deriv\w*"
        r"|synthesi[zs]\w*|debat\w*|justif\w*|refut\w*|reconcil\w*"
        r"|architec\w*|optimiz\w*)\b",
        text,
        re.I,
    ):
        task_verb_complexity = 2.0
    elif re.search(
        r"\b(explain|compare|write|implement|summariz\w*|creat\w*"
        r"|describ\w*|discuss|develop|build|construct|demonstrat\w*"
        r"|compos\w*|generat\w*|produc\w*|formulat\w*)\b",
        text,
        re.I,
    ):
        task_verb_complexity = 1.0

    # output_constraint_count: number of specific output format constraints
    # More constraints often signals structured/economy tasks
    output_constraints = re.findall(
        r"\bas\s+json\b|\bin\s+json\b|\bjson\s+format\b"
        r"|\bexactly\s+\d+\b|\bunder\s+\d+\s+words\b|\bin\s+\d+\s+words\b"
        r"|\bbullet\s+points?\b|\bnumbered\s+list\b|\btable\s+format\b"
        r"|\bas\s+a\s+table\b|\bas\s+csv\b|\bas\s+xml\b"
        r"|\bmaximum\s+\d+\b|\bat\s+most\s+\d+\b|\bno\s+more\s+than\s+\d+\b"
        r"|\bin\s+one\s+sentence\b|\bin\s+\d+\s+sentences?\b"
        r"|\bwords?\s+max\b|\bword\s+limit\b",
        text,
        re.I,
    )
    output_constraint_count = float(len(output_constraints))

    return [
        avg_word_length,
        vocabulary_richness,
        conditional_density,
        negation_density,
        comparison_density,
        numeric_density,
        multi_part,
        which_of_following,
        formula_present,
        code_present,
        calculation_demanded,
        explanation_demanded,
        factual_lookup,
        task_verb_complexity,
        output_constraint_count,
    ]


def _extract_v3(text: str) -> List[float]:
    """Extract v3 features (27 = 15 from v2 + 12 structural complexity).

    Adds denser difficulty signals: entity introductions, reference chains,
    logical connectives, clause depth, question count, step indicators,
    constraints, domain jargon, proof demands, examples, structured input,
    and prompt length buckets.
    """
    # Start with all v2 features
    v2_feats = _extract_v2(text)

    words = text.split()
    word_count = float(max(len(words), 1))
    sentences = [s for s in re.split(r"[.!?]+", text) if s.strip()]
    sentence_count = float(max(len(sentences), 1))

    # --- Structural complexity (5) ---

    # Entity introductions: "let X", "given X", "define X", variable assignments
    entity_introduction_count = float(
        len(
            re.findall(
                r"\blet\s+\$?\w|\bgiven\s+(?:that\s+)?\$?\w|\bdefine\s+\w"
                r"|\bdenote\s+\w|\bsuppose\s+\$?\w|\bassume\s+\$?\w",
                text,
                re.I,
            )
        )
    )

    # Reference chain length: unique single-letter math variables
    math_vars = set(re.findall(r"\$([a-zA-Z])\$", text))
    # Also match standalone single-letter variables in math context
    math_vars.update(re.findall(r"(?<=\s)([a-zA-Z])(?=\s*[=<>+\-*/^])", text))
    reference_chain_length = float(len(math_vars))

    # Logical connective density
    logical_connectives = re.findall(
        r"\bimplies\b|\biff\b|\btherefore\b|\bhence\b|\bthus\b"
        r"|\bconsequently\b|\bmoreover\b|\bfurthermore\b|\bhowever\b"
        r"|\bnevertheless\b|\bin\s+particular\b|\bspecifically\b",
        text,
        re.I,
    )
    logical_connective_density = float(len(logical_connectives)) / sentence_count

    # Clause depth proxy: avg commas + semicolons per sentence
    clause_markers = float(len(re.findall(r"[,;]", text)))
    clause_depth_proxy = clause_markers / sentence_count

    # Question count
    question_count = float(len(re.findall(r"\?", text)))

    # --- Reasoning demand (4) ---

    # Step indicators: sequential reasoning markers
    step_indicator_count = float(
        len(
            re.findall(
                r"\bfirst(?:ly)?\b|\bthen\b|\bnext\b|\bfinally\b"
                r"|\bstep\s+\d|\bafter\s+that\b|\bsubsequently\b"
                r"|\bfollowed\s+by\b|\bin\s+turn\b",
                text,
                re.I,
            )
        )
    )

    # Constraint count
    constraint_count = float(
        len(
            re.findall(
                r"\bmust\b|\bshould\b|\bat\s+least\b|\bat\s+most\b"
                r"|\bexactly\b|\bbetween\b.*\band\b|\bno\s+(?:more|fewer|less)\s+than\b"
                r"|\brequire[sd]?\b|\bconstraint\w*\b|\bcondition\w*\b"
                r"|\bensure\b|\bguarantee\b",
                text,
                re.I,
            )
        )
    )

    # Domain jargon density: ratio of words > 10 chars
    long_words = [w for w in words if len(w) > 10]
    domain_jargon_density = float(len(long_words)) / word_count

    # Proof demand
    proof_demand = (
        1.0
        if re.search(
            r"\bprov(?:e|ing)\b|\bshow\s+that\b|\bdemonstrat(?:e|ing)\s+that\b"
            r"|\bverif(?:y|ying)\s+that\b|\bestablish\b|\bconfirm\s+that\b"
            r"|\bdisprove\b|\brefute\b",
            text,
            re.I,
        )
        else 0.0
    )

    # --- Format complexity (3) ---

    # Has examples
    has_examples = (
        1.0
        if re.search(
            r"\bfor\s+example\b|\be\.g\.\b|\bsuch\s+as\b|\bfor\s+instance\b"
            r"|\bincluding\b.*\band\b",
            text,
            re.I,
        )
        else 0.0
    )

    # Has structured input (code blocks, tables, matrices, JSON)
    has_structured_input = (
        1.0
        if re.search(
            r"```|\|\s*-+\s*\||\bmatrix\b|\[\[.*\]\]"
            r"|\{.*\".*\":|\binput\s*:|output\s*:",
            text,
            re.I,
        )
        else 0.0
    )

    # Prompt length bucket (nonlinear)
    wc = len(words)
    if wc < 20:
        prompt_length_bucket = 0.0
    elif wc < 50:
        prompt_length_bucket = 1.0
    elif wc < 150:
        prompt_length_bucket = 2.0
    else:
        prompt_length_bucket = 3.0

    return v2_feats + [
        entity_introduction_count,
        reference_chain_length,
        logical_connective_density,
        clause_depth_proxy,
        question_count,
        step_indicator_count,
        constraint_count,
        domain_jargon_density,
        proof_demand,
        has_examples,
        has_structured_input,
        prompt_length_bucket,
    ]


def extract_prompt_features(
    text: str,
    choices: Optional[List[str]] = None,
    version: int = 1,
) -> List[float]:
    """Extract prompt complexity features from text.

    All features are computable from prompt text alone via regex — runs in
    microseconds at inference time. No external dependencies beyond ``re``.

    Args:
        text: The prompt text to extract features from.
        choices: Optional list of answer choices (for multiple-choice tasks).
        version: Feature version (1 = original 17 features,
                 2 = length-invariant 15 features). Default 1 for backward
                 compatibility.

    Returns:
        List of float feature values.
    """
    if version == 3:
        feats = _extract_v3(text)
    elif version == 2:
        feats = _extract_v2(text)
    else:
        feats = _extract_v1(text)

    # Choice structure features (same for both versions)
    if choices is not None and len(choices) > 0:
        choice_count = float(len(choices))
        avg_choice_len = sum(len(c) for c in choices) / len(choices)
        max_choice_len = float(max(len(c) for c in choices))
        feats.extend([choice_count, avg_choice_len, max_choice_len])

    return feats


def get_feature_names(version: int = 1, with_choices: bool = False) -> List[str]:
    """Get feature names for a given version.

    Args:
        version: Feature version (1 or 2).
        with_choices: Whether to include choice features.

    Returns:
        List of feature name strings.
    """
    if version == 3:
        names = list(FEATURE_NAMES_V3)
    elif version == 2:
        names = list(FEATURE_NAMES_V2)
    else:
        names = list(FEATURE_NAMES_V1)
    if with_choices:
        names.extend(FEATURE_NAMES_CHOICES)
    return names
