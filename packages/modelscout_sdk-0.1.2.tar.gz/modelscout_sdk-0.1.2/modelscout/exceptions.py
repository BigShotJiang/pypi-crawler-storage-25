"""ModelScout SDK exceptions."""

from typing import Any, Dict, Optional


class ModelScoutError(Exception):
    """Base exception for ModelScout SDK errors."""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.details = details or {}
        super().__init__(message)

    def __str__(self) -> str:
        if self.details:
            return f"{self.message} - {self.details}"
        return self.message


class APIError(ModelScoutError):
    """Error from the ModelScout API.

    Attributes:
        status_code: HTTP status code from the API response.
        code: Error code from the API (e.g., "DATASET_NOT_FOUND").
        retry_after: Seconds to wait before retrying (for rate limits).
    """

    def __init__(
        self,
        message: str,
        status_code: int,
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        retry_after: Optional[float] = None,
    ):
        self.status_code = status_code
        self.code = code
        self.retry_after = retry_after
        super().__init__(message, details)

    def __str__(self) -> str:
        base = f"[{self.status_code}]"
        if self.code:
            base += f" {self.code}:"
        base += f" {self.message}"
        return base


class AuthenticationError(APIError):
    """Authentication failed (401 Unauthorized).

    This usually means the API key is invalid or expired.
    """

    def __init__(
        self,
        message: str = "Authentication failed. Check your API key.",
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, status_code=401, code="UNAUTHORIZED", details=details)


class NotFoundError(APIError):
    """Resource not found (404 Not Found).

    The requested dataset, evaluation, or other resource doesn't exist
    or you don't have access to it.
    """

    def __init__(
        self,
        message: str = "Resource not found",
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, status_code=404, code=code or "NOT_FOUND", details=details)


class ValidationError(APIError):
    """Request validation failed (400 Bad Request).

    The request was malformed or contained invalid data.
    """

    def __init__(
        self,
        message: str = "Validation error",
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, status_code=400, code=code or "VALIDATION_ERROR", details=details)


class RateLimitError(APIError):
    """Rate limit exceeded (429 Too Many Requests).

    You've exceeded the API rate limit. Wait before retrying.

    Attributes:
        retry_after: Seconds to wait before retrying (if provided).
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(
            message, status_code=429, code="RATE_LIMITED", details=details, retry_after=retry_after
        )


class ConcurrencyLimitError(APIError):
    """Concurrency limit exceeded (429 Too Many Requests).

    Your organization has reached its maximum concurrent request limit.
    Wait for existing requests to complete before retrying.

    This is different from rate limiting - it's about simultaneous requests,
    not requests per time window.

    Attributes:
        max_concurrent: Maximum allowed concurrent requests for your tier.
        retry_after: Suggested seconds to wait before retrying.
    """

    def __init__(
        self,
        message: str = "Concurrency limit exceeded",
        max_concurrent: Optional[int] = None,
        retry_after: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.max_concurrent = max_concurrent
        super().__init__(
            message,
            status_code=429,
            code="CONCURRENCY_LIMIT_EXCEEDED",
            details=details or {
                "max_concurrent": max_concurrent,
            },
            retry_after=retry_after,
        )

    def __str__(self) -> str:
        base = f"[429] CONCURRENCY_LIMIT_EXCEEDED: {self.message}"
        if self.max_concurrent is not None:
            base += f" (limit: {self.max_concurrent})"
        if self.retry_after is not None:
            base += f" - retry after {self.retry_after}s"
        return base


class TierRestrictionError(APIError):
    """Feature requires a higher subscription tier (403 Forbidden).

    The requested feature (e.g., benchmarking, custom routing configs) is not
    available on your current subscription tier.

    Attributes:
        current_tier: Your organization's current subscription tier.
        required_tier: The minimum tier required for this feature.
    """

    def __init__(
        self,
        message: str = "This feature requires a higher subscription tier",
        current_tier: Optional[str] = None,
        required_tier: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.current_tier = current_tier
        self.required_tier = required_tier
        super().__init__(
            message,
            status_code=403,
            code="TIER_RESTRICTION",
            details=details or {
                "current_tier": current_tier,
                "required_tier": required_tier,
            },
        )

    def __str__(self) -> str:
        base = f"[403] TIER_RESTRICTION: {self.message}"
        if self.current_tier and self.required_tier:
            base += f" (current: {self.current_tier}, required: {self.required_tier})"
        return base


class TimeoutError(ModelScoutError):
    """Operation timed out.

    This can happen during:
    - Agent execution (task took too long)
    - API requests (network issues)
    - Polling for results (evaluation took too long)
    """

    def __init__(
        self,
        message: str = "Operation timed out",
        timeout_seconds: Optional[float] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.timeout_seconds = timeout_seconds
        super().__init__(message, details)


class AgentExecutionError(ModelScoutError):
    """Error during agent execution.

    The agent raised an exception while processing a task.

    Attributes:
        task_id: ID of the task that failed.
        original_error: The exception raised by the agent.
    """

    def __init__(
        self,
        message: str,
        task_id: str,
        original_error: Optional[Exception] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.task_id = task_id
        self.original_error = original_error
        super().__init__(message, details)


class MaxIterationsError(ModelScoutError):
    """Agent tool loop exceeded maximum iterations.

    The agent kept making tool calls beyond the allowed limit,
    possibly indicating an infinite loop.

    Attributes:
        iterations: Number of iterations before stopping.
        max_iterations: The configured maximum.
    """

    def __init__(
        self,
        iterations: int,
        max_iterations: int,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.iterations = iterations
        self.max_iterations = max_iterations
        message = f"Agent exceeded max iterations ({iterations}/{max_iterations})"
        super().__init__(message, details)


class ProviderError(ModelScoutError):
    """Error from an LLM provider.

    Wraps provider-specific errors (OpenAI, Anthropic, etc.) into a unified
    exception with retry information.

    Attributes:
        provider: The provider that raised the error (e.g., "openai").
        model: The model that was called.
        status_code: HTTP status code if available.
        retry_after: Seconds to wait before retrying (for rate limits).
        is_retryable: Whether this error can be retried (429, 5xx).
    """

    def __init__(
        self,
        message: str,
        provider: str,
        model: str,
        status_code: Optional[int] = None,
        retry_after: Optional[float] = None,
        is_retryable: bool = False,
        original_error: Optional[Exception] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.provider = provider
        self.model = model
        self.status_code = status_code
        self.retry_after = retry_after
        self.is_retryable = is_retryable
        self.original_error = original_error
        super().__init__(message, details)

    def __str__(self) -> str:
        parts = [f"[{self.provider}/{self.model}]"]
        if self.status_code:
            parts.append(f"[{self.status_code}]")
        parts.append(self.message)
        return " ".join(parts)


class AllProvidersFailedError(ModelScoutError):
    """All providers in the fallback chain failed.

    Raised when retry and fallback attempts are exhausted across all
    providers in the chain.

    Attributes:
        attempts: List of all provider attempts with details.
        total_latency_ms: Total time spent across all attempts.
        last_error: The last error that occurred.
    """

    def __init__(
        self,
        message: str,
        attempts: list,
        total_latency_ms: float,
        last_error: Optional[Exception] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.attempts = attempts
        self.total_latency_ms = total_latency_ms
        self.last_error = last_error
        super().__init__(message, details)

    def summary(self) -> str:
        """Get a human-readable summary of all attempts."""
        lines = [f"All providers failed after {len(self.attempts)} attempts:"]
        for i, attempt in enumerate(self.attempts):
            status = "OK" if attempt.success else f"FAILED ({attempt.failure_reason})"
            lines.append(
                f"  {i + 1}. {attempt.provider}/{attempt.model}: {status} "
                f"({attempt.latency_ms:.0f}ms)"
            )
        lines.append(f"Total latency: {self.total_latency_ms:.0f}ms")
        return "\n".join(lines)


# =============================================================================
# Billing & Quota Errors
# =============================================================================


class MatchEnforcementError(ModelScoutError):
    """Match blocked by core enforcement (expired config or exhausted quota).

    Raised when the compiled core refuses to match because:
    - Config TTL has expired and refresh failed
    - Match counter reached zero and refresh failed

    This is distinct from QuotaExceededError (monthly API-level quota).
    MatchEnforcementError is a local enforcement gate inside the compiled core.

    Attributes:
        reason: "expired" or "quota_exhausted"
    """

    def __init__(
        self,
        message: str,
        reason: str = "unknown",
        details: Optional[Dict[str, Any]] = None,
    ):
        self.reason = reason
        super().__init__(message, details)

    def __str__(self) -> str:
        return f"[{self.reason}] {self.message}"


class BillingConfigurationError(ModelScoutError):
    """Billing is not properly configured to use ModelRoute routing.

    This error is raised early (at load time) when:
    - API key is missing
    - API key is invalid
    - Cannot connect to ModelScout API

    This is a configuration error, not a runtime error. Fix the configuration
    and retry.

    Example:
        >>> engine = ModelRoute()  # No API key
        >>> engine.load_template("general-purpose")
        BillingConfigurationError: API key required for routing decisions.
        Set api_key parameter or MODELSCOUT_API_KEY environment variable.
    """

    def __init__(
        self,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, details)


class QuotaExceededError(APIError):
    """Monthly match quota has been exhausted (429 Too Many Requests).

    Raised when:
    - Free tier: 5,000 matches/month hard limit reached
    - Paid tiers: Monthly quota exceeded

    Attributes:
        used: Number of matches used this month.
        limit: Monthly match limit for your tier.
        tier: Your subscription tier.

    Example:
        >>> engine.load_template("general-purpose")
        QuotaExceededError: Monthly match quota exhausted (5000/5000).
        Upgrade your plan or wait for quota reset.
    """

    def __init__(
        self,
        message: str = "Monthly match quota exceeded",
        used: Optional[int] = None,
        limit: Optional[int] = None,
        tier: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.used = used
        self.limit = limit
        self.tier = tier
        super().__init__(
            message,
            status_code=429,
            code="QUOTA_EXCEEDED",
            details=details or {
                "used": used,
                "limit": limit,
                "tier": tier,
            },
        )

    def __str__(self) -> str:
        base = f"[429] QUOTA_EXCEEDED: {self.message}"
        if self.used is not None and self.limit is not None:
            base += f" ({self.used}/{self.limit})"
        if self.tier:
            base += f" [tier: {self.tier}]"
        return base


class BillingError(ModelScoutError):
    """Runtime billing operation failed.

    This error occurs during match operations when billing cannot be completed,
    such as:
    - Network errors when reporting match decisions
    - API errors during billing

    Unlike BillingConfigurationError, this is a runtime error that may be
    transient. The match decision itself was valid, but billing may be delayed.

    Attributes:
        unreported_count: Number of match decisions that couldn't be reported.
        original_error: The underlying error that caused the failure.
    """

    def __init__(
        self,
        message: str,
        unreported_count: Optional[int] = None,
        original_error: Optional[Exception] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.unreported_count = unreported_count
        self.original_error = original_error
        super().__init__(message, details)

    def __str__(self) -> str:
        base = self.message
        if self.unreported_count is not None:
            base += f" ({self.unreported_count} unreported matches)"
        return base


# =============================================================================
# Configuration & State Errors
# =============================================================================


class ConfigNotLoadedError(ModelScoutError):
    """Routing configuration has not been loaded.

    This error is raised when attempting to use routing functionality
    (match, get_regions, etc.) before calling load() or load_template().

    This is a programming error - ensure the config is loaded before use.

    Example:
        >>> engine = ModelRoute(api_key="ms_...")
        >>> engine.match("hello")  # Forgot to call load()
        ConfigNotLoadedError: Routing config not loaded.
        Call load() or load_template() before using match().

    Fix:
        >>> engine = ModelRoute(api_key="ms_...")
        >>> engine.load_template("general-purpose")  # Load first
        >>> engine.match("hello")  # Now it works
    """

    def __init__(
        self,
        message: str = "Routing config not loaded. Call load() or load_template() first.",
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, details)


class ConfigParseError(ModelScoutError):
    """Failed to parse routing configuration or token metadata.

    This error is raised when:
    - Token file is corrupted or has invalid JSON
    - Config data has unexpected structure
    - Required fields are missing from config

    Attributes:
        file_path: Path to the file that failed to parse (if applicable).
        original_error: The underlying parsing error.
    """

    def __init__(
        self,
        message: str,
        file_path: Optional[str] = None,
        original_error: Optional[Exception] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.file_path = file_path
        self.original_error = original_error
        super().__init__(message, details)

    def __str__(self) -> str:
        base = self.message
        if self.file_path:
            base += f" (file: {self.file_path})"
        return base


class EmbeddingError(ModelScoutError):
    """Error computing or validating embeddings.

    This error is raised when:
    - Embedding computation fails
    - Embedding dimensions don't match expected size
    - Zero-norm vectors are detected (degenerate embeddings)

    Attributes:
        expected_dim: Expected embedding dimension (e.g., 384).
        actual_dim: Actual dimension received.
    """

    def __init__(
        self,
        message: str,
        expected_dim: Optional[int] = None,
        actual_dim: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        self.expected_dim = expected_dim
        self.actual_dim = actual_dim
        super().__init__(message, details)

    def __str__(self) -> str:
        base = self.message
        if self.expected_dim is not None and self.actual_dim is not None:
            base += f" (expected {self.expected_dim}d, got {self.actual_dim}d)"
        return base
