"""Setup script for modelscout (open-source wrapper).

The modelscout package is the open-source orchestration layer that handles:
- Config fetching, decryption, caching
- LLM vendor calls (API key handling)
- Gateway wrappers (LiteLLM, OpenRouter, etc.)
- Billing/quota tracking
- ModelRoute lifecycle

All matching intelligence lives in the separate modelscout-core package
(closed-source, Cython-compiled).
"""

from setuptools import setup

setup()
