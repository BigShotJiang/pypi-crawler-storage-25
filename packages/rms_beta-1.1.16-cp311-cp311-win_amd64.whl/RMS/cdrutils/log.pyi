from ..const.config import Config
from datetime import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
import os
from PyQt5.QtCore import QObject, pyqtSignal
class LogSignalEmitter(QObject):
    sig_log = pyqtSignal(str)

class CDRLog:
    text_edit = None
    emitter = LogSignalEmitter()
    def __init__(self, log_file: str, when: str = 'midnight', interval: int = 1, backup_count: int = 7, level: int = logging.INFO, log_format: str = None): ...
    def get_logger(self) -> logging.Logger: ...
    @classmethod
    def set_text_edit(cls, text_edit): ...
    @classmethod
    def print(cls, msg: object, **kwargs): ...
    @classmethod
    def Log(self, msg: object): ...

