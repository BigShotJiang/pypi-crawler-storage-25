"""Tests for the ODX-D (Diagnostic Data) XML serializer."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest
from lxml import etree

from udsxml2tex import ArxmlParser
from udsxml2tex.odx import (
    AdminData,
    Audience,
    BaseVariant,
    CompanyData,
    CompuMethod,
    CompuScale,
    DataObjectProp,
    DiagCodedType,
    DiagDataDictionarySpec,
    DiagLayerContainer,
    DiagService,
    DocRevision,
    Dtc,
    DtcDop,
    EcuVariant,
    EcuVariantPattern,
    FunctionalClass,
    OdxCategory,
    OdxDocument,
    OdxRef,
    Param,
    PhysicalType,
    Protocol,
    Request,
    SnRef,
    SpecialDataGroup,
    Structure,
    Table,
    TableRow,
    Unit,
    UnitGroup,
    UnitSpec,
    map_spec_to_odx,
)
from udsxml2tex.odx.serializers.odx_d import serialize_odx_d, write_odx_d

XSI = "http://www.w3.org/2001/XMLSchema-instance"
XSI_TYPE = f"{{{XSI}}}type"

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_doc(dlc: DiagLayerContainer) -> OdxDocument:
    """Wrap ``dlc`` into a minimal :class:`OdxDocument` of DIAG_LAYER category."""
    return OdxDocument(
        category=OdxCategory.DIAG_LAYER,
        diag_layer_container=dlc,
        pdx_member_path=f"{dlc.short_name}.odx-d",
    )


def _parse(payload: bytes) -> etree._Element:
    """Parse a serialized ODX-D byte string back into an ``Element`` tree."""
    return etree.fromstring(payload)


# ---------------------------------------------------------------------------
# 1. Empty / minimal documents
# ---------------------------------------------------------------------------


class TestEmptyAndMinimal:
    """Empty and minimal containers serialize to well-formed XML."""

    def test_empty_dlc_well_formed(self):
        dlc = DiagLayerContainer(oid="udsxml2tex.odx.d.dlc.Empty",
                                 short_name="EmptyDLC")
        payload = serialize_odx_d(_make_doc(dlc))
        root = _parse(payload)
        assert root.tag == "ODX"
        assert root.get("MODEL-VERSION") == "2.2.0"
        # Exactly one DLC child, no other layer-collection wrappers.
        assert len(root) == 1
        assert root[0].tag == "DIAG-LAYER-CONTAINER"

    def test_empty_dlc_has_xsi_namespace(self):
        payload = serialize_odx_d(_make_doc(DiagLayerContainer(short_name="X")))
        assert b'xmlns:xsi="' in payload

    def test_xml_declaration_present(self):
        payload = serialize_odx_d(_make_doc(DiagLayerContainer(short_name="X")))
        assert payload.startswith(b"<?xml")
        assert b'encoding=\'UTF-8\'' in payload or b'encoding="UTF-8"' in payload
        assert b'standalone="no"' in payload or b"standalone='no'" in payload

    def test_minimal_base_variant_has_short_name(self):
        bv = BaseVariant(oid="udsxml2tex.odx.d.bv.X", short_name="MyEcu")
        dlc = DiagLayerContainer(short_name="DLC", base_variants=[bv])
        root = _parse(serialize_odx_d(_make_doc(dlc)))
        bvs = root.findall(".//BASE-VARIANT")
        assert len(bvs) == 1
        sn = bvs[0].find("SHORT-NAME")
        assert sn is not None
        assert sn.text == "MyEcu"
        assert bvs[0].get("ID") == "udsxml2tex.odx.d.bv.X"

    def test_optional_long_name_omitted_when_none(self):
        # short_name only — long_name is None — no LONG-NAME element.
        bv = BaseVariant(short_name="X")
        dlc = DiagLayerContainer(short_name="DLC", base_variants=[bv])
        root = _parse(serialize_odx_d(_make_doc(dlc)))
        bv_el = root.find(".//BASE-VARIANT")
        assert bv_el is not None
        assert bv_el.find("LONG-NAME") is None

    def test_empty_short_name_still_emits_element(self):
        # short_name == "" — the element is still emitted with empty text.
        dlc = DiagLayerContainer(short_name="")
        root = _parse(serialize_odx_d(_make_doc(dlc)))
        dlc_el = root.find("DIAG-LAYER-CONTAINER")
        sn = dlc_el.find("SHORT-NAME")
        assert sn is not None


# ---------------------------------------------------------------------------
# 2. DOP / DiagCodedType / PhysicalType
# ---------------------------------------------------------------------------


class TestDopSerialization:
    """DataObjectProp emission across base-data-types and coded-type variants."""

    @pytest.mark.parametrize("base_type", [
        "A_UINT32", "A_INT32", "A_FLOAT32", "A_FLOAT64",
        "A_ASCIISTRING", "A_UNICODE2STRING", "A_BYTEFIELD",
    ])
    def test_each_base_data_type(self, base_type):
        dop = DataObjectProp(
            oid="udsxml2tex.odx.d.dop.X",
            short_name="DopX",
            diag_coded_type=DiagCodedType(base_data_type=base_type, bit_length=16),
            physical_type=PhysicalType(base_data_type=base_type),
        )
        ddds = DiagDataDictionarySpec(data_object_props=[dop])
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        dlc = DiagLayerContainer(short_name="DLC", base_variants=[bv])
        root = _parse(serialize_odx_d(_make_doc(dlc)))
        dct = root.find(".//DIAG-CODED-TYPE")
        assert dct.get("BASE-DATA-TYPE") == base_type
        pt = root.find(".//PHYSICAL-TYPE")
        assert pt.get("BASE-DATA-TYPE") == base_type

    @pytest.mark.parametrize("coded", [
        "STANDARD-LENGTH-TYPE",
        "LEADING-LENGTH-INFO-TYPE",
        "MIN-MAX-LENGTH-TYPE",
        "PARAM-LENGTH-INFO-TYPE",
    ])
    def test_each_coded_type_discriminator(self, coded):
        dop = DataObjectProp(
            oid="udsxml2tex.odx.d.dop.X",
            short_name="DopX",
            diag_coded_type=DiagCodedType(coded_type=coded, bit_length=8),
        )
        ddds = DiagDataDictionarySpec(data_object_props=[dop])
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        dlc = DiagLayerContainer(short_name="DLC", base_variants=[bv])
        root = _parse(serialize_odx_d(_make_doc(dlc)))
        dct = root.find(".//DIAG-CODED-TYPE")
        assert dct.get(XSI_TYPE) == coded

    def test_dop_compu_method_identical(self):
        dop = DataObjectProp(
            oid="x.y", short_name="DopX",
            compu_method=CompuMethod(category="IDENTICAL"),
            diag_coded_type=DiagCodedType(bit_length=8),
        )
        ddds = DiagDataDictionarySpec(data_object_props=[dop])
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        cat = root.find(".//COMPU-METHOD/CATEGORY")
        assert cat.text == "IDENTICAL"

    def test_dop_compu_method_linear_scales(self):
        scale = CompuScale(
            lower_limit="0", upper_limit="255",
            compu_rational_coeffs=([0.0, 0.5], [1.0]),
        )
        dop = DataObjectProp(
            short_name="LinDop", oid="x.lin",
            compu_method=CompuMethod(
                category="LINEAR",
                compu_internal_to_phys=[scale],
            ),
        )
        ddds = DiagDataDictionarySpec(data_object_props=[dop])
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        coeffs = root.find(".//COMPU-RATIONAL-COEFFS")
        assert coeffs is not None
        nums = coeffs.findall("COMPU-NUMERATOR/V")
        assert [n.text for n in nums] == ["0.0", "0.5"]

    def test_dop_unit_ref_present(self):
        dop = DataObjectProp(
            short_name="WithUnit", oid="x.u",
            unit_ref=OdxRef(id_ref="udsxml2tex.odx.d.unit.rpm"),
            diag_coded_type=DiagCodedType(bit_length=8),
        )
        ddds = DiagDataDictionarySpec(data_object_props=[dop])
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        ur = root.find(".//UNIT-REF")
        assert ur is not None
        assert ur.get("ID-REF") == "udsxml2tex.odx.d.unit.rpm"


# ---------------------------------------------------------------------------
# 3. DiagService — all ref types
# ---------------------------------------------------------------------------


class TestDiagService:
    """DiagService emits attributes, audience, and every reference list."""

    def test_diag_service_all_attributes(self):
        svc = DiagService(
            oid="x.svc",
            short_name="RDBI_VIN",
            semantic="DATA",
            is_executable=True,
            addressing="PHYSICAL",
            transmission_mode="SEND-OR-RECEIVE",
            audience=Audience(),
            request_ref=OdxRef(id_ref="rq.oid"),
            pos_response_refs=[OdxRef(id_ref="pr.oid")],
            neg_response_refs=[OdxRef(id_ref="nr.oid")],
            functional_class_refs=[OdxRef(id_ref="fc.oid")],
            comparam_refs=[OdxRef(id_ref="cp.oid")],
        )
        bv = BaseVariant(short_name="BV", diag_comms=[svc])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        s = root.find(".//DIAG-SERVICE")
        assert s.get("SEMANTIC") == "DATA"
        assert s.get("ADDRESSING") == "PHYSICAL"
        assert s.get("IS-EXECUTABLE") == "true"
        assert s.get("TRANSMISSION-MODE") == "SEND-OR-RECEIVE"
        assert s.find("AUDIENCE") is not None
        assert s.find("REQUEST-REF").get("ID-REF") == "rq.oid"
        assert s.find("POS-RESPONSE-REFS/POS-RESPONSE-REF").get("ID-REF") == "pr.oid"
        assert s.find("NEG-RESPONSE-REFS/NEG-RESPONSE-REF").get("ID-REF") == "nr.oid"
        assert s.find("FUNCT-CLASS-REFS/FUNCT-CLASS-REF").get("ID-REF") == "fc.oid"
        assert s.find("COMPARAM-REFS/COMPARAM-REF").get("ID-REF") == "cp.oid"

    def test_diag_service_omits_empty_ref_lists(self):
        svc = DiagService(short_name="X", request_ref=OdxRef(id_ref="r"))
        bv = BaseVariant(short_name="BV", diag_comms=[svc])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        s = root.find(".//DIAG-SERVICE")
        assert s.find("POS-RESPONSE-REFS") is None
        assert s.find("NEG-RESPONSE-REFS") is None
        assert s.find("FUNCT-CLASS-REFS") is None
        assert s.find("AUDIENCE") is None


# ---------------------------------------------------------------------------
# 4. Param kinds
# ---------------------------------------------------------------------------


class TestParamKinds:
    """Every PARAM kind round-trips its xsi:type discriminator."""

    @pytest.mark.parametrize("kind", [
        "VALUE", "PHYS-CONST", "CODED-CONST", "RESERVED",
        "MATCHING-REQUEST-PARAM", "TABLE-KEY", "TABLE-STRUCT",
        "TABLE-ENTRY", "NRC-CONST",
    ])
    def test_param_kind_round_trip(self, kind):
        params = [Param(
            short_name="P", byte_position=0, bit_length=8,
            semantic="DATA", param_kind=kind, coded_value=0x55,
            dop_ref=OdxRef(id_ref="dop.oid") if kind == "VALUE" else None,
        )]
        req = Request(short_name="RQ", oid="rq.oid", params=params)
        bv = BaseVariant(short_name="BV", requests=[req])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        param = root.find(".//PARAM")
        assert param.get(XSI_TYPE) == kind

    def test_param_value_prefers_dop_ref_over_snref(self):
        p = Param(
            short_name="VinParam",
            byte_position=1,
            param_kind="VALUE",
            dop_ref=OdxRef(id_ref="dop.id.preferred"),
            dop_snref=SnRef(short_name="snref_fallback"),
        )
        req = Request(short_name="RQ", oid="rq.oid", params=[p])
        bv = BaseVariant(short_name="BV", requests=[req])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        param = root.find(".//PARAM")
        dop_ref = param.find("DOP-REF")
        snref = param.find("DOP-SNREF")
        assert dop_ref is not None
        assert dop_ref.get("ID-REF") == "dop.id.preferred"
        assert snref is None

    def test_param_uses_snref_when_no_id_ref(self):
        p = Param(
            short_name="P", byte_position=0,
            param_kind="VALUE",
            dop_snref=SnRef(short_name="MySn"),
        )
        req = Request(short_name="RQ", oid="rq.oid", params=[p])
        bv = BaseVariant(short_name="BV", requests=[req])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        param = root.find(".//PARAM")
        assert param.find("DOP-REF") is None
        assert param.find("DOP-SNREF").get("SHORT-NAME") == "MySn"

    def test_coded_const_param_emits_coded_value_decimal(self):
        p = Param(short_name="SID", byte_position=0, bit_length=8,
                  param_kind="CODED-CONST", coded_value=0x22)
        req = Request(short_name="RQ", oid="rq.oid", params=[p])
        bv = BaseVariant(short_name="BV", requests=[req])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        cv = root.find(".//PARAM/CODED-VALUE")
        assert cv.text == "34"  # 0x22 == 34


# ---------------------------------------------------------------------------
# 5. DTC / DTC-DOP
# ---------------------------------------------------------------------------


class TestDtcDop:
    """DTC-DOP with multiple DTCs is serialized in order."""

    def test_multiple_dtcs(self):
        dtcs = [
            Dtc(oid="x.dtc.A", short_name="DtcA", trouble_code=0x100001,
                display_trouble_code="P0001", text="A"),
            Dtc(oid="x.dtc.B", short_name="DtcB", trouble_code=0x100002,
                display_trouble_code="P0002", text="B", level=0x40),
            Dtc(oid="x.dtc.C", short_name="DtcC", trouble_code=0x100003,
                display_trouble_code="P0003", text="C", is_temporary=True),
        ]
        dtc_dop = DtcDop(short_name="DtcDop", oid="x.dop", dtcs=dtcs)
        ddds = DiagDataDictionarySpec(dtc_dops=[dtc_dop])
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        items = root.findall(".//DTC")
        assert len(items) == 3
        # Order preserved.
        assert items[0].find("TROUBLE-CODE").text == str(0x100001)
        assert items[1].find("TROUBLE-CODE").text == str(0x100002)
        assert items[2].find("TROUBLE-CODE").text == str(0x100003)
        # Optional fields appear only when set.
        assert items[0].find("LEVEL") is None
        assert items[1].find("LEVEL").text == str(0x40)
        assert items[2].find("IS-TEMPORARY").text == "true"


# ---------------------------------------------------------------------------
# 6. AdminData / DocRevision
# ---------------------------------------------------------------------------


class TestAdminData:
    """ADMIN-DATA full round trip."""

    def test_admin_data_full(self):
        rev = DocRevision(
            team_member_ref="tm.oid",
            revision_label="0.1.0",
            state="RELEASED",
            date=datetime(2026, 5, 14, 0, 0, 0),
            tool="udsxml2tex/0.37.0",
        )
        ad = AdminData(
            language="en-US",
            company_doc_infos=[
                CompanyData(oid="company.acme", short_name="Acme",
                            roles=["MANUFACTURER"]),
            ],
            doc_revisions=[rev],
        )
        dlc = DiagLayerContainer(short_name="DLC", admin_data=ad)
        root = _parse(serialize_odx_d(_make_doc(dlc)))
        ad_el = root.find(".//ADMIN-DATA")
        assert ad_el is not None
        assert ad_el.find("LANGUAGE").text == "en-US"
        assert ad_el.find(".//COMPANY-DATA-REF").get("ID-REF") == "company.acme"
        drev = ad_el.find(".//DOC-REVISION")
        assert drev.find("REVISION-LABEL").text == "0.1.0"
        assert drev.find("STATE").text == "RELEASED"
        assert drev.find("DATE").text == "2026-05-14T00:00:00Z"
        assert drev.find("TOOL").text == "udsxml2tex/0.37.0"

    def test_admin_data_string_date_passthrough(self):
        rev = DocRevision(date="2025-01-02T03:04:05Z")
        ad = AdminData(doc_revisions=[rev])
        dlc = DiagLayerContainer(short_name="DLC", admin_data=ad)
        root = _parse(serialize_odx_d(_make_doc(dlc)))
        assert root.find(".//DATE").text == "2025-01-02T03:04:05Z"

    def test_admin_data_omitted_when_none(self):
        dlc = DiagLayerContainer(short_name="DLC", admin_data=None)
        root = _parse(serialize_odx_d(_make_doc(dlc)))
        assert root.find(".//ADMIN-DATA") is None


# ---------------------------------------------------------------------------
# 7. Audience
# ---------------------------------------------------------------------------


class TestAudience:
    """AUDIENCE element carries the 5 standard booleans."""

    def test_audience_all_true(self):
        svc = DiagService(short_name="S", audience=Audience())
        bv = BaseVariant(short_name="BV", diag_comms=[svc])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        a = root.find(".//AUDIENCE")
        for flag in ("IS-SUPPLIER", "IS-DEVELOPMENT", "IS-MANUFACTURING",
                     "IS-AFTERSALES", "IS-AFTERMARKET"):
            assert a.get(flag) == "true"

    def test_audience_all_false(self):
        svc = DiagService(
            short_name="S",
            audience=Audience(
                is_supplier=False, is_development=False,
                is_manufacturing=False, is_aftersales=False,
                is_aftermarket=False,
            ),
        )
        bv = BaseVariant(short_name="BV", diag_comms=[svc])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        a = root.find(".//AUDIENCE")
        for flag in ("IS-SUPPLIER", "IS-DEVELOPMENT", "IS-MANUFACTURING",
                     "IS-AFTERSALES", "IS-AFTERMARKET"):
            assert a.get(flag) == "false"


# ---------------------------------------------------------------------------
# 8. SDGs / FunctionalClass / EcuVariantPattern
# ---------------------------------------------------------------------------


class TestSdgsAndAux:
    """SDGS preserves caption + nested items; FunctionalClass round-trips."""

    def test_sdgs_nested_items_preserved(self):
        sdg = SpecialDataGroup(
            caption="MyCaption",
            sd_items=[("key1", "value1"), ("key2", "value2")],
        )
        bv = BaseVariant(short_name="BV", sdgs=[sdg])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        sdgs = root.find(".//SDGS")
        assert sdgs is not None
        sds = sdgs.findall(".//SD")
        assert len(sds) == 2
        assert sds[0].get("SI") == "key1"
        assert sds[0].text == "value1"
        assert sds[1].get("SI") == "key2"
        assert sds[1].text == "value2"
        # Caption is emitted as SDG-CAPTION/SHORT-NAME.
        cap = sdgs.find(".//SDG-CAPTION/SHORT-NAME")
        assert cap is not None
        assert cap.text == "MyCaption"

    def test_no_sdgs_when_list_empty(self):
        bv = BaseVariant(short_name="BV", sdgs=[])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        assert root.find(".//BASE-VARIANT/SDGS") is None

    def test_functional_class_round_trip(self):
        fc = FunctionalClass(
            oid="fc.OID", short_name="FC_DATA",
            long_name="Read-data services",
        )
        bv = BaseVariant(short_name="BV", functional_classes=[fc])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        fc_el = root.find(".//FUNCT-CLASS")
        assert fc_el is not None
        assert fc_el.get("ID") == "fc.OID"
        assert fc_el.find("SHORT-NAME").text == "FC_DATA"
        assert fc_el.find("LONG-NAME").text == "Read-data services"

    def test_ecu_variant_pattern_round_trip(self):
        pat = EcuVariantPattern(
            matching_parameters=[("SoftwareVersion", "1.0.0")],
        )
        ev = EcuVariant(short_name="EV", ecu_variant_patterns=[pat])
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", ecu_variants=[ev]))))
        mp = root.find(".//MATCHING-PARAMETER")
        assert mp is not None
        assert mp.find("EXPECTED-VALUE").text == "1.0.0"
        snref = mp.find("DIAG-COMM-SNREF")
        assert snref.get("SHORT-NAME") == "SoftwareVersion"


# ---------------------------------------------------------------------------
# 9. UnitSpec / Structure / Table
# ---------------------------------------------------------------------------


class TestUnitsStructuresTables:
    """UnitSpec, Structure and Table elements round-trip."""

    def test_unit_spec_with_groups(self):
        u1 = Unit(oid="u.km_h", short_name="UnitKmh", display_name="km/h",
                  factor_si_to_unit=3.6)
        u2 = Unit(oid="u.rpm", short_name="UnitRpm", display_name="rpm")
        ug = UnitGroup(oid="ug.SI", short_name="SI", category="EQUIV-UNITS",
                       unit_refs=[OdxRef(id_ref="u.km_h"), OdxRef(id_ref="u.rpm")])
        us = UnitSpec(units=[u1, u2], unit_groups=[ug])
        ddds = DiagDataDictionarySpec(unit_spec=us)
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        units = root.findall(".//UNIT")
        assert len(units) == 2
        groups = root.findall(".//UNIT-GROUP")
        assert len(groups) == 1
        assert groups[0].find("CATEGORY").text == "EQUIV-UNITS"

    def test_structure_with_params(self):
        s = Structure(
            oid="s.MemRange", short_name="MemRange", byte_size=8,
            params=[
                Param(short_name="start", byte_position=0, bit_length=32,
                      param_kind="VALUE",
                      dop_ref=OdxRef(id_ref="dop.u32")),
                Param(short_name="end", byte_position=4, bit_length=32,
                      param_kind="VALUE",
                      dop_ref=OdxRef(id_ref="dop.u32")),
            ],
        )
        ddds = DiagDataDictionarySpec(structures=[s])
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        sel = root.find(".//STRUCTURE")
        assert sel is not None
        assert sel.find("BYTE-SIZE").text == "8"
        params = sel.findall("PARAMS/PARAM")
        assert len(params) == 2

    def test_table_with_rows(self):
        rows = [
            TableRow(oid="t.r.def", short_name="Default", key=1),
            TableRow(oid="t.r.prg", short_name="Programming", key=2),
        ]
        t = Table(oid="t.session", short_name="SessionTable",
                  long_name="Session Table", table_rows=rows)
        ddds = DiagDataDictionarySpec(tables=[t])
        bv = BaseVariant(short_name="BV", diag_data_dictionary_spec=ddds)
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", base_variants=[bv]))))
        tbl = root.find(".//TABLE")
        assert tbl.find("SHORT-NAME").text == "SessionTable"
        assert len(tbl.findall(".//TABLE-ROW")) == 2


# ---------------------------------------------------------------------------
# 10. EcuVariant inheritance
# ---------------------------------------------------------------------------


class TestEcuVariant:
    """ECU-VARIANT preserves base_variant_ref and parent_refs."""

    def test_ecu_variant_with_parent_refs(self):
        ev = EcuVariant(
            oid="ev.X",
            short_name="EV_X",
            base_variant_ref=OdxRef(id_ref="bv.parent"),
            parent_refs=[
                OdxRef(id_ref="bv.parent", docref_type="LAYER"),
            ],
        )
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", ecu_variants=[ev]))))
        ev_el = root.find(".//ECU-VARIANT")
        assert ev_el.find("BASE-VARIANT-REF").get("ID-REF") == "bv.parent"
        parent = ev_el.find("PARENT-REFS/PARENT-REF")
        assert parent.get("ID-REF") == "bv.parent"
        assert parent.get("DOCREF-TYPE") == "LAYER"

    def test_protocol_in_dlc(self):
        proto = Protocol(oid="p.uds", short_name="UDS_on_CAN")
        root = _parse(serialize_odx_d(_make_doc(
            DiagLayerContainer(short_name="DLC", protocols=[proto]))))
        p = root.find(".//PROTOCOL")
        assert p is not None
        assert p.get("ID") == "p.uds"


# ---------------------------------------------------------------------------
# 11. Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    """Bad inputs raise ValueError with a clear message."""

    def test_wrong_category_raises(self):
        doc = OdxDocument(category=OdxCategory.FLASH)
        with pytest.raises(ValueError, match="category"):
            serialize_odx_d(doc)

    def test_none_content_raises(self):
        doc = OdxDocument(category=OdxCategory.DIAG_LAYER,
                          diag_layer_container=None)
        with pytest.raises(ValueError, match="DiagLayerContainer"):
            serialize_odx_d(doc)


# ---------------------------------------------------------------------------
# 12. ID-REF integrity (within document)
# ---------------------------------------------------------------------------


class TestRefIntegrity:
    """Every internal ID-REF must resolve to an ID somewhere in the same doc."""

    def test_mapper_output_is_internally_consistent(self):
        # Use the mapper sample to obtain a realistic doc graph.
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec)
        odx_d = next(d for d in docs.values() if d.category == OdxCategory.DIAG_LAYER)
        payload = serialize_odx_d(odx_d)
        root = _parse(payload)
        # Collect IDs.
        ids = {el.get("ID") for el in root.iter() if el.get("ID")}
        # Refs that are EXPECTED to be within-document. Skip refs that ODX
        # commonly resolves cross-document: UNIT-REF (unit-spec dictionary
        # rather than ID-based), COMPANY-DATA-REF (admin data).
        cross_doc_tags = {
            "UNIT-REF", "COMPARAM-REF", "COMPANY-DATA-REF",
            "TEAM-MEMBER-REF",
        }
        missing: list[tuple[str, str]] = []
        for el in root.iter():
            ref = el.get("ID-REF")
            if not ref:
                continue
            if el.tag in cross_doc_tags:
                continue
            if ref not in ids:
                missing.append((el.tag, ref))
        assert not missing, f"Dangling internal refs: {missing[:5]}"


# ---------------------------------------------------------------------------
# 13. Sample ARXML integration
# ---------------------------------------------------------------------------


class TestSampleIntegration:
    """End-to-end: parse ARXML, map to ODX, serialize, re-parse."""

    def test_sample_round_trip(self):
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec)
        odx_d = next(d for d in docs.values() if d.category == OdxCategory.DIAG_LAYER)
        payload = serialize_odx_d(odx_d)
        assert payload, "Empty payload from serializer"
        # Re-parse to confirm well-formedness.
        root = _parse(payload)
        assert root.tag == "ODX"
        # Sample has DIDs, DOPs and services.
        assert len(root.findall(".//DATA-OBJECT-PROP")) >= 1
        assert len(root.findall(".//DIAG-SERVICE")) >= 5

    def test_sample_has_dtc_dop(self):
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec)
        odx_d = next(d for d in docs.values() if d.category == OdxCategory.DIAG_LAYER)
        root = _parse(serialize_odx_d(odx_d))
        # When the sample exposes DTCs, the DTC-DOP must serialize too.
        bv = odx_d.diag_layer_container.base_variants[0]
        if bv.diag_data_dictionary_spec.dtc_dops:
            assert root.find(".//DTC-DOP") is not None

    def test_write_odx_d_creates_file(self, tmp_path):
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec)
        odx_d = next(d for d in docs.values() if d.category == OdxCategory.DIAG_LAYER)
        out = tmp_path / "subdir" / "ECU.odx-d"
        result = write_odx_d(odx_d, out)
        assert result == out
        assert out.is_file()
        assert out.stat().st_size > 0
        # Parse the written file as a sanity check.
        parsed = etree.parse(str(out))
        assert parsed.getroot().tag == "ODX"

    def test_sample_request_response_refs_resolvable(self):
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec)
        odx_d = next(d for d in docs.values() if d.category == OdxCategory.DIAG_LAYER)
        root = _parse(serialize_odx_d(odx_d))
        # Every REQUEST-REF in DIAG-SERVICE should match a REQUEST ID.
        req_ids = {r.get("ID") for r in root.findall(".//REQUEST")}
        for svc_req in root.findall(".//DIAG-SERVICE/REQUEST-REF"):
            assert svc_req.get("ID-REF") in req_ids
