"""Tests for the ODX-V (Vehicle Information) and ODX-E (ECU Shared Data) serializers."""

from __future__ import annotations

from pathlib import Path

import pytest
from lxml import etree

from udsxml2tex.odx import (
    AdminData,
    Audience,
    CompanyData,
    ComparamRefValuePair,
    CompuMethod,
    DataObjectProp,
    DiagCodedType,
    DiagDataDictionarySpec,
    DiagService,
    DocRevision,
    Dtc,
    DtcDop,
    EcuSharedData,
    FunctionalClass,
    InfoComponent,
    LogicalLink,
    OdxCategory,
    OdxDocument,
    OdxRef,
    OemVersion,
    Param,
    PhysicalType,
    PhysicalVehicleLink,
    Request,
    Response,
    SpecialDataGroup,
    Structure,
    Vehicle,
    VehicleConnector,
    VehicleInformation,
    VehicleInfoSpec,
    load_supplement,
    map_spec_to_odx,
)
from udsxml2tex.odx.serializers.odx_e import serialize_odx_e, write_odx_e
from udsxml2tex.odx.serializers.odx_v import serialize_odx_v, write_odx_v

SAMPLES_DIR = (
    Path(__file__).parent.parent / "src" / "udsxml2tex" / "samples"
)
SAMPLE_YAML = SAMPLES_DIR / "odx_supplement_sample.yaml"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse(xml_bytes: bytes) -> etree._Element:
    """Parse ``xml_bytes`` and return the root element."""
    return etree.fromstring(xml_bytes)


def _odx_v_doc(spec: VehicleInfoSpec, admin: AdminData | None = None) -> OdxDocument:
    """Wrap ``spec`` in an OdxDocument with the correct category."""
    return OdxDocument(
        category=OdxCategory.VEHICLE_INFO,
        vehicle_info_spec=spec,
        admin_data=admin,
        pdx_member_path="VehicleInfo.odx-v",
    )


def _odx_e_doc(shared: EcuSharedData) -> OdxDocument:
    """Build an ODX-E OdxDocument wrapping ``shared`` directly."""
    from udsxml2tex.odx import DiagLayerContainer

    return OdxDocument(
        category=OdxCategory.ECU_SHARED_DATA,
        diag_layer_container=DiagLayerContainer(
            oid="udsxml2tex.odx.e.container.Shared",
            short_name="SharedContainer",
            ecu_shared_datas=[shared],
        ),
        pdx_member_path="SharedData.odx-e",
    )


def _simple_dop(oid: str = "udsxml2tex.odx.d.dop.U8") -> DataObjectProp:
    """Build a minimal DOP usable inside DiagDataDictionarySpec."""
    return DataObjectProp(
        oid=oid,
        short_name=oid.split(".")[-1],
        compu_method=CompuMethod(),
        diag_coded_type=DiagCodedType(bit_length=8),
        physical_type=PhysicalType(),
    )


# ---------------------------------------------------------------------------
# 1. ODX-V — minimal / empty
# ---------------------------------------------------------------------------


class TestOdxVMinimal:
    """Empty VehicleInfoSpec round-trips through serialize_odx_v."""

    def test_empty_spec_emits_root(self):
        spec = VehicleInfoSpec(
            oid="udsxml2tex.odx.v.spec.Empty",
            short_name="Empty",
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        assert payload.startswith(b"<?xml")
        root = _parse(payload)
        assert root.tag == "ODX"
        vis = root.find("VEHICLE-INFO-SPEC")
        assert vis is not None
        assert vis.get("ID") == "udsxml2tex.odx.v.spec.Empty"
        assert vis.findtext("SHORT-NAME") == "Empty"

    def test_model_version_attribute(self):
        spec = VehicleInfoSpec(short_name="Empty")
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        assert root.get("MODEL-VERSION") == "2.2.0"

    def test_wrong_category_raises(self):
        doc = OdxDocument(
            category=OdxCategory.DIAG_LAYER,
            vehicle_info_spec=VehicleInfoSpec(short_name="X"),
        )
        with pytest.raises(ValueError):
            serialize_odx_v(doc)

    def test_missing_spec_raises(self):
        doc = OdxDocument(
            category=OdxCategory.VEHICLE_INFO,
            vehicle_info_spec=None,
        )
        with pytest.raises(ValueError):
            serialize_odx_v(doc)


# ---------------------------------------------------------------------------
# 2. ODX-V — Vehicle metadata → INFO-COMPONENTS
# ---------------------------------------------------------------------------


class TestOdxVInfoComponents:
    """Vehicle metadata is surfaced as INFO-COMPONENT children."""

    def test_vehicle_metadata_synthesises_info_components(self):
        veh = Vehicle(
            oid="udsxml2tex.odx.v.vehicle.Demo",
            short_name="Demo",
            vin="ABC123",
            model_year=2025,
            model="ExampleCar",
            manufacturer="ExampleOEM",
        )
        spec = VehicleInfoSpec(
            oid="udsxml2tex.odx.v.spec.Demo",
            short_name="Demo",
            vehicles=[veh],
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        ic_short_names = {
            ic.findtext("SHORT-NAME")
            for ic in root.iter("INFO-COMPONENT")
        }
        # All four expected categories materialise.
        assert {"MANUFACTURER", "MODEL_YEAR", "MODEL", "VIN"}.issubset(ic_short_names)

    def test_info_component_xsi_type_manufacturer(self):
        spec = VehicleInfoSpec(
            short_name="Demo",
            info_components=[
                InfoComponent(
                    oid="udsxml2tex.odx.v.ic.Manufacturer",
                    short_name="Manufacturer",
                    category="MANUFACTURER",
                    value="ExampleOEM",
                ),
            ],
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        ic = root.find(".//INFO-COMPONENT")
        assert ic is not None
        # xsi:type with the namespace prefix
        xsi_type = ic.get("{http://www.w3.org/2001/XMLSchema-instance}type")
        assert xsi_type == "MANUFACTURER"

    def test_info_component_value_emitted(self):
        spec = VehicleInfoSpec(
            short_name="Demo",
            info_components=[
                InfoComponent(
                    oid="udsxml2tex.odx.v.ic.ModelYear",
                    short_name="ModelYear",
                    category="MODEL-YEAR",
                    value="2025",
                ),
            ],
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        ic = root.find(".//INFO-COMPONENT")
        assert ic is not None
        assert ic.findtext("VALUE") == "2025"


# ---------------------------------------------------------------------------
# 3. ODX-V — VehicleConnector
# ---------------------------------------------------------------------------


class TestOdxVConnectors:
    """Vehicle connectors emit VEHICLE-CONNECTOR with pin infos."""

    def test_connector_with_pins(self):
        veh = Vehicle(
            short_name="Demo",
            vehicle_connectors=[
                VehicleConnector(
                    oid="udsxml2tex.odx.v.connector.OBD2",
                    short_name="OBD2_Connector",
                    connector_type="ISO-15031-3",
                    pins=[(6, "CAN-H"), (14, "CAN-L"), (16, "BAT+")],
                ),
            ],
        )
        spec = VehicleInfoSpec(
            short_name="Demo",
            vehicles=[veh],
            vehicle_informations=[
                VehicleInformation(short_name="Demo", logical_links=[]),
            ],
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        pins = list(root.iter("VEHICLE-CONNECTOR-PIN-INFO"))
        assert len(pins) == 3
        numbers = [int(p.findtext("PIN-NUMBER")) for p in pins]
        assert numbers == [6, 14, 16]

    def test_connector_short_name(self):
        veh = Vehicle(
            short_name="Demo",
            vehicle_connectors=[
                VehicleConnector(
                    oid="udsxml2tex.odx.v.connector.OBD2",
                    short_name="OBD2_Connector",
                    connector_type="ISO-15031-3",
                ),
            ],
        )
        spec = VehicleInfoSpec(
            short_name="Demo",
            vehicles=[veh],
            vehicle_informations=[VehicleInformation(short_name="Demo")],
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        conn = root.find(".//VEHICLE-CONNECTOR")
        assert conn is not None
        assert conn.findtext("SHORT-NAME") == "OBD2_Connector"


# ---------------------------------------------------------------------------
# 4. ODX-V — LogicalLink + PhysicalVehicleLink graph
# ---------------------------------------------------------------------------


class TestOdxVLinks:
    """Logical/physical vehicle links emit the correct reference graph."""

    def _spec_with_links(self) -> VehicleInfoSpec:
        physical_link = PhysicalVehicleLink(
            oid="udsxml2tex.odx.v.pvl.ISOTP_500K",
            short_name="ISOTP_500K",
            link_type="ISO-15765-2-on-ISO-11898-2-DWCAN",
            vehicle_connector_ref=OdxRef(
                id_ref="udsxml2tex.odx.v.connector.OBD2",
            ),
        )
        link = LogicalLink(
            oid="udsxml2tex.odx.v.ll.EcuPhysical",
            short_name="ECU_PhysicalLink",
            link_type="MEMBER-LOGICAL-LINK",
            physical_vehicle_link_ref=OdxRef(id_ref=physical_link.oid),
            base_variant_ref=OdxRef(
                id_ref="udsxml2tex.odx.d.bv.ECU",
                docref="ECU",
                docref_type="CONTAINER",
            ),
            protocol_ref=OdxRef(id_ref="udsxml2tex.odx.d.protocol.UDS_On_CAN"),
        )
        return VehicleInfoSpec(
            short_name="Demo",
            vehicles=[Vehicle(short_name="Demo")],
            vehicle_informations=[
                VehicleInformation(short_name="Demo", logical_links=[link]),
            ],
            physical_vehicle_links=[physical_link],
        )

    def test_physical_vehicle_link_type_underscore(self):
        spec = self._spec_with_links()
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        pvl = root.find(".//PHYSICAL-VEHICLE-LINK")
        assert pvl is not None
        # ODX 2.2.0 uses underscores in the TYPE attribute
        assert pvl.get("TYPE") == "ISO_15765_2_on_ISO_11898_2_DWCAN"

    def test_logical_link_has_xsi_type_member(self):
        spec = self._spec_with_links()
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        ll = root.find(".//LOGICAL-LINK")
        assert ll is not None
        xsi_type = ll.get("{http://www.w3.org/2001/XMLSchema-instance}type")
        assert xsi_type == "MEMBER-LOGICAL-LINK"

    def test_logical_link_references(self):
        spec = self._spec_with_links()
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        ll = root.find(".//LOGICAL-LINK")
        assert ll is not None
        pvl_ref = ll.find("PHYSICAL-VEHICLE-LINK-REF")
        assert pvl_ref is not None
        assert pvl_ref.get("ID-REF") == "udsxml2tex.odx.v.pvl.ISOTP_500K"
        bv_ref = ll.find("BASE-VARIANT-REF")
        assert bv_ref is not None
        assert bv_ref.get("ID-REF") == "udsxml2tex.odx.d.bv.ECU"
        assert bv_ref.get("DOCREF") == "ECU"
        assert bv_ref.get("DOCTYPE") == "CONTAINER"
        proto_ref = ll.find("PROTOCOL-REF")
        assert proto_ref is not None
        assert proto_ref.get("ID-REF") == "udsxml2tex.odx.d.protocol.UDS_On_CAN"

    def test_comparam_ref_value_pairs(self):
        link = LogicalLink(
            oid="udsxml2tex.odx.v.ll.EcuPhysical",
            short_name="ECU_PhysicalLink",
            comparam_ref_value_pairs=[
                ComparamRefValuePair(
                    comparam_ref=OdxRef(id_ref="udsxml2tex.odx.cs.cp.CP_P2_SERVER_MAX"),
                    value="50",
                ),
                ComparamRefValuePair(
                    comparam_ref=OdxRef(id_ref="udsxml2tex.odx.cs.cp.CP_STMIN"),
                    value="0",
                ),
            ],
        )
        spec = VehicleInfoSpec(
            short_name="Demo",
            vehicle_informations=[
                VehicleInformation(short_name="Demo", logical_links=[link]),
            ],
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        pairs = list(root.iter("COMPARAM-REF-VALUE-PAIR"))
        assert len(pairs) == 2
        values = [p.findtext("VALUE") for p in pairs]
        assert "50" in values and "0" in values

    def test_multiple_physical_vehicle_link_types(self):
        # DoIP + ISOTP coexist in a single spec.
        doip = PhysicalVehicleLink(
            oid="udsxml2tex.odx.v.pvl.DoIP",
            short_name="DoIP_100M",
            link_type="ISO-13400-2-DoIP",
        )
        isotp = PhysicalVehicleLink(
            oid="udsxml2tex.odx.v.pvl.ISOTP",
            short_name="ISOTP_500K",
            link_type="ISO-15765-2-on-ISO-11898-2-DWCAN",
        )
        spec = VehicleInfoSpec(
            short_name="Demo",
            vehicles=[Vehicle(short_name="Demo")],
            vehicle_informations=[VehicleInformation(short_name="Demo")],
            physical_vehicle_links=[doip, isotp],
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        types = sorted(
            pvl.get("TYPE") for pvl in root.iter("PHYSICAL-VEHICLE-LINK")
        )
        assert types == ["ISO_13400_2_DoIP", "ISO_15765_2_on_ISO_11898_2_DWCAN"]


# ---------------------------------------------------------------------------
# 5. ODX-V — AdminData / SDGs / OEM versions / write_odx_v
# ---------------------------------------------------------------------------


class TestOdxVAdminAndIO:
    """ADMIN-DATA, COMPANY-DATAS and write_odx_v on-disk emission."""

    def test_admin_data_present(self):
        admin = AdminData(
            language="en-US",
            doc_revisions=[
                DocRevision(revision_label="0.1", state="DRAFT", date="2026-05-14"),
            ],
        )
        spec = VehicleInfoSpec(short_name="WithAdmin")
        payload = serialize_odx_v(_odx_v_doc(spec, admin=admin))
        root = _parse(payload)
        ad = root.find(".//ADMIN-DATA")
        assert ad is not None
        assert ad.findtext("LANGUAGE") == "en-US"
        rev = ad.find(".//DOC-REVISION")
        assert rev is not None
        assert rev.findtext("REVISION-LABEL") == "0.1"

    def test_company_datas_emitted_when_admin_company(self):
        admin = AdminData(
            language="en-US",
            company_doc_infos=[
                CompanyData(
                    oid="udsxml2tex.odx.d.cd.ExampleOEM",
                    short_name="ExampleOEM",
                    long_name="Example OEM Corporation",
                    roles=["MANUFACTURER"],
                ),
            ],
        )
        spec = VehicleInfoSpec(short_name="WithCompany")
        payload = serialize_odx_v(_odx_v_doc(spec, admin=admin))
        root = _parse(payload)
        cd = root.find(".//COMPANY-DATAS/COMPANY-DATA")
        assert cd is not None
        assert cd.get("ID") == "udsxml2tex.odx.d.cd.ExampleOEM"
        assert cd.findtext("SHORT-NAME") == "ExampleOEM"
        roles = [r.text for r in cd.iter("ROLE")]
        assert "MANUFACTURER" in roles

    def test_oem_versions_emitted(self):
        spec = VehicleInfoSpec(
            short_name="WithOEM",
            oem_versions=[
                OemVersion(
                    oid="udsxml2tex.odx.v.oem.V1",
                    short_name="V1",
                    label="Release",
                    value="1.2.3",
                ),
            ],
        )
        payload = serialize_odx_v(_odx_v_doc(spec))
        root = _parse(payload)
        ov = root.find(".//OEM-VERSION")
        assert ov is not None
        assert ov.findtext("VALUE") == "1.2.3"

    def test_write_odx_v_creates_file(self, tmp_path: Path):
        spec = VehicleInfoSpec(short_name="OnDisk")
        out_path = tmp_path / "sub" / "VehicleInfo.odx-v"
        result = write_odx_v(_odx_v_doc(spec), out_path)
        assert result == out_path
        assert out_path.exists()
        content = out_path.read_bytes()
        assert content.startswith(b"<?xml")
        # File is parseable.
        root = etree.fromstring(content)
        assert root.find("VEHICLE-INFO-SPEC").findtext("SHORT-NAME") == "OnDisk"


# ---------------------------------------------------------------------------
# 6. ODX-V — supplement-driven Vehicle round-trip
# ---------------------------------------------------------------------------


pytest.importorskip("yaml")


class TestOdxVSupplement:
    """Supplement YAML produces a working VEHICLE-INFO-SPEC output."""

    def test_supplement_vehicle_round_trip(self):
        from udsxml2tex.models import UdsSpecification

        sup = load_supplement(SAMPLE_YAML)
        spec = UdsSpecification()
        docs = map_spec_to_odx(spec, sup)
        odx_v = next(
            d for d in docs.values() if d.category == OdxCategory.VEHICLE_INFO
        )
        payload = serialize_odx_v(odx_v)
        root = _parse(payload)
        # VIN was passed through the mapper into Vehicle, and the serializer
        # surfaces it as a VIN INFO-COMPONENT.
        vin_value = None
        for ic in root.iter("INFO-COMPONENT"):
            if ic.findtext("SHORT-NAME") == "VIN":
                vin_value = ic.findtext("VALUE")
                break
        assert vin_value == "WAUZZZ8K0XA000001"

    def test_supplement_model_year_present(self):
        from udsxml2tex.models import UdsSpecification

        sup = load_supplement(SAMPLE_YAML)
        docs = map_spec_to_odx(UdsSpecification(), sup)
        odx_v = next(
            d for d in docs.values() if d.category == OdxCategory.VEHICLE_INFO
        )
        payload = serialize_odx_v(odx_v)
        root = _parse(payload)
        year_value = None
        for ic in root.iter("INFO-COMPONENT"):
            if ic.findtext("SHORT-NAME") == "MODEL_YEAR":
                year_value = ic.findtext("VALUE")
                break
        assert year_value == "2025"

    def test_supplement_physical_links_present(self):
        from udsxml2tex.models import UdsSpecification

        sup = load_supplement(SAMPLE_YAML)
        docs = map_spec_to_odx(UdsSpecification(), sup)
        odx_v = next(
            d for d in docs.values() if d.category == OdxCategory.VEHICLE_INFO
        )
        payload = serialize_odx_v(odx_v)
        root = _parse(payload)
        short_names = {
            pvl.findtext("SHORT-NAME") for pvl in root.iter("PHYSICAL-VEHICLE-LINK")
        }
        assert "ISOTP_500K" in short_names
        assert "DoIP_100M" in short_names


# ---------------------------------------------------------------------------
# 7. ODX-E — minimal / empty
# ---------------------------------------------------------------------------


class TestOdxEMinimal:
    """Empty EcuSharedData round-trips through serialize_odx_e."""

    def test_empty_shared_emits_root(self):
        shared = EcuSharedData(
            oid="udsxml2tex.odx.e.shared.Empty",
            short_name="Empty",
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        assert root.tag == "ODX"
        esd = root.find("ECU-SHARED-DATA")
        assert esd is not None
        assert esd.get("ID") == "udsxml2tex.odx.e.shared.Empty"
        assert esd.findtext("SHORT-NAME") == "Empty"

    def test_wrong_category_raises(self):
        doc = OdxDocument(
            category=OdxCategory.DIAG_LAYER,
            diag_layer_container=None,
        )
        with pytest.raises(ValueError):
            serialize_odx_e(doc)

    def test_missing_payload_raises(self):
        doc = OdxDocument(
            category=OdxCategory.ECU_SHARED_DATA,
            diag_layer_container=None,
        )
        with pytest.raises(ValueError):
            serialize_odx_e(doc)


# ---------------------------------------------------------------------------
# 8. ODX-E — DiagDataDictionarySpec full
# ---------------------------------------------------------------------------


class TestOdxEDiagDataDictionarySpec:
    """EcuSharedData with a fully-populated DiagDataDictionarySpec."""

    def test_data_object_props_emitted(self):
        dds = DiagDataDictionarySpec(
            data_object_props=[
                _simple_dop("udsxml2tex.odx.d.dop.U8"),
                _simple_dop("udsxml2tex.odx.d.dop.U16"),
            ],
        )
        shared = EcuSharedData(
            oid="udsxml2tex.odx.e.shared.WithDops",
            short_name="WithDops",
            diag_data_dictionary_spec=dds,
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        dops = list(root.iter("DATA-OBJECT-PROP"))
        assert len(dops) == 2

    def test_dtc_dops_emitted(self):
        dop = DtcDop(
            oid="udsxml2tex.odx.d.dtcdop.Main",
            short_name="MainDtcDop",
            dtcs=[
                Dtc(
                    oid="udsxml2tex.odx.d.dtc.P0420",
                    short_name="P0420",
                    trouble_code=0x000420,
                ),
            ],
        )
        shared = EcuSharedData(
            short_name="WithDtc",
            diag_data_dictionary_spec=DiagDataDictionarySpec(dtc_dops=[dop]),
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        dtc_dops = list(root.iter("DTC-DOP"))
        assert len(dtc_dops) == 1
        dtcs = list(root.iter("DTC"))
        assert len(dtcs) == 1
        assert dtcs[0].findtext("TROUBLE-CODE") == "1056"  # 0x000420

    def test_structure_with_params(self):
        struct = Structure(
            oid="udsxml2tex.odx.d.struct.S",
            short_name="S",
            byte_size=2,
            params=[
                Param(
                    oid="udsxml2tex.odx.d.param.A",
                    short_name="A",
                    byte_position=0,
                    bit_length=8,
                    param_kind="VALUE",
                    semantic="DATA",
                    dop_ref=OdxRef(id_ref="udsxml2tex.odx.d.dop.U8"),
                ),
                Param(
                    oid="udsxml2tex.odx.d.param.B",
                    short_name="B",
                    byte_position=1,
                    bit_length=8,
                    param_kind="VALUE",
                    semantic="DATA",
                    dop_ref=OdxRef(id_ref="udsxml2tex.odx.d.dop.U8"),
                ),
            ],
        )
        shared = EcuSharedData(
            short_name="WithStruct",
            diag_data_dictionary_spec=DiagDataDictionarySpec(structures=[struct]),
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        params = list(root.iter("PARAM"))
        assert len(params) == 2
        # Verify xsi:type attribute on each param.
        for p in params:
            assert (
                p.get("{http://www.w3.org/2001/XMLSchema-instance}type") == "VALUE"
            )


# ---------------------------------------------------------------------------
# 9. ODX-E — DiagServices, Requests, Responses
# ---------------------------------------------------------------------------


class TestOdxEDiagComms:
    """EcuSharedData with diagnostic services, requests, and responses."""

    def _shared_with_service(self) -> EcuSharedData:
        req = Request(
            oid="udsxml2tex.odx.d.rq.RDBI_VIN",
            short_name="RDBI_VIN_RQ",
            params=[
                Param(
                    short_name="SID",
                    byte_position=0,
                    bit_length=8,
                    param_kind="CODED-CONST",
                    semantic="SERVICE-ID",
                    coded_value=0x22,
                ),
            ],
        )
        resp = Response(
            oid="udsxml2tex.odx.d.pr.RDBI_VIN",
            short_name="RDBI_VIN_PR",
            response_type="POS-RESPONSE",
        )
        svc = DiagService(
            oid="udsxml2tex.odx.d.svc.RDBI_VIN",
            short_name="RDBI_VIN",
            semantic="DATA",
            request_ref=OdxRef(id_ref=req.oid),
            pos_response_refs=[OdxRef(id_ref=resp.oid)],
            audience=Audience(),
        )
        return EcuSharedData(
            oid="udsxml2tex.odx.e.shared.RDBI",
            short_name="RdbiShared",
            diag_comms=[svc],
            requests=[req],
            pos_responses=[resp],
        )

    def test_diag_service_emitted(self):
        payload = serialize_odx_e(_odx_e_doc(self._shared_with_service()))
        root = _parse(payload)
        svc = root.find(".//DIAG-SERVICE")
        assert svc is not None
        assert svc.get("ID") == "udsxml2tex.odx.d.svc.RDBI_VIN"
        assert svc.get("SEMANTIC") == "DATA"
        assert svc.get("ADDRESSING") == "PHYSICAL"
        assert svc.get("IS-EXECUTABLE") == "true"

    def test_request_with_coded_const_param(self):
        payload = serialize_odx_e(_odx_e_doc(self._shared_with_service()))
        root = _parse(payload)
        params = list(root.iter("PARAM"))
        assert any(
            p.get("{http://www.w3.org/2001/XMLSchema-instance}type") == "CODED-CONST"
            for p in params
        )
        assert any(p.findtext("CODED-VALUE") == "34" for p in params)  # 0x22

    def test_pos_response_emitted(self):
        payload = serialize_odx_e(_odx_e_doc(self._shared_with_service()))
        root = _parse(payload)
        pr = root.find(".//POS-RESPONSES/POS-RESPONSE")
        assert pr is not None
        assert pr.findtext("SHORT-NAME") == "RDBI_VIN_PR"

    def test_neg_response_block(self):
        shared = EcuSharedData(
            short_name="WithNeg",
            neg_responses=[
                Response(
                    oid="udsxml2tex.odx.d.nr.NR_RDBI",
                    short_name="NR_RDBI",
                    response_type="NEG-RESPONSE",
                ),
            ],
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        nr = root.find(".//NEG-RESPONSES/NEG-RESPONSE")
        assert nr is not None
        assert nr.findtext("SHORT-NAME") == "NR_RDBI"


# ---------------------------------------------------------------------------
# 10. ODX-E — AdminData / SDGs / FunctionalClasses / write
# ---------------------------------------------------------------------------


class TestOdxEMisc:
    """Auxiliary blocks: ADMIN-DATA, FUNCT-CLASSES, SDGS, IMPORT-REFS."""

    def test_admin_data_and_company_datas(self):
        shared = EcuSharedData(
            short_name="Admin",
            admin_data=AdminData(
                language="en-US",
                doc_revisions=[DocRevision(revision_label="0.1", state="DRAFT")],
            ),
            company_datas=[
                CompanyData(
                    oid="udsxml2tex.odx.d.cd.OEM",
                    short_name="OEM",
                    roles=["MANUFACTURER"],
                ),
            ],
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        esd = root.find("ECU-SHARED-DATA")
        assert esd.find("ADMIN-DATA") is not None
        cd = root.find(".//COMPANY-DATAS/COMPANY-DATA")
        assert cd is not None
        assert cd.findtext("SHORT-NAME") == "OEM"

    def test_functional_classes_emitted(self):
        shared = EcuSharedData(
            short_name="WithFcs",
            functional_classes=[
                FunctionalClass(
                    oid="udsxml2tex.odx.d.fc.SAFETY",
                    short_name="Safety",
                    long_name="Safety-critical services",
                ),
            ],
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        fc = root.find(".//FUNCT-CLASSES/FUNCT-CLASS")
        assert fc is not None
        assert fc.findtext("SHORT-NAME") == "Safety"

    def test_sdgs_emitted(self):
        shared = EcuSharedData(
            short_name="WithSDG",
            sdgs=[
                SpecialDataGroup(
                    caption="OEM",
                    sd_items=[("brand", "Example"), ("variant", "A")],
                ),
            ],
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        sds = list(root.iter("SD"))
        assert len(sds) == 2
        assert {sd.get("SI") for sd in sds} == {"brand", "variant"}

    def test_import_refs_emitted(self):
        shared = EcuSharedData(
            short_name="WithImports",
            import_refs=[
                OdxRef(id_ref="udsxml2tex.odx.d.shared.Other"),
            ],
        )
        payload = serialize_odx_e(_odx_e_doc(shared))
        root = _parse(payload)
        ir = root.find(".//IMPORT-REFS/IMPORT-REF")
        assert ir is not None
        assert ir.get("ID-REF") == "udsxml2tex.odx.d.shared.Other"

    def test_write_odx_e_creates_file(self, tmp_path: Path):
        shared = EcuSharedData(short_name="OnDisk")
        out_path = tmp_path / "Shared.odx-e"
        result = write_odx_e(_odx_e_doc(shared), out_path)
        assert result == out_path
        assert out_path.exists()
        content = out_path.read_bytes()
        assert content.startswith(b"<?xml")
        root = etree.fromstring(content)
        assert root.find("ECU-SHARED-DATA").findtext("SHORT-NAME") == "OnDisk"
