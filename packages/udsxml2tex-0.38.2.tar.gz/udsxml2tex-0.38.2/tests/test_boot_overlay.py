"""Tests for :mod:`udsxml2tex.boot_overlay` and the new ``domain`` field.

Covers:

* :func:`load_overlay` YAML parsing (happy path, hex/decimal coercion,
  conflict detection, malformed input rejection)
* :func:`empty_overlay`
* :func:`apply_to_spec` mutating session / service / DID / routine domains
* Backward compatibility of :class:`UdsSpecification` JSON: old JSONs without
  ``domain`` fields still load
* ``UdsSpecification`` merge (``|``) promoting ``domain`` to ``"both"`` when
  the two sides disagree
* Sample :file:`samples/boot_overlay_sample.yaml` loads + applies cleanly
* :class:`BootloaderInfo` / :class:`DomainCanIds` round-trip through load
* Parser fix: real-world OEM ARXML (gitignored) yields >=10 services when
  available, otherwise the test skips gracefully
"""

from __future__ import annotations

from pathlib import Path

import pytest

from udsxml2tex import (
    BootloaderInfo,
    BootOverlay,
    DiagSession,
    Did,
    DomainCanIds,
    DomainMap,
    FlashSegment,
    Routine,
    UdsService,
    UdsSpecification,
    apply_boot_overlay,
    empty_overlay,
    load_overlay,
)
from udsxml2tex.boot_overlay import (
    _coerce_int,
    _coerce_int_list,
    _coerce_str_list,
)
from udsxml2tex.models import _promote_domain

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SAMPLE_OVERLAY = PROJECT_ROOT / "src" / "udsxml2tex" / "samples" / "boot_overlay_sample.yaml"
SAMPLE_ARXML = PROJECT_ROOT / "src" / "udsxml2tex" / "samples" / "sample1_dcm.arxml"
OEM_ARXML = PROJECT_ROOT / "refs" / "uds-tex-spec-oem" / "arxml" / "Dcm_EcucValues.arxml"


# ---------------------------------------------------------------------------
# Coercion helpers
# ---------------------------------------------------------------------------


class TestCoerceInt:
    def test_int_passthrough(self) -> None:
        assert _coerce_int(42) == 42
        assert _coerce_int(0) == 0
        assert _coerce_int(-1) == -1

    def test_hex_string(self) -> None:
        assert _coerce_int("0xF180") == 0xF180
        assert _coerce_int("0xff") == 255

    def test_decimal_string(self) -> None:
        assert _coerce_int("100") == 100
        assert _coerce_int("0") == 0

    def test_rejects_bool(self) -> None:
        # bool is an int subclass; must be rejected to avoid silent True->1.
        with pytest.raises(ValueError):
            _coerce_int(True)
        with pytest.raises(ValueError):
            _coerce_int(False)

    def test_rejects_empty(self) -> None:
        with pytest.raises(ValueError):
            _coerce_int("")
        with pytest.raises(ValueError):
            _coerce_int("   ")

    def test_rejects_non_numeric(self) -> None:
        with pytest.raises(ValueError):
            _coerce_int(None)
        with pytest.raises(ValueError):
            _coerce_int([1])


class TestCoerceLists:
    def test_int_list_none_to_empty(self) -> None:
        assert _coerce_int_list(None) == []

    def test_int_list_mixed_hex_and_decimal(self) -> None:
        assert _coerce_int_list([0x10, "0x22", "0xFF00"]) == [0x10, 0x22, 0xFF00]

    def test_int_list_rejects_non_sequence(self) -> None:
        with pytest.raises(ValueError):
            _coerce_int_list(42)

    def test_str_list_none_to_empty(self) -> None:
        assert _coerce_str_list(None) == []

    def test_str_list_single_string_wraps(self) -> None:
        assert _coerce_str_list("alpha") == ["alpha"]

    def test_str_list_passthrough(self) -> None:
        assert _coerce_str_list(["a", "b"]) == ["a", "b"]


# ---------------------------------------------------------------------------
# empty_overlay
# ---------------------------------------------------------------------------


class TestEmptyOverlay:
    def test_returns_bootoverlay(self) -> None:
        ov = empty_overlay()
        assert isinstance(ov, BootOverlay)

    def test_defaults(self) -> None:
        ov = empty_overlay()
        assert ov.ecu_name == ""
        assert ov.default_domain == "drive"
        assert ov.domain_map.sessions == {}
        assert ov.domain_map.sids == {}
        assert ov.domain_map.dids == {}
        assert ov.domain_map.rids == {}
        assert ov.bootloader is None
        assert ov.can_ids_drive is None
        assert ov.can_ids_boot is None
        assert ov.boot_only_dids == []
        assert ov.boot_only_rids == []


# ---------------------------------------------------------------------------
# load_overlay
# ---------------------------------------------------------------------------


def _write_yaml(tmp_path: Path, content: str) -> Path:
    p = tmp_path / "overlay.yaml"
    p.write_text(content, encoding="utf-8")
    return p


class TestLoadOverlay:
    def test_file_not_found(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            load_overlay(tmp_path / "missing.yaml")

    def test_minimal_overlay(self, tmp_path: Path) -> None:
        p = _write_yaml(tmp_path, "ecu_name: ExampleECU\n")
        ov = load_overlay(p)
        assert ov.ecu_name == "ExampleECU"
        assert ov.default_domain == "drive"

    def test_empty_file_yields_defaults(self, tmp_path: Path) -> None:
        p = _write_yaml(tmp_path, "")
        ov = load_overlay(p)
        assert isinstance(ov, BootOverlay)
        assert ov.ecu_name == ""

    def test_top_level_must_be_mapping(self, tmp_path: Path) -> None:
        p = _write_yaml(tmp_path, "- not a mapping\n")
        with pytest.raises(ValueError):
            load_overlay(p)

    def test_invalid_default_domain_raises(self, tmp_path: Path) -> None:
        p = _write_yaml(tmp_path, "default_domain: bogus\n")
        with pytest.raises(ValueError):
            load_overlay(p)

    def test_sessions_loaded(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
domains:
  sessions:
    boot_only: [PROGRAMMING_SESSION]
    both:      [DEFAULT_SESSION]
""",
        )
        ov = load_overlay(p)
        assert ov.domain_map.sessions == {
            "PROGRAMMING_SESSION": "boot",
            "DEFAULT_SESSION": "both",
        }

    def test_sids_hex_and_decimal_mix(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
domains:
  sids:
    boot_only: [0x34, 54, "0xFE"]
    both:      [16, 0x11]
""",
        )
        ov = load_overlay(p)
        assert ov.domain_map.sids == {
            0x34: "boot",
            54: "boot",
            0xFE: "boot",
            16: "both",
            0x11: "both",
        }

    def test_conflict_same_sid_in_two_buckets_raises(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
domains:
  sids:
    boot_only: [0x34]
    both:      [0x34]
""",
        )
        with pytest.raises(ValueError, match="0x34|52"):
            load_overlay(p)

    def test_conflict_in_dids_raises(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
domains:
  dids:
    boot_only:  [0xF180]
    drive_only: [0xF180]
""",
        )
        with pytest.raises(ValueError, match="dids"):
            load_overlay(p)

    def test_conflict_in_rids_raises(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
domains:
  rids:
    both:      [0xFF00]
    drive_only: [0xFF00]
""",
        )
        with pytest.raises(ValueError, match="rids"):
            load_overlay(p)

    def test_conflict_in_sessions_raises(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
domains:
  sessions:
    boot_only:  [Foo]
    drive_only: [Foo]
""",
        )
        with pytest.raises(ValueError, match="Foo|sessions"):
            load_overlay(p)

    def test_empty_lists_permitted(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
domains:
  sids:
    boot_only:  []
    both:       []
    drive_only: []
""",
        )
        ov = load_overlay(p)
        assert ov.domain_map.sids == {}

    def test_bootloader_section(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
bootloader:
  reset_address: 0x80000
  download_block_size: 4090
  checksum_algorithm: CRC32
  flash_segments:
    - {name: AppCode, start: 0x100000, end: 0x1FFFFF, description: "Main code"}
  programming_sequence:
    - "Step 1"
    - "Step 2"
""",
        )
        ov = load_overlay(p)
        assert ov.bootloader is not None
        assert ov.bootloader.reset_address == 0x80000
        assert ov.bootloader.download_block_size == 4090
        assert ov.bootloader.checksum_algorithm == "CRC32"
        assert ov.bootloader.programming_sequence == ["Step 1", "Step 2"]
        assert len(ov.bootloader.flash_segments) == 1
        seg = ov.bootloader.flash_segments[0]
        assert seg.name == "AppCode"
        assert seg.start == 0x100000
        assert seg.end == 0x1FFFFF
        assert seg.description == "Main code"

    def test_can_ids_drive_and_boot(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
can_ids:
  drive:
    physical:   "0x18DA00E0"
    functional: "0x18DBEFE0"
    telematics: "0x18DA00E1"
  boot:
    physical:   "0x18DA00F0"
""",
        )
        ov = load_overlay(p)
        assert ov.can_ids_drive is not None
        assert ov.can_ids_drive.physical == "0x18DA00E0"
        assert ov.can_ids_drive.functional == "0x18DBEFE0"
        assert ov.can_ids_drive.telematics == "0x18DA00E1"
        assert ov.can_ids_boot is not None
        assert ov.can_ids_boot.physical == "0x18DA00F0"
        assert ov.can_ids_boot.functional == ""

    def test_boot_only_dids_hex_coerced(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
boot_only_dids:
  - {did_id: 0xF180, short_name: BootSwIdent, description: "Boot SW"}
  - {did_id: 61828,  short_name: BootHwIdent}
""",
        )
        ov = load_overlay(p)
        assert len(ov.boot_only_dids) == 2
        assert ov.boot_only_dids[0]["did_id"] == 0xF180
        assert ov.boot_only_dids[0]["short_name"] == "BootSwIdent"
        assert ov.boot_only_dids[1]["did_id"] == 61828

    def test_boot_only_rids_hex_coerced(self, tmp_path: Path) -> None:
        p = _write_yaml(
            tmp_path,
            """
boot_only_rids:
  - {rid_id: 0xFF00, short_name: FlashErase, description: "Erase"}
""",
        )
        ov = load_overlay(p)
        assert ov.boot_only_rids[0]["rid_id"] == 0xFF00


# ---------------------------------------------------------------------------
# apply_to_spec
# ---------------------------------------------------------------------------


def _build_spec() -> UdsSpecification:
    return UdsSpecification(
        sessions=[
            DiagSession(short_name="DefaultSession", session_id=0x01),
            DiagSession(short_name="ProgrammingSession", session_id=0x02),
            DiagSession(short_name="ExtendedSession", session_id=0x03),
        ],
        services=[
            UdsService(short_name="DiagnosticSessionControl", service_id=0x10),
            UdsService(short_name="RequestDownload", service_id=0x34),
            UdsService(short_name="ReadDataByIdentifier", service_id=0x22),
        ],
        dids=[
            Did(short_name="VIN", did_id=0xF190),
            Did(short_name="AppVersion", did_id=0xF101),
            Did(short_name="OutputControl", did_id=0xD001),
        ],
        routines=[
            Routine(short_name="FlashErase", routine_id=0xFF00),
            Routine(short_name="SelfTest", routine_id=0xF000),
        ],
    )


class TestApplyToSpec:
    def test_defaults_remain_drive(self) -> None:
        spec = _build_spec()
        ov = empty_overlay()
        apply_boot_overlay(spec, ov)
        for s in spec.sessions:
            assert s.domain == "drive"
        for s in spec.services:
            assert s.domain == "drive"
        for d in spec.dids:
            assert d.domain == "drive"
        for r in spec.routines:
            assert r.domain == "drive"

    def test_session_domain_mapped(self) -> None:
        spec = _build_spec()
        ov = empty_overlay()
        ov.domain_map.sessions["ProgrammingSession"] = "boot"
        ov.domain_map.sessions["DefaultSession"] = "both"
        apply_boot_overlay(spec, ov)
        domains = {s.short_name: s.domain for s in spec.sessions}
        assert domains["DefaultSession"] == "both"
        assert domains["ProgrammingSession"] == "boot"
        assert domains["ExtendedSession"] == "drive"  # not mentioned

    def test_service_domain_mapped(self) -> None:
        spec = _build_spec()
        ov = empty_overlay()
        ov.domain_map.sids[0x34] = "boot"
        ov.domain_map.sids[0x10] = "both"
        apply_boot_overlay(spec, ov)
        by_sid = {s.service_id: s.domain for s in spec.services}
        assert by_sid[0x34] == "boot"
        assert by_sid[0x10] == "both"
        assert by_sid[0x22] == "drive"

    def test_did_domain_mapped(self) -> None:
        spec = _build_spec()
        ov = empty_overlay()
        ov.domain_map.dids[0xF190] = "both"
        ov.domain_map.dids[0xD001] = "drive"
        apply_boot_overlay(spec, ov)
        by_did = {d.did_id: d.domain for d in spec.dids}
        assert by_did[0xF190] == "both"
        assert by_did[0xF101] == "drive"
        assert by_did[0xD001] == "drive"

    def test_routine_domain_mapped(self) -> None:
        spec = _build_spec()
        ov = empty_overlay()
        ov.domain_map.rids[0xFF00] = "boot"
        apply_boot_overlay(spec, ov)
        by_rid = {r.routine_id: r.domain for r in spec.routines}
        assert by_rid[0xFF00] == "boot"
        assert by_rid[0xF000] == "drive"

    def test_returns_same_spec_instance(self) -> None:
        spec = _build_spec()
        ov = empty_overlay()
        result = apply_boot_overlay(spec, ov)
        assert result is spec

    def test_idempotent_when_overlay_empty(self) -> None:
        spec = _build_spec()
        apply_boot_overlay(spec, empty_overlay())
        apply_boot_overlay(spec, empty_overlay())  # second pass changes nothing
        assert spec.sessions[0].domain == "drive"


# ---------------------------------------------------------------------------
# Backward-compat for old JSONs without ``domain``
# ---------------------------------------------------------------------------


class TestDomainBackwardCompat:
    def test_load_old_json_no_domain_fields(self) -> None:
        # JSON shape predating the domain field — all four item kinds.
        old = {
            "sessions": [{"short_name": "Default", "session_id": 1}],
            "services": [{"short_name": "S1", "service_id": 0x10}],
            "dids": [{"short_name": "D1", "did_id": 0xF100}],
            "routines": [{"short_name": "R1", "routine_id": 0xFF00}],
        }
        import json as _json

        spec = UdsSpecification.from_json(_json.dumps(old))
        assert spec.sessions[0].domain == "drive"
        assert spec.services[0].domain == "drive"
        assert spec.dids[0].domain == "drive"
        assert spec.routines[0].domain == "drive"

    def test_round_trip_preserves_domain(self) -> None:
        spec = UdsSpecification(
            sessions=[DiagSession(short_name="Default", session_id=1, domain="both")],
            services=[UdsService(short_name="S1", service_id=0x10, domain="boot")],
            dids=[Did(short_name="D1", did_id=0xF100, domain="both")],
            routines=[Routine(short_name="R1", routine_id=0xFF00, domain="boot")],
        )
        re = UdsSpecification.from_json(spec.to_json())
        assert re.sessions[0].domain == "both"
        assert re.services[0].domain == "boot"
        assert re.dids[0].domain == "both"
        assert re.routines[0].domain == "boot"


# ---------------------------------------------------------------------------
# Merge (UdsSpecification.__or__) promotes conflicting domains to "both"
# ---------------------------------------------------------------------------


class TestMergeDomain:
    def test_merge_drive_and_boot_promotes_to_both(self) -> None:
        a = UdsSpecification(
            dids=[Did(short_name="D1", did_id=0xF100, domain="drive")]
        )
        b = UdsSpecification(
            dids=[Did(short_name="D1", did_id=0xF100, domain="boot")]
        )
        merged = a | b
        assert merged.dids[0].domain == "both"

    def test_merge_same_domain_preserved(self) -> None:
        a = UdsSpecification(
            dids=[Did(short_name="D1", did_id=0xF100, domain="drive")]
        )
        b = UdsSpecification(
            dids=[Did(short_name="D1", did_id=0xF100, domain="drive")]
        )
        merged = a | b
        assert merged.dids[0].domain == "drive"

    def test_merge_both_dominates(self) -> None:
        a = UdsSpecification(
            services=[UdsService(short_name="S1", service_id=0x10, domain="both")]
        )
        b = UdsSpecification(
            services=[UdsService(short_name="S1", service_id=0x10, domain="boot")]
        )
        merged = a | b
        assert merged.services[0].domain == "both"

    def test_merge_disjoint_keys_keeps_each_domain(self) -> None:
        a = UdsSpecification(
            dids=[Did(short_name="D1", did_id=0xF100, domain="drive")]
        )
        b = UdsSpecification(
            dids=[Did(short_name="D2", did_id=0xF200, domain="boot")]
        )
        merged = a | b
        by_did = {d.did_id: d.domain for d in merged.dids}
        assert by_did[0xF100] == "drive"
        assert by_did[0xF200] == "boot"

    def test_merge_sessions_promotes(self) -> None:
        a = UdsSpecification(
            sessions=[DiagSession(short_name="Prog", session_id=2, domain="boot")]
        )
        b = UdsSpecification(
            sessions=[DiagSession(short_name="Prog", session_id=2, domain="drive")]
        )
        merged = a | b
        assert merged.sessions[0].domain == "both"

    def test_merge_routines_promotes(self) -> None:
        a = UdsSpecification(
            routines=[Routine(short_name="R", routine_id=0xFF00, domain="drive")]
        )
        b = UdsSpecification(
            routines=[Routine(short_name="R", routine_id=0xFF00, domain="boot")]
        )
        merged = a | b
        assert merged.routines[0].domain == "both"


# ---------------------------------------------------------------------------
# Sample YAML round-trip
# ---------------------------------------------------------------------------


class TestSampleOverlay:
    def test_sample_loads(self) -> None:
        assert SAMPLE_OVERLAY.exists(), "boot_overlay_sample.yaml must ship with the package"
        ov = load_overlay(SAMPLE_OVERLAY)
        assert ov.ecu_name == "ExampleECU"
        assert ov.default_domain == "drive"
        assert "ProgrammingSession" in ov.domain_map.sessions
        assert ov.domain_map.sessions["ProgrammingSession"] == "boot"

    def test_sample_bootloader_section(self) -> None:
        ov = load_overlay(SAMPLE_OVERLAY)
        assert ov.bootloader is not None
        assert isinstance(ov.bootloader, BootloaderInfo)
        assert ov.bootloader.reset_address == 0x00080000
        assert ov.bootloader.download_block_size == 4090
        assert ov.bootloader.checksum_algorithm == "CRC32"
        # programming_sequence non-empty list of strings
        assert len(ov.bootloader.programming_sequence) >= 5
        for step in ov.bootloader.programming_sequence:
            assert isinstance(step, str)
        # at least one flash segment
        assert len(ov.bootloader.flash_segments) >= 1
        assert all(isinstance(s, FlashSegment) for s in ov.bootloader.flash_segments)

    def test_sample_can_ids(self) -> None:
        ov = load_overlay(SAMPLE_OVERLAY)
        assert isinstance(ov.can_ids_drive, DomainCanIds)
        assert isinstance(ov.can_ids_boot, DomainCanIds)
        # exact values are placeholders; just verify they were parsed
        assert ov.can_ids_drive.physical.startswith("0x")
        assert ov.can_ids_boot.physical.startswith("0x")

    def test_sample_boot_only_dids_and_rids(self) -> None:
        ov = load_overlay(SAMPLE_OVERLAY)
        assert len(ov.boot_only_dids) >= 1
        assert all("did_id" in d for d in ov.boot_only_dids)
        assert all(isinstance(d["did_id"], int) for d in ov.boot_only_dids)
        assert len(ov.boot_only_rids) >= 1
        assert all("rid_id" in r for r in ov.boot_only_rids)

    def test_sample_applies_to_sample1_arxml(self) -> None:
        from udsxml2tex import ArxmlParser

        ov = load_overlay(SAMPLE_OVERLAY)
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        apply_boot_overlay(spec, ov)
        # ProgrammingSession should now be tagged boot.
        by_name = {s.short_name: s.domain for s in spec.sessions}
        assert by_name["ProgrammingSession"] == "boot"
        # RequestDownload (0x34) is boot only.
        by_sid = {s.service_id: s.domain for s in spec.services}
        assert by_sid[0x34] == "boot"
        # VIN (0xF190) is "both".
        by_did = {d.did_id: d.domain for d in spec.dids}
        assert by_did[0xF190] == "both"


# ---------------------------------------------------------------------------
# Parser fix (OEM ARXML, gitignored — skip if absent)
# ---------------------------------------------------------------------------


class TestParserOemArxml:
    def test_oem_arxml_yields_services(self) -> None:
        if not OEM_ARXML.exists():
            pytest.skip("OEM ARXML not present (refs/uds-tex-spec-oem)")
        from udsxml2tex import ArxmlParser

        spec = ArxmlParser().parse(OEM_ARXML)
        assert len(spec.services) >= 10, (
            f"expected >= 10 services after the _find_containers fix, "
            f"got {len(spec.services)}"
        )

    def test_oem_arxml_services_have_nonzero_sid(self) -> None:
        if not OEM_ARXML.exists():
            pytest.skip("OEM ARXML not present (refs/uds-tex-spec-oem)")
        from udsxml2tex import ArxmlParser

        spec = ArxmlParser().parse(OEM_ARXML)
        # The _parse_single_service guard must skip table/wrapper containers
        # rather than emitting bogus services with service_id == 0.
        zero_sid = [s for s in spec.services if s.service_id == 0]
        assert not zero_sid, f"got services with service_id=0: {zero_sid}"

    def test_sample1_still_parses_after_fix(self) -> None:
        # The pre-existing sample uses standard SHORT-NAMEs; the broader
        # _find_containers logic must not regress its service count.
        from udsxml2tex import ArxmlParser

        spec = ArxmlParser().parse(SAMPLE_ARXML)
        assert len(spec.services) >= 10


# ---------------------------------------------------------------------------
# Misc dataclass / DomainMap shape checks
# ---------------------------------------------------------------------------


class TestPromoteDomainHelper:
    def test_equal_markers_return_self(self) -> None:
        assert _promote_domain("drive", "drive") == "drive"
        assert _promote_domain("boot", "boot") == "boot"
        assert _promote_domain("both", "both") == "both"

    def test_disagreement_promotes_to_both(self) -> None:
        assert _promote_domain("drive", "boot") == "both"
        assert _promote_domain("boot", "drive") == "both"

    def test_either_both_yields_both(self) -> None:
        assert _promote_domain("both", "drive") == "both"
        assert _promote_domain("both", "boot") == "both"
        assert _promote_domain("drive", "both") == "both"
        assert _promote_domain("boot", "both") == "both"

    def test_unknown_marker_treated_as_drive(self) -> None:
        # Defensive: unknown markers must not crash; they are coerced to "drive".
        assert _promote_domain("foobar", "drive") == "drive"
        assert _promote_domain("", "boot") == "both"


class TestDataclassShapes:
    def test_domainmap_independent_default_factories(self) -> None:
        # Each DomainMap instance must own its own dicts.
        m1 = DomainMap()
        m2 = DomainMap()
        m1.sids[0x10] = "boot"
        assert m2.sids == {}

    def test_bootoverlay_independent_default_factories(self) -> None:
        a = BootOverlay()
        b = BootOverlay()
        a.boot_only_dids.append({"did_id": 0xF180})
        assert b.boot_only_dids == []

    def test_flashsegment_fields(self) -> None:
        s = FlashSegment(name="X", start=0, end=1)
        assert s.description == ""
        assert s.name == "X"

    def test_domaincanids_defaults_empty(self) -> None:
        c = DomainCanIds()
        assert c.physical == ""
        assert c.functional == ""
        assert c.telematics == ""

    def test_bootloaderinfo_defaults(self) -> None:
        b = BootloaderInfo()
        assert b.flash_segments == []
        assert b.programming_sequence == []
        assert b.reset_address is None
        assert b.download_block_size is None
        assert b.checksum_algorithm == ""
