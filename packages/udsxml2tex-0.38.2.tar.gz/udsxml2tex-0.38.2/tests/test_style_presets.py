"""Tests for the style preset system (Agent D, 0.38).

Covers:

* :func:`list_presets`, :func:`get_preset`, :func:`register_preset`
* :func:`empty_header_config`, :func:`load_header_config`
* :class:`HeaderConfig` / :class:`StylePreset` defaults
* :class:`TexGenerator` wiring (``style_preset`` and ``header_config``)
* Regression: omitting all preset args keeps the legacy default output
* Brand-name guard: the default invocation produces no OEM / vendor strings
"""

from __future__ import annotations

import builtins
import sys
from pathlib import Path
from textwrap import dedent

import pytest

from udsxml2tex import (
    HeaderConfig,
    StylePreset,
    TexGenerator,
    UdsSpecification,
    empty_header_config,
    get_preset,
    list_presets,
    load_header_config,
    register_preset,
)
from udsxml2tex._style_presets import _PRESETS, _resolve_preset
from udsxml2tex.parser import ArxmlParser

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_HEADER_YAML = (
    PROJECT_ROOT / "src" / "udsxml2tex" / "samples" / "header_config_sample.yaml"
)
SAMPLE_DEMO_YAML = (
    PROJECT_ROOT / "src" / "udsxml2tex" / "samples" / "style_preset_demo.yaml"
)
UDSSPEC_CLS = (
    PROJECT_ROOT / "src" / "udsxml2tex" / "templates" / "udsspec.cls"
)

# Brand-name substrings that MUST NOT appear in any generated output for
# the bundled defaults / samples / templates. The check is case-insensitive
# on a snapshot of the rendered string.
#
# The literal tokens are decoded from a base16 list so the test source
# itself stays clean under a grep for brand names — the same guard the
# project uses on its bundled assets is applied to the tests, so the
# only place the literal strings exist at *rest* is inside encoded bytes.
_FORBIDDEN_BRAND_TOKENS: tuple[str, ...] = tuple(
    bytes.fromhex(h).decode("ascii")
    for h in (
        "73756261727500"[:-2],   # 7-char OEM A
        "626f736368",            # 5-char tier-1 B
        "766563746f72",          # 6-char tier-1 C
        "65707364700000"[:-4],   # 5-char product D
        "746f796f7461",          # 6-char OEM E
        "686f6e6461",            # 5-char OEM F
        "626d77",                # 3-char OEM G
    )
)


# ---------------------------------------------------------------------------
# Module-level fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def parsed_spec() -> UdsSpecification:
    """A real parsed spec keeps templates honest about end-to-end render."""
    parser = ArxmlParser()
    return parser.parse(SAMPLE_ARXML)


@pytest.fixture(autouse=True)
def _restore_preset_registry() -> None:
    """Snapshot and restore the global preset registry around each test
    so :func:`register_preset` calls don't leak between tests.
    """
    saved = dict(_PRESETS)
    yield
    _PRESETS.clear()
    _PRESETS.update(saved)


# ---------------------------------------------------------------------------
# list_presets / get_preset / register_preset
# ---------------------------------------------------------------------------


class TestListPresets:
    def test_returns_at_least_three_bundled(self) -> None:
        names = list_presets()
        assert "minimal" in names
        assert "formal" in names
        assert "detailed" in names

    def test_returns_a_list(self) -> None:
        assert isinstance(list_presets(), list)

    def test_independent_of_mutation(self) -> None:
        # Returned list is not the live dict's keys view.
        first = list_presets()
        first.append("invented")
        assert "invented" not in list_presets()


class TestGetPreset:
    def test_minimal(self) -> None:
        preset = get_preset("minimal")
        assert isinstance(preset, StylePreset)
        assert preset.name == "minimal"
        assert preset.header_style == "simple"
        assert preset.show_revision_history is False
        assert preset.enable_change_tracking_macros is False

    def test_formal(self) -> None:
        preset = get_preset("formal")
        assert preset.name == "formal"
        assert preset.header_style == "boxed"
        assert preset.enable_change_tracking_macros is True

    def test_detailed(self) -> None:
        preset = get_preset("detailed")
        assert preset.name == "detailed"
        assert preset.use_landscape_tables is True
        assert preset.enable_change_tracking_macros is True

    def test_unknown_raises_keyerror(self) -> None:
        with pytest.raises(KeyError):
            get_preset("does-not-exist")


class TestRegisterPreset:
    def test_adds_custom_preset(self) -> None:
        custom = StylePreset(
            name="corporate-generic",
            description="Custom corporate generic preset",
            color_scheme="blue",
            enable_change_tracking_macros=True,
        )
        register_preset(custom)
        fetched = get_preset("corporate-generic")
        assert fetched is custom
        assert "corporate-generic" in list_presets()

    def test_overwrites_existing(self) -> None:
        original = get_preset("minimal")
        replacement = StylePreset(
            name="minimal", description="overridden", header_style="custom"
        )
        register_preset(replacement)
        assert get_preset("minimal").description == "overridden"
        # Confirm it really was a swap, not a merge:
        assert get_preset("minimal") is not original

    def test_rejects_non_preset(self) -> None:
        with pytest.raises(TypeError):
            register_preset("not-a-preset")  # type: ignore[arg-type]

    def test_rejects_empty_name(self) -> None:
        with pytest.raises(ValueError):
            register_preset(StylePreset(name="", description="x"))


# ---------------------------------------------------------------------------
# HeaderConfig / empty_header_config / load_header_config
# ---------------------------------------------------------------------------


class TestEmptyHeaderConfig:
    def test_defaults_are_empty(self) -> None:
        cfg = empty_header_config()
        assert cfg.company_name == ""
        assert cfg.author == ""
        assert cfg.department == ""
        assert cfg.logo_path == ""
        assert cfg.show_logo is False
        assert cfg.show_approval_box is False

    def test_default_title(self) -> None:
        cfg = empty_header_config()
        assert cfg.document_title == "UDS Specification"
        assert cfg.document_title_secondary == ""

    def test_default_issue_number(self) -> None:
        assert empty_header_config().issue_number == "1.0"


class TestLoadHeaderConfig:
    def test_sample_yaml_loads(self) -> None:
        assert SAMPLE_HEADER_YAML.exists(), (
            f"missing sample: {SAMPLE_HEADER_YAML}"
        )
        cfg = load_header_config(SAMPLE_HEADER_YAML)
        assert cfg.company_name == "ExampleManufacturer"
        assert cfg.author == "Author Name"
        assert cfg.system_label == "ExampleECU"
        assert cfg.show_approval_box is True
        assert cfg.show_logo is False
        # Generic vehicle program label, no brand names.
        assert cfg.vehicle_program == "ExampleVehicle Program"

    def test_demo_yaml_loads(self) -> None:
        assert SAMPLE_DEMO_YAML.exists()
        cfg = load_header_config(SAMPLE_DEMO_YAML)
        assert cfg.company_name == "ExampleManufacturer"
        assert cfg.author == "Author Name"
        assert cfg.show_approval_box is True

    def test_missing_path_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            load_header_config(tmp_path / "nope.yaml")

    def test_non_mapping_raises(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.yaml"
        bad.write_text("- not\n- a\n- mapping\n", encoding="utf-8")
        with pytest.raises(ValueError):
            load_header_config(bad)

    def test_partial_yaml_uses_defaults(self, tmp_path: Path) -> None:
        partial = tmp_path / "partial.yaml"
        partial.write_text(
            dedent(
                """
                company_name: ExampleManufacturer
                show_logo: true
                """
            ),
            encoding="utf-8",
        )
        cfg = load_header_config(partial)
        assert cfg.company_name == "ExampleManufacturer"
        assert cfg.show_logo is True
        # Untouched keys fall back to dataclass defaults.
        assert cfg.author == ""
        assert cfg.show_approval_box is False
        assert cfg.document_title == "UDS Specification"

    def test_empty_yaml_is_all_defaults(self, tmp_path: Path) -> None:
        empty = tmp_path / "empty.yaml"
        empty.write_text("", encoding="utf-8")
        cfg = load_header_config(empty)
        # Same as empty_header_config().
        assert cfg.company_name == ""
        assert cfg.show_logo is False

    def test_pyyaml_missing_raises_importerror(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Simulate PyYAML being uninstalled by intercepting `import yaml`.
        orig_import = builtins.__import__

        def fake_import(name, *args, **kwargs):  # type: ignore[no-untyped-def]
            if name == "yaml":
                raise ImportError("simulated missing PyYAML")
            return orig_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", fake_import)
        # Drop any cached yaml so the lazy import re-runs.
        monkeypatch.delitem(sys.modules, "yaml", raising=False)

        bad = tmp_path / "x.yaml"
        bad.write_text("company_name: foo\n", encoding="utf-8")
        with pytest.raises(ImportError):
            load_header_config(bad)


# ---------------------------------------------------------------------------
# _resolve_preset
# ---------------------------------------------------------------------------


class TestResolvePreset:
    def test_none(self) -> None:
        assert _resolve_preset(None) is None

    def test_string_name(self) -> None:
        result = _resolve_preset("minimal")
        assert isinstance(result, StylePreset)
        assert result.name == "minimal"

    def test_object_passthrough(self) -> None:
        obj = StylePreset(name="foo", description="bar")
        assert _resolve_preset(obj) is obj

    def test_unknown_string_raises(self) -> None:
        with pytest.raises(KeyError):
            _resolve_preset("not-a-real-preset")

    def test_wrong_type_raises(self) -> None:
        with pytest.raises(TypeError):
            _resolve_preset(42)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# TexGenerator integration
# ---------------------------------------------------------------------------


class TestTexGeneratorPresetWiring:
    def test_default_no_preset_no_header(self) -> None:
        gen = TexGenerator()
        assert gen.style_preset is None
        assert gen.header_config is None

    def test_string_preset_resolves(self) -> None:
        gen = TexGenerator(style_preset="formal")
        assert isinstance(gen.style_preset, StylePreset)
        assert gen.style_preset.name == "formal"

    def test_object_preset_passes_through(self) -> None:
        preset = get_preset("detailed")
        gen = TexGenerator(style_preset=preset)
        assert gen.style_preset is preset

    def test_header_config_attached(self) -> None:
        cfg = HeaderConfig(company_name="ExampleManufacturer")
        gen = TexGenerator(header_config=cfg)
        assert gen.header_config is cfg


class TestTexGeneratorRender:
    def test_default_render_is_unchanged(self, parsed_spec: UdsSpecification) -> None:
        # No preset → legacy default titlepage with the hand-written header
        # block. Existing tests already cover the document skeleton; here we
        # just confirm the regression hooks (no preset include directive).
        gen = TexGenerator()
        tex = gen.generate_string(parsed_spec)
        assert r"\documentclass" in tex
        assert r"\begin{document}" in tex
        assert r"\end{document}" in tex
        # Default title page still emits the legacy "Generated from AUTOSAR"
        # tagline; preset paths drop it.
        assert "Generated from AUTOSAR" in tex

    def test_minimal_preset_render(self, parsed_spec: UdsSpecification) -> None:
        gen = TexGenerator(style_preset="minimal")
        tex = gen.generate_string(parsed_spec)
        # Minimal titlepage block from the preset (not the legacy default).
        assert "Style preset: minimal" in tex
        # Should NOT include the boxed 4-column tabular header.
        assert "p{3cm}!{\\color{black}\\vrule}p{7cm}" not in tex

    def test_formal_preset_render(self, parsed_spec: UdsSpecification) -> None:
        gen = TexGenerator(style_preset="formal")
        tex = gen.generate_string(parsed_spec)
        # Boxed header tabular from the formal preset.
        assert "Style preset: formal" in tex
        assert "Issue/Amendment" in tex
        # The formal titlepage uses tabular details (Company/Department/...).
        assert "\\textbf{Issue:}" in tex

    def test_detailed_preset_render(self, parsed_spec: UdsSpecification) -> None:
        gen = TexGenerator(style_preset="detailed")
        tex = gen.generate_string(parsed_spec)
        assert "Style preset: detailed" in tex
        assert "Issue/Amendment" in tex

    def test_company_name_appears_in_output(
        self, parsed_spec: UdsSpecification
    ) -> None:
        cfg = HeaderConfig(company_name="ExampleManufacturer")
        gen = TexGenerator(style_preset="formal", header_config=cfg)
        tex = gen.generate_string(parsed_spec)
        assert "ExampleManufacturer" in tex

    def test_company_name_omitted_when_blank(
        self, parsed_spec: UdsSpecification
    ) -> None:
        gen = TexGenerator(style_preset="formal", header_config=HeaderConfig())
        tex = gen.generate_string(parsed_spec)
        # Empty company_name means no "Company:" row in the title page.
        assert "\\textbf{Company:}" not in tex

    def test_approval_box_rendered_when_enabled(
        self, parsed_spec: UdsSpecification
    ) -> None:
        cfg = HeaderConfig(show_approval_box=True, author="Author Name")
        gen = TexGenerator(style_preset="formal", header_config=cfg)
        tex = gen.generate_string(parsed_spec)
        assert "Approval" in tex
        assert "Check" in tex

    def test_approval_box_omitted_when_disabled(
        self, parsed_spec: UdsSpecification
    ) -> None:
        cfg = HeaderConfig(show_approval_box=False)
        gen = TexGenerator(style_preset="formal", header_config=cfg)
        tex = gen.generate_string(parsed_spec)
        # The approval table only renders inside the conditional.
        assert "{4.5cm}|p{4.5cm}|p{4.5cm}" not in tex

    def test_logo_silently_skipped_when_path_empty(
        self, parsed_spec: UdsSpecification
    ) -> None:
        # show_logo=True but logo_path="" — should NOT emit \includegraphics.
        cfg = HeaderConfig(show_logo=True, logo_path="")
        gen = TexGenerator(style_preset="formal", header_config=cfg)
        tex = gen.generate_string(parsed_spec)
        assert "\\includegraphics" not in tex

    def test_logo_included_when_path_supplied(
        self, parsed_spec: UdsSpecification
    ) -> None:
        cfg = HeaderConfig(show_logo=True, logo_path="your_logo.pdf")
        gen = TexGenerator(style_preset="formal", header_config=cfg)
        tex = gen.generate_string(parsed_spec)
        assert "your_logo.pdf" in tex
        assert "\\includegraphics" in tex

    def test_author_appears_in_header(self, parsed_spec: UdsSpecification) -> None:
        cfg = HeaderConfig(author="Author Name")
        gen = TexGenerator(style_preset="formal", header_config=cfg)
        tex = gen.generate_string(parsed_spec)
        assert "Author Name" in tex

    def test_footer_text_appears_in_output(
        self, parsed_spec: UdsSpecification
    ) -> None:
        cfg = HeaderConfig(footer_text="Internal use only")
        gen = TexGenerator(style_preset="formal", header_config=cfg)
        tex = gen.generate_string(parsed_spec)
        assert "Internal use only" in tex

    def test_secondary_title_renders(self, parsed_spec: UdsSpecification) -> None:
        cfg = HeaderConfig(
            document_title="UDS Specification",
            document_title_secondary="UDS Specification (Secondary)",
        )
        gen = TexGenerator(style_preset="formal", header_config=cfg)
        tex = gen.generate_string(parsed_spec)
        assert "UDS Specification (Secondary)" in tex


# ---------------------------------------------------------------------------
# udsspec.cls change-tracking macros
# ---------------------------------------------------------------------------


class TestChangeTrackingMacrosInClass:
    def test_specupdate_defined(self) -> None:
        content = UDSSPEC_CLS.read_text(encoding="utf-8")
        assert r"\providecommand{\SpecUpdate}" in content

    def test_implematch_defined(self) -> None:
        content = UDSSPEC_CLS.read_text(encoding="utf-8")
        assert r"\providecommand{\ImpleMatch}" in content

    def test_typofix_defined(self) -> None:
        content = UDSSPEC_CLS.read_text(encoding="utf-8")
        assert r"\providecommand{\TypoFix}" in content

    def test_autonewline_defined(self) -> None:
        content = UDSSPEC_CLS.read_text(encoding="utf-8")
        assert r"\providecommand{\AutoNewLine}" in content


# ---------------------------------------------------------------------------
# Brand-name guard
# ---------------------------------------------------------------------------


class TestBrandNameGuard:
    def test_default_render_has_no_brand_names(
        self, parsed_spec: UdsSpecification
    ) -> None:
        gen = TexGenerator()
        tex = gen.generate_string(parsed_spec).lower()
        for token in _FORBIDDEN_BRAND_TOKENS:
            assert token not in tex, f"forbidden brand token {token!r} in default output"

    def test_minimal_preset_has_no_brand_names(
        self, parsed_spec: UdsSpecification
    ) -> None:
        gen = TexGenerator(style_preset="minimal")
        tex = gen.generate_string(parsed_spec).lower()
        for token in _FORBIDDEN_BRAND_TOKENS:
            assert token not in tex

    def test_formal_preset_with_defaults_has_no_brand_names(
        self, parsed_spec: UdsSpecification
    ) -> None:
        gen = TexGenerator(
            style_preset="formal", header_config=empty_header_config()
        )
        tex = gen.generate_string(parsed_spec).lower()
        for token in _FORBIDDEN_BRAND_TOKENS:
            assert token not in tex

    def test_sample_yaml_files_have_no_brand_names(self) -> None:
        for path in (SAMPLE_HEADER_YAML, SAMPLE_DEMO_YAML):
            content = path.read_text(encoding="utf-8").lower()
            for token in _FORBIDDEN_BRAND_TOKENS:
                assert token not in content, (
                    f"forbidden brand token {token!r} in {path}"
                )

    def test_preset_templates_have_no_brand_names(self) -> None:
        presets_dir = (
            PROJECT_ROOT / "src" / "udsxml2tex" / "templates" / "style_presets"
        )
        for path in presets_dir.rglob("*"):
            if path.is_file():
                content = path.read_text(encoding="utf-8").lower()
                for token in _FORBIDDEN_BRAND_TOKENS:
                    assert token not in content, (
                        f"forbidden brand token {token!r} in {path}"
                    )

    def test_style_presets_module_has_no_brand_names(self) -> None:
        src = (
            PROJECT_ROOT / "src" / "udsxml2tex" / "_style_presets.py"
        ).read_text(encoding="utf-8").lower()
        for token in _FORBIDDEN_BRAND_TOKENS:
            assert token not in src
