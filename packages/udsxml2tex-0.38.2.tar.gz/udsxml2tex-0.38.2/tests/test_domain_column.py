"""Tests for Drive/Boot domain-column rendering across output formats."""

from __future__ import annotations

from pathlib import Path

import pytest

from udsxml2tex import ArxmlParser, BootOverlay, TexGenerator, apply_boot_overlay
from udsxml2tex.boot_overlay import DomainMap
from udsxml2tex.generator import (
    DOMAIN_LABELS_LONG,
    DOMAIN_LABELS_SHORT,
    _domain_label,
    _resolve_show_domain,
    _should_show_domain,
)
from udsxml2tex.models import DiagSession, Did, Routine, UdsService, UdsSpecification

SAMPLE_DCM = Path(__file__).resolve().parent.parent / "src/udsxml2tex/samples/sample1_dcm.arxml"


def _make_spec_with_boot_did() -> UdsSpecification:
    spec = ArxmlParser().parse(SAMPLE_DCM)
    overlay = BootOverlay(domain_map=DomainMap(
        sids={0x10: "both", 0x34: "boot"},
        dids={d.did_id: "boot" for d in spec.dids[:1]} if spec.dids else {},
        rids={r.routine_id: "boot" for r in spec.routines[:1]} if spec.routines else {},
        sessions={"PROGRAMMING_SESSION": "boot"},
    ))
    apply_boot_overlay(spec, overlay)
    return spec


# ---------------------------------------------------------------------------
# Label helpers
# ---------------------------------------------------------------------------

class TestDomainLabel:
    def test_long_drive(self) -> None:
        assert _domain_label("drive") == DOMAIN_LABELS_LONG["drive"]

    def test_long_boot(self) -> None:
        assert _domain_label("boot") == DOMAIN_LABELS_LONG["boot"]

    def test_long_both(self) -> None:
        assert _domain_label("both") == DOMAIN_LABELS_LONG["both"]

    def test_short_drive(self) -> None:
        assert _domain_label("drive", short=True) == DOMAIN_LABELS_SHORT["drive"]

    def test_short_boot(self) -> None:
        assert _domain_label("boot", short=True) == DOMAIN_LABELS_SHORT["boot"]

    def test_short_both(self) -> None:
        assert _domain_label("both", short=True) == DOMAIN_LABELS_SHORT["both"]

    def test_unknown_falls_back_to_drive(self) -> None:
        assert _domain_label("xxx") == DOMAIN_LABELS_LONG["drive"]

    def test_unknown_short_falls_back_to_drive(self) -> None:
        assert _domain_label("", short=True) == DOMAIN_LABELS_SHORT["drive"]


# ---------------------------------------------------------------------------
# _should_show_domain
# ---------------------------------------------------------------------------

class TestShouldShowDomain:
    def test_fresh_parse_is_all_drive(self) -> None:
        spec = ArxmlParser().parse(SAMPLE_DCM)
        assert _should_show_domain(spec) is False

    def test_with_boot_did(self) -> None:
        spec = ArxmlParser().parse(SAMPLE_DCM)
        if spec.dids:
            spec.dids[0].domain = "boot"
        assert _should_show_domain(spec) is True

    def test_with_both_service(self) -> None:
        spec = ArxmlParser().parse(SAMPLE_DCM)
        if spec.services:
            spec.services[0].domain = "both"
        assert _should_show_domain(spec) is True

    def test_empty_spec(self) -> None:
        spec = UdsSpecification(ecu_name="E")
        assert _should_show_domain(spec) is False

    def test_boot_session_triggers_show(self) -> None:
        spec = UdsSpecification(
            ecu_name="E",
            sessions=[DiagSession(short_name="PROG", session_id=2, domain="boot")],
        )
        assert _should_show_domain(spec) is True

    def test_boot_routine_triggers_show(self) -> None:
        spec = UdsSpecification(
            ecu_name="E",
            routines=[Routine(short_name="R", routine_id=0xFF00, domain="boot")],
        )
        assert _should_show_domain(spec) is True


# ---------------------------------------------------------------------------
# _resolve_show_domain
# ---------------------------------------------------------------------------

class TestResolveShowDomain:
    def test_auto_drive_only(self) -> None:
        spec = UdsSpecification(ecu_name="E")
        assert _resolve_show_domain(spec, "auto") is False

    def test_auto_with_boot(self) -> None:
        spec = UdsSpecification(ecu_name="E",
                                services=[UdsService(short_name="x", service_id=1, domain="boot")])
        assert _resolve_show_domain(spec, "auto") is True

    def test_always(self) -> None:
        spec = UdsSpecification(ecu_name="E")
        assert _resolve_show_domain(spec, "always") is True

    def test_never_with_boot(self) -> None:
        spec = UdsSpecification(ecu_name="E",
                                services=[UdsService(short_name="x", service_id=1, domain="boot")])
        assert _resolve_show_domain(spec, "never") is False

    def test_case_insensitive(self) -> None:
        spec = UdsSpecification(ecu_name="E")
        assert _resolve_show_domain(spec, "ALWAYS") is True

    def test_empty_string_treats_as_auto(self) -> None:
        spec = UdsSpecification(ecu_name="E")
        assert _resolve_show_domain(spec, "") is False

    def test_unknown_value_treats_as_auto(self) -> None:
        spec = UdsSpecification(ecu_name="E")
        assert _resolve_show_domain(spec, "weird") is False


# ---------------------------------------------------------------------------
# Generator integration — Domain column appears in output
# ---------------------------------------------------------------------------

class TestGeneratorDomain:
    def test_tex_no_overlay_no_domain_col(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_DCM)
        out = tmp_path / "out.tex"
        TexGenerator().generate(spec, out, show_domain="auto")
        text = out.read_text(encoding="utf-8")
        assert "Bootloader" not in text or "domain_column_header" not in text

    def test_tex_with_overlay_shows_domain(self, tmp_path: Path) -> None:
        spec = _make_spec_with_boot_did()
        out = tmp_path / "out.tex"
        TexGenerator().generate(spec, out, show_domain="auto")
        text = out.read_text(encoding="utf-8")
        # Header column AND at least one Boot/Both label rendered.
        assert "textbf{Domain}" in text
        assert "Boot" in text or "Both" in text

    def test_html_with_overlay_emits_boot_class_and_header(self, tmp_path: Path) -> None:
        spec = _make_spec_with_boot_did()
        out = tmp_path / "out.html"
        TexGenerator().generate_html(spec, out, show_domain="auto")
        text = out.read_text(encoding="utf-8")
        assert "<th>Domain</th>" in text
        assert 'class="boot-only"' in text or "Boot" in text

    def test_md_with_overlay_shows_boot(self, tmp_path: Path) -> None:
        spec = _make_spec_with_boot_did()
        out = tmp_path / "out.md"
        TexGenerator().generate_markdown(spec, out)
        text = out.read_text(encoding="utf-8")
        assert "Boot" in text

    def test_csv_with_overlay_has_domain_column(self, tmp_path: Path) -> None:
        spec = _make_spec_with_boot_did()
        TexGenerator().generate_csv(spec, tmp_path)
        csv_text = "\n".join(p.read_text(encoding="utf-8") for p in tmp_path.glob("*.csv"))
        assert csv_text
        # CSV header row contains "domain" for sessions/services/routines tables.
        assert "domain" in csv_text.lower()

    def test_always_with_drive_only_spec_still_renders(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_DCM)
        out = tmp_path / "out.tex"
        TexGenerator().generate(spec, out, show_domain="always")
        # Should render without error
        assert out.exists() and out.stat().st_size > 100

    def test_never_with_boot_does_not_show(self, tmp_path: Path) -> None:
        spec = _make_spec_with_boot_did()
        out = tmp_path / "out.tex"
        TexGenerator().generate(spec, out, show_domain="never")
        # Should still render valid tex
        assert out.exists() and out.stat().st_size > 100


# ---------------------------------------------------------------------------
# Overlay + reprogramming end-to-end
# ---------------------------------------------------------------------------

class TestOverlayReprogrammingIntegration:
    def test_overlay_with_bootloader_emits_section(self, tmp_path: Path) -> None:
        from udsxml2tex.boot_overlay import BootloaderInfo, FlashSegment
        spec = ArxmlParser().parse(SAMPLE_DCM)
        overlay = BootOverlay(
            bootloader=BootloaderInfo(
                programming_sequence=["Step 1: enter programming session",
                                       "Step 2: download"],
                flash_segments=[FlashSegment(name="AppCode", start=0x100000,
                                              end=0x1FFFFF)],
            )
        )
        out = tmp_path / "out.tex"
        TexGenerator().generate(spec, out, overlay=overlay)
        text = out.read_text(encoding="utf-8")
        assert "Bootloader" in text or "ブートローダ" in text
        assert "AppCode" in text

    def test_no_overlay_produces_no_bootloader_section(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_DCM)
        out = tmp_path / "out.tex"
        TexGenerator().generate(spec, out)
        text = out.read_text(encoding="utf-8")
        # No reprogramming-specific markers
        assert "AppCode" not in text

    def test_empty_overlay_produces_no_section(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_DCM)
        out = tmp_path / "out.tex"
        TexGenerator().generate(spec, out, overlay=BootOverlay())
        text = out.read_text(encoding="utf-8")
        # Empty overlay has no bootloader data; should match no-overlay output shape
        assert "AppCode" not in text


# ---------------------------------------------------------------------------
# Brand-name sanity check
# ---------------------------------------------------------------------------

class TestNoBrandNames:
    @pytest.mark.parametrize("brand", ["SUBARU", "Bosch", "Vector", "EPSdp", "BMW", "Toyota"])
    def test_default_output_excludes_brand(self, tmp_path: Path, brand: str) -> None:
        spec = ArxmlParser().parse(SAMPLE_DCM)
        out = tmp_path / "out.tex"
        TexGenerator().generate(spec, out)
        text = out.read_text(encoding="utf-8")
        assert brand not in text, f"Output unexpectedly contains brand name {brand!r}"
