"""Tests for the PDX (ZIP) packager (`udsxml2tex.odx.pdx_packager`)."""

from __future__ import annotations

import zipfile
from pathlib import Path

import pytest

from udsxml2tex import ArxmlParser, CanTpParser
from udsxml2tex.odx import (
    ComparamSubset,
    DiagLayerContainer,
    OdxCategory,
    OdxDocument,
    map_spec_to_odx,
)
from udsxml2tex.odx.pdx_packager import (
    REPRODUCIBLE_TIMESTAMP,
    PdxPackResult,
    pack_pdx,
    write_loose_odx,
)

# The packager imports serializers lazily. We import them up-front so the
# test module is skipped cleanly when one of the agent-2/3/4/5 serializers
# has not yet been committed. Once the full suite is in place these
# ``importorskip`` calls are no-ops.
pytest.importorskip("udsxml2tex.odx.serializers.odx_d")
pytest.importorskip("udsxml2tex.odx.serializers.odx_cs")


FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_CANTP = FIXTURES_DIR / "sample_cantp.arxml"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _minimal_odx_d(short_name: str = "ECU") -> OdxDocument:
    """Build a minimal ODX-D document accepted by the serializer."""
    return OdxDocument(
        category=OdxCategory.DIAG_LAYER,
        diag_layer_container=DiagLayerContainer(
            oid=f"oid.dlc.{short_name}",
            short_name=f"DLC_{short_name}",
            long_name=f"DiagLayerContainer for {short_name}",
        ),
        pdx_member_path=f"{short_name}.odx-d",
    )


def _minimal_odx_cs(short_name: str = "ISO_15765_2") -> OdxDocument:
    """Build a minimal ODX-CS document accepted by the serializer."""
    return OdxDocument(
        category=OdxCategory.COMPARAM_SUBSET,
        comparam_subset=ComparamSubset(
            oid=f"oid.cs.{short_name}",
            short_name=short_name,
            category=short_name,
        ),
        pdx_member_path=f"{short_name}.odx-cs",
    )


@pytest.fixture
def sample_dlc_doc() -> OdxDocument:
    return _minimal_odx_d("ECU")


@pytest.fixture
def sample_cs_doc() -> OdxDocument:
    return _minimal_odx_cs("ISO_15765_2")


@pytest.fixture(scope="module")
def sample_spec_pdx_docs():
    """Run the mapper on the bundled ARXML to get realistic input."""
    spec = ArxmlParser().parse(SAMPLE_ARXML)
    spec.transport_config = CanTpParser().parse(SAMPLE_CANTP)
    return map_spec_to_odx(spec)


# ---------------------------------------------------------------------------
# Pack: empty input
# ---------------------------------------------------------------------------


class TestPackEmpty:
    """Edge case: zero documents → still produce a valid archive."""

    def test_empty_dict_writes_only_index(self, tmp_path: Path):
        out = tmp_path / "Empty.pdx"
        result = pack_pdx({}, out)
        assert out.is_file()
        assert result.members == ["index.xml"]
        with zipfile.ZipFile(out) as zf:
            assert zf.namelist() == ["index.xml"]

    def test_empty_iterable(self, tmp_path: Path):
        out = tmp_path / "Empty2.pdx"
        result = pack_pdx([], out)
        assert result.members == ["index.xml"]


# ---------------------------------------------------------------------------
# Pack: single document
# ---------------------------------------------------------------------------


class TestPackSingle:
    """One DIAG-LAYER document is the most common case."""

    def test_single_odx_d_members(self, tmp_path: Path, sample_dlc_doc):
        out = tmp_path / "ECU.pdx"
        result = pack_pdx({sample_dlc_doc.pdx_member_path: sample_dlc_doc}, out)
        assert result.members == ["index.xml", "ECU.odx-d"]
        with zipfile.ZipFile(out) as zf:
            names = zf.namelist()
        assert names == ["index.xml", "ECU.odx-d"]

    def test_single_odx_d_contains_xml_payload(
        self, tmp_path: Path, sample_dlc_doc
    ):
        out = tmp_path / "ECU.pdx"
        pack_pdx({sample_dlc_doc.pdx_member_path: sample_dlc_doc}, out)
        with zipfile.ZipFile(out) as zf:
            payload = zf.read("ECU.odx-d")
        assert payload.startswith(b"<?xml")
        assert b"<DIAG-LAYER-CONTAINER" in payload

    def test_iterable_input_uses_pdx_member_path(self, tmp_path: Path):
        doc = _minimal_odx_d("Foo")
        out = tmp_path / "Foo.pdx"
        result = pack_pdx([doc], out)
        assert "Foo.odx-d" in result.members


# ---------------------------------------------------------------------------
# Pack: multiple categories
# ---------------------------------------------------------------------------


class TestPackMultiCategory:
    """Combinations of categories all show up in members and index.xml."""

    def test_dlc_plus_cs(
        self, tmp_path: Path, sample_dlc_doc, sample_cs_doc
    ):
        out = tmp_path / "Multi.pdx"
        result = pack_pdx(
            {
                sample_dlc_doc.pdx_member_path: sample_dlc_doc,
                sample_cs_doc.pdx_member_path: sample_cs_doc,
            },
            out,
        )
        assert "ECU.odx-d" in result.members
        assert "ISO_15765_2.odx-cs" in result.members

    def test_index_lists_each_member(
        self, tmp_path: Path, sample_dlc_doc, sample_cs_doc
    ):
        out = tmp_path / "Multi.pdx"
        result = pack_pdx(
            {
                sample_dlc_doc.pdx_member_path: sample_dlc_doc,
                sample_cs_doc.pdx_member_path: sample_cs_doc,
            },
            out,
        )
        assert b"ECU.odx-d" in result.index_xml
        assert b"ISO_15765_2.odx-cs" in result.index_xml


# ---------------------------------------------------------------------------
# Reproducible builds
# ---------------------------------------------------------------------------


class TestReproducible:
    """Two packs of the same input must be byte-identical."""

    def test_byte_identical_dlc_only(self, tmp_path: Path):
        d = _minimal_odx_d("ECU")
        a = tmp_path / "a.pdx"
        b = tmp_path / "b.pdx"
        pack_pdx({d.pdx_member_path: d}, a)
        pack_pdx({d.pdx_member_path: d}, b)
        assert a.read_bytes() == b.read_bytes()

    def test_byte_identical_multi_category(self, tmp_path: Path):
        docs = {
            "ECU.odx-d": _minimal_odx_d("ECU"),
            "ISO_15765_2.odx-cs": _minimal_odx_cs("ISO_15765_2"),
        }
        a = tmp_path / "a.pdx"
        b = tmp_path / "b.pdx"
        pack_pdx(docs, a)
        pack_pdx(docs, b)
        assert a.read_bytes() == b.read_bytes()

    def test_zip_member_timestamp_fixed(self, tmp_path: Path, sample_dlc_doc):
        out = tmp_path / "ECU.pdx"
        pack_pdx({sample_dlc_doc.pdx_member_path: sample_dlc_doc}, out)
        with zipfile.ZipFile(out) as zf:
            for info in zf.infolist():
                assert info.date_time == REPRODUCIBLE_TIMESTAMP


# ---------------------------------------------------------------------------
# Extra files
# ---------------------------------------------------------------------------


class TestExtraFiles:
    """``extra_files`` lets callers embed binary blobs / logos."""

    def test_extra_files_present(self, tmp_path: Path, sample_dlc_doc):
        out = tmp_path / "ECU.pdx"
        extras = {"flash/app.bin": b"\xde\xad\xbe\xef", "README.txt": b"hello"}
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc},
            out,
            extra_files=extras,
        )
        assert "flash/app.bin" in result.members
        assert "README.txt" in result.members
        with zipfile.ZipFile(out) as zf:
            assert zf.read("flash/app.bin") == b"\xde\xad\xbe\xef"
            assert zf.read("README.txt") == b"hello"

    def test_extra_files_not_in_index(self, tmp_path: Path, sample_dlc_doc):
        out = tmp_path / "ECU.pdx"
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc},
            out,
            extra_files={"flash/app.bin": b"\xab"},
        )
        # extras must not pollute the index — only .odx-* members.
        assert b"flash/app.bin" not in result.index_xml


# ---------------------------------------------------------------------------
# index.xml structure
# ---------------------------------------------------------------------------


class TestIndexXml:
    """``index.xml`` is well-formed and follows the conventional schema."""

    def test_index_xml_is_well_formed(
        self, tmp_path: Path, sample_dlc_doc
    ):
        from lxml import etree

        out = tmp_path / "ECU.pdx"
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc}, out
        )
        root = etree.fromstring(result.index_xml)
        assert root.tag == "ODX-INDEX"
        assert root.get("MODEL-VERSION") == "2.2.0"
        entries = root.find("ENTRIES")
        assert entries is not None
        assert len(entries.findall("ENTRY")) == 1

    def test_index_entry_fields(self, tmp_path: Path, sample_dlc_doc):
        from lxml import etree

        out = tmp_path / "ECU.pdx"
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc}, out
        )
        root = etree.fromstring(result.index_xml)
        entry = root.find("ENTRIES/ENTRY")
        assert entry.find("FILE-NAME").text == "ECU.odx-d"
        assert entry.find("CATEGORY").text == "DIAG-LAYER"
        assert entry.find("PDX-MIME-TYPE").text == "application/vnd.iso.odx-d+xml"
        assert entry.find("SHORT-NAME").text == "DLC_ECU"

    def test_index_generated_block(self, tmp_path: Path, sample_dlc_doc):
        from lxml import etree

        out = tmp_path / "ECU.pdx"
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc},
            out,
            tool_version="udsxml2tex/0.36.0",
        )
        root = etree.fromstring(result.index_xml)
        tool = root.find("GENERATED/TOOL")
        assert tool is not None and tool.text == "udsxml2tex/0.36.0"
        date = root.find("GENERATED/DATE")
        assert date is not None and date.text

    def test_index_xml_inside_archive_matches_result(
        self, tmp_path: Path, sample_dlc_doc
    ):
        out = tmp_path / "ECU.pdx"
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc}, out
        )
        with zipfile.ZipFile(out) as zf:
            on_disk = zf.read("index.xml")
        assert on_disk == result.index_xml


# ---------------------------------------------------------------------------
# Integration: ARXML → mapper → pack
# ---------------------------------------------------------------------------


class TestIntegration:
    """End-to-end: ARXML → ODX IR → PDX, with members matching expectations."""

    def test_round_trip_members(
        self, tmp_path: Path, sample_spec_pdx_docs
    ):
        out = tmp_path / "Sample.pdx"
        result = pack_pdx(sample_spec_pdx_docs, out)
        with zipfile.ZipFile(out) as zf:
            names = set(zf.namelist())
        assert "index.xml" in names
        # mapper always produces at least one ODX-D entry
        assert any(n.endswith(".odx-d") for n in names)
        # every mapper key shows up
        for key in sample_spec_pdx_docs:
            assert key in names
            assert key in result.members

    def test_archive_is_valid_zip(self, tmp_path: Path, sample_spec_pdx_docs):
        out = tmp_path / "Sample.pdx"
        pack_pdx(sample_spec_pdx_docs, out)
        assert zipfile.is_zipfile(out)


# ---------------------------------------------------------------------------
# Validation flag
# ---------------------------------------------------------------------------


class TestValidationFlag:
    """``validate=True`` runs the XSD validator; ``False`` leaves it alone."""

    def test_validate_false_default(self, tmp_path: Path, sample_dlc_doc):
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc},
            tmp_path / "x.pdx",
        )
        assert result.validation_errors == []

    def test_validate_true_passes_on_valid_output(
        self, tmp_path: Path, sample_dlc_doc
    ):
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc},
            tmp_path / "x.pdx",
            validate=True,
        )
        # lenient XSDs should be happy with the structured serializer output.
        assert result.validation_errors == []

    def test_validate_true_reports_errors_but_completes(
        self, tmp_path: Path, monkeypatch
    ):
        """When a member fails validation packaging still completes."""
        import udsxml2tex.odx.pdx_packager as pkg

        # Replace the dispatch helper with one that emits clearly-wrong bytes
        # for the COMPARAM-SUBSET document. The DIAG-LAYER document still uses
        # the real serializer so the bytes-level archive is valid.
        original = pkg._serialize

        def stub(doc):
            if doc.category == OdxCategory.COMPARAM_SUBSET:
                return b"<?xml version='1.0'?><NOT-ODX/>"
            return original(doc)

        monkeypatch.setattr(pkg, "_serialize", stub)

        result = pkg.pack_pdx(
            {
                "ECU.odx-d": _minimal_odx_d("ECU"),
                "ISO_15765_2.odx-cs": _minimal_odx_cs("ISO_15765_2"),
            },
            tmp_path / "broken.pdx",
            validate=True,
        )
        # The archive was still written.
        assert (tmp_path / "broken.pdx").is_file()
        # And we got validation errors flagged against the broken member.
        assert any("ISO_15765_2.odx-cs" in e for e in result.validation_errors)


# ---------------------------------------------------------------------------
# Loose mode
# ---------------------------------------------------------------------------


class TestLooseMode:
    """``write_loose_odx`` writes per-category files without a ZIP."""

    def test_loose_writes_files(
        self, tmp_path: Path, sample_dlc_doc, sample_cs_doc
    ):
        out_dir = tmp_path / "loose"
        paths = write_loose_odx(
            {
                sample_dlc_doc.pdx_member_path: sample_dlc_doc,
                sample_cs_doc.pdx_member_path: sample_cs_doc,
            },
            out_dir,
        )
        assert len(paths) == 2
        names = sorted(p.name for p in paths)
        assert names == ["ECU.odx-d", "ISO_15765_2.odx-cs"]
        for p in paths:
            assert p.is_file() and p.read_bytes().startswith(b"<?xml")

    def test_loose_creates_missing_directory(
        self, tmp_path: Path, sample_dlc_doc
    ):
        out_dir = tmp_path / "does/not/exist/yet"
        paths = write_loose_odx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc}, out_dir
        )
        assert paths[0].parent == out_dir.resolve()


# ---------------------------------------------------------------------------
# PdxPackResult dataclass
# ---------------------------------------------------------------------------


class TestPdxPackResult:
    """The result dataclass exposes everything callers need."""

    def test_result_path_matches_argument(self, tmp_path: Path, sample_dlc_doc):
        out = tmp_path / "x.pdx"
        result = pack_pdx(
            {sample_dlc_doc.pdx_member_path: sample_dlc_doc}, out
        )
        assert isinstance(result, PdxPackResult)
        assert result.path == out

    def test_result_members_order_preserved(
        self, tmp_path: Path, sample_dlc_doc, sample_cs_doc
    ):
        out = tmp_path / "x.pdx"
        # dict ordering is insertion order in Python 3.7+
        docs = {
            sample_dlc_doc.pdx_member_path: sample_dlc_doc,
            sample_cs_doc.pdx_member_path: sample_cs_doc,
        }
        result = pack_pdx(docs, out)
        # index.xml comes first, then members in supplied order.
        assert result.members == [
            "index.xml",
            "ECU.odx-d",
            "ISO_15765_2.odx-cs",
        ]
