"""Tests for the ODX XSD validator (`udsxml2tex.odx.xsd_validator`)."""

from __future__ import annotations

from pathlib import Path

import pytest

from udsxml2tex.odx import (
    ComparamSubset,
    DiagLayerContainer,
    OdxCategory,
    OdxDocument,
)
from udsxml2tex.odx.models_odx import ODX_CATEGORY_SUFFIX
from udsxml2tex.odx.pdx_packager import pack_pdx
from udsxml2tex.odx.xsd_validator import (
    ValidationResult,
    get_xsd_path,
    validate_odx,
    validate_pdx,
    xsd_dir,
)

# Same lazy guard as the packager tests so the suite still passes when the
# COMPARAM-SUBSET serializer has not landed yet.
pytest.importorskip("udsxml2tex.odx.serializers.odx_d")
pytest.importorskip("udsxml2tex.odx.serializers.odx_cs")

from udsxml2tex.odx.serializers.odx_cs import serialize_odx_cs  # noqa: E402,I001
from udsxml2tex.odx.serializers.odx_d import serialize_odx_d  # noqa: E402,I001


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _minimal_odx_d() -> OdxDocument:
    return OdxDocument(
        category=OdxCategory.DIAG_LAYER,
        diag_layer_container=DiagLayerContainer(
            oid="oid.dlc.ECU",
            short_name="DLC_ECU",
        ),
        pdx_member_path="ECU.odx-d",
    )


def _minimal_odx_cs() -> OdxDocument:
    return OdxDocument(
        category=OdxCategory.COMPARAM_SUBSET,
        comparam_subset=ComparamSubset(
            oid="oid.cs.ISO_15765_2",
            short_name="ISO_15765_2",
            category="ISO_15765_2",
        ),
        pdx_member_path="ISO_15765_2.odx-cs",
    )


# ---------------------------------------------------------------------------
# get_xsd_path
# ---------------------------------------------------------------------------


class TestGetXsdPath:
    """Every ODX category resolves to a real XSD file on disk."""

    def test_all_categories_present(self):
        for category in OdxCategory:
            path = get_xsd_path(category)
            assert path is not None, f"No XSD found for category {category!r}"
            assert path.is_file()
            assert path.name.startswith("odx-")
            assert path.suffix == ".xsd"

    def test_xsd_dir_points_to_package(self):
        d = xsd_dir()
        assert d.is_dir()
        # Bundled with the package, alongside __init__.py
        assert (d.parent / "__init__.py").is_file()

    def test_filenames_use_canonical_suffix(self):
        for cat, suffix in ODX_CATEGORY_SUFFIX.items():
            path = get_xsd_path(cat)
            assert path is not None
            assert path.name == f"{suffix}.xsd"


# ---------------------------------------------------------------------------
# validate_odx — happy path
# ---------------------------------------------------------------------------


class TestValidateOdxValid:
    """Output from the agent serializers must pass the bundled XSDs."""

    def test_serialized_odx_d_is_valid(self):
        payload = serialize_odx_d(_minimal_odx_d())
        result = validate_odx(payload, OdxCategory.DIAG_LAYER)
        assert isinstance(result, ValidationResult)
        assert result.is_valid is True
        assert result.errors == []
        assert result.schema_used == "odx-d.xsd"

    def test_serialized_odx_cs_is_valid(self):
        payload = serialize_odx_cs(_minimal_odx_cs())
        result = validate_odx(payload, OdxCategory.COMPARAM_SUBSET)
        assert result.is_valid is True
        assert result.errors == []
        assert result.schema_used == "odx-cs.xsd"


# ---------------------------------------------------------------------------
# validate_odx — error paths
# ---------------------------------------------------------------------------


class TestValidateOdxInvalid:
    """Invalid bytes are reported with structured errors, never raised."""

    def test_wrong_root_element(self):
        bad = b"<?xml version='1.0'?><NOT-ODX/>"
        result = validate_odx(bad, OdxCategory.DIAG_LAYER)
        assert result.is_valid is False
        assert result.errors

    def test_corrupt_xml_returns_parse_error(self):
        bad = b"<?xml version='1.0'?><ODX MODEL-VERSION='2.2.0'><BROKEN"
        result = validate_odx(bad, OdxCategory.DIAG_LAYER)
        assert result.is_valid is False
        assert any("parse" in e.lower() for e in result.errors)

    def test_wrong_category_inside_odx(self):
        # ODX root, but the inner element belongs to ODX-CS not ODX-D.
        bad = (
            b"<?xml version='1.0'?>"
            b"<ODX MODEL-VERSION='2.2.0'><COMPARAM-SUBSET/></ODX>"
        )
        result = validate_odx(bad, OdxCategory.DIAG_LAYER)
        assert result.is_valid is False
        assert result.errors

    def test_serialized_odx_d_against_wrong_schema(self):
        """ODX-D bytes validated as COMPARAM-SUBSET should fail."""
        payload = serialize_odx_d(_minimal_odx_d())
        result = validate_odx(payload, OdxCategory.COMPARAM_SUBSET)
        assert result.is_valid is False
        assert result.schema_used == "odx-cs.xsd"


# ---------------------------------------------------------------------------
# validate_odx — missing XSD
# ---------------------------------------------------------------------------


class TestValidateOdxMissingXsd:
    """When the XSD file is unavailable, a clear FileNotFoundError is raised."""

    def test_missing_xsd_raises(self, monkeypatch):
        # Point xsd_dir() at an empty directory so no XSD is found.
        import udsxml2tex.odx.xsd_validator as mod

        monkeypatch.setattr(mod, "xsd_dir", lambda: Path("/nonexistent/xsd-dir"))
        with pytest.raises(FileNotFoundError):
            validate_odx(b"<ODX/>", OdxCategory.DIAG_LAYER)


# ---------------------------------------------------------------------------
# validate_pdx
# ---------------------------------------------------------------------------


class TestValidatePdx:
    """``validate_pdx`` walks every member of a PDX archive."""

    def test_validates_each_member(self, tmp_path: Path):
        out = tmp_path / "Sample.pdx"
        docs = {
            "ECU.odx-d": _minimal_odx_d(),
            "ISO_15765_2.odx-cs": _minimal_odx_cs(),
        }
        pack_pdx(docs, out)
        results = validate_pdx(out)
        assert set(results.keys()) == {"ECU.odx-d", "ISO_15765_2.odx-cs"}
        for r in results.values():
            assert r.is_valid is True

    def test_skips_index_and_extras(self, tmp_path: Path):
        out = tmp_path / "Sample.pdx"
        pack_pdx(
            {"ECU.odx-d": _minimal_odx_d()},
            out,
            extra_files={"flash/app.bin": b"\x01\x02"},
        )
        results = validate_pdx(out)
        # index.xml is not an .odx-* member; binary blobs are skipped too.
        assert "index.xml" not in results
        assert "flash/app.bin" not in results
        assert "ECU.odx-d" in results

    def test_missing_archive_raises(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            validate_pdx(tmp_path / "missing.pdx")

    def test_reports_invalid_member(self, tmp_path: Path, monkeypatch):
        """Inject a clearly-wrong payload and confirm it fails validation."""
        import udsxml2tex.odx.pdx_packager as pkg

        original = pkg._serialize

        def stub(doc):
            if doc.category == OdxCategory.COMPARAM_SUBSET:
                return b"<?xml version='1.0'?><NOPE/>"
            return original(doc)

        monkeypatch.setattr(pkg, "_serialize", stub)
        out = tmp_path / "broken.pdx"
        pkg.pack_pdx(
            {
                "ECU.odx-d": _minimal_odx_d(),
                "ISO_15765_2.odx-cs": _minimal_odx_cs(),
            },
            out,
        )
        results = validate_pdx(out)
        assert results["ECU.odx-d"].is_valid is True
        assert results["ISO_15765_2.odx-cs"].is_valid is False
        assert results["ISO_15765_2.odx-cs"].errors
