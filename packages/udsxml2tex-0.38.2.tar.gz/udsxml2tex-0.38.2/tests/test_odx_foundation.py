"""Foundation tests for the ODX 2.2.0 IR, supplement loader and mapper."""

from __future__ import annotations

from pathlib import Path

import pytest

from udsxml2tex import ArxmlParser, CanTpParser
from udsxml2tex.models import (
    CanTpConfig,
    DataElement,
    DiagSession,
    Did,
    DoIpConfig,
    DtcDefinition,
    MemoryRange,
    NrcEntry,
    Routine,
    RoutineParameter,
    SecurityLevel,
    UdsService,
    UdsSpecification,
)
from udsxml2tex.odx import (
    AdminData,
    BaseVariant,
    DiagCodedType,
    DiagLayerContainer,
    Dtc,
    DtcDop,
    OdxCategory,
    OdxDocument,
    OdxRef,
    OdxSupplement,
    Param,
    Response,
    SnRef,
    Structure,
    dop_key,
    empty_supplement,
    load_supplement,
    make_oid,
    map_spec_to_odx,
    sanitize_short_name,
)
from udsxml2tex.odx.supplement import (
    EcuMemSupplement,
    FlashSegmentSupplement,
    FlashSupplement,
    FunctionalGroupSupplement,
    VehicleConnectorSupplement,
    VehicleSupplement,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_CANTP = FIXTURES_DIR / "sample_cantp.arxml"
SAMPLE_SECONDARY_DCM = FIXTURES_DIR / "sample_secondary_dcm.arxml"
SAMPLES_DIR = (
    Path(__file__).parent.parent / "src" / "udsxml2tex" / "samples"
)
SAMPLE_YAML = SAMPLES_DIR / "odx_supplement_sample.yaml"


# ---------------------------------------------------------------------------
# 1. sanitize_short_name
# ---------------------------------------------------------------------------


class TestSanitizeShortName:
    """Edge cases for ``sanitize_short_name``."""

    def test_passthrough_valid(self):
        assert sanitize_short_name("MyEcu") == "MyEcu"

    def test_leading_digit_gets_prefix(self):
        assert sanitize_short_name("1stEcu").startswith("ECU_")

    def test_empty_returns_fallback(self):
        assert sanitize_short_name("") == "Unnamed"
        assert sanitize_short_name(None) == "Unnamed"
        assert sanitize_short_name("   ") == "Unnamed"

    def test_special_chars_replaced(self):
        out = sanitize_short_name("ECU-Foo.Bar/Baz")
        assert out == "ECU_Foo_Bar_Baz"

    def test_special_chars_collapse_underscores(self):
        # "A!!B" -> "A_B", not "A__B"
        out = sanitize_short_name("A!!B")
        assert out == "A_B"

    def test_length_cap(self):
        long_name = "A" + "B" * 200
        out = sanitize_short_name(long_name)
        assert len(out) <= 128
        assert out[0].isalpha()

    def test_custom_fallback(self):
        assert sanitize_short_name(None, fallback="Anon") == "Anon"

    def test_leading_underscore_then_letter(self):
        # leading underscore is not a letter so falls through prefix path
        out = sanitize_short_name("_Hello")
        assert out.startswith("ECU_") or out == "Hello"


# ---------------------------------------------------------------------------
# 2. make_oid and dop_key
# ---------------------------------------------------------------------------


class TestOidsAndKeys:
    """Deterministic OID generation and DOP dedupe keys."""

    def test_make_oid_format(self):
        oid = make_oid("d", "dop", "Foo")
        assert oid == "udsxml2tex.odx.d.dop.Foo"

    def test_make_oid_stable(self):
        a = make_oid("d", "dop", "Bar")
        b = make_oid("d", "dop", "Bar")
        assert a == b

    def test_make_oid_sanitises_input(self):
        oid = make_oid("d", "dop", "Foo Bar/Baz")
        assert "/" not in oid and " " not in oid

    def test_dop_key_case_insensitive(self):
        assert dop_key("UINT8", "rpm", "X") == dop_key("uint8", "RPM", "x")

    def test_dop_key_distinct_when_different(self):
        assert dop_key("uint8", "rpm", "ident") != dop_key("uint16", "rpm", "ident")
        assert dop_key("uint8", "rpm", "ident") != dop_key("uint8", "kph", "ident")
        assert dop_key("uint8", "", "") != dop_key("uint16", "", "")


# ---------------------------------------------------------------------------
# 3. Model instantiation smoke tests
# ---------------------------------------------------------------------------


class TestModelInstantiation:
    """All key dataclasses can be instantiated with their declared defaults."""

    def test_admin_data_default(self):
        a = AdminData()
        assert a.language == "en-US"
        assert a.company_doc_infos == []
        assert a.doc_revisions == []

    def test_diag_coded_type_default(self):
        c = DiagCodedType()
        assert c.base_data_type == "A_UINT32"
        assert c.coded_type == "STANDARD-LENGTH-TYPE"
        assert c.is_highlow_byte_order is True

    def test_param_default(self):
        p = Param()
        assert p.param_kind == "VALUE"

    def test_response_default(self):
        r = Response()
        assert r.response_type == "POS-RESPONSE"

    def test_dtc_default(self):
        d = Dtc(short_name="DTC_A", trouble_code=0x123456)
        assert d.is_temporary is False
        assert d.level is None

    def test_dtc_dop_default(self):
        d = DtcDop()
        assert d.is_visible is True

    def test_structure_default(self):
        s = Structure(short_name="S")
        assert s.params == []

    def test_diag_layer_container_default(self):
        c = DiagLayerContainer(short_name="DLC")
        assert c.base_variants == []

    def test_base_variant_default(self):
        bv = BaseVariant(short_name="BV")
        assert bv.diag_comms == []
        assert bv.requests == []

    def test_odx_document_category_default(self):
        d = OdxDocument()
        assert d.category == OdxCategory.DIAG_LAYER
        assert d.model_version == "2.2.0"

    def test_odx_document_file_suffix(self):
        d = OdxDocument(category=OdxCategory.DIAG_LAYER)
        assert d.file_suffix == "odx-d"
        d = OdxDocument(category=OdxCategory.FLASH)
        assert d.file_suffix == "odx-f"
        d = OdxDocument(category=OdxCategory.COMPARAM_SUBSET)
        assert d.file_suffix == "odx-cs"

    def test_odxref_carries_docref(self):
        ref = OdxRef(id_ref="x.y.z", docref="ECU.odx-d", docref_type="CONTAINER")
        assert ref.id_ref == "x.y.z"
        assert ref.docref == "ECU.odx-d"

    def test_snref_default(self):
        sn = SnRef(short_name="foo")
        assert sn.docref is None


# ---------------------------------------------------------------------------
# 4. Mapper — empty spec
# ---------------------------------------------------------------------------


class TestMapperEmptySpec:
    """Mapper degrades gracefully on near-empty inputs."""

    def test_empty_spec_emits_only_odx_d(self):
        spec = UdsSpecification()
        docs = map_spec_to_odx(spec)
        assert len(docs) == 1
        member = next(iter(docs.keys()))
        assert member.endswith(".odx-d")
        assert docs[member].category == OdxCategory.DIAG_LAYER

    def test_empty_spec_has_diag_layer_container(self):
        docs = map_spec_to_odx(UdsSpecification())
        odx_d = next(iter(docs.values()))
        assert odx_d.diag_layer_container is not None
        assert len(odx_d.diag_layer_container.base_variants) == 1

    def test_empty_spec_ecu_short_name_sanitised(self):
        spec = UdsSpecification(ecu_name="1Bad/Name")
        docs = map_spec_to_odx(spec)
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        assert bv.short_name.startswith("ECU_")
        assert "/" not in bv.short_name

    def test_supplement_default_is_empty(self):
        sup = empty_supplement()
        assert sup.vehicle is None
        assert sup.flash is None
        assert sup.functional_groups == []

    def test_empty_spec_with_no_cantp_no_odx_cs(self):
        docs = map_spec_to_odx(UdsSpecification())
        assert all(not k.endswith(".odx-cs") for k in docs)


# ---------------------------------------------------------------------------
# 5. Mapper — sample ARXML round trip
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def sample_spec() -> UdsSpecification:
    """Parsed UdsSpecification from the bundled sample_dcm.arxml fixture."""
    return ArxmlParser().parse(SAMPLE_ARXML)


@pytest.fixture(scope="module")
def sample_spec_with_cantp() -> UdsSpecification:
    """Sample spec with CanTpConfig attached for ODX-CS coverage."""
    spec = ArxmlParser().parse(SAMPLE_ARXML)
    spec.transport_config = CanTpParser().parse(SAMPLE_CANTP)
    return spec


class TestMapperSample:
    """Mapper produces non-empty ODX-D for the bundled sample fixture."""

    def test_emits_at_least_odx_d(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        assert any(k.endswith(".odx-d") for k in docs)

    def test_base_variant_has_diag_comms(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        odx_d = next(v for v in docs.values() if v.category == OdxCategory.DIAG_LAYER)
        bv = odx_d.diag_layer_container.base_variants[0]
        assert bv.diag_comms, "BaseVariant has no DiagService entries"

    def test_did_count_preserved_as_rdbi_services(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        odx_d = next(v for v in docs.values() if v.category == OdxCategory.DIAG_LAYER)
        bv = odx_d.diag_layer_container.base_variants[0]
        rdbi_services = [s for s in bv.diag_comms if s.short_name.startswith("RDBI_")]
        assert len(rdbi_services) == len(sample_spec.dids)

    def test_writable_did_emits_wdbi_service(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        odx_d = next(v for v in docs.values() if v.category == OdxCategory.DIAG_LAYER)
        bv = odx_d.diag_layer_container.base_variants[0]
        write_dids = [d for d in sample_spec.dids if d.write_access]
        wdbi_services = [s for s in bv.diag_comms if s.short_name.startswith("WDBI_")]
        assert len(wdbi_services) == len(write_dids)

    def test_each_did_has_request_and_response(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        odx_d = next(v for v in docs.values() if v.category == OdxCategory.DIAG_LAYER)
        bv = odx_d.diag_layer_container.base_variants[0]
        req_oids = {r.oid for r in bv.requests}
        resp_oids = {r.oid for r in bv.pos_responses}
        for s in bv.diag_comms:
            if s.short_name.startswith(("RDBI_", "WDBI_")):
                assert s.request_ref is not None
                assert s.request_ref.id_ref in req_oids
                assert s.pos_response_refs
                assert s.pos_response_refs[0].id_ref in resp_oids

    def test_routines_produce_routine_control_services(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        odx_d = next(v for v in docs.values() if v.category == OdxCategory.DIAG_LAYER)
        bv = odx_d.diag_layer_container.base_variants[0]
        rc_services = [s for s in bv.diag_comms if s.semantic == "ROUTINECONTROL"]
        assert rc_services, "no routine-control services emitted"
        # at least one service per routine
        assert len(rc_services) >= len(sample_spec.routines)

    def test_session_table_emitted(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        odx_d = next(v for v in docs.values() if v.category == OdxCategory.DIAG_LAYER)
        bv = odx_d.diag_layer_container.base_variants[0]
        tables = bv.diag_data_dictionary_spec.tables
        names = {t.short_name for t in tables}
        assert "SessionTable" in names

    def test_security_table_emitted(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        names = {t.short_name for t in bv.diag_data_dictionary_spec.tables}
        assert "SecurityLevelTable" in names

    def test_dops_are_interned(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        dops = bv.diag_data_dictionary_spec.data_object_props
        # Every DOP key is unique → no duplicates by short_name.
        assert len({d.short_name for d in dops}) == len(dops)

    def test_oid_stability_across_runs(self, sample_spec):
        first = map_spec_to_odx(sample_spec)
        second = map_spec_to_odx(sample_spec)
        first_oids = sorted(
            s.oid
            for s in first[next(iter(first))].diag_layer_container.base_variants[0].diag_comms
        )
        second_oids = sorted(
            s.oid
            for s in second[next(iter(second))].diag_layer_container.base_variants[0].diag_comms
        )
        assert first_oids == second_oids

    def test_global_neg_response_with_nrcs(self, sample_spec):
        docs = map_spec_to_odx(sample_spec)
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        if any(s.nrc_list for s in sample_spec.services):
            assert bv.global_neg_responses, "expected a global negative response"
            nrc_params = bv.global_neg_responses[0].params
            assert any(p.param_kind == "NRC-CONST" for p in nrc_params)


# ---------------------------------------------------------------------------
# 6. Mapper — CanTp ⇒ ODX-CS
# ---------------------------------------------------------------------------


class TestMapperComparamSubset:
    """ComparamSubset emission when ``spec.transport_config`` is present."""

    def test_cantp_present_emits_subset(self, sample_spec_with_cantp):
        docs = map_spec_to_odx(sample_spec_with_cantp)
        cs_docs = [d for d in docs.values() if d.category == OdxCategory.COMPARAM_SUBSET]
        assert cs_docs, "expected ODX-CS document when CanTp is present"
        assert cs_docs[0].comparam_subset.category == "ISO_15765_2"

    def test_no_cantp_no_subset(self, sample_spec):
        spec = sample_spec
        # Ensure transport_config really is missing on this fixture
        spec.transport_config = None
        docs = map_spec_to_odx(spec)
        cs_docs = [d for d in docs.values() if d.category == OdxCategory.COMPARAM_SUBSET]
        assert cs_docs == []

    def test_comparam_subset_has_standard_params(self):
        cfg = CanTpConfig()
        spec = UdsSpecification(transport_config=cfg)
        docs = map_spec_to_odx(spec)
        cs = next(d for d in docs.values() if d.category == OdxCategory.COMPARAM_SUBSET)
        params = {c.short_name for c in cs.comparam_subset.comparams}
        for expected in {
            "CP_P2_SERVER_MAX",
            "CP_P2_STAR_SERVER_MAX",
            "CP_S3_SERVER",
            "CP_STMIN",
            "CP_BLOCK_SIZE",
        }:
            assert expected in params


# ---------------------------------------------------------------------------
# 7. Supplement loader
# ---------------------------------------------------------------------------


pytest.importorskip("yaml")


class TestSupplementLoader:
    """YAML supplement round-trip behaviour."""

    def test_load_sample_supplement(self):
        sup = load_supplement(SAMPLE_YAML)
        assert sup.vehicle is not None
        assert sup.vehicle.vin == "WAUZZZ8K0XA000001"
        assert sup.vehicle.model_year == 2025

    def test_sample_flash_segments(self):
        sup = load_supplement(SAMPLE_YAML)
        assert sup.flash is not None
        assert sup.flash.ecu_mem is not None
        assert len(sup.flash.ecu_mem.segments) >= 1
        seg = sup.flash.ecu_mem.segments[0]
        assert seg.source_start_address == 0x00100000
        assert seg.source_end_address == 0x001FFFFF

    def test_sample_functional_groups(self):
        sup = load_supplement(SAMPLE_YAML)
        names = [g.short_name for g in sup.functional_groups]
        assert "Powertrain" in names

    def test_sample_company_data(self):
        sup = load_supplement(SAMPLE_YAML)
        assert sup.company_data is not None
        assert "MANUFACTURER" in sup.company_data.roles

    def test_sample_physical_links(self):
        sup = load_supplement(SAMPLE_YAML)
        assert any(p.short_name == "ISOTP_500K" for p in sup.physical_vehicle_links)

    def test_missing_file_raises(self):
        with pytest.raises(FileNotFoundError):
            load_supplement("/nonexistent/path/file.yaml")

    def test_hex_string_addresses(self, tmp_path):
        yaml_path = tmp_path / "sup.yaml"
        yaml_path.write_text(
            "flash:\n"
            "  ecu_mem:\n"
            "    short_name: M\n"
            "    segments:\n"
            "      - short_name: S\n"
            "        source_start_address: '0x10'\n"
            "        source_end_address: '0x1F'\n",
            encoding="utf-8",
        )
        sup = load_supplement(yaml_path)
        assert sup.flash.ecu_mem.segments[0].source_start_address == 0x10
        assert sup.flash.ecu_mem.segments[0].source_end_address == 0x1F


# ---------------------------------------------------------------------------
# 8. Supplement-driven ODX documents (vehicle / flash / fd)
# ---------------------------------------------------------------------------


class TestSupplementDocs:
    """When supplement sections are populated, the corresponding ODX docs appear."""

    def test_flash_supplement_emits_odx_f(self, sample_spec):
        sup = OdxSupplement(
            flash=FlashSupplement(
                ecu_mem=EcuMemSupplement(
                    short_name="MainMemory",
                    segments=[
                        FlashSegmentSupplement(
                            short_name="Seg1",
                            source_start_address=0x100,
                            source_end_address=0x1FF,
                            target_start_address=0x100,
                            target_end_address=0x1FF,
                        ),
                    ],
                ),
            ),
        )
        docs = map_spec_to_odx(sample_spec, sup)
        assert any(d.category == OdxCategory.FLASH for d in docs.values())

    def test_functional_groups_emits_odx_fd(self, sample_spec):
        sup = OdxSupplement(
            functional_groups=[
                FunctionalGroupSupplement(short_name="Powertrain", ecus=["E1", "E2"]),
            ],
        )
        docs = map_spec_to_odx(sample_spec, sup)
        assert any(d.category == OdxCategory.FUNCTION_DICTIONARY for d in docs.values())

    def test_vehicle_supplement_emits_odx_v(self, sample_spec):
        sup = OdxSupplement(
            vehicle=VehicleSupplement(
                vin="ABC", model_year=2025,
                vehicle_connectors=[
                    VehicleConnectorSupplement(short_name="OBD", connector_type="ISO-15031-3"),
                ],
            ),
        )
        docs = map_spec_to_odx(sample_spec, sup)
        veh_docs = [d for d in docs.values() if d.category == OdxCategory.VEHICLE_INFO]
        assert veh_docs
        assert veh_docs[0].vehicle_info_spec.vehicles[0].vin == "ABC"

    def test_doip_present_emits_physical_link(self, sample_spec):
        sample_spec.doip_config = DoIpConfig(short_name="MyDoIP")
        docs = map_spec_to_odx(sample_spec)
        veh_docs = [d for d in docs.values() if d.category == OdxCategory.VEHICLE_INFO]
        # DoIP alone (no supplement vehicle) still produces a physical link
        assert veh_docs
        sample_spec.doip_config = None  # cleanup for other tests


# ---------------------------------------------------------------------------
# 9. Hand-crafted UdsSpecification ⇒ ODX (no ARXML)
# ---------------------------------------------------------------------------


def _toy_spec() -> UdsSpecification:
    """Build a minimal UdsSpecification with one of every interesting field."""
    return UdsSpecification(
        ecu_name="ToyEcu",
        description="Test ECU",
        sessions=[DiagSession(short_name="Default", session_id=0x01)],
        security_levels=[SecurityLevel(short_name="Level1", security_level=1,
                                       seed_size=4, key_size=4)],
        services=[
            UdsService(
                short_name="ReadDataByIdentifier",
                service_id=0x22,
                addressing_modes=["physical", "functional"],
                nrc_list=[
                    NrcEntry(nrc_code=0x13, nrc_name="incorrectMessageLengthOrInvalidFormat"),
                ],
            ),
        ],
        dids=[
            Did(
                short_name="VIN",
                did_id=0xF190,
                read_access=True, write_access=True,
                data_elements=[
                    DataElement(short_name="vin_str", data_type="ascii", bit_size=17 * 8),
                ],
            ),
            Did(
                short_name="EcuRev",
                did_id=0xF18C,
                data_elements=[
                    DataElement(short_name="rev", data_type="uint8", bit_size=8),
                ],
            ),
        ],
        routines=[
            Routine(
                short_name="EraseRoutine",
                routine_id=0xFF00,
                start_supported=True,
                stop_supported=True,
                result_supported=True,
                in_parameters=[
                    RoutineParameter(short_name="addr", data_type="uint32", bit_size=32),
                ],
                out_parameters=[
                    RoutineParameter(short_name="status", data_type="uint8", bit_size=8),
                ],
            ),
        ],
        dtcs=[DtcDefinition(short_name="P0420", dtc_id=0x000420)],
        memory_ranges=[
            MemoryRange(
                short_name="AppFlash",
                start_address=0x10000, end_address=0x1FFFF,
                read_access=True,
            ),
        ],
        transport_config=CanTpConfig(),
    )


class TestToySpec:
    """Mapping a hand-crafted spec covers all main code paths."""

    def test_toy_basic_layout(self):
        docs = map_spec_to_odx(_toy_spec())
        assert any(k.endswith(".odx-d") for k in docs)
        assert any(k.endswith(".odx-cs") for k in docs)

    def test_toy_dop_dedup(self):
        spec = _toy_spec()
        docs = map_spec_to_odx(spec)
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        # DOPs are interned by (data_type, unit, coding); the resulting set
        # must therefore have unique short names and unique OIDs.
        names = [d.short_name for d in bv.diag_data_dictionary_spec.data_object_props]
        oids = [d.oid for d in bv.diag_data_dictionary_spec.data_object_props]
        assert len(set(names)) == len(names)
        assert len(set(oids)) == len(oids)
        # rev (uint8) and status (uint8) should share a DOP — i.e. fewer DOPs
        # than data elements + routine parameters defined.
        total_value_slots = sum(len(d.data_elements) for d in spec.dids)
        total_value_slots += sum(len(r.in_parameters) + len(r.out_parameters)
                                 for r in spec.routines)
        assert len(names) <= total_value_slots

    def test_toy_dtc_dop(self):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        assert bv.diag_data_dictionary_spec.dtc_dops
        dtc_dop = bv.diag_data_dictionary_spec.dtc_dops[0]
        assert any(d.trouble_code == 0x000420 for d in dtc_dop.dtcs)

    def test_toy_memory_ranges_become_structures(self):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        names = {s.short_name for s in bv.diag_data_dictionary_spec.structures}
        assert any(n.startswith("MemRange_") for n in names)

    def test_toy_routine_sub_services(self):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        names = {s.short_name for s in bv.diag_comms}
        assert any(n.startswith("RC_Start_") for n in names)
        assert any(n.startswith("RC_Stop_") for n in names)
        assert any(n.startswith("RC_Results_") for n in names)

    def test_toy_addressing_both(self):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        rdbi = next(s for s in bv.diag_comms if s.short_name == "ReadDataByIdentifier")
        assert rdbi.addressing == "PHYSICAL-AND-FUNCTIONAL"


# ---------------------------------------------------------------------------
# 10. Multi-ECU mapper
# ---------------------------------------------------------------------------


class TestMultiEcuMapper:
    """Multi-ECU mapper emits one EcuVariant per ECU."""

    def test_two_ecu_system(self):
        from udsxml2tex.multi_ecu.models import (
            EcuConfig,
            EcuRole,
            EcuSystem,
        )
        from udsxml2tex.odx import map_ecu_system_to_odx

        s1 = ArxmlParser().parse(SAMPLE_ARXML)
        s2 = ArxmlParser().parse(SAMPLE_SECONDARY_DCM)
        system = EcuSystem(
            name="Two_Ecu_System",
            ecus={
                "Primary": EcuConfig(name="Primary", role=EcuRole.GATEWAY, spec=s1),
                "Secondary": EcuConfig(name="Secondary", role=EcuRole.ENDPOINT, spec=s2),
            },
        )
        docs = map_ecu_system_to_odx(system)
        odx_d = next(d for d in docs.values() if d.category == OdxCategory.DIAG_LAYER)
        variants = odx_d.diag_layer_container.ecu_variants
        assert len(variants) == 2
        names = {v.short_name for v in variants}
        assert "Primary" in names
        assert "Secondary" in names

    def test_skips_unparsed_ecus(self):
        from udsxml2tex.multi_ecu.models import EcuConfig, EcuSystem
        from udsxml2tex.odx import map_ecu_system_to_odx

        spec = ArxmlParser().parse(SAMPLE_ARXML)
        system = EcuSystem(
            name="System",
            ecus={
                "Primary": EcuConfig(name="Primary", spec=spec),
                "Skipped": EcuConfig(name="Skipped", spec=None),
            },
        )
        docs = map_ecu_system_to_odx(system)
        variants = next(iter(docs.values())).diag_layer_container.ecu_variants
        assert len(variants) == 1
        assert variants[0].short_name == "Primary"


# ---------------------------------------------------------------------------
# 11. Helper invariants
# ---------------------------------------------------------------------------


class TestMapperInvariants:
    """Cross-cutting properties of the mapper output."""

    def test_pdx_member_path_uses_correct_suffix(self):
        docs = map_spec_to_odx(_toy_spec())
        for member, doc in docs.items():
            suffix = member.split(".")[-1]
            assert suffix == doc.file_suffix

    def test_every_service_has_request_ref(self, sample_spec=None):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        for svc in bv.diag_comms:
            assert svc.request_ref is not None

    def test_request_oids_are_unique(self):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        oids = [r.oid for r in bv.requests]
        assert len(oids) == len(set(oids))

    def test_response_oids_are_unique(self):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        oids = [r.oid for r in bv.pos_responses]
        assert len(oids) == len(set(oids))

    def test_dop_oids_are_unique(self):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        oids = [d.oid for d in bv.diag_data_dictionary_spec.data_object_props]
        assert len(oids) == len(set(oids))

    def test_admin_data_attached_to_base_variant(self):
        docs = map_spec_to_odx(_toy_spec())
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        assert bv.admin_data is not None
        assert bv.admin_data.doc_revisions

    def test_short_name_prefix(self):
        docs = map_spec_to_odx(UdsSpecification(ecu_name="MyEcu"), short_name_prefix="V2_")
        bv = next(iter(docs.values())).diag_layer_container.base_variants[0]
        assert bv.short_name.startswith("V2_") or bv.short_name == "V2_MyEcu"
