"""Tests for :mod:`udsxml2tex._reprogramming` and TexGenerator integration.

Covers:

* ``has_reprogramming_data`` presence detection.
* Format-specific helpers for tex / html / md / rst:
    - programming sequence (tikz-uml)
    - flash memory map
    - boot-only DIDs / RIDs
    - CAN ID comparison
* End-to-end section renderers.
* Generator integration: ``TexGenerator.generate / generate_html /
  generate_markdown / generate_rst`` accept an ``overlay`` argument and
  produce a Bootloader chapter, while remaining byte-identical without one.
* ``render_reprogramming`` / ``write_reprogramming`` convenience API.

The tests use only generic placeholder identifiers — no vendor / brand
names appear anywhere in the assertions or fixtures.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from udsxml2tex import (
    ArxmlParser,
    BootloaderInfo,
    BootOverlay,
    DomainCanIds,
    FlashSegment,
    TexGenerator,
    empty_overlay,
)
from udsxml2tex._reprogramming import (
    has_reprogramming_data,
    render_boot_only_did_table_html,
    render_boot_only_did_table_md,
    render_boot_only_did_table_rst,
    render_boot_only_did_table_tex,
    render_boot_only_rid_table_html,
    render_boot_only_rid_table_md,
    render_boot_only_rid_table_rst,
    render_boot_only_rid_table_tex,
    render_can_id_comparison_html,
    render_can_id_comparison_md,
    render_can_id_comparison_rst,
    render_can_id_comparison_tex,
    render_flash_memory_map_html,
    render_flash_memory_map_md,
    render_flash_memory_map_rst,
    render_flash_memory_map_tex,
    render_programming_sequence_tikz,
    render_reprogramming_section_html,
    render_reprogramming_section_md,
    render_reprogramming_section_rst,
    render_reprogramming_section_tex,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SAMPLE_ARXML = (
    PROJECT_ROOT / "src" / "udsxml2tex" / "samples" / "sample1_dcm.arxml"
)


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------


def _bootloader_info() -> BootloaderInfo:
    return BootloaderInfo(
        flash_segments=[
            FlashSegment(
                name="AppCode",
                start=0x00100000,
                end=0x001FFFFF,
                description="Main application code",
            ),
            FlashSegment(
                name="AppData",
                start=0x00200000,
                end=0x002FFFFF,
                description="Calibration data",
            ),
        ],
        programming_sequence=[
            "DiagnosticSessionControl (programmingSession)",
            "SecurityAccess (request seed)",
            "SecurityAccess (send key)",
            "RoutineControl (eraseMemory)",
        ],
        reset_address=0x00080000,
        download_block_size=4096,
        checksum_algorithm="CRC32",
    )


def _overlay_with_bootloader() -> BootOverlay:
    return BootOverlay(
        ecu_name="ExampleECU",
        bootloader=_bootloader_info(),
    )


def _overlay_with_boot_only_dids() -> BootOverlay:
    return BootOverlay(
        ecu_name="ExampleECU",
        boot_only_dids=[
            {
                "did_id": 0xF180,
                "short_name": "BootSwIdentification",
                "description": "Bootloader software identifier",
            },
            {
                "did_id": 0xF184,
                "short_name": "AppSwFingerprint",
                "description": "Application software fingerprint",
            },
        ],
    )


def _overlay_with_boot_only_rids() -> BootOverlay:
    return BootOverlay(
        ecu_name="ExampleECU",
        boot_only_rids=[
            {
                "rid_id": 0xFF00,
                "short_name": "FlashErase",
                "description": "Erase flash region",
            },
            {
                "rid_id": 0xFF01,
                "short_name": "CheckProgrammingDependencies",
                "description": "Verify programming dependencies",
            },
        ],
    )


def _overlay_with_can_ids() -> BootOverlay:
    return BootOverlay(
        ecu_name="ExampleECU",
        can_ids_drive=DomainCanIds(
            physical="0x18DA00E0",
            functional="0x18DBEFE0",
            telematics="",
        ),
        can_ids_boot=DomainCanIds(
            physical="0x18DA00F0",
            functional="0x18DBEFF0",
            telematics="",
        ),
    )


# ---------------------------------------------------------------------------
# has_reprogramming_data
# ---------------------------------------------------------------------------


class TestHasReprogrammingData:
    def test_none_returns_false(self) -> None:
        assert has_reprogramming_data(None) is False

    def test_empty_overlay_returns_false(self) -> None:
        assert has_reprogramming_data(empty_overlay()) is False
        assert has_reprogramming_data(BootOverlay()) is False

    def test_bootloader_present_returns_true(self) -> None:
        assert has_reprogramming_data(_overlay_with_bootloader()) is True

    def test_boot_only_dids_present_returns_true(self) -> None:
        assert has_reprogramming_data(_overlay_with_boot_only_dids()) is True

    def test_boot_only_rids_present_returns_true(self) -> None:
        assert has_reprogramming_data(_overlay_with_boot_only_rids()) is True

    def test_boot_can_ids_present_returns_true(self) -> None:
        overlay = BootOverlay(can_ids_boot=DomainCanIds(physical="0x18DA00F0"))
        assert has_reprogramming_data(overlay) is True

    def test_drive_can_ids_only_returns_false(self) -> None:
        # Drive-side CAN IDs alone are not "reprogramming" data — they belong
        # to the existing application chapter.
        overlay = BootOverlay(can_ids_drive=DomainCanIds(physical="0x18DA00E0"))
        assert has_reprogramming_data(overlay) is False


# ---------------------------------------------------------------------------
# Programming sequence (tikz-uml)
# ---------------------------------------------------------------------------


class TestProgrammingSequenceTikz:
    def test_empty_steps_produces_minimal_figure(self) -> None:
        out = render_programming_sequence_tikz([])
        assert "\\begin{figure}" in out
        assert "\\end{figure}" in out
        assert "umlseqdiag" in out
        # No umlcall when there are no steps.
        assert "umlcall" not in out

    def test_non_empty_steps_produces_umlcalls(self) -> None:
        out = render_programming_sequence_tikz(["step1", "step2"])
        assert out.count("umlcall") == 4  # begin + end for each step
        assert "begin{umlseqdiag}" in out
        assert "end{umlseqdiag}" in out
        assert "tikzpicture" in out

    def test_generic_actors_used_by_default(self) -> None:
        out = render_programming_sequence_tikz(["foo"])
        assert "Tester" in out
        assert "ECU" in out

    def test_step_text_appears_in_output(self) -> None:
        out = render_programming_sequence_tikz(["SecurityAccess (seed)"])
        assert "SecurityAccess (seed)" in out

    def test_special_chars_in_steps_are_escaped(self) -> None:
        out = render_programming_sequence_tikz(["Use 100% throttle & test"])
        # `%` and `&` must be LaTeX-escaped.
        assert "\\%" in out
        assert "\\&" in out

    def test_custom_actor_labels(self) -> None:
        out = render_programming_sequence_tikz(
            ["x"], actor_tester="ClientA", actor_ecu="ServerB"
        )
        assert "ClientA" in out
        assert "ServerB" in out


# ---------------------------------------------------------------------------
# Flash memory map
# ---------------------------------------------------------------------------


class TestFlashMemoryMap:
    def test_tex_empty_returns_empty_string(self) -> None:
        assert render_flash_memory_map_tex([]) == ""

    def test_tex_basic_table(self) -> None:
        seg = FlashSegment(
            name="AppCode", start=0x00100000, end=0x001FFFFF, description="Code"
        )
        out = render_flash_memory_map_tex([seg])
        assert "longtable" in out
        assert "AppCode" in out
        assert "0x00100000" in out
        assert "0x001FFFFF" in out
        # Size = 0x001FFFFF - 0x00100000 + 1 = 0x00100000 = 1048576
        assert "1048576" in out

    def test_html_basic_table(self) -> None:
        seg = FlashSegment(name="BootCode", start=0, end=0xFFFF)
        out = render_flash_memory_map_html([seg])
        assert "<table" in out
        assert "BootCode" in out
        assert "0x00000000" in out
        assert "0x0000FFFF" in out
        assert "65536" in out  # end - start + 1

    def test_md_header_row(self) -> None:
        seg = FlashSegment(name="X", start=0, end=15)
        out = render_flash_memory_map_md([seg])
        # The header row contains the expected columns.
        assert "| Name |" in out
        assert "Start" in out and "End" in out and "Size" in out
        assert "|---|---|---|---|---|" in out
        # Size = 15 - 0 + 1 = 16
        assert "16" in out

    def test_rst_csv_table(self) -> None:
        seg = FlashSegment(name="X", start=0, end=255, description="Sample")
        out = render_flash_memory_map_rst([seg])
        assert "csv-table" in out
        assert "0x000000FF" in out
        assert "256" in out

    def test_size_calc_inclusive(self) -> None:
        seg = FlashSegment(name="One", start=0x10, end=0x10)
        out = render_flash_memory_map_tex([seg])
        # one byte: end == start, size = 1
        # The "1" must appear as the size cell.
        assert " 1 &" in out or "& 1 " in out


# ---------------------------------------------------------------------------
# Boot-only DIDs
# ---------------------------------------------------------------------------


class TestBootOnlyDids:
    def test_tex_empty_returns_empty_string(self) -> None:
        assert render_boot_only_did_table_tex([]) == ""

    def test_tex_malformed_entries_skipped(self) -> None:
        # Entry without did_id should be silently skipped.
        entries = [
            {"short_name": "Orphan", "description": "no did_id"},
            {"did_id": 0xF180, "short_name": "Real"},
        ]
        out = render_boot_only_did_table_tex(entries)
        assert "Orphan" not in out
        assert "Real" in out
        assert "0xF180" in out

    def test_tex_all_malformed_returns_empty(self) -> None:
        assert render_boot_only_did_table_tex([{"foo": "bar"}]) == ""

    def test_html_basic_table(self) -> None:
        out = render_boot_only_did_table_html(
            [{"did_id": 0xF180, "short_name": "Boot", "description": "Bootloader id"}]
        )
        assert "<table" in out
        assert "0xF180" in out
        assert "Boot" in out
        assert "Bootloader id" in out

    def test_md_basic_table(self) -> None:
        out = render_boot_only_did_table_md(
            [{"did_id": 0xF180, "short_name": "Boot"}]
        )
        # Header row uses "DID ID" to match the codebase's `did_id` field.
        assert "| DID" in out and "Short Name" in out
        assert "`0xF180`" in out

    def test_rst_basic_table(self) -> None:
        out = render_boot_only_did_table_rst(
            [{"did_id": 0xF180, "short_name": "Boot"}]
        )
        assert "csv-table" in out
        assert "0xF180" in out


# ---------------------------------------------------------------------------
# Boot-only RIDs
# ---------------------------------------------------------------------------


class TestBootOnlyRids:
    def test_tex_empty_returns_empty_string(self) -> None:
        assert render_boot_only_rid_table_tex([]) == ""

    def test_tex_malformed_entries_skipped(self) -> None:
        entries = [
            {"short_name": "Orphan"},
            {"rid_id": 0xFF00, "short_name": "FlashErase"},
        ]
        out = render_boot_only_rid_table_tex(entries)
        assert "Orphan" not in out
        assert "FlashErase" in out
        assert "0xFF00" in out

    def test_html_basic_table(self) -> None:
        out = render_boot_only_rid_table_html(
            [{"rid_id": 0xFF00, "short_name": "Erase"}]
        )
        assert "<table" in out
        assert "0xFF00" in out

    def test_md_basic_table(self) -> None:
        out = render_boot_only_rid_table_md(
            [{"rid_id": 0xFF00, "short_name": "Erase"}]
        )
        assert "| RID |" in out
        assert "`0xFF00`" in out

    def test_rst_basic_table(self) -> None:
        out = render_boot_only_rid_table_rst(
            [{"rid_id": 0xFF00, "short_name": "Erase"}]
        )
        assert "csv-table" in out


# ---------------------------------------------------------------------------
# CAN ID comparison
# ---------------------------------------------------------------------------


class TestCanIdComparison:
    def test_tex_both_drive_and_boot(self) -> None:
        out = render_can_id_comparison_tex(
            DomainCanIds(physical="0x18DA00E0"),
            DomainCanIds(physical="0x18DA00F0"),
        )
        assert "Drive" in out
        assert "Boot" in out
        assert "0x18DA00E0" in out
        assert "0x18DA00F0" in out

    def test_tex_drive_only(self) -> None:
        out = render_can_id_comparison_tex(
            DomainCanIds(physical="0x18DA00E0"),
            None,
        )
        assert "Drive" in out
        assert "Boot" not in out
        assert "0x18DA00E0" in out

    def test_tex_boot_only(self) -> None:
        out = render_can_id_comparison_tex(
            None,
            DomainCanIds(physical="0x18DA00F0"),
        )
        assert "Boot" in out
        assert "Drive" not in out
        assert "0x18DA00F0" in out

    def test_tex_both_none_empty_string(self) -> None:
        assert render_can_id_comparison_tex(None, None) == ""

    def test_html_basic(self) -> None:
        out = render_can_id_comparison_html(
            DomainCanIds(physical="0x123"),
            DomainCanIds(physical="0x456"),
        )
        assert "<table" in out
        assert "0x123" in out
        assert "0x456" in out

    def test_md_basic(self) -> None:
        out = render_can_id_comparison_md(
            DomainCanIds(physical="0x123"),
            DomainCanIds(physical="0x456"),
        )
        assert "| Domain | Physical |" in out
        assert "0x123" in out
        assert "0x456" in out

    def test_rst_basic(self) -> None:
        out = render_can_id_comparison_rst(
            DomainCanIds(physical="0x123"),
            DomainCanIds(physical="0x456"),
        )
        assert "csv-table" in out
        assert "0x123" in out
        assert "0x456" in out


# ---------------------------------------------------------------------------
# Full section composers
# ---------------------------------------------------------------------------


class TestSectionTex:
    def test_no_data_returns_empty(self) -> None:
        assert render_reprogramming_section_tex(BootOverlay()) == ""
        assert render_reprogramming_section_tex(empty_overlay()) == ""

    def test_starts_with_section_command(self) -> None:
        out = render_reprogramming_section_tex(_overlay_with_bootloader())
        assert "\\section{" in out
        # Bootloader / Reprogramming title (or its i18n equivalent).
        assert "Bootloader" in out or "Reprogramming" in out

    def test_contains_all_subsections(self) -> None:
        out = render_reprogramming_section_tex(_overlay_with_bootloader())
        # programming sequence, flash map, config
        assert out.count("\\subsection{") >= 2
        # tikz figure for sequence diagram
        assert "umlseqdiag" in out
        # flash memory map data
        assert "AppCode" in out
        # config: reset address
        assert "0x00080000" in out

    def test_boot_only_dids_subsection_added(self) -> None:
        overlay = _overlay_with_boot_only_dids()
        out = render_reprogramming_section_tex(overlay)
        assert "BootSwIdentification" in out
        assert "0xF180" in out

    def test_boot_only_rids_subsection_added(self) -> None:
        overlay = _overlay_with_boot_only_rids()
        out = render_reprogramming_section_tex(overlay)
        assert "FlashErase" in out
        assert "0xFF00" in out


class TestSectionHtml:
    def test_no_data_returns_empty(self) -> None:
        assert render_reprogramming_section_html(BootOverlay()) == ""

    def test_contains_section_and_headings(self) -> None:
        out = render_reprogramming_section_html(_overlay_with_bootloader())
        assert "<section" in out
        assert "<h2>" in out
        # Programming sequence rendered as an <ol>.
        assert "<ol>" in out
        # Flash memory map rendered as <table>.
        assert "<table" in out
        assert "AppCode" in out


class TestSectionMd:
    def test_no_data_returns_empty(self) -> None:
        assert render_reprogramming_section_md(BootOverlay()) == ""

    def test_h2_and_h3(self) -> None:
        out = render_reprogramming_section_md(_overlay_with_bootloader())
        assert "## " in out  # section heading
        assert "### " in out  # subsection heading
        assert "AppCode" in out


class TestSectionRst:
    def test_no_data_returns_empty(self) -> None:
        assert render_reprogramming_section_rst(BootOverlay()) == ""

    def test_has_underlined_title(self) -> None:
        out = render_reprogramming_section_rst(_overlay_with_bootloader())
        # title underlined with '=' characters
        assert "=====" in out
        assert "AppCode" in out


# ---------------------------------------------------------------------------
# Generator integration
# ---------------------------------------------------------------------------


class TestGeneratorIntegrationTex:
    def test_generate_with_overlay_contains_bootloader(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        overlay = _overlay_with_bootloader()
        gen = TexGenerator()
        out_path = gen.generate(spec, tmp_path / "spec.tex", overlay=overlay)
        text = out_path.read_text(encoding="utf-8")
        assert "Bootloader" in text or "Reprogramming" in text
        assert "AppCode" in text  # flash segment

    def test_generate_without_overlay_no_bootloader(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        gen = TexGenerator()
        out_path = gen.generate(spec, tmp_path / "spec.tex")
        text = out_path.read_text(encoding="utf-8")
        # Without an overlay there must be no auto-generated section header.
        assert "Bootloader / Reprogramming" not in text

    def test_generate_string_no_overlay_matches_baseline(self) -> None:
        # Empty overlay should be byte-identical to None.
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        gen = TexGenerator()
        baseline = gen.generate_string(spec)
        with_empty = gen.generate_string(spec, overlay=BootOverlay())
        assert with_empty == baseline


class TestGeneratorIntegrationHtml:
    def test_generate_html_with_overlay(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        overlay = _overlay_with_bootloader()
        gen = TexGenerator()
        out_path = gen.generate_html(spec, tmp_path / "spec.html", overlay=overlay)
        text = out_path.read_text(encoding="utf-8")
        assert "Bootloader" in text or "Reprogramming" in text
        assert "AppCode" in text
        assert "<section" in text or "<h2" in text

    def test_generate_html_without_overlay(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        gen = TexGenerator()
        out_path = gen.generate_html(spec, tmp_path / "spec.html")
        text = out_path.read_text(encoding="utf-8")
        # No reprogramming chapter when no overlay supplied.
        assert "<section class=\"bootloader-reprogramming\"" not in text


class TestGeneratorIntegrationMd:
    def test_generate_md_with_overlay(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        overlay = _overlay_with_bootloader()
        gen = TexGenerator()
        out_path = gen.generate_markdown(
            spec, tmp_path / "spec.md", overlay=overlay
        )
        text = out_path.read_text(encoding="utf-8")
        assert "## Bootloader" in text or "Reprogramming" in text
        assert "AppCode" in text

    def test_generate_md_without_overlay_unchanged(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        gen = TexGenerator()
        path_a = gen.generate_markdown(spec, tmp_path / "a.md")
        path_b = gen.generate_markdown(
            spec, tmp_path / "b.md", overlay=BootOverlay()
        )
        # Empty overlay → identical content to no overlay.
        assert path_a.read_text(encoding="utf-8") == path_b.read_text(
            encoding="utf-8"
        )


class TestGeneratorIntegrationRst:
    def test_generate_rst_with_overlay(self, tmp_path: Path) -> None:
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        overlay = _overlay_with_bootloader()
        gen = TexGenerator()
        out_path = gen.generate_rst(spec, tmp_path / "spec.rst", overlay=overlay)
        text = out_path.read_text(encoding="utf-8")
        assert "AppCode" in text


# ---------------------------------------------------------------------------
# Convenience API
# ---------------------------------------------------------------------------


class TestRenderReprogrammingConvenience:
    def test_render_tex(self) -> None:
        gen = TexGenerator()
        out = gen.render_reprogramming(_overlay_with_bootloader(), "tex")
        assert "\\section{" in out
        assert "AppCode" in out

    def test_render_html(self) -> None:
        gen = TexGenerator()
        out = gen.render_reprogramming(_overlay_with_bootloader(), "html")
        assert "<section" in out
        assert "AppCode" in out

    def test_render_md(self) -> None:
        gen = TexGenerator()
        out = gen.render_reprogramming(_overlay_with_bootloader(), "md")
        assert "## " in out
        assert "AppCode" in out

    def test_render_rst(self) -> None:
        gen = TexGenerator()
        out = gen.render_reprogramming(_overlay_with_bootloader(), "rst")
        assert "AppCode" in out

    def test_unknown_fmt_raises(self) -> None:
        gen = TexGenerator()
        with pytest.raises(ValueError):
            gen.render_reprogramming(_overlay_with_bootloader(), "xml")

    def test_write_reprogramming(self, tmp_path: Path) -> None:
        gen = TexGenerator()
        out_path = gen.write_reprogramming(
            _overlay_with_bootloader(), tmp_path / "frag.tex", "tex"
        )
        text = out_path.read_text(encoding="utf-8")
        assert "AppCode" in text
        assert "\\section{" in text

    def test_write_reprogramming_empty_overlay(self, tmp_path: Path) -> None:
        gen = TexGenerator()
        out_path = gen.write_reprogramming(BootOverlay(), tmp_path / "frag.tex")
        # empty overlay -> empty file
        assert out_path.read_text(encoding="utf-8") == ""


# ---------------------------------------------------------------------------
# Generic-only / no brand names
# ---------------------------------------------------------------------------


class TestGenericOnly:
    """The module must never emit vendor / OEM identifiers."""

    BANNED = ("SUBARU", "Bosch", "Vector", "EPSdp", "BMW", "Toyota")

    def test_renderers_have_no_brand_names(self) -> None:
        overlay = _overlay_with_bootloader()
        for renderer in (
            render_reprogramming_section_tex,
            render_reprogramming_section_html,
            render_reprogramming_section_md,
            render_reprogramming_section_rst,
        ):
            text = renderer(overlay)
            for token in self.BANNED:
                assert token not in text, f"{renderer.__name__} leaked {token}"
