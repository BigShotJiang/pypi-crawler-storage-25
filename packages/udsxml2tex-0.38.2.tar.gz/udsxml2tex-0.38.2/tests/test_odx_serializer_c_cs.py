"""Tests for the ODX-C and ODX-CS XML serializers.

Covers the shared helpers in :mod:`udsxml2tex.odx.serializers._shared`,
the :func:`serialize_odx_cs` and :func:`serialize_odx_c` entry points and
an end-to-end round-trip against the bundled sample fixture (ARXML →
mapper → ODX-CS serializer → re-parse).
"""

from __future__ import annotations

from pathlib import Path

import pytest
from lxml import etree

from udsxml2tex import ArxmlParser, CanTpParser
from udsxml2tex.models import UdsSpecification
from udsxml2tex.odx import (
    AdminData,
    Audience,
    CompanyData,
    Comparam,
    ComparamRefValuePair,
    ComparamSpec,
    ComparamSubset,
    ComplexComparam,
    CompuMethod,
    CompuScale,
    DataObjectProp,
    DiagCodedType,
    DocRevision,
    OdxCategory,
    OdxDocument,
    OdxId,
    OdxRef,
    PhysicalType,
    ProtocolStack,
    SpecialDataGroup,
    Unit,
    UnitGroup,
    UnitSpec,
    map_spec_to_odx,
)
from udsxml2tex.odx.serializers._shared import (
    XSI_NS,
    add_admin_data,
    add_audience,
    add_company_datas,
    add_compu_method,
    add_diag_coded_type,
    add_dop,
    add_long_name,
    add_physical_type,
    add_sdgs,
    add_text_child,
    add_unit_spec,
    make_root,
    serialize_element,
    set_ref_attrs,
)
from udsxml2tex.odx.serializers.odx_c import serialize_odx_c, write_odx_c
from udsxml2tex.odx.serializers.odx_cs import serialize_odx_cs, write_odx_cs

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_CANTP = FIXTURES_DIR / "sample_cantp.arxml"


# ---------------------------------------------------------------------------
# 1. _shared helpers
# ---------------------------------------------------------------------------


class TestSharedHelpers:
    """Direct unit tests for the public helpers in ``_shared.py``."""

    def test_make_root_attributes(self):
        root = make_root()
        assert root.tag == "ODX"
        assert root.get("MODEL-VERSION") == "2.2.0"
        # xmlns:xsi must be declared on the root.
        assert root.nsmap.get("xsi") == XSI_NS

    def test_serialize_element_emits_declaration(self):
        root = make_root()
        out = serialize_element(root)
        assert isinstance(out, bytes)
        assert out.startswith(b"<?xml")
        assert b"encoding='UTF-8'" in out or b'encoding="UTF-8"' in out
        assert b"standalone='no'" in out or b'standalone="no"' in out

    def test_add_text_child_skips_none(self):
        root = etree.Element("R")
        assert add_text_child(root, "X", None) is None
        assert root.find("X") is None

    def test_add_text_child_skips_empty_string(self):
        root = etree.Element("R")
        assert add_text_child(root, "X", "") is None
        assert root.find("X") is None

    def test_add_text_child_zero_is_emitted(self):
        root = etree.Element("R")
        add_text_child(root, "X", 0)
        assert root.find("X").text == "0"

    def test_add_text_child_bool_serialises_lowercase(self):
        root = etree.Element("R")
        add_text_child(root, "Y", True)
        add_text_child(root, "N", False)
        assert root.find("Y").text == "true"
        assert root.find("N").text == "false"

    def test_add_long_name_skipped_when_none(self):
        root = etree.Element("R")
        add_long_name(root, None)
        assert root.find("LONG-NAME") is None

    def test_set_ref_attrs_full(self):
        elem = etree.Element("REF")
        set_ref_attrs(elem, OdxRef(id_ref="a.b", docref="X.odx-cs", docref_type="X"))
        assert elem.get("ID-REF") == "a.b"
        assert elem.get("DOCREF") == "X.odx-cs"
        assert elem.get("DOCTYPE") == "X"

    def test_set_ref_attrs_minimal(self):
        elem = etree.Element("REF")
        set_ref_attrs(elem, OdxRef(id_ref="just.id"))
        assert elem.get("ID-REF") == "just.id"
        assert elem.get("DOCREF") is None
        assert elem.get("DOCTYPE") is None

    def test_add_admin_data_noop(self):
        root = etree.Element("R")
        add_admin_data(root, None)
        assert root.find("ADMIN-DATA") is None

    def test_add_admin_data_full(self):
        root = etree.Element("R")
        admin = AdminData(
            language="en-US",
            company_doc_infos=[CompanyData(oid="udsxml2tex.odx.d.company.Foo", short_name="Foo")],
            doc_revisions=[
                DocRevision(revision_label="0.1", state="DRAFT", date="2026-01-01"),
                DocRevision(revision_label="0.2", state="RELEASED", date="2026-02-01"),
            ],
        )
        add_admin_data(root, admin)
        ad = root.find("ADMIN-DATA")
        assert ad is not None
        assert ad.findtext("LANGUAGE") == "en-US"
        revisions = ad.findall("DOC-REVISIONS/DOC-REVISION")
        assert len(revisions) == 2
        labels = [r.findtext("REVISION-LABEL") for r in revisions]
        assert labels == ["0.1", "0.2"]
        company_ref = ad.find("COMPANY-DOC-INFOS/COMPANY-DOC-INFO/COMPANY-DATA-REF")
        assert company_ref.get("ID-REF") == "udsxml2tex.odx.d.company.Foo"

    def test_add_company_datas_with_roles(self):
        root = etree.Element("R")
        add_company_datas(
            root,
            [
                CompanyData(
                    oid="cd.1",
                    short_name="Acme",
                    long_name="Acme Corp",
                    roles=["MANUFACTURER", "SUPPLIER"],
                )
            ],
        )
        cd = root.find("COMPANY-DATAS/COMPANY-DATA")
        assert cd is not None
        assert cd.get("ID") == "cd.1"
        roles = [r.text for r in cd.findall("ROLES/ROLE")]
        assert roles == ["MANUFACTURER", "SUPPLIER"]

    def test_add_sdgs_skipped_when_empty(self):
        root = etree.Element("R")
        add_sdgs(root, [])
        assert root.find("SDGS") is None

    def test_add_sdgs_emits_items(self):
        root = etree.Element("R")
        add_sdgs(
            root,
            [
                SpecialDataGroup(
                    caption="Vendor",
                    sd_items=[("k1", "v1"), ("k2", "v2")],
                )
            ],
        )
        sds = root.findall("SDGS/SDG/SD")
        assert [(s.get("SI"), s.text) for s in sds] == [("k1", "v1"), ("k2", "v2")]
        caption = root.findtext("SDGS/SDG/SDG-CAPTION/SHORT-NAME")
        assert caption == "Vendor"

    def test_add_audience_all_attrs(self):
        root = etree.Element("R")
        add_audience(
            root,
            Audience(
                enabled_audiences=["x.aud.1"],
                is_supplier=False,
                is_development=True,
                is_manufacturing=False,
                is_aftersales=True,
                is_aftermarket=False,
            ),
        )
        a = root.find("AUDIENCE")
        assert a is not None
        assert a.get("IS-SUPPLIER") == "false"
        assert a.get("IS-DEVELOPMENT") == "true"
        assert a.get("IS-MANUFACTURING") == "false"
        assert a.get("IS-AFTERSALES") == "true"
        assert a.get("IS-AFTERMARKET") == "false"
        refs = a.findall("ENABLED-AUDIENCE-REFS/ENABLED-AUDIENCE-REF")
        assert [r.get("ID-REF") for r in refs] == ["x.aud.1"]

    def test_add_diag_coded_type_xsi_type(self):
        root = etree.Element("R")
        add_diag_coded_type(
            root,
            DiagCodedType(
                base_data_type="A_UINT32",
                coded_type="STANDARD-LENGTH-TYPE",
                bit_length=16,
            ),
        )
        dct = root.find("DIAG-CODED-TYPE")
        assert dct is not None
        assert dct.get("BASE-DATA-TYPE") == "A_UINT32"
        assert dct.get(f"{{{XSI_NS}}}type") == "STANDARD-LENGTH-TYPE"
        assert dct.findtext("BIT-LENGTH") == "16"

    def test_add_diag_coded_type_min_max(self):
        root = etree.Element("R")
        add_diag_coded_type(
            root,
            DiagCodedType(
                coded_type="MIN-MAX-LENGTH-TYPE",
                min_length=1,
                max_length=8,
                termination="END-OF-PDU",
            ),
        )
        dct = root.find("DIAG-CODED-TYPE")
        assert dct.findtext("MIN-LENGTH") == "1"
        assert dct.findtext("MAX-LENGTH") == "8"
        assert dct.findtext("TERMINATION") == "END-OF-PDU"

    def test_add_physical_type_optional_attrs(self):
        root = etree.Element("R")
        add_physical_type(
            root,
            PhysicalType(base_data_type="A_FLOAT64", display_radix="DEC", precision=2),
        )
        pt = root.find("PHYSICAL-TYPE")
        assert pt.get("BASE-DATA-TYPE") == "A_FLOAT64"
        assert pt.get("DISPLAY-RADIX") == "DEC"
        assert pt.findtext("PRECISION") == "2"

    def test_add_compu_method_linear(self):
        root = etree.Element("R")
        add_compu_method(
            root,
            CompuMethod(
                category="LINEAR",
                compu_internal_to_phys=[
                    CompuScale(
                        lower_limit="0",
                        upper_limit="255",
                        compu_rational_coeffs=([0.0, 1.0], [1.0]),
                    )
                ],
            ),
        )
        cm = root.find("COMPU-METHOD")
        assert cm.findtext("CATEGORY") == "LINEAR"
        scale = cm.find("COMPU-INTERNAL-TO-PHYS/COMPU-SCALES/COMPU-SCALE")
        assert scale is not None
        assert scale.findtext("LOWER-LIMIT") == "0"
        nums = scale.findall("COMPU-RATIONAL-COEFFS/COMPU-NUMERATOR/V")
        assert [n.text for n in nums] == ["0.0", "1.0"]

    def test_add_compu_method_texttable_const(self):
        root = etree.Element("R")
        add_compu_method(
            root,
            CompuMethod(
                category="TEXTTABLE",
                compu_internal_to_phys=[
                    CompuScale(lower_limit="0", upper_limit="0", compu_const="off"),
                    CompuScale(lower_limit="1", upper_limit="1", compu_const="on"),
                ],
            ),
        )
        values = [v.text for v in root.findall(
            "COMPU-METHOD/COMPU-INTERNAL-TO-PHYS/COMPU-SCALES/COMPU-SCALE/COMPU-CONST/VT"
        )]
        assert values == ["off", "on"]

    def test_add_unit_spec_full(self):
        root = etree.Element("R")
        add_unit_spec(
            root,
            UnitSpec(
                units=[
                    Unit(oid="u.1", short_name="ms", display_name="ms"),
                    Unit(oid="u.2", short_name="s", display_name="s",
                         factor_si_to_unit=1.0, offset_si_to_unit=0.0),
                ],
                unit_groups=[
                    UnitGroup(
                        oid="g.1",
                        short_name="SI",
                        category="EQUIV-UNITS",
                        unit_refs=[OdxRef(id_ref="u.1"), OdxRef(id_ref="u.2")],
                    )
                ],
                physical_dimensions=[
                    OdxId(oid="pd.1", short_name="Time", long_name="Time dim.")
                ],
            ),
        )
        us = root.find("UNIT-SPEC")
        assert us is not None
        units = us.findall("UNITS/UNIT")
        assert [u.findtext("SHORT-NAME") for u in units] == ["ms", "s"]
        group_refs = us.findall("UNIT-GROUPS/UNIT-GROUP/UNIT-REFS/UNIT-REF")
        assert [r.get("ID-REF") for r in group_refs] == ["u.1", "u.2"]
        dim = us.find("PHYSICAL-DIMENSIONS/PHYSICAL-DIMENSION")
        assert dim.findtext("SHORT-NAME") == "Time"

    def test_add_unit_spec_skipped_when_empty(self):
        root = etree.Element("R")
        add_unit_spec(root, UnitSpec())
        assert root.find("UNIT-SPEC") is None

    def test_add_dop_full(self):
        root = etree.Element("DATA-OBJECT-PROPS")
        add_dop(
            root,
            DataObjectProp(
                oid="d.dop.1",
                short_name="Speed",
                long_name="Vehicle speed",
                description="km/h reading",
                compu_method=CompuMethod(category="IDENTICAL"),
                diag_coded_type=DiagCodedType(bit_length=8),
                physical_type=PhysicalType(),
                internal_constr=("0", "255"),
                unit_ref=OdxRef(id_ref="u.kmh"),
                sdgs=[SpecialDataGroup(caption="Vendor", sd_items=[("k", "v")])],
            ),
        )
        dop = root.find("DATA-OBJECT-PROP")
        assert dop.get("ID") == "d.dop.1"
        assert dop.findtext("SHORT-NAME") == "Speed"
        assert dop.findtext("DESC/p") == "km/h reading"
        assert dop.find("DIAG-CODED-TYPE") is not None
        assert dop.find("PHYSICAL-TYPE") is not None
        ic = dop.find("INTERNAL-CONSTR")
        assert ic.findtext("LOWER-LIMIT") == "0"
        assert ic.findtext("UPPER-LIMIT") == "255"
        assert dop.find("UNIT-REF").get("ID-REF") == "u.kmh"
        assert dop.find("SDGS") is not None


# ---------------------------------------------------------------------------
# 2. ODX-CS serializer
# ---------------------------------------------------------------------------


def _parse_bytes(payload: bytes) -> etree._Element:
    """Helper: parse serialized XML and return the ``<ODX>`` root."""
    return etree.fromstring(payload)


def _make_subset_doc(subset: ComparamSubset) -> OdxDocument:
    return OdxDocument(
        category=OdxCategory.COMPARAM_SUBSET,
        comparam_subset=subset,
        pdx_member_path=f"{subset.short_name}.odx-cs",
    )


class TestOdxCsSerializer:
    """End-to-end behaviour of :func:`serialize_odx_cs`."""

    def test_wrong_category_raises(self):
        doc = OdxDocument(category=OdxCategory.COMPARAM_SPEC)
        with pytest.raises(ValueError):
            serialize_odx_cs(doc)

    def test_empty_content_raises(self):
        doc = OdxDocument(category=OdxCategory.COMPARAM_SUBSET, comparam_subset=None)
        with pytest.raises(ValueError):
            serialize_odx_cs(doc)

    def test_empty_subset_yields_minimum_structure(self):
        subset = ComparamSubset(
            oid="udsxml2tex.odx.cs.subset.Empty",
            short_name="Empty",
            category="EMPTY",
        )
        out = serialize_odx_cs(_make_subset_doc(subset))
        root = _parse_bytes(out)
        assert root.tag == "ODX"
        cs = root.find("COMPARAM-SUBSET")
        assert cs is not None
        assert cs.get("ID") == "udsxml2tex.odx.cs.subset.Empty"
        assert cs.get("CATEGORY") == "EMPTY"
        assert cs.findtext("SHORT-NAME") == "Empty"
        # No optional blocks present.
        assert cs.find("COMPARAMS") is None
        assert cs.find("COMPLEX-COMPARAMS") is None
        assert cs.find("DATA-OBJECT-PROPS") is None
        assert cs.find("UNIT-SPEC") is None

    def test_multiple_cptypes(self):
        subset = ComparamSubset(
            oid="udsxml2tex.odx.cs.subset.Multi",
            short_name="Multi",
            category="ISO_15765_2",
            comparams=[
                Comparam(
                    oid="udsxml2tex.odx.cs.comparam.A",
                    short_name="A",
                    param_class="TIMING",
                    cptype="STANDARD",
                    physical_default_value="100",
                ),
                Comparam(
                    oid="udsxml2tex.odx.cs.comparam.B",
                    short_name="B",
                    param_class="FUNCTIONAL",
                    cptype="OPTIONAL",
                    physical_default_value="0",
                ),
                Comparam(
                    oid="udsxml2tex.odx.cs.comparam.C",
                    short_name="C",
                    param_class="IDENTIFICATION",
                    cptype="SYSTEM",
                ),
            ],
        )
        out = serialize_odx_cs(_make_subset_doc(subset))
        root = _parse_bytes(out)
        comparams = root.findall("COMPARAM-SUBSET/COMPARAMS/COMPARAM")
        assert len(comparams) == 3
        cptypes = [c.get("CPTYPE") for c in comparams]
        assert cptypes == ["STANDARD", "OPTIONAL", "SYSTEM"]
        param_classes = [c.get("PARAM-CLASS") for c in comparams]
        assert param_classes == ["TIMING", "FUNCTIONAL", "IDENTIFICATION"]
        defaults = [c.findtext("PHYSICAL-DEFAULT-VALUE") for c in comparams]
        assert defaults == ["100", "0", None]

    def test_complex_comparam_with_nested(self):
        subset = ComparamSubset(
            oid="udsxml2tex.odx.cs.subset.X",
            short_name="X",
            complex_comparams=[
                ComplexComparam(
                    oid="udsxml2tex.odx.cs.ccomparam.Outer",
                    short_name="Outer",
                    cptype="STANDARD",
                    sub_comparams=[
                        Comparam(
                            oid="udsxml2tex.odx.cs.comparam.SubA",
                            short_name="SubA",
                            param_class="TIMING",
                            cptype="STANDARD",
                            physical_default_value="10",
                        ),
                        Comparam(
                            oid="udsxml2tex.odx.cs.comparam.SubB",
                            short_name="SubB",
                            param_class="TIMING",
                            cptype="STANDARD",
                            physical_default_value="20",
                        ),
                    ],
                )
            ],
        )
        out = serialize_odx_cs(_make_subset_doc(subset))
        root = _parse_bytes(out)
        outer = root.find("COMPARAM-SUBSET/COMPLEX-COMPARAMS/COMPLEX-COMPARAM")
        assert outer is not None
        assert outer.get("ID") == "udsxml2tex.odx.cs.ccomparam.Outer"
        nested = outer.findall("COMPARAMS/COMPARAM")
        assert [c.findtext("SHORT-NAME") for c in nested] == ["SubA", "SubB"]

    def test_subset_with_data_object_props(self):
        subset = ComparamSubset(
            oid="udsxml2tex.odx.cs.subset.DOP",
            short_name="DOP",
            data_object_props=[
                DataObjectProp(
                    oid="udsxml2tex.odx.cs.dop.uint32_ms",
                    short_name="uint32_ms",
                    compu_method=CompuMethod(category="IDENTICAL"),
                    diag_coded_type=DiagCodedType(
                        base_data_type="A_UINT32", bit_length=32
                    ),
                    physical_type=PhysicalType(base_data_type="A_UINT32"),
                )
            ],
        )
        out = serialize_odx_cs(_make_subset_doc(subset))
        root = _parse_bytes(out)
        dop = root.find("COMPARAM-SUBSET/DATA-OBJECT-PROPS/DATA-OBJECT-PROP")
        assert dop is not None
        assert dop.get("ID") == "udsxml2tex.odx.cs.dop.uint32_ms"
        assert dop.find("DIAG-CODED-TYPE/BIT-LENGTH").text == "32"

    @pytest.mark.parametrize(
        "base_type",
        ["A_UINT32", "A_INT32", "A_FLOAT32", "A_FLOAT64", "A_BYTEFIELD",
         "A_ASCIISTRING", "A_UTF8STRING", "A_UNICODE2STRING"],
    )
    def test_dop_covers_base_data_types(self, base_type):
        subset = ComparamSubset(
            oid="x.cs.subset.types",
            short_name="Types",
            data_object_props=[
                DataObjectProp(
                    oid=f"x.cs.dop.{base_type}",
                    short_name=f"dop_{base_type}",
                    diag_coded_type=DiagCodedType(base_data_type=base_type),
                    physical_type=PhysicalType(base_data_type=base_type),
                )
            ],
        )
        out = serialize_odx_cs(_make_subset_doc(subset))
        root = _parse_bytes(out)
        dop = root.find("COMPARAM-SUBSET/DATA-OBJECT-PROPS/DATA-OBJECT-PROP")
        assert dop.find("DIAG-CODED-TYPE").get("BASE-DATA-TYPE") == base_type
        assert dop.find("PHYSICAL-TYPE").get("BASE-DATA-TYPE") == base_type

    def test_subset_with_unit_spec(self):
        subset = ComparamSubset(
            oid="udsxml2tex.odx.cs.subset.US",
            short_name="US",
            unit_spec=UnitSpec(
                units=[Unit(oid="u.ms", short_name="ms", display_name="ms")],
                unit_groups=[
                    UnitGroup(
                        oid="g.SI",
                        short_name="SI",
                        category="EQUIV-UNITS",
                        unit_refs=[OdxRef(id_ref="u.ms")],
                    )
                ],
            ),
        )
        out = serialize_odx_cs(_make_subset_doc(subset))
        root = _parse_bytes(out)
        unit = root.find("COMPARAM-SUBSET/UNIT-SPEC/UNITS/UNIT")
        assert unit.findtext("SHORT-NAME") == "ms"
        group = root.find("COMPARAM-SUBSET/UNIT-SPEC/UNIT-GROUPS/UNIT-GROUP")
        assert group.findtext("SHORT-NAME") == "SI"

    def test_admin_data_attached_to_subset(self):
        subset = ComparamSubset(
            oid="udsxml2tex.odx.cs.subset.AD",
            short_name="AD",
        )
        admin = AdminData(
            language="en-US",
            doc_revisions=[
                DocRevision(revision_label="0.1", state="DRAFT", date="2026-01-01"),
                DocRevision(revision_label="0.2", state="DRAFT", date="2026-02-01"),
                DocRevision(revision_label="1.0", state="RELEASED", date="2026-03-01"),
            ],
        )
        doc = _make_subset_doc(subset)
        doc.admin_data = admin
        out = serialize_odx_cs(doc)
        root = _parse_bytes(out)
        ad = root.find("COMPARAM-SUBSET/ADMIN-DATA")
        assert ad is not None
        labels = [r.text for r in ad.findall("DOC-REVISIONS/DOC-REVISION/REVISION-LABEL")]
        assert labels == ["0.1", "0.2", "1.0"]
        assert ad.findtext("LANGUAGE") == "en-US"

    def test_write_odx_cs_writes_bytes(self, tmp_path: Path):
        subset = ComparamSubset(
            oid="udsxml2tex.odx.cs.subset.W",
            short_name="W",
            category="ISO_15765_2",
        )
        out = tmp_path / "W.odx-cs"
        result = write_odx_cs(_make_subset_doc(subset), out)
        assert result == out
        assert out.exists()
        assert out.read_bytes().startswith(b"<?xml")


# ---------------------------------------------------------------------------
# 3. ODX-C serializer
# ---------------------------------------------------------------------------


def _make_spec_doc(spec: ComparamSpec) -> OdxDocument:
    return OdxDocument(
        category=OdxCategory.COMPARAM_SPEC,
        comparam_spec=spec,
        pdx_member_path=f"{spec.short_name}.odx-c",
    )


class TestOdxCSerializer:
    """End-to-end behaviour of :func:`serialize_odx_c`."""

    def test_wrong_category_raises(self):
        doc = OdxDocument(category=OdxCategory.COMPARAM_SUBSET)
        with pytest.raises(ValueError):
            serialize_odx_c(doc)

    def test_empty_content_raises(self):
        doc = OdxDocument(category=OdxCategory.COMPARAM_SPEC, comparam_spec=None)
        with pytest.raises(ValueError):
            serialize_odx_c(doc)

    def test_basic_spec_serialises(self):
        spec = ComparamSpec(
            oid="udsxml2tex.odx.c.spec.UDS_On_CAN",
            short_name="UDS_On_CAN",
            long_name="UDS on CAN comparam spec",
        )
        out = serialize_odx_c(_make_spec_doc(spec))
        root = _parse_bytes(out)
        assert root.tag == "ODX"
        spec_elem = root.find("COMPARAM-SPEC")
        assert spec_elem is not None
        assert spec_elem.get("ID") == "udsxml2tex.odx.c.spec.UDS_On_CAN"
        assert spec_elem.findtext("SHORT-NAME") == "UDS_On_CAN"
        assert spec_elem.findtext("LONG-NAME") == "UDS on CAN comparam spec"

    def test_spec_with_multiple_subset_refs(self):
        spec = ComparamSpec(
            oid="udsxml2tex.odx.c.spec.S",
            short_name="S",
            comparam_subsets=[
                ComparamSubset(
                    oid="udsxml2tex.odx.cs.subset.ISO_15765_2",
                    short_name="ISO_15765_2",
                    category="ISO_15765_2",
                ),
                ComparamSubset(
                    oid="udsxml2tex.odx.cs.subset.DCM",
                    short_name="DCM",
                    category="DCM",
                ),
            ],
        )
        out = serialize_odx_c(_make_spec_doc(spec))
        root = _parse_bytes(out)
        refs = root.findall("COMPARAM-SPEC/COMPARAM-SUBSET-REFS/COMPARAM-SUBSET-REF")
        assert len(refs) == 2
        assert [r.get("ID-REF") for r in refs] == [
            "udsxml2tex.odx.cs.subset.ISO_15765_2",
            "udsxml2tex.odx.cs.subset.DCM",
        ]
        assert [r.get("DOCTYPE") for r in refs] == ["COMPARAM-SUBSET", "COMPARAM-SUBSET"]
        assert [r.get("DOCREF") for r in refs] == ["ISO_15765_2", "DCM"]

    def test_spec_with_protocol_stacks(self):
        spec = ComparamSpec(
            oid="udsxml2tex.odx.c.spec.S",
            short_name="S",
            protocol_stacks=[
                ProtocolStack(
                    oid="udsxml2tex.odx.c.stack.UDS_On_CAN",
                    short_name="UDS_On_CAN",
                    pdu_protocol_type="ISO_15765_2",
                    physical_link_type="ISO_11898_2_DWCAN",
                ),
                ProtocolStack(
                    oid="udsxml2tex.odx.c.stack.UDS_On_IP",
                    short_name="UDS_On_IP",
                    pdu_protocol_type="ISO_13400_2",
                    physical_link_type="ISO_13400_2_DoIP",
                ),
            ],
        )
        out = serialize_odx_c(_make_spec_doc(spec))
        root = _parse_bytes(out)
        stacks = root.findall("COMPARAM-SPEC/PROTOCOL-STACKS/PROTOCOL-STACK")
        assert len(stacks) == 2
        assert stacks[0].get("PDU-PROTOCOL-TYPE") == "ISO_15765_2"
        assert stacks[0].get("PHYSICAL-LINK-TYPE") == "ISO_11898_2_DWCAN"
        assert stacks[1].get("PDU-PROTOCOL-TYPE") == "ISO_13400_2"

    def test_spec_with_comparam_ref_value_pairs(self):
        stack = ProtocolStack(
            oid="udsxml2tex.odx.c.stack.UDS_On_CAN",
            short_name="UDS_On_CAN",
            pdu_protocol_type="ISO_15765_2",
            physical_link_type="ISO_11898_2_DWCAN",
        )
        spec = ComparamSpec(
            oid="udsxml2tex.odx.c.spec.S",
            short_name="S",
            protocol_stacks=[stack],
        )
        overrides = {
            stack.oid: [
                ComparamRefValuePair(
                    comparam_ref=OdxRef(
                        id_ref="udsxml2tex.odx.cs.comparam.CP_P2Server_Max",
                        docref="ISO_15765_2",
                        docref_type="COMPARAM-SUBSET",
                    ),
                    value="50",
                ),
                ComparamRefValuePair(
                    comparam_ref=OdxRef(
                        id_ref="udsxml2tex.odx.cs.comparam.CP_STmin",
                        docref="ISO_15765_2",
                        docref_type="COMPARAM-SUBSET",
                    ),
                    value="0",
                ),
            ]
        }
        out = serialize_odx_c(
            _make_spec_doc(spec), protocol_stack_overrides=overrides
        )
        root = _parse_bytes(out)
        pairs = root.findall(
            "COMPARAM-SPEC/PROTOCOL-STACKS/PROTOCOL-STACK/"
            "COMPARAM-REF-VALUE-PAIRS/COMPARAM-REF-VALUE-PAIR"
        )
        assert len(pairs) == 2
        refs = [p.find("COMPARAM-REF") for p in pairs]
        assert refs[0].get("ID-REF") == "udsxml2tex.odx.cs.comparam.CP_P2Server_Max"
        assert refs[0].get("DOCREF") == "ISO_15765_2"
        assert refs[0].get("DOCTYPE") == "COMPARAM-SUBSET"
        values = [p.findtext("PHYSICAL-DEFAULT-VALUE") for p in pairs]
        assert values == ["50", "0"]

    def test_spec_with_admin_data(self):
        spec = ComparamSpec(short_name="WithAdmin", oid="udsxml2tex.odx.c.spec.WithAdmin")
        doc = _make_spec_doc(spec)
        doc.admin_data = AdminData(
            language="en-US",
            doc_revisions=[DocRevision(revision_label="0.1", state="DRAFT")],
        )
        out = serialize_odx_c(doc)
        root = _parse_bytes(out)
        assert root.find("COMPARAM-SPEC/ADMIN-DATA") is not None
        assert root.findtext("COMPARAM-SPEC/ADMIN-DATA/LANGUAGE") == "en-US"

    def test_write_odx_c_writes_bytes(self, tmp_path: Path):
        spec = ComparamSpec(short_name="W", oid="udsxml2tex.odx.c.spec.W")
        out = tmp_path / "W.odx-c"
        result = write_odx_c(_make_spec_doc(spec), out)
        assert result == out
        assert out.exists()


# ---------------------------------------------------------------------------
# 4. Round-trip against the bundled sample
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def sample_spec_with_cantp() -> UdsSpecification:
    """Bundled ARXML sample + CanTp config attached so an ODX-CS is emitted."""
    spec = ArxmlParser().parse(SAMPLE_ARXML)
    spec.transport_config = CanTpParser().parse(SAMPLE_CANTP)
    return spec


class TestIntegrationRoundTrip:
    """Mapper output → serializer → parser round-trip."""

    def test_cs_present_in_mapper_output(self, sample_spec_with_cantp):
        docs = map_spec_to_odx(sample_spec_with_cantp)
        cs_docs = [d for d in docs.values()
                   if d.category == OdxCategory.COMPARAM_SUBSET]
        assert cs_docs, "mapper should emit at least one ODX-CS document"

    def test_serialized_cs_parses_back(self, sample_spec_with_cantp):
        docs = map_spec_to_odx(sample_spec_with_cantp)
        cs_doc = next(d for d in docs.values()
                      if d.category == OdxCategory.COMPARAM_SUBSET)
        payload = serialize_odx_cs(cs_doc)
        root = etree.fromstring(payload)
        assert root.tag == "ODX"
        cs = root.find("COMPARAM-SUBSET")
        assert cs is not None
        assert cs.get("CATEGORY") == "ISO_15765_2"

    def test_serialized_cs_has_expected_comparams(self, sample_spec_with_cantp):
        docs = map_spec_to_odx(sample_spec_with_cantp)
        cs_doc = next(d for d in docs.values()
                      if d.category == OdxCategory.COMPARAM_SUBSET)
        payload = serialize_odx_cs(cs_doc)
        root = etree.fromstring(payload)
        comparams = root.findall("COMPARAM-SUBSET/COMPARAMS/COMPARAM")
        short_names = {c.findtext("SHORT-NAME") for c in comparams}
        # Mapper sanitises CP_P2_SERVER_MAX → CP_P2_SERVER_MAX (already valid).
        assert "CP_P2_SERVER_MAX" in short_names
        assert "CP_P2_STAR_SERVER_MAX" in short_names
        assert "CP_STMIN" in short_names

    def test_round_trip_preserves_default_values(self, sample_spec_with_cantp):
        docs = map_spec_to_odx(sample_spec_with_cantp)
        cs_doc = next(d for d in docs.values()
                      if d.category == OdxCategory.COMPARAM_SUBSET)
        payload = serialize_odx_cs(cs_doc)
        root = etree.fromstring(payload)
        comparams = root.findall("COMPARAM-SUBSET/COMPARAMS/COMPARAM")
        by_name = {c.findtext("SHORT-NAME"): c for c in comparams}
        # All emitted comparams carry a CPTYPE attribute.
        assert all(c.get("CPTYPE") for c in comparams)
        # P2/STmin entries carry numeric default values.
        for name in ("CP_P2_SERVER_MAX", "CP_STMIN"):
            elem = by_name[name]
            text = elem.findtext("PHYSICAL-DEFAULT-VALUE")
            assert text is not None and text != ""

    def test_round_trip_xml_well_formed(self, sample_spec_with_cantp):
        docs = map_spec_to_odx(sample_spec_with_cantp)
        cs_doc = next(d for d in docs.values()
                      if d.category == OdxCategory.COMPARAM_SUBSET)
        payload = serialize_odx_cs(cs_doc)
        # Re-parsing must not raise — the bytes are valid XML.
        etree.fromstring(payload)
        # And the declaration must be present.
        assert payload.startswith(b"<?xml")
        assert b"MODEL-VERSION=\"2.2.0\"" in payload
