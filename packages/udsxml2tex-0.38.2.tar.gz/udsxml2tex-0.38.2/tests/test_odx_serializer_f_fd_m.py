"""Tests for the ODX-F, ODX-FD and ODX-M XML serializers.

Covers the :func:`serialize_odx_f`, :func:`serialize_odx_fd` and
:func:`serialize_odx_m` entry points and round-trips against the bundled
sample supplement YAML.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from lxml import etree

from udsxml2tex import ArxmlParser
from udsxml2tex.odx import (
    AdminData,
    Audience,
    AudienceGroup,
    CompanyData,
    DocRevision,
    EcuMem,
    EcuState,
    FlashClass,
    Flashdata,
    FlashSession,
    FunctionDictionarySpec,
    FunctionGroup,
    FunctionNode,
    MultipleEcuJob,
    MultipleEcuJobSpec,
    OdxCategory,
    OdxDocument,
    OdxRef,
    ProgCode,
    ProgrammingStep,
    Segment,
    load_supplement,
    map_spec_to_odx,
)
from udsxml2tex.odx.serializers.odx_f import serialize_odx_f, write_odx_f
from udsxml2tex.odx.serializers.odx_fd import serialize_odx_fd, write_odx_fd
from udsxml2tex.odx.serializers.odx_m import serialize_odx_m, write_odx_m

XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"
XSI_TYPE = f"{{{XSI_NS}}}type"

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLES_DIR = (
    Path(__file__).parent.parent / "src" / "udsxml2tex" / "samples"
)
SAMPLE_YAML = SAMPLES_DIR / "odx_supplement_sample.yaml"


def _admin_data() -> AdminData:
    """Build a populated AdminData (language + company + one revision)."""
    return AdminData(
        language="en-US",
        company_doc_infos=[
            CompanyData(
                oid="udsxml2tex.odx.d.company.OEM",
                short_name="OEM",
                long_name="Example OEM",
                roles=["MANUFACTURER"],
            ),
        ],
        doc_revisions=[
            DocRevision(
                revision_label="0.1",
                state="DRAFT",
                date="2026-05-14",
                tool="udsxml2tex",
            ),
        ],
    )


# ---------------------------------------------------------------------------
# 1. ODX-F (Flash) — minimal and basic structure
# ---------------------------------------------------------------------------


class TestOdxFMinimal:
    """Smallest-possible ODX-F documents serialize cleanly."""

    def test_empty_flash_class_emits_minimal_root(self):
        doc = OdxDocument(
            category=OdxCategory.FLASH,
            flash_class=FlashClass(
                oid="udsxml2tex.odx.f.flash.X",
                short_name="X",
            ),
        )
        xml = serialize_odx_f(doc)
        assert isinstance(xml, bytes)
        assert xml.startswith(b"<?xml")
        root = etree.fromstring(xml)
        assert root.tag == "ODX"
        flash = root.find("FLASH")
        assert flash is not None
        assert flash.get("ID") == "udsxml2tex.odx.f.flash.X"
        assert flash.findtext("SHORT-NAME") == "X"

    def test_wrong_category_raises(self):
        doc = OdxDocument(category=OdxCategory.DIAG_LAYER)
        with pytest.raises(ValueError):
            serialize_odx_f(doc)

    def test_missing_flash_class_raises(self):
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=None)
        with pytest.raises(ValueError):
            serialize_odx_f(doc)

    def test_xml_declaration_and_namespace(self):
        doc = OdxDocument(
            category=OdxCategory.FLASH,
            flash_class=FlashClass(short_name="X"),
        )
        xml = serialize_odx_f(doc).decode("utf-8")
        assert "<?xml" in xml
        assert "MODEL-VERSION=\"2.2.0\"" in xml
        assert "xmlns:xsi" in xml


# ---------------------------------------------------------------------------
# 2. ODX-F — single ECU-MEM with sessions and segments
# ---------------------------------------------------------------------------


class TestOdxFEcuMem:
    """ECU-MEM, sessions, segments are placed correctly."""

    def _build_doc(self) -> OdxDocument:
        fc = FlashClass(
            oid="udsxml2tex.odx.f.flash.MainMemory",
            short_name="MainMemory",
            long_name="Primary flash",
            ecu_mems=[
                EcuMem(
                    oid="udsxml2tex.odx.f.ecumem.MainMemory",
                    short_name="MainMemory",
                    long_name="Primary",
                    segments=[
                        Segment(
                            oid="udsxml2tex.odx.f.segment.ApplSeg1",
                            short_name="ApplSeg1",
                            source_start_address=0x100000,
                            source_end_address=0x1FFFFF,
                            target_start_address=0x100000,
                            target_end_address=0x1FFFFF,
                        ),
                    ],
                ),
            ],
            sessions=[
                FlashSession(
                    oid="udsxml2tex.odx.f.fsession.Programming",
                    short_name="ProgrammingSession",
                    security_method="SEED_KEY",
                    expected_idents=["SW_VERSION_X.Y"],
                ),
            ],
        )
        return OdxDocument(
            category=OdxCategory.FLASH,
            flash_class=fc,
        )

    def test_single_session_emitted(self):
        xml = serialize_odx_f(self._build_doc())
        root = etree.fromstring(xml)
        sessions = root.findall("FLASH/SESSIONS/SESSION")
        assert len(sessions) == 1
        assert sessions[0].findtext("SHORT-NAME") == "ProgrammingSession"
        assert sessions[0].findtext("SECURITY-METHOD") == "SEED_KEY"

    def test_expected_idents_listed(self):
        xml = serialize_odx_f(self._build_doc())
        root = etree.fromstring(xml)
        idents = root.findall("FLASH/SESSIONS/SESSION/EXPECTED-IDENTS/EXPECTED-IDENT")
        names = [e.findtext("SHORT-NAME") for e in idents]
        assert names == ["SW_VERSION_X.Y"]

    def test_ecu_mem_emitted(self):
        xml = serialize_odx_f(self._build_doc())
        root = etree.fromstring(xml)
        mems = root.findall("FLASH/ECU-MEMS/ECU-MEM")
        assert len(mems) == 1
        assert mems[0].get("ID") == "udsxml2tex.odx.f.ecumem.MainMemory"
        assert mems[0].findtext("SHORT-NAME") == "MainMemory"

    def test_segment_addresses_present(self):
        xml = serialize_odx_f(self._build_doc())
        root = etree.fromstring(xml)
        seg = root.find("FLASH/ECU-MEMS/ECU-MEM/MEM/DATABLOCKS/DATABLOCK/SEGMENTS/SEGMENT")
        assert seg is not None
        assert seg.findtext("SOURCE-START-ADDRESS") == "1048576"
        assert seg.findtext("SOURCE-END-ADDRESS") == "2097151"
        assert seg.findtext("TARGET-START-ADDRESS") == "1048576"
        assert seg.findtext("TARGET-END-ADDRESS") == "2097151"


# ---------------------------------------------------------------------------
# 3. ODX-F — multiple segments / sessions / flashdatas
# ---------------------------------------------------------------------------


class TestOdxFMultiple:
    """Multi-segment / multi-session / multi-flashdata serialization."""

    def test_multiple_segments(self):
        fc = FlashClass(
            short_name="Multi",
            ecu_mems=[
                EcuMem(
                    short_name="Mem",
                    segments=[
                        Segment(short_name=f"Seg{i}", oid=f"s{i}",
                                source_start_address=i * 0x1000,
                                source_end_address=i * 0x1000 + 0xFFF)
                        for i in range(3)
                    ],
                ),
            ],
        )
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        xml = serialize_odx_f(doc)
        root = etree.fromstring(xml)
        segs = root.findall("FLASH/ECU-MEMS/ECU-MEM/MEM/DATABLOCKS/DATABLOCK/SEGMENTS/SEGMENT")
        assert len(segs) == 3
        assert [s.findtext("SHORT-NAME") for s in segs] == ["Seg0", "Seg1", "Seg2"]

    def test_multiple_sessions(self):
        fc = FlashClass(
            short_name="Multi",
            sessions=[
                FlashSession(short_name="ProgSess", oid="ps", security_method="SEED_KEY"),
                FlashSession(short_name="DiagSess", oid="ds", security_method="NONE"),
            ],
        )
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        xml = serialize_odx_f(doc)
        root = etree.fromstring(xml)
        sessions = root.findall("FLASH/SESSIONS/SESSION")
        assert len(sessions) == 2
        methods = [s.findtext("SECURITY-METHOD") for s in sessions]
        assert methods == ["SEED_KEY", "NONE"]

    def test_multiple_flashdatas_format_ids(self):
        fc = FlashClass(
            short_name="Multi",
            flashdatas=[
                Flashdata(short_name="ApplBinary", oid="fb",
                          format_id="BINARY"),
                Flashdata(short_name="CalIntelHex", oid="fi",
                          format_id="INTEL-HEX"),
                Flashdata(short_name="MotorolaSrec", oid="fm",
                          format_id="MOTOROLA-S"),
            ],
        )
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        xml = serialize_odx_f(doc)
        root = etree.fromstring(xml)
        fds = root.findall("FLASH/FLASHDATAS/FLASHDATA")
        assert len(fds) == 3
        formats = [fd.findtext("DATA-FORMAT") for fd in fds]
        assert formats == ["BINARY", "INTEL-HEX", "MOTOROLA-S"]


# ---------------------------------------------------------------------------
# 4. ODX-F — Flashdata xsi:type discrimination
# ---------------------------------------------------------------------------


class TestOdxFFlashdataXsiType:
    """xsi:type chooses INTERN-FLASHDATA vs EXTERN-FLASHDATA based on datafile."""

    def test_intern_flashdata_default(self):
        fc = FlashClass(
            short_name="X",
            flashdatas=[Flashdata(short_name="Embedded", format_id="BINARY")],
        )
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        root = etree.fromstring(serialize_odx_f(doc))
        fd = root.find("FLASH/FLASHDATAS/FLASHDATA")
        assert fd.get(XSI_TYPE) == "INTERN-FLASHDATA"

    def test_extern_flashdata_when_datafile_set(self):
        fc = FlashClass(
            short_name="X",
            flashdatas=[
                Flashdata(short_name="External",
                          format_id="MOTOROLA-S", datafile="app.s19"),
            ],
        )
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        root = etree.fromstring(serialize_odx_f(doc))
        fd = root.find("FLASH/FLASHDATAS/FLASHDATA")
        assert fd.get(XSI_TYPE) == "EXTERN-FLASHDATA"
        assert fd.findtext("DATAFILE") == "app.s19"


# ---------------------------------------------------------------------------
# 5. ODX-F — segment compression / encrypt-compress method
# ---------------------------------------------------------------------------


class TestOdxFCompression:
    """encrypt_compress_method on segments and flashdata round-trips."""

    def test_segment_compression_method(self):
        fc = FlashClass(
            short_name="X",
            ecu_mems=[EcuMem(short_name="Mem", segments=[
                Segment(short_name="S", source_start_address=0,
                        source_end_address=0xFF,
                        encrypt_compress_method="AES_GZIP"),
            ])],
        )
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        root = etree.fromstring(serialize_odx_f(doc))
        seg = root.find(
            "FLASH/ECU-MEMS/ECU-MEM/MEM/DATABLOCKS/DATABLOCK/SEGMENTS/SEGMENT"
        )
        assert seg.findtext("COMPRESSION-ENCRYPTION-METHOD") == "AES_GZIP"

    def test_flashdata_encrypt_compress_method_set(self):
        fc = FlashClass(
            short_name="X",
            flashdatas=[
                Flashdata(short_name="F", format_id="BINARY",
                          encrypt_compress_method="AES_LZ4"),
            ],
        )
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        root = etree.fromstring(serialize_odx_f(doc))
        fd = root.find("FLASH/FLASHDATAS/FLASHDATA")
        assert fd.findtext("ENCRYPT-COMPRESS-METHOD") == "AES_LZ4"

    def test_flashdata_empty_encrypt_compress_method_emits_element(self):
        fc = FlashClass(
            short_name="X",
            flashdatas=[Flashdata(short_name="F", format_id="BINARY")],
        )
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        root = etree.fromstring(serialize_odx_f(doc))
        fd = root.find("FLASH/FLASHDATAS/FLASHDATA")
        # ODX 2.2.0 schema requires ENCRYPT-COMPRESS-METHOD presence even if empty.
        assert fd.find("ENCRYPT-COMPRESS-METHOD") is not None


# ---------------------------------------------------------------------------
# 6. ODX-F — admin data, company data, SDGs
# ---------------------------------------------------------------------------


class TestOdxFMetadata:
    """ADMIN-DATA / COMPANY-DATAS / SDG handling in ODX-F."""

    def test_admin_data_present(self):
        fc = FlashClass(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.FLASH,
            flash_class=fc,
            admin_data=_admin_data(),
        )
        root = etree.fromstring(serialize_odx_f(doc))
        ad = root.find("FLASH/ADMIN-DATA")
        assert ad is not None
        assert ad.findtext("LANGUAGE") == "en-US"

    def test_admin_data_doc_revisions(self):
        fc = FlashClass(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.FLASH,
            flash_class=fc,
            admin_data=_admin_data(),
        )
        root = etree.fromstring(serialize_odx_f(doc))
        revs = root.findall("FLASH/ADMIN-DATA/DOC-REVISIONS/DOC-REVISION")
        assert len(revs) == 1
        assert revs[0].findtext("REVISION-LABEL") == "0.1"

    def test_company_datas_emitted(self):
        fc = FlashClass(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.FLASH,
            flash_class=fc,
            admin_data=_admin_data(),
        )
        root = etree.fromstring(serialize_odx_f(doc))
        cds = root.findall("FLASH/COMPANY-DATAS/COMPANY-DATA")
        assert len(cds) == 1
        assert cds[0].findtext("SHORT-NAME") == "OEM"

    def test_no_admin_data_no_block(self):
        fc = FlashClass(short_name="X")
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        root = etree.fromstring(serialize_odx_f(doc))
        assert root.find("FLASH/ADMIN-DATA") is None
        assert root.find("FLASH/COMPANY-DATAS") is None


# ---------------------------------------------------------------------------
# 7. ODX-F — write_odx_f to disk
# ---------------------------------------------------------------------------


class TestOdxFFileWrite:
    """write_odx_f produces a readable .odx-f file."""

    def test_write_creates_parent_dirs(self, tmp_path):
        fc = FlashClass(short_name="X")
        doc = OdxDocument(category=OdxCategory.FLASH, flash_class=fc)
        target = tmp_path / "nested" / "out.odx-f"
        ret = write_odx_f(doc, target)
        assert ret == target
        assert target.exists()
        assert target.read_bytes().startswith(b"<?xml")


# ---------------------------------------------------------------------------
# 8. ODX-FD (Function Dictionary)
# ---------------------------------------------------------------------------


class TestOdxFdMinimal:
    """Smallest-possible ODX-FD documents serialize cleanly."""

    def test_empty_spec_emits_minimal_root(self):
        doc = OdxDocument(
            category=OdxCategory.FUNCTION_DICTIONARY,
            function_dictionary_spec=FunctionDictionarySpec(
                oid="udsxml2tex.odx.fd.spec.X",
                short_name="X",
            ),
        )
        xml = serialize_odx_fd(doc)
        root = etree.fromstring(xml)
        spec = root.find("FUNCTION-DICTIONARY-SPEC")
        assert spec is not None
        assert spec.get("ID") == "udsxml2tex.odx.fd.spec.X"
        assert spec.findtext("SHORT-NAME") == "X"

    def test_wrong_category_raises(self):
        doc = OdxDocument(category=OdxCategory.DIAG_LAYER)
        with pytest.raises(ValueError):
            serialize_odx_fd(doc)

    def test_missing_spec_raises(self):
        doc = OdxDocument(
            category=OdxCategory.FUNCTION_DICTIONARY,
            function_dictionary_spec=None,
        )
        with pytest.raises(ValueError):
            serialize_odx_fd(doc)


# ---------------------------------------------------------------------------
# 9. ODX-FD — function groups and nodes
# ---------------------------------------------------------------------------


class TestOdxFdGroups:
    """FUNCTION-GROUPS and FUNCTION-NODES emitted correctly."""

    def _build_doc(self) -> OdxDocument:
        spec = FunctionDictionarySpec(
            short_name="Powertrain",
            function_groups=[
                FunctionGroup(
                    oid="udsxml2tex.odx.fd.fgroup.Engine",
                    short_name="Engine",
                    function_nodes=[
                        FunctionNode(
                            oid="udsxml2tex.odx.fd.fnode.EngineECU",
                            short_name="EngineECU",
                            service_refs=[
                                OdxRef(id_ref="udsxml2tex.odx.d.service.RDBI_F190"),
                            ],
                        ),
                    ],
                ),
                FunctionGroup(
                    short_name="Chassis",
                    function_nodes=[
                        FunctionNode(short_name="BrakeECU"),
                        FunctionNode(short_name="SteeringECU"),
                    ],
                ),
            ],
        )
        return OdxDocument(
            category=OdxCategory.FUNCTION_DICTIONARY,
            function_dictionary_spec=spec,
        )

    def test_groups_emitted(self):
        xml = serialize_odx_fd(self._build_doc())
        root = etree.fromstring(xml)
        groups = root.findall("FUNCTION-DICTIONARY-SPEC/FUNCTION-GROUPS/FUNCTION-GROUP")
        assert len(groups) == 2
        names = [g.findtext("SHORT-NAME") for g in groups]
        assert names == ["Engine", "Chassis"]

    def test_multiple_function_nodes(self):
        xml = serialize_odx_fd(self._build_doc())
        root = etree.fromstring(xml)
        nodes = root.findall(
            "FUNCTION-DICTIONARY-SPEC/FUNCTION-GROUPS/FUNCTION-GROUP/"
            "FUNCTION-NODES/FUNCTION-NODE"
        )
        assert len(nodes) == 3
        names = [n.findtext("SHORT-NAME") for n in nodes]
        assert "EngineECU" in names
        assert "BrakeECU" in names

    def test_function_node_diag_comm_ref(self):
        xml = serialize_odx_fd(self._build_doc())
        root = etree.fromstring(xml)
        refs = root.findall(
            "FUNCTION-DICTIONARY-SPEC/FUNCTION-GROUPS/FUNCTION-GROUP/"
            "FUNCTION-NODES/FUNCTION-NODE/DIAG-COMM-REFS/DIAG-COMM-REF"
        )
        assert len(refs) == 1
        assert refs[0].get("ID-REF") == "udsxml2tex.odx.d.service.RDBI_F190"


# ---------------------------------------------------------------------------
# 10. ODX-FD — audience groups
# ---------------------------------------------------------------------------


class TestOdxFdAudienceGroups:
    """AUDIENCE-GROUPS block emitted when populated."""

    def test_audience_group(self):
        spec = FunctionDictionarySpec(
            short_name="X",
            audience_groups=[
                AudienceGroup(
                    oid="udsxml2tex.odx.fd.aud.G1",
                    short_name="DevGroup",
                    audiences=[Audience(is_development=True, is_aftersales=False)],
                ),
            ],
        )
        doc = OdxDocument(
            category=OdxCategory.FUNCTION_DICTIONARY,
            function_dictionary_spec=spec,
        )
        root = etree.fromstring(serialize_odx_fd(doc))
        ag = root.find("FUNCTION-DICTIONARY-SPEC/AUDIENCE-GROUPS/AUDIENCE-GROUP")
        assert ag is not None
        aud = ag.find("AUDIENCES/AUDIENCE")
        assert aud is not None
        assert aud.get("IS-DEVELOPMENT") == "true"
        assert aud.get("IS-AFTERSALES") == "false"


# ---------------------------------------------------------------------------
# 11. ODX-FD — metadata (admin/company/SDGs)
# ---------------------------------------------------------------------------


class TestOdxFdMetadata:
    """ADMIN-DATA / COMPANY-DATAS appear at the spec level."""

    def test_admin_data_in_fd(self):
        spec = FunctionDictionarySpec(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.FUNCTION_DICTIONARY,
            function_dictionary_spec=spec,
            admin_data=_admin_data(),
        )
        root = etree.fromstring(serialize_odx_fd(doc))
        ad = root.find("FUNCTION-DICTIONARY-SPEC/ADMIN-DATA")
        assert ad is not None
        assert ad.findtext("LANGUAGE") == "en-US"

    def test_company_datas_in_fd(self):
        spec = FunctionDictionarySpec(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.FUNCTION_DICTIONARY,
            function_dictionary_spec=spec,
            admin_data=_admin_data(),
        )
        root = etree.fromstring(serialize_odx_fd(doc))
        cds = root.findall("FUNCTION-DICTIONARY-SPEC/COMPANY-DATAS/COMPANY-DATA")
        assert len(cds) == 1


# ---------------------------------------------------------------------------
# 12. ODX-FD — write_odx_fd
# ---------------------------------------------------------------------------


class TestOdxFdFileWrite:
    """write_odx_fd produces a readable .odx-fd file."""

    def test_write_creates_file(self, tmp_path):
        spec = FunctionDictionarySpec(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.FUNCTION_DICTIONARY,
            function_dictionary_spec=spec,
        )
        target = tmp_path / "out.odx-fd"
        ret = write_odx_fd(doc, target)
        assert ret == target
        assert target.exists()
        assert b"FUNCTION-DICTIONARY-SPEC" in target.read_bytes()


# ---------------------------------------------------------------------------
# 13. ODX-M (Multiple ECU Job)
# ---------------------------------------------------------------------------


class TestOdxMMinimal:
    """Smallest-possible ODX-M documents serialize cleanly."""

    def test_empty_spec_emits_minimal_root(self):
        doc = OdxDocument(
            category=OdxCategory.MULTIPLE_ECU_JOB_SPEC,
            multiple_ecu_job_spec=MultipleEcuJobSpec(
                oid="udsxml2tex.odx.m.spec.X",
                short_name="X",
            ),
        )
        xml = serialize_odx_m(doc)
        root = etree.fromstring(xml)
        spec = root.find("MULTIPLE-ECU-JOB-SPEC")
        assert spec is not None
        assert spec.get("ID") == "udsxml2tex.odx.m.spec.X"
        assert spec.findtext("SHORT-NAME") == "X"

    def test_wrong_category_raises(self):
        doc = OdxDocument(category=OdxCategory.DIAG_LAYER)
        with pytest.raises(ValueError):
            serialize_odx_m(doc)

    def test_missing_spec_raises(self):
        doc = OdxDocument(
            category=OdxCategory.MULTIPLE_ECU_JOB_SPEC,
            multiple_ecu_job_spec=None,
        )
        with pytest.raises(ValueError):
            serialize_odx_m(doc)


# ---------------------------------------------------------------------------
# 14. ODX-M — jobs, steps and prog codes
# ---------------------------------------------------------------------------


class TestOdxMJobs:
    """MULTIPLE-ECU-JOBS, PROGRAMMING-STEPS and PROG-CODES emit correctly."""

    def _build_doc(self) -> OdxDocument:
        spec = MultipleEcuJobSpec(
            short_name="SystemFlash",
            ecu_states=[
                EcuState(
                    oid="udsxml2tex.odx.m.state.Prog",
                    short_name="ProgrammingMode",
                ),
            ],
            multiple_ecu_jobs=[
                MultipleEcuJob(
                    oid="udsxml2tex.odx.m.job.FlashAll",
                    short_name="FlashAllEcus",
                    programming_steps=[
                        ProgrammingStep(
                            oid="udsxml2tex.odx.m.step.S1",
                            short_name="Step1",
                            prog_code_ref=OdxRef(id_ref="udsxml2tex.odx.m.code.C1"),
                        ),
                        ProgrammingStep(
                            oid="udsxml2tex.odx.m.step.S2",
                            short_name="Step2",
                            target_ecu_refs=[
                                OdxRef(id_ref="udsxml2tex.odx.d.ecu.A"),
                                OdxRef(id_ref="udsxml2tex.odx.d.ecu.B"),
                            ],
                        ),
                    ],
                ),
            ],
            prog_codes=[
                ProgCode(
                    oid="udsxml2tex.odx.m.code.C1",
                    short_name="C1",
                    syntax="JAVA",
                    code_file="job.jar",
                ),
            ],
        )
        return OdxDocument(
            category=OdxCategory.MULTIPLE_ECU_JOB_SPEC,
            multiple_ecu_job_spec=spec,
        )

    def test_ecu_states_emitted(self):
        xml = serialize_odx_m(self._build_doc())
        root = etree.fromstring(xml)
        states = root.findall("MULTIPLE-ECU-JOB-SPEC/ECU-STATES/ECU-STATE")
        assert len(states) == 1
        assert states[0].findtext("SHORT-NAME") == "ProgrammingMode"

    def test_multiple_programming_steps(self):
        xml = serialize_odx_m(self._build_doc())
        root = etree.fromstring(xml)
        steps = root.findall(
            "MULTIPLE-ECU-JOB-SPEC/MULTIPLE-ECU-JOBS/MULTIPLE-ECU-JOB/"
            "PROGRAMMING-STEPS/PROGRAMMING-STEP"
        )
        assert len(steps) == 2
        assert [s.findtext("SHORT-NAME") for s in steps] == ["Step1", "Step2"]

    def test_step_prog_code_ref(self):
        xml = serialize_odx_m(self._build_doc())
        root = etree.fromstring(xml)
        refs = root.findall(
            "MULTIPLE-ECU-JOB-SPEC/MULTIPLE-ECU-JOBS/MULTIPLE-ECU-JOB/"
            "PROGRAMMING-STEPS/PROGRAMMING-STEP/PROG-CODE-REF"
        )
        assert len(refs) == 1
        assert refs[0].get("ID-REF") == "udsxml2tex.odx.m.code.C1"

    def test_step_target_ecu_refs(self):
        xml = serialize_odx_m(self._build_doc())
        root = etree.fromstring(xml)
        refs = root.findall(
            "MULTIPLE-ECU-JOB-SPEC/MULTIPLE-ECU-JOBS/MULTIPLE-ECU-JOB/"
            "PROGRAMMING-STEPS/PROGRAMMING-STEP/TARGET-ECU-REFS/TARGET-ECU-REF"
        )
        assert len(refs) == 2
        assert {r.get("ID-REF") for r in refs} == {
            "udsxml2tex.odx.d.ecu.A",
            "udsxml2tex.odx.d.ecu.B",
        }

    def test_prog_codes_emitted(self):
        xml = serialize_odx_m(self._build_doc())
        root = etree.fromstring(xml)
        codes = root.findall("MULTIPLE-ECU-JOB-SPEC/PROG-CODES/PROG-CODE")
        assert len(codes) == 1
        assert codes[0].findtext("SHORT-NAME") == "C1"
        assert codes[0].findtext("SYNTAX") == "JAVA"
        assert codes[0].findtext("CODE-FILE") == "job.jar"


# ---------------------------------------------------------------------------
# 15. ODX-M — admin / company data
# ---------------------------------------------------------------------------


class TestOdxMMetadata:
    """ADMIN-DATA / COMPANY-DATAS in ODX-M."""

    def test_admin_data_in_m(self):
        spec = MultipleEcuJobSpec(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.MULTIPLE_ECU_JOB_SPEC,
            multiple_ecu_job_spec=spec,
            admin_data=_admin_data(),
        )
        root = etree.fromstring(serialize_odx_m(doc))
        ad = root.find("MULTIPLE-ECU-JOB-SPEC/ADMIN-DATA")
        assert ad is not None
        assert ad.findtext("LANGUAGE") == "en-US"

    def test_company_datas_in_m(self):
        spec = MultipleEcuJobSpec(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.MULTIPLE_ECU_JOB_SPEC,
            multiple_ecu_job_spec=spec,
            admin_data=_admin_data(),
        )
        root = etree.fromstring(serialize_odx_m(doc))
        cds = root.findall("MULTIPLE-ECU-JOB-SPEC/COMPANY-DATAS/COMPANY-DATA")
        assert len(cds) == 1
        assert cds[0].findtext("SHORT-NAME") == "OEM"


# ---------------------------------------------------------------------------
# 16. ODX-M — write_odx_m
# ---------------------------------------------------------------------------


class TestOdxMFileWrite:
    """write_odx_m produces a readable .odx-m file."""

    def test_write_creates_file(self, tmp_path):
        spec = MultipleEcuJobSpec(short_name="X")
        doc = OdxDocument(
            category=OdxCategory.MULTIPLE_ECU_JOB_SPEC,
            multiple_ecu_job_spec=spec,
        )
        target = tmp_path / "out.odx-m"
        ret = write_odx_m(doc, target)
        assert ret == target
        assert target.exists()
        assert b"MULTIPLE-ECU-JOB-SPEC" in target.read_bytes()


# ---------------------------------------------------------------------------
# 17. Supplement-driven Flash (load YAML → mapper → serializer)
# ---------------------------------------------------------------------------


pytest.importorskip("yaml")


class TestOdxFFromSupplement:
    """End-to-end: sample YAML supplement maps and serializes to ODX-F."""

    def test_supplement_flash_serializes(self):
        sup = load_supplement(SAMPLE_YAML)
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec, sup)
        odx_f_docs = [d for d in docs.values() if d.category == OdxCategory.FLASH]
        assert odx_f_docs, "expected supplement to produce an ODX-F doc"
        xml = serialize_odx_f(odx_f_docs[0])
        assert b"<FLASH" in xml
        root = etree.fromstring(xml)
        segs = root.findall(
            "FLASH/ECU-MEMS/ECU-MEM/MEM/DATABLOCKS/DATABLOCK/SEGMENTS/SEGMENT"
        )
        # The sample YAML contains two segments (ApplSeg1, CalSeg1).
        assert len(segs) >= 2
        seg_names = {s.findtext("SHORT-NAME") for s in segs}
        assert "ApplSeg1" in seg_names

    def test_supplement_flash_session_security_method(self):
        sup = load_supplement(SAMPLE_YAML)
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec, sup)
        odx_f = next(d for d in docs.values() if d.category == OdxCategory.FLASH)
        root = etree.fromstring(serialize_odx_f(odx_f))
        sess = root.find("FLASH/SESSIONS/SESSION")
        assert sess is not None
        assert sess.findtext("SECURITY-METHOD") == "SEED_KEY"


# ---------------------------------------------------------------------------
# 18. Supplement-driven FunctionDictionary
# ---------------------------------------------------------------------------


class TestOdxFdFromSupplement:
    """End-to-end: sample YAML supplement maps and serializes to ODX-FD."""

    def test_supplement_fd_serializes(self):
        sup = load_supplement(SAMPLE_YAML)
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec, sup)
        odx_fd_docs = [
            d for d in docs.values() if d.category == OdxCategory.FUNCTION_DICTIONARY
        ]
        assert odx_fd_docs, "expected supplement to produce an ODX-FD doc"
        xml = serialize_odx_fd(odx_fd_docs[0])
        root = etree.fromstring(xml)
        groups = root.findall(
            "FUNCTION-DICTIONARY-SPEC/FUNCTION-GROUPS/FUNCTION-GROUP"
        )
        assert len(groups) >= 2  # Powertrain + Chassis
        names = {g.findtext("SHORT-NAME") for g in groups}
        assert "Powertrain" in names
        assert "Chassis" in names

    def test_supplement_fd_function_nodes_per_ecu(self):
        sup = load_supplement(SAMPLE_YAML)
        spec = ArxmlParser().parse(SAMPLE_ARXML)
        docs = map_spec_to_odx(spec, sup)
        odx_fd = next(
            d for d in docs.values() if d.category == OdxCategory.FUNCTION_DICTIONARY
        )
        root = etree.fromstring(serialize_odx_fd(odx_fd))
        nodes = root.findall(
            "FUNCTION-DICTIONARY-SPEC/FUNCTION-GROUPS/FUNCTION-GROUP/"
            "FUNCTION-NODES/FUNCTION-NODE"
        )
        # Powertrain has 2 ECUs + Chassis has 2 ECUs = 4 nodes.
        assert len(nodes) == 4
