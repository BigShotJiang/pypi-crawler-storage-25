import os
import pytest
from tinfoil import SecureClient

API_KEY = os.getenv("TINFOIL_API_KEY", "tinfoil")

pytestmark = pytest.mark.integration

@pytest.fixture(scope="session")
def client() -> SecureClient:
    return SecureClient()

def test_doc_upload(client):
    """Test synchronous doc upload."""
    httpx_client = client.make_secure_http_client()

    with open("tests/dummy.pdf", "rb") as file:
        response = httpx_client.post(
            f"https://{client.enclave}/v1/convert/file",
            files={'files': file},
            headers={"Authorization": f"Bearer {API_KEY}"},
            timeout=30,
        )
        assert response.status_code == 200
        assert response.json()["status"] == "success"

@pytest.mark.asyncio
async def test_doc_upload_async(client):
    """Test asynchronous doc upload."""
    httpx_client = client.make_secure_async_http_client()

    with open("tests/dummy.pdf", "rb") as file:
        response = await httpx_client.post(
            f"https://{client.enclave}/v1/convert/file",
            files={'files': file},
            headers={"Authorization": f"Bearer {API_KEY}"},
            timeout=30,
        )
        assert response.status_code == 200
        assert response.json()["status"] == "success"
