from typing import Optional
from openai import OpenAI, AsyncOpenAI, NOT_GIVEN, NotGiven
from openai.resources.chat import Chat as OpenAIChat
from openai.resources.embeddings import Embeddings as OpenAIEmbeddings
from openai.resources.audio import Audio as OpenAIAudio
import httpx

from .client import SecureClient, VerificationDocument, get_router_address

class TinfoilAI:
    chat: OpenAIChat
    embeddings: OpenAIEmbeddings
    audio: OpenAIAudio
    api_key: str
    enclave: str

    def __init__(
        self,
        enclave: str = "",
        repo: str = "tinfoilsh/confidential-model-router",
        api_key: str = "tinfoil",
        measurement: Optional[dict] = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ):
        if measurement is not None:
            repo = ""
        
        # Ensure at least one verification method is provided
        if measurement is None and (repo == "" or repo is None):
            raise ValueError("Must provide either 'measurement' or 'repo' parameter for verification.")
        
        # If enclave is empty, fetch a random one from the routers API
        if enclave == "" or enclave is None:
            enclave = get_router_address()
        
        self.enclave = enclave
        self.api_key = api_key
        self._secure_client = SecureClient(enclave, repo, measurement)
        secure_http = self._secure_client.make_secure_http_client()
        self.client = OpenAI(
            base_url=f"https://{enclave}/v1/",
            api_key=api_key,
            timeout=timeout,
            http_client=secure_http,
        )
        self.chat = self.client.chat
        self.embeddings = self.client.embeddings
        self.audio = self.client.audio

    def get_verification_document(self) -> Optional[VerificationDocument]:
        """Returns the detailed verification document with per-step status"""
        return self._secure_client.get_verification_document()

class AsyncTinfoilAI:
    """
    Exactly like TinfoilAI, but fully async using AsyncOpenAI and httpx.AsyncClient.
    """
    chat: OpenAIChat
    embeddings: OpenAIEmbeddings
    audio: OpenAIAudio
    api_key: str
    enclave: str

    def __init__(
        self,
        enclave: str = "",
        repo: str = "tinfoilsh/confidential-model-router",
        api_key: str = "tinfoil",
        measurement: Optional[dict] = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ):
        if measurement is not None:
            repo = ""
        
        # Ensure at least one verification method is provided
        if measurement is None and (repo == "" or repo is None):
            raise ValueError("Must provide either 'measurement' or 'repo' parameter for verification.")
        
        # If enclave is empty, fetch a random one from the routers API
        if enclave == "" or enclave is None:
            enclave = get_router_address()
        
        self.enclave = enclave
        self.api_key = api_key
        # verifier client remains sync; only used to fetch the expected public key
        self._secure_client = SecureClient(enclave, repo, measurement)
        async_http = self._secure_client.make_secure_async_http_client()
        self.client = AsyncOpenAI(
            base_url=f"https://{enclave}/v1/",
            api_key=api_key,
            timeout=timeout,
            http_client=async_http,
        )
        self.chat = self.client.chat
        self.embeddings = self.client.embeddings
        self.audio = self.client.audio

    def get_verification_document(self) -> Optional[VerificationDocument]:
        """Returns the detailed verification document with per-step status"""
        return self._secure_client.get_verification_document()

class _HTTPSecureClient:
    """Low-level HTTP client with enclave-pinned TLS."""
    def __init__(self, enclave: str, tf_client: SecureClient):
        self.enclave = enclave
        self._tf_client = tf_client
        self._http_client = tf_client.make_secure_http_client()

    def get(self, url: str, headers: Optional[dict] = None, params: Optional[dict] = None, timeout: Optional[int] = None) -> httpx.Response:
        return self._http_client.get(url, headers=headers, params=params, timeout=timeout)

    def post(
        self,
        url: str,
        headers: Optional[dict] = None,
        data: Optional[dict] = None,
        json: Optional[dict] = None,
        timeout: Optional[int] = None,
    ) -> httpx.Response:
        return self._http_client.post(url, headers=headers, data=data, json=json, timeout=timeout)


def NewSecureClient(enclave: str = "", repo: str = "tinfoilsh/confidential-model-router", measurement: Optional[dict] = None):
    """Create a secure HTTP client for direct GET/POST through the Tinfoil enclave."""
    if measurement is not None:
        repo = ""

    # Ensure at least one verification method is provided
    if measurement is None and (repo == "" or repo is None):
        raise ValueError("Must provide either 'measurement' or 'repo' parameter for verification.")

    # If enclave is empty, fetch a random one from the routers API
    if enclave == "" or enclave is None:
        enclave = get_router_address()

    tf_client = SecureClient(enclave, repo, measurement)
    return _HTTPSecureClient(enclave, tf_client)

__all__ = ["TinfoilAI", "AsyncTinfoilAI", "NewSecureClient", "SecureClient", "VerificationDocument"]
