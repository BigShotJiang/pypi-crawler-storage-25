"""Feedback API endpoint."""

from typing import Annotated

from fastapi import APIRouter, Depends

from daimyo.application.error_handling import ErrorMapper
from daimyo.application.feedback import FeedbackService
from daimyo.infrastructure.logging import get_logger
from daimyo.presentation.rest.dependencies import get_feedback_service
from daimyo.presentation.rest.models import (
    ErrorResponse,
    FeedbackRequest,
)

logger = get_logger(__name__)

router = APIRouter(prefix="/api/v1/feedback", tags=["feedback"])


@router.post(
    "",
    status_code=201,
    response_model=dict[str, str],
    responses={
        201: {
            "description": "Feedback submitted successfully",
            "content": {"application/json": {"example": {"status": "ok"}}},
        },
        422: {"description": "Validation error"},
        500: {"model": ErrorResponse},
    },
    summary="Submit feedback about daimyo rules",
    description=(
        "Submit feedback about contradictory rules or missed categories. "
        "Feedback is appended to the configured JSONL file."
    ),
)
async def submit_feedback(
    body: FeedbackRequest,
    feedback_service: Annotated[FeedbackService, Depends(get_feedback_service)],
) -> dict[str, str]:
    """Submit a feedback entry.

    :param body: Feedback payload (discriminated by ``type`` field).
    :type body: FeedbackRequest
    :param feedback_service: Feedback service from DI container.
    :type feedback_service: FeedbackService
    :returns: Status confirmation.
    :rtype: dict[str, str]
    """
    try:
        logger.info(f"POST /api/v1/feedback type={body.type}")
        feedback_service.submit(body.type, body.model_dump(exclude={"type"}))
        return {"status": "ok"}
    except Exception as exc:
        raise ErrorMapper.map_to_http_exception(exc, context="submit_feedback")


__all__ = ["router"]
