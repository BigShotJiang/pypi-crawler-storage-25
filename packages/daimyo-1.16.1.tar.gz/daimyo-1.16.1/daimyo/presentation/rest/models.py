"""Pydantic models for REST API requests and responses."""

from typing import Annotated, Literal

from pydantic import BaseModel, Field


class CategorySummary(BaseModel):
    """Summary of a category for index endpoint."""

    category: str = Field(..., description="Category key (e.g., 'python.web.testing')")
    when: str | None = Field(None, description="Applicability description")
    rule_count: int = Field(..., description="Number of rules in this category")
    tags: list[str] = Field(default_factory=list, description="Tags associated with this category")

    model_config = {
        "json_schema_extra": {
            "example": {
                "category": "python.web.testing",
                "when": "When testing web interfaces implemented in Python",
                "rule_count": 5,
                "tags": ["python", "testing", "web"],
            }
        }
    }


class IndexResponse(BaseModel):
    """Response for /index endpoint."""

    scope_name: str = Field(..., description="Name of the scope")
    description: str = Field(..., description="Scope description")
    commandments: list[CategorySummary] = Field(
        ..., description="Summary of commandment categories"
    )
    suggestions: list[CategorySummary] = Field(..., description="Summary of suggestion categories")
    sources: list[str] = Field(..., description="Sources that contributed to this scope")

    model_config = {
        "json_schema_extra": {
            "example": {
                "scope_name": "team-backend",
                "description": "Backend team specific rules",
                "commandments": [
                    {
                        "category": "python.web.api",
                        "when": "When building REST APIs",
                        "rule_count": 4,
                    }
                ],
                "suggestions": [
                    {
                        "category": "python.web.api",
                        "when": "When building REST APIs",
                        "rule_count": 3,
                    }
                ],
                "sources": ["local"],
            }
        }
    }


class KataSummary(BaseModel):
    """Summary of a kata category for index endpoint."""

    category: str = Field(..., description="Category key (e.g., 'python.web.testing')")
    when: str | None = Field(None, description="Applicability description")
    kata_count: int = Field(..., description="Number of katas in this category")


class KataIndexResponse(BaseModel):
    """Response for /katas/index endpoint."""

    scope_name: str = Field(..., description="Name of the scope")
    description: str = Field(..., description="Scope description")
    categories: list[KataSummary] = Field(..., description="Summary of kata categories")
    sources: list[str] = Field(..., description="Sources that contributed to this scope")


class KataItem(BaseModel):
    """Brief information about a kata."""

    name: str = Field(..., description="Name of the kata")
    category: str = Field(..., description="Category key the kata belongs to")


class KataListResponse(BaseModel):
    """Response for /katas list endpoint."""

    scope_name: str = Field(..., description="Name of the scope")
    katas: list[KataItem] = Field(..., description="List of available katas")


class ErrorResponse(BaseModel):
    """Error response model."""

    detail: str = Field(..., description="Error message")

    model_config = {"json_schema_extra": {"example": {"detail": "Scope 'invalid' not found"}}}


class ContradictoryRuleItem(BaseModel):
    """A single rule involved in a contradiction.

    :param category: Category key the rule belongs to.
    :param rule: Full rule text.
    """

    category: str = Field(..., min_length=2, description="Category key (e.g. 'python.testing')")
    rule: str = Field(..., min_length=2, description="Rule text")


class ContradictoryRulesFeedback(BaseModel):
    """Feedback payload for contradictory rules.

    :param type: Discriminator — must be ``contradictory_rules``.
    :param task: Description of the work being done when the contradiction was found.
    :param rules: Two or more contradicting rules with their categories.
    """

    type: Literal["contradictory_rules"]
    task: str = Field(..., min_length=10, description="Work being done when contradiction found")
    rules: list[ContradictoryRuleItem] = Field(
        ..., min_length=1, description="Contradicting rules"
    )


class MissedCategoriesFeedback(BaseModel):
    """Feedback payload for missed categories.

    :param type: Discriminator — must be ``missed_categories``.
    :param task: Description of the task.
    :param categories: Category names that were missed.
    :param reason: Why the categories were not fetched initially.
    """

    type: Literal["missed_categories"]
    task: str = Field(..., min_length=10, description="What the task was about")
    categories: list[str] = Field(..., min_length=1, description="Missed category names")
    reason: str = Field(
        ..., min_length=10, description="Why the categories were not initially fetched"
    )


FeedbackRequest = Annotated[
    ContradictoryRulesFeedback | MissedCategoriesFeedback,
    Field(discriminator="type"),
]


__all__ = [
    "CategorySummary",
    "IndexResponse",
    "KataSummary",
    "KataIndexResponse",
    "KataItem",
    "KataListResponse",
    "ErrorResponse",
    "ContradictoryRuleItem",
    "ContradictoryRulesFeedback",
    "MissedCategoriesFeedback",
    "FeedbackRequest",
]
