"""Feedback service for writing user feedback to a JSONL file."""

import json
from datetime import datetime, timezone
from pathlib import Path

from daimyo.domain.exceptions import FeedbackWriteError
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)


class FeedbackService:
    """Appends structured feedback entries to a JSON Lines file.

    :param feedback_file: Path to the JSONL file where feedback is written.
    :type feedback_file: str
    """

    def __init__(self, feedback_file: str) -> None:
        """Initialise the service.

        :param feedback_file: Path to the JSONL feedback file.
        :type feedback_file: str
        """
        self._feedback_file = feedback_file

    def submit(self, feedback_type: str, payload: dict) -> None:
        """Append a feedback entry to the JSONL file.

        :param feedback_type: Feedback type identifier (e.g. ``contradictory_rules``).
        :type feedback_type: str
        :param payload: Type-specific fields to include in the entry.
        :type payload: dict
        :raises FeedbackWriteError: If the file cannot be written.
        """
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": feedback_type,
            **payload,
        }
        try:
            path = Path(self._feedback_file)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry) + "\n")
        except OSError as exc:
            raise FeedbackWriteError(f"Failed to write feedback: {exc}") from exc

        logger.info(f"Feedback submitted: type={feedback_type}, file={self._feedback_file}")


__all__ = ["FeedbackService"]
