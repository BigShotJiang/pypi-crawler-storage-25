"""Integration tests for the feedback REST endpoint."""

from __future__ import annotations

from unittest.mock import Mock

import pytest
from fastapi.testclient import TestClient

from daimyo.application.feedback import FeedbackService, FeedbackWriteError
from daimyo.presentation.rest.app import app
from daimyo.presentation.rest.dependencies import get_feedback_service


@pytest.fixture
def mock_feedback_service():
    """Mock FeedbackService for endpoint tests."""
    return Mock(spec=FeedbackService)


@pytest.fixture
def client(mock_feedback_service):
    """TestClient with overridden feedback dependency."""
    app.dependency_overrides[get_feedback_service] = lambda: mock_feedback_service
    yield TestClient(app)
    app.dependency_overrides.pop(get_feedback_service, None)


class TestFeedbackEndpoint:
    """Tests for POST /api/v1/feedback."""

    def test_contradictory_rules_returns_201(self, client, mock_feedback_service):
        """Valid contradictory_rules payload returns 201 with status ok."""
        response = client.post(
            "/api/v1/feedback",
            json={
                "type": "contradictory_rules",
                "task": "Writing integration tests for the REST endpoint",
                "rules": [
                    {"category": "python.testing", "rule": "Use pytest"},
                    {"category": "development.coding.testing", "rule": "Avoid mocking internals"},
                ],
            },
        )
        assert response.status_code == 201
        assert response.json() == {"status": "ok"}
        mock_feedback_service.submit.assert_called_once()

    def test_missed_categories_returns_201(self, client, mock_feedback_service):
        """Valid missed_categories payload returns 201."""
        response = client.post(
            "/api/v1/feedback",
            json={
                "type": "missed_categories",
                "task": "Adding a REST endpoint for rule feedback",
                "categories": ["development.domain_specific.apis.rest"],
                "reason": "Initially focused on Python rules and overlooked REST API category",
            },
        )
        assert response.status_code == 201
        assert response.json()["status"] == "ok"

    def test_missing_type_returns_422(self, client):
        """Missing discriminator field returns 422."""
        response = client.post(
            "/api/v1/feedback",
            json={"task": "Some task long enough", "categories": ["a.b"]},
        )
        assert response.status_code == 422

    @pytest.mark.parametrize(
        "payload",
        [
            {
                "type": "contradictory_rules",
                "task": "Valid task text here",
                "rules": [],
            },
            {
                "type": "contradictory_rules",
                "task": "Short",
                "rules": [{"category": "a.b", "rule": "some rule"}],
            },
            {
                "type": "missed_categories",
                "task": "Valid task text here",
                "categories": [],
                "reason": "Valid reason text here",
            },
        ],
    )
    def test_invalid_payload_returns_422(self, client, payload):
        """Invalid payload fields return 422."""
        response = client.post("/api/v1/feedback", json=payload)
        assert response.status_code == 422

    def test_unknown_type_returns_422(self, client):
        """Unknown type value returns 422."""
        response = client.post(
            "/api/v1/feedback",
            json={"type": "unknown_type", "task": "Some task long enough", "data": {}},
        )
        assert response.status_code == 422

    def test_feedback_write_error_returns_500(self, client, mock_feedback_service):
        """FeedbackWriteError from service results in 500."""
        mock_feedback_service.submit.side_effect = FeedbackWriteError("disk full")

        response = client.post(
            "/api/v1/feedback",
            json={
                "type": "missed_categories",
                "task": "Task description long enough",
                "categories": ["a.b"],
                "reason": "Reason description long enough",
            },
        )
        assert response.status_code == 500
