"""Integration tests for the submit_feedback MCP tool."""

from __future__ import annotations

import json
from unittest.mock import patch

from daimyo.presentation.mcp import server


class TestSubmitFeedbackMCPTool:
    """Tests for the submit_feedback MCP tool function."""

    @patch("daimyo.presentation.mcp.server._feedback_service")
    def test_contradictory_rules_success(self, mock_service):
        """Valid contradictory_rules call returns success message."""
        rules = [{"category": "python.testing", "rule": "Use pytest"}]
        result = server.submit_feedback(
            type="contradictory_rules",
            task="Writing integration tests",
            rules_json=json.dumps(rules),
        )
        assert result == "Feedback submitted successfully."
        mock_service.submit.assert_called_once_with(
            "contradictory_rules",
            {"task": "Writing integration tests", "rules": rules},
        )

    @patch("daimyo.presentation.mcp.server._feedback_service")
    def test_missed_categories_success(self, mock_service):
        """Valid missed_categories call returns success message."""
        result = server.submit_feedback(
            type="missed_categories",
            task="Adding REST endpoint",
            categories="development.domain_specific.apis.rest, python.web",
            reason="Focused on Python rules initially",
        )
        assert result == "Feedback submitted successfully."
        mock_service.submit.assert_called_once_with(
            "missed_categories",
            {
                "task": "Adding REST endpoint",
                "categories": [
                    "development.domain_specific.apis.rest",
                    "python.web",
                ],
                "reason": "Focused on Python rules initially",
            },
        )

    @patch("daimyo.presentation.mcp.server._feedback_service")
    def test_unknown_type_returns_error(self, mock_service):
        """Unknown type value returns an error string without calling service."""
        result = server.submit_feedback(type="bad_type", task="Some task")
        assert result.startswith("Error:")
        mock_service.submit.assert_not_called()

    @patch("daimyo.presentation.mcp.server._feedback_service")
    def test_malformed_rules_json_returns_error(self, mock_service):
        """Malformed rules_json returns an error string without calling service."""
        result = server.submit_feedback(
            type="contradictory_rules",
            task="Some task",
            rules_json="not valid json{",
        )
        assert result.startswith("Error:")
        mock_service.submit.assert_not_called()

    @patch("daimyo.presentation.mcp.server._feedback_service")
    def test_missing_categories_for_missed_returns_error(self, mock_service):
        """Missing categories param for missed_categories returns an error."""
        result = server.submit_feedback(
            type="missed_categories",
            task="Some task",
            reason="Some reason",
        )
        assert result.startswith("Error:")
        mock_service.submit.assert_not_called()

    @patch("daimyo.presentation.mcp.server._feedback_service")
    def test_empty_rules_json_array_returns_error(self, mock_service):
        """Empty rules_json array returns an error."""
        result = server.submit_feedback(
            type="contradictory_rules",
            task="Some task",
            rules_json="[]",
        )
        assert result.startswith("Error:")
        mock_service.submit.assert_not_called()
