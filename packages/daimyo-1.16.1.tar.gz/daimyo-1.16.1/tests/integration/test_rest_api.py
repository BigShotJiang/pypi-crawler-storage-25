"""Integration tests for REST API."""

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def client(temp_rules_dir):
    """Create a test client with temporary rules directory."""
    # Override container to use test directory
    from daimyo.infrastructure.composite import CompositeScopeRepository
    from daimyo.infrastructure.di import ServiceContainer
    from daimyo.infrastructure.filesystem import FilesystemScopeRepository

    container = ServiceContainer()

    # Override scope repository with test path
    def test_scope_repo_factory():
        local_repo = FilesystemScopeRepository(str(temp_rules_dir))
        return CompositeScopeRepository(local_repo=local_repo, remote_repo=None)

    container.override_scope_repository(test_scope_repo_factory)

    # Import app and override its container dependency
    from daimyo.presentation.rest import dependencies

    # Temporarily override the get_container function
    original_get_container = dependencies.get_container
    dependencies.get_container = lambda: container

    from daimyo.presentation.rest.app import app

    client = TestClient(app)

    yield client

    # Restore original get_container
    dependencies.get_container = original_get_container


class TestRestAPI:
    """Integration tests for REST API endpoints."""

    def test_root_endpoint(self, client):
        """Test root endpoint."""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "Daimyo" in data["service"]

    def test_health_endpoint(self, client):
        """Test health check endpoint."""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"

    def test_get_scope_index(self, client):
        """Test getting scope index."""
        response = client.get(
            "/api/v1/scopes/test-scope/index", headers={"Accept": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()

        assert data["scope_name"] == "test-scope"
        assert "commandments" in data
        assert "suggestions" in data
        assert isinstance(data["commandments"], list)
        assert isinstance(data["suggestions"], list)

    def test_get_scope_index_not_found(self, client):
        """Test getting index for non-existent scope."""
        response = client.get(
            "/api/v1/scopes/nonexistent/index", headers={"Accept": "application/json"}
        )
        assert response.status_code == 404

    def test_get_scope_rules_yaml(self, client):
        """Test getting rules in YAML format."""
        response = client.get(
            "/api/v1/scopes/test-scope/rules?format=yaml-multi-doc",
            headers={"Accept": "application/x-yaml"},
        )
        assert response.status_code == 200
        assert "application/x-yaml" in response.headers["content-type"]
        assert "---" in response.text  # Multi-document separator

    def test_get_scope_rules_json(self, client):
        """Test getting rules in JSON format."""
        response = client.get(
            "/api/v1/scopes/test-scope/rules?format=json", headers={"Accept": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()

        assert "metadata" in data
        assert "commandments" in data
        assert "suggestions" in data

    def test_get_scope_rules_with_filter(self, client):
        """Test getting rules with category filter."""
        response = client.get(
            "/api/v1/scopes/test-scope/rules?format=json&categories=python.testing",
            headers={"Accept": "application/json"},
        )
        assert response.status_code == 200
        data = response.json()

        commandments = data["commandments"]
        assert "python.testing" in commandments

    def test_get_scope_rules_invalid_format(self, client):
        """Test getting rules with invalid format."""
        response = client.get(
            "/api/v1/scopes/test-scope/rules?format=invalid",
            headers={"Accept": "application/invalid"},
        )
        assert response.status_code == 406

    def test_api_docs_available(self, client):
        """Test that API documentation is available."""
        response = client.get("/docs")
        assert response.status_code == 200


@pytest.fixture
def client_with_katas(tmp_path):
    """Test client backed by a scope that has katas with duplicate names across categories."""
    rules_dir = tmp_path / "rules"
    rules_dir.mkdir()

    scope_dir = rules_dir / "test-scope"
    scope_dir.mkdir()

    (scope_dir / "metadata.yml").write_text(
        "name: test-scope\ndescription: Test scope\nparent: null\ntags: {}\n"
    )
    (scope_dir / "commandments.yml").write_text(
        "python:\n  when: When writing Python\n  ruleset:\n    - Use type hints\n"
    )
    (scope_dir / "suggestions.yml").write_text("{}\n")
    (scope_dir / "katas.yml").write_text(
        "python:\n"
        "  testing:\n"
        "    when: When testing\n"
        "    katas:\n"
        "      setup: Testing setup procedure\n"
        "  web:\n"
        "    when: When building web apps\n"
        "    katas:\n"
        "      setup: Web setup procedure\n"
    )

    from daimyo.infrastructure.composite import CompositeScopeRepository
    from daimyo.infrastructure.di import ServiceContainer
    from daimyo.infrastructure.filesystem import FilesystemScopeRepository

    container = ServiceContainer()
    container.override_scope_repository(
        lambda: CompositeScopeRepository(
            local_repo=FilesystemScopeRepository(str(rules_dir)), remote_repo=None
        )
    )

    from daimyo.presentation.rest import dependencies

    original_get_container = dependencies.get_container
    dependencies.get_container = lambda: container

    from daimyo.presentation.rest.app import app

    test_client = TestClient(app)

    yield test_client

    dependencies.get_container = original_get_container


class TestRestGetKataCategory:
    """Tests for GET /katas/{kata_name}?category= disambiguation."""

    def test_get_kata_with_category_returns_correct_procedure(
        self, client_with_katas: TestClient
    ) -> None:
        """?category= returns the kata from the specified category only."""
        response = client_with_katas.get(
            "/api/v1/scopes/test-scope/katas/setup?category=python.web"
        )
        assert response.status_code == 200
        assert "Web setup procedure" in response.text
        assert "Testing setup procedure" not in response.text

    def test_get_kata_without_category_returns_first_match(
        self, client_with_katas: TestClient
    ) -> None:
        """Without ?category=, the first matching kata is returned."""
        response = client_with_katas.get("/api/v1/scopes/test-scope/katas/setup")
        assert response.status_code == 200
        assert "setup procedure" in response.text.lower()

    def test_get_kata_nonexistent_category_returns_404(
        self, client_with_katas: TestClient
    ) -> None:
        """A category that does not exist returns 404."""
        response = client_with_katas.get(
            "/api/v1/scopes/test-scope/katas/setup?category=python.nonexistent"
        )
        assert response.status_code == 404

    def test_get_kata_not_in_specified_category_returns_404(
        self, client_with_katas: TestClient
    ) -> None:
        """A kata name absent from the specified category returns 404."""
        response = client_with_katas.get(
            "/api/v1/scopes/test-scope/katas/nonexistent-kata?category=python.testing"
        )
        assert response.status_code == 404


__all__ = ["TestRestAPI"]
