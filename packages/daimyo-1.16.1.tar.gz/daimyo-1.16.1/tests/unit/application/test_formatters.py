"""Tests for output formatters."""

import yaml

from daimyo.application.formatters import (
    IndexMarkdownFormatter,
    JsonFormatter,
    KataIndexMarkdownFormatter,
    KataListMarkdownFormatter,
    KataMarkdownFormatter,
    MarkdownFormatter,
    YamlMultiDocFormatter,
)
from daimyo.domain import (
    Category,
    CategoryKey,
    Kata,
    KataCategory,
    KataSet,
    MergedScope,
    Rule,
    RuleSet,
    RuleType,
    ScopeMetadata,
)


class TestYamlMultiDocFormatter:
    """Tests for YAML multi-document formatter."""

    def test_format_basic(self, sample_scope):
        """Test basic YAML multi-doc formatting."""
        from daimyo.domain import MergedScope

        merged = MergedScope.from_scope(sample_scope)
        formatter = YamlMultiDocFormatter()
        result = formatter.format(merged)

        documents = list(yaml.safe_load_all(result))
        assert len(documents) == 3

        assert "metadata" in documents[0]
        assert documents[0]["metadata"]["name"] == "test-scope"

        assert "commandments" in documents[1]

        assert "suggestions" in documents[2]


class TestJsonFormatter:
    """Tests for JSON formatter."""

    def test_format_basic(self, sample_scope):
        """Test basic JSON formatting."""
        from daimyo.domain import MergedScope

        merged = MergedScope.from_scope(sample_scope)
        formatter = JsonFormatter()
        result = formatter.format(merged)

        assert "metadata" in result
        assert "commandments" in result
        assert "suggestions" in result
        assert result["metadata"]["name"] == "test-scope"

    def test_format_includes_katas(self):
        """Test that katas are included in JSON output keyed by category."""
        scope = _make_kata_scope()
        result = JsonFormatter().format(scope)

        assert "katas" in result
        assert "python.testing" in result["katas"]
        entry = result["katas"]["python.testing"]
        assert entry["when"] == "When writing tests"
        assert "TDD-cycle" in entry["katas"]
        assert "BDD-scenario" in entry["katas"]

    def test_format_katas_empty_when_no_katas(self, sample_scope):
        """Test that katas key is present but empty when scope has no katas."""
        from daimyo.domain import MergedScope

        merged = MergedScope.from_scope(sample_scope)
        result = JsonFormatter().format(merged)

        assert "katas" in result
        assert result["katas"] == {}


class TestMarkdownFormatter:
    """Tests for Markdown formatter."""

    def test_format_basic(self, sample_scope):
        """Test basic Markdown formatting."""
        from daimyo.domain import MergedScope

        merged = MergedScope.from_scope(sample_scope)
        formatter = MarkdownFormatter()
        result = formatter.format(merged)

        assert "# Rules for test-scope" in result
        assert "## Commandments" in result
        assert "MUST" in result

    def test_format_with_hierarchy(self):
        """Test Markdown formatting with hierarchy (categorized mode)."""
        from unittest.mock import MagicMock

        metadata = ScopeMetadata(name="test", description="Test")
        merged = MergedScope(
            metadata=metadata,
            commandments=RuleSet(),
            suggestions=RuleSet(),
            sources=["local"],
        )

        cat1 = Category(CategoryKey.from_string("python"), when="Python")
        cat1.add_rule(Rule("Rule 1", RuleType.COMMANDMENT))
        merged.commandments.add_category(cat1)

        cat2 = Category(CategoryKey.from_string("python.web"), when="Web")
        cat2.add_rule(Rule("Rule 2", RuleType.COMMANDMENT))
        merged.commandments.add_category(cat2)

        formatter = MarkdownFormatter()
        mock_settings = MagicMock()
        mock_settings.get.side_effect = lambda key, default=None: (
            True if key == "RULES_CATEGORIZED" else default
        )
        formatter.settings = mock_settings
        result = formatter.format(merged)

        assert "## python" in result
        assert "### web" in result
        assert "MUST" in result


class TestIndexMarkdownFormatter:
    """Tests for Index Markdown formatter."""

    def test_format_basic(self, sample_merged_scope):
        """Test basic index markdown formatting."""
        formatter = IndexMarkdownFormatter()
        result = formatter.format(sample_merged_scope)

        assert "# Index of rule categories for scope test-scope" in result
        assert "Test scope for unit tests" in result
        assert "When requesting rules" in result

    def test_format_with_footer(self, sample_merged_scope):
        """Test that footer is included by default."""
        formatter = IndexMarkdownFormatter(include_footer=True)
        result = formatter.format(sample_merged_scope)

        expected_text = (
            "When requesting rules, the rules of a given category include "
            "also the rules of all its subcategories."
        )
        assert expected_text in result

    def test_format_without_footer(self, sample_merged_scope):
        """Test that footer can be excluded."""
        formatter = IndexMarkdownFormatter(include_footer=False)
        result = formatter.format(sample_merged_scope)

        assert "When requesting rules" not in result

    def test_format_with_hierarchy(self):
        """Test index formatting with hierarchical categories."""
        metadata = ScopeMetadata(name="test", description="Test scope")
        merged_commandments = RuleSet()
        merged_suggestions = RuleSet()

        python_cat = Category(CategoryKey.from_string("python"), when="When writing Python code")
        python_cat.add_rule(Rule("Use type hints", RuleType.COMMANDMENT))
        merged_commandments.add_category(python_cat)

        web_cat = Category(
            CategoryKey.from_string("python.web"), when="When building web applications"
        )
        web_cat.add_rule(Rule("Use FastAPI", RuleType.COMMANDMENT))
        merged_commandments.add_category(web_cat)

        api_cat = Category(CategoryKey.from_string("python.web.api"), when="When building APIs")
        api_cat.add_rule(Rule("Use REST", RuleType.SUGGESTION))
        merged_suggestions.add_category(api_cat)

        merged_scope = MergedScope(
            metadata=metadata,
            commandments=merged_commandments,
            suggestions=merged_suggestions,
            sources=["local"],
        )

        formatter = IndexMarkdownFormatter(include_footer=False)
        result = formatter.format(merged_scope)

        assert "- `python`: When writing Python code" in result
        assert "  - `python.web`: When building web applications" in result
        assert "    - `python.web.api`: When building APIs" in result

    def test_format_with_empty_categories(self):
        """Test index formatting with no categories."""
        metadata = ScopeMetadata(name="empty", description="Empty scope")
        merged_scope = MergedScope(
            metadata=metadata,
            commandments=RuleSet(),
            suggestions=RuleSet(),
            sources=["local"],
        )

        formatter = IndexMarkdownFormatter()
        result = formatter.format(merged_scope)

        assert "# Index of rule categories for scope empty" in result
        assert "Empty scope" in result

    def test_format_aggregates_categories(self):
        """Test that categories from both commandments and suggestions are aggregated."""
        metadata = ScopeMetadata(name="test", description="Test")
        merged_commandments = RuleSet()
        merged_suggestions = RuleSet()

        cat1 = Category(CategoryKey.from_string("python"), when="Python code")
        cat1.add_rule(Rule("Rule 1", RuleType.COMMANDMENT))
        merged_commandments.add_category(cat1)

        cat2 = Category(CategoryKey.from_string("python.web"), when="Web development")
        cat2.add_rule(Rule("Rule 2", RuleType.SUGGESTION))
        merged_suggestions.add_category(cat2)

        merged_scope = MergedScope(
            metadata=metadata,
            commandments=merged_commandments,
            suggestions=merged_suggestions,
            sources=["local"],
        )

        formatter = IndexMarkdownFormatter(include_footer=False)
        result = formatter.format(merged_scope)

        assert "- `python`: Python code" in result
        assert "  - `python.web`: Web development" in result

    def test_format_backtick_formatting(self, sample_merged_scope):
        """Test that category keys are wrapped in backticks."""
        formatter = IndexMarkdownFormatter()
        result = formatter.format(sample_merged_scope)

        assert "`python`" in result
        assert "`python.testing`" in result

    def test_format_no_description(self):
        """Test formatting when scope has no description."""
        metadata = ScopeMetadata(name="no-desc", description=None)
        merged_scope = MergedScope(
            metadata=metadata,
            commandments=RuleSet(),
            suggestions=RuleSet(),
            sources=["local"],
        )

        formatter = IndexMarkdownFormatter()
        result = formatter.format(merged_scope)

        assert "# Index of rule categories for scope no-desc" in result


def _make_kata_scope(name: str = "test-scope") -> MergedScope:
    """Build a minimal MergedScope with katas for formatter tests."""
    metadata = ScopeMetadata(name=name, description="Test scope for unit tests")
    kataset = KataSet()
    cat = KataCategory(key=CategoryKey.from_string("python.testing"), when="When writing tests")
    cat.add_kata(Kata(name="TDD-cycle", procedure="1. Write failing test\n2. Make it pass"))
    cat.add_kata(Kata(name="BDD-scenario", procedure="Given/When/Then"))
    kataset.add_category(cat)
    return MergedScope(
        metadata=metadata,
        commandments=RuleSet(),
        suggestions=RuleSet(),
        katas=kataset,
        sources=["local"],
    )


class TestKataFormatters:
    """Tests for kata output formatters."""

    def test_kata_markdown_formatter_basic(self):
        """Test basic kata markdown formatting."""
        scope = _make_kata_scope()
        kata = Kata(name="TDD-cycle", procedure="1. Write failing test\n2. Make it pass")
        formatter = KataMarkdownFormatter()
        result = formatter.format_kata(scope, kata)

        assert "# Kata: TDD-cycle" in result
        assert "1. Write failing test" in result
        assert "2. Make it pass" in result

    def test_kata_list_markdown_formatter_with_katas(self):
        """Test kata list markdown formatting with categories present."""
        scope = _make_kata_scope()
        formatter = KataListMarkdownFormatter()
        result = formatter.format(scope)

        assert "# Available Katas in test-scope" in result
        assert "python.testing" in result
        assert "`TDD-cycle`" in result
        assert "`BDD-scenario`" in result

    def test_kata_list_markdown_formatter_empty(self):
        """Test kata list markdown formatting with no katas."""
        metadata = ScopeMetadata(name="empty", description="Empty scope")
        scope = MergedScope(
            metadata=metadata,
            commandments=RuleSet(),
            suggestions=RuleSet(),
            katas=KataSet(),
            sources=["local"],
        )
        formatter = KataListMarkdownFormatter()
        result = formatter.format(scope)

        assert "No katas found" in result

    def test_kata_index_markdown_formatter_with_categories(self):
        """Test kata index markdown formatting with categories."""
        scope = _make_kata_scope()
        formatter = KataIndexMarkdownFormatter()
        result = formatter.format(scope)

        assert "# Kata Categories for test-scope" in result
        assert "`python.testing`" in result

    def test_kata_index_markdown_formatter_empty(self):
        """Test kata index markdown formatting with no categories."""
        metadata = ScopeMetadata(name="empty", description="Empty scope")
        scope = MergedScope(
            metadata=metadata,
            commandments=RuleSet(),
            suggestions=RuleSet(),
            katas=KataSet(),
            sources=["local"],
        )
        formatter = KataIndexMarkdownFormatter()
        result = formatter.format(scope)

        assert "# Kata Categories for empty" in result


__all__ = [
    "TestYamlMultiDocFormatter",
    "TestJsonFormatter",
    "TestMarkdownFormatter",
    "TestIndexMarkdownFormatter",
    "TestKataFormatters",
]
