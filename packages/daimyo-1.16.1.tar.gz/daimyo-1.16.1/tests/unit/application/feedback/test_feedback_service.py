"""Unit tests for FeedbackService."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from daimyo.application.feedback import FeedbackService, FeedbackWriteError


class TestFeedbackService:
    """Tests for FeedbackService.submit."""

    def test_contradictory_rules_writes_entry(self, tmp_path):
        """Submit contradictory_rules feedback and verify the JSONL entry."""
        feedback_file = tmp_path / "feedback.jsonl"
        service = FeedbackService(str(feedback_file))

        service.submit(
            "contradictory_rules",
            {
                "task": "Writing integration tests",
                "rules": [{"category": "python.testing", "rule": "Use pytest"}],
            },
        )

        lines = feedback_file.read_text(encoding="utf-8").splitlines()
        assert len(lines) == 1
        entry = json.loads(lines[0])
        assert entry["type"] == "contradictory_rules"
        assert entry["task"] == "Writing integration tests"
        assert entry["rules"] == [{"category": "python.testing", "rule": "Use pytest"}]
        assert "timestamp" in entry

    def test_missed_categories_writes_entry(self, tmp_path):
        """Submit missed_categories feedback and verify the JSONL entry."""
        feedback_file = tmp_path / "feedback.jsonl"
        service = FeedbackService(str(feedback_file))

        service.submit(
            "missed_categories",
            {
                "task": "Adding REST endpoint",
                "categories": ["development.domain_specific.apis.rest"],
                "reason": "Focused on Python rules initially",
            },
        )

        entry = json.loads(feedback_file.read_text(encoding="utf-8").strip())
        assert entry["type"] == "missed_categories"
        assert entry["categories"] == ["development.domain_specific.apis.rest"]
        assert entry["reason"] == "Focused on Python rules initially"

    def test_multiple_submissions_append(self, tmp_path):
        """Multiple submit calls append separate lines."""
        feedback_file = tmp_path / "feedback.jsonl"
        service = FeedbackService(str(feedback_file))

        service.submit("missed_categories", {"task": "Task one", "categories": ["a"], "reason": "r"})
        service.submit("missed_categories", {"task": "Task two", "categories": ["b"], "reason": "r"})

        lines = feedback_file.read_text(encoding="utf-8").splitlines()
        assert len(lines) == 2
        assert json.loads(lines[0])["task"] == "Task one"
        assert json.loads(lines[1])["task"] == "Task two"

    def test_parent_directory_created(self, tmp_path):
        """Parent directories are created if they do not exist."""
        feedback_file = tmp_path / "nested" / "dir" / "feedback.jsonl"
        service = FeedbackService(str(feedback_file))

        service.submit("missed_categories", {"task": "Some task", "categories": ["a"], "reason": "r"})

        assert feedback_file.exists()

    def test_timestamp_is_utc_iso8601(self, tmp_path):
        """Timestamp in the entry is UTC ISO-8601."""
        feedback_file = tmp_path / "feedback.jsonl"
        service = FeedbackService(str(feedback_file))

        service.submit("missed_categories", {"task": "Check timestamp", "categories": ["a"], "reason": "r"})

        entry = json.loads(feedback_file.read_text(encoding="utf-8").strip())
        from datetime import datetime

        dt = datetime.fromisoformat(entry["timestamp"])
        assert dt.tzinfo is not None
        assert dt.tzinfo.utcoffset(dt).total_seconds() == 0

    @pytest.mark.parametrize(
        "exc_type, expected_context",
        [
            (OSError, pytest.raises(FeedbackWriteError)),
        ],
    )
    def test_os_error_raises_feedback_write_error(self, tmp_path, exc_type, expected_context):
        """OSError during write is wrapped in FeedbackWriteError."""
        feedback_file = tmp_path / "feedback.jsonl"
        service = FeedbackService(str(feedback_file))

        with patch("pathlib.Path.open", side_effect=exc_type("disk full")):
            with expected_context:
                service.submit(
                    "missed_categories", {"task": "Some task", "categories": ["a"], "reason": "r"}
                )
