"""Tests for HttpRemoteScopeClient."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from daimyo.domain import RemoteServerError
from daimyo.infrastructure.remote.remote_client import HttpRemoteScopeClient


class TestFlatKatasToNested:
    """Tests for _flat_katas_to_nested conversion."""

    @pytest.fixture
    def client(self) -> HttpRemoteScopeClient:
        """Create client instance."""
        return HttpRemoteScopeClient(timeout=30, max_retries=3)

    def test_single_top_level_category(self, client: HttpRemoteScopeClient) -> None:
        """Single flat key with no dots maps to a top-level nested dict."""
        flat = {"testing": {"when": "When testing", "katas": {"tdd-cycle": "step 1"}}}
        result = client._flat_katas_to_nested(flat)

        assert "testing" in result
        assert result["testing"]["when"] == "When testing"
        assert result["testing"]["katas"] == {"tdd-cycle": "step 1"}

    def test_dotted_key_produces_nesting(self, client: HttpRemoteScopeClient) -> None:
        """A dotted key is expanded into nested dicts."""
        flat = {
            "python.testing": {
                "when": "When writing Python tests",
                "katas": {"tdd-cycle": "1. Red 2. Green 3. Refactor"},
            }
        }
        result = client._flat_katas_to_nested(flat)

        assert "python" in result
        assert "testing" in result["python"]
        assert result["python"]["testing"]["katas"] == {
            "tdd-cycle": "1. Red 2. Green 3. Refactor"
        }

    def test_missing_when_defaults_to_none(self, client: HttpRemoteScopeClient) -> None:
        """A category without 'when' gets None in the nested dict."""
        flat = {"dev": {"katas": {"build": "step 1"}}}
        result = client._flat_katas_to_nested(flat)

        assert result["dev"]["when"] is None

    def test_empty_input_returns_empty_dict(self, client: HttpRemoteScopeClient) -> None:
        """Empty flat dict produces an empty nested dict."""
        assert client._flat_katas_to_nested({}) == {}

    def test_multiple_categories(self, client: HttpRemoteScopeClient) -> None:
        """Multiple flat keys produce sibling entries in the nested dict."""
        flat = {
            "python.testing": {"when": "Tests", "katas": {"tdd-cycle": "..."}},
            "python.web": {"when": "Web", "katas": {"build-api": "..."}},
        }
        result = client._flat_katas_to_nested(flat)

        assert "testing" in result["python"]
        assert "web" in result["python"]


class TestParseJsonWithKatas:
    """Tests for _parse_json kata parsing."""

    @pytest.fixture
    def client(self) -> HttpRemoteScopeClient:
        """Create client instance."""
        return HttpRemoteScopeClient(timeout=30, max_retries=3)

    def test_parse_json_includes_katas(self, client: HttpRemoteScopeClient) -> None:
        """Katas present in the JSON payload are parsed into the returned Scope."""
        json_payload = {
            "metadata": {"name": "test-scope", "description": "desc", "parent": None},
            "commandments": {},
            "suggestions": {},
            "katas": {
                "python.testing": {
                    "when": "When writing Python tests",
                    "katas": {"tdd-cycle": "1. Red\n2. Green\n3. Refactor"},
                }
            },
        }
        scope = client._parse_json(json_payload, "test-scope", "http://example.com")

        from daimyo.domain import CategoryKey

        cat_key = CategoryKey.from_string("python.testing")
        assert cat_key in scope.katas.categories
        category = scope.katas.categories[cat_key]
        assert "tdd-cycle" in category.katas
        assert category.katas["tdd-cycle"].procedure == "1. Red\n2. Green\n3. Refactor"

    def test_parse_json_no_katas_key_leaves_katas_empty(
        self, client: HttpRemoteScopeClient
    ) -> None:
        """A JSON payload without a 'katas' key results in an empty KataSet."""
        json_payload = {
            "metadata": {"name": "test-scope", "description": "desc", "parent": None},
            "commandments": {},
            "suggestions": {},
        }
        scope = client._parse_json(json_payload, "test-scope", "http://example.com")

        assert scope.katas.categories == {}


class TestHttpRemoteScopeClient:
    """Test suite for HttpRemoteScopeClient."""

    @pytest.fixture
    def client(self):
        """Create client instance."""
        return HttpRemoteScopeClient(timeout=30, max_retries=3)

    @pytest.fixture
    def valid_yaml_response(self):
        """Create valid multi-document YAML response."""
        return """---
metadata:
  name: test-scope
  description: Test scope
  parent: null
  tags: {}
---
commandments:
  python:
    when: When writing Python
    ruleset:
      - Use type hints
      - Follow PEP 8
---
suggestions:
  python:
    when: When writing Python
    ruleset:
      - Consider dataclasses
"""

    def test_client_initialization_with_params(self):
        """Test client initialization with custom parameters."""
        client = HttpRemoteScopeClient(timeout=60, max_retries=5)

        assert client.timeout == 60
        assert client.max_retries == 5
        assert client.client is not None

    def test_client_initialization_with_defaults(self):
        """Test client initialization uses defaults from settings."""
        client = HttpRemoteScopeClient()

        assert client.timeout > 0
        assert client.max_retries >= 0

    @pytest.mark.skipif(True, reason="Requires pytest-httpx which is not installed")
    def test_fetch_scope_success(self, client, valid_yaml_response):
        """Test successful scope fetch."""
        from pytest_httpx import HTTPXMock

        base_url = "https://example.com"
        scope_name = "test-scope"
        api_url = f"{base_url}/api/v1/scopes/{scope_name}/rules"

        httpx_mock = HTTPXMock()
        httpx_mock.add_response(url=api_url, status_code=200, text=valid_yaml_response)

        result = client.fetch_scope(base_url, scope_name)

        assert result is not None
        assert result.metadata.name == "test-scope"
        assert len(result.commandments.categories) > 0

    @pytest.mark.skipif(True, reason="Requires pytest-httpx which is not installed")
    def test_fetch_scope_404_returns_none(self, client):
        """Test fetch returns None for 404 response."""
        from pytest_httpx import HTTPXMock

        base_url = "https://example.com"
        scope_name = "nonexistent"
        api_url = f"{base_url}/api/v1/scopes/{scope_name}/rules"

        httpx_mock = HTTPXMock()
        httpx_mock.add_response(url=api_url, status_code=404)

        result = client.fetch_scope(base_url, scope_name)

        assert result is None

    @pytest.mark.skipif(True, reason="Requires pytest-httpx which is not installed")
    def test_fetch_scope_500_raises_error(self, client):
        """Test fetch raises RemoteServerError for 500 response."""
        from pytest_httpx import HTTPXMock

        base_url = "https://example.com"
        scope_name = "test-scope"
        api_url = f"{base_url}/api/v1/scopes/{scope_name}/rules"

        httpx_mock = HTTPXMock()
        httpx_mock.add_response(url=api_url, status_code=500, text="Internal server error")

        with pytest.raises(RemoteServerError):
            client.fetch_scope(base_url, scope_name)

    @pytest.mark.skipif(True, reason="Requires pytest-httpx which is not installed")
    def test_fetch_scope_timeout_raises_error(self, client):
        """Test fetch raises RemoteServerError on timeout."""
        import httpx
        from pytest_httpx import HTTPXMock

        base_url = "https://example.com"
        scope_name = "test-scope"

        httpx_mock = HTTPXMock()
        httpx_mock.add_exception(httpx.TimeoutException("Request timed out"))

        with pytest.raises(RemoteServerError) as exc_info:
            client.fetch_scope(base_url, scope_name)

        assert "Timeout" in str(exc_info.value)

    @pytest.mark.skipif(True, reason="Requires pytest-httpx which is not installed")
    def test_fetch_scope_connection_error_raises(self, client):
        """Test fetch raises RemoteServerError on connection error."""
        import httpx
        from pytest_httpx import HTTPXMock

        base_url = "https://example.com"
        scope_name = "test-scope"

        httpx_mock = HTTPXMock()
        httpx_mock.add_exception(httpx.ConnectError("Cannot connect"))

        with pytest.raises(RemoteServerError) as exc_info:
            client.fetch_scope(base_url, scope_name)

        assert "Connection error" in str(exc_info.value)

    def test_fetch_scope_url_construction(self, client):
        """Test that API URL is constructed correctly."""
        base_url = "https://example.com"
        scope_name = "test-scope"

        expected_url = "https://example.com/api/v1/scopes/test-scope/rules"

        assert expected_url in f"{base_url}/api/v1/scopes/{scope_name}/rules"

    def test_fetch_scope_url_with_trailing_slash(self, client):
        """Test URL construction with trailing slash in base URL."""
        base_url = "https://example.com/"
        scope_name = "test-scope"

        expected_url = "https://example.com/api/v1/scopes/test-scope/rules"

        assert expected_url in f"{base_url.rstrip('/')}/api/v1/scopes/{scope_name}/rules"

    def test_client_closes_on_deletion(self):
        """Test that client closes httpx client on deletion."""
        import gc
        import weakref

        client = HttpRemoteScopeClient(timeout=30, max_retries=3)
        httpx_client = client.client

        # Create weak reference to verify cleanup
        weak_ref = weakref.ref(client)

        del client
        gc.collect()

        # Verify client was garbage collected
        assert weak_ref() is None
        assert httpx_client.is_closed

    def test_fetch_scope_sets_accept_header(self, client):
        """Test that Accept header is set to application/x-yaml."""
        pass

    def test_fetch_scope_follows_redirects(self, client):
        """Test that client follows redirects."""
        assert client.client._transport._pool._retries > 0


class TestHttpRemoteScopeClientSSL:
    """Tests for SSL/TLS configuration of HttpRemoteScopeClient."""

    def _get_verify_kwarg(self, **kwargs) -> bool | str:
        """Instantiate the client with patched httpx.Client and return the verify kwarg."""
        with patch("daimyo.infrastructure.remote.remote_client.httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = MagicMock()
            HttpRemoteScopeClient(**kwargs)
            _, ctor_kwargs = mock_client_cls.call_args
            return ctor_kwargs["verify"]

    def test_default_ssl_verify_true(self):
        """Default config uses verify=True (system CA store)."""
        with patch("daimyo.infrastructure.remote.remote_client.settings") as mock_settings:
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            verify = self._get_verify_kwarg()
        assert verify is True

    def test_ssl_verify_disabled(self):
        """ssl_verify=False passes verify=False to httpx.Client."""
        verify = self._get_verify_kwarg(ssl_verify=False, ssl_ca_bundle="")
        assert verify is False

    def test_ssl_verify_disabled_ca_bundle_ignored(self):
        """ssl_verify=False ignores ssl_ca_bundle and passes verify=False."""
        verify = self._get_verify_kwarg(ssl_verify=False, ssl_ca_bundle="/path/to/ca.pem")
        assert verify is False

    def test_custom_ca_bundle(self):
        """ssl_verify=True with a ca bundle path passes the path as verify."""
        verify = self._get_verify_kwarg(
            ssl_verify=True, ssl_ca_bundle="/etc/ssl/certs/company-ca.pem"
        )
        assert verify == "/etc/ssl/certs/company-ca.pem"

    def test_default_verify_true_no_bundle(self):
        """ssl_verify=True with empty ca bundle passes verify=True."""
        verify = self._get_verify_kwarg(ssl_verify=True, ssl_ca_bundle="")
        assert verify is True

    def test_config_defaults_used_when_params_omitted(self):
        """When no SSL params are passed, values are read from settings."""
        with patch("daimyo.infrastructure.remote.remote_client.settings") as mock_settings:
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = "/from/config/ca.pem"
            verify = self._get_verify_kwarg()
        assert verify == "/from/config/ca.pem"

    def test_config_default_verify_false(self):
        """When settings.REMOTE_SSL_VERIFY is False, verify=False is used."""
        with patch("daimyo.infrastructure.remote.remote_client.settings") as mock_settings:
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = False
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            verify = self._get_verify_kwarg()
        assert verify is False
