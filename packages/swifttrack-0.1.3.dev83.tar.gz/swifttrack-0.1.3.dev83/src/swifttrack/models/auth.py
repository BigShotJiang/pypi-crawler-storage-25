"""Authentication models for SwiftTrack SDK."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class LoginRequest(BaseModel):
    """Request model for email/password login."""

    model_config = ConfigDict(populate_by_name=True)

    email: str = Field(..., description="User email address")
    password: str = Field(..., description="User password", min_length=1)


class LoginResponse(BaseModel):
    """Response model for successful login."""

    model_config = ConfigDict(populate_by_name=True)

    token_type: str = Field(..., alias="tokenType", description="Type of token (e.g., Bearer)")
    access_token: str = Field(..., alias="accessToken", description="JWT access token")

    @property
    def token(self) -> str:
        """Get the full authorization token."""
        return f"{self.token_type} {self.access_token}"


class MobileLoginRequest(BaseModel):
    """Request model for mobile/OTP login."""

    mobile_number: str = Field(..., description="Mobile phone number", min_length=10)
    otp: str = Field(..., description="One-time password", min_length=4, max_length=8)


class TokenValidationRequest(BaseModel):
    """Request model for token validation."""

    token: str = Field(..., description="JWT token to validate")


class UserDetails(BaseModel):
    """User details from token validation."""

    id: str = Field(..., description="User ID")
    email: Optional[str] = Field(None, description="User email")
    name: Optional[str] = Field(None, description="User name")
    tenant_id: Optional[str] = Field(None, description="Tenant ID")
    roles: list[str] = Field(default_factory=list, description="User roles")
    is_active: bool = Field(True, description="Whether the user is active")


class RegisterUserRequest(BaseModel):
    """Request model for user registration."""

    email: str = Field(..., description="User email address")
    password: str = Field(..., description="User password", min_length=8)
    mobile: Optional[str] = Field(None, description="Mobile phone number")
    name: Optional[str] = Field(None, description="User full name")
