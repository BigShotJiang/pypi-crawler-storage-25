"""CLI interface for MacFleet."""
