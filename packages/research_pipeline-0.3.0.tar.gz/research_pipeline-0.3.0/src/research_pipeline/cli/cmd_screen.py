"""CLI handler for the 'screen' command."""

import json
import logging
from pathlib import Path

import typer

from research_pipeline.config.loader import load_config
from research_pipeline.models.candidate import CandidateRecord
from research_pipeline.models.query_plan import QueryPlan
from research_pipeline.models.screening import RelevanceDecision
from research_pipeline.screening.heuristic import score_candidates, select_topk
from research_pipeline.storage.manifests import read_jsonl, write_jsonl
from research_pipeline.storage.workspace import get_stage_dir, init_run

logger = logging.getLogger(__name__)


def run_screen(
    resume: bool = False,
    config_path: Path | None = None,
    workspace: Path | None = None,
    run_id: str | None = None,
) -> None:
    """Execute the screen stage: two-pass relevance filtering.

    Args:
        resume: Skip if already completed.
        config_path: Path to config TOML.
        workspace: Workspace directory.
        run_id: Run ID with search results.
    """
    config = load_config(config_path)
    ws = workspace or Path(config.workspace)
    run_id_str, run_root = init_run(ws, run_id)

    # Load plan
    plan_path = get_stage_dir(run_root, "plan") / "query_plan.json"
    if not plan_path.exists():
        typer.echo("Error: no query plan found. Run 'plan' first.", err=True)
        raise typer.Exit(1)
    plan = QueryPlan.model_validate(json.loads(plan_path.read_text(encoding="utf-8")))

    # Load candidates
    candidates_path = get_stage_dir(run_root, "search") / "candidates.jsonl"
    if not candidates_path.exists():
        typer.echo("Error: no candidates found. Run 'search' first.", err=True)
        raise typer.Exit(1)
    raw = read_jsonl(candidates_path)
    candidates = [CandidateRecord.model_validate(d) for d in raw]

    # Score
    scores = score_candidates(
        candidates,
        must_terms=plan.must_terms,
        nice_terms=plan.nice_terms,
        negative_terms=plan.negative_terms,
        target_categories=plan.candidate_categories,
    )

    screen_dir = get_stage_dir(run_root, "screen")
    write_jsonl(
        screen_dir / "cheap_scores.jsonl",
        [s.model_dump(mode="json") for s in scores],
    )

    top = select_topk(candidates, scores, top_k=config.screen.cheap_top_k)

    shortlist = []
    for candidate, score in top[: config.screen.download_top_n]:
        decision = RelevanceDecision(
            paper=candidate,
            cheap=score,
            llm=None,
            final_score=score.cheap_score,
            download=True,
            download_reason="score_threshold",
        )
        shortlist.append(decision)

    shortlist_path = screen_dir / "shortlist.json"
    shortlist_path.write_text(
        json.dumps(
            [d.model_dump(mode="json") for d in shortlist], indent=2, default=str
        ),
        encoding="utf-8",
    )

    typer.echo(f"Screened {len(candidates)} → {len(shortlist)} shortlisted")
    typer.echo(f"Saved to: {shortlist_path}")
    logger.info("Screen stage complete: %d shortlisted", len(shortlist))
