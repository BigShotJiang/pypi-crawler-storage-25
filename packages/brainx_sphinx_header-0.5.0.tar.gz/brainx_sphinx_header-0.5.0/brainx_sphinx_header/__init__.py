"""Inject the canonical BrainX brand header and footer into a Sphinx docs site.

The header and footer are fetched live from
https://brainx.chaobrain.com/shared-header so every package's docs stays in
sync with the landing site without copy-paste.

Usage in conf.py
----------------

    extensions = [
        ...,
        "brainx_sphinx_header",
    ]

Optional configuration (all have sensible defaults):

    brainx_header_url     = "https://brainx.chaobrain.com/shared-header"
    brainx_header_ttl     = 3600        # cache TTL in seconds
    brainx_header_offline = False       # use cache only, never fetch
    brainx_header_local   = None        # str path to a local shared-header dir
                                        # (e.g. ".../brainx.chaobrain.com/dist/shared-header")
                                        # for live-preview against an unpushed change
    brainx_inject_base    = True        # inject <base href="{html_baseurl}"> into the
                                        # index page so the site works at both
                                        # https://host/<pkg>  and  https://host/<pkg>/
                                        # No-op if html_baseurl is unset.
    brainx_ssr_inject     = True        # post-process every built .html to embed the
                                        # header/footer markup server-side, so it is in
                                        # the document at first paint (no flash, SEO,
                                        # no-JS, screen readers all see the chrome).
                                        # The JS injection remains as a self-skipping
                                        # fallback for any page that wasn't post-processed.

Environment variable overrides (handy in CI):

    BRAINX_HEADER_URL, BRAINX_HEADER_TTL, BRAINX_HEADER_OFFLINE=1, BRAINX_HEADER_LOCAL,
    BRAINX_SSR_INJECT=0

What this extension does
------------------------

1. On ``builder-inited``, fetches header.html + header.css + header.js +
   footer.html + footer.css from the BrainX landing site (with TTL cache at
   ``<confdir>/_brand/``).
2. Writes them to ``_static/css/brainx-header.css``,
   ``_static/js/brainx-header.js``, ``_static/css/brainx-footer.css``, and
   ``_static/js/brainx-footer.js`` (the JS preambles embed the markup and
   prepend/append it to ``<body>`` on DOM ready as a fallback).
3. Registers all four files via ``add_css_file`` / ``add_js_file``.
4. The header CSS appends ``_THEME_OVERRIDES`` that hide
   ``sphinx_book_theme`` / ``pydata_sphinx_theme`` top bars
   (``header.bd-header``, ``.bd-header-article``,
   ``.header-article-items.header-article__inner``) so the BrainX header is
   the only one visible.
5. The footer CSS appends ``_FOOTER_OVERRIDES`` that zero the ``.bx-footer``
   top margin. The canonical CSS ships ``margin-top: 6rem`` to separate the
   brand footer from editorial content on the Astro landing page; in Sphinx
   docs the theme already renders its own footer above ours, and that margin
   shows up as a 6-8rem blank band between the two. The override removes it
   so the two footers sit flush; the brand footer's own internal padding
   still gives a clear visual band.
6. On ``build-finished``, ``_ssr_inject_pages`` post-processes every built
   ``.html`` outside ``_static/`` and embeds the header markup after
   ``<body>`` and the footer markup before ``</body>``. Idempotent: pages
   that already contain ``data-bx-header`` and ``data-bx-footer`` are
   skipped. The JS preambles emitted in step 2 also self-skip when those
   markers are present, so they become a pure behavior payload (theme
   toggle, burger delegation) plus a fallback if SSR is disabled or
   couldn't touch a page.
7. The header JS rewires the BrainX header's burger button to the theme's
   hidden original (``.primary-toggle``) via capture-phase
   ``stopImmediatePropagation``, so sidebar toggle keeps working without
   touching theme templates.

Supported themes: ``sphinx_book_theme``, ``pydata_sphinx_theme`` (the
``bd-*`` family). Other themes will still show the BrainX header but won't
get button delegation; functionality of the theme's own header is
unaffected.
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from urllib.request import Request, urlopen

from sphinx.application import Sphinx

from ._fa_icons import FA_ICONS_CSS

__version__ = "0.5.0"

DEFAULT_BASE    = "https://brainx.chaobrain.com/shared-header"
DEFAULT_TTL     = 3600
ARTIFACT_CSS           = "css/brainx-header.css"
ARTIFACT_JS            = "js/brainx-header.js"
ARTIFACT_FOOTER_CSS    = "css/brainx-footer.css"
ARTIFACT_FOOTER_JS     = "js/brainx-footer.js"
CACHE_DIR_NAME  = "_brand"


# ---------------------------------------------------------------------------
# fetch / cache
# ---------------------------------------------------------------------------

def _fetch(url: str, timeout: int = 10) -> str:
    req = Request(url, headers={"User-Agent": "brainx-sphinx-header"})
    with urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8")


_ASSETS = ("header.html", "header.css", "header.js", "footer.html", "footer.css")


def _read_local(local_dir: Path) -> dict:
    return {name: (local_dir / name).read_text(encoding="utf-8") for name in _ASSETS}


def _load_with_cache(base_url: str, cache_dir: Path, ttl: int, offline: bool) -> dict:
    cache_dir.mkdir(parents=True, exist_ok=True)
    paths = {name: cache_dir / name for name in _ASSETS}
    meta_path = cache_dir / "meta.json"

    fresh = False
    if meta_path.exists() and all(p.exists() for p in paths.values()):
        try:
            meta = json.loads(meta_path.read_text())
            fresh = (time.time() - meta.get("ts", 0)) < ttl
        except Exception:
            fresh = False

    if not fresh and not offline:
        try:
            fetched = {name: _fetch(f"{base_url}/{name}") for name in _ASSETS}
            for name, content in fetched.items():
                paths[name].write_text(content, encoding="utf-8")
            meta_path.write_text(json.dumps({"ts": time.time(), "src": base_url}))
            return fetched
        except Exception as e:
            if not all(p.exists() for p in paths.values()):
                raise RuntimeError(
                    f"[brainx-sphinx-header] fetch failed for {base_url} "
                    f"and no complete cache exists: {e}"
                ) from e
            print(f"[brainx-sphinx-header] fetch failed ({e}); using stale cache at {cache_dir}")

    if not all(p.exists() for p in paths.values()):
        raise RuntimeError(
            f"[brainx-sphinx-header] offline=True but cache at {cache_dir} is incomplete. "
            f"Run once online first."
        )
    return {name: paths[name].read_text(encoding="utf-8") for name in _ASSETS}


# ---------------------------------------------------------------------------
# artifact emission (CSS + JS)
# ---------------------------------------------------------------------------

_THEME_OVERRIDES = """

/* --- brainx-sphinx-header docs-site overrides --- */
/* Hide pydata_sphinx_theme / sphinx_book_theme native top bars. The
   BrainX header replaces them visually; their functional buttons remain
   in the DOM (display: none) so the JS below can still click them. */
header.bd-header,
.bd-header-article,
.header-article-items.header-article__inner {
  display: none !important;
}

body {
  padding-top: 0 !important;
}
"""


_FOOTER_OVERRIDES = """

/* --- brainx-sphinx-header docs-site footer overrides ---
   The shared footer.css ships with `margin-top: 6rem` so the brand footer
   separates cleanly from the editorial content on the Astro landing page.
   Inside a Sphinx page the theme renders its own footer (bd-footer-content
   with copyright / last-updated) directly above ours, and that top margin
   then shows up as a ~6-8rem blank band between the two footers. Zero it
   so the BrainX footer sits flush against the theme footer; its own
   internal padding and distinct background still mark a clear band. */
.bx-footer {
  margin-top: 0 !important;
}
"""


def _build_js(html_payload: str, behavior_js: str, source_label: str) -> str:
    """Return the bundle the docs site loads.

    Bundle = injection preamble + canonical header.js. The preamble prepends
    the markup to <body> on DOM ready (Astro doesn't need this — it SSRs the
    markup). All actual behavior (theme, burger, sphinx delegation) lives in
    `behavior_js`, fetched verbatim from shared-header/header.js so every host
    converges on the same logic.
    """
    payload = json.dumps(html_payload)
    preamble = f"""// Auto-generated by brainx-sphinx-header from {source_label}
(function () {{
  var HTML = {payload};
  function inject() {{
    if (document.querySelector('[data-bx-header]')) return;
    var holder = document.createElement('div');
    holder.innerHTML = HTML;
    var node = holder.firstElementChild;
    if (node) document.body.insertBefore(node, document.body.firstChild);
  }}
  if (document.readyState === 'loading') {{
    document.addEventListener('DOMContentLoaded', inject);
  }} else {{
    inject();
  }}
}})();
"""
    return preamble + "\n/* --- canonical header.js (shared-header) --- */\n" + behavior_js


def _build_footer_js(html_payload: str, source_label: str) -> str:
    """Return the docs-site footer bundle.

    Appends the markup at the end of <body>. The footer has no behavior, so
    there is no canonical footer.js — only this preamble. The theme's native
    footer is left intact; the BrainX footer renders below it.
    """
    payload = json.dumps(html_payload)
    return f"""// Auto-generated by brainx-sphinx-header from {source_label}
(function () {{
  var HTML = {payload};
  function inject() {{
    if (document.querySelector('[data-bx-footer]')) return;
    var holder = document.createElement('div');
    holder.innerHTML = HTML;
    var node = holder.firstElementChild;
    if (node) document.body.appendChild(node);
  }}
  if (document.readyState === 'loading') {{
    document.addEventListener('DOMContentLoaded', inject);
  }} else {{
    inject();
  }}
}})();
"""


# ---------------------------------------------------------------------------
# Sphinx hooks
# ---------------------------------------------------------------------------

def _resolve_config(app: Sphinx) -> dict:
    cfg = app.config
    return {
        "url":     os.environ.get("BRAINX_HEADER_URL",     cfg.brainx_header_url).rstrip("/"),
        "ttl":     int(os.environ.get("BRAINX_HEADER_TTL", cfg.brainx_header_ttl)),
        "offline": (os.environ.get("BRAINX_HEADER_OFFLINE") == "1") or bool(cfg.brainx_header_offline),
        "local":   os.environ.get("BRAINX_HEADER_LOCAL",   cfg.brainx_header_local),
    }


def _on_builder_inited(app: Sphinx) -> None:
    cfg     = _resolve_config(app)
    confdir = Path(app.confdir)

    static_dirs = list(getattr(app.config, "html_static_path", []) or [])
    if not static_dirs:
        static_dirs = ["_static"]
        app.config.html_static_path = static_dirs
    primary_static = confdir / static_dirs[0]

    css_out        = primary_static / ARTIFACT_CSS
    js_out         = primary_static / ARTIFACT_JS
    footer_css_out = primary_static / ARTIFACT_FOOTER_CSS
    footer_js_out  = primary_static / ARTIFACT_FOOTER_JS
    css_out.parent.mkdir(parents=True, exist_ok=True)
    js_out.parent.mkdir(parents=True,  exist_ok=True)

    if cfg["local"]:
        assets = _read_local(Path(cfg["local"]))
        source_label = f"local:{cfg['local']}"
        print(f"[brainx-sphinx-header] using local source: {cfg['local']}")
    else:
        assets = _load_with_cache(
            cfg["url"],
            confdir / CACHE_DIR_NAME,
            cfg["ttl"],
            cfg["offline"],
        )
        source_label = cfg["url"]
        print(f"[brainx-sphinx-header] source={cfg['url']} offline={cfg['offline']} ttl={cfg['ttl']}")

    fa_css = FA_ICONS_CSS if getattr(app.config, "brainx_skip_fontawesome", True) else ""
    css_out.write_text(
        assets["header.css"] + _THEME_OVERRIDES + fa_css,
        encoding="utf-8",
    )
    js_out.write_text(
        _build_js(assets["header.html"], assets["header.js"], source_label),
        encoding="utf-8",
    )

    # Footer: append below the theme footer. The brand footer coexists with
    # the theme's own footer (bd-footer-content); _FOOTER_OVERRIDES zeroes
    # the top margin so the two sit flush instead of leaving a 6-8rem gap.
    footer_html = assets["footer.html"].replace("{{YEAR}}", str(time.gmtime().tm_year))
    footer_css_out.write_text(
        assets["footer.css"] + _FOOTER_OVERRIDES,
        encoding="utf-8",
    )
    footer_js_out.write_text(
        _build_footer_js(footer_html, source_label),
        encoding="utf-8",
    )


_FONTAWESOME_STUB = (
    "/* fontawesome.js stubbed by brainx-sphinx-header to save ~1.5MB. "
    "Set brainx_skip_fontawesome=False in conf.py to restore. */\n"
)


# ---------------------------------------------------------------------------
# SSR injection
# ---------------------------------------------------------------------------
#
# Why SSR on top of the JS injection: the JS path puts the header/footer in
# the DOM only after DOMContentLoaded, which means a one-frame flash where
# the page renders sans-header, and crawlers / no-JS clients / screen readers
# never see the brand chrome at all. The post-process below rewrites every
# built .html so the markup is in the document at first paint. The JS
# preamble in brainx-header.js / brainx-footer.js already self-skips when it
# sees a `[data-bx-header]` / `[data-bx-footer]` element, so it becomes a
# free fallback for any pages SSR couldn't touch.

_BODY_OPEN_RE = re.compile(r"(<body\b[^>]*>)", re.IGNORECASE)


def _ssr_inject_pages(app: Sphinx) -> None:
    cfg     = _resolve_config(app)
    confdir = Path(app.confdir)
    outdir  = Path(app.outdir)

    # Re-read the assets the builder fetched/cached earlier. With offline=True
    # we trust the on-disk cache populated by _on_builder_inited and never
    # re-fetch here (the build is finishing — no time for network surprises).
    if cfg["local"]:
        assets = _read_local(Path(cfg["local"]))
    else:
        assets = _load_with_cache(
            cfg["url"], confdir / CACHE_DIR_NAME, ttl=cfg["ttl"], offline=True,
        )

    header_html = assets["header.html"].strip()
    footer_html = assets["footer.html"].replace(
        "{{YEAR}}", str(time.gmtime().tm_year),
    ).strip()

    n_injected = 0
    n_skipped  = 0
    n_no_body  = 0

    for html_file in outdir.rglob("*.html"):
        # Skip theme/asset internals. sphinx_book_theme parks Jinja macro
        # templates here (e.g. webpack-macros.html) — they contain
        # `<body` inside comments but no `</body>`, and Sphinx never serves
        # them as pages. Touching them corrupts the macro and breaks the
        # next build.
        if "_static" in html_file.relative_to(outdir).parts:
            continue

        try:
            content = html_file.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue

        # Idempotency: never inject twice. Matches both SSR-injected and
        # JS-injected markers (same data attribute on both code paths).
        if "data-bx-header" in content and "data-bx-footer" in content:
            n_skipped += 1
            continue

        # Both anchors must exist. A file with only `<body` (and no closing
        # tag) is almost certainly a template fragment, not a real page.
        if "</body>" not in content or not _BODY_OPEN_RE.search(content):
            n_no_body += 1
            continue

        new_content = _BODY_OPEN_RE.sub(
            lambda m: m.group(1) + "\n" + header_html, content, count=1,
        )
        new_content = new_content.replace(
            "</body>", footer_html + "\n</body>", 1,
        )

        try:
            html_file.write_text(new_content, encoding="utf-8")
            n_injected += 1
        except OSError as e:
            print(f"[brainx-sphinx-header] SSR write failed for {html_file}: {e}")

    print(
        f"[brainx-sphinx-header] SSR injected header/footer into {n_injected} "
        f"page(s); {n_skipped} already-injected, {n_no_body} non-pages"
    )


def _on_html_page_context(
    app: Sphinx,
    pagename: str,
    templatename: str,
    context: dict,
    doctree,
) -> None:
    """Inject ``<base href="{html_baseurl}">`` into the docs site index page.

    Why this exists: a docs site lives at, e.g., ``/brainstate/`` on the server.
    Nginx normally 301-redirects ``/brainstate`` -> ``/brainstate/`` so that the
    relative URLs in the emitted HTML (``_static/``, sibling pages) resolve
    against the correct directory. When the server is configured to *also*
    serve the same content at ``/brainstate`` (no trailing slash) without a
    redirect, those relative URLs would otherwise resolve against the parent
    directory and 404.

    Injecting ``<base>`` into the index makes relative URLs resolve against
    ``html_baseurl`` regardless of whether the browser's address bar shows the
    trailing slash. We only touch ``index`` because every other page is
    accessed via a real path on disk (file or directory), so nginx's normal
    trailing-slash behavior keeps their relative URLs intact.

    Config:
        ``brainx_inject_base`` -- bool, default True. Set False to opt out.
    """
    if not getattr(app.config, "brainx_inject_base", True):
        return
    if pagename != "index":
        return
    base_url = (app.config.html_baseurl or "").strip()
    if not base_url:
        return
    if not base_url.endswith("/"):
        base_url += "/"
    tag = f'<base href="{base_url}">'
    existing = context.get("metatags") or ""
    if "<base " in existing:
        return
    context["metatags"] = existing + tag + "\n"


def _on_build_finished(app: Sphinx, exception: Exception | None) -> None:
    if exception is not None:
        return

    if getattr(app.config, "brainx_ssr_inject", True) and os.environ.get(
        "BRAINX_SSR_INJECT"
    ) != "0":
        try:
            _ssr_inject_pages(app)
        except Exception as e:
            print(
                f"[brainx-sphinx-header] SSR injection failed ({e}); "
                f"the JS fallback in brainx-header.js / brainx-footer.js "
                f"will still inject the markup on page load."
            )

    if not getattr(app.config, "brainx_skip_fontawesome", True):
        return
    if os.environ.get("BRAINX_SKIP_FONTAWESOME") == "0":
        return
    outdir = Path(app.outdir)
    targets = [
        outdir / "_static" / "scripts" / "fontawesome.js",
        outdir / "_static" / "scripts" / "fontawesome.js.map",
    ]
    for target in targets:
        if target.exists():
            try:
                before = target.stat().st_size
                target.write_text(_FONTAWESOME_STUB, encoding="utf-8")
                print(
                    f"[brainx-sphinx-header] stubbed {target.name}: "
                    f"{before} -> {target.stat().st_size} bytes"
                )
            except Exception as e:
                print(f"[brainx-sphinx-header] could not stub {target}: {e}")


def setup(app: Sphinx) -> dict:
    app.add_config_value("brainx_header_url",      DEFAULT_BASE, "html")
    app.add_config_value("brainx_header_ttl",      DEFAULT_TTL,  "html")
    app.add_config_value("brainx_header_offline",  False,        "html")
    app.add_config_value("brainx_header_local",    None,         "html")
    app.add_config_value("brainx_skip_fontawesome", True,        "html")
    app.add_config_value("brainx_inject_base",      True,        "html")
    app.add_config_value("brainx_ssr_inject",       True,        "html")

    app.connect("builder-inited",     _on_builder_inited)
    app.connect("html-page-context",  _on_html_page_context)
    app.connect("build-finished",     _on_build_finished)
    app.add_css_file(ARTIFACT_CSS)
    app.add_js_file(ARTIFACT_JS)
    app.add_css_file(ARTIFACT_FOOTER_CSS)
    app.add_js_file(ARTIFACT_FOOTER_JS)

    return {
        "version": __version__,
        "parallel_read_safe":  True,
        "parallel_write_safe": True,
    }
