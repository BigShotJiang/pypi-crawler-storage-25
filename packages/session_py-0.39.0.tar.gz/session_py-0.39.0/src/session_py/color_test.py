from .color import Color
from .mini_test import MINI_TEST
from .mini_test import MINI_CHECK
from .mini_test import run_all
from .tolerance import TOLERANCE


@MINI_TEST("Color", "Constructor")
def test_color_constructor():
    from session_py import Color

    # Constructor
    red = Color(255, 0, 0, 255, "red")

    # Setters
    red[0] = 255
    red[1] = 0
    red[2] = 0
    red[3] = 255

    # Getters
    r = red[0]
    g = red[1]
    b = red[2]
    a = red[3]

    # Minimal and Full String Representation
    cstr = str(red)
    crepr = repr(red)

    # Copy (duplicates everything except guid)
    ccopy = red.duplicate()
    cother = Color(255, 0, 0, 255, "red")

    MINI_CHECK(red.name == "red")
    MINI_CHECK(red.guid != "")
    MINI_CHECK(red[0] == 255)
    MINI_CHECK(red[1] == 0)
    MINI_CHECK(red[2] == 0)
    MINI_CHECK(red[3] == 255)
    MINI_CHECK(red.guid)

    MINI_CHECK(r == 255 and g == 0 and b == 0 and a == 255)
    MINI_CHECK(cstr == "255, 0, 0, 255")
    MINI_CHECK(crepr == "Color(red, 255, 0, 0, 255)")
    MINI_CHECK(ccopy == cother)
    MINI_CHECK(ccopy.guid != red.guid)


@MINI_TEST("Color", "Json Roundtrip")
def test_color_json_roundtrip():
    from session_py import Color
    from pathlib import Path

    c = Color(255, 128, 64, 255, "test_color")

    #   __jsondump__()  │ dict         │ to JSON object (internal use)
    #   __jsonload__(d) │ dict         │ from JSON object (internal use)
    #   json_dumps()    │ str          │ to JSON string
    #   json_loads(s)   │ str          │ from JSON string
    #   json_dump(path) │ file         │ write to file
    #   json_load(path) │ file         │ read from file

    # json_dump(fname) / json_load(fname) - file-based serialization
    fname = Path(__file__).resolve().parents[2] / "serialization" / "test_color.json"
    c.json_dump(fname)
    loaded = Color.json_load(fname)

    MINI_CHECK(loaded.name == "test_color")
    MINI_CHECK(loaded[0] == 255)
    MINI_CHECK(loaded[1] == 128)
    MINI_CHECK(loaded[2] == 64)
    MINI_CHECK(loaded[3] == 255)


@MINI_TEST("Color", "Protobuf Roundtrip")
def test_color_protobuf_roundtrip():
    from session_py import Color
    from pathlib import Path

    color = Color(255, 128, 64, 255, "test_color")

    #   pb_dumps()      │ bytes        │ to protobuf bytes
    #   pb_loads(b)     │ bytes        │ from protobuf bytes
    #   pb_dump(path)   │ file         │ write to file
    #   pb_load(path)   │ file         │ read from file

    path = Path(__file__).resolve().parents[2] / "serialization" / "test_color.bin"
    color.pb_dump(path)
    loaded = Color.pb_load(path)

    MINI_CHECK(loaded.name == "test_color")
    MINI_CHECK(loaded[0] == 255)
    MINI_CHECK(loaded[1] == 128)
    MINI_CHECK(loaded[2] == 64)
    MINI_CHECK(loaded[3] == 255)


@MINI_TEST("Color", "Conversion")
def test_color_conversion():
    from session_py import Color

    color = Color(255, 128, 64, 255)
    flts = color.to_unified_array()
    ints = Color.from_unified_array(flts)

    MINI_CHECK(TOLERANCE.is_close(flts[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(flts[1], 0.50196078))
    MINI_CHECK(TOLERANCE.is_close(flts[2], 0.25098039))
    MINI_CHECK(TOLERANCE.is_close(flts[3], 1.0))
    MINI_CHECK(ints == color)

@MINI_TEST("Color", "Presets")
def test_color_presets():
    from session_py import Color
    
    white = Color.white()
    black = Color.black()
    grey = Color.grey()
    red = Color.red()
    orange = Color.orange()
    yellow = Color.yellow()
    lime = Color.lime()
    green = Color.green()
    mint = Color.mint()
    cyan = Color.cyan()
    azure = Color.azure()
    blue = Color.blue()
    violet = Color.violet()
    magenta = Color.magenta()
    pink = Color.pink()
    maroon = Color.maroon()
    brown = Color.brown()
    olive = Color.olive()
    teal = Color.teal()
    navy = Color.navy()
    purple = Color.purple()
    silver = Color.silver()

    MINI_CHECK(white == Color(255, 255, 255, 255, "white"))
    MINI_CHECK(black == Color(0, 0, 0, 255, "black"))
    MINI_CHECK(grey == Color(128, 128, 128, 255, "grey"))
    MINI_CHECK(red == Color(255, 0, 0, 255, "red"))
    MINI_CHECK(orange == Color(255, 128, 0, 255, "orange"))
    MINI_CHECK(yellow == Color(255, 255, 0, 255, "yellow"))
    MINI_CHECK(lime == Color(128, 255, 0, 255, "lime"))
    MINI_CHECK(green == Color(0, 255, 0, 255, "green"))
    MINI_CHECK(mint == Color(0, 255, 128, 255, "mint"))
    MINI_CHECK(cyan == Color(0, 255, 255, 255, "cyan"))
    MINI_CHECK(azure == Color(0, 128, 255, 255, "azure"))
    MINI_CHECK(blue == Color(0, 0, 255, 255, "blue"))
    MINI_CHECK(violet == Color(128, 0, 255, 255, "violet"))
    MINI_CHECK(magenta == Color(255, 0, 255, 255, "magenta"))
    MINI_CHECK(pink == Color(255, 0, 128, 255, "pink"))
    MINI_CHECK(maroon == Color(128, 0, 0, 255, "maroon"))
    MINI_CHECK(brown == Color(128, 64, 0, 255, "brown"))
    MINI_CHECK(olive == Color(128, 128, 0, 255, "olive"))
    MINI_CHECK(teal == Color(0, 128, 128, 255, "teal"))
    MINI_CHECK(navy == Color(0, 0, 128, 255, "navy"))
    MINI_CHECK(purple == Color(128, 0, 128, 255, "purple"))
    MINI_CHECK(silver == Color(192, 192, 192, 255, "silver"))


if __name__ == "__main__":
    run_all(language="python")
