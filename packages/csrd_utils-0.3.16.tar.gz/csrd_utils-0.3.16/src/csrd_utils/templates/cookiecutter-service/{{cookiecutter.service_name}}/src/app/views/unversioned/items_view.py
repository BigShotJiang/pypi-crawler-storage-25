import uuid
from datetime import UTC, datetime

{%- if cookiecutter.has_delegates and not cookiecutter.has_database %}
import httpx
{%- endif %}

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

{%- if cookiecutter.has_database %}
from ...dependencies import RepositoryDep
{%- endif %}

ITEMS_ROUTE = "/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}"

{%- if cookiecutter.has_delegates and not cookiecutter.has_database %}
_UPSTREAMS = [entry.strip() for entry in "{{ cookiecutter.upstreams }}".split(",") if entry.strip()]
{%- elif not cookiecutter.has_database %}
_DUMMY_ITEMS: dict[str, dict[str, str]] = {}
{%- endif %}

router = APIRouter(prefix="/api", tags=["{{ cookiecutter.model_name_plural }} Endpoints"])


class Create{{ cookiecutter.model_name }}Request(BaseModel):
    name: str


class Update{{ cookiecutter.model_name }}Request(BaseModel):
    name: str


{%- if cookiecutter.has_delegates and not cookiecutter.has_database %}
async def _delegate_request(
    method: str,
    path: str,
    payload: dict[str, object] | None = None,
) -> dict[str, object]:
    if not _UPSTREAMS:
        raise HTTPException(status_code=503, detail="no upstreams configured")

    url = f"{_UPSTREAMS[0].rstrip('/')}{path}"
    async with httpx.AsyncClient(timeout=5.0) as client:
        response = await client.request(method, url, json=payload)

    if response.status_code == 404:
        raise HTTPException(status_code=404, detail="{{ cookiecutter.model_name | lower }} not found")
    if response.status_code >= 400:
        raise HTTPException(status_code=502, detail="delegate upstream request failed")

    body = response.json()
    if not isinstance(body, dict):
        raise HTTPException(status_code=502, detail="delegate upstream returned invalid payload")
    return body
{%- elif not cookiecutter.has_database %}
def _dummy_item(record_id: str, name: str, created_at: str) -> dict[str, str]:
    return {"id": record_id, "name": name, "created_at": created_at}
{%- endif %}


@router.post(ITEMS_ROUTE)
async def create_{{ cookiecutter.model_name | lower }}(
    payload: Create{{ cookiecutter.model_name }}Request,
    {%- if cookiecutter.has_database %}
    repo: RepositoryDep,
    {%- endif %}
) -> dict[str, str]:
    {%- if cookiecutter.has_database %}
    return await repo.create(payload.name)
    {%- elif cookiecutter.has_delegates %}
    delegated = await _delegate_request("POST", f"/api{ITEMS_ROUTE}", {"name": payload.name})
    return {
        "id": str(delegated.get("id", "")),
        "name": str(delegated.get("name", payload.name)),
        "created_at": str(delegated.get("created_at", "")),
    }
    {%- else %}
    record_id = str(uuid.uuid4())
    created_at = datetime.now(UTC).isoformat()
    item = _dummy_item(record_id, payload.name, created_at)
    _DUMMY_ITEMS[record_id] = item
    return item
    {%- endif %}


@router.get(ITEMS_ROUTE)
async def list_{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}(
    {%- if cookiecutter.has_database %}
    repo: RepositoryDep,
    {%- endif %}
) -> dict[str, list[dict[str, str]]]:
    {%- if cookiecutter.has_database %}
    return {"{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}": await repo.list()}
    {%- elif cookiecutter.has_delegates %}
    delegated = await _delegate_request("GET", f"/api{ITEMS_ROUTE}")
    items = delegated.get("{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}", [])
    if not isinstance(items, list):
        raise HTTPException(status_code=502, detail="delegate upstream returned invalid payload")
    normalized = [item for item in items if isinstance(item, dict)]
    return {"{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}": normalized}
    {%- else %}
    return {"{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}": list(_DUMMY_ITEMS.values())}
    {%- endif %}


@router.get(f"{ITEMS_ROUTE}/{entity_id}")
async def get_{{ cookiecutter.model_name | lower }}(
    entity_id: str,
    {%- if cookiecutter.has_database %}
    repo: RepositoryDep,
    {%- endif %}
) -> dict[str, str]:
    {%- if cookiecutter.has_database %}
    item = await repo.get(entity_id)
    {%- elif cookiecutter.has_delegates %}
    delegated = await _delegate_request("GET", f"/api{ITEMS_ROUTE}/{entity_id}")
    return {
        "id": str(delegated.get("id", entity_id)),
        "name": str(delegated.get("name", "")),
        "created_at": str(delegated.get("created_at", "")),
    }
    {%- else %}
    item = _DUMMY_ITEMS.get(entity_id)
    {%- endif %}
    if item is None:
        raise HTTPException(status_code=404, detail="{{ cookiecutter.model_name | lower }} not found")
    return item


@router.put(f"{ITEMS_ROUTE}/{entity_id}")
async def update_{{ cookiecutter.model_name | lower }}(
    entity_id: str,
    payload: Update{{ cookiecutter.model_name }}Request,
    {%- if cookiecutter.has_database %}
    repo: RepositoryDep,
    {%- endif %}
) -> dict[str, object]:
    {%- if cookiecutter.has_database %}
    rows = await repo.update(entity_id, payload.name)
    {%- elif cookiecutter.has_delegates %}
    delegated = await _delegate_request(
        "PUT",
        f"/api{ITEMS_ROUTE}/{entity_id}",
        {"name": payload.name},
    )
    return {
        "id": str(delegated.get("id", entity_id)),
        "name": str(delegated.get("name", payload.name)),
        "updated": bool(delegated.get("updated", True)),
    }
    {%- else %}
    item = _DUMMY_ITEMS.get(entity_id)
    rows = 0
    if item is not None:
        item["name"] = payload.name
        rows = 1
    {%- endif %}
    if rows == 0:
        raise HTTPException(status_code=404, detail="{{ cookiecutter.model_name | lower }} not found")
    return {"id": entity_id, "name": payload.name, "updated": True}


@router.put(f"{ITEMS_ROUTE}/{entity_id}/upsert")
async def upsert_{{ cookiecutter.model_name | lower }}(
    entity_id: str,
    payload: Update{{ cookiecutter.model_name }}Request,
    {%- if cookiecutter.has_database %}
    repo: RepositoryDep,
    {%- endif %}
) -> dict[str, object]:
    {%- if cookiecutter.has_database %}
    rows = await repo.upsert(entity_id, payload.name)
    {%- elif cookiecutter.has_delegates %}
    delegated = await _delegate_request(
        "PUT",
        f"/api{ITEMS_ROUTE}/{entity_id}/upsert",
        {"name": payload.name},
    )
    return {
        "id": str(delegated.get("id", entity_id)),
        "name": str(delegated.get("name", payload.name)),
        "rows_affected": int(delegated.get("rows_affected", 1)),
    }
    {%- else %}
    existing = _DUMMY_ITEMS.get(entity_id)
    if existing is None:
        created_at = datetime.now(UTC).isoformat()
        _DUMMY_ITEMS[entity_id] = _dummy_item(entity_id, payload.name, created_at)
    else:
        existing["name"] = payload.name
    rows = 1
    {%- endif %}
    return {"id": entity_id, "name": payload.name, "rows_affected": rows}


@router.delete(f"{ITEMS_ROUTE}/{entity_id}")
async def delete_{{ cookiecutter.model_name | lower }}(
    entity_id: str,
    {%- if cookiecutter.has_database %}
    repo: RepositoryDep,
    {%- endif %}
) -> dict[str, object]:
    {%- if cookiecutter.has_database %}
    rows = await repo.delete(entity_id)
    {%- elif cookiecutter.has_delegates %}
    delegated = await _delegate_request("DELETE", f"/api{ITEMS_ROUTE}/{entity_id}")
    return {
        "id": str(delegated.get("id", entity_id)),
        "deleted": bool(delegated.get("deleted", True)),
    }
    {%- else %}
    rows = 1 if _DUMMY_ITEMS.pop(entity_id, None) is not None else 0
    {%- endif %}
    if rows == 0:
        raise HTTPException(status_code=404, detail="{{ cookiecutter.model_name | lower }} not found")
    return {"id": entity_id, "deleted": True}
