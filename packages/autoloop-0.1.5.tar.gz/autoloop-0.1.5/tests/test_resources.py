from __future__ import annotations

from pathlib import Path
from importlib.resources import files


def test_packaged_plan_template_present():
    template = files("autoloop").joinpath("templates/plan_producer.md")
    assert template.is_file()


def test_packaged_audit_templates_present():
    templates = files("autoloop").joinpath("templates")
    assert templates.joinpath("audit_producer.md").is_file()
    assert templates.joinpath("audit_verifier.md").is_file()
    assert templates.joinpath("audit_criteria.md").is_file()


def test_packaged_agent_templates_do_not_reference_legacy_artifact_paths():
    templates = files("autoloop").joinpath("templates")
    for template in templates.iterdir():
        if template.name.endswith(".md"):
            text = template.read_text(encoding="utf-8")
            assert ".autoloop/" not in text, template.name
            assert "<phase-dir-key>" not in text, template.name
            assert "path/to/the/active" not in text, template.name


def test_readme_links_claude_rollout_checklist_with_repo_relative_path():
    repo_root = Path(__file__).resolve().parents[1]
    readme_text = (repo_root / "README.md").read_text(encoding="utf-8")

    assert "[docs/claude_rollout_checklist.md](docs/claude_rollout_checklist.md)" in readme_text
    assert "/workspace/superloop/docs/claude_rollout_checklist.md" not in readme_text
    assert (repo_root / "docs" / "claude_rollout_checklist.md").is_file()


def test_readme_quickstart_covers_first_run_resume_and_troubleshooting():
    repo_root = Path(__file__).resolve().parents[1]
    readme_text = (repo_root / "README.md").read_text(encoding="utf-8")

    assert "## Quickstart" in readme_text
    assert "provider:\n  name: codex" in readme_text
    assert "provider:\n  name: claude" in readme_text
    assert "autoloop --workspace /path/to/workspace --list-tasks" in readme_text
    assert "autoloop --workspace /path/to/workspace --task-id <task-id> --resume" in readme_text
    assert "| Symptom | Fix |" in readme_text
