"""Autoloop package."""
