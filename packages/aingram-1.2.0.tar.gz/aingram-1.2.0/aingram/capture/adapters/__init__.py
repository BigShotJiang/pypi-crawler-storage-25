"""Tool-specific capture adapters."""
