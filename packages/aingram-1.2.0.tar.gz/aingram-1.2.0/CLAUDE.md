# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

> **See also: `AGENTS.md`** — full module map, architecture invariants, and design rationale. Claude Code loads both files; this one stays lean.

Never force-push any documents (anything in docs/), without explicit instructions to so beforehand.

## Dev Setup

```bash
pip install -e ".[dev]"          # install all dev dependencies
```

The ONNX embedding model (Nomic MiniLM, 768-dim) downloads to `~/.aingram/models/` on first `MemoryStore` instantiation. Tests inject a `MockEmbedder` to skip this — preserve that pattern.

## Commands

```bash
pytest                            # run all tests
pytest tests/test_store_v3.py     # run a single file
pytest -x                         # stop on first failure
pytest -k "test_name"             # run tests matching pattern
ruff check .                      # lint
ruff check --fix .                # lint + auto-fix
ruff format .                     # format (single quotes, 100-char lines)
```

Integration adapters (LangChain, CrewAI, etc.) require their extras before testing:
```bash
pip install -e ".[langchain]"     # then pytest tests/test_integrations/
```

## Architecture

**Single public API surface.** `MemoryStore` (`aingram/store.py`) is the only sanctioned entry point for reads and writes. `StorageEngine` (`aingram/storage/engine.py`) is a threading-safe SQLite wrapper with no business logic — call its methods through `MemoryStore`, not directly from outside `storage/`.

**Data flow for `remember()`:**
1. Canonicalize + hash content → compute `entry_id` (content + parent IDs + pubkey)
2. Ed25519 sign the entry
3. Embed via `NomicEmbedder` (ONNX) → float32 vector
4. Encode QJL 1-bit projection → `qjl_bits`
5. Atomic write: `memory_entries` + `vec_entries` + `vec_entries_qjl` + FTS index

**Data flow for `recall()`:**
- `entry_count < 25K`: FTS pre-filter → adaptive KNN (filtered or full)
- `entry_count ≥ 25K`: Hamming coarse search on QJL bits → float32 re-rank on candidates
- Graph traversal runs in parallel; results merged via Reciprocal Rank Fusion

**Schema versioning.** Current version is in `SCHEMA_VERSION` (`storage/schema.py`). `apply_schema()` runs all migrations in order on open. Adding a table or column = bump version + add `_migrate_vN_to_vM(conn)`.

**Trust / append-only invariant.** Every entry is Ed25519-signed. The `entry_id` is a content-derived hash forming a DAG — post-write mutation is detectable. Consolidation creates *new* entries (`consolidated=1`), never mutates existing ones.

## Critical Invariants

These are non-obvious and cause silent bugs if violated:

1. **`threading.Lock` is non-reentrant.** `engine._lock` cannot be acquired twice on the same thread. Never call a method that acquires `_lock` from inside a `with engine._lock:` block (e.g. `_get_qjl_projection()` acquires the lock internally — call it *before* entering any lock block).

2. **vec0 virtual tables: no UPDATE on embedding columns.** sqlite-vec's `vec0` doesn't support `UPDATE`. Always `DROP TABLE` + recreate + re-insert (see `truncate_all_embeddings_to_dim()`).

3. **SQL `IN` clauses: chunk to ≤ 900 items.** SQLite's `SQLITE_LIMIT_VARIABLE_NUMBER` is 999. Use `_SQLITE_VAR_LIMIT = 900` from `engine.py`.

4. **FTS + KNN cannot be combined in sqlite-vec.** `MATCH` on a vec0 table cannot be filtered with `IN`. Workaround: fetch float32 blobs via `IN` on `vec_entries`, then compute cosine similarity in Python (`search_vectors_filtered()`).

5. **`background-clip: text` only clips an element's own text nodes**, not descendants. Apply gradient styles to the innermost element that directly holds the text (e.g. `<strong>`, not its parent `<td>`).

## Capture Daemon

Opt-in subsystem in `aingram/capture/` (requires `pip install aingram[capture]`). A Starlette/uvicorn HTTP daemon on `localhost:7749` receives tool-specific payloads from AI coding tools, normalizes through per-tool adapters into `CaptureRecord`, buffers in a separate SQLite WAL queue (`capture_queue.db`), and drains via `CaptureDrain` background thread calling `MemoryStore.remember()`. Seven adapters: Claude Code, Cursor, Gemini CLI, Aider (file watcher), Copilot (OTLP), Cline, ChatGPT (ZIP export). Filter pipeline: `@nocapture` opt-out, secret redaction, container tag resolution. CLI: `aingram capture start|stop|status|on|off|install`. Config: `[capture]` section in `config.toml` or `AINGRAM_CAPTURE_ENABLED`/`AINGRAM_CAPTURE_PORT` env vars. Disabled by default.

## Landing Page

Static HTML/CSS/JS in `landing_page/` deployed to Vercel. Auto-deploy on git push is **disabled** (`landing_page/vercel.json`). To deploy:

```bash
cd landing_page
vercel --prod
```

Serverless functions in `landing_page/api/` (Node.js) use `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY` injected by the Vercel–Supabase integration. There is no `package.json` for the landing page; functions use no npm dependencies.
