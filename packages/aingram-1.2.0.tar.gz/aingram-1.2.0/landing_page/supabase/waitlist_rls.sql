-- Enable RLS on the waitlist table (addresses Supabase security linter).
--
-- The site only talks to Supabase from Vercel serverless (`api/waitlist.js`) using
-- SUPABASE_SERVICE_ROLE_KEY. That role bypasses RLS, so inserts keep working without
-- any permissive anon/authenticated policies. Do not expose INSERT to `anon` unless
-- you have a client calling PostgREST directly (this project does not).

ALTER TABLE public.waitlist ENABLE ROW LEVEL SECURITY;
