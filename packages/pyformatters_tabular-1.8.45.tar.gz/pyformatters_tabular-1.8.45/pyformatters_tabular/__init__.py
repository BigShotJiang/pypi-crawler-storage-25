"""Sherpa Tabular formatter"""

__version__ = "1.8.45"
