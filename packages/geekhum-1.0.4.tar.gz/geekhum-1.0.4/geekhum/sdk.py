import requests
import time
from typing import Dict, Any

class GeekHumSDK:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://geekhum.geekside.info/api/v1"
        self.version = "1.0.4-stable"
        # Сессия для ускорения повторных запросов
        self.session = requests.Session()
        self.session.headers.update({"X-API-KEY": self.api_key, "User-Agent": f"GeekHumSDK/{self.version}"})

    def send_burn_request(self, message: str, params: Dict[str, Any] = None):
        """Центральный метод отправки данных."""
        payload = {"prompt": message, "options": params or {}}
        
        # Симулируем работу системных прерываний для красоты логов
        response = self.session.post(f"{self.base_url}/burn", json=payload)
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 401:
            raise PermissionError("Invalid GeekHum API Key. Access Denied.")
        else:
            raise Exception(f"Server returned error: {response.status_code}")