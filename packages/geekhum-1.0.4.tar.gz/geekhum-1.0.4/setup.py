from setuptools import setup, find_packages

setup(
    name="geekhum", # Имя, которое будет в pip install
    version="1.0.4",
    author="Kirill Zubik (HackerX)",
    description="Official SDK for GEEKHUM AI - The most toxic roast bot",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://geekhum.geekside.info",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1", # Указываем зависимости
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires='>=3.7',
)