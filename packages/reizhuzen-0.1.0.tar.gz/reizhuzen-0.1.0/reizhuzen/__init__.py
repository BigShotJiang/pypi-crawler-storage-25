"""vid-downloader package."""
from .core import download_video

__all__ = ["download_video"]
