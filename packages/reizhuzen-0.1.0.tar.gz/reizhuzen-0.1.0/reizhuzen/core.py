import yt_dlp
import os

def download_video(url, output_path=None, audio_only=False, download_playlist=False):
    """
    Download a video from YouTube or Instagram using yt-dlp.
    """
    # Determine the target folder based on the download type
    base_path = output_path if output_path else '.'
    folder_name = 'Audio' if audio_only else 'Video'
    final_output_path = os.path.join(base_path, folder_name)
    
    # Ensure the directory exists
    os.makedirs(final_output_path, exist_ok=True)

    ydl_opts = {
        'outtmpl': os.path.join(final_output_path, '%(title)s.%(ext)s'),
        'noplaylist': not download_playlist,
        'ignoreerrors': True,  # Keep going if an item in the playlist errors
    }

    if audio_only:
        ydl_opts.update({
            'format': 'bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
        })
    else:
        ydl_opts.update({
            'format': 'best'
        })
        
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            print(f"Starting download for: {url}")
            error_code = ydl.download([url])
            return error_code == 0
    except Exception as e:
        print(f"An error occurred: {e}")
        return False
