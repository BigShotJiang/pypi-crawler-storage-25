import click
import sys
from .core import download_video

@click.command()
@click.argument('url')
@click.option('--output', '-o', default=None, help='Output directory for the downloaded file')
@click.option('--audio', '-a', is_flag=True, help='Extract audio only (mp3)')
@click.option('--playlist', '-p', is_flag=True, help='Download the entire playlist if the URL contains one')
def main(url, output, audio, playlist):
    """
    Download a video from YouTube, Instagram, and more!
    """
    success = download_video(url, output_path=output, audio_only=audio, download_playlist=playlist)
    if success:
        click.secho("Download completed successfully!", fg="green")
    else:
        click.secho("Download failed.", fg="red")
        sys.exit(1)

if __name__ == "__main__":
    main()
