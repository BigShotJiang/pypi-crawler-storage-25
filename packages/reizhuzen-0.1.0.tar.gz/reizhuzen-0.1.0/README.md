# Reizhuzen Video Downloader

A minimal and robust Python package built on top of `yt-dlp` for intelligently downloading videos and audio from YouTube and Instagram.

## Core Features
- 🎥 Download videos intelligently with automated selection logic.
- 🎵 Extract MP3 audio from any supported video, music-mix, or reel.
- 📁 Automatic folder curation which sends downloads to `Audio/` and `Video/` directories.
- ⚡ Smart playlist skipping ensures you don't accidentally download infinite YouTube Mixes unless explicitly requested.

---

## 🚀 Installation

Because this is packaged as a standard Python module, you can install it into any Python environment using `pip`. 

Open your terminal in this package's directory and run:

```bash
# Standard install
pip install .

# For development (updates automatically when you change the .py files)
pip install -e .
```

---

## 💻 How to Use (Command Line)

Once installed, the `reizhuzen` command is registered globally on your system. You can invoke it from any directory in your terminal!

### 1. Download a Video
Simply pass the URL to the command:
```bash
reizhuzen "https://www.youtube.com/watch?v=your_video_id"
```
✅ Your download will be saved automatically inside a `Video/` folder in your current directory.

### 2. Download Audio Only
Pass the `-a` (or `--audio`) flag to extract just the MP3:
```bash
reizhuzen "https://www.instagram.com/reel/your_audio_clip" --audio
```
✅ Your download will be saved automatically inside an `Audio/` folder.

### 3. Specify an Output Path
Pass the `-o` (or `--output`) argument to pick exactly where the `Video/` or `Audio/` folders should be generated:
```bash
reizhuzen "https://www.youtube.com/watch?v=..." -o "C:\My\Custom\Folder"
```

### 4. Download a Full Playlist
If you paste a YouTube link that contains a playlist (e.g. `&list=RD...`), Reizhuzen will ignore the playlist and only download the specific video you requested to prevent downloading 100+ items by accident.

If you explicitly **want** to download the whole playlist, you must pass the `--playlist` (or `-p`) flag:
```bash
reizhuzen "https://www.youtube.com/watch?v=...&list=..." --playlist
```

You can view the full help menu at any time by running:
```bash
reizhuzen --help
```

---

## 🐍 Using as a Python Library

Because this is a real python package, you can just import it into any other python script you write on your machine!

```python
from reizhuzen import download_video

print("Starting custom download process...")

# Download
success = download_video(
    url="https://www.youtube.com/watch?v=...", 
    output_path="./my_cool_assets", 
    audio_only=True,
    download_playlist=False
)

if success:
    print("Files acquired successfully!")
```
