from __future__ import annotations

from typing import Optional

from .lib.http import HttpClient
from .resources.scrape import ScrapeResource
from .resources.batch import BatchResource
from .resources.crawl import CrawlResource
from .resources.logs import LogsResource
from .resources.usage import UsageResource
from .types.client import SpidraConfig


class SpidraClient:
    """
    The official Spidra Python SDK client.

    Mirrors the JS ``SpidraClient`` in src/client.ts.

    Usage::

        import asyncio
        from spidra import SpidraClient, ScrapeParams, ScrapeUrl

        async def main():
            spidra = SpidraClient(api_key="spd_YOUR_API_KEY")
            job = await spidra.scrape.run(ScrapeParams(
                urls=[ScrapeUrl(url="https://news.ycombinator.com")],
                prompt="List the top 5 stories with title, points, and comment count",
                output="json",
            ))
            print(job.result.content)

        asyncio.run(main())

    Use as an async context manager to ensure connections are closed::

        async with SpidraClient(api_key="spd_YOUR_API_KEY") as spidra:
            job = await spidra.scrape.run(...)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.spidra.io/api",
        session: Optional[object] = None,
    ) -> None:
        config = SpidraConfig(api_key=api_key, base_url=base_url, session=session)
        http = HttpClient(config)

        self.scrape = ScrapeResource(http)
        self.batch = BatchResource(http)
        self.crawl = CrawlResource(http)
        self.logs = LogsResource(http)
        self.usage = UsageResource(http)

        self._http = http

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> "SpidraClient":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()
