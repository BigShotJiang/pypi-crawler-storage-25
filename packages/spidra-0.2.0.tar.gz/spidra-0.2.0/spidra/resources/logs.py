from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional

from ..lib.http import HttpClient
from ..types.logs import (
    ScrapeLogsParams,
    ScrapeLogsResponse,
    ScrapeLog,
    ScrapeLogDetail,
)


def _parse_log(raw: Dict[str, Any]) -> ScrapeLog:
    return ScrapeLog(
        uuid=raw.get("uuid", ""),
        urls=raw.get("urls", []),
        status=raw.get("status", "failed"),
        extraction_prompt=raw.get("extraction_prompt"),
        credits_used=raw.get("credits_used"),
        started_at=raw.get("started_at"),
        finished_at=raw.get("finished_at"),
        error_message=raw.get("error_message"),
        input_tokens=raw.get("input_tokens"),
        output_tokens=raw.get("output_tokens"),
        tokens_used=raw.get("tokens_used"),
        latency_ms=raw.get("latency_ms"),
        ai_output_format=raw.get("ai_output_format"),
        use_proxy=raw.get("use_proxy"),
        proxy_country=raw.get("proxy_country"),
    )


class LogsResource:
    """
    Logs resource — mirrors JS ``LogsResource`` in src/resources/logs.ts.

    Usage::

        response = await spidra.logs.list(ScrapeLogsParams(status="failed", limit=20))
        for log in response.logs:
            print(log.uuid, log.status)
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(
        self, params: Optional[ScrapeLogsParams] = None
    ) -> ScrapeLogsResponse:
        """List scrape logs for the authenticated user with optional filters."""
        p = params or ScrapeLogsParams()
        qs_parts = []
        if p.status:
            qs_parts.append(f"status={p.status}")
        if p.search_term:
            qs_parts.append(f"searchTerm={p.search_term}")
        if p.limit is not None:
            qs_parts.append(f"limit={p.limit}")
        if p.page is not None:
            qs_parts.append(f"page={p.page}")
        if p.channel:
            qs_parts.append(f"channel={p.channel}")
        if p.date_start:
            qs_parts.append(f"dateStart={p.date_start}")
        if p.date_end:
            qs_parts.append(f"dateEnd={p.date_end}")
        qs = f"?{'&'.join(qs_parts)}" if qs_parts else ""

        data = await self._http.get(f"/scrape-logs{qs}")
        inner = data.get("data", data)  # API wraps response in { status, data }
        logs = [_parse_log(r) for r in inner.get("logs", [])]
        return ScrapeLogsResponse(logs=logs, total=inner.get("total", 0))

    def list_sync(
        self, params: Optional[ScrapeLogsParams] = None
    ) -> ScrapeLogsResponse:
        """Synchronous version of :meth:`list`."""
        return asyncio.run(self.list(params))

    async def get(self, uuid: str) -> ScrapeLogDetail:
        """Get a single scrape log by UUID, including the full AI extraction result."""
        data = await self._http.get(f"/scrape-logs/{uuid}")
        inner = data.get("data", data)
        base = _parse_log(inner)
        return ScrapeLogDetail(
            uuid=base.uuid,
            urls=base.urls,
            status=base.status,
            extraction_prompt=base.extraction_prompt,
            credits_used=base.credits_used,
            started_at=base.started_at,
            finished_at=base.finished_at,
            error_message=base.error_message,
            input_tokens=base.input_tokens,
            output_tokens=base.output_tokens,
            tokens_used=base.tokens_used,
            latency_ms=base.latency_ms,
            ai_output_format=base.ai_output_format,
            use_proxy=base.use_proxy,
            proxy_country=base.proxy_country,
            result_data=inner.get("result_data"),
        )

    def get_sync(self, uuid: str) -> ScrapeLogDetail:
        """Synchronous version of :meth:`get`."""
        return asyncio.run(self.get(uuid))
