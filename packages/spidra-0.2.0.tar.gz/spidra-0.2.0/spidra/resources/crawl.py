from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional, cast

from ..lib.http import HttpClient
from ..lib.poll import PollOptions, poll
from ..types.crawl import (
    CrawlParams,
    CrawlQueued,
    CrawlJobResponse,
    CrawlJobCompleted,
    CrawlJobFailed,
    CrawlJobPending,
    CrawlPageResult,
    CrawlPage,
    CrawlPagesResponse,
    CrawlHistoryParams,
    CrawlHistoryEntry,
    CrawlHistoryResponse,
    CrawlStats,
)


def _crawl_params_to_dict(params: CrawlParams) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "baseUrl": params.base_url,
        "crawlInstruction": params.crawl_instruction,
        "transformInstruction": params.transform_instruction,
    }
    if params.max_pages is not None:
        body["maxPages"] = params.max_pages
    if params.use_proxy is not None:
        body["useProxy"] = params.use_proxy
    if params.proxy_country is not None:
        body["proxyCountry"] = params.proxy_country
    if params.cookies is not None:
        body["cookies"] = params.cookies
    return body


def _parse_crawl_job(data: Dict[str, Any]) -> CrawlJobResponse:
    status = data.get("status", "")

    if status in ("waiting", "active", "running"):
        return CrawlJobPending(status=status, progress=data.get("progress"))

    if status == "completed":
        pages = [
            CrawlPageResult(
                url=p.get("url", ""),
                title=p.get("title"),
                data=p.get("data"),
            )
            for p in data.get("result", [])
        ]
        return CrawlJobCompleted(status="completed", result=pages)

    if status == "failed":
        return CrawlJobFailed(status="failed", error=data.get("error"))

    return CrawlJobPending(status=cast(Any, status))


class CrawlResource:
    """
    Crawl resource — mirrors JS ``CrawlResource`` in src/resources/crawl.ts.

    Usage::

        job = await spidra.crawl.run(CrawlParams(
            base_url="https://example.com/blog",
            crawl_instruction="Find all blog posts from 2024",
            transform_instruction="Extract title, author, and summary",
            max_pages=30,
        ))
        for page in job.result:
            print(page.url, page.data)
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def history(
        self, params: Optional[CrawlHistoryParams] = None
    ) -> CrawlHistoryResponse:
        """List past crawl jobs for the authenticated user, newest first."""
        p = params or CrawlHistoryParams()
        qs_parts = []
        if p.page is not None:
            qs_parts.append(f"page={p.page}")
        if p.limit is not None:
            qs_parts.append(f"limit={p.limit}")
        qs = f"?{'&'.join(qs_parts)}" if qs_parts else ""
        data = await self._http.get(f"/crawl/history{qs}")

        jobs = [
            CrawlHistoryEntry(
                id=j.get("id", ""),
                base_url=j.get("base_url", ""),
                crawl_instruction=j.get("crawl_instruction", ""),
                transform_instruction=j.get("transform_instruction", ""),
                max_pages=j.get("max_pages", 0),
                status=j.get("status", ""),
                created_at=j.get("created_at", ""),
                updated_at=j.get("updated_at", ""),
                pages_crawled=j.get("pages_crawled", 0),
                credits_used=j.get("credits_used"),
            )
            for j in data.get("jobs", [])
        ]
        return CrawlHistoryResponse(
            jobs=jobs,
            total=data.get("total", 0),
            page=data.get("page", 1),
            total_pages=data.get("totalPages", 0),
        )

    def history_sync(
        self, params: Optional[CrawlHistoryParams] = None
    ) -> CrawlHistoryResponse:
        """Synchronous version of :meth:`history`."""
        return asyncio.run(self.history(params))

    async def stats(self) -> CrawlStats:
        """Get the total crawl job count for the authenticated user."""
        data = await self._http.get("/crawl/stats")
        return CrawlStats(total=data.get("total", 0))

    def stats_sync(self) -> CrawlStats:
        """Synchronous version of :meth:`stats`."""
        return asyncio.run(self.stats())

    async def submit(self, params: CrawlParams) -> CrawlQueued:
        """Submit a crawl job. Returns a job_id immediately."""
        data = await self._http.post("/crawl", _crawl_params_to_dict(params))
        return CrawlQueued(status="queued", job_id=data["jobId"])

    def submit_sync(self, params: CrawlParams) -> CrawlQueued:
        """Synchronous version of :meth:`submit`."""
        return asyncio.run(self.submit(params))

    async def get(self, job_id: str) -> CrawlJobResponse:
        """Get the current status of a crawl job."""
        data = await self._http.get(f"/crawl/{job_id}")
        return _parse_crawl_job(data)

    def get_sync(self, job_id: str) -> CrawlJobResponse:
        """Synchronous version of :meth:`get`."""
        return asyncio.run(self.get(job_id))

    async def pages(self, job_id: str) -> CrawlPagesResponse:
        """Get crawled pages with signed S3 download URLs (expire after 1 hour)."""
        data = await self._http.get(f"/crawl/{job_id}/pages")
        pages = [
            CrawlPage(
                id=p.get("id", ""),
                url=p.get("url", ""),
                title=p.get("title"),
                status=p.get("status", "failed"),
                data=p.get("data"),
                error_message=p.get("error_message"),
                html_url=p.get("html_url"),
                markdown_url=p.get("markdown_url"),
                created_at=p.get("created_at", ""),
            )
            for p in data.get("pages", [])
        ]
        return CrawlPagesResponse(pages=pages)

    def pages_sync(self, job_id: str) -> CrawlPagesResponse:
        """Synchronous version of :meth:`pages`."""
        return asyncio.run(self.pages(job_id))

    async def extract(self, job_id: str, transform_instruction: str) -> CrawlQueued:
        """
        Re-extract data from an existing crawl using a new instruction.
        Does not re-crawl pages — only charges credits for the transformation.
        """
        data = await self._http.post(
            f"/crawl/{job_id}/extract",
            {"transformInstruction": transform_instruction},
        )
        return CrawlQueued(status="queued", job_id=data["jobId"])

    def extract_sync(self, job_id: str, transform_instruction: str) -> CrawlQueued:
        """Synchronous version of :meth:`extract`."""
        return asyncio.run(self.extract(job_id, transform_instruction))

    async def run(
        self,
        params: CrawlParams,
        options: Optional[PollOptions] = None,
    ) -> CrawlJobCompleted:
        """Submit a crawl job and wait for it to complete."""
        queued = await self.submit(params)

        result = await poll(lambda: self.get(queued.job_id), options)

        if result.status == "failed":
            raise RuntimeError(
                getattr(result, "error", None) or "Crawl job failed"
            )

        return cast(CrawlJobCompleted, result)

    def run_sync(
        self,
        params: CrawlParams,
        options: Optional[PollOptions] = None,
    ) -> CrawlJobCompleted:
        """Synchronous version of :meth:`run`."""
        return asyncio.run(self.run(params, options))
