from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional, cast

from ..lib.http import HttpClient, _snake_to_camel
from ..lib.poll import PollOptions, poll
from ..types.batch import (
    BatchScrapeParams,
    BatchScrapeQueued,
    BatchScrapeResponse,
    BatchCancelResponse,
    BatchListParams,
    BatchListEntry,
    BatchListPagination,
    BatchListResponse,
    BatchItem,
)


def _batch_params_to_dict(params: BatchScrapeParams) -> Dict[str, Any]:
    body: Dict[str, Any] = {"urls": params.urls, "prompt": params.prompt}
    if params.output is not None:
        body["output"] = params.output
    if params.schema is not None:
        body["schema"] = params.schema
    if params.use_proxy is not None:
        body["useProxy"] = params.use_proxy
    if params.proxy_country is not None:
        body["proxyCountry"] = params.proxy_country
    if params.extract_content_only is not None:
        body["extractContentOnly"] = params.extract_content_only
    if params.screenshot is not None:
        body["screenshot"] = params.screenshot
    if params.full_page_screenshot is not None:
        body["fullPageScreenshot"] = params.full_page_screenshot
    if params.cookies is not None:
        body["cookies"] = params.cookies
    return body


def _parse_batch_response(data: Dict[str, Any]) -> BatchScrapeResponse:
    items = [
        BatchItem(
            uuid=i.get("uuid", ""),
            url=i.get("url", ""),
            job_id=i.get("jobId"),
            status=i.get("status", "pending"),
            result=i.get("result"),
            credits_used=i.get("creditsUsed", 0),
            started_at=i.get("startedAt"),
            finished_at=i.get("finishedAt"),
            screenshot_url=i.get("screenshotUrl"),
            error=i.get("error"),
        )
        for i in data.get("items", [])
    ]
    return BatchScrapeResponse(
        status=data.get("status", "pending"),
        total_urls=data.get("totalUrls", 0),
        completed_count=data.get("completedCount", 0),
        failed_count=data.get("failedCount", 0),
        created_at=data.get("createdAt", ""),
        finished_at=data.get("finishedAt"),
        items=items,
    )


class BatchResource:
    """
    Batch scrape resource — mirrors JS ``BatchResource`` in src/resources/batch.ts.

    Usage::

        batch = await spidra.batch.run(BatchScrapeParams(
            urls=["https://example.com/1", "https://example.com/2"],
            prompt="Extract the page title",
        ))
        for item in batch.items:
            print(item.url, item.status)
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(self, params: Optional[BatchListParams] = None) -> BatchListResponse:
        """List all batch jobs for the authenticated user, newest first."""
        p = params or BatchListParams()
        qs_parts = []
        if p.page is not None:
            qs_parts.append(f"page={p.page}")
        if p.limit is not None:
            qs_parts.append(f"limit={p.limit}")
        qs = f"?{'&'.join(qs_parts)}" if qs_parts else ""
        data = await self._http.get(f"/batch/scrape{qs}")

        jobs = [
            BatchListEntry(
                uuid=j.get("uuid", ""),
                status=j.get("status", "pending"),
                total_urls=j.get("totalUrls", 0),
                completed_count=j.get("completedCount", 0),
                failed_count=j.get("failedCount", 0),
                output_format=j.get("outputFormat", ""),
                scraping_channel=j.get("scrapingChannel", ""),
                created_at=j.get("createdAt", ""),
                finished_at=j.get("finishedAt"),
            )
            for j in data.get("jobs", [])
        ]
        pg = data.get("pagination", {})
        pagination = BatchListPagination(
            page=pg.get("page", 1),
            limit=pg.get("limit", 20),
            total=pg.get("total", 0),
            total_pages=pg.get("totalPages", 0),
        )
        return BatchListResponse(jobs=jobs, pagination=pagination)

    def list_sync(self, params: Optional[BatchListParams] = None) -> BatchListResponse:
        """Synchronous version of :meth:`list`."""
        return asyncio.run(self.list(params))

    async def submit(self, params: BatchScrapeParams) -> BatchScrapeQueued:
        """Submit a batch of URLs. Returns a batch_id immediately."""
        data = await self._http.post("/batch/scrape", _batch_params_to_dict(params))
        return BatchScrapeQueued(
            status="queued",
            batch_id=data["batchId"],
            total=data.get("total", len(params.urls)),
        )

    def submit_sync(self, params: BatchScrapeParams) -> BatchScrapeQueued:
        """Synchronous version of :meth:`submit`."""
        return asyncio.run(self.submit(params))

    async def get(self, batch_id: str) -> BatchScrapeResponse:
        """Get the current status of a batch job."""
        data = await self._http.get(f"/batch/scrape/{batch_id}")
        return _parse_batch_response(data)

    def get_sync(self, batch_id: str) -> BatchScrapeResponse:
        """Synchronous version of :meth:`get`."""
        return asyncio.run(self.get(batch_id))

    async def retry(self, batch_id: str) -> Dict[str, int]:
        """Retry all failed items in a batch."""
        data = await self._http.post(f"/batch/scrape/{batch_id}/retry", {})
        return {"retried_count": data.get("retriedCount", 0)}

    def retry_sync(self, batch_id: str) -> Dict[str, int]:
        """Synchronous version of :meth:`retry`."""
        return asyncio.run(self.retry(batch_id))

    async def cancel(self, batch_id: str) -> BatchCancelResponse:
        """Cancel a pending or active batch. Credits for unprocessed items are refunded."""
        data = await self._http.delete(f"/batch/scrape/{batch_id}")
        return BatchCancelResponse(
            status="cancelled",
            cancelled_items=data.get("cancelledItems", 0),
            credits_refunded=data.get("creditsRefunded", 0),
        )

    def cancel_sync(self, batch_id: str) -> BatchCancelResponse:
        """Synchronous version of :meth:`cancel`."""
        return asyncio.run(self.cancel(batch_id))

    async def run(
        self,
        params: BatchScrapeParams,
        options: Optional[PollOptions] = None,
    ) -> BatchScrapeResponse:
        """Submit a batch and wait for it to reach a terminal status."""
        queued = await self.submit(params)
        return cast(BatchScrapeResponse, await poll(lambda: self.get(queued.batch_id), options))

    def run_sync(
        self,
        params: BatchScrapeParams,
        options: Optional[PollOptions] = None,
    ) -> BatchScrapeResponse:
        """Synchronous version of :meth:`run`."""
        return asyncio.run(self.run(params, options))
