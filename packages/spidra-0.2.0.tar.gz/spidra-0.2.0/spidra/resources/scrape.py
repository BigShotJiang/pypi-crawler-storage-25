from __future__ import annotations

import asyncio
import dataclasses
from typing import Any, Dict, Optional, cast

from ..lib.http import HttpClient, _serialize, _snake_to_camel
from ..lib.poll import PollOptions, poll
from ..types.scrape import (
    ScrapeParams,
    ScrapeJobQueued,
    ScrapeJobCompleted,
    ScrapeJobFailed,
    ScrapeJobResponse,
    ScrapeResult,
    ScrapeResultStats,
    ScrapeUrlResult,
    ScrapeJobPending,
)


def _parse_scrape_job(data: Dict[str, Any]) -> ScrapeJobResponse:
    """Convert a raw API dict into a typed ScrapeJobResponse."""
    status = data.get("status", "")

    if status in ("waiting", "active"):
        return ScrapeJobPending(
            status=status,
            progress=data.get("progress"),
        )

    if status == "completed":
        raw_result = data.get("result", {})
        raw_stats = raw_result.get("stats", {})
        result = ScrapeResult(
            content=raw_result.get("content"),
            data=[
                ScrapeUrlResult(
                    url=u.get("url", ""),
                    success=u.get("success", False),
                    title=u.get("title"),
                    markdown_content=u.get("markdownContent"),
                    screenshot_url=u.get("screenshotUrl"),
                )
                for u in raw_result.get("data", [])
            ],
            screenshots=raw_result.get("screenshots", []),
            ai_extraction_failed=raw_result.get("ai_extraction_failed", False),
            stats=ScrapeResultStats(
                duration_ms=raw_stats.get("durationMs", 0),
                captcha_solved_count=raw_stats.get("captchaSolvedCount", 0),
                input_tokens=raw_stats.get("inputTokens", 0),
                output_tokens=raw_stats.get("outputTokens", 0),
                total_tokens=raw_stats.get("totalTokens", 0),
            ),
        )
        return ScrapeJobCompleted(
            status="completed",
            result=result,
            error=None,
            progress=data.get("progress"),
        )

    if status == "failed":
        return ScrapeJobFailed(
            status="failed",
            error=data.get("error", "Scrape job failed"),
        )

    # Fallback — treat unknown status as still pending
    return ScrapeJobPending(status=cast(Any, status))


def _params_to_dict(params: ScrapeParams) -> Dict[str, Any]:
    """Serialise ScrapeParams to camelCase dict for the REST API."""
    urls = []
    for su in params.urls:
        entry: Dict[str, Any] = {"url": su.url}
        if su.actions:
            entry["actions"] = [_action_to_dict(a) for a in su.actions]
        if su.instruction is not None:
            entry["instruction"] = su.instruction
        urls.append(entry)

    body: Dict[str, Any] = {"urls": urls, "prompt": params.prompt}
    if params.output is not None:
        body["output"] = params.output
    if params.schema is not None:
        body["schema"] = params.schema
    if params.use_proxy is not None:
        body["useProxy"] = params.use_proxy
    if params.proxy_country is not None:
        body["proxyCountry"] = params.proxy_country
    if params.extract_content_only is not None:
        body["extractContentOnly"] = params.extract_content_only
    if params.screenshot is not None:
        body["screenshot"] = params.screenshot
    if params.full_page_screenshot is not None:
        body["fullPageScreenshot"] = params.full_page_screenshot
    if params.cookies is not None:
        body["cookies"] = params.cookies
    return body


def _action_to_dict(action: Any) -> Dict[str, Any]:
    """Recursively convert a BrowserAction dataclass to a camelCase dict."""
    if dataclasses.is_dataclass(action) and not isinstance(action, type):
        raw = dataclasses.asdict(action)
    else:
        raw = dict(action)

    result: Dict[str, Any] = {}
    key_map = {
        "capture_selector": "captureSelector",
        "max_items": "maxItems",
        "wait_after_click": "waitAfterClick",
        "item_prompt": "itemPrompt",
        "next_selector": "nextSelector",
        "max_pages": "maxPages",
    }
    for k, v in raw.items():
        if v is None:
            continue
        camel = key_map.get(k, _snake_to_camel(k))
        if k == "actions" and isinstance(v, list):
            result[camel] = [_action_to_dict(a) for a in v]
        elif k == "pagination" and isinstance(v, dict):
            pg: Dict[str, Any] = {}
            if v.get("next_selector") is not None:
                pg["nextSelector"] = v["next_selector"]
            if v.get("max_pages") is not None:
                pg["maxPages"] = v["max_pages"]
            result[camel] = pg
        else:
            result[camel] = v
    return result


class ScrapeResource:
    """
    Scrape resource — mirrors JS ``ScrapeResource`` in src/resources/scrape.ts.

    Usage::

        job = await spidra.scrape.run(ScrapeParams(...))
        print(job.result.content)
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def submit(self, params: ScrapeParams) -> ScrapeJobQueued:
        """Submit a scrape job. Returns a job_id immediately without waiting."""
        data = await self._http.post("/scrape", _params_to_dict(params))
        return ScrapeJobQueued(status="queued", job_id=data["jobId"])

    def submit_sync(self, params: ScrapeParams) -> ScrapeJobQueued:
        """Synchronous version of :meth:`submit`."""
        return asyncio.run(self.submit(params))

    async def get(self, job_id: str) -> ScrapeJobResponse:
        """Get the current status of a previously submitted scrape job."""
        data = await self._http.get(f"/scrape/{job_id}")
        return _parse_scrape_job(data)

    def get_sync(self, job_id: str) -> ScrapeJobResponse:
        """Synchronous version of :meth:`get`."""
        return asyncio.run(self.get(job_id))

    async def run(
        self,
        params: ScrapeParams,
        options: Optional[PollOptions] = None,
    ) -> ScrapeJobCompleted:
        """
        Submit a scrape job and block until it completes.

        Raises:
            RuntimeError: if the job fails.
            TimeoutError: if the job does not complete within ``options.timeout`` seconds.
        """
        queued = await self.submit(params)

        result = await poll(lambda: self.get(queued.job_id), options)

        if result.status == "failed":
            raise RuntimeError(
                getattr(result, "error", None) or "Scrape job failed"
            )

        return cast(ScrapeJobCompleted, result)

    def run_sync(
        self,
        params: ScrapeParams,
        options: Optional[PollOptions] = None,
    ) -> ScrapeJobCompleted:
        """Synchronous version of :meth:`run`."""
        return asyncio.run(self.run(params, options))
