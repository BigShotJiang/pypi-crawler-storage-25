from __future__ import annotations

import asyncio
from typing import List

from ..lib.http import HttpClient
from ..types.usage import UsageRange, UsageStatRow


class UsageResource:
    """
    Usage resource — mirrors JS ``UsageResource`` in src/resources/usage.ts.

    Usage::

        rows = await spidra.usage.get("30d")
        for row in rows:
            print(row.date, row.requests, row.credits)
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def get(self, range: UsageRange) -> List[UsageStatRow]:
        """
        Get usage statistics for the given time range.

        - ``"7d"``     — last 7 days, one row per day
        - ``"30d"``    — last 30 days, one row per day
        - ``"weekly"`` — last 7 weeks, one row per week
        """
        data = await self._http.get(f"/usage-stats?range={range}")
        inner = data.get("data", data)  # API wraps in { status, data }
        return [
            UsageStatRow(
                label=r.get("label", ""),
                date=r.get("date", ""),
                tokens=r.get("tokens", 0),
                requests=r.get("requests", 0),
                crawls=r.get("crawls", 0),
                captchas=r.get("captchas", 0),
                latency=r.get("latency", 0.0),
                credits=r.get("credits", 0.0),
            )
            for r in (inner if isinstance(inner, list) else [])
        ]

    def get_sync(self, range: UsageRange) -> List[UsageStatRow]:
        """Synchronous version of :meth:`get`."""
        return asyncio.run(self.get(range))
