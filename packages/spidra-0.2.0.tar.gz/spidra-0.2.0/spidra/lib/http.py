from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Dict, Optional

import httpx

from ..types.client import SpidraConfig

logger = logging.getLogger("spidra")

# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------


class SpidraError(Exception):
    """Base class for all Spidra API errors."""

    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.message = message

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(status={self.status}, message={self.message!r})"


class SpidraAuthenticationError(SpidraError):
    """Raised when the API key is missing or invalid (HTTP 401)."""

    def __init__(self, message: str) -> None:
        super().__init__(401, message)


class SpidraInsufficientCreditsError(SpidraError):
    """Raised when the account has run out of credits (HTTP 403)."""

    def __init__(self, message: str) -> None:
        super().__init__(403, message)


class SpidraRateLimitError(SpidraError):
    """Raised when the rate limit is exceeded (HTTP 429)."""

    def __init__(self, message: str) -> None:
        super().__init__(429, message)


class SpidraServerError(SpidraError):
    """Raised on an unrecoverable server-side error (HTTP 500)."""

    def __init__(self, message: str) -> None:
        super().__init__(500, message)


def _raise_for_status(status: int, message: str) -> None:
    """Map an HTTP status code to the appropriate SpidraError subclass."""
    if status == 401:
        raise SpidraAuthenticationError(message)
    elif status == 403:
        raise SpidraInsufficientCreditsError(message)
    elif status == 429:
        raise SpidraRateLimitError(message)
    elif status == 500:
        raise SpidraServerError(message)
    else:
        raise SpidraError(status, message)


# ---------------------------------------------------------------------------
# Retry helpers
# ---------------------------------------------------------------------------

#: HTTP status codes that represent transient upstream/gateway failures.
#: These are safe to retry because the request never reached the application.
_TRANSIENT_STATUS_CODES = {502, 503, 504}

#: Maximum number of retry attempts after the first failure.
_MAX_RETRIES = 3

#: Maximum delay between retries in seconds (caps exponential growth).
_MAX_BACKOFF_SECONDS = 5.0


def _is_transient_response(response: httpx.Response) -> bool:
    """
    Return True if the response represents a transient error that is safe to retry.

    Mirrors the ``isTransientError`` function in the frontend's ``axios.ts``:
    - HTTP 502, 503, 504  -> gateway / upstream errors
    - Body ``code == "QUEUE_UNAVAILABLE"`` -> Spidra-specific transient condition
    """
    if response.status_code in _TRANSIENT_STATUS_CODES:
        logger.debug("Transient HTTP %s — will retry", response.status_code)
        return True

    # Check for Spidra-specific error code in the response body
    try:
        body = response.json()
        if body.get("code") == "QUEUE_UNAVAILABLE":
            logger.debug("QUEUE_UNAVAILABLE — will retry")
            return True
    except Exception:
        pass

    return False


def _backoff_seconds(attempt: int) -> float:
    """
    Exponential backoff matching the frontend formula exactly:
        delay = min(1000ms * 2^(attempt-1), 5000ms)

    attempt=1 -> 1.0s
    attempt=2 -> 2.0s
    attempt=3 -> 4.0s   (never reaches 5s cap with MAX_RETRIES=3)
    """
    return float(min(1.0 * (2 ** (attempt - 1)), _MAX_BACKOFF_SECONDS))


# ---------------------------------------------------------------------------
# HTTP client
# ---------------------------------------------------------------------------


class HttpClient:
    """
    Async HTTP wrapper around httpx.AsyncClient with automatic retry.

    Mirrors the JS HttpClient in src/lib/http.ts but goes further by adding
    exponential-backoff retry logic for transient errors, matching the
    behaviour of the frontend's ``axios.ts`` interceptor.

    Retry policy
    ------------
    - Up to **3 retries** on transient failures (HTTP 502/503/504, network
      errors, ``QUEUE_UNAVAILABLE`` response code).
    - Backoff delays: 1 s -> 2 s -> 4 s (capped at 5 s).
    - **No retry** on client errors (401, 403, 429) or server logic errors
      (500) — those require user action, not a second attempt.

    Enable debug logging to observe retry attempts::

        import logging
        logging.getLogger("spidra").setLevel(logging.DEBUG)
    """

    def __init__(self, config: SpidraConfig) -> None:
        self._api_key = config.api_key
        self._base_url = config.base_url.rstrip("/")
        # Allow a custom async client to be injected (useful for testing).
        self._client: Optional[httpx.AsyncClient] = config.session

    def _headers(self) -> Dict[str, str]:
        return {"x-api-key": self._api_key}

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        # Lazily create a shared client the first time it is needed.
        self._client = httpx.AsyncClient(timeout=60.0)
        return self._client

    async def _extract_error_message(self, response: httpx.Response) -> str:
        """Pull the human-readable error message out of an API error response."""
        try:
            body = response.json()
            return str(body.get("message", response.text))
        except Exception:
            return response.text or response.reason_phrase or "Unknown error"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        body: Optional[Any] = None,
    ) -> Any:
        """
        Core request dispatcher with retry + exponential backoff.

        All public methods (``post``, ``get``, ``delete``) delegate here so
        the retry logic lives in exactly one place.
        """
        client = await self._get_client()
        url = f"{self._base_url}{path}"

        headers = self._headers()
        content: Optional[bytes] = None
        if body is not None:
            headers = {**headers, "Content-Type": "application/json"}
            content = json.dumps(body, default=_serialize).encode()

        last_exception: Optional[Exception] = None

        for attempt in range(1, _MAX_RETRIES + 2):  # attempts: 1 to MAX_RETRIES+1
            try:
                logger.debug("%s %s (attempt %d)", method.upper(), path, attempt)

                response = await client.request(
                    method,
                    url,
                    headers=headers,
                    content=content,
                )

                # Success
                if response.is_success:
                    return response.json()

                # Transient error — maybe retry
                if _is_transient_response(response) and attempt <= _MAX_RETRIES:
                    delay = _backoff_seconds(attempt)
                    logger.debug(
                        "Retrying in %.1fs (attempt %d/%d)...",
                        delay, attempt, _MAX_RETRIES,
                    )
                    await asyncio.sleep(delay)
                    continue  # go to next attempt

                # Non-transient or retries exhausted — raise immediately
                message = await self._extract_error_message(response)
                _raise_for_status(response.status_code, message)

            except (httpx.ConnectError, httpx.TimeoutException, httpx.RemoteProtocolError) as exc:
                # Network-level transient error (mirrors axios.ts: !error.response -> retry)
                last_exception = exc
                if attempt <= _MAX_RETRIES:
                    delay = _backoff_seconds(attempt)
                    logger.debug(
                        "Network error (%s) — retrying in %.1fs (attempt %d/%d)...",
                        type(exc).__name__, delay, attempt, _MAX_RETRIES,
                    )
                    await asyncio.sleep(delay)
                    continue
                # All retries exhausted — re-raise the last network error
                raise

        # Should only be reached if the loop exits without returning or raising
        if last_exception is not None:
            raise last_exception
        raise SpidraError(0, "Request failed after all retries")  # pragma: no cover

    # Public HTTP verbs

    async def post(self, path: str, body: Any) -> Any:
        return await self._request("POST", path, body=body)

    async def get(self, path: str) -> Any:
        return await self._request("GET", path)

    async def delete(self, path: str) -> Any:
        return await self._request("DELETE", path)

    async def aclose(self) -> None:
        """Close the underlying httpx client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None


# ---------------------------------------------------------------------------
# Internal serialisation helpers
# ---------------------------------------------------------------------------


def _serialize(obj: Any) -> Any:
    """
    Custom JSON serialiser for dataclass instances.
    Converts dataclasses to dicts and snake_case keys to camelCase so that
    the Spidra REST API receives the field names it expects.
    """
    import dataclasses

    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        raw = {k: v for k, v in dataclasses.asdict(obj).items() if v is not None}
        return {_snake_to_camel(k): v for k, v in raw.items()}
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")


def _snake_to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(p.title() for p in parts[1:])
