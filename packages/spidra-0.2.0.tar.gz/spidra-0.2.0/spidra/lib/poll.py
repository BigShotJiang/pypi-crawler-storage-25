from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional

TERMINAL_STATUSES = {"completed", "failed", "cancelled"}


@dataclass
class PollOptions:
    """Controls how ``run()`` polls for a job result."""

    poll_interval: float = 3.0
    """Seconds between status checks. Default: 3 seconds."""

    timeout: float = 120.0
    """Maximum seconds to wait before raising a TimeoutError. Default: 120 seconds."""


async def poll(
    fn: Callable[[], Awaitable[Any]],
    options: Optional[PollOptions] = None,
) -> Any:
    """
    Call ``fn()`` repeatedly until the returned object's ``status`` field is a
    terminal value (``completed``, ``failed``, or ``cancelled``), then return it.

    Mirrors the JS ``poll`` helper in src/lib/poll.ts.

    Raises:
        TimeoutError: if the job does not reach a terminal status within ``options.timeout`` seconds.
    """
    opts = options or PollOptions()
    deadline = asyncio.get_event_loop().time() + opts.timeout

    while True:
        result = await fn()

        status = _get_status(result)
        if status in TERMINAL_STATUSES:
            return result

        remaining = deadline - asyncio.get_event_loop().time()
        if remaining <= opts.poll_interval:
            raise TimeoutError(
                f"Spidra job timed out after {opts.timeout:.0f} seconds"
            )

        await asyncio.sleep(opts.poll_interval)


def _get_status(result: Any) -> str:
    """Extract the status field from a result dict or dataclass."""
    if isinstance(result, dict):
        return str(result.get("status", ""))
    return str(getattr(result, "status", ""))
