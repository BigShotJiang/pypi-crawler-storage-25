from dataclasses import dataclass
from typing import Optional, Callable, Any


@dataclass
class SpidraConfig:
    """Configuration for the SpidraClient."""

    api_key: str
    """Your Spidra API key. Get it at app.spidra.io under Settings > API Keys."""

    base_url: str = "https://api.spidra.io/api"
    """Override the base URL. Defaults to https://api.spidra.io/api"""

    session: Optional[Any] = None
    """Bring your own httpx.AsyncClient instance (must be an httpx.AsyncClient)."""
