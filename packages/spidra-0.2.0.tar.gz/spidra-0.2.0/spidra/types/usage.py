from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional


UsageRange = Literal["7d", "30d", "weekly"]


@dataclass
class UsageStatRow:
    label: str
    """Chart axis label — e.g. "Apr 16" or "Apr 14-20"."""

    date: str
    """Tooltip date — YYYY-MM-DD for daily ranges, "Apr 14 – Apr 20" for weekly."""

    tokens: int
    requests: int
    crawls: int
    captchas: int
    latency: float
    """Average latency in milliseconds."""
    credits: float
