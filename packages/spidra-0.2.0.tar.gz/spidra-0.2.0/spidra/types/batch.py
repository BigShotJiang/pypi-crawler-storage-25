from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional, Union

from .scrape import OutputFormat, ProxyCountry

# ---------------------------------------------------------------------------
# Input params
# ---------------------------------------------------------------------------


@dataclass
class BatchScrapeParams:
    """Parameters for a batch scrape job. Up to 50 URLs processed in parallel."""

    urls: List[str]
    """Plain URL strings (not ScrapeUrl objects)."""

    prompt: str
    """What data to extract from every URL."""

    output: Optional[OutputFormat] = None
    schema: Optional[Dict[str, Any]] = None
    use_proxy: Optional[bool] = None
    proxy_country: Optional[str] = None
    extract_content_only: Optional[bool] = None
    screenshot: Optional[bool] = None
    full_page_screenshot: Optional[bool] = None
    cookies: Optional[str] = None


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


@dataclass
class BatchScrapeQueued:
    status: Literal["queued"]
    batch_id: str
    total: int


BatchItemStatus = Literal["pending", "running", "completed", "failed"]
BatchStatus = Literal["pending", "running", "completed", "failed", "cancelled"]


@dataclass
class BatchItem:
    uuid: str
    url: str
    job_id: Optional[str]
    status: BatchItemStatus
    result: Optional[Any]
    credits_used: int
    started_at: Optional[str]
    finished_at: Optional[str]
    screenshot_url: Optional[str]
    error: Optional[str] = None


@dataclass
class BatchScrapeResponse:
    status: BatchStatus
    total_urls: int
    completed_count: int
    failed_count: int
    created_at: str
    items: List[BatchItem]
    finished_at: Optional[str] = None


@dataclass
class BatchCancelResponse:
    status: Literal["cancelled"]
    cancelled_items: int
    credits_refunded: int


@dataclass
class BatchListParams:
    page: Optional[int] = None
    limit: Optional[int] = None


@dataclass
class BatchListEntry:
    uuid: str
    status: BatchStatus
    total_urls: int
    completed_count: int
    failed_count: int
    output_format: str
    scraping_channel: str
    created_at: str
    finished_at: Optional[str] = None


@dataclass
class BatchListPagination:
    page: int
    limit: int
    total: int
    total_pages: int


@dataclass
class BatchListResponse:
    jobs: List[BatchListEntry]
    pagination: BatchListPagination
