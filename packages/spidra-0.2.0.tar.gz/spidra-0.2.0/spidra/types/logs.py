from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional


@dataclass
class ScrapeLogsParams:
    """Filters for listing scrape logs."""

    status: Optional[Literal["success", "failed"]] = None
    search_term: Optional[str] = None
    limit: Optional[int] = None
    page: Optional[int] = None
    channel: Optional[str] = None
    """Filter by channel: ``"api"`` or ``"playground"``."""
    date_start: Optional[str] = None
    """ISO date string — only return logs on or after this date."""
    date_end: Optional[str] = None
    """ISO date string — only return logs on or before this date."""


@dataclass
class ScrapeLog:
    uuid: str
    urls: List[Dict[str, Any]]
    status: Literal["success", "failed"]
    extraction_prompt: Optional[str] = None
    credits_used: Optional[float] = None
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    error_message: Optional[str] = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    tokens_used: Optional[int] = None
    latency_ms: Optional[int] = None
    ai_output_format: Optional[str] = None
    use_proxy: Optional[int] = None
    proxy_country: Optional[str] = None


@dataclass
class ScrapeLogsResponse:
    logs: List[ScrapeLog]
    total: int


@dataclass
class ScrapeLogDetail(ScrapeLog):
    """Single log entry with the full AI extraction result included."""
    result_data: Any = None
