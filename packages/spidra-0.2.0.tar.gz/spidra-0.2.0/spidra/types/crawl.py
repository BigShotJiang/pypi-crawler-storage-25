from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional, Union

from .scrape import ProxyCountry

# ---------------------------------------------------------------------------
# Input params
# ---------------------------------------------------------------------------


@dataclass
class CrawlParams:
    """Parameters for a crawl job."""

    base_url: str
    """The starting URL for the crawl."""

    crawl_instruction: str
    """Natural language description of which pages to discover."""

    transform_instruction: str
    """Natural language description of what data to extract from each page."""

    max_pages: Optional[int] = None
    """Maximum number of pages to crawl."""

    use_proxy: Optional[bool] = None
    proxy_country: Optional[str] = None
    cookies: Optional[str] = None


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


@dataclass
class CrawlQueued:
    status: Literal["queued"]
    job_id: str


CrawlStatus = Literal["waiting", "active", "running", "completed", "failed"]


@dataclass
class CrawlPageResult:
    url: str
    data: Any
    title: Optional[str] = None


@dataclass
class CrawlJobPending:
    status: Literal["waiting", "active", "running"]
    progress: Optional[Dict[str, Any]] = None


@dataclass
class CrawlJobCompleted:
    status: Literal["completed"]
    result: List[CrawlPageResult]


@dataclass
class CrawlJobFailed:
    status: Literal["failed"]
    error: Optional[str] = None


# Union of all possible polling responses
CrawlJobResponse = Union[CrawlJobPending, CrawlJobCompleted, CrawlJobFailed]


@dataclass
class CrawlPage:
    id: str
    url: str
    status: Literal["success", "failed"]
    data: Any
    error_message: Optional[str]
    html_url: Optional[str]
    markdown_url: Optional[str]
    created_at: str
    title: Optional[str] = None


@dataclass
class CrawlPagesResponse:
    pages: List[CrawlPage]


@dataclass
class CrawlHistoryParams:
    page: Optional[int] = None
    limit: Optional[int] = None


@dataclass
class CrawlHistoryEntry:
    id: str
    base_url: str
    crawl_instruction: str
    transform_instruction: str
    max_pages: int
    status: str
    created_at: str
    updated_at: str
    pages_crawled: int
    credits_used: Optional[float] = None


@dataclass
class CrawlHistoryResponse:
    jobs: List[CrawlHistoryEntry]
    total: int
    page: int
    total_pages: int


@dataclass
class CrawlStats:
    total: int
