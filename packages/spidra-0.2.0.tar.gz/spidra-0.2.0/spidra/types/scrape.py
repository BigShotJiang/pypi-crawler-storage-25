from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Union

# ---------------------------------------------------------------------------
# Literal type aliases
# ---------------------------------------------------------------------------

OutputFormat = Literal["json", "markdown", "text", "table"]

# All country codes supported by the proxy, including regional aliases.
ProxyCountry = Literal[
    "us", "gb", "de", "fr", "jp", "au", "ca", "br", "in",
    "nl", "sg", "es", "it", "mx", "za", "ng", "ar", "be",
    "ch", "cl", "cn", "co", "cz", "dk", "eg", "fi", "gr",
    "hk", "hu", "id", "ie", "il", "kr", "my", "no", "nz",
    "pe", "ph", "pl", "pt", "ro", "sa", "se", "th", "tr",
    "tw", "ua", "vn", "eu", "global",
]

BrowserActionType = Literal[
    "click", "type", "check", "uncheck", "wait", "scroll", "forEach"
]

# ---------------------------------------------------------------------------
# Browser action
# ---------------------------------------------------------------------------


@dataclass
class BrowserActionPagination:
    """Pagination config for the forEach browser action."""

    next_selector: str
    """CSS selector or description of the "next page" button/link."""

    max_pages: Optional[int] = None
    """Maximum number of pages to paginate through (default: 5, hard cap: 10)."""


@dataclass
class BrowserAction:
    """A single browser action step executed before the page is extracted."""

    type: BrowserActionType

    selector: Optional[str] = None
    """CSS selector or XPath targeting a specific element."""

    value: Optional[str] = None
    """Plain-English element description (AI locates the element) or text to type."""

    duration: Optional[int] = None
    """Milliseconds to pause — used by the ``wait`` action."""

    to: Optional[str] = None
    """Scroll destination as a percentage string e.g. ``"80%"`` — used by ``scroll``."""

    # forEach-specific fields
    observe: Optional[str] = None
    """Natural language description of which elements to find, e.g. "Find all product cards"."""

    mode: Optional[Literal["click", "inline", "navigate"]] = None
    """How to interact with each matched element (default: ``"click"``)."""

    capture_selector: Optional[str] = None
    """CSS selector of the content container to capture after each interaction."""

    max_items: Optional[int] = None
    """Maximum number of elements to process (default: 50, hard cap: 50)."""

    wait_after_click: Optional[int] = None
    """Milliseconds to wait after clicking/navigating before capturing content (default: 2500)."""

    item_prompt: Optional[str] = None
    """Per-element extraction prompt — runs AI on each item individually before combining."""

    actions: Optional[List["BrowserAction"]] = None
    """Per-element actions to run after click/navigation."""

    pagination: Optional[BrowserActionPagination] = None
    """Paginate through "next page" links to collect more elements."""


# ---------------------------------------------------------------------------
# Scrape input params
# ---------------------------------------------------------------------------


@dataclass
class ScrapeUrl:
    """A single URL entry with optional pre-scrape browser actions."""

    url: str

    actions: Optional[List[BrowserAction]] = None
    """Step-by-step browser actions to run before extraction."""

    instruction: Optional[str] = None
    """AI Navigate mode — a single natural language instruction that handles all interactions automatically."""


@dataclass
class ScrapeParams:
    """Parameters for a scrape job."""

    urls: List[ScrapeUrl]
    """Up to 3 URLs to scrape in parallel."""

    prompt: str
    """What data to extract (natural language)."""

    output: Optional[OutputFormat] = None
    """Desired output format (json, markdown, text, table)."""

    schema: Optional[Dict[str, Any]] = None
    """JSON Schema to enforce on the output; missing fields are returned as null."""

    use_proxy: Optional[bool] = None
    """Route the request through a residential proxy."""

    proxy_country: Optional[str] = None
    """ISO country code for geo-targeted proxy routing."""

    extract_content_only: Optional[bool] = None
    """Strip navigation/footer boilerplate before extraction."""

    screenshot: Optional[bool] = None
    """Capture a viewport screenshot."""

    full_page_screenshot: Optional[bool] = None
    """Capture a full-page screenshot."""

    cookies: Optional[str] = None
    """Cookies to inject as a raw header string, e.g. ``"session=abc; token=xyz"``."""


# ---------------------------------------------------------------------------
# Scrape job response shapes
# ---------------------------------------------------------------------------


@dataclass
class ScrapeUrlResult:
    url: str
    success: bool
    title: Optional[str] = None
    markdown_content: Optional[str] = None
    screenshot_url: Optional[str] = None


@dataclass
class ScrapeResultStats:
    duration_ms: int
    captcha_solved_count: int
    input_tokens: int
    output_tokens: int
    total_tokens: int


@dataclass
class ScrapeResult:
    content: Any
    data: List[ScrapeUrlResult]
    screenshots: List[str]
    ai_extraction_failed: bool
    stats: ScrapeResultStats


@dataclass
class ScrapeJobQueued:
    status: Literal["queued"]
    job_id: str


@dataclass
class ScrapeJobPending:
    status: Literal["waiting", "active"]
    progress: Optional[Dict[str, Any]] = None


@dataclass
class ScrapeJobCompleted:
    status: Literal["completed"]
    result: ScrapeResult
    error: None = None
    progress: Optional[Dict[str, Any]] = None


@dataclass
class ScrapeJobFailed:
    status: Literal["failed"]
    error: str


# Union of all possible polling responses
ScrapeJobResponse = Union[ScrapeJobPending, ScrapeJobCompleted, ScrapeJobFailed]
