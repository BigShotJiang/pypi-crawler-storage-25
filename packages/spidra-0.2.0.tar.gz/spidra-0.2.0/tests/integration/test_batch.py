"""
Integration tests for BatchResource — mocked HTTP via respx.
"""
import json
import pytest
import respx
import httpx

from spidra import SpidraClient
from spidra.types.batch import BatchScrapeParams, BatchScrapeResponse, BatchCancelResponse, BatchListResponse

BASE_URL = "https://api.spidra.io/api"


@pytest.fixture
def client() -> SpidraClient:
    return SpidraClient(api_key="spd_test_key")


def _completed_batch_response() -> dict:  # type: ignore[type-arg]
    return {
        "status": "completed",
        "totalUrls": 2,
        "completedCount": 2,
        "failedCount": 0,
        "createdAt": "2024-01-01T00:00:00Z",
        "finishedAt": "2024-01-01T00:01:00Z",
        "items": [
            {
                "uuid": "item-1", "url": "https://a.com", "jobId": "j1",
                "status": "completed", "result": {"title": "A"}, "creditsUsed": 1,
                "startedAt": "2024-01-01T00:00:01Z", "finishedAt": "2024-01-01T00:00:05Z",
                "screenshotUrl": None,
            },
            {
                "uuid": "item-2", "url": "https://b.com", "jobId": "j2",
                "status": "completed", "result": {"title": "B"}, "creditsUsed": 1,
                "startedAt": "2024-01-01T00:00:01Z", "finishedAt": "2024-01-01T00:00:06Z",
                "screenshotUrl": None,
            },
        ],
    }


class TestBatchSubmit:
    @respx.mock
    async def test_submit_returns_batch_id(self, client: SpidraClient) -> None:
        respx.post(f"{BASE_URL}/batch/scrape").mock(
            return_value=httpx.Response(200, json={"status": "queued", "batchId": "batch-abc", "total": 2})
        )
        queued = await client.batch.submit(BatchScrapeParams(
            urls=["https://a.com", "https://b.com"],
            prompt="Extract title",
        ))
        assert queued.batch_id == "batch-abc"
        assert queued.total == 2

    @respx.mock
    async def test_submit_urls_are_strings_in_body(self, client: SpidraClient) -> None:
        route = respx.post(f"{BASE_URL}/batch/scrape").mock(
            return_value=httpx.Response(200, json={"status": "queued", "batchId": "b1", "total": 1})
        )
        await client.batch.submit(BatchScrapeParams(urls=["https://example.com"], prompt="test"))
        body = json.loads(route.calls.last.request.content)
        assert body["urls"] == ["https://example.com"]
        assert isinstance(body["urls"][0], str)


class TestBatchGet:
    @respx.mock
    async def test_get_parses_response(self, client: SpidraClient) -> None:
        respx.get(f"{BASE_URL}/batch/scrape/batch-abc").mock(
            return_value=httpx.Response(200, json=_completed_batch_response())
        )
        result = await client.batch.get("batch-abc")
        assert isinstance(result, BatchScrapeResponse)
        assert result.status == "completed"
        assert result.total_urls == 2
        assert len(result.items) == 2
        assert result.items[0].url == "https://a.com"
        assert result.items[0].job_id == "j1"


class TestBatchRetry:
    @respx.mock
    async def test_retry_returns_retried_count(self, client: SpidraClient) -> None:
        respx.post(f"{BASE_URL}/batch/scrape/batch-xyz/retry").mock(
            return_value=httpx.Response(200, json={"retriedCount": 3})
        )
        result = await client.batch.retry("batch-xyz")
        assert result["retried_count"] == 3


class TestBatchCancel:
    @respx.mock
    async def test_cancel_returns_cancel_response(self, client: SpidraClient) -> None:
        respx.delete(f"{BASE_URL}/batch/scrape/batch-del").mock(
            return_value=httpx.Response(200, json={
                "status": "cancelled",
                "cancelledItems": 5,
                "creditsRefunded": 10,
            })
        )
        result = await client.batch.cancel("batch-del")
        assert isinstance(result, BatchCancelResponse)
        assert result.cancelled_items == 5
        assert result.credits_refunded == 10


class TestBatchList:
    @respx.mock
    async def test_list_parses_pagination(self, client: SpidraClient) -> None:
        respx.get(f"{BASE_URL}/batch/scrape").mock(
            return_value=httpx.Response(200, json={
                "jobs": [
                    {
                        "uuid": "b-1", "status": "completed", "totalUrls": 3,
                        "completedCount": 3, "failedCount": 0, "outputFormat": "json",
                        "scrapingChannel": "api", "createdAt": "2024-01-01", "finishedAt": None,
                    }
                ],
                "pagination": {"page": 1, "limit": 20, "total": 1, "totalPages": 1},
            })
        )
        result = await client.batch.list()
        assert isinstance(result, BatchListResponse)
        assert len(result.jobs) == 1
        assert result.jobs[0].uuid == "b-1"
        assert result.pagination.total == 1
        assert result.pagination.total_pages == 1

    @respx.mock
    async def test_list_with_page_and_limit(self, client: SpidraClient) -> None:
        from spidra.types.batch import BatchListParams

        route = respx.get(f"{BASE_URL}/batch/scrape").mock(
            return_value=httpx.Response(200, json={
                "jobs": [], "pagination": {"page": 2, "limit": 5, "total": 0, "totalPages": 0},
            })
        )
        await client.batch.list(BatchListParams(page=2, limit=5))
        assert "page=2" in str(route.calls.last.request.url)
        assert "limit=5" in str(route.calls.last.request.url)


class TestBatchRun:
    @respx.mock
    async def test_run_polls_until_completed(self, client: SpidraClient) -> None:
        from spidra.lib.poll import PollOptions

        respx.post(f"{BASE_URL}/batch/scrape").mock(
            return_value=httpx.Response(200, json={"status": "queued", "batchId": "b-run", "total": 2})
        )
        respx.get(f"{BASE_URL}/batch/scrape/b-run").mock(
            side_effect=[
                httpx.Response(200, json={
                    "status": "running", "totalUrls": 2, "completedCount": 0,
                    "failedCount": 0, "createdAt": "2024-01-01", "finishedAt": None, "items": [],
                }),
                httpx.Response(200, json=_completed_batch_response()),
            ]
        )
        result = await client.batch.run(
            BatchScrapeParams(urls=["https://a.com", "https://b.com"], prompt="test"),
            PollOptions(poll_interval=0.01),
        )
        assert result.status == "completed"
        assert result.completed_count == 2
