"""
Integration tests for ScrapeResource — mocked HTTP via respx.
"""
import pytest
import respx
import httpx

from spidra import SpidraClient, ScrapeParams, ScrapeUrl, BrowserAction
from spidra.types.scrape import ScrapeJobCompleted, ScrapeJobFailed


BASE_URL = "https://api.spidra.io/api"


@pytest.fixture
def client() -> SpidraClient:
    return SpidraClient(api_key="spd_test_key")


# ---------------------------------------------------------------------------
# scrape.submit()
# ---------------------------------------------------------------------------


class TestScrapeSubmit:
    @respx.mock
    async def test_submit_returns_job_id(self, client: SpidraClient) -> None:
        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "job-123"})
        )
        queued = await client.scrape.submit(
            ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
        )
        assert queued.job_id == "job-123"
        assert queued.status == "queued"

    @respx.mock
    async def test_submit_sends_api_key_header(self, client: SpidraClient) -> None:
        route = respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "job-x"})
        )
        await client.scrape.submit(
            ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
        )
        assert route.called
        request = route.calls.last.request
        assert request.headers["x-api-key"] == "spd_test_key"

    @respx.mock
    async def test_submit_sends_camel_case_body(self, client: SpidraClient) -> None:
        import json

        route = respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "job-x"})
        )
        await client.scrape.submit(
            ScrapeParams(
                urls=[ScrapeUrl(url="https://example.com")],
                prompt="test",
                use_proxy=True,
                proxy_country="ng",
            )
        )
        body = json.loads(route.calls.last.request.content)
        assert "useProxy" in body
        assert body["useProxy"] is True
        assert body["proxyCountry"] == "ng"
        assert "use_proxy" not in body  # snake_case must NOT reach the API


# ---------------------------------------------------------------------------
# scrape.get()
# ---------------------------------------------------------------------------


class TestScrapeGet:
    @respx.mock
    async def test_get_completed_job(self, client: SpidraClient) -> None:
        respx.get(f"{BASE_URL}/scrape/job-123").mock(
            return_value=httpx.Response(200, json={
                "status": "completed",
                "result": {
                    "content": {"answer": 42},
                    "data": [],
                    "screenshots": [],
                    "ai_extraction_failed": False,
                    "stats": {
                        "durationMs": 1000, "captchaSolvedCount": 0,
                        "inputTokens": 10, "outputTokens": 5, "totalTokens": 15,
                    },
                },
                "error": None,
            })
        )
        result = await client.scrape.get("job-123")
        assert isinstance(result, ScrapeJobCompleted)
        assert result.result.content == {"answer": 42}

    @respx.mock
    async def test_get_failed_job(self, client: SpidraClient) -> None:
        respx.get(f"{BASE_URL}/scrape/job-fail").mock(
            return_value=httpx.Response(200, json={"status": "failed", "error": "Rendered blank"})
        )
        result = await client.scrape.get("job-fail")
        assert isinstance(result, ScrapeJobFailed)
        assert result.error == "Rendered blank"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestScrapeErrors:
    @respx.mock
    async def test_401_raises_authentication_error(self, client: SpidraClient) -> None:
        from spidra import SpidraAuthenticationError

        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(401, json={"message": "Invalid API key"})
        )
        with pytest.raises(SpidraAuthenticationError) as exc_info:
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
            )
        assert exc_info.value.status == 401

    @respx.mock
    async def test_403_raises_insufficient_credits_error(self, client: SpidraClient) -> None:
        from spidra import SpidraInsufficientCreditsError

        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(403, json={"message": "Out of credits"})
        )
        with pytest.raises(SpidraInsufficientCreditsError) as exc_info:
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
            )
        assert exc_info.value.status == 403

    @respx.mock
    async def test_429_raises_rate_limit_error(self, client: SpidraClient) -> None:
        from spidra import SpidraRateLimitError

        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(429, json={"message": "Rate limit exceeded"})
        )
        with pytest.raises(SpidraRateLimitError):
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
            )

    @respx.mock
    async def test_500_raises_server_error(self, client: SpidraClient) -> None:
        from spidra import SpidraServerError

        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(500, json={"message": "Internal server error"})
        )
        with pytest.raises(SpidraServerError):
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
            )

    @respx.mock
    async def test_error_message_extracted_from_body(self, client: SpidraClient) -> None:
        from spidra import SpidraError

        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(422, json={"message": "Validation failed: urls required"})
        )
        with pytest.raises(SpidraError) as exc_info:
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
            )
        assert "Validation failed" in str(exc_info.value)


# ---------------------------------------------------------------------------
# scrape.run()  (full submit → poll → return flow)
# ---------------------------------------------------------------------------


class TestScrapeRun:
    @respx.mock
    async def test_run_polls_and_returns_completed(self, client: SpidraClient) -> None:
        from spidra.lib.poll import PollOptions

        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "job-run-1"})
        )
        respx.get(f"{BASE_URL}/scrape/job-run-1").mock(
            side_effect=[
                httpx.Response(200, json={"status": "active"}),
                httpx.Response(200, json={
                    "status": "completed",
                    "result": {
                        "content": "Hello",
                        "data": [],
                        "screenshots": [],
                        "ai_extraction_failed": False,
                        "stats": {"durationMs": 500, "captchaSolvedCount": 0,
                                  "inputTokens": 5, "outputTokens": 3, "totalTokens": 8},
                    },
                    "error": None,
                }),
            ]
        )
        result = await client.scrape.run(
            ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test"),
            PollOptions(poll_interval=0.01),
        )
        assert isinstance(result, ScrapeJobCompleted)
        assert result.result.content == "Hello"

    @respx.mock
    async def test_run_raises_on_failed_job(self, client: SpidraClient) -> None:
        from spidra.lib.poll import PollOptions

        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "job-run-fail"})
        )
        respx.get(f"{BASE_URL}/scrape/job-run-fail").mock(
            return_value=httpx.Response(200, json={"status": "failed", "error": "Page crashed"})
        )
        with pytest.raises(RuntimeError, match="Page crashed"):
            await client.scrape.run(
                ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test"),
                PollOptions(poll_interval=0.01),
            )
