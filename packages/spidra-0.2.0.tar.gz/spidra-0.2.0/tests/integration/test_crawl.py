"""
Integration tests for CrawlResource — mocked HTTP via respx.
"""
import json
import pytest
import respx
import httpx

from spidra import SpidraClient
from spidra.types.crawl import (
    CrawlParams,
    CrawlQueued,
    CrawlJobCompleted,
    CrawlPagesResponse,
    CrawlHistoryResponse,
    CrawlStats,
)

BASE_URL = "https://api.spidra.io/api"


@pytest.fixture
def client() -> SpidraClient:
    return SpidraClient(api_key="spd_test_key")


def _completed_job_payload() -> dict:  # type: ignore[type-arg]
    return {
        "status": "completed",
        "result": [
            {"url": "https://blog.example.com/post-1", "title": "Post 1", "data": {"summary": "A post"}},
            {"url": "https://blog.example.com/post-2", "title": "Post 2", "data": {"summary": "B post"}},
        ],
    }


class TestCrawlSubmit:
    @respx.mock
    async def test_submit_returns_job_id(self, client: SpidraClient) -> None:
        respx.post(f"{BASE_URL}/crawl").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "crawl-001"})
        )
        queued = await client.crawl.submit(CrawlParams(
            base_url="https://example.com/blog",
            crawl_instruction="Find all blog posts",
            transform_instruction="Extract title and summary",
        ))
        assert isinstance(queued, CrawlQueued)
        assert queued.job_id == "crawl-001"

    @respx.mock
    async def test_submit_sends_camel_case_keys(self, client: SpidraClient) -> None:
        route = respx.post(f"{BASE_URL}/crawl").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "crawl-002"})
        )
        await client.crawl.submit(CrawlParams(
            base_url="https://example.com",
            crawl_instruction="Find pages",
            transform_instruction="Extract data",
            max_pages=30,
            use_proxy=True,
            proxy_country="us",
        ))
        body = json.loads(route.calls.last.request.content)
        assert "baseUrl" in body
        assert "crawlInstruction" in body
        assert "transformInstruction" in body
        assert "maxPages" in body
        assert body["maxPages"] == 30
        assert body["useProxy"] is True
        # snake_case must NOT appear
        assert "base_url" not in body
        assert "crawl_instruction" not in body

    @respx.mock
    async def test_submit_omits_none_optional_fields(self, client: SpidraClient) -> None:
        route = respx.post(f"{BASE_URL}/crawl").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "crawl-003"})
        )
        await client.crawl.submit(CrawlParams(
            base_url="https://example.com",
            crawl_instruction="x",
            transform_instruction="y",
        ))
        body = json.loads(route.calls.last.request.content)
        assert "maxPages" not in body
        assert "useProxy" not in body
        assert "proxyCountry" not in body
        assert "cookies" not in body


class TestCrawlGet:
    @respx.mock
    async def test_get_completed_job(self, client: SpidraClient) -> None:
        respx.get(f"{BASE_URL}/crawl/crawl-001").mock(
            return_value=httpx.Response(200, json=_completed_job_payload())
        )
        result = await client.crawl.get("crawl-001")
        assert isinstance(result, CrawlJobCompleted)
        assert len(result.result) == 2
        assert result.result[0].url == "https://blog.example.com/post-1"

    @respx.mock
    async def test_get_pending_job(self, client: SpidraClient) -> None:
        from spidra.types.crawl import CrawlJobPending

        respx.get(f"{BASE_URL}/crawl/crawl-002").mock(
            return_value=httpx.Response(200, json={"status": "running", "progress": {"message": "...", "progress": 50}})
        )
        result = await client.crawl.get("crawl-002")
        assert isinstance(result, CrawlJobPending)
        assert result.progress is not None


class TestCrawlPages:
    @respx.mock
    async def test_pages_returns_signed_urls(self, client: SpidraClient) -> None:
        respx.get(f"{BASE_URL}/crawl/crawl-001/pages").mock(
            return_value=httpx.Response(200, json={
                "pages": [
                    {
                        "id": "pg-1",
                        "url": "https://example.com/post-1",
                        "title": "Post 1",
                        "status": "success",
                        "data": None,
                        "error_message": None,
                        "html_url": "https://s3.amazonaws.com/bucket/html/pg-1.html?X-Exp=3600",
                        "markdown_url": "https://s3.amazonaws.com/bucket/md/pg-1.md?X-Exp=3600",
                        "created_at": "2024-01-01T00:00:00Z",
                    }
                ]
            })
        )
        result = await client.crawl.pages("crawl-001")
        assert isinstance(result, CrawlPagesResponse)
        assert len(result.pages) == 1
        page = result.pages[0]
        assert page.id == "pg-1"
        assert page.html_url is not None
        assert "s3.amazonaws.com" in page.html_url


class TestCrawlExtract:
    @respx.mock
    async def test_extract_returns_new_job_id(self, client: SpidraClient) -> None:
        respx.post(f"{BASE_URL}/crawl/crawl-001/extract").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "crawl-extract-1"})
        )
        queued = await client.crawl.extract("crawl-001", "Extract only product SKUs as CSV")
        assert queued.job_id == "crawl-extract-1"

    @respx.mock
    async def test_extract_sends_correct_body(self, client: SpidraClient) -> None:
        route = respx.post(f"{BASE_URL}/crawl/crawl-001/extract").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "crawl-x"})
        )
        await client.crawl.extract("crawl-001", "New instruction")
        body = json.loads(route.calls.last.request.content)
        assert body == {"transformInstruction": "New instruction"}


class TestCrawlHistory:
    @respx.mock
    async def test_history_parsed_correctly(self, client: SpidraClient) -> None:
        respx.get(f"{BASE_URL}/crawl/history").mock(
            return_value=httpx.Response(200, json={
                "jobs": [
                    {
                        "id": "crawl-001",
                        "base_url": "https://example.com",
                        "crawl_instruction": "Find pages",
                        "transform_instruction": "Extract data",
                        "max_pages": 20,
                        "status": "completed",
                        "created_at": "2024-01-01",
                        "updated_at": "2024-01-01",
                        "pages_crawled": 15,
                        "credits_used": 30,
                    }
                ],
                "total": 1,
                "page": 1,
                "totalPages": 1,
            })
        )
        result = await client.crawl.history()
        assert isinstance(result, CrawlHistoryResponse)
        assert result.total == 1
        assert result.jobs[0].id == "crawl-001"
        assert result.jobs[0].pages_crawled == 15


class TestCrawlStats:
    @respx.mock
    async def test_stats_returns_total(self, client: SpidraClient) -> None:
        respx.get(f"{BASE_URL}/crawl/stats").mock(
            return_value=httpx.Response(200, json={"total": 42})
        )
        result = await client.crawl.stats()
        assert isinstance(result, CrawlStats)
        assert result.total == 42


class TestCrawlRun:
    @respx.mock
    async def test_run_polls_until_done(self, client: SpidraClient) -> None:
        from spidra.lib.poll import PollOptions

        respx.post(f"{BASE_URL}/crawl").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "crawl-run-1"})
        )
        respx.get(f"{BASE_URL}/crawl/crawl-run-1").mock(
            side_effect=[
                httpx.Response(200, json={"status": "running"}),
                httpx.Response(200, json=_completed_job_payload()),
            ]
        )
        result = await client.crawl.run(
            CrawlParams(
                base_url="https://example.com/blog",
                crawl_instruction="Find all posts",
                transform_instruction="Extract data",
            ),
            PollOptions(poll_interval=0.01),
        )
        assert isinstance(result, CrawlJobCompleted)
        assert len(result.result) == 2

    @respx.mock
    async def test_run_raises_on_failure(self, client: SpidraClient) -> None:
        from spidra.lib.poll import PollOptions

        respx.post(f"{BASE_URL}/crawl").mock(
            return_value=httpx.Response(200, json={"status": "queued", "jobId": "crawl-fail"})
        )
        respx.get(f"{BASE_URL}/crawl/crawl-fail").mock(
            return_value=httpx.Response(200, json={"status": "failed", "error": "Robots.txt blocked"})
        )
        with pytest.raises(RuntimeError, match="Robots.txt blocked"):
            await client.crawl.run(
                CrawlParams(
                    base_url="https://example.com",
                    crawl_instruction="x",
                    transform_instruction="y",
                ),
                PollOptions(poll_interval=0.01),
            )
