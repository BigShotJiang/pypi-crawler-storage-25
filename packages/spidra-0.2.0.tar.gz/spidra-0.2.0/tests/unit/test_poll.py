"""
Unit tests for the poll() helper.
"""
import asyncio
import pytest

from spidra.lib.poll import poll, PollOptions


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_fn(responses: list) -> object:  # type: ignore[type-arg]
    """Returns an async function that yields successive responses from a list."""
    responses_iter = iter(responses)

    async def fn() -> dict:  # type: ignore[type-arg]
        return next(responses_iter)

    return fn


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPoll:
    async def test_returns_immediately_on_terminal_status(self) -> None:
        result = await poll(_make_fn([{"status": "completed"}]))  # type: ignore[arg-type]
        assert result["status"] == "completed"

    async def test_polls_until_completed(self) -> None:
        responses = [
            {"status": "waiting"},
            {"status": "active"},
            {"status": "completed", "result": "done"},
        ]
        result = await poll(_make_fn(responses), PollOptions(poll_interval=0.01))  # type: ignore[arg-type]
        assert result["status"] == "completed"
        assert result["result"] == "done"

    async def test_stops_on_failed(self) -> None:
        responses = [
            {"status": "active"},
            {"status": "failed", "error": "Something broke"},
        ]
        result = await poll(_make_fn(responses), PollOptions(poll_interval=0.01))  # type: ignore[arg-type]
        assert result["status"] == "failed"

    async def test_stops_on_cancelled(self) -> None:
        responses = [
            {"status": "running"},
            {"status": "cancelled"},
        ]
        result = await poll(_make_fn(responses), PollOptions(poll_interval=0.01))  # type: ignore[arg-type]
        assert result["status"] == "cancelled"

    async def test_raises_timeout_error(self) -> None:
        async def always_waiting() -> dict:  # type: ignore[type-arg]
            return {"status": "waiting"}

        with pytest.raises(TimeoutError, match="timed out"):
            await poll(always_waiting, PollOptions(poll_interval=0.01, timeout=0.05))

    async def test_default_poll_options_used_when_none_passed(self) -> None:
        """poll() should not raise if called without options — it uses the defaults."""
        # Just check it accepts a terminal result immediately
        result = await poll(_make_fn([{"status": "completed"}]))  # type: ignore[arg-type]
        assert result["status"] == "completed"

    async def test_works_with_dataclass_status(self) -> None:
        """poll() reads .status from dataclass objects too, not only dicts."""
        from dataclasses import dataclass

        @dataclass
        class FakeJob:
            status: str

        async def fn() -> FakeJob:
            return FakeJob(status="completed")

        result = await poll(fn, PollOptions(poll_interval=0.01))
        assert result.status == "completed"
