"""
Unit + integration tests for the retry + exponential backoff logic in HttpClient.

These verify:
1. _backoff_seconds() formula matches axios.ts exactly
2. _is_transient_response() correctly identifies transient vs non-transient errors
3. HttpClient retries on 502/503/504 and network errors, succeeds on eventual 200
4. HttpClient does NOT retry on 401/403/429/500
5. HttpClient raises after exceeding MAX_RETRIES
6. Backoff delays are actually awaited (timing check)
"""
import asyncio
import pytest
import respx
import httpx

from spidra import SpidraClient, ScrapeParams, ScrapeUrl
from spidra.lib.http import (
    _backoff_seconds,
    _is_transient_response,
    _MAX_RETRIES,
    SpidraAuthenticationError,
    SpidraInsufficientCreditsError,
    SpidraRateLimitError,
    SpidraServerError,
    SpidraError,
)

BASE_URL = "https://api.spidra.io/api"


# ---------------------------------------------------------------------------
# _backoff_seconds — formula must match axios.ts exactly
# ---------------------------------------------------------------------------


class TestBackoffFormula:
    def test_attempt_1_is_1_second(self) -> None:
        # min(1000ms * 2^0, 5000ms) = 1000ms = 1.0s
        assert _backoff_seconds(1) == 1.0

    def test_attempt_2_is_2_seconds(self) -> None:
        # min(1000ms * 2^1, 5000ms) = 2000ms = 2.0s
        assert _backoff_seconds(2) == 2.0

    def test_attempt_3_is_4_seconds(self) -> None:
        # min(1000ms * 2^2, 5000ms) = 4000ms = 4.0s
        assert _backoff_seconds(3) == 4.0

    def test_large_attempt_capped_at_5_seconds(self) -> None:
        # min(1000ms * 2^10, 5000ms) = 5000ms = 5.0s
        assert _backoff_seconds(10) == 5.0

    def test_cap_is_5_seconds(self) -> None:
        for attempt in range(1, 20):
            assert _backoff_seconds(attempt) <= 5.0


# ---------------------------------------------------------------------------
# _is_transient_response — transient detection
# ---------------------------------------------------------------------------


class TestIsTransientResponse:
    def _make_response(self, status: int, body: dict = {}) -> httpx.Response:  # type: ignore[type-arg]
        return httpx.Response(status, json=body)

    def test_502_is_transient(self) -> None:
        assert _is_transient_response(self._make_response(502)) is True

    def test_503_is_transient(self) -> None:
        assert _is_transient_response(self._make_response(503)) is True

    def test_504_is_transient(self) -> None:
        assert _is_transient_response(self._make_response(504)) is True

    def test_queue_unavailable_code_is_transient(self) -> None:
        assert _is_transient_response(
            self._make_response(503, {"code": "QUEUE_UNAVAILABLE"})
        ) is True

    def test_500_is_not_transient(self) -> None:
        assert _is_transient_response(self._make_response(500)) is False

    def test_429_is_not_transient(self) -> None:
        assert _is_transient_response(self._make_response(429)) is False

    def test_401_is_not_transient(self) -> None:
        assert _is_transient_response(self._make_response(401)) is False

    def test_403_is_not_transient(self) -> None:
        assert _is_transient_response(self._make_response(403)) is False

    def test_200_is_not_transient(self) -> None:
        assert _is_transient_response(self._make_response(200)) is False

    def test_generic_error_code_is_not_transient(self) -> None:
        assert _is_transient_response(
            self._make_response(400, {"code": "SOME_OTHER_ERROR"})
        ) is False


# ---------------------------------------------------------------------------
# HttpClient retry behaviour — mocked HTTP via respx
# ---------------------------------------------------------------------------


@pytest.fixture
def client() -> SpidraClient:
    return SpidraClient(api_key="spd_test_key")


class TestRetryOn502:
    @respx.mock
    async def test_retries_on_502_then_succeeds(self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch) -> None:
        """Should retry on 502, succeed on the next attempt."""
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        respx.post(f"{BASE_URL}/scrape").mock(
            side_effect=[
                httpx.Response(502, json={"message": "Bad Gateway"}),
                httpx.Response(200, json={"status": "queued", "jobId": "job-1"}),
            ]
        )
        queued = await client.scrape.submit(
            ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
        )
        assert queued.job_id == "job-1"

    @respx.mock
    async def test_retries_on_503(self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        respx.post(f"{BASE_URL}/scrape").mock(
            side_effect=[
                httpx.Response(503, json={"message": "Service Unavailable"}),
                httpx.Response(200, json={"status": "queued", "jobId": "job-2"}),
            ]
        )
        queued = await client.scrape.submit(
            ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
        )
        assert queued.job_id == "job-2"

    @respx.mock
    async def test_retries_on_504(self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        respx.post(f"{BASE_URL}/scrape").mock(
            side_effect=[
                httpx.Response(504, json={"message": "Gateway Timeout"}),
                httpx.Response(200, json={"status": "queued", "jobId": "job-3"}),
            ]
        )
        queued = await client.scrape.submit(
            ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
        )
        assert queued.job_id == "job-3"

    @respx.mock
    async def test_retries_on_queue_unavailable(self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        respx.post(f"{BASE_URL}/scrape").mock(
            side_effect=[
                httpx.Response(503, json={"code": "QUEUE_UNAVAILABLE", "message": "Queue is down"}),
                httpx.Response(200, json={"status": "queued", "jobId": "job-4"}),
            ]
        )
        queued = await client.scrape.submit(
            ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
        )
        assert queued.job_id == "job-4"


class TestRetryExhausted:
    @respx.mock
    async def test_raises_after_max_retries_exceeded(
        self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """
        After MAX_RETRIES consecutive 502s the client must stop retrying
        and raise SpidraError, NOT retry forever.
        """
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        # Return 502 for every call (initial + 3 retries = 4 total requests)
        respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(502, json={"message": "Bad Gateway"})
        )
        with pytest.raises(SpidraError) as exc_info:
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
            )
        assert exc_info.value.status == 502

    @respx.mock
    async def test_exactly_max_retries_plus_one_requests_sent(
        self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Client must send exactly 1 + MAX_RETRIES requests total."""
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        route = respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(502, json={"message": "Bad Gateway"})
        )
        with pytest.raises(SpidraError):
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://example.com")], prompt="test")
            )
        # First attempt + 3 retries = 4 total
        assert route.call_count == 1 + _MAX_RETRIES


class TestNoRetryOnNonTransientErrors:
    @respx.mock
    async def test_no_retry_on_401(self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        route = respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(401, json={"message": "Unauthorized"})
        )
        with pytest.raises(SpidraAuthenticationError):
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
            )
        # Must NOT retry — only 1 request sent
        assert route.call_count == 1

    @respx.mock
    async def test_no_retry_on_403(self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        route = respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(403, json={"message": "Forbidden"})
        )
        with pytest.raises(SpidraInsufficientCreditsError):
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
            )
        assert route.call_count == 1

    @respx.mock
    async def test_no_retry_on_429(self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        route = respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(429, json={"message": "Rate limited"})
        )
        with pytest.raises(SpidraRateLimitError):
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
            )
        assert route.call_count == 1

    @respx.mock
    async def test_no_retry_on_500(self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", _instant_sleep)

        route = respx.post(f"{BASE_URL}/scrape").mock(
            return_value=httpx.Response(500, json={"message": "Internal Error"})
        )
        with pytest.raises(SpidraServerError):
            await client.scrape.submit(
                ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
            )
        assert route.call_count == 1


class TestBackoffDelayActuallyAwaited:
    @respx.mock
    async def test_sleep_called_with_correct_delay_on_first_retry(
        self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify asyncio.sleep is called with 1.0s on the first retry (attempt=1)."""
        sleep_calls: list[float] = []

        async def capture_sleep(seconds: float) -> None:
            sleep_calls.append(seconds)

        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", capture_sleep)

        respx.post(f"{BASE_URL}/scrape").mock(
            side_effect=[
                httpx.Response(502, json={"message": "Bad Gateway"}),
                httpx.Response(200, json={"status": "queued", "jobId": "j1"}),
            ]
        )
        await client.scrape.submit(
            ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
        )
        assert sleep_calls == [1.0]

    @respx.mock
    async def test_sleep_delays_grow_exponentially_across_retries(
        self, client: SpidraClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify delays follow: 1.0s, 2.0s, 4.0s across three retries."""
        sleep_calls: list[float] = []

        async def capture_sleep(seconds: float) -> None:
            sleep_calls.append(seconds)

        monkeypatch.setattr("spidra.lib.http.asyncio.sleep", capture_sleep)

        # 3 failing 502s, then succeeds on 4th attempt
        respx.post(f"{BASE_URL}/scrape").mock(
            side_effect=[
                httpx.Response(502, json={"message": "Bad Gateway"}),
                httpx.Response(502, json={"message": "Bad Gateway"}),
                httpx.Response(502, json={"message": "Bad Gateway"}),
                httpx.Response(200, json={"status": "queued", "jobId": "j-final"}),
            ]
        )
        await client.scrape.submit(
            ScrapeParams(urls=[ScrapeUrl(url="https://a.com")], prompt="test")
        )
        assert sleep_calls == [1.0, 2.0, 4.0]


# ---------------------------------------------------------------------------
# Helper: skip actual sleep in tests
# ---------------------------------------------------------------------------

async def _instant_sleep(seconds: float) -> None:
    """Drop-in for asyncio.sleep that returns instantly — keeps tests fast."""
    pass
