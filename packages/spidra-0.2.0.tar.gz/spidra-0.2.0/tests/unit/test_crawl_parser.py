"""
Unit tests for the crawl serialiser (_crawl_params_to_dict) and response parser (_parse_crawl_job).
"""
import pytest

from spidra.resources.crawl import _crawl_params_to_dict, _parse_crawl_job
from spidra.types.crawl import (
    CrawlParams,
    CrawlJobCompleted,
    CrawlJobFailed,
    CrawlJobPending,
    CrawlPageResult,
)


# ---------------------------------------------------------------------------
# _crawl_params_to_dict
# ---------------------------------------------------------------------------


class TestCrawlParamsToDict:
    def test_required_fields_present(self) -> None:
        params = CrawlParams(
            base_url="https://example.com/blog",
            crawl_instruction="Find all blog posts",
            transform_instruction="Extract title and summary",
        )
        result = _crawl_params_to_dict(params)

        assert result["baseUrl"] == "https://example.com/blog"
        assert result["crawlInstruction"] == "Find all blog posts"
        assert result["transformInstruction"] == "Extract title and summary"

    def test_optional_fields_excluded_when_none(self) -> None:
        params = CrawlParams(
            base_url="https://example.com",
            crawl_instruction="Find pages",
            transform_instruction="Extract data",
        )
        result = _crawl_params_to_dict(params)

        assert "maxPages" not in result
        assert "useProxy" not in result
        assert "proxyCountry" not in result
        assert "cookies" not in result

    def test_snake_to_camel_for_all_optional_fields(self) -> None:
        params = CrawlParams(
            base_url="https://example.com",
            crawl_instruction="Find pages",
            transform_instruction="Extract data",
            max_pages=50,
            use_proxy=True,
            proxy_country="gb",
            cookies="session=abc",
        )
        result = _crawl_params_to_dict(params)

        assert result["maxPages"] == 50
        assert result["useProxy"] is True
        assert result["proxyCountry"] == "gb"
        assert result["cookies"] == "session=abc"

    def test_base_url_key_is_camel_case(self) -> None:
        params = CrawlParams(
            base_url="https://example.com",
            crawl_instruction="x",
            transform_instruction="y",
        )
        result = _crawl_params_to_dict(params)
        # This is the most likely key to be wrong (base_url -> baseUrl)
        assert "base_url" not in result
        assert "baseUrl" in result

    def test_crawl_instruction_key_is_camel_case(self) -> None:
        params = CrawlParams(
            base_url="https://example.com",
            crawl_instruction="Find products",
            transform_instruction="Extract SKUs",
        )
        result = _crawl_params_to_dict(params)
        assert "crawl_instruction" not in result
        assert "crawlInstruction" in result
        assert "transform_instruction" not in result
        assert "transformInstruction" in result


# ---------------------------------------------------------------------------
# _parse_crawl_job
# ---------------------------------------------------------------------------


def _completed_payload() -> dict:  # type: ignore[type-arg]
    return {
        "status": "completed",
        "result": [
            {"url": "https://example.com/post-1", "title": "Post One", "data": {"summary": "First post"}},
            {"url": "https://example.com/post-2", "title": None, "data": None},
        ],
    }


class TestParseCrawlJob:
    def test_completed_returns_completed_type(self) -> None:
        result = _parse_crawl_job(_completed_payload())
        assert isinstance(result, CrawlJobCompleted)
        assert result.status == "completed"

    def test_completed_pages_parsed(self) -> None:
        result = _parse_crawl_job(_completed_payload())
        assert isinstance(result, CrawlJobCompleted)
        assert len(result.result) == 2

    def test_page_result_fields(self) -> None:
        result = _parse_crawl_job(_completed_payload())
        assert isinstance(result, CrawlJobCompleted)
        page = result.result[0]
        assert isinstance(page, CrawlPageResult)
        assert page.url == "https://example.com/post-1"
        assert page.title == "Post One"
        assert page.data == {"summary": "First post"}

    def test_page_with_no_title_or_data(self) -> None:
        result = _parse_crawl_job(_completed_payload())
        assert isinstance(result, CrawlJobCompleted)
        page2 = result.result[1]
        assert page2.title is None
        assert page2.data is None

    def test_failed_status(self) -> None:
        payload = {"status": "failed", "error": "Max pages exceeded"}
        result = _parse_crawl_job(payload)
        assert isinstance(result, CrawlJobFailed)
        assert result.status == "failed"
        assert result.error == "Max pages exceeded"

    def test_failed_with_no_error_message(self) -> None:
        payload = {"status": "failed"}
        result = _parse_crawl_job(payload)
        assert isinstance(result, CrawlJobFailed)
        assert result.error is None

    def test_waiting_status(self) -> None:
        payload = {"status": "waiting"}
        result = _parse_crawl_job(payload)
        assert isinstance(result, CrawlJobPending)
        assert result.status == "waiting"

    def test_active_status(self) -> None:
        payload = {"status": "active"}
        result = _parse_crawl_job(payload)
        assert isinstance(result, CrawlJobPending)

    def test_running_status(self) -> None:
        payload = {"status": "running", "progress": {"message": "Crawling...", "progress": 60}}
        result = _parse_crawl_job(payload)
        assert isinstance(result, CrawlJobPending)
        assert result.progress == {"message": "Crawling...", "progress": 60}

    def test_empty_result_list(self) -> None:
        payload = {"status": "completed", "result": []}
        result = _parse_crawl_job(payload)
        assert isinstance(result, CrawlJobCompleted)
        assert result.result == []
