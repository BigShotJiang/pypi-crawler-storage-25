"""
Unit tests for the batch serialiser and response parser.
"""
import pytest

from spidra.resources.batch import _batch_params_to_dict, _parse_batch_response
from spidra.types.batch import BatchScrapeParams, BatchScrapeResponse, BatchItem


# ---------------------------------------------------------------------------
# _batch_params_to_dict
# ---------------------------------------------------------------------------


class TestBatchParamsToDict:
    def test_minimal_required_fields(self) -> None:
        params = BatchScrapeParams(
            urls=["https://a.com", "https://b.com"],
            prompt="Extract the title",
        )
        result = _batch_params_to_dict(params)

        assert result["urls"] == ["https://a.com", "https://b.com"]
        assert result["prompt"] == "Extract the title"

    def test_urls_are_plain_strings_not_objects(self) -> None:
        """Batch URLs are strings, not ScrapeUrl objects — critical difference from scrape."""
        params = BatchScrapeParams(urls=["https://example.com"], prompt="test")
        result = _batch_params_to_dict(params)

        assert isinstance(result["urls"][0], str)

    def test_none_fields_excluded(self) -> None:
        params = BatchScrapeParams(urls=["https://a.com"], prompt="test")
        result = _batch_params_to_dict(params)

        assert "output" not in result
        assert "schema" not in result
        assert "useProxy" not in result
        assert "proxyCountry" not in result
        assert "extractContentOnly" not in result

    def test_snake_to_camel_conversion(self) -> None:
        params = BatchScrapeParams(
            urls=["https://a.com"],
            prompt="test",
            use_proxy=True,
            proxy_country="us",
            extract_content_only=False,
            full_page_screenshot=True,
        )
        result = _batch_params_to_dict(params)

        assert result["useProxy"] is True
        assert result["proxyCountry"] == "us"
        assert result["extractContentOnly"] is False
        assert result["fullPageScreenshot"] is True

    def test_output_format_included(self) -> None:
        params = BatchScrapeParams(urls=["https://a.com"], prompt="test", output="json")
        result = _batch_params_to_dict(params)
        assert result["output"] == "json"

    def test_schema_passed_through(self) -> None:
        schema = {"type": "object"}
        params = BatchScrapeParams(urls=["https://a.com"], prompt="test", schema=schema)
        result = _batch_params_to_dict(params)
        assert result["schema"] == schema

    def test_cookies_passed_as_string(self) -> None:
        params = BatchScrapeParams(
            urls=["https://a.com"],
            prompt="test",
            cookies="session=xyz",
        )
        result = _batch_params_to_dict(params)
        assert result["cookies"] == "session=xyz"


# ---------------------------------------------------------------------------
# _parse_batch_response
# ---------------------------------------------------------------------------


def _make_item(
    uuid: str = "item-1",
    url: str = "https://example.com",
    status: str = "completed",
    result: object = None,
    error: object = None,
) -> dict:  # type: ignore[type-arg]
    return {
        "uuid": uuid,
        "url": url,
        "jobId": "job-abc",
        "status": status,
        "result": result,
        "creditsUsed": 2,
        "startedAt": "2024-01-01T00:00:00Z",
        "finishedAt": "2024-01-01T00:00:05Z",
        "screenshotUrl": None,
        "error": error,
    }


class TestParseBatchResponse:
    def _full_payload(self) -> dict:  # type: ignore[type-arg]
        return {
            "status": "completed",
            "totalUrls": 3,
            "completedCount": 2,
            "failedCount": 1,
            "createdAt": "2024-01-01T00:00:00Z",
            "finishedAt": "2024-01-01T00:01:00Z",
            "items": [
                _make_item("item-1", "https://a.com", "completed", {"title": "A"}),
                _make_item("item-2", "https://b.com", "completed", {"title": "B"}),
                _make_item("item-3", "https://c.com", "failed", None, "Timeout"),
            ],
        }

    def test_returns_batch_scrape_response(self) -> None:
        result = _parse_batch_response(self._full_payload())
        assert isinstance(result, BatchScrapeResponse)

    def test_top_level_fields_parsed(self) -> None:
        result = _parse_batch_response(self._full_payload())
        assert result.status == "completed"
        assert result.total_urls == 3
        assert result.completed_count == 2
        assert result.failed_count == 1
        assert result.created_at == "2024-01-01T00:00:00Z"
        assert result.finished_at == "2024-01-01T00:01:00Z"

    def test_items_parsed(self) -> None:
        result = _parse_batch_response(self._full_payload())
        assert len(result.items) == 3

    def test_item_fields_mapped_from_camel(self) -> None:
        """jobId -> job_id, creditsUsed -> credits_used, etc."""
        result = _parse_batch_response(self._full_payload())
        item = result.items[0]
        assert isinstance(item, BatchItem)
        assert item.uuid == "item-1"
        assert item.url == "https://a.com"
        assert item.job_id == "job-abc"
        assert item.credits_used == 2
        assert item.started_at == "2024-01-01T00:00:00Z"
        assert item.finished_at == "2024-01-01T00:00:05Z"
        assert item.screenshot_url is None

    def test_failed_item_has_error(self) -> None:
        result = _parse_batch_response(self._full_payload())
        failed = result.items[2]
        assert failed.status == "failed"
        assert failed.error == "Timeout"
        assert failed.result is None

    def test_empty_items_list(self) -> None:
        payload = {
            "status": "pending",
            "totalUrls": 0,
            "completedCount": 0,
            "failedCount": 0,
            "createdAt": "2024-01-01T00:00:00Z",
            "finishedAt": None,
            "items": [],
        }
        result = _parse_batch_response(payload)
        assert result.items == []
        assert result.finished_at is None

    def test_cancelled_status(self) -> None:
        payload = {
            "status": "cancelled",
            "totalUrls": 5,
            "completedCount": 2,
            "failedCount": 0,
            "createdAt": "2024-01-01T00:00:00Z",
            "finishedAt": None,
            "items": [],
        }
        result = _parse_batch_response(payload)
        assert result.status == "cancelled"
