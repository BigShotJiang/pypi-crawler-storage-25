"""
Unit tests for the scrape serialiser (_params_to_dict) and response parser (_parse_scrape_job).
These are the riskiest parts of the SDK — they silently map Python snake_case to API camelCase.
"""
import pytest

from spidra.resources.scrape import _params_to_dict, _parse_scrape_job, _action_to_dict
from spidra.types.scrape import (
    ScrapeParams,
    ScrapeUrl,
    BrowserAction,
    BrowserActionPagination,
    ScrapeJobCompleted,
    ScrapeJobFailed,
    ScrapeJobPending,
)


# ---------------------------------------------------------------------------
# _params_to_dict
# ---------------------------------------------------------------------------


class TestParamsToDict:
    def test_minimal_required_fields(self) -> None:
        params = ScrapeParams(
            urls=[ScrapeUrl(url="https://example.com")],
            prompt="Extract the title",
        )
        result = _params_to_dict(params)

        assert result["urls"] == [{"url": "https://example.com"}]
        assert result["prompt"] == "Extract the title"

    def test_optional_fields_omitted_when_none(self) -> None:
        params = ScrapeParams(
            urls=[ScrapeUrl(url="https://example.com")],
            prompt="test",
        )
        result = _params_to_dict(params)

        # None fields must not appear in the dict — the API rejects unknown nulls
        assert "output" not in result
        assert "schema" not in result
        assert "useProxy" not in result
        assert "proxyCountry" not in result
        assert "extractContentOnly" not in result
        assert "screenshot" not in result
        assert "fullPageScreenshot" not in result
        assert "cookies" not in result

    def test_snake_case_converted_to_camel_case(self) -> None:
        params = ScrapeParams(
            urls=[ScrapeUrl(url="https://example.com")],
            prompt="test",
            use_proxy=True,
            proxy_country="ng",
            extract_content_only=True,
            full_page_screenshot=True,
        )
        result = _params_to_dict(params)

        assert result["useProxy"] is True
        assert result["proxyCountry"] == "ng"
        assert result["extractContentOnly"] is True
        assert result["fullPageScreenshot"] is True

    def test_output_and_schema_passed_through(self) -> None:
        schema = {"type": "object", "properties": {"title": {"type": "string"}}}
        params = ScrapeParams(
            urls=[ScrapeUrl(url="https://example.com")],
            prompt="test",
            output="json",
            schema=schema,
        )
        result = _params_to_dict(params)

        assert result["output"] == "json"
        assert result["schema"] == schema

    def test_multiple_urls(self) -> None:
        params = ScrapeParams(
            urls=[
                ScrapeUrl(url="https://a.com"),
                ScrapeUrl(url="https://b.com"),
                ScrapeUrl(url="https://c.com"),
            ],
            prompt="test",
        )
        result = _params_to_dict(params)

        assert len(result["urls"]) == 3
        assert result["urls"][1]["url"] == "https://b.com"

    def test_cookies_sent_as_string(self) -> None:
        params = ScrapeParams(
            urls=[ScrapeUrl(url="https://example.com")],
            prompt="test",
            cookies="session=abc; token=xyz",
        )
        result = _params_to_dict(params)
        assert result["cookies"] == "session=abc; token=xyz"


# ---------------------------------------------------------------------------
# _action_to_dict  (browser actions serialisation)
# ---------------------------------------------------------------------------


class TestActionToDict:
    def test_click_with_selector(self) -> None:
        action = BrowserAction(type="click", selector="#accept-cookies")
        result = _action_to_dict(action)

        assert result["type"] == "click"
        assert result["selector"] == "#accept-cookies"
        assert "value" not in result  # None fields omitted

    def test_wait_action(self) -> None:
        action = BrowserAction(type="wait", duration=2000)
        result = _action_to_dict(action)

        assert result["type"] == "wait"
        assert result["duration"] == 2000

    def test_scroll_action(self) -> None:
        action = BrowserAction(type="scroll", to="80%")
        result = _action_to_dict(action)

        assert result["type"] == "scroll"
        assert result["to"] == "80%"

    def test_foreach_inline_snake_to_camel(self) -> None:
        action = BrowserAction(
            type="forEach",
            observe="Find all product cards",
            mode="inline",
            capture_selector="article.product_pod",
            max_items=20,
            item_prompt="Extract title and price",
            wait_after_click=800,
        )
        result = _action_to_dict(action)

        assert result["type"] == "forEach"
        assert result["observe"] == "Find all product cards"
        assert result["mode"] == "inline"
        assert result["captureSelector"] == "article.product_pod"
        assert result["maxItems"] == 20
        assert result["itemPrompt"] == "Extract title and price"
        assert result["waitAfterClick"] == 800

    def test_foreach_pagination(self) -> None:
        action = BrowserAction(
            type="forEach",
            observe="Find links",
            mode="navigate",
            pagination=BrowserActionPagination(next_selector="li.next > a", max_pages=3),
        )
        result = _action_to_dict(action)

        assert "pagination" in result
        assert result["pagination"]["nextSelector"] == "li.next > a"
        assert result["pagination"]["maxPages"] == 3

    def test_nested_per_element_actions(self) -> None:
        action = BrowserAction(
            type="forEach",
            observe="Find items",
            mode="navigate",
            actions=[
                BrowserAction(type="scroll", to="50%"),
            ],
        )
        result = _action_to_dict(action)

        assert isinstance(result["actions"], list)
        assert result["actions"][0]["type"] == "scroll"
        assert result["actions"][0]["to"] == "50%"

    def test_url_entry_with_actions(self) -> None:
        params = ScrapeParams(
            urls=[
                ScrapeUrl(
                    url="https://example.com",
                    actions=[BrowserAction(type="click", selector="#btn")],
                )
            ],
            prompt="test",
        )
        result = _params_to_dict(params)
        url_entry = result["urls"][0]

        assert "actions" in url_entry
        assert url_entry["actions"][0]["type"] == "click"
        assert url_entry["actions"][0]["selector"] == "#btn"

    def test_url_instruction_field(self) -> None:
        params = ScrapeParams(
            urls=[ScrapeUrl(url="https://example.com", instruction="Click the login button and fill in credentials")],
            prompt="test",
        )
        result = _params_to_dict(params)
        assert result["urls"][0]["instruction"] == "Click the login button and fill in credentials"


# ---------------------------------------------------------------------------
# _parse_scrape_job  (response parsing)
# ---------------------------------------------------------------------------


class TestParseScrapejob:
    def _completed_payload(self) -> dict:  # type: ignore[type-arg]
        return {
            "status": "completed",
            "result": {
                "content": {"title": "Hello World"},
                "data": [
                    {
                        "url": "https://example.com",
                        "success": True,
                        "title": "Example",
                        "markdownContent": "# Hello",
                        "screenshotUrl": None,
                    }
                ],
                "screenshots": [],
                "ai_extraction_failed": False,
                "stats": {
                    "durationMs": 1200,
                    "captchaSolvedCount": 0,
                    "inputTokens": 100,
                    "outputTokens": 50,
                    "totalTokens": 150,
                },
            },
            "error": None,
        }

    def test_completed_status_returns_completed_type(self) -> None:
        result = _parse_scrape_job(self._completed_payload())
        assert isinstance(result, ScrapeJobCompleted)
        assert result.status == "completed"

    def test_completed_content_parsed(self) -> None:
        result = _parse_scrape_job(self._completed_payload())
        assert isinstance(result, ScrapeJobCompleted)
        assert result.result.content == {"title": "Hello World"}

    def test_completed_url_result_parsed(self) -> None:
        result = _parse_scrape_job(self._completed_payload())
        assert isinstance(result, ScrapeJobCompleted)
        assert len(result.result.data) == 1
        url_result = result.result.data[0]
        assert url_result.url == "https://example.com"
        assert url_result.success is True
        assert url_result.title == "Example"
        assert url_result.markdown_content == "# Hello"

    def test_completed_stats_parsed(self) -> None:
        result = _parse_scrape_job(self._completed_payload())
        assert isinstance(result, ScrapeJobCompleted)
        stats = result.result.stats
        assert stats.duration_ms == 1200
        assert stats.input_tokens == 100
        assert stats.output_tokens == 50
        assert stats.total_tokens == 150
        assert stats.captcha_solved_count == 0

    def test_failed_status_returns_failed_type(self) -> None:
        payload = {"status": "failed", "error": "Page could not be rendered"}
        result = _parse_scrape_job(payload)
        assert isinstance(result, ScrapeJobFailed)
        assert result.status == "failed"
        assert result.error == "Page could not be rendered"

    def test_waiting_status_returns_pending_type(self) -> None:
        payload = {"status": "waiting"}
        result = _parse_scrape_job(payload)
        assert isinstance(result, ScrapeJobPending)
        assert result.status == "waiting"

    def test_active_status_returns_pending_type(self) -> None:
        payload = {"status": "active", "progress": {"message": "Scraping page...", "progress": 40}}
        result = _parse_scrape_job(payload)
        assert isinstance(result, ScrapeJobPending)
        assert result.progress == {"message": "Scraping page...", "progress": 40}

    def test_empty_data_array(self) -> None:
        payload = {
            "status": "completed",
            "result": {
                "content": None,
                "data": [],
                "screenshots": [],
                "ai_extraction_failed": True,
                "stats": {
                    "durationMs": 0, "captchaSolvedCount": 0,
                    "inputTokens": 0, "outputTokens": 0, "totalTokens": 0,
                },
            },
        }
        result = _parse_scrape_job(payload)
        assert isinstance(result, ScrapeJobCompleted)
        assert result.result.data == []
        assert result.result.ai_extraction_failed is True
