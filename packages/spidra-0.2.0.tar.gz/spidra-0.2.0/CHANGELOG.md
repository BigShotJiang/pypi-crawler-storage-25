# Changelog

All notable changes to the Spidra Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-04-19

### Added
- **Initial Python SDK Beta Release!** 
- Fully mirrored feature set from the Node.js (`spidra-js`) SDK.
- Strong type hinting across the entire library via Python Dataclasses and `mypy --strict` compliance.
- Complete `httpx` based asynchronous client mimicking `SpidraClient` architecture.
- Full resource implementations mapping:
  - `spidra.scrape`
  - `spidra.batch`
  - `spidra.crawl`
  - `spidra.logs`
  - `spidra.usage`
- Exposed sync wrapper variants (`*_sync`) for all async methods utilizing `asyncio.run()` (e.g. `run_sync`, `submit_sync`).
- Robust Automatic Retry framework utilizing exponential backoff on transient errors (`502`, `503`, `504` and `QUEUE_UNAVAILABLE`).
- Added exhaustive testing coverage with `pytest` matching all expected response schemas correctly.
- PEP 561 compliance marker (`py.typed`) included.
