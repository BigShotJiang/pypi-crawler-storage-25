# Intro

[![PyPiVersion](https://img.shields.io/pypi/v/llm-function-tools)](https://pypi.org/project/llm-function-tools/) 

`llm_function_tools` is an extension component for
[`llm_function`](https://pypi.org/project/llm-function/).

It provides small helpers for defining tools used by reusable LLM functions, including
tools stored in standalone `.py` files.


## Installation

```bash
pip install llm-function-tools
```

