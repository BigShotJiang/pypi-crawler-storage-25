from setuptools import setup

import codecs
import os

here = os.path.abspath(os.path.dirname(__file__))
path_to_readme = os.path.join(here, "README.md")

long_description = """# Llm function tools

`llm_function_tools` is an extension component for
[`llm_function`](https://pypi.org/project/llm-function/).

It provides small helpers for defining tools used by reusable LLM functions, including
tools stored in standalone `.py` files.

"""

if os.path.exists(path_to_readme):
  with codecs.open(path_to_readme, encoding="utf-8") as fh:
      long_description += fh.read()

setup(
    name="llm_function_tools",
    packages=["llm_function_tools"],
    install_requires=['pydantic'],
    classifiers=['Development Status :: 3 - Alpha'],
    long_description=long_description,
    long_description_content_type='text/markdown',
    author="Kyrylo Mordan",
    author_email="parachute.repo@gmail.com",
    description="Minimal metadata and discovery helpers for typed Python tools used by llm_function runtimes.",
    url="https://kiril-mordan.github.io/adaptive-reusables/llm-function-tools/",
    keywords=['aa-paa-tool'],
    version="0.0.1",
    license = "apache-2.0",
    include_package_data = True,
    package_data = {'llm_function_tools': ['mkdocs/**/*', 'artifacts/.paa.tracking/git/**/*', 'artifacts/.paa.tracking/git_repo/**/*', '.paa.tracking/version_logs.csv', '.paa.tracking/release_notes.md', '.paa.tracking/lsts_package_versions.yml', '.paa.tracking/notebook.ipynb', '.paa.tracking/package_mapping.json', '.paa.tracking/package_licenses.json', '.paa.tracking/.paa.config', '.paa.tracking/git/**/*', '.paa.tracking/git_repo/**/*', '.paa.tracking/python_modules/llm_function_tools.py', '.paa.tracking/.paa.version']} ,
    license_files = ["LICENSE", "NOTICE"],
    )
