
"""
`llm_function_tools` is an extension component for
[`llm_function`](https://pypi.org/project/llm-function/).

It provides small helpers for defining tools used by reusable LLM functions, including
tools stored in standalone `.py` files.
"""
from .llm_function_tools import *
__version__='0.0.1'