from __future__ import annotations

from pathlib import Path

import pytest
from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.shared import Pt, RGBColor


@pytest.fixture()
def sample_docx(tmp_path: Path) -> Path:
    path = tmp_path / "template.docx"
    document = Document()

    body_style = document.styles.add_style("BodyText", WD_STYLE_TYPE.PARAGRAPH)
    body_style.name = "Body Text"
    body_style.base_style = document.styles["Normal"]
    body_style.font.name = "Calibri"
    body_style.font.size = Pt(11)
    body_style.paragraph_format.space_after = Pt(8)

    status_style = document.styles.add_style("StatusGreen", WD_STYLE_TYPE.CHARACTER)
    status_style.name = "Status Green"
    status_style.font.color.rgb = RGBColor(0x00, 0x80, 0x00)
    status_style.font.bold = True

    heading = document.add_paragraph("Quarterly Report", style="Heading 1")
    heading.paragraph_format.space_after = Pt(12)

    paragraph = document.add_paragraph(style="Body Text")
    paragraph.add_run("Delivery is ")
    run = paragraph.add_run("on track")
    run.style = "Status Green"
    paragraph.add_run(" for the current quarter.")

    document.sections[0].header.paragraphs[0].text = "Acme Header"
    document.sections[0].footer.paragraphs[0].text = "Acme Footer"
    document.core_properties.title = "Template Title"
    document.core_properties.author = "Raphael"
    document.save(path)
    return path
