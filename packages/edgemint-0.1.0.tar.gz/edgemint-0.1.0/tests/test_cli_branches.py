from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from edgemint.cli import app
from edgemint.errors import FileError, PandocError
from edgemint.schema.models import MetaInfo, Style, StyleSheet, StyleType

runner = CliRunner()


def test_extract_styles_command_filter_and_warning(monkeypatch, tmp_path: Path) -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(style_id="P", name="P", type=StyleType.PARAGRAPH),
            Style(style_id="C", name="C", type=StyleType.CHARACTER),
        ],
    )
    monkeypatch.setattr(
        "edgemint.cli.extract_stylesheet",
        lambda path, include_resolved=True: (stylesheet, ["warn"]),
    )
    path = tmp_path / "in.docx"
    path.write_bytes(b"x")
    out = tmp_path / "styles.json"

    result = runner.invoke(
        app, ["extract-styles", str(path), "-o", str(out), "--filter", "paragraph"]
    )
    assert result.exit_code == 0
    assert "WARNING: warn" in result.stderr
    assert '"style_id": "P"' in out.read_text(encoding="utf-8")
    assert '"style_id": "C"' not in out.read_text(encoding="utf-8")


def test_extract_styles_command_handles_typed_errors(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        "edgemint.cli.extract_stylesheet",
        lambda *args, **kwargs: (_ for _ in ()).throw(FileError("boom")),
    )
    path = tmp_path / "in.docx"
    path.write_bytes(b"x")
    out = tmp_path / "styles.json"
    result = runner.invoke(app, ["extract-styles", str(path), "-o", str(out)])
    assert result.exit_code != 0
    assert "boom" in result.stderr


def test_extract_command_handles_typed_errors(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        "edgemint.cli.extract_document_bundle",
        lambda *args, **kwargs: (_ for _ in ()).throw(FileError("boom")),
    )
    path = tmp_path / "in.docx"
    path.write_bytes(b"x")
    result = runner.invoke(app, ["extract", str(path), "-o", str(tmp_path / "out")])
    assert result.exit_code != 0


def test_extract_command_prints_warnings(monkeypatch, tmp_path: Path) -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
    )
    monkeypatch.setattr(
        "edgemint.cli.extract_document_bundle",
        lambda *args, **kwargs: (stylesheet, ["warn"]),
    )
    path = tmp_path / "in.docx"
    path.write_bytes(b"x")
    result = runner.invoke(app, ["extract", str(path), "-o", str(tmp_path / "out")])
    assert result.exit_code == 0
    assert "WARNING: warn" in result.stderr


def test_apply_command_handles_typed_errors(monkeypatch, tmp_path: Path) -> None:
    styles = tmp_path / "styles.json"
    styles.write_text(
        '{"schema_version":"edgemint/v1","meta":{"source_file":"x","extracted_at":"2026-04-12T00:00:00+00:00"},"styles":[]}',
        encoding="utf-8",
    )
    md = tmp_path / "content.md"
    md.write_text("hello", encoding="utf-8")
    monkeypatch.setattr(
        "edgemint.cli.apply_stylesheet",
        lambda *args, **kwargs: (_ for _ in ()).throw(FileError("boom")),
    )
    result = runner.invoke(
        app, ["apply-styles", str(md), str(styles), "-o", str(tmp_path / "o.docx")]
    )
    assert result.exit_code != 0


def test_apply_command_accepts_input_format(monkeypatch, tmp_path: Path) -> None:
    styles = tmp_path / "styles.json"
    styles.write_text(
        '{"schema_version":"edgemint/v1","meta":{"source_file":"x","extracted_at":"2026-04-12T00:00:00+00:00"},"styles":[]}',
        encoding="utf-8",
    )
    source = tmp_path / "content.adoc"
    source.write_text("= Report\nRaphael\n\nBody", encoding="utf-8")
    captured: dict[str, object] = {}

    def fake_apply_stylesheet(*args, **kwargs):
        captured.update(kwargs)

    monkeypatch.setattr("edgemint.cli.apply_stylesheet", fake_apply_stylesheet)
    result = runner.invoke(
        app,
        [
            "apply-styles",
            str(source),
            str(styles),
            "-o",
            str(tmp_path / "o.docx"),
            "--input-format",
            "asciidoc",
        ],
    )
    assert result.exit_code == 0
    assert str(captured["input_format"]) == "asciidoc"


def test_diff_command_reports_changes(tmp_path: Path) -> None:
    before = tmp_path / "before.json"
    after = tmp_path / "after.json"
    before.write_text(
        '{"schema_version":"edgemint/v1","meta":{"source_file":"x","extracted_at":"2026-04-12T00:00:00+00:00"},"styles":[{"style_id":"A","name":"A","type":"paragraph"}]}',
        encoding="utf-8",
    )
    after.write_text(
        '{"schema_version":"edgemint/v1","meta":{"source_file":"x","extracted_at":"2026-04-12T00:00:00+00:00"},"styles":[{"style_id":"B","name":"B","type":"paragraph"}]}',
        encoding="utf-8",
    )
    result = runner.invoke(app, ["diff", str(before), str(after)])
    assert result.exit_code == 0
    assert "ADDED B" in result.stdout
    assert "REMOVED A" in result.stdout


def test_info_command_handles_errors(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        "edgemint.cli.extract_stylesheet",
        lambda *args, **kwargs: (_ for _ in ()).throw(FileError("boom")),
    )
    path = tmp_path / "in.docx"
    path.write_bytes(b"x")
    result = runner.invoke(app, ["info", str(path)])
    assert result.exit_code != 0


def test_strict_mode_fails_on_warnings(monkeypatch, tmp_path: Path) -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[Style(style_id="P", name="P", type=StyleType.PARAGRAPH)],
    )
    monkeypatch.setattr(
        "edgemint.cli.extract_stylesheet",
        lambda *args, **kwargs: (stylesheet, ["Unsupported construct detected: tracked changes"]),
    )
    path = tmp_path / "in.docx"
    path.write_bytes(b"x")

    result = runner.invoke(
        app, ["extract-styles", str(path), "-o", str(tmp_path / "x.json"), "--strict"]
    )
    assert result.exit_code == 1
    assert "Strict mode aborted extraction" in result.stderr


def test_apply_command_surfaces_pandoc_error(monkeypatch, tmp_path: Path) -> None:
    styles = tmp_path / "styles.json"
    styles.write_text(
        '{"schema_version":"edgemint/v1","meta":{"source_file":"x","extracted_at":"2026-04-12T00:00:00+00:00"},"styles":[]}',
        encoding="utf-8",
    )
    source = tmp_path / "content.adoc"
    source.write_text("= Report\n\nBody", encoding="utf-8")
    monkeypatch.setattr(
        "edgemint.cli.apply_stylesheet",
        lambda *args, **kwargs: (_ for _ in ()).throw(PandocError("pandoc required")),
    )
    result = runner.invoke(
        app,
        [
            "apply-styles",
            str(source),
            str(styles),
            "-o",
            str(tmp_path / "o.docx"),
            "--input-format",
            "asciidoc",
        ],
    )
    assert result.exit_code == 4
    assert "pandoc required" in result.stderr
