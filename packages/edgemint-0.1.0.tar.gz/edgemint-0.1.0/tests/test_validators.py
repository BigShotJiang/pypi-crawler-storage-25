from edgemint.schema.validators import (
    emu_to_pt,
    half_pt_to_pt,
    pt_to_emu,
    pt_to_half_pt,
    pt_to_twips,
    twips_to_pt,
)


def test_twips_round_trip() -> None:
    assert twips_to_pt(240) == 12.0
    assert pt_to_twips(12.0) == 240


def test_half_points_round_trip() -> None:
    assert half_pt_to_pt(22) == 11.0
    assert pt_to_half_pt(11.0) == 22


def test_emu_round_trip() -> None:
    assert emu_to_pt(12700) == 1.0
    assert pt_to_emu(1.0) == 12700
