from edgemint.markdown import (
    _is_table_block,
    _parse_basic_inlines,
    _parse_metadata,
    _split_table_row,
    parse_markdown,
)


def test_markdown_helpers_cover_table_and_metadata_edges() -> None:
    assert _parse_metadata(["plain"]) == ({}, 0)
    assert _is_table_block(["| a |", "|---|"]) is True
    assert _is_table_block(["short"]) is False
    assert _split_table_row("| a | b |") == ["a", "b"]


def test_parse_markdown_supports_table_style_and_multiline_paragraph() -> None:
    document = parse_markdown(
        """::: {custom-style="Table Grid"}
| A | B |
|---|---|
| 1 | 2 |
:::

first line
second line
"""
    )
    assert document.blocks[0].kind == "table"
    assert document.blocks[0].style == "Table Grid"
    assert document.blocks[1].text == "first line second line"


def test_parse_markdown_supports_plain_table_block() -> None:
    document = parse_markdown(
        """| A | B |
|---|---|
| 1 | 2 |
"""
    )
    assert document.blocks[0].kind == "table"


def test_parse_basic_inlines_preserves_plain_tail() -> None:
    chunks = _parse_basic_inlines("x **b** *i* `c` z")
    assert [chunk.text for chunk in chunks] == ["x ", "b", " ", "i", " ", "c", " z"]


def test_parse_markdown_stops_list_when_non_list_line_appears() -> None:
    document = parse_markdown(
        """- one
- two
after
"""
    )
    assert document.blocks[0].kind == "list"
    assert document.blocks[1].kind == "paragraph"
