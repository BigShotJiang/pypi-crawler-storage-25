from __future__ import annotations

import json
from base64 import b64encode
from pathlib import Path
from zipfile import ZipFile

from docx import Document
from lxml import etree
from typer.testing import CliRunner

from edgemint.cli import app

runner = CliRunner()
ROOT = Path(__file__).resolve().parent
FIXTURES_DIR = ROOT / "golden" / "fixtures"
EXPECTED_DIR = ROOT / "golden" / "expected"
CONTENT_TYPES_NS = {"ct": "http://schemas.openxmlformats.org/package/2006/content-types"}
STYLE_PACKAGE_PARTS = {
    "word/styles.xml",
    "word/numbering.xml",
    "word/theme/theme1.xml",
    "word/fontTable.xml",
    "word/_rels/fontTable.xml.rels",
}


def _fixture_names() -> list[str]:
    if not FIXTURES_DIR.exists():
        return []
    return sorted(item.name for item in FIXTURES_DIR.iterdir() if (item / "source.docx").exists())


def test_golden_extract_and_apply(tmp_path: Path) -> None:
    fixture_names = _fixture_names()
    assert fixture_names, "golden fixtures are missing; run scripts/download_golden_fixtures.sh"

    for name in fixture_names:
        source_docx = FIXTURES_DIR / name / "source.docx"
        expected_dir = EXPECTED_DIR / name
        assert expected_dir.exists(), f"missing expected dataset for {name}"

        bundle_dir = tmp_path / name / "bundle"
        result = runner.invoke(app, ["extract", str(source_docx), "-o", str(bundle_dir)])
        assert result.exit_code == 0, result.stdout

        actual_styles = json.loads((bundle_dir / "styles.json").read_text(encoding="utf-8"))
        expected_styles = json.loads((expected_dir / "styles.json").read_text(encoding="utf-8"))
        actual_styles["meta"]["extracted_at"] = "<normalized>"
        actual_styles["meta"]["pandoc_version"] = "<normalized>"
        assert actual_styles == expected_styles

        assert (bundle_dir / "content.md").read_text(encoding="utf-8") == (
            expected_dir / "content.md"
        ).read_text(encoding="utf-8")
        assert (bundle_dir / "content.adoc").read_text(encoding="utf-8") == (
            expected_dir / "content.adoc"
        ).read_text(encoding="utf-8")
        expected_summary = json.loads((expected_dir / "summary.json").read_text(encoding="utf-8"))
        actual_media = sorted(path.name for path in (bundle_dir / "media").iterdir())
        assert actual_media == expected_summary["media_files"]

        output_docx = tmp_path / name / "roundtrip.docx"
        result = runner.invoke(
            app,
            [
                "apply-styles",
                str(expected_dir / "content.md"),
                str(expected_dir / "styles.json"),
                "-o",
                str(output_docx),
                "--media",
                str(expected_dir / "media"),
            ],
        )
        assert result.exit_code == 0, result.stdout

        expected_snapshot = json.loads(
            (expected_dir / "apply_snapshot.json").read_text(encoding="utf-8")
        )
        assert _snapshot_docx(output_docx) == expected_snapshot
        _assert_style_package_preserved(source_docx, output_docx)

        adoc_output_docx = tmp_path / name / "roundtrip-adoc.docx"
        result = runner.invoke(
            app,
            [
                "apply-styles",
                str(expected_dir / "content.adoc"),
                str(expected_dir / "styles.json"),
                "-o",
                str(adoc_output_docx),
                "--media",
                str(expected_dir / "media"),
                "--input-format",
                "asciidoc",
            ],
        )
        assert result.exit_code == 0, result.stdout
        expected_adoc_snapshot = json.loads(
            (expected_dir / "apply_snapshot_adoc.json").read_text(encoding="utf-8")
        )
        assert _snapshot_docx(adoc_output_docx) == expected_adoc_snapshot
        _assert_style_package_preserved(source_docx, adoc_output_docx)


def _snapshot_docx(path: Path) -> dict:
    document = Document(path)
    with ZipFile(path) as archive:
        zip_names = sorted(archive.namelist())
    return {
        "paragraphs": [
            {"text": paragraph.text, "style": paragraph.style.name if paragraph.style else None}
            for paragraph in document.paragraphs
        ],
        "tables": [
            [[cell.text for cell in row.cells] for row in table.rows] for table in document.tables
        ],
        "core_properties": {
            "title": document.core_properties.title,
            "author": document.core_properties.author,
        },
        "zip_entries": zip_names,
    }


def _style_package_snapshot(path: Path) -> dict:
    with ZipFile(path) as archive:
        names = set(archive.namelist())
        relevant_parts = sorted(
            STYLE_PACKAGE_PARTS.union(name for name in names if name.startswith("word/fonts/"))
            & names
        )
        package_parts = {
            name: b64encode(archive.read(name)).decode("ascii") for name in relevant_parts
        }
        content_types = _style_content_types_snapshot(archive, set(relevant_parts))
    return {
        "parts": package_parts,
        "content_types": content_types,
    }


def _assert_style_package_preserved(source_docx: Path, output_docx: Path) -> None:
    source_snapshot = _style_package_snapshot(source_docx)
    output_snapshot = _style_package_snapshot(output_docx)

    for part_name, content in source_snapshot["parts"].items():
        assert output_snapshot["parts"].get(part_name) == content
    for default_item in source_snapshot["content_types"]["defaults"]:
        assert default_item in output_snapshot["content_types"]["defaults"]
    for override_item in source_snapshot["content_types"]["overrides"]:
        assert override_item in output_snapshot["content_types"]["overrides"]


def _style_content_types_snapshot(
    archive: ZipFile, relevant_parts: set[str]
) -> dict[str, list[list[str]]]:
    root = etree.fromstring(archive.read("[Content_Types].xml"))
    relevant_part_names = {
        f"/{name}" if not name.startswith("/") else name for name in relevant_parts
    }
    relevant_extensions = {
        name.rsplit(".", 1)[1] for name in relevant_parts if "." in Path(name).name
    }
    defaults = sorted(
        [
            [node.get("Extension", ""), node.get("ContentType", "")]
            for node in root.findall("ct:Default", CONTENT_TYPES_NS)
            if node.get("Extension") in relevant_extensions
        ]
    )
    overrides = sorted(
        [
            [node.get("PartName", ""), node.get("ContentType", "")]
            for node in root.findall("ct:Override", CONTENT_TYPES_NS)
            if node.get("PartName") in relevant_part_names
        ]
    )
    return {"defaults": defaults, "overrides": overrides}
