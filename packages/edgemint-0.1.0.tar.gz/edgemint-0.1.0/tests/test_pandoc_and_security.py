from __future__ import annotations

import sys
import types
from pathlib import Path
from types import SimpleNamespace

import pytest

from edgemint.errors import PandocError, SecurityError
from edgemint.extract.security import validate_docx_archive
from edgemint.pandoc import _discover_pandoc, get_pandoc_version, has_pandoc, run_pandoc


class _Archive:
    def __init__(self, infos):
        self._infos = infos

    def infolist(self):
        return self._infos


def test_validate_docx_archive_rejects_unsafe_paths() -> None:
    archive = _Archive([SimpleNamespace(filename="../evil.xml", file_size=1)])
    with pytest.raises(SecurityError):
        validate_docx_archive(archive)


def test_validate_docx_archive_rejects_oversized_archives() -> None:
    archive = _Archive([SimpleNamespace(filename="word/document.xml", file_size=200 * 1024 * 1024)])
    with pytest.raises(SecurityError):
        validate_docx_archive(archive)


def test_discover_pandoc_prefers_system_pandoc_on_path(monkeypatch: pytest.MonkeyPatch) -> None:
    """Covers the early-return path when pandoc is found via shutil.which (line 47)."""
    monkeypatch.setattr("edgemint.pandoc.shutil.which", lambda _: "/usr/bin/pandoc")
    assert _discover_pandoc() == "/usr/bin/pandoc"


def test_discover_pandoc_uses_pypandoc_when_path_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("edgemint.pandoc.shutil.which", lambda _: None)

    class FakePypandoc:
        @staticmethod
        def get_pandoc_path() -> str:
            return "/tmp/pandoc"

    monkeypatch.setitem(sys.modules, "pypandoc", FakePypandoc)
    assert _discover_pandoc() == "/tmp/pandoc"


def test_discover_pandoc_returns_none_when_pypandoc_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("edgemint.pandoc.shutil.which", lambda _: None)
    monkeypatch.delitem(sys.modules, "pypandoc", raising=False)

    real_import = __import__

    def fake_import(name, *args, **kwargs):
        if name == "pypandoc":
            raise ImportError
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", fake_import)
    assert _discover_pandoc() is None


def test_discover_pandoc_returns_none_on_oerror(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("edgemint.pandoc.shutil.which", lambda _: None)

    fake_pypandoc = types.ModuleType("pypandoc")

    def _raise_oserror() -> str:
        raise OSError("pandoc binary not found")

    fake_pypandoc.get_pandoc_path = _raise_oserror  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "pypandoc", fake_pypandoc)
    assert _discover_pandoc() is None


def test_get_pandoc_version_handles_subprocess_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("edgemint.pandoc._discover_pandoc", lambda: "/tmp/pandoc")
    monkeypatch.setattr(
        "edgemint.pandoc.subprocess.run",
        lambda *args, **kwargs: SimpleNamespace(returncode=1, stdout="", stderr="boom"),
    )
    assert get_pandoc_version() is None


def test_has_pandoc_reflects_discovery(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("edgemint.pandoc._discover_pandoc", lambda: None)
    assert has_pandoc() is False


def test_run_pandoc_raises_typed_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("edgemint.pandoc._discover_pandoc", lambda: "/tmp/pandoc")
    monkeypatch.setattr(
        "edgemint.pandoc.subprocess.run",
        lambda *args, **kwargs: SimpleNamespace(returncode=1, stdout="", stderr="failed"),
    )
    with pytest.raises(PandocError):
        run_pandoc(["--version"], workdir=Path("."))
