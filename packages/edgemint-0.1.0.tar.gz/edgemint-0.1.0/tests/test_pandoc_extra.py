import pytest

from edgemint.errors import PandocError
from edgemint.pandoc import get_pandoc_version, run_pandoc


def test_get_pandoc_version_when_missing(monkeypatch) -> None:
    monkeypatch.setattr("edgemint.pandoc._discover_pandoc", lambda: None)
    assert get_pandoc_version() is None


def test_run_pandoc_when_missing(monkeypatch) -> None:
    monkeypatch.setattr("edgemint.pandoc._discover_pandoc", lambda: None)
    with pytest.raises(PandocError):
        run_pandoc(["--version"])
