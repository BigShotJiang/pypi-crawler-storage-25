from __future__ import annotations

import json
from base64 import b64encode
from pathlib import Path
from zipfile import ZipFile

from docx import Document
from lxml import etree
from typer.testing import CliRunner

from edgemint.cli import app

runner = CliRunner()
ROOT = Path(__file__).resolve().parents[1]
EXAMPLES_DIR = ROOT / "examples"
CONTENT_TYPES_NS = {"ct": "http://schemas.openxmlformats.org/package/2006/content-types"}
STYLE_PACKAGE_PARTS = {
    "word/styles.xml",
    "word/numbering.xml",
    "word/theme/theme1.xml",
    "word/fontTable.xml",
    "word/_rels/fontTable.xml.rels",
}


def test_packt_template_extracts_styles_and_bundle(tmp_path: Path) -> None:
    styles_path = tmp_path / "packt-style.styles.json"
    bundle_dir = tmp_path / "packt-style.bundle"

    result = runner.invoke(
        app,
        [
            "extract-styles",
            str(EXAMPLES_DIR / "packt-style.docx"),
            "-o",
            str(styles_path),
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert styles_path.exists()

    result = runner.invoke(
        app,
        [
            "extract",
            str(EXAMPLES_DIR / "packt-style.docx"),
            "-o",
            str(bundle_dir),
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert (bundle_dir / "styles.json").exists()
    assert (bundle_dir / "content.md").read_text(encoding="utf-8").strip() == ""
    assert (bundle_dir / "content.adoc").read_text(encoding="utf-8").strip() == ""


def test_packt_representative_markdown_renders_to_docx(tmp_path: Path) -> None:
    styles_path = tmp_path / "packt-style.styles.json"
    output_path = tmp_path / "packt-style-example.docx"

    result = runner.invoke(
        app,
        [
            "extract-styles",
            str(EXAMPLES_DIR / "packt-style.docx"),
            "-o",
            str(styles_path),
        ],
    )
    assert result.exit_code == 0, result.stdout

    result = runner.invoke(
        app,
        [
            "apply-styles",
            str(EXAMPLES_DIR / "packt-style-example.md"),
            str(styles_path),
            "-o",
            str(output_path),
            "--media",
            str(EXAMPLES_DIR),
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert output_path.exists()

    document = Document(output_path)
    text = "\n".join(paragraph.text for paragraph in document.paragraphs)
    assert "Representative Markdown Surface for the Packt Template" in text
    assert "Built-In Heading Mapping" in text
    assert "After the Forced Break" in text
    assert document.tables
    assert document.core_properties.title == "EdgeMint Packt Style Demonstration"
    assert document.core_properties.author == "Raphael Mansuy"

    with ZipFile(output_path) as archive:
        zip_entries = set(archive.namelist())
        document_xml = archive.read("word/document.xml")
        footnotes_xml = archive.read("word/footnotes.xml")
    assert any(name.startswith("word/media/") for name in zip_entries)
    assert b"Bullet list item one using the native Markdown list reader." in document_xml
    assert b"Numbered list item one." in document_xml
    assert b"footnoteReference" in document_xml
    assert b'w:pStyle w:val="L1-Bullet"' in document_xml
    assert b'w:pStyle w:val="L1-Numbered"' in document_xml
    assert b'w:pStyle w:val="C0-CodeBlock"' in document_xml
    assert b'w:rStyle w:val="CS-InlineCode"' in document_xml
    assert b'w:pStyle w:val="Title"' not in document_xml
    assert b'w:pStyle w:val="Author"' not in document_xml
    assert b'w:numId w:val="1001"' not in document_xml
    assert b'w:numId w:val="1002"' not in document_xml
    assert b"SourceCode" not in document_xml
    assert b"VerbatimChar" not in document_xml
    assert b"Footnotes survive the Pandoc path" in footnotes_xml

    root = etree.fromstring(document_xml)
    numbering_paragraphs = root.xpath(
        ".//w:p[w:pPr/w:numPr]",
        namespaces={"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"},
    )
    assert numbering_paragraphs


def test_packt_book_chapter_avoids_fallback_title_block_styles(tmp_path: Path) -> None:
    styles_path = tmp_path / "packt-style.styles.json"
    output_path = tmp_path / "packt-book-chapter.docx"

    extract_result = runner.invoke(
        app,
        [
            "extract-styles",
            str(EXAMPLES_DIR / "packt-style.docx"),
            "-o",
            str(styles_path),
        ],
    )
    assert extract_result.exit_code == 0, extract_result.stdout

    apply_result = runner.invoke(
        app,
        [
            "apply-styles",
            str(EXAMPLES_DIR / "packt-book-chapter.md"),
            str(styles_path),
            "-o",
            str(output_path),
        ],
    )
    assert apply_result.exit_code == 0, apply_result.stdout

    document = Document(output_path)
    text = "\n".join(paragraph.text for paragraph in document.paragraphs)
    assert "Designing Reliable Python Delivery Systems" in text
    assert "Practical Python Delivery Systems" not in text
    assert "Raphael Mansuy" not in text

    with ZipFile(output_path) as archive:
        document_xml = archive.read("word/document.xml")
    assert b'w:pStyle w:val="Title"' not in document_xml
    assert b'w:pStyle w:val="Author"' not in document_xml


def test_transformer_example_renders_math_figures_and_citations(tmp_path: Path) -> None:
    styles_path = tmp_path / "packt-style.styles.json"
    output_path = tmp_path / "01-transformer.docx"

    extract_result = runner.invoke(
        app,
        [
            "extract-styles",
            str(EXAMPLES_DIR / "packt-style.docx"),
            "-o",
            str(styles_path),
        ],
    )
    assert extract_result.exit_code == 0, extract_result.stdout

    apply_result = runner.invoke(
        app,
        [
            "apply-styles",
            str(EXAMPLES_DIR / "01-transformer.md"),
            str(styles_path),
            "-o",
            str(output_path),
            "--media",
            str(EXAMPLES_DIR),
        ],
    )
    assert apply_result.exit_code == 0, apply_result.stdout

    document = Document(output_path)
    text = "\n".join(paragraph.text for paragraph in document.paragraphs)
    assert "What Is a Transformer in the Context of an LLM?" in text
    assert "References" in text
    assert "Attention Is All You Need" in text
    assert "Scaling Laws for Neural Language Models" in text

    with ZipFile(output_path) as archive:
        names = set(archive.namelist())
        document_xml = archive.read("word/document.xml")
    assert len([name for name in names if name.startswith("word/media/")]) >= 3
    assert b"m:oMath" in document_xml
    assert b'w:pStyle w:val="Title"' not in document_xml
    assert b'w:pStyle w:val="Author"' not in document_xml
    _assert_style_package_preserved(EXAMPLES_DIR / "packt-style.docx", output_path)


def test_packt_author_guide_uses_author_addressable_style_catalog(tmp_path: Path) -> None:
    styles_path = tmp_path / "packt-style.styles.json"
    output_path = tmp_path / "packt-style-author-guide.docx"

    extract_result = runner.invoke(
        app,
        [
            "extract-styles",
            str(EXAMPLES_DIR / "packt-style.docx"),
            "-o",
            str(styles_path),
        ],
    )
    assert extract_result.exit_code == 0, extract_result.stdout

    apply_result = runner.invoke(
        app,
        [
            "apply-styles",
            str(EXAMPLES_DIR / "packt-style-author-guide.md"),
            str(styles_path),
            "-o",
            str(output_path),
            "--media",
            str(EXAMPLES_DIR),
        ],
    )
    assert apply_result.exit_code == 0, apply_result.stdout

    styles_data = json.loads(styles_path.read_text(encoding="utf-8"))["styles"]
    expected_style_ids = {
        style["style_id"]
        for style in styles_data
        if style["type"] in {"paragraph", "character"}
        and style["style_id"] not in {"Normal", "TableNormal"}
    }
    used_style_ids = _document_style_refs(output_path)
    missing = expected_style_ids - used_style_ids
    assert missing == set(), f"author guide did not exercise styles: {sorted(missing)}"
    _assert_style_package_preserved(EXAMPLES_DIR / "packt-style.docx", output_path)


def _document_style_refs(docx_path: Path) -> set[str]:
    with ZipFile(docx_path) as archive:
        root = etree.fromstring(archive.read("word/document.xml"))
    namespaces = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    refs = set(root.xpath(".//w:pStyle/@w:val", namespaces=namespaces))
    refs.update(root.xpath(".//w:rStyle/@w:val", namespaces=namespaces))
    refs.update(root.xpath(".//w:tblStyle/@w:val", namespaces=namespaces))
    return refs


def _assert_style_package_preserved(source_docx: Path, output_docx: Path) -> None:
    source_snapshot = _style_package_snapshot(source_docx)
    output_snapshot = _style_package_snapshot(output_docx)
    for part_name, content in source_snapshot["parts"].items():
        assert output_snapshot["parts"].get(part_name) == content
    for default_item in source_snapshot["content_types"]["defaults"]:
        assert default_item in output_snapshot["content_types"]["defaults"]
    for override_item in source_snapshot["content_types"]["overrides"]:
        assert override_item in output_snapshot["content_types"]["overrides"]


def _style_package_snapshot(path: Path) -> dict:
    with ZipFile(path) as archive:
        names = set(archive.namelist())
        relevant_parts = sorted(
            STYLE_PACKAGE_PARTS.union(name for name in names if name.startswith("word/fonts/"))
            & names
        )
        package_parts = {
            name: b64encode(archive.read(name)).decode("ascii") for name in relevant_parts
        }
        content_types = _style_content_types_snapshot(archive, set(relevant_parts))
    return {
        "parts": package_parts,
        "content_types": content_types,
    }


def _style_content_types_snapshot(
    archive: ZipFile, relevant_parts: set[str]
) -> dict[str, list[list[str]]]:
    root = etree.fromstring(archive.read("[Content_Types].xml"))
    relevant_part_names = {
        f"/{name}" if not name.startswith("/") else name for name in relevant_parts
    }
    relevant_extensions = {
        name.rsplit(".", 1)[1] for name in relevant_parts if "." in Path(name).name
    }
    defaults = sorted(
        [
            [node.get("Extension", ""), node.get("ContentType", "")]
            for node in root.findall("ct:Default", CONTENT_TYPES_NS)
            if node.get("Extension") in relevant_extensions
        ]
    )
    overrides = sorted(
        [
            [node.get("PartName", ""), node.get("ContentType", "")]
            for node in root.findall("ct:Override", CONTENT_TYPES_NS)
            if node.get("PartName") in relevant_part_names
        ]
    )
    return {"defaults": defaults, "overrides": overrides}
