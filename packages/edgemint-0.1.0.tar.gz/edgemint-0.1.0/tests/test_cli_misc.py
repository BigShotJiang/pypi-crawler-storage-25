from __future__ import annotations

import json
from pathlib import Path

import typer
from typer.testing import CliRunner

from edgemint.cli import app, run
from edgemint.errors import SchemaError
from edgemint.schema.models import MetaInfo, Style, StyleSheet, StyleType

runner = CliRunner()


def test_version_command_outputs_version() -> None:
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert result.stdout.strip() == "0.1.0"


def test_diff_command_reports_no_changes(tmp_path: Path) -> None:
    data = {
        "schema_version": "edgemint/v1",
        "meta": {"source_file": "x.docx", "extracted_at": "2026-04-12T00:00:00+00:00"},
        "styles": [],
    }
    left = tmp_path / "left.json"
    right = tmp_path / "right.json"
    left.write_text(json.dumps(data), encoding="utf-8")
    right.write_text(json.dumps(data), encoding="utf-8")

    result = runner.invoke(app, ["diff", str(left), str(right)])
    assert result.exit_code == 0
    assert "No changes" in result.stdout


def test_diff_command_reports_modified_styles(tmp_path: Path) -> None:
    left = tmp_path / "left.json"
    right = tmp_path / "right.json"
    left.write_text(
        json.dumps(
            {
                "schema_version": "edgemint/v1",
                "meta": {
                    "source_file": "x.docx",
                    "extracted_at": "2026-04-12T00:00:00+00:00",
                },
                "styles": [
                    {
                        "style_id": "BodyText",
                        "name": "Body Text",
                        "type": "paragraph",
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    right.write_text(
        json.dumps(
            {
                "schema_version": "edgemint/v1",
                "meta": {
                    "source_file": "x.docx",
                    "extracted_at": "2026-04-12T00:00:00+00:00",
                },
                "styles": [
                    {
                        "style_id": "BodyText",
                        "name": "Body Copy",
                        "type": "paragraph",
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["diff", str(left), str(right)])
    assert result.exit_code == 0
    assert "CHANGED BodyText" in result.stdout
    assert "name: 'Body Text' -> 'Body Copy'" in result.stdout


def test_validate_command_reports_schema_errors(tmp_path: Path) -> None:
    broken = tmp_path / "broken.json"
    broken.write_text("{}", encoding="utf-8")

    result = runner.invoke(app, ["validate", str(broken)])
    assert result.exit_code != 0


def test_run_returns_zero_on_success() -> None:
    import edgemint.cli as cli

    original = cli.app

    def fake_app(*, standalone_mode: bool) -> None:
        assert standalone_mode is False

    cli.app = fake_app
    try:
        assert run() == 0
    finally:
        cli.app = original


def test_run_returns_exit_code_from_typer_exit() -> None:
    import edgemint.cli as cli

    original = cli.app

    def fake_app(*, standalone_mode: bool) -> None:
        raise typer.Exit(7)

    cli.app = fake_app
    try:
        assert run() == 7
    finally:
        cli.app = original


def test_info_command_prints_warnings(monkeypatch) -> None:
    import edgemint.cli as cli

    def fake_extract_stylesheet(_path: Path):
        return (
            StyleSheet(
                meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
                styles=[Style(style_id="BodyText", name="Body Text", type=StyleType.PARAGRAPH)],
            ),
            ["tracked changes were dropped"],
        )

    monkeypatch.setattr(cli, "extract_stylesheet", fake_extract_stylesheet)
    result = runner.invoke(app, ["info", __file__])
    assert result.exit_code == 0
    assert "WARNING: tracked changes were dropped" in result.stderr


def test_info_command_strict_mode_fails_on_warnings(monkeypatch) -> None:
    import edgemint.cli as cli

    def fake_extract_stylesheet(_path: Path):
        return (
            StyleSheet(
                meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
                styles=[Style(style_id="BodyText", name="Body Text", type=StyleType.PARAGRAPH)],
            ),
            ["comments were dropped"],
        )

    monkeypatch.setattr(cli, "extract_stylesheet", fake_extract_stylesheet)
    result = runner.invoke(app, ["info", __file__, "--strict"])
    assert result.exit_code == 1
    assert "Strict mode aborted extraction" in result.stderr


def test_diff_command_exits_with_schema_error(monkeypatch) -> None:
    import edgemint.cli as cli

    monkeypatch.setattr(
        cli, "load_stylesheet", lambda _path: (_ for _ in ()).throw(SchemaError("broken"))
    )
    result = runner.invoke(app, ["diff", __file__, __file__])
    assert result.exit_code == 3
    assert "broken" in result.stderr
