from edgemint.diffing import diff_stylesheets
from edgemint.schema.models import FontProperties, MetaInfo, Style, StyleSheet, StyleType


def test_diff_reports_modified_style() -> None:
    before = StyleSheet(
        meta=MetaInfo(source_file="before.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(
                style_id="Heading1",
                name="Heading 1",
                type=StyleType.PARAGRAPH,
                font=FontProperties(size_pt=16.0),
            )
        ],
    )
    after = StyleSheet(
        meta=MetaInfo(source_file="after.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(
                style_id="Heading1",
                name="Heading 1",
                type=StyleType.PARAGRAPH,
                font=FontProperties(size_pt=18.0),
            )
        ],
    )

    result = diff_stylesheets(before, after)

    assert "Heading1" in result.modified
    assert result.modified["Heading1"][0].path == "font.size_pt"
