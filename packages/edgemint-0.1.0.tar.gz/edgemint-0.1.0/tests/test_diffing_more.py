from edgemint.diffing import _diff_dicts, diff_stylesheets
from edgemint.schema.models import FontProperties, MetaInfo, Style, StyleSheet, StyleType


def test_diffing_reports_added_removed_and_list_changes() -> None:
    before = StyleSheet(
        meta=MetaInfo(source_file="a", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(style_id="A", name="A", type=StyleType.PARAGRAPH),
            Style(
                style_id="B",
                name="B",
                type=StyleType.PARAGRAPH,
                font=FontProperties(name="A"),
            ),
        ],
    )
    after = StyleSheet(
        meta=MetaInfo(source_file="b", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(
                style_id="B",
                name="B",
                type=StyleType.PARAGRAPH,
                font=FontProperties(name="B"),
            ),
            Style(style_id="C", name="C", type=StyleType.PARAGRAPH),
        ],
    )
    result = diff_stylesheets(before, after)
    assert [style.style_id for style in result.added] == ["C"]
    assert [style.style_id for style in result.removed] == ["A"]
    assert "B" in result.modified
    assert _diff_dicts("x", [1], [2])[0].path == "x"
