from __future__ import annotations

import base64
from pathlib import Path

from docx import Document
from lxml import etree

from edgemint.errors import FileError
from edgemint.extract.document import (
    _build_stylesheet,
    _detect_unsupported,
    _ensure_exists,
    _fallback_extract_asciidoc,
    _fallback_extract_markdown,
    _find_text,
    _get_attr,
    _get_val,
    _hex,
    _int_attr,
    _int_val,
    _normalize_extracted_asciidoc,
    _normalize_extracted_markdown,
    _pandoc_extract_content,
    _parse_border,
    _parse_borders,
    _parse_doc_defaults,
    _parse_headers_footers,
    _parse_line_spacing,
    _parse_section_properties,
    _parse_sections,
    _parse_styles,
    _parse_theme_font,
    _read_parts,
    _style_depth,
    _wrap_custom_style,
    _wrap_custom_style_asciidoc,
    extract_document_bundle,
    summarize_stylesheet,
)
from edgemint.ooxml import NS
from edgemint.schema.models import BorderStyle, MetaInfo, Style, StyleSheet, StyleType


def test_detect_unsupported_handles_missing_document() -> None:
    assert _detect_unsupported({}) == []


def test_detect_unsupported_finds_tracked_changes() -> None:
    parts = {
        "word/document.xml": (
            b'<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            b"<w:body><w:ins /></w:body></w:document>"
        )
    }
    warnings = _detect_unsupported(parts)
    assert any("tracked changes" in warning for warning in warnings)


def test_detect_unsupported_finds_table_comments_and_form_field_constructs() -> None:
    parts = {
        "word/document.xml": (
            b'<w:document xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" '
            b'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            b"<w:body>"
            b"<w:tbl><w:tr><w:tc><w:p/></w:tc><w:tc><w:tcPr><w:gridSpan w:val='2'/></w:tcPr></w:tc></w:tr></w:tbl>"
            b"<w:tbl><w:tr><w:tc><w:tbl><w:tr><w:tc><w:p/></w:tc></w:tr></w:tbl></w:tc></w:tr></w:tbl>"
            b"<w:p><w:commentRangeStart w:id='0'/><w:r><w:commentReference w:id='0'/></w:r></w:p>"
            b"<w:ffData/>"
            b"<w:drawing><w:inline/></w:drawing>"
            b"</w:body></w:document>"
        )
    }
    warnings = _detect_unsupported(parts)
    assert any("merged table cells" in warning for warning in warnings)
    assert any("nested tables" in warning for warning in warnings)
    assert any("comments / annotations" in warning for warning in warnings)
    assert any("form fields" in warning for warning in warnings)
    assert any("non-image drawing objects" in warning for warning in warnings)


def test_parse_border_and_borders_helpers() -> None:
    root = etree.fromstring(
        b'<w:pBdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        b'<w:top w:val="single" w:sz="8" w:color="FF0000" w:space="20" />'
        b"</w:pBdr>"
    )
    borders = _parse_borders(root)
    assert borders is not None
    assert borders.top is not None
    assert borders.top.style == BorderStyle.SINGLE
    assert borders.top.color == "#FF0000"
    assert _parse_border(None) is None


def test_xml_access_helpers() -> None:
    root = etree.fromstring(
        b'<w:root xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        b'<w:item w:val="12" w:left="24">hello</w:item></w:root>'
    )
    item = root.find("w:item", NS)
    assert _find_text(root, "w:item") == "hello"
    assert _get_val(item) == "12"
    assert _int_val(item) == 12
    assert _get_attr(item, "left") == "24"
    assert _int_attr(item, "left") == 24
    assert _hex("00FF00") == "#00FF00"
    assert _hex("auto") is None


def test_normalize_markdown_paths_and_wrap_custom_style(tmp_path: Path) -> None:
    media_dir = tmp_path / "media"
    media_dir.mkdir()
    content_path = tmp_path / "content.md"
    content_path.write_text(f"![]({media_dir.resolve()}/image.png)\n", encoding="utf-8")

    _normalize_extracted_markdown(content_path, media_dir)

    assert content_path.read_text(encoding="utf-8") == "![](media/image.png)\n"
    assert _wrap_custom_style("Body Text", "Hello") == '::: {custom-style="Body Text"}\nHello\n:::'

    adoc_path = tmp_path / "content.adoc"
    adoc_path.write_text(
        (
            f"image::{media_dir.resolve()}/image.png[]\n"
            f"[{media_dir}/image]\n"
            f"[{str(media_dir).replace('_', '++_++')}/image]\n"
        ),
        encoding="utf-8",
    )
    _normalize_extracted_asciidoc(adoc_path, media_dir)
    assert (
        adoc_path.read_text(encoding="utf-8")
        == "image::media/image.png[]\n[media/image]\n[media/image]\n"
    )
    assert (
        _wrap_custom_style_asciidoc("Body Text", "Hello")
        == '[custom-style="Body Text"]\n====\nHello\n===='
    )


def test_summarize_and_style_depth_helpers() -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(style_id="Base", name="Base", type=StyleType.PARAGRAPH),
            Style(
                style_id="Child",
                name="Child",
                type=StyleType.PARAGRAPH,
                based_on="Base",
            ),
        ],
    )
    summary = summarize_stylesheet(stylesheet)
    assert summary["counts"]["paragraph"] == 2
    assert _style_depth(stylesheet.styles[1], stylesheet) == 2
    orphan = Style(style_id="Orphan", name="Orphan", type=StyleType.PARAGRAPH, based_on="Missing")
    assert _style_depth(orphan, stylesheet) == 1


def test_fallback_extract_markdown_handles_non_numeric_heading(tmp_path: Path) -> None:
    path = tmp_path / "sample.docx"
    document = Document()
    style = document.styles.add_style("Heading Custom", 1)
    style.name = "Heading Custom"
    document.add_paragraph("Hello", style="Heading Custom")
    document.save(path)

    content = _fallback_extract_markdown(path)
    assert 'custom-style="Heading Custom"' in content
    adoc = _fallback_extract_asciidoc(path)
    assert '[custom-style="Heading Custom"]' in adoc


def test_fallback_extract_markdown_covers_blank_normal_and_custom(tmp_path: Path) -> None:
    path = tmp_path / "sample.docx"
    document = Document()
    document.add_paragraph("")
    document.add_paragraph("Normal text", style="Normal")
    custom = document.styles.add_style("Custom Body", 1)
    custom.name = "Custom Body"
    document.add_paragraph("Custom text", style="Custom Body")
    document.save(path)

    content = _fallback_extract_markdown(path)
    assert "Normal text" in content
    assert 'custom-style="Custom Body"' in content
    adoc = _fallback_extract_asciidoc(path)
    assert "Normal text" in adoc
    assert '[custom-style="Custom Body"]' in adoc


def test_build_stylesheet_handles_missing_optional_parts(sample_docx: Path) -> None:
    import zipfile

    with zipfile.ZipFile(sample_docx) as archive:
        parts = {"word/styles.xml": archive.read("word/styles.xml")}
    stylesheet = _build_stylesheet(sample_docx, parts)
    assert stylesheet.theme.colors == {}
    assert stylesheet.numbering_defs == []


def test_read_parts_and_build_stylesheet_capture_font_assets(
    sample_docx: Path, tmp_path: Path
) -> None:
    import shutil
    import zipfile
    from tempfile import NamedTemporaryFile

    font_docx = tmp_path / "font.docx"
    shutil.copyfile(sample_docx, font_docx)
    with zipfile.ZipFile(font_docx, "r") as source:
        rewritten_parts = {info.filename: source.read(info.filename) for info in source.infolist()}
    rewritten_parts["[Content_Types].xml"] = (
        rewritten_parts["[Content_Types].xml"]
        .decode("utf-8")
        .replace(
            "</Types>",
            (
                '<Default Extension="odttf" '
                'ContentType="application/vnd.openxmlformats-officedocument.obfuscatedFont"/>'
                "</Types>"
            ),
        )
        .encode("utf-8")
    )
    rewritten_parts["word/_rels/fontTable.xml.rels"] = (
        b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        b'<Relationship Id="rId1" '
        b'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/font" '
        b'Target="fonts/font1.odttf"/></Relationships>'
    )
    rewritten_parts["word/fonts/font1.odttf"] = b"font-data"
    with NamedTemporaryFile(suffix=".docx", delete=False) as handle:
        rewritten_docx = Path(handle.name)
    with zipfile.ZipFile(rewritten_docx, "w") as archive:
        for name, content in rewritten_parts.items():
            archive.writestr(name, content)
    rewritten_docx.replace(font_docx)

    with zipfile.ZipFile(font_docx) as archive:
        parts = _read_parts(archive)

    assert "[Content_Types].xml" in parts
    assert "word/fontTable.xml" in parts
    assert "word/_rels/fontTable.xml.rels" in parts
    assert parts["word/fonts/font1.odttf"] == b"font-data"

    stylesheet = _build_stylesheet(font_docx, parts)
    assert "word/fontTable.xml" in stylesheet.raw_parts
    assert "word/_rels/fontTable.xml.rels" in stylesheet.raw_parts
    assert stylesheet.raw_binary_parts["word/fonts/font1.odttf"] == base64.b64encode(
        b"font-data"
    ).decode("ascii")
    assert stylesheet.content_types_xml is not None


def test_extract_document_bundle_fallback_and_missing_file(
    monkeypatch, sample_docx: Path, tmp_path: Path
) -> None:
    monkeypatch.setattr("edgemint.extract.document.has_pandoc", lambda: False)
    bundle_dir = tmp_path / "bundle"
    stylesheet, warnings = extract_document_bundle(sample_docx, bundle_dir)
    assert stylesheet.styles
    assert isinstance(warnings, list)
    assert (bundle_dir / "content.md").exists()
    assert (bundle_dir / "content.adoc").exists()
    _ensure_exists(sample_docx)
    missing = tmp_path / "missing.docx"
    try:
        _ensure_exists(missing)
    except FileError as exc:
        assert "File not found" in str(exc)
    else:
        raise AssertionError("expected FileError for missing path")


def test_parse_helpers_cover_none_and_non_auto_paths() -> None:
    styles_root = etree.fromstring(
        b'<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        b'<w:style w:type="paragraph"><w:name w:val="MissingId"/></w:style>'
        b"</w:styles>"
    )
    assert _parse_styles(styles_root) == []
    assert _parse_doc_defaults(styles_root) is None
    assert _parse_theme_font(None).latin is None

    spacing = etree.fromstring(
        b'<w:spacing xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        b'w:line="240" w:lineRule="exact" />'
    )
    assert _parse_line_spacing(spacing) == 12.0

    document_root = etree.fromstring(
        b'<w:document xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        b'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'
        b'<w:p><w:pPr><w:sectPr><w:type w:val="continuous"/><w:pgSz w:w="12240" w:h="15840"/></w:sectPr></w:pPr></w:p>'
        b'<w:sectPr><w:pgSz w:w="15840" w:h="12240" w:orient="landscape"/><w:headerReference r:id="rId1" w:type="default"/></w:sectPr>'
        b"</w:body></w:document>"
    )
    rels_root = etree.fromstring(
        b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        b'<Relationship Id="rId1" Target="header1.xml"/></Relationships>'
    )
    sections = _parse_sections(document_root)
    assert len(sections) == 2
    assert sections[0].start_type == "CONTINUOUS"
    assert sections[1].orientation == "landscape"
    assert _parse_section_properties(document_root) == sections[0]
    headers = _parse_headers_footers(
        {"word/header1.xml": b"<w:hdr/>"},
        document_root,
        rels_root,
    )
    assert headers[0].section_index == 1
    assert _parse_headers_footers({}, document_root, rels_root) == []


def test_pandoc_extract_content_delegates_to_runner(monkeypatch, tmp_path: Path) -> None:
    captured: dict[str, object] = {}

    def fake_run_pandoc(args: list[str]) -> None:
        captured["args"] = args

    monkeypatch.setattr("edgemint.extract.document.run_pandoc", fake_run_pandoc)
    _pandoc_extract_content(
        tmp_path / "in.docx", tmp_path / "out.md", tmp_path / "media", "asciidoc"
    )
    assert captured["args"] is not None


def test_fallback_extract_markdown_covers_numeric_heading(sample_docx: Path) -> None:
    content = _fallback_extract_markdown(sample_docx)
    assert "# Quarterly Report" in content


def test_parse_borders_none_when_empty_node() -> None:
    node = etree.fromstring(
        b'<w:pBdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"></w:pBdr>'
    )
    assert _parse_borders(node) is None
