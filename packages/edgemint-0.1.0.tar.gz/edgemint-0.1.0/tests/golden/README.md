# Golden Dataset

This dataset is intentionally committed to the repository.

Why:
- regression tests should exercise real DOCX files, not only synthetic fixtures
- extraction and round-trip behavior are easiest to review as stable snapshots
- both `content.md` and `content.adoc` are tracked to enforce dual authoring workflows
- refresh remains deterministic through the helper scripts

Refresh flow:

```bash
./scripts/download_golden_fixtures.sh
.venv/bin/python scripts/build_golden_dataset.py
```
