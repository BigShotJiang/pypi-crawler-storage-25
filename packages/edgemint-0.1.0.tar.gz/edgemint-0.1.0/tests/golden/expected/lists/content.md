## Some nested lists

1.  ::: {custom-style="Normal"}
    one
    :::

2.  ::: {custom-style="Normal"}
    two
    :::

    a.  ::: {custom-style="Normal"}
        a
        :::

    b.  ::: {custom-style="Normal"}
        b
        :::

- ::: {custom-style="Normal"}
  one
  :::

- ::: {custom-style="Normal"}
  two
  :::

  - ::: {custom-style="Normal"}
    three
    :::

    - ::: {custom-style="Normal"}
      four
      :::

      ::: {custom-style="Normal"}
      Sub paragraph
      :::

- ::: {custom-style="Normal"}
  Same list
  :::

<!-- -->

- Different list adjacent to the one above.
