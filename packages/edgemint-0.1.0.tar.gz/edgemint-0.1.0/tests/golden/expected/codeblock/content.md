This is some code:

::: {custom-style="Source Code"}
    readDocx :: ReaderOptions
             -> B.ByteString
             -> Pandoc
:::

from the beginning of the docx reader.
