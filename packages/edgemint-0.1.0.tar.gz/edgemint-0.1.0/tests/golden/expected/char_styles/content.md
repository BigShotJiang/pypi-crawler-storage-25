[This is all in an]{custom-style="Emphasis"} [**italic style**.]{custom-style="Emphasis"}

[This is an italic style with some words unitalicized.]{custom-style="Emphasis"}

[This is all in a *strong style*.]{custom-style="Strong"}

[This is a strong style with some words ubolded.]{custom-style="Strong"}
