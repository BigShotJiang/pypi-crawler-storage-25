## A footnote

Test footnote.[^1] Test endnote.[^2]

[^1]:
    ::: {custom-style="footnote text"}
    []{custom-style="footnote reference"} My note.
    :::

[^2]:
    ::: {custom-style="endnote text"}
    []{custom-style="endnote reference"} This is an endnote at the end of the document.
    :::
