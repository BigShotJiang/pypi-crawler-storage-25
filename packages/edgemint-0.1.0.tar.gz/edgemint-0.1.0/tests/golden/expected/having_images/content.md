![](media/media/image1.png){width="2.9305555555555554in" height="0.9861111111111112in"}

![](media/media/image2.png){width="1.2465748031496062in" height="1.7784470691163605in"}

![](media/media/image3.png){width="1.9444444444444444in" height="0.7777777777777778in"}

![](media/media/image2.png){width="0.7501443569553806in" height="1.0702055993000874in"}

![](media/media/image3.png){width="1.2465748031496062in" height="0.49862970253718286in"}
