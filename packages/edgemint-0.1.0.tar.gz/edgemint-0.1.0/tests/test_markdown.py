from edgemint.markdown import parse_markdown


def test_markdown_parser_supports_custom_blocks_and_lists() -> None:
    document = parse_markdown(
        """---
title: "Hello"
---

# Heading

::: {custom-style="Body Text"}
Paragraph with [green]{custom-style="Status Green"} text.
:::

- One
- Two
"""
    )

    assert document.metadata["title"] == "Hello"
    assert document.blocks[0].kind == "heading"
    assert document.blocks[1].style == "Body Text"
    assert document.blocks[1].inlines[1].custom_style == "Status Green"
    assert document.blocks[2].kind == "list"
