from pydantic import BaseModel, ConfigDict

from edgemint.extract.resolver import _merge_model


class _Nested(BaseModel):
    model_config = ConfigDict(frozen=True)
    inner: dict[str, str]
    plain: str | None = None


def test_merge_model_merges_nested_dicts() -> None:
    base = _Nested(inner={"a": "1"}, plain="x")
    override = _Nested(inner={"b": "2"})
    merged = _merge_model(base, override)
    assert merged.inner == {"a": "1", "b": "2"}
    assert merged.plain == "x"
