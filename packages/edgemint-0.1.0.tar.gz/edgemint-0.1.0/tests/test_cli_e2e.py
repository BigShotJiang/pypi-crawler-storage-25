from __future__ import annotations

import json
from pathlib import Path

from docx import Document
from typer.testing import CliRunner

from edgemint.cli import app

runner = CliRunner()


def test_extract_styles_validate_and_info(sample_docx: Path, tmp_path: Path) -> None:
    styles_path = tmp_path / "styles.json"

    result = runner.invoke(app, ["extract-styles", str(sample_docx), "-o", str(styles_path)])
    assert result.exit_code == 0, result.stdout
    assert styles_path.exists()

    data = json.loads(styles_path.read_text(encoding="utf-8"))
    assert data["schema_version"] == "edgemint/v1"
    assert any(style["name"] == "Body Text" for style in data["styles"])

    result = runner.invoke(app, ["validate", str(styles_path)])
    assert result.exit_code == 0
    assert "Valid" in result.stdout

    result = runner.invoke(app, ["info", str(sample_docx)])
    assert result.exit_code == 0
    assert "Styles:" in result.stdout


def test_apply_styles_round_trip(sample_docx: Path, tmp_path: Path) -> None:
    styles_path = tmp_path / "styles.json"
    markdown_path = tmp_path / "content.md"
    output_path = tmp_path / "output.docx"

    result = runner.invoke(app, ["extract-styles", str(sample_docx), "-o", str(styles_path)])
    assert result.exit_code == 0, result.stdout

    markdown_path.write_text(
        """---
title: "Generated Report"
author: "Raphael"
---

# Heading Example

::: {custom-style="Body Text"}
Delivery is [on track]{custom-style="Status Green"} this quarter.
:::
""",
        encoding="utf-8",
    )

    result = runner.invoke(
        app,
        ["apply-styles", str(markdown_path), str(styles_path), "-o", str(output_path)],
    )
    assert result.exit_code == 0, result.stdout
    assert output_path.exists()

    generated = Document(output_path)
    paragraphs = [(paragraph.text, paragraph.style.name) for paragraph in generated.paragraphs]
    assert ("Heading Example", "Heading 1") in paragraphs
    assert ("Delivery is on track this quarter.", "Body Text") in paragraphs


def test_extract_bundle_generates_project_layout(sample_docx: Path, tmp_path: Path) -> None:
    output_dir = tmp_path / "bundle"

    result = runner.invoke(app, ["extract", str(sample_docx), "-o", str(output_dir)])
    assert result.exit_code == 0, result.stdout
    assert (output_dir / "styles.json").exists()
    assert (output_dir / "content.md").exists()
    assert (output_dir / "content.adoc").exists()
    assert (output_dir / "media").exists()


def test_schema_command_outputs_json() -> None:
    result = runner.invoke(app, ["schema"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert "properties" in data
