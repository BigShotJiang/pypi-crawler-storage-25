from edgemint.extract.resolver import resolve_styles
from edgemint.schema.models import (
    DocDefaults,
    FontProperties,
    MetaInfo,
    ParagraphFormat,
    Style,
    StyleSheet,
    StyleType,
)


def test_resolver_merges_defaults_and_parent_styles() -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        doc_defaults=DocDefaults(
            paragraph_format=ParagraphFormat(space_after_pt=6.0),
            font=FontProperties(name="Calibri"),
        ),
        styles=[
            Style(
                style_id="Base",
                name="Base",
                type=StyleType.PARAGRAPH,
                paragraph_format=ParagraphFormat(space_before_pt=10.0),
            ),
            Style(
                style_id="Child",
                name="Child",
                type=StyleType.PARAGRAPH,
                based_on="Base",
                font=FontProperties(bold=True),
            ),
        ],
    )

    resolved = resolve_styles(stylesheet)
    child = resolved.get_style("Child")

    assert child is not None
    assert child.resolved is not None
    assert child.resolved.paragraph_format.space_after_pt == 6.0
    assert child.resolved.paragraph_format.space_before_pt == 10.0
    assert child.resolved.font.name == "Calibri"
    assert child.resolved.font.bold is True
