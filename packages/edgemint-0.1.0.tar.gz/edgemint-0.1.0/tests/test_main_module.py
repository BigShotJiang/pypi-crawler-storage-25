import runpy

import edgemint.__main__ as main_module


def test_main_module_invokes_app(monkeypatch) -> None:
    called = {"value": False}

    def fake_app() -> None:
        called["value"] = True

    monkeypatch.setattr(main_module, "app", fake_app)
    main_module.main()
    assert called["value"] is True


def test_main_module_script_path_executes(monkeypatch) -> None:
    import edgemint.cli as cli

    called = {"value": False}

    def fake_app() -> None:
        called["value"] = True

    monkeypatch.setattr(cli, "app", fake_app)
    runpy.run_module("edgemint.__main__", run_name="__main__")
    assert called["value"] is True
