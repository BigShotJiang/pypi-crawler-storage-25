from __future__ import annotations

from pathlib import Path
from zipfile import ZipFile

import pytest
from docx import Document

from edgemint.apply import (
    SourceFormat,
    _apply_font_properties,
    _apply_paragraph_format,
    _load_source_document,
    _pandoc_body_source,
    _pandoc_input_format,
    _parse_asciidoc_metadata,
    _preserve_generated_parts,
    _relink_list_paragraph_styles,
    _relink_pandoc_styles,
    _resolve_source_format,
    _source_numbering_formats,
    _strip_asciidoc_header,
    _strip_markdown_metadata_block,
    _template_list_targets,
    apply_stylesheet,
)
from edgemint.errors import FileError, PandocError
from edgemint.schema.models import (
    FontProperties,
    MetaInfo,
    NumberingDef,
    NumberingLevel,
    ParagraphFormat,
    SectionProperties,
    Style,
    StyleSheet,
    StyleType,
)


def test_apply_stylesheet_raises_on_missing_markdown(tmp_path: Path) -> None:
    with pytest.raises(FileError):
        apply_stylesheet(
            tmp_path / "missing.md",
            None,  # type: ignore[arg-type]
            tmp_path / "out.docx",
        )


def test_apply_with_pandoc_propagates_pandoc_errors(
    monkeypatch, tmp_path: Path, sample_docx: Path
) -> None:
    from edgemint.extract.document import extract_stylesheet

    stylesheet, _ = extract_stylesheet(sample_docx)
    markdown = tmp_path / "content.md"
    markdown.write_text("hello", encoding="utf-8")
    monkeypatch.setattr("edgemint.apply.has_pandoc", lambda: True)
    monkeypatch.setattr(
        "edgemint.apply.run_pandoc", lambda *args, **kwargs: (_ for _ in ()).throw(PandocError("x"))
    )
    with pytest.raises(PandocError):
        apply_stylesheet(markdown, stylesheet, tmp_path / "out.docx")


def test_apply_paragraph_and_font_helpers_set_remaining_flags() -> None:
    document = Document()
    paragraph = document.add_paragraph()
    _apply_paragraph_format(
        paragraph.paragraph_format,
        ParagraphFormat(page_break_before=True, widow_control=True),
    )
    run = paragraph.add_run("x")
    _apply_font_properties(
        run.font,
        FontProperties(strike=True, double_strike=True, superscript=True, all_caps=True),
    )
    assert paragraph.paragraph_format.page_break_before is True
    assert paragraph.paragraph_format.widow_control is True
    assert run.font.strike is True
    assert run.font.double_strike is True
    assert run.font.superscript is True
    assert run.font.all_caps is True


def test_apply_paragraph_and_font_helpers_cover_remaining_flags() -> None:
    document = Document()
    paragraph = document.add_paragraph()
    _apply_paragraph_format(paragraph.paragraph_format, ParagraphFormat())
    run = paragraph.add_run("x")
    _apply_font_properties(
        run.font,
        FontProperties(bold=True, italic=True, subscript=True),
    )
    assert run.font.bold is True
    assert run.font.italic is True
    assert run.font.subscript is True


def test_apply_direct_handles_empty_table_and_unknown_style(monkeypatch, tmp_path: Path) -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        section_properties=SectionProperties(orientation="landscape"),
        styles=[Style(style_id="Known", name="Known", type=StyleType.TABLE)],
    )
    markdown = tmp_path / "content.md"
    markdown.write_text("hello", encoding="utf-8")
    monkeypatch.setattr("edgemint.apply.has_pandoc", lambda: False)
    apply_stylesheet(markdown, stylesheet, tmp_path / "out.docx")


def test_apply_stylesheet_requires_pandoc_for_asciidoc(monkeypatch, tmp_path: Path) -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
    )
    source = tmp_path / "content.adoc"
    source.write_text("= Report\nRaphael\n\nText", encoding="utf-8")
    monkeypatch.setattr("edgemint.apply.has_pandoc", lambda: False)
    with pytest.raises(PandocError):
        apply_stylesheet(
            source,
            stylesheet,
            tmp_path / "out.docx",
            input_format=SourceFormat.ASCIIDOC,
        )


def test_apply_stylesheet_uses_asciidoc_reader_with_pandoc(monkeypatch, tmp_path: Path) -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
    )
    source = tmp_path / "content.adoc"
    source.write_text("= Report\nRaphael\n\nParagraph.", encoding="utf-8")
    output = tmp_path / "out.docx"
    recorded: dict[str, object] = {}

    def fake_run_pandoc(args: list[str], workdir=None) -> None:
        recorded["args"] = args
        Document().save(Path(args[args.index("-o") + 1]))

    monkeypatch.setattr("edgemint.apply.has_pandoc", lambda: True)
    monkeypatch.setattr("edgemint.apply.run_pandoc", fake_run_pandoc)

    apply_stylesheet(
        source,
        stylesheet,
        output,
        input_format=SourceFormat.ASCIIDOC,
    )

    assert recorded["args"] is not None
    assert "asciidoc" in recorded["args"]
    assert "--citeproc" in recorded["args"]
    assert output.exists()


def test_source_format_and_asciidoc_metadata_helpers() -> None:
    assert _resolve_source_format(Path("x.md"), SourceFormat.AUTO) == SourceFormat.MARKDOWN
    assert _resolve_source_format(Path("x.adoc"), SourceFormat.AUTO) == SourceFormat.ASCIIDOC
    assert _pandoc_input_format(SourceFormat.MARKDOWN).startswith("markdown+")
    assert _pandoc_input_format(SourceFormat.ASCIIDOC) == "asciidoc"

    metadata = _parse_asciidoc_metadata("= Report\n:author: Raphael\n\nBody")
    assert metadata == {"title": "Report", "author": "Raphael"}
    metadata = _parse_asciidoc_metadata("\n\n= Report\nRaphael\n\nBody")
    assert metadata == {"title": "Report", "author": "Raphael"}
    assert _parse_asciidoc_metadata("=== Heading\n\nBody") == {}

    source = _load_source_document("= Report\nRaphael\n\nBody", SourceFormat.ASCIIDOC)
    assert source.metadata == {"title": "Report", "author": "Raphael"}
    assert source.blocks == []


def test_pandoc_body_source_strips_visible_metadata_boilerplate() -> None:
    markdown_text = (
        "---\ntitle: Report\nauthor: Raphael\nbibliography: refs.bib\nnocite: '@*'\n---\n\nBody\n"
    )
    markdown_source = _load_source_document(markdown_text, SourceFormat.MARKDOWN)
    assert (
        _strip_markdown_metadata_block(markdown_text)
        == "---\nbibliography: refs.bib\nnocite: '@*'\n---\n\nBody\n"
    )
    assert (
        _pandoc_body_source(markdown_text, markdown_source, SourceFormat.MARKDOWN)
        == "---\nbibliography: refs.bib\nnocite: '@*'\n---\n\nBody\n"
    )

    asciidoc_text = "= Report\n:author: Raphael\n:bibliography-database: refs.bib\n\nBody\n"
    asciidoc_source = _load_source_document(asciidoc_text, SourceFormat.ASCIIDOC)
    assert (
        _strip_asciidoc_header(asciidoc_text)
        == ":author: Raphael\n:bibliography-database: refs.bib\n\nBody\n"
    )
    assert (
        _pandoc_body_source(asciidoc_text, asciidoc_source, SourceFormat.ASCIIDOC)
        == ":author: Raphael\n:bibliography-database: refs.bib\n\nBody\n"
    )


def test_metadata_strip_helpers_leave_non_metadata_sources_unchanged() -> None:
    plain_markdown = "Body\n"
    assert _strip_markdown_metadata_block(plain_markdown) == plain_markdown

    broken_markdown = "---\ntitle: Report\nBody\n"
    assert _strip_markdown_metadata_block(broken_markdown) == broken_markdown

    plain_asciidoc = "\n\nBody\n"
    assert _strip_asciidoc_header(plain_asciidoc) == plain_asciidoc


def test_preserve_generated_parts_copies_pandoc_footnotes(tmp_path: Path) -> None:
    source_docx = tmp_path / "source.docx"
    target_docx = tmp_path / "target.docx"

    with ZipFile(source_docx, "w") as archive:
        archive.writestr("[Content_Types].xml", "<types/>")
        archive.writestr("word/document.xml", "<document/>")
        archive.writestr("word/footnotes.xml", "<footnotes><note>kept</note></footnotes>")
    with ZipFile(target_docx, "w") as archive:
        archive.writestr("[Content_Types].xml", "<types/>")
        archive.writestr("word/document.xml", "<document/>")
        archive.writestr("word/footnotes.xml", "<footnotes/>")

    _preserve_generated_parts(source_docx, target_docx)

    with ZipFile(target_docx, "r") as archive:
        assert archive.read("word/footnotes.xml") == b"<footnotes><note>kept</note></footnotes>"


def test_numbering_helpers_extract_source_formats_and_template_targets(
    sample_docx: Path,
    tmp_path: Path,
) -> None:
    numbering_docx = tmp_path / "numbering.docx"
    with ZipFile(numbering_docx, "w") as archive:
        archive.writestr(
            "word/numbering.xml",
            """
            <w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:abstractNum w:abstractNumId="1">
                <w:lvl w:ilvl="0"><w:numFmt w:val="bullet"/></w:lvl>
                <w:lvl w:ilvl="1"><w:numFmt w:val="decimal"/></w:lvl>
              </w:abstractNum>
              <w:num w:numId="1001"><w:abstractNumId w:val="1"/></w:num>
            </w:numbering>
            """.strip(),
        )
    assert _source_numbering_formats(numbering_docx) == {
        (1001, 0): "bullet",
        (1001, 1): "decimal",
    }

    from edgemint.extract.document import extract_stylesheet

    stylesheet, _ = extract_stylesheet(sample_docx)
    targets = _template_list_targets(stylesheet)
    assert targets[("bullet", 0)][0] == "ListBullet"
    assert targets[("decimal", 0)][0] == "ListNumber"


def test_source_numbering_formats_skips_incomplete_numbering_nodes(tmp_path: Path) -> None:
    numbering_docx = tmp_path / "numbering.docx"
    with ZipFile(numbering_docx, "w") as archive:
        archive.writestr(
            "word/numbering.xml",
            """
            <w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:abstractNum>
                <w:lvl w:ilvl="0"><w:numFmt w:val="bullet"/></w:lvl>
              </w:abstractNum>
              <w:abstractNum w:abstractNumId="9">
                <w:lvl><w:numFmt w:val="bullet"/></w:lvl>
                <w:lvl w:ilvl="1"/>
                <w:lvl w:ilvl="2"><w:numFmt w:val="decimal"/></w:lvl>
              </w:abstractNum>
              <w:num><w:abstractNumId w:val="9"/></w:num>
              <w:num w:numId="77"><w:abstractNumId/></w:num>
              <w:num w:numId="78"><w:abstractNumId w:val="9"/></w:num>
            </w:numbering>
            """.strip(),
        )

    assert _source_numbering_formats(numbering_docx) == {(78, 2): "decimal"}


def test_source_numbering_formats_returns_empty_when_part_is_missing(tmp_path: Path) -> None:
    numbering_docx = tmp_path / "missing-numbering.docx"
    with ZipFile(numbering_docx, "w") as archive:
        archive.writestr("word/document.xml", "<document/>")

    assert _source_numbering_formats(numbering_docx) == {}


def test_relink_list_paragraph_styles_rewrites_missing_style_and_falls_back_level_zero(
    tmp_path: Path,
) -> None:
    source_docx = tmp_path / "source.docx"
    target_docx = tmp_path / "target.docx"
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        numbering_defs=[
            NumberingDef(
                num_id=42,
                abstract_num_id=7,
                levels=[
                    NumberingLevel(
                        level=0,
                        num_fmt="bullet",
                        lvl_text="•",
                        paragraph_style_id="L1-Bullet",
                    )
                ],
            )
        ],
    )
    with ZipFile(source_docx, "w") as archive:
        archive.writestr(
            "word/numbering.xml",
            """
            <w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:abstractNum w:abstractNumId="7">
                <w:lvl w:ilvl="0"><w:numFmt w:val="bullet"/></w:lvl>
              </w:abstractNum>
              <w:abstractNum w:abstractNumId="8">
                <w:lvl w:ilvl="0"><w:numFmt w:val="decimal"/></w:lvl>
              </w:abstractNum>
              <w:num w:numId="1001"><w:abstractNumId w:val="7"/></w:num>
              <w:num w:numId="1002"><w:abstractNumId w:val="8"/></w:num>
            </w:numbering>
            """.strip(),
        )
    with ZipFile(target_docx, "w") as archive:
        archive.writestr(
            "word/document.xml",
            """
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:body>
                <w:p>
                  <w:pPr>
                    <w:numPr>
                      <w:ilvl w:val="2"/>
                      <w:numId w:val="1001"/>
                    </w:numPr>
                  </w:pPr>
                  <w:r><w:t>bullet</w:t></w:r>
                </w:p>
              </w:body>
            </w:document>
            """.strip(),
        )

    _relink_list_paragraph_styles(source_docx, target_docx, stylesheet)

    with ZipFile(target_docx, "r") as archive:
        xml = archive.read("word/document.xml")
    assert b'w:pStyle w:val="L1-Bullet"' in xml
    assert b'w:numId w:val="42"' in xml


def test_relink_list_paragraph_styles_skips_unmappable_cases(tmp_path: Path) -> None:
    source_docx = tmp_path / "source.docx"
    target_docx = tmp_path / "target.docx"
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        numbering_defs=[
            NumberingDef(
                num_id=42,
                abstract_num_id=7,
                levels=[
                    NumberingLevel(
                        level=0,
                        num_fmt="bullet",
                        lvl_text="•",
                        paragraph_style_id="L1-Bullet",
                    )
                ],
            )
        ],
    )
    with ZipFile(source_docx, "w") as archive:
        archive.writestr(
            "word/numbering.xml",
            """
            <w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:abstractNum w:abstractNumId="7">
                <w:lvl w:ilvl="0"><w:numFmt w:val="bullet"/></w:lvl>
              </w:abstractNum>
              <w:abstractNum w:abstractNumId="8">
                <w:lvl w:ilvl="0"><w:numFmt w:val="decimal"/></w:lvl>
              </w:abstractNum>
              <w:num w:numId="1001"><w:abstractNumId w:val="7"/></w:num>
              <w:num w:numId="1002"><w:abstractNumId w:val="8"/></w:num>
            </w:numbering>
            """.strip(),
        )
    with ZipFile(target_docx, "w") as archive:
        archive.writestr(
            "word/document.xml",
            """
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:body>
                <w:p>
                  <w:pPr>
                    <w:numPr>
                      <w:ilvl w:val="0"/>
                    </w:numPr>
                  </w:pPr>
                  <w:r><w:t>missing numId</w:t></w:r>
                </w:p>
                <w:p>
                  <w:pPr>
                    <w:numPr>
                      <w:ilvl w:val="9"/>
                      <w:numId w:val="1001"/>
                    </w:numPr>
                  </w:pPr>
                  <w:r><w:t>missing format fallback</w:t></w:r>
                </w:p>
                <w:p>
                  <w:pPr>
                    <w:numPr>
                      <w:ilvl w:val="0"/>
                      <w:numId w:val="9999"/>
                    </w:numPr>
                  </w:pPr>
                  <w:r><w:t>missing numbering source</w:t></w:r>
                </w:p>
                <w:p>
                  <w:pPr>
                    <w:numPr>
                      <w:ilvl w:val="0"/>
                      <w:numId w:val="1002"/>
                    </w:numPr>
                  </w:pPr>
                  <w:r><w:t>missing template target</w:t></w:r>
                </w:p>
              </w:body>
            </w:document>
            """.strip(),
        )

    _relink_list_paragraph_styles(source_docx, target_docx, stylesheet)

    with ZipFile(target_docx, "r") as archive:
        xml = archive.read("word/document.xml")
    assert b"missing numId" in xml
    assert b"missing numbering source" in xml
    assert b"missing template target" in xml
    assert b'w:numId w:val="1002"' in xml


def test_relink_pandoc_styles_rewrites_known_aliases(tmp_path: Path) -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(style_id="C0-CodeBlock", name="C0 - CodeBlock", type=StyleType.PARAGRAPH),
            Style(style_id="CS-InlineCode", name="CS - InlineCode", type=StyleType.CHARACTER),
        ],
    )
    docx_path = tmp_path / "styled.docx"
    with ZipFile(docx_path, "w") as archive:
        archive.writestr(
            "word/document.xml",
            """
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:body>
                <w:p>
                  <w:pPr><w:pStyle w:val="SourceCode"/></w:pPr>
                  <w:r><w:rPr><w:rStyle w:val="VerbatimChar"/></w:rPr><w:t>x</w:t></w:r>
                </w:p>
              </w:body>
            </w:document>
            """.strip(),
        )

    _relink_pandoc_styles(docx_path, stylesheet)

    with ZipFile(docx_path, "r") as archive:
        xml = archive.read("word/document.xml")
    assert b"SourceCode" not in xml
    assert b"VerbatimChar" not in xml
    assert b"C0-CodeBlock" in xml
    assert b"CS-InlineCode" in xml


def test_relink_pandoc_styles_returns_when_document_has_no_alias_references(tmp_path: Path) -> None:
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[Style(style_id="C0-CodeBlock", name="C0 - CodeBlock", type=StyleType.PARAGRAPH)],
    )
    docx_path = tmp_path / "styled.docx"
    with ZipFile(docx_path, "w") as archive:
        archive.writestr(
            "word/document.xml",
            """
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:body>
                <w:p>
                  <w:pPr><w:pStyle w:val="P0-Paragraph"/></w:pPr>
                  <w:r><w:t>x</w:t></w:r>
                </w:p>
              </w:body>
            </w:document>
            """.strip(),
        )

    _relink_pandoc_styles(docx_path, stylesheet)

    with ZipFile(docx_path, "r") as archive:
        xml = archive.read("word/document.xml")
    assert b"P0-Paragraph" in xml
