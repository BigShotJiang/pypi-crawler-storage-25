from __future__ import annotations

from pathlib import Path

import pytest

from edgemint.errors import ExitCode, FileError, PandocError, SchemaError, SecurityError
from edgemint.jsonio import load_stylesheet


def test_error_types_expose_expected_exit_codes() -> None:
    assert str(FileError("x")) == "x"
    assert FileError("x").exit_code == ExitCode.FILE
    assert SecurityError("x").exit_code == ExitCode.SECURITY
    assert PandocError("x").exit_code == ExitCode.PANDOC
    assert SchemaError("x").exit_code == ExitCode.SCHEMA


def test_load_stylesheet_missing_file_raises_file_error(tmp_path: Path) -> None:
    with pytest.raises(FileError):
        load_stylesheet(tmp_path / "missing.json")


def test_load_stylesheet_invalid_json_raises_schema_error(tmp_path: Path) -> None:
    path = tmp_path / "broken.json"
    path.write_text("{oops", encoding="utf-8")

    with pytest.raises(SchemaError):
        load_stylesheet(path)


def test_load_stylesheet_invalid_schema_raises_schema_error(tmp_path: Path) -> None:
    path = tmp_path / "broken.json"
    path.write_text("{}", encoding="utf-8")

    with pytest.raises(SchemaError):
        load_stylesheet(path)
