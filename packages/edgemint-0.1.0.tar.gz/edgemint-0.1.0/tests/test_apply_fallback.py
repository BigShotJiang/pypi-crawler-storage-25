from __future__ import annotations

import base64
from pathlib import Path

from docx import Document

from edgemint.apply import (
    _append_inlines,
    _apply_headers_and_footers,
    _extract_plain_text,
    _header_footer_target,
    _inject_header_footer_parts,
    _inject_raw_parts,
    _map_alignment,
    _map_line_spacing,
    _map_tab_alignment,
    _map_tab_leader,
    _map_underline,
    _merge_content_types_part,
    _normalize_header_footer_xml,
    _prepare_header_footer_scopes,
    _render_block,
    _resolve_header_footer_targets,
    apply_stylesheet,
)
from edgemint.markdown import Block, Inline
from edgemint.schema.models import (
    Alignment,
    FontProperties,
    HeaderFooter,
    LineSpacingRule,
    MetaInfo,
    ParagraphFormat,
    ResolvedProperties,
    SectionProperties,
    Style,
    StyleSheet,
    StyleType,
    TabStop,
    UnderlineType,
)


def _basic_stylesheet() -> StyleSheet:
    return StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(style_id="BodyText", name="Body Text", type=StyleType.PARAGRAPH),
            Style(
                style_id="StatusGreen",
                name="Status Green",
                type=StyleType.CHARACTER,
                font=FontProperties(color="#008000", bold=True),
            ),
        ],
        headers_footers=[
            HeaderFooter(
                type="header",
                scope="default",
                content_xml="<w:hdr><w:p><w:r><w:t>Header</w:t></w:r></w:p></w:hdr>",
            )
        ],
        raw_parts={"word/styles.xml": "<styles/>"},
    )


def test_apply_stylesheet_direct_fallback(monkeypatch, tmp_path: Path) -> None:
    markdown = tmp_path / "content.md"
    output = tmp_path / "out.docx"
    markdown.write_text(
        '# Title\n\n::: {custom-style="Body Text"}\nHello [green]{custom-style="Status Green"}.\n:::\n',
        encoding="utf-8",
    )

    monkeypatch.setattr("edgemint.apply.has_pandoc", lambda: False)
    stylesheet = _basic_stylesheet()
    apply_stylesheet(markdown, stylesheet, output)

    document = Document(output)
    assert any(paragraph.text == "Title" for paragraph in document.paragraphs)
    assert any(paragraph.text == "Hello green." for paragraph in document.paragraphs)


def test_inject_raw_parts_rewrites_existing_parts(tmp_path: Path) -> None:
    path = tmp_path / "sample.docx"
    document = Document()
    document.add_paragraph("hello")
    document.save(path)

    stylesheet = _basic_stylesheet()
    _inject_raw_parts(path, stylesheet)

    import zipfile

    with zipfile.ZipFile(path) as archive:
        assert archive.read("word/styles.xml") == b"<styles/>"


def test_inject_raw_parts_preserves_embedded_font_assets(tmp_path: Path) -> None:
    path = tmp_path / "sample.docx"
    document = Document()
    document.add_paragraph("hello")
    document.save(path)

    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        raw_parts={
            "word/fontTable.xml": '<w:fonts xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>',
            "word/_rels/fontTable.xml.rels": (
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId1" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/font" '
                'Target="fonts/font1.odttf"/></Relationships>'
            ),
        },
        raw_binary_parts={"word/fonts/font1.odttf": base64.b64encode(b"font-data").decode("ascii")},
        content_types_xml=(
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="odttf" ContentType="application/vnd.openxmlformats-officedocument.obfuscatedFont"/>'
            '<Override PartName="/word/fontTable.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml"/>'
            "</Types>"
        ),
    )

    _inject_raw_parts(path, stylesheet)

    import zipfile

    with zipfile.ZipFile(path) as archive:
        assert archive.read("word/fontTable.xml").startswith(b"<w:fonts")
        assert archive.read("word/_rels/fontTable.xml.rels").startswith(b"<Relationships")
        assert archive.read("word/fonts/font1.odttf") == b"font-data"
        content_types = archive.read("[Content_Types].xml")
    assert b'Extension="odttf"' in content_types
    assert b'PartName="/word/fontTable.xml"' in content_types


def test_merge_content_types_part_is_noop_when_nothing_matches(tmp_path: Path) -> None:
    path = tmp_path / "sample.docx"
    document = Document()
    document.save(path)

    _merge_content_types_part(
        path,
        (
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="odttf" ContentType="application/vnd.openxmlformats-officedocument.obfuscatedFont"/>'
            "</Types>"
        ),
        set(),
    )

    import zipfile

    with zipfile.ZipFile(path) as archive:
        assert b'Extension="odttf"' not in archive.read("[Content_Types].xml")


def test_merge_content_types_part_adds_missing_override(tmp_path: Path) -> None:
    path = tmp_path / "sample.docx"
    Document().save(path)

    _merge_content_types_part(
        path,
        (
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Override PartName="/word/custom-font-map.xml" ContentType="application/test+xml"/>'
            "</Types>"
        ),
        {"word/custom-font-map.xml"},
    )

    import zipfile

    with zipfile.ZipFile(path) as archive:
        assert b'PartName="/word/custom-font-map.xml"' in archive.read("[Content_Types].xml")


def test_apply_mapping_helpers_cover_supported_enums() -> None:
    assert _map_alignment(Alignment.LEFT) is not None
    assert _map_line_spacing(LineSpacingRule.DOUBLE) is not None
    assert _map_tab_alignment("DECIMAL") is not None
    assert _map_tab_alignment("UNKNOWN") is not None
    assert _map_tab_leader("DOTS") is not None
    assert _map_tab_leader("UNKNOWN") is not None
    assert _map_underline(UnderlineType.WAVE) is not None
    assert _extract_plain_text("<w:p><w:r><w:t>Hi</w:t></w:r></w:p>") == "Hi"


def test_render_block_supports_list_table_and_image(tmp_path: Path) -> None:
    document = Document()

    _render_block(document, Block(kind="list", ordered=True, items=[[Inline(text="One")]]), None)
    _render_block(document, Block(kind="table", rows=[["A", "B"], ["1", "2"]]), None)

    image_path = tmp_path / "pixel.png"
    image_path.write_bytes(
        base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aRXcAAAAASUVORK5CYII="
        )
    )
    _render_block(document, Block(kind="image", text="pixel.png"), tmp_path)

    assert any(paragraph.text == "One" for paragraph in document.paragraphs)
    assert len(document.tables) == 1


def test_append_inlines_ignores_missing_custom_style() -> None:
    document = Document()
    paragraph = document.add_paragraph()
    _append_inlines(paragraph, [Inline(text="x", custom_style="Missing Style")])
    assert paragraph.text == "x"


def test_append_inlines_applies_bold_italic_and_code() -> None:
    document = Document()
    paragraph = document.add_paragraph()
    _append_inlines(paragraph, [Inline(text="styled", bold=True, italic=True, code=True)])
    run = paragraph.runs[0]
    assert run.bold is True
    assert run.italic is True
    assert run.font.name == "Courier New"


def test_header_footer_helpers_inject_raw_parts(tmp_path: Path) -> None:
    document = Document()
    document.sections[0].different_first_page_header_footer = True
    document.settings.odd_and_even_pages_header_footer = True
    document.sections[0].header.paragraphs[0].text = "default"
    document.sections[0].first_page_header.paragraphs[0].text = "first"
    document.sections[0].even_page_header.paragraphs[0].text = "even"
    path = tmp_path / "doc.docx"
    document.save(path)

    items = [
        HeaderFooter(
            type="header",
            scope="default",
            section_index=0,
            content_xml="<w:hdr><w:p><w:r><w:t>A</w:t></w:r></w:p></w:hdr>",
        ),
        HeaderFooter(
            type="header",
            scope="first",
            section_index=0,
            content_xml="<w:hdr><w:p><w:r><w:t>B</w:t></w:r></w:p></w:hdr>",
        ),
        HeaderFooter(
            type="header",
            scope="even",
            section_index=0,
            content_xml="<w:hdr><w:p><w:r><w:t>C</w:t></w:r></w:p></w:hdr>",
        ),
    ]

    _inject_header_footer_parts(path, items)

    import zipfile

    with zipfile.ZipFile(path) as archive:
        mapping = _resolve_header_footer_targets(
            archive.read("word/document.xml"),
            archive.read("word/_rels/document.xml.rels"),
        )
        for part_name, key in mapping.items():
            if key[0] == "header":
                assert _extract_plain_text(archive.read(part_name).decode("utf-8")) in {
                    "A",
                    "B",
                    "C",
                }


def test_normalize_header_footer_xml_adds_required_namespaces() -> None:
    content = _normalize_header_footer_xml(
        "<w:hdr><w:p><w:r><w:t>Header</w:t></w:r></w:p></w:hdr>"
    ).decode("utf-8")
    assert 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"' in content
    assert _extract_plain_text(content) == "Header"


def test_normalize_header_footer_xml_handles_footer_and_blank_content() -> None:
    assert _normalize_header_footer_xml("") == b""
    content = _normalize_header_footer_xml(
        "<w:ftr><w:p><w:r><w:t>Footer</w:t></w:r></w:p></w:ftr>"
    ).decode("utf-8")
    assert "<w:ftr" in content
    assert _extract_plain_text(content) == "Footer"


def test_header_footer_target_selector() -> None:
    document = Document()
    section = document.sections[0]
    assert (
        _header_footer_target(
            document,
            section,
            HeaderFooter(type="header", scope="default", section_index=0, content_xml=""),
        ).part
        == section.header.part
    )
    assert (
        _header_footer_target(
            document,
            section,
            HeaderFooter(type="header", scope="first", section_index=0, content_xml=""),
        ).part
        == section.first_page_header.part
    )
    assert (
        _header_footer_target(
            document,
            section,
            HeaderFooter(type="header", scope="even", section_index=0, content_xml=""),
        ).part
        == section.even_page_header.part
    )
    assert (
        _header_footer_target(
            document,
            section,
            HeaderFooter(type="footer", scope="default", section_index=0, content_xml=""),
        ).part
        == section.footer.part
    )
    assert (
        _header_footer_target(
            document,
            section,
            HeaderFooter(type="footer", scope="first", section_index=0, content_xml=""),
        ).part
        == section.first_page_footer.part
    )
    assert (
        _header_footer_target(
            document,
            section,
            HeaderFooter(type="footer", scope="even", section_index=0, content_xml=""),
        ).part
        == section.even_page_footer.part
    )


def test_apply_headers_and_footers_handles_empty_input() -> None:
    document = Document()
    _apply_headers_and_footers(document, [])
    assert document.sections[0].header.paragraphs[0].text == ""


def test_prepare_header_footer_scopes_enables_first_and_even_modes() -> None:
    document = Document()
    _prepare_header_footer_scopes(
        document,
        [
            HeaderFooter(type="header", scope="first", content_xml=""),
            HeaderFooter(type="footer", scope="even", section_index=0, content_xml=""),
        ],
    )
    assert document.sections[0].different_first_page_header_footer is True
    assert document.settings.odd_and_even_pages_header_footer is True


def test_apply_stylesheet_builds_resolved_and_local_styles(monkeypatch, tmp_path: Path) -> None:
    markdown = tmp_path / "content.md"
    output = tmp_path / "out.docx"
    markdown.write_text("Paragraph text.\n", encoding="utf-8")

    monkeypatch.setattr("edgemint.apply.has_pandoc", lambda: False)
    stylesheet = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        styles=[
            Style(
                style_id="BodyText",
                name="Body Text",
                type=StyleType.PARAGRAPH,
                paragraph_format=ParagraphFormat(
                    line_spacing=1.5,
                    line_spacing_rule=LineSpacingRule.MULTIPLE,
                    keep_with_next=True,
                    keep_together=True,
                    page_break_before=False,
                    widow_control=True,
                    indent_left_pt=6.0,
                    indent_right_pt=4.0,
                    indent_first_line_pt=8.0,
                    tab_stops=[TabStop(position_pt=12.0, alignment="CENTER", leader="DOTS")],
                ),
            ),
            Style(
                style_id="ResolvedChar",
                name="Resolved Char",
                type=StyleType.CHARACTER,
                resolved=ResolvedProperties(
                    font=FontProperties(
                        name="Courier New",
                        size_pt=11.0,
                        bold=True,
                        italic=True,
                        underline=UnderlineType.DOUBLE,
                        strike=True,
                        double_strike=True,
                        color="#112233",
                        superscript=True,
                        subscript=False,
                        small_caps=True,
                        all_caps=True,
                    )
                ),
            ),
        ],
        section_properties=SectionProperties(orientation="landscape"),
    )

    apply_stylesheet(markdown, stylesheet, output)

    document = Document(output)
    assert document.styles["Body Text"].paragraph_format.keep_with_next is True
    assert document.styles["Body Text"].paragraph_format.keep_together is True
    assert document.styles["Resolved Char"].font.bold is True
    assert document.sections[0].orientation is not None


def test_render_block_skips_empty_table_and_missing_image(tmp_path: Path) -> None:
    document = Document()
    _render_block(document, Block(kind="table", rows=[]), None)
    _render_block(document, Block(kind="image", text="missing.png"), tmp_path)
    assert len(document.tables) == 0


def test_render_block_applies_table_style_when_available() -> None:
    document = Document()
    _render_block(document, Block(kind="table", rows=[["A"], ["B"]], style="TableGrid"), None)
    assert document.tables[0].style.name == "Table Grid"


def test_prepare_scopes_and_target_resolution_cover_edge_cases() -> None:
    document = Document()
    empty_mapping = _resolve_header_footer_targets(
        b'<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body/></w:document>',
        b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>',
    )
    assert empty_mapping == {}

    missing_rel_mapping = _resolve_header_footer_targets(
        (
            b'<w:document xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
            b'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:sectPr>'
            b'<w:headerReference r:id="rId9" w:type="default"/></w:sectPr></w:body></w:document>'
        ),
        b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>',
    )
    assert missing_rel_mapping == {}

    _apply_headers_and_footers(
        document,
        [
            HeaderFooter(
                type="header",
                scope="first",
                section_index=0,
                content_xml="<w:hdr><w:p><w:r><w:t>First</w:t></w:r></w:p></w:hdr>",
            ),
            HeaderFooter(
                type="footer",
                scope="even",
                section_index=0,
                content_xml="<w:ftr><w:p><w:r><w:t>Even</w:t></w:r></w:p></w:ftr>",
            ),
        ],
    )
    assert document.sections[0].first_page_header.paragraphs[0].text == "First"
    assert document.sections[0].even_page_footer.paragraphs[0].text == "Even"


def test_multi_section_configuration_and_header_footer_mapping() -> None:
    document = Document()
    styles = StyleSheet(
        meta=MetaInfo(source_file="x.docx", extracted_at="2026-04-12T00:00:00+00:00"),
        sections=[
            SectionProperties(section_index=0, start_type="NEW_PAGE"),
            SectionProperties(section_index=1, orientation="landscape", start_type="CONTINUOUS"),
        ],
        headers_footers=[
            HeaderFooter(
                type="header",
                scope="default",
                section_index=1,
                content_xml="<w:hdr><w:p><w:r><w:t>S2</w:t></w:r></w:p></w:hdr>",
            ),
        ],
    )
    from edgemint.apply import _configure_sections

    _configure_sections(document, styles)
    _apply_headers_and_footers(document, styles.headers_footers)
    assert len(document.sections) == 2
    assert document.sections[1].orientation is not None
    assert document.sections[1].header.paragraphs[0].text == "S2"
