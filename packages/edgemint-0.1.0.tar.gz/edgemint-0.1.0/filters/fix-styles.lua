-- WHY: Pandoc's native readers can express the same intent through different
-- attribute spellings or classes. Normalizing them here keeps the DOCX writer
-- path deterministic and reduces drift between Markdown and AsciiDoc input.

local PAGEBREAK_XML = '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'

local function has_class(el, wanted)
  for _, class_name in ipairs(el.classes) do
    if class_name == wanted then
      return true
    end
  end
  return false
end

local function normalize_custom_style(el)
  local style = el.attributes["custom-style"]
  if style and style ~= "" then
    return style
  end

  for _, key in ipairs({ "custom_style", "style-name", "style_name" }) do
    local value = el.attributes[key]
    if value and value ~= "" then
      el.attributes["custom-style"] = value
      el.attributes[key] = nil
      return value
    end
  end

  for _, class_name in ipairs(el.classes) do
    local inferred = class_name:match("^custom%-style%-(.+)$")
    if inferred then
      inferred = inferred:gsub("_", " ")
      el.attributes["custom-style"] = inferred
      return inferred
    end
  end

  return nil
end

local function is_pagebreak(el)
  return has_class(el, "pagebreak")
    or el.attributes["pagebreak"] == "true"
    or el.attributes["role"] == "pagebreak"
end

function Div(div)
  normalize_custom_style(div)
  if is_pagebreak(div) then
    return pandoc.RawBlock("openxml", PAGEBREAK_XML)
  end
  return div
end

function Span(span)
  normalize_custom_style(span)
  return span
end
