-- WHY: list items often arrive with wrapper blocks that are harmless in HTML
-- but confusing for DOCX paragraph styling. Flattening trivial wrappers keeps
-- list content closer to the author's source structure before the DOCX writer.
--
-- Pandoc 3.x calls Lua filters with element objects, not the older positional
-- `(items, attributes)` callback shape. Mutating the element in place keeps the
-- filter forward-compatible and avoids silently erasing list content.

local function normalize_item_blocks(blocks)
  local normalized = {}

  for _, block in ipairs(blocks) do
    if block.t == "Div" and #block.content > 0 and block.identifier == "" then
      local style = block.attributes["custom-style"]
      for _, inner in ipairs(block.content) do
        if style and inner.t == "Div" and inner.attributes["custom-style"] == nil then
          inner.attributes["custom-style"] = style
        end
        table.insert(normalized, inner)
      end
    elseif block.t == "Plain" then
      table.insert(normalized, pandoc.Para(block.content))
    else
      table.insert(normalized, block)
    end
  end

  return normalized
end

local function normalize_items(items)
  local normalized = {}
  for _, item in ipairs(items) do
    table.insert(normalized, normalize_item_blocks(item))
  end
  return normalized
end

function BulletList(list)
  list.content = normalize_items(list.content)
  return list
end

function OrderedList(list)
  list.content = normalize_items(list.content)
  return list
end
