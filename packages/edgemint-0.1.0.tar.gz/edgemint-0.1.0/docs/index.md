# edgemint Documentation

> **Your branded documents deserve better than copy-paste styling.**

You have a beautiful `.docx` template. Your designer spent weeks on it. Now you
need to produce 50 reports with that exact look, from Markdown your team writes
in Git.

The standard answer is: open Word, copy-paste, manually re-apply every style,
fix the spacing, fix the fonts, repeat forever.

**edgemint's answer:** two commands.

```bash
edgemint extract-styles brand.docx -o styles.json  # once
edgemint apply-styles   report.md  styles.json -o report.docx  # every time
```

That's it. Every font, color, spacing, and border — identical to your template,
every time, from plain Markdown, no Word required.

---

## Who are you?

| Persona | Start here |
|---------|-----------|
| Just want to try it out | [Quick Start](quick-start.md) |
| Writing Packt / publisher content | [Packt Author Guide](packt-author-guide.md) |
| Automating document pipelines | [CI/CD Integration](cicd-integration.md) |
| Building on top of edgemint | [CLI Reference](cli-reference.md) |
| Contributing code | [Contributing Guide](../CONTRIBUTING.md) |
| About to cut a release | [Release Process](release-process.md) |
| Understanding the design | [Architecture](architecture.md) |

---

## 30-second orientation

```
┌──────────────┐   extract-styles   ┌───────────────┐
│ branded.docx │ ─────────────────▶ │  styles.json  │
│  (template)  │                    │  (identity)   │
└──────────────┘                    └───────┬───────┘
                                            │
                          apply-styles      │
                    ┌────────────────────── ┘
                    │
                    ▼
         ┌──────────────────┐
         │   content.md     │
         │  (your words)    │
         └────────┬─────────┘
                  │
                  ▼
         ┌──────────────────┐
         │   output.docx    │
         │  (pixel-perfect) │
         └──────────────────┘
```

Two commands. Any template. Every time.

---

## Docs map

```
docs/
├── index.md              ← you are here
├── quick-start.md        ← install + first round-trip in 3 min
├── cli-reference.md      ← every command, flag, exit code
├── style-guide.md        ← how to name styles in Markdown
├── packt-author-guide.md ← Packt publisher workflow
├── cicd-integration.md   ← GitHub Actions / Docker pipeline
├── architecture.md       ← design decisions, schema, ADR
└── release-process.md    ← how to cut a release
```
