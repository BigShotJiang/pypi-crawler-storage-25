# Release Process

This document describes how to cut a new release of **edgemint** — from bump to PyPI to GitHub Container Registry.

---

## Overview

```
bump version in pyproject.toml + __init__.py
          │
          ▼
     make release-check          ← pre-flight (lint + tests + tag guard)
          │
          ▼
     make release-tag            ← git tag vX.Y.Z && push
          │
          ▼
  GitHub Actions: Release workflow
    ├── build job        (lint + test + python -m build)
    ├── github-release   (creates GitHub Release + uploads assets)
    ├── publish-pypi     (OIDC Trusted Publisher → PyPI)
    └── publish-container (Docker image → ghcr.io)
```

---

## Step-by-step

### 1. Bump the version

Edit **two files** — both must match the git tag:

| File | Field |
|------|-------|
| `pyproject.toml` | `[project] version = "X.Y.Z"` |
| `src/edgemint/__init__.py` | `__version__ = "X.Y.Z"` |

`edgemint` follows [Semantic Versioning](https://semver.org/):

- `PATCH` — bug fixes, no API change
- `MINOR` — new features, backwards-compatible
- `MAJOR` — breaking changes

### 2. Update CHANGELOG / release notes (optional but recommended)

Add a `## vX.Y.Z — YYYY-MM-DD` section to `CHANGELOG.md` (if present) or
rely on the auto-generated GitHub Release notes (the CI uses
`generate_release_notes: true`).

### 3. Commit the bump

```bash
git add pyproject.toml src/edgemint/__init__.py
git commit -m "chore: bump version to X.Y.Z"
git push
```

### 4. Run the pre-flight checklist

```bash
make release-check
```

This will verify that:

- The working tree is clean
- You are on `main` / `master`
- The tag `vX.Y.Z` does not already exist
- Lint passes (`ruff`)
- The full test suite passes at 100 % coverage

All checks must be green before proceeding.

### 5. (Optional) Inspect the built packages

```bash
make release-dry-run
```

Builds `dist/` locally and lists the contents without publishing anywhere.
Requires `twine` for the full integrity check: `pip install twine`.

### 6. Push the tag

```bash
make release-tag
```

This runs:

```bash
git tag -a "vX.Y.Z" -m "Release vX.Y.Z"
git push origin "vX.Y.Z"
```

The push of a `v*` tag automatically triggers the
[Release workflow](.github/workflows/release.yml).

### 7. Monitor the Release workflow

Open the Actions tab:

```
https://github.com/raphaelmansuy/edgemint/actions
```

Four parallel jobs run after the build succeeds:

| Job | What it does |
|-----|-------------|
| `github-release` | Creates a GitHub Release with auto-generated notes and attaches the wheel + sdist |
| `publish-pypi` | Publishes to PyPI via OIDC Trusted Publishing (no API key needed) |
| `publish-container` | Pushes `ghcr.io/raphaelmansuy/edgemint:X.Y.Z` and `:latest` |

---

## One-Time GitHub Setup

These steps are performed **once per repository**, not per release.

### A. PyPI — Trusted Publisher

Trusted Publishing uses GitHub Actions OIDC to authenticate with PyPI —
**no API token or secret is stored in GitHub**.

1. Go to **https://pypi.org/manage/account/publishing/** (log in as the package owner).
2. Click **Add a new pending publisher**.
3. Fill in:

   | Field | Value |
   |-------|-------|
   | PyPI project name | `edgemint` |
   | Owner | `raphaelmansuy` |
   | Repository name | `edgemint` |
   | Workflow filename | `release.yml` |
   | Environment name | `pypi` |

4. Click **Add**.
5. In the GitHub repository → **Settings → Environments**, create an environment named **`pypi`**.
   - Optionally add a **Required reviewer** for extra safety.

The `publish-pypi` job in [release.yml](.github/workflows/release.yml) uses:

```yaml
environment:
  name: pypi
permissions:
  id-token: write   # OIDC token — no secrets stored
```

### B. GitHub Container Registry (GHCR)

GHCR authentication uses the built-in `GITHUB_TOKEN` — **no secret setup required**.

The `publish-container` job uses:

```yaml
permissions:
  packages: write
```

and authenticates via:

```yaml
- uses: docker/login-action@v3
  with:
    registry: ghcr.io
    username: ${{ github.actor }}
    password: ${{ secrets.GITHUB_TOKEN }}
```

### C. GitHub Release creation

The `github-release` job uses `softprops/action-gh-release` and requires:

```yaml
permissions:
  contents: write
```

No additional secrets needed.

### Summary of required secrets / permissions

| What | Secret/Permission | Where configured |
|------|------------------|-----------------|
| PyPI publish | OIDC `id-token: write` + Trusted Publisher on pypi.org | pypi.org publisher settings + GitHub Environment `pypi` |
| GHCR push | `packages: write` (auto) | GitHub Actions built-in |
| GitHub Release | `contents: write` (auto) | GitHub Actions built-in |
| **Total external secrets stored in GitHub** | **0** | — |

---

## Hotfix releases

For a patch release from a stable branch:

```bash
git checkout -b hotfix/X.Y.Z vX.Y.(Z-1)
# apply fix
# bump version in pyproject.toml and __init__.py to X.Y.Z
git commit -m "fix: <description>"
git push -u origin hotfix/X.Y.Z
make release-check
make release-tag
```

The Release workflow runs identically regardless of the source branch.

---

## Rolling back a bad release

PyPI does not allow deleting published versions, but you can **yank** them:

```bash
pip install twine
twine yank edgemint==X.Y.Z
```

Or via the PyPI web UI: **Manage project → Release X.Y.Z → Yank release**.

Yanked releases are hidden from `pip install edgemint` (latest) but remain
installable with `pip install edgemint==X.Y.Z` for pinned consumers.
