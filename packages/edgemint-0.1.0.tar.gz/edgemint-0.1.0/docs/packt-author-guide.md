# Packt Author Guide — Writing with edgemint

> **Write once in Markdown. Get a pixel-perfect Packt-styled DOCX every time.**

This guide is for authors writing Packt books or technical content using edgemint
to produce Word manuscripts from plain Markdown source.

---

## Why this workflow exists

Packt chapters need precise Word styling: chapter openers, info boxes, code
blocks, tip/note callouts, figure captions — all mapped to specific named Word
styles. Re-applying those styles by hand after every content edit is error-prone
and slow.

edgemint solves this by:

1. Extracting the complete Packt style catalogue from the provided `.docx` template
2. Letting you write content in plain Markdown with `custom-style` annotations
3. Regenerating a perfectly-styled `.docx` with one command

The template stores **how it looks**. Your Markdown stores **what it says**. They
never get tangled.

---

## Setup (one time)

```bash
pip install edgemint[pandoc]

# From the edgemint repo, extract the Packt template
edgemint extract-styles examples/packt-style.docx -o packt.json

# Verify your toolchain
edgemint info examples/packt-style.docx
```

---

## The authoring loop

```
  Write content.md
       │
       ▼
  edgemint apply-styles content.md packt.json -o chapter.docx --media media
       │
       ▼
  Open chapter.docx in Word or LibreOffice — review only the style output,
  not the content (content lives in content.md)
       │
       ▼
  Iterate in content.md until satisfied, then submit chapter.docx
```

---

## Chapter structure

Every Packt chapter follows this opening pattern:

```markdown
---
title: "Chapter 3"
author: "Your Name"
---

::: {custom-style="HS - ChapterNumber"}
Chapter 3
:::

::: {custom-style="HS - ChapterTitle"}
Understanding Transformer Architectures
:::

::: {custom-style="P0 - Paragraph"}
This chapter explains the self-attention mechanism...
:::
```

---

## Body text

Use standard Markdown headings for structure. Use `P0 - Paragraph` for body
text that needs the Packt paragraph style explicitly:

```markdown
# Self-Attention

Standard body paragraphs use the `Normal` style automatically.

::: {custom-style="P0 - Paragraph"}
Use this style for the opening paragraph of a new section, or wherever the
template expects the Packt primary paragraph style.
:::

::: {custom-style="P1 - Paragraph"}
Use P1 for secondary exposition — a tighter or visually distinct cadence.
:::
```

---

## Callout boxes

```markdown
::: {custom-style="I - InfoBox"}
**Info box content.** Use for background context the reader needs immediately.
:::

::: {custom-style="T - TipBox"}
**Tip.** Tips should change the reader's behaviour. If a tip does not alter a
concrete decision, it is decoration.
:::

::: {custom-style="C - Citation"}
"A production workflow fails first at the seam between intention and repeatability."
:::
```

---

## Code blocks

```markdown
::: {custom-style="C0 - CodeBlock"}
def train_step(model, batch):
    logits = model(batch["input_ids"])
    return loss_fn(logits, batch["labels"])
:::

::: {custom-style="C0 - ConsoleBlock"}
$ python train.py --epochs 10 --lr 1e-4
Epoch 1/10: loss=2.34
:::

::: {custom-style="C1 - CodeBlock"}
# Secondary code style — alternative listing appearance
import torch
x = torch.randn(4, 512, 768)
:::
```

---

## Lists

Use native Markdown lists for bullet and numbered content — the template owns
the visual treatment:

```markdown
- First bullet point.
- Second bullet point.
  - Nested bullet (use sparingly).
    - Third level (avoid).

1. First ordered step.
2. Second ordered step.
   1. Sub-step when the sequence matters.
```

For explicit Packt list styles:

```markdown
::: {custom-style="L1 - Bullet"}
Level 1 bullet using the explicit Packt list style.
:::

::: {custom-style="L1 - Numbered"}
Level 1 numbered item.
:::

::: {custom-style="L2 - Bullet"}
Level 2 (nested) bullet.
:::
```

---

## Tables

Wrap tables in the `TS - Table` style:

```markdown
::: {custom-style="TS - Table"}
| Concept        | Markdown move              | Word result              |
|:---------------|:--------------------------|:------------------------|
| Info callout   | `I - InfoBox` div          | Styled info paragraph   |
| Code listing   | `C0 - CodeBlock` div       | Packt code block        |
| Console output | `C0 - ConsoleBlock` div    | Packt console block     |
| Figure caption | `F0 - FigureCaption` div   | Consistent caption      |
:::
```

---

## Figures and captions

```markdown
![Transformer self-attention mechanism](media/attention-map.png){ width=80% }

::: {custom-style="F0 - FigureCaption"}
Figure 3.1 — Self-attention scores for a single head across all token positions.
The diagonal indicates each token attending to itself.
:::
```

Always place images in a `media/` directory alongside your Markdown file,
then pass `--media media` when generating:

```bash
edgemint apply-styles chapter.md packt.json -o chapter.docx --media media
```

---

## Inline character styles

Use these within paragraphs for semantic inline emphasis:

```markdown
The [transformer]{custom-style="CS - Keyword"} model uses
[self_attention()]{custom-style="CS - InlineCode"} to compute
[attention weights]{custom-style="CS - BoldItalic"}.

Visit [https://arxiv.org/abs/1706.03762]{custom-style="CS - URL"} for the
original paper.
```

| Style | Use for |
|-------|--------|
| `CS - Keyword` | technical terms, model names |
| `CS - InlineCode` | code identifiers, function names, CLI commands |
| `CS - BoldItalic` | strong emphasis |
| `CS - Italic` | editorial asides, first-use definitions |
| `CS - URL` | hyperlinks (when not using standard Markdown syntax) |
| `CS - Screentext` | UI labels, menu items, button names |
| `CS - Subscript` | chemical formulae, math subscripts |
| `CS - Superscript` | footnote anchors, math superscripts |

---

## Complete Packt style catalogue

These are all the paragraph styles exposed by the Packt template:

### Chapter openers
| Style | Purpose |
|-------|--------|
| `HS - ChapterNumber` | "Chapter N" label at the top of each chapter |
| `HS - ChapterTitle` | Chapter title |
| `HS - Heading 1–4` | House headings for major sections |

### Body text
| Style | Purpose |
|-------|--------|
| `P0 - Paragraph` | Primary Packt body paragraph |
| `P0 - ParagraphCenter` | Centred variant (epigraphs, dividers) |
| `P1 - Paragraph` | Secondary body paragraph |

### Callouts
| Style | Purpose |
|-------|--------|
| `I - InfoBox` | Background information callout |
| `T - TipBox` | Actionable tip |
| `C - Citation` | Block quotation |
| `QS - Quote` | Standalone quote block |

### Code
| Style | Purpose |
|-------|--------|
| `C0 - CodeBlock` | Primary code listing |
| `C0 - ConsoleBlock` | Terminal / shell session |
| `C1 - CodeBlock` | Secondary code listing |
| `C1 - ConsoleBlock` | Secondary console block |

### Lists
| Style | Purpose |
|-------|--------|
| `L1 - Bullet` / `L2 - Bullet` / `L3 - Bullet` | Bullet list levels |
| `L1 - Numbered` / `L2 - Numbered` / `L3 - Numbered` | Numbered list levels |
| `L1 - Alphabet` / `L2 - Alphabet` / `L3 - Alphabet` | Alphabetic list levels |

### Figures
| Style | Purpose |
|-------|--------|
| `F0 - Figure` | Figure container paragraph |
| `F0 - FigureCaption` | Caption below figure |

### Tables
| Style | Purpose |
|-------|--------|
| `TS - Table` | Table wrapper paragraph |
| `TS - TableBullet` | Bullet list inside a table cell |
| `TS - TableCenter` | Centred text in a table cell |
| `TS - TableNumberedList` | Numbered list inside a table cell |

---

## Generating your chapter DOCX

```bash
# From your working directory (with content.md, media/, packt.json)
edgemint apply-styles content.md packt.json -o chapter-03.docx --media media
```

For a full batch build in the edgemint repo:

```bash
make examples
# rebuilds all example DOCXs from source
```

---

## Validating the style sheet

```bash
edgemint validate packt.json     # → Valid

# See all available style names
python -c "
import json
for s in json.load(open('packt.json'))['styles']:
    print(f\"{s['type']:12} {s['name']}\")
" | sort
```

---

## Troubleshooting

**Style not applying?**
Check that the `custom-style` value exactly matches the `name` field in `packt.json`.
Style names are case-sensitive.

**Images not appearing?**
Pass `--media` pointing to the directory that contains the image files:
```bash
edgemint apply-styles content.md packt.json -o out.docx --media ./media
```

**Font looks wrong?**
The font is template-owned. If `C0 - CodeBlock` uses the wrong font, the issue
is in the template, not your Markdown. Inspect with:
```bash
edgemint extract-styles packt-style.docx -o check.json
```

---

## Further reading

- [Style Guide](style-guide.md) — complete `custom-style` annotation reference
- [CLI Reference](cli-reference.md) — all commands and flags
- [Architecture](architecture.md) — how the pipeline works internally
