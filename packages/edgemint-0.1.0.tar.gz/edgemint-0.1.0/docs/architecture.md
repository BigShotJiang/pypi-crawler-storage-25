# Architecture — Design Decisions and Technical Reference

How edgemint works internally, why certain decisions were made, and the
complete data model.

---

## The core insight

A `.docx` file is a ZIP archive of XML parts (ECMA-376 / Office Open XML).
The style sheet lives in `word/styles.xml`. Each style is a **compression** —
it encodes N formatting properties under a single name.

```
┌─────────────────────────────────────────────────────────────────┐
│           DOCX as a lossless information store                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   word/styles.xml       → style definitions + inheritance chain │
│   word/numbering.xml    → list/numbering definitions            │
│   word/theme/theme1.xml → fonts, colors                        │
│   word/document.xml     → body content                         │
│   word/header*.xml      → headers                              │
│   word/footer*.xml      → footers                              │
│   word/media/*          → embedded images and objects          │
│                                                                 │
│   All parts are addressable by relationship IDs.               │
│   edgemint decompresses the style map into an explicit JSON.   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## System overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         edgemint CLI                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────┐  ┌───────────┐ │
│  │ extract-     │  │  extract     │  │  apply-   │  │  diff /   │ │
│  │ styles       │  │  (full)      │  │  styles   │  │  validate │ │
│  │ (no Pandoc)  │  │ (+ Pandoc)   │  │(+ Pandoc) │  │(no Pandoc)│ │
│  └──────┬───────┘  └──────┬───────┘  └─────┬─────┘  └─────┬─────┘ │
│         │                 │                │              │       │
│         ▼                 ▼                ▼              ▼       │
│  ┌──────────────┐  ┌────────────┐  ┌────────────┐  ┌──────────┐ │
│  │ StyleParser  │  │ Pandoc CLI │  │ Pandoc CLI │  │ StyleDiff│ │
│  │ (python-docx)│  │ + PostProc │  │ + PostProc │  │(Pydantic)│ │
│  └──────┬───────┘  └──────┬─────┘  └──────┬─────┘  └──────────┘ │
│         │                 │                │                      │
│         ▼                 ▼                ▼                      │
│  ┌─────────────────────────────────────────────────┐             │
│  │          StyleSchema (shared Pydantic models)   │             │
│  └─────────────────────────────────────────────────┘             │
│         │                 │                │                      │
│         ▼                 ▼                ▼                      │
│    styles.json     project/ bundle    output.docx                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Extract phase

```
input.docx
     │
     ├──▶ word/styles.xml
     │    word/numbering.xml   ──▶  StyleParser
     │    word/theme/theme1.xml         │
     │                                  ▼
     │                            StyleSheet (Pydantic)
     │                                  │
     │                                  ▼
     │                            styles.json
     │
     ├──▶ word/document.xml  ──▶  Pandoc (docx+styles → markdown)
     │                                  │
     │                                  ▼
     │                            content.md
     │
     └──▶ word/media/*  ──────────────▶ media/ (binary copy)
```

**StyleParser** walks the `based_on` chain for each style, resolves theme
font/color references, and emits `ResolvedProperties` containing the fully
computed formatting (no further inheritance required to render).

---

## Apply phase

```
content.md     styles.json     media/
     │               │             │
     │               ▼             │
     │         StyleSheet          │
     │         build reference     │
     │         .docx in memory     │
     │               │             │
     ▼               ▼             ▼
┌───────────────────────────────────────┐
│          Pandoc DOCX Writer           │
│  pandoc content.md                    │
│    --reference-doc=reference.docx     │
│    --lua-filter=fix-lists.lua         │
│    --lua-filter=fix-styles.lua        │
│    --resource-path=media/             │
│    -o raw_output.docx                 │
└─────────────────┬─────────────────────┘
                  │
                  ▼
┌───────────────────────────────────────┐
│        PostProcessor (python-docx)    │
│  1. Deduplicate styles                │
│  2. Inject styles.json definitions    │
│  3. Fix list paragraph styles         │
│  4. Re-link heading numbering         │
│  5. Inject headers/footers from JSON  │
└─────────────────┬─────────────────────┘
                  │
                  ▼
            output.docx
```

---

## The three-file architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                WHAT  +  HOW IT LOOKS  +  ASSETS                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  content.md            styles.json           media/            │
│  ───────────           ───────────           ──────            │
│  The words,            The fonts,            The images,       │
│  the structure,        the colors,           the charts,       │
│  the references,       the spacing,          the diagrams      │
│  the math              the borders                             │
│                                                                 │
│  Separation = power.                                           │
│  Edit content without touching styles.                         │
│  Swap styles without touching content.                         │
│  Version everything in Git.                                    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Pydantic model hierarchy

```
StyleSheet
├── meta: MetaInfo
│   └── source_file, extracted_at, tool_version
├── theme: ThemeInfo
│   ├── major_font: FontSpec   (headings)
│   ├── minor_font: FontSpec   (body)
│   └── colors: dict[str, str] (accent1..accent6, dk1, lt1, ...)
├── styles: list[Style]
│   └── Style
│       ├── style_id: str          (locale-independent key)
│       ├── name: str              (locale-dependent display name)
│       ├── type: StyleType        (paragraph|character|table|numbering)
│       ├── based_on: str | None   (inheritance parent)
│       ├── next_style: str | None
│       ├── paragraph_format: ParagraphFormat | None
│       ├── font: FontProperties | None
│       └── resolved: ResolvedProperties | None
│           ├── paragraph_format: ParagraphFormat
│           └── font: FontProperties
├── numbering_defs: list[NumberingDef]
│   └── NumberingDef
│       ├── num_id: int
│       ├── abstract_num_id: int
│       └── levels: list[NumberingLevel]
├── section_properties: SectionProperties
│   └── page_width_pt, page_height_pt, margins, orientation, columns
└── headers_footers: list[HeaderFooter]
    └── HeaderFooter
        ├── type: "header" | "footer"
        ├── scope: "default" | "first" | "even"
        └── content_xml: str  (raw OOXML — lossless)
```

All models use `ConfigDict(frozen=True)` — immutable, hashable, thread-safe.

---

## JSON schema sample

```json
{
  "$schema": "edgemint/v1",
  "meta": {
    "source_file": "brand.docx",
    "extracted_at": "2026-04-12T10:30:00+08:00",
    "tool_version": "0.1.0"
  },
  "theme": {
    "major_font": { "latin": "Calibri Light" },
    "minor_font": { "latin": "Calibri" },
    "colors": { "accent1": "#4472C4", "accent2": "#ED7D31" }
  },
  "styles": [
    {
      "style_id": "Heading1",
      "name": "heading 1",
      "type": "paragraph",
      "based_on": "Normal",
      "font": {
        "name": "Calibri Light",
        "size_pt": 16.0,
        "color": "#2F5496",
        "bold": false
      },
      "paragraph_format": {
        "space_before_pt": 12.0,
        "keep_with_next": true
      }
    }
  ]
}
```

---

## Technology decision rationale

| Criterion | Python + python-docx | Rust + docx-rust | Node.js + mammoth |
|-----------|---------------------|-----------------|-----------------|
| Style enumeration | `doc.styles` iterator, XML fallback | No high-level iterator | No style API |
| Property depth | Full: font, paragraph, tab stops, borders, numbering | Incomplete field coverage | Strips styles by design |
| Inheritance resolution | `style.base_style` chain | Manual implementation | N/A |
| DOCX generation | Full write support | Limited write support | Separate package |
| Ecosystem maturity | v1.2+, 5,300+ stars | 0.x, limited community | mammoth = wrong tool |
| Time to MVP | ~2 days | ~5-7 days | ~4-5 days |

**Verdict**: Python + python-docx wins on every axis.

---

## Security model

- **Path traversal**: all file paths are validated against a safe root before
  any read or write. Paths resolving outside the working directory are blocked
  (exit code `5`).
- **Macro stripping**: macros and VBA are not executed and are stripped during
  extraction. There is no intent to preserve them.
- **Dependency hygiene**: all dependencies are pinned with lower bounds and
  tested against their latest versions in CI.

---

## Markdown dialect decision

edgemint uses **Pandoc Extended Markdown** with these extensions:

```
fenced_divs             ::: {custom-style="X"} blocks
bracketed_spans         [text]{custom-style="Y"} spans
yaml_metadata_block     YAML front matter
footnotes               [^id] syntax
grid_tables             tables with cell spanning
fenced_code_attrs       code blocks with language + attributes
raw_attribute           ```{=openxml} for raw OOXML injection
implicit_figures        images as figures with captions
link_attributes         ![](img){width=X}
```

Standard CommonMark / GFM cannot represent named style annotations at the
paragraph or character level, which is the critical requirement.

See [official Pandoc MANUAL](https://pandoc.org/MANUAL.html) for the full
extension reference.

---

## Module map

```
src/edgemint/
├── __init__.py          version
├── __main__.py          python -m edgemint entry
├── cli.py               Typer app + all commands
├── apply.py             apply-styles pipeline
├── diffing.py           diff engine
├── errors.py            EdgemintError hierarchy + exit codes
├── jsonio.py            JSON serialisation / deserialisation
├── markdown.py          Markdown post-processing helpers
├── ooxml.py             python-docx XML manipulation
├── pandoc.py            Pandoc subprocess wrapper
├── extract/
│   ├── document.py      full extract-styles + extract bundle
│   ├── resolver.py      based_on chain + theme resolution
│   └── security.py      path traversal guard
└── schema/
    ├── models.py         Pydantic models (the authoritative schema)
    └── validators.py     cross-model validation rules
```
