# Quick Start — Your First Round-Trip in 3 Minutes

> **Goal**: take a branded `.docx` template, write content in Markdown, get back a perfectly-styled Word document.

---

## Install

### Lightweight (style extraction only, no Pandoc required)

```bash
pip install edgemint
```

### Full pipeline (extraction + generation)

```bash
pip install edgemint[pandoc]
```

### Docker (zero local dependencies)

```bash
docker pull ghcr.io/raphaelmansuy/edgemint:latest
alias edgemint='docker run --rm -v "$PWD:/work" -w /work ghcr.io/raphaelmansuy/edgemint'
```

### From source

```bash
git clone https://github.com/raphaelmansuy/edgemint
cd edgemint
make bootstrap          # creates .venv and installs all deps
make doctor             # verify everything is working
```

---

## Step 1 — Inspect your template

```bash
edgemint info template.docx
```

```
Styles: 42
Paragraph: 28
Character: 11
Table: 3
Theme heading font: Calibri Light
Theme body font: Calibri
Sections: 1
Max inheritance depth: 4
```

---

## Step 2 — Extract the style identity

```bash
edgemint extract-styles template.docx -o styles.json
```

`styles.json` now contains everything: fonts, colors, spacing, borders, numbering, inheritance chains — **lossless**.

---

## Step 3 — Write your content

Create `report.md`:

```markdown
---
title: "Q1 Report"
author: "Your Name"
---

# Executive Summary

Revenue grew 23 % quarter-over-quarter.

::: {custom-style="Body Text"}
This paragraph uses your template's exact Body Text style.
:::

| Metric       | Q4 2025 | Q1 2026 |
|:-------------|:-------:|:-------:|
| Revenue ($M) | 12.4    | 15.3    |
| Churn        | 4.1%    | 3.2%    |
```

The `::: {custom-style="..."}` blocks map directly to style names in your template.

---

## Step 4 — Generate the styled document

```bash
edgemint apply-styles report.md styles.json -o report.docx
```

Open `report.docx`. Every heading, font, color, and spacing is **identical** to your template.

---

## Step 5 (optional) — Full extraction with images

If your source DOCX has images and complex content:

```bash
edgemint extract source.docx -o project/
# produces: project/content.md  project/styles.json  project/media/

edgemint apply-styles project/content.md project/styles.json \
  -o rebuilt.docx --media project/media
```

---

## What to do next

- **Name styles correctly** → [Style Guide](style-guide.md)
- **See all commands** → [CLI Reference](cli-reference.md)
- **Use in CI/CD** → [CI/CD Integration](cicd-integration.md)
- **Packt publisher workflow** → [Packt Author Guide](packt-author-guide.md)
