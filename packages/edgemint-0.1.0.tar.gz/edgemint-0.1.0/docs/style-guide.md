# Style Guide — Naming Styles in Markdown

How to annotate your Markdown so edgemint maps it to the right style in your DOCX template.

---

## The mental model

```
┌───────────────────────────────────────────────────────────────┐
│                     edgemint style model                      │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│   Markdown element          →    DOCX style                  │
│   ─────────────────              ──────────                  │
│                                                               │
│   # Heading                 →    Heading 1      (automatic)  │
│   ## Heading                →    Heading 2      (automatic)  │
│   Plain paragraph           →    Normal         (automatic)  │
│   **bold**                  →    Character: Bold (automatic) │
│                                                               │
│   ::: {custom-style="X"}   →    Paragraph style X  (explicit)│
│   [text]{custom-style="Y"} →    Character style Y  (explicit)│
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

**Rule**: use automatic Markdown for standard structure. Use `custom-style` only when your template has a named style beyond the defaults.

---

## Default Markdown → DOCX mapping

These work without any annotation:

```
MARKDOWN                     DOCX STYLE
────────────────────         ──────────────────
# Heading                →  Heading 1
## Heading               →  Heading 2
### Heading              →  Heading 3
#### Heading             →  Heading 4
##### Heading            →  Heading 5
###### Heading           →  Heading 6
Plain paragraph          →  Normal
> Blockquote             →  Block Text
- Bullet list            →  List Bullet
  - Nested bullet        →  List Bullet 2
1. Numbered list         →  List Number
   1. Nested numbered    →  List Number 2
**bold text**            →  Strong (character)
*italic text*            →  Emphasis (character)
`inline code`            →  Verbatim Char (character)
    fenced code block    →  Verbatim
[^1]: footnote           →  Footnote Text
```

---

## Block-level custom styles

Wrap a paragraph (or multiple paragraphs) in a fenced div:

```markdown
::: {custom-style="Executive Summary"}
This paragraph uses the "Executive Summary" style from your template.
:::
```

Multi-paragraph blocks:

```markdown
::: {custom-style="Body Text"}
First paragraph in this style.

Second paragraph in the same style.
:::
```

Nested blocks (inner style takes precedence):

```markdown
::: {custom-style="InfoBox"}
::: {custom-style="InfoBox Title"}
Important Note
:::
All text inside the info box uses InfoBox styling.
:::
```

---

## Inline character styles

Apply a character style to a span of text within a paragraph:

```markdown
The server is [RUNNING]{custom-style="Status Green"} and
[memory usage is normal]{custom-style="Highlight"}.
```

Multiple spans in one paragraph:

```markdown
Press [Ctrl+S]{custom-style="Keyboard"} to save, then
click [File → Export]{custom-style="Menu Path"} to export.
```

---

## Finding your template's style names

```bash
# Step 1: extract the style sheet
edgemint extract-styles template.docx -o styles.json

# Step 2: list all style names
python -c "
import json
data = json.load(open('styles.json'))
for s in data['styles']:
    print(f\"{s['type']:12} {s['name']}\")
" | sort
```

Or use `edgemint info` for a quick count:

```bash
edgemint info template.docx
```

---

## Style name rules

- Use the **`name`** field from `styles.json`, not `style_id`
- Names are **case-sensitive** in the annotation but Word normalises them at apply time
- Spaces are allowed: `"Body Text Indent"`, `"Heading 1"`
- Use the locale-independent English name when working across language versions of Word

---

## Fidelity matrix

What gets preserved — and what doesn't:

```
┌────────────────────────┬───────────┬─────────────────────────────────┐
│  Construct             │  Fidelity │  How                            │
├────────────────────────┼───────────┼─────────────────────────────────┤
│  Paragraph styles      │ LOSSLESS  │  custom-style fenced divs       │
│  Character styles      │ LOSSLESS  │  custom-style bracketed spans   │
│  Bold / italic / code  │ LOSSLESS  │  standard MD syntax             │
│  Footnotes             │ LOSSLESS  │  [^id] syntax                   │
│  Images                │ LOSSLESS  │  ![alt](media/x.png){attrs}     │
│  Simple tables         │ LOSSLESS  │  pipe / grid tables             │
│  Math (LaTeX)          │ LOSSLESS  │  $...$ and $$...$$              │
│  Page breaks           │ LOSSLESS  │  raw openxml block              │
│  Theme / colors        │ LOSSLESS  │  styles.json sidecar            │
│  Numbering defs        │ LOSSLESS  │  styles.json sidecar            │
│  Headers / footers     │ LOSSLESS  │  styles.json sidecar            │
├────────────────────────┼───────────┼─────────────────────────────────┤
│  Merged table cells    │ NEAR      │  raw openxml fallback           │
│  Image float/anchor    │ NEAR      │  raw openxml fallback           │
├────────────────────────┼───────────┼─────────────────────────────────┤
│  Track changes         │ LOST      │  accepted only (not preserved)  │
│  Comments              │ LOST      │  no Markdown representation     │
│  Form fields           │ LOST      │  no Markdown representation     │
│  Macros / VBA          │ LOST      │  stripped (security policy)     │
└────────────────────────┴───────────┴─────────────────────────────────┘
```

---

## Raw OOXML escape hatch

For constructs that Markdown cannot represent, inject raw Office Open XML:

```markdown
Page break:

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

Column break:

```{=openxml}
<w:p><w:r><w:br w:type="column"/></w:r></w:p>
```
```

Use sparingly. Raw OOXML is fragile — prefer standard constructs where possible.

---

## AsciiDoc source

edgemint also accepts AsciiDoc via Pandoc's reader:

```bash
edgemint apply-styles chapter.adoc styles.json -o chapter.docx
```

Style annotations in AsciiDoc use roles:

```asciidoc
[.custom-style#Executive_Summary]
This paragraph uses the "Executive Summary" style.
```

AsciiDoc is recommended for large technical books (better list/table semantics).
Markdown is recommended for reports, articles, and content-first workflows.

---

## Troubleshooting style mapping

**Styles not applying?**

```bash
# Verify the exact style name exists
edgemint extract-styles template.docx -o styles.json
grep '"name"' styles.json | grep -i "my style"
```

**List indentation wrong?**

Known Pandoc issue — the built-in `fix-lists.lua` filter and post-processor
handle this automatically. If it persists, check that you installed correctly:

```bash
edgemint version      # must be ≥ 0.1.0
pip show edgemint     # check installed path
```

**Math equations look different?**

- Standard LaTeX (`$...$`, `$$...$$`) rounds trips losslessly via OMML
- Custom `\newcommand` macros must be expanded before conversion
- `\cancel` and TikZ have no OMML equivalent — rasterise to PNG first
