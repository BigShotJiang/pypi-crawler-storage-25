# CLI Reference

Complete reference for every `edgemint` command, option, and exit code.

---

## Command map

```
edgemint
├── extract-styles   .docx → styles.json          (no Pandoc needed)
├── extract          .docx → content.md + styles.json + media/
├── apply-styles     content.md + styles.json → .docx
├── diff             styles-a.json vs styles-b.json
├── validate         check styles.json schema
├── info             quick .docx summary
├── schema           print JSON Schema for styles.json
└── version          print installed version
```

---

## Exit codes

| Code | Meaning |
|------|---------|
| `0` | Success |
| `1` | Validation error (schema, style) |
| `2` | File error (not found, unreadable) |
| `3` | Schema error |
| `4` | Pandoc error (not installed or conversion failed) |
| `5` | Security error (path traversal blocked) |

---

## `extract-styles`

Extract style definitions from a DOCX template. **No Pandoc required.**

```
edgemint extract-styles INPUT_DOCX [OPTIONS]

Arguments:
  INPUT_DOCX          path to the source .docx file

Options:
  -o, --output PATH   output JSON file  [required]
  --resolved / --no-resolved
                      include fully-resolved inherited properties
                      (walks the based_on chain + theme defaults)
                      default: --resolved
  --filter TYPE       emit only styles of this type:
                      paragraph | character | table | numbering
  --strict / --lenient
                      --strict: abort on unsupported constructs
                      --lenient: emit warnings and continue (default)
```

**Examples:**

```bash
# Basic extraction
edgemint extract-styles brand.docx -o brand.json

# Only paragraph styles, with resolved inheritance
edgemint extract-styles brand.docx -o brand.json --filter paragraph

# Strict mode (fail-fast on non-standard constructs)
edgemint extract-styles brand.docx -o brand.json --strict

# Without resolved properties (smaller JSON, raw definitions only)
edgemint extract-styles brand.docx -o brand.json --no-resolved
```

---

## `extract`

Full document extraction: content + styles + media in one command.

```
edgemint extract INPUT_DOCX [OPTIONS]

Arguments:
  INPUT_DOCX          path to the source .docx file

Options:
  -o, --output PATH   output directory  [required]
  --strict / --lenient
                      same as extract-styles (default: --lenient)
```

**Output structure:**

```
output/
├── content.md        Pandoc Extended Markdown with custom-style attrs
├── styles.json       complete style identity
└── media/            all embedded images and objects
    ├── image1.png
    └── chart2.emf
```

**Examples:**

```bash
edgemint extract report.docx -o project/
edgemint extract report.docx -o project/ --strict
```

---

## `apply-styles`

Generate a styled `.docx` from Markdown (or AsciiDoc) and a style sheet.
**Requires Pandoc** (`pip install edgemint[pandoc]`).

```
edgemint apply-styles CONTENT STYLES_JSON [OPTIONS]

Arguments:
  CONTENT             path to .md or .adoc source file
  STYLES_JSON         path to styles.json

Options:
  -o, --output PATH   output .docx file  [required]
  --media PATH        directory containing images referenced in CONTENT
  --input-format FMT  auto | markdown | asciidoc  (default: auto)
```

**Auto-detection:** the input format is detected from the file extension
(`.md` → markdown, `.adoc` → asciidoc). Use `--input-format` to override.

**Examples:**

```bash
# Markdown → DOCX
edgemint apply-styles content.md styles.json -o output.docx

# With images
edgemint apply-styles content.md styles.json -o output.docx --media ./media

# AsciiDoc source
edgemint apply-styles chapter.adoc styles.json -o chapter.docx

# Explicit format
edgemint apply-styles source.txt styles.json -o out.docx --input-format markdown
```

---

## `diff`

Compare two style sheets and print semantic differences.

```
edgemint diff BEFORE_JSON AFTER_JSON
```

**Output format:**

```
ADDED    StyleID (Style Name)
REMOVED  StyleID (Style Name)
CHANGED  StyleID
  field.path: old_value → new_value
```

**Example:**

```bash
edgemint diff brand-v1.json brand-v2.json

CHANGED  Heading1
  font.size_pt: 16.0 → 18.0
  font.color: #2F5496 → #1A3C6E
ADDED    Subtitle
REMOVED  BodyTextIndent
```

---

## `validate`

Validate a `styles.json` file against the Pydantic schema.

```
edgemint validate STYLES_JSON
```

Exits `0` and prints `Valid` on success. Exits `1` with a full validation
error on failure.

```bash
edgemint validate brand.json     # → Valid
edgemint validate bad.json       # → [validation errors]
```

---

## `info`

Quick inspection of a `.docx` file's style inventory. **No Pandoc required.**

```
edgemint info INPUT_DOCX [--strict/--lenient]
```

**Example output:**

```
Styles: 42
Paragraph: 28
Character: 11
Table: 3
Theme heading font: Calibri Light
Theme body font: Calibri
Sections: 1
Max inheritance depth: 4
```

---

## `schema`

Print the JSON Schema for `styles.json` (useful for IDE auto-completion).

```bash
edgemint schema > edgemint-schema.json
```

Configure your editor to validate `styles.json` against this schema:

```json
{
  "$schema": "./edgemint-schema.json"
}
```

---

## `version`

```bash
edgemint version    # → 0.1.0
```

---

## Pandoc under the hood

When `extract` or `apply-styles` runs, edgemint invokes Pandoc with these
extension sets:

**Extract** (DOCX → Markdown):

```
-f docx+styles
-t markdown+fenced_divs+bracketed_spans+yaml_metadata_block
--wrap=none
--extract-media=<media_dir>
```

**Apply** (Markdown → DOCX):

```
-f markdown+fenced_divs+bracketed_spans+yaml_metadata_block+raw_attribute
-t docx
--reference-doc=<generated_reference.docx>
--lua-filter=filters/fix-lists.lua
--lua-filter=filters/fix-styles.lua
--resource-path=<media_dir>
```

The raw Pandoc output is then post-processed by `python-docx` to:
1. Deduplicate styles (known Pandoc issue)
2. Fix list paragraph styles (Pandoc bug #7280)
3. Re-link heading numbering
4. Inject full style definitions from `styles.json`

---

## Environment & requirements

| Requirement | Version | Notes |
|------------|---------|-------|
| Python | ≥ 3.11 | uses `tomllib` (stdlib) |
| python-docx | ≥ 1.2.0 | style write support |
| pydantic | ≥ 2.8, < 3 | frozen models |
| lxml | ≥ 5.2 | XML manipulation |
| typer | ≥ 0.12, < 1 | CLI framework |
| Pandoc | any recent | only for `extract` / `apply-styles` |
| pypandoc-binary | ≥ 1.15 | optional, bundles Pandoc binary |
