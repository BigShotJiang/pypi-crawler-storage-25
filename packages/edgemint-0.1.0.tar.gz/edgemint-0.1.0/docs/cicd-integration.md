# CI/CD Integration — Automated Document Pipelines

Automate styled DOCX generation in GitHub Actions, GitLab CI, or any
container-based pipeline using the official edgemint Docker image.

---

## The pattern

```
┌─────────────────────────────────────────────────────────────────────┐
│                   Automated Document Pipeline                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   Git repo                                                          │
│   ├── reports/                                                      │
│   │   ├── q1-2026.md          ← your Markdown content              │
│   │   └── q2-2026.md                                                │
│   ├── brand/                                                        │
│   │   └── styles.json         ← committed style identity           │
│   └── media/                                                        │
│       └── logo.png                                                  │
│              │                                                      │
│              │  git push     triggers workflow                       │
│              ▼                                                      │
│   ┌─────────────────────┐                                           │
│   │  edgemint container │  apply-styles q1.md brand/styles.json    │
│   │  (ghcr.io/...)      │  → output/q1-2026.docx                   │
│   └─────────────────────┘                                           │
│              │                                                      │
│              ▼                                                      │
│   GitHub Actions artifact / S3 / SharePoint upload                  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## GitHub Actions — basic pipeline

Generate one report per Markdown file on every push:

```yaml
# .github/workflows/generate-docs.yml
name: Generate Reports

on:
  push:
    paths: ['reports/**.md', 'brand/styles.json']
  workflow_dispatch:

jobs:
  generate:
    runs-on: ubuntu-latest
    container:
      image: ghcr.io/raphaelmansuy/edgemint:latest

    steps:
      - uses: actions/checkout@v4

      - name: Generate all reports
        run: |
          mkdir -p output
          for md in reports/*.md; do
            name=$(basename "$md" .md)
            edgemint apply-styles "$md" brand/styles.json \
              -o "output/${name}.docx" \
              --media media
            echo "  generated output/${name}.docx"
          done

      - name: Upload DOCX artifacts
        uses: actions/upload-artifact@v4
        with:
          name: reports-${{ github.sha }}
          path: output/*.docx
          retention-days: 30
```

---

## GitHub Actions — matrix build

Generate the same content for multiple brand templates (EMEA, APAC, internal):

```yaml
# .github/workflows/multi-brand.yml
name: Multi-Brand Report

on:
  push:
    branches: [main]
    paths: ['reports/**.md']

jobs:
  generate:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        brand:
          - { name: emea,     styles: brand/emea.json     }
          - { name: apac,     styles: brand/apac.json     }
          - { name: internal, styles: brand/internal.json }

    container:
      image: ghcr.io/raphaelmansuy/edgemint:latest

    steps:
      - uses: actions/checkout@v4

      - name: Generate ${{ matrix.brand.name }} report
        run: |
          edgemint apply-styles reports/annual.md \
            ${{ matrix.brand.styles }} \
            -o annual-${{ matrix.brand.name }}.docx \
            --media media

      - uses: actions/upload-artifact@v4
        with:
          name: annual-${{ matrix.brand.name }}
          path: annual-${{ matrix.brand.name }}.docx
```

---

## GitHub Actions — track template changes

Use `edgemint diff` to fail CI when a template changes unexpectedly:

```yaml
# .github/workflows/brand-guard.yml
name: Brand Guard

on:
  pull_request:
    paths: ['brand/**.docx']

jobs:
  guard:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Install edgemint
        run: pip install edgemint

      - name: Extract styles from new template
        run: edgemint extract-styles brand/template.docx -o new.json

      - name: Restore previous styles
        run: git show HEAD~1:brand/styles.json > old.json

      - name: Diff
        run: |
          edgemint diff old.json new.json | tee diff.txt
          if grep -q "CHANGED\|REMOVED" diff.txt; then
            echo "::warning::Template style changes detected — review before merging"
            cat diff.txt
          fi
```

---

## GitLab CI

```yaml
# .gitlab-ci.yml
generate-docs:
  image: ghcr.io/raphaelmansuy/edgemint:latest
  stage: build
  script:
    - mkdir -p output
    - |
      for md in reports/*.md; do
        name=$(basename "$md" .md)
        edgemint apply-styles "$md" brand/styles.json \
          -o "output/${name}.docx" --media media
      done
  artifacts:
    paths:
      - output/*.docx
    expire_in: 1 week
  rules:
    - changes:
        - reports/**/*.md
        - brand/styles.json
```

---

## Docker usage

### Pull the image

```bash
docker pull ghcr.io/raphaelmansuy/edgemint:latest
```

Available tags:

| Tag | Contents |
|-----|---------|
| `latest` | most recent release |
| `0.1.0` | specific version |
| `0.1` | minor series latest |

### Run commands

```bash
# Mount current directory into /work
docker run --rm \
  -v "$PWD:/work" \
  -w /work \
  ghcr.io/raphaelmansuy/edgemint \
  extract-styles template.docx -o styles.json

# Apply styles
docker run --rm \
  -v "$PWD:/work" \
  -w /work \
  ghcr.io/raphaelmansuy/edgemint \
  apply-styles content.md styles.json -o output.docx
```

### Shell alias for convenience

```bash
alias edgemint='docker run --rm -v "$PWD:/work" -w /work ghcr.io/raphaelmansuy/edgemint'
# then use normally:
edgemint extract-styles template.docx -o styles.json
```

---

## Caching in CI

Cache pip installs to speed up workflows:

```yaml
- uses: actions/setup-python@v5
  with:
    python-version: "3.12"
    cache: "pip"

- name: Install edgemint
  run: pip install edgemint[pandoc]
```

Or use the Docker image (no install step needed, fastest):

```yaml
container:
  image: ghcr.io/raphaelmansuy/edgemint:latest
```

---

## Security considerations

- The Docker image runs as a non-root user
- edgemint blocks path traversal attacks (exit code `5`)
- Macros and VBA are stripped during extraction (not executed)
- For sensitive documents, run in an ephemeral container, not a shared runner

---

## Exit codes in CI

Use exit codes to fail pipelines on errors:

```bash
# Strict mode: fail on any unsupported construct
edgemint extract-styles template.docx -o styles.json --strict || exit 1

# Validate before applying
edgemint validate styles.json || { echo "Invalid styles.json"; exit 1; }
edgemint apply-styles content.md styles.json -o output.docx
```

| Exit code | How to handle in CI |
|-----------|-------------------|
| `0` | Success — proceed |
| `1` | Validation error — print `styles.json` and fail |
| `2` | File not found — check paths |
| `4` | Pandoc missing — use `edgemint[pandoc]` or Docker |
| `5` | Security error — audit input paths |
