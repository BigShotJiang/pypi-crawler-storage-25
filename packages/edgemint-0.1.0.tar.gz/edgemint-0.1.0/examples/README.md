# Examples

`examples/packt-style.docx` is a real Packt template used to exercise extraction and regeneration.

Files in this directory:

- `packt-style.docx`: source DOCX template.
- `packt-style.styles.json`: extracted style sheet produced by `edgemint extract-styles`.
- `packt-style.bundle/`: extracted project bundle from `edgemint extract`.
- `packt-style-example.md`: representative Markdown input covering supported objects.
- `packt-style-example.docx`: generated DOCX created from the Markdown example and extracted style sheet.
- `packt-book-chapter.md`: long-form fictive Chapter 1 for a Packt-style Python book.
- `packt-book-chapter.docx`: generated long-form DOCX chapter built from the extracted Packt style sheet.
- `01-transformer.md`: math-heavy transformer chapter using citations, bibliography, figures, code, tables, and footnotes.
- `01-transformer.docx`: generated DOCX proof for the transformer chapter.
- `transformer-references.bib`: bibliography used by the transformer chapter via Pandoc citeproc.
- `packt-style-author-guide.md`: Packt-author tutorial generated from the extracted style catalogue.
- `packt-style-author-guide.docx`: generated tutorial DOCX that exercises the author-addressable Packt styles.
- `packt-style-example-image.png`: small image asset used by the representative example.
- `transformer-attention-map.png`: local figure asset used by the transformer chapter.
- `transformer-layer-stack.png`: local figure asset used by the transformer chapter.
- `transformer-token-geometry.png`: local figure asset used by the transformer chapter.

Rebuild the generated assets with:

```bash
make examples
```
