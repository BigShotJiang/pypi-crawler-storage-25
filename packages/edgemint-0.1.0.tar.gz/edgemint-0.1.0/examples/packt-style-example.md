---
title: "EdgeMint Packt Style Demonstration"
author: "Raphael Mansuy"
---

::: {custom-style="HS - ChapterNumber"}
Chapter 7
:::

::: {custom-style="HS - ChapterTitle"}
Representative Markdown Surface for the Packt Template
:::

::: {custom-style="P0 - Paragraph"}
This document exercises the supported Markdown-to-DOCX surface against the extracted Packt template. It combines native Markdown constructs with Word-native custom styles so the generated output proves both structure and branding.
:::

# Built-In Heading Mapping

::: {custom-style="P1 - Paragraph"}
The built-in heading syntax below uses the template's built-in heading definitions, while the custom-style paragraphs around it show the Packt-specific display styles. Inline runs demonstrate [bold italic emphasis]{custom-style="CS - BoldItalic"}, [inline code]{custom-style="CS - InlineCode"}, [keywords]{custom-style="CS - Keyword"}, [screen text]{custom-style="CS - Screentext"}, H[subscript]{custom-style="CS - Subscript"}, and x[superscript]{custom-style="CS - Superscript"}.
:::

## Styled Paragraph Families

::: {custom-style="P0 - ParagraphCenter"}
Centered body copy uses the Packt paragraph-center style instead of generic alignment-only formatting.
:::

::: {custom-style="C - Citation"}
"A template is only useful when the authoring workflow is deterministic."
:::

::: {custom-style="QS - Quote"}
This quote block uses the dedicated Packt quote paragraph style through the explicit custom-style escape hatch.
:::

::: {custom-style="I - InfoBox"}
Info box content travels through Markdown as regular prose, but the target DOCX gets the dedicated Packt info-box paragraph styling on output.
:::

::: {custom-style="T - TipBox"}
Tip boxes are authored as content, not layout. The stylesheet owns the visual semantics.
:::

## Lists, Notes, and Links

- Bullet list item one using the native Markdown list reader.
- Bullet list item two with a [styled URL run]{custom-style="CS - URL"} rendered inside the paragraph.
- Bullet list item three with a footnote reference.[^packt-note]

1. Numbered list item one.
2. Numbered list item two.
3. Numbered list item three.

The canonical project link is [https://github.com/raphaelmansuy/edgemint](https://github.com/raphaelmansuy/edgemint).

## Code and Console Blocks

::: {custom-style="C0 - CodeBlock"}
def extract_stylesheet(template_path: str) -> dict:
    return {"template": template_path, "mode": "loss-aware"}
:::

::: {custom-style="C1 - ConsoleBlock"}
$ edgemint extract-styles examples/packt-style.docx -o examples/packt-style.styles.json
$ edgemint apply-styles examples/packt-style-example.md examples/packt-style.styles.json -o examples/packt-style-example.docx --media examples
:::

```python
from pathlib import Path

bundle = Path("examples/packt-style.bundle")
print(bundle / "content.md")
```

## Tables and Figures

::: {custom-style="TS - Table"}
| Surface | Markdown Authoring | DOCX Result |
| --- | --- | --- |
| Headings | `#`, `##`, `###` | Built-in branded heading styles |
| Paragraphs | `::: {custom-style="P0 - Paragraph"}` | Packt paragraph family |
| Tables | Pipe tables | Styled Word table |
| Media | Markdown image syntax | Embedded DOCX media |
:::

![Representative example image](packt-style-example-image.png){ width=35% }

::: {custom-style="F0 - FigureCaption"}
Figure 1. A small embedded image proves the media pipeline survives apply-styles.
:::

## Page Transition

::: {.pagebreak}
:::

### After the Forced Break

::: {custom-style="P0 - Paragraph"}
The page-break marker is authored declaratively. The Lua filter rewrites it to raw OOXML so the generated document contains an actual Word page break instead of an approximation.
:::

[^packt-note]: Footnotes survive the Pandoc path and remain visible in the generated DOCX.
