---
title: "Packt Author Guide for EdgeMint Markdown"
author: "Raphael Mansuy"
---

::: {custom-style="HS - ChapterNumber"}
Chapter 2
:::

::: {custom-style="HS - ChapterTitle"}
Using the Packt Style System with Markdown
:::

::: {custom-style="P0 - Paragraph"}
This guide shows a Packt author how to write one source manuscript in Markdown while deliberately steering the final DOCX through the extracted Packt style catalogue. The working rule is simple: write semantic content in Markdown, use custom-style blocks only when the template expects a Word-native semantic surface, and let the template own the presentation layer.
:::

::: {custom-style="P1 - Paragraph"}
The appendix at the end is intentionally exhaustive. It exists to prove that the example document references the full author-addressable style set exposed by the Packt template, not just a curated subset.
:::

This unstyled paragraph intentionally keeps the built-in `Normal` paragraph style active in the proof document.

# Core Authoring Moves

::: {custom-style="I - InfoBox"}
Use built-in Markdown headings for structural hierarchy when the target style is one of the built-in Word heading levels. Use `custom-style` blocks when the template defines a Packt-specific semantic role such as chapter openers, info boxes, or quote blocks.
:::

::: {custom-style="T - TipBox"}
Keep the manuscript readable in plain text. If a collaborator cannot understand the chapter without opening Word, the Markdown source has become too presentation-heavy.
:::

## Recommended Heading Flow

### Heading 3 preview

#### Heading 4 preview

##### Heading 5 preview

###### Heading 6 preview

####### Heading 7 preview

######## Heading 8 preview

######### Heading 9 preview

::: {custom-style="C - Citation"}
"Write once, style deterministically, and review in DOCX only after structure is already correct."
:::

## Inline Character Styles

::: {custom-style="P0 - Paragraph"}
Use inline styles only when the template assigns semantic meaning to the span. Catalogue preview: [Default paragraph font baseline]{custom-style="Default Paragraph Font"}, [Heading 1 Char]{custom-style="Heading 1 Char"}, [Heading 2 Char]{custom-style="Heading 2 Char"}, [Heading 3 Char]{custom-style="Heading 3 Char"}, [Heading 4 Char]{custom-style="Heading 4 Char"}, [Heading 5 Char]{custom-style="Heading 5 Char"}, [Heading 6 Char]{custom-style="Heading 6 Char"}, [Heading 7 Char]{custom-style="Heading 7 Char"}, [Heading 8 Char]{custom-style="Heading 8 Char"}, [Heading 9 Char]{custom-style="Heading 9 Char"}, [Bold italic emphasis]{custom-style="CS - BoldItalic"}, [highlighted code]{custom-style="CS - HighlightedCode"}, [inline_code()]{custom-style="CS - InlineCode"}, [editorial aside]{custom-style="CS - Italic"}, [transformer]{custom-style="CS - Keyword"}, [Run cell]{custom-style="CS - Screentext"}, [subscript]{custom-style="CS - Subscript"}, [superscript]{custom-style="CS - Superscript"}, [https://example.com/packt-workflow]{custom-style="CS - URL"}, [House Heading 1 Char]{custom-style="HS - Heading 1 Char"}, [InfoBox inline emphasis]{custom-style="I - InfoBox Char"}.
:::

## Lists, Code, Tables, and Figures

- Native bullet lists are the easiest path for common procedures.
- Nested bullets prove that list numbering and paragraph styles remain template-owned.
  - Second-level bullets should still read cleanly in plain Markdown.
    - Third-level bullets should remain rare and purposeful.

1. Ordered procedures should stay short.
2. If a step becomes a paragraph, promote it into body copy.
   1. Sub-steps are acceptable when the sequence matters.
   2. But the author should still favor clarity over hierarchy depth.

::: {custom-style="TS - Table"}
| Authoring need | Markdown move | Template-owned result |
| --- | --- | --- |
| Callout box | `::: {custom-style="I - InfoBox"}` | Styled info box paragraph |
| Code listing | `::: {custom-style="C0 - CodeBlock"}` | Packt code block |
| Console session | `::: {custom-style="C1 - ConsoleBlock"}` | Packt console block |
| Figure | Markdown image plus `F0 - FigureCaption` | Consistent figure treatment |
:::

![Packt authoring workflow preview](transformer-attention-map.png){ width=48% }

::: {custom-style="F0 - FigureCaption"}
Preview figure using `transformer-attention-map.png` to validate repeated figure handling under the Packt template.
:::

![Packt authoring workflow preview](transformer-layer-stack.png){ width=48% }

::: {custom-style="F0 - FigureCaption"}
Preview figure using `transformer-layer-stack.png` to validate repeated figure handling under the Packt template.
:::

![Packt authoring workflow preview](transformer-token-geometry.png){ width=48% }

::: {custom-style="F0 - FigureCaption"}
Preview figure using `transformer-token-geometry.png` to validate repeated figure handling under the Packt template.
:::

## Style Catalogue Appendix

::: {custom-style="P0 - Paragraph"}
The following appendix intentionally touches each author-addressable paragraph style in the extracted template. Internal table and numbering defaults are preserved through the package-level round trip, while these samples prove visible style references remain stable.
:::

::: {custom-style="P0 - Paragraph"}
Use the core body style for standard exposition. The safest Packt workflow is to treat layout as template-owned and semantics as author-owned.
:::

::: {custom-style="C - Citation"}
"A production workflow fails first at the seam between intention and repeatability."
:::

::: {custom-style="C0 - CodeBlock"}
def author_contract(section: str) -> str:
    return f"Write for readers first, styles second: {section}"
:::

::: {custom-style="C0 - ConsoleBlock"}
$ edgemint apply-styles manuscript.md packt-style.styles.json -o chapter.docx --media examples
$ make examples
:::

::: {custom-style="C1 - CodeBlock"}
from pathlib import Path

assets = Path("examples")
print(sorted(path.name for path in assets.glob("*.png")))
:::

::: {custom-style="C1 - ConsoleBlock"}
$ python -m venv .venv
$ . .venv/bin/activate
$ pip install -e '.[dev,pandoc]'
:::

::: {custom-style="F0 - Figure"}
Figure placeholders should be authored as ordinary Markdown images. The template owns the visual treatment, not the manuscript.
:::

::: {custom-style="F0 - FigureCaption"}
Figure captions should explain the reader payoff, not merely restate what is visible.
:::

::: {custom-style="L3 - Bullet"}
Level 3 bullet style preview.
:::

::: {custom-style="L3 - Alphabet"}
Level 3 alphabetic list style preview.
:::

::: {custom-style="HS - ChapterNumber"}
Chapter 2
:::

::: {custom-style="HS - ChapterTitle"}
Using the Packt Style System with Markdown
:::

::: {custom-style="HS - Heading 1"}
House Heading 1 preview for direct style coverage.
:::

::: {custom-style="HS - Heading 2"}
House Heading 2 preview for direct style coverage.
:::

::: {custom-style="HS - Heading 3"}
House Heading 3 preview for direct style coverage.
:::

::: {custom-style="HS - Heading 4"}
House Heading 4 preview for direct style coverage.
:::

::: {custom-style="L3 - Numbered"}
Level 3 numbered list style preview.
:::

::: {custom-style="I - InfoBox"}
Info boxes work best when they condense context the reader needs immediately but does not need to memorize.
:::

::: {custom-style="L1 - Bullet"}
Level 1 bullet style preview.
:::

::: {custom-style="L1 - Alphabet"}
Level 1 alphabetic list style preview.
:::

::: {custom-style="L1 - Numbered"}
Level 1 numbered list style preview.
:::

::: {custom-style="L2 - Bullet"}
Level 2 bullet style preview.
:::

::: {custom-style="L2 - Alphabet"}
Level 2 alphabetic list style preview.
:::

::: {custom-style="L2 - Numbered"}
Level 2 numbered list style preview.
:::

::: {custom-style="P0 - ParagraphCenter"}
Use the centered paragraph style sparingly for opening epigraphs, section dividers, or short framing statements.
:::

::: {custom-style="P1 - Paragraph"}
Use the secondary paragraph family when the template expects a tighter or visually distinct explanatory cadence.
:::

::: {custom-style="QS - Quote"}
A strong quote block should carry a full idea. If the text can be merged into body copy without losing force, it probably does not deserve separate styling.
:::

::: {custom-style="T - TipBox"}
Tips should change the author's behavior. A tip that does not alter a concrete decision is only decoration.
:::

::: {custom-style="TS - Table"}
Preview paragraph for `TS - Table`. Use this style only when the template assigns a stable semantic role to the content.
:::

::: {custom-style="TS - TableBullet"}
Table bullet paragraph sample for prose placed inside a styled table cell.
:::

::: {custom-style="TS - TableCenter"}
Centered table paragraph sample for tabular callouts or compact summaries.
:::

::: {custom-style="TS - TableNumberedList"}
Table numbered-list paragraph sample for ordered procedures in cells.
:::
