---
title: "What Is a Transformer in the Context of an LLM?"
author: "Raphael Mansuy"
bibliography: transformer-references.bib
nocite: "@*"
reference-section-title: "References"
---

::: {custom-style="HS - ChapterNumber"}
Chapter 1
:::

::: {custom-style="HS - ChapterTitle"}
What Is a Transformer in the Context of an LLM?
:::

::: {custom-style="P0 - Paragraph"}
In the context of a large language model, a transformer is a sequence model whose central operation is learned attention over token representations. It replaces the recurrent bottleneck of earlier NLP systems with a layered architecture that can compare each token against every other token in context, transform those comparisons into weighted mixtures, and then refine the result through residual computation blocks. The practical consequence is not merely better parallelism. The deeper consequence is that the model can build a hierarchy of contextual features while keeping the optimization surface reasonably uniform across depth [@vaswani2017attention; @brown2020language].
:::

::: {custom-style="P1 - Paragraph"}
An LLM is therefore not one giant lookup table and not one monolithic formula. It is a stack of embedding layers, attention layers, feed-forward layers, normalization steps, positional schemes, and output projection machinery trained to minimize next-token prediction loss over a vast corpus. This chapter explains that stack with enough mathematical detail to test the Markdown-to-DOCX pipeline under pressure, not merely to tell a high-level story.
:::

::: {custom-style="I - InfoBox"}
When authors explain transformers to practitioners, the usual failure mode is abstraction without mechanism. The reader hears that "attention lets the model focus" but never sees the algebra that makes the statement true.
:::

# From Tokens to Vectors

::: {custom-style="P0 - Paragraph"}
The first practical step in an LLM is tokenization. Raw text is segmented into discrete units such as subwords or byte-pair merges. If the token vocabulary has size $V$ and the hidden width is $d$, the embedding matrix is
:::

$$
E \in \mathbb{R}^{V \times d}.
$$

::: {custom-style="P0 - Paragraph"}
Given a token index sequence $(t_1, t_2, \dots, t_n)$, the model forms an embedding sequence
:::

$$
x_i = E[t_i] \in \mathbb{R}^{d}, \qquad X = \begin{bmatrix} x_1 \\ x_2 \\ \vdots \\ x_n \end{bmatrix} \in \mathbb{R}^{n \times d}.
$$

::: {custom-style="P0 - ParagraphCenter"}
Tokens become vectors before they become meaning.
:::

::: {custom-style="QS - Quote"}
An embedding is not a definition. It is a trainable coordinate system that makes future computation convenient.
:::

## Positional Information

::: {custom-style="P0 - Paragraph"}
Because self-attention alone is permutation-invariant, the model must inject positional structure. The original transformer used sinusoidal encodings [@vaswani2017attention]:
:::

$$
\mathrm{PE}_{(pos, 2i)} = \sin\left(\frac{pos}{10000^{2i/d}}\right), \qquad
\mathrm{PE}_{(pos, 2i+1)} = \cos\left(\frac{pos}{10000^{2i/d}}\right).
$$

::: {custom-style="P0 - Paragraph"}
Modern LLMs often prefer rotary position embeddings (RoPE), which rotate query and key pairs in two-dimensional subspaces [@su2024roformer]:
:::

$$
\operatorname{RoPE}(x_m, m) =
\begin{bmatrix}
\cos(m\theta_1) & -\sin(m\theta_1) & & \\
\sin(m\theta_1) & \cos(m\theta_1) & & \\
& & \ddots & \\
& & & \cos(m\theta_{d/2}) \\
\end{bmatrix}
x_m.
$$

::: {custom-style="T - TipBox"}
If a chapter introduces RoPE, explain the reason before the formula: it preserves relative phase information inside dot products, which is why attention can remain sensitive to order without explicit absolute-position features at every layer.
:::

## A Figure for the Authoring Pipeline

![Transformer context window sketch](transformer-attention-map.png){ width=52% }

::: {custom-style="F0 - FigureCaption"}
Figure 1. A repeated local image is sufficient to prove that the DOCX media relationship graph survives a heavier manuscript.
:::

# Self-Attention as the Core Operation

::: {custom-style="P0 - Paragraph"}
For one attention head, the layer projects the hidden states into queries, keys, and values:
:::

$$
Q = XW_Q, \qquad K = XW_K, \qquad V = XW_V,
$$

$$
W_Q, W_K \in \mathbb{R}^{d \times d_k}, \qquad W_V \in \mathbb{R}^{d \times d_v}.
$$

::: {custom-style="P0 - Paragraph"}
The unnormalized compatibility score between token $i$ and token $j$ is the scaled dot product
:::

$$
s_{ij} = \frac{q_i k_j^\top}{\sqrt{d_k}}.
$$

::: {custom-style="P0 - Paragraph"}
Collecting all scores yields the attention matrix
:::

$$
S = \frac{QK^\top}{\sqrt{d_k}} \in \mathbb{R}^{n \times n}.
$$

::: {custom-style="P0 - Paragraph"}
For autoregressive language modeling, the matrix is masked so that token $i$ cannot attend to future positions:
:::

$$
\tilde{S}_{ij} =
\begin{cases}
S_{ij}, & j \le i, \\
-\infty, & j > i.
\end{cases}
$$

::: {custom-style="P0 - Paragraph"}
Applying the row-wise softmax produces attention weights
:::

$$
A = \operatorname{softmax}(\tilde{S}),
\qquad
A_{ij} = \frac{e^{\tilde{S}_{ij}}}{\sum_{k=1}^{n} e^{\tilde{S}_{ik}}}.
$$

::: {custom-style="P1 - Paragraph"}
The output of the head is then the weighted mixture of value vectors:
:::

$$
H = AV.
$$

::: {custom-style="C - Citation"}
"Attention is useful because it creates data-dependent routing, not because the word attention sounds cognitively plausible."
:::

### Why the Softmax Matters

::: {custom-style="P0 - Paragraph"}
The softmax is the normalization that turns arbitrary compatibility scores into a probability simplex. Each row of $A$ sums to one:
:::

$$
\sum_{j=1}^{n} A_{ij} = 1.
$$

::: {custom-style="P0 - Paragraph"}
That makes attention interpretable as a convex combination over value vectors. The row output
:::

$$
h_i = \sum_{j=1}^{n} A_{ij} v_j
$$

::: {custom-style="P0 - Paragraph"}
lies in the span of the values and can therefore be read as the model's context-aware rewrite of token $i$.[^convex]
:::

[^convex]: The output is convex only because the weights are non-negative and sum to one after masking and softmax.

## Multi-Head Attention

::: {custom-style="P0 - Paragraph"}
One head is too restrictive because it forces every dependency pattern through the same projection subspace. Multi-head attention introduces $h$ distinct learned projections:
:::

$$
\operatorname{head}_r(X) = \operatorname{Attention}(XW_Q^{(r)}, XW_K^{(r)}, XW_V^{(r)}).
$$

$$
\operatorname{MHA}(X) =
\operatorname{Concat}\left(\operatorname{head}_1(X), \dots, \operatorname{head}_h(X)\right) W_O.
$$

::: {custom-style="P0 - Paragraph"}
If each head uses width $d_h = d / h$, then concatenation returns to the original hidden width $d$. This is one reason the transformer scales cleanly in engineering practice: the architecture keeps the residual stream width stable even while specialization emerges inside the head decomposition [@dao2022flashattention].
:::

![Multi-head attention sketch](transformer-layer-stack.png){ width=52% }

::: {custom-style="F0 - FigureCaption"}
Figure 2. Repeated figure handling is as important for publishing pipelines as the mathematical exposition itself.
:::

# Residual Blocks and Layer Normalization

::: {custom-style="P0 - Paragraph"}
A modern decoder block is usually written in pre-normalization form:
:::

$$
Y^{(\ell)} = X^{(\ell)} + \operatorname{MHA}\left(\operatorname{LN}(X^{(\ell)})\right),
$$

$$
X^{(\ell+1)} = Y^{(\ell)} + \operatorname{MLP}\left(\operatorname{LN}(Y^{(\ell)})\right).
$$

::: {custom-style="P0 - Paragraph"}
Layer normalization stabilizes the feature distribution per token:
:::

$$
\operatorname{LN}(x) = \gamma \odot \frac{x - \mu(x)}{\sqrt{\sigma^2(x) + \epsilon}} + \beta.
$$

::: {custom-style="P1 - Paragraph"}
Residual connections matter just as much. Without them, deep optimization becomes fragile because each layer would need to relearn the identity transform whenever the useful update is small. With residuals, the model can treat new computation as a correction rather than a replacement.
:::

## The Feed-Forward Network

::: {custom-style="P0 - Paragraph"}
The position-wise feed-forward or MLP sublayer expands and contracts the hidden width:
:::

$$
\operatorname{MLP}(x) = W_2 \, \phi(W_1 x + b_1) + b_2,
$$

$$
W_1 \in \mathbb{R}^{d_{\text{ff}} \times d}, \qquad
W_2 \in \mathbb{R}^{d \times d_{\text{ff}}}.
$$

::: {custom-style="P0 - Paragraph"}
In LLMs, the activation is often GELU or SwiGLU:
:::

$$
\operatorname{GELU}(x) = x \Phi(x),
\qquad
\operatorname{SwiGLU}(x) = (xW_a) \odot \sigma(xW_b).
$$

::: {custom-style="I - InfoBox"}
Authors should tell readers that the MLP is not a secondary detail. Attention mixes information across tokens, but the feed-forward network is where much of the nonlinear feature transformation happens inside each token position.
:::

# Training Objective

::: {custom-style="P0 - Paragraph"}
For causal language modeling, the objective is next-token prediction. Given prefix tokens $t_{\le i}$, the model produces logits
:::

$$
z_i = h_i W_U + b_U,
$$

::: {custom-style="P0 - Paragraph"}
and probabilities
:::

$$
p_\theta(t_{i+1} = v \mid t_{\le i}) =
\frac{\exp(z_{i,v})}{\sum_{u=1}^{V} \exp(z_{i,u})}.
$$

::: {custom-style="P0 - Paragraph"}
The negative log-likelihood over a dataset $\mathcal{D}$ is
:::

$$
\mathcal{L}(\theta) =
- \sum_{(t_1,\dots,t_m)\in\mathcal{D}} \sum_{i=1}^{m-1}
\log p_\theta(t_{i+1} \mid t_{\le i}).
$$

::: {custom-style="P0 - Paragraph"}
Perplexity is the exponential of mean token loss:
:::

$$
\operatorname{PPL} = \exp\left(\frac{\mathcal{L}}{N}\right).
$$

::: {custom-style="TS - Table"}
| Quantity | Meaning in an LLM | Typical engineering tradeoff |
| --- | --- | --- |
| $d$ | Residual stream width | Higher width raises capacity and cost |
| $h$ | Number of heads | More heads increase routing flexibility |
| $n$ | Context length | Longer context increases memory pressure |
| $d_{\text{ff}}$ | MLP expansion width | Larger MLP boosts nonlinear capacity |
| $V$ | Vocabulary size | Larger vocab changes embedding and output costs |
:::

## Why Context Length Hurts

::: {custom-style="P0 - Paragraph"}
The classical attention cost scales quadratically in sequence length:
:::

$$
\operatorname{cost}_{\text{attn}} = O(n^2 d).
$$

::: {custom-style="P0 - Paragraph"}
The memory pressure from storing the score or attention matrix is likewise quadratic in $n$:
:::

$$
\operatorname{memory}_{\text{scores}} = O(n^2).
$$

::: {custom-style="P1 - Paragraph"}
This is why long-context research matters. A model with excellent linguistic ability but poor long-context efficiency becomes expensive or impossible to deploy at the window sizes modern applications demand [@bai2023long].
:::

![Long-context pressure sketch](transformer-token-geometry.png){ width=52% }

::: {custom-style="F0 - FigureCaption"}
Figure 3. A third figure keeps the image and caption path active while the manuscript grows in complexity.
:::

## Practical Decoder Stack

::: {custom-style="TS - Table"} 
| Stage | Representative formula | Reader takeaway |
| --- | --- | --- |
| Embedding | $x_i = E[t_i]$ | Tokens enter as vectors |
| Position | $x_i + p_i$ or RoPE | Order enters the model |
| Attention | $A = \operatorname{softmax}(QK^\top/\sqrt{d_k})$ | Tokens route information |
| MLP | $W_2\phi(W_1x)$ | Features are transformed locally |
| Output | $z_i = h_iW_U + b_U$ | The model predicts the next token |
:::

# What Makes This a Large Language Model?

::: {custom-style="P0 - Paragraph"}
The transformer becomes an LLM when scale changes the operating regime. Parameter count, token count, optimization budget, and context length all move far enough that the model learns broad reusable abstractions rather than narrow task heuristics [@kaplan2020scaling]. A simplified scaling-law relationship is often written as
:::

$$
L(N, D, C) \approx L_\infty + aN^{-\alpha} + bD^{-\beta} + cC^{-\gamma},
$$

::: {custom-style="P0 - Paragraph"}
where $N$ is parameter count, $D$ is dataset size, and $C$ is compute. The exact coefficients are empirical, but the lesson is practical: performance is constrained by coordinated scale, not by one number in isolation.
:::

::: {custom-style="C0 - CodeBlock"}
def scaled_dot_product_attention(q, k, v, mask):
    scores = (q @ k.transpose(-1, -2)) / (q.shape[-1] ** 0.5)
    scores = scores.masked_fill(~mask, float("-inf"))
    weights = scores.softmax(dim=-1)
    return weights @ v
:::

::: {custom-style="C1 - ConsoleBlock"}
$ python -m torch.distributed.run --nproc_per_node=8 train.py --model decoder-xl
$ python evaluate.py --checkpoint ckpt.pt --tasks ppl long_context reasoning
:::

## Reading the Model as a Computation Graph

::: {custom-style="P0 - Paragraph"}
At inference time, the decoder repeatedly executes the same conceptual loop:
:::

1. Embed the current prefix.
2. Apply causal attention and MLP blocks layer by layer.
3. Produce logits for the next token.
4. Sample or select the next token.
5. Append it to the prefix and continue.

::: {custom-style="P0 - Paragraph"}
If the generation policy is temperature-scaled sampling, the probabilities become
:::

$$
p_T(v) = \frac{\exp(z_v/T)}{\sum_{u=1}^{V} \exp(z_u/T)}.
$$

::: {custom-style="P0 - Paragraph"}
Top-$k$ and nucleus sampling then prune or reweight the distribution:
:::

$$
\mathcal{V}_k = \operatorname{arg\,topk}(z, k),
\qquad
\mathcal{V}_p = \min \left\{ S \subseteq \mathcal{V} : \sum_{v \in S} p(v) \ge p \right\}.
$$

::: {custom-style="T - TipBox"}
If your audience is engineering-focused, always separate the model definition from the decoding policy. The transformer defines the conditional distribution. Sampling defines how you traverse it.
:::

### Failure Modes Worth Explaining

::: {custom-style="P1 - Paragraph"}
A strong chapter should also name the limits: quadratic attention cost, sensitivity to data quality, hallucination under weak retrieval or grounding, and brittle numerical behavior at scale without careful optimization. These are not footnotes. They are part of what a transformer is in production.
:::

## A Final Equation Chain

::: {custom-style="P0 - Paragraph"}
Putting the decoder together for layer $\ell$:
:::

$$
X_0 = \operatorname{Embed}(t_{1:n}),
$$

$$
\hat{X}_\ell = X_\ell + \operatorname{MHA}(\operatorname{LN}(X_\ell)),
$$

$$
X_{\ell+1} = \hat{X}_\ell + \operatorname{MLP}(\operatorname{LN}(\hat{X}_\ell)),
$$

$$
z_n = X_L[n] W_U + b_U,
\qquad
t_{n+1} \sim \pi(z_n).
$$

::: {custom-style="P0 - Paragraph"}
That chain is the core of an autoregressive LLM. Everything else, from caching to quantization to alignment tuning, is engineering around this backbone rather than a replacement for it.
:::

![Decoder summary sketch](transformer-attention-map.png){ width=52% }

::: {custom-style="F0 - FigureCaption"}
Figure 4. A fourth figure keeps the package-level media preservation path active late in the document.
:::

## Conclusion

::: {custom-style="P0 - Paragraph"}
In the context of an LLM, a transformer is a stack of differentiable routing and feature-transformation blocks trained to model the conditional distribution of the next token over long text sequences. Attention explains how the model mixes context, the MLP explains how it transforms features, residuals and normalization explain how it trains deeply, and large-scale optimization explains why it becomes useful beyond toy settings. That is the mechanical story behind the term.
:::
