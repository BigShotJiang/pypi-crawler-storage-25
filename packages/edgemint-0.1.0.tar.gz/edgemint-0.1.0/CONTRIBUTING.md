# Contributing to edgemint

Thank you for investing your time. Every bug report, doc fix, and PR matters.

---

## Quick start for contributors

```bash
git clone https://github.com/raphaelmansuy/edgemint
cd edgemint
make bootstrap    # creates .venv, installs all dev + pandoc deps
make doctor       # verify toolchain is working
make test         # must pass at 100% coverage
```

---

## Development workflow

```
bootstrap → fmt → lint → test → build
```

| Command | What it does |
|---------|-------------|
| `make bootstrap` | Create / update `.venv` with all deps |
| `make doctor` | Check Python, edgemint, Pandoc, ruff versions |
| `make fmt` | Auto-format with ruff |
| `make lint` | Static checks (ruff check + format --check) |
| `make test` | Full test suite, 100% coverage enforced |
| `make test-unit` | Unit tests only (faster) |
| `make test-e2e` | CLI + golden round-trip tests |
| `make build` | Build wheel + sdist into `dist/` |

---

## Before opening a PR

1. **All tests must pass at 100% coverage** — `make test`
2. **Lint must be clean** — `make lint`
3. **Format must be applied** — `make fmt`
4. Keep commits focused: one logical change per commit
5. Write a clear PR description explaining *why*, not just *what*

```bash
make fmt && make lint && make test
# all green? open the PR
```

---

## Project structure

```
src/edgemint/
├── cli.py           Typer commands — entry point for all user-facing commands
├── apply.py         apply-styles pipeline (Pandas → DOCX post-processing)
├── diffing.py       style diff engine
├── errors.py        EdgemintError hierarchy + exit codes
├── jsonio.py        JSON serialisation / deserialisation
├── markdown.py      Markdown helpers
├── ooxml.py         python-docx XML manipulation utilities
├── pandoc.py        Pandoc subprocess wrapper + version detection
├── extract/
│   ├── document.py  extract-styles + extract bundle commands
│   ├── resolver.py  based_on chain + theme resolution
│   └── security.py  path traversal guard
└── schema/
    ├── models.py    Pydantic models (the authoritative schema)
    └── validators.py cross-model validation
```

---

## Adding a new command

1. Add a new `@app.command("name")` function in `src/edgemint/cli.py`
2. Add unit tests in `tests/test_cli_branches.py` and/or `tests/test_cli_e2e.py`
3. Document it in `docs/cli-reference.md`
4. Run `make test` — 100% coverage is enforced, the new code must be covered

---

## Updating the schema

The Pydantic models in `src/edgemint/schema/models.py` are the source of truth.
If you add or change a field:

1. Update `models.py`
2. Update `validators.py` if cross-field validation is needed
3. Update `docs/architecture.md` (the model hierarchy section)
4. Run `make golden` to regenerate the expected golden snapshots
5. Run `make test` — all golden tests must pass

---

## Golden tests

Golden tests compare full extraction output against committed expected JSON:

```bash
make fixtures-download   # download the committed golden .docx fixtures
make golden              # rebuild the expected JSON snapshots
make test-e2e            # run the comparison
```

If you change extraction behaviour intentionally, regenerate the golden files
with `make golden`, review the diff, then commit the new expected files.

---

## Reporting bugs

Please include:
- edgemint version: `edgemint version`
- Python version: `python --version`
- Pandoc version (if relevant): `pandoc --version`
- Minimal reproduction command
- Full error output

---

## Code style

- **Formatter**: ruff (configured in `pyproject.toml`)
- **Linter**: ruff with `E, F, I, B, UP` rules
- **Line length**: 100 characters
- **Target**: Python 3.11+
- **Types**: type annotations on all public functions
- **Docstrings**: module-level and class-level only; avoid redundant function docstrings

Run `make fmt && make lint` before every commit.

---

## Release process

Releases are made by maintainers. See [docs/release-process.md](docs/release-process.md)
for the full checklist.

---

## License

By contributing you agree that your contributions will be licensed under the
[Apache 2.0 License](LICENSE).
