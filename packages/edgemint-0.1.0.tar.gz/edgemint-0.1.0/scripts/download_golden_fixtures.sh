#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FIXTURES_DIR="$ROOT_DIR/tests/golden/fixtures"

mkdir -p "$FIXTURES_DIR"/block_quotes "$FIXTURES_DIR"/char_styles "$FIXTURES_DIR"/unicode "$FIXTURES_DIR"/having_images
mkdir -p \
  "$FIXTURES_DIR"/codeblock \
  "$FIXTURES_DIR"/lists \
  "$FIXTURES_DIR"/notes \
  "$FIXTURES_DIR"/tables \
  "$FIXTURES_DIR"/headers \
  "$FIXTURES_DIR"/track_changes_insertion

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/block_quotes.docx" \
  -o "$FIXTURES_DIR/block_quotes/source.docx"

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/char_styles.docx" \
  -o "$FIXTURES_DIR/char_styles/source.docx"

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/unicode.docx" \
  -o "$FIXTURES_DIR/unicode/source.docx"

curl -L \
  "https://raw.githubusercontent.com/python-openxml/python-docx/master/tests/test_files/having-images.docx" \
  -o "$FIXTURES_DIR/having_images/source.docx"

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/codeblock.docx" \
  -o "$FIXTURES_DIR/codeblock/source.docx"

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/lists.docx" \
  -o "$FIXTURES_DIR/lists/source.docx"

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/notes.docx" \
  -o "$FIXTURES_DIR/notes/source.docx"

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/tables.docx" \
  -o "$FIXTURES_DIR/tables/source.docx"

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/headers.docx" \
  -o "$FIXTURES_DIR/headers/source.docx"

curl -L \
  "https://raw.githubusercontent.com/jgm/pandoc/main/test/docx/track_changes_insertion.docx" \
  -o "$FIXTURES_DIR/track_changes_insertion/source.docx"
