"""Build a Packt-author tutorial that exercises the extracted style catalogue.

WHY: the Packt template is the contract, not an aspirational screenshot. This
generator reads the extracted `styles.json` and emits a deterministic Markdown
guide that references every author-addressable paragraph and character style so
the example DOCX can be used as a style-coverage proof document.
"""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES_DIR = ROOT / "examples"
STYLES_PATH = EXAMPLES_DIR / "packt-style.styles.json"
OUTPUT_PATH = EXAMPLES_DIR / "packt-style-author-guide.md"

IMAGE_NAMES = [
    "transformer-attention-map.png",
    "transformer-layer-stack.png",
    "transformer-token-geometry.png",
]

PARAGRAPH_STYLE_TEXT = {
    "P0 - Paragraph": (
        "Use the core body style for standard exposition. The safest Packt workflow is to treat "
        "layout as template-owned and semantics as author-owned."
    ),
    "P0 - ParagraphCenter": (
        "Use the centered paragraph style sparingly for opening epigraphs, section dividers, or "
        "short framing statements."
    ),
    "P1 - Paragraph": (
        "Use the secondary paragraph family when the template expects a tighter or visually "
        "distinct explanatory cadence."
    ),
    "C - Citation": (
        '"A production workflow fails first at the seam between intention and repeatability."'
    ),
    "C0 - CodeBlock": (
        "def author_contract(section: str) -> str:\n"
        '    return f"Write for readers first, styles second: {section}"'
    ),
    "C0 - ConsoleBlock": (
        "$ edgemint apply-styles manuscript.md packt-style.styles.json -o chapter.docx --media examples\n"
        "$ make examples"
    ),
    "C1 - CodeBlock": (
        "from pathlib import Path\n\n"
        'assets = Path("examples")\n'
        'print(sorted(path.name for path in assets.glob("*.png")))'
    ),
    "C1 - ConsoleBlock": (
        "$ python -m venv .venv\n$ . .venv/bin/activate\n$ pip install -e '.[dev,pandoc]'"
    ),
    "F0 - Figure": (
        "Figure placeholders should be authored as ordinary Markdown images. The template owns the "
        "visual treatment, not the manuscript."
    ),
    "F0 - FigureCaption": (
        "Figure captions should explain the reader payoff, not merely restate what is visible."
    ),
    "HS - ChapterNumber": "Chapter 2",
    "HS - ChapterTitle": "Using the Packt Style System with Markdown",
    "HS - Heading 1": "House Heading 1 preview for direct style coverage.",
    "HS - Heading 2": "House Heading 2 preview for direct style coverage.",
    "HS - Heading 3": "House Heading 3 preview for direct style coverage.",
    "HS - Heading 4": "House Heading 4 preview for direct style coverage.",
    "I - InfoBox": (
        "Info boxes work best when they condense context the reader needs immediately but does not "
        "need to memorize."
    ),
    "L1 - Bullet": "Level 1 bullet style preview.",
    "L1 - Alphabet": "Level 1 alphabetic list style preview.",
    "L1 - Numbered": "Level 1 numbered list style preview.",
    "L2 - Bullet": "Level 2 bullet style preview.",
    "L2 - Alphabet": "Level 2 alphabetic list style preview.",
    "L2 - Numbered": "Level 2 numbered list style preview.",
    "L3 - Bullet": "Level 3 bullet style preview.",
    "L3 - Alphabet": "Level 3 alphabetic list style preview.",
    "L3 - Numbered": "Level 3 numbered list style preview.",
    "QS - Quote": (
        "A strong quote block should carry a full idea. If the text can be merged into body copy "
        "without losing force, it probably does not deserve separate styling."
    ),
    "T - TipBox": (
        "Tips should change the author's behavior. A tip that does not alter a concrete decision is "
        "only decoration."
    ),
    "TS - TableBullet": "Table bullet paragraph sample for prose placed inside a styled table cell.",
    "TS - TableCenter": "Centered table paragraph sample for tabular callouts or compact summaries.",
    "TS - TableNumberedList": "Table numbered-list paragraph sample for ordered procedures in cells.",
}

CHARACTER_STYLE_TEXT = {
    "Default Paragraph Font": "Default paragraph font baseline",
    "Heading 1 Char": "Heading 1 Char",
    "Heading 2 Char": "Heading 2 Char",
    "Heading 3 Char": "Heading 3 Char",
    "Heading 4 Char": "Heading 4 Char",
    "Heading 5 Char": "Heading 5 Char",
    "Heading 6 Char": "Heading 6 Char",
    "Heading 7 Char": "Heading 7 Char",
    "Heading 8 Char": "Heading 8 Char",
    "Heading 9 Char": "Heading 9 Char",
    "CS - BoldItalic": "Bold italic emphasis",
    "CS - HighlightedCode": "highlighted code",
    "CS - InlineCode": "inline_code()",
    "CS - Italic": "editorial aside",
    "CS - Keyword": "transformer",
    "CS - Screentext": "Run cell",
    "CS - Subscript": "subscript",
    "CS - Superscript": "superscript",
    "CS - URL": "https://example.com/packt-workflow",
    "HS - Heading 1 Char": "House Heading 1 Char",
    "I - InfoBox Char": "InfoBox inline emphasis",
}


def main() -> None:
    """Write the deterministic Packt author guide to `examples/`."""
    styles = json.loads(STYLES_PATH.read_text(encoding="utf-8"))["styles"]
    paragraph_styles = [style for style in styles if style["type"] == "paragraph"]
    character_styles = [style for style in styles if style["type"] == "character"]

    lines: list[str] = [
        "---",
        'title: "Packt Author Guide for EdgeMint Markdown"',
        'author: "Raphael Mansuy"',
        "---",
        "",
        '::: {custom-style="HS - ChapterNumber"}',
        "Chapter 2",
        ":::",
        "",
        '::: {custom-style="HS - ChapterTitle"}',
        "Using the Packt Style System with Markdown",
        ":::",
        "",
        '::: {custom-style="P0 - Paragraph"}',
        "This guide shows a Packt author how to write one source manuscript in Markdown while "
        "deliberately steering the final DOCX through the extracted Packt style catalogue. The "
        "working rule is simple: write semantic content in Markdown, use custom-style blocks only "
        "when the template expects a Word-native semantic surface, and let the template own the "
        "presentation layer.",
        ":::",
        "",
        '::: {custom-style="P1 - Paragraph"}',
        "The appendix at the end is intentionally exhaustive. It exists to prove that the example "
        "document references the full author-addressable style set exposed by the Packt template, "
        "not just a curated subset.",
        ":::",
        "",
        "This unstyled paragraph intentionally keeps the built-in `Normal` paragraph style active in "
        "the proof document.",
        "",
        "# Core Authoring Moves",
        "",
        '::: {custom-style="I - InfoBox"}',
        "Use built-in Markdown headings for structural hierarchy when the target style is one of the "
        "built-in Word heading levels. Use `custom-style` blocks when the template defines a Packt-"
        "specific semantic role such as chapter openers, info boxes, or quote blocks.",
        ":::",
        "",
        '::: {custom-style="T - TipBox"}',
        "Keep the manuscript readable in plain text. If a collaborator cannot understand the chapter "
        "without opening Word, the Markdown source has become too presentation-heavy.",
        ":::",
        "",
        "## Recommended Heading Flow",
        "",
        "### Heading 3 preview",
        "",
        "#### Heading 4 preview",
        "",
        "##### Heading 5 preview",
        "",
        "###### Heading 6 preview",
        "",
        "####### Heading 7 preview",
        "",
        "######## Heading 8 preview",
        "",
        "######### Heading 9 preview",
        "",
        '::: {custom-style="C - Citation"}',
        '"Write once, style deterministically, and review in DOCX only after structure is already '
        'correct."',
        ":::",
        "",
        "## Inline Character Styles",
        "",
        '::: {custom-style="P0 - Paragraph"}',
        _character_style_sentence(character_styles),
        ":::",
        "",
        "## Lists, Code, Tables, and Figures",
        "",
        "- Native bullet lists are the easiest path for common procedures.",
        "- Nested bullets prove that list numbering and paragraph styles remain template-owned.",
        "  - Second-level bullets should still read cleanly in plain Markdown.",
        "    - Third-level bullets should remain rare and purposeful.",
        "",
        "1. Ordered procedures should stay short.",
        "2. If a step becomes a paragraph, promote it into body copy.",
        "   1. Sub-steps are acceptable when the sequence matters.",
        "   2. But the author should still favor clarity over hierarchy depth.",
        "",
        '::: {custom-style="TS - Table"}',
        "| Authoring need | Markdown move | Template-owned result |",
        "| --- | --- | --- |",
        '| Callout box | `::: {custom-style="I - InfoBox"}` | Styled info box paragraph |',
        '| Code listing | `::: {custom-style="C0 - CodeBlock"}` | Packt code block |',
        '| Console session | `::: {custom-style="C1 - ConsoleBlock"}` | Packt console block |',
        "| Figure | Markdown image plus `F0 - FigureCaption` | Consistent figure treatment |",
        ":::",
        "",
    ]

    for image_name in IMAGE_NAMES:
        lines.extend(
            [
                f"![Packt authoring workflow preview]({image_name}){{ width=48% }}",
                "",
                '::: {custom-style="F0 - FigureCaption"}',
                f"Preview figure using `{image_name}` to validate repeated figure handling under the Packt template.",
                ":::",
                "",
            ]
        )

    lines.extend(
        [
            "## Style Catalogue Appendix",
            "",
            '::: {custom-style="P0 - Paragraph"}',
            "The following appendix intentionally touches each author-addressable paragraph style in "
            "the extracted template. Internal table and numbering defaults are preserved through the "
            "package-level round trip, while these samples prove visible style references remain stable.",
            ":::",
            "",
        ]
    )

    for style in paragraph_styles:
        if style["name"] in {"Normal", "heading 1", "heading 2", "heading 3"}:
            continue
        if style["name"] == "heading 4":
            continue
        if style["name"] == "heading 5":
            continue
        if style["name"] == "heading 6":
            continue
        if style["name"] == "heading 7":
            continue
        if style["name"] == "heading 8":
            continue
        if style["name"] == "heading 9":
            continue
        if style["name"] == "Normal":
            continue
        lines.extend(_paragraph_block(style["name"], PARAGRAPH_STYLE_TEXT.get(style["name"])))

    OUTPUT_PATH.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def _character_style_sentence(character_styles: list[dict[str, str]]) -> str:
    """Return one paragraph that references every character style once."""
    segments = []
    for style in character_styles:
        label = CHARACTER_STYLE_TEXT.get(style["name"], style["name"])
        segments.append(f'[{label}]{{custom-style="{style["name"]}"}}')
    return (
        "Use inline styles only when the template assigns semantic meaning to the span. "
        "Catalogue preview: " + ", ".join(segments) + "."
    )


def _paragraph_block(style_name: str, sample_text: str | None) -> list[str]:
    """Return one fenced custom-style block for a paragraph style preview."""
    text = sample_text or (
        f"Preview paragraph for `{style_name}`. Use this style only when the template assigns a "
        "stable semantic role to the content."
    )
    return [f'::: {{custom-style="{style_name}"}}', text, ":::", ""]


if __name__ == "__main__":
    main()
