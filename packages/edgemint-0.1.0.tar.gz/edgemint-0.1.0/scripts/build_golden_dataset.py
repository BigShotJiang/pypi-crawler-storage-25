#!/usr/bin/env python3
"""Refresh committed golden fixtures from source DOCX files.

Dataset layout:
    tests/golden/fixtures/<name>/source.docx
    tests/golden/expected/<name>/
        styles.json
        content.md
        content.adoc
        media/
        summary.json
        apply_snapshot.json
        apply_snapshot_adoc.json
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from zipfile import ZipFile

from docx import Document

from edgemint.apply import SourceFormat, apply_stylesheet
from edgemint.extract.document import extract_document_bundle

ROOT = Path(__file__).resolve().parents[1]
FIXTURES_DIR = ROOT / "tests" / "golden" / "fixtures"
EXPECTED_DIR = ROOT / "tests" / "golden" / "expected"


def main() -> None:
    EXPECTED_DIR.mkdir(parents=True, exist_ok=True)
    for fixture_dir in sorted(FIXTURES_DIR.iterdir()):
        if not fixture_dir.is_dir():
            continue
        source_docx = fixture_dir / "source.docx"
        if not source_docx.exists():
            continue
        expected_dir = EXPECTED_DIR / fixture_dir.name
        if expected_dir.exists():
            shutil.rmtree(expected_dir)
        expected_dir.mkdir(parents=True)

        bundle_dir = expected_dir / "_bundle"
        stylesheet, warnings = extract_document_bundle(source_docx, bundle_dir)
        normalized = normalize_stylesheet(json.loads(stylesheet.model_dump_json(exclude_none=True)))

        dump_json(expected_dir / "styles.json", normalized)
        shutil.move(str(bundle_dir / "content.md"), str(expected_dir / "content.md"))
        shutil.move(str(bundle_dir / "content.adoc"), str(expected_dir / "content.adoc"))
        shutil.move(str(bundle_dir / "media"), str(expected_dir / "media"))
        shutil.rmtree(bundle_dir)

        apply_output = expected_dir / "roundtrip.docx"
        apply_stylesheet(
            expected_dir / "content.md",
            stylesheet,
            apply_output,
            media_dir=expected_dir / "media",
        )
        apply_output_adoc = expected_dir / "roundtrip-adoc.docx"
        apply_stylesheet(
            expected_dir / "content.adoc",
            stylesheet,
            apply_output_adoc,
            media_dir=expected_dir / "media",
            input_format=SourceFormat.ASCIIDOC,
        )
        dump_json(
            expected_dir / "summary.json",
            {
                "warnings": warnings,
                "media_files": sorted(path.name for path in (expected_dir / "media").iterdir()),
            },
        )
        dump_json(expected_dir / "apply_snapshot.json", snapshot_docx(apply_output))
        dump_json(expected_dir / "apply_snapshot_adoc.json", snapshot_docx(apply_output_adoc))


def normalize_stylesheet(data: dict) -> dict:
    data["meta"]["extracted_at"] = "<normalized>"
    data["meta"]["pandoc_version"] = "<normalized>"
    return data


def snapshot_docx(path: Path) -> dict:
    document = Document(path)
    with ZipFile(path) as archive:
        zip_names = sorted(archive.namelist())
    return {
        "paragraphs": [
            {"text": paragraph.text, "style": paragraph.style.name if paragraph.style else None}
            for paragraph in document.paragraphs
        ],
        "tables": [
            [[cell.text for cell in row.cells] for row in table.rows] for table in document.tables
        ],
        "core_properties": {
            "title": document.core_properties.title,
            "author": document.core_properties.author,
        },
        "zip_entries": zip_names,
    }


def dump_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
