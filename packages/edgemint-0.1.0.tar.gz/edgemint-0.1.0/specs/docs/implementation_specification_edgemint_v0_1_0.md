# Implementation Specification — edgemint v0.1.0

**Status**: Draft · **Date**: 2026-04-12 · **Author**: Raphaël Mansuy

**Repository**: [github.com/raphaelmansuy/edgemint](http://github.com/raphaelmansuy/edgemint) · **PyPI**: `pip install edgemint`

**Parent**: ADR-002

This document is the **build blueprint**. Every module, algorithm, data structure, and function signature is specified to the level where implementation is mechanical.

---

# Part 0 — Lossless Scope Definition

## What "Lossless" Means

The round-trip guarantee covers **style-level and structural fidelity**: every style property, numbering definition, theme binding, section layout, and header/footer that exists in the source DOCX is preserved through `extract → JSON → regenerate`. Visual equivalence is the assertion target — not byte-identical ZIP output.

## Supported Constructs (In Scope)

- All paragraph, character, and table style properties (including inheritance chains)
- Document defaults (`w:docDefaults`) as the inheritance root
- Theme fonts and colors (slot references preserved, not just computed values)
- Numbering definitions (all levels, all formats)
- Section properties (page size, margins, orientation, columns)
- Headers and footers (preserved as raw OOXML for lossless fidelity)
- Tab stops, borders, shading, bidi, outline levels
- Character spacing, kerning, all underline types
- Paragraph content via Pandoc: text, headings, lists, tables (simple), images, math, footnotes, hyperlinks, code blocks
- Document core properties (title, author, subject, keywords)

## Unsupported Constructs (Out of Scope — Logged as Warnings)

- Merged table cells and nested tables (Pandoc limitation)
- Text boxes, shapes, SmartArt, drawing objects beyond images
- Content controls (structured document tags)
- Form fields
- Revision marks / tracked changes
- Ruby text, custom XML
- OLE embedded objects
- Font embedding
- Conditional table style formatting

The CLI **must** emit a warning to stderr when an unsupported construct is detected during extraction, so users know what was dropped.

---

# Part I — Core Data Models (schema/)

## First Principle: Style = Compression

A DOCX style compresses N formatting properties into a single name. Our Pydantic models are the **decompressed representation** — every property explicit, every inheritance chain resolved.

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Model Dependency Graph                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  StyleSheet ─────────────────────────────────────────────┐          │
│  │                                                       │          │
│  ├─ meta: MetaInfo                                       │          │
│  ├─ theme: ThemeInfo ──┬─ major_font: FontSpec           │          │
│  │                     ├─ minor_font: FontSpec           │          │
│  │                     └─ colors: dict[str, str]         │          │
│  ├─ styles: list[Style]                                  │          │
│  │  └─ Style ──────┬─ paragraph_format: ParagraphFormat  │          │
│  │                 ├─ font: FontProperties                │          │
│  │                 ├─ resolved: ResolvedProperties        │          │
│  │                 └─ linked_style_id: str | None         │          │
│  ├─ numbering_defs: list[NumberingDef]                   │          │
│  │  └─ NumberingDef ─ levels: list[NumberingLevel]       │          │
│  ├─ section_properties: SectionProperties                │          │
│  └─ headers_footers: list[HeaderFooter]                  │          │
│                                                          │          │
│  All models inherit from pydantic.BaseModel               │          │
│  All use model_config = ConfigDict(frozen=True)           │          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

## schema/[models.py](http://models.py) — Complete Pydantic Models

```python
"""Core Pydantic models for edgemint.

Design principles:
- Frozen (immutable) models for thread safety and hashability
- All measurements in points (pt) — single unit, DRY
- Optional fields use None sentinel (not default values)
- Enums for constrained choices
- JSON schema auto-generated via model_json_schema()
"""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

# ─── Enums ───────────────────────────────────────────────────────

class StyleType(str, Enum):
    PARAGRAPH = "paragraph"
    CHARACTER = "character"
    TABLE = "table"
    NUMBERING = "numbering"

class Alignment(str, Enum):
    LEFT = "LEFT"
    CENTER = "CENTER"
    RIGHT = "RIGHT"
    JUSTIFY = "JUSTIFY"
    DISTRIBUTE = "DISTRIBUTE"

class LineSpacingRule(str, Enum):
    SINGLE = "SINGLE"
    ONE_POINT_FIVE = "ONE_POINT_FIVE"
    DOUBLE = "DOUBLE"
    AT_LEAST = "AT_LEAST"
    EXACTLY = "EXACTLY"
    MULTIPLE = "MULTIPLE"

class UnderlineType(str, Enum):
    NONE = "NONE"
    SINGLE = "SINGLE"
    DOUBLE = "DOUBLE"
    DOTTED = "DOTTED"
    DASH = "DASH"
    WAVE = "WAVE"
    THICK = "THICK"
    WORDS = "WORDS"

class BorderStyle(str, Enum):
    NONE = "none"
    SINGLE = "single"
    DOUBLE = "double"
    DOTTED = "dotted"
    DASHED = "dashed"
    THICK = "thick"
    TRIPLE = "triple"

# ─── Value Objects ───────────────────────────────────────────────

class BorderProperties(BaseModel):
    model_config = ConfigDict(frozen=True)
    style: BorderStyle = BorderStyle.NONE
    width_pt: Optional[float] = None
    color: Optional[str] = None  # hex color e.g. "#4472C4"
    space_pt: Optional[float] = None

class Borders(BaseModel):
    model_config = ConfigDict(frozen=True)
    top: Optional[BorderProperties] = None
    bottom: Optional[BorderProperties] = None
    left: Optional[BorderProperties] = None
    right: Optional[BorderProperties] = None
    between: Optional[BorderProperties] = None

class TabStop(BaseModel):
    model_config = ConfigDict(frozen=True)
    position_pt: float
    alignment: str = "LEFT"  # LEFT, CENTER, RIGHT, DECIMAL, BAR
    leader: str = "NONE"     # NONE, DOTS, DASHES, UNDERSCORE

class FontSpec(BaseModel):
    """Theme font specification."""
    model_config = ConfigDict(frozen=True)
    latin: Optional[str] = None
    ea: Optional[str] = None      # East Asian
    cs: Optional[str] = None      # Complex Script
    ascii_theme: Optional[str] = None  # e.g. "majorHAnsi"

# ─── Property Composites ─────────────────────────────────────────

class FontProperties(BaseModel):
    """Character-level formatting properties."""
    model_config = ConfigDict(frozen=True)
    name: Optional[str] = None
    size_pt: Optional[float] = None
    bold: Optional[bool] = None
    italic: Optional[bool] = None
    underline: Optional[UnderlineType] = None
    strike: Optional[bool] = None
    double_strike: Optional[bool] = None
    color: Optional[str] = None         # hex "#RRGGBB"
    highlight: Optional[str] = None     # highlight color name
    superscript: Optional[bool] = None
    subscript: Optional[bool] = None
    small_caps: Optional[bool] = None
    all_caps: Optional[bool] = None
    spacing_pt: Optional[float] = None  # character spacing
    kern_pt: Optional[float] = None
    # Theme reference (resolved in ResolvedProperties)
    ascii_theme: Optional[str] = None
    cs_font: Optional[str] = None
    ea_font: Optional[str] = None

class ParagraphFormat(BaseModel):
    """Paragraph-level formatting properties."""
    model_config = ConfigDict(frozen=True)
    alignment: Optional[Alignment] = None
    space_before_pt: Optional[float] = None
    space_after_pt: Optional[float] = None
    line_spacing: Optional[float] = None
    line_spacing_rule: Optional[LineSpacingRule] = None
    keep_with_next: Optional[bool] = None
    keep_together: Optional[bool] = None
    page_break_before: Optional[bool] = None
    widow_control: Optional[bool] = None
    indent_left_pt: Optional[float] = None
    indent_right_pt: Optional[float] = None
    indent_first_line_pt: Optional[float] = None
    indent_hanging_pt: Optional[float] = None
    tab_stops: Optional[list[TabStop]] = None
    borders: Optional[Borders] = None
    shading_color: Optional[str] = None
    bidi: Optional[bool] = None  # RTL support
    outline_level: Optional[int] = None

class ResolvedProperties(BaseModel):
    """Fully resolved after walking based_on chain + theme."""
    model_config = ConfigDict(frozen=True)
    paragraph_format: ParagraphFormat = Field(default_factory=ParagraphFormat)
    font: FontProperties = Field(default_factory=FontProperties)

# ─── Style ───────────────────────────────────────────────────────

class Style(BaseModel):
    """A single DOCX style definition."""
    model_config = ConfigDict(frozen=True)
    style_id: str                        # locale-independent key
    name: str                            # locale-dependent display name
    name_locale: Optional[str] = None    # e.g. "Überschrift 1"
    type: StyleType
    based_on: Optional[str] = None       # style_id of parent
    next_style: Optional[str] = None     # style_id for next paragraph
    linked_style_id: Optional[str] = None
    is_builtin: bool = False
    is_quick_style: bool = False
    is_default: bool = False
    priority: Optional[int] = None
    # Local properties (what THIS style defines, before inheritance)
    paragraph_format: Optional[ParagraphFormat] = None
    font: Optional[FontProperties] = None
    # Resolved properties (after walking full chain)
    resolved: Optional[ResolvedProperties] = None

# ─── Numbering ───────────────────────────────────────────────────

class NumberingLevel(BaseModel):
    model_config = ConfigDict(frozen=True)
    level: int                        # 0-8
    num_fmt: str                      # decimal, bullet, lowerLetter, etc.
    lvl_text: str                     # "%1.", "%1.%2", bullet char
    start: int = 1
    indent_left_pt: Optional[float] = None
    hanging_pt: Optional[float] = None
    font: Optional[FontProperties] = None
    paragraph_style_id: Optional[str] = None

class NumberingDef(BaseModel):
    model_config = ConfigDict(frozen=True)
    num_id: int
    abstract_num_id: int
    levels: list[NumberingLevel]

# ─── Document Structure ──────────────────────────────────────────

class SectionProperties(BaseModel):
    model_config = ConfigDict(frozen=True)
    page_width_pt: Optional[float] = None
    page_height_pt: Optional[float] = None
    margin_top_pt: Optional[float] = None
    margin_bottom_pt: Optional[float] = None
    margin_left_pt: Optional[float] = None
    margin_right_pt: Optional[float] = None
    orientation: str = "portrait"  # portrait | landscape
    columns: int = 1
    header_distance_pt: Optional[float] = None
    footer_distance_pt: Optional[float] = None

class HeaderFooter(BaseModel):
    model_config = ConfigDict(frozen=True)
    type: str  # "header" | "footer"
    scope: str  # "default" | "first" | "even"
    content_xml: str  # raw OOXML preserved losslessly

# ─── Theme ───────────────────────────────────────────────────────

class ThemeInfo(BaseModel):
    model_config = ConfigDict(frozen=True)
    major_font: FontSpec = Field(default_factory=FontSpec)
    minor_font: FontSpec = Field(default_factory=FontSpec)
    colors: dict[str, str] = Field(default_factory=dict)

# ─── Document Defaults ────────────────────────────────────────────

class DocDefaults(BaseModel):
    """Document-wide default run and paragraph properties.
    
    Corresponds to w:docDefaults in styles.xml.
    These are the implicit root of every inheritance chain.
    """
    model_config = ConfigDict(frozen=True)
    paragraph_format: ParagraphFormat = Field(default_factory=ParagraphFormat)
    font: FontProperties = Field(default_factory=FontProperties)

# ─── Core Properties ─────────────────────────────────────────────

class CoreProperties(BaseModel):
    """Document core properties from docProps/core.xml."""
    model_config = ConfigDict(frozen=True)
    title: Optional[str] = None
    author: Optional[str] = None
    subject: Optional[str] = None
    keywords: Optional[str] = None
    description: Optional[str] = None
    last_modified_by: Optional[str] = None
    created: Optional[str] = None    # ISO-8601
    modified: Optional[str] = None   # ISO-8601

# ─── Meta ────────────────────────────────────────────────────────

class MetaInfo(BaseModel):
    model_config = ConfigDict(frozen=True)
    source_file: str
    extracted_at: str  # ISO-8601
    tool_version: str = "0.1.0"
    default_styles: dict[str, str] = Field(default_factory=dict)
    pandoc_version: Optional[str] = None

# ─── Root ────────────────────────────────────────────────────────

class StyleSheet(BaseModel):
    """Root model. This IS styles.json."""
    model_config = ConfigDict(frozen=True)
    schema_version: str = "edgemint/v1"
    meta: MetaInfo
    core_properties: Optional[CoreProperties] = None
    doc_defaults: Optional[DocDefaults] = None
    theme: ThemeInfo = Field(default_factory=ThemeInfo)
    styles: list[Style] = Field(default_factory=list)
    numbering_defs: list[NumberingDef] = Field(default_factory=list)
    section_properties: Optional[SectionProperties] = None
    headers_footers: list[HeaderFooter] = Field(default_factory=list)

    def get_style(self, style_id: str) -> Style | None:
        """O(1) lookup by style_id."""
        if not hasattr(self, '_style_map'):
            object.__setattr__(
                self, '_style_map',
                {s.style_id: s for s in self.styles}
            )
        return self._style_map.get(style_id)
```

## schema/[validators.py](http://validators.py) — Unit Conversion (DRY)

```python
"""Single source of truth for unit conversions.

All internal values stored in POINTS (pt).
Convert on boundary only (read from XML / write to XML).
"""

# DOCX uses English Metric Units (EMU)
# 1 inch = 914400 EMU = 72 pt
# 1 cm = 360000 EMU ≈ 28.3465 pt
# 1 half-point = 0.5 pt (used for font sizes in DOCX)
# 1 twip = 1/20 pt (used for spacing/indentation)

EMU_PER_PT = 12700
TWIPS_PER_PT = 20
HALF_POINTS_PER_PT = 2
EMU_PER_INCH = 914400
PT_PER_INCH = 72
PT_PER_CM = 28.3465

def emu_to_pt(emu: int | None) -> float | None:
    """English Metric Units → points."""
    return round(emu / EMU_PER_PT, 2) if emu is not None else None

def pt_to_emu(pt: float | None) -> int | None:
    """Points → English Metric Units."""
    return round(pt * EMU_PER_PT) if pt is not None else None

def twips_to_pt(twips: int | None) -> float | None:
    """Twips (1/20 pt) → points."""
    return round(twips / TWIPS_PER_PT, 2) if twips is not None else None

def pt_to_twips(pt: float | None) -> int | None:
    """Points → Twips."""
    return round(pt * TWIPS_PER_PT) if pt is not None else None

def half_pt_to_pt(hp: int | None) -> float | None:
    """Half-points → points. DOCX stores font sizes as half-points."""
    return hp / HALF_POINTS_PER_PT if hp is not None else None

def pt_to_half_pt(pt: float | None) -> int | None:
    """Points → half-points."""
    return round(pt * HALF_POINTS_PER_PT) if pt is not None else None

def eighth_pt_to_pt(ep: int | None) -> float | None:
    """Eighth-points → points. Used for border widths."""
    return ep / 8.0 if ep is not None else None
```

---

# Part II — Style Extraction (extract/)

## First Principle: Read XML, Build Model, Resolve Inheritance

```
┌─────────────────────────────────────────────────────────────────────┐
│              Extraction Pipeline (4 stages)                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Stage 1          Stage 2          Stage 3          Stage 4        │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐     │
│  │ Security  │───▶│ Parse    │───▶│ Resolve  │───▶│ Serialize│     │
│  │ Validate  │    │ XML to   │    │ Inherit- │    │ to JSON  │     │
│  │ ZIP       │    │ Pydantic │    │ ance     │    │          │     │
│  └──────────┘    └──────────┘    └──────────┘    └──────────┘     │
│                                                                     │
│  security.py      parser.py       resolver.py     StyleSheet       │
│  + theme.py       + numbering.py                  .model_dump_json │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
``` 
