# Claude Code Skill — edgemint

**Status**: Ready · **Date**: 2026-04-12 · **Author**: Raphaël Mansuy

**Repository**: [github.com/raphaelmansuy/edgemint](http://github.com/raphaelmansuy/edgemint) · **Skill Standard**: [Agent Skills](https://code.claude.com/docs/en/skills)

---

## Why edgemint as a Claude Code Skill?

edgemint transforms Claude from a text-only assistant into a **document production engine**. Once installed via PyPI, Claude can:

1. **Analyze** any `.docx` template — extract its complete visual identity into machine-readable JSON
2. **Write** Markdown with precise `custom-style` annotations that map to the template's named styles
3. **Generate** pixel-perfect branded documents in a single command
4. **Audit** style changes between template versions
5. **Orchestrate** batch document pipelines (50 reports from one template)

The skill turns a multi-step manual workflow into a conversational request: *"Generate a Q1 report using our EMEA template."*

---

## Skill Architecture

```jsx
┌─────────────────────────────────────────────────────────────────┐
│              edgemint Skill — Architecture                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  USER REQUEST                                                   │
│  "Generate a styled report from this template"                  │
│       │                                                         │
│       ▼                                                         │
│  ┌──────────────────────────────────────────────┐               │
│  │           SKILL.md (this file)                │               │
│  │  • Detects edgemint availability              │               │
│  │  • Chooses workflow (extract / apply / diff)  │               │
│  │  • Writes Markdown with custom-style attrs    │               │
│  │  • Orchestrates the CLI pipeline              │               │
│  └──────────────────────────────────────────────┘               │
│       │                                                         │
│       ▼                                                         │
│  ┌──────────────────────────────────────────────┐               │
│  │           edgemint CLI (via pip)              │               │
│  │  extract-styles · extract · apply-styles      │               │
│  │  diff · validate · info · schema              │               │
│  └──────────────────────────────────────────────┘               │
│       │                                                         │
│       ▼                                                         │
│  OUTPUT: styled .docx, styles.json, content.md                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Skill Directory Structure

```
edgemint/
├── SKILL.md                    # Main skill instructions (below)
├── examples/
│   └── sample-workflow.md      # Example output showing expected format
├── templates/
│   └── report-template.md      # Pandoc Extended Markdown template
└── scripts/
    └── check-install.sh        # Verify edgemint + Pandoc availability
```

---

## [SKILL.md](http://SKILL.md) — Complete Skill Definition

This is the file to place at `~/.claude/skills/edgemint/SKILL.md` (personal) or `.claude/skills/edgemint/SKILL.md` (project).

```yaml
---
name: edgemint
description: >
  Generate style-faithful DOCX documents from Markdown using edgemint.
  Use when creating branded reports, extracting styles from .docx templates,
  generating documents from Markdown, diffing style sheets, or automating
  document pipelines. Handles extract-styles, apply-styles, diff, and batch generation.
argument-hint: "[template.docx] [action: extract|apply|diff|batch]"
allowed-tools: Bash(edgemint *) Bash(pip install *) Bash(pandoc *) Read Write
effort: high
---

# edgemint — DOCX Style Extraction & Regeneration Skill

You are an expert at producing style-faithful Word documents from Markdown
using the `edgemint` CLI. You understand DOCX styles, Pandoc Extended Markdown,
and the three-file architecture (content.md + styles.json + media/).

## Prerequisites Check

Before any operation, verify edgemint is installed:

```

edgemint --version 2>/dev/null || echo "NOT_INSTALLED"

```

If NOT_INSTALLED, install it:

```

pip install edgemint[pandoc]

```

## Core Workflows

### Workflow 1: Extract Styles from a Template

When the user provides a .docx template and wants to understand or capture its styles:

1. Run `edgemint extract-styles <template.docx> -o styles.json --resolved`
2. Read `styles.json` and summarize:
   - Total style count by type (paragraph, character, table)
   - Theme fonts (headings vs. body)
   - Key custom styles (non-built-in)
   - Color palette from theme
3. Present findings in a clear table

### Workflow 2: Generate a Styled Document

When the user wants to create a branded .docx from content:

1. If no styles.json exists yet, extract from the template first (Workflow 1)
2. Read styles.json to understand available style names
3. Write content in Pandoc Extended Markdown using the correct style annotations:

   **Block-level styles** (paragraphs, headings):
```

::: {custom-style="Heading 1"}

Chapter Title

:::

::: {custom-style="Body Text"}

Paragraph content here.

:::

```

**Inline styles** (character-level):
```

The project is [on track]{custom-style="Status Green"}.

```

**Standard Markdown** (auto-mapped to DOCX styles):
```

# Heading 1          → Heading 1

## Heading 2         → Heading 2

**bold**             → Strong

*italic*             → Emphasis

- Bullet item        → List Bullet
1. Numbered item     → List Number

> Blockquote         → Quote
> 

$E = mc^2$           → OMML equation

```

4. Save content as `content.md`
5. Run `edgemint apply-styles content.md styles.json -o output.docx`
6. Confirm the output file was created and report its size

### Workflow 3: Full Round-Trip Extraction

When the user wants to decompose an existing .docx into editable parts:

1. Run `edgemint extract <document.docx> -o project/`
2. This produces: `project/content.md`, `project/styles.json`, `project/media/`
3. Read `content.md` and explain its structure
4. Summarize the styles and media assets found
5. The user can now edit `content.md` and regenerate with:
   `edgemint apply-styles project/content.md project/styles.json -o rebuilt.docx --media project/media`

### Workflow 4: Diff / Audit Styles

When the user wants to compare two templates or track style changes:

1. Extract styles from both templates
2. Run `edgemint diff before.json after.json`
3. Present changes grouped by: Added, Removed, Modified
4. For modified styles, highlight the specific properties that changed

### Workflow 5: Batch Document Generation

When the user wants to generate multiple documents from one template:

1. Extract styles from the template (once)
2. For each document:
   a. Write content as Pandoc Extended Markdown with proper custom-style annotations
   b. Save as individual .md files
3. Generate all documents:
```

for md in docs/*.md; do

name=$(basename "$md" .md)

edgemint apply-styles "$md" styles.json -o "output/${name}.docx"

done

```

### Workflow 6: Quick Template Inspection

When the user just wants a quick look at a .docx file's styles:

1. Run `edgemint info <document.docx>`
2. Summarize the output: style count, key styles, inheritance depth

## Style Annotation Rules

When writing Markdown content for edgemint, follow these rules strictly:

1. **Always check styles.json first** — never guess style names. Use the exact `name` field.
2. **Use `custom-style` for non-default styles** — standard Markdown (`#`, `**`, `-`) auto-maps to built-in DOCX styles. Only use `::: {custom-style="..."}` for custom or branded styles.
3. **Prefer standard Markdown when possible** — `# Heading` is cleaner than `::: {custom-style="Heading 1"}` and produces the same result.
4. **Math uses LaTeX** — inline `$...$` and display `$$...$$`. Pandoc converts to OMML automatically.
5. **Images reference the media/ directory** — `![Caption](media/image1.png){width=80%}`
6. **Tables use pipe syntax** — simple tables work. Complex merged cells need raw OOXML fallback.
7. **Page breaks use raw OOXML** — `` ```{=openxml}\n<w:p><w:r><w:br w:type="page"/></w:r></w:p>\n``` ``

## Error Handling

- **Exit code 2 (file error)**: Check that the .docx file exists and is valid
- **Exit code 4 (Pandoc error)**: Run `pandoc --version` to verify Pandoc is installed. If missing: `pip install edgemint[pandoc]`
- **Exit code 5 (security error)**: The file failed security validation (ZIP bomb, path traversal). Warn the user.
- **Style deduplication warning**: Normal — Pandoc creates duplicate styles that edgemint auto-fixes
- **List style warning**: Normal — Pandoc bug #7280, edgemint auto-fixes

## Output Quality Checklist

After generating a .docx, verify:
- [ ] File exists and has reasonable size (not 0 bytes)
- [ ] Run `edgemint validate styles.json` if style issues suspected
- [ ] Check for warnings in edgemint output (dedup count, fix count)
- [ ] For critical documents, do a round-trip: extract the output and diff against original styles

## What edgemint CANNOT Do

- Track changes / revision marks (stripped on extraction)
- Comments / annotations (not representable in Markdown)
- Form fields, macros, VBA (stripped for security)
- Complex merged table cells (requires raw OOXML fallback)
- Text boxes, shapes, SmartArt (images only)

Be transparent with users about these limitations.

```

---

## Design Decisions & Rationale

### Why these frontmatter choices?

| **Field** | **Value** | **Rationale** |
| --- | --- | --- |
| `name` | `edgemint` | Matches the PyPI package name. User types `/edgemint` to invoke. |
| `description` | Multi-line, keyword-rich | Front-loaded with "Generate style-faithful DOCX" so Claude matches on document/report/DOCX requests. Under 250 chars for the key part. |
| `argument-hint` | `[template.docx] [action]` | Guides user during `/` autocomplete. Shows edgemint expects a file and an action. |
| `allowed-tools` | `Bash(edgemint *)`  • others | Pre-approves all edgemint CLI commands, pip install, Pandoc, and file read/write. No permission prompts during workflow. |
| `effort` | `high` | Document generation involves multiple steps (extract → write → apply → verify). High effort ensures thorough execution. |
| `disable-model-invocation` | not set (default: false) | Claude should auto-detect when to use this skill. If user says "generate a report" or "extract styles", Claude should load it automatically. |
| `context` | not set (inline) | Runs inline, not in a subagent. Claude needs conversation context (file paths, user preferences) to write good Markdown content. |

### Why dynamic context injection (`!` backtick)?

The `edgemint --version` check runs **before** the skill content reaches Claude. If edgemint isn't installed, Claude sees `NOT_INSTALLED` in the rendered prompt and knows to install it first. Zero wasted turns.

### Why `effort: high`?

Document generation is inherently multi-step. With `effort: high`, Claude will:

- Read styles.json thoroughly before writing Markdown
- Use proper `custom-style` annotations (not guess)
- Run validation after generation
- Report the output quality checklist

### Why inline (no `context: fork`)?

The skill needs access to the user's conversation history:

- File paths mentioned earlier in the chat
- Content preferences expressed in prior turns
- Iterative refinement ("change the heading font" requires knowing which styles.json is active)

Forking would lose all this context.

---

## Installation Instructions

### For Personal Use (all projects)

```bash
# Create the skill directory
mkdir -p ~/.claude/skills/edgemint

# Copy SKILL.md (from the code block above)
cat > ~/.claude/skills/edgemint/SKILL.md << 'SKILL_EOF'
# ... paste the SKILL.md content here ...
SKILL_EOF

# Verify
ls ~/.claude/skills/edgemint/SKILL.md
```

### For a Specific Project

```bash
# In your project root
mkdir -p .claude/skills/edgemint
# Copy SKILL.md into .claude/skills/edgemint/
```

### For Organization-Wide Deployment

Add to managed settings to deploy across all users. See [managed settings documentation](https://code.claude.com/docs/en/skills#share-skills).

---

## Usage Examples

### Example 1: Extract and Inspect

```
User: /edgemint corporate-template.docx extract

Claude:
  ✓ edgemint v0.1.0 detected
  ✓ Extracting styles from corporate-template.docx...
  ✓ Found 28 styles (18 paragraph, 8 character, 2 table)

  Theme: Calibri Light (headings) / Calibri (body)
  Key custom styles:
    • "Executive Summary" — Calibri 11pt, #2F5496, justified
    • "VE" — Bold, #C00000 (character style)
    • "Block Quote" — Italic, 36pt left indent, gray border

  Saved to styles.json (ready for apply-styles)
```

### Example 2: Generate a Report

```
User: /edgemint Generate a Q1 performance report using styles.json

Claude:
  Reading styles.json... 28 styles available.
  Writing content.md with proper style annotations...
  Running: edgemint apply-styles content.md styles.json -o q1-report.docx
  ✓ Generated q1-report.docx (186 KB)
  ✓ Post-processed: deduplicated 3 styles, fixed 5 list paragraphs
```

### Example 3: Batch Generation

```
User: /edgemint Generate monthly reports for Jan-Mar using emea-styles.json

Claude:
  Writing 3 Markdown files with EMEA branding...
  Generating:
    ✓ january-report.docx (142 KB)
    ✓ february-report.docx (138 KB)
    ✓ march-report.docx (156 KB)
  All 3 documents use identical EMEA styling.
```

---

## Sovereignty Check

- [x]  **Reusable IP**: The skill itself is a reusable asset (Estonian OÜ)
- [x]  **Open distribution**: Published alongside edgemint on GitHub (Apache-2.0 license)
- [x]  **No client dependency**: Works with any .docx template, no vendor lock-in
- [x]  **Scales without time**: Once installed, Claude handles everything autonomously
- [x]  **Amplifies the tool**: Makes edgemint accessible to non-CLI users through natural language

---

## Publishing Checklist

- [ ]  Include `SKILL.md` in the [edgemint GitHub repo](https://github.com/raphaelmansuy/edgemint) under `.claude/skills/edgemint/`
- [ ]  Add installation instructions to the README
- [ ]  Submit to the [Anthropic Skills Registry](https://github.com/anthropics/skills) via PR
- [ ]  Add a `skills/` directory to the PyPI package for auto-discovery
- [ ]  Document in the User Guide (link to this page)
- [ ]  Test with Claude Code: `/edgemint` should appear in the slash command menu
