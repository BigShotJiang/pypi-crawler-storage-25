# edgemint — User Guide

**Your branded documents deserve better than copy-paste styling.**

> 📦 **Install**: `pip install edgemint` · **Source**: [github.com/raphaelmansuy/edgemint](http://github.com/raphaelmansuy/edgemint) · **License**: Apache-2.0
> 

---

## Why Does This Exist?

You have a beautiful `.docx` template. Corporate fonts, precise spacing, branded headings. Your designer spent weeks on it.

Now you need to produce 50 reports with that exact look — but from Markdown content your team writes in Git repos, wikis, and notebooks.

What happens today:

```
┌─────────────────────────────────────────────────────────────┐
│                    THE PAINFUL WAY                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Open Word                                               │
│  2. Copy-paste your Markdown content                        │
│  3. Manually apply Heading 1... Heading 2... Body Text...   │
│  4. Fix the spacing. Again.                                 │
│  5. Fix the fonts. Again.                                   │
│  6. Realize the numbered list is wrong. Fix it. Again.      │
│  7. Repeat for the next 49 documents.                       │
│                                                             │
│  Total time: ∞          Errors: guaranteed                  │
│  Will to live: declining                                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

What should happen:

```jsx
┌─────────────────────────────────────────────────────────────┐
│                   THE edgemint WAY                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Extract styles from your template     (once)            │
│  2. Write content in Markdown             (the fun part)    │
│  3. Run one command                       (< 5 seconds)     │
│  4. Get a perfectly styled .docx          (every time)      │
│                                                             │
│  Total time: seconds    Errors: zero                        │
│  Will to live: restored                                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**edgemint** is a CLI that extracts the complete visual identity from any `.docx` template, then regenerates new documents from Markdown while preserving every font, color, spacing, and border — pixel for pixel.

---

## How It Works (30-Second Version)

```
YOUR TEMPLATE                YOUR CONTENT              YOUR OUTPUT
────────────                ────────────              ───────────

┌──────────┐    extract     ┌──────────┐    apply     ┌──────────┐
│ Branded  │──────────────▶ │styles.json│─────────────▶│ Branded  │
│  .docx   │               └──────────┘    +          │  .docx   │
│ template │                               │          │  output  │
└──────────┘               ┌──────────┐    │          └──────────┘
                           │content.md │────┘
                           │(Markdown) │
                           └──────────┘

"What it looks like"    "What it says"          "Both, together"
```

Two commands. That's it.

---

## Installation

### Style extraction only (lightweight, no Pandoc)

```bash
pip install edgemint
```

### Full pipeline (extraction + generation)

```bash
pip install edgemint[pandoc]
```

### Docker (zero dependencies on your machine)

```bash
docker run ghcr.io/raphaelmansuy/edgemint extract input.docx
```

---

## Quick Start: Your First Round-Trip in 3 Minutes

Let's take a real branded template and produce a document from Markdown.

### Step 1 — Extract styles from your template

```bash
$ edgemint extract-styles acme-template.docx -o styles.json

✓ Extracted 23 styles (14 paragraph, 7 character, 2 table)
✓ Resolved 3-level inheritance chain
✓ Theme fonts: Calibri Light (headings), Calibri (body)
✓ Saved to styles.json
```

That `styles.json` now contains **everything** about your template's visual identity: fonts, sizes, colors, spacing, borders, numbering schemes, theme colors — the lot.

### Step 2 — Write your content in Markdown

Create `report.md`:

```markdown
---
title: "Q1 2026 Performance Report"
author: "Raphaël Mansuy"
date: 2026-04-12
---

::: {custom-style="Heading 1"}
Executive Summary
:::

::: {custom-style="Body Text"}
Revenue grew 23% quarter-over-quarter, driven by
expansion in the APAC region and the launch of
three new product lines.
:::

::: {custom-style="Heading 2"}
Key Metrics
:::

| Metric          | Q4 2025  | Q1 2026  | Change  |
|:--------------- |:--------:|:--------:|:-------:|
| Revenue ($M)    | 12.4     | 15.3     | +23%    |
| Active Users    | 84,200   | 112,500  | +34%    |
| Churn Rate      | 4.1%     | 3.2%     | -0.9pp  |

::: {custom-style="Block Quote"}
"The best quarter in company history." — CEO
:::
```

Notice the `::: {custom-style="..."}` blocks. These map directly to your template's named styles. **That's the magic** — your Markdown content speaks the same language as your Word template.

### Step 3 — Generate the styled document

```bash
$ edgemint apply-styles report.md styles.json -o report.docx

✓ Loaded 23 styles from styles.json
✓ Built reference document
✓ Pandoc conversion complete
✓ Post-processed: deduplicated 2 styles, fixed list paragraphs
✓ Output: report.docx (142 KB)
```

Open `report.docx`. It looks **exactly** like it was styled by hand in your branded template. Every heading, every font, every color — identical.

---

## Full Extraction: The Three-File Architecture

For documents with images, math, and complex content, use the full extraction mode:

```bash
$ edgemint extract branded-report.docx -o project/
```

This produces three outputs:

```
project/
├── content.md        ← Text + structure (Pandoc Extended Markdown)
├── styles.json       ← Visual identity (fonts, colors, spacing...)
└── media/            ← Images and embedded objects
     ├── image1.png
     └── chart2.emf
```

Why three files? Because a document has three independent information channels:

```
┌─────────────────────────────────────────────────────────────────┐
│              WHAT    +    HOW IT LOOKS    +    ASSETS           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  content.md              styles.json           media/           │
│  ───────────             ───────────           ──────           │
│  The words,              The fonts,            The images,      │
│  the structure,          the colors,           the charts,      │
│  the references,         the spacing,          the diagrams     │
│  the math                the borders                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

  Separation = power.
  Edit content without touching styles.
  Swap styles without touching content.
  Version everything in Git.
```

To rebuild the document from these three files:

```bash
$ edgemint apply-styles project/content.md project/styles.json -o rebuilt-report.docx --media project/media
```

---

## Real-World Examples

### Example 1: Monthly Report Pipeline

Your team writes reports in Markdown. Finance provides a branded template. Automate the whole thing.

```bash
# One-time setup: extract the brand
$ edgemint extract-styles finance-template.docx -o brand.json

# Every month: generate from Markdown
$ edgemint apply-styles march-report.md brand.json -o march-report.docx
$ edgemint apply-styles april-report.md brand.json -o april-report.docx
```

```
finance-template.docx
       │
       │  extract (once)
       ▼
   brand.json ─────────────────────────────────┐
       │                                       │
       │  + march-report.md ──▶ march.docx     │
       │  + april-report.md ──▶ april.docx     │
       │  + may-report.md   ──▶ may.docx       │
       │       ...                              │
       │                                       │
       └── Same brand. Every time. Zero effort.┘
```

### Example 2: Multi-Language Documents

Same content, different templates for different regions:

```bash
# Extract each regional template
$ edgemint extract-styles emea-template.docx -o emea.json
$ edgemint extract-styles apac-template.docx -o apac.json

# Apply same content to each
$ edgemint apply-styles report.md emea.json -o report-emea.docx
$ edgemint apply-styles report.md apac.json -o report-apac.docx
```

### Example 3: Style Auditing & Migration

Compare two versions of a template to see what changed:

```bash
$ edgemint diff old-template.json new-template.json

  CHANGED  Heading 1
    font.size_pt:   16.0 → 18.0
    font.color:     #2F5496 → #1A3C6E
    paragraph_format.space_before_pt: 12.0 → 16.0

  ADDED    Subtitle
    font: Calibri Light, 14pt, #4472C4

  REMOVED  Body Text Indent
    (was: Normal + 36pt left indent)
```

### Example 4: Math-Heavy Academic Papers

Equations round-trip through LaTeX notation:

```markdown
The quadratic formula is $\frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$.

For the general case:

$$\int_0^\infty e^{-x^2} dx = \frac{\sqrt{\pi}}{2}$$
```

```
YOUR MARKDOWN                         YOUR DOCX
──────────────                        ─────────

$\frac{a}{b}$        ──────────▶     Word equation editor
(7 characters)          Pandoc        renders the fraction
                       LaTeX→OMML     perfectly, editable
                                      in Word natively
```

Pandoc handles the LaTeX → OMML conversion natively. No plugins, no extra steps.

---

## Naming Your Styles in Markdown

The key to style-faithful output is using the right `custom-style` names. Here's how standard Markdown elements map to DOCX styles — and how to override them:

### Default Mapping (No Annotation Needed)

```
MARKDOWN                    DOCX STYLE
────────────                ──────────
# Heading               →  Heading 1
## Heading              →  Heading 2
### Heading             →  Heading 3
Plain paragraph         →  Normal
> Blockquote            →  Quote
- Bullet item           →  List Bullet
1. Numbered item        →  List Number
**bold**                →  Strong
*italic*                →  Emphasis
`inline code`           →  Code
```

These work out of the box. For most documents, you never need `custom-style`.

### Explicit Style Annotation (For Branded Templates)

When your template has custom styles beyond the defaults:

**Block-level** (paragraphs, headings, block quotes):

```markdown
::: {custom-style="Executive Summary"}
This paragraph uses a style specific to your template.
:::
```

**Inline** (character styles within a paragraph):

```markdown
The project is [on track]{custom-style="Status Green"}
and [under budget]{custom-style="Highlight"}.
```

### How to Find Your Template's Style Names

```bash
$ edgemint extract-styles template.docx -o styles.json
$ cat styles.json | python -m json.tool | grep '"name"'

    "name": "Normal"
    "name": "heading 1"
    "name": "heading 2"
    "name": "Body Text"
    "name": "Block Quote"
    "name": "VE"               ← your custom style!
    "name": "Executive Summary" ← another custom style!
```

Use the `name` field as your `custom-style` value. These are the exact names that Word uses.

---

## Command Reference

```jsx
┌──────────────────────────────────────────────────────────────┐
│  COMMAND           │  WHAT IT DOES          │  NEEDS PANDOC? │
├────────────────────┼────────────────────────┼────────────────┤
│  extract-styles    │  .docx → styles.json   │  No            │
│  extract           │  .docx → project/      │  Yes           │
│  apply-styles      │  md + json → .docx     │  Yes           │
│  diff              │  Compare two JSONs     │  No            │
│  validate          │  Check JSON schema     │  No            │
│  info              │  Quick .docx summary   │  No            │
│  schema            │  Export JSON Schema    │  No            │
├────────────────────┼────────────────────────┼────────────────┤
│  Exit codes:                                                 │
│    0 = success   1 = validation   2 = file   3 = schema     │
│    4 = pandoc    5 = security                                │
└──────────────────────────────────────────────────────────────┘
```

### extract-styles

Extract style definitions only (fast, no Pandoc required).

```bash
$ edgemint extract-styles template.docx -o styles.json
$ edgemint extract-styles template.docx --resolved      # include inherited props
$ edgemint extract-styles template.docx --filter paragraph  # paragraph styles only
```

### extract

Full document extraction: content + styles + media.

```bash
$ edgemint extract report.docx -o project/
# Produces: project/content.md, project/styles.json, project/media/
```

### apply-styles

Generate a styled `.docx` from Markdown + styles.

```bash
$ edgemint apply-styles content.md styles.json -o output.docx
$ edgemint apply-styles content.md styles.json -o output.docx --media ./media
```

### diff

Compare two style sheets to see what changed.

```bash
$ edgemint diff old.json new.json
```

### validate

Check a style JSON against the schema.

```bash
$ edgemint validate styles.json
```

### info

Quick inspection of a `.docx` file's styles (no extraction, no Pandoc).

```bash
$ edgemint info report.docx
```

### schema

Export the JSON Schema for `styles.json` (useful for IDE auto-completion).

```bash
$ edgemint schema > edgemint-schema.json
```

---

## What Gets Preserved (And What Doesn't)

Transparency matters. Here's the honest fidelity matrix:

```
┌────────────────────────┬───────────┬───────────────────────────────┐
│  Feature               │ Fidelity  │ How                           │
├────────────────────────┼───────────┼───────────────────────────────┤
│  Paragraph styles      │ LOSSLESS  │ custom-style fenced divs      │
│  Character styles      │ LOSSLESS  │ custom-style bracketed spans  │
│  Bold / italic         │ LOSSLESS  │ **bold** / *italic*           │
│  Footnotes             │ LOSSLESS  │ [^id] syntax                  │
│  Images                │ LOSSLESS  │ ![](media/x.png){attrs}       │
│  Simple tables         │ LOSSLESS  │ pipe/grid tables              │
│  Math (LaTeX)          │ LOSSLESS  │ $...$ and $$...$$             │
│  Page breaks           │ LOSSLESS  │ raw openxml block             │
│  Theme / colors        │ LOSSLESS  │ styles.json sidecar           │
│  Numbering             │ LOSSLESS  │ styles.json sidecar           │
├────────────────────────┼───────────┼───────────────────────────────┤
│  Complex table merges  │ NEAR      │ raw openxml fallback          │
│  Image float/anchor    │ NEAR      │ raw openxml fallback          │
│  Headers / footers     │ NEAR      │ JSON sidecar representation   │
├────────────────────────┼───────────┼───────────────────────────────┤
│  Track changes         │ LOST      │ Accepted only (not preserved) │
│  Comments              │ LOST      │ Not representable in Markdown │
│  Form fields           │ LOST      │ Not representable in Markdown │
│  Macros / VBA          │ LOST      │ Stripped (security policy)    │
└────────────────────────┴───────────┴───────────────────────────────┘
```

No surprises. No silent degradation. If something is lost, you'll know.

---

## CI/CD Integration

Automate document generation in your pipeline:

```yaml
# .github/workflows/generate-docs.yml
name: Generate Reports
on:
  push:
    paths: ['reports/*.md']

jobs:
  generate:
    runs-on: ubuntu-latest
    container: ghcr.io/raphaelmansuy/edgemint:latest
    steps:
      - uses: actions/checkout@v4
      - name: Generate all reports
        run: |
          for md in reports/*.md; do
            name=$(basename "$md" .md)
            edgemint apply-styles "$md" \
              brand/styles.json \
              -o "output/${name}.docx"
          done
      - uses: actions/upload-artifact@v4
        with:
          name: reports
          path: output/*.docx
```

Push Markdown → get styled `.docx` artifacts. Every commit. Automatically.

---

## Troubleshooting

### "My styles look wrong in the output"

Pandoc sometimes creates duplicate style entries. The post-processor fixes this automatically, but if you see issues:

```bash
# Re-run with verbose output to see what's happening
$ edgemint apply-styles content.md styles.json -o out.docx --verbose
```

Look for `Deduplicated N styles` in the output. If deduplication didn't trigger, file a bug.

### "List indentation is off"

Known Pandoc bug (#7280): list items get `Normal` style instead of `List Paragraph`. The built-in Lua filter and post-processor handle this, but verify:

```bash
# Check that list styles are correctly assigned
$ edgemint extract-styles output.docx --filter paragraph | grep -i list
```

### "Math equations look different"

The LaTeX → OMML conversion is lossless for standard math. Edge cases:

- `\cancel{x}` has no OMML equivalent (will be lost)
- Custom `\newcommand` macros must be expanded before conversion
- TikZ diagrams cannot be represented — rasterize to PNG first

### "Pandoc not found"

```bash
# Option A: install with Pandoc bundled
pip install edgemint[pandoc]

# Option B: use Docker (Pandoc included)
docker run ghcr.io/raphaelmansuy/edgemint apply ...

# Option C: install Pandoc separately
brew install pandoc   # macOS
apt install pandoc    # Ubuntu
```

---

## FAQ

### Can I use this without Pandoc?

`extract-styles`, `diff`, `validate`, `info`, and `schema` work without Pandoc. Only `extract` (full) and `apply-styles` require it.

### What Markdown flavor does it use?

**Pandoc Extended Markdown** — the only dialect that supports named style annotations at both paragraph and character levels via `custom-style` attributes. Standard Markdown (CommonMark, GFM) can't represent styles.

### Does it work with LibreOffice / Google Docs templates?

Yes, with `--lenient` mode (the default). Non-standard DOCX files may produce warnings but extraction will continue.

### Can I version-control the styles?

Absolutely. `styles.json` is a plain JSON file — diff it, commit it, review changes in PRs. This is one of the core design goals.

### How fast is it?

Style extraction: **< 1 second** for most templates. Full round-trip (extract + apply): **< 5 seconds** for a 50-page document with images.
