# ADR-002: edgemint — DOCX Style Extraction & Regeneration CLI

**Status**: Proposed · **Date**: 2026-04-12 · **Author**: Raphaël Mansuy

**Repository**: [github.com/raphaelmansuy/edgemint](http://github.com/raphaelmansuy/edgemint) · **PyPI**: `pip install edgemint`

---

## §0 Context & Problem Statement

Professional document workflows require **style-faithful round-tripping**: taking a branded `.docx` template, extracting its complete style sheet, then regenerating new documents from Markdown or AsciiDoc content while preserving the exact visual identity.

No existing open-source CLI does this as a single, composable pipeline. Current tools either convert lossy (Mammoth, Pandoc) or require manual Word interaction.

---

## §1 OODA Loop — Decision Reflexion

### Observe

- `.docx` is Office Open XML (ECMA-376): a ZIP of XML parts. Styles live in `word/styles.xml`.
- Style properties span: font family, size, color, spacing, indentation, borders, numbering, tab stops, based-on chains, next-style links.
- Users need **two tools**: (1) Extract styles → JSON, (2) Markdown + JSON → `.docx`.
- Pandoc handles Markdown→DOCX but uses a reference doc, not a granular style map. It cannot remap arbitrary heading/paragraph styles.

### Orient

- **First Principle**: A `.docx` style is a *named compression* of formatting properties (rate-distortion: one name encodes N properties). Extracting styles = decompressing that mapping into an explicit JSON schema.
- The tool must be **lossless on styles** — every property the XML encodes must appear in the JSON. Lossy extraction defeats the purpose.
- Round-trip fidelity is the acceptance criterion: `extract(template) → JSON → generate(markdown, JSON) → docx` must produce visually identical output to manually styled content.

### Decide

- **Language**: Python 3.11+
- **Core Library**: `python-docx` (v1.2+) — only library with direct `Style` object access, `based_on` chain traversal, and XML-level fallback via `lxml`.
- **Architecture**: Two-phase CLI with shared JSON schema.
- Rust and Node.js rejected (see §3).

### Act

- Build `edgemint` as a single CLI with subcommands: `extract-styles`, `extract`, `apply-styles`, `diff`, `validate`, `info`, and `schema`.

---

## §2 Architecture

### System Overview

```jsx
┌──────────────────────────────────────────────────────────────────────────┐
│                         edgemint CLI                              │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────┐  ┌────────────────┐  │
│  │ extract-     │  │  extract     │  │  apply   │  │  diff /        │  │
│  │ styles       │  │  (full)      │  │          │  │  validate      │  │
│  │ (no Pandoc)  │  │ (+ Pandoc)   │  │(+ Pandoc)│  │  (no Pandoc)   │  │
│  └──────┬───────┘  └──────┬───────┘  └────┬─────┘  └───────┬────────┘  │
│         │                 │               │                │          │
│         ▼                 ▼               ▼                ▼          │
│  ┌──────────────┐  ┌────────────┐  ┌────────────┐  ┌──────────────┐  │
│  │ StyleParser   │  │ Pandoc CLI │  │ Pandoc CLI │  │ StyleCompare │  │
│  │ (python-docx) │  │ + PostProc │  │ + PostProc │  │ (Pydantic)   │  │
│  └──────┬───────┘  └──────┬─────┘  └──────┬─────┘  └──────────────┘  │
│         │                 │               │                          │
│         ▼                 ▼               ▼                          │
│  ┌───────────────────────────────────────────────┐                    │
│  │           StyleSchema (shared Pydantic models) │                    │
│  └───────────────────────────────────────────────┘                    │
│         │                 │               │                          │
│         ▼                 ▼               ▼                          │
│    styles.json     project/ dir      output.docx                     │
│                  (md + json + media)                                  │
│                                                                        │
└──────────────────────────────────────────────────────────────────────────┘
```

### Data Flow — Extract Phase (Three-File Output)

```jsx
input.docx
     │
     ▼
┌──────────┐     ┌───────────────────────┐
│ ZIP open  │────▶│ word/styles.xml       │──┐
└──────────┘     │ word/numbering.xml    │  │
     │           │ word/theme1.xml       │  ├──▶ styles.json
     │           │ word/header1.xml      │  │
     │           │ word/footer1.xml      │──┘
     │           └───────────────────────┘
     │
     │           ┌───────────────────────┐
     ├──────────▶│ word/document.xml     │──────▶ content.md
     │           │  (via Pandoc AST or   │       (Pandoc Extended MD
     │           │   python-docx parse)  │        with custom-style attrs)
     │           └───────────────────────┘
     │
     │           ┌───────────────────────┐
     └──────────▶│ word/media/*          │──────▶ media/
                 │  (images, embeddings) │       (binary copy)
                 └───────────────────────┘
```

### Data Flow — Apply Phase (Three-File Input)

```
content.md        styles.json       media/
     │                 │                │
     ▼                 ▼                │
┌──────────┐   ┌──────────────┐        │
│ Pandoc    │   │ Load         │        │
│ Reader    │   │ StyleSheet   │        │
│ (parse to │   │ → build      │        │
│  AST)     │   │ reference.docx│       │
└────┬─────┘   └──────┬───────┘        │
     │                │                │
     ▼                ▼                ▼
┌────────────────────────────────────────┐
│        Pandoc DOCX Writer              │
│  pandoc content.md                     │
│    --reference-doc=reference.docx      │
│    --lua-filter=fix-lists.lua          │
│    --resource-path=media/              │
│    -o raw_output.docx                  │
└───────────────────┬────────────────────┘
                    │
                    ▼
┌────────────────────────────────────────┐
│        PostProcessor (python-docx)     │
│  1. Deduplicate styles (§16 RB-2)      │
│  2. Inject styles.json definitions     │
│  3. Fix list paragraph styles (§16 RB-5)│
│  4. Re-link heading numbering          │
│  5. Inject headers/footers from JSON   │
│  6. Validate output consistency        │
└───────────────────┬────────────────────┘
                    │
                    ▼
              output.docx
```

### Exact Pandoc Commands

**Extract** (DOCX → Markdown with style preservation):

```bash
pandoc input.docx \
  -f docx+styles \
  -t markdown+fenced_divs+bracketed_spans+yaml_metadata_block \
  --wrap=none \
  --extract-media=media/ \
  -o content.md
```

**Apply** (Markdown → DOCX with style injection):

```bash
pandoc content.md \
  -f markdown+fenced_divs+bracketed_spans+yaml_metadata_block+raw_attribute \
  -t docx \
  --reference-doc=reference.docx \
  --lua-filter=filters/fix-lists.lua \
  --lua-filter=filters/fix-styles.lua \
  --resource-path=media/ \
  -o raw_output.docx
```

The `raw_output.docx` is then post-processed by python-docx to fix known Pandoc bugs (style duplication, list styles) and inject full style definitions from `styles.json`.

---

## §3 Technology Decision

| **Criterion** | **Python + python-docx** | **Rust + docx-rust** | **Node.js + mammoth** |
| --- | --- | --- | --- |
| Style enumeration API | `doc.styles` iterator, direct property access, XML fallback via `style.element` | Has `styles` module but no high-level iterator; must parse raw XML manually | No style extraction API — conversion-only (docx→HTML) |
| Property depth | Font, paragraph format, tab stops, borders, numbering — full coverage | Structs exist for formatting but incomplete field coverage | Strips styles by design (semantic conversion) |
| Inheritance resolution | `style.base_style` chain + theme fallback | Manual implementation required | N/A |
| DOCX generation | Full write support with style application | `docx-rust` write support exists but limited | `docx` npm package exists but separate from mammoth |
| Ecosystem maturity | 1.2.0, 5,300+ stars, active maintenance | 0.x versions, limited community | mammoth stable but wrong tool for this job |
| Time to MVP | ~2 days | ~5-7 days (XML plumbing) | ~4-5 days (need JSZip + xml2js manual parsing) |

**Verdict**: Python + `python-docx` wins on every axis. Rust is defensible for Phase 3 (performance CLI distribution via single binary), but premature for MVP.

> **Future consideration**: If distribution as a single binary matters, wrap the Python core with PyInstaller or rewrite the hot path in Rust post-validation.
> 

---

## §4 JSON Style Schema

The output JSON must be **lossless** — every property encoded in `word/styles.xml` must be represented.

```json
{
  "$schema": "edgemint/v1",
  "meta": {
    "source_file": "template.docx",
    "extracted_at": "2026-04-12T10:30:00+08:00",
    "tool_version": "0.1.0",
    "default_styles": {
      "paragraph": "Normal",
      "character": "Default Paragraph Font",
      "table": "Table Normal"
    }
  },
  "theme": {
    "major_font": { "latin": "Calibri Light", "ea": "", "cs": "" },
    "minor_font": { "latin": "Calibri", "ea": "", "cs": "" },
    "colors": {
      "accent1": "#4472C4",
      "accent2": "#ED7D31"
    }
  },
  "styles": [
    {
      "style_id": "Heading1",
      "name": "heading 1",
      "type": "paragraph",
      "based_on": "Normal",
      "next_style": "Normal",
      "is_builtin": true,
      "is_quick_style": true,
      "priority": 9,
      "paragraph_format": {
        "alignment": "LEFT",
        "space_before_pt": 12.0,
        "space_after_pt": 0.0,
        "line_spacing": 1.08,
        "line_spacing_rule": "MULTIPLE",
        "keep_with_next": true,
        "keep_together": true,
        "page_break_before": false,
        "widow_control": true,
        "indent_left_pt": 0.0,
        "indent_right_pt": 0.0,
        "indent_first_line_pt": 0.0,
        "tab_stops": [],
        "borders": {
          "bottom": { "style": "single", "width_pt": 0.5, "color": "#4472C4" }
        }
      },
      "font": {
        "name": "Calibri Light",
        "size_pt": 16.0,
        "bold": false,
        "italic": false,
        "underline": "NONE",
        "strike": false,
        "color": "#2F5496",
        "highlight": null,
        "superscript": false,
        "subscript": false,
        "small_caps": false,
        "all_caps": false
      },
      "resolved": {
        "_comment": "Fully resolved properties after walking based_on chain + theme defaults",
        "paragraph_format": { "..." : "..." },
        "font": { "..." : "..." }
      }
    }
  ],
  "numbering_definitions": [
    {
      "num_id": 1,
      "abstract_num_id": 0,
      "levels": [
        {
          "level": 0,
          "num_fmt": "decimal",
          "lvl_text": "%1.",
          "start": 1,
          "indent_left_pt": 36.0,
          "hanging_pt": 18.0
        }
      ]
    }
  ]
}
```

---

## §5 Intermediate Markdown Format — Dialect Decision

### OODA Loop — Which Markdown?

#### Observe: The Semantic Gap

A `.docx` document encodes semantics at **five levels**. Any intermediate Markdown format must cover all five or declare explicit loss boundaries.

```
┌─────────────────────────────────────────────────────────────────┐
│              DOCX Semantic Model (5 Layers)                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  L1  PARAGRAPH LEVEL                                            │
│      Named style + direct formatting overrides                  │
│      (alignment, spacing, indentation, borders, keep-together)  │
│                                                                 │
│  L2  RUN LEVEL (inline)                                         │
│      Named character style + direct formatting overrides        │
│      (font, size, color, bold, italic, underline, smallcaps)    │
│                                                                 │
│  L3  STRUCTURAL                                                 │
│      Sections, page/column breaks, headers, footers             │
│                                                                 │
│  L4  REFERENCE OBJECTS                                          │
│      Footnotes, endnotes, cross-refs, bookmarks, TOC fields    │
│                                                                 │
│  L5  EMBEDDED OBJECTS                                           │
│      Tables (with cell merging), images (with positioning),     │
│      charts, equations, text boxes                              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

Standard Markdown (CommonMark, GFM) only covers a fraction of L1/L2 via structural conventions (`#`, `**`, `*`) and nothing beyond. The core question: **which dialect extends coverage to all five layers?**

#### Orient: Dialect Comparison Matrix

```
┌─────────────────────────┬───────────┬──────┬───────────┬──────────┬───────┐
│  Capability             │ CommonMark│  GFM │ Pandoc MD │ AsciiDoc │  Djot │
├─────────────────────────┼───────────┼──────┼───────────┼──────────┼───────┤
│ Named paragraph styles  │     ✗     │   ✗  │  ✓ (a)    │  ✓       │   ✗   │
│ Named character styles  │     ✗     │   ✗  │  ✓ (b)    │  ✓       │   ✗   │
│ Direct format overrides │     ✗     │   ✗  │  ✓ (c)    │  partial │   ✗   │
│ Footnotes / endnotes    │     ✗     │   ✗  │  ✓        │  ✓       │   ✓   │
│ Page / section breaks   │     ✗     │   ✗  │  ✓ (d)    │  ✓       │   ✗   │
│ YAML metadata           │     ✗     │   ✗  │  ✓        │  ✓       │   ✗   │
│ Tables w/ cell merging  │     ✗     │  basic│ partial(e)│  ✓       │  basic│
│ Image positioning/size  │     ✗     │   ✗  │  ✓ (f)    │  ✓       │   ✗   │
│ Cross-references        │     ✗     │   ✗  │  ✓ (g)    │  ✓       │   ✗   │
│ Raw OOXML escape hatch  │     ✗     │   ✗  │  ✓ (h)    │  ✓       │   ✗   │
│ Math equations          │     ✗     │   ✗  │  ✓        │  ✓       │   ✓   │
│ Definition lists        │     ✗     │   ✗  │  ✓        │  ✓       │   ✓   │
│ Headers / footers       │     ✗     │   ✗  │  ✗ (i)    │  ✗       │   ✗   │
├─────────────────────────┼───────────┼──────┼───────────┼──────────┼───────┤
│ COVERAGE SCORE /13      │    0      │   1  │   11      │   11     │   3   │
└─────────────────────────┴───────────┴──────┴───────────┴──────────┴───────┘

(a) ::: {custom-style="StyleName"}      Fenced divs
(b) [text]{custom-style="StyleName"}    Bracketed spans
(c) Via attributes: {.class key=val}    Attribute syntax
(d) \newpage  or  ::: {.pagebreak}      Raw LaTeX or div
(e) Grid tables support col/row span    But complex syntax
(f) ![caption](img){width=50%}          Image attributes
(g) pandoc-crossref filter              External filter
(h) ```{=openxml}\n<raw OOXML>```      Raw block injection
(i) NO dialect supports this            → sidecar JSON only
```

#### Decide: Pandoc Extended Markdown + Style Sidecar

**Pandoc's Extended Markdown** is the only dialect that supports **named style annotation** at both paragraph and character levels via the `custom-style` attribute. This is the critical differentiator.

The key Pandoc extensions required:

```
┌──────────────────────────────────────────────────────────────────┐
│               Required Pandoc Extensions                         │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  fenced_divs          Block-level style: ::: {custom-style="X"}  │
│  bracketed_spans      Inline style: [text]{custom-style="X"}     │
│  yaml_metadata_block  Document metadata in YAML front matter     │
│  footnotes            [^id]: Footnote content                    │
│  grid_tables          Tables with cell spanning                  │
│  fenced_code_attrs    Code blocks with language + attributes     │
│  raw_attribute        ```{=openxml} for raw OOXML injection      │
│  implicit_figures     Images as figures with captions             │
│  link_attributes      ![](img){width=X height=Y}                 │
│  definition_lists     Term : Definition                          │
│  header_attributes    # Heading {#id .class}                     │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

**But Pandoc MD alone is not sufficient for lossless round-tripping.** Two gaps remain:

1. **Headers/footers** — No Markdown dialect can represent these. Stored in `styles.json` sidecar.
2. **Direct formatting overrides** — When a run has bold applied *directly* (not via style), Pandoc MD captures it as `**text**`, but loses the distinction between style-bold vs. direct-bold.
3. **Complex table merging** — Grid tables handle simple spans, but complex nested merges require raw OOXML fallback.

The solution is a **three-file architecture**:

```
┌────────────────────────────────────────────────────────────────┐
│              Lossless Round-Trip Architecture                   │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│   ┌──────────────┐                                             │
│   │ content.md   │  Pandoc Extended Markdown                   │
│   │              │  • Text, structure, inline formatting        │
│   │              │  • Named styles via custom-style attrs       │
│   │              │  • Footnotes, cross-refs, images             │
│   │              │  • Raw OOXML blocks for edge cases           │
│   └──────┬───────┘                                             │
│          │                                                     │
│   ┌──────┴───────┐                                             │
│   │ styles.json  │  Style definition sidecar (our schema)      │
│   │              │  • Full style properties (fonts, spacing...) │
│   │              │  • Inheritance DAG                           │
│   │              │  • Numbering definitions                     │
│   │              │  • Theme colors and fonts                    │
│   │              │  • Headers/footers content                   │
│   │              │  • Section/page layout properties             │
│   └──────┬───────┘                                             │
│          │                                                     │
│   ┌──────┴───────┐                                             │
│   │ media/       │  Extracted media assets                     │
│   │              │  • Images (original resolution)              │
│   │              │  • Embedded objects                          │
│   └──────────────┘                                             │
│                                                                │
│   Round-trip guarantee:                                        │
│   extract(doc.docx) → {content.md, styles.json, media/}       │
│   apply(content.md, styles.json, media/) → doc_rebuilt.docx    │
│   visual_diff(doc.docx, doc_rebuilt.docx) ≤ ε                  │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

#### Act: Concrete Markdown Syntax for Each DOCX Layer

**L1 — Paragraph Styles** (via fenced divs):

```markdown
::: {custom-style="Heading 1"}
Chapter Title
:::

::: {custom-style="Body Text"}
This paragraph uses the Body Text style from the template.
:::

::: {custom-style="Block Quote"}
A styled blockquote that maps to a specific DOCX style,
not just the generic Markdown > syntax.
:::
```

**L2 — Character Styles** (via bracketed spans):

```markdown
This sentence has [emphasized text]{custom-style="Subtle Emphasis"}
and [strong text]{custom-style="Intense Reference"} using named styles.

Direct formatting is still available: **bold** and *italic*.
The distinction is preserved: style-applied vs. direct-applied.
```

**L3 — Structural** (via raw blocks + metadata):

```markdown
---
title: "Document Title"
author: "Raphaël Mansuy"
date: 2026-04-12
section-layout:
  orientation: portrait
  margin-top: 2.54cm
  margin-bottom: 2.54cm
---

Content of section 1.

```

<w:p><w:r><w:br w:type="page"/></w:r></w:p>

```

Content of section 2 (after page break).
```

**L4 — References**:

```markdown
See the analysis below[^1] for details.

[^1]: This is a footnote that will render as a Word footnote.

Refer to [Chapter 3](#chapter-3) for the methodology.
```

**L5 — Embedded Objects**:

```markdown
![Figure 1: System Architecture](media/architecture.png){width=80%}

| Header 1 | Header 2 | Header 3 |
|:---------|:--------:|----------|
| Cell     | Merged   |          |
| Data     | Data     | Data     |

$$E = mc^2$$
```

### First Principles: Why This Architecture is Lossless

```
┌──────────────────────────────────────────────────────────────┐
│         Information Partitioning Theorem                      │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  A .docx document D contains three orthogonal info channels: │
│                                                              │
│  D = C(content) ⊕ S(styling) ⊕ M(media)                     │
│                                                              │
│  Where:                                                      │
│    C = text + structure + references + semantic annotations  │
│    S = style definitions + inheritance + layout + theme      │
│    M = binary media assets (images, embeddings)              │
│                                                              │
│  Lossless round-trip requires:                               │
│    encode(D) = encode(C) ∪ encode(S) ∪ encode(M)            │
│    decode(encode(C), encode(S), encode(M)) ≈ D              │
│                                                              │
│  Our mapping:                                                │
│    encode(C) → content.md    (Pandoc Extended Markdown)      │
│    encode(S) → styles.json   (Pydantic schema, §4)           │
│    encode(M) → media/        (binary files, untransformed)   │
│                                                              │
│  No single file can encode all three channels without        │
│  either losing information or becoming unreadable.           │
│  The three-file split is the MINIMAL lossless partition.      │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

The key insight from rate-distortion theory: **trying to encode S (styling) into C (content) increases rate (complexity) without reducing distortion (loss)**. Keeping them separate is the knee-point solution — maximum fidelity, minimum coupling.

### Why Not Other Dialects?

```
┌─────────────┬───────────────────────────────────────────────────┐
│  Dialect     │  Rejection Reason                                 │
├─────────────┼───────────────────────────────────────────────────┤
│ CommonMark  │ No attribute syntax. Cannot annotate styles.       │
│             │ Structural only (headings, lists, emphasis).       │
│             │ Fatal gap: no custom-style equivalent.             │
├─────────────┼───────────────────────────────────────────────────┤
│ GFM         │ Adds tables + task lists + strikethrough.          │
│             │ Still no attribute syntax or style annotations.    │
│             │ Same fatal gap as CommonMark.                      │
├─────────────┼───────────────────────────────────────────────────┤
│ Djot        │ Designed to fix MD ambiguities. Cleaner grammar.   │
│             │ Has {.class} attrs but NO custom-style convention.  │
│             │ No DOCX writer exists. No ecosystem for .docx.     │
├─────────────┼───────────────────────────────────────────────────┤
│ AsciiDoc    │ Rich semantics: roles, admonitions, includes.      │
│             │ Comparable coverage to Pandoc MD (11/13).           │
│             │ BUT: weaker DOCX toolchain. Asciidoctor outputs    │
│             │ via DocBook → DOCX (two-hop, more loss).           │
│             │ No direct custom-style ↔ DOCX style bridge.        │
├─────────────┼───────────────────────────────────────────────────┤
│ MyST        │ Sphinx-ecosystem. Excellent for RST-style roles.   │
│             │ Jupyter-oriented. No DOCX-native pipeline.         │
│             │ Would require building a custom writer from scratch.│
├─────────────┼───────────────────────────────────────────────────┤
│ Pandoc MD   │ SELECTED. Only dialect with:                       │
│  (extended) │  1. custom-style attr (block + inline)             │
│             │  2. Raw OOXML injection escape hatch               │
│             │  3. Mature DOCX reader AND writer                  │
│             │  4. Proven round-trip path (docx+styles ext)       │
│             │  5. Programmable via filters (Lua/Python)           │
└─────────────┴───────────────────────────────────────────────────┘
```

### Explicit Loss Budget

Even with the three-file architecture, some DOCX features have **no lossless Markdown encoding**. These are declared explicitly:

```
┌──────────────────────┬──────────┬──────────────────────────────┐
│  Feature             │ Fidelity │  Encoding Strategy            │
├──────────────────────┼──────────┼──────────────────────────────┤
│ Paragraph styles     │ LOSSLESS │ custom-style fenced div       │
│ Character styles     │ LOSSLESS │ custom-style bracketed span   │
│ Direct bold/italic   │ LOSSLESS │ **bold** / *italic*           │
│ Footnotes            │ LOSSLESS │ [^id] syntax                  │
│ Images               │ LOSSLESS │ ![](media/x.png){attrs}       │
│ Simple tables        │ LOSSLESS │ pipe/grid tables              │
│ Math equations       │ LOSSLESS │ $...$ / $$...$$               │
│ Page breaks          │ LOSSLESS │ raw openxml block             │
│ Metadata             │ LOSSLESS │ YAML front matter             │
│ Theme / colors       │ LOSSLESS │ styles.json sidecar           │
│ Numbering defs       │ LOSSLESS │ styles.json sidecar           │
├──────────────────────┼──────────┼──────────────────────────────┤
│ Complex table merge  │ NEAR     │ raw openxml fallback          │
│ Image float/anchor   │ NEAR     │ raw openxml fallback          │
│ Headers / footers    │ NEAR     │ styles.json (HTML-like repr)  │
│ Track changes        │ LOSSY    │ Not preserved (accepted only) │
│ Comments/annotations │ LOSSY    │ Not preserved in MD           │
│ Form fields          │ LOSSY    │ Not preserved in MD           │
│ Macros / VBA         │ LOSSY    │ Not preserved (security)      │
└──────────────────────┴──────────┴──────────────────────────────┘
```

---

## §5A Math Formula Support — LaTeX ↔ OMML Round-Trip

### OODA Loop — Math in DOCX

#### Observe: How DOCX Represents Math

DOCX does **not** store math as LaTeX, MathML, or images. It uses a proprietary XML dialect called **OMML (Office Math Markup Language)**, defined in ECMA-376 §22.1, within the `m:` XML namespace.

A DOCX math object is a tree of typed XML elements:

```
┌─────────────────────────────────────────────────────────────────┐
│              OMML Object Model (m: namespace)                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  m:oMathPara   Math paragraph (display mode, centered)         │
│  └─ m:oMath    Math expression container                       │
│     ├─ m:r     Math run (text + properties)                    │
│     ├─ m:f     Fraction        ┌─ m:num (numerator)            │
│     │                          └─ m:den (denominator)          │
│     ├─ m:rad   Radical         ┌─ m:deg (degree, e.g. ³√)     │
│     │                          └─ m:e   (expression under √)   │
│     ├─ m:nary  N-ary operator  ┌─ m:sub (lower limit)          │
│     │          (∑ ∫ ∏ ⋃)       ├─ m:sup (upper limit)          │
│     │                          └─ m:e   (operand)              │
│     ├─ m:sSub  Subscript       ┌─ m:e   (base)                 │
│     │                          └─ m:sub (subscript)            │
│     ├─ m:sSup  Superscript     ┌─ m:e   (base)                 │
│     │                          └─ m:sup (superscript)          │
│     ├─ m:sSubSup  Sub+Super   ┌─ m:e   (base)                 │
│     │                          ├─ m:sub (subscript)            │
│     │                          └─ m:sup (superscript)          │
│     ├─ m:d     Delimiters      ┌─ m:dPr (bracket chars)        │
│     │          (parentheses,   └─ m:e   (enclosed expression)  │
│     │           brackets)                                      │
│     ├─ m:m     Matrix          ┌─ m:mr  (matrix row)           │
│     │                          └─ m:e   (cell)                 │
│     ├─ m:func  Function        ┌─ m:fName (sin, cos, lim...)   │
│     │                          └─ m:e   (argument)             │
│     ├─ m:acc   Accent          (hat, tilde, bar, dot, ddot)    │
│     ├─ m:bar   Overbar/Underbar                                │
│     ├─ m:eqArr Equation array  (aligned multi-line)            │
│     ├─ m:limLow Lower limit    (lim, min, max)                 │
│     ├─ m:limUpp Upper limit                                    │
│     ├─ m:groupChr Grouping character (underbrace, overbrace)   │
│     └─ m:box   Box (isolate expression for line-breaking)      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### Concrete Example: LaTeX vs. OMML

The equation $\frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$ (quadratic formula):

**LaTeX representation** (in Markdown):

```latex
$$\frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$$
```

**OMML representation** (in DOCX XML):

```xml
<m:oMathPara>
  <m:oMath>
    <m:f>                                    <!-- fraction -->
      <m:fPr><m:type m:val="bar"/></m:fPr>
      <m:num>                                 <!-- numerator -->
        <m:r><m:t>-b±</m:t></m:r>
        <m:rad>                               <!-- radical -->
          <m:radPr><m:degHide m:val="1"/></m:radPr>
          <m:deg/>                            <!-- degree hidden = √ -->
          <m:e>                               <!-- expression -->
            <m:sSup>                           <!-- superscript -->
              <m:e><m:r><m:t>b</m:t></m:r></m:e>
              <m:sup><m:r><m:t>2</m:t></m:r></m:sup>
            </m:sSup>
            <m:r><m:t>-4ac</m:t></m:r>
          </m:e>
        </m:rad>
      </m:num>
      <m:den>                                 <!-- denominator -->
        <m:r><m:t>2a</m:t></m:r>
      </m:den>
    </m:f>
  </m:oMath>
</m:oMathPara>
```

**Key insight**: 7 characters of LaTeX expand to ~30 lines of OMML. The compression ratio is ~20:1. LaTeX is a far more efficient encoding, which is why we use it as the intermediate representation in Markdown.

#### Orient: The Three Conversion Paths

```
┌─────────────────────────────────────────────────────────────────┐
│           Math Conversion Paths                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  PATH A: Pandoc Native (RECOMMENDED)                            │
│  ┌──────────┐         ┌──────────┐         ┌──────────┐        │
│  │  LaTeX   │─────────│ Pandoc   │─────────│  OMML    │        │
│  │  $...$   │  parse  │  AST     │  write  │ <m:oMath>│        │
│  │  $$...$$ │─────────│ (Math    │─────────│  in .docx│        │
│  └──────────┘         │  node)   │         └──────────┘        │
│                       └──────────┘                              │
│  Pandoc's DOCX writer has built-in LaTeX→OMML.                 │
│  Pandoc's DOCX reader has built-in OMML→LaTeX.                 │
│  BIDIRECTIONAL. Proven. Zero external dependencies.             │
│                                                                 │
│  PATH B: XSLT Pipeline (FALLBACK)                               │
│  ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐    │
│  │  LaTeX   │──▶│ MathML   │──▶│   XSLT   │──▶│  OMML    │    │
│  │  $...$   │   │ <math>   │   │ MML2OMML │   │ <m:oMath>│    │
│  └──────────┘   └──────────┘   │ .xsl     │   └──────────┘    │
│  latex2mathml   W3C standard   └──────────┘                    │
│  (Python lib)                  Ships with MS Word              │
│                                                                 │
│  PATH C: Direct XML Injection (ESCAPE HATCH)                    │
│  ┌──────────┐         ┌──────────────────────────┐             │
│  │  LaTeX   │────────▶│  python-docx lxml inject │             │
│  │  $...$   │  custom │  raw OMML XML into       │             │
│  └──────────┘  parser │  paragraph.element       │             │
│                       └──────────────────────────┘             │
│  Maximum control. Maximum complexity. For edge cases only.     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### Decide: Path A (Pandoc Native) as Primary

Pandoc already handles the full LaTeX → OMML conversion internally when writing DOCX, and the reverse OMML → LaTeX when reading DOCX. Since our architecture already uses Pandoc as the Markdown engine (§5), math conversion comes **for free** with zero additional code.

Path B (XSLT) is the fallback for cases where:

- We bypass Pandoc (e.g., direct python-docx manipulation)
- We need finer control over OMML generation
- Pandoc mishandles a specific LaTeX construct

Path C is the emergency escape hatch for raw XML injection.

#### Act: Integration into edgemint

```jsx
┌─────────────────────────────────────────────────────────────────┐
│           Math Round-Trip in edgemint                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  EXTRACT (DOCX → Markdown):                                     │
│                                                                 │
│  input.docx                                                     │
│    │                                                            │
│    ├─ text paragraphs ──▶ Markdown text                        │
│    │                                                            │
│    ├─ <m:oMath> inline ──▶ $\frac{a}{b}$        (inline)      │
│    │  (Pandoc DOCX reader automatically converts OMML→LaTeX)   │
│    │                                                            │
│    └─ <m:oMathPara> ─────▶ $$\int_0^\infty ...$$ (display)    │
│       (Pandoc DOCX reader automatically converts OMML→LaTeX)   │
│                                                                 │
│  The extraction pipeline requires NO special math handling.     │
│  Pandoc's -f docx+styles does it natively.                      │
│                                                                 │
│  ─────────────────────────────────────────────────────────────  │
│                                                                 │
│  APPLY (Markdown → DOCX):                                       │
│                                                                 │
│  content.md                                                     │
│    │                                                            │
│    ├─ $E = mc^2$ ─────────▶ <m:oMath> inline in <w:p>          │
│    │  (Pandoc DOCX writer converts LaTeX→OMML)                 │
│    │                                                            │
│    └─ $$\sum_{i=1}^{n}$$ ─▶ <m:oMathPara> display block       │
│       (Pandoc DOCX writer converts LaTeX→OMML)                 │
│                                                                 │
│  The apply pipeline requires NO special math handling.          │
│  Pandoc's -t docx does it natively.                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### First Principles: Why LaTeX is the Correct Intermediate

```
┌──────────────────────────────────────────────────────────────┐
│         Math Representation Comparison                        │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Representation  │ Encoding   │ Human    │ Tooling  │ Round │
│                  │ Efficiency │ Readable │ Support  │ Trip  │
│  ────────────────┼────────────┼──────────┼──────────┼────── │
│  LaTeX           │ ★★★★★     │ ★★★★    │ ★★★★★   │ ★★★★ │
│  ($\frac{a}{b}$)│ ~10 chars  │ Yes      │ Pandoc,  │ Yes   │
│                  │            │          │ KaTeX,   │       │
│                  │            │          │ MathJax  │       │
│  ────────────────┼────────────┼──────────┼──────────┼────── │
│  MathML          │ ★★        │ ★★      │ ★★★     │ ★★★  │
│  (<mfrac>)       │ ~80 chars  │ Verbose  │ W3C std  │ XSLT  │
│                  │            │          │ browsers │       │
│  ────────────────┼────────────┼──────────┼──────────┼────── │
│  OMML            │ ★★        │ ★       │ ★★      │ N/A   │
│  (<m:f>)         │ ~100 chars │ Opaque   │ MS only  │ Dest  │
│                  │            │          │          │ only  │
│  ────────────────┼────────────┼──────────┼──────────┼────── │
│  UnicodeMath     │ ★★★★     │ ★★★    │ ★       │ ★    │
│  (a/b)           │ ~8 chars   │ Yes      │ Word     │ Lossy │
│                  │            │          │ only     │       │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

From rate-distortion theory: LaTeX has the **best compression ratio** (lowest rate) with **near-zero information loss** (lowest distortion) for mathematical expressions. It encodes structural semantics (fraction, integral, subscript) in a human-readable, diff-friendly text format.

OMML is the **destination format** — necessary for Word's equation editor to render and allow editing. But it's a terrible intermediate format: verbose, opaque, and tied to a single vendor.

**Decision**: LaTeX in Markdown (`$...$` / `$$...$$`) is the canonical math representation. Conversion to OMML happens at DOCX generation time only.

### OMML Element Coverage for Complex Math

The following table maps LaTeX constructs to their OMML counterparts, with Pandoc's conversion fidelity:

```
┌───────────────────────────┬──────────────────┬──────────┬───────────┐
│  LaTeX Construct          │ OMML Element     │ Pandoc   │ Fidelity  │
├───────────────────────────┼──────────────────┼──────────┼───────────┤
│ \frac{a}{b}              │ m:f              │ ✓ native │ LOSSLESS  │
│ \sqrt{x}, \sqrt[3]{x}   │ m:rad + m:deg    │ ✓ native │ LOSSLESS  │
│ x^2, x_i                 │ m:sSup, m:sSub   │ ✓ native │ LOSSLESS  │
│ x_i^2                    │ m:sSubSup        │ ✓ native │ LOSSLESS  │
│ \sum_{i=0}^{n}           │ m:nary (∑)       │ ✓ native │ LOSSLESS  │
│ \int_0^{\infty}          │ m:nary (∫)       │ ✓ native │ LOSSLESS  │
│ \prod, \coprod           │ m:nary (∏)       │ ✓ native │ LOSSLESS  │
│ \lim_{x→0}               │ m:func + m:limLow│ ✓ native │ LOSSLESS  │
│ \sin, \cos, \log         │ m:func           │ ✓ native │ LOSSLESS  │
│ \hat{x}, \tilde{x}      │ m:acc            │ ✓ native │ LOSSLESS  │
│ \overline{x}             │ m:bar            │ ✓ native │ LOSSLESS  │
│ \underbrace{x}_{text}    │ m:groupChr       │ ✓ native │ LOSSLESS  │
│ \left( ... \right)       │ m:d + m:dPr      │ ✓ native │ LOSSLESS  │
│ \begin{pmatrix}...       │ m:m + m:mr       │ ✓ native │ LOSSLESS  │
│ \begin{cases}...         │ m:d + m:eqArr    │ ✓ native │ LOSSLESS  │
│ \begin{aligned}...       │ m:eqArr          │ ✓ native │ LOSSLESS  │
│ \mathbb{R}, \mathcal{L}  │ m:r + m:rPr(scr) │ ✓ native │ LOSSLESS  │
│ \text{...}               │ m:r + w:rPr      │ ✓ native │ LOSSLESS  │
├───────────────────────────┼──────────────────┼──────────┼───────────┤
│ \xrightarrow{text}       │ m:acc (fallback)  │ ⚠ approx│ NEAR      │
│ \cancel{x}               │ (no OMML equiv)  │ ✗ lost  │ LOSSY     │
│ \tikz diagrams           │ (no OMML equiv)  │ ✗ lost  │ LOSSY     │
│ Custom \newcommand       │ (must expand)     │ ⚠ expand│ NEAR      │
│ \label / \ref (eq nums)  │ w:bookmarkStart  │ ⚠ filter│ NEAR      │
└───────────────────────────┴──────────────────┴──────────┴───────────┘
```

### Fallback: XSLT Pipeline for Non-Pandoc Path

When bypassing Pandoc (e.g., direct python-docx assembly), we need our own LaTeX → OMML converter:

```python
import latex2mathml.converter
from lxml import etree

# Open-source XSLT (transpect project, BSD-2-Clause license)
# NOT Microsoft's proprietary version (NOT redistributable)
MML2OMML_XSL = "edgemint/math/xslt/mml2omml.xsl"

def latex_to_omml(latex: str) -> etree._Element:
    """Convert LaTeX math string to OMML XML element.
    
    Pipeline: LaTeX → MathML → OMML (via XSLT)
    """
    # Step 1: LaTeX → MathML
    mathml_str = latex2mathml.converter.convert(latex)
    
    # Step 2: MathML → OMML (via Microsoft's XSLT)
    mathml_tree = etree.fromstring(mathml_str.encode())
    xslt = etree.parse(MML2OMML_XSL)
    transform = etree.XSLT(xslt)
    omml_tree = transform(mathml_tree)
    
    return omml_tree.getroot()

def omml_to_latex(omml_element: etree._Element) -> str:
    """Convert OMML XML element back to LaTeX string.
    
    Pipeline: OMML → MathML (via XSLT) → LaTeX
    """
    # Step 1: OMML → MathML (reverse XSLT)
    xslt = etree.parse("path/to/OMML2MML.xsl")
    transform = etree.XSLT(xslt)
    mathml_tree = transform(omml_element)
    
    # Step 2: MathML → LaTeX (custom or via flatlatex/mathml2latex)
    return mathml_to_latex(mathml_tree)  # implementation in utils/
```

### Updated Module Structure (Math Addition)

```jsx
edgemint/
├── ...
├── math/
│   ├── __init__.py
│   ├── converter.py        # latex_to_omml() and omml_to_latex()
│   ├── xslt/
│   │   ├── mml2omml.xsl    # transpect project (BSD-2-Clause)
│   │   └── omml2mml.xsl    # TEI Stylesheets (CC-SA/BSD)
│   └── mathml_latex.py     # MathML ↔ LaTeX helpers
└── ...
```

### Updated Loss Budget (Math Row)

```
┌──────────────────────┬──────────┬──────────────────────────────┐
│  Feature             │ Fidelity │  Encoding Strategy            │
├──────────────────────┼──────────┼──────────────────────────────┤
│ Inline math          │ LOSSLESS │ $...$ → m:oMath (via Pandoc) │
│ Display math         │ LOSSLESS │ $$...$$ → m:oMathPara        │
│ Fractions, radicals  │ LOSSLESS │ \frac, \sqrt → m:f, m:rad   │
│ Integrals, sums      │ LOSSLESS │ \int, \sum → m:nary          │
│ Matrices             │ LOSSLESS │ pmatrix → m:m + m:mr         │
│ Aligned equations    │ LOSSLESS │ aligned → m:eqArr            │
│ Script styles        │ LOSSLESS │ \mathbb → m:rPr(scr)         │
│ Equation numbering   │ NEAR     │ Requires pandoc-crossref     │
│ Custom LaTeX macros  │ NEAR     │ Must pre-expand before conv  │
│ TikZ / PGF diagrams  │ LOSSY    │ No OMML equiv → rasterize    │
│ \cancel (strikeout)  │ LOSSY    │ No OMML equiv                │
└──────────────────────┴──────────┴──────────────────────────────┘
```

---

## §5B First Principles Decomposition

### What is a DOCX style, fundamentally?

A `.docx` file is a ZIP archive containing XML. A **style** is a named node in `word/styles.xml` that encodes a set of formatting properties. Styles form an **inheritance DAG** via `w:basedOn` links.

```
          ┌──────────────┐
          │  Default     │  (implicit root)
          │  Properties  │
          └──────┬───────┘
                 │
          ┌──────▼───────┐
          │   Normal     │  base paragraph style
          └──┬───────┬──┘
             │       │
    ┌────────▼──┐  ┌─▼──────────┐
    │ Heading 1  │  │ Body Text   │
    └────┬───────┘  └─────┬──────┘
         │                │
┌────────▼──┐    ┌───────▼───────┐
│ Heading 2  │    │ Body Text 2   │
└───────────┘    └───────────────┘
```

**Insight**: Extraction must walk this DAG to produce both **local** (what the style itself defines) and **resolved** (effective after inheritance) property sets. The JSON includes both to enable both exact reproduction and human understanding.

### The round-trip invariant

```
Let S = extract(template.docx)
Let M = markdown content
Let D = apply(M, S)

Then: visual_render(D) ≈ visual_render(manual_styling(M, template.docx))
```

The approximation bound is controlled by the **completeness of S** — hence the lossless requirement.

---

## §6 SOLID & DRY Design

### Module Structure

```jsx
edgemint/
├── __init__.py
├── cli.py                  # Click-based CLI entry point
├── schema/
│   ├── __init__.py
│   ├── models.py           # Pydantic models (StyleSheet, Style, Font, ParagraphFormat)
│   └── validators.py       # Custom validators, enums
├── extract/
│   ├── __init__.py
│   ├── parser.py           # StyleParser: .docx → StyleSheet
│   ├── resolver.py         # InheritanceResolver: walk based_on DAG
│   ├── theme.py            # ThemeExtractor: parse theme1.xml
│   ├── numbering.py        # NumberingExtractor: parse numbering.xml
│   ├── section_properties.py # SectionPropertiesExtractor: page layout
│   ├── headers_footers.py  # HeaderFooterExtractor: raw OOXML preservation
│   ├── doc_defaults.py     # DocDefaultsExtractor: w:docDefaults root
│   ├── core_properties.py  # CorePropertiesExtractor: OPC metadata
│   └── orchestrator.py     # extract_styles() pipeline glue
├── apply/
│   ├── __init__.py
│   ├── builder.py          # DocBuilder: orchestrates Pandoc + PostProcessor
│   ├── reference.py        # Build reference.docx from styles.json
│   └── pandoc_runner.py    # Pandoc subprocess wrapper with version pinning
├── postprocess/
│   ├── __init__.py
│   ├── dedup_styles.py     # Fix Pandoc duplicate style bug (§16 RB-2)
│   ├── fix_lists.py        # Fix list paragraph styles (§16 RB-5)
│   ├── inject_styles.py    # Inject styles.json into word/styles.xml
│   ├── inject_headers.py   # Inject headers/footers from styles.json
│   └── validate.py         # Output validation (duplicates, broken refs)
├── math/
│   ├── __init__.py
│   ├── converter.py        # latex_to_omml() and omml_to_latex()
│   ├── xslt/
│   │   ├── mml2omml.xsl    # transpect project (BSD-2-Clause)
│   │   └── omml2mml.xsl    # TEI Stylesheets (CC-SA/BSD)
│   └── mathml_latex.py     # MathML ↔ LaTeX helpers
├── filters/
│   ├── fix-lists.lua       # Pandoc Lua filter: list style fix
│   └── fix-styles.lua      # Pandoc Lua filter: style normalization
├── diff/
│   ├── __init__.py
│   └── comparator.py       # StyleComparator: diff two JSONs
└── utils/
    ├── __init__.py
    └── security.py          # ZIP bomb detection, XXE prevention
```

### SOLID Mapping

| **Principle** | **Application** | **Concrete Example** |
| --- | --- | --- |
| **S** — Single Responsibility | Each module owns one concern | `resolver.py` only walks inheritance; `parser.py` only reads XML→model |
| **O** — Open/Closed | New style types via extension, not modification | `StyleParser` uses a registry of `PropertyExtractor` handlers; add table style support by registering a new extractor |
| **L** — Liskov Substitution | Single `Style` model with type discriminator | `Style(type=PARAGRAPH)`, `Style(type=CHARACTER)`, `Style(type=TABLE)` share the same interface; optional fields (`paragraph_format`, `font`) vary by type |
| **I** — Interface Segregation | CLI, extract, apply are independent entry points | `extract` never imports from `apply`; shared types live in `schema/` |
| **D** — Dependency Inversion | High-level modules depend on abstractions | `DocBuilder` depends on `StyleSheet` (Pydantic model), not on `python-docx` internals. The `python-docx` adapter is injected. |

### DRY Enforcement

- **Unit conversions**: Single `validators.py` module in `schema/`. EMU↔pt↔inch↔cm conversions. Used everywhere, defined once.
- **XML namespace map**: Uses python-docx’s built-in `qn()` (qualified name) helper. No inline namespace strings.
- **Property extraction**: Each property category (font, paragraph, border) has one extractor function reused across style types.
- **Pydantic models**: The JSON schema is derived from models, not hand-maintained. `StyleSheet.model_json_schema()` generates the `$schema`.
- **Post-processing**: All Pandoc bug workarounds live in `postprocess/` — isolated, testable, and removable when Pandoc fixes the upstream bugs.

---

## §6A Security Model

DOCX files are ZIP archives from untrusted sources. The tool must defend against common attack vectors.

```
┌─────────────────────────────────────────────────────────────────┐
│                    Threat Model                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  THREAT 1: ZIP Bomb                                             │
│  Attack: DOCX with 1KB compressed → 10GB decompressed           │
│  Defense: Check compression ratio before extraction.            │
│           Reject files with ratio > 100:1 or decompressed       │
│           size > 500MB. Use zipfile with size limits.            │
│                                                                 │
│  THREAT 2: XML External Entity (XXE) Injection                  │
│  Attack: Crafted styles.xml with <!ENTITY> referencing           │
│          file:///etc/passwd or http://attacker.com/exfil         │
│  Defense: Use defusedxml or lxml with resolve_entities=False.   │
│           NEVER use xml.etree.ElementTree for untrusted input.   │
│           lxml default is safe; explicitly set no_network=True.  │
│                                                                 │
│  THREAT 3: Path Traversal in Media                              │
│  Attack: Media file named "../../etc/cron.d/backdoor"           │
│  Defense: Sanitize all media filenames. Strip path components.  │
│           Write only to the designated media/ output directory.   │
│           Reject filenames with '..' or absolute paths.          │
│                                                                 │
│  THREAT 4: Resource Exhaustion                                  │
│  Attack: Document with 10,000 styles or 500MB images            │
│  Defense: --max-styles (default 500), --max-media-size           │
│           (default 100MB per file), --max-total-size (1GB).     │
│                                                                 │
│  THREAT 5: Malicious OMML / Raw XML                             │
│  Attack: Crafted OMML with script injection or XSLT exploits   │
│  Defense: XSLT transforms run in sandboxed lxml context.        │
│           No network access during transforms. Validate output. │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Implementation**: All security checks live in `utils/security.py` — imported by every module that reads untrusted input. Security tests (T22–T24) verify each defense.

---

## §7 CLI Interface

```bash
# Phase 1: Extract styles from a .docx template
$ edgemint extract-styles template.docx -o styles.json
$ edgemint extract-styles template.docx --resolved  # include inheritance-resolved props
$ edgemint extract-styles template.docx --filter paragraph  # only paragraph styles

# Phase 2: Generate .docx from Markdown using extracted styles
$ edgemint apply-styles content.md styles.json -o output.docx
$ edgemint apply-styles content.adoc styles.json -o output.docx

# Utility: Diff two style sheets
$ edgemint diff styles-v1.json styles-v2.json

# Utility: Validate a style JSON against schema
$ edgemint validate styles.json

# Utility: Quick inspection of a .docx file's styles
$ edgemint info template.docx

# Utility: Export JSON Schema for IDE integration
$ edgemint schema > edgemint-schema.json
```

### CLI Framework: `click` + `rich`

- `click` for argument parsing (composable, testable)
- `rich` for terminal output (tables, progress bars, diff highlighting)
- Exit codes: 0 = success, 1 = validation error, 2 = file error, 3 = schema mismatch, 4 = Pandoc error, 5 = security error

### Pandoc Integration

The CLI wraps Pandoc (via `pypandoc` or subprocess) for the heavy lifting of Markdown ↔ AST conversion, then applies our style enrichment layer on top:

```bash
# Full round-trip extraction
$ edgemint extract report.docx -o project/
#   → project/content.md      (Pandoc MD with custom-style attrs)
#   → project/styles.json     (full style definitions)
#   → project/media/          (images, embeddings)

# Full round-trip regeneration
$ edgemint apply-styles project/content.md project/styles.json -o report_rebuilt.docx --media project/media
#   Reads content.md + styles.json + media/
#   Produces styled .docx

# Extract styles only (original behavior)
$ edgemint extract-styles template.docx -o styles.json
```

---

## §8 Key Implementation Details

### Style Inheritance Resolution Algorithm

```python
def resolve_style(style: Style, style_map: dict[str, Style]) -> ResolvedProperties:
    """Walk the based_on chain, merge properties bottom-up.
    
    Later (more specific) properties override earlier (base) ones.
    This is identical to CSS cascade resolution.
    """
    chain = []
    current = style
    visited = set()  # cycle detection
    
    while current:
        if current.style_id in visited:
            break  # malformed doc, break cycle
        visited.add(current.style_id)
        chain.append(current)
        current = style_map.get(current.based_on)
    
    # Merge from root → leaf (base → specific)
    resolved = ResolvedProperties()
    for ancestor in reversed(chain):
        resolved.merge(ancestor.local_properties)
    
    return resolved
```

### Markdown → Style Mapping (Default)

```
┌─────────────────────┬──────────────────────┐
│  Markdown Element    │  DOCX Style Name     │
├─────────────────────┼──────────────────────┤
│  # Heading          │  Heading 1           │
│  ## Heading         │  Heading 2           │
│  ### Heading        │  Heading 3           │
│  Paragraph          │  Normal              │
│  > Blockquote       │  Quote               │
│  - List item        │  List Bullet         │
│  1. List item       │  List Number         │
│  `code`             │  Code (character)    │
│  ```code block```   │  Code Block          │
│  **bold**           │  Strong (character)  │
│  *italic*           │  Emphasis (character)│
└─────────────────────┴──────────────────────┘
```

This mapping is **configurable** via an optional `mapping.json` override file, satisfying Open/Closed.

---

## §9 Dependencies

```toml
[project]
name = "edgemint"
version = "0.1.0"
requires-python = ">=3.11"
description = "Lossless DOCX style extraction and style-faithful Markdown→DOCX regeneration"
license = {text = "Apache-2.0"}

[project.dependencies]
python-docx = ">=1.1.0"       # Core DOCX read/write + style access
pydantic = ">=2.0"             # Schema models + JSON serialization
click = ">=8.0"                # CLI framework
rich = ">=13.0"                # Terminal output (tables, progress, diff)
lxml = ">=4.9"                 # XML parsing, XSLT transforms, XPath
latex2mathml = ">=3.0"         # Fallback LaTeX→MathML (Path B)

[project.optional-dependencies]
pandoc = [
    "pypandoc>=1.13",          # Pandoc Python wrapper
    "pypandoc_binary>=1.13",   # Auto-downloads Pandoc binary
]
dev = [
    "pytest>=7.0",
    "pytest-cov",
    "ruff>=0.4",               # Linting + formatting
    "mypy>=1.10",              # Type checking
    "pypandoc>=1.13",          # Pandoc integration tests
    "pypandoc_binary>=1.13",
]

[project.scripts]
edgemint = "edgemint.cli:main"
```

**Install profiles**:

- `pip install edgemint` — Style extraction only (pure Python, no Pandoc)
- `pip install edgemint[pandoc]` — Full pipeline (auto-installs Pandoc ~150MB)
- `pip install edgemint[dev]` — Development with all test dependencies

---

## §10 Testing Strategy

```
┌──────────────────────────────────────────────────┐
│                 Test Pyramid                      │
├──────────────────────────────────────────────────┤
│                                                  │
│          ┌──────────────┐                        │
│          │  E2E (3-5)   │  Round-trip: .docx →   │
│          │              │  JSON → .md → .docx    │
│          └──────┬───────┘  visual diff ≤ ε       │
│           ┌─────┴──────┐                         │
│           │ Integration │  Extract real .docx     │
│           │   (10-15)   │  templates, validate    │
│           │             │  JSON schema            │
│           └──────┬──────┘                         │
│        ┌─────────┴──────────┐                    │
│        │    Unit (40-60)     │  Each extractor,   │
│        │                     │  resolver, mapper   │
│        │                     │  tested in isolation│
│        └─────────────────────┘                    │
│                                                  │
└──────────────────────────────────────────────────┘
```

**Golden file tests**: Maintain a set of `.docx` templates with known styles. Extract → compare against committed `.json` golden files. Any regression = broken test.

### Specific Test Cases Required

```
┌───────────────────────────────────────────────────────────────────────┐
│                    Mandatory Test Matrix                              │
├───────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  STYLE EXTRACTION                                                     │
│  ├─ T01: Extract all paragraph styles from a 20-style template       │
│  ├─ T02: Extract character styles with based_on chain (3 levels)     │
│  ├─ T03: Resolve theme-dependent fonts (majorHAnsi → actual font)    │
│  ├─ T04: Extract numbering definitions (3 list styles)               │
│  ├─ T05: Extract from LibreOffice-generated DOCX (non-standard)     │
│  ├─ T06: Extract from Google Docs-exported DOCX                      │
│  └─ T07: Handle corrupted DOCX (missing styles.xml) gracefully       │
│                                                                       │
│  ROUND-TRIP FIDELITY                                                  │
│  ├─ T08: extract → apply → re-extract: styles.json must match        │
│  ├─ T09: Style deduplication: no duplicate style IDs in output       │
│  ├─ T10: List items use List Paragraph, not Normal                   │
│  ├─ T11: Images survive round-trip (binary identical)                │
│  └─ T12: Math equations survive round-trip (LaTeX ≈ LaTeX)           │
│                                                                       │
│  MATH                                                                 │
│  ├─ T13: Inline $E=mc^2$ → OMML → LaTeX round-trip                  │
│  ├─ T14: Display $$\sum_{i=1}^n$$ → OMML → LaTeX round-trip         │
│  ├─ T15: Matrix (pmatrix) → OMML → LaTeX round-trip                  │
│  └─ T16: Nested fractions with radicals                              │
│                                                                       │
│  EDGE CASES                                                          │
│  ├─ T17: Non-English locale style names (German, Japanese)           │
│  ├─ T18: RTL document (Arabic) paragraph direction preserved         │
│  ├─ T19: Legacy OLE equation objects detected and warned              │
│  ├─ T20: ZIP bomb detection (< 100:1 compression ratio limit)        │
│  └─ T21: Document with 100+ styles (performance < 5s)                │
│                                                                       │
│  SECURITY                                                             │
│  ├─ T22: XXE attack via crafted styles.xml → blocked by defusedxml   │
│  ├─ T23: Path traversal in media filenames (../../etc/passwd)         │
│  └─ T24: Oversized media file skipped with --max-media-size          │
│                                                                       │
└───────────────────────────────────────────────────────────────────────┘
```

---

## §11 Rate-Distortion Analysis

Applying §7 of the Constitution:

- **Rate** (complexity cost): 6 dependencies, ~2500 LoC estimated, 7 subcommands (extract-styles, extract, apply-styles, diff, validate, info, schema) + Pandoc integration.
- **Distortion** (information loss): Zero on text+styles+media. Declared lossy on track changes, comments, form fields, VBA (see §5 Loss Budget). This is an explicit, auditable loss boundary — not a silent degradation.
- **Knee point assessment**: The three-file architecture ([content.md](http://content.md) + styles.json + media/) captures ~95% of practical round-trip fidelity with ~35% of the complexity of a full OOXML reimplementation. The remaining 5% (complex table merging, header/footer templating) is handled via raw OOXML escape hatches — available but not required for common workflows.
- **Key insight**: Separating content (Markdown) from styling (JSON) from assets (binary files) is the information-theoretic minimum partition for lossless encoding. Trying to merge S into C increases rate without reducing distortion.

---

## §12 Sovereignty Check

- [x]  **Scales without Raphaël's time**: Once built, it's a CLI tool. No ongoing human dependency.
- [x]  **No IP contamination**: Reusable IP — no client-specific logic.
- [x]  **No leverage transfer**: Open-source friendly (Apache-2.0); original owner retains copyright.
- [x]  **Complexity justified**: Solves a real, recurring need in document automation pipelines.
- [x]  **Shift alignment**: This is Shift 1 (Sovereign Builder) work — deep asset creation.

---

## §13 Milestones

| **Phase** | **Deliverable** | **Acceptance Criteria** | **Estimate** |
| --- | --- | --- | --- |
| Phase 1 | `extract-styles` — .docx → styles.json (pure Python, no Pandoc) | T01–T07 pass. All paragraph, character, table styles extracted with inheritance resolution. Theme fonts resolved. Non-standard DOCX handled gracefully. | 1.5 days |
| Phase 2 | `extract` (full) — .docx → project/ dir ([content.md](http://content.md)  • styles.json + media/) | T08, T11, T12 pass. Pandoc integration working. Math round-trips. Media files binary identical. | 1.5 days |
| Phase 3 | `apply-styles` — [content.md](http://content.md)  • styles.json → .docx with PostProcessor pipeline | T08–T12 pass (full round-trip). Style deduplication working. List styles correct. Headers/footers injected. | 2 days |
| Phase 4 | `diff`  • `validate`  • CI + golden file test suite + Docker image | T17–T24 pass. Security tests pass. CI green on Python 3.11/3.12/3.13. Docker image builds and runs. | 1 day |
| Phase 5 (opt.) | AsciiDoc input, table style extraction, Rust hot path, PyInstaller binary | Benchmarks show < 2s for 50-page document. Single-binary distribution working. | TBD |

---

## §14 Decision

**Build `edgemint` in Python using `python-docx` + Pandoc + Pydantic + Click.**

**Intermediate format**: Pandoc Extended Markdown with `custom-style` attributes (fenced divs for paragraph styles, bracketed spans for character styles) + JSON style sidecar + media folder.

This three-file architecture is the minimal lossless partition of DOCX content. Pandoc provides the only Markdown dialect with bidirectional `custom-style` ↔ DOCX style mapping. The JSON schema is the contract that decouples extraction from generation, enabling future language ports without breaking the pipeline.

---

## §16 Edge Cases, Roadblocks & Mitigations — Fact-Checked

Every claim in this specification has been validated against current library versions, open GitHub issues, and real-world usage reports. This section documents **what can go wrong**, **what was corrected**, and **how to mitigate**.

### Fact-Check Register

```jsx
┌──────────────────────────┬─────────┬───────────────────────────────────────┐
│  Claim                    │ Verdict │ Detail                                │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ python-docx v1.2.0       │ ✅ TRUE │ Confirmed on PyPI (Jun 16, 2025)       │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ python-docx has full     │ ⚠️ NUANCE│ Style read/write: YES. Math/OMML:      │
│ style access              │         │ NO native support. Issue #213 open    │
│                          │         │ since 2015. Must inject raw XML.       │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ Pandoc custom-style      │ ⚠️ NUANCE│ Works bidirectionally BUT creates      │
│ is lossless              │         │ DUPLICATE styles instead of reusing   │
│                          │         │ existing ones from reference.docx.     │
│                          │         │ Must post-process to deduplicate.      │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ Pandoc list styles       │ ❌ BUG   │ Pandoc applies "Normal" to list items  │
│ use List Paragraph       │         │ instead of "List Paragraph". Open      │
│                          │         │ issue #7280, confirmed through v3.8.3.   │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ Pandoc 3.5+ reference    │ ⚠️ BUG   │ Issue #10282: Pandoc 3.5+ loses custom │
│ doc style preservation   │         │ title/subtitle formatting from         │
│                          │         │ reference.docx. Pin Pandoc version.    │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ MML2OMML.xsl "ships      │ ❌ WRONG │ Ships with Word but NOT redistribut-  │
│ with MS Word"            │         │ able under MS license. Use open-source │
│                          │         │ TEI/transpect version (CC-SA/BSD).     │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ OMML2MML.xsl available   │ ✅ TRUE │ TEI Stylesheets project publishes it  │
│ as open-source           │         │ under CC-SA/BSD. plurimath/omml2mathml│
│                          │         │ also packages it (Ruby, reusable XSL). │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ latex2mathml handles     │ ⚠️ PARTIAL│ Pure Python, 232 stars, works for     │
│ all LaTeX math           │         │ common math. FAILS on: {*{20}{l}}     │
│                          │         │ column specs, some LaTeX environments, │
│                          │         │ and amsmath edge cases.                │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ Pandoc LaTeX→OMML       │ ⚠️ NUANCE│ Works for standard math. Known issues: │
│ is fully lossless        │         │ \lim subscript placement may differ   │
│                          │         │ from LaTeX rendering. Complex array    │
│                          │         │ environments may fail silently.        │
├──────────────────────────┼─────────┼───────────────────────────────────────┤
│ pypandoc wraps Pandoc     │ ✅ TRUE │ But Pandoc is an external Haskell      │
│ seamlessly               │         │ binary (~150MB). Must be installed     │
│                          │         │ separately. Major deployment concern.  │
└──────────────────────────┴─────────┴───────────────────────────────────────┘
```

### Roadblock 1: Pandoc as External Binary Dependency

**Severity**: HIGH — blocks deployment on constrained environments

**Problem**: Pandoc is a Haskell binary (~150MB compiled). `pypandoc` requires it installed separately. This creates friction for `pip install edgemint` — users expect a pure-Python tool.

**Mitigations**:

1. **pypandoc_binary** — A companion package that auto-downloads Pandoc binaries. Add as optional dependency: `pip install edgemint[pandoc]`
2. **Docker image** — Ship `edgemint` as a Docker image with Pandoc pre-installed: docker run [ghcr.io/raphaelmansuy/edgemint](http://ghcr.io/raphaelmansuy/edgemint) extract input.docx
3. **Graceful degradation** — `extract-styles` (style-only extraction) works without Pandoc (pure python-docx). Only `extract` (full content) and `apply-styles` require it. Detect at runtime and give clear error.
4. **Pin Pandoc version** — Due to regressions in 3.5+ (§16 Fact-Check), pin to a tested version in CI (e.g., test against 3.7.x and 3.8.x, document known-good versions per release).

```jsx
┌─────────────────────────────────────────────────────────────┐
│           Dependency Architecture                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  edgemint (pure Python)                                │
│  ├─ extract-styles  ── python-docx only (NO Pandoc)         │
│  ├─ diff / validate ── pydantic only    (NO Pandoc)         │
│  ├─ extract (full)  ── REQUIRES Pandoc (content parse)     │
│  └─ apply-styles    ── REQUIRES Pandoc (DOCX generation)   │
│                                                             │
│  Install modes:                                              │
│    pip install edgemint           (styles only, no P.) │
│    pip install edgemint[pandoc]    (full, with P.)     │
│    docker run ghcr.io/raphaelmansuy/edgemint  (all-in-one)   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Roadblock 2: Pandoc Duplicate Style Bug

**Severity**: MEDIUM — produces corrupted style sheets in output

**Problem**: When writing DOCX with `custom-style` attributes, Pandoc creates a **new style definition** even when a style with the same name already exists in the reference document. This results in two styles named "VE" — one correct (from reference), one default (Pandoc-generated) — and Word uses the Pandoc-generated one, losing all formatting.

**Evidence**: Confirmed in Stack Overflow reports and Pandoc issue tracker. Pandoc's own docs state: "If they are already defined, pandoc will not alter the definition" — but this is **not always true in practice** for character styles applied via `<span>`.

**Mitigations**:

1. **Post-processing step** — After Pandoc generates the DOCX, open it with python-docx and deduplicate styles: remove Pandoc-generated duplicates, keep the reference originals.
2. **Style injection** — Instead of relying on reference.docx, inject our `styles.json` definitions directly into the output DOCX's `word/styles.xml` after Pandoc writes it.
3. **Integration test** — Add a specific test: extract styles → apply → re-extract → compare. Any style duplication = test failure.

### Roadblock 3: python-docx Has No Math/OMML Support

**Severity**: MEDIUM — blocks Path C (direct XML injection)

**Problem**: python-docx Issue #213 (opened October 2015, **still open**) confirms there is no API for creating or reading OMML math objects. The library treats `<m:oMath>` elements as opaque XML that it silently skips or preserves but cannot manipulate.

**Impact on our design**:

- **Path A (Pandoc)**: Unaffected. Pandoc handles all math conversion independently.
- **Path B (XSLT)**: Requires raw lxml injection into `paragraph._element`, bypassing python-docx APIs. Works but fragile.
- **Path C (direct injection)**: Requires constructing OMML XML manually and appending to paragraph elements via lxml.

**Mitigation**: Primary path (Pandoc) is unaffected. For fallback paths, document the raw XML injection pattern explicitly and wrap it in a tested `math/injector.py` module.

### Roadblock 4: XSLT Stylesheet Licensing

**Severity**: MEDIUM — legal risk if using wrong source

**Problem**: The original `MML2OMML.xsl` ships with Microsoft Office but is **not freely redistributable** under MS license. The spec incorrectly stated it could be bundled.

**Corrected approach**:

- **OMML → MathML direction**: Use the TEI project's `omml2mml.xsl` (CC-SA/BSD dual license, published for years in [github.com/TEIC/Stylesheets](http://github.com/TEIC/Stylesheets)).
- **MathML → OMML direction**: Use the transpect project's open-source `mml2omml.xsl` ([github.com/transpect/docx_modify-lib](http://github.com/transpect/docx_modify-lib), BSD-2-Clause license).
- **Alternative**: The npm package `mathml2omml` implements MathML→OMML conversion without XSLT at all (pure JS). A Python port could eliminate the XSLT dependency entirely.

### Roadblock 5: Pandoc List Style Assignment

**Severity**: MEDIUM — visual fidelity broken for lists

**Problem**: Pandoc assigns `Normal` style to list items instead of the conventional `List Paragraph` style. This causes incorrect indentation and spacing in the output DOCX. Confirmed as bug #7280, still present in Pandoc 3.7.0.2.

**Mitigations**:

1. **Lua filter** — Write a Pandoc Lua filter that post-processes list items and applies `List Paragraph` style:

```lua
function BulletList(el)
  -- Wrap each list item in a Div with custom-style
  for i, item in ipairs(el.content) do
    el.content[i] = pandoc.Div(item, {["custom-style"] = "List Paragraph"})
  end
  return el
end
```

1. **Post-processing** — After DOCX generation, walk paragraphs with python-docx and re-assign list styles based on numbering properties.

### Edge Case 1: Locale-Dependent Style Names

**Problem**: DOCX style names are locale-dependent. "Heading 1" in English is "Überschrift 1" in German, "見出し 1" in Japanese. The `style_id` (e.g., "Heading1") is locale-independent, but the display `name` is not.

**Impact**: The Markdown → Style mapping table (§8) uses English display names. Documents created in non-English Word will have different names.

**Mitigation**: Always use `style_id` (not `name`) as the canonical key in `styles.json` and `custom-style` attributes. Add a `name_locale` field for display purposes only. The mapping.json should support both `style_id` and `name` lookups.

### Edge Case 2: Theme-Dependent Font Resolution

**Problem**: Many styles reference theme fonts ("majorHAnsi", "minorHAnsi") rather than explicit font names. The actual font depends on `word/theme1.xml`. If the theme is not extracted, font resolution is incomplete.

**Impact**: `styles.json` might say `font.name = null` when the font comes from the theme.

**Mitigation**: Already addressed in §4 schema (theme section). The resolver must merge theme defaults into the resolved properties. Add explicit tests for theme-font resolution.

### Edge Case 3: Corrupted or Non-Standard DOCX Files

**Problem**: Real-world DOCX files are frequently non-conformant:

- Created by LibreOffice, Google Docs, or WPS Office (different OOXML dialects)
- Manually edited ZIPs with missing XML parts
- Password-protected or encrypted
- Containing embedded OLE objects (legacy Equation Editor, not OMML)

**Mitigations**:

1. **Strict mode / lenient mode** — CLI flag `--strict` fails on any parse error; `--lenient` (default) logs warnings and continues.
2. **OLE equation detection** — Detect legacy Equation Editor objects (binary OLE, not OMML) and warn that they cannot be round-tripped. These are images, not editable math.
3. **Validation on open** — Check for required XML parts (`word/document.xml`, `word/styles.xml`) before proceeding.

### Edge Case 4: Very Large Documents

**Problem**: Documents with 100+ styles, 500+ pages, or hundreds of images could cause memory issues with python-docx's DOM-based parsing.

**Mitigation**: For the `extract-styles` subcommand, parse only `word/styles.xml` (stream via lxml iterparse if needed). For full extraction, Pandoc handles streaming internally. Add `--max-media-size` flag to skip oversized embedded objects.

### Edge Case 5: Bidirectional (RTL) Text

**Problem**: Arabic/Hebrew documents use RTL paragraph direction and complex script fonts. python-docx has limited RTL support (open issues for table direction). Pandoc handles `dir` attributes but they may not always round-trip correctly.

**Mitigation**: Preserve RTL properties in `styles.json` paragraph format (`bidi`, `rtl` flags). Add integration tests with Arabic/Hebrew template documents. Flag RTL documents in extraction output.

### Edge Case 6: Math Round-Trip Fidelity

**Problem**: The LaTeX → OMML → LaTeX round-trip through Pandoc is **not identity**. Pandoc's OMML→LaTeX output may differ from the original LaTeX input:

- `\frac{a}{b}` may become `\dfrac{a}{b}` or vice versa
- Spacing commands (`\,`, `\;`, `\!`) may be lost
- `\limits` vs default limit placement may change
- Display/inline mode may shift

**Mitigation**: For documents where math fidelity is critical, store the **original LaTeX** as metadata alongside the Pandoc-generated LaTeX. Add a `<!-- original: \frac{a}{b} -->` comment in the Markdown for diff auditing.

### Edge Case 7: Numbered Headings and TOC Fields

**Problem**: DOCX numbered headings use `w:numPr` (numbering properties) linked to `word/numbering.xml`. Pandoc strips these on extraction, converting them to plain `# Heading` without preserving the numbering link.

**Mitigation**: Capture the heading-to-numbering mapping in `styles.json` under a `heading_numbering` section. On apply, re-link headings to their numbering definitions. TOC fields are Word-specific computed fields — declare as NEAR fidelity (require Word to regenerate).

### Edge Case 8: Conditional/Linked Styles

**Problem**: DOCX supports "linked styles" where a paragraph style and character style share properties (e.g., Heading 1 as paragraph style also defines Heading 1 Char as character style). python-docx exposes `style.linked_style` but this link can break on round-trip.

**Mitigation**: Preserve `linked_style_id` in `styles.json`. On apply, recreate the linkage. Add validation that linked pairs remain consistent.

### Updated Risk Matrix

```
┌──────────────────────────┬──────────┬────────────┬────────────────────┐
│  Risk                    │ Severity │ Likelihood │ Mitigation Status   │
├──────────────────────────┼──────────┼────────────┼────────────────────┤
│ Pandoc binary dep.      │ HIGH     │ CERTAIN    │ MITIGATED (optional)│
│ Style duplication bug    │ MEDIUM   │ HIGH       │ MITIGATED (postproc)│
│ List style bug           │ MEDIUM   │ HIGH       │ MITIGATED (Lua fltr)│
│ XSLT licensing           │ MEDIUM   │ LOW (if    │ MITIGATED (open src)│
│                          │          │  using OSS)│                    │
│ python-docx no math     │ MEDIUM   │ CERTAIN    │ ACCEPTED (use Pandoc│
│                          │          │            │  as primary path)   │
│ Locale-dependent names   │ LOW      │ MEDIUM     │ MITIGATED (style_id)│
│ RTL text fidelity        │ LOW      │ LOW        │ MONITORED (test)    │
│ Non-standard DOCX        │ LOW      │ HIGH       │ MITIGATED (lenient) │
│ Math round-trip drift    │ LOW      │ MEDIUM     │ MONITORED (metadata)│
│ Pandoc version regress.  │ MEDIUM   │ MEDIUM     │ MITIGATED (pin ver) │
└──────────────────────────┴──────────┴────────────┴────────────────────┘
```

---

## §15 References

- ECMA-376 Office Open XML File Formats — [https://ecma-international.org/publications-and-standards/standards/ecma-376/](https://ecma-international.org/publications-and-standards/standards/ecma-376/)
- python-docx documentation — [https://python-docx.readthedocs.io/en/latest/](https://python-docx.readthedocs.io/en/latest/)
- python-docx styles documentation — [https://python-docx.readthedocs.io/en/latest/user/styles-using.html](https://python-docx.readthedocs.io/en/latest/user/styles-using.html)
- docx-rust (Rust) — [https://docs.rs/docx-rust](https://docs.rs/docx-rust)
- ooxmlsdk (Rust) — [https://github.com/KaiserY/ooxmlsdk](https://github.com/KaiserY/ooxmlsdk)
- mammoth.js (Node.js) — [https://www.npmjs.com/package/mammoth](https://www.npmjs.com/package/mammoth)
- mistune Markdown parser — [https://github.com/lepture/mistune](https://github.com/lepture/mistune)
- TEI Stylesheets (OMML↔MathML XSLT, CC-SA/BSD) — [https://github.com/TEIC/Stylesheets](https://github.com/TEIC/Stylesheets)
- transpect mml2omml.xsl (BSD-2-Clause) — [https://github.com/transpect/docx_modify-lib](https://github.com/transpect/docx_modify-lib)
- latex2mathml (pure Python) — [https://github.com/roniemartinez/latex2mathml](https://github.com/roniemartinez/latex2mathml)
- Pandoc Issue #7280 — List style bug — [https://github.com/jgm/pandoc/issues/7280](https://github.com/jgm/pandoc/issues/7280)
- Pandoc Issue #10282 — Reference doc regression — [https://github.com/jgm/pandoc/issues/10282](https://github.com/jgm/pandoc/issues/10282)
- python-docx Issue #213 — No OMML support — [https://github.com/python-openxml/python-docx/issues/213](https://github.com/python-openxml/python-docx/issues/213)

[Implementation Specification — edgemint v0.1.0](docs/implementation_specification_edgemint_v0_1_0.md)

[edgemint — User Guide](docs/edgemint_user_guide.md)

[Claude Code Skill — edgemint](docs/claude_code_skill_edgemint.md)