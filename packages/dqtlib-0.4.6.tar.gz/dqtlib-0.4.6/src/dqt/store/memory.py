from __future__ import annotations

from collections import defaultdict
from uuid import UUID

from dqt.store._protocol import CausalEdgeReview, CausalityReport, Incident, ProfileReport, RunResult


class MemoryStore:
    def __init__(self) -> None:
        self._runs: dict[UUID, list[RunResult]] = defaultdict(list)
        self._incidents: dict[UUID, list[Incident]] = defaultdict(list)
        self._causal_reviews: list[CausalEdgeReview] = []
        self._profile_reports: list[ProfileReport] = []
        self._causality_reports: list[CausalityReport] = []

    def save_run(self, run: RunResult) -> None:
        self._runs[run.check_id].append(run)

    def list_runs(self, check_id: UUID, limit: int = 100) -> list[RunResult]:
        return self._runs[check_id][-limit:][::-1]

    def save_incident(self, incident: Incident) -> None:
        self._incidents[incident.check_id].append(incident)

    def list_incidents(self, check_id: UUID, status: str | None = None) -> list[Incident]:
        items = self._incidents[check_id]
        if status is not None:
            items = [i for i in items if i.status == status]
        return list(items)

    def list_all_incidents(self) -> list[Incident]:
        result = []
        for inc_list in self._incidents.values():
            result.extend(inc_list)
        return result

    def save_causal_review(self, review: CausalEdgeReview) -> None:
        self._causal_reviews.append(review)

    def list_causal_reviews(self, edge_id: UUID) -> list[CausalEdgeReview]:
        return [r for r in self._causal_reviews if r.edge_id == edge_id]

    def causal_edge_precision(self, edge_id: UUID) -> float:
        reviews = self.list_causal_reviews(edge_id)
        decided = [r for r in reviews if r.decision in ("accept", "reject")]
        if not decided:
            return float("nan")
        return sum(1 for r in decided if r.decision == "accept") / len(decided)

    def save_profile_report(self, report: ProfileReport) -> None:
        self._profile_reports.append(report)

    def list_profile_reports(self) -> list[ProfileReport]:
        return list(self._profile_reports)

    def save_causality_report(self, report: CausalityReport) -> None:
        self._causality_reports.append(report)

    def list_causality_reports(self) -> list[CausalityReport]:
        return list(self._causality_reports)
