# pysegmenters_pysdb

[![license](https://img.shields.io/github/license/oterrier/pysegmenters_pysdb)](https://github.com/oterrier/pysegmenters_pysdb/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pysegmenters_pysdb/workflows/tests/badge.svg)](https://github.com/oterrier/pysegmenters_pysdb/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pysegmenters_pysdb)](https://codecov.io/gh/oterrier/pysegmenters_pysdb)
[![docs](https://img.shields.io/readthedocs/pysegmenters_pysdb)](https://pysegmenters_pysdb.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pysegmenters_pysdb)](https://pypi.org/project/pysegmenters_pysdb/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pysegmenters_pysdb)](https://pypi.org/project/pysegmenters_pysdb/)

Rule based segmenter based on Spacy and PySBD (Python Sentence Boundary Disambiguation).

## Installation

You can simply `pip install pysegmenters_pysdb`.

## Developing

### Pre-requesites

You will need to install `uv` (for building and managing the package):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pysegmenters_pysdb
```

Install development dependencies:

```
uv sync --extra test
```

### Running the test suite

You can run the full test suite with:

```
uv run pytest
```

### Linting and formatting

```
uv run ruff check .
uv run ruff format .
```

### Building the documentation

You can build the HTML documentation with:

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
