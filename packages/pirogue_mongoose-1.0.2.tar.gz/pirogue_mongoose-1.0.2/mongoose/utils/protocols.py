# SPDX-FileCopyrightText: 2026 Defensive Lab Agency
# SPDX-FileContributor: u039b <git@0x39b.fr>
#
# SPDX-License-Identifier: GPL-3.0-or-later

PROTOCOL_NUMBERS = {
    0: {
        "keyword": "HOPOPT",
        "name": "IPv6 Hop-by-Hop Option",
    },
    1: {
        "keyword": "ICMP",
        "name": "Internet Control Message",
    },
    2: {
        "keyword": "IGMP",
        "name": "Internet Group Management",
    },
    3: {
        "keyword": "GGP",
        "name": "Gateway-to-Gateway",
    },
    4: {
        "keyword": "IPv4",
        "name": "IPv4 encapsulation",
    },
    5: {
        "keyword": "ST",
        "name": "Stream",
    },
    6: {
        "keyword": "TCP",
        "name": "Transmission Control",
    },
    7: {
        "keyword": "CBT",
        "name": "CBT",
    },
    8: {
        "keyword": "EGP",
        "name": "Exterior Gateway Protocol",
    },
    9: {
        "keyword": "IGP",
        "name": "any private interior gateway (used by Cisco for their IGRP)",
    },
    10: {
        "keyword": "BBN-RCC-MON",
        "name": "RCC Monitoring",
    },
    11: {
        "keyword": "NVP-II",
        "name": "Network Voice Protocol",
    },
    12: {
        "keyword": "PUP",
        "name": "PUP",
    },
    14: {
        "keyword": "EMCON",
        "name": "EMCON",
    },
    15: {
        "keyword": "XNET",
        "name": "Cross Net Debugger",
    },
    16: {
        "keyword": "CHAOS",
        "name": "Chaos",
    },
    17: {
        "keyword": "UDP",
        "name": "User Datagram",
    },
    18: {
        "keyword": "MUX",
        "name": "Multiplexing",
    },
    19: {
        "keyword": "DCN-MEAS",
        "name": "DCN Measurement Subsystems",
    },
    20: {
        "keyword": "HMP",
        "name": "Host Monitoring",
    },
    21: {
        "keyword": "PRM",
        "name": "Packet Radio Measurement",
    },
    22: {
        "keyword": "XNS-IDP",
        "name": "XEROX NS IDP",
    },
    23: {
        "keyword": "TRUNK-1",
        "name": "Trunk-1",
    },
    24: {
        "keyword": "TRUNK-2",
        "name": "Trunk-2",
    },
    25: {
        "keyword": "LEAF-1",
        "name": "Leaf-1",
    },
    26: {
        "keyword": "LEAF-2",
        "name": "Leaf-2",
    },
    27: {
        "keyword": "RDP",
        "name": "Reliable Data Protocol",
    },
    28: {
        "keyword": "IRTP",
        "name": "Internet Reliable Transaction",
    },
    29: {
        "keyword": "ISO-TP4",
        "name": "ISO Transport Protocol Class 4",
    },
    30: {
        "keyword": "NETBLT",
        "name": "Bulk Data Transfer Protocol",
    },
    31: {
        "keyword": "MFE-NSP",
        "name": "MFE Network Services Protocol",
    },
    32: {
        "keyword": "MERIT-INP",
        "name": "MERIT Internodal Protocol",
    },
    33: {
        "keyword": "DCCP",
        "name": "Datagram Congestion Control Protocol",
    },
    34: {
        "keyword": "3PC",
        "name": "Third Party Connect Protocol",
    },
    35: {
        "keyword": "IDPR",
        "name": "Inter-Domain Policy Routing Protocol",
    },
    36: {
        "keyword": "XTP",
        "name": "XTP",
    },
    37: {
        "keyword": "DDP",
        "name": "Datagram Delivery Protocol",
    },
    38: {
        "keyword": "IDPR-CMTP",
        "name": "IDPR Control Message Transport Proto",
    },
    39: {
        "keyword": "TP++",
        "name": "Transport Protocol",
    },
    40: {
        "keyword": "IL",
        "name": "IL Transport Protocol",
    },
    41: {
        "keyword": "IPv6",
        "name": "IPv6 encapsulation",
    },
    42: {
        "keyword": "SDRP",
        "name": "Source Demand Routing Protocol",
    },
    43: {
        "keyword": "IPv6-Route",
        "name": "Routing Header for IPv6",
    },
    44: {
        "keyword": "IPv6-Frag",
        "name": "Fragment Header for IPv6",
    },
    45: {
        "keyword": "IDRP",
        "name": "Inter-Domain Routing Protocol",
    },
    46: {
        "keyword": "RSVP",
        "name": "Reservation Protocol",
    },
    47: {
        "keyword": "GRE",
        "name": "Generic Routing Encapsulation",
    },
    48: {
        "keyword": "DSR",
        "name": "Dynamic Source Routing Protocol",
    },
    49: {
        "keyword": "BNA",
        "name": "BNA",
    },
    50: {
        "keyword": "ESP",
        "name": "Encap Security Payload",
    },
    51: {
        "keyword": "AH",
        "name": "Authentication Header",
    },
    52: {
        "keyword": "I-NLSP",
        "name": "Integrated Net Layer Security  TUBA",
    },
    53: {
        "keyword": "SWIPE",
        "name": "IP with Encryption",
    },
    54: {
        "keyword": "NARP",
        "name": "NBMA Address Resolution Protocol",
    },
    55: {
        "keyword": "Min-IPv4",
        "name": "Minimal IPv4 Encapsulation",
    },
    56: {
        "keyword": "TLSP",
        "name": "Transport Layer Security Protocol using Kryptonet key management",
    },
    57: {
        "keyword": "SKIP",
        "name": "SKIP",
    },
    58: {
        "keyword": "IPv6-ICMP",
        "name": "ICMP for IPv6",
    },
    59: {
        "keyword": "IPv6-NoNxt",
        "name": "No Next Header for IPv6",
    },
    60: {
        "keyword": "IPv6-Opts",
        "name": "Destination Options for IPv6",
    },
    62: {
        "keyword": "CFTP",
        "name": "CFTP",
    },
    64: {
        "keyword": "SAT-EXPAK",
        "name": "SATNET and Backroom EXPAK",
    },
    65: {
        "keyword": "KRYPTOLAN",
        "name": "Kryptolan",
    },
    66: {
        "keyword": "RVD",
        "name": "MIT Remote Virtual Disk Protocol",
    },
    67: {
        "keyword": "IPPC",
        "name": "Internet Pluribus Packet Core",
    },
    69: {
        "keyword": "SAT-MON",
        "name": "SATNET Monitoring",
    },
    70: {
        "keyword": "VISA",
        "name": "VISA Protocol",
    },
    71: {
        "keyword": "IPCV",
        "name": "Internet Packet Core Utility",
    },
    72: {
        "keyword": "CPNX",
        "name": "Computer Protocol Network Executive",
    },
    73: {
        "keyword": "CPHB",
        "name": "Computer Protocol Heart Beat",
    },
    74: {
        "keyword": "WSN",
        "name": "Wang Span Network",
    },
    75: {
        "keyword": "PVP",
        "name": "Packet Video Protocol",
    },
    77: {
        "keyword": "SUN-ND",
        "name": "SUN ND PROTOCOL-Temporary",
    },
    78: {
        "keyword": "WB-MON",
        "name": "WIDEBAND Monitoring",
    },
    79: {
        "keyword": "WB-EXPAK",
        "name": "WIDEBAND EXPAK",
    },
    80: {
        "keyword": "ISO-IP",
        "name": "ISO Internet Protocol",
    },
    81: {
        "keyword": "VMTP",
        "name": "VMTP",
    },
    82: {
        "keyword": "SECURE-VMTP",
        "name": "SECURE-VMTP",
    },
    83: {
        "keyword": "VINES",
        "name": "VINES",
    },
    84: {
        "keyword": "IPTM",
        "name": "Internet Protocol Traffic Manager",
    },
    85: {
        "keyword": "NSFNET-IGP",
        "name": "NSFNET-IGP",
    },
    86: {
        "keyword": "DGP",
        "name": "Dissimilar Gateway Protocol",
    },
    87: {
        "keyword": "TCF",
        "name": "TCF",
    },
    88: {
        "keyword": "EIGRP",
        "name": "EIGRP",
    },
    89: {
        "keyword": "OSPFIGP",
        "name": "OSPFIGP",
    },
    90: {
        "keyword": "Sprite-RPC",
        "name": "Sprite RPC Protocol",
    },
    91: {
        "keyword": "LARP",
        "name": "Locus Address Resolution Protocol",
    },
    92: {
        "keyword": "MTP",
        "name": "Multicast Transport Protocol",
    },
    93: {
        "keyword": "AX.25",
        "name": "AX.25 Frames",
    },
    94: {
        "keyword": "IPIP",
        "name": "IP-within-IP Encapsulation Protocol",
    },
    96: {
        "keyword": "SCC-SP",
        "name": "Semaphore Communications Sec. Pro.",
    },
    97: {
        "keyword": "ETHERIP",
        "name": "Ethernet-within-IP Encapsulation",
    },
    98: {
        "keyword": "ENCAP",
        "name": "Encapsulation Header",
    },
    100: {
        "keyword": "GMTP",
        "name": "GMTP",
    },
    101: {
        "keyword": "IFMP",
        "name": "Ipsilon Flow Management Protocol",
    },
    102: {
        "keyword": "PNNI",
        "name": "PNNI over IP",
    },
    103: {
        "keyword": "PIM",
        "name": "Protocol Independent Multicast",
    },
    104: {
        "keyword": "ARIS",
        "name": "ARIS",
    },
    105: {
        "keyword": "SCPS",
        "name": "SCPS",
    },
    106: {
        "keyword": "QNX",
        "name": "QNX",
    },
    108: {
        "keyword": "IPComp",
        "name": "IP Payload Compression Protocol",
    },
    109: {
        "keyword": "SNP",
        "name": "Sitara Networks Protocol",
    },
    110: {
        "keyword": "Compaq-Peer",
        "name": "Compaq Peer Protocol",
    },
    112: {
        "keyword": "VRRP",
        "name": "Virtual Router Redundancy Protocol",
    },
    113: {
        "keyword": "PGM",
        "name": "PGM Reliable Transport Protocol",
    },
    115: {
        "keyword": "L2TP",
        "name": "Layer Two Tunneling Protocol",
    },
    116: {
        "keyword": "DDX",
        "name": "D-II Data Exchange (DDX)",
    },
    117: {
        "keyword": "IATP",
        "name": "Interactive Agent Transfer Protocol",
    },
    118: {
        "keyword": "STP",
        "name": "Schedule Transfer Protocol",
    },
    119: {
        "keyword": "SRP",
        "name": "SpectraLink Radio Protocol",
    },
    120: {
        "keyword": "UTI",
        "name": "UTI",
    },
    121: {
        "keyword": "SMP",
        "name": "Simple Message Protocol",
    },
    123: {
        "keyword": "PTP",
        "name": "Performance Transparency Protocol",
    },
    125: {
        "keyword": "FIRE",
        "name": "",
    },
    126: {
        "keyword": "CRTP",
        "name": "Combat Radio Transport Protocol",
    },
    127: {
        "keyword": "CRUDP",
        "name": "Combat Radio User Datagram",
    },
    128: {
        "keyword": "SSCOPMCE",
        "name": "",
    },
    129: {
        "keyword": "IPLT",
        "name": "",
    },
    130: {
        "keyword": "SPS",
        "name": "Secure Packet Shield",
    },
    131: {
        "keyword": "PIPE",
        "name": "Private IP Encapsulation within IP",
    },
    132: {
        "keyword": "SCTP",
        "name": "Stream Control Transmission Protocol",
    },
    133: {
        "keyword": "FC",
        "name": "Fibre Channel",
    },
    134: {
        "keyword": "RSVP-E2E",
        "name": "IGNORE,",
    },
    135: {
        "keyword": "Mobility Header",
        "name": "",
    },
    136: {
        "keyword": "UDPLite",
        "name": "",
    },
    138: {
        "keyword": "manet",
        "name": "MANET Protocols",
    },
    139: {
        "keyword": "HIP",
        "name": "Host Identity Protocol",
    },
    140: {
        "keyword": "Shim6",
        "name": "Shim6 Protocol",
    },
    141: {
        "keyword": "WESP",
        "name": "Wrapped Encapsulating Security Payload",
    },
    142: {
        "keyword": "ROHC",
        "name": "Robust Header Compression",
    },
    143: {
        "keyword": "Ethernet",
        "name": "Ethernet",
    },
    144: {
        "keyword": "AGGFRAG",
        "name": "AGGFRAG encapsulation payload for ESP",
    },
    145: {
        "keyword": "NSH",
        "name": "Network Service Header",
    },
    146: {
        "keyword": "Homa",
        "name": "Homa",
    },
    147: {
        "keyword": "BIT-EMU",
        "name": "Bit-stream Emulation",
    },
}
