.. include:: ../AUTHORS.rst 
