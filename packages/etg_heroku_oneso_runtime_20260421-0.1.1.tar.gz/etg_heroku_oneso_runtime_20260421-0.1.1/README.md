# etg-heroku-oneso-runtime-20260421

Pure-Python helper wheel for the ExteraGram Heroku OneSO plugin.

The wheel carries the native `heroku_oneso_native.so` blob as package data and
exposes a tiny Python API to resolve its on-disk path after installation.
