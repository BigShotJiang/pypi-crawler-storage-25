from __future__ import annotations

import os


def native_path() -> str:
    return os.path.join(os.path.dirname(__file__), "heroku_oneso_native.so")


__all__ = ["native_path"]
