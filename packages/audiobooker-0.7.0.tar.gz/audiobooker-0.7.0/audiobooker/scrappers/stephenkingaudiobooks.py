from dataclasses import dataclass
from typing import Iterable

from audiobooker.exceptions import ParseErrorException
from audiobooker.base import AudioBook, BookAuthor, AudiobookNarrator
from audiobooker.scrappers import AudioBookSource
from audiobooker.utils import get_soup, extractor_narrator, extract_year, iter_sitemap_urls

_BASE = "https://stephenkingaudiobooks.com"
_SITEMAP = "https://stephenkingaudiobooks.com/wp-sitemap-posts-post-1.xml"


@dataclass
class StephenKingAudioBook:
    url: str

    def parse_page(self):
        soup = get_soup(self.url)
        if not soup:
            return None

        tags = soup.find("span", {"class": "post-meta-category"})
        h1 = soup.find("h1", {"class": "title-page"})
        if not h1:
            return None
        title = h1.text.replace("\xa0", " ")

        content = soup.find("div", {"class": "post-single clearfix"})
        if not content:
            return None

        p = content.find("p")
        desc = p.text.replace("\xa0", " ") if p else ""

        img_tag = content.find("img")
        img = img_tag["src"] if img_tag else ""

        if tags and "Harry Potter" not in tags.text:
            authors = [BookAuthor(first_name="Stephen", last_name="King")]
        else:
            authors = [BookAuthor(first_name="J.K.", last_name="Rowling")]

        if tags and "Stephen Fry" in title and "Harry Potter" in tags.text:
            narrator = AudiobookNarrator(first_name="Stephen", last_name="Fry")
        else:
            narrator = extractor_narrator(title) or extractor_narrator(desc)

        streams = []
        for audio in content.find_all("audio"):
            a = audio.find("a")
            if a:
                streams.append(a.text)

        if not streams:
            raise ParseErrorException("No streams found")

        return AudioBook(
            title=title.replace(" Audiobook", ""),
            streams=streams,
            description=desc,
            narrator=narrator,
            image=img,
            tags=[],
            authors=authors,
            year=extract_year(title) or extract_year(desc),
            language="en",
        )


class StephenKingAudioBooks(AudioBookSource):

    @classmethod
    def _parse_page(cls, url=_BASE, limit=-1, **params) -> Iterable[AudioBook]:
        soup = get_soup(url, **params)
        if not soup:
            return
        for entry in soup.find_all("article"):
            try:
                a = entry.find("a")
                if not a:
                    continue
                book = StephenKingAudioBook(url=a["href"]).parse_page()
                if book:
                    yield book
            except Exception:
                continue
        if limit == -1 or limit > 0:
            next_page = soup.find("div", {"class": "nav-previous"})
            if next_page:
                a = next_page.find("a")
                if a:
                    yield from cls._parse_page(url=a["href"], limit=limit - 1, **params)

    def search(self, query) -> Iterable[AudioBook]:
        from audiobooker.utils import fuzzy_match
        for b in self._parse_page(params={"s": query}):
            if fuzzy_match(query, b.title) or \
               any(fuzzy_match(query, f"{a.first_name} {a.last_name}") for a in b.authors):
                yield self._tag(b)

    def search_by_title(self, query) -> Iterable[AudioBook]:
        from audiobooker.utils import fuzzy_match
        for b in self._parse_page(params={"s": query}):
            if fuzzy_match(query, b.title):
                yield self._tag(b)

    def search_by_author(self, query) -> Iterable[AudioBook]:
        from audiobooker.utils import fuzzy_match
        for b in self._parse_page(params={"s": query}):
            if any(fuzzy_match(query, f"{a.first_name} {a.last_name}") or
                   fuzzy_match(query, a.last_name) for a in b.authors):
                yield self._tag(b)

    def iterate_all(self) -> Iterable[AudioBook]:
        for url in iter_sitemap_urls(_SITEMAP):
            try:
                book = StephenKingAudioBook(url=url).parse_page()
                if book:
                    yield self._tag(book)
            except Exception:
                continue
