"""
配置管理模块 - 支持 .env 文件 + CLI 参数双通道
优先级：CLI 参数 > .env 文件 > 内置默认值
"""
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv


@dataclass
class LLMConfig:
    """LLM 连接配置"""
    api_key:    str  = ""
    api_url:    str  = "https://api.deepseek.com/v1/chat/completions"
    model:      str  = "deepseek-chat"
    timeout:    int  = 60
    verify_ssl: bool = True


def _load_env(env_file: Optional[str] = None) -> None:
    """加载 .env 文件。优先使用指定路径，否则查找当前工作目录。"""
    if env_file:
        load_dotenv(dotenv_path=env_file, override=True)
        return
    cwd_env = Path.cwd() / ".env"
    if cwd_env.exists():
        load_dotenv(dotenv_path=cwd_env, override=True)


def load_config(
    api_key:    Optional[str]  = None,
    api_url:    Optional[str]  = None,
    model:      Optional[str]  = None,
    timeout:    Optional[int]  = None,
    verify_ssl: Optional[bool] = None,
    env_file:   Optional[str]  = None,
) -> LLMConfig:
    """加载 LLM 配置。

    优先级：CLI 参数 > .env 文件 > 内置默认值。

    Args:
        api_key:    API 密钥（覆盖 TALENT_WHALE_API_KEY）
        api_url:    API 地址（覆盖 TALENT_WHALE_API_URL）
        model:      模型名称（覆盖 TALENT_WHALE_MODEL）
        timeout:    超时秒数（覆盖 TALENT_WHALE_TIMEOUT）
        verify_ssl: 是否验证 SSL（覆盖 TALENT_WHALE_VERIFY_SSL）
        env_file:   指定 .env 文件路径

    Returns:
        LLMConfig 实例
    """
    _load_env(env_file)

    return LLMConfig(
        api_key=api_key or os.getenv("TALENT_WHALE_API_KEY", ""),
        api_url=api_url or os.getenv(
            "TALENT_WHALE_API_URL",
            "https://api.deepseek.com/v1/chat/completions",
        ),
        model=model or os.getenv("TALENT_WHALE_MODEL", "deepseek-chat"),
        timeout=timeout if timeout is not None
                else int(os.getenv("TALENT_WHALE_TIMEOUT", "60")),
        verify_ssl=verify_ssl if verify_ssl is not None
                   else os.getenv("TALENT_WHALE_VERIFY_SSL", "true").lower() != "false",
    )
