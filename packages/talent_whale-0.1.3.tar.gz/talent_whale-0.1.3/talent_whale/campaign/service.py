"""
邮件营销活动 - 抽象接口 + 核心服务层
来源: 文件 004
"""
import datetime
import random
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from talent_whale.campaign.models import Candidate, CampaignConfig, EmailLog
from talent_whale.output import console, stats_table


# ==================== 抽象接口 ====================

class EmailDataSource(ABC):
    """邮箱数据源抽象接口"""

    @abstractmethod
    def fetch_email(self, linkedin_id: str) -> Optional[str]:
        """根据 LinkedIn ID 获取邮箱地址"""


class EmailSender(ABC):
    """邮件发送器抽象接口"""

    @abstractmethod
    def send(self, to_email: str, subject: str, body: str) -> Dict[str, Any]:
        """发送邮件，返回发送结果字典"""


class EmailRepository(ABC):
    """邮件日志存储抽象接口"""

    @abstractmethod
    def is_sent(self, linkedin_id: str) -> bool:
        """检查是否已发送过邮件"""

    @abstractmethod
    def save_log(self, log: EmailLog) -> None:
        """保存发送日志"""


class CandidateSource(ABC):
    """候选人数据源抽象接口"""

    @abstractmethod
    def get_candidates(self, tag_filter: str) -> List[Candidate]:
        """获取经过标签过滤的候选人列表"""


# ==================== 统计数据类 ====================

@dataclass
class CampaignStats:
    """营销活动统计"""
    total:                int = 0
    sent:                 int = 0
    skipped_no_email:     int = 0
    skipped_already_sent: int = 0
    failed:               int = 0

    @property
    def success_rate(self) -> float:
        """已发送占总计的百分比"""
        return (self.sent / self.total * 100) if self.total else 0.0


# ==================== 核心服务 ====================

class EmailCampaignService:
    """邮件营销活动服务 - 核心业务逻辑编排"""

    def __init__(
        self,
        candidate_source:  CandidateSource,
        email_sender:      EmailSender,
        email_repository:  EmailRepository,
        config:            CampaignConfig,
    ) -> None:
        self.candidate_source = candidate_source
        self.email_sender     = email_sender
        self.email_repository = email_repository
        self.config           = config

    def run_campaign(self) -> CampaignStats:
        """执行完整的邮件营销活动流程。

        Returns:
            CampaignStats 统计对象
        """
        stats      = CampaignStats()
        candidates = self.candidate_source.get_candidates(self.config.tag_filter)
        stats.total = len(candidates)

        for i, candidate in enumerate(candidates, 1):
            console.rule(f"[highlight]进度 [{i}/{stats.total}][/highlight]")
            console.print(
                f"[info]ℹ  候选人: {candidate.linkedin_id or 'N/A'}  "
                f"URL: {candidate.linkedin_url}[/info]"
            )

            if not candidate.email:
                console.print("[warning]⚠  跳过: 无邮箱地址[/warning]")
                stats.skipped_no_email += 1
                continue

            console.print(f"[dim]邮箱: {candidate.email}[/dim]")

            if self.email_repository.is_sent(candidate.linkedin_id):
                console.print("[dim]⏭  跳过: 已发送过邮件[/dim]")
                stats.skipped_already_sent += 1
                continue

            full_content = candidate.get_full_email_content(self.config.signature)
            if self._send_email(candidate, full_content):
                stats.sent += 1
            else:
                stats.failed += 1

            delay = random.uniform(*self.config.delay_range)
            console.print(f"[dim]⏳ 等待 {delay:.1f} 秒...[/dim]")
            time.sleep(delay)

        self._print_summary(stats)
        return stats

    def _send_email(self, candidate: Candidate, content: str) -> bool:
        """发送单封邮件并记录日志。"""
        console.print(f"[info]ℹ  主题: {candidate.recommend_title}[/info]")

        response = self.email_sender.send(
            to_email=candidate.email,
            subject=candidate.recommend_title,
            body=content,
        )

        if not response:
            console.print("[error]✗  发送失败: 无响应数据[/error]")
            return False

        console.print(f"[dim]响应: {response}[/dim]")

        is_success = (
            response.get("status") == "success"
            or "已发送过邮件" in response.get("message", "")
        )

        if is_success:
            log = EmailLog(
                linkedin=candidate.linkedin_url,
                linkedin_id=candidate.linkedin_id,
                subject=candidate.recommend_title,
                content=content,
                to_email=candidate.email,
                from_email=getattr(
                    getattr(self.email_sender, "config", None), "email", ""
                ),
                timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                senddate=datetime.date.today().strftime("%Y-%m-%d"),
            )
            self.email_repository.save_log(log)
            console.print("[success]✓  邮件发送成功[/success]")
            return True

        console.print(
            f"[error]✗  发送失败: {response.get('message', '未知错误')}[/error]"
        )
        return False

    def _print_summary(self, stats: CampaignStats) -> None:
        """用 Rich 表格打印活动统计摘要。"""
        stats_table([
            ("总计处理",      stats.total),
            ("成功发送",      f"[success]{stats.sent}[/success]"),
            ("跳过(无邮箱)",  stats.skipped_no_email),
            ("跳过(已发送)",  stats.skipped_already_sent),
            ("发送失败",      f"[error]{stats.failed}[/error]"),
            ("成功率",        f"{stats.success_rate:.1f}%"),
        ], title="活动执行摘要")
