"""
邮件营销活动领域模型
来源: 文件 004
"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class SenderConfig:
    """发件人配置"""
    email:        str
    password:     str
    api_base_url: str = "http://127.0.0.1:5000/api/zmail/send"

    def __post_init__(self) -> None:
        if "@" not in self.email:
            raise ValueError(f"邮箱格式无效: {self.email}")


@dataclass(frozen=True)
class DataSourceConfig:
    """数据源配置"""
    excel_file:      str = "email_json.xlsx"
    email_json_path: str = "./resume_json"


@dataclass(frozen=True)
class RepositoryConfig:
    """日志存储配置"""
    log_folder: str = "./email_log"


@dataclass(frozen=True)
class CampaignConfig:
    """营销活动配置"""
    tag_filter: str
    signature:  str   = field(default="\n\n\n祝颂商祺 \nMichael\nWechat:mywechat")
    delay_min:  float = 5.0
    delay_max:  float = 30.0

    @property
    def delay_range(self) -> tuple:
        """发送间隔随机范围 (min, max)"""
        return (self.delay_min, self.delay_max)


@dataclass(frozen=True)
class AppConfig:
    """应用程序总配置"""
    sender:      SenderConfig
    campaign:    CampaignConfig
    data_source: DataSourceConfig = field(default_factory=DataSourceConfig)
    repository:  RepositoryConfig = field(default_factory=RepositoryConfig)

    # ---------- 预设配置模板 ----------

    @classmethod
    def metatech(cls, tag: str = "agent") -> "AppConfig":
        """Metatech 账号预设"""
        return cls(
            sender=SenderConfig(email="metatech@.163.com", password="123456"),
            campaign=CampaignConfig(tag_filter=tag),
        )

    @classmethod
    def deepresearch(cls, tag: str = "agent") -> "AppConfig":
        """DeepResearch 账号预设"""
        return cls(
            sender=SenderConfig(email="deepresearch@163.com", password="123456"),
            campaign=CampaignConfig(tag_filter=tag),
        )


@dataclass
class Candidate:
    """候选人领域模型"""
    linkedin_url:     str
    linkedin_id:      str
    recommend_title:  str
    email_content:    str
    email:            Optional[str] = None
    tag:              str = ""

    def get_full_email_content(self, signature: str) -> str:
        """拼接邮件正文与签名，同时移除多余星号。"""
        return f"{self.email_content.replace('*', '')}{signature}"


@dataclass
class EmailLog:
    """邮件发送日志领域模型"""
    linkedin:    str
    linkedin_id: str
    subject:     str
    content:     str
    to_email:    str
    from_email:  str
    timestamp:   str
    senddate:    str
