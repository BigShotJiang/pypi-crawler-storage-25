"""
邮件营销活动 - 具体实现层 + 工厂
来源: 文件 004
"""
import json
from pathlib import Path
from typing import List, Optional
from urllib.parse import quote, urlencode

import pandas as pd
import requests

from talent_whale.campaign.models import (
    Candidate,
    DataSourceConfig,
    EmailLog,
    RepositoryConfig,
)
from talent_whale.campaign.models import AppConfig
from talent_whale.campaign.service import (
    CandidateSource,
    EmailCampaignService,
    EmailDataSource,
    EmailRepository,
    EmailSender,
)
from talent_whale.output import console


# ==================== 具体实现 ====================

class JsonFileEmailDataSource(EmailDataSource):
    """基于 JSON 文件目录的邮箱数据源。

    每个候选人对应一个 {linkedin_id}.json 文件，文件中包含 ``email`` 字段。
    """

    def __init__(self, config: DataSourceConfig) -> None:
        self.base_path = Path(config.email_json_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

    def fetch_email(self, linkedin_id: str) -> Optional[str]:
        file_path = self.base_path / f"{linkedin_id}.json"
        if not file_path.exists():
            console.print(f"[warning]⚠  邮件 JSON 未找到: {file_path}[/warning]")
            return None
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return json.load(f).get("email")
        except json.JSONDecodeError as e:
            console.print(f"[error]✗  JSON 解析错误: {file_path} — {e}[/error]")
        except Exception as e:
            console.print(f"[error]✗  读取文件失败: {file_path} — {e}[/error]")
        return None


class ZmailEmailSender(EmailSender):
    """通过 Zmail REST API 发送邮件。"""

    def __init__(self, config) -> None:
        self.config      = config
        self.api_base_url = config.api_base_url.rstrip()

    def _build_url(self, to_email: str, subject: str, body: str) -> str:
        params = {
            "to_email":   to_email,
            "subject":    subject,
            "body":       body,
            "from_email": self.config.email,
            "password":   self.config.password,
        }
        return f"{self.api_base_url}?{urlencode(params, quote_via=quote)}"

    def send(self, to_email: str, subject: str, body: str) -> dict:
        url = self._build_url(to_email, subject, body)
        try:
            resp = requests.get(url, timeout=30)
            return resp.json()
        except Exception as e:
            console.print(f"[error]✗  HTTP 请求失败: {e}[/error]")
            return {}


class JsonFileEmailRepository(EmailRepository):
    """以 JSON 文件为介质的邮件发送日志存储。"""

    def __init__(self, config: RepositoryConfig) -> None:
        self.log_folder = Path(config.log_folder)
        self.log_folder.mkdir(parents=True, exist_ok=True)

    def is_sent(self, linkedin_id: str) -> bool:
        return (self.log_folder / f"{linkedin_id}.json").exists()

    def save_log(self, log: EmailLog) -> None:
        file_path = self.log_folder / f"{log.linkedin_id}.json"
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(log.__dict__, f, ensure_ascii=False, indent=4)
        console.print(f"[success]✓  日志已保存: {file_path}[/success]")


class ExcelCandidateSource(CandidateSource):
    """从 Excel 文件读取候选人，并按标签过滤。"""

    def __init__(
        self,
        config:            DataSourceConfig,
        email_data_source: EmailDataSource,
    ) -> None:
        self.file_path         = Path(config.excel_file)
        self.email_data_source = email_data_source

    def get_candidates(self, tag_filter: str) -> List[Candidate]:
        try:
            df = pd.read_excel(self.file_path, engine="openpyxl")
        except FileNotFoundError:
            raise FileNotFoundError(f"Excel 文件未找到: {self.file_path}")
        except Exception as e:
            raise RuntimeError(f"读取 Excel 失败: {e}")

        filtered = df[df["tag"].astype(str).str.contains(tag_filter, na=False)]
        candidates = []
        for _, row in filtered.iterrows():
            linkedin_id = self._extract_linkedin_id(str(row.get("url", "")))
            email       = self.email_data_source.fetch_email(linkedin_id) if linkedin_id else None
            candidates.append(Candidate(
                linkedin_url=str(row.get("url", "")),
                linkedin_id=linkedin_id or "",
                recommend_title=str(row.get("recommend_title", "N/A")),
                email_content=str(row.get("email_content", "N/A")),
                email=email,
                tag=str(row.get("tag", "")),
            ))
        return candidates

    @staticmethod
    def _extract_linkedin_id(url: str) -> str:
        from talent_whale.utils.text import extract_linkedin_id
        return extract_linkedin_id(url) or ""


# ==================== 工厂 ====================

class EmailCampaignFactory:
    """工厂类 - 根据 AppConfig 组装完整的 EmailCampaignService。"""

    @staticmethod
    def create_service(config: AppConfig) -> EmailCampaignService:
        """组装所有依赖，返回可直接调用的服务实例。"""
        email_data_source = JsonFileEmailDataSource(config.data_source)
        candidate_source  = ExcelCandidateSource(config.data_source, email_data_source)
        email_sender      = ZmailEmailSender(config.sender)
        email_repository  = JsonFileEmailRepository(config.repository)

        return EmailCampaignService(
            candidate_source=candidate_source,
            email_sender=email_sender,
            email_repository=email_repository,
            config=config.campaign,
        )
