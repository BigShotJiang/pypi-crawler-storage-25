"""
邮件营销活动 CLI 子命令
命令: talent-whale campaign run
"""
import typer

from talent_whale.output import banner, console

app = typer.Typer(help="邮件营销活动管理")


@app.command("run")
def campaign_run(
    email: str = typer.Option(
        "aigresearch@163.com", "--email", "-e",
        help="发件人邮箱地址",
    ),
    password: str = typer.Option(
        "123456", "--password", "-p",
        help="邮箱密码或授权码",
    ),
    tag_filter: str = typer.Option(
        "agent", "--tag-filter", "-t",
        help="邮件标签过滤关键字",
    ),
    signature: str = typer.Option(
        "\n\nMichael\nWechat: mywechat", "--signature", "-s",
        help="邮件签名内容（支持换行符 \\n）",
    ),
    delay_min: float = typer.Option(
        10.0, "--delay-min",
        help="最小发送延迟（秒）",
    ),
    delay_max: float = typer.Option(
        30.0, "--delay-max",
        help="最大发送延迟（秒）",
    ),
    excel_file: str = typer.Option(
        "email_lk_json.xlsx", "--excel", "-x",
        help="收件人信息 Excel 文件路径",
    ),
    email_json_path: str = typer.Option(
        "./resume_json", "--json-path", "-j",
        help="存放邮件内容 JSON 文件的目录",
    ),
    log_folder: str = typer.Option(
        "./email_log", "--log-folder", "-l",
        help="日志文件存储目录",
    ),
):
    """运行邮件营销活动，所有参数均可通过命令行指定，未指定时使用默认值。"""
    from talent_whale.campaign.factory import EmailCampaignFactory
    from talent_whale.campaign.models import (
        AppConfig,
        CampaignConfig,
        DataSourceConfig,
        RepositoryConfig,
        SenderConfig,
    )

    banner("邮件营销活动", f"发件人: {email} | 标签: {tag_filter}")

    config = AppConfig(
        sender=SenderConfig(email=email, password=password),
        campaign=CampaignConfig(
            tag_filter=tag_filter,
            signature=signature,
            delay_min=delay_min,
            delay_max=delay_max,
        ),
        data_source=DataSourceConfig(
            excel_file=excel_file,
            email_json_path=email_json_path,
        ),
        repository=RepositoryConfig(log_folder=log_folder),
    )

    service = EmailCampaignFactory.create_service(config)
    try:
        stats = service.run_campaign()
        console.print(
            f"[success]✓  活动执行完成，成功率: {stats.success_rate:.1f}%[/success]"
        )
    except Exception as e:
        console.print(f"[error]✗  程序执行失败: {e}[/error]", stderr=True)
        raise typer.Exit(code=1)
