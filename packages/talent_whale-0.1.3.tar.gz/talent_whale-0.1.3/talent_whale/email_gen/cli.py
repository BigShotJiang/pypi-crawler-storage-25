"""
简历邮件生成 CLI 子命令
命令结构:
  talent-whale email generate batch  <urls_file> <output_dir> --template-file
  talent-whale email generate single <resume_file> <output_dir> --template-file
"""
import os
from typing import Optional

import typer

from talent_whale.email_gen.generator import DEFAULT_PROMPT_TEMPLATE
from talent_whale.output import banner, console, rule
from talent_whale.utils.io import ensure_directory_exists
from talent_whale.utils.text import extract_filename_without_extension

app        = typer.Typer(help="简历邮件生成工具")
generate_app = typer.Typer(help="生成邮件 JSON（batch / single）")
app.add_typer(generate_app, name="generate")


def _load_template(template_file: Optional[str]) -> Optional[str]:
    """从文件加载 Prompt 模板。

    Args:
        template_file: 模板文件路径；None 表示使用内置 DEFAULT_PROMPT_TEMPLATE

    Returns:
        模板内容字符串；None 表示使用默认模板
    """
    if template_file is None:
        console.print("[info]ℹ  未指定模板文件，将使用内置 DEFAULT_PROMPT_TEMPLATE[/info]")
        return None
    try:
        with open(template_file, "r", encoding="utf-8") as f:
            content = f.read()
        console.print(f"[info]ℹ  已加载模板文件: {template_file}[/info]")
        return content
    except Exception as e:
        console.print(f"[error]✗  读取模板文件失败: {e}[/error]", stderr=True)
        raise typer.Exit(1)


@generate_app.command("batch")
def generate_batch(
    urls_file: str = typer.Argument(
        ..., help="包含 LinkedIn URL 列表的文本文件（每行一个）"
    ),
    output_dir: str = typer.Argument(
        ..., help="输出目录，保存生成的 JSON 邮件文件"
    ),
    template_file: Optional[str] = typer.Option(
        None, "--template-file", "-p",
        help="Prompt 模板文件路径（UTF-8 编码）；不指定则使用内置默认模板",
    ),
    file_type: str = typer.Option(
        "json", "--type", "-t",
        help="简历文件类型：'json'（resume_json/）或 'txt'（resume_txt/）",
    ),
    resume_base_dir: str = typer.Option(
        "./", "--resume-base-dir", "-d",
        help="简历文件根目录，默认当前目录",
    ),
    skip_existing: bool = typer.Option(
        True, "--skip-existing/--overwrite",
        help="跳过已存在的输出文件",
    ),
    model: str = typer.Option(
        "deepseek-v3.1-terminus", "--model", "-m",
        help="LLM 模型名称",
    ),
):
    """批量处理：根据 URL 列表逐一读取简历，生成邮件 JSON。"""
    from talent_whale.email_gen.generator import gen_email_tool

    if file_type not in ("json", "txt"):
        console.print(
            f"[error]✗  不支持的 --type 值: {file_type}（请使用 'json' 或 'txt'）[/error]",
            stderr=True,
        )
        raise typer.Exit(1)

    prompt_template = _load_template(template_file)
    gen_email_tool(
        urls_file=urls_file,
        output_dir=output_dir,
        prompt_template=prompt_template,
        file_type=file_type,
        resume_base_dir=resume_base_dir,
        skip_existing=skip_existing,
        model=model,
    )


@generate_app.command("single")
def generate_single(
    resume_file: str = typer.Argument(
        ..., help="单个简历文件路径（.txt 或 .json）"
    ),
    output_dir: str = typer.Argument(
        ..., help="输出目录，保存生成的 JSON 邮件文件"
    ),
    template_file: Optional[str] = typer.Option(
        None, "--template-file", "-p",
        help="Prompt 模板文件路径（UTF-8 编码）；不指定则使用内置默认模板",
    ),
    skip_existing: bool = typer.Option(
        True, "--skip-existing/--overwrite",
        help="跳过已存在的输出文件",
    ),
    model: str = typer.Option(
        "deepseek-v3.1-terminus", "--model", "-m",
        help="LLM 模型名称",
    ),
):
    """单文件处理：直接处理一个简历文件，生成邮件 JSON。"""
    from talent_whale.email_gen.generator import process_resume_file

    banner("邮件生成工具", "单文件模式")
    prompt_template = _load_template(template_file)
    ensure_directory_exists(output_dir)

    if not os.path.exists(resume_file):
        console.print(
            f"[error]✗  简历文件不存在: {resume_file}[/error]", stderr=True
        )
        raise typer.Exit(1)

    output_path = os.path.join(
        output_dir,
        extract_filename_without_extension(resume_file) + ".json",
    )
    if skip_existing and os.path.exists(output_path):
        console.print(f"[dim]SKIP 输出文件已存在: {output_path}[/dim]")
        raise typer.Exit(0)

    process_resume_file(resume_file, output_dir, prompt_template, model)
    rule()
    console.print("[success]✓  单文件处理完成！[/success]")


@app.command("show-template")
def show_template(
    compact: bool = typer.Option(
        False, "--compact", "-c",
        help="仅显示模板格式说明，不输出完整职位列表",
    ),
):
    """查看内置 DEFAULT_PROMPT_TEMPLATE 的完整内容和格式说明。

    此命令帮助用户了解 Prompt 模板的结构，以及如何编写自定义模板。
    """
    banner("默认 Prompt 模板", "来源: 文件 002 PROMPT_TEMPLATE")

    console.print(
        "\n[highlight]📋 模板结构说明[/highlight]\n"
        "\n"
        "  1. [bold]角色设定[/bold] — 定义 LLM 为「招聘邮件撰写资深专家」\n"
        "  2. [bold]输出格式[/bold] — JSON 返回，key 包括:\n"
        '     • match_job_title: true/false\n'
        '     • recommend_title: 邮件标题\n'
        '     • email_content: 邮件正文\n'
        "  3. [bold]邮件示例[/bold] — 含 {FullName}/{JobTitle}/{Location} 占位符\n"
        "  4. [bold]撰写要求[/bold] — 结构清晰、简洁流畅、态度诚恳、不含占位符\n"
        "  5. [bold]语言风格[/bold] — 中文，自然口语化\n"
        "  6. [bold]禁用词项[/bold] — 「让我印象深刻」「很欣赏您」等\n"
        "  7. [bold]职位列表[/bold] — JSON 数组，每项含 JobTitle/Qualification/Location\n"
    )

    console.print("\n[highlight]📝 自定义 Prompt 模板的方法[/highlight]\n")
    console.print(
        "  将上述完整内容复制到一个 .txt 文件（UTF-8 编码），按需修改：\n"
        "  • 替换「职位列表」为你实际要招聘的岗位\n"
        "  • 调整「邮件示例」中的签名信息（Michael → 你的名字）\n"
        "  • 修改「禁用词项」和「语言风格」以匹配你的场景\n"
        "  • 在命令行通过 --template-file 指定自定义模板文件路径\n"
    )

    console.print("\n[highlight]📄 完整模板内容[/highlight]\n")
    if compact:
        console.print("[dim](使用 --no-compact 查看完整职位列表)[/dim]")
        # 仅显示模板前段（不含职位列表）
        lines = DEFAULT_PROMPT_TEMPLATE.split("\n")
        for i, line in enumerate(lines):
            if line.strip() == "# 职位列表如下:":
                console.print("\n".join(lines[:i]))
                console.print("\n[dim]... (职位列表共 %d 行，使用 --no-compact 查看完整内容)[/dim]" % (len(lines) - i))
                break
        else:
            console.print(DEFAULT_PROMPT_TEMPLATE)
    else:
        console.print(DEFAULT_PROMPT_TEMPLATE)
