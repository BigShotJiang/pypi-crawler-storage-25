"""
简历邮件生成核心逻辑
来源: 文件 001、002（合并后去重）
"""
import os
from typing import Optional

from talent_whale.llm.client import chat
from talent_whale.output import console, banner, rule
from talent_whale.utils.io import (
    ensure_directory_exists,
    read_txt_data,
    read_txt_to_list,
    save_json_to_file,
)
from talent_whale.utils.text import (
    clean_llm_response,
    extract_filename_without_extension,
    parse_json_safely,
)

MAX_RETRIES = 3
DEFAULT_MODEL = "deepseek-v3.1-terminus"

# ==================== 默认 Prompt 模板 ====================
# 来源: 文件 002 PROMPT_TEMPLATE
# 当命令行或函数调用未指定 --template-file 时自动使用此模板

DEFAULT_PROMPT_TEMPLATE = """

#### 
你是招聘邮件撰写资深专家，以上是候选人的信息，请仔细阅读，先根据末尾的职位列表，评估他适合哪个岗位，然后写一份Email的Sales Pitch给他，如果评估不适合列表中的任何职位，match_job_title返回false，job_role和email_content都为空，如果评估适合列表中的职位，则给出具体的Email内容，Email的示例如下：JSON格式返回，key包括：{"match_job_title": true/false, "recommend_title": ""，"email_content": ""}

#### 
您好{FullName}，
我来自高端招聘团队，很冒昧的给您发邮件。通过Linkedin了解到您，了解到您在XXX, XXX等方向有丰富经验。

我负责国际知名大型科技公司招聘，非常希望邀请到您这样的人才在此向您推荐"{JobTitle}"的职位。负责带领技术团队攻克更多XXX，XXX技术难题，进一步提升您在行业内的影响力。

职位地点： {Location}

如果您有兴趣具体了解的话，可以留个电话或者微信，给您详细介绍一下，期待与您的沟通~

祝颂商祺
Michael
####


# 请根据候选人技术背景，撰写一封直接可用的中文销售推介邮件，要求如下：

1. 匹配评估：结合候选人技术方向与职位列表中的具体岗位（含JobTitle和Location），评估匹配度, 必须要写Location。

2. 内容要求：
   - 结构清晰：开头简要说明来意，主体突出技术匹配点，结尾自然引导联系。
   - 简洁流畅：语言自然、口语化，避免冗余和套话。
   - 态度诚恳：不浮夸，不使用"让我印象深刻""很欣赏您"等表达。
   - 不含占位符：输出为完整、可直接发送的邮件正文。

3. 语言风格：
   - 使用中文，简洁自然，符合职场沟通习惯。
   - 避免"体现了技术实力""由于网络原因无法解析链接"等无效或技术性表述。

4. 结尾要求：
   - 在邮件末尾自然添加一句联系方式索要语，例如："如果您有兴趣进一步了解，欢迎留下电话或微信，我将为您详细介绍。"

5. 禁用词项（确保不出现）：
   - "让我印象深刻"
   - "很欣赏您"
   - "体现了您技术实力"
   - "由于网络原因，我无法成功解析您提供的个人主页链接"
   - 其他主观性、冗余性表达

请输出一封完整、可直接发送的中文销售推介邮件。


# 职位列表如下: 

```

职位列表:
[
  {
    "JobTitle": "大模型数据工程首席专家",
    "Qualification": "精通数据集构建、清洗、标注、增强、蒸馏与质量评估全流程，具备大规模高质量语料库交付经验，熟悉大模型数据生成与去偏技术。",
    "Location": "北京、上海"
  },
  {
    "JobTitle": "大模型后训练强化学习首席专家",
    "Qualification": "博士学历，精通大模型后训练与强化学习技术，具备RLHF、DPO等实际项目经验，有千卡级大模型训练落地成果者优先。",
    "Location": "北上深"
  },
  
]


```

"""


def call_llm_with_retry(
    content:         str,
    prompt_template: Optional[str] = None,
    max_retries:     int = MAX_RETRIES,
    model:           str = DEFAULT_MODEL,
) -> str:
    """调用 LLM 生成邮件内容，内置重试机制。

    Args:
        content:         候选人简历文本
        prompt_template: Prompt 模板（含职位列表等）；None 时使用 DEFAULT_PROMPT_TEMPLATE
        max_retries:     最大重试次数
        model:           LLM 模型名称

    Returns:
        LLM 返回的原始文本；失败时返回空字符串
    """
    if prompt_template is None:
        prompt_template = DEFAULT_PROMPT_TEMPLATE
    full_prompt = content + prompt_template

    for attempt in range(max_retries):
        try:
            console.print(
                f"[info]ℹ  正在调用 LLM（第 {attempt + 1}/{max_retries} 次）...[/info]"
            )
            response = chat(full_prompt, model=model)
            if response and isinstance(response, str):
                console.print(
                    f"[success]✓  LLM 调用成功，返回长度: {len(response)}[/success]"
                )
                return response
            console.print("[warning]⚠  LLM 返回无效（空或非字符串）[/warning]")
        except Exception as e:
            console.print(
                f"[error]✗  LLM 调用失败（第 {attempt + 1} 次）: {e}[/error]"
            )

        if attempt == max_retries - 1:
            console.print(
                f"[error]✗  已达最大重试次数 {max_retries}，放弃[/error]"
            )
            return ""

    return ""


def process_resume_file(
    resume_path:     str,
    output_dir:      str,
    prompt_template: Optional[str] = None,
    model:           str = DEFAULT_MODEL,
) -> None:
    """处理单个简历文件：读取 → 调用 LLM → 解析 JSON → 保存。

    Args:
        resume_path:     简历文件路径（.txt 或 .json）
        output_dir:      输出目录
        prompt_template: Prompt 模板内容；None 时使用 DEFAULT_PROMPT_TEMPLATE
        model:           LLM 模型名称
    """
    console.print(f"[info]ℹ  正在处理: {resume_path}[/info]")

    content = read_txt_data(resume_path)
    if not content or not content.strip():
        console.print(f"[warning]⚠  文件为空，跳过: {resume_path}[/warning]")
        return

    raw_response = call_llm_with_retry(content, prompt_template, MAX_RETRIES, model)
    if not raw_response:
        console.print(f"[error]✗  LLM 未返回有效结果，跳过: {resume_path}[/error]")
        return

    cleaned  = clean_llm_response(raw_response)
    parsed   = parse_json_safely(cleaned)
    if not parsed:
        console.print(f"[error]✗  JSON 解析失败，跳过: {resume_path}[/error]")
        return

    filename    = extract_filename_without_extension(resume_path)
    output_path = os.path.join(output_dir, f"{filename}.json")
    save_json_to_file(parsed, output_path)


def gen_email_tool(
    urls_file:       str,
    output_dir:      str,
    prompt_template: Optional[str] = None,
    file_type:       str  = "json",
    resume_base_dir: str  = "./",
    skip_existing:   bool = True,
    model:           str  = DEFAULT_MODEL,
) -> None:
    """批量生成邮件：根据 URL 列表遍历对应简历文件并调用 LLM。

    Args:
        urls_file:       包含 LinkedIn URL 的文本文件（每行一个）
        output_dir:      生成的 JSON 邮件输出目录
        prompt_template: Prompt 模板内容；None 时使用 DEFAULT_PROMPT_TEMPLATE
        file_type:       简历文件类型（'json' 对应 resume_json/，'txt' 对应 resume_txt/）
        resume_base_dir: 简历根目录（默认当前目录）
        skip_existing:   是否跳过已存在的输出文件
        model:           LLM 模型名称
    """
    banner("邮件生成工具", "批量模式")
    ensure_directory_exists(output_dir)

    linkedin_urls = read_txt_to_list(urls_file)
    resume_subdir = "resume_json" if file_type == "json" else "resume_txt"
    resume_dir    = os.path.join(resume_base_dir, resume_subdir)

    console.print(f"[info]ℹ  共找到 {len(linkedin_urls)} 个 LinkedIn 链接[/info]")

    for url in linkedin_urls:
        url = url.strip()
        if not url:
            continue

        console.print(f"\n[highlight]处理 LinkedIn: {url}[/highlight]")
        linkedin_id  = extract_filename_without_extension(url)
        resume_path  = os.path.join(resume_dir, f"{linkedin_id}.{file_type}")
        output_path  = os.path.join(output_dir, f"{linkedin_id}.json")

        if not os.path.exists(resume_path):
            console.print(f"[warning]⚠  简历文件不存在，跳过: {resume_path}[/warning]")
            continue

        if skip_existing and os.path.exists(output_path):
            console.print(f"[dim]SKIP 输出文件已存在: {output_path}[/dim]")
            continue

        process_resume_file(resume_path, output_dir, prompt_template, model)

    rule()
    console.print("[success]✓  批量处理完成！[/success]")
    console.print(f"[info]ℹ  输出目录: {output_dir}[/info]")
