"""
LinkedIn 自动化 CLI 子命令
命令: talent-whale linkedin run

依赖 selenium 扩展：pip install talent-whale
浏览器登录通过 browser_dog 包实现，需提前安装：pip install browser-dog
"""
import os
import random
import time
from typing import Optional

import typer

from talent_whale.output import banner, console

app = typer.Typer(help="LinkedIn Recruiter 自动化消息发送（需要 selenium 扩展）")


@app.command("run")
def linkedin_run(
    excel_path: str = typer.Option(
        "./lk_email_gen.xlsx", "--excel", "-e",
        help="候选人 Excel 文件路径",
    ),
    tag_filter: str = typer.Option(
        "agent", "--tag-filter", "-t",
        help="标签过滤关键字（如 agent / speech / compiler）",
    ),
    checkpoint_file: str = typer.Option(
        "./urn/checkpoint.json", "--checkpoint", "-c",
        help="断点 JSON 文件路径（用于跨进程去重）",
    ),
    cache_dir: str = typer.Option(
        "./cache_dir", "--cache-dir", "-d",
        help="diskcache 缓存目录",
    ),
    start_index: int = typer.Option(
        0, "--start", "-s",
        help="从第几个候选人开始处理（断点续传）",
    ),
    delay_min: float = typer.Option(
        1.0, "--delay-min",
        help="每条消息发送后的最小延迟（秒）",
    ),
    delay_max: float = typer.Option(
        3.0, "--delay-max",
        help="每条消息发送后的最大延迟（秒）",
    ),
    headless: bool = typer.Option(
        False, "--headless", "-H",
        help="无头模式运行浏览器",
    ),
    recruiter: str = typer.Option(
        "Michael", "--recruiter", "-r",
        help="招聘人员名称（用于消息历史去重判断）",
    ),
    status_keywords: str = typer.Option(
        "accepted,deleted", "--status-kw",
        help="状态关键词（逗号分隔），含此关键词的线程视为已处理",
    ),
    subject_keywords: str = typer.Option(
        "agent,deleted", "--subject-kw",
        help="主题关键词（逗号分隔），含此关键词的线程视为已处理",
    ),
    ignore_file: str = typer.Option(
        "ignore.txt", "--ignore-file", "-i",
        help="忽略名单文件（每行一个 LinkedIn URL）",
    ),
):
    """运行 LinkedIn Recruiter 自动化发消息流程。

    注意：启动前需安装 browser-dog（pip install browser-dog）并准备好 cookie.json 文件。
    """
    from talent_whale.linkedin.factory import create_default_orchestrator
    from talent_whale.linkedin.models import AutomationConfig
    from talent_whale.utils.io import read_txt_to_list

    banner("LinkedIn 自动化", f"Excel: {excel_path} | 标签: {tag_filter}")

    # 读取忽略名单
    ignore_list: list = []
    if os.path.exists(ignore_file):
        ignore_list = [u.lower() for u in read_txt_to_list(ignore_file)]

    automation_config = AutomationConfig(
        status_keywords=status_keywords.split(","),
        subject_keywords=subject_keywords.split(","),
        recruiter=recruiter,
        start_index=start_index,
        ignore_linkedin_list=ignore_list,
    )

    # 初始化浏览器（使用 browser_dog 实现 LinkedIn Talent 登录）
    try:
        from browser_dog.browser import BrowserDog  # type: ignore
    except ImportError:
        console.print(
            "[error]✗  找不到 browser_dog 模块。请执行：pip install browser-dog[/error]",
            stderr=True,
        )
        raise typer.Exit(1)

    try:
        console.print("[info]🌐  正在初始化 BrowserDog 客户端...[/info]")
        cat = BrowserDog(
            "cookie.json",
            "https://www.linkedin.com/talent/home",
            headless=headless,
        )
        driver = cat.get_driver()
        driver.maximize_window()
        console.print("[info]🔗  正在打开 LinkedIn Talent 首页...[/info]")
        driver.get("https://www.linkedin.com/talent/home")
        cat.long_wait()
    except Exception as e:
        console.print(f"[error]✗  浏览器初始化失败: {e}[/error]", stderr=True)
        raise typer.Exit(1)

    orchestrator, data_source = create_default_orchestrator(
        driver=driver,
        excel_path=excel_path,
        tag_filter=tag_filter,
        checkpoint_file=checkpoint_file,
        cache_dir=cache_dir,
        automation_config=automation_config,
    )

    try:
        candidates = data_source.fetch_candidates(tag_filter=tag_filter)
    except Exception as e:
        console.print(f"[error]✗  加载候选人失败: {e}[/error]", stderr=True)
        raise typer.Exit(1)

    console.print(f"[info]ℹ  共加载 {len(candidates)} 个候选人[/info]")
    stats = {"success": 0, "failed": 0, "duplicate": 0}

    for i, candidate in enumerate(candidates[start_index:]):
        console.rule(
            f"[highlight][{i + 1 + start_index}/{len(candidates)}] "
            f"{candidate.linkedin_url or 'Unknown'}[/highlight]"
        )

        content_key = candidate.recommend_title

        # 前置去重
        if orchestrator.duplicate_checker.is_duplicate(
            candidate.linkedin_url, content_key
        ):
            console.print(f"[dim]PRE-CHECK Duplicate, skipping[/dim]")
            stats["duplicate"] += 1
            continue

        if (candidate.linkedin_url or "").lower() in automation_config.ignore_linkedin_list:
            console.print(f"[dim]PRE-CHECK Ignore list, skipping[/dim]")
            stats["duplicate"] += 1
            continue

        success = orchestrator.process_candidate_urn(candidate)

        if success:
            stats["success"] += 1
            orchestrator.duplicate_checker.mark_as_sent(
                candidate.linkedin_url, content_key
            )
        else:
            stats["failed"] += 1

        time.sleep(random.uniform(delay_min, delay_max))

    console.print(
        f"\n[success]✓  处理完成 — "
        f"成功: {stats['success']} | "
        f"失败: {stats['failed']} | "
        f"重复: {stats['duplicate']}[/success]"
    )
