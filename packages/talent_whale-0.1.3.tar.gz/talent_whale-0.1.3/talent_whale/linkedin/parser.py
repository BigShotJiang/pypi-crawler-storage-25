"""
LinkedIn 页面解析器 - 解析姓名、职位、消息线程
来源: 文件 003

依赖 selenium（可选扩展）：pip install talent-whale
"""
from typing import List, Optional

from talent_whale.linkedin.models import CandidateProfile, MessageThread
from talent_whale.output import console


class ParseException(Exception):
    """页面解析失败异常"""


class LinkedInProfileParser:
    """LinkedIn Recruiter 页面解析器"""

    def __init__(self, wait_timeout: int = 15) -> None:
        self.wait_timeout = wait_timeout

    def parse_profile(self, driver) -> CandidateProfile:
        """解析当前页面的候选人姓名和职位。

        Raises:
            ParseException: 无法提取姓名或职位时抛出
        """
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait

        try:
            name_el = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, ".artdeco-entity-lockup__title")
                )
            )
            name = name_el.text.strip()

            title_el = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, ".artdeco-entity-lockup__subtitle.ember-view")
                )
            )
            title = title_el.text.strip()

            return CandidateProfile(
                name=name,
                title=title,
                linkedin_url=driver.current_url,
                raw_data={"source": "linkedin"},
            )
        except Exception as e:
            raise ParseException(f"Failed to parse profile: {e}")

    def extract_message_threads(self, driver) -> List[MessageThread]:
        """提取当前页面的消息线程列表（用于去重检查）。"""
        from selenium.common.exceptions import TimeoutException
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait

        threads: List[MessageThread] = []
        try:
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located(
                    (By.CSS_SELECTOR, "li.message-threads-list__list-item")
                )
            )
            items = driver.find_elements(
                By.CSS_SELECTOR, "li.message-threads-list__list-item"
            )
            for item in items:
                try:
                    threads.append(MessageThread(
                        sender=self._safe_text(item, ".message-threads-list-entity__text-inline.t-12.t-black--light"),
                        subject=self._safe_text(item, ".message-threads-list-entity__text.t-14.t-black.t-bold"),
                        status=self._safe_text(item, ".message-state-entity__text"),
                        date=item.find_element(By.CSS_SELECTOR, "time").get_attribute("textContent").strip(),
                        preview=self._safe_text(item, ".message-threads-list-entity__text.message-threads-list-entity__text-inline"),
                    ))
                except Exception:
                    continue
        except TimeoutException:
            pass
        return threads

    def extract_talent_profile_url(self, driver) -> Optional[str]:
        """从页面链接中提取 Talent Profile URL。"""
        from selenium.webdriver.common.by import By

        try:
            for link in driver.find_elements(By.CSS_SELECTOR, "a[href]"):
                href = link.get_attribute("href")
                if href and "linkedin.com/talent/profile" in href:
                    return href
        except Exception:
            pass
        return None

    def _safe_text(self, parent, selector: str) -> str:
        from selenium.webdriver.common.by import By
        try:
            return parent.find_element(By.CSS_SELECTOR, selector).text.strip()
        except Exception:
            return ""
