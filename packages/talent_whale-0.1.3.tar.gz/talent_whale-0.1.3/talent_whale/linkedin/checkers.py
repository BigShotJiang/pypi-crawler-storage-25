"""
消息发送去重检查器
来源: 文件 003

DiskCacheDuplicateChecker 依赖 diskcache（可选扩展）：
    pip install 'talent-whale[selenium]'
"""
import json
import os
from abc import ABC, abstractmethod
from typing import List, Set


class DuplicateChecker(ABC):
    """去重检查器抽象基类"""

    @abstractmethod
    def is_duplicate(self, identifier: str, content_key: str) -> bool:
        """判断 identifier + content_key 组合是否已发送"""

    @abstractmethod
    def mark_as_sent(self, identifier: str, content_key: str) -> None:
        """标记 identifier + content_key 为已发送"""


class DiskCacheDuplicateChecker(DuplicateChecker):
    """基于 diskcache 的持久化去重检查器（需要 selenium 扩展）。"""

    def __init__(self, cache_dir: str = "./cache_dir") -> None:
        try:
            import diskcache as dc
        except ImportError:
            raise ImportError(
                "diskcache 未安装。请执行：pip install 'talent-whale[selenium]'"
            )
        self.cache = dc.Cache(cache_dir)

    def is_duplicate(self, identifier: str, content_key: str) -> bool:
        cached: Set[str] = self.cache.get(identifier, default=set())
        return content_key in cached

    def mark_as_sent(self, identifier: str, content_key: str) -> None:
        existing: Set[str] = self.cache.get(identifier, default=set())
        existing.add(content_key)
        self.cache[identifier] = existing


class JsonCheckpointDuplicateChecker(DuplicateChecker):
    """基于 JSON 文件的断点检查器（仅依赖标准库）。"""

    def __init__(self, checkpoint_file: str) -> None:
        self.checkpoint_file = checkpoint_file
        self._cache: Set[str] = self._load()

    def _load(self) -> Set[str]:
        if os.path.exists(self.checkpoint_file):
            try:
                with open(self.checkpoint_file, "r", encoding="utf-8") as f:
                    return set(json.load(f))
            except Exception:
                pass
        return set()

    def _save(self) -> None:
        parent = os.path.dirname(self.checkpoint_file)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(self.checkpoint_file, "w", encoding="utf-8") as f:
            json.dump(list(self._cache), f, indent=2)

    def is_duplicate(self, identifier: str, content_key: str = "") -> bool:
        return identifier in self._cache

    def mark_as_sent(self, identifier: str, content_key: str = "") -> None:
        self._cache.add(identifier)
        self._save()


class CompositeDuplicateChecker(DuplicateChecker):
    """组合多个检查器：任意一个命中即视为重复，写入时同步更新全部。"""

    def __init__(self, checkers: List[DuplicateChecker]) -> None:
        self.checkers = checkers

    def is_duplicate(self, identifier: str, content_key: str) -> bool:
        return any(c.is_duplicate(identifier, content_key) for c in self.checkers)

    def mark_as_sent(self, identifier: str, content_key: str) -> None:
        for c in self.checkers:
            c.mark_as_sent(identifier, content_key)
