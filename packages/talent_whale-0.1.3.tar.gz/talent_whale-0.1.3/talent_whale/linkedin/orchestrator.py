"""
LinkedIn 自动化核心编排器
来源: 文件 003

整合导航 → 解析 → 过滤 → 去重 → 发消息的完整流程
"""
from pathlib import Path
from typing import Callable, Optional

from talent_whale.linkedin.checkers import DuplicateChecker
from talent_whale.linkedin.models import AutomationConfig, Candidate
from talent_whale.linkedin.navigator import LinkedInNavigator
from talent_whale.linkedin.parser import LinkedInProfileParser, ParseException
from talent_whale.linkedin.sender import LinkedInMessageSenderImpl
from talent_whale.output import console


class LinkedInAutomationOrchestrator:
    """LinkedIn 自动化流程编排器 - 接受 Candidate 对象，执行完整发消息流程。"""

    def __init__(
        self,
        driver,
        profile_parser:     LinkedInProfileParser,
        message_strategy,
        duplicate_checker:  DuplicateChecker,
        navigator:          LinkedInNavigator,
        message_sender:     LinkedInMessageSenderImpl,
        automation_config:  AutomationConfig,
        cache_path:         str = "./cache_dir",
        name_evaluator      = None,
        title_evaluator     = None,
        on_success:         Optional[Callable] = None,
        on_failure:         Optional[Callable] = None,
        on_skip:            Optional[Callable] = None,
    ) -> None:
        self.driver            = driver
        self.profile_parser    = profile_parser
        self.message_strategy  = message_strategy
        self.duplicate_checker = duplicate_checker
        self.navigator         = navigator
        self.message_sender    = message_sender
        self.automation_config = automation_config
        self.cache_path        = Path(cache_path)
        self.name_evaluator    = name_evaluator
        self.title_evaluator   = title_evaluator
        self.on_success        = on_success
        self.on_failure        = on_failure
        self.on_skip           = on_skip

    # ==================== 缓存操作 ====================

    def _read_cache(self, key: str, default=None):
        self.cache_path.mkdir(parents=True, exist_ok=True)
        try:
            import diskcache as dc
            with dc.Cache(self.cache_path) as cache:
                return cache.get(key, default=default)
        except ImportError:
            return default

    def _write_cache(self, key: str, value, expire=None) -> None:
        self.cache_path.mkdir(parents=True, exist_ok=True)
        try:
            import diskcache as dc
            with dc.Cache(self.cache_path) as cache:
                cache.set(key, value, expire=expire)
        except ImportError:
            pass

    # ==================== 公开方法 ====================

    def process_candidate_urn(self, candidate: Candidate) -> bool:
        """优先从缓存读取 URN，快速定位 Talent Profile 并发消息。"""
        url = candidate.linkedin_url
        url = url if url.endswith("/") else url + "/"
        console.print(f"[info]ℹ  Processing (URN): {url}[/info]")

        try:
            urn = self._read_cache(url)
            if not urn:
                # 先走 process_candidate 拿到 URN 并写缓存
                self.process_candidate(candidate)
                return self._handle_failure(url, "URN not found in cache")

            talent_url = (
                f"https://www.linkedin.com/talent/profile/{urn}/"
                "?trk=FLAGSHIP_VIEW_IN_RECRUITER"
            )
            return self._run_flow(candidate, talent_url, candidate.recommend_title)
        except Exception as e:
            return self._handle_failure(url, str(e))

    def process_candidate(self, candidate: Candidate) -> bool:
        """通过普通 LinkedIn URL 访问主页，提取 Talent URL 后执行发消息流程。"""
        url = candidate.linkedin_url
        url = url if url.endswith("/") else url + "/"
        console.print(f"[info]ℹ  Processing (Direct): {url}[/info]")

        try:
            if not self.navigator.navigate_to_profile(self.driver, url):
                return self._handle_failure(url, "Navigation failed")

            talent_url  = self.profile_parser.extract_talent_profile_url(self.driver)
            target_url  = talent_url or url

            if target_url != url:
                if not self.navigator.navigate_to_profile(self.driver, target_url):
                    return self._handle_failure(url, "Navigation to talent URL failed")

            # 提取并缓存 URN
            urn = target_url.rstrip("/").split("/")[-1]
            self._write_cache(url, urn)
            console.print(f"[info]ℹ  URN 已缓存: {urn}[/info]")

            return self._run_flow(
                candidate, target_url, candidate.recommend_title,
                skip_navigation=True,
            )
        except Exception as e:
            return self._handle_failure(url, str(e))

    # ==================== 核心流程 ====================

    def _run_flow(
        self,
        candidate:       Candidate,
        target_url:      str,
        content_key:     str,
        skip_navigation: bool = False,
    ) -> bool:
        url = candidate.linkedin_url

        if not skip_navigation:
            if not self.navigator.navigate_to_profile(self.driver, target_url):
                return self._handle_failure(url, "Navigation failed")

        # 1. 解析 Profile
        try:
            profile = self.profile_parser.parse_profile(self.driver)
        except ParseException as e:
            return self._handle_failure(url, f"Parse error: {e}")

        # 2. 姓名过滤
        if self.name_evaluator:
            name_type = self.name_evaluator.evaluate(profile.name)
            if name_type in ("indian", "russian"):
                return self._handle_skip(url, f"Name filter: {name_type}")

        # 3. 职位过滤
        if self.title_evaluator:
            if not self.title_evaluator.evaluate(profile.title):
                self.duplicate_checker.mark_as_sent(url, content_key)
                return self._handle_skip(url, "Non-tech title")

        # 4. 打开 Messages 标签检查发送历史
        if not self.navigator.click_messages_tab(self.driver):
            console.print("[warning]⚠  无法打开消息标签页[/warning]")

        threads = self.profile_parser.extract_message_threads(self.driver)
        cfg     = self.automation_config
        for thread in threads:
            sender_lower  = (thread.sender  or "").lower()
            subject_lower = (thread.subject or "").lower()
            status_lower  = (thread.status  or "").lower()

            if (
                cfg.recruiter in sender_lower
                and (
                    candidate.recommend_title in thread.subject
                    or any(k in status_lower  for k in cfg.status_keywords)
                    or any(k in subject_lower for k in cfg.subject_keywords)
                )
            ):
                self.duplicate_checker.mark_as_sent(url, content_key)
                return self._handle_skip(url, "Already sent")

        # 5. 缓存去重
        if self.duplicate_checker.is_duplicate(url, content_key):
            return self._handle_skip(url, "Duplicate in cache")

        # 6. 确认消息按钮可用
        if not self.navigator.is_message_button_clickable(self.driver):
            return self._handle_skip(url, "Message button not available")

        # 7. 打开消息弹窗
        if not self.navigator.open_message_dialog(self.driver):
            return self._handle_failure(url, "Could not open message dialog")

        # 8. 生成并发送消息
        content = self.message_strategy.generate_content(candidate, profile)
        if not self.message_sender.send_message(self.driver, content):
            return self._handle_failure(url, "Send failed")

        # 9. 标记已发送
        self.duplicate_checker.mark_as_sent(url, content_key)
        return self._handle_success(url)

    # ==================== 回调帮助方法 ====================

    def _handle_success(self, url: str) -> bool:
        if self.on_success:
            self.on_success(url)
        console.print(f"[success]✓  SUCCESS: {url}[/success]")
        return True

    def _handle_failure(self, url: str, reason: str) -> bool:
        if self.on_failure:
            self.on_failure(url, reason)
        console.print(f"[error]✗  FAILED: {url} — {reason}[/error]")
        return False

    def _handle_skip(self, url: str, reason: str) -> bool:
        if self.on_skip:
            self.on_skip(url, reason)
        console.print(f"[dim]SKIP: {url} — {reason}[/dim]")
        return False
