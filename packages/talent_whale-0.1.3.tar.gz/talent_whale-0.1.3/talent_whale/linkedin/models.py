"""
LinkedIn 自动化数据模型
来源: 文件 003
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class AutomationConfig:
    """LinkedIn 自动化全局配置"""
    status_keywords:       List[str]
    subject_keywords:      List[str]
    recruiter:             str
    start_index:           int       = 0
    blacklist:             List[str] = field(default_factory=list)
    ignore_linkedin_list:  List[str] = field(default_factory=list)
    title_list:            List[str] = field(default_factory=list)


@dataclass
class CandidateProfile:
    """候选人解析资料（从 LinkedIn 页面提取）"""
    name:         str
    title:        str
    linkedin_url: str
    raw_data:     Dict[str, Any] = field(default_factory=dict)


@dataclass
class MessageThread:
    """InMail/消息线程摘要"""
    sender:  str
    subject: str
    status:  str
    date:    str
    preview: str


@dataclass
class MessageContent:
    """待发送消息内容"""
    title: str
    body:  str


@dataclass
class Candidate:
    """完整候选人数据（含 Excel 字段）"""
    linkedin_url:    str
    linkedin_id:     Optional[str]
    recommend_title: str
    email_content:   str
    email:           Optional[str]
    tag:             str
    raw_data:        Dict[str, Any] = field(default_factory=dict)
