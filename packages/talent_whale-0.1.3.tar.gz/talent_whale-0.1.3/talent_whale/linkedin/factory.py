"""
LinkedIn 自动化 - 具体策略实现 + 工厂函数
来源: 文件 003
"""
import re
from typing import List, Optional

import pandas as pd

from talent_whale.linkedin.checkers import (
    CompositeDuplicateChecker,
    DiskCacheDuplicateChecker,
    JsonCheckpointDuplicateChecker,
)
from talent_whale.linkedin.models import AutomationConfig, Candidate, MessageContent
from talent_whale.linkedin.navigator import LinkedInNavigator
from talent_whale.linkedin.orchestrator import LinkedInAutomationOrchestrator
from talent_whale.linkedin.parser import LinkedInProfileParser
from talent_whale.linkedin.sender import LinkedInMessageSenderImpl
from talent_whale.output import console


# ==================== 消息内容策略 ====================

class ExcelMessageStrategy:
    """基于 Excel 数据的消息策略 - 直接使用 recommend_title 和 email_content。"""

    def generate_content(self, candidate: Candidate, profile) -> MessageContent:
        """将 Excel 中的标题/内容与 Profile 变量合并，生成最终消息。"""
        title = candidate.recommend_title
        body  = candidate.email_content

        variables = {
            "{name}":         profile.name,
            "{title}":        profile.title,
            "{email}":        candidate.email or "",
            "{linkedin_url}": candidate.linkedin_url,
        }
        for var, value in variables.items():
            title = title.replace(var, str(value))
            body  = body.replace(var, str(value))

        return MessageContent(title=title, body=body)


# ==================== 职位过滤器 ====================

class KeywordTitleEvaluator:
    """基于关键词完整词匹配的职位评估器（排除非技术岗位）。"""

    DEFAULT_EXCLUDE: List[str] = [
        "product", "program", "ux", "ui", "user experience",
        "analyst", "hr", "recruiter", "staffing", "pm", "talent", "acquisition",
        "support", "general manager", "strategy", "managing director",
        "business solutions", "business development", "escalation",
    ]

    def __init__(self, exclude_keywords: Optional[List[str]] = None) -> None:
        kws = exclude_keywords or self.DEFAULT_EXCLUDE
        self.pattern = re.compile(
            r"\b(" + "|".join(re.escape(k) for k in kws) + r")\b",
            re.IGNORECASE,
        )

    def evaluate(self, title: str) -> bool:
        """True = 职位符合要求（不含排除关键词）"""
        return not bool(self.pattern.search(title))


# ==================== 候选人数据源 ====================

class ExcelCandidateDataSource:
    """从 Excel 文件中读取并过滤候选人列表。"""

    def __init__(self, file_path: str, email_data_source=None) -> None:
        self.file_path         = file_path
        self.email_data_source = email_data_source

    def fetch_candidates(self, tag_filter: str) -> List[Candidate]:
        try:
            df = pd.read_excel(self.file_path, engine="openpyxl")
        except FileNotFoundError:
            raise FileNotFoundError(f"Excel 文件未找到: {self.file_path}")
        except Exception as e:
            raise RuntimeError(f"读取 Excel 失败: {e}")

        filtered   = df[df["tag"].astype(str).str.contains(tag_filter, na=False)]
        candidates = []
        for _, row in filtered.iterrows():
            linkedin_id = self._extract_linkedin_id(str(row.get("url", "")))
            email       = None
            if self.email_data_source and linkedin_id:
                email = self.email_data_source.fetch_email(linkedin_id)

            candidates.append(Candidate(
                linkedin_url=str(row.get("url", "")),
                linkedin_id=linkedin_id,
                recommend_title=str(row.get("recommend_title", "N/A")),
                email_content=str(row.get("email_content", "N/A")),
                email=email,
                tag=str(row.get("tag", "")),
                raw_data=row.to_dict(),
            ))
        return candidates

    @staticmethod
    def _extract_linkedin_id(url: str) -> Optional[str]:
        from talent_whale.utils.text import extract_linkedin_id
        return extract_linkedin_id(url)


# ==================== 工厂函数 ====================

def create_default_orchestrator(
    driver,
    excel_path:        str                        = "./meta_lk.xlsx",
    tag_filter:        str                        = "agent",
    checkpoint_file:   str                        = "./urn/checkpoint.json",
    cache_dir:         str                        = "./cache_dir",
    automation_config: Optional[AutomationConfig] = None,
    use_llm:           bool                       = False,
    llm_client                                    = None,
) -> tuple:
    """工厂函数：创建默认配置的编排器与数据源。

    Returns:
        (LinkedInAutomationOrchestrator, ExcelCandidateDataSource)
    """
    if automation_config is None:
        automation_config = AutomationConfig(
            status_keywords=["accepted", "deleted"],
            subject_keywords=["agent", "deleted"],
            recruiter="chandler",
        )

    data_source        = ExcelCandidateDataSource(file_path=excel_path)
    profile_parser     = LinkedInProfileParser()
    message_strategy   = ExcelMessageStrategy()
    cache_checker      = DiskCacheDuplicateChecker(cache_dir)
    checkpoint_checker = JsonCheckpointDuplicateChecker(checkpoint_file)
    duplicate_checker  = CompositeDuplicateChecker([cache_checker, checkpoint_checker])
    navigator          = LinkedInNavigator()
    message_sender     = LinkedInMessageSenderImpl()
    title_evaluator    = KeywordTitleEvaluator()

    orchestrator = LinkedInAutomationOrchestrator(
        driver=driver,
        profile_parser=profile_parser,
        message_strategy=message_strategy,
        duplicate_checker=duplicate_checker,
        navigator=navigator,
        message_sender=message_sender,
        automation_config=automation_config,
        cache_path=cache_dir,
        title_evaluator=title_evaluator,
    )

    return orchestrator, data_source
