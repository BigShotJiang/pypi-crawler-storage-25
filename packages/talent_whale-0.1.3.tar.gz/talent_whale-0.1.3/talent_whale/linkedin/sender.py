"""
LinkedIn InMail 消息发送器
来源: 文件 003

依赖 selenium（可选扩展）：pip install talent-whale
"""
import random
import time

from talent_whale.linkedin.models import MessageContent
from talent_whale.output import console


class LinkedInMessageSenderImpl:
    """LinkedIn Recruiter 消息发送器 - 填写标题 + 正文 + 点击发送"""

    def __init__(self, wait_timeout: int = 15) -> None:
        self.timeout = wait_timeout

    def send_message(self, driver, content: MessageContent) -> bool:
        """填写并发送一条 InMail 消息。"""
        from selenium.webdriver.support.ui import WebDriverWait

        wait = WebDriverWait(driver, self.timeout)

        if not self._enter_subject(driver, wait, content.title):
            console.print("[warning]⚠  无法填写消息主题[/warning]")

        if not self._enter_body(driver, wait, content.body):
            console.print("[error]✗  无法填写消息正文[/error]")
            return False

        return self._click_send(driver, wait)

    # ---------- 私有帮助方法 ----------

    def _enter_subject(self, driver, wait, title: str) -> bool:
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC

        for locator in [
            (By.CSS_SELECTOR, "input[name='subject']"),
            (By.CSS_SELECTOR, "input.compose-subject__input"),
            (By.XPATH,        "//input[@placeholder='Subject']"),
            (By.CSS_SELECTOR, "input.msg-form__subject"),
        ]:
            try:
                el = wait.until(EC.element_to_be_clickable(locator))
                driver.execute_script("arguments[0].value = arguments[1];", el, title)
                driver.execute_script(
                    "arguments[0].dispatchEvent(new Event('input'));", el
                )
                time.sleep(random.uniform(0.5, 1))
                return True
            except Exception:
                continue
        return False

    def _enter_body(self, driver, wait, message: str) -> bool:
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC

        for locator in [
            (By.CSS_SELECTOR, "div.msg-form__contenteditable"),
            (By.CSS_SELECTOR, "div.ql-editor"),
            (By.CSS_SELECTOR, "div[contenteditable='true']"),
            (By.XPATH,        "//div[@aria-label='Write a message…']"),
            (By.XPATH,        "//div[@role='textbox']"),
        ]:
            try:
                el = wait.until(EC.element_to_be_clickable(locator))
                driver.execute_script("arguments[0].innerHTML = '';", el)
                driver.execute_script(
                    "arguments[0].innerText = arguments[1];", el, message
                )
                driver.execute_script(
                    "arguments[0].dispatchEvent(new Event('input'));", el
                )
                time.sleep(random.uniform(0.5, 1))
                return True
            except Exception:
                continue
        return False

    def _click_send(self, driver, wait) -> bool:
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC

        for _ in range(3):
            for locator in [
                (By.CSS_SELECTOR, "button.msg-form__send-button"),
                (By.XPATH,        "//button[contains(.,'Send')]"),
                (By.CSS_SELECTOR, "button[type='submit']"),
                (By.CSS_SELECTOR, "button.artdeco-button--primary"),
            ]:
                try:
                    el = wait.until(EC.element_to_be_clickable(locator))
                    driver.execute_script("arguments[0].click();", el)
                    console.print("[success]✓  消息已发送[/success]")
                    return True
                except Exception:
                    continue
            time.sleep(1)
        return False
