"""
LinkedIn 页面导航器
来源: 文件 003

依赖 selenium（可选扩展）：pip install talent-whale
"""
import random
import time

from talent_whale.output import console


class LinkedInNavigator:
    """LinkedIn Recruiter 页面导航器"""

    def __init__(self, wait_timeout: int = 15) -> None:
        self.timeout = wait_timeout

    def navigate_to_profile(self, driver, url: str) -> bool:
        """导航到指定 URL，等待页面主体加载完成。"""
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait

        try:
            driver.get(url)
            WebDriverWait(driver, self.timeout).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            time.sleep(1)
            return True
        except Exception as e:
            console.print(f"[error]✗  导航失败: {url} — {e}[/error]")
            return False

    def open_message_dialog(self, driver) -> bool:
        """点击「Message」按钮，打开消息弹窗。"""
        from selenium.webdriver.common.by import By

        locators = [
            (By.XPATH, "//button[contains(@class,'message') and contains(.,'Message')]"),
            (By.XPATH, "//button[contains(.,'Message')]"),
            (By.CSS_SELECTOR, "button.pv-s-profile-actions__label"),
            (By.CSS_SELECTOR, "button[data-control-name='compose_message']"),
        ]
        for locator in locators:
            if self._try_click(driver, locator):
                time.sleep(random.uniform(0.5, 1.0))
                return True
        return False

    def is_message_button_clickable(self, driver, timeout: int = 10) -> bool:
        """检查第一个 profile-item-actions 中的第二个按钮是否可点击（未禁用）。"""
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait

        try:
            first_li = WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located(
                    (By.CSS_SELECTOR, "li.profile-item-actions")
                )
            )
            buttons = first_li.find_elements(By.TAG_NAME, "button")
            if len(buttons) < 2:
                return False
            return not buttons[1].get_attribute("disabled")
        except Exception as e:
            console.print(f"[warning]⚠  无法判断消息按钮状态: {e}[/warning]")
            return False

    def click_messages_tab(self, driver) -> bool:
        """点击页面上的「Messages」标签页，带指数退避重试。"""
        from tenacity import (
            RetryError,
            retry,
            retry_if_exception_type,
            stop_after_attempt,
            wait_exponential,
        )
        from selenium.common.exceptions import (
            ElementClickInterceptedException,
            TimeoutException,
        )

        @retry(
            stop=stop_after_attempt(5),
            wait=wait_exponential(multiplier=1, max=10),
            retry=retry_if_exception_type(
                (TimeoutException, ElementClickInterceptedException)
            ),
        )
        def _click() -> bool:
            script = """
            const divs = document.querySelectorAll('div[role="presentation"]');
            for (let div of divs) {
                if (div.textContent?.includes('Messages')) return div;
            }
            return null;
            """
            element = driver.execute_script(script)
            if element:
                driver.execute_script("arguments[0].click();", element)
                return True
            raise TimeoutException("Messages tab not found")

        try:
            return _click()
        except RetryError:
            return False

    def _try_click(self, driver, locator) -> bool:
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait

        try:
            wait    = WebDriverWait(driver, 10)
            element = wait.until(EC.element_to_be_clickable(locator))
            driver.execute_script(
                "arguments[0].scrollIntoView({block:'center'});", element
            )
            try:
                element.click()
            except Exception:
                driver.execute_script("arguments[0].click();", element)
            return True
        except Exception:
            return False
