"""
Rich 终端输出模块 - 统一主题与辅助函数
严格遵循 DESIGN_SPEC.md 规范：全局禁止裸 print()
"""
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.theme import Theme

custom_theme = Theme({
    "info":      "cyan",
    "success":   "bold bright_green",
    "warning":   "bold bright_yellow",
    "error":     "bold bright_red",
    "highlight": "bold magenta",
    "dim":       "dim white",
})

# 全局 console 实例，所有模块统一使用
console = Console(theme=custom_theme)


# ---------- 快捷打印函数 ----------

def info(msg: str) -> None:
    """输出蓝绿色信息行"""
    console.print(f"[info]ℹ  {msg}[/info]")


def success(msg: str) -> None:
    """输出绿色成功行"""
    console.print(f"[success]✓  {msg}[/success]")


def warning(msg: str) -> None:
    """输出黄色警告行"""
    console.print(f"[warning]⚠  {msg}[/warning]")


def error(msg: str, stderr: bool = False) -> None:
    """输出红色错误行（可重定向到 stderr）"""
    console.print(f"[error]✗  {msg}[/error]", stderr=stderr)


def highlight(msg: str) -> None:
    """输出高亮洋红行"""
    console.print(f"[highlight]{msg}[/highlight]")


def dim(msg: str) -> None:
    """输出灰色次要信息行"""
    console.print(f"[dim]{msg}[/dim]")


def rule(title: str = "") -> None:
    """输出水平分隔线（可含标题）"""
    if title:
        console.rule(f"[highlight]{title}[/highlight]")
    else:
        console.rule()


def banner(title: str, subtitle: str = "") -> None:
    """输出带边框的横幅面板"""
    content = f"[highlight]{title}[/highlight]"
    if subtitle:
        content += f"\n[dim]{subtitle}[/dim]"
    console.print(Panel(content, border_style="cyan"))


def stats_table(rows: list[tuple], title: str = "执行摘要") -> None:
    """输出统计信息表格（交替行底色）

    Args:
        rows: [(指标名, 值), ...] 列表
        title: 表格标题
    """
    table = Table(
        title=title,
        show_header=True,
        header_style="bold cyan",
        row_styles=["", "dim"],
    )
    table.add_column("指标", style="dim", min_width=16)
    table.add_column("数量", justify="right", min_width=8)
    for label, value in rows:
        table.add_row(str(label), str(value))
    console.print(table)
