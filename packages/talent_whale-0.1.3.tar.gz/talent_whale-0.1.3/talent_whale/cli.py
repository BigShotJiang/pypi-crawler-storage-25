"""
talent-whale 根 CLI 入口
注册所有子命令组，统一入口为 `talent-whale`
"""
import typer

from talent_whale.campaign.cli import app as campaign_app
from talent_whale.data_cli import app as data_app
from talent_whale.email_gen.cli import app as email_app
from talent_whale.linkedin.cli import app as linkedin_app
from talent_whale.output import banner

app = typer.Typer(
    name="talent-whale",
    help=(
        "一站式招聘自动化工具箱\n\n"
        "  email     简历邮件生成（LLM 驱动）\n"
        "  campaign  邮件营销活动管理\n"
        "  linkedin  LinkedIn Recruiter 自动化发消息\n"
        "  data      邮件数据后处理（JSON → Excel）"
    ),
    add_completion=False,
)

app.add_typer(email_app,    name="email",    help="简历邮件生成（batch / single）")
app.add_typer(campaign_app, name="campaign", help="邮件营销活动管理")
app.add_typer(linkedin_app, name="linkedin", help="LinkedIn Recruiter 自动化")
app.add_typer(data_app,     name="data",     help="邮件数据后处理")


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """talent-whale CLI 根入口"""
    if ctx.invoked_subcommand is None:
        banner(
            "talent-whale",
            "招聘自动化工具箱  |  运行 talent-whale --help 查看完整命令列表",
        )


if __name__ == "__main__":
    app()
