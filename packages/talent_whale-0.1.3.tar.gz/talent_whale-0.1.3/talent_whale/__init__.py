"""
talent-whale 公开 API

快速开始示例::

    from talent_whale import chat, load_config

    cfg = load_config(
        api_key="sk-xxxx",
        api_url="https://api.deepseek.com/v1/chat/completions",
        model="deepseek-chat",
    )
    reply = chat("用 Python 实现二叉树的层序遍历", config=cfg)
    print(reply)

工具函数示例::

    from talent_whale import read_txt_data, parse_json_safely, clean_llm_response

    content = read_txt_data("data/resume.txt")
    data    = parse_json_safely('{"name": "lark"}')
    clean   = clean_llm_response('```json\\n{"result": "ok"}\\n```')
"""

# LLM 调用
from talent_whale.llm.client import chat

# 配置管理
from talent_whale.config import load_config

# 文件 I/O 工具
from talent_whale.utils.io import (
    ensure_directory_exists,
    read_txt_data,
    read_txt_to_list,
    save_json_to_file,
)

# 文本处理工具
from talent_whale.utils.text import (
    clean_llm_response,
    extract_filename_without_extension,
    extract_linkedin_id,
    parse_json_safely,
)

__version__ = "0.1.0"

__all__ = [
    # LLM
    "chat",
    "load_config",
    # I/O
    "read_txt_data",
    "read_txt_to_list",
    "save_json_to_file",
    "ensure_directory_exists",
    # 文本
    "extract_linkedin_id",
    "extract_filename_without_extension",
    "clean_llm_response",
    "parse_json_safely",
]
