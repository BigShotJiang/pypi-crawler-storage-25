from talent_whale.llm.client import chat

__all__ = ["chat"]
