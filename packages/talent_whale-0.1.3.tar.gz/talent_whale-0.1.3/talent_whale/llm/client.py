"""
LLM 客户端模块 - 封装 llmdog，支持配置注入
参照「模块导入」示例，使用 llmdog 提供的 chat 与 load_config
"""
from typing import Optional

from llmdog import chat as _llmdog_chat
from llmdog.config import load_config as _llmdog_load_config

from talent_whale.config import LLMConfig
from talent_whale.config import load_config as _load_tw_config


def chat(
    prompt: str,
    model:  Optional[str]      = None,
    config: Optional[LLMConfig] = None,
) -> str:
    """调用 LLM 对话接口。

    优先级：参数 config > .env 文件 > 内置默认值。
    model 参数会覆盖 config 中的 model 字段。

    Args:
        prompt: 输入提示词
        model:  模型名称（可选，覆盖 config.model）
        config: LLMConfig 实例；None 时自动从环境变量加载

    Returns:
        LLM 返回的文本字符串
    """
    if config is None:
        config = _load_tw_config()

    llm_cfg = _llmdog_load_config(
        api_key=config.api_key,
        api_url=config.api_url,
        model=model or config.model,
        timeout=config.timeout,
        verify_ssl=config.verify_ssl,
    )
    return _llmdog_chat(prompt, config=llm_cfg)
