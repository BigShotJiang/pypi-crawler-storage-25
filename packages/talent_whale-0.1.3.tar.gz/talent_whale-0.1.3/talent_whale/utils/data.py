"""
数据处理模块 - 邮件内容后处理
来源: 文件 005
"""
import json
import os
import re

import pandas as pd

from talent_whale.output import console


def clean_email_signature(email_content: str) -> str:
    """去除邮件结尾签名（支持「祝颂商祺/祝好 + Michael」各种变体）。

    Args:
        email_content: 原始邮件内容

    Returns:
        清除签名后的邮件正文
    """
    pattern = r"""
        \s*
        (祝颂商祺|祝商祺|祝好)
        [，,]?\s*
        \n?\s*
        Michael\s*$
    """
    cleaned = re.sub(
        pattern,
        "",
        email_content.strip(),
        flags=re.DOTALL | re.VERBOSE,
    )
    return re.sub(r"michael", "", cleaned, flags=re.IGNORECASE).strip()


def format_firstname(content: str) -> str:
    """在邮件首行插入 {firstName} 占位符，用于个性化替换。

    Args:
        content: 原始邮件内容（第一行视为称呼行）

    Returns:
        替换首行为「您好{firstName},」的内容
    """
    return "您好{firstName},\n" + "\n".join(content.splitlines()[1:])


def process_email_content(input_folder: str, output_excel_file: str) -> None:
    """读取指定目录下所有 JSON 邮件文件，整合并输出为 Excel 表格。

    每条记录包含：url、match_job_title、recommend_title、email_content、filename。
    邮件内容会自动清除签名并去除「*」字符。

    Args:
        input_folder:     包含 JSON 邮件文件的目录路径
        output_excel_file: 输出 Excel 文件路径（.xlsx）

    Raises:
        FileNotFoundError: 输入目录不存在时抛出
    """
    if not os.path.exists(input_folder):
        raise FileNotFoundError(f"输入文件夹不存在: {input_folder}")

    data_list = []
    for filename in os.listdir(input_folder):
        if not filename.lower().endswith(".json"):
            continue

        file_path = os.path.join(input_folder, filename)
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                json_data = json.load(f)

            base_name = os.path.splitext(filename)[0]
            url = f"https://www.linkedin.com/in/{base_name}"
            email_content = json_data.get("email_content", "").replace("*", "")
            cleaned_content = clean_email_signature(email_content.strip())

            data_list.append({
                "url":             url,
                "match_job_title": json_data.get("match_job_title", False),
                "recommend_title": json_data.get("recommend_title", ""),
                "email_content":   cleaned_content,
                "filename":        filename,
            })
        except Exception as e:
            console.print(f"[error]✗  读取文件失败: {file_path} — {e}[/error]")

    column_order = ["url", "match_job_title", "recommend_title", "email_content", "filename"]
    df = pd.DataFrame(data_list)[column_order]
    df.to_excel(output_excel_file, index=False)
    console.print(f"[success]✓  处理完成，共 {len(df)} 条记录，已保存至: {output_excel_file}[/success]")
