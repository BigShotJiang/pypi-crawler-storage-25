"""
数据处理 CLI 子命令
命令: talent-whale data process <input_folder> <output_excel>
"""
import typer

from talent_whale.output import banner, console

app = typer.Typer(help="邮件数据后处理工具")


@app.command("process")
def data_process(
    input_folder: str = typer.Argument(
        ..., help="包含 JSON 邮件文件的目录"
    ),
    output_excel: str = typer.Argument(
        ..., help="输出 Excel 文件路径（.xlsx）"
    ),
):
    """读取邮件 JSON 目录，清洗内容并整合输出为 Excel 表格。

    每行记录包含 url、match_job_title、recommend_title、email_content、filename。
    """
    from talent_whale.utils.data import process_email_content

    banner("数据处理", f"输入目录: {input_folder}")
    try:
        process_email_content(input_folder, output_excel)
    except FileNotFoundError as e:
        console.print(f"[error]✗  {e}[/error]", stderr=True)
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[error]✗  处理失败: {e}[/error]", stderr=True)
        raise typer.Exit(1)
