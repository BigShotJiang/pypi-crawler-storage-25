from __future__ import annotations

import re
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Dict, List, Optional, Union

import requests

from paradime.cli import console
from paradime.core.scripts.utils import handle_http_error


@dataclass(frozen=True)
class TableauPathName:
    """Fully-qualified Tableau workbook or data source identifier.

    Use this when a plain name is ambiguous (e.g. multiple workbooks with the
    same leaf name in different projects) and a UUID is impractical.

    Args:
        project_path: Slash-separated project hierarchy. Leading and trailing
            slashes are tolerated (e.g. ``"Explore/Samples/TestNested/Nested2"``
            or ``"/Explore/Samples/"``). An empty string targets the
            top-level "Default" project tier.
        name: Exact workbook / data source name (the leaf).

    Example:
        TableauPathName(project_path="Explore/Samples", name="World Indicators")
    """

    project_path: str
    name: str


WorkbookIdentifier = Union[str, TableauPathName]
DatasourceIdentifier = Union[str, TableauPathName]


def _normalise_project_path(path: str) -> str:
    """Strip leading/trailing whitespace and slashes from a project path."""
    return path.strip().strip("/")


class _TableauProjectTree:
    """Lazy resolver mapping a slash-separated project path to a project LUID.

    Tableau's REST workbook/datasource filter ``projectName:eq:<leaf>`` only
    matches the leaf name, so projects with the same leaf in different parent
    chains are indistinguishable without walking the project tree. This class
    fetches every project once (paginated), then resolves a path by matching
    the full chain of parent names.

    The instance is intended to be constructed once per refresh invocation and
    shared across all path-based lookups for that invocation.
    """

    def __init__(
        self,
        *,
        host: str,
        auth_token: str,
        site_id: str,
        api_version: str,
    ) -> None:
        self._host = host
        self._auth_token = auth_token
        self._site_id = site_id
        self._api_version = api_version
        self._projects_by_id: Optional[Dict[str, dict]] = None
        self._segments_by_id: Dict[str, List[str]] = {}
        self._path_cache: Dict[str, str] = {}

    def resolve(self, project_path: str) -> str:
        """Return the LUID of the project at the given path.

        Raises:
            KeyError: No project matches the path.
            ValueError: The path is ambiguous (matches more than one project).
        """
        normalised = _normalise_project_path(project_path)
        if normalised in self._path_cache:
            return self._path_cache[normalised]

        self._ensure_loaded()
        target_segments = normalised.split("/") if normalised else []

        candidates = [
            luid
            for luid in (self._projects_by_id or {})
            if self._segments_for(luid) == target_segments
        ]

        if not candidates:
            raise KeyError(
                f"Tableau project path not found: {project_path!r}. "
                f"Verify the path matches the Tableau project hierarchy exactly."
            )
        if len(candidates) > 1:
            raise ValueError(
                f"Tableau project path {project_path!r} is ambiguous "
                f"(matches {len(candidates)} projects). Please report this bug."
            )

        self._path_cache[normalised] = candidates[0]
        return candidates[0]

    def _segments_for(self, luid: str) -> List[str]:
        """Return the project's path as a list of segments from root to leaf."""
        if luid in self._segments_by_id:
            return self._segments_by_id[luid]

        chain: List[str] = []
        current: Optional[str] = luid
        guard = 0
        while current is not None:
            project = (self._projects_by_id or {}).get(current)
            if project is None:
                break
            chain.append(project.get("name", ""))
            current = project.get("parentProjectId") or None
            guard += 1
            if guard > 1024:
                # Defensive: should never happen unless Tableau returns a cycle.
                break
        chain.reverse()
        self._segments_by_id[luid] = chain
        return chain

    def _ensure_loaded(self) -> None:
        if self._projects_by_id is not None:
            return

        self._projects_by_id = {}
        page_number = 1
        while True:
            response = requests.get(
                f"{self._host}/api/{self._api_version}/sites/{self._site_id}/projects",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Tableau-Auth": self._auth_token,
                },
                params={"pageSize": 1000, "pageNumber": page_number},
            )
            handle_http_error(response, "Error listing Tableau projects:")

            payload = response.json()
            project_block = payload.get("projects", {}) or {}
            page = project_block.get("project", []) or []
            if isinstance(page, dict):
                page = [page]

            for project in page:
                luid = project.get("id")
                if luid:
                    self._projects_by_id[luid] = project

            try:
                total_available = int(payload.get("pagination", {}).get("totalAvailable", 0))
            except (TypeError, ValueError):
                total_available = 0

            if not page or len(self._projects_by_id) >= total_available:
                break
            page_number += 1


def _find_resource_in_project(
    *,
    host: str,
    auth_token: str,
    site_id: str,
    api_version: str,
    project_luid: str,
    resource_name: str,
    resource_kind: str,  # "workbooks" or "datasources"
) -> str:
    """Look up a workbook / datasource UUID by name, scoped to a single project.

    Tableau enforces unique workbook (and datasource) names within a project,
    so post-filtering a name match by ``project.id`` yields at most one hit.
    """
    if resource_kind not in ("workbooks", "datasources"):
        raise ValueError(f"Unsupported resource_kind: {resource_kind!r}")

    response = requests.get(
        f"{host}/api/{api_version}/sites/{site_id}/{resource_kind}",
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Tableau-Auth": auth_token,
        },
        params={"filter": f"name:eq:{resource_name}"},
    )
    handle_http_error(
        response,
        f"Error searching for {resource_kind[:-1]} by name '{resource_name}':",
    )

    payload = response.json()
    container = payload.get(resource_kind, {}) or {}
    items = container.get(resource_kind[:-1], []) or []
    if isinstance(items, dict):
        items = [items]

    matches = [
        item
        for item in items
        if isinstance(item.get("project"), dict) and item["project"].get("id") == project_luid
    ]

    if not matches:
        raise Exception(
            f"No {resource_kind[:-1]} named {resource_name!r} found in the resolved "
            f"Tableau project (LUID: {project_luid}). Verify the project path and name."
        )
    if len(matches) > 1:
        # Tableau enforces uniqueness within a project; this should be unreachable.
        raise Exception(
            f"Multiple {resource_kind} named {resource_name!r} in the same project — "
            f"please report this."
        )
    return matches[0]["id"]


def trigger_tableau_refresh(
    *,
    host: str,
    personal_access_token_name: str,
    personal_access_token_secret: str,
    site_name: str,
    workbook_names: List[WorkbookIdentifier],  # str (name or UUID) or TableauPathName
    api_version: str,
    wait_for_completion: bool = False,
    timeout_minutes: int = 30,
) -> List[str]:
    auth_response = requests.post(
        f"{host}/api/{api_version}/auth/signin",
        json={
            "credentials": {
                "personalAccessTokenName": personal_access_token_name,
                "personalAccessTokenSecret": personal_access_token_secret,
                "site": {"contentUrl": site_name},
            }
        },
        headers={"Accept": "application/json", "Content-Type": "application/json"},
    )
    handle_http_error(auth_response)
    # Extract token to use for subsequent calls
    auth_token: str = auth_response.json()["credentials"]["token"]
    site_id: str = auth_response.json()["credentials"]["site"]["id"]

    # Build a single project tree if any path-based identifiers are supplied,
    # so the /projects fetch is amortised across all workbooks in this call.
    has_path_ids = any(isinstance(w, TableauPathName) for w in workbook_names)
    project_tree: Optional[_TableauProjectTree] = (
        _TableauProjectTree(
            host=host,
            auth_token=auth_token,
            site_id=site_id,
            api_version=api_version,
        )
        if has_path_ids
        else None
    )

    # Deduplicate while preserving identifier kind (TableauPathName is hashable).
    unique_workbooks = list({w: None for w in workbook_names}.keys())

    # call refresh for the workbooks async
    futures = []
    results = []
    with ThreadPoolExecutor() as executor:
        for workbook_name in unique_workbooks:
            console.debug(f"Refreshing Tableau workbook: {_describe_identifier(workbook_name)}")
            futures.append(
                (
                    workbook_name,
                    executor.submit(
                        trigger_workbook_refresh,
                        host=host,
                        auth_token=auth_token,
                        site_id=site_id,
                        api_version=api_version,
                        workbook_name=workbook_name,
                        project_tree=project_tree,
                        wait_for_completion=wait_for_completion,
                        timeout_minutes=timeout_minutes,
                    ),
                )
            )
        for workbook_name, future in futures:
            # Use longer timeout when waiting for completion
            future_timeout = (timeout_minutes * 60 + 120) if wait_for_completion else 120
            response_txt = future.result(timeout=future_timeout)
            results.append(response_txt)
            console.debug(
                f"Refreshed Tableau workbook: "
                f"{_describe_identifier(workbook_name)} - {response_txt}"
            )
    return results


def _describe_identifier(identifier: Union[str, TableauPathName]) -> str:
    """Render an identifier for log messages."""
    if isinstance(identifier, TableauPathName):
        path = _normalise_project_path(identifier.project_path)
        return f"{path}/{identifier.name}" if path else identifier.name
    return identifier


def trigger_workbook_refresh(
    *,
    host: str,
    auth_token: str,
    site_id: str,
    api_version: str,
    workbook_name: WorkbookIdentifier,  # str (name or UUID) or TableauPathName
    project_tree: Optional[_TableauProjectTree] = None,
    wait_for_completion: bool = False,
    timeout_minutes: int = 30,
) -> str:
    # Path+name dispatch: resolve the project, then look up the workbook by
    # name scoped to that project's LUID. This avoids the leaf-collision
    # problem that motivated the feature.
    workbook_uuid: Optional[str] = None
    if isinstance(workbook_name, TableauPathName):
        if project_tree is None:
            project_tree = _TableauProjectTree(
                host=host,
                auth_token=auth_token,
                site_id=site_id,
                api_version=api_version,
            )
        display_name = _describe_identifier(workbook_name)
        console.debug(f"Resolving Tableau workbook by path: {display_name}")
        project_luid = project_tree.resolve(workbook_name.project_path)
        workbook_uuid = _find_resource_in_project(
            host=host,
            auth_token=auth_token,
            site_id=site_id,
            api_version=api_version,
            project_luid=project_luid,
            resource_name=workbook_name.name,
            resource_kind="workbooks",
        )
        return _refresh_workbook(
            host=host,
            auth_token=auth_token,
            site_id=site_id,
            api_version=api_version,
            workbook_uuid=workbook_uuid,
            display_name=display_name,
            wait_for_completion=wait_for_completion,
            timeout_minutes=timeout_minutes,
        )

    workbook_uuid = None

    def _is_uuid_format(value: str) -> bool:
        """Check if input string matches UUID format."""
        uuid_pattern = r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
        return bool(re.match(uuid_pattern, value, re.IGNORECASE))

    def _get_workbook_from_response(workbooks_data: dict) -> Optional[str]:
        """Extract workbook UUID from API response."""
        if "workbooks" not in workbooks_data or "workbook" not in workbooks_data["workbooks"]:
            return None

        workbook = workbooks_data["workbooks"]["workbook"]
        if isinstance(workbook, list) and len(workbook) > 0:
            return workbook[0]["id"]
        elif isinstance(workbook, dict):
            return workbook["id"]
        return None

    # If input looks like an ID, try direct access first
    if _is_uuid_format(workbook_name):
        try:
            console.debug(f"Input appears to be an ID, trying direct access: '{workbook_name}'")
            direct_workbook_response = requests.get(
                f"{host}/api/{api_version}/sites/{site_id}/workbooks/{workbook_name}",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Tableau-Auth": auth_token,
                },
            )

            if direct_workbook_response.status_code == 200:
                workbook_data = direct_workbook_response.json()
                if "workbook" in workbook_data:
                    workbook_uuid = workbook_data["workbook"]["id"]
                    console.debug(
                        f"Found workbook by direct UUID access: '{workbook_name}' -> confirmed UUID: {workbook_uuid}"
                    )
            else:
                console.debug(
                    f"Could not access workbook directly by UUID '{workbook_name}': HTTP {direct_workbook_response.status_code}"
                )
        except Exception as e:
            console.debug(f"Could not access workbook by direct UUID '{workbook_name}': {e}")

    # If not found by direct ID access (or input wasn't an ID), try searching by name
    if workbook_uuid is None:
        try:
            console.debug(f"Searching for workbook by name: '{workbook_name}'")
            workbook_response = requests.get(
                f"{host}/api/{api_version}/sites/{site_id}/workbooks",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Tableau-Auth": auth_token,
                },
                params={"filter": f"name:eq:{workbook_name}"},
            )
            handle_http_error(
                workbook_response, f"Error searching for workbook by name '{workbook_name}':"
            )

            workbooks_data = workbook_response.json()
            workbook_uuid = _get_workbook_from_response(workbooks_data)
            if workbook_uuid:
                console.debug(f"Found workbook by name: '{workbook_name}' -> UUID: {workbook_uuid}")
        except Exception as e:
            console.debug(f"Could not find workbook by name '{workbook_name}': {e}")

    # If still not found and input wasn't a UUID, try searching all workbooks for an ID match
    if workbook_uuid is None and not _is_uuid_format(workbook_name):
        try:
            console.debug(f"Searching all workbooks for potential UUID match: '{workbook_name}'")
            all_workbooks_response = requests.get(
                f"{host}/api/{api_version}/sites/{site_id}/workbooks",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Tableau-Auth": auth_token,
                },
            )
            handle_http_error(
                all_workbooks_response,
                f"Error getting all workbooks while searching for '{workbook_name}':",
            )

            workbooks_data = all_workbooks_response.json()
            if "workbooks" in workbooks_data and "workbook" in workbooks_data["workbooks"]:
                workbooks_list = workbooks_data["workbooks"]["workbook"]
                if isinstance(workbooks_list, dict):
                    workbooks_list = [workbooks_list]

                for workbook in workbooks_list:
                    if workbook.get("id") == workbook_name:
                        workbook_uuid = workbook["id"]
                        console.debug(
                            f"Found workbook by UUID in all workbooks search: '{workbook_name}' -> confirmed UUID: {workbook_uuid}"
                        )
                        break
        except Exception as e:
            console.debug(f"Could not search all workbooks for UUID '{workbook_name}': {e}")

    # If still not found, raise an exception
    if workbook_uuid is None:
        raise Exception(
            f"Could not find workbook with name or UUID '{workbook_name}'. Please check that the workbook exists and you have permission to access it."
        )

    return _refresh_workbook(
        host=host,
        auth_token=auth_token,
        site_id=site_id,
        api_version=api_version,
        workbook_uuid=workbook_uuid,
        display_name=workbook_name,
        wait_for_completion=wait_for_completion,
        timeout_minutes=timeout_minutes,
    )


def _refresh_workbook(
    *,
    host: str,
    auth_token: str,
    site_id: str,
    api_version: str,
    workbook_uuid: str,
    display_name: str,
    wait_for_completion: bool,
    timeout_minutes: int,
) -> str:
    refresh_trigger = requests.post(
        f"{host}/api/{api_version}/sites/{site_id}/workbooks/{workbook_uuid}/refresh",
        json={},
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Tableau-Auth": auth_token,
        },
    )
    handle_http_error(
        refresh_trigger,
        f"Error triggering refresh for workbook '{display_name}' (UUID: {workbook_uuid}):",
    )

    if not wait_for_completion:
        return refresh_trigger.text

    job_id = _extract_job_id_from_response(refresh_trigger.text)
    if not job_id:
        console.debug(
            f"Could not extract job ID from refresh response for workbook '{display_name}'. "
            f"Cannot monitor completion."
        )
        return refresh_trigger.text

    console.debug(f"Monitoring refresh job {job_id} for workbook '{display_name}'...")

    job_status = _wait_for_job_completion(
        host=host,
        auth_token=auth_token,
        site_id=site_id,
        api_version=api_version,
        job_id=job_id,
        resource_type="Workbook",
        resource_name=display_name,
        timeout_minutes=timeout_minutes,
    )

    return f"Refresh completed. Job status: {job_status}"


def _extract_job_id_from_response(response_text: str) -> Optional[str]:
    """Extract job ID from refresh response JSON or XML."""
    try:
        # Try JSON first (newer API versions)
        import json

        data = json.loads(response_text)
        if "job" in data and "id" in data["job"]:
            return data["job"]["id"]
    except (json.JSONDecodeError, KeyError):
        pass

    try:
        # Fallback to XML parsing (older API versions)
        import xml.etree.ElementTree as ET

        root = ET.fromstring(response_text)

        # Look for job element in response
        job_elem = root.find(".//{http://onlinehelp.tableau.com/ts-api}job")
        if job_elem is not None:
            return job_elem.get("id")
    except Exception as e:
        console.debug(f"Could not parse job ID from response: {e}")

    return None


def _wait_for_job_completion(
    *,
    host: str,
    auth_token: str,
    site_id: str,
    api_version: str,
    job_id: str,
    resource_type: str,
    resource_name: str,
    timeout_minutes: int,
) -> str:
    """Poll job status until completion or timeout."""
    start_time = time.time()
    timeout_seconds = timeout_minutes * 60
    sleep_interval = 5  # Poll every 5 seconds
    counter = 0

    while True:
        elapsed = time.time() - start_time
        if elapsed > timeout_seconds:
            raise Exception(
                f"Timeout waiting for {resource_type.lower()} '{resource_name}' refresh job {job_id} to complete after {timeout_minutes} minutes"
            )

        try:
            job_response = requests.get(
                f"{host}/api/{api_version}/sites/{site_id}/jobs/{job_id}",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Tableau-Auth": auth_token,
                },
            )

            if job_response.status_code != 200:
                console.error(f"Failed to get job status: HTTP {job_response.status_code}")
                console.error("The refresh was triggered successfully, but job monitoring failed.")
                console.error(
                    "The refresh may still be running on Tableau Server. Check the server directly for job status."
                )
                raise Exception(
                    f"Job monitoring failed with HTTP {job_response.status_code}. The refresh job was triggered but monitoring failed."
                )

            # Parse job status from JSON or XML response
            progress = "0"
            finish_code = None
            started_at = None
            completed_at = None

            try:
                # Try JSON first (newer API versions)
                import json

                data = json.loads(job_response.text)
                if "job" in data:
                    job = data["job"]
                    progress = str(job.get("progress", "0"))
                    finish_code = job.get("finishCode")
                    started_at = job.get("startedAt")
                    completed_at = job.get("completedAt")
                else:
                    console.debug(f"No job element found in JSON response for job {job_id}")
                    time.sleep(sleep_interval)
                    continue
            except (json.JSONDecodeError, KeyError):
                # Fallback to XML parsing (older API versions)
                try:
                    import xml.etree.ElementTree as ET

                    root = ET.fromstring(job_response.text)
                    job_elem = root.find(".//{http://onlinehelp.tableau.com/ts-api}job")

                    if job_elem is None:
                        console.debug(
                            f"Could not find job element in XML response for job {job_id}"
                        )
                        time.sleep(sleep_interval)
                        continue

                    progress = job_elem.get("progress", "0")
                    finish_code = job_elem.get("finishCode")
                    started_at = job_elem.get("startedAt")
                    completed_at = job_elem.get("completedAt")
                except Exception as e:
                    console.debug(f"Could not parse job status response for {job_id}: {e}")
                    time.sleep(sleep_interval)
                    continue

            # Log progress on first check and then every 5 checks (2.5 minutes)
            if counter == 0 or counter % 5 == 0:
                if started_at:
                    console.debug(f"Job {job_id} progress: {progress}% (started at {started_at})")
                else:
                    console.debug(f"Job {job_id} progress: {progress}% (waiting to start...)")

            # Check if job is complete
            if finish_code is not None:
                if finish_code == "0":
                    elapsed_min = int(elapsed // 60)
                    elapsed_sec = int(elapsed % 60)
                    console.debug(
                        f"{resource_type} '{resource_name}' refresh completed successfully in {elapsed_min}m {elapsed_sec}s"
                    )
                    return f"SUCCESS (finished at {completed_at})"
                elif finish_code == "1":
                    console.error(f"{resource_type} '{resource_name}' refresh failed")
                    return f"FAILED (finish code: {finish_code})"
                elif finish_code == "2":
                    console.debug(f"{resource_type} '{resource_name}' refresh was canceled")
                    return f"CANCELED (finish code: {finish_code})"
                else:
                    console.debug(
                        f"{resource_type} '{resource_name}' refresh finished with unknown code: {finish_code}"
                    )
                    return f"UNKNOWN (finish code: {finish_code})"

            counter += 1
            time.sleep(sleep_interval)

        except requests.exceptions.RequestException as e:
            console.debug(f"Network error polling job status for {job_id}: {e}")
            time.sleep(sleep_interval)
            continue


def trigger_tableau_datasource_refresh(
    *,
    host: str,
    personal_access_token_name: str,
    personal_access_token_secret: str,
    site_name: str,
    datasource_names: List[DatasourceIdentifier],  # str (name or UUID) or TableauPathName
    api_version: str,
    wait_for_completion: bool = False,
    timeout_minutes: int = 30,
) -> List[str]:
    auth_response = requests.post(
        f"{host}/api/{api_version}/auth/signin",
        json={
            "credentials": {
                "personalAccessTokenName": personal_access_token_name,
                "personalAccessTokenSecret": personal_access_token_secret,
                "site": {"contentUrl": site_name},
            }
        },
        headers={"Accept": "application/json", "Content-Type": "application/json"},
    )
    handle_http_error(auth_response)
    # Extract token to use for subsequent calls
    auth_token: str = auth_response.json()["credentials"]["token"]
    site_id: str = auth_response.json()["credentials"]["site"]["id"]

    has_path_ids = any(isinstance(d, TableauPathName) for d in datasource_names)
    project_tree: Optional[_TableauProjectTree] = (
        _TableauProjectTree(
            host=host,
            auth_token=auth_token,
            site_id=site_id,
            api_version=api_version,
        )
        if has_path_ids
        else None
    )

    unique_datasources = list({d: None for d in datasource_names}.keys())

    # call refresh for the datasources async
    futures = []
    results = []
    with ThreadPoolExecutor() as executor:
        for datasource_name in unique_datasources:
            console.debug(
                f"Refreshing Tableau data source: {_describe_identifier(datasource_name)}"
            )
            futures.append(
                (
                    datasource_name,
                    executor.submit(
                        trigger_datasource_refresh,
                        host=host,
                        auth_token=auth_token,
                        site_id=site_id,
                        api_version=api_version,
                        datasource_name=datasource_name,
                        project_tree=project_tree,
                        wait_for_completion=wait_for_completion,
                        timeout_minutes=timeout_minutes,
                    ),
                )
            )
        for datasource_name, future in futures:
            # Use longer timeout when waiting for completion
            future_timeout = (timeout_minutes * 60 + 120) if wait_for_completion else 120
            response_txt = future.result(timeout=future_timeout)
            results.append(response_txt)
            console.debug(
                f"Refreshed Tableau data source: "
                f"{_describe_identifier(datasource_name)} - {response_txt}"
            )
    return results


def trigger_datasource_refresh(
    *,
    host: str,
    auth_token: str,
    site_id: str,
    api_version: str,
    datasource_name: DatasourceIdentifier,  # str (name or UUID) or TableauPathName
    project_tree: Optional[_TableauProjectTree] = None,
    wait_for_completion: bool = False,
    timeout_minutes: int = 30,
) -> str:
    datasource_uuid: Optional[str] = None
    if isinstance(datasource_name, TableauPathName):
        if project_tree is None:
            project_tree = _TableauProjectTree(
                host=host,
                auth_token=auth_token,
                site_id=site_id,
                api_version=api_version,
            )
        display_name = _describe_identifier(datasource_name)
        console.debug(f"Resolving Tableau data source by path: {display_name}")
        project_luid = project_tree.resolve(datasource_name.project_path)
        datasource_uuid = _find_resource_in_project(
            host=host,
            auth_token=auth_token,
            site_id=site_id,
            api_version=api_version,
            project_luid=project_luid,
            resource_name=datasource_name.name,
            resource_kind="datasources",
        )
        return _refresh_datasource(
            host=host,
            auth_token=auth_token,
            site_id=site_id,
            api_version=api_version,
            datasource_uuid=datasource_uuid,
            display_name=display_name,
            wait_for_completion=wait_for_completion,
            timeout_minutes=timeout_minutes,
        )

    datasource_uuid = None

    def _is_uuid_format(value: str) -> bool:
        """Check if input string matches UUID format."""
        uuid_pattern = r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
        return bool(re.match(uuid_pattern, value, re.IGNORECASE))

    def _get_datasource_from_response(datasources_data: dict) -> Optional[str]:
        """Extract data source UUID from API response."""
        if (
            "datasources" not in datasources_data
            or "datasource" not in datasources_data["datasources"]
        ):
            return None

        datasource = datasources_data["datasources"]["datasource"]
        if isinstance(datasource, list) and len(datasource) > 0:
            return datasource[0]["id"]
        elif isinstance(datasource, dict):
            return datasource["id"]
        return None

    # If input looks like an ID, try direct access first
    if _is_uuid_format(datasource_name):
        try:
            console.debug(f"Input appears to be a UUID, trying direct access: '{datasource_name}'")
            direct_datasource_response = requests.get(
                f"{host}/api/{api_version}/sites/{site_id}/datasources/{datasource_name}",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Tableau-Auth": auth_token,
                },
            )

            if direct_datasource_response.status_code == 200:
                datasource_data = direct_datasource_response.json()
                if "datasource" in datasource_data:
                    datasource_uuid = datasource_data["datasource"]["id"]
                    console.debug(
                        f"Found data source by direct UUID access: '{datasource_name}' -> confirmed UUID: {datasource_uuid}"
                    )
            else:
                console.debug(
                    f"Could not access data source directly by UUID '{datasource_name}': HTTP {direct_datasource_response.status_code}"
                )
        except Exception as e:
            console.debug(f"Could not access data source by direct UUID '{datasource_name}': {e}")

    # If not found by direct ID access (or input wasn't an ID), try searching by name
    if datasource_uuid is None:
        try:
            console.debug(f"Searching for data source by name: '{datasource_name}'")
            datasource_response = requests.get(
                f"{host}/api/{api_version}/sites/{site_id}/datasources",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Tableau-Auth": auth_token,
                },
                params={"filter": f"name:eq:{datasource_name}"},
            )
            handle_http_error(
                datasource_response, f"Error searching for data source by name '{datasource_name}':"
            )

            datasources_data = datasource_response.json()
            datasource_uuid = _get_datasource_from_response(datasources_data)
            if datasource_uuid:
                console.debug(
                    f"Found data source by name: '{datasource_name}' -> UUID: {datasource_uuid}"
                )
        except Exception as e:
            console.debug(f"Could not find data source by name '{datasource_name}': {e}")

    # If still not found and input wasn't a UUID, try searching all datasources for an ID match
    if datasource_uuid is None and not _is_uuid_format(datasource_name):
        try:
            console.debug(
                f"Searching all data sources for potential UUID match: '{datasource_name}'"
            )
            all_datasources_response = requests.get(
                f"{host}/api/{api_version}/sites/{site_id}/datasources",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Tableau-Auth": auth_token,
                },
            )
            handle_http_error(
                all_datasources_response,
                f"Error getting all data sources while searching for '{datasource_name}':",
            )

            datasources_data = all_datasources_response.json()
            if (
                "datasources" in datasources_data
                and "datasource" in datasources_data["datasources"]
            ):
                datasources_list = datasources_data["datasources"]["datasource"]
                if isinstance(datasources_list, dict):
                    datasources_list = [datasources_list]

                for datasource in datasources_list:
                    if datasource.get("id") == datasource_name:
                        datasource_uuid = datasource["id"]
                        console.debug(
                            f"Found data source by UUID in all data sources search: '{datasource_name}' -> confirmed UUID: {datasource_uuid}"
                        )
                        break
        except Exception as e:
            console.debug(f"Could not search all data sources for UUID '{datasource_name}': {e}")

    # If still not found, raise an exception
    if datasource_uuid is None:
        raise Exception(
            f"Could not find data source with name or UUID '{datasource_name}'. Please check that the data source exists and you have permission to access it."
        )

    return _refresh_datasource(
        host=host,
        auth_token=auth_token,
        site_id=site_id,
        api_version=api_version,
        datasource_uuid=datasource_uuid,
        display_name=datasource_name,
        wait_for_completion=wait_for_completion,
        timeout_minutes=timeout_minutes,
    )


def _refresh_datasource(
    *,
    host: str,
    auth_token: str,
    site_id: str,
    api_version: str,
    datasource_uuid: str,
    display_name: str,
    wait_for_completion: bool,
    timeout_minutes: int,
) -> str:
    refresh_trigger = requests.post(
        f"{host}/api/{api_version}/sites/{site_id}/datasources/{datasource_uuid}/refresh",
        json={},
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Tableau-Auth": auth_token,
        },
    )
    handle_http_error(
        refresh_trigger,
        f"Error triggering refresh for data source '{display_name}' (UUID: {datasource_uuid}):",
    )

    if not wait_for_completion:
        return refresh_trigger.text

    job_id = _extract_job_id_from_response(refresh_trigger.text)
    if not job_id:
        console.debug(
            f"Could not extract job ID from refresh response for data source '{display_name}'. "
            f"Cannot monitor completion."
        )
        return refresh_trigger.text

    console.debug(f"Monitoring refresh job {job_id} for data source '{display_name}'...")

    job_status = _wait_for_job_completion(
        host=host,
        auth_token=auth_token,
        site_id=site_id,
        api_version=api_version,
        job_id=job_id,
        resource_type="Data source",
        resource_name=display_name,
        timeout_minutes=timeout_minutes,
    )

    return f"Refresh completed. Job status: {job_status}"


def list_tableau_workbooks(
    *,
    host: str,
    personal_access_token_name: str,
    personal_access_token_secret: str,
    site_name: str,
    api_version: str,
    json_output: bool = False,
) -> list | None:
    """List all Tableau workbooks with their names and UUIDs."""
    auth_response = requests.post(
        f"{host}/api/{api_version}/auth/signin",
        json={
            "credentials": {
                "personalAccessTokenName": personal_access_token_name,
                "personalAccessTokenSecret": personal_access_token_secret,
                "site": {"contentUrl": site_name},
            }
        },
        headers={"Accept": "application/json", "Content-Type": "application/json"},
    )
    handle_http_error(auth_response)

    auth_token: str = auth_response.json()["credentials"]["token"]
    site_id: str = auth_response.json()["credentials"]["site"]["id"]

    # Get all workbooks
    workbooks_response = requests.get(
        f"{host}/api/{api_version}/sites/{site_id}/workbooks",
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Tableau-Auth": auth_token,
        },
    )
    handle_http_error(workbooks_response, "Error getting workbooks:")

    workbooks_data = workbooks_response.json()

    if "workbooks" not in workbooks_data or "workbook" not in workbooks_data["workbooks"]:
        if not json_output:
            console.info("No workbooks found.")
        return [] if json_output else None

    workbooks = workbooks_data["workbooks"]["workbook"]
    if isinstance(workbooks, dict):
        workbooks = [workbooks]

    rows = []
    data = []
    for workbook in workbooks:
        name = workbook.get("name", "Unknown")
        wb_uuid = workbook.get("id", "Unknown")
        project_name = (
            workbook.get("project", {}).get("name", "Unknown")
            if isinstance(workbook.get("project"), dict)
            else "Unknown"
        )
        rows.append((name, wb_uuid, project_name))
        data.append({"name": name, "uuid": wb_uuid, "project": project_name})

    if json_output:
        return data

    console.table(
        columns=["Name", "UUID", "Project"],
        rows=rows,
        title="Tableau Workbooks",
    )
    return None


def list_tableau_datasources(
    *,
    host: str,
    personal_access_token_name: str,
    personal_access_token_secret: str,
    site_name: str,
    api_version: str,
    json_output: bool = False,
) -> list | None:
    """List all Tableau data sources with their names and UUIDs."""
    auth_response = requests.post(
        f"{host}/api/{api_version}/auth/signin",
        json={
            "credentials": {
                "personalAccessTokenName": personal_access_token_name,
                "personalAccessTokenSecret": personal_access_token_secret,
                "site": {"contentUrl": site_name},
            }
        },
        headers={"Accept": "application/json", "Content-Type": "application/json"},
    )
    handle_http_error(auth_response)

    auth_token: str = auth_response.json()["credentials"]["token"]
    site_id: str = auth_response.json()["credentials"]["site"]["id"]

    # Get all data sources
    datasources_response = requests.get(
        f"{host}/api/{api_version}/sites/{site_id}/datasources",
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Tableau-Auth": auth_token,
        },
    )
    handle_http_error(datasources_response, "Error getting data sources:")

    datasources_data = datasources_response.json()

    if "datasources" not in datasources_data or "datasource" not in datasources_data["datasources"]:
        if not json_output:
            console.info("No data sources found.")
        return [] if json_output else None

    datasources = datasources_data["datasources"]["datasource"]
    if isinstance(datasources, dict):
        datasources = [datasources]

    rows = []
    data = []
    for datasource in datasources:
        name = datasource.get("name", "Unknown")
        ds_uuid = datasource.get("id", "Unknown")
        ds_type = datasource.get("type", "Unknown")
        project_name = (
            datasource.get("project", {}).get("name", "Unknown")
            if isinstance(datasource.get("project"), dict)
            else "Unknown"
        )
        rows.append((name, ds_uuid, ds_type, project_name))
        data.append({"name": name, "uuid": ds_uuid, "type": ds_type, "project": project_name})

    if json_output:
        return data

    console.table(
        columns=["Name", "UUID", "Type", "Project"],
        rows=rows,
        title="Tableau Data Sources",
    )
    return None
