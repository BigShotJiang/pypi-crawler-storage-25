"""Tests for exploration mode definitions."""

import pytest

from pulseopt.modes import (
    build_candidate_configs_from_axes,
    build_default_modes,
    get_mode_by_name,
)


def test_build_default_modes_returns_expected_defaults() -> None:
    """Default modes should have stable names and numeric settings."""

    modes = build_default_modes(noise_std=0.15)

    assert [(mode.name, mode.lr_multiplier, mode.grad_noise_std) for mode in modes] == [
        ("base", 1.0, 0.0),
        ("conservative", 0.8, 0.0),
        ("aggressive", 1.2, 0.0),
        ("noisy", 1.0, 0.15),
        ("aggressive_noisy", 1.2, 0.15),
    ]


def test_get_mode_by_name_returns_matching_mode() -> None:
    """Lookup by name should return the requested immutable mode."""

    modes = build_default_modes(noise_std=0.2)

    mode = get_mode_by_name(modes, "aggressive_noisy")

    assert mode.name == "aggressive_noisy"
    assert mode.lr_multiplier == 1.2
    assert mode.grad_noise_std == 0.2


def test_get_mode_by_name_raises_clear_error_for_unknown_name() -> None:
    """Invalid names should produce a helpful error message."""

    modes = build_default_modes(noise_std=0.1)

    with pytest.raises(ValueError, match="Unknown exploration mode 'missing'") as exc_info:
        get_mode_by_name(modes, "missing")

    assert "base" in str(exc_info.value)


def test_build_candidate_configs_from_lr_and_noise_axes() -> None:
    """Structured candidates should be the LR/noise Cartesian product only."""

    candidates = build_candidate_configs_from_axes(
        lr_candidates=[1.0, 1.2],
        noise_candidates=[0.0, 0.01],
    )

    assert [(candidate.lr_multiplier, candidate.noise_std) for candidate in candidates] == [
        (1.0, 0.0),
        (1.0, 0.01),
        (1.2, 0.0),
        (1.2, 0.01),
    ]


def test_structured_modes_reject_adaptive_weight_decay_candidates() -> None:
    """AEES v1.0.0 should keep weight decay fixed in the structured path."""

    with pytest.raises(ValueError, match="Adaptive weight_decay candidates"):
        build_candidate_configs_from_axes(
            lr_candidates=[1.0],
            noise_candidates=[0.0],
            weight_decay_candidates=[0.5, 1.0],
        )
