"""Regression guards for the AEES v1.0.0 public config and CLI surface."""

from __future__ import annotations

from pathlib import Path
import subprocess
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_v1_reference_configs_expose_new_surface_and_hide_stale_fields() -> None:
    """Reference YAMLs should reflect the v1.0.0 thesis-facing surface."""

    checked_files = [
        PROJECT_ROOT / "configs" / "cifar100.yaml",
        PROJECT_ROOT / "configs" / "sst2.yaml",
        PROJECT_ROOT / "configs" / "adaptive.yaml",
        PROJECT_ROOT / "configs" / "random_scheduler.yaml",
        PROJECT_ROOT / "configs" / "fixed_modes.yaml",
    ]

    for path in checked_files:
        contents = path.read_text(encoding="utf-8")
        assert "driver_axis" not in contents
        assert "weight_decay_candidates" not in contents
        assert "structured_control_mode" in contents or path.name == "fixed_modes.yaml"
        assert "context_mode" in contents or path.name == "fixed_modes.yaml"
        assert "context_trend_window" in contents or path.name == "fixed_modes.yaml"
        assert "context_trend_epsilon" in contents or path.name == "fixed_modes.yaml"

    cifar_contents = (PROJECT_ROOT / "configs" / "cifar100.yaml").read_text(encoding="utf-8")
    assert "label_noise_type" in cifar_contents
    assert "label_noise_rate" in cifar_contents
    assert "lr_scheduler" in cifar_contents
    assert "scheduler_t_max" in cifar_contents
    assert "warmup_epochs" in cifar_contents


def test_v1_cli_surface_exposes_new_flags_and_not_stale_structured_flags() -> None:
    """The experiment help output should expose the v1 flags and omit old structured ones."""

    cifar_help = _run_help(PROJECT_ROOT / "experiments" / "task_cifar100.py")
    sst2_help = _run_help(PROJECT_ROOT / "experiments" / "task_sst2.py")
    agnews_help = _run_help(PROJECT_ROOT / "experiments" / "task_agnews.py")

    for help_text in [cifar_help, sst2_help, agnews_help]:
        assert "--lr-candidates" in help_text
        assert "--noise-candidates" in help_text
        assert "--structured-control-mode" in help_text
        assert "--context-mode" in help_text
        assert "--context-trend-window" in help_text
        assert "--context-trend-epsilon" in help_text
        assert "--lr-scheduler" in help_text
        assert "--scheduler-t-max" in help_text
        assert "--warmup-epochs" in help_text
        assert "--run-tag" in help_text
        assert "--driver-axis" not in help_text
        assert "--weight-decay-candidates" not in help_text

    assert "--label-noise-type" in cifar_help
    assert "--label-noise-rate" in cifar_help
    assert "--label-noise-type" not in sst2_help
    assert "--label-noise-rate" not in sst2_help
    assert "--label-noise-rate" in agnews_help


def _run_help(script_path: Path) -> str:
    completed = subprocess.run(
        [sys.executable, str(script_path), "--help"],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
        check=True,
    )
    return completed.stdout
