"""Regression guards for the AEES v1.0.0 orchestration helpers."""

from __future__ import annotations

from pathlib import Path

from experiments.run_v1_matrix import build_matrix_specs, parse_seeds
from experiments.run_v1_quick import build_quick_specs
from experiments.utils.run_plan import RunSpec, build_cli_args, runspec_to_command


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_build_cli_args_is_deterministic_and_omits_none_and_false() -> None:
    """CLI formatting should stay stable for manifests and printed commands."""

    args = {
        "noise_candidates": [0.0, 0.01],
        "method": "AdaptiveScheduler",
        "context_mode": "trend",
        "seed": 3,
        "unused_none": None,
        "print_only": False,
    }

    cli_args = build_cli_args(args)

    assert cli_args == [
        "--method",
        "AdaptiveScheduler",
        "--noise-candidates",
        "0,0.01",
        "--context-mode",
        "trend",
        "--seed",
        "3",
    ]


def test_quick_plan_generation_produces_expected_debug_runs() -> None:
    """The quick helper should stay small and CIFAR-focused."""

    specs = build_quick_specs(PROJECT_ROOT / "results" / "_tmp_quick_test")

    assert len(specs) == 6
    assert all(spec.script.endswith("task_cifar100.py") for spec in specs)
    assert {spec.args["method"] for spec in specs} == {"AdamW", "AdaptiveScheduler"}
    assert any(spec.args.get("context_mode") == "trend" for spec in specs)


def test_main_matrix_plan_is_filtered_and_uses_v1_surface() -> None:
    """The main matrix should generate thesis-relevant runs without stale flags."""

    specs = build_matrix_specs(
        plan="main",
        output_dir=PROJECT_ROOT / "results" / "_tmp_matrix_test",
        seeds=parse_seeds("0"),
        include_sst2=False,
    )

    assert specs
    assert any(spec.args["method"] == "AdamW" for spec in specs)
    assert any(spec.args["method"] == "AdaptiveScheduler" for spec in specs)
    assert len(specs) == len({spec.name for spec in specs})

    adaptive_specs = [spec for spec in specs if spec.args["method"] == "AdaptiveScheduler"]
    assert adaptive_specs
    assert any(spec.args.get("structured_control_mode") == "conditional" for spec in adaptive_specs)
    assert any(spec.args.get("context_mode") == "trend_phase" for spec in adaptive_specs)

    for spec in specs:
        command = runspec_to_command(spec)
        joined = " ".join(command)
        assert "--driver-axis" not in joined
        assert "--weight-decay-candidates" not in joined


def test_runspec_to_command_keeps_output_flag() -> None:
    """RunSpec rendering should preserve script path and output path cleanly."""

    spec = RunSpec(
        name="demo",
        script=str(PROJECT_ROOT / "experiments" / "task_cifar100.py"),
        args={
            "method": "AdamW",
            "epochs": 1,
            "output": str(PROJECT_ROOT / "results" / "demo.json"),
        },
        output_path=str(PROJECT_ROOT / "results" / "demo.json"),
        tags=["demo"],
    )

    command = runspec_to_command(spec, python_executable="python3.11")

    assert command[:2] == ["python3.11", str(PROJECT_ROOT / "experiments" / "task_cifar100.py")]
    assert "--output" in command
    assert str(PROJECT_ROOT / "results" / "demo.json") in command
