"""Immutable exploration mode definitions and helpers."""

from __future__ import annotations

from pulseopt.types import CandidateConfig


SUPPORTED_STRUCTURED_AXES = ("lr", "noise")


class ExplorationMode(CandidateConfig):
    """Backward-compatible alias for a scheduler candidate configuration."""

    def __init__(
        self,
        name: str,
        lr_multiplier: float = 1.0,
        grad_noise_std: float = 0.0,
        noise_std: float | None = None,
    ) -> None:
        resolved_noise_std = grad_noise_std if noise_std is None else noise_std
        super().__init__(
            name=name,
            lr_multiplier=lr_multiplier,
            noise_std=resolved_noise_std,
        )


def build_default_candidate_configs(noise_std: float) -> list[CandidateConfig]:
    """Build the backward-compatible default candidate configuration set."""

    if noise_std < 0.0:
        raise ValueError("noise_std must be non-negative.")
    return [
        CandidateConfig(name="base", lr_multiplier=1.0, noise_std=0.0),
        CandidateConfig(name="conservative", lr_multiplier=0.8, noise_std=0.0),
        CandidateConfig(name="aggressive", lr_multiplier=1.2, noise_std=0.0),
        CandidateConfig(name="noisy", lr_multiplier=1.0, noise_std=noise_std),
        CandidateConfig(name="aggressive_noisy", lr_multiplier=1.2, noise_std=noise_std),
    ]


def build_default_modes(noise_std: float) -> list[ExplorationMode]:
    """Build the backward-compatible default exploration modes."""

    return [
        ExplorationMode(
            name=candidate.name,
            lr_multiplier=candidate.lr_multiplier,
            noise_std=candidate.noise_std,
        )
        for candidate in build_default_candidate_configs(noise_std)
    ]


def parse_mode_names(mode_names_str: str) -> list[str]:
    """Parse a comma-separated mode list from the CLI."""

    names = [name.strip() for name in mode_names_str.split(",") if name.strip()]
    if not names:
        raise ValueError("mode_names must contain at least one non-empty mode name.")
    return names


def parse_lr_candidates(lr_candidates_str: str) -> list[float]:
    """Parse a comma-separated list of LR multipliers."""

    return _parse_float_candidates(
        values_str=lr_candidates_str,
        field_name="lr_candidates",
        positive_only=True,
    )


def parse_noise_candidates(noise_candidates_str: str) -> list[float]:
    """Parse a comma-separated list of gradient-noise values."""

    return _parse_float_candidates(
        values_str=noise_candidates_str,
        field_name="noise_candidates",
        positive_only=False,
    )


def parse_weight_decay_candidates(weight_decay_candidates_str: str) -> list[float]:
    """Reject deprecated structured weight-decay adaptation."""

    raise ValueError(
        "Adaptive weight_decay candidates were removed in AEES v1.0.0. "
        "Keep weight decay as a normal optimizer hyperparameter."
    )


def build_candidate_configs_from_axes(
    lr_candidates: list[float],
    noise_candidates: list[float],
    weight_decay_candidates: list[float] | None = None,
) -> list[CandidateConfig]:
    """Build candidate configs from the Cartesian product of LR and noise values."""

    if weight_decay_candidates not in (None, [1.0]):
        raise ValueError(
            "Adaptive weight_decay candidates are not supported in AEES v1.0.0."
        )
    if not lr_candidates:
        raise ValueError("lr_candidates must contain at least one value.")
    if not noise_candidates:
        raise ValueError("noise_candidates must contain at least one value.")

    candidate_configs: list[CandidateConfig] = []
    for lr_multiplier in lr_candidates:
        for noise_std in noise_candidates:
            candidate_configs.append(
                CandidateConfig(
                    name=build_generated_candidate_name(lr_multiplier, noise_std),
                    lr_multiplier=lr_multiplier,
                    noise_std=noise_std,
                )
            )
    return candidate_configs


def filter_candidate_configs_by_name(
    candidate_configs: list[CandidateConfig],
    selected_names: list[str],
) -> list[CandidateConfig]:
    """Select a validated subset of candidate configs in the requested order."""

    if not selected_names:
        raise ValueError("selected_names must contain at least one candidate name.")

    available_configs = {candidate.name: candidate for candidate in candidate_configs}
    filtered_configs: list[CandidateConfig] = []
    seen_names: set[str] = set()
    for name in selected_names:
        if name in seen_names:
            raise ValueError(f"Duplicate candidate config name requested: '{name}'.")
        if name not in available_configs:
            available = ", ".join(candidate.name for candidate in candidate_configs) or "<none>"
            raise ValueError(
                f"Unknown candidate config '{name}'. Available candidate configs: {available}."
            )
        seen_names.add(name)
        filtered_configs.append(available_configs[name])
    return filtered_configs


def filter_modes_by_name(
    modes: list[ExplorationMode],
    selected_names: list[str],
) -> list[ExplorationMode]:
    """Select a validated subset of modes in the requested order."""

    return [
        ExplorationMode(
            name=candidate.name,
            lr_multiplier=candidate.lr_multiplier,
            noise_std=candidate.noise_std,
        )
        for candidate in filter_candidate_configs_by_name(modes, selected_names)
    ]


def get_candidate_config_by_name(
    candidate_configs: list[CandidateConfig],
    name: str,
) -> CandidateConfig:
    """Return the candidate config with the requested name."""

    for candidate in candidate_configs:
        if candidate.name == name:
            return candidate
    available = ", ".join(candidate.name for candidate in candidate_configs) or "<none>"
    raise ValueError(
        f"Unknown candidate config '{name}'. Available candidate configs: {available}."
    )


def get_mode_by_name(modes: list[ExplorationMode], name: str) -> ExplorationMode:
    """Return the mode with the requested name."""

    for mode in modes:
        if mode.name == name:
            return mode
    available = ", ".join(mode.name for mode in modes) or "<none>"
    raise ValueError(f"Unknown exploration mode '{name}'. Available modes: {available}.")


def build_generated_candidate_name(
    lr_multiplier: float,
    noise_std: float,
    weight_decay_multiplier: float | None = None,
) -> str:
    """Build a stable readable candidate name for LR/noise settings."""

    parts = [
        f"lr{_format_float_token(lr_multiplier)}",
        f"n{_format_float_token(noise_std)}",
    ]
    if weight_decay_multiplier is not None:
        parts.append(f"wd{_format_float_token(weight_decay_multiplier)}")
    return "_".join(parts)


def get_axis_candidate_values(
    lr_candidates: list[float],
    noise_candidates: list[float],
    weight_decay_candidates: list[float] | None,
    axis_name: str,
) -> list[float]:
    """Return candidate values for the supported structured axes."""

    if axis_name == "lr":
        return list(lr_candidates)
    if axis_name == "noise":
        return list(noise_candidates)
    raise ValueError(f"Unsupported structured axis '{axis_name}' in AEES v1.0.0.")


def get_non_driver_structured_axes(driver_axis: str) -> list[str]:
    """Return the remaining structured axes for compatibility helpers."""

    validate_structured_axis_name(driver_axis)
    return [axis_name for axis_name in SUPPORTED_STRUCTURED_AXES if axis_name != driver_axis]


def validate_structured_axis_name(axis_name: str) -> str:
    """Validate one structured axis name."""

    if axis_name not in SUPPORTED_STRUCTURED_AXES:
        supported = ", ".join(SUPPORTED_STRUCTURED_AXES)
        raise ValueError(f"axis_name must be one of {supported}, got '{axis_name}'.")
    return axis_name


def resolve_structured_driver_axis(
    lr_candidates: list[float],
    noise_candidates: list[float],
    weight_decay_candidates: list[float] | None,
    requested_driver_axis: str | None,
) -> str:
    """Compatibility helper for older structured callers."""

    if weight_decay_candidates not in (None, [1.0]):
        raise ValueError(
            "Adaptive weight_decay candidates are not supported in AEES v1.0.0."
        )
    adaptive_axes = [
        axis_name
        for axis_name, values in {
            "lr": lr_candidates,
            "noise": noise_candidates,
        }.items()
        if len(values) > 1
    ]
    if requested_driver_axis is not None:
        validate_structured_axis_name(requested_driver_axis)
        if requested_driver_axis not in adaptive_axes and adaptive_axes:
            raise ValueError(
                f"requested_driver_axis '{requested_driver_axis}' is not adaptive."
            )
        return requested_driver_axis
    if not adaptive_axes:
        return "lr"
    return adaptive_axes[0]


def estimate_hierarchical_controller_count(
    lr_candidates: list[float],
    noise_candidates: list[float],
    weight_decay_candidates: list[float] | None,
    driver_axis: str,
) -> int:
    """Compatibility helper retained for old callers."""

    if weight_decay_candidates not in (None, [1.0]):
        raise ValueError(
            "Adaptive weight_decay candidates are not supported in AEES v1.0.0."
        )
    validate_structured_axis_name(driver_axis)
    driver_candidates = get_axis_candidate_values(
        lr_candidates=lr_candidates,
        noise_candidates=noise_candidates,
        weight_decay_candidates=None,
        axis_name=driver_axis,
    )
    downstream_axes = get_non_driver_structured_axes(driver_axis)
    adaptive_downstream_axes = [
        axis_name
        for axis_name in downstream_axes
        if len(
            get_axis_candidate_values(
                lr_candidates=lr_candidates,
                noise_candidates=noise_candidates,
                weight_decay_candidates=None,
                axis_name=axis_name,
            )
        )
        > 1
    ]
    return 1 + len(driver_candidates) * len(adaptive_downstream_axes)


def _parse_float_candidates(
    values_str: str,
    field_name: str,
    positive_only: bool,
) -> list[float]:
    raw_values = [value.strip() for value in values_str.split(",") if value.strip()]
    if not raw_values:
        raise ValueError(f"{field_name} must contain at least one value.")

    parsed_values: list[float] = []
    seen_values: set[float] = set()
    for raw_value in raw_values:
        try:
            value = float(raw_value)
        except ValueError as exc:
            raise ValueError(f"Invalid value '{raw_value}' in {field_name}.") from exc
        if positive_only and value <= 0.0:
            raise ValueError(f"{field_name} values must be positive.")
        if not positive_only and value < 0.0:
            raise ValueError(f"{field_name} values must be non-negative.")
        if value in seen_values:
            raise ValueError(f"{field_name} contains a duplicate value: {value}.")
        seen_values.add(value)
        parsed_values.append(value)
    return parsed_values


def _format_float_token(value: float) -> str:
    text = f"{value:.12g}"
    text = text.replace("-", "m").replace(".", "p")
    return text
