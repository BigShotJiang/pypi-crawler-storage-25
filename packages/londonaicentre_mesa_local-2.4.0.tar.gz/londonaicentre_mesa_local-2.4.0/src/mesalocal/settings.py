from pathlib import Path
from typing import Self

import yaml
from pydantic import AliasChoices, Field, computed_field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        extra="allow",
    )


class WeightsConfig(Config):
    id: str | None = None
    key: str | None = None
    uri: str | None = None
    region: str = "eu-west-2"
    assets_folder: str = "assets/weights"
    model_config = SettingsConfigDict(env_prefix="weights_")

    @model_validator(mode="after")
    def _validate_auth(self) -> Self:
        if (self.id is None) ^ (self.key is None):
            raise ValueError("id and key must be provided together")
        if self.uri is None and self.id is None:
            raise ValueError("provide at least one of: uri, or id and key")
        return self


class VLLMConfig(Config):
    model: str = Field(
        default="mesalocal", validation_alias=AliasChoices("model", "model_name")
    )
    gpu: str | None = Field(default=None, exclude=True)
    max_model_len: int = Field(
        default=41152, validation_alias=AliasChoices("max_model_len", "model_length")
    )
    enforce_eager: bool = False
    enable_chunked_prefill: bool = True
    enable_prefix_caching: bool = True
    gpu_memory_utilization: float = 0.9
    max_num_seqs: int = 1024
    max_num_batched_tokens: int | None = None
    enable_log_requests: bool = False
    uvicorn_log_level: str = "warning"
    http_timeout_keep_alive: int = 30

    @model_validator(mode="after")
    def _load_gpu_config(self) -> Self:
        if not self.gpu:
            return self
        config_path: Path = (
            Path(__file__).parent / "config" / self.gpu / f"{self.model}.yaml"
        )
        if not config_path.exists():
            return self
        with open(config_path) as config:
            for key, value in (yaml.safe_load(config) or {}).items():
                if key not in self.model_fields_set:
                    setattr(self, key, value)
        return self

    @computed_field  # type: ignore[misc]
    @property
    def served_model_name(self) -> list[str]:
        return [self.model]


class ServerConfig(Config):
    port: int = 5000
