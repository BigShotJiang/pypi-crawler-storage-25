from prwg_imdeathbang.data import *

def get_param_marshaling(param: Param) -> str:
    type = param.type
    if type == "bool":
        return "[MarshalAs(UnmanagedType.I1)] "
    return ""

def get_params_data(params: list[Param], declare: bool = True, marshal = True) -> str:    
    if not params:
        return ""
    
    data: list[str] = []
    if not declare:
        for param in params:
            data.append(f"{param.name}")
        return ", ".join(data)

    for param in params:
        marshaling = ""
        if marshal:
            marshaling = get_param_marshaling(param)
        data.append(f"{" " * 8}{marshaling}{param.type} {param.name}")
    return "\n" + ",\n".join(data) + "\n    "

def get_library_import(library_name, params: list[Param] = [], return_type: str = "") -> str:
    data: list[str] = []
    data.append(f'"{library_name}"')
    for param in params:
        if param.type == "string":
            data.append("StringMarshalling = StringMarshalling.Utf16")
    if return_type == "string":
        data.append("StringMarshalling = StringMarshalling.Utf16")
    return_marshal = ""
    if return_type == "bool":
        return_marshal = "\n    [return: MarshalAs(UnmanagedType.I1)]"
    call_convention = "[UnmanagedCallConv(CallConvs = new Type[] { typeof(CallConvCdecl) })]\n    "
    return f'{call_convention}[LibraryImport({", ".join(data)})]{return_marshal}'

def get_constructor_interop_data(library_name: str, constructor: Constructor) -> str:
    prefix = "    private static partial"
    import_data = get_library_import(library_name, params=constructor.params)
    if import_data:
        prefix = f"    {import_data}\n{prefix}"
    if constructor.options == ConstructorOptions.RETURN_INSTANCE:
        param_data = get_params_data(constructor.params)
        return f"{prefix} IntPtr {constructor.command}({param_data});\n"
    elif constructor.options == ConstructorOptions.RETURN_RESULT_OUT_INSTANCE:
        params = constructor.params.copy()
        params.append(Param("out IntPtr", "handle"))
        param_data = get_params_data(params)
        return f"{prefix} {constructor.result.type} {constructor.command}({param_data});\n"
    else:
        params = constructor.params.copy()
        params.append(Param("out IntPtr", "handle"))
        param_data = get_params_data(params)
        return f"{prefix} {constructor.result.type} {constructor.command}({param_data});\n"

def get_interop_commands_data(library_name: str, handle: Handle) -> str:
    data: list[str] = []
    constructor_data = get_constructor_interop_data(library_name, handle.constructor)
    if constructor_data:
        data.append(constructor_data)
    prefix = "    private static partial"
    for command in handle.commands:
        data.append(f'    {get_library_import(library_name, command.params, command.type)}')
        params: list[Param] = [Param("IntPtr", handle.name)] + command.params
        param_data = get_params_data(params)
        data.append(f"{prefix} {command.type} {command.name}({param_data});\n")
    for property in handle.properties:
        data.append(f'    {get_library_import(library_name, return_type=property.type)}')
        data.append(f"{prefix} {property.type} {property.get_name}(")
        data.append(f"        IntPtr {handle.name}")
        data.append("    );\n")
        return_param = Param(property.type, property.name)
        data.append(f'    {get_library_import(library_name, [return_param])}')
        data.append(f"{prefix} void {property.set_name}(")
        data.append(f"{" " * 8}IntPtr {handle.name},")
        data.append(f"{" " * 8}{property.type} {property.name}")
        data.append("    );\n")
    return "\n".join(data)

def get_constructor_data(handle: Handle) -> str:
    data: list[str] = []
    constructor = handle.constructor
    param_data = get_params_data(constructor.params)
    data.append(f"    public {handle.type}({param_data}) {{")
    if constructor.options == ConstructorOptions.RETURN_INSTANCE:
        params_data = get_params_data(constructor.params, declare=False)
        data.append(f"        _handle = {constructor.command}({params_data});")
        data.append("        if (_handle == IntPtr.Zero) {")
        data.append('            throw new InvalidOperationException("Handle is NULL");')
        data.append("        }")
    elif constructor.options == ConstructorOptions.RETURN_RESULT_OUT_INSTANCE:
        result = constructor.result
        params = constructor.params.copy()
        params.append(Param("", "out IntPtr handle"))
        params_data = get_params_data(params, declare=False)
        data.append(f"        {result.type} result = {constructor.command}({params_data});")
        data.append(f"        if (result != {result.type}.{result.success}) {{")
        data.append("            throw new InvalidOperationException(result.ToString());")
        data.append("        }")
        data.append("        _handle = handle;")
    else:
        params = constructor.params.copy() + Param("", "out IntPtr handle")
        params_data = get_params_data(params, declare=False)
        data.append(f"        {constructor.command}({params_data});")
        data.append("        if (handle == IntPtr.Zero) {")
        data.append('            throw new InvalidOperationException("Handle is NULL");')
        data.append("        }")
        data.append("        _handle = handle;")
    data.append("    }")
    return "\n".join(data) + "\n"

def get_members_data(handle: Handle) -> str:
    data: list[str] = []
    data.append(f"    private IntPtr _handle;")
    return "\n".join(data) + "\n"

def get_enumerators_data(enumerators: list[Enumerator]) -> str:
    data: list[str] = []
    for enumerator in enumerators:
        data.append(f"    {enumerator.name} = {enumerator.value}")
    return ",\n".join(data)

def get_enum_data(library_name: str, enum: Enum) -> str:
    data: list[str] = []
    data.append(f"namespace {library_name};\n")
    data.append(f"public enum {enum.name} : {enum.type} {{")
    data.append(get_enumerators_data(enum.enumerators))
    data.append("}")
    return "\n".join(data)

def pascal_command_name(name: str) -> str:
    return name[0].upper() + name[1:]

def get_commands_data(handle: Handle) -> str:
    data: list[str] = []
    prefix = "    public"
    for command in handle.commands:
        param_data = get_params_data(command.params, marshal=False)
        name = pascal_command_name(command.name)
        data.append(f"{prefix} {command.type} {name}({param_data}) {{")

        params: list[Param] = [Param("", "_handle")] + command.params

        call_data = get_params_data(params, declare=False)
        postfix = "        return "
        if command.type == "void":
            postfix = "        "
        data.append(f"{postfix}{command.name}({call_data});")
        data.append("    }\n")
    return "\n".join(data)

def get_property_data(property: Property) -> str:
    data: list[str] = []
    data.append(f"    public {property.type} {pascal_command_name(property.name)} {{")
    data.append(f"        get => {property.get_name}(_handle);")
    data.append(f"        set => {property.set_name}(_handle, value);")
    data.append("    }")
    return "\n".join(data)

def get_properties_data(handle: Handle) -> str:
    data: list[str] = []
    if not handle.properties:
        return ""

    for property in handle.properties:
        data.append(get_property_data(property))
    return "\n".join(data) + "\n"

def get_handle_data(library_name: str, handle: Handle) -> str:
    data: list[str] = []
    data.append("using System.Runtime.InteropServices;")
    data.append("using System.Runtime.CompilerServices;\n")
    data.append(f"namespace {library_name};\n")
    data.append(f"public partial class {handle.type} {{\n")
    data.append(get_interop_commands_data(library_name, handle))
    data.append(get_members_data(handle))
    properties_data = get_properties_data(handle)
    if properties_data:
        data.append(properties_data)
    data.append(get_constructor_data(handle))
    data.append(get_commands_data(handle))
    data.append("}")
    return "\n".join(data) + "\n"

def process_handle(library_name: str, target_directory: str, handle: Handle):
    with open(f"{target_directory}/{handle.type}.cs", "w") as file:
        file.write(get_handle_data(library_name, handle))

def process_enum(library_name: str, target_directory: str, enum: Enum):
    with open(f"{target_directory}/{enum.name}.cs", "w") as file:
        file.write(get_enum_data(library_name, enum))

def process_data(parsed_data: ParsedData):
    for handle in parsed_data.handles:
        process_handle(parsed_data.project_name, parsed_data.target_directory, handle)
    for enum in parsed_data.enums:
        process_enum(parsed_data.project_name, parsed_data.target_directory, enum)

def get_type_dict() -> dict[str, str]:
    return {
        "string": "string"
    }