# R5-A 抓包报告 — Notion Custom Agent 异步运行 endpoint 序列

**目的**：搞清 Notion chat panel 跑长任务 Custom Agent 时走的 endpoint 序列，决定 CLI 怎么实现 detach + follow。
**方法**：Playwright persistent context + CDP，hook 全部 `/api/v3` request/response 实时写 NDJSON。
**捕获日期**：2026-05-16 17:40–17:44 PT
**目标 Agent**：Omada 周报 Agent (`workflowId=c8a3359d-5dab-49ee-aa0a-5d9fba7df667`)
**Space**：TP-Link (`spaceId=883c77cc-e7d8-4103-84a8-13ba401a991c`)
**User**：Lucien Chen (`userId=3f4b90ff-b3eb-4e34-b080-0b45a23f4fa2`)

---

## TL;DR — 答案

**没有 `runStart` / `runStatus` 这类原生异步 API。**

整个异步运行架构是这样的：

1. **客户端预生成 threadId（UUID v4）** — 不是 server 分发
2. **`POST /api/v3/runInferenceTranscript`**（Content-Type: application/x-ndjson）— 一次 HTTP POST，**长连接 NDJSON 流**，server 把事件流写回 socket 直到任务完成。**这就是"吊着"的同步路径**，CLI 当前用的也是这条
3. **重新打开 panel / 切回 agent 时**，UI 调一组**轮询型**端点拿"当前状态"：
   - `getInferenceTranscriptsForWorkflow` → 拉历史 thread 列表（按 workflow 维度，含 thread_id + 累计 usage）
   - `getInferenceTranscriptsForUser` → 同上但按 user 维度
   - `listPausedWorkflowRuns` → 找因 credit/run-limit 暂停的 run
   - `getInferenceTranscriptsUnreadCount` → 未读计数
4. **"恢复 in-progress run" 看起来没有专门接口**。如果原来的 NDJSON 流已经断开，新流的接续机制本次没观测到（任务 ~1 分钟跑完，可能太短没触发暂停）

---

## 对 CLI 实现的判断

**Detach + Follow 策略**：

| 你要实现的 | 怎么做 |
|---|---|
| **fire-and-forget**（发起后立刻 detach） | client 自己生成 threadId（UUID v4），调 `runInferenceTranscript` 时把 NDJSON socket 让 server 写到 `/dev/null`，然后立刻退出。run 在 server 端继续 |
| **find current runs**（查"我有哪些跑过/在跑的"） | `POST /api/v3/getInferenceTranscriptsForWorkflow` `{workflowId, spaceId, limit}` — 返 transcript 列表 + usage |
| **follow（重连看进度）** | 重新 `POST runInferenceTranscript` 带同 `threadId`、`createThread:false`、`isPartialTranscript:true`、可能 `transcript:[]` —— 这是猜测，需要继续抓 |
| **list paused** | `POST listPausedWorkflowRuns` `{workflowId, spaceId, pausedReasons:["creditLimit","runLimit","runawayCreditUsage"], countOnly:true/false}` |

**坑**：本次 60 秒"切走"窗口太短，长任务 ~1 分钟跑完，没观测到"返回时有未完成 run"的具体 reconnect 调用。如果 CC 想确认 follow 的 RPC 形状，需要再抓一次更长任务（≥5 分钟）。

---

## 完整 endpoint 清单（仅 async runs 相关）

```
POST /api/v3/runInferenceTranscript           ← 主流，NDJSON 长流
POST /api/v3/getInferenceTranscriptsForWorkflow  ← workflow 维度拉历史
POST /api/v3/getInferenceTranscriptsForUser   ← user 维度拉历史
POST /api/v3/getInferenceTranscriptsUnreadCount  ← unread counter
POST /api/v3/listPausedWorkflowRuns           ← 暂停 run 列表
POST /api/v3/markInferenceTranscriptSeen      ← mark unread/seen
POST /api/v3/getWorkflowCreditUsage           ← 累计 credit
POST /api/v3/getPendingWorkflowCreditLimitIncreaseRequest
POST /api/v3/getPublicWorkflowData
POST /api/v3/getCustomAgents
POST /api/v3/getAgentTemplates
```

---

## runInferenceTranscript 详细规约

### Request

```http
POST /api/v3/runInferenceTranscript HTTP/2
Content-Type: application/json
Accept: application/x-ndjson
x-notion-active-user-header: REDACTED
x-notion-space-id: REDACTED
notion-client-version: 23.13.20260516.1857
```

**Body**（top-level keys）：

```json
{
  "traceId": "<uuid>",
  "spaceId": "883c77cc-e7d8-4103-84a8-13ba401a991c",
  "threadId": "36315375-830d-80bc-947a-00a981cb1901",
  "threadType": "workflow",
  "threadParentPointer": {
    "table": "workflow",
    "id": "c8a3359d-5dab-49ee-aa0a-5d9fba7df667",
    "spaceId": "883c77cc-e7d8-4103-84a8-13ba401a991c"
  },
  "createThread": true,
  "generateTitle": true,
  "asPatchResponse": true,
  "isPartialTranscript": false,
  "hasHeartbeat": false,
  "saveAllThreadOperations": true,
  "setUnreadState": true,
  "transcript": [
    { "id": "<uuid>", "type": "config", "value": { "type": "workflow", "workflowId": "...", "enable*": true/false, ... 60+ feature flags ... } },
    { "id": "<uuid>", "type": "context", "value": { "timezone": "America/Los_Angeles", "userName": "...", "userId": "...", "spaceId": "...", "currentDatetime": "ISO8601", "surface": "custom_agent", "workflowId": "...", "context_page_id": "..." } },
    { "id": "<uuid>", "type": "user", "value": [[<user input rich text>]] }
  ]
}
```

**关键字段含义**（client → server 的运行控制信号）：
- `threadId` — **客户端生成的 UUID**，是 run 的稳定标识
- `createThread: true` — 新建 thread；恢复时应该是 false
- `isPartialTranscript: false` — 是否完整 transcript（断点续传可能用 true）
- `hasHeartbeat: false` — 是否启用心跳维持长连接（**值得 CC 尝试设 true 看 server 行为**）
- `saveAllThreadOperations: true` — server 端是否持久化操作（说明 server 端确实有 run 状态存档）
- `setUnreadState: true` — 完成后是否标 unread
- `asPatchResponse: true` — 响应是否用 patch 格式

### Response

```http
HTTP/2 200
Content-Type: application/x-ndjson
X-Content-Type-Options: nosniff
X-Notion-Request-Id: REDACTED
```

Body 是 NDJSON 长流，每行一个事件。Playwright 在流断开前抓不到 body（已确认报错 `No resource with given identifier found`）。**CC 自己实现客户端时直接按行读 socket 即可。**

---

## getInferenceTranscriptsForWorkflow 详细规约

### Request
```json
POST /api/v3/getInferenceTranscriptsForWorkflow
{
  "workflowId": "c8a3359d-5dab-49ee-aa0a-5d9fba7df667",
  "spaceId": "883c77cc-e7d8-4103-84a8-13ba401a991c",
  "limit": 10
}
```

可选变体（同时观测到）：
```json
{ "workflowId": "...", "spaceId": "...", "userId": "..." }
```

### Response（节选）
```json
{
  "threadIds": [
    "36315375-830d-80bc-947a-00a981cb1901",
    "36315375-830d-80e6-bbc2-00a9d8b02578",
    "36315375-830d-804d-9392-00a9e7dfe73a",
    ...
  ],
  "transcripts": [
    {
      "id": "36315375-830d-80bc-947a-00a981cb1901",
      "title": "Omada 本周项目进展",
      "created_at": 1778978517768,
      "updated_at": 1778978613661,
      "created_by_display_name": "Lucien Chen",
      "type": "workflow",
      "usage_summary": {
        "spend_usd": 1.03971355,
        "input_tokens": 302950,
        "output_tokens": 3546,
        "completion_count": 4,
        "last_updated_time": 1778978589629,
        "credits_by_type_unit": {
          "basic_ai_credits": 0,
          "premium_ai_credits": 137,
          "preview_ai_credits": 0
        },
        "agent_inference_count": 3,
        "cached_input_tokens_read": 301759,
        "cached_input_tokens_created": 127397
      }
    }
  ]
}
```

⚠️ **transcript 顶层 schema 里没有 `status` / `in_progress` / `paused` 字段**。靠 `last_updated_time` 比 wall clock 判断是否仍在 run，或者结合 `listPausedWorkflowRuns`。

---

## listPausedWorkflowRuns 详细规约

```json
POST /api/v3/listPausedWorkflowRuns
{
  "spaceId": "883c77cc-e7d8-4103-84a8-13ba401a991c",
  "workflowId": "c8a3359d-5dab-49ee-aa0a-5d9fba7df667",
  "pausedReasons": ["creditLimit", "runLimit", "runawayCreditUsage"],
  "countOnly": true
}
```

`countOnly:true` 时仅返计数；`false` 时返完整列表（本次未捕获列表 shape，因为没暂停的 run）。

---

## 时间线（关键事件，对齐了 phase mark 和实际 HTTP 调用）

| 时刻 (UTC) | 事件 |
|---|---|
| 00:41:55 | **phase: v2_B_start** — UI 即将发送长任务 |
| 00:41:55 | `getInferenceTranscriptsForUser` (panel 预热) |
| 00:41:55 | `listPausedWorkflowRuns` (检查有没有 paused) |
| 00:41:55 | `getInferenceTranscriptsForWorkflow` ×2 |
| 00:41:57 | **phase: v2_B_sent** — 用户消息送出 |
| 00:41:57 | **`POST runInferenceTranscript`** ← run 发起，NDJSON 长流 |
| 00:41:57 | `getInferenceTranscriptsForWorkflow` ×2 (refresh 列表) |
| 00:41:57 | `getInferenceTranscriptsForUser` |
| 00:42:37 | **phase: v2_C_leave** — 准备 navigate 走 |
| 00:42:40 | `getInferenceTranscriptsForUser` (panel 后台 keepalive) |
| 00:42:41 | **phase: v2_C_left** — 已在 Eagle Sentry 页 |
| (60s 静默) | — |
| 00:43:41 | **phase: v2_C_return** — 准备回 agent |
| 00:43:43 | **phase: v2_C_returned** — 已在 Omada 周报 Agent 页 |
| 00:43:43 | `listPausedWorkflowRuns` ×2 ← **resume 探测**（确认无 paused） |
| 00:43:43 | `getInferenceTranscriptsForWorkflow` ×2 ← **resume 探测**（拉历史 thread 列表） |
| 00:43:43 | `getInferenceTranscriptsForUser` |
| 00:43:44 | `getInferenceTranscriptsForWorkflow` (第二批 refresh) |
| 00:44:10 | **phase: v2_D_done** — 任务完成（实际可能 ~00:43:55 完成，UI 显示 1m ago） |
| 00:44:11 | `getInferenceTranscriptsForWorkflow` ×2 (最终 refresh) |

**关键观察**：return 时刻（00:43:43）触发的 endpoint 组合 = `listPausedWorkflowRuns + getInferenceTranscriptsForWorkflow + getInferenceTranscriptsForUser`，**没有 reconnect runInferenceTranscript**。这说明：
- 如果 run 还在跑，UI 可能在拉 thread 列表里发现 "这个 thread last_updated_time 是最近的、completion_count 还在涨" 来推断 in-progress
- 或者通过 WebSocket（**本次没观察到任何 WS**，可能因为 Notion 在这条 panel 上没启用）
- 真正的 NDJSON 流是否在 navigate-away 时被 server 主动关闭、还是 client 在后台维持，从客户端这边看不出来

---

## 给 CC 的下一步建议

1. **实现 fire-and-forget**：直接照 runInferenceTranscript 规约走，client 生成 threadId，发完关 socket
2. **实现 list-runs**：用 `getInferenceTranscriptsForWorkflow` + 比较 `last_updated_time` 来推断 in-progress
3. **如果需要真正的 follow 接口**，需要再抓一次：
   - 跑一个**更长**的 batch（≥5 分钟）
   - 在跑的过程中**完全杀掉 client**（不是 navigate，而是关 tab）
   - 再开 tab 回到 agent，看 UI 是否触发某个**新的** endpoint 把流接回来
4. **`hasHeartbeat: true`** 这个 client 端 flag 值得做对比实验 — 它可能切换 server 用 long-polling vs streaming

---

## 文件清单

- `/tmp/notion-capture/requests.ndjson` — 全部 1359 条 request/response（11MB，cookie / x-notion-* headers 已脱敏）
- `/tmp/notion-capture/async-runs-only.ndjson` — 仅 async runs 相关 endpoint（1496 行，1MB）
- `/tmp/notion-capture/phases.jsonl` — phase 时间戳
- `/tmp/notion-capture/R5-A-REPORT.md` — 本文档
