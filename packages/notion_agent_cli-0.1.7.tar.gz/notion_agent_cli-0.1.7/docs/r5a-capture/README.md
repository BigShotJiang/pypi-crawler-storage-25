# R5-A Capture (2026-05-16)

Network capture for designing async run support in 0.1.7.

- **`R5-A-REPORT.md`** — Analysis + endpoint specs + CLI recommendations
- **`async-runs-only.ndjson`** (1MB, 1496 lines) — Filtered to run/transcript/workflow endpoints
- **`phases.jsonl`** — UI action timeline aligned with HTTP timing
- **Full capture (~11MB, 1359 lines)** — Available at `~/Downloads/notion-r5a-capture/requests.ndjson`, gitignored

Capture method: Playwright persistent context + per-request hook → NDJSON.
Sanitization: `cookie`, `set-cookie`, `x-notion-*` headers replaced with `REDACTED`. UUIDs (user/space/workflow/thread IDs) preserved.

Target: Omada 周报 Agent (workflowId `c8a3359d-5dab-49ee-aa0a-5d9fba7df667`) in TP-Link space.
