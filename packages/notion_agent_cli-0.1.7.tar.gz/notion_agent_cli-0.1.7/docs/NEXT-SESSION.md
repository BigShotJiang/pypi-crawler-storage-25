# Next-session handoff — v0.1.7 verify + R5-C carry-over

> Written 2026-05-16 right after shipping v0.1.7. v0.1.6 closed the
> agents-list-name saga + the post-success polish; v0.1.6.1 added
> the conceptual upgrade (binding_mode + four-axis docs); v0.1.7
> ships **R5-A** — async-run support — the long-standing blocker
> jarvis kept hitting on workflow-mode Custom Agents.

## TL;DR — what's in v0.1.7

Three commits (feature + bump + this NEXT-SESSION refresh):

- **R5-A: workflow-mode async runs**. New `runs` subcommand wraps
  the three endpoints captured in `docs/r5a-capture/R5-A-REPORT.md`:
  - `runs start <prompt> --workflow <id>` — fire-and-forget POST to
    `/runInferenceTranscript` in workflow mode
    (`threadParentPointer.table="workflow"`,
    `context.surface="custom_agent"`, `context.workflowId=<id>`,
    `createdSource="custom_agent"`). Waits for 200, closes socket,
    Notion continues the run server-side via
    `saveAllThreadOperations:true`. Returns thread_id.
  - `runs list --workflow <id>` — wraps
    `/getInferenceTranscriptsForWorkflow`. Sorts newest-first by
    `usage_summary.last_updated_time`; flags rows inside
    `--stale-after <sec>` (default 90s) as `in_progress` heuristically
    since the endpoint has no native status field.
  - `runs paused --workflow <id>` — wraps
    `/listPausedWorkflowRuns`. Raw JSON pass-through until we have a
    captured response shape (R5-A: operator's workspace had no
    paused runs at the time).
- **Streaming variants for `runs start`**:
  - `--stream` — same workflow-mode body, but keep socket open and
    print text chunks live (LLM streaming style). thread_id surfaces
    on stderr so `... --stream | tee` doesn't muddy captured body.
  - `--ndjson` — same socket-open behavior, raw NDJSON to stdout.
  - Default (no flag) stays detach.
- **`workflow_id` threaded through `complete()` / `stream_lines()`** —
  same `_prepare_call` builds the body for detach and attached paths,
  so the wire shape can't drift between fire-and-forget and stream.
- **`ThreadState.workflow_id`** — persisted per-thread, so
  `chat --thread-id <id>` continuations after a workflow run stay in
  workflow mode (partial transcript keeps `context.workflowId`).

Tests 239 → 258. New file `tests/test_runs.py` (10 cases) + fixture
`get_inference_transcripts_for_workflow_list.json`. One existing test
`tests/test_thread_state.py::test_json_keys_match_dataclass_fields`
got the new `workflow_id` key added to its expected set.

## Startup checks (~30s)

```bash
.venv/bin/pytest -q | tail -3                    # expect 258 pass
.venv/bin/ruff check src tests | tail -1         # expect "All checks passed!"
notion-agent --version                           # 0.1.7
git log --oneline -8
git status -s                                    # expect clean
```

PyPI fanout (Trusted Publishing fires per tag push; takes ~5 min):

```bash
curl -s https://pypi.org/simple/notion-agent-cli/ \
  | grep -oE 'notion[_-]agent[_-]cli-0\.1\.[567]'
# expect notion_agent_cli-0.1.5, 0.1.6, 0.1.6.1, 0.1.7
```

## Operator quickstart (paste into chat history when LLM operator asks)

```bash
# 1) Find workflow_id (= agent_id)
notion-agent agents list

# 2) Async-launch a long Custom Agent run
notion-agent runs start "生成本周项目周报" \
    --workflow <agent_id> --json
# → {"thread_id": "<tid>", "workflow_id": "<wid>"}

# 3) Poll status (last_updated within 90s ⇒ in_progress)
notion-agent runs list --workflow <agent_id>

# 4) When done, continue the thread
notion-agent chat "刚才提到的 X 项目展开说" --thread-id <tid>

# Variants:
notion-agent runs start "..." --workflow <id> --stream   # watch live
notion-agent runs start "..." --workflow <id> --ndjson   # raw events
notion-agent runs paused --workflow <id> --count-only    # discovery
```

## The big open thread — R5-C `runs follow`

R5-C ("watch one in-flight run's progress") is **not in v0.1.7** by
design. Two paths forward:

| Path | Status |
|---|---|
| **A. Poll-based follow** — `runs follow --thread-id <tid> --workflow <wid>` loops `getInferenceTranscriptsForWorkflow`, prints `completion_count` / `spend_usd` / `last_updated_time` deltas, exits when stale | ✅ Buildable today; all endpoints already wrapped. ~50 LOC. |
| **B. NDJSON reconnect follow** — re-POST `/runInferenceTranscript` with same threadId + `createThread:false` + `isPartialTranscript:true` + `transcript:[]` | ❌ R5-A: shape is *speculation*. Needs a fresh capture: long batch (≥5 min), fully kill client (close tab, not navigate), reopen, see what new endpoint UI hits. |

R5-A report's "下一步建议 §3" is the explicit ask if jarvis re-asserts
the need.

## Other carry-overs

- **R5-B → embedding/proxy router** — same as last round: jarvis
  v0.1.6 §2 瑕疵 1 (cross-lingual gaps, `emails` vs `邮件`) and 瑕疵 3
  (semantically-close names) are real keyword-router limits. Deferred
  until reported as blocking in real usage.
- **`hasHeartbeat: true` experiment** — R5-A § runInferenceTranscript
  flagged it as worth toggling to see whether server flips to
  long-polling. Untouched; useful follow-up when reconnect work
  starts.

## Likely v0.1.7 feedback shape

Probability ordered from most to least:

1. **🎉 R5-A unblocks the 9+ minute hang.** jarvis kicks off a real
   batch agent run, gets thread_id back immediately, polls with
   `runs list` until the row stops moving, then continues with
   `chat --thread-id`. This is the "did v0.1.7 fix the headline
   problem" path.
2. **Wants `runs follow` poll mode**. Reasonable ask; build per
   §"R5-C carry-over above".
3. **First `--stream` use hits something flaky** — NDJSON parser was
   already battle-tested on chat-mode streams but workflow-mode emits
   different tool-call events. If a specific event type breaks the
   parser, `tests/test_notion_agent_cli.py` is where the captured
   event ladder gets pinned.
4. **`runs paused` returns a shape we want to parse properly** —
   commit a sanitized fixture under `tests/fixtures/` and extend
   `runs.py` with a `parse_paused_runs()` helper.

## Hot paths (round-7+ changes likely land here)

| Theme | First file to look at |
|---|---|
| R5-C poll-follow | `src/notion_agent_cli/cli/__main__.py::_cmd_runs_list` (extract the in-progress heuristic; add `_cmd_runs_follow` that loops it) |
| R5-C NDJSON reconnect | `src/notion_agent_cli/provider.py::start_run_detached` + `transcript.build_inference_request` (need `isPartialTranscript:true` + empty transcript variant) |
| Workflow run event types | `src/notion_agent_cli/ndjson.py` (current parser handles chat-mode events; workflow tools emit additional event_type values worth pinning) |
| Account-bound default workflow | `src/notion_agent_cli/account.py` + `init` reverse-resolve (jarvis may want a default workflow per profile, so `runs start` doesn't need `--workflow` every time) |

## What NOT to touch

Same baseline. Plus:

- **Don't strip the workflow_id from ThreadState.** It's the only way
  a chat-mode continuation knows to send `surface="custom_agent"` +
  `context.workflowId` for follow-up turns. Removing it would silently
  flip continuation back to default-AI mode and the operator wouldn't
  see why their follow-up didn't trigger tool calls.
- **Don't guess the `listPausedWorkflowRuns` response shape.** R5-A
  was explicit that the shape wasn't captured. The current raw JSON
  passthrough is honest; speculative parsing would set a wrong
  contract.
- **Keep streaming + detach using the same `_prepare_call`.** If you
  diverge them (e.g. inline body construction in `start_run_detached`),
  the next time we add a workflow-mode field someone will forget one
  path and the bug surfaces as "fire-and-forget works but `--stream`
  doesn't trigger tools".

## How to ship v0.1.8 (when R5-C lands or a new round drops)

Same SOP — three commits (feature + bump + NEXT-SESSION refresh) +
tag + push. v0.1.6 + v0.1.6.1 + v0.1.7 tag pushes all worked, so the
prior auth blocker is resolved and the pipeline is healthy.

## Done state for this session

You're done when:

1. v0.1.7 is live on PyPI (tag push → Trusted Publishing; ~5 min
   after `git push origin v0.1.7`).
2. jarvis tries one real workflow-mode run end-to-end:
   - `runs start "<batch task>" --workflow <id>` returns thread_id immediately
   - `runs list --workflow <id>` shows the run as `in_progress`
   - Eventually it flips to `completed?`
   - `chat --thread-id <tid> "<follow-up>"` continues the same thread
3. If jarvis asks for `runs follow` (likely), scope R5-C path A and
   ship in v0.1.8. Path B keeps waiting for the long-batch capture.
