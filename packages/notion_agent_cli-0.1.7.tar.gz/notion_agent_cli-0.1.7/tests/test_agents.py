"""Unit tests for the agents module + /getCustomAgents wrapper.

Uses ``tests/fixtures/get_custom_agents.json`` — a sanitized copy of a
real Notion response (UUIDs and titles redacted to synthetic patterns
``a0000001-...`` for agents, ``70000001-...`` for threads, etc.).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from notion_agent_cli import NotionAgentClient, NotionAgentError
from notion_agent_cli.agents import (
    AgentSummary,
    ThreadSummary,
    extract_workflow_description,
    extract_workflow_icon,
    extract_workflow_instructions_page_id,
    extract_workflow_name,
    parse_agents,
    parse_threads,
    parse_workflow_records,
)

FIXTURES = Path(__file__).parent / "fixtures"


def _load_fixture(name: str) -> dict[str, Any]:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


# --------------------------------------------------------------------------- #
# parse_threads
# --------------------------------------------------------------------------- #

class TestParseThreads:
    def test_real_fixture_yields_all_entries(self):
        data = _load_fixture("get_custom_agents.json")
        threads = parse_threads(data)
        assert len(threads) == len(data["mostRecentTranscripts"])
        # All ids preserved as strings
        for t in threads:
            assert isinstance(t.thread_id, str)
            assert t.thread_id.startswith("7")  # sanitized prefix for threads

    def test_real_fixture_sorted_newest_first(self):
        threads = parse_threads(_load_fixture("get_custom_agents.json"))
        # Take entries with timestamps; verify monotonic non-increasing.
        timestamps = [
            (t.updated_at_ms or t.created_at_ms or 0) for t in threads
        ]
        assert timestamps == sorted(timestamps, reverse=True)

    def test_real_fixture_titles_round_trip_with_none(self):
        threads = parse_threads(_load_fixture("get_custom_agents.json"))
        # Some real transcripts had null titles — that should survive as None.
        any_none = any(t.title is None for t in threads)
        any_str = any(isinstance(t.title, str) for t in threads)
        assert any_none, "fixture should contain at least one null title"
        assert any_str

    def test_empty_response(self):
        assert parse_threads({}) == []
        assert parse_threads({"mostRecentTranscripts": []}) == []

    def test_skips_non_dict_and_missing_id(self):
        data = {"mostRecentTranscripts": [
            "not-a-dict",
            {"no_id_field": True},
            {"id": 42},
            {"id": "good", "title": "ok"},
        ]}
        threads = parse_threads(data)
        assert len(threads) == 1
        assert threads[0].thread_id == "good"

    def test_int_coercion_of_timestamps(self):
        # Notion returns timestamps as strings.
        data = {"mostRecentTranscripts": [
            {"id": "t1", "created_time": "1778017615141",
             "updated_time": "1778021049107"},
        ]}
        t = parse_threads(data)[0]
        assert t.created_at_ms == 1778017615141
        assert t.updated_at_ms == 1778021049107


# --------------------------------------------------------------------------- #
# parse_agents
# --------------------------------------------------------------------------- #

class TestParseAgents:
    def test_real_fixture_yields_all_agents(self):
        data = _load_fixture("get_custom_agents.json")
        agents = parse_agents(data)
        assert len(agents) == len(data["agentIds"])
        for a in agents:
            assert isinstance(a.agent_id, str)

    def test_real_fixture_active_agents_have_scores(self):
        data = _load_fixture("get_custom_agents.json")
        agents = parse_agents(data)
        # activityScores covered 12 of 19 agents in the captured fixture.
        scored = [a for a in agents if a.activity_score is not None]
        unscored = [a for a in agents if a.activity_score is None]
        assert len(scored) == len(data["activityScores"])
        assert len(unscored) == len(data["agentIds"]) - len(data["activityScores"])

    def test_active_agents_sort_before_inactive(self):
        agents = parse_agents(_load_fixture("get_custom_agents.json"))
        seen_none = False
        for a in agents:
            if a.activity_score is None:
                seen_none = True
            elif seen_none:
                pytest.fail(
                    f"agent {a.agent_id} (score={a.activity_score}) followed "
                    f"a None-score agent — sort order broken"
                )

    def test_breadcrumb_uses_most_recent_thread_per_agent(self):
        agents = parse_agents(_load_fixture("get_custom_agents.json"))
        # At least one agent in the fixture has its breadcrumb set.
        with_breadcrumb = [a for a in agents if a.most_recent_thread_id]
        assert len(with_breadcrumb) >= 1
        # Spot check: breadcrumb thread id should belong to an entry whose
        # parent_id matches the agent_id.
        data = _load_fixture("get_custom_agents.json")
        ts_by_id = {t["id"]: t for t in data["mostRecentTranscripts"] if t.get("id")}
        for a in with_breadcrumb:
            assert ts_by_id[a.most_recent_thread_id]["parent_id"] == a.agent_id

    def test_empty_agent_ids(self):
        assert parse_agents({}) == []
        assert parse_agents({"agentIds": []}) == []

    def test_activity_score_dedup_keeps_highest(self):
        data = {
            "agentIds": ["a1"],
            "activityScores": [
                {"parent_id": "a1", "activity_score": "100"},
                {"parent_id": "a1", "activity_score": "200"},
                {"parent_id": "a1", "activity_score": "50"},
            ],
        }
        a = parse_agents(data)[0]
        assert a.activity_score == 200


# --------------------------------------------------------------------------- #
# NotionAgentClient.fetch_custom_agents via MockTransport
# --------------------------------------------------------------------------- #

def _account_file(tmp_path: Path) -> Path:
    p = tmp_path / "notion_account.json"
    p.write_text(json.dumps({
        "token_v2":   "v03:test",
        "user_id":    "11111111-1111-1111-1111-111111111111",
        "space_id":   "22222222-2222-2222-2222-222222222222",
        "space_name": "T",
        "browser_id": "bid",
    }), encoding="utf-8")
    return p


class TestFetchCustomAgents:
    async def test_happy_path_returns_top_keys(self, tmp_path: Path):
        fixture = _load_fixture("get_custom_agents.json")
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=fixture)

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            data = await client.fetch_custom_agents()

        assert set(data.keys()) >= {"agentIds", "mostRecentTranscripts",
                                    "activityScores"}
        req = captured[0]
        assert str(req.url).endswith("/getCustomAgents")
        assert req.headers["accept"] == "application/json"
        body = json.loads(req.content)
        assert body == {"spaceId": "22222222-2222-2222-2222-222222222222"}

    async def test_401_surfaces_auth_invalid_code(self, tmp_path: Path):
        from notion_agent_cli import ErrorCode

        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(401, text="nope")

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            with pytest.raises(NotionAgentError) as exc:
                await client.fetch_custom_agents()
        assert exc.value.code == ErrorCode.AUTH_INVALID


# --------------------------------------------------------------------------- #
# Cross-check: parse_agents + parse_threads on the same fixture stay
# consistent — every breadcrumb thread id appears in the threads list.
# --------------------------------------------------------------------------- #

def test_breadcrumb_thread_ids_are_subset_of_threads_list():
    data = _load_fixture("get_custom_agents.json")
    agents = parse_agents(data)
    threads = parse_threads(data)
    thread_ids = {t.thread_id for t in threads}
    for a in agents:
        if a.most_recent_thread_id is not None:
            assert a.most_recent_thread_id in thread_ids


# --------------------------------------------------------------------------- #
# Workflow-record extraction (v0.1.5: the actual correct lookup for agent
# name + agent_page_id, replacing the v0.1.4 bot-table attempt that returned
# only ACL probes on real workspaces).
#
# The fixture mirrors the operator's getInferenceTranscriptsForWorkflow
# capture — recordMap.workflow.<id>.value.value.data carries
# {name, icon, description, instructions: {id, table:"block", spaceId}}.
# syncRecordValuesMain with table=workflow returns the same record shape.
# --------------------------------------------------------------------------- #

WORKFLOW_ID = "c0000001-0000-0000-0000-000000000001"


def _workflow_record_value(fixture: dict[str, Any]) -> dict[str, Any]:
    """Pull the inner workflow value dict out of the fixture."""
    return fixture["recordMap"]["workflow"][WORKFLOW_ID]["value"]["value"]


class TestWorkflowFieldExtraction:
    def test_name_from_real_capture(self):
        wf = _workflow_record_value(_load_fixture("get_inference_transcripts_for_workflow.json"))
        assert extract_workflow_name(wf) == "Omada 周报 Agent"

    def test_icon_from_real_capture(self):
        wf = _workflow_record_value(_load_fixture("get_inference_transcripts_for_workflow.json"))
        assert extract_workflow_icon(wf) == "📮"

    def test_description_from_real_capture(self):
        wf = _workflow_record_value(_load_fixture("get_inference_transcripts_for_workflow.json"))
        desc = extract_workflow_description(wf)
        assert isinstance(desc, str) and "周报" in desc

    def test_instructions_page_id_from_real_capture(self):
        """The instructions.id is what the operator passes to
        ``init --agent-page-id`` — this is the bridge from agent_id
        space to persistent_instructions_page space.
        """
        wf = _workflow_record_value(_load_fixture("get_inference_transcripts_for_workflow.json"))
        assert extract_workflow_instructions_page_id(wf) == (
            "11111111-0000-0000-0000-000000000001"
        )

    def test_missing_data_returns_none(self):
        # No data dict at all.
        assert extract_workflow_name({}) is None
        assert extract_workflow_icon({}) is None
        assert extract_workflow_description({}) is None
        assert extract_workflow_instructions_page_id({}) is None

    def test_data_present_but_field_missing(self):
        wf = {"data": {"name": "X"}}  # only name; icon / description / instructions absent
        assert extract_workflow_name(wf) == "X"
        assert extract_workflow_icon(wf) is None
        assert extract_workflow_description(wf) is None
        assert extract_workflow_instructions_page_id(wf) is None

    def test_trims_whitespace(self):
        assert extract_workflow_name({"data": {"name": "  J  "}}) == "J"
        assert extract_workflow_icon({"data": {"icon": " 📮 "}}) == "📮"
        assert extract_workflow_description({"data": {"description": "  hi  "}}) == "hi"

    def test_non_string_fields_safe(self):
        wf = {"data": {"name": 42, "icon": None, "description": ["nope"],
                       "instructions": "not-a-dict"}}
        assert extract_workflow_name(wf) is None
        assert extract_workflow_icon(wf) is None
        assert extract_workflow_description(wf) is None
        assert extract_workflow_instructions_page_id(wf) is None

    def test_instructions_without_id(self):
        wf = {"data": {"instructions": {"table": "block"}}}
        assert extract_workflow_instructions_page_id(wf) is None


class TestParseWorkflowRecords:
    def test_real_capture_shape(self):
        resp = _load_fixture("get_inference_transcripts_for_workflow.json")
        out = parse_workflow_records(resp)
        assert WORKFLOW_ID in out
        assert out[WORKFLOW_ID]["data"]["name"] == "Omada 周报 Agent"

    def test_double_nested_value(self):
        resp = {"recordMap": {"workflow": {
            "w1": {"value": {"value": {"data": {"name": "Hi"}}}},
        }}}
        assert parse_workflow_records(resp)["w1"]["data"]["name"] == "Hi"

    def test_single_nested_fallback(self):
        resp = {"recordMap": {"workflow": {
            "w2": {"value": {"data": {"name": "Yo"}}},
        }}}
        assert parse_workflow_records(resp)["w2"]["data"]["name"] == "Yo"

    def test_empty_or_malformed(self):
        assert parse_workflow_records({}) == {}
        assert parse_workflow_records({"recordMap": {}}) == {}
        assert parse_workflow_records({"recordMap": {"workflow": "wrong-type"}}) == {}
        assert parse_workflow_records({"recordMap": {"workflow": {}}}) == {}


class TestParseAgentsWithWorkflows:
    def test_workflow_metadata_threads_through(self):
        """End-to-end: parse_agents + workflows map fills name / icon /
        agent_page_id / description on the AgentSummary."""
        data = _load_fixture("get_custom_agents.json")
        agent_ids = [x for x in data.get("agentIds", []) if isinstance(x, str)]
        chosen_aid = agent_ids[0]
        workflows = {chosen_aid: {"data": {
            "name": "Jarvis",
            "icon": "🐲",
            "description": "Lucien's assistant.",
            "instructions": {"id": "deadbeef-0000-0000-0000-000000000001"},
        }}}
        agents = parse_agents(data, workflows=workflows)
        target = next(a for a in agents if a.agent_id == chosen_aid)
        assert target.name == "Jarvis"
        assert target.icon == "🐲"
        assert target.description == "Lucien's assistant."
        assert target.agent_page_id == "deadbeef-0000-0000-0000-000000000001"
        # Agents not in the workflows map keep None for all four fields.
        others = [a for a in agents if a.agent_id != chosen_aid]
        assert others and all(
            o.name is None and o.icon is None
            and o.description is None and o.agent_page_id is None
            for o in others
        )

    def test_default_is_all_none(self):
        data = _load_fixture("get_custom_agents.json")
        for a in parse_agents(data):
            assert a.name is None
            assert a.icon is None
            assert a.description is None
            assert a.agent_page_id is None


# --------------------------------------------------------------------------- #
# NotionAgentClient.fetch_workflow_records — provider-side wiring
# --------------------------------------------------------------------------- #

class TestFetchWorkflowRecords:
    async def test_empty_ids_short_circuits(self, tmp_path: Path):
        """No HTTP call when given an empty id list."""
        called = False

        def handler(_req: httpx.Request) -> httpx.Response:  # pragma: no cover
            nonlocal called
            called = True
            return httpx.Response(500)

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            out = await client.fetch_workflow_records([])
        assert called is False
        assert out == {"recordMap": {"workflow": {}}}

    async def test_pointer_shape_includes_spaceid(self, tmp_path: Path):
        """Each pointer is ``{table: "workflow", id, spaceId}``.

        Workflow records are space-scoped — Notion needs the spaceId
        on the pointer to route the request.
        """
        captured: list[httpx.Request] = []
        fixture = _load_fixture("get_inference_transcripts_for_workflow.json")

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=fixture)

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            raw = await client.fetch_workflow_records([WORKFLOW_ID])

        assert str(captured[0].url).endswith("/syncRecordValuesMain")
        body = json.loads(captured[0].content)
        assert len(body["requests"]) == 1
        assert body["requests"][0]["pointer"]["table"] == "workflow"
        assert body["requests"][0]["pointer"]["spaceId"] == (
            "22222222-2222-2222-2222-222222222222"
        )
        assert body["requests"][0]["version"] == -1
        # Round-trips through parse_workflow_records → metadata readable
        flat = parse_workflow_records(raw)
        assert flat[WORKFLOW_ID]["data"]["name"] == "Omada 周报 Agent"


# --------------------------------------------------------------------------- #
# Regression: agent_id from getCustomAgents is NOT a bot/block/notion_user
# /space/team record id. v0.1.4 shipped a "name lookup" against table=bot
# that always returned only an ACL probe — operators saw 19/19 (no name).
# This test pins the ACL-only response so any future "name resolution"
# refactor that re-queries the wrong table will fail loudly.
# --------------------------------------------------------------------------- #

class TestAgentIdAclProbeRegression:
    """syncRecordValuesMain on agent_id with the wrong table returns
    only ``{"role": "editor"}`` — confirmed by the operator's 5-table
    sweep on a real workspace (notion-agent-cli-feedback-v0.1.4.md §1).
    """

    def test_bot_table_returns_role_only(self):
        # This is what real prod returns for table=bot on a getCustomAgents
        # agent_id. The fixture is small + intentional — no recordMap.bot
        # entries despite a 200 response.
        prod_shape = {"recordMap": {"bot": {}}}
        assert parse_workflow_records(prod_shape) == {}
        # And the bot record dict is empty — no name to extract.
        assert prod_shape["recordMap"]["bot"] == {}


def test_dataclasses_are_frozen():
    # Frozen dataclasses are immutable — tests + downstream wrappers
    # can stash them in sets / dict keys safely.
    a = AgentSummary("x", None, None, None)
    t = ThreadSummary("y", None, None, None, None, None, None)
    with pytest.raises((AttributeError, Exception)):  # FrozenInstanceError
        a.agent_id = "z"  # type: ignore[misc]
    with pytest.raises((AttributeError, Exception)):
        t.thread_id = "z"  # type: ignore[misc]


# --------------------------------------------------------------------------- #
# v0.1.6 R5-B: `agents route <query>` — keyword router over the workspace's
# Custom Agents. jarvis v0.1.5 Round-5 Addendum: "main Jarvis is the agent
# router; LLM operator needs a hint for which Custom Agent to dispatch to."
# Pure tokenizer / scorer tests + a CLI smoke test through main().
# --------------------------------------------------------------------------- #

from notion_agent_cli.cli.__main__ import (  # noqa: E402
    _route_score,
    _route_tokenize,
    main,
)


class TestRouteTokenize:
    def test_latin_words_lowercased(self):
        assert _route_tokenize("Email Agent") == {"email", "agent"}

    def test_cjk_per_character(self):
        # Each CJK ideograph is one token (no segmenter dependency).
        assert _route_tokenize("处理邮件") == {"处", "理", "邮", "件"}

    def test_mixed_language(self):
        assert _route_tokenize("Daily 周报 Agent") == {
            "daily", "周", "报", "agent",
        }

    def test_punctuation_stripped(self):
        assert _route_tokenize("Email-Agent: !!!") == {"email", "agent"}

    def test_empty_input(self):
        assert _route_tokenize("") == set()
        assert _route_tokenize(None) == set()


class TestRouteScore:
    def _agent(self, *, name: str | None, description: str | None) -> AgentSummary:
        return AgentSummary(
            agent_id="a0000001-0000-0000-0000-000000000001",
            activity_score=1,
            most_recent_thread_id=None,
            most_recent_thread_title=None,
            name=name,
            icon=None,
            description=description,
            agent_page_id=None,
        )

    def test_perfect_overlap_with_name_bonus(self):
        q = _route_tokenize("email agent")
        score = _route_score(
            q, self._agent(name="Email Agent", description="Triages inbox messages."),
        )
        # full recall (1.0) + name substring bonus (0.2); no null-desc penalty.
        assert score == pytest.approx(1.2)

    def test_null_description_penalty_halves_score(self):
        """Agents with no description take a 0.5x penalty on the final score.

        jarvis v0.1.6 §2 瑕疵 2: an agent with description=null shouldn't
        out-rank a description-backed match just because its name happens
        to share a keyword with the query. The penalty downweights
        name-only signal so authored descriptions surface first.
        """
        q = _route_tokenize("email agent")
        score = _route_score(q, self._agent(name="Email Agent", description=None))
        # (1.0 + 0.2) * 0.5 = 0.6 — half what a description-backed agent gets.
        assert score == pytest.approx(0.6)

    def test_description_backed_match_beats_name_only_on_same_query(self):
        """Two agents, same name-keyword hit; the one with a description wins.

        This is the regression jarvis surfaced: a name-only agent
        ("Knowledge Q&A") shouldn't outrank a description-backed agent
        ("Knowledge Agent") when the query semantically matches the
        latter's description.
        """
        q = _route_tokenize("knowledge ingest")
        name_only = self._agent(name="Knowledge Helper", description=None)
        desc_backed = self._agent(
            name="Knowledge Agent",
            description="Handles knowledge ingest, retrieval, and summarization.",
        )
        assert _route_score(q, desc_backed) > _route_score(q, name_only)

    def test_partial_recall_from_description(self):
        q = _route_tokenize("email")
        score = _route_score(
            q, self._agent(name="Daily Planner", description="handles email inbox"),
        )
        # 1/1 query tokens hit description, no name match → 1.0 base, 0.0 bonus.
        assert score == pytest.approx(1.0)

    def test_no_overlap_returns_zero(self):
        q = _route_tokenize("calendar")
        score = _route_score(
            q, self._agent(name="Email Agent", description="inbox triage"),
        )
        assert score == 0.0

    def test_empty_query_returns_zero(self):
        assert _route_score(set(), self._agent(name="X", description="Y")) == 0.0

    def test_empty_haystack_returns_zero(self):
        q = _route_tokenize("anything")
        assert _route_score(q, self._agent(name=None, description=None)) == 0.0

    def test_cjk_query_matches_cjk_description(self):
        q = _route_tokenize("邮件")
        score = _route_score(
            q, self._agent(name="Email Agent", description="处理邮件归档"),
        )
        # Both query chars (邮, 件) appear in the description.
        assert score >= 1.0


class TestAgentsRouteCommand:
    """End-to-end smoke through ``main(["agents","route", ...])``.

    Monkeypatches the two async helpers that hit Notion (so no HTTP
    transport is needed) and checks the formatter chooses the right
    best_match by score.
    """

    def _stub(self, monkeypatch, *, agents: list[tuple[str, str, str]]):
        """Stub the two async fetchers used by `agents route`.

        ``agents`` is a list of (agent_id, name, description) — converted
        into both the getCustomAgents response shape and the workflow
        records map so parse_agents() rebuilds the full AgentSummary.
        """
        agent_ids = [aid for aid, _n, _d in agents]
        raw = {
            "agentIds":              agent_ids,
            "activityScores":        [
                {"parent_id": aid, "activity_score": str(1_700_000_000_000 + i)}
                for i, aid in enumerate(agent_ids)
            ],
            "mostRecentTranscripts": [],
        }
        workflows = {
            aid: {"data": {"name": name, "description": desc,
                           "instructions": {"id": f"page-{aid}"}}}
            for aid, name, desc in agents
        }

        async def _fake_fetch_agents(_args):
            return raw

        async def _fake_fetch_workflows(_args, _ids):
            return workflows

        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__._run_fetch_custom_agents",
            _fake_fetch_agents,
        )
        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__._run_fetch_agent_workflows",
            _fake_fetch_workflows,
        )

    def test_picks_best_match_in_json(self, tmp_path: Path, capsys, monkeypatch):
        self._stub(monkeypatch, agents=[
            ("a0000001-0000-0000-0000-000000000001", "Email Agent",
             "Triages inbox 邮件 and drafts replies."),
            ("a0000002-0000-0000-0000-000000000002", "Daily Planner",
             "Builds the day's schedule from your calendar."),
        ])
        # account path is irrelevant — the fetchers are stubbed.
        rc = main([
            "agents", "route", "处理邮件",
            "--account", str(tmp_path / "acc.json"),
            "--json",
        ])
        assert rc == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload["query"] == "处理邮件"
        # Email Agent wins (description hits 邮 + 件 via CJK token overlap).
        assert payload["best_match"]["name"] == "Email Agent"
        assert payload["best_match"]["agent_page_id"] == (
            "page-a0000001-0000-0000-0000-000000000001"
        )
        assert payload["best_match"]["score"] > 0

    def test_no_matches_prints_helpful_message(
        self, tmp_path: Path, capsys, monkeypatch,
    ):
        self._stub(monkeypatch, agents=[
            ("a0000001-0000-0000-0000-000000000001", "Calendar Bot",
             "Builds schedules."),
        ])
        rc = main([
            "agents", "route", "render videos",
            "--account", str(tmp_path / "acc.json"),
        ])
        assert rc == 0
        out = capsys.readouterr().out
        assert "no agents matched" in out
        assert "agents list" in out

    def test_no_agents_in_workspace(self, tmp_path: Path, capsys, monkeypatch):
        self._stub(monkeypatch, agents=[])
        rc = main([
            "agents", "route", "anything",
            "--account", str(tmp_path / "acc.json"),
        ])
        assert rc == 0
        out = capsys.readouterr().out
        assert "no custom agents" in out

    def test_table_output_shows_score_column(
        self, tmp_path: Path, capsys, monkeypatch,
    ):
        self._stub(monkeypatch, agents=[
            ("a0000001-0000-0000-0000-000000000001", "Email Agent",
             "Inbox helper."),
        ])
        rc = main([
            "agents", "route", "email",
            "--account", str(tmp_path / "acc.json"),
        ])
        assert rc == 0
        out = capsys.readouterr().out
        assert "score" in out
        assert "Email Agent" in out
