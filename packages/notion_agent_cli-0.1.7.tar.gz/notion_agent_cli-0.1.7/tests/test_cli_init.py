"""Tests for ``notion-agent init`` CLI plumbing.

The live HTTP path (``/api/v3/loadUserContent``) is covered by
``test_bootstrap.py``; this file pins the CLI's argv/stdin handling so
``--cookie -`` / ``--token-v2 -`` keep reading from stdin rather than
argv, plus the v0.1.3 onboarding-feedback fixes (clearer errors on
misused ``--cookie``, ``--agent-name`` without ``--agent-page-id``,
and ready-to-copy AmbiguousWorkspace hint).
"""
from __future__ import annotations

import io
from pathlib import Path

import pytest

from notion_agent_cli.account import NotionAccount, load_notion_account
from notion_agent_cli.agents import AgentSummary
from notion_agent_cli.bootstrap import AmbiguousWorkspaceError, Workspace
from notion_agent_cli.cli.__main__ import main
from notion_agent_cli.exceptions import ErrorCode, NotionAgentError


@pytest.fixture
def stub_bootstrap(monkeypatch):
    """Replace bootstrap_account with a sink that records its kwargs."""
    captured: dict[str, str] = {}

    async def _fake(**kwargs) -> NotionAccount:
        captured.update(kwargs)
        return NotionAccount(
            token_v2=kwargs.get("token_v2", ""),
            user_id=kwargs.get("user_id", ""),
            space_id="space-id-stub",
            space_name="Stub Space",
            space_view_id="",
            browser_id=kwargs.get("browser_id") or "",
            device_id="",
            timezone=kwargs.get("timezone", "America/Los_Angeles"),
            agent_name=kwargs.get("agent_name", ""),
            agent_accessory=kwargs.get("agent_accessory", ""),
            agent_context_page_id=kwargs.get("agent_context_page_id", ""),
            default_model=kwargs.get("default_model", "opus-4.7"),
        )

    monkeypatch.setattr(
        "notion_agent_cli.cli.__main__.bootstrap_account", _fake,
    )
    return captured


class TestInitStdin:
    def test_dash_cookie_reads_from_stdin(
        self, tmp_path: Path, monkeypatch, stub_bootstrap,
    ):
        """`--cookie -` reads the cookie string from stdin, not argv."""
        cookie = (
            "notion_user_id=11111111-1111-1111-1111-111111111111; "
            "token_v2=v03:secret; "
            "notion_browser_id=44444444-4444-4444-4444-444444444444"
        )
        monkeypatch.setattr("sys.stdin", io.StringIO(cookie))

        out_path = tmp_path / "acc.json"
        rc = main(["init", "--cookie", "-", "--account", str(out_path)])
        assert rc == 0
        assert out_path.exists()
        # The stdin-supplied cookie was parsed into token_v2 + user_id.
        assert stub_bootstrap["token_v2"] == "v03:secret"
        assert stub_bootstrap["user_id"] == "11111111-1111-1111-1111-111111111111"
        assert stub_bootstrap["browser_id"] == "44444444-4444-4444-4444-444444444444"

    def test_dash_cookie_empty_stdin_errors(
        self, tmp_path: Path, monkeypatch, capsys,
    ):
        monkeypatch.setattr("sys.stdin", io.StringIO("   \n"))
        out_path = tmp_path / "acc.json"
        rc = main(["init", "--cookie", "-", "--account", str(out_path)])
        assert rc == 2
        assert "empty" in capsys.readouterr().err.lower()

    def test_dash_token_v2_reads_from_stdin(
        self, tmp_path: Path, monkeypatch, stub_bootstrap,
    ):
        """`--token-v2 -` keeps the token out of argv / shell history."""
        monkeypatch.setattr("sys.stdin", io.StringIO("v03%3Aabc\n"))
        out_path = tmp_path / "acc.json"
        rc = main(["init", "--token-v2", "-", "--account", str(out_path)])
        assert rc == 0
        assert out_path.exists()
        assert stub_bootstrap["token_v2"] == "v03%3Aabc"

    def test_dash_token_v2_empty_stdin_errors(
        self, tmp_path: Path, monkeypatch, capsys,
    ):
        monkeypatch.setattr("sys.stdin", io.StringIO(""))
        out_path = tmp_path / "acc.json"
        rc = main(["init", "--token-v2", "-", "--account", str(out_path)])
        assert rc == 2
        err = capsys.readouterr().err
        assert "empty" in err.lower() and "token" in err.lower()


class TestInitFeedbackHints:
    """v0.1.3 fixes for the openclaw/Jarvis onboarding feedback round."""

    def test_cookie_with_only_token_value_suggests_token_v2(
        self, tmp_path: Path, capsys,
    ):
        """Passing a bare token to --cookie should suggest --token-v2.

        openclaw P0-1: the agent prompt nudged the operator toward
        `--cookie <token>`, but --cookie wants a full document.cookie
        string. The new behavior surfaces a hint instead of the generic
        "--token-v2 is required" miss.
        """
        out_path = tmp_path / "acc.json"
        # The bare value has no `=` — parse_browser_cookie skips it,
        # so token_v2 stays empty and we hit the hint branch.
        rc = main([
            "init",
            "--cookie", "v03%3Aabc",
            "--account", str(out_path),
        ])
        assert rc == 2
        err = capsys.readouterr().err
        assert "--token-v2" in err
        assert "document.cookie" in err

    def test_agent_name_without_page_id_warns_but_proceeds(
        self, tmp_path: Path, capsys, stub_bootstrap,
    ):
        """openclaw P0-3: silent fallback to default chat was surprising.

        Passing --agent-name without --agent-page-id should warn loudly
        on stderr (binding will not be created) but still complete init.
        """
        out_path = tmp_path / "acc.json"
        rc = main([
            "init",
            "--token-v2", "v03:abc",
            "--agent-name", "Jarvis",
            "--account", str(out_path),
        ])
        assert rc == 0
        err = capsys.readouterr().err
        assert "Jarvis" in err
        assert "--agent-page-id" in err
        # The warning is informational — the file is still written.
        assert out_path.exists()

    def test_ambiguous_workspace_prints_rerun_command(
        self, tmp_path: Path, monkeypatch, capsys,
    ):
        """openclaw P0-2: list the workspaces *and* give a copy-paste
        rerun line with shell-quoted name (curly-quote-safe)."""
        ws = [
            Workspace(
                space_id="11111111-1111-1111-1111-111111111111",
                space_view_id="",
                # U+2019 right single quotation mark — needs shell quoting.
                space_name="Lucien Chen’s space",  # noqa: RUF001
                domain="",
            ),
            Workspace(
                space_id="22222222-2222-2222-2222-222222222222",
                space_view_id="",
                space_name="TP-Link",
                domain="tp-link",
            ),
        ]

        async def _fake(**_kwargs):
            raise AmbiguousWorkspaceError(ws)

        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__.bootstrap_account", _fake,
        )
        out_path = tmp_path / "acc.json"
        rc = main([
            "init", "--token-v2", "v03:abc", "--account", str(out_path),
        ])
        assert rc == 3
        err = capsys.readouterr().err
        # Both workspace names listed
        assert "TP-Link" in err
        assert "Lucien Chen" in err
        # Ready-to-copy rerun present, with the first workspace's name
        # shell-quoted so curly quotes don't break paste.
        assert "Try:" in err
        assert "notion-agent init --token-v2" in err
        assert "--space-name" in err


# --------------------------------------------------------------------------- #
# v0.1.6 R4-A: --agent-page-id reverse-resolves to a workflow-registered
# Custom Agent. jarvis v0.1.5 Round-4 found that two distinct kinds of
# pages can land in --agent-page-id: a workflow-registered instructions
# page (real Custom Agent persona) or a free-form steering page (just a
# chat-panel context). init should enrich agent_name when it can and
# warn loudly when the page isn't a registered agent.
# --------------------------------------------------------------------------- #

def _make_agent(*, agent_id: str, name: str | None, page_id: str | None) -> AgentSummary:
    return AgentSummary(
        agent_id=agent_id,
        activity_score=1_700_000_000_000,
        most_recent_thread_id=None,
        most_recent_thread_title=None,
        name=name,
        icon=None,
        description=None,
        agent_page_id=page_id,
    )


class TestInitPageIdReverseResolve:
    def test_matched_page_id_enriches_agent_name(
        self, tmp_path: Path, capsys, stub_bootstrap, monkeypatch,
    ):
        """page_id matches a workflow record → agent_name auto-filled."""
        async def _fake_lookup(_acc, page_id):
            assert page_id == "11111111-0000-0000-0000-000000000001"
            return _make_agent(
                agent_id="a0000001-0000-0000-0000-000000000001",
                name="Email Agent",
                page_id=page_id,
            )

        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__._lookup_agent_by_page_id",
            _fake_lookup,
        )

        out_path = tmp_path / "acc.json"
        rc = main([
            "init",
            "--token-v2", "v03:abc",
            "--user-id", "11111111-1111-1111-1111-111111111111",
            "--agent-page-id", "11111111-0000-0000-0000-000000000001",
            "--account", str(out_path),
        ])
        assert rc == 0
        err = capsys.readouterr().err
        assert "Email Agent" in err
        assert "persona_overlay" in err
        # The saved file should now carry the resolved agent_name + the
        # binding_mode that chat --json will surface to LLM callers.
        saved = load_notion_account(out_path)
        assert saved.agent_name == "Email Agent"
        assert saved.agent_context_page_id == "11111111-0000-0000-0000-000000000001"
        assert saved.has_jarvis_binding
        assert saved.agent_binding_mode == "persona_overlay"

    def test_unmatched_page_id_warns_free_form_steering(
        self, tmp_path: Path, capsys, stub_bootstrap, monkeypatch,
    ):
        """page_id not in agents list → warn 'free-form steering page'.

        This is the jarvis v0.1.5 §"概念差异" case: the operator bound
        a regular block (e.g. a notes index page), not a workflow record.
        Binding still completes — the warning just clarifies semantics.
        """
        async def _fake_lookup(_acc, _page_id):
            return None

        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__._lookup_agent_by_page_id",
            _fake_lookup,
        )

        out_path = tmp_path / "acc.json"
        rc = main([
            "init",
            "--token-v2", "v03:abc",
            "--user-id", "11111111-1111-1111-1111-111111111111",
            "--agent-page-id", "deadbeef-0000-0000-0000-000000000099",
            "--account", str(out_path),
        ])
        assert rc == 0
        err = capsys.readouterr().err
        assert "free-form steering page" in err
        # No agent_name was set (user didn't pass one and lookup missed).
        # No binding overall → binding_mode stays empty and chat output
        # will report binding_mode="default_ai".
        saved = load_notion_account(out_path)
        assert saved.agent_name == ""
        assert saved.agent_binding_mode == ""

    def test_explicit_agent_name_wins_over_resolved(
        self, tmp_path: Path, capsys, stub_bootstrap, monkeypatch,
    ):
        """User-supplied --agent-name is preserved even when lookup matches.

        Operators sometimes alias an agent locally (e.g. "Jarvis" instead
        of the workspace's "Lucien's Assistant"). The reverse-resolve
        should never silently rename their binding.
        """
        async def _fake_lookup(_acc, _page_id):
            return _make_agent(
                agent_id="a0000001-0000-0000-0000-000000000001",
                name="Lucien's Assistant",
                page_id="11111111-0000-0000-0000-000000000001",
            )

        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__._lookup_agent_by_page_id",
            _fake_lookup,
        )

        out_path = tmp_path / "acc.json"
        rc = main([
            "init",
            "--token-v2", "v03:abc",
            "--user-id", "11111111-1111-1111-1111-111111111111",
            "--agent-name", "Jarvis",
            "--agent-page-id", "11111111-0000-0000-0000-000000000001",
            "--account", str(out_path),
        ])
        assert rc == 0
        saved = load_notion_account(out_path)
        # User's alias survives, but binding_mode still reflects that
        # the page is a workflow-registered Custom Agent persona.
        assert saved.agent_name == "Jarvis"
        assert saved.agent_binding_mode == "persona_overlay"

    def test_lookup_failure_is_silent_and_init_succeeds(
        self, tmp_path: Path, capsys, stub_bootstrap, monkeypatch,
    ):
        """Network/parse failure during reverse-resolve must not abort init.

        Best-effort enrichment: a transient lookup error mustn't block
        the credential file from landing on disk. The user already
        supplied a page id; the worst case is we miss the enrichment.
        """
        async def _fake_lookup(_acc, _page_id):
            raise NotionAgentError("boom", code=ErrorCode.HTTP_ERROR)

        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__._lookup_agent_by_page_id",
            _fake_lookup,
        )

        out_path = tmp_path / "acc.json"
        rc = main([
            "init",
            "--token-v2", "v03:abc",
            "--user-id", "11111111-1111-1111-1111-111111111111",
            "--agent-name", "Jarvis",  # supplied so no warn-on-miss fires
            "--agent-page-id", "11111111-0000-0000-0000-000000000001",
            "--account", str(out_path),
        ])
        assert rc == 0
        # File still written with the user's values. binding_mode stays
        # empty because the lookup never completed — chat --json will
        # report binding_mode=null, signaling "unknown, re-run init".
        saved = load_notion_account(out_path)
        assert saved.agent_name == "Jarvis"
        assert saved.agent_context_page_id == "11111111-0000-0000-0000-000000000001"
        assert saved.agent_binding_mode == ""

    def test_explicit_name_with_unmatched_page_marks_free_form_steering(
        self, tmp_path: Path, capsys, stub_bootstrap, monkeypatch,
    ):
        """v0.1.6.1: user gave both --agent-name + a non-registered page.

        The binding is real (has_jarvis_binding=True) but the page
        isn't a workflow-registered Custom Agent — record
        binding_mode="free_form_steering" so chat --json can tell
        LLM operators they're steering with a regular page, not
        wearing a registered persona.
        """
        async def _fake_lookup(_acc, _page_id):
            return None

        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__._lookup_agent_by_page_id",
            _fake_lookup,
        )

        out_path = tmp_path / "acc.json"
        rc = main([
            "init",
            "--token-v2", "v03:abc",
            "--user-id", "11111111-1111-1111-1111-111111111111",
            "--agent-name", "My Notes Index",
            "--agent-page-id", "deadbeef-0000-0000-0000-000000000099",
            "--account", str(out_path),
        ])
        assert rc == 0
        err = capsys.readouterr().err
        assert "free_form_steering" in err
        saved = load_notion_account(out_path)
        assert saved.agent_name == "My Notes Index"
        assert saved.has_jarvis_binding
        assert saved.agent_binding_mode == "free_form_steering"

    def test_no_page_id_skips_lookup_entirely(
        self, tmp_path: Path, monkeypatch, stub_bootstrap,
    ):
        """No --agent-page-id → reverse-resolve isn't even called."""
        called = False

        async def _fake_lookup(_acc, _page_id):
            nonlocal called
            called = True
            return None

        monkeypatch.setattr(
            "notion_agent_cli.cli.__main__._lookup_agent_by_page_id",
            _fake_lookup,
        )

        out_path = tmp_path / "acc.json"
        rc = main(["init", "--token-v2", "v03:abc", "--account", str(out_path)])
        assert rc == 0
        assert called is False
