"""Tests for v0.1.7 async-run support (R5-A).

Three surfaces under test:

1. ``runs.parse_workflow_transcripts`` — wire-shape parser for
   ``/getInferenceTranscriptsForWorkflow``.
2. ``NotionAgentClient.start_run_detached`` /
   ``fetch_workflow_transcripts`` / ``fetch_paused_workflow_runs`` —
   provider wrappers, exercised via ``httpx.MockTransport``.
3. ``notion-agent runs {start,list,paused}`` — CLI smoke + JSON
   output shape.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from notion_agent_cli import NotionAgentClient, NotionAgentError
from notion_agent_cli.cli.__main__ import main
from notion_agent_cli.runs import TranscriptRun, parse_workflow_transcripts
from notion_agent_cli.thread_state import load_thread_state

FIXTURES = Path(__file__).parent / "fixtures"


def _load_fixture(name: str) -> dict[str, Any]:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


# --------------------------------------------------------------------------- #
# parse_workflow_transcripts
# --------------------------------------------------------------------------- #

class TestParseWorkflowTranscripts:
    def test_fixture_yields_all_rows(self):
        data = _load_fixture("get_inference_transcripts_for_workflow_list.json")
        rows = parse_workflow_transcripts(data)
        assert len(rows) == len(data["transcripts"])
        for r in rows:
            assert isinstance(r, TranscriptRun)
            assert isinstance(r.thread_id, str)

    def test_fixture_sorted_newest_first(self):
        rows = parse_workflow_transcripts(
            _load_fixture("get_inference_transcripts_for_workflow_list.json"),
        )
        # Sort key is max(last_updated_time, updated_at, created_at); verify
        # monotonic non-increasing.
        keys = [
            max(r.last_updated_time_ms or 0, r.updated_at_ms or 0, r.created_at_ms or 0)
            for r in rows
        ]
        assert keys == sorted(keys, reverse=True)

    def test_titleless_row_round_trips_as_none(self):
        rows = parse_workflow_transcripts(
            _load_fixture("get_inference_transcripts_for_workflow_list.json"),
        )
        assert any(r.title is None for r in rows), (
            "fixture should contain at least one title-less trigger run"
        )

    def test_usage_summary_extracted(self):
        rows = parse_workflow_transcripts(
            _load_fixture("get_inference_transcripts_for_workflow_list.json"),
        )
        top = next(r for r in rows if r.thread_id.startswith("36315375-830d-80bc"))
        assert top.spend_usd == pytest.approx(1.03971355)
        assert top.completion_count == 4
        assert top.agent_inference_count == 3
        assert top.last_updated_time_ms == 1778978589629
        assert top.input_tokens == 302950
        assert top.output_tokens == 3546

    def test_empty_response(self):
        assert parse_workflow_transcripts({}) == []
        assert parse_workflow_transcripts({"transcripts": []}) == []

    def test_skips_non_dict_and_missing_id(self):
        data = {"transcripts": [
            "not-a-dict",
            {"no_id_field": True},
            {"id": 42},
            {"id": "good", "usage_summary": {"spend_usd": 0.1}},
        ]}
        rows = parse_workflow_transcripts(data)
        assert len(rows) == 1
        assert rows[0].thread_id == "good"
        assert rows[0].spend_usd == pytest.approx(0.1)

    def test_missing_usage_summary_safe(self):
        data = {"transcripts": [{"id": "t1", "created_at": 100}]}
        row = parse_workflow_transcripts(data)[0]
        assert row.thread_id == "t1"
        assert row.spend_usd is None
        assert row.completion_count is None
        assert row.last_updated_time_ms is None

    def test_int_coercion_of_string_timestamps(self):
        data = {"transcripts": [
            {"id": "t1", "created_at": "100", "updated_at": "200",
             "usage_summary": {"last_updated_time": "150"}},
        ]}
        row = parse_workflow_transcripts(data)[0]
        assert row.created_at_ms == 100
        assert row.updated_at_ms == 200
        assert row.last_updated_time_ms == 150


# --------------------------------------------------------------------------- #
# Provider wrappers (httpx.MockTransport)
# --------------------------------------------------------------------------- #

def _account_file(tmp_path: Path) -> Path:
    p = tmp_path / "notion_account.json"
    p.write_text(json.dumps({
        "token_v2":   "v03:test",
        "user_id":    "11111111-1111-1111-1111-111111111111",
        "space_id":   "22222222-2222-2222-2222-222222222222",
        "space_name": "T",
        "browser_id": "44444444-4444-4444-4444-444444444444",
    }), encoding="utf-8")
    return p


class TestFetchWorkflowTranscripts:
    async def test_happy_path(self, tmp_path: Path):
        fixture = _load_fixture("get_inference_transcripts_for_workflow_list.json")
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=fixture)

        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            data = await client.fetch_workflow_transcripts(
                "c0000001-0000-0000-0000-000000000001", limit=10,
            )

        assert "transcripts" in data and "threadIds" in data
        req = captured[0]
        assert str(req.url).endswith("/getInferenceTranscriptsForWorkflow")
        body = json.loads(req.content)
        assert body == {
            "workflowId": "c0000001-0000-0000-0000-000000000001",
            "spaceId":    "22222222-2222-2222-2222-222222222222",
            "limit":      10,
        }

    async def test_user_filter_round_trips(self, tmp_path: Path):
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json={"transcripts": [], "threadIds": []})

        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            await client.fetch_workflow_transcripts(
                "c0000001-0000-0000-0000-000000000001",
                limit=5, user_id="11111111-1111-1111-1111-111111111111",
            )
        body = json.loads(captured[0].content)
        assert body["userId"] == "11111111-1111-1111-1111-111111111111"
        assert body["limit"] == 5


class TestFetchPausedWorkflowRuns:
    async def test_count_only_round_trip(self, tmp_path: Path):
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json={"count": 0})

        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            data = await client.fetch_paused_workflow_runs(
                "c0000001-0000-0000-0000-000000000001", count_only=True,
            )

        assert data == {"count": 0}
        req = captured[0]
        assert str(req.url).endswith("/listPausedWorkflowRuns")
        body = json.loads(req.content)
        assert body == {
            "spaceId":       "22222222-2222-2222-2222-222222222222",
            "workflowId":    "c0000001-0000-0000-0000-000000000001",
            "pausedReasons": ["creditLimit", "runLimit", "runawayCreditUsage"],
            "countOnly":     True,
        }


class TestStartRunDetached:
    """Detach semantics: POST goes out with workflow-mode body, the
    socket closes on 200 without reading the NDJSON stream, and the
    thread state is persisted under ``thread_state_dir``."""

    async def test_workflow_mode_body_shape(self, tmp_path: Path):
        """The detached request must carry the workflow-mode fields
        R5-A captured: threadParentPointer.table = "workflow",
        context.surface = "custom_agent", context.workflowId set,
        createdSource = "custom_agent"."""
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            # Stream a sentinel NDJSON line + close. start_run_detached
            # should not need to read it.
            return httpx.Response(
                200,
                headers={"content-type": "application/x-ndjson"},
                content=b'{"event": "ack"}\n',
            )

        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            client = NotionAgentClient(
                _account_file(tmp_path),
                http_client=http,
                thread_state_dir=tmp_path / "threads",
            )
            thread_id = await client.start_run_detached(
                prompt="do the thing",
                workflow_id="c0000001-0000-0000-0000-000000000001",
            )

        assert isinstance(thread_id, str) and len(thread_id) == 36
        body = json.loads(captured[0].content)
        assert body["threadId"] == thread_id
        assert body["createdSource"] == "custom_agent"
        assert body["threadParentPointer"] == {
            "table":   "workflow",
            "id":      "c0000001-0000-0000-0000-000000000001",
            "spaceId": "22222222-2222-2222-2222-222222222222",
        }
        # context block carries the workflow_id + surface=custom_agent
        ctx_value = next(
            t["value"] for t in body["transcript"] if t["type"] == "context"
        )
        assert ctx_value["surface"] == "custom_agent"
        assert ctx_value["workflowId"] == "c0000001-0000-0000-0000-000000000001"

    async def test_persists_thread_state_with_workflow_id(self, tmp_path: Path):
        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                headers={"content-type": "application/x-ndjson"},
                content=b'{"event": "ack"}\n',
            )

        state_dir = tmp_path / "threads"
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            client = NotionAgentClient(
                _account_file(tmp_path),
                http_client=http,
                thread_state_dir=state_dir,
            )
            tid = await client.start_run_detached(
                prompt="hi",
                workflow_id="c0000001-0000-0000-0000-000000000001",
            )

        state = load_thread_state(tid, state_dir)
        assert state.workflow_id == "c0000001-0000-0000-0000-000000000001"
        assert state.thread_id == tid

    async def test_401_surfaces_auth_invalid_code(self, tmp_path: Path):
        from notion_agent_cli import ErrorCode

        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(401, text="nope")

        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            client = NotionAgentClient(
                _account_file(tmp_path),
                http_client=http,
                thread_state_dir=tmp_path / "threads",
            )
            with pytest.raises(NotionAgentError) as exc:
                await client.start_run_detached(
                    prompt="hi",
                    workflow_id="c0000001-0000-0000-0000-000000000001",
                )
        assert exc.value.code == ErrorCode.AUTH_INVALID


# --------------------------------------------------------------------------- #
# CLI surface
# --------------------------------------------------------------------------- #

class TestCliRunsStart:
    def test_json_output_carries_thread_id(self, tmp_path: Path, monkeypatch, capsys):
        async def _fake_start(self, **kwargs):
            assert kwargs["workflow_id"] == "c0000001-0000-0000-0000-000000000001"
            assert kwargs["prompt"] == "do the thing"
            return "tid-00000000-0000-0000-0000-000000000001"

        monkeypatch.setattr(
            "notion_agent_cli.provider.NotionAgentClient.start_run_detached",
            _fake_start,
        )
        acc = _account_file(tmp_path)
        rc = main([
            "runs", "start", "do the thing",
            "--workflow", "c0000001-0000-0000-0000-000000000001",
            "--json", "--account", str(acc),
        ])
        assert rc == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload == {
            "thread_id":   "tid-00000000-0000-0000-0000-000000000001",
            "workflow_id": "c0000001-0000-0000-0000-000000000001",
        }


class TestCliRunsStartStreaming:
    def test_stream_uses_complete_with_workflow_id(
        self, tmp_path: Path, monkeypatch, capsys,
    ):
        """`--stream` switches from detach to synchronous workflow-mode
        chat, threading workflow_id into complete() and printing chunks
        live via on_text_delta."""
        from notion_agent_cli.types import ChatResponse, TokenUsage

        captured_kwargs: dict = {}

        async def _fake_complete(self, **kwargs):
            captured_kwargs.update(kwargs)
            # Simulate two streamed chunks before the final response.
            cb = kwargs.get("on_text_delta")
            if cb is not None:
                cb("hello ")
                cb("world")
            return ChatResponse(
                text="hello world",
                model="apricot-sorbet-high",
                thread_id="tid-stream-1",
                usage=TokenUsage(input_tokens=1, output_tokens=2,
                                 cache_read=0, cache_creation=0),
                thinking="",
                raw={},
            )

        monkeypatch.setattr(
            "notion_agent_cli.provider.NotionAgentClient.complete",
            _fake_complete,
        )
        acc = _account_file(tmp_path)
        rc = main([
            "runs", "start", "do it",
            "--workflow", "c0000001-0000-0000-0000-000000000001",
            "--stream", "--account", str(acc),
        ])
        assert rc == 0
        out = capsys.readouterr()
        # Streamed chunks appear on stdout with a trailing newline.
        assert out.out.startswith("hello world")
        # thread_id surfaces on stderr so it doesn't muddy `tee` output.
        assert "tid-stream-1" in out.err
        # complete() was called with workflow_id and an on_text_delta callback.
        assert captured_kwargs["workflow_id"] == "c0000001-0000-0000-0000-000000000001"
        assert captured_kwargs["on_text_delta"] is not None

    def test_ndjson_mutex_with_stream(
        self, tmp_path: Path, capsys,
    ):
        acc = _account_file(tmp_path)
        rc = main([
            "runs", "start", "x",
            "--workflow", "c0000001-0000-0000-0000-000000000001",
            "--ndjson", "--stream", "--account", str(acc),
        ])
        assert rc == 2
        assert "mutually exclusive" in capsys.readouterr().err


class TestCliRunsList:
    def test_json_output_flags_in_progress(self, tmp_path: Path, monkeypatch, capsys):
        """The CLI's stale-after heuristic should flag the freshest
        fixture row as in_progress when ``stale-after`` covers it."""
        fixture = _load_fixture("get_inference_transcripts_for_workflow_list.json")

        async def _fake_fetch(self, workflow_id, *, limit=10, user_id=None):
            assert workflow_id == "c0000001-0000-0000-0000-000000000001"
            return fixture

        monkeypatch.setattr(
            "notion_agent_cli.provider.NotionAgentClient.fetch_workflow_transcripts",
            _fake_fetch,
        )
        # Freeze "now" just past the freshest fixture row so the
        # 90s default catches it.
        import notion_agent_cli.cli.__main__ as cli_mod

        class _FrozenTime:
            @staticmethod
            def time() -> float:
                return (1778978589629 + 30_000) / 1000  # 30s after last_updated

        monkeypatch.setattr(cli_mod, "time", _FrozenTime, raising=False)

        acc = _account_file(tmp_path)
        rc = main([
            "runs", "list",
            "--workflow", "c0000001-0000-0000-0000-000000000001",
            "--json", "--account", str(acc),
        ])
        assert rc == 0
        rows = json.loads(capsys.readouterr().out)
        assert len(rows) == len(fixture["transcripts"])
        top = next(r for r in rows if r["thread_id"].startswith("36315375-830d-80bc"))
        assert top["in_progress"] is True
        legacy = next(r for r in rows if r["thread_id"].startswith("36315375-830d-804d"))
        assert legacy["in_progress"] is False


class TestCliRunsPaused:
    def test_raw_json_passthrough(self, tmp_path: Path, monkeypatch, capsys):
        """Until we have a captured listPausedWorkflowRuns response
        shape, the CLI just emits whatever the server returned so
        operators can discover the shape themselves."""
        sentinel = {"count": 2, "runs": [{"id": "r-1"}, {"id": "r-2"}]}

        async def _fake_paused(self, workflow_id, *, count_only=False, paused_reasons=()):
            assert workflow_id == "c0000001-0000-0000-0000-000000000001"
            assert count_only is False
            return sentinel

        monkeypatch.setattr(
            "notion_agent_cli.provider.NotionAgentClient.fetch_paused_workflow_runs",
            _fake_paused,
        )
        acc = _account_file(tmp_path)
        rc = main([
            "runs", "paused",
            "--workflow", "c0000001-0000-0000-0000-000000000001",
            "--account", str(acc),
        ])
        assert rc == 0
        assert json.loads(capsys.readouterr().out) == sentinel
