"""CLI tests for the ``chat`` subcommand's JSON output shape.

v0.1.6.1 added a ``binding_mode`` field so LLM operators can tell
which Notion AI configuration the call landed in. This file pins
the four-case shape (default_ai / persona_overlay /
free_form_steering / null) without going over the wire.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from notion_agent_cli.cli.__main__ import main
from notion_agent_cli.types import ChatResponse, TokenUsage


def _write_account(
    path: Path,
    *,
    agent_name: str = "",
    agent_context_page_id: str = "",
    agent_binding_mode: str = "",
) -> Path:
    """Drop a minimal-but-valid notion_account.json into ``path``."""
    body = {
        "token_v2":              "v03:test-token",
        "user_id":               "11111111-1111-1111-1111-111111111111",
        "space_id":              "22222222-2222-2222-2222-222222222222",
        "space_name":            "Test Space",
        "browser_id":            "44444444-4444-4444-4444-444444444444",
        "agent_name":            agent_name,
        "agent_context_page_id": agent_context_page_id,
        "agent_binding_mode":    agent_binding_mode,
    }
    path.write_text(json.dumps(body), encoding="utf-8")
    return path


@pytest.fixture
def stub_complete(monkeypatch):
    """Replace NotionAgentClient.complete so chat tests don't hit Notion."""
    async def _fake_complete(self, **_kwargs):
        return ChatResponse(
            text="hi",
            model="apricot-sorbet-high",
            thread_id="t-00000000-0000-0000-0000-000000000001",
            usage=TokenUsage(input_tokens=10, output_tokens=5,
                             cache_read=0, cache_creation=0),
            thinking="",
            raw={},
        )

    monkeypatch.setattr(
        "notion_agent_cli.provider.NotionAgentClient.complete",
        _fake_complete,
    )


class TestChatJsonBindingMode:
    """``chat --json`` emits a ``binding_mode`` field LLM operators
    can branch on, with four possible values:

    - ``"default_ai"``         — no Custom Agent binding configured.
    - ``"persona_overlay"``    — bound page is a workflow-registered
                                 Custom Agent's instructions page.
    - ``"free_form_steering"`` — bound page is any other Notion page.
    - ``null``                 — legacy account file (pre v0.1.6.1),
                                 binding present but mode not recorded.
    """

    def test_default_ai_when_no_binding(
        self, tmp_path: Path, capsys, stub_complete,
    ):
        path = _write_account(tmp_path / "acc.json")
        rc = main(["chat", "hi", "--json", "--account", str(path)])
        assert rc == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload["surface"] == "default_chat"
        assert payload["agent_name"] is None
        assert payload["binding_mode"] == "default_ai"

    def test_persona_overlay_when_workflow_registered(
        self, tmp_path: Path, capsys, stub_complete,
    ):
        path = _write_account(
            tmp_path / "acc.json",
            agent_name="Example Agent",
            agent_context_page_id="11111111-0000-0000-0000-000000000001",
            agent_binding_mode="persona_overlay",
        )
        rc = main(["chat", "hi", "--json", "--account", str(path)])
        assert rc == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload["surface"] == "custom_agent"
        assert payload["agent_name"] == "Example Agent"
        assert payload["binding_mode"] == "persona_overlay"

    def test_free_form_steering_when_arbitrary_page(
        self, tmp_path: Path, capsys, stub_complete,
    ):
        path = _write_account(
            tmp_path / "acc.json",
            agent_name="My Notes Index",
            agent_context_page_id="deadbeef-0000-0000-0000-000000000099",
            agent_binding_mode="free_form_steering",
        )
        rc = main(["chat", "hi", "--json", "--account", str(path)])
        assert rc == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload["surface"] == "custom_agent"
        assert payload["binding_mode"] == "free_form_steering"

    def test_null_when_legacy_account_file(
        self, tmp_path: Path, capsys, stub_complete,
    ):
        """Bound binding without recorded mode → null, not a fabrication.

        Operators upgrading from < v0.1.6.1 keep their existing
        account files; their binding still works but the mode wasn't
        recorded at init time. Surface that honestly so LLM callers
        can branch on null and (optionally) prompt for a reinit
        rather than assume a mode that may be wrong.
        """
        path = _write_account(
            tmp_path / "acc.json",
            agent_name="Example Agent",
            agent_context_page_id="11111111-0000-0000-0000-000000000001",
            agent_binding_mode="",  # legacy: field present in schema, empty value
        )
        rc = main(["chat", "hi", "--json", "--account", str(path)])
        assert rc == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload["surface"] == "custom_agent"
        assert payload["binding_mode"] is None
