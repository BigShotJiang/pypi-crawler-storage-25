"""Schema and validator for external MCP prompt files (JSON / YAML).

Each file describes one prompt and must conform to the following structure:

.. code-block:: json

    {
      "name": "create_bug_report",
      "description": "Create a structured bug report page in Jira",
      "arguments": [
        {"name": "project", "required": true, "description": "Project key"},
        {"name": "summary", "required": true, "description": "Bug summary"},
        {"name": "priority", "required": false, "description": "Bug priority"}
      ],
      "template": "Create a Jira bug in project {project} with summary '{summary}'. ..."
    }

**Fields:**

- ``name`` (str, required) — prompt name, used as the MCP prompt identifier.
- ``description`` (str, required) — short human-readable description.
- ``arguments`` (list, required) — each element is a dict with:

  - ``name`` (str, required) — argument name.
  - ``required`` (bool, default true) — whether the LLM must ask for this.
  - ``description`` (str, optional) — help text for the LLM / user.

- ``template`` (str, required) — Jinja-like template.  Use ``{arg_name}``
  placeholders that will be substituted with argument values at render time.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger("www-jira-mcp")

_EXPECTED_TOP_KEYS = {"name", "description", "arguments", "template"}
_ARG_KEYS = {"name", "required", "description"}
_PLACEHOLDER_RE = re.compile(r"\{(\w+)\}")


def validate_prompt(data: dict[str, Any], source: str = "<unknown>") -> list[str]:
    """Validate a prompt dict. Returns a list of error strings (empty = valid)."""
    errors: list[str] = []

    for key in ("name", "description", "arguments", "template"):
        if key not in data:
            errors.append(f"Missing required field '{key}'")
        elif not isinstance(data[key], str) and key != "arguments":
            errors.append(f"Field '{key}' must be a string")

    if errors:
        return errors

    name = data["name"]
    if not isinstance(name, str) or not name.strip():
        errors.append("'name' must be a non-empty string")
    elif not re.match(r"^[a-zA-Z0-9_]+$", name):
        errors.append("'name' must contain only letters, digits, underscores")

    desc = data["description"]
    if not isinstance(desc, str) or not desc.strip():
        errors.append("'description' must be a non-empty string")

    args = data["arguments"]
    if not isinstance(args, list):
        errors.append("'arguments' must be a list")
    else:
        seen_names: set[str] = set()
        for i, arg in enumerate(args, 1):
            if not isinstance(arg, dict):
                errors.append(f"arguments[{i}] must be a dict")
                continue
            if "name" not in arg:
                errors.append(f"arguments[{i}]: missing 'name'")
            else:
                aname = arg["name"]
                if not isinstance(aname, str) or not aname.strip():
                    errors.append(f"arguments[{i}]: 'name' must be a non-empty string")
                elif aname in seen_names:
                    errors.append(f"arguments[{i}]: duplicate argument name '{aname}'")
                else:
                    seen_names.add(aname)
                if not re.match(r"^[a-zA-Z0-9_]+$", str(aname)):
                    errors.append(f"arguments[{i}]: 'name' must contain only letters, digits, underscores")
            if "required" in arg and not isinstance(arg["required"], bool):
                errors.append(f"arguments[{i}]: 'required' must be a boolean")
            extra = set(arg.keys()) - _ARG_KEYS
            if extra:
                errors.append(f"arguments[{i}]: unknown keys {extra}")

        if isinstance(data.get("template"), str) and seen_names:
            placeholders = set(_PLACEHOLDER_RE.findall(data["template"]))
            undefined = placeholders - seen_names
            if undefined:
                errors.append(f"Template uses placeholders not defined in arguments: {undefined}")

    tpl = data.get("template")
    if not isinstance(tpl, str) or not tpl.strip():
        errors.append("'template' must be a non-empty string")

    extra_top = set(data.keys()) - _EXPECTED_TOP_KEYS
    if extra_top:
        errors.append(f"Unknown top-level keys: {extra_top}")

    if errors:
        logger.warning("Prompt validation errors in %s: %s", source, errors)
    return errors


def load_prompt_file(path: Path) -> dict[str, Any] | None:
    """Load and validate a single prompt file (.json, .yaml, .yml)."""
    suffix = path.suffix.lower()
    raw: str = path.read_text(encoding="utf-8")

    if suffix == ".json":
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            logger.error("Invalid JSON in %s: %s", path, exc)
            return None
    elif suffix in (".yaml", ".yml"):
        try:
            import yaml  # type: ignore[import-untyped]
        except ImportError:
            logger.error("PyYAML is required to load .yaml/.yml prompt files. Install it with: pip install pyyaml")
            return None
        try:
            data = yaml.safe_load(raw)
        except yaml.YAMLError as exc:
            logger.error("Invalid YAML in %s: %s", path, exc)
            return None
    else:
        logger.error("Unsupported prompt file format: %s", path)
        return None

    if not isinstance(data, dict):
        logger.error("Prompt file %s must contain a JSON/YAML object, got %s", path, type(data).__name__)
        return None

    errors = validate_prompt(data, source=str(path))
    if errors:
        for e in errors:
            logger.error("Validation error in %s: %s", path, e)
        return None

    return data


def render_template(template: str, arguments: dict[str, str]) -> str:
    """Render a prompt template. Missing args kept as placeholders."""
    def _replace(match: re.Match) -> str:
        key = match.group(1)
        if key in arguments and arguments[key]:
            return arguments[key]
        return match.group(0)

    return _PLACEHOLDER_RE.sub(_replace, template)


def default_args_from_prompt(prompt_data: dict[str, Any]) -> dict[str, str]:
    """Build a dict of argument_name -> empty string from prompt metadata."""
    return {arg["name"]: "" for arg in prompt_data.get("arguments", [])}
