"""MCP tools for LLM-driven prompt generation and management for Jira."""

from __future__ import annotations

import inspect
import json
import logging
from pathlib import Path
from typing import Any

from .prompt_schema import render_template, validate_prompt
from .server import mcp

logger = logging.getLogger("www-jira-mcp")


def _prompts_dir() -> Path | None:
    from .config import PROMPTS_DIR
    if PROMPTS_DIR:
        p = Path(PROMPTS_DIR)
        if p.is_dir():
            return p
    return None


@mcp.tool(
    name="jira_generate_prompt",
    title="Generate Custom Jira Prompt",
    description=(
        "Create a new MCP prompt from a JSON definition for Jira workflows. "
        "The prompt is validated, registered immediately, and optionally saved "
        "to the prompts directory for persistence. "
        "The 'prompt_def' parameter must be a JSON object with: "
        "name, description, arguments [{name, required?, description?}], "
        "template (str with {arg_name} placeholders). "
        "Set save=true to write to disk."
    ),
)
async def jira_generate_prompt(
    prompt_def: str,
    save: bool = False,
) -> dict[str, Any]:
    """Validate, register, and optionally persist a prompt definition."""
    try:
        data = json.loads(prompt_def)
    except json.JSONDecodeError as exc:
        return {"status": "error", "reason": f"Invalid JSON: {exc}"}

    if not isinstance(data, dict):
        return {"status": "error", "reason": "prompt_def must be a JSON object"}

    errors = validate_prompt(data, source="<generated>")
    if errors:
        return {"status": "error", "reason": "Validation failed", "errors": errors}

    name = data["name"]

    # Sanitize prompt name to prevent path traversal when saving
    if "/" in name or "\\" in name or ".." in name:
        return {"status": "error", "reason": "Prompt name must not contain '/', '\\', or '..'"}

    from .prompt_loader import _LOADED_PROMPTS

    arg_names = [a["name"] for a in data.get("arguments", [])]
    template = data["template"]
    description = data["description"]

    params = [
        inspect.Parameter(n, inspect.Parameter.KEYWORD_ONLY, default="")
        for n in arg_names
    ]
    sig = inspect.Signature(params)

    def _prompt_fn(**kwargs: str) -> str:
        return render_template(template, kwargs)

    _prompt_fn.__signature__ = sig  # type: ignore[attr-defined]
    _prompt_fn.__doc__ = description

    try:
        mcp.prompt(name=name)(_prompt_fn)
    except Exception as exc:
        return {"status": "error", "reason": f"Could not register prompt '{name}': {exc}"}

    _LOADED_PROMPTS[name] = data

    result: dict[str, Any] = {
        "status": "ok",
        "name": name,
        "description": description,
        "arguments": arg_names,
        "saved": False,
    }

    if save:
        prompts_dir = _prompts_dir()
        if prompts_dir is None:
            result["save_error"] = "No prompts directory configured. Set JIRA_PROMPTS_DIR to enable saving."
        else:
            out_path = prompts_dir / f"{name}.json"
            try:
                out_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                result["saved"] = True
                result["file"] = str(out_path)
                logger.info("Saved prompt '%s' to %s", name, out_path)
            except OSError as exc:
                result["save_error"] = f"Could not write file: {exc}"

    return result


@mcp.tool(
    name="jira_list_prompts",
    title="List External Jira Prompts",
    description="List all loaded external prompt definitions with their arguments.",
)
async def jira_list_prompts() -> dict[str, Any]:
    from .prompt_loader import get_loaded_prompts

    loaded = get_loaded_prompts()
    if not loaded:
        return {"status": "ok", "count": 0, "prompts": []}

    prompts = []
    for name, data in sorted(loaded.items()):
        prompts.append({
            "name": name,
            "description": data.get("description", ""),
            "arguments": [
                {
                    "name": a.get("name", ""),
                    "required": a.get("required", True),
                    "description": a.get("description", ""),
                }
                for a in data.get("arguments", [])
            ],
        })

    return {"status": "ok", "count": len(prompts), "prompts": prompts}
