"""www_jira_mcp - MCP server providing Jira integration."""

from importlib.metadata import version as _pkg_version

from .server import main

try:
    __version__ = _pkg_version("www-jira-mcp")
except Exception:
    __version__ = "0.0.0"

__all__ = ["main", "__version__"]
