"""Write MCP tools for Jira Server/Data Center (only loaded when READ_ONLY=false)."""

from __future__ import annotations

import logging
from typing import Any

from . import client
from .server import mcp

logger = logging.getLogger("www-jira-mcp")


# ---------------------------------------------------------------------------
# Issues CRUD
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_create_issue(
    project: str,
    issuetype: str,
    summary: str,
    description: str = "",
    priority: str | None = None,
    assignee: str | None = None,
    labels: list[str] | None = None,
    extra_fields: str | None = None,
) -> dict[str, Any]:
    """Create a new Jira issue.

    *project*: project key (e.g. "PROJ").
    *issuetype*: issue type name (e.g. "Bug", "Task").
    *summary*: issue title.
    *description*: issue description (plain text or Jira wiki markup).
    *priority*: optional priority name.
    *assignee*: optional username to assign.
    *labels*: optional list of labels.
    *extra_fields*: optional JSON string of additional fields to set.
    """
    if not summary.strip():
        return {"status": "error", "message": "summary is required"}

    parsed_extra: dict[str, Any] | None = None
    if extra_fields:
        import json
        try:
            parsed_extra = json.loads(extra_fields)
        except json.JSONDecodeError as e:
            return {"status": "error", "message": f"Invalid extra_fields JSON: {e}"}

    return await client.create_issue(
        project=project,
        issuetype=issuetype,
        summary=summary,
        description=description,
        priority=priority,
        assignee=assignee,
        labels=labels,
        extra_fields=parsed_extra,
    )


@mcp.tool()
async def jira_update_issue(
    issue_key: str,
    fields: str,
) -> dict[str, Any]:
    """Update an existing Jira issue's fields.

    *fields*: JSON string of fields to update, e.g. '{"summary": "New title", "priority": {"name": "High"}}'.
    """
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    import json
    try:
        parsed = json.loads(fields)
    except json.JSONDecodeError as e:
        return {"status": "error", "message": f"Invalid fields JSON: {e}"}
    return await client.update_issue(issue_key, fields=parsed)


@mcp.tool()
async def jira_delete_issue(
    issue_key: str,
    delete_subtasks: bool = False,
) -> dict[str, Any]:
    """Delete a Jira issue."""
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    return await client.delete_issue(issue_key, delete_subtasks=delete_subtasks)


@mcp.tool()
async def jira_assign_issue(
    issue_key: str,
    assignee: str,
) -> dict[str, Any]:
    """Assign a Jira issue to a user by username."""
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not assignee.strip():
        return {"status": "error", "message": "assignee is required"}
    return await client.assign_issue(issue_key, assignee)


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_add_comment(
    issue_key: str,
    body: str,
) -> dict[str, Any]:
    """Add a comment to a Jira issue."""
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not body.strip():
        return {"status": "error", "message": "body is required"}
    return await client.add_comment(issue_key, body)


@mcp.tool()
async def jira_update_comment(
    issue_key: str,
    comment_id: str,
    body: str,
) -> dict[str, Any]:
    """Update an existing comment on a Jira issue."""
    if not comment_id.strip():
        return {"status": "error", "message": "comment_id is required"}
    if not body.strip():
        return {"status": "error", "message": "body is required"}
    return await client.update_comment(issue_key, comment_id, body)


# ---------------------------------------------------------------------------
# Transitions
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_transition_issue(
    issue_key: str,
    transition_id: str,
    comment: str | None = None,
) -> dict[str, Any]:
    """Transition a Jira issue to a new status.

    Use jira_get_transitions to find the available transition IDs.
    """
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not transition_id.strip():
        return {"status": "error", "message": "transition_id is required"}
    return await client.transition_issue(issue_key, transition_id, comment=comment)


# ---------------------------------------------------------------------------
# Issue Links
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_link_issues(
    link_type_name: str,
    inward_issue: str,
    outward_issue: str,
    comment: str | None = None,
) -> dict[str, Any]:
    """Create a link between two Jira issues.

    Use jira_get_link_types to find available link type names.
    """
    if not link_type_name.strip():
        return {"status": "error", "message": "link_type_name is required"}
    if not inward_issue.strip() or not outward_issue.strip():
        return {"status": "error", "message": "both inward_issue and outward_issue are required"}
    return await client.create_issue_link(
        link_type_name=link_type_name,
        inward_issue=inward_issue,
        outward_issue=outward_issue,
        comment=comment,
    )


@mcp.tool()
async def jira_delete_link(link_id: str) -> dict[str, Any]:
    """Delete an issue link by ID."""
    if not link_id.strip():
        return {"status": "error", "message": "link_id is required"}
    return await client.delete_issue_link(link_id)


# ---------------------------------------------------------------------------
# Attachments
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_upload_attachment(
    issue_key: str,
    file_path: str,
    filename: str | None = None,
) -> dict[str, Any]:
    """Upload a file as attachment to a Jira issue.

    *file_path*: absolute path to the file to upload.
    *filename*: optional custom filename (defaults to the file's name).
    """
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not file_path.strip():
        return {"status": "error", "message": "file_path is required"}
    return await client.upload_attachment(issue_key, file_path, filename=filename)


@mcp.tool()
async def jira_delete_attachment(attachment_id: str) -> dict[str, Any]:
    """Delete a Jira attachment by ID."""
    if not attachment_id.strip():
        return {"status": "error", "message": "attachment_id is required"}
    return await client.delete_attachment(attachment_id)


# ---------------------------------------------------------------------------
# Worklogs
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_add_worklog(
    issue_key: str,
    time_spent: str,
    comment: str | None = None,
    started: str | None = None,
) -> dict[str, Any]:
    """Add a worklog entry to a Jira issue.

    *time_spent*: time string like "1h 30m", "2d", "4h".
    *started*: optional ISO-8601 datetime string.
    """
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not time_spent.strip():
        return {"status": "error", "message": "time_spent is required"}
    return await client.add_worklog(issue_key, time_spent=time_spent, comment=comment, started=started)


# ---------------------------------------------------------------------------
# Watchers
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_add_watcher(
    issue_key: str,
    user: str,
) -> dict[str, Any]:
    """Add a watcher to a Jira issue. *user* is the username."""
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not user.strip():
        return {"status": "error", "message": "user is required"}
    return await client.add_watcher(issue_key, user)


@mcp.tool()
async def jira_remove_watcher(
    issue_key: str,
    user: str,
) -> dict[str, Any]:
    """Remove a watcher from a Jira issue. *user* is the username."""
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not user.strip():
        return {"status": "error", "message": "user is required"}
    return await client.remove_watcher(issue_key, user)


# ---------------------------------------------------------------------------
# Transitions by name
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_transition_issue_by_name(
    issue_key: str,
    transition_name: str,
    comment: str | None = None,
) -> dict[str, Any]:
    """Transition a Jira issue by status name (e.g. \"In Progress\", \"Done\").

    Automatically resolves the transition name to an ID.
    """
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not transition_name.strip():
        return {"status": "error", "message": "transition_name is required"}
    return await client.transition_issue_by_name(issue_key, transition_name, comment=comment)


# ---------------------------------------------------------------------------
# Comments (delete)
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_delete_comment(
    issue_key: str,
    comment_id: str,
) -> dict[str, Any]:
    """Delete a comment from a Jira issue."""
    if not issue_key.strip():
        return {"status": "error", "message": "issue_key is required"}
    if not comment_id.strip():
        return {"status": "error", "message": "comment_id is required"}
    return await client.delete_comment(issue_key, comment_id)


# ---------------------------------------------------------------------------
# Agile: Sprint management
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_create_sprint(
    board_id: int,
    name: str,
    goal: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
) -> dict[str, Any]:
    """Create a new sprint on a board.

    *board_id*: the Agile board ID.
    *name*: sprint name.
    *goal*: optional sprint goal.
    *start_date* / *end_date*: optional ISO-8601 datetime strings.
    """
    if not name.strip():
        return {"status": "error", "message": "name is required"}
    return await client.create_sprint(
        board_id, name, goal=goal, start_date=start_date, end_date=end_date,
    )


@mcp.tool()
async def jira_update_sprint(
    sprint_id: int,
    fields: str,
) -> dict[str, Any]:
    """Update a sprint's fields.

    *fields*: JSON string with fields to update, e.g.
    '{"name": "Sprint 2", "state": "active", "goal": "Ship v2"}'.
    """
    import json
    try:
        parsed = json.loads(fields)
    except json.JSONDecodeError as e:
        return {"status": "error", "message": f"Invalid fields JSON: {e}"}
    return await client.update_sprint(sprint_id, fields=parsed)


@mcp.tool()
async def jira_move_issues_to_sprint(
    sprint_id: int,
    issue_keys: list[str],
) -> dict[str, Any]:
    """Move issues into a sprint."""
    if not issue_keys:
        return {"status": "error", "message": "issue_keys is required"}
    return await client.move_issues_to_sprint(sprint_id, issue_keys)


@mcp.tool()
async def jira_move_issues_to_backlog(
    issue_keys: list[str],
) -> dict[str, Any]:
    """Move issues to the backlog (remove from sprint)."""
    if not issue_keys:
        return {"status": "error", "message": "issue_keys is required"}
    return await client.move_issues_to_backlog(issue_keys)
