"""MCP Resources — reference data that AI can read on demand."""

from __future__ import annotations

from . import client
from .server import mcp


@mcp.resource("jira://projects")
async def projects_resource() -> str:
    """Available Jira projects (key: name)."""
    data = await client.get_projects()
    lines = []
    for p in data.get("projects", []):
        lines.append(f"{p['key']}: {p['name']}")
    return "\n".join(lines) if lines else "No projects found."


@mcp.resource("jira://issuetypes")
async def issuetypes_resource() -> str:
    """Available Jira issue types."""
    data = await client.get_issue_types()
    lines = []
    for it in data.get("issue_types", []):
        sub = " (sub-task)" if it.get("subtask") else ""
        lines.append(f"{it['name']}{sub}: {it.get('description', '')}")
    return "\n".join(lines) if lines else "No issue types found."


@mcp.resource("jira://priorities")
async def priorities_resource() -> str:
    """Available Jira priorities."""
    data = await client.get_priorities()
    lines = []
    for p in data.get("priorities", []):
        lines.append(f"{p['name']}: {p.get('description', '')}")
    return "\n".join(lines) if lines else "No priorities found."


@mcp.resource("jira://statuses")
async def statuses_resource() -> str:
    """Available Jira statuses grouped by category."""
    data = await client.get_statuses()
    lines = []
    for s in data.get("statuses", []):
        cat = s.get("category", "")
        lines.append(f"{s['name']} [{cat}]: {s.get('description', '')}")
    return "\n".join(lines) if lines else "No statuses found."


@mcp.resource("jira://fields")
async def fields_resource() -> str:
    """Available Jira fields (system + custom)."""
    data = await client.get_fields()
    lines = []
    for f in data.get("fields", []):
        custom = " (custom)" if f.get("custom") else ""
        schema = f.get("schema", "")
        lines.append(f"{f['id']} — {f['name']}{custom} [{schema}]")
    return "\n".join(lines) if lines else "No fields found."
