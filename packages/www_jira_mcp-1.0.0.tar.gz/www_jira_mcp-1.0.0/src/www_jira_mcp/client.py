"""Async Jira REST API client (v2) for Server/Data Center using httpx."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import urllib.parse
from pathlib import Path
from typing import Any

import httpx

from .config import (
    AUTH_TYPE,
    HTTP_PROXY,
    HTTPS_PROXY,
    MAX_RESULTS,
    PASSWORD,
    PERSONAL_TOKEN,
    PROJECTS_FILTER,
    SSL_VERIFY,
    TIMEOUT,
    URL,
    USERNAME,
)

logger = logging.getLogger("www-jira-mcp")

# Pre-compiled JQL detection regex — avoids re-compilation on every search() call.
_JQL_KEYWORD_RE = re.compile(
    r"(?:assignee|reporter|status|priority|project|issuetype|resolution|fixVersion"
    r"|affectedVersion|component|label|created|updated|due|summary|description"
    r"|comment|key|issueKey|type|sprint|epicLink|parent|subtask)"
    r"\s*[=!<>~]",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Client singleton
# ---------------------------------------------------------------------------

_CLIENT: httpx.AsyncClient | None = None
_CLIENT_LOCK = asyncio.Lock()


async def get_client() -> httpx.AsyncClient:
    """Return (or lazily create) the shared async HTTP client."""
    global _CLIENT
    async with _CLIENT_LOCK:
        if _CLIENT is not None and not _CLIENT.is_closed:
            return _CLIENT

        if not URL or not AUTH_TYPE:
            raise RuntimeError(
                "Jira is not configured. Set JIRA_URL and "
                "JIRA_PERSONAL_TOKEN (or JIRA_USERNAME + JIRA_PASSWORD) "
                "environment variables."
            )

        base = URL.rstrip("/")

        headers: dict[str, str] = {
            "Accept": "application/json",
        }

        if AUTH_TYPE == "pat":
            headers["Authorization"] = f"Bearer {PERSONAL_TOKEN}"
        else:
            credentials = base64.b64encode(f"{USERNAME}:{PASSWORD}".encode()).decode()
            headers["Authorization"] = f"Basic {credentials}"

        proxy = HTTPS_PROXY or HTTP_PROXY
        _CLIENT = httpx.AsyncClient(
            base_url=base,
            headers=headers,
            timeout=TIMEOUT,
            verify=SSL_VERIFY,
            proxy=proxy,
            follow_redirects=True,
        )
        return _CLIENT


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _apply_projects_filter(jql: str) -> str:
    """Append a project filter clause to JQL if JIRA_PROJECTS_FILTER is set."""
    if not PROJECTS_FILTER:
        return jql
    projects = [p.strip().replace("\\", "\\\\").replace('"', '\\"') for p in PROJECTS_FILTER.split(",")]
    if len(projects) == 1:
        clause = f'project = "{projects[0]}"'
    else:
        clause = "project IN (" + ", ".join(f'"{p}"' for p in projects) + ")"
    if clause.lower() in jql.lower():
        return jql
    return f"{jql} AND {clause}" if jql else clause


def _is_jql(query: str) -> bool:
    """Heuristic: return True if *query* looks like JQL."""
    return bool(_JQL_KEYWORD_RE.search(query))


def _safe_path_segment(segment: str) -> str:
    """URL-encode a path segment to prevent path injection via '/' or special chars."""
    return urllib.parse.quote(str(segment), safe="")


def _escape_jql_value(value: str) -> str:
    """Escape special characters in a value intended for JQL string literals."""
    # Backslash must be escaped first, then double quotes.
    return value.replace("\\", "\\\\").replace('"', '\\"')


async def _request(method: str, path: str, **kwargs: Any) -> httpx.Response:
    """Make an API request and return the response, raising on HTTP errors."""
    client = await get_client()
    response = await client.request(method, path, **kwargs)
    response.raise_for_status()
    return response


async def _get_json(path: str, **kwargs: Any) -> Any:
    """GET request returning parsed JSON."""
    r = await _request("GET", path, **kwargs)
    return r.json()


# ---------------------------------------------------------------------------
# URL parsing
# ---------------------------------------------------------------------------


def parse_jira_url(url: str) -> str | None:
    """Extract issue key from a Jira URL.

    Supports patterns like:
      - https://jira.example.com/browse/PROJ-123
      - https://jira.example.com/projects/PROJ/issues/PROJ-123
      - https://jira.example.com/jira/browse/PROJ-123
    """
    m = re.search(r"(?:browse|issues)/([A-Z][A-Z0-9]+-\d+)", url)
    if m:
        return m.group(1)
    return None


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


async def search(
    query: str,
    *,
    max_results: int = MAX_RESULTS,
    start: int = 0,
    fields: str | None = None,
    expand: str | None = None,
) -> dict[str, Any]:
    """Search issues using JQL or plain text."""
    if not query.strip():
        return {"status": "error", "message": "Empty query"}

    jql = query if _is_jql(query) else f'summary ~ "{_escape_jql_value(query)}" OR description ~ "{_escape_jql_value(query)}"'
    jql = _apply_projects_filter(jql)

    params: dict[str, Any] = {
        "jql": jql,
        "startAt": start,
        "maxResults": max_results,
    }
    if fields:
        params["fields"] = fields
    if expand:
        params["expand"] = expand

    data = await _get_json("/rest/api/2/search", params=params)
    issues = []
    for issue in data.get("issues", []):
        fld = issue.get("fields", {})
        issues.append({
            "key": issue.get("key"),
            "summary": fld.get("summary", ""),
            "status": fld.get("status", {}).get("name", ""),
            "priority": fld.get("priority", {}).get("name", ""),
            "issuetype": fld.get("issuetype", {}).get("name", ""),
            "assignee": (fld.get("assignee") or {}).get("displayName", "Unassigned"),
            "reporter": (fld.get("reporter") or {}).get("displayName", ""),
            "created": fld.get("created", ""),
            "updated": fld.get("updated", ""),
        })
    return {
        "status": "success",
        "total": data.get("total", 0),
        "start_at": data.get("startAt", 0),
        "max_results": data.get("maxResults", max_results),
        "result_count": len(issues),
        "issues": issues,
        "next_start": start + len(issues) if data.get("total", 0) > start + len(issues) else None,
    }


# ---------------------------------------------------------------------------
# Issues
# ---------------------------------------------------------------------------


async def get_issue(
    issue_key: str,
    *,
    fields: str | None = None,
    expand: str | None = None,
) -> dict[str, Any]:
    """Get a single issue by key."""
    params: dict[str, Any] = {}
    if fields:
        params["fields"] = fields
    if expand:
        params["expand"] = expand

    data = await _get_json(f"/rest/api/2/issue/{_safe_path_segment(issue_key)}", params=params)
    return data


async def create_issue(
    *,
    project: str,
    issuetype: str,
    summary: str,
    description: str = "",
    priority: str | None = None,
    assignee: str | None = None,
    labels: list[str] | None = None,
    extra_fields: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a new issue."""
    fields: dict[str, Any] = {
        "project": {"key": project},
        "issuetype": {"name": issuetype},
        "summary": summary,
    }
    if description:
        fields["description"] = description
    if priority:
        fields["priority"] = {"name": priority}
    if assignee:
        fields["assignee"] = {"name": assignee}
    if labels:
        fields["labels"] = labels
    if extra_fields:
        fields.update(extra_fields)

    payload = {"fields": fields}
    r = await _request("POST", "/rest/api/2/issue", json=payload)
    return r.json()


async def update_issue(
    issue_key: str,
    *,
    fields: dict[str, Any],
) -> dict[str, Any]:
    """Update an existing issue's fields."""
    await _request("PUT", f"/rest/api/2/issue/{_safe_path_segment(issue_key)}", json={"fields": fields})
    return {"status": "success", "message": f"Issue {issue_key} updated"}


async def delete_issue(
    issue_key: str,
    *,
    delete_subtasks: bool = False,
) -> dict[str, Any]:
    """Delete an issue."""
    params = {"deleteSubtasks": "true" if delete_subtasks else "false"}
    await _request("DELETE", f"/rest/api/2/issue/{_safe_path_segment(issue_key)}", params=params)
    return {"status": "success", "message": f"Issue {issue_key} deleted"}


async def assign_issue(
    issue_key: str,
    assignee: str,
) -> dict[str, Any]:
    """Assign an issue to a user."""
    await _request(
        "PUT",
        f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/assignee",
        json={"name": assignee},
    )
    return {"status": "success", "message": f"Issue {issue_key} assigned to {assignee}"}


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


async def get_comments(
    issue_key: str,
    *,
    start: int = 0,
    limit: int = MAX_RESULTS,
) -> dict[str, Any]:
    """Get comments for an issue."""
    data = await _get_json(
        f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/comment",
        params={"startAt": start, "maxResults": limit},
    )
    comments = []
    for c in data.get("comments", []):
        comments.append({
            "id": c.get("id"),
            "author": (c.get("author") or {}).get("displayName", ""),
            "body": c.get("body", ""),
            "created": c.get("created", ""),
            "updated": c.get("updated", ""),
        })
    return {
        "status": "success",
        "issue_key": issue_key,
        "total": data.get("total", len(comments)),
        "result_count": len(comments),
        "comments": comments,
        "next_start": start + len(comments) if data.get("total", 0) > start + len(comments) else None,
    }


async def add_comment(
    issue_key: str,
    body: str,
    *,
    visibility: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Add a comment to an issue."""
    payload: dict[str, Any] = {"body": body}
    if visibility:
        payload["visibility"] = visibility
    r = await _request("POST", f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/comment", json=payload)
    return r.json()


async def update_comment(
    issue_key: str,
    comment_id: str,
    body: str,
) -> dict[str, Any]:
    """Update an existing comment."""
    r = await _request(
        "PUT",
        f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/comment/{_safe_path_segment(comment_id)}",
        json={"body": body},
    )
    return r.json()


async def delete_comment(
    issue_key: str,
    comment_id: str,
) -> dict[str, Any]:
    """Delete a comment."""
    await _request("DELETE", f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/comment/{_safe_path_segment(comment_id)}")
    return {"status": "success", "message": f"Comment {comment_id} deleted"}


# ---------------------------------------------------------------------------
# Transitions
# ---------------------------------------------------------------------------


async def get_transitions(issue_key: str) -> dict[str, Any]:
    """Get available transitions for an issue."""
    data = await _get_json(f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/transitions")
    transitions = []
    for t in data.get("transitions", []):
        transitions.append({
            "id": t.get("id"),
            "name": t.get("name"),
            "to_status": (t.get("to") or {}).get("name", ""),
        })
    return {
        "status": "success",
        "issue_key": issue_key,
        "transitions": transitions,
    }


async def transition_issue(
    issue_key: str,
    transition_id: str,
    *,
    fields: dict[str, Any] | None = None,
    comment: str | None = None,
) -> dict[str, Any]:
    """Perform a transition on an issue."""
    payload: dict[str, Any] = {"transition": {"id": transition_id}}
    if fields:
        payload["fields"] = fields
    if comment:
        payload["update"] = {"comment": [{"add": {"body": comment}}]}
    await _request("POST", f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/transitions", json=payload)
    return {"status": "success", "message": f"Issue {issue_key} transitioned"}


async def transition_issue_by_name(
    issue_key: str,
    transition_name: str,
    *,
    comment: str | None = None,
) -> dict[str, Any]:
    """Transition an issue by transition name (e.g. "In Progress", "Done").

    Resolves the name to a transition ID automatically.
    """
    data = await _get_json(f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/transitions")
    for t in data.get("transitions", []):
        if t.get("name", "").lower() == transition_name.lower():
            return await transition_issue(
                issue_key, t["id"], comment=comment,
            )
    available = [t.get("name") for t in data.get("transitions", [])]
    return {
        "status": "error",
        "message": f"Transition '{transition_name}' not found. Available: {', '.join(available)}",
    }


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------


async def get_projects() -> dict[str, Any]:
    """List all projects."""
    data = await _get_json("/rest/api/2/project")
    projects = []
    for p in data if isinstance(data, list) else []:
        projects.append({
            "key": p.get("key"),
            "name": p.get("name"),
            "projectTypeKey": p.get("projectTypeKey", ""),
            "lead": (p.get("lead") or {}).get("displayName", ""),
        })
    return {"status": "success", "result_count": len(projects), "projects": projects}


async def get_project(project_key: str) -> dict[str, Any]:
    """Get a single project by key."""
    return await _get_json(f"/rest/api/2/project/{_safe_path_segment(project_key)}")


async def get_project_statuses(project_key: str) -> dict[str, Any]:
    """Get all statuses for a project's issue types."""
    data = await _get_json(f"/rest/api/2/project/{_safe_path_segment(project_key)}/statuses")
    return {"status": "success", "project": project_key, "statuses": data}


# ---------------------------------------------------------------------------
# Issue Links
# ---------------------------------------------------------------------------


async def get_link_types() -> dict[str, Any]:
    """Get available issue link types."""
    data = await _get_json("/rest/api/2/issueLinkType")
    link_types = []
    for lt in data.get("issueLinkTypes", []):
        link_types.append({
            "id": lt.get("id"),
            "name": lt.get("name"),
            "inward": lt.get("inward", ""),
            "outward": lt.get("outward", ""),
        })
    return {"status": "success", "result_count": len(link_types), "link_types": link_types}


async def create_issue_link(
    *,
    link_type_name: str,
    inward_issue: str,
    outward_issue: str,
    comment: str | None = None,
) -> dict[str, Any]:
    """Create a link between two issues."""
    payload: dict[str, Any] = {
        "type": {"name": link_type_name},
        "inwardIssue": inward_issue,
        "outwardIssue": outward_issue,
    }
    if comment:
        payload["comment"] = {"body": comment}
    await _request("POST", "/rest/api/2/issueLink", json=payload)
    return {"status": "success", "message": f"Linked {inward_issue} <-> {outward_issue}"}


async def delete_issue_link(link_id: str) -> dict[str, Any]:
    """Delete an issue link."""
    await _request("DELETE", f"/rest/api/2/issueLink/{_safe_path_segment(link_id)}")
    return {"status": "success", "message": f"Link {link_id} deleted"}


# ---------------------------------------------------------------------------
# Attachments
# ---------------------------------------------------------------------------


async def get_attachments(issue_key: str) -> dict[str, Any]:
    """Get attachments for an issue (from issue fields)."""
    data = await _get_json(f"/rest/api/2/issue/{_safe_path_segment(issue_key)}", params={"fields": "attachment"})
    attachments = []
    for a in data.get("fields", {}).get("attachment", []):
        attachments.append({
            "id": a.get("id"),
            "filename": a.get("filename", ""),
            "size": a.get("size", 0),
            "content_type": a.get("mimeType", ""),
            "author": (a.get("author") or {}).get("displayName", ""),
            "created": a.get("created", ""),
            "content_url": a.get("content", ""),
        })
    return {
        "status": "success",
        "issue_key": issue_key,
        "result_count": len(attachments),
        "attachments": attachments,
    }


async def download_attachment(
    attachment_id: str,
    save_path: str,
) -> dict[str, Any]:
    """Download an attachment by ID to a file path."""
    client = await get_client()
    r = await client.get(f"/rest/api/2/attachment/content/{_safe_path_segment(attachment_id)}")
    r.raise_for_status()

    path = Path(save_path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(r.content)
    return {
        "status": "success",
        "attachment_id": attachment_id,
        "saved_to": str(path),
        "bytes": len(r.content),
    }


async def upload_attachment(
    issue_key: str,
    file_path: str,
    filename: str | None = None,
) -> dict[str, Any]:
    """Upload a file as attachment to an issue."""
    client = await get_client()
    path = Path(file_path)
    if not path.is_file():
        return {"status": "error", "message": f"File not found: {file_path}"}

    name = filename or path.name
    files = {"file": (name, path.read_bytes())}
    # Jira requires X-Atlassian-Token: no-check for attachment uploads
    r = await client.post(
        f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/attachments",
        files=files,
        headers={"X-Atlassian-Token": "no-check"},
    )
    r.raise_for_status()
    result = r.json()
    if isinstance(result, list) and result:
        return {"status": "success", "attachment": result[0]}
    return {"status": "success", "attachment": result}


async def delete_attachment(attachment_id: str) -> dict[str, Any]:
    """Delete an attachment."""
    await _request("DELETE", f"/rest/api/2/attachment/{_safe_path_segment(attachment_id)}")
    return {"status": "success", "message": f"Attachment {attachment_id} deleted"}


# ---------------------------------------------------------------------------
# Worklogs
# ---------------------------------------------------------------------------


async def get_worklogs(
    issue_key: str,
) -> dict[str, Any]:
    """Get worklogs for an issue."""
    data = await _get_json(f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/worklog")
    worklogs = []
    for w in data.get("worklogs", []):
        worklogs.append({
            "id": w.get("id"),
            "author": (w.get("author") or {}).get("displayName", ""),
            "time_spent": w.get("timeSpent", ""),
            "time_spent_seconds": w.get("timeSpentSeconds", 0),
            "comment": w.get("comment", ""),
            "started": w.get("started", ""),
            "created": w.get("created", ""),
        })
    return {
        "status": "success",
        "issue_key": issue_key,
        "total": data.get("total", len(worklogs)),
        "result_count": len(worklogs),
        "worklogs": worklogs,
    }


async def add_worklog(
    issue_key: str,
    *,
    time_spent: str,
    comment: str | None = None,
    started: str | None = None,
) -> dict[str, Any]:
    """Add a worklog entry to an issue."""
    payload: dict[str, Any] = {"timeSpent": time_spent}
    if comment:
        payload["comment"] = comment
    if started:
        payload["started"] = started
    r = await _request("POST", f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/worklog", json=payload)
    return r.json()


# ---------------------------------------------------------------------------
# Watchers
# ---------------------------------------------------------------------------


async def get_watchers(issue_key: str) -> dict[str, Any]:
    """Get watchers for an issue."""
    data = await _get_json(f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/watchers")
    watchers = []
    for w in data.get("watchers", []):
        watchers.append({
            "name": w.get("name", ""),
            "display_name": w.get("displayName", ""),
            "active": w.get("active", False),
        })
    return {
        "status": "success",
        "issue_key": issue_key,
        "watcher_count": data.get("watchCount", len(watchers)),
        "is_watching": data.get("isWatching", False),
        "watchers": watchers,
    }


async def add_watcher(
    issue_key: str,
    user: str,
) -> dict[str, Any]:
    """Add a watcher to an issue. *user* is username (Server/DC)."""
    await _request("POST", f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/watchers", content=json.dumps(user))
    return {"status": "success", "message": f"Watcher {user} added to {issue_key}"}


async def remove_watcher(
    issue_key: str,
    user: str,
) -> dict[str, Any]:
    """Remove a watcher from an issue."""
    await _request(
        "DELETE",
        f"/rest/api/2/issue/{_safe_path_segment(issue_key)}/watchers",
        params={"username": user},
    )
    return {"status": "success", "message": f"Watcher {user} removed from {issue_key}"}


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------


async def search_user(
    query: str,
    *,
    max_results: int = MAX_RESULTS,
) -> dict[str, Any]:
    """Search for users."""
    if not query.strip():
        return {"status": "error", "message": "Empty query"}

    data = await _get_json(
        "/rest/api/2/user/search",
        params={"username": query, "maxResults": max_results},
    )
    users = []
    for u in data if isinstance(data, list) else []:
        users.append({
            "name": u.get("name", ""),
            "display_name": u.get("displayName", ""),
            "email": u.get("emailAddress", ""),
            "active": u.get("active", False),
        })
    return {"status": "success", "result_count": len(users), "users": users}


async def get_current_user() -> dict[str, Any]:
    """Get the current authenticated user."""
    return await _get_json("/rest/api/2/myself")


# ---------------------------------------------------------------------------
# Metadata: priorities, statuses, resolutions, fields
# ---------------------------------------------------------------------------


async def get_priorities() -> dict[str, Any]:
    """List all priorities."""
    data = await _get_json("/rest/api/2/priority")
    priorities = []
    for p in data if isinstance(data, list) else []:
        priorities.append({
            "id": p.get("id"),
            "name": p.get("name", ""),
            "description": p.get("description", ""),
            "icon_url": p.get("iconUrl", ""),
        })
    return {"status": "success", "result_count": len(priorities), "priorities": priorities}


async def get_statuses() -> dict[str, Any]:
    """List all statuses."""
    data = await _get_json("/rest/api/2/status")
    statuses = []
    for s in data if isinstance(data, list) else []:
        statuses.append({
            "id": s.get("id"),
            "name": s.get("name", ""),
            "description": s.get("description", ""),
            "category": (s.get("statusCategory") or {}).get("name", ""),
        })
    return {"status": "success", "result_count": len(statuses), "statuses": statuses}


async def get_resolutions() -> dict[str, Any]:
    """List all resolutions."""
    data = await _get_json("/rest/api/2/resolution")
    resolutions = []
    for r in data if isinstance(data, list) else []:
        resolutions.append({
            "id": r.get("id"),
            "name": r.get("name", ""),
            "description": r.get("description", ""),
        })
    return {"status": "success", "result_count": len(resolutions), "resolutions": resolutions}


async def get_fields() -> dict[str, Any]:
    """List all fields (including custom)."""
    data = await _get_json("/rest/api/2/field")
    fields = []
    for f in data if isinstance(data, list) else []:
        fields.append({
            "id": f.get("id"),
            "name": f.get("name", ""),
            "custom": f.get("custom", False),
            "schema": (f.get("schema") or {}).get("type", ""),
        })
    return {"status": "success", "result_count": len(fields), "fields": fields}


# ---------------------------------------------------------------------------
# Issue Types
# ---------------------------------------------------------------------------


async def get_issue_types(
    project_key: str | None = None,
) -> dict[str, Any]:
    """List all issue types, optionally scoped to a project."""
    if project_key:
        # Server/DC: get issue types for a specific project via project ID.
        # First resolve project key to ID.
        proj = await _get_json(f"/rest/api/2/project/{_safe_path_segment(project_key)}")
        project_id = proj.get("id")
        data = await _get_json("/rest/api/2/issuetype/project", params={"projectId": project_id})
    else:
        data = await _get_json("/rest/api/2/issuetype")

    issue_types = []
    for it in data if isinstance(data, list) else []:
        issue_types.append({
            "id": it.get("id"),
            "name": it.get("name", ""),
            "description": it.get("description", ""),
            "subtask": it.get("subtask", False),
            "icon_url": it.get("iconUrl", ""),
        })
    return {"status": "success", "result_count": len(issue_types), "issue_types": issue_types}


# ---------------------------------------------------------------------------
# Agile: Boards & Sprints
# ---------------------------------------------------------------------------


async def get_boards(
    project_key: str | None = None,
    board_type: str | None = None,
    *,
    max_results: int = MAX_RESULTS,
) -> dict[str, Any]:
    """List Agile boards, optionally filtered by project or type."""
    params: dict[str, Any] = {"maxResults": max_results}
    if project_key:
        params["projectKeyOrId"] = project_key
    if board_type:
        params["type"] = board_type
    data = await _get_json("/rest/agile/1.0/board", params=params)
    boards = []
    for b in data.get("values", []):
        boards.append({
            "id": b.get("id"),
            "name": b.get("name", ""),
            "type": b.get("type", ""),
        })
    return {
        "status": "success",
        "result_count": len(boards),
        "is_last": data.get("isLast", True),
        "boards": boards,
    }


async def get_board(board_id: int) -> dict[str, Any]:
    """Get a single Agile board by ID."""
    return await _get_json(f"/rest/agile/1.0/board/{board_id}")


async def get_sprints(
    board_id: int,
    state: str | None = None,
    *,
    max_results: int = MAX_RESULTS,
) -> dict[str, Any]:
    """List sprints for a board."""
    params: dict[str, Any] = {"maxResults": max_results}
    if state:
        params["state"] = state
    data = await _get_json(f"/rest/agile/1.0/board/{board_id}/sprint", params=params)
    sprints = []
    for s in data.get("values", []):
        sprints.append({
            "id": s.get("id"),
            "name": s.get("name", ""),
            "state": s.get("state", ""),
            "start_date": s.get("startDate", ""),
            "end_date": s.get("endDate", ""),
            "goal": s.get("goal", ""),
        })
    return {
        "status": "success",
        "result_count": len(sprints),
        "is_last": data.get("isLast", True),
        "sprints": sprints,
    }


async def get_sprint(sprint_id: int) -> dict[str, Any]:
    """Get a single sprint by ID."""
    return await _get_json(f"/rest/agile/1.0/sprint/{sprint_id}")


async def get_sprint_issues(
    sprint_id: int,
    *,
    max_results: int = MAX_RESULTS,
) -> dict[str, Any]:
    """Get issues in a sprint."""
    data = await _get_json(
        f"/rest/agile/1.0/sprint/{sprint_id}/issue",
        params={"maxResults": max_results},
    )
    issues = []
    for issue in data.get("issues", []):
        fld = issue.get("fields", {})
        issues.append({
            "key": issue.get("key"),
            "summary": fld.get("summary", ""),
            "status": fld.get("status", {}).get("name", ""),
            "priority": fld.get("priority", {}).get("name", ""),
            "issuetype": fld.get("issuetype", {}).get("name", ""),
            "assignee": (fld.get("assignee") or {}).get("displayName", "Unassigned"),
        })
    return {
        "status": "success",
        "result_count": len(issues),
        "issues": issues,
    }


async def create_sprint(
    board_id: int,
    name: str,
    *,
    goal: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
) -> dict[str, Any]:
    """Create a sprint on a board."""
    payload: dict[str, Any] = {"name": name, "originBoardId": board_id}
    if goal:
        payload["goal"] = goal
    if start_date:
        payload["startDate"] = start_date
    if end_date:
        payload["endDate"] = end_date
    r = await _request("POST", "/rest/agile/1.0/sprint", json=payload)
    return r.json()


async def update_sprint(
    sprint_id: int,
    *,
    fields: dict[str, Any],
) -> dict[str, Any]:
    """Update a sprint's fields (name, goal, state, dates)."""
    r = await _request("PUT", f"/rest/agile/1.0/sprint/{sprint_id}", json=fields)
    return r.json()


async def move_issues_to_sprint(
    sprint_id: int,
    issue_keys: list[str],
) -> dict[str, Any]:
    """Move issues into a sprint."""
    await _request(
        "POST",
        f"/rest/agile/1.0/sprint/{sprint_id}/issue",
        json={"issues": issue_keys},
    )
    return {"status": "success", "message": f"{len(issue_keys)} issues moved to sprint {sprint_id}"}


async def move_issues_to_backlog(
    issue_keys: list[str],
) -> dict[str, Any]:
    """Move issues to the backlog."""
    await _request(
        "POST",
        "/rest/agile/1.0/backlog/issue",
        json={"issues": issue_keys},
    )
    return {"status": "success", "message": f"{len(issue_keys)} issues moved to backlog"}
