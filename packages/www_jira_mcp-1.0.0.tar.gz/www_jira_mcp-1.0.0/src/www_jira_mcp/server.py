"""MCP server for Jira Server/Data Center integration."""

from __future__ import annotations

import logging
import os

from mcp.server.fastmcp import FastMCP

from .config import READ_ONLY

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.DEBUG if os.getenv("JIRA_DEBUG") else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("www-jira-mcp")

# ---------------------------------------------------------------------------
# MCP instance
# ---------------------------------------------------------------------------

_READ_INSTRUCTIONS = (
    "Jira Server/Data Center integration tools.\n"
    "\nSearch & Issues:\n"
    "- jira_search: Search issues using JQL.\n"
    "- jira_get_issue: Get issue by key or URL.\n"
    "\nComments:\n"
    "- jira_get_comments: Get comments on an issue.\n"
    "\nTransitions:\n"
    "- jira_get_transitions: Get available status transitions.\n"
    "\nProjects:\n"
    "- jira_get_projects: List projects.\n"
    "- jira_get_project: Get project by key.\n"
    "- jira_get_project_statuses: Get statuses for a project.\n"
    "\nLinks:\n"
    "- jira_get_link_types: Get available issue link types.\n"
    "\nAttachments:\n"
    "- jira_get_attachments: List attachments on an issue.\n"
    "- jira_download_attachment: Download a single attachment.\n"
    "\nWorklogs:\n"
    "- jira_get_worklogs: Get worklogs for an issue.\n"
    "\nWatchers:\n"
    "- jira_get_watchers: Get watchers for an issue.\n"
    "\nMetadata:\n"
    "- jira_get_priorities: List priorities.\n"
    "- jira_get_statuses: List statuses.\n"
    "- jira_get_resolutions: List resolutions.\n"
    "- jira_get_fields: List custom fields.\n"
    "- jira_get_issue_types: List issue types (all or per project).\n"
    "\nAgile (Boards & Sprints):\n"
    "- jira_get_boards: List Agile boards.\n"
    "- jira_get_board: Get board details.\n"
    "- jira_get_sprints: List sprints for a board.\n"
    "- jira_get_sprint: Get sprint details.\n"
    "- jira_get_sprint_issues: Get issues in a sprint.\n"
    "\nUsers:\n"
    "- jira_search_user: Search for users.\n"
    "- jira_get_current_user: Get current authenticated user.\n"
)

_WRITE_INSTRUCTIONS = (
    "\nIssues:\n"
    "- jira_create_issue: Create a new issue.\n"
    "- jira_update_issue: Update an existing issue.\n"
    "- jira_delete_issue: Delete an issue.\n"
    "- jira_assign_issue: Assign an issue to a user.\n"
    "\nComments:\n"
    "- jira_add_comment: Add a comment.\n"
    "- jira_update_comment: Update a comment.\n"
    "- jira_delete_comment: Delete a comment.\n"
    "\nTransitions:\n"
    "- jira_transition_issue: Transition by ID.\n"
    "- jira_transition_issue_by_name: Transition by name (e.g. \"Done\").\n"
    "\nLinks:\n"
    "- jira_link_issues: Link two issues.\n"
    "- jira_delete_link: Delete an issue link.\n"
    "\nAttachments:\n"
    "- jira_upload_attachment: Upload a file.\n"
    "- jira_delete_attachment: Delete an attachment.\n"
    "\nWorklogs:\n"
    "- jira_add_worklog: Add a worklog entry.\n"
    "\nWatchers:\n"
    "- jira_add_watcher: Add a watcher.\n"
    "- jira_remove_watcher: Remove a watcher.\n"
    "\nAgile (Sprints):\n"
    "- jira_create_sprint: Create a sprint.\n"
    "- jira_update_sprint: Update sprint fields.\n"
    "- jira_move_issues_to_sprint: Move issues into a sprint.\n"
    "- jira_move_issues_to_backlog: Move issues to backlog.\n"
    "\nPrompt management:\n"
    "- jira_generate_prompt: Create custom prompts from JSON definitions.\n"
    "- jira_list_prompts: List loaded external prompts.\n"
)

mcp = FastMCP(
    name="www-jira-mcp",
    instructions=_READ_INSTRUCTIONS + (_WRITE_INSTRUCTIONS if not READ_ONLY else ""),
)

# ---------------------------------------------------------------------------
# Load tools
# ---------------------------------------------------------------------------

from . import read_tools  # noqa: F401, E402
from . import resources  # noqa: F401, E402
from . import prompt_generate  # noqa: F401, E402

if not READ_ONLY:
    from . import write_tools  # noqa: F401, E402

# ---------------------------------------------------------------------------
# Load prompts from bundled defaults + user directory
# ---------------------------------------------------------------------------
from pathlib import Path  # noqa: E402

from .config import PROMPTS_DIR  # noqa: E402
from .prompt_loader import load_prompts_from_dir  # noqa: E402

_builtin_dir = Path(__file__).parent / "prompts.d"
_count = load_prompts_from_dir(_builtin_dir)
if _count:
    logger.info("Loaded %d built-in prompt(s)", _count)

if PROMPTS_DIR:
    _count = load_prompts_from_dir(Path(PROMPTS_DIR))
    if _count:
        logger.info("Loaded %d user prompt(s) from %s", _count, PROMPTS_DIR)


def main() -> None:
    logger.info("Starting www-jira-mcp (READ_ONLY=%s)", READ_ONLY)
    mcp.run(transport="stdio")
