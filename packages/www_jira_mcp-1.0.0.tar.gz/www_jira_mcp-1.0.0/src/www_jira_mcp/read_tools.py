"""Read-only MCP tools for Jira Server/Data Center."""

from __future__ import annotations

import logging
from typing import Any

from . import client
from .server import mcp

logger = logging.getLogger("www-jira-mcp")


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_search(
    query: str,
    max_results: int = 50,
    start: int = 0,
    fields: str | None = None,
) -> dict[str, Any]:
    """Search Jira issues using JQL or plain text.

    If the query looks like JQL it is used as-is; otherwise a text search
    is performed across summary and description fields.
    """
    return await client.search(query, max_results=max_results, start=start, fields=fields)


# ---------------------------------------------------------------------------
# Issue details
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_issue(
    issue_key: str | None = None,
    url: str | None = None,
    fields: str | None = None,
) -> dict[str, Any]:
    """Get a Jira issue by key or URL.

    Provide either *issue_key* (e.g. "PROJ-123") or *url*
    (e.g. "https://jira.example.com/browse/PROJ-123").
    """
    key = issue_key
    if not key and url:
        key = client.parse_jira_url(url)
    if not key:
        return {"status": "error", "message": "Provide issue_key or url"}
    return await client.get_issue(key, fields=fields)


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_comments(
    issue_key: str,
    start: int = 0,
    limit: int = 50,
) -> dict[str, Any]:
    """Get comments for a Jira issue."""
    return await client.get_comments(issue_key, start=start, limit=limit)


# ---------------------------------------------------------------------------
# Transitions
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_transitions(issue_key: str) -> dict[str, Any]:
    """Get available status transitions for a Jira issue."""
    return await client.get_transitions(issue_key)


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_projects() -> dict[str, Any]:
    """List all Jira projects visible to the current user."""
    return await client.get_projects()


@mcp.tool()
async def jira_get_project(project_key: str) -> dict[str, Any]:
    """Get a Jira project by key (e.g. "PROJ")."""
    if not project_key.strip():
        return {"status": "error", "message": "project_key is required"}
    return await client.get_project(project_key)


@mcp.tool()
async def jira_get_project_statuses(project_key: str) -> dict[str, Any]:
    """Get all statuses for issue types in a project."""
    if not project_key.strip():
        return {"status": "error", "message": "project_key is required"}
    return await client.get_project_statuses(project_key)


# ---------------------------------------------------------------------------
# Issue Links
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_link_types() -> dict[str, Any]:
    """Get available issue link types."""
    return await client.get_link_types()


# ---------------------------------------------------------------------------
# Attachments
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_attachments(issue_key: str) -> dict[str, Any]:
    """List attachments for a Jira issue."""
    return await client.get_attachments(issue_key)


@mcp.tool()
async def jira_download_attachment(
    attachment_id: str,
    save_path: str,
) -> dict[str, Any]:
    """Download a Jira attachment to disk.

    *attachment_id*: the numeric attachment ID.
    *save_path*: absolute file path to save the file.
    """
    if not attachment_id.strip():
        return {"status": "error", "message": "attachment_id is required"}
    if not save_path.strip():
        return {"status": "error", "message": "save_path is required"}
    return await client.download_attachment(attachment_id, save_path)


# ---------------------------------------------------------------------------
# Worklogs
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_worklogs(issue_key: str) -> dict[str, Any]:
    """Get worklog entries for a Jira issue."""
    return await client.get_worklogs(issue_key)


# ---------------------------------------------------------------------------
# Watchers
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_watchers(issue_key: str) -> dict[str, Any]:
    """Get watchers for a Jira issue."""
    return await client.get_watchers(issue_key)


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_priorities() -> dict[str, Any]:
    """List all Jira priorities."""
    return await client.get_priorities()


@mcp.tool()
async def jira_get_statuses() -> dict[str, Any]:
    """List all Jira statuses."""
    return await client.get_statuses()


@mcp.tool()
async def jira_get_resolutions() -> dict[str, Any]:
    """List all Jira resolutions."""
    return await client.get_resolutions()


@mcp.tool()
async def jira_get_fields() -> dict[str, Any]:
    """List all Jira fields (including custom fields)."""
    return await client.get_fields()


@mcp.tool()
async def jira_get_issue_types(
    project_key: str | None = None,
) -> dict[str, Any]:
    """List all Jira issue types, optionally for a specific project."""
    return await client.get_issue_types(project_key)


# ---------------------------------------------------------------------------
# Agile: Boards & Sprints (read)
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_get_boards(
    project_key: str | None = None,
    board_type: str | None = None,
    max_results: int = 50,
) -> dict[str, Any]:
    """List Jira Agile boards, optionally filtered by project key or type (scrum/kanban)."""
    return await client.get_boards(project_key, board_type, max_results=max_results)


@mcp.tool()
async def jira_get_board(board_id: int) -> dict[str, Any]:
    """Get details of a Jira Agile board by ID."""
    return await client.get_board(board_id)


@mcp.tool()
async def jira_get_sprints(
    board_id: int,
    state: str | None = None,
    max_results: int = 50,
) -> dict[str, Any]:
    """List sprints for a board. Filter by state: active, future, closed."""
    return await client.get_sprints(board_id, state, max_results=max_results)


@mcp.tool()
async def jira_get_sprint(sprint_id: int) -> dict[str, Any]:
    """Get details of a specific sprint."""
    return await client.get_sprint(sprint_id)


@mcp.tool()
async def jira_get_sprint_issues(
    sprint_id: int,
    max_results: int = 50,
) -> dict[str, Any]:
    """Get issues in a sprint."""
    return await client.get_sprint_issues(sprint_id, max_results=max_results)


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------


@mcp.tool()
async def jira_search_user(
    query: str,
    max_results: int = 50,
) -> dict[str, Any]:
    """Search for Jira users by name or username."""
    return await client.search_user(query, max_results=max_results)


@mcp.tool()
async def jira_get_current_user() -> dict[str, Any]:
    """Get the current authenticated Jira user."""
    return await client.get_current_user()
