"""Tests for external prompt schema, loader, and generator tools (Jira)."""

import json
from pathlib import Path

import pytest

from www_jira_mcp.prompt_schema import (
    load_prompt_file,
    render_template,
    validate_prompt,
)
from www_jira_mcp.prompt_loader import (
    clear_loaded_prompts,
    load_prompts_from_dir,
)
from www_jira_mcp.prompt_generate import (
    jira_generate_prompt,
    jira_list_prompts,
)


@pytest.fixture(autouse=True)
def _reset_prompts():
    clear_loaded_prompts()
    yield
    clear_loaded_prompts()


# ---------------------------------------------------------------------------
# Schema validation
# ---------------------------------------------------------------------------

class TestValidatePrompt:
    def test_valid_minimal(self):
        data = {
            "name": "hello",
            "description": "Says hello",
            "arguments": [{"name": "user", "required": True}],
            "template": "Hello {user}!",
        }
        assert validate_prompt(data) == []

    def test_valid_full(self):
        data = {
            "name": "bug_report",
            "description": "Bug report",
            "arguments": [
                {"name": "project", "required": True, "description": "Project key"},
                {"name": "priority", "required": False},
            ],
            "template": "Bug in {project} [{priority}]",
        }
        assert validate_prompt(data) == []

    def test_missing_name(self):
        data = {"description": "d", "arguments": [], "template": "t"}
        errors = validate_prompt(data)
        assert any("'name'" in e for e in errors)

    def test_missing_template(self):
        data = {"name": "n", "description": "d", "arguments": []}
        errors = validate_prompt(data)
        assert any("'template'" in e for e in errors)

    def test_invalid_name_chars(self):
        data = {"name": "my-prompt!", "description": "d", "arguments": [], "template": "t"}
        errors = validate_prompt(data)
        assert any("name" in e for e in errors)

    def test_duplicate_args(self):
        data = {
            "name": "n", "description": "d",
            "arguments": [{"name": "x"}, {"name": "x"}],
            "template": "{x}",
        }
        errors = validate_prompt(data)
        assert any("duplicate" in e for e in errors)

    def test_undefined_placeholder(self):
        data = {
            "name": "n", "description": "d",
            "arguments": [{"name": "x"}],
            "template": "{x} and {y}",
        }
        errors = validate_prompt(data)
        assert any("not defined in arguments" in e for e in errors)


# ---------------------------------------------------------------------------
# File loading
# ---------------------------------------------------------------------------

class TestLoadPromptFile:
    def test_valid_json(self, tmp_path):
        f = tmp_path / "p.json"
        f.write_text(json.dumps({
            "name": "test", "description": "d",
            "arguments": [{"name": "x"}], "template": "{x}",
        }))
        assert load_prompt_file(f)["name"] == "test"

    def test_invalid_json(self, tmp_path):
        f = tmp_path / "bad.json"
        f.write_text("{bad")
        assert load_prompt_file(f) is None

    def test_valid_yaml(self, tmp_path):
        f = tmp_path / "p.yaml"
        f.write_text("name: y\ndescription: d\narguments: []\ntemplate: hello\n")
        assert load_prompt_file(f)["name"] == "y"

    def test_unsupported(self, tmp_path):
        f = tmp_path / "p.toml"
        f.write_text("name = x")
        assert load_prompt_file(f) is None


# ---------------------------------------------------------------------------
# Template rendering
# ---------------------------------------------------------------------------

class TestRenderTemplate:
    def test_substitution(self):
        assert render_template("Hi {n}!", {"n": "World"}) == "Hi World!"

    def test_missing_kept(self):
        assert render_template("Hi {n} {m}!", {"n": "X"}) == "Hi X {m}!"

    def test_empty_kept(self):
        assert render_template("Hi {n}!", {"n": ""}) == "Hi {n}!"


# ---------------------------------------------------------------------------
# Directory loader
# ---------------------------------------------------------------------------

class TestLoadPromptsFromDir:
    def test_loads_files(self, tmp_path):
        (tmp_path / "a.json").write_text(json.dumps({
            "name": "pa", "description": "d", "arguments": [], "template": "t",
        }))
        (tmp_path / "b.yaml").write_text("name: pb\ndescription: d\narguments: []\ntemplate: t\n")
        assert load_prompts_from_dir(tmp_path) == 2

    def test_skips_dotfiles(self, tmp_path):
        (tmp_path / ".h.json").write_text("{}")
        assert load_prompts_from_dir(tmp_path) == 0

    def test_nonexistent(self):
        assert load_prompts_from_dir(Path("/nope_xyz")) == 0


# ---------------------------------------------------------------------------
# Generate / List tools
# ---------------------------------------------------------------------------

class TestGeneratePromptTool:
    async def test_valid(self):
        r = await jira_generate_prompt(prompt_def=json.dumps({
            "name": "my_p", "description": "d",
            "arguments": [{"name": "x"}], "template": "{x}",
        }))
        assert r["status"] == "ok"
        assert r["name"] == "my_p"

    async def test_invalid_json(self):
        r = await jira_generate_prompt(prompt_def="{bad")
        assert r["status"] == "error"

    async def test_validation_fails(self):
        r = await jira_generate_prompt(prompt_def=json.dumps({
            "name": "", "description": "", "arguments": "x", "template": "",
        }))
        assert "Validation" in r["reason"]

    async def test_save_no_dir(self, monkeypatch):
        monkeypatch.setattr("www_jira_mcp.config.PROMPTS_DIR", "")
        r = await jira_generate_prompt(prompt_def=json.dumps({
            "name": "s", "description": "d", "arguments": [], "template": "t",
        }), save=True)
        assert "save_error" in r

    async def test_save_to_dir(self, tmp_path, monkeypatch):
        monkeypatch.setattr("www_jira_mcp.config.PROMPTS_DIR", str(tmp_path))
        r = await jira_generate_prompt(prompt_def=json.dumps({
            "name": "saved_p", "description": "d",
            "arguments": [{"name": "x"}], "template": "{x}",
        }), save=True)
        assert r["saved"] is True
        assert (tmp_path / "saved_p.json").exists()


class TestListPromptsTool:
    async def test_empty(self):
        r = await jira_list_prompts()
        assert r["count"] == 0

    async def test_after_generate(self):
        await jira_generate_prompt(prompt_def=json.dumps({
            "name": "lp", "description": "d",
            "arguments": [{"name": "x", "required": False}],
            "template": "{x}",
        }))
        r = await jira_list_prompts()
        assert r["count"] == 1
        assert r["prompts"][0]["arguments"][0]["required"] is False
