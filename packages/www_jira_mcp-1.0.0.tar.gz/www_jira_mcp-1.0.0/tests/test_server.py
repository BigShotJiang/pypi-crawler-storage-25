"""Tests for www_jira_mcp."""

from __future__ import annotations

import os
from unittest.mock import AsyncMock

import pytest

# ---------------------------------------------------------------------------
# Ensure env vars are set before importing config (avoids ValueError)
# ---------------------------------------------------------------------------
os.environ.setdefault("JIRA_URL", "https://jira.example.com")
os.environ.setdefault("JIRA_PERSONAL_TOKEN", "test-pat")

from www_jira_mcp.config import (
    _detect_auth,
    _env_bool,
    _env_int,
    _env_str,
)


# ===========================================================================
# Config helpers
# ===========================================================================


class TestEnvHelpers:
    def test_env_str(self, monkeypatch):
        monkeypatch.setenv("TEST_STR", "hello")
        assert _env_str("TEST_STR") == "hello"

    def test_env_str_default(self):
        assert _env_str("NONEXISTENT_VAR_XYZ") == ""
        assert _env_str("NONEXISTENT_VAR_XYZ", "fallback") == "fallback"

    def test_env_int(self, monkeypatch):
        monkeypatch.setenv("TEST_INT", "42")
        assert _env_int("TEST_INT", 0) == 42

    def test_env_int_default(self):
        assert _env_int("NONEXISTENT_VAR_XYZ", 99) == 99

    def test_env_int_clamp(self, monkeypatch):
        monkeypatch.setenv("TEST_CLAMP", "200")
        assert _env_int("TEST_CLAMP", 50, hi=100) == 100

    def test_env_bool_true(self, monkeypatch):
        for val in ("1", "true", "True", "yes", "on"):
            monkeypatch.setenv("TEST_BOOL", val)
            assert _env_bool("TEST_BOOL", default=False) is True

    def test_env_bool_false(self, monkeypatch):
        monkeypatch.setenv("TEST_BOOL", "no")
        assert _env_bool("TEST_BOOL") is False

    def test_env_bool_false_correct(self, monkeypatch):
        monkeypatch.setenv("TEST_BOOL2", "false")
        assert _env_bool("TEST_BOOL2", default=True) is False

    def test_env_bool_default(self):
        assert _env_bool("NONEXISTENT_VAR_XYZ", default=True) is True
        assert _env_bool("NONEXISTENT_VAR_XYZ", default=False) is False


class TestAuthDetect:
    def test_dc_pat(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.internal.com")
        monkeypatch.setenv("JIRA_PERSONAL_TOKEN", "my-pat-token")
        monkeypatch.delenv("JIRA_USERNAME", raising=False)
        monkeypatch.delenv("JIRA_PASSWORD", raising=False)
        monkeypatch.delenv("JIRA_API_TOKEN", raising=False)
        auth_type, user, password, pat = _detect_auth()
        assert auth_type == "pat"
        assert pat == "my-pat-token"

    def test_dc_basic(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.internal.com")
        monkeypatch.setenv("JIRA_USERNAME", "admin")
        monkeypatch.setenv("JIRA_PASSWORD", "pass")
        monkeypatch.delenv("JIRA_PERSONAL_TOKEN", raising=False)
        auth_type, user, password, pat = _detect_auth()
        assert auth_type == "basic"
        assert password == "pass"

    def test_dc_no_auth(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.internal.com")
        monkeypatch.delenv("JIRA_USERNAME", raising=False)
        monkeypatch.delenv("JIRA_PASSWORD", raising=False)
        monkeypatch.delenv("JIRA_API_TOKEN", raising=False)
        monkeypatch.delenv("JIRA_PERSONAL_TOKEN", raising=False)
        with pytest.raises(ValueError, match="JIRA_PASSWORD"):
            _detect_auth()

    def test_no_url(self, monkeypatch):
        monkeypatch.delenv("JIRA_URL", raising=False)
        with pytest.raises(ValueError, match="JIRA_URL"):
            _detect_auth()

    def test_pat_takes_priority_over_basic(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.example.com")
        monkeypatch.setenv("JIRA_PERSONAL_TOKEN", "my-pat")
        monkeypatch.setenv("JIRA_USERNAME", "admin")
        monkeypatch.setenv("JIRA_PASSWORD", "pass")
        auth_type, _, _, pat = _detect_auth()
        assert auth_type == "pat"
        assert pat == "my-pat"

    def test_api_token_backward_compat(self, monkeypatch):
        """JIRA_API_TOKEN still works as fallback for JIRA_PASSWORD."""
        monkeypatch.setenv("JIRA_URL", "https://jira.example.com")
        monkeypatch.setenv("JIRA_USERNAME", "admin")
        monkeypatch.setenv("JIRA_API_TOKEN", "legacy-pass")
        monkeypatch.delenv("JIRA_PASSWORD", raising=False)
        monkeypatch.delenv("JIRA_PERSONAL_TOKEN", raising=False)
        auth_type, _, password, _ = _detect_auth()
        assert auth_type == "basic"
        assert password == "legacy-pass"

    def test_password_takes_priority_over_api_token(self, monkeypatch):
        monkeypatch.setenv("JIRA_URL", "https://jira.example.com")
        monkeypatch.setenv("JIRA_USERNAME", "admin")
        monkeypatch.setenv("JIRA_PASSWORD", "new-pass")
        monkeypatch.setenv("JIRA_API_TOKEN", "old-pass")
        monkeypatch.delenv("JIRA_PERSONAL_TOKEN", raising=False)
        _, _, password, _ = _detect_auth()
        assert password == "new-pass"


# ---------------------------------------------------------------------------
# READ_ONLY flag
# ---------------------------------------------------------------------------


class TestReadOnly:
    def test_write_tools_not_registered_in_read_only(self):
        """When READ_ONLY=true, write tools module should not be loaded."""
        from www_jira_mcp.config import READ_ONLY
        if not READ_ONLY:
            pytest.skip("READ_ONLY is false, skip")
        import www_jira_mcp.server as srv
        # read_tools should be loaded
        import www_jira_mcp.read_tools  # noqa: F401
        # write_tools should NOT be in sys.modules
        import sys
        assert "www_jira_mcp.write_tools" not in sys.modules or not srv.READ_ONLY

    def test_write_allowed_when_not_read_only(self, monkeypatch):
        monkeypatch.setenv("JIRA_READ_ONLY", "false")
        # We just test that the env var is respected
        from www_jira_mcp.config import _env_bool
        assert _env_bool("JIRA_READ_ONLY", default=True) is False

    def test_read_not_blocked_in_read_only(self):
        """Read tools are always available."""
        import www_jira_mcp.read_tools  # noqa: F401


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


class TestMain:
    def test_main_is_callable(self):
        from www_jira_mcp.server import main
        assert callable(main)


# ---------------------------------------------------------------------------
# Server tool tests (mocked API)
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_jira(monkeypatch):
    """Patch the API client module to return mock responses."""
    import www_jira_mcp.client as client_mod

    mock = AsyncMock()
    monkeypatch.setattr(client_mod, "get_client", mock.get_client)

    # Patch all API functions
    for name in [
        "search", "get_issue", "create_issue", "update_issue", "delete_issue",
        "assign_issue", "get_comments", "add_comment", "update_comment",
        "delete_comment",
        "get_transitions", "transition_issue", "transition_issue_by_name",
        "get_projects", "get_project", "get_project_statuses",
        "get_link_types", "create_issue_link", "delete_issue_link",
        "get_attachments", "download_attachment", "upload_attachment", "delete_attachment",
        "get_worklogs", "add_worklog",
        "get_watchers", "add_watcher", "remove_watcher",
        "search_user", "get_current_user",
        "get_priorities", "get_statuses", "get_resolutions", "get_fields",
        "get_issue_types",
        "get_boards", "get_board",
        "get_sprints", "get_sprint", "get_sprint_issues",
        "create_sprint", "update_sprint",
        "move_issues_to_sprint", "move_issues_to_backlog",
    ]:
        monkeypatch.setattr(client_mod, name, getattr(mock, name))
    return mock


# --- Search ---

class TestSearchTool:
    @pytest.mark.asyncio
    async def test_search_returns_results(self, mock_jira):
        mock_jira.search.return_value = {
            "status": "success", "total": 1, "issues": [{"key": "PROJ-1"}],
            "result_count": 1, "next_start": None,
        }
        from www_jira_mcp.read_tools import jira_search
        r = await jira_search("project = PROJ")
        assert r["status"] == "success"
        assert r["result_count"] == 1

    @pytest.mark.asyncio
    async def test_search_no_results(self, mock_jira):
        mock_jira.search.return_value = {
            "status": "success", "total": 0, "issues": [],
            "result_count": 0, "next_start": None,
        }
        from www_jira_mcp.read_tools import jira_search
        r = await jira_search("nonexistent")
        assert r["result_count"] == 0

    @pytest.mark.asyncio
    async def test_search_empty_query(self):
        """Empty query is validated by the client, not mocked here."""
        from www_jira_mcp.client import search
        r = await search("")
        assert r["status"] == "error"


# --- URL Parsing ---

class TestParseJiraUrl:
    def test_browse_url(self):
        from www_jira_mcp.client import parse_jira_url
        assert parse_jira_url("https://jira.example.com/browse/PROJ-123") == "PROJ-123"

    def test_issues_url(self):
        from www_jira_mcp.client import parse_jira_url
        assert parse_jira_url("https://jira.example.com/projects/PROJ/issues/PROJ-456") == "PROJ-456"

    def test_with_context_path(self):
        from www_jira_mcp.client import parse_jira_url
        assert parse_jira_url("https://jira.example.com/jira/browse/PROJ-789") == "PROJ-789"

    def test_invalid_url(self):
        from www_jira_mcp.client import parse_jira_url
        assert parse_jira_url("https://example.com/something") is None


# --- Issue ---

class TestGetIssueTool:
    @pytest.mark.asyncio
    async def test_get_issue_by_key(self, mock_jira):
        mock_jira.get_issue.return_value = {"key": "PROJ-1", "fields": {"summary": "Test"}}
        from www_jira_mcp.read_tools import jira_get_issue
        r = await jira_get_issue(issue_key="PROJ-1")
        assert r["key"] == "PROJ-1"

    @pytest.mark.asyncio
    async def test_get_issue_by_url(self, mock_jira):
        mock_jira.get_issue.return_value = {"key": "PROJ-1", "fields": {"summary": "Test"}}
        from www_jira_mcp.read_tools import jira_get_issue
        r = await jira_get_issue(url="https://jira.example.com/browse/PROJ-1")
        assert r["key"] == "PROJ-1"

    @pytest.mark.asyncio
    async def test_get_issue_no_args(self, mock_jira):
        from www_jira_mcp.read_tools import jira_get_issue
        r = await jira_get_issue()
        assert r["status"] == "error"


# --- Projects ---

class TestProjectsTools:
    @pytest.mark.asyncio
    async def test_get_projects(self, mock_jira):
        mock_jira.get_projects.return_value = {"status": "success", "projects": []}
        from www_jira_mcp.read_tools import jira_get_projects
        r = await jira_get_projects()
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_project_by_key(self, mock_jira):
        mock_jira.get_project.return_value = {"key": "PROJ", "name": "My Project"}
        from www_jira_mcp.read_tools import jira_get_project
        r = await jira_get_project("PROJ")
        assert r["key"] == "PROJ"

    @pytest.mark.asyncio
    async def test_get_project_empty_key(self, mock_jira):
        from www_jira_mcp.read_tools import jira_get_project
        r = await jira_get_project("")
        assert r["status"] == "error"


# --- Comments ---

class TestCommentsTools:
    @pytest.mark.asyncio
    async def test_get_comments(self, mock_jira):
        mock_jira.get_comments.return_value = {"status": "success", "comments": []}
        from www_jira_mcp.read_tools import jira_get_comments
        r = await jira_get_comments("PROJ-1")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_add_comment(self, mock_jira):
        mock_jira.add_comment.return_value = {"id": "1001", "body": "hello"}
        from www_jira_mcp.write_tools import jira_add_comment
        r = await jira_add_comment("PROJ-1", "hello")
        assert r["id"] == "1001"

    @pytest.mark.asyncio
    async def test_add_comment_empty_body(self, mock_jira):
        from www_jira_mcp.write_tools import jira_add_comment
        r = await jira_add_comment("PROJ-1", "")
        assert r["status"] == "error"


# --- Transitions ---

class TestTransitionsTools:
    @pytest.mark.asyncio
    async def test_get_transitions(self, mock_jira):
        mock_jira.get_transitions.return_value = {"status": "success", "transitions": []}
        from www_jira_mcp.read_tools import jira_get_transitions
        r = await jira_get_transitions("PROJ-1")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_transition_issue(self, mock_jira):
        mock_jira.transition_issue.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_transition_issue
        r = await jira_transition_issue("PROJ-1", "31")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_transition_issue_empty_id(self, mock_jira):
        from www_jira_mcp.write_tools import jira_transition_issue
        r = await jira_transition_issue("PROJ-1", "")
        assert r["status"] == "error"


# --- Issue CRUD ---

class TestIssueCrudTools:
    @pytest.mark.asyncio
    async def test_create_issue(self, mock_jira):
        mock_jira.create_issue.return_value = {"key": "PROJ-10"}
        from www_jira_mcp.write_tools import jira_create_issue
        r = await jira_create_issue("PROJ", "Bug", "Something broke")
        assert r["key"] == "PROJ-10"

    @pytest.mark.asyncio
    async def test_create_issue_empty_summary(self, mock_jira):
        from www_jira_mcp.write_tools import jira_create_issue
        r = await jira_create_issue("PROJ", "Bug", "")
        assert r["status"] == "error"

    @pytest.mark.asyncio
    async def test_update_issue(self, mock_jira):
        mock_jira.update_issue.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_update_issue
        r = await jira_update_issue("PROJ-1", '{"summary": "Updated"}')
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_delete_issue(self, mock_jira):
        mock_jira.delete_issue.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_delete_issue
        r = await jira_delete_issue("PROJ-1")
        assert r["status"] == "success"


# --- Links ---

class TestLinksTools:
    @pytest.mark.asyncio
    async def test_get_link_types(self, mock_jira):
        mock_jira.get_link_types.return_value = {"status": "success", "link_types": []}
        from www_jira_mcp.read_tools import jira_get_link_types
        r = await jira_get_link_types()
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_link_issues(self, mock_jira):
        mock_jira.create_issue_link.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_link_issues
        r = await jira_link_issues("Duplicate", "PROJ-1", "PROJ-2")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_delete_link(self, mock_jira):
        mock_jira.delete_issue_link.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_delete_link
        r = await jira_delete_link("10001")
        assert r["status"] == "success"


# --- Attachments ---

class TestAttachmentsTools:
    @pytest.mark.asyncio
    async def test_get_attachments(self, mock_jira):
        mock_jira.get_attachments.return_value = {"status": "success", "attachments": []}
        from www_jira_mcp.read_tools import jira_get_attachments
        r = await jira_get_attachments("PROJ-1")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_delete_attachment(self, mock_jira):
        mock_jira.delete_attachment.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_delete_attachment
        r = await jira_delete_attachment("10001")
        assert r["status"] == "success"


# --- Worklogs ---

class TestWorklogsTools:
    @pytest.mark.asyncio
    async def test_get_worklogs(self, mock_jira):
        mock_jira.get_worklogs.return_value = {"status": "success", "worklogs": []}
        from www_jira_mcp.read_tools import jira_get_worklogs
        r = await jira_get_worklogs("PROJ-1")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_add_worklog(self, mock_jira):
        mock_jira.add_worklog.return_value = {"id": "1001", "timeSpent": "1h"}
        from www_jira_mcp.write_tools import jira_add_worklog
        r = await jira_add_worklog("PROJ-1", "1h")
        assert r["timeSpent"] == "1h"

    @pytest.mark.asyncio
    async def test_add_worklog_empty_time(self, mock_jira):
        from www_jira_mcp.write_tools import jira_add_worklog
        r = await jira_add_worklog("PROJ-1", "")
        assert r["status"] == "error"


# --- Watchers ---

class TestWatchersTools:
    @pytest.mark.asyncio
    async def test_get_watchers(self, mock_jira):
        mock_jira.get_watchers.return_value = {"status": "success", "watchers": []}
        from www_jira_mcp.read_tools import jira_get_watchers
        r = await jira_get_watchers("PROJ-1")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_add_watcher(self, mock_jira):
        mock_jira.add_watcher.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_add_watcher
        r = await jira_add_watcher("PROJ-1", "admin")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_remove_watcher(self, mock_jira):
        mock_jira.remove_watcher.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_remove_watcher
        r = await jira_remove_watcher("PROJ-1", "admin")
        assert r["status"] == "success"


# --- Users ---

class TestSearchUserTool:
    @pytest.mark.asyncio
    async def test_search_user(self, mock_jira):
        mock_jira.search_user.return_value = {"status": "success", "users": []}
        from www_jira_mcp.read_tools import jira_search_user
        r = await jira_search_user("admin")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_search_user_empty(self):
        """Empty query is validated by the client, not mocked here."""
        from www_jira_mcp.client import search_user
        r = await search_user("")
        assert r["status"] == "error"


# --- Metadata ---

class TestMetadataTools:
    @pytest.mark.asyncio
    async def test_get_priorities(self, mock_jira):
        mock_jira.get_priorities.return_value = {"status": "success", "priorities": []}
        from www_jira_mcp.read_tools import jira_get_priorities
        r = await jira_get_priorities()
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_statuses(self, mock_jira):
        mock_jira.get_statuses.return_value = {"status": "success", "statuses": []}
        from www_jira_mcp.read_tools import jira_get_statuses
        r = await jira_get_statuses()
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_resolutions(self, mock_jira):
        mock_jira.get_resolutions.return_value = {"status": "success", "resolutions": []}
        from www_jira_mcp.read_tools import jira_get_resolutions
        r = await jira_get_resolutions()
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_fields(self, mock_jira):
        mock_jira.get_fields.return_value = {"status": "success", "fields": []}
        from www_jira_mcp.read_tools import jira_get_fields
        r = await jira_get_fields()
        assert r["status"] == "success"


# --- Issue Types ---


class TestIssueTypesTool:
    @pytest.mark.asyncio
    async def test_get_issue_types_all(self, mock_jira):
        mock_jira.get_issue_types.return_value = {"status": "success", "result_count": 2, "issue_types": [
            {"id": "1", "name": "Bug"}, {"id": "2", "name": "Task"},
        ]}
        from www_jira_mcp.read_tools import jira_get_issue_types
        r = await jira_get_issue_types()
        assert r["status"] == "success"
        assert r["result_count"] == 2

    @pytest.mark.asyncio
    async def test_get_issue_types_for_project(self, mock_jira):
        mock_jira.get_issue_types.return_value = {"status": "success", "result_count": 1, "issue_types": [
            {"id": "1", "name": "Bug"},
        ]}
        from www_jira_mcp.read_tools import jira_get_issue_types
        r = await jira_get_issue_types(project_key="PROJ")
        mock_jira.get_issue_types.assert_called_once_with("PROJ")
        assert r["result_count"] == 1


# --- Agile: Boards ---


class TestBoardsTools:
    @pytest.mark.asyncio
    async def test_get_boards(self, mock_jira):
        mock_jira.get_boards.return_value = {"status": "success", "boards": [
            {"id": 1, "name": "Scrum Board", "type": "scrum"},
        ]}
        from www_jira_mcp.read_tools import jira_get_boards
        r = await jira_get_boards()
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_board_by_id(self, mock_jira):
        mock_jira.get_board.return_value = {"id": 1, "name": "Scrum Board"}
        from www_jira_mcp.read_tools import jira_get_board
        r = await jira_get_board(1)
        assert r["id"] == 1


# --- Agile: Sprints ---


class TestSprintsTools:
    @pytest.mark.asyncio
    async def test_get_sprints(self, mock_jira):
        mock_jira.get_sprints.return_value = {"status": "success", "sprints": [
            {"id": 10, "name": "Sprint 1", "state": "active"},
        ]}
        from www_jira_mcp.read_tools import jira_get_sprints
        r = await jira_get_sprints(1)
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_sprint_issues(self, mock_jira):
        mock_jira.get_sprint_issues.return_value = {"status": "success", "result_count": 1, "issues": [
            {"key": "PROJ-1", "summary": "Task"},
        ]}
        from www_jira_mcp.read_tools import jira_get_sprint_issues
        r = await jira_get_sprint_issues(10)
        assert r["result_count"] == 1


# --- Transition by name ---


class TestTransitionByNameTool:
    @pytest.mark.asyncio
    async def test_transition_by_name(self, mock_jira):
        mock_jira.transition_issue_by_name.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_transition_issue_by_name
        r = await jira_transition_issue_by_name("PROJ-1", "Done")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_transition_by_name_empty(self, mock_jira):
        from www_jira_mcp.write_tools import jira_transition_issue_by_name
        r = await jira_transition_issue_by_name("PROJ-1", "")
        assert r["status"] == "error"

    @pytest.mark.asyncio
    async def test_transition_by_name_not_found(self, mock_jira):
        mock_jira.transition_issue_by_name.return_value = {
            "status": "error",
            "message": "Transition 'Unknown' not found.",
        }
        from www_jira_mcp.write_tools import jira_transition_issue_by_name
        r = await jira_transition_issue_by_name("PROJ-1", "Unknown")
        assert r["status"] == "error"


# --- Delete comment ---


class TestDeleteCommentTool:
    @pytest.mark.asyncio
    async def test_delete_comment(self, mock_jira):
        mock_jira.delete_comment.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_delete_comment
        r = await jira_delete_comment("PROJ-1", "10001")
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_delete_comment_empty_id(self, mock_jira):
        from www_jira_mcp.write_tools import jira_delete_comment
        r = await jira_delete_comment("PROJ-1", "")
        assert r["status"] == "error"


# --- Agile: Sprint write tools ---


class TestSprintWriteTools:
    @pytest.mark.asyncio
    async def test_create_sprint(self, mock_jira):
        mock_jira.create_sprint.return_value = {"id": 20, "name": "Sprint 2"}
        from www_jira_mcp.write_tools import jira_create_sprint
        r = await jira_create_sprint(1, "Sprint 2")
        assert r["name"] == "Sprint 2"

    @pytest.mark.asyncio
    async def test_create_sprint_empty_name(self, mock_jira):
        from www_jira_mcp.write_tools import jira_create_sprint
        r = await jira_create_sprint(1, "")
        assert r["status"] == "error"

    @pytest.mark.asyncio
    async def test_update_sprint(self, mock_jira):
        mock_jira.update_sprint.return_value = {"id": 20, "name": "Renamed"}
        from www_jira_mcp.write_tools import jira_update_sprint
        r = await jira_update_sprint(20, '{"name": "Renamed"}')
        assert r["name"] == "Renamed"

    @pytest.mark.asyncio
    async def test_update_sprint_invalid_json(self, mock_jira):
        from www_jira_mcp.write_tools import jira_update_sprint
        r = await jira_update_sprint(20, "not json")
        assert r["status"] == "error"

    @pytest.mark.asyncio
    async def test_move_issues_to_sprint(self, mock_jira):
        mock_jira.move_issues_to_sprint.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_move_issues_to_sprint
        r = await jira_move_issues_to_sprint(10, ["PROJ-1", "PROJ-2"])
        assert r["status"] == "success"

    @pytest.mark.asyncio
    async def test_move_issues_to_sprint_empty_list(self, mock_jira):
        from www_jira_mcp.write_tools import jira_move_issues_to_sprint
        r = await jira_move_issues_to_sprint(10, [])
        assert r["status"] == "error"

    @pytest.mark.asyncio
    async def test_move_issues_to_backlog(self, mock_jira):
        mock_jira.move_issues_to_backlog.return_value = {"status": "success"}
        from www_jira_mcp.write_tools import jira_move_issues_to_backlog
        r = await jira_move_issues_to_backlog(["PROJ-1"])
        assert r["status"] == "success"
