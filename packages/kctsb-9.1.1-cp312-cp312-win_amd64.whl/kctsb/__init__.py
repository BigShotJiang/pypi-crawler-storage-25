"""
kctsb - Knight's Cryptographic Trusted Security Base (Python Interface)

High-performance homomorphic encryption, differential privacy, and encrypted
ML inference library. Python bindings for the kctsb C++ cryptographic core.

Architecture:
    Python API (kctsb.ckks, kctsb.dp, kctsb.ml)
        ↓
    pybind11 bindings (_kctsb_core)
        ↓
    C++ core (libkctsb_static)

Usage:
    >>> import kctsb
    >>> ctx = kctsb.CKKSContext(poly_modulus_degree=8192,
    ...                         coeff_modulus_levels=5,
    ...                         scale_bits=40)
    >>> sk = ctx.keygen()
    >>> pk = ctx.public_key(sk)
    >>> pt = ctx.encode([1.0, 2.0, 3.0])
    >>> ct = ctx.encrypt(pk, pt)
    >>> result = ctx.decrypt(sk, ct)
    >>> values = ctx.decode(result)

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

import os
import sys
import logging

__version__ = "9.1.1"
__author__ = "knightc"

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# DLL loader: add bundled runtime libraries to DLL search path (Windows)
# ---------------------------------------------------------------------------
_libs_dir = os.path.join(os.path.dirname(__file__), "_libs")
_dll_handle = None
if sys.platform == "win32" and os.path.isdir(_libs_dir):
    try:
        _dll_handle = os.add_dll_directory(_libs_dir)
        logger.debug("Added DLL directory: %s", _libs_dir)
    except OSError:
        logger.warning("Failed to add DLL directory: %s", _libs_dir)

# Try to import the compiled C++ core module
try:
    from ._kctsb_core import ckks as _ckks_core
    from ._kctsb_core import dp as _dp_core
    from ._kctsb_core import __version__ as _core_version
    _HAS_CORE = True
except ImportError as exc:
    _HAS_CORE = False
    _core_version = "N/A (core not compiled)"
    logger.warning("kctsb C++ core not available: %s", exc)

# Re-export C++ submodules without Python wrapper conflicts
# Usage: from kctsb import bfv, psi, pir, crypto, ...
if _HAS_CORE:
    from . import bfv, bgv, psi, pir, hcc, upsi, voprf, sss, core, mpc
    from . import ecc_blind_sign
    from . import encode

# High-level Python facades (keep these AFTER the core re-exports so they win on name conflicts)
from . import crypto
from . import ac_pir
from . import zk_membership
from .ckks import CKKSContext
from .dp import DPMechanism, DPBudget
from . import dp

__all__ = [
    # High-level Python wrappers
    "CKKSContext",
    "DPMechanism",
    "DPBudget",
    # Python facade modules
    "crypto",
    "ac_pir",
    "zk_membership",
    "dp",
    # C++ submodules (direct re-exports)
    "bfv",
    "bgv",
    "psi",
    "pir",
    "hcc",
    "upsi",
    "voprf",
    "ecc_blind_sign",
    "sss",
    "core",
    "mpc",
    "encode",
    "__version__",
]
