# AI Interview Assistant

Ghost background AI assistant for live coding interviews and challenges. Runs invisibly, transcribes audio in real-time, and streams AI-powered answers to your phone or a native overlay — completely hidden from screen share.

## Features

- **Invisible overlay** — native macOS window hidden from Zoom/Meet/Teams screen share via `NSWindow.setSharingType_(0)`
- **Real-time transcription** — captures system audio (interviewer's voice) via ScreenCaptureKit + Deepgram Nova-3 streaming
- **AI responses** — sends transcript + screenshots to Claude, streams answers in real-time
- **Web viewer** — mobile-friendly page on your local network (phone/tablet on same Wi-Fi)
- **Manual recording** — hold ESC to record your own voice and transcribe via Deepgram
- **Clipboard context** — double-tap Ctrl to copy selected code and include it in the query
- **Hotkey-driven** — everything controlled from the keyboard, no need to touch your phone

## Requirements

- macOS 12.3+ (ScreenCaptureKit)

## Quick Start

### 1. Install

```bash
brew install pipx && pipx ensurepath && pipx install ai-interview-assistant
```

### 2. Run

```bash
ai-interview
```

On first run, you'll be prompted for:

1. **Anthropic API key** — get one at [console.anthropic.com/settings/keys](https://console.anthropic.com/settings/keys)
2. **Deepgram API key** (optional) — get one at [console.deepgram.com](https://console.deepgram.com/) for real-time transcription. Without it, falls back to local Whisper (slower).
3. **Programming language** and **transcription language**
4. **Codebase path** (optional) — point to your project repo for full context

All API keys are saved to `~/.config/ai-interview/config.json` and remembered for next time.

### Full setup wizard (optional)

To reconfigure everything at once:

```bash
ai-interview setup
```

### Check for updates

```bash
ai-interview version
```

## Commands

```bash
ai-interview              # start (same as ai-interview start)
ai-interview start        # start the daemon
ai-interview stop         # stop the daemon
ai-interview status       # show uptime + viewer URL
ai-interview qr           # QR code to open viewer on phone
ai-interview logs         # tail daemon logs
ai-interview send "text"  # send text directly to Claude
ai-interview version      # update to latest + show version
ai-interview setup        # reconfigure API keys, model, etc.
```

## Hotkeys

| Combo | Action |
|-------|--------|
| ESC + ↓ | Capture screenshot |
| ESC + ←/→ | Scroll viewer up/down |
| ESC + [ / ] | Navigate prev/next response |
| ESC + =/- | Font size up/down |
| ESC double-tap + release | Toggle overlay UI |
| ESC double-tap + hold | Manual voice recording |
| Cmd double-tap | Trigger AI query |
| Ctrl double-tap | Copy selection + trigger query |

## macOS Permissions

On first run, macOS will prompt for:

- **Microphone** — for manual voice recording
- **Screen Recording** — for system audio capture (System Settings > Privacy > Screen Recording)
- **Accessibility** — for global hotkeys (System Settings > Privacy > Accessibility)

## How the Overlay Works

The native overlay uses `NSWindow.setSharingType_(0)`, an Apple API that hides the window from all screen capture methods — Zoom, Meet, Teams, OBS, QuickTime, `screencapture` CLI. It is visible only on your physical screen. This is the same mechanism macOS uses to hide password fields and DRM content.

## License

Private — not for public distribution.
