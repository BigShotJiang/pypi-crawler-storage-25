"""Native macOS overlay window — always-on-top, frameless, dark panel.

Launched as a separate process by `ai-interview ui`.
Connects to the daemon WebSocket and renders AI responses.

Usage (internal):  python -m ai_interview.overlay <port>
"""

from __future__ import annotations

import json
import sys

from PySide6.QtCore import (
    QObject,
    QPoint,
    Qt,
    QThread,
    QTimer,
    Signal,
    Slot,
)
from PySide6.QtGui import QColor, QFont, QPalette
from PySide6.QtNetwork import QAbstractSocket, QTcpSocket
from PySide6.QtWebSockets import QWebSocket
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSizeGrip,
    QSizePolicy,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

# ---------------------------------------------------------------------------
# Markdown → HTML renderer (with cached CSS)
# ---------------------------------------------------------------------------

_PYGMENTS_CSS_CACHE: dict[int, str] = {}  # font_size → full <style> block


def _get_css(font_size: int) -> str:
    """Return the full <style> block, cached per font_size."""
    if font_size in _PYGMENTS_CSS_CACHE:
        return _PYGMENTS_CSS_CACHE[font_size]
    try:
        from pygments.formatters import HtmlFormatter
        pygments_css = HtmlFormatter(style="github-dark", noclasses=True).get_style_defs(".codehilite")
    except Exception:
        pygments_css = ""
    code_size = max(8, font_size - 2)
    css = f"""<style>
body {{ color: #e6edf3; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
        font-size: {font_size}px; line-height: 1.65; margin: 0; padding: 0; background: transparent; }}
h1, h2, h3 {{ color: #ffffff; margin: 14px 0 6px; }}
h1 {{ font-size: {font_size + 2}px; }}
h2 {{ font-size: {font_size + 1}px; }}
h3 {{ font-size: {font_size}px; }}
p {{ margin: 6px 0; }}
code {{ background: #1c2128; border: 1px solid #30363d; border-radius: 3px;
        padding: 1px 5px; font-family: Menlo, monospace; font-size: {code_size}px; color: #79c0ff; }}
pre {{ background: #1c2128; border: 1px solid #30363d; border-radius: 6px;
       padding: 12px; margin: 8px 0; overflow-x: auto; }}
pre code {{ background: none; border: none; padding: 0; color: #e6edf3; font-size: {code_size}px; }}
ul, ol {{ padding-left: 18px; margin: 6px 0; }}
li {{ margin: 3px 0; }}
strong {{ color: #ffffff; }}
em {{ color: #d2a8ff; }}
blockquote {{ border-left: 3px solid #30363d; margin: 6px 0; padding-left: 10px; color: #8b949e; }}
table {{ border-collapse: collapse; width: 100%; margin: 8px 0; font-size: {font_size - 1}px; }}
th, td {{ border: 1px solid #30363d; padding: 5px 10px; }}
th {{ background: #1c2128; }}
{pygments_css}
</style>"""
    _PYGMENTS_CSS_CACHE[font_size] = css
    return css


def _md_to_html(text: str, font_size: int = 14) -> str:
    """Convert markdown to styled HTML for QTextBrowser."""
    try:
        import markdown
        extensions = ["fenced_code", "codehilite", "tables", "nl2br"]
        body = markdown.markdown(text, extensions=extensions)
        return _get_css(font_size) + "\n" + body
    except Exception:
        # Ultra-simple fallback if markdown/pygments not available
        escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return f'<pre style="color:#e6edf3;white-space:pre-wrap">{escaped}</pre>'


# ---------------------------------------------------------------------------
# WebSocket worker thread
# ---------------------------------------------------------------------------

class WSWorker(QObject):
    message = Signal(dict)
    connected = Signal()
    disconnected = Signal()

    def __init__(self, port: int) -> None:
        super().__init__()
        self._port = port
        self._ws: QWebSocket | None = None

    def start(self) -> None:
        self._ws = QWebSocket()
        self._ws.connected.connect(self._on_connected)
        self._ws.disconnected.connect(self._on_disconnected)
        self._ws.textMessageReceived.connect(self._on_message)
        self._connect()

    def _connect(self) -> None:
        from PySide6.QtCore import QUrl
        self._ws.open(QUrl(f"ws://127.0.0.1:{self._port}/ws"))

    @Slot()
    def _on_connected(self) -> None:
        self.connected.emit()

    @Slot()
    def _on_disconnected(self) -> None:
        self.disconnected.emit()
        # Reconnect after 2 seconds
        QTimer.singleShot(2000, self._connect)

    @Slot(str)
    def _on_message(self, raw: str) -> None:
        try:
            self.message.emit(json.loads(raw))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Overlay window
# ---------------------------------------------------------------------------

BG_COLOR = "#0d1117"
BG_ALPHA = 230  # 0-255; 230 = ~90% opaque


class OverlayWindow(QWidget):
    def __init__(self, port: int) -> None:
        super().__init__()
        self._port = port
        self._raw_md = ""
        self._current_html = ""
        self._history: list[dict] = []  # [{md, html}]
        self._nav_index = -1  # -1 = current, 0..N = history
        self._max_history = 3
        self._font_size = 14
        self._drag_pos: QPoint | None = None
        self._thinking = False
        self._render_dirty = False
        self._render_timer = QTimer()
        self._render_timer.setSingleShot(True)
        self._render_timer.setInterval(80)  # debounce: render at most ~12 fps
        self._render_timer.timeout.connect(self._flush_render)
        self._setup_window()
        self._build_ui()
        self._start_ws()

    # ---- Window flags ----

    def _setup_window(self) -> None:
        self.setWindowFlags(
            Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground)

        # Landscape mobile shape — wide and short, pinned to bottom
        screen = QApplication.primaryScreen().availableGeometry()
        width = min(screen.width() - 32, 820)
        height = 280
        self.resize(width, height)
        self.move(
            screen.left() + (screen.width() - width) // 2,
            screen.bottom() - height - 16,
        )

    def showEvent(self, event) -> None:
        """Hide window from screen capture/screen share after it becomes visible."""
        super().showEvent(event)
        try:
            from AppKit import NSApp
            # NSWindowSharingNone = 0 — invisible to Zoom, Meet, OBS, etc.
            for window in NSApp.windows():
                window.setSharingType_(0)
        except Exception:
            pass

    # ---- UI layout ----

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Card container (rounded, semi-opaque)
        card = QWidget()
        card.setObjectName("card")
        card.setStyleSheet(f"""
            QWidget#card {{
                background: rgba(13,17,23,{BG_ALPHA});
                border: 1px solid #30363d;
                border-radius: 12px;
            }}
        """)
        outer.addWidget(card)

        layout = QVBoxLayout(card)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Title bar
        title_bar = QWidget()
        title_bar.setFixedHeight(32)
        title_bar.setStyleSheet("background: transparent;")
        tb_layout = QHBoxLayout(title_bar)
        tb_layout.setContentsMargins(12, 0, 8, 0)

        self._status_dot = QLabel("●")
        self._status_dot.setStyleSheet("color: #555; font-size: 10px;")
        tb_layout.addWidget(self._status_dot)

        self._title_label = QLabel("AI Interview Assistant")
        self._title_label.setStyleSheet("color: #8b949e; font-size: 11px;")
        tb_layout.addWidget(self._title_label)
        tb_layout.addStretch()

        # Info pills — right side of title bar
        _pill_css = (
            "QLabel { background: rgba(30,37,46,0.9); border: 1px solid #30363d; "
            "border-radius: 8px; padding: 1px 7px; font-size: 10px; font-family: Menlo, monospace; }"
        )
        self._pill_rec = QLabel("● REC")
        self._pill_rec.setStyleSheet(_pill_css + "QLabel { color: #f85149; border-color: rgba(248,81,73,0.4); }")
        self._pill_rec.hide()
        tb_layout.addWidget(self._pill_rec)

        self._pill_shots = QLabel("📷 0")
        self._pill_shots.setStyleSheet(_pill_css + "QLabel { color: #8b949e; }")
        self._pill_shots.hide()
        tb_layout.addWidget(self._pill_shots)

        self._pill_transcriber = QLabel("—")
        self._pill_transcriber.setStyleSheet(_pill_css + "QLabel { color: #8b949e; }")
        tb_layout.addWidget(self._pill_transcriber)

        self._pill_model = QLabel("—")
        self._pill_model.setStyleSheet(_pill_css + "QLabel { color: #8b949e; }")
        tb_layout.addWidget(self._pill_model)

        self._pill_cpu = QLabel("CPU —")
        self._pill_cpu.setStyleSheet(_pill_css + "QLabel { color: #8b949e; }")
        tb_layout.addWidget(self._pill_cpu)

        tb_layout.addSpacing(4)

        restart_btn = QPushButton("⟳")
        restart_btn.setFixedSize(20, 20)
        restart_btn.setCursor(Qt.PointingHandCursor)
        restart_btn.setToolTip("Restart daemon")
        restart_btn.setStyleSheet("""
            QPushButton { background: transparent; color: #555; border: none; font-size: 13px; }
            QPushButton:hover { color: #d29922; }
        """)
        restart_btn.clicked.connect(self._do_restart)
        tb_layout.addWidget(restart_btn)

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(20, 20)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton { background: transparent; color: #555; border: none; font-size: 12px; }
            QPushButton:hover { color: #f85149; }
        """)
        close_btn.clicked.connect(self.close)
        tb_layout.addWidget(close_btn)

        layout.addWidget(title_bar)

        # Divider
        divider = QWidget()
        divider.setFixedHeight(1)
        divider.setStyleSheet("background: #21262d;")
        layout.addWidget(divider)

        # Thinking label
        self._thinking_label = QLabel("  Thinking…")
        self._thinking_label.setStyleSheet("color: #8b949e; font-size: 12px; padding: 8px 12px;")
        self._thinking_label.hide()
        layout.addWidget(self._thinking_label)

        # Scroll area + text browser
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical { width: 5px; background: transparent; }
            QScrollBar::handle:vertical { background: #30363d; border-radius: 2px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        """)

        self._browser = QTextBrowser()
        self._browser.setOpenExternalLinks(True)
        self._browser.setStyleSheet("background: transparent; border: none; color: #e6edf3;")
        self._browser.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        # Set base font on the widget so font_size changes are visible
        font = QFont("Helvetica Neue", self._font_size)
        self._browser.setFont(font)
        scroll.setWidget(self._browser)
        layout.addWidget(scroll)

        self._scroll = scroll

        # Live transcript label
        self._transcript_label = QLabel()
        self._transcript_label.setWordWrap(True)
        self._transcript_label.setStyleSheet(
            "color: #8b949e; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
        )
        self._transcript_label.hide()
        layout.addWidget(self._transcript_label)

        # Ask AI text input
        ask_row = QWidget()
        ask_row.setStyleSheet("background: transparent;")
        ask_layout = QHBoxLayout(ask_row)
        ask_layout.setContentsMargins(12, 2, 12, 2)
        ask_layout.setSpacing(6)

        self._ask_input = QLineEdit()
        self._ask_input.setPlaceholderText("Ask AI...")
        self._ask_input.setStyleSheet(
            "QLineEdit { background: #1c2128; border: 1px solid #30363d; border-radius: 4px; "
            "color: #e6edf3; font-size: 11px; padding: 4px 8px; }"
            "QLineEdit:focus { border-color: #4ec9b0; }"
        )
        self._ask_input.returnPressed.connect(self._send_ask)
        ask_layout.addWidget(self._ask_input)

        ask_btn = QPushButton("Send")
        ask_btn.setFixedHeight(24)
        ask_btn.setCursor(Qt.PointingHandCursor)
        ask_btn.setStyleSheet(
            "QPushButton { background: #4ec9b0; color: #0d1117; border: none; "
            "border-radius: 4px; font-size: 10px; padding: 2px 10px; font-weight: bold; }"
            "QPushButton:hover { background: #3fb950; }"
        )
        ask_btn.clicked.connect(self._send_ask)
        ask_layout.addWidget(ask_btn)

        layout.addWidget(ask_row)

        # Resize grip
        grip_row = QWidget()
        grip_row.setStyleSheet("background: transparent;")
        grip_layout = QHBoxLayout(grip_row)
        grip_layout.setContentsMargins(0, 0, 4, 4)
        grip_layout.addStretch()
        grip = QSizeGrip(self)
        grip.setStyleSheet("background: transparent;")
        grip_layout.addWidget(grip)
        layout.addWidget(grip_row)

    # ---- Debounced render ----

    @Slot()
    def _flush_render(self) -> None:
        """Render accumulated markdown. Called immediately for first chunk, debounced after."""
        if not self._raw_md:
            return
        sb = self._scroll.verticalScrollBar()
        was_at_bottom = sb.maximum() == 0 or (sb.maximum() - sb.value()) < 60
        old_pos = sb.value()
        self._browser.setHtml(_md_to_html(self._raw_md, self._font_size))
        if was_at_bottom:
            QTimer.singleShot(0, lambda: self._scroll.verticalScrollBar().setValue(
                self._scroll.verticalScrollBar().maximum()
            ))
        else:
            QTimer.singleShot(0, lambda p=old_pos: self._scroll.verticalScrollBar().setValue(p))

    # ---- Ask AI ----

    def _send_ask(self) -> None:
        text = self._ask_input.text().strip()
        if not text:
            return
        self._ask_input.clear()

        import json
        import urllib.request
        try:
            body = json.dumps({"text": text, "trigger": True}).encode()
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}/inject",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=3)
        except Exception:
            pass

    # ---- WebSocket ----

    def _start_ws(self) -> None:
        self._ws_thread = QThread()
        self._ws_worker = WSWorker(self._port)
        self._ws_worker.moveToThread(self._ws_thread)
        self._ws_thread.started.connect(self._ws_worker.start)
        self._ws_worker.message.connect(self._on_message)
        self._ws_worker.connected.connect(self._on_connected)
        self._ws_worker.disconnected.connect(self._on_disconnected)
        self._ws_thread.start()

    # ---- Message handling ----

    @Slot(dict)
    def _on_message(self, msg: dict) -> None:
        t = msg.get("type")

        if t == "status":
            val = msg.get("value", "idle")
            if val == "processing":
                self._status_dot.setStyleSheet("color: #f85149; font-size: 10px;")
            elif val == "listening":
                self._status_dot.setStyleSheet("color: #3fb950; font-size: 10px;")
            else:
                self._status_dot.setStyleSheet("color: #555; font-size: 10px;")

        elif t == "speech_started":
            # Voice detected before words — show bar immediately
            self._transcript_label.show()

        elif t == "transcript":
            text = msg.get("text", "")
            if msg.get("interim"):
                # Interim: gray text, replacing in-place
                display = "🎙 " + text[-110:] if len(text) > 110 else "🎙 " + text
                self._transcript_label.setStyleSheet(
                    "color: #8b949e; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                )
            else:
                # Final: flash green to confirm sentence committed
                current = self._transcript_label.text().lstrip("🎙 ")
                combined = (current + " " + text).strip()
                if len(combined) > 110:
                    combined = "…" + combined[-107:]
                display = "🎙 " + combined
                self._transcript_label.setStyleSheet(
                    "color: #3fb950; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                )
                # Fade back to gray after 800ms
                QTimer.singleShot(800, lambda: self._transcript_label.setStyleSheet(
                    "color: #8b949e; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                ))
            self._transcript_label.setText(display)
            self._transcript_label.show()

        elif t == "start":
            self._render_timer.stop()
            self._render_dirty = False
            if self._raw_md:
                self._history.insert(0, {"md": self._raw_md, "html": self._current_html})
                if len(self._history) > self._max_history:
                    self._history.pop()
            self._raw_md = ""
            self._current_html = ""
            self._nav_index = -1
            self._browser.setHtml("")
            self._transcript_label.hide()
            self._transcript_label.setText("")
            self._thinking_label.show()

        elif t == "chunk":
            self._thinking_label.hide()
            self._raw_md += msg.get("text", "")
            self._current_html = self._raw_md
            if not self._render_dirty:
                # First chunk — render immediately for instant feedback
                self._render_dirty = True
                self._flush_render()
            elif not self._render_timer.isActive():
                # Subsequent chunks — debounce to avoid hammering the renderer
                self._render_timer.start()

        elif t == "done":
            self._render_timer.stop()
            self._render_dirty = False
            self._thinking_label.hide()
            full = msg.get("full_text", "")
            if full and not self._raw_md:
                self._raw_md = full
                self._current_html = self._raw_md
            # Final render with complete text
            if self._raw_md:
                self._flush_render()

        elif t == "error":
            self._thinking_label.hide()
            err_html = f'<p style="color:#f85149">⚠ {msg.get("message","Unknown error")}</p>'
            self._browser.setHtml(err_html)

        elif t == "scroll":
            sb = self._browser.verticalScrollBar()
            delta = 150 if msg.get("direction") == "down" else -150
            sb.setValue(sb.value() + delta)

        elif t == "nav":
            total = 1 + len(self._history)
            if total < 2:
                return
            if msg.get("direction") == "prev":
                self._nav_index = min(self._nav_index + 1, len(self._history) - 1)
            else:
                self._nav_index = max(self._nav_index - 1, -1)
            md = self._raw_md if self._nav_index == -1 else self._history[self._nav_index].get("md", "")
            self._browser.setHtml(_md_to_html(md, self._font_size))
            label = "current" if self._nav_index == -1 else f"{self._nav_index + 1} of {len(self._history)} ago"
            self._thinking_label.setText(f"  {label}")
            self._thinking_label.show()
            QTimer.singleShot(1500, lambda: self._thinking_label.hide() if not self._thinking else None)

        elif t == "mode_changed":
            mode = msg.get("mode", "auto")
            if mode == "code":
                self._title_label.setText("AI Interview Assistant  ·  ⌨ Code Mode")
                self._title_label.setStyleSheet("color: #f0883e; font-size: 11px;")
            else:
                self._title_label.setText("AI Interview Assistant  ·  connected")
                self._title_label.setStyleSheet("color: #3fb950; font-size: 11px;")
            label = "Code Mode ON" if mode == "code" else "Auto Mode"
            self._thinking_label.setText(f"  {label}")
            self._thinking_label.show()
            QTimer.singleShot(1500, lambda: self._thinking_label.hide())

        elif t == "cpu":
            pct = msg.get("process")
            rss = msg.get("proc_rss_mb")
            if pct is not None:
                mem_str = f"  {rss} MB" if rss is not None else ""
                self._pill_cpu.setText(f"CPU {pct}%{mem_str}")
                color = "#f85149" if pct >= 60 else "#d29922" if pct >= 30 else "#3fb950"
                self._pill_cpu.setStyleSheet(
                    "QLabel { background: rgba(30,37,46,0.9); border: 1px solid #30363d; "
                    f"border-radius: 8px; padding: 1px 7px; font-size: 10px; "
                    f"font-family: Menlo, monospace; color: {color}; }}"
                )

        elif t == "info":
            # Recording pill
            recording = msg.get("recording", False)
            self._pill_rec.setVisible(recording)

            # Screenshots pill
            n = msg.get("screenshots", 0)
            self._pill_shots.setText(f"📷 {n}")
            self._pill_shots.setVisible(n > 0)

            # Transcriber pill
            t_name = msg.get("transcriber", "") or "—"
            if t_name.startswith("Deepgram"):
                dot, color = "● ", "#3fb950"
            elif t_name.startswith("Whisper"):
                dot, color = "● ", "#d29922"
            else:
                dot, color = "", "#555"
            short_t = "DG" if t_name.startswith("Deepgram") else t_name.replace(" (local)", "")
            self._pill_transcriber.setText(dot + short_t)
            self._pill_transcriber.setStyleSheet(
                "QLabel { background: rgba(30,37,46,0.9); border: 1px solid #30363d; "
                f"border-radius: 8px; padding: 1px 7px; font-size: 10px; "
                f"font-family: Menlo, monospace; color: {color}; }}"
            )

            # Model pill
            model = msg.get("model", "") or "—"
            short_m = model.replace("claude-", "").replace("-latest", "")
            self._pill_model.setText(short_m)

        elif t == "overlay_toggle":
            if msg.get("visible"):
                self.show()
            else:
                self.hide()

        elif t == "font_size":
            self._font_size += 1 if msg.get("direction") == "up" else -1
            self._font_size = max(8, min(32, self._font_size))
            font = self._browser.font()
            font.setPointSize(self._font_size)
            self._browser.setFont(font)
            md = self._raw_md if self._nav_index == -1 else self._history[self._nav_index].get("md", "")
            if md:
                self._browser.setHtml(_md_to_html(md, self._font_size))

    @Slot()
    def _on_connected(self) -> None:
        self._title_label.setText("AI Interview Assistant  ·  connected")
        self._title_label.setStyleSheet("color: #3fb950; font-size: 11px;")

    @Slot()
    def _on_disconnected(self) -> None:
        self._title_label.setText("AI Interview Assistant  ·  reconnecting…")
        self._title_label.setStyleSheet("color: #d29922; font-size: 11px;")

    @Slot()
    def _do_restart(self) -> None:
        self._title_label.setText("AI Interview Assistant  ·  restarting…")
        self._title_label.setStyleSheet("color: #d29922; font-size: 11px;")
        from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
        from PySide6.QtCore import QUrl
        self._nam = QNetworkAccessManager()
        req = QNetworkRequest(QUrl(f"http://127.0.0.1:{self._port}/restart"))
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        self._nam.post(req, b"")

    # ---- Drag to move ----

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        if self._drag_pos and event.buttons() & Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, event):
        self._drag_pos = None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    import os
    # Detach from terminal so Ctrl+C in the shell doesn't kill the overlay
    try:
        os.setsid()
    except OSError:
        pass  # already session leader

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 7890

    app = QApplication(sys.argv)
    app.setApplicationName("AI Interview Assistant")

    # Hide from Dock on macOS
    try:
        from AppKit import NSApplication, NSApplicationActivationPolicyAccessory
        NSApplication.sharedApplication().setActivationPolicy_(
            NSApplicationActivationPolicyAccessory
        )
    except Exception:
        pass

    window = OverlayWindow(port)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
