"""Global hotkey listener using pynput.

Runs in a background daemon thread. Detects ESC+arrow combos and
bridges to the asyncio event loop via asyncio.run_coroutine_threadsafe().

Hotkey map:
  ESC + ↓  → capture screenshot
  ESC + →  → scroll viewer down
  ESC + ←  → scroll viewer up
  ESC + [ / ]          → navigate prev/next response
  ESC double-tap+release → toggle overlay UI
  ESC double-tap+hold   → manual voice recording
  Cmd double-tap       → trigger query
  Ctrl double-tap      → copy selection + trigger query
  Cmd + ↑/↓            → font size up/down
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import Optional, TYPE_CHECKING

from pynput import keyboard


# ---------------------------------------------------------------------------
# Audio feedback
# ---------------------------------------------------------------------------

def _beep(freq: float, duration: float = 0.07, volume: float = 0.4) -> None:
    """Play a short sine-wave tone via NSSound (no fork — safe alongside CoreAudio/SCKit)."""
    def _play():
        try:
            import math
            import struct
            import wave
            import io

            sr = 44100
            n = int(sr * duration)
            fade_samples = int(sr * 0.01)

            frames = bytearray()
            for i in range(n):
                s = math.sin(2 * math.pi * freq * i / sr) * volume
                if i >= n - fade_samples:
                    s *= (n - i) / fade_samples
                frames += struct.pack('<h', max(-32767, min(32767, int(s * 32767))))

            buf = io.BytesIO()
            with wave.open(buf, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sr)
                wf.writeframes(bytes(frames))

            from AppKit import NSSound
            from Foundation import NSData
            data = NSData.dataWithBytes_length_(buf.getvalue(), len(buf.getvalue()))
            sound = NSSound.alloc().initWithData_(data)
            if sound:
                sound.setVolume_(min(1.0, volume * 2))
                sound.play()
                time.sleep(duration + 0.05)
        except Exception:
            pass
    threading.Thread(target=_play, daemon=True).start()


def beep_screenshot():   _beep(900, 0.06)           # short high click
def beep_send():         _beep(660, 0.08)           # mid tone — "sending"
def beep_rec_start():    _beep(500, 0.12)           # low — recording on
def beep_rec_stop():     _beep(400, 0.10)           # lower — recording off

if TYPE_CHECKING:
    from ai_interview.config import Config

logger = logging.getLogger(__name__)

_ESC_DOUBLE_TAP_THRESHOLD = 0.5   # seconds between two ESC presses
_ESC_HOLD_THRESHOLD = 0.2         # seconds ESC must be held for "double-tap+hold"

_DOUBLE_TAP_THRESHOLD = 0.4  # seconds between two taps for Cmd/Option

_current_keys: set = set()
_last_esc_time: float = 0.0
_esc_press_time: float = 0.0
_esc_was_released: bool = True   # must be released between tap and hold
_esc_double_tapped: bool = False  # True between double-tap press and release
_is_recording_manual: bool = False
_manual_recording_thread: Optional[threading.Thread] = None
_manual_audio_chunks: list = []
_lock = threading.Lock()

# Double-tap tracking for Cmd and Option
_last_cmd_release: float = 0.0
_last_ctrl_release: float = 0.0
_cmd_was_solo: bool = True   # True if no other key pressed while Cmd held
_ctrl_was_solo: bool = True   # True if no other key pressed while Option held


def _schedule(coro):
    """Schedule a coroutine on the daemon's asyncio event loop."""
    import time
    from ai_interview.state import state
    state.last_activity_at = time.time()
    loop = state.asyncio_loop
    if loop is not None:
        asyncio.run_coroutine_threadsafe(coro, loop)


def _do_toggle_mode():
    """Toggle between Auto and Code response mode. Clears conversation history on switch."""
    from ai_interview.state import state
    from ai_interview.metrics import metrics
    state.response_mode = "code" if state.response_mode == "auto" else "auto"
    # Clear history so the model doesn't carry over the style from the previous mode
    state.conversation_history.clear()
    metrics.record("hotkey", action="toggle_mode")
    logger.info("Response mode: %s (history cleared)", state.response_mode)

    async def _broadcast():
        from ai_interview.server.websocket import broadcast
        await broadcast({"type": "mode_changed", "mode": state.response_mode})
    _schedule(_broadcast())


async def _broadcast_info():
    from ai_interview.server.websocket import broadcast_info
    await broadcast_info()


def _do_capture_screenshot():
    """Capture screenshot and add to buffer."""
    from ai_interview.screenshot import capture_active_window
    from ai_interview.state import state
    from ai_interview.metrics import metrics
    metrics.record("hotkey", action="screenshot")

    path = capture_active_window()
    if path and state.screenshot_buffer is not None:
        state.screenshot_buffer.append(path)
        logger.info("Screenshot buffered: %s", path.name)
        _schedule(_broadcast_info())
    elif path is None:
        logger.warning("Screenshot capture returned None")


def _do_trigger_query(config: "Config", action: str = "2x_cmd_query"):
    """Trigger AI query — scheduled on the asyncio loop."""
    from ai_interview.metrics import metrics
    metrics.record("hotkey", action=action)

    async def _query():
        from ai_interview.ai_client import handle_query
        from ai_interview.state import state
        await handle_query(state, config)

    _schedule(_query())


def _do_nav(direction: str):
    """Navigate prev/next through response history on the viewer."""
    from ai_interview.metrics import metrics
    metrics.record("hotkey", action=f"nav_{direction}")

    async def _nav():
        from ai_interview.server.websocket import broadcast
        await broadcast({"type": "nav", "direction": direction})
    _schedule(_nav())


def _do_scroll(direction: str):
    """Send scroll command to viewer — scheduled on asyncio loop."""
    from ai_interview.metrics import metrics
    metrics.record("hotkey", action=f"scroll_{direction}")

    async def _scroll():
        from ai_interview.server.websocket import broadcast
        await broadcast({"type": "scroll", "direction": direction, "amount": 150})

    _schedule(_scroll())


def _do_font_size(direction: str):
    """Change viewer font size up/down by 1px."""
    from ai_interview.metrics import metrics
    metrics.record("hotkey", action=f"font_{direction}")

    async def _fs():
        from ai_interview.server.websocket import broadcast
        await broadcast({"type": "font_size", "direction": direction})
    _schedule(_fs())


_overlay_proc: Optional["subprocess.Popen"] = None


_overlay_visible: bool = True  # starts visible when launched


def _kill_stale_overlays():
    """Kill any leftover overlay processes from previous daemon sessions."""
    import subprocess
    try:
        result = subprocess.run(
            ["pgrep", "-f", "ai_interview.overlay"],
            capture_output=True, text=True, timeout=2,
        )
        for pid_str in result.stdout.strip().split("\n"):
            pid_str = pid_str.strip()
            if pid_str and pid_str.isdigit():
                import os, signal
                try:
                    os.kill(int(pid_str), signal.SIGTERM)
                    logger.info("Killed stale overlay process %s", pid_str)
                except ProcessLookupError:
                    pass
    except Exception:
        pass


def _do_toggle_overlay(config: "Config"):
    """Toggle the native overlay window: launch if not running, show/hide if running."""
    import subprocess
    import sys
    from pathlib import Path
    from ai_interview.metrics import metrics
    metrics.record("hotkey", action="toggle_overlay")
    global _overlay_proc, _overlay_visible

    # If running, toggle visibility via WS message
    if _overlay_proc is not None and _overlay_proc.poll() is None:
        _overlay_visible = not _overlay_visible
        async def _toggle():
            from ai_interview.server.websocket import broadcast
            await broadcast({"type": "overlay_toggle", "visible": _overlay_visible})
        _schedule(_toggle())
        logger.info("Overlay %s", "shown" if _overlay_visible else "hidden")
        return

    # Kill any stale overlays from previous sessions before launching
    _kill_stale_overlays()

    # Not running — launch it
    _overlay_visible = True
    port = config.port
    ui_log = Path.home() / ".ai-interview-ui.log"
    with open(ui_log, "a") as log_fh:
        _overlay_proc = subprocess.Popen(
            [sys.executable, "-m", "ai_interview.overlay", str(port)],
            stdout=log_fh,
            stderr=log_fh,
            stdin=subprocess.DEVNULL,
        )
    logger.info("Overlay launched on port %d", port)


def _start_manual_recording(config: "Config"):
    """Start recording microphone manually (bypasses rolling transcriber)."""
    global _manual_audio_chunks, _is_recording_manual
    from ai_interview.metrics import metrics
    metrics.record("hotkey", action="manual_rec_start")

    import sounddevice as sd
    import numpy as np

    _manual_audio_chunks = []
    _is_recording_manual = True
    state.is_recording = True
    logger.info("Manual recording started")
    _schedule(_broadcast_info())

    def _callback(indata, frames, time_info, status):
        if _is_recording_manual:
            _manual_audio_chunks.append(indata[:, 0].copy())

    try:
        stream = sd.InputStream(
            channels=1,
            samplerate=16000,
            dtype=np.float32,
            callback=_callback,
        )
        stream.start()

        while _is_recording_manual:
            time.sleep(0.05)

        stream.stop()
        stream.close()
        _flush_manual_recording(config)
    except Exception as exc:
        logger.error("Manual recording error: %s", exc)
        _is_recording_manual = False


def _flush_manual_recording(config: "Config"):
    """Transcribe manual recording via Deepgram REST, append to buffer, auto-trigger query."""
    import io
    import wave
    import numpy as np
    from ai_interview.state import state

    if not _manual_audio_chunks:
        return

    audio = np.concatenate(_manual_audio_chunks)
    if len(audio) < 8000:  # less than 0.5 seconds — ignore noise
        return

    logger.info("Transcribing manual recording (%d samples)…", len(audio))

    # Show "Transcribing…" in the viewer immediately
    async def _show_transcribing():
        from ai_interview.server.websocket import broadcast
        from ai_interview.state import state
        await broadcast({"type": "status", "value": "processing"})
        await broadcast({"type": "start"})
        await broadcast({"type": "chunk", "text": "_Transcribing your question…_"})
    _schedule(_show_transcribing())

    def _transcribe():
        try:
            from ai_interview.metrics import metrics
            # Encode float32 → 16-bit PCM WAV in memory
            audio_int16 = (audio * 32767).astype(np.int16)
            buf = io.BytesIO()
            with wave.open(buf, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(16000)
                wf.writeframes(audio_int16.tobytes())
            wav_bytes = buf.getvalue()

            # Transcribe with Deepgram REST (pre-recorded)
            import httpx
            lang = config.transcription_language or "en"
            _t0 = time.time()
            resp = httpx.post(
                f"https://api.deepgram.com/v1/listen?model=nova-2&smart_format=true&language={lang}",
                headers={
                    "Authorization": f"Token {config.deepgram_api_key}",
                    "Content-Type": "audio/wav",
                },
                content=wav_bytes,
                timeout=15,
            )
            resp.raise_for_status()
            rest_ms = int((time.time() - _t0) * 1000)
            text = (
                resp.json()
                .get("results", {})
                .get("channels", [{}])[0]
                .get("alternatives", [{}])[0]
                .get("transcript", "")
                .strip()
            )

            if text:
                logger.info("Manual transcript: %s", text[:120])
                metrics.record("manual_recording", val=rest_ms, ok=True,
                               chars=len(text), samples=len(audio))
                if state.transcript_buffer is not None:
                    state.transcript_buffer.append(f"[user] {text}")
                # Reset status then auto-trigger query
                async def _reset():
                    from ai_interview.server.websocket import broadcast
                    from ai_interview.state import state as st
                    st.status = "idle"
                    await broadcast({"type": "start"})  # clear placeholder
                _schedule(_reset())
                _do_trigger_query(config, action="manual_rec_query")
            else:
                logger.warning("Manual recording: no speech detected")
                metrics.record("manual_recording", val=rest_ms, ok=False,
                               chars=0, samples=len(audio))

        except Exception as exc:
            logger.error("Manual transcription error: %s", exc)
            from ai_interview.metrics import metrics
            metrics.record("manual_recording", val=0, ok=False, error=str(exc)[:60])

    threading.Thread(target=_transcribe, daemon=True).start()


def start_hotkey_listener(config: "Config") -> None:
    """Start the pynput keyboard listener in a daemon thread.

    Hotkey bindings are loaded from config.json — configurable via the GUI Settings.
    """
    from ai_interview.hotkey_config import load_hotkeys, key_name_to_pynput, pynput_to_key_name
    from ai_interview.config import load_saved_config

    global _last_esc_time, _esc_press_time, _esc_was_released, _esc_double_tapped, _is_recording_manual, _manual_recording_thread

    # Load configured hotkeys
    hk = load_hotkeys(load_saved_config())

    # Build lookup maps from config
    # combined_map: {(frozenset of modifier pynput keys, trigger pynput key): (action, beep)}
    combined_map = {}
    for action, binding in hk.items():
        if binding["type"] == "combined":
            mod_name = binding["modifier"]
            key_name = binding["key"]
            mod_pynput = key_name_to_pynput(mod_name)
            key_pynput = key_name_to_pynput(key_name)
            if mod_pynput and key_pynput:
                # For cmd/ctrl/alt, also match _l and _r variants
                mod_set = _expand_modifier(mod_pynput)
                combined_map[(frozenset(mod_set), key_pynput)] = (action, binding.get("beep", False))

    # Double-tap trackers: group by key
    class _Tracker:
        def __init__(self):
            self.last_tap = 0.0
            self.press_time = 0.0
            self.was_released = True
            self.double_tapped = False
            self.was_solo = True
            self.tap_action = None      # double_tap action
            self.tap_beep = False
            self.hold_action = None     # press_hold_release action
            self.hold_beep = False

    trackers = {}  # key_name -> _Tracker
    for action, binding in hk.items():
        if binding["type"] in ("double_tap", "press_hold_release"):
            key_name = binding["key"]
            if key_name not in trackers:
                trackers[key_name] = _Tracker()
            t = trackers[key_name]
            if binding["type"] == "double_tap":
                t.tap_action = action
                t.tap_beep = binding.get("beep", False)
            else:
                t.hold_action = action
                t.hold_beep = binding.get("beep", False)

    # Action dispatch
    def _dispatch(action, beep):
        if beep:
            _beep(660, 0.08)
        handlers = {
            "capture_screenshot": lambda: threading.Thread(target=_do_capture_screenshot, daemon=True).start(),
            "scroll_down": lambda: _do_scroll("down"),
            "scroll_up": lambda: _do_scroll("up"),
            "nav_prev": lambda: _do_nav("prev"),
            "nav_next": lambda: _do_nav("next"),
            "toggle_code_mode": lambda: _do_toggle_mode(),
            "font_size_up": lambda: _do_font_size("up"),
            "font_size_down": lambda: _do_font_size("down"),
            "toggle_overlay": lambda: threading.Thread(target=lambda: _do_toggle_overlay(config), daemon=True).start(),
            "trigger_query": lambda: threading.Thread(target=lambda: _do_trigger_query(config), daemon=True).start(),
            "copy_and_query": lambda: threading.Thread(target=_do_copy_and_query, daemon=True).start(),
        }
        handler = handlers.get(action)
        if handler:
            logger.info("Hotkey: %s", action)
            handler()

    def _do_copy_and_query():
        from pynput.keyboard import Controller, Key
        from ai_interview.state import state
        kb = Controller()
        kb.press(Key.cmd); kb.press('c'); kb.release('c'); kb.release(Key.cmd)
        time.sleep(0.1)
        state.include_clipboard = True
        _do_trigger_query(config, action="2x_ctrl_query")

    # Resolve tracker pynput keys
    tracker_keys = {}  # pynput_key -> (key_name, _Tracker)
    for key_name, tracker in trackers.items():
        pk = key_name_to_pynput(key_name)
        if pk:
            tracker_keys[pk] = (key_name, tracker)
            # Also match _l/_r variants for modifier keys
            for variant in _expand_modifier(pk):
                tracker_keys[variant] = (key_name, tracker)

    def on_press(key):
        global _last_esc_time, _esc_press_time, _esc_was_released, _esc_double_tapped
        global _is_recording_manual, _manual_recording_thread

        _current_keys.add(key)

        # Mark modifiers as non-solo if another key is pressed
        for pk, (kn, trk) in tracker_keys.items():
            if key != pk and pk in _current_keys:
                trk.was_solo = False

        # Check double-tap / hold trackers
        if key in tracker_keys:
            kn, trk = tracker_keys[key]
            now = time.time()
            if trk.was_released:
                trk.press_time = now
            gap = now - trk.last_tap

            if gap < _ESC_DOUBLE_TAP_THRESHOLD and trk.was_released:
                trk.double_tapped = True
                # Check if held for press_hold_release action
                if trk.hold_action:
                    pynput_key = key
                    def _check_hold(t=trk, pk=pynput_key):
                        global _is_recording_manual, _manual_recording_thread
                        time.sleep(_ESC_HOLD_THRESHOLD)
                        if pk in _current_keys and t.hold_action == "manual_recording":
                            if not _is_recording_manual:
                                _is_recording_manual = True
                                if t.hold_beep:
                                    beep_rec_start()
                                from ai_interview.state import state
                                state.is_recording = True
                                _schedule(_broadcast_info())
                                _manual_recording_thread = threading.Thread(
                                    target=_start_manual_recording, args=(config,), daemon=True
                                )
                                _manual_recording_thread.start()
                    threading.Thread(target=_check_hold, daemon=True).start()

            trk.was_released = False
            trk.last_tap = now
            return

        # Check combined hotkeys
        for (mod_set, trigger_key), (action, beep) in combined_map.items():
            if key == trigger_key and any(mk in _current_keys for mk in mod_set):
                _dispatch(action, beep)
                return

    def on_release(key):
        global _is_recording_manual, _esc_press_time, _esc_was_released, _esc_double_tapped

        _current_keys.discard(key)

        if key in tracker_keys:
            kn, trk = tracker_keys[key]
            trk.was_released = True
            held_duration = time.time() - trk.press_time

            # Recording stop (press_hold_release)
            if _is_recording_manual and trk.hold_action == "manual_recording" and held_duration >= _ESC_HOLD_THRESHOLD:
                _is_recording_manual = False
                from ai_interview.state import state
                state.is_recording = False
                if trk.hold_beep:
                    beep_rec_stop()
                logger.info("Manual recording stopped")
                _schedule(_broadcast_info())

            # Double-tap + quick release (tap action)
            elif trk.double_tapped and held_duration < _ESC_HOLD_THRESHOLD and trk.tap_action:
                _dispatch(trk.tap_action, trk.tap_beep)

            # Solo modifier double-tap (cmd, ctrl, etc.)
            elif trk.tap_action and trk.tap_action in ("trigger_query", "copy_and_query"):
                now = time.time()
                if trk.was_solo and (now - getattr(trk, '_last_release', 0.0)) < _DOUBLE_TAP_THRESHOLD:
                    _dispatch(trk.tap_action, trk.tap_beep)
                    trk._last_release = 0.0
                else:
                    trk._last_release = now

            trk.double_tapped = False
            trk.was_solo = True

    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    t = threading.Thread(target=listener.run, daemon=True)
    t.start()
    logger.info("Hotkey listener started")


def _expand_modifier(pk) -> set:
    """Return a set of pynput keys that should match a modifier (e.g. cmd → {cmd, cmd_l, cmd_r})."""
    expansions = {
        keyboard.Key.cmd: {keyboard.Key.cmd, keyboard.Key.cmd_l, keyboard.Key.cmd_r},
        keyboard.Key.cmd_l: {keyboard.Key.cmd, keyboard.Key.cmd_l, keyboard.Key.cmd_r},
        keyboard.Key.cmd_r: {keyboard.Key.cmd, keyboard.Key.cmd_l, keyboard.Key.cmd_r},
        keyboard.Key.ctrl: {keyboard.Key.ctrl, keyboard.Key.ctrl_l, keyboard.Key.ctrl_r},
        keyboard.Key.ctrl_l: {keyboard.Key.ctrl, keyboard.Key.ctrl_l, keyboard.Key.ctrl_r},
        keyboard.Key.ctrl_r: {keyboard.Key.ctrl, keyboard.Key.ctrl_l, keyboard.Key.ctrl_r},
        keyboard.Key.alt: {keyboard.Key.alt, keyboard.Key.alt_l, keyboard.Key.alt_r},
        keyboard.Key.alt_l: {keyboard.Key.alt, keyboard.Key.alt_l, keyboard.Key.alt_r},
        keyboard.Key.alt_r: {keyboard.Key.alt, keyboard.Key.alt_l, keyboard.Key.alt_r},
        keyboard.Key.shift: {keyboard.Key.shift, keyboard.Key.shift_l, keyboard.Key.shift_r},
        keyboard.Key.shift_l: {keyboard.Key.shift, keyboard.Key.shift_l, keyboard.Key.shift_r},
        keyboard.Key.shift_r: {keyboard.Key.shift, keyboard.Key.shift_l, keyboard.Key.shift_r},
    }
    return expansions.get(pk, {pk})
