"""aiohttp application factory."""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiohttp import web

from ai_interview.server.routes import setup_routes

if TYPE_CHECKING:
    from ai_interview.config import Config


def create_app(config: "Config") -> web.Application:
    """Create and configure the aiohttp web application."""
    app = web.Application()
    app["config"] = config
    setup_routes(app)
    return app
