# IMPORTANT: Do NOT import audio modules at the top level of this package.
# Audio modules (sounddevice, ScreenCaptureKit) must only be imported AFTER
# daemonize() to prevent CoreAudio IPC crashes during process forking.
