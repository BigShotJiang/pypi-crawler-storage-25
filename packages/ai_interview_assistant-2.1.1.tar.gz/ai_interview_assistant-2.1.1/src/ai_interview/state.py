"""Shared mutable state for the daemon process."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Literal, Optional, Set

if TYPE_CHECKING:
    import aiohttp
    from ai_interview.buffer import RollingTranscriptBuffer, ScreenshotBuffer


class AppState:
    """Thread-safe shared state for the running daemon."""

    def __init__(self) -> None:
        # Set by daemon after asyncio loop starts
        self.asyncio_loop: Optional[asyncio.AbstractEventLoop] = None

        # Set by daemon after buffers are created
        self.transcript_buffer: Optional["RollingTranscriptBuffer"] = None
        self.screenshot_buffer: Optional["ScreenshotBuffer"] = None

        # WebSocket clients connected to the viewer
        self.ws_clients: Set["aiohttp.web.WebSocketResponse"] = set()

        # Processing status (drives tray icon color)
        self.status: Literal["idle", "listening", "processing"] = "idle"

        # Last full AI response (sent to late-joining viewers)
        self.last_response: str = ""

        # Conversation history: list of {"role": "user"|"assistant", "content": str}
        # Cleared on daemon restart. Only assistant turns are kept from previous rounds.
        self.conversation_history: list = []

        # Timing
        self.started_at: float = 0.0
        self.last_activity_at: float = 0.0  # updated on hotkey / query / transcript

        # Flags
        self.audio_active: bool = False
        self.shutdown_event: Optional[asyncio.Event] = None
        self.include_clipboard: bool = False  # set True by Ctrl double-tap, consumed by query
        self.response_mode: str = "auto"      # "auto" | "code" — toggled by ESC+↑

        # Info bar fields (shown on viewer)
        self.transcriber_name: str = ""       # "Deepgram" | "Whisper"
        self.ai_model: str = ""               # e.g. "claude-sonnet-4-6"
        self.is_recording: bool = False       # manual voice recording active


# Module-level singleton — the daemon imports this directly
state = AppState()
