"""
maskphish 0.1.0 - Introducing "URL Making Technology" to the world for the very FIRST TIME. Give a Mask to Phishing URL like a PRO.. A MUST have tool for Phishing.
Packaged by PyPack. Run command: bash maskphish.sh
"""
__version__ = "0.1.0"
__author__ = "jaykali"
