import asyncio
import contextlib
import functools
import inspect
import re
import socket
import typing as t
from collections.abc import Callable
from contextlib import aclosing, asynccontextmanager
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import ParamSpec, TypeVar
from urllib.parse import ParseResult, urlparse

import typing_extensions as te
from logfire._internal.stack_info import (
    add_non_user_code_prefix,
)
from logfire._internal.stack_info import (
    get_filepath_attribute as _get_filepath_attribute,
)
from logfire._internal.stack_info import (
    get_user_frame_and_stacklevel as _get_user_frame_and_stacklevel,
)
from logfire._internal.stack_info import (
    is_user_code as _is_user_code,
)
from loguru import logger

P = ParamSpec("P")
R = TypeVar("R")

get_user_frame_and_stacklevel = _get_user_frame_and_stacklevel
get_filepath_attribute = _get_filepath_attribute
is_user_code = _is_user_code


import dreadnode  # noqa: E402

"""
The return type of sys.exc_info(): exc_type, exc_val, exc_tb.
"""

add_non_user_code_prefix(Path(dreadnode.__file__).parent)

T = t.TypeVar("T")
T_in = t.TypeVar("T_in")
T_out = t.TypeVar("T_out")

FIXED_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")


# Formatting


def shorten_string(
    text: str,
    max_length: int | None = None,
    *,
    max_lines: int | None = None,
    separator: str = "...",
) -> str:
    """
    Shortens text to a maximum number of lines and/or characters by removing
    content from the middle.

    Line shortening is applied first, followed by character shortening.

    Args:
        text: The string to shorten.
        max_lines: The maximum number of lines to allow.
        max_chars: The maximum number of characters to allow.
        separator: The separator to insert in the middle of the shortened text.

    Returns:
        The shortened text
    """
    if max_lines is not None:
        lines = text.splitlines()
        if len(lines) > max_lines:
            remaining_lines = max_lines - 1  # leave space for the separator
            if remaining_lines <= 0:
                text = separator  # if max_lines is 1, just use the separator
            else:
                half = remaining_lines // 2
                start_lines = lines[:half]
                end_lines = lines[-(remaining_lines - half) :]
                text = "\n".join([*start_lines, separator, *end_lines])

    if max_length is not None and len(text) > max_length:
        remaining_chars = max_length - len(separator)
        if remaining_chars <= 0:
            text = separator
        else:
            half_chars = remaining_chars // 2
            text = text[:half_chars] + separator + text[-half_chars:]

    return text


def truncate_string(text: str, max_length: int = 80, *, suf: str = "...") -> str:
    """
    Return a string at most max_length characters long by removing the end of the string.
    """
    if len(text) <= max_length:
        return text

    remaining = max_length - len(suf)
    if remaining <= 0:
        return suf

    return text[:remaining] + suf


def clean_str(string: str, *, max_length: int | None = None, replace_with: str = "_") -> str:
    """
    Clean a string by replacing all non-alphanumeric characters (except `/`, '.', and `@`)
    with `replace_with` (`_` by default).
    """
    result = re.sub(r"[^a-z0-9/@.]+", replace_with, string.lower()).strip(replace_with)
    if max_length is not None:
        result = result[:max_length]
    return result


def format_dict(data: dict[str, t.Any], max_length: int = 80) -> str:
    """
    Formats a dictionary to a string, prioritizing showing key-value pairs
    and truncating gracefully if the string exceeds a max length.
    """
    parts: list[str] = []
    items = list(data.items())
    max_length = max_length - 2  # Account for the surrounding braces

    for i, (key, value) in enumerate(items):
        part_str = f"{key}={value!r}"
        potential_parts = [*parts, part_str]

        # Check if adding the next full part would exceed the length
        if len(", ".join(potential_parts)) > max_length:
            num_remaining = len(items) - i
            parts.append(f"... (+{num_remaining} more)")
        else:
            parts.append(part_str)

    formatted = ", ".join(parts)
    return f"{{{formatted}}}"


def create_key_from_name(name: str) -> str:
    key = name.strip().lower()

    key = re.sub(r"[\s_]+", "-", key)

    return re.sub(r"[^a-z0-9-]", "", key)


def valid_key(key: str) -> bool:
    """
    Check if the key is valid (only contains lowercase letters, numbers, and hyphens).
    """
    return bool(re.fullmatch(r"[a-z0-9-]+", key))


def valid_version(version: str) -> bool:
    """
    Check if the version uses fixed semver (MAJOR.MINOR.PATCH).
    """
    return bool(FIXED_SEMVER_RE.fullmatch(version))


# Imports


def get_obj_name(obj: t.Any, *, short: bool = False, clean: bool = False) -> str:
    """
    Return a best effort name for an object.
    """
    name = "unknown"
    if hasattr(obj, "name"):
        name = obj.name
    elif hasattr(obj, "__name__"):
        name = obj.__name__
    elif hasattr(obj.__class__, "__name__"):
        name = obj.__class__.__name__

    if short:
        name = name.split(".")[-1]

    if clean:
        name = clean_str(name)

    return name


def safe_repr(obj: t.Any) -> str:
    """
    Return some kind of non-empty string representation of an object, catching exceptions.
    """
    try:
        result = repr(obj)
    except Exception:
        result = ""

    if result:
        return result

    try:
        return f"<{type(obj).__name__} object>"
    except Exception:
        return "<unknown (repr failed)>"


def get_callable_name(obj: t.Any, *, short: bool = False) -> str:
    """
    Return a best-effort, comprehensive name for a callable object.

    This function handles a wide variety of callables, including regular
    functions, methods, lambdas, partials, wrapped functions, and callable
    class instances.

    Args:
        obj: The callable object to name.
        short: If True, returns a shorter name suitable for logs or UI,
               typically omitting the module path. The class name is
               retained for methods.

    Returns:
        A string representing the callable's name.
    """
    if not callable(obj):
        return safe_repr(obj)

    if isinstance(obj, functools.partial):
        inner_name = get_callable_name(obj.func, short=short)
        return f"partial({inner_name})"

    unwrapped = obj
    with contextlib.suppress(Exception):
        unwrapped = inspect.unwrap(obj)

    if short:
        name = getattr(unwrapped, "__name__", getattr(unwrapped, "__qualname__", None))
    else:
        name = getattr(unwrapped, "__qualname__", getattr(unwrapped, "__name__", None))

    if name is None:
        if hasattr(obj, "__class__"):
            name = getattr(obj.__class__, "__qualname__", obj.__class__.__name__)
        else:
            return safe_repr(obj)

    if short:
        return str(name).split(".")[-1]  # Return only the last part of the name

    with contextlib.suppress(Exception):
        if module := inspect.getmodule(unwrapped):
            module_name = module.__name__
            if module_name and module_name not in ("builtins", "__main__"):
                return f"{module_name}.{name}"

    return str(name)


# Time


def time_to(future_datetime: datetime) -> str:
    """
    Get a string describing the time difference between a future datetime and now.
    """
    now = datetime.now(tz=future_datetime.tzinfo)
    time_difference = future_datetime - now

    days = time_difference.days
    seconds = time_difference.seconds
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60

    result = []
    if days > 0:
        result.append(f"{days}d")
    if hours > 0:
        result.append(f"{hours}hr")
    if minutes > 0:
        result.append(f"{minutes}m")

    return ", ".join(result) if result else "Just now"


# Async


async def concurrent(coros: t.Iterable[t.Awaitable[T]], limit: int | None = None) -> list[T]:
    """
    Run multiple coroutines concurrently with a limit on the number of concurrent tasks.

    Args:
        coros: An iterable of coroutines to run concurrently.
        limit: The maximum number of concurrent tasks. If None, no limit is applied.

    Returns:
        A list of results from the coroutines, in the order they were provided.
    """
    coros = list(coros)
    semaphore = asyncio.Semaphore(limit or len(coros))

    async def run_coroutine_with_semaphore(
        coro: t.Awaitable[T],
    ) -> T:
        async with semaphore:
            return await coro

    return await asyncio.gather(
        *(run_coroutine_with_semaphore(coro) for coro in coros),
    )


# Some weirdness here: https://discuss.python.org/t/overloads-of-async-generators-inconsistent-coroutine-wrapping/56665/2


@t.overload
@contextlib.asynccontextmanager
def concurrent_gen(
    coros: t.Iterable[t.Awaitable[T]],
    limit: int | None = None,
    *,
    return_task: t.Literal[False] = False,
) -> t.AsyncIterator[t.AsyncGenerator[T, None]]: ...


@t.overload
@contextlib.asynccontextmanager
def concurrent_gen(
    coros: t.Iterable[t.Awaitable[T]],
    limit: int | None = None,
    *,
    return_task: t.Literal[True],
) -> t.AsyncIterator[t.AsyncGenerator[asyncio.Task[T], None]]: ...


@contextlib.asynccontextmanager
async def concurrent_gen(
    coros: t.Iterable[t.Awaitable[T]],
    limit: int | None = None,
    *,
    return_task: bool = False,
) -> t.AsyncIterator[t.AsyncGenerator[T | asyncio.Task[T], None]]:
    """
    Run multiple coroutines concurrently with a limit on the number of concurrent tasks.

    Args:
        coros: An iterable of coroutines to run concurrently.
        limit: The maximum number of concurrent tasks. If None, no limit is applied.
        return_task: If True, yields the asyncio.Task object instead of the result.

    Yields:
        An asynchronous generator yielding the results of the coroutines.
        If return_task is True, yields the asyncio.Task objects instead.
    """
    coros = list(coros)
    semaphore = asyncio.Semaphore(limit or len(coros))

    async def run_coroutine_with_semaphore(coro: t.Awaitable[T]) -> T:
        async with semaphore:
            return await coro

    async def generator() -> t.AsyncGenerator[T | asyncio.Task[T], None]:
        pending_tasks = {asyncio.create_task(run_coroutine_with_semaphore(coro)) for coro in coros}

        try:
            while pending_tasks:
                done, pending_tasks = await asyncio.wait(
                    pending_tasks, return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    yield task if return_task else await task
        finally:
            for task in pending_tasks:
                task.cancel()
            await asyncio.gather(*pending_tasks, return_exceptions=True)

    async with aclosing(generator()) as gen:
        yield gen


async def join_generators(
    *generators: t.AsyncGenerator[T, None],
) -> t.AsyncGenerator[T, None]:
    """
    Join multiple asynchronous generators into a single asynchronous generator.

    If any of the generators raise an exception, the other generators will be
    cancelled immediately and the exception will be raised to the caller.

    Args:
        *generators: The asynchronous generators to join.

    Yields:
        The items yielded by the joined generators.

    Raises:
        Exception: If any of the generators raises an exception.
    """
    FINISHED = object()  # noqa: N806 — sentinel
    queue = asyncio.Queue[T | object | Exception](maxsize=1)

    async def _queue_generator(
        generator: t.AsyncGenerator[T, None],
    ) -> None:
        try:
            async with aclosing(generator) as gen:
                async for item in gen:
                    await queue.put(item)
        except Exception as e:
            await queue.put(e)
        finally:
            await queue.put(FINISHED)

    tasks = [asyncio.create_task(_queue_generator(gen)) for gen in generators]

    finished_count = 0

    try:
        while finished_count < len(generators):
            item = await queue.get()

            if isinstance(item, Exception):
                raise item

            if item is FINISHED:
                finished_count += 1
                continue

            yield t.cast("T", item)

    finally:
        for task in tasks:
            if not task.done():
                task.cancel()

        await asyncio.gather(*tasks, return_exceptions=True)


@asynccontextmanager
async def stream_map_and_merge(
    source: t.AsyncGenerator[T_in, None],
    processor: t.Callable[[T_in], t.AsyncGenerator[T_out, None]],
    *,
    limit: int | None = None,
    concurrency: int | None = None,
    source_queue_size: int = 1,
    out_queue_size: int = 1,
) -> t.AsyncIterator[t.AsyncGenerator[T_out, None]]:
    """
    The "one-to-many-to-one" abstraction helpful for concurrently processing
    items from a stream using workers which themselves yield items.

    It consumes items from a source stream and creates processing workers
    which concurrently yield items, then merges them into a single interleaved stream.

    Note: As an oddity for supporting better syntax in our most common Study/Search
    use case, the values yielded from the source generator will be sent back into
    the source generator as the value of the next `asend()` call. This is a syntax
    convenience to allow code like `item = await (yield Item(...))`.

    Args:
        source: The source stream of items to process.
        processor: A function that processes each item from the source and
            returns an asynchronous generator of results.
        limit: Maximum number of items to consume from the source before early stopping.
        concurrency: The maximum number of items to process concurrently.
            If None, there will be no limit on workers.
        in_queue_size: The maximum number of items to buffer from the source.
            This limits how far ahead the source can get before backpressure is applied.
        out_queue_size: The maximum number of processed items to buffer for output.
            This limits how far ahead the workers can get before backpressure is applied.

    Yields:
        An asynchronous generator which yields the processed items from the processor streams.
    """

    # In general, this function is quite complex, mainly because we
    # need to properly manage downstream and upstream backpressure,
    # as well as error handling, cancellation, and lifecycle management.
    #
    # In short, it looks a mess, but not for lack of trying

    in_queue = asyncio.Queue[T_in](maxsize=source_queue_size)
    out_queue = asyncio.Queue[T_out](maxsize=out_queue_size)
    error_queue = asyncio.Queue[Exception]()

    feeding_done = asyncio.Event()
    workers_done = asyncio.Event()

    # Workers create the processor stream for a source item
    # and push results to the out_queue

    async def worker(inner_item: T_in) -> None:
        try:
            async with aclosing(processor(inner_item)) as results:
                async for result in results:
                    while True:
                        with contextlib.suppress(asyncio.QueueFull):
                            out_queue.put_nowait(result)
                            break
                        await asyncio.sleep(0)
        except Exception as e:
            error_queue.put_nowait(e)

    # The feeder pulls from the source generator
    # limited by the in_queue size

    async def feeder() -> None:
        try:
            async with aclosing(source) as stream:
                source_count = 0
                async for item in stream:
                    source_count += 1

                    if limit is not None and source_count > limit:
                        break

                    while True:
                        with contextlib.suppress(asyncio.QueueFull):
                            in_queue.put_nowait(item)
                            break
                        await asyncio.sleep(0)

        except Exception as e:
            error_queue.put_nowait(e)
        finally:
            feeding_done.set()

    # The worker_pool starts the feed, watches the in_queue,
    # and starts worker tasks for every item yielded from source,
    # respecting the concurrency limit.

    async def worker_pool() -> None:
        workers: set[asyncio.Task[None]] = set()
        feed_task = asyncio.create_task(feeder())

        try:
            while not (feeding_done.is_set() and in_queue.empty()):
                try:
                    item = await asyncio.wait_for(in_queue.get(), timeout=0.01)
                except TimeoutError:
                    continue

                # Manage concurrency
                while concurrency and len(workers) >= concurrency:
                    with contextlib.suppress(asyncio.TimeoutError):
                        await asyncio.wait(
                            workers, timeout=0.01, return_when=asyncio.FIRST_COMPLETED
                        )

                # Start new worker
                worker_task = asyncio.create_task(worker(item))
                workers.add(worker_task)
                worker_task.add_done_callback(workers.discard)

            if workers:
                await asyncio.gather(*workers)
        except Exception as e:
            error_queue.put_nowait(e)
        finally:
            feed_task.cancel()
            for task in workers:
                task.cancel()
            await asyncio.gather(feed_task, *workers, return_exceptions=True)
            workers_done.set()

    async def generator() -> t.AsyncGenerator[T_out, None]:
        worker_pool_task = asyncio.create_task(worker_pool())

        try:
            while not (feeding_done.is_set() and workers_done.is_set() and out_queue.empty()):
                with contextlib.suppress(asyncio.QueueEmpty):
                    error = error_queue.get_nowait()
                    raise error

                with contextlib.suppress(asyncio.QueueEmpty):
                    yield out_queue.get_nowait()

                await asyncio.sleep(0)
        finally:
            worker_pool_task.cancel()
            await asyncio.gather(worker_pool_task, return_exceptions=True)

    async with aclosing(generator()) as gen:
        yield gen


# List utilities


@t.overload
def flatten_list(nested_list: t.Sequence[t.Sequence[t.Sequence[T] | T]]) -> list[T]: ...


@t.overload
def flatten_list(nested_list: t.Sequence[t.Sequence[T] | T]) -> list[T]: ...


def flatten_list(nested_list: t.Sequence[t.Any]) -> list[t.Any]:
    """
    Recursively flatten a nested list into a single list.
    """
    flattened = []
    for item in nested_list:
        if isinstance(item, list):
            flattened.extend(flatten_list(item))
        else:
            flattened.append(item)
    return flattened


def is_homogeneous_list(obj: t.Any, item_type: type[T]) -> te.TypeIs[list[T]]:
    """Type guard to check if an object is a homogeneous list of the specified type."""
    return isinstance(obj, list) and all(isinstance(item, item_type) for item in obj)


# Endpoint and networking


def is_docker_service_name(hostname: str) -> bool:
    """
    Check if this looks like a Docker service name

    Args:
        hostname: The hostname to check.

    Returns:
        bool: True if the hostname looks like a Docker service name, False otherwise.
    """
    return bool(hostname and "." not in hostname and hostname != "localhost")


def resolve_endpoint(endpoint: str | None) -> str | None:
    """
    Automatically resolve endpoints based on environment

    Args:
        endpoint: The endpoint URL to resolve.

    Returns:
        str: The resolved endpoint URL.

    Raises:
        ValueError: If the endpoint URL is invalid.
    """
    if not endpoint:
        return None
    parsed = urlparse(endpoint)

    # If it's a real domain (has dots), use as-is
    if not parsed.hostname:
        raise ValueError(f"Invalid endpoint URL: {endpoint}")

    if parsed.hostname == "host.docker.internal":
        return resolve_docker_service(endpoint, parsed)

    if "." in parsed.hostname:
        return endpoint

    # If it's a service name, try to resolve it
    if is_docker_service_name(parsed.hostname):
        return resolve_docker_service(endpoint, parsed)

    return endpoint


def test_connection(endpoint: str) -> bool:
    """
    Simple test to check if the endpoint is reachable.

    Args:
        endpoint: The endpoint URL to test.

    Returns:
        bool: True if the endpoint is reachable, False otherwise.
    """
    try:
        parsed = urlparse(endpoint)
        if not parsed.hostname:
            return False
        default_port = 443 if parsed.scheme == "https" else 80
        socket.create_connection((parsed.hostname, parsed.port or default_port), timeout=1)
    except Exception:
        return False

    return True


def resolve_docker_service(original_endpoint: str, parsed: ParseResult) -> str:
    """
    Try different resolution strategies for Docker services

    Args:
        original_endpoint: The original endpoint URL.
        parsed: The parsed URL object.

    Returns:
        str: The resolved endpoint URL.

    Raises:
        RuntimeError: If no valid endpoint is found.
    """
    port = parsed.port or (443 if parsed.scheme == "https" else 80)

    strategies = [
        original_endpoint,  # Try original first (works if running in same network)
        f"{parsed.scheme}://localhost:{port}",  # Try localhost
        f"{parsed.scheme}://host.docker.internal:{port}",  # Docker Desktop
        f"{parsed.scheme}://172.17.0.1:{port}",  # Docker bridge IP
    ]

    for endpoint in strategies:
        if test_connection(endpoint):
            logger.warning(f"Resolved Docker service endpoint '{parsed.hostname}' to '{endpoint}'.")
            return str(endpoint)

    # If nothing works, return original and let it fail with a helpful error
    raise RuntimeError(
        f"Failed to connect to the Dreadnode Artifact storage at {original_endpoint}."
    )


def _factory(func: Callable[P, R]) -> Callable[P, R]:
    """
    A simple, type-safe wrapper to maintain a consistent API factory pattern.
    """

    @wraps(func)
    def _wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        return func(*args, **kwargs)

    return _wrapper
