"""Services screen — inspect and manage background services (MCP servers, workers)."""

import asyncio
import typing as t

from rich.text import Text
from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.widgets import Static

from dreadnode.app.tui.capabilities_manager import ComponentStateChanged
from dreadnode.app.tui.screens.base import DreadnodeScreen
from dreadnode.app.tui.theme import (
    ACCENT,
    BRAND,
    ERROR,
    FG,
    FG_FAINTEST,
    FG_MUTED,
    FG_SUBTLE,
    SUCCESS,
    WARNING,
)

if t.TYPE_CHECKING:
    from textual.app import ComposeResult
    from textual.events import Key
    from textual.timer import Timer

    from dreadnode.app.client.managed_client import ManagedRuntimeClient


# Poll interval for the detail view so operators see Recent output / Recent
# stderr tail in near-real-time without having to leave and re-enter the
# page after a restart. Silent refresh — no "Loading..." flicker.
_DETAIL_REFRESH_SECONDS = 2.0


# Maximum MCP tools to list inline in the detail view before collapsing the
# rest behind a "View tools" affordance. Chosen to fit a terminal pane without
# scrolling; callers use the "View tools" action to see the full list.
_MAX_INLINE_TOOLS = 8

# Truncation length for a tool description shown inline in the detail view.
# Descriptions longer than this are elided with an ellipsis.
_INLINE_TOOL_DESC_MAX_CHARS = 60

# Marker used by SubprocessWorkerRunner to separate the exit message from the
# captured output tail. Keep in sync with worker_runner.OUTPUT_ERROR_MARKER.
_WORKER_OUTPUT_MARKER = "\n\nWorker output:\n"

# Marker used by MCPClient._set_error_status to append a captured stderr tail.
_MCP_STDERR_MARKER = "\n\nServer stderr:\n"

# Maximum recent-output lines rendered inline in the detail pane. The in-memory
# buffer on the runner / client keeps more; we only need the tail for
# progressive-disclosure troubleshooting in the TUI.
_MAX_RECENT_LINES = 30


def _build_items(
    servers: list[dict[str, t.Any]],
    workers: list[dict[str, t.Any]],
) -> list[dict[str, t.Any]]:
    """Merge MCP servers and workers into a unified item list, grouped by capability."""
    by_cap: dict[str, list[dict[str, t.Any]]] = {}
    for s in servers:
        entry = dict(s, kind="mcp_server")
        by_cap.setdefault(entry.get("capability", ""), []).append(entry)
    for w in workers:
        entry = dict(w, kind="worker")
        by_cap.setdefault(entry.get("capability", ""), []).append(entry)
    items: list[dict[str, t.Any]] = []
    for _cap in sorted(by_cap):
        items.extend(by_cap[_cap])
    return items


class ServicesScreen(DreadnodeScreen):
    """Full-screen services manager — list, inspect, reconnect/restart."""

    BINDINGS: t.ClassVar[list[Binding]] = [Binding("escape", "dismiss", "Back", show=False)]

    def __init__(
        self,
        runtime_client: "ManagedRuntimeClient",
        servers: list[dict[str, t.Any]],
        workers: list[dict[str, t.Any]] | None = None,
        *,
        collect_servers: t.Callable[[], list[dict[str, t.Any]]] | None = None,
        collect_workers: t.Callable[[], list[dict[str, t.Any]]] | None = None,
    ) -> None:
        super().__init__()
        self._client = runtime_client
        self._servers = servers
        self._workers = workers or []
        self._items = _build_items(servers, workers or [])
        # Collectors let the screen pull a fresh snapshot from the
        # capabilities manager when a ``component.state_changed`` event
        # arrives. Optional so existing callers keep working — without
        # them the screen still renders, just without bus-driven refresh.
        self._collect_servers = collect_servers
        self._collect_workers = collect_workers
        self._view: str = "list"  # list | detail | tool_list
        self._cursor: int = 0
        self._action_cursor: int = 0
        self._selected_item: dict[str, t.Any] | None = None
        self._item_detail: dict[str, t.Any] | None = None
        self._tool_search: str = ""
        self._loading: bool = False
        self._acting: bool = False  # reconnecting or restarting
        self._refresh_timer: Timer | None = None

    def compose_content(self) -> "ComposeResult":
        yield Static(id="services-header")
        yield Static(id="services-search")
        with VerticalScroll(id="services-scroll"):
            yield Static(id="services-content")
        # Pinned below the scroll region so a long Recent output / Recent
        # stderr block or a long tools/handlers list never pushes the
        # action menu off the bottom of the screen. Non-detail views
        # clear this widget.
        yield Static(id="services-actions")
        yield Static(id="services-hint")

    def on_mount(self) -> None:
        super().on_mount()
        self._render_current_view()

    def on_component_state_changed(self, message: ComponentStateChanged) -> None:
        """Refresh the list (and the cached selection) from the manager.

        Fired by the app-level subscriber after a ``component.state_changed``
        envelope has already patched ``runtime_info`` in place. We re-pull
        the collectors so the list snapshot tracks the live state, and if
        the affected component is the one currently selected we mirror the
        fields onto the selected-item dict so the detail pane's next render
        picks up the new status without waiting for its own poll.
        """
        payload = message.payload
        # 1. Rebuild the list items from the freshly-patched snapshot so
        #    the list view (if visible) reflects the new status.
        if self._collect_servers is not None and self._collect_workers is not None:
            self._servers = self._collect_servers()
            self._workers = self._collect_workers()
            self._items = _build_items(self._servers, self._workers)
            # Keep the cursor in range after a rebuild (e.g. if a
            # capability was unloaded since the screen opened).
            if self._items:
                self._cursor = min(self._cursor, len(self._items) - 1)
            else:
                self._cursor = 0

        # 2. If the user is currently looking at this component's detail,
        #    mirror the payload onto the selection so the list-status maps
        #    over (error/ok/stopped) without racing the 2s detail poll.
        selected = self._selected_item
        if (
            selected is not None
            and selected.get("capability") == payload.get("capability")
            and selected.get("name") == payload.get("name")
        ):
            if "status" in payload:
                selected["status"] = payload["status"]
            selected["error"] = payload.get("error")
            if payload.get("detail") is not None:
                selected["detail"] = payload["detail"]

        if self.is_mounted:
            self._render_current_view()

    def on_key(self, event: "Key") -> None:
        key = event.key
        if key.startswith("ctrl+") or (key.startswith("f") and key[1:].isdigit()):
            return

        if self._view == "tool_list":
            self._handle_tool_list_key(key, event)
            if key != "escape":
                return
        elif self._view == "detail":
            self._handle_detail_key(key)
        else:
            self._handle_list_key(key)

        event.prevent_default()
        event.stop()

    # ── Helpers ──

    def _selected_kind(self) -> str:
        return (self._item_detail or self._selected_item or {}).get("kind", "mcp_server")

    def _is_mcp(self) -> bool:
        return self._selected_kind() == "mcp_server"

    # ── List view ──

    def _handle_list_key(self, key: str) -> None:
        if key == "up":
            self._cursor = max(0, self._cursor - 1)
        elif key == "down":
            self._cursor = min(len(self._items) - 1, self._cursor + 1)
        elif key == "enter" and self._items:
            self._selected_item = self._items[self._cursor]
            self._view = "detail"
            self._action_cursor = 0
            self._item_detail = None
            self._loading = True
            self._render_current_view()
            self._fetch_detail()
            self._start_detail_refresh()
            return
        elif key == "escape":
            self._stop_detail_refresh()
            self.dismiss()
            return
        self._render_current_view()

    def _fetch_detail(self) -> None:
        item = self._selected_item
        if item is None:
            return
        cap = item.get("capability", "")
        name = item.get("name", "")
        kind = item.get("kind", "mcp_server")
        self.run_worker(self._do_fetch_detail(cap, name, kind), exclusive=True)

    async def _do_fetch_detail(self, capability: str, name: str, kind: str) -> None:
        try:
            if kind == "worker":
                self._item_detail = await self._client.fetch_worker_detail(capability, name)
                self._item_detail["kind"] = "worker"
            else:
                self._item_detail = await self._client.fetch_mcp_detail(capability, name)
                self._item_detail["kind"] = "mcp_server"
            # Detail is the freshest source — sync the list entry so it doesn't
            # drift (the list snapshot was captured at screen-open).
            self._sync_list_from_detail(self._item_detail)
        except Exception as exc:
            self._item_detail = None
            self.notify(f"Failed to load detail: {exc}", title="Services", severity="error")
            # Reflect the fetch failure on the list entry so navigating back
            # doesn't show a stale "ok" status for something we know is broken.
            self._sync_list_entry(capability, name, "error", str(exc))
        finally:
            self._loading = False
            self._render_current_view()

    # ── Auto-refresh ──

    def _start_detail_refresh(self) -> None:
        """Kick off periodic polling of the detail endpoint.

        Idempotent — calling while already running is a no-op. Runs only
        while the detail view is active; the timer is torn down on any
        transition away so we never poll a stale selection.
        """
        if self._refresh_timer is not None:
            return
        self._refresh_timer = self.set_interval(
            _DETAIL_REFRESH_SECONDS, self._silent_refresh_detail
        )

    def _stop_detail_refresh(self) -> None:
        if self._refresh_timer is not None:
            self._refresh_timer.stop()
            self._refresh_timer = None

    def _silent_refresh_detail(self) -> None:
        """Timer callback: fetch fresh detail without the Loading flicker."""
        if self._view != "detail" or self._selected_item is None:
            return
        if self._loading or self._acting:
            return  # don't race a pending fetch/action
        self.run_worker(self._do_silent_refresh_async(), exclusive=False)

    async def _do_silent_refresh_async(self) -> None:
        item = self._selected_item
        if item is None:
            return
        capability = item.get("capability", "")
        name = item.get("name", "")
        kind = item.get("kind", "mcp_server")
        try:
            if kind == "worker":
                fresh = await self._client.fetch_worker_detail(capability, name)
                fresh["kind"] = "worker"
            else:
                fresh = await self._client.fetch_mcp_detail(capability, name)
                fresh["kind"] = "mcp_server"
        except Exception:
            # Silent refresh swallows transient failures — user-initiated
            # fetches still surface errors via the normal path.
            return
        # Selection or view may have changed while the fetch was in flight.
        if self._view != "detail" or self._acting:
            return
        current = self._selected_item or {}
        if current.get("capability") != capability or current.get("name") != name:
            return
        self._item_detail = fresh
        # Auto-refresh found drift — propagate to the list entry too so
        # leaving the detail view back to the list shows the current state.
        self._sync_list_from_detail(fresh)
        self._render_current_view()

    def _render_list(self) -> None:
        header = self.query_one("#services-header", Static)
        content = self.query_one("#services-content", Static)
        actions_pane = self.query_one("#services-actions", Static)
        hint = self.query_one("#services-hint", Static)
        actions_pane.update(Text())  # list view has no per-item actions pane

        count = len(self._items)
        text = Text()
        text.append(" Services", style=f"bold {FG}")
        if count:
            text.append(f"  {count}", style=FG_MUTED)
        text.append("\n")
        text.append(" MCP servers and workers running in the background", style=FG_FAINTEST)
        header.update(text)

        if not self._items:
            content.update(Text("No background services configured", style=f"italic {FG_MUTED}"))
            hint.update(Text("Esc close", style=FG_FAINTEST))
            return

        output = Text()
        current_cap = None
        for i, item in enumerate(self._items):
            cap = item.get("capability", "")
            if cap != current_cap:
                if current_cap is not None:
                    output.append("\n")
                output.append(f"  {cap}\n", style=FG_MUTED)
                current_cap = cap

            is_selected = i == self._cursor
            prefix = "> " if is_selected else "  "
            kind = item.get("kind", "mcp_server")

            status = item.get("status", "?")
            if status == "ok":
                if kind == "worker":
                    icon, icon_style, label = "✓", SUCCESS, "running"
                else:
                    icon, icon_style, label = "✓", SUCCESS, "connected"
            elif status == "stopped":
                icon, icon_style, label = "◯", FG_MUTED, "stopped"
            elif status == "gated_off":
                gated_detail = item.get("detail", "")
                gated_label = gated_detail.lower() if gated_detail else "gated off"
                icon, icon_style, label = "◯", FG_MUTED, gated_label
            elif status == "enabled_failed":
                icon, icon_style, label = "✗", ERROR, item.get("error", "enabled but failed")
            elif status == "degraded":
                icon, icon_style, label = "⚠", WARNING, item.get("detail", "degraded")
            elif status == "error":
                icon, icon_style, label = "✗", ERROR, item.get("error") or "error"
            else:
                icon, icon_style, label = "?", WARNING, status

            kind_label = "worker" if kind == "worker" else "mcp server"
            transport = item.get("transport", "")
            tool_count = item.get("tool_count", 0)

            output.append(prefix, style=ACCENT if is_selected else "")
            output.append(item.get("name", "?"), style=f"bold {FG}" if is_selected else FG)
            output.append(" · ", style=FG_FAINTEST)
            output.append(f"{icon} ", style=icon_style)
            output.append(label, style=FG_MUTED)
            if transport:
                output.append(f" · {transport}", style=FG_FAINTEST)
            if tool_count:
                output.append(f" · {tool_count} tools", style=FG_FAINTEST)
            output.append(f"   {kind_label}", style=FG_FAINTEST)
            output.append("\n")

        content.update(output)
        hint.update(Text("↑↓ navigate · Enter select · Esc close", style=FG_FAINTEST))

    # ── Detail view ──

    def _handle_detail_key(self, key: str) -> None:
        actions = self._get_actions()
        if key == "up":
            self._action_cursor = max(0, self._action_cursor - 1)
        elif key == "down":
            self._action_cursor = min(len(actions) - 1, self._action_cursor + 1)
        elif key == "r":
            # Manual refresh — the detail pane already polls on an
            # interval, but operators often want an immediate pull right
            # after a restart or reconnect. Enter still triggers the
            # currently-highlighted menu action (including restart).
            self._silent_refresh_detail()
            return
        elif key == "enter" and actions:
            action_id = actions[self._action_cursor][0]
            if action_id == "view_tools":
                self._stop_detail_refresh()
                self._view = "tool_list"
                self._render_current_view()
                return
            if action_id in ("reconnect", "restart"):
                self._do_action()
                return
        elif key == "escape":
            self._stop_detail_refresh()
            self._view = "list"
            self._item_detail = None
        self._render_current_view()

    def _action_verb(self, past: bool = False) -> str:
        """Return the appropriate verb for the primary action."""
        if self._is_mcp():
            transport = (self._item_detail or self._selected_item or {}).get("transport", "")
            if transport == "stdio":
                return "Restarted" if past else "Restart"
            return "Reconnected" if past else "Reconnect"
        return "Restarted" if past else "Restart"

    def _get_actions(self) -> list[tuple[str, str]]:
        actions: list[tuple[str, str]] = []
        item = self._item_detail or self._selected_item or {}
        is_gated_off = item.get("status") == "gated_off" or item.get("state") == "gated_off"
        if self._is_mcp():
            detail = self._item_detail
            if detail and detail.get("tool_count", 0) > 0:
                actions.append(("view_tools", "View tools"))
            # CAP-FLAG-014: reconnect would fail with 409 anyway
            if not is_gated_off:
                actions.append(("reconnect", self._action_verb()))
        elif not is_gated_off:
            # CAP-WLIF-006: restart is rejected for gated-off workers
            actions.append(("restart", self._action_verb()))
        return actions

    def _do_action(self) -> None:
        item = self._selected_item
        if item is None:
            return
        cap = item.get("capability", "")
        name = item.get("name", "")
        if self._is_mcp():
            self.run_worker(self._do_reconnect_async(cap, name), exclusive=True)
        else:
            self.run_worker(self._do_restart_worker_async(cap, name), exclusive=True)

    async def _do_reconnect_async(self, capability: str, server_name: str) -> None:
        verb = self._action_verb()
        self._acting = True
        self._render_current_view()
        self.notify(f"{verb}ing...", title="Services", severity="information", timeout=10)
        await asyncio.sleep(0)
        try:
            self._item_detail = await self._client.reconnect_mcp_server(capability, server_name)
            self._item_detail["kind"] = "mcp_server"
            status = self._item_detail.get("status", "")
            verb = self._action_verb(past=True)
            if status in ("connected", "ok"):
                self.notify(verb, title="Services", severity="information")
                self._sync_list_entry(capability, server_name, "ok", None)
            else:
                error = self._item_detail.get("error", "unknown error")
                short = error.split("\n", 1)[0] if error else "unknown error"
                self.notify(
                    f"{self._action_verb()} failed: {short}",
                    title="Services",
                    severity="error",
                )
                self._sync_list_entry(capability, server_name, "error", error)
        except Exception as exc:
            self.notify(f"{self._action_verb()} failed: {exc}", title="Services", severity="error")
        finally:
            self._acting = False
        self._render_current_view()

    async def _do_restart_worker_async(self, capability: str, worker_name: str) -> None:
        self._acting = True
        self._render_current_view()
        self.notify("Restarting...", title="Services", severity="information", timeout=10)
        await asyncio.sleep(0)
        try:
            self._item_detail = await self._client.restart_worker(capability, worker_name)
            self._item_detail["kind"] = "worker"
            state = self._item_detail.get("state", "")
            restarted = bool(self._item_detail.get("restarted", True))
            if state in ("running", "ok"):
                message = "Restarted" if restarted else "Already running"
                self.notify(message, title="Services", severity="information")
                self._sync_list_entry(capability, worker_name, "ok", None)
            else:
                error = self._item_detail.get("error", "unknown error")
                short = error.split("\n", 1)[0] if error else "unknown error"
                self.notify(f"Restart failed: {short}", title="Services", severity="error")
                self._sync_list_entry(capability, worker_name, "error", error)
        except Exception as exc:
            self.notify(f"Restart failed: {exc}", title="Services", severity="error")
        finally:
            self._acting = False
        self._render_current_view()

    def _sync_list_entry(self, capability: str, name: str, status: str, error: str | None) -> None:
        """Update the list-level entry so navigating back shows current state."""
        for item in self._items:
            if item.get("capability") == capability and item.get("name") == name:
                item["status"] = status
                item["error"] = error
                break

    @staticmethod
    def _detail_to_list_status(detail: dict[str, t.Any]) -> tuple[str | None, str | None]:
        """Map a fresh detail dict to (list-status, error) for list-entry sync.

        Detail and list use *different* status vocabularies. Workers carry
        ``state`` (``WorkerState`` enum: ``running``/``error``/...); MCP
        servers carry ``status`` (``MCPStatus`` enum: ``connected``/
        ``failed``/...). The list renderer only knows the lifecycle-manager
        vocabulary (``ok``/``error``/``stopped``/``gated_off``/
        ``enabled_failed``/``degraded``) and falls through to ``?`` for
        anything else.

        Returns ``(None, _)`` when the detail status doesn't have a known
        list equivalent — the caller must NOT overwrite the existing list
        entry in that case (otherwise a healthy ``ok`` MCP becomes ``?``
        when the user steps in/out of its detail).
        """
        error = detail.get("error")
        kind = detail.get("kind")
        if kind == "worker":
            # Mirror WorkerLifecycleManager._update_health (worker_manager.py).
            mapping = {
                "running": "ok",
                "error": "error",
                "stopped": "stopped",
                "gated_off": "gated_off",
            }
            return mapping.get(detail.get("state", "")), error
        # Mirror MCPLifecycleManager's component_health updates
        # (capability_manager.py): success → "ok", connect failure → "error".
        # ``disconnected`` is the lifecycle-not-yet-attached state and isn't
        # a clean STOPPED, so we don't sync it. Transient/auth states aren't
        # in the list-renderer vocabulary either — leave the existing entry
        # alone rather than churning it to a ``?``.
        mapping = {
            "connected": "ok",
            "failed": "error",
        }
        return mapping.get(detail.get("status", "")), error

    def _sync_list_from_detail(self, detail: dict[str, t.Any]) -> None:
        """Push the freshly-fetched detail's status onto its list entry.

        Without this, the list view (a snapshot from screen-open) drifts from
        the detail view (re-fetched on open + auto-refresh) — e.g. a worker
        that errors after the screen opened still shows ``running`` in the
        list while the detail correctly shows ``failed``.
        """
        capability = detail.get("capability", "")
        name = detail.get("name", "")
        if not capability or not name:
            return
        status, error = self._detail_to_list_status(detail)
        if status is None:
            return  # Unknown detail status — preserve the existing list entry.
        self._sync_list_entry(capability, name, status, error)

    def _render_detail(self) -> None:
        header = self.query_one("#services-header", Static)
        content = self.query_one("#services-content", Static)
        actions_pane = self.query_one("#services-actions", Static)
        hint = self.query_one("#services-hint", Static)

        item = self._selected_item or {}
        detail = self._item_detail
        is_mcp = self._is_mcp()

        name = item.get("name", "?")
        text = Text()
        text.append(f" {name}", style=f"bold {FG}")
        text.append("\n")
        text.append(" Worker" if not is_mcp else " MCP Server", style=FG_FAINTEST)
        header.update(text)

        output = Text()

        if self._loading:
            output.append("\n  Loading...\n", style=FG_MUTED)
            content.update(output)
            actions_pane.update(Text())
            hint.update(Text("Esc back", style=FG_FAINTEST))
            return

        if is_mcp:
            self._render_mcp_detail_body(output, item, detail)
        else:
            self._render_worker_detail_body(output, item, detail)

        content.update(output)

        # Actions live in a pinned pane below the scroll region so long
        # detail bodies (Recent output, tool lists, etc.) don't push the
        # selectable menu off the visible screen.
        actions_output = Text()
        if self._acting:
            verb = self._action_verb()
            actions_output.append(f"  {verb}ing...\n", style=FG_FAINTEST)
        else:
            actions = self._get_actions()
            for i, (_action_id, label) in enumerate(actions):
                is_selected = i == self._action_cursor
                prefix = "> " if is_selected else "  "
                style = f"bold {FG}" if is_selected else FG
                actions_output.append(
                    f"  {prefix}{i + 1}. ",
                    style=ACCENT if is_selected else FG_FAINTEST,
                )
                actions_output.append(f"{label}\n", style=style)
        actions_pane.update(actions_output)

        hint.update(
            Text(
                "up/down navigate · Enter select · r refresh · Esc back",
                style=FG_FAINTEST,
            )
        )

    def _render_mcp_detail_body(
        self,
        output: Text,
        item: dict[str, t.Any],
        detail: dict[str, t.Any] | None,
    ) -> None:
        """Render MCP-server-specific detail fields."""
        # Status
        status_val = (
            detail.get("status", item.get("status", "?")) if detail else item.get("status", "?")
        )
        if status_val in ("connected", "ok"):
            output.append("  Status: ", style=f"bold {FG}")
            output.append("connected\n", style=ACCENT)
        elif status_val == "gated_off":
            gated_detail = (detail or item).get("detail", "")
            output.append("  Status: ", style=f"bold {FG}")
            output.append("gated off\n", style=FG_MUTED)
            if gated_detail:
                output.append(f"  {gated_detail}\n", style=FG_FAINTEST)
            else:
                output.append(
                    "  Enable the required flag to start this server\n", style=FG_FAINTEST
                )
        elif status_val == "enabled_failed":
            output.append("  Status: ", style=f"bold {FG}")
            output.append("enabled but failed to start\n", style=ERROR)
            error = (detail or item).get("error")
            if error:
                parts = error.split("\n\nServer stderr:\n", 1)
                output.append(f"  Error: {parts[0]}\n", style=FG_MUTED)
        elif status_val in ("needs_auth", "degraded"):
            output.append("  Status: ", style=f"bold {FG}")
            output.append("needs authentication\n", style=WARNING)
        else:
            output.append("  Status: ", style=f"bold {FG}")
            output.append(f"failed ({status_val})\n", style=ERROR)
            error = (detail or item).get("error")
            if error:
                parts = error.split("\n\nServer stderr:\n", 1)
                output.append(f"  Error: {parts[0]}\n", style=FG_MUTED)

        if detail:
            transport = detail.get("transport", "")
            output.append("  Transport: ", style=f"bold {FG}")
            output.append(f"{transport}\n", style=FG_MUTED)

            if transport == "stdio":
                output.append("  Command: ", style=f"bold {FG}")
                output.append(f"{detail.get('command', '?')}\n", style=FG_MUTED)
                args = detail.get("args", [])
                if args:
                    output.append("  Args: ", style=f"bold {FG}")
                    output.append(f"{' '.join(str(a) for a in args)}\n", style=FG_MUTED)
            else:
                output.append("  URL: ", style=f"bold {FG}")
                output.append(f"{detail.get('url', '?')}\n", style=FG_MUTED)

            output.append("  Capability: ", style=f"bold {FG}")
            output.append(f"{detail.get('capability', '?')}\n", style=FG_MUTED)

            log_path = detail.get("log_path")
            if log_path:
                output.append("  Log file: ", style=f"bold {FG}")
                output.append(f"{log_path}\n", style=FG_MUTED)

            tool_count = detail.get("tool_count", 0)
            output.append("  Tools: ", style=f"bold {FG}")
            output.append(f"{tool_count} tool{'s' if tool_count != 1 else ''}\n", style=FG_MUTED)

            tools = detail.get("tools", [])
            if tools:
                output.append("\n")
                for i, tool in enumerate(tools[:_MAX_INLINE_TOOLS]):
                    # Tool descriptions often arrive as multi-paragraph
                    # docstrings ("Args:\n  ...\n\nReturns:..."). Collapse
                    # runs of whitespace to single spaces *before* truncating
                    # so the inline summary stays on one line and the
                    # character limit applies to visible content, not to
                    # newlines that the renderer would expand again.
                    desc = " ".join((tool.get("description", "") or "").split())
                    if len(desc) > _INLINE_TOOL_DESC_MAX_CHARS:
                        desc = desc[: _INLINE_TOOL_DESC_MAX_CHARS - 3] + "..."
                    output.append(f"    {i + 1}. ", style=FG_FAINTEST)
                    output.append(tool.get("name", "?"), style=FG)
                    if desc:
                        output.append(f" -- {desc}", style=FG_MUTED)
                    output.append("\n")
                if len(tools) > _MAX_INLINE_TOOLS:
                    remaining = len(tools) - _MAX_INLINE_TOOLS
                    output.append(
                        f"    ... and {remaining} more (View tools to see all)\n",
                        style=FG_FAINTEST,
                    )
            elif status_val not in ("connected", "ok"):
                verb = self._action_verb().lower()
                output.append(
                    f"\n  Server disconnected -- {verb} to view tools\n",
                    style=f"italic {FG_MUTED}",
                )

        # Recent stderr — prefer the live ring buffer from the connected
        # client so operators see output for healthy servers too; fall back
        # to the tail embedded in the error message for failed connects
        # where the client was discarded before we could read its buffer.
        stderr_lines: list[str] = []
        if detail:
            live = detail.get("recent_stderr") or []
            if live:
                stderr_lines = list(live)[-_MAX_RECENT_LINES:]
        if not stderr_lines:
            error = (detail or item).get("error", "") if detail else item.get("error", "")
            if error and _MCP_STDERR_MARKER in error:
                stderr_lines = error.split(_MCP_STDERR_MARKER, 1)[1].splitlines()
        if stderr_lines:
            output.append("\n")
            output.append("  Recent stderr\n", style=f"bold {FG_SUBTLE}")
            for line in stderr_lines:
                output.append(f"    {line}\n", style=FG_MUTED)

    def _render_worker_detail_body(
        self,
        output: Text,
        item: dict[str, t.Any],
        detail: dict[str, t.Any] | None,
    ) -> None:
        """Render worker-specific detail fields."""
        state_val = (
            detail.get("state", item.get("status", "?")) if detail else item.get("status", "?")
        )
        if state_val in ("running", "ok"):
            output.append("  State: ", style=f"bold {FG}")
            output.append("running\n", style=ACCENT)
        elif state_val == "stopped":
            output.append("  State: ", style=f"bold {FG}")
            output.append("stopped\n", style=FG_MUTED)
        elif state_val == "gated_off":
            # CAP-WRK-007: manifest-declared but when: predicate unsatisfied
            output.append("  State: ", style=f"bold {FG}")
            output.append("gated off\n", style=FG_MUTED)
            when = (detail or item).get("when") or []
            if when:
                output.append(f"  Enable flag(s) to start: {', '.join(when)}\n", style=FG_FAINTEST)
            else:
                output.append(
                    "  Enable the required flag(s) to start this worker\n", style=FG_FAINTEST
                )
        elif state_val == "error":
            output.append("  State: ", style=f"bold {FG}")
            output.append("error\n", style=ERROR)
            error = (detail or item).get("error")
            if error:
                # Strip the captured-output tail: the Recent output block below
                # already renders it, and doubling it up clutters the pane.
                error_head = error.split(_WORKER_OUTPUT_MARKER, 1)[0]
                output.append(f"  Error: {error_head}\n", style=FG_MUTED)
        else:
            output.append("  State: ", style=f"bold {FG}")
            output.append(f"{state_val}\n", style=WARNING)

        if detail:
            output.append("  Capability: ", style=f"bold {FG}")
            output.append(f"{detail.get('capability', '?')}\n", style=FG_MUTED)

            process = detail.get("process") or {}
            if process:
                command = process.get("command")
                if command:
                    output.append("  Command: ", style=f"bold {FG}")
                    output.append(f"{command}\n", style=FG_MUTED)
                args = process.get("args") or []
                if args:
                    output.append("  Args: ", style=f"bold {FG}")
                    output.append(f"{' '.join(str(a) for a in args)}\n", style=FG_MUTED)
                pid = process.get("pid")
                if pid is not None:
                    output.append("  PID: ", style=f"bold {FG}")
                    output.append(f"{pid}\n", style=FG_MUTED)
                log_path = process.get("log_path")
                if log_path:
                    output.append("  Log file: ", style=f"bold {FG}")
                    output.append(f"{log_path}\n", style=FG_MUTED)

            handlers = detail.get("handlers", {})
            if handlers:
                output.append("\n")
                output.append("  Handlers\n", style=f"bold {FG_SUBTLE}")

                task_count = handlers.get("tasks", 0)
                schedule_count = handlers.get("schedules", 0)
                event_kinds = handlers.get("event_kinds", [])
                startup_count = handlers.get("startup", 0)
                shutdown_count = handlers.get("shutdown", 0)

                if task_count:
                    output.append("    tasks        ", style=FG_MUTED)
                    output.append(f"{task_count}\n", style=FG)
                if schedule_count:
                    output.append("    schedules    ", style=FG_MUTED)
                    output.append(f"{schedule_count}\n", style=FG)
                if event_kinds:
                    output.append("    events       ", style=FG_MUTED)
                    output.append(f"{', '.join(event_kinds)}\n", style=FG)
                if startup_count:
                    output.append("    on_startup   ", style=FG_MUTED)
                    output.append(f"{startup_count}\n", style=FG)
                if shutdown_count:
                    output.append("    on_shutdown  ", style=FG_MUTED)
                    output.append(f"{shutdown_count}\n", style=FG)

                if not any(
                    [task_count, schedule_count, event_kinds, startup_count, shutdown_count]
                ):
                    output.append("    (none)\n", style=FG_FAINTEST)

            recent_output = (detail.get("process") or {}).get("recent_output") or []
            if recent_output:
                output.append("\n")
                output.append("  Recent output\n", style=f"bold {FG_SUBTLE}")
                for line in recent_output[-_MAX_RECENT_LINES:]:
                    output.append(f"    {line}\n", style=FG_MUTED)

    # ── Tool list view (MCP only) ──

    def _handle_tool_list_key(self, key: str, event: "Key") -> None:
        if key == "escape":
            if self._tool_search:
                self._tool_search = ""
                self._render_current_view()
            else:
                self._tool_search = ""
                self._view = "detail"
                self._action_cursor = 0
                self._render_current_view()
                self._start_detail_refresh()
            return
        if key == "backspace":
            if self._tool_search:
                self._tool_search = self._tool_search[:-1]
                self._render_current_view()
            return
        if event.character and event.character.isprintable() and len(event.character) == 1:
            self._tool_search += event.character
            self._render_current_view()
            return

    def _render_tool_list(self) -> None:
        header = self.query_one("#services-header", Static)
        content = self.query_one("#services-content", Static)
        actions_pane = self.query_one("#services-actions", Static)
        hint = self.query_one("#services-hint", Static)
        actions_pane.update(Text())  # tool-list view is inline, no separate actions

        all_tools = (self._item_detail or {}).get("tools", [])
        server_name = (self._selected_item or {}).get("name", "?")
        cap_name = (self._selected_item or {}).get("capability", "?")

        query = self._tool_search.lower()
        tools = [
            tool
            for tool in all_tools
            if not query
            or query in tool.get("name", "").lower()
            or query in tool.get("description", "").lower()
        ]

        text = Text()
        text.append(" Tools", style=f"bold {FG}")
        text.append(
            f"  {len(tools)}/{len(all_tools)}" if query else f"  {len(all_tools)}", style=FG_MUTED
        )
        text.append("\n")
        text.append(f" {server_name}", style=FG_FAINTEST)
        header.update(text)

        search_bar = self.query_one("#services-search", Static)
        search_text = Text()
        if self._tool_search:
            search_text.append(f" \u2315 {self._tool_search}", style=FG)
            search_text.append("\u2581", style=FG_FAINTEST)
        else:
            search_text.append(" \u2315 Search\u2026", style=FG_FAINTEST)
        search_bar.update(search_text)

        output = Text()
        if query and not tools:
            output.append(f'No tools matching "{self._tool_search}"\n', style=f"italic {FG_MUTED}")

        for i, tool in enumerate(tools):
            if i > 0:
                output.append(
                    "────────────────────────────────────────────────\n", style=FG_FAINTEST
                )

            tool_name = tool.get("name", "?")
            qualified = f"{cap_name}:{server_name}:{tool_name}"

            output.append(f"{tool_name}  ", style=f"bold {BRAND}")
            output.append(f"{qualified}\n", style=FG_FAINTEST)
            output.append("\n")

            schema = tool.get("input_schema", {})
            properties = schema.get("properties", {})
            required_params = set(schema.get("required", []))

            if properties:
                for param_name, param_info in properties.items():
                    req_label = "required" if param_name in required_params else "optional"
                    param_type = param_info.get("type", "any")

                    output.append(param_name, style=FG)
                    output.append(f" ({req_label}): {param_type}", style=FG_MUTED)
                    param_desc = param_info.get("description")
                    if param_desc:
                        output.append(f" -- {param_desc}", style=FG_FAINTEST)
                    output.append("\n")

                output.append("\n")

            desc = tool.get("description", "")
            if desc:
                output.append(f"{desc}\n", style=FG_MUTED)

        content.update(output)
        hint.update(Text("Type to search · Esc back", style=FG_FAINTEST))

    # ── Rendering dispatch ──

    def _render_current_view(self) -> None:
        search = self.query_one("#services-search", Static)
        search.display = self._view == "tool_list"

        if self._view == "list":
            self._render_list()
        elif self._view == "detail":
            self._render_detail()
        elif self._view == "tool_list":
            self._render_tool_list()
