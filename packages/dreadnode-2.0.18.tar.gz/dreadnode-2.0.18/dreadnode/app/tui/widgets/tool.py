"""Widgets and helpers for displaying tool calls."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any, ClassVar

from rich.console import Group
from rich.markdown import Heading, Markdown
from rich.segment import Segment
from rich.style import Style
from rich.text import Text
from textual.reactive import reactive
from textual.widget import Widget

from dreadnode.app.tui.theme import ACCENT, ERROR, FG_FAINTEST, FG_MUTED, FG_SUBTLE

if TYPE_CHECKING:
    from rich.console import (
        Console,
        ConsoleOptions,
        ConsoleRenderable,
        RenderableType,
        RenderResult,
    )
    from rich.markdown import MarkdownContext

# Short label rendered in place of the raw URL when a tool result carries
# a deep link — the URL itself can be 100+ chars wide and wraps past the
# tool widget's gutter, breaking the bordered visual frame and adding
# noise. The link target rides on the OSC 8 hyperlink the label carries.
URL_LABEL = "View in web"


class _ThemedHeading(Heading):
    """Rich heading subclass that mirrors the project's TCSS palette.

    Rich's defaults center H1, color H2/H3 magenta, and underline both —
    fine for ``rich.print``, jarring next to the conversation's themed
    Textual ``Markdown`` widgets. The proper fix is to refactor
    ``ToolCall`` to a ``compose()`` widget so the expanded body can use
    the same Textual ``Markdown`` (and inherit ``MarkdownH1`` / ``MarkdownH2``
    rules from ``dreadnode.tcss``). Until that lands, we override
    ``Heading`` in our Rich Markdown subclass below to apply the same
    accent-bold-no-underline styling Rich's renderer produces.
    """

    LEVEL_ALIGN: ClassVar[dict[str, str]] = {f"h{i}": "left" for i in range(1, 7)}

    _STYLES: ClassVar[dict[str, Style]] = {
        "h1": Style(color=ACCENT, bold=True),
        "h2": Style(color=ACCENT, bold=True),
        "h3": Style(color=FG_SUBTLE, bold=True),
        "h4": Style(color=FG_SUBTLE, bold=True),
        "h5": Style(color=FG_MUTED, bold=True),
        "h6": Style(color=FG_MUTED, bold=True),
    }

    def on_enter(self, context: MarkdownContext) -> None:
        # Push a no-op style instead of ``markdown.h{n}`` so the magenta
        # / underline from Rich's default theme don't bake into
        # per-character styles. The push is still required because
        # ``on_leave`` always pops; we apply our themed style in
        # ``__rich_console__`` afterwards.
        context.enter_style("none")
        self.text = Text()

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        text = self.text.copy()
        text.justify = "left"
        text.stylize(self._STYLES.get(self.tag, Style(bold=True)))
        yield text


class ThemedMarkdown(Markdown):
    """Rich ``Markdown`` whose headings match the TCSS conversation theme.

    See ``_ThemedHeading`` for the rationale — this subclass simply swaps
    the heading element so report bodies rendered inside ``ToolCall``
    don't fall back to Rich's centered/magenta-underlined defaults.
    """

    elements: ClassVar[dict[str, type]] = {**Markdown.elements, "heading_open": _ThemedHeading}


class _GutterFrame:
    """Wrap a renderable so each rendered line is prefixed with the
    tool-call gutter (``│ ``).

    The header/meta block built in :func:`render_tool_call` paints its
    own per-line gutter while assembling a single ``Text``. A multi-line
    body (Markdown for the report tool) is a Rich renderable that
    doesn't know about that gutter — without help, headings/lists/blank
    lines bleed past column 0 and look like they've escaped the tool
    frame. We let Rich do the line breaking (so headings and code blocks
    still render natively at the reduced width), then prepend the gutter
    Segment to each resulting line. Width is reserved up front so the
    inner renderable wraps correctly.
    """

    def __init__(
        self,
        renderable: ConsoleRenderable,
        *,
        gutter: str = "│ ",
        gutter_style: str = FG_FAINTEST,
    ) -> None:
        self.renderable = renderable
        self.gutter = gutter
        self.gutter_style = gutter_style

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        gutter_width = len(self.gutter)
        inner_width = max(options.max_width - gutter_width, 1)
        inner_options = options.update_width(inner_width)
        prefix = Segment(self.gutter, console.get_style(self.gutter_style))
        new_line = Segment.line()
        for line in console.render_lines(self.renderable, inner_options, pad=False):
            yield prefix
            yield from line
            yield new_line


def _link_style(url: str) -> Style:
    return Style.from_meta({"@click": f"open_url({url!r})"})


def render_tool_call(
    label: str,
    *,
    meta: str | None = None,
    details: str = "",
    meta_style: str = FG_FAINTEST,
    url: str | None = None,
    body: ConsoleRenderable | None = None,
) -> RenderableType:
    """Render a tool call as Rich Text — or a Group when a rich body is
    attached.

    Pure rendering function — no awareness of display modes.
    Used by ToolCall.render() as the single output path.

    ``meta_style`` colors the ``↳ <meta>`` line; defaults to the same
    dim gray used for summaries. Errored calls pass :data:`ERROR` so the
    failure pops without changing the tool-name color.

    ``url`` renders a compact Textual-clickable link on the summary line
    (currently used by the ``report`` tool). The raw URL is not shown.

    ``body`` is an optional Rich renderable (typically ``Markdown`` for
    the ``report`` tool's expanded view). When present, the function
    returns a ``Group`` with the body sitting after the header/meta
    block, wrapped in :class:`_GutterFrame` so every line of the body
    carries the same ``│ `` gutter as the header — Rich still does the
    line breaking, so multi-line markdown elements (lists, code blocks,
    headings) render natively at the reduced width.
    """
    text = Text()
    text.append("│ ", style=FG_FAINTEST)

    match = re.match(r"^([a-zA-Z0-9_-]+)\((.*)\)$", label)
    if match:
        name, args = match.groups()
        text.append(name, style=ACCENT)
        text.append(f"({args})", style=FG_MUTED)
    else:
        text.append(label, style=ACCENT)

    if meta:
        # Multi-line metas (typically multi-line errors like
        # "Command failed (1):\n<stderr>...") need each continuation
        # line prefixed with the gutter so the bordered widget stays
        # visually contiguous instead of leaking bare text into the
        # conversation flow.
        meta_lines = meta.splitlines() or [""]
        text.append("\n│ ↳ ", style=meta_style)
        text.append(meta_lines[0], style=meta_style)
        if url:
            text.append(" - ", style=meta_style)
            text.append(URL_LABEL, style=_link_style(url))
        for line in meta_lines[1:]:
            text.append("\n│   ", style=meta_style)
            text.append(line, style=meta_style)

    if details:
        lines = details.splitlines()
        prefix = "\n│   " if meta else "\n│ ↳ "
        text.append(f"{prefix}{lines[0]}", style=FG_FAINTEST)
        for line in lines[1:]:
            text.append(f"\n│   {line}", style=FG_FAINTEST)

    if url and not meta:
        text.append("\n│ ↗ ", style=FG_FAINTEST)
        text.append(URL_LABEL, style=_link_style(url))

    if body is None:
        return text

    return Group(text, _GutterFrame(body))


class ToolCall(Widget):
    """A widget to display a tool call — in-progress or completed.

    Used by both the live interactive stream (tool_start → tool_end) and the
    transcript rebuild path. Stores full data; display mode is resolved
    at render time via app._output_mode.
    """

    tool_name: reactive[str] = reactive("")
    meta: reactive[str] = reactive("")
    details: reactive[str] = reactive("")
    error: reactive[str] = reactive("")
    url: reactive[str] = reactive("")
    expanded_body: reactive[str] = reactive("")
    expanded_body_format: reactive[str] = reactive("")

    def __init__(
        self,
        *,
        name: str,
        details: str = "",
        meta: str | None = None,
        error: str | None = None,
        url: str | None = None,
        expanded_body: str | None = None,
        expanded_body_format: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.tool_name = name
        self.details = details
        self.meta = meta or ""
        self.error = error or ""
        self.url = url or ""
        self.expanded_body = expanded_body or ""
        self.expanded_body_format = expanded_body_format or ""

    def _output_mode(self) -> str:
        try:
            return self.app.output_mode  # type: ignore[attr-defined]
        except Exception:
            return "compact"

    def _get_visible_details(self) -> str:
        """Return details respecting the app-level output mode.

        Applies 8-line truncation for display. The full details are
        always stored on the widget — truncation is render-time only.
        """
        if not self.details:
            return ""
        if self._output_mode() != "expanded":
            return ""
        lines = self.details.splitlines()
        if len(lines) > 8:
            omitted = len(lines) - 6
            return "\n".join(lines[:3] + [f"... {omitted} lines omitted ..."] + lines[-3:])
        return self.details

    def _get_visible_error(self) -> str:
        """Return the error string respecting the app-level output mode.

        Mirrors :meth:`_get_visible_details`: compact mode keeps the
        first line only (so the failure is still visible at a glance
        without a multi-screen traceback dominating the conversation),
        expanded mode shows the full error with the same 8-line
        truncation applied to long bodies.
        """
        if not self.error:
            return ""
        lines = self.error.splitlines() or [""]
        if self._output_mode() != "expanded":
            first = lines[0]
            if len(lines) > 1:
                return f"{first} (+{len(lines) - 1} more lines)"
            return first
        if len(lines) > 8:
            omitted = len(lines) - 6
            return "\n".join(lines[:3] + [f"... {omitted} lines omitted ..."] + lines[-3:])
        return self.error

    def complete(
        self,
        *,
        meta: str | None = None,
        details: str = "",
        error: str | None = None,
        url: str | None = None,
        expanded_body: str | None = None,
        expanded_body_format: str | None = None,
    ) -> None:
        """Transition from in-progress to completed state."""
        if meta is not None:
            self.meta = meta
        self.details = details
        if error:
            self.error = error
        if url:
            self.url = url
        if expanded_body:
            self.expanded_body = expanded_body
        if expanded_body_format:
            self.expanded_body_format = expanded_body_format

    def _build_expanded_body_renderable(self) -> ConsoleRenderable | None:
        if not self.expanded_body:
            return None
        if self.expanded_body_format == "markdown":
            return ThemedMarkdown(self.expanded_body)
        return Text(self.expanded_body)

    def render(self) -> RenderableType:
        """Render the tool call."""
        if self.error:
            visible_error = self._get_visible_error()
            return render_tool_call(
                self.tool_name,
                meta=f"error: {visible_error}",
                meta_style=ERROR,
            )
        visible_details = self._get_visible_details()
        body: ConsoleRenderable | None = None
        if self._output_mode() == "expanded":
            body = self._build_expanded_body_renderable()
        if body is not None:
            return render_tool_call(
                self.tool_name,
                meta=self.meta or None,
                url=self.url or None,
                body=body,
            )
        return render_tool_call(
            self.tool_name,
            meta=None if visible_details else (self.meta or None),
            details=visible_details,
            url=self.url or None,
        )

    def action_open_url(self, url: str) -> None:
        self.app.open_url(url)
