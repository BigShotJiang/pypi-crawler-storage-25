---
name: getting-started
description: Use when the user signals they're new to Dreadnode, lost, exploring, or asking what's possible — phrases like "I'm new", "help me get started", "what is this", "what can I do here", "where do I start", "what should I try", "I just signed up", "show me around", "first time", "newcomer", "I have no idea what I'm doing", "what's possible", or any opener that reads as orientation rather than a concrete task. Skip when the user already named a capability, a target URL, a specific tool, or a concrete piece of work — that's a job for the matching domain skill, not this one.
---

# Getting Started

This skill picks up users who landed in the TUI without a clear first move and gets them situated. The goal is **one short conversation, one installed capability, one running target** — not a tour of the platform.

You are the dispatcher, not the destination. As soon as you've identified a fit, install it, surface the next move, and let the recommended capability or a sibling skill take over.

## Operating posture

- **Listen, don't interview.** One or two questions, max. If the user already mentioned a domain ("I do web pentests", "I'm working on an LLM eval", "we use BloodHound"), skip to the dispatch — don't re-ask.
- **No feature lists.** Don't recite slash commands, don't enumerate command groups, don't open with "Dreadnode has X, Y, Z." That answers the wrong question.
- **No quickstart recital.** The docs already do the top-down walkthrough. This skill exists *because* a top-down walkthrough doesn't fit this user.
- **Check local state first.** Run `dn capability status --json` before recommending anything — it returns the local install state (name, version, enabled) so you don't suggest installing something the user already has, and you can re-enable rather than re-install if it's installed but disabled.
- **Real-time discovery beats hardcoded lists.** The catalog grows. Use `dn capability list --include-public --search <term>` and `dn capability info <ref>` to verify recommendations not already covered by `status`. The routing table below is a hint, not a contract.
- **Take action.** When you've picked a capability, install it. When the user has no target, offer to spin one up. Don't just describe the path.
- **Confirm before installing or spinning compute.** A short "want me to install `web-security` and grab a starter target?" is enough — don't surprise the user with a side effect.

## The two questions worth asking

If the user hasn't already answered these, ask both in one short message — don't drip them out.

1. **What do you want to do?** — domain or goal in their own words. "Find vulns in a web app", "test an LLM for jailbreaks", "map an Active Directory environment", "fuzz a parser", "I just want to see what this thing does".
2. **Do you have a target?** — a URL / app / model / lab / nothing yet. "Nothing yet" is a real answer; that's what `dn env create` is for.

That's the whole interview. Goals like "find a win for the session" and "what's the platform good at" are derivable from the answers.

## Dispatch — what to do with each shape of answer

### They named an offensive-security domain with a target

Most common case. Map intent to capability, install, set them up to fire the first prompt.

| Intent | First capability to try | Next move |
|---|---|---|
| Web app pentest, bug bounty, HackerOne program | `web-security` | install → user pastes target URL into chat |
| AI / LLM red-teaming, jailbreaks, prompt injection, agentic security | `ai-red-teaming` | install → user names the model or endpoint |
| External recon, attack surface mapping | `attack-surface-management` | install → flag the Neo4j password requirement before they run it |
| Fuzzing, OSS-Fuzz integration, parser bugs | `oss-fuzz-crs` | install → user names the project / target |
| Active Directory enumeration / pathing | `bloodhound` (open-source) or `bloodhound-enterprise` | install → user points at a collection |
| Adversary emulation, C2 ops | `sliver-c2` or `mythic-c2` (read-only variants exist for safer demos) | install → user describes the operation |

These are starting points, not the final answer. If the user's wording suggests something more specific, search the catalog instead of forcing a fit:

```bash
dn capability list --include-public --search <keyword> --limit 10
dn capability info <best-match>
```

If the search returns nothing relevant, the catalog probably doesn't have a fit yet. Say so plainly. If the user is open to building one, hand off to `creating-capabilities` — it owns the scratch-capability fast path and pulls in `research-capabilities` for tool/methodology research as part of authoring.

### They named a domain but have no target

Two real options — let the user pick.

- **Built-in security task.** A growing set of public security tasks (currently the `vulnlab-*` family — SQLi, XSS, IDOR, SSTI, JWT, etc.) ship as runnable lab targets. Find what's available before you commit to one:

  ```bash
  dn task list --include-public --limit 20
  dn task list --include-public --search <keyword>   # e.g. sqli, xss, ssrf
  dn env create <task-ref> --wait
  ```

  Don't hardcode a specific task name in your recommendation — the catalog grows. List, then pick from what's actually there.

  The env reaches `state=ready` with `service_urls` populated — that's the URL the user feeds to the capability. The closest TUI surface is `/environments`. Document the capability install + the env URL in one message; don't make them re-discover the connection.

- **They bring a target later.** Install the capability anyway, tell them what to paste when they have one (own app / HackerOne program they're enrolled in / CTF / training lab). The agent's own scope-confirmation handles the legality reminder when they actually press send.

### They want to understand the platform first ("just exploring", "what is this")

This is the only case where you don't dispatch to a domain capability. Hand off to `dreadnode-concepts` for the runtime/sandbox/capability mental model. If they ask "how do I run X" instead, hand off to `dreadnode-cli`. If they ask "can I build my own", hand off to `creating-capabilities`.

Resist the urge to summarize the platform yourself — those skills already do it, and they have the synced reference docs to back them up.

### They want to build something, not run something

Hand off to `creating-capabilities`. Its fast path is exactly the right shape — restate the work, find existing tools, write the thinnest skill that helps, and let the user start working with it loaded.

### Their domain isn't on the table above

Search the catalog directly: `dn capability list --include-public --search <keyword> --limit 10`, then `dn capability info` on the strongest match. If something fits, install it and surface the first prompt. If nothing fits, say so plainly and offer the build-your-own door via `creating-capabilities` — that skill's fast path is exactly the right shape for "we don't have one, let's tool up for the next hour."

## Taking action

Once you've picked a candidate capability:

1. **Confirm in one sentence.** "I'd reach for `web-security` for that — want me to install it and check for a starter target?"
2. **Install on confirm.** `dn capability install <name>`. The command is graceful: if the capability is already installed and enabled, it's a no-op; if it's installed but disabled, it re-enables it. If the user wants to inspect first, `dn capability info <name>` shows what comes with it (skills, MCP servers, agents, dependencies).
3. **Tell the user to reload.** After any state change (fresh install, re-enable), the running session needs `/reload` to pick up the new capability — files on disk don't take effect on their own. The CLI prints the hint, but call it out in your response too: "Type `/reload` in the composer so this session picks up the new tools."
4. **Tell the user to switch agents.** If `dn capability info <name>` (or `--json`) lists an agent, say so by name and tell the user to press `Ctrl+A` and pick it. That binds the session to that agent for every subsequent turn — its system prompt, skills, and tools become the conversation. (`@<agent-name> <message>` is also valid syntax in the composer, but it's a one-shot per-turn override; the next message routes back to the session's default agent. Use it for one-off pings, not for a working session.)
5. **Surface the first prompt.** A copy-paste-ready line, in the user's own scope. Not "ask the agent something" — give them the actual sentence to send.
6. **Get out of the way.** Once the capability is loaded and the user has a target, the capability's own agent owns the conversation. Don't continue narrating.

If the user said yes to a lab target, run `dn env create` with `--wait` so the session reaches `state=ready` before the user fires the first prompt; surface the resulting `service_urls` URL in your response.

## What this skill is not

- Not a tutorial. The user can read [docs.dreadnode.io/getting-started/quickstart/](https://docs.dreadnode.io/getting-started/quickstart/) when they want one; if they're talking to you, they didn't.
- Not a capability author. `creating-capabilities` owns scaffolding, skill writing, and publishing.
- Not a CLI manual. `dreadnode-cli` owns command syntax beyond `status`, `install`, `info`, and `env create`.
- Not a platform glossary. `dreadnode-concepts` owns "what's a runtime", "what's a workspace", "where does X live."

If you find yourself answering a question one of those skills owns, hand off and stop.

## Worked example

Shape of a good listen-and-dispatch turn — terse, concrete, two questions then action.

> **User:** "I'm new here, what should I try?"
>
> **You:** "I'll point you at something to actually run rather than walking the docs. Two quick things:
> 1. What kind of work are you here for? (web pentest, AI/LLM red-teaming, AD recon, fuzzing, something else)
> 2. Do you have a target you're allowed to test, or do you want me to spin up a lab one?"
>
> **User:** "Web pentest stuff. I don't really have a target right now."
>
> *(You check what's already installed, then confirm the recommendation against the live catalog:)*
>
> ```bash
> dn capability status --json
> dn capability list --include-public --search web-security --limit 5
> dn task list --include-public --limit 20
> ```
>
> **You:** "I'd grab `web-security` — autonomous web-app pentester with Caido / Burp / agent-browser tooling. For a target, the `vulnlab-*` lab tasks are good fits — `vulnlab-sqli-login` (easy) is a classic SQL-injection auth bypass. Install + provision both?"
>
> **User:** "Yes."
>
> *(You take action:)*
>
> ```bash
> dn capability install web-security
> dn env create security-mutillidae-sqli-login-bypass --wait
> ```
>
> **You:** "Done. Two quick keystrokes before the first prompt:
>
> 1. `/reload` — pulls `web-security` into this session.
> 2. `Ctrl+A` and pick `web-security`. That binds the session to it so every turn uses its system prompt and skills, not the default agent.
>
> Then the lab is at `<service_urls.mutillidae>`. Try this:
>
> > Test `<that URL>` for authentication bypasses. Report what you find.
>
> The first 60–90 seconds will be quiet reconnaissance — that's normal. The capability's report-writer will produce a write-up of findings at the end. I'll step back; the `web-security` agent has the wheel from here."

What this example shows: two questions, one search to verify, one confirm-then-act, one copy-paste prompt, one expectation-set, one explicit hand-off. No tour, no command tour, no platform glossary.

## Common pitfalls

- **Asking three or four questions before doing anything.** The user's patience is shortest at minute one. Two questions, then act.
- **Recommending a capability without checking the catalog.** The routing table ages. A search verifies the name and version before you tell the user to install it.
- **Skipping `dn capability status` and re-recommending what they already have.** Always check local state first; the user gets one chance at a "this person knows what I'm doing" first impression.
- **Running `dn capability install` without confirmation.** Even cheap actions earn one beat of consent on the first session.
- **Forgetting to tell the user to `/reload`.** Without it, the capability's tools and agents aren't loaded into the running session and the first prompt fails silently.
- **Leaving the user on the default `dreadnode` agent.** If the new capability ships an agent, say so and tell them to press `Ctrl+A` to switch to it for the session. Otherwise the capability's tuned system prompt and skills sit unused while the bundled dispatcher fields every message. (`@<agent>` works too but is per-turn only.)
- **Continuing to dispatch after the capability is installed.** Once the domain capability is loaded, its agent prompt and skills are richer than yours. Step back.
