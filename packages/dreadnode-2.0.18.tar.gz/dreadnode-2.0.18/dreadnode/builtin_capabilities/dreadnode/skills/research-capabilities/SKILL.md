---
name: research-capabilities
description: Use when the user needs to know what tools, methodologies, MCP servers, libraries, or existing Dreadnode capabilities already exist for a piece of work — before building, extending, or picking between approaches. Also handles standalone "what's out there for X" questions. Domain lean is offensive security, red teaming, vuln research, RE, OSINT, and AI security.
---

# Researching Capabilities

Research that ends in a recommendation the user can act on. Invoked from `creating-capabilities` (Step 2) and `promoting-capabilities`. Valid standalone when a user asks "what tools exist for X" without committing to build anything.

Domain lean is **AI + offensive security**. Mechanic works on adjacent domains; the source lists below are just where to look first.

## Research in parallel

Fire these as parallel queries, not a serial walk:

- **Methodology** — HackTricks, PayloadsAllTheThings, OWASP (top-10, agentic, MASVS), AtomicRedTeam, MITRE ATT&CK, vendor playbooks, recent write-ups from Unit 42 / Wiz / XBOW / Praetorian / PromptArmor. The shape of good work for a domain usually already exists.
- **Tools / CLIs** — GitHub topic search and the CLIs you'd expect for the domain (`skopeo`, `nmap`, `semgrep`, `nuclei`, `trufflehog`, `jadx`, `ghidra`, `bloodhound`, `caido`, …).
- **MCP servers** — MCP registries, GitHub `mcp-server` topic, domain-specific MCP repos (ghidra-mcp, binaryninja-mcp, burp-ai-agent).
- **Existing Dreadnode capabilities** — `ls ~/.dreadnode/capabilities/` and the catalog. Sometimes the thing already exists and the answer is "install, don't build."
- **Recent signal** — blog posts and arXiv from the last 6–12 months. Fast-moving field; look for named techniques, not just tools.

Empty slots are fine.

## Know what you're reading

First-party vendor docs and actively-maintained OSS repos are the trustworthy tier. Papers with replication and labs with a track record (XBOW, Anthropic red team, Praetorian, Unit 42) are the next tier. Single-post sites, stale forks, and unsigned writeups are the "mention but don't recommend" tier. Security work lives or dies on whether the source is trustworthy — think about it; don't just collect hits.

Never auto-install an external MCP server or skill you haven't eyeballed. Supply-chain risk is real — the output of research is a recommendation, not a dependency graph.

## Take a position

The output is a short message in chat: restate the target, name 3–6 candidates worth knowing about with a one-line note on each (including where it came from), then the one you'd reach for and why over the runner-up.

If there isn't enough signal to recommend, say that plainly — "nothing authoritative here; I'd check X manually" is a valid answer. A shortlist without a pick is reflection, not research.

## Verify only what the recommendation hinges on

If the pick depends on a tool being installed or a repo still being alive, one quick check earns its keep:

- `which <cli>` — is the tool actually here?
- `gh repo view <repo>` — recent commits?
- `curl --head <url>` — page still there?

Not every candidate. Just the one the recommendation stands on.
