<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/getting-started/quickstart.mdx -->
<!-- public: https://docs.dreadnode.io/getting-started/quickstart/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Quickstart

> Install Dreadnode, install web-security, and run your first authorized web pentest from the TUI.

Install the CLI, install the `web-security` capability, point it at a target you’re authorized to test, and let the agent work until it produces a report. About fifteen minutes end-to-end.

Working on AI red teaming?

Skip ahead to the [AI Red Teaming guide](https://docs.dreadnode.io/ai-red-teaming/getting-started/tui/) — different flow, different target model.

1. **Install the CLI.**

   Terminal window

   ```
   curl -fsSL https://dreadnode.io/install.sh | bash
   ```

   The installer drops a single binary at `~/.local/bin/dn` (also exposed as `dreadnode`) on macOS and Linux. Confirm:

   Terminal window

   ```
   dn --version
   ```

   Already in a Python project?

   `pip install -U dreadnode` installs the same TUI, CLI, and SDK from PyPI.

2. **Sign in.**

   Terminal window

   ```
   dn
   ```

   The TUI opens an authentication modal — press **1** for browser login or **2** to paste a Dreadnode API key. Browser login starts a device-code flow, opens your browser, and polls for confirmation. New accounts go through onboarding (pick a username, name an organization on SaaS) and land on a default workspace and project. Starter credits attach automatically.

   

3. **Install `web-security`.**

   Press `Ctrl+P` to open the capability browser, type `web-security` to filter, then press `Enter` to open its details:

   

   Pick **Install** from the action menu (or **Enable capability** if it’s already installed). The capability ships an autonomous OODA-loop pentester, a built-in headless browser, and 42 skills covering request smuggling, cache poisoning, SSRF, SSTI, DOM vulnerabilities, OAuth abuse, and parser differentials.

   Prefer the command line? Same result, no UI:

   Terminal window

   ```
   dn capability install dreadnode/web-security
   ```

   MCP warnings are normal

   Optional integrations (Caido, Burp, HackerOne) load when their dependencies are present and degrade quietly when they aren’t. A `⚠ burp (/mcp)` line in the status bar means Burp wasn’t running — the agent will skip that path and use the built-in HTTP client instead.

   Switch the agent on with a slash command (or press `Ctrl+A` and pick from the list):

   ```
   /agent web-security
   ```

4. **Send a target.**

   Type your target into the composer and press `Enter`:

   ```
   test the /api/v1/auth flow on https://target.example for vulnerabilities — full scope
   ```

   Concrete prompts beat vague ones. Name the stack (`Django`, `Next.js`, `Laravel`) if you know it. Name the surface you care about (`auth flow`, `file uploads`, `admin panel`) if there’s one to focus on. If you genuinely don’t know where to start, ask plainly — `what should I try here?` — and the agent will pick a thread from what it can see.

   Test only what you're authorized to test

   The agent will probe aggressively — only point it at a web app you own or deploy, a HackerOne / Bugcrowd program you’re enrolled in, or a CTF / training target you have permission to attack (HackTheBox, PortSwigger Web Security Academy, or the public Acunetix testbed at `http://testphp.vulnweb.com`). Unscoped testing is your problem, not ours.

5. **Watch the OODA loop.**

   The agent runs in continuous OODA cycles — observe, orient, decide, act. You’ll see a todo list form, then a stream of HTTP probes, fingerprints, and exploit attempts:

   

   Expect a quiet first minute or two while reconnaissance runs. A real engagement is forty minutes of patient work, not four — silence isn’t failure, it’s the agent reading responses you can’t see.

   Findings surface as **leads** (hypotheses with partial evidence) before they’re promoted to confirmed vulnerabilities. When you see one, press for proof: `show me the request and response that confirms it`. If the agent can’t, it’s still a lead.

   You stay in control:

   | Key                   | What it does                              |
   | --------------------- | ----------------------------------------- |
   | `Esc`                 | Interrupt mid-thought                     |
   | `/thinking high`      | Bump reasoning effort                     |
   | `@web-security <msg>` | Redirect the agent without ending the run |
   | `Ctrl+O`              | Toggle compact / expanded tool details    |

6. **Receive the report.**

   Confirmed findings land in `reports/R<NNN>-<slug>.md` in your working directory — markdown with title, CVSS scores, reproduction steps, evidence, and recommendations. The body scrolls inline as the agent writes it.

   The whole session is also persisted. Press `Ctrl+B` to list every conversation you’ve run; the active one is tagged at the top:

   

   From here:

   * `Enter` jumps back into any prior session
   * `N` starts a fresh session
   * `D` deletes a session
   * `Ctrl+T` opens the trace browser when you need every span and tool call

   If the agent hits a genuine dead end before finding anything reportable, it says so. The session is still saved end-to-end and replayable, which is often what you actually want from a recon pass.

## What’s next

The natural fast-follow is **building your own capability** — same shape as `web-security`, but specialized for the work you actually do. Ten minutes from `dn capability init` to a runnable agent.

[Build your own capability](https://docs.dreadnode.io/capabilities/quickstart/)

Looking for something else? Browse the [full capability catalog](../capabilities/installing.md) for network ops, recon, and AI red teaming bundles, or read the [AI Red Teaming guide](https://docs.dreadnode.io/ai-red-teaming/) for model-target work.
