<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/runtimes/quickstart.mdx -->
<!-- public: https://docs.dreadnode.io/runtimes/quickstart/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Quickstart

> Create a runtime, start it, run a prompt against it, and pause it — end-to-end in five commands.

Go from nothing to a running sandbox backing an interactive session, then pause it cleanly so credits stop accruing.

## Prerequisites

* The Dreadnode CLI authenticated (`dn login`) — see [Authentication](../getting-started/authentication.md)
* A workspace scope on your active profile (`dn profile show`)

## 1. Create the runtime

Terminal window

```
dn runtime create my-runtime --key scratch --name "Scratch Runtime"
```

```
✓ Created runtime 'Scratch Runtime' in project 'my-runtime'
7c1e2d4f-...  idle  Scratch Runtime (scratch)  my-runtime
```

`create` is idempotent. Running it again with the same key returns the existing runtime instead of failing.

If you omit `<project>`, the CLI uses the active project scope from your profile, then falls back to the workspace default project.

## 2. Start it

Terminal window

```
dn runtime start 7c1e2d4f
```

```
✓ Started runtime 'Scratch Runtime'
7c1e2d4f-...  running  Scratch Runtime (scratch)  my-runtime
URL:   https://sandbox-xyz.e2b.dev
```

Starting provisions a sandbox, links it to the runtime, and returns a sandbox URL you can use for provider-level operations.

UUID prefix matching works anywhere an ID is expected — the first eight characters are enough.

## 3. Run a one-shot prompt against it

Terminal window

```
dn --print --prompt "list files in /workspace" --model openai/gpt-4.1-mini
```

The default `dn` command opens the interactive app. `--print` runs one turn against your runtime and exits — useful for smoke tests and scripting.

To open the full interactive app instead, just run `dn`.

## 4. Keep it alive while you work

Terminal window

```
dn sandbox list --state running
```

Each sandbox has an expiry window. If you’re working in longer bursts, the [TUI runtimes screen](./managing.md) has a one-keystroke extend action, or you can call the keepalive action from the App.

## 5. Pause when you’re done

Pause from the TUI (`Ctrl+R`, select the runtime, press pause) or the App to stop credit accrual while preserving sandbox state. Resume the same way — no state is lost, capability bindings are intact, and session history comes back with the runtime.

When you want a clean environment again, `reset` discards the sandbox and returns the runtime to `idle` without losing the runtime’s identity, bindings, or project association.

## What to reach for next

* Author a `runtime.yaml` so the configuration lives in source → [Configuration](./configuration.md)
* Learn the full lifecycle (pause, resume, reset, keepalive, connect) → [Managing runtimes](./managing.md)
* Install a capability bundle on the runtime → [Capabilities](../capabilities/overview.md)
* Inspect the sandbox behind the runtime → [Sandboxes](../sandboxes/overview.md)
* Browse every CLI flag → [`dn runtime`](https://docs.dreadnode.io/cli/runtime/)
