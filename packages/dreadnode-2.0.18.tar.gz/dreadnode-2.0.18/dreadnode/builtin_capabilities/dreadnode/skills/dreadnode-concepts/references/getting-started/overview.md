<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/getting-started/overview.mdx -->
<!-- public: https://docs.dreadnode.io/getting-started/overview/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Overview

> Dreadnode is a terminal-native platform for offensive security agents — install once, drop into a TUI, run your first authorized pentest from the same place you write code.

Dreadnode is a terminal-native platform for offensive security agents. You install one binary, drop into a TUI in any project, and drive the whole workflow — running pentests, building capabilities, evaluating models, inspecting traces — from the same terminal you already work in.

## What you’ll end up with

After the [Quickstart](./quickstart.md), you have:

* a logged-in TUI with starter credits attached to your default workspace and project
* the `web-security` capability installed and runnable against any target you’re authorized to test
* a session you can replay end-to-end via `/sessions`
* a markdown vulnerability report in `reports/` for any confirmed findings the agent produced

That’s the first-value path. Everything below extends it.

## Start here

* **[Quickstart](./quickstart.md)** — install, log in, install `web-security`, run your first pentest.
* **[Authentication](./authentication.md)** — profiles, workspaces, BYOK provider keys, machine credentials for CI.
* **[AI Red Teaming](https://docs.dreadnode.io/ai-red-teaming/getting-started/tui/)** — different audience, different flow. If you’re testing model targets, start there.
* **[Self-hosting](https://docs.dreadnode.io/self-hosting/)** — deploy the platform on your own Kubernetes cluster.

## What the TUI gives you on day one

A fresh TUI has everything needed for a useful first conversation. You can map an unfamiliar target, draft a test plan, or run a tool call against a local repo without installing anything else.

* **[Default tools](https://docs.dreadnode.io/tui/default-tools/)** — file read/write, shell, web search, multi-page extraction, direct fetch, and the rest of the standard pool.
* **[Capabilities](../capabilities/overview.md)** — bundles of agents, tools, skills, and MCP servers that specialize the TUI for web pentesting, AI red teaming, network ops, or vuln research.
* **[Chat models](../platform/chat-models.md)** — hosted Dreadnode models plus BYOK access to Anthropic, OpenAI, Google, and others.
* **[Traces & analysis](https://docs.dreadnode.io/tui/analysis/)** — replay every tool call, span, and model turn for any session.

Press `?` inside the TUI for live keybindings and slash-command help.

Tip

`dn` is installed as an alias for `dreadnode` — both run the same binary. The rest of these docs use `dn` for brevity.
