<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/platform/users.mdx -->
<!-- public: https://docs.dreadnode.io/platform/users/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Users

> Deployment-wide platform-admin tools for managing user accounts, roles, and access.

Platform administrators can manage users across the entire deployment from the admin dashboard.

This page is the deployment-wide admin surface. It is not the same as organization membership management or workspace sharing.

Note

The platform-admin area is a separate `/admin` surface with its own navigation for `Organizations`, `Users`, and admin `Billing`. It is not the org-scoped settings shell.

## Scope and boundary

Use user administration when you need to:

* search for a user across the whole deployment
* inspect their top-level account record and organization memberships
* grant or revoke platform-admin access
* delete an account at the deployment level

Do not use this page when you only need to add someone to an organization or grant workspace access. Those flows belong under [Organizations](./organizations.md) and [Workspaces](./workspaces.md).

## What the user detail workflow includes

The current admin user flow is:

1. open the deployment-wide user list from the admin sidebar
2. inspect one account’s top-level state, email verification, and platform-admin status
3. review that user’s organization memberships
4. decide whether to verify email, change platform-admin role, or delete the account

That is a much broader scope than any one organization page.

The concrete actions in the current detail view include `Verify Email`, platform-admin role changes, and destructive delete operations.

## List users

View a paginated list of all users. Supports search by identity fields and sorting for operations work.

## User details

View detailed information about a specific user, including:

* email and onboarding state
* whether the account is a service account or a human user
* whether the user already has platform-admin privileges
* organization memberships and their active or inactive state

## Delete a user

Permanently delete a user account. This action cannot be undone.

Deleting a deployment user is much broader than removing them from one organization. Use it carefully.

## Grant or revoke platform admin role

Update whether a user has the `platform-admin` role.

Safety rules:

* You cannot modify your own role
* You cannot modify platform owners
* Only platform owners can revoke `platform-admin` from an existing admin
* Grant/revoke operations are idempotent (no error if role is already in the desired state)

## Operational boundary

Use this page for deployment-wide account governance.

Do not use it for:

* inviting a teammate into one org
* changing workspace permissions
* configuring org billing or org limits

## What agents should assume

* This is a deployment admin surface, not a tenant-scoped membership page.
* Organization roles and workspace permissions are separate from platform-admin status.
* Safety checks around self-modification and platform owners are part of the intended contract.
* The admin area groups `Organizations`, `Users`, and admin `Billing` because those are deployment-wide controls.

Use [Manage overview](./overview.md) for the larger boundary model, [Organizations](./organizations.md) for tenant membership, and [Workspaces](./workspaces.md) for sharing and permission boundaries inside one org.
