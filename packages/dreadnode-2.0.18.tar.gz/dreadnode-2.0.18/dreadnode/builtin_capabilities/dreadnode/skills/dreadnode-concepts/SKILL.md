---
name: dreadnode-concepts
description: Use when the user asks how Dreadnode itself works — platform hierarchy (orgs/workspaces/projects), the runtime/sandbox split, where capabilities install on disk, what the bundled default agent is, how authentication and profiles resolve, what `~/.dreadnode/` contains, or any "how do I find/configure X in Dreadnode" question that isn't about a specific CLI command.
---

# Dreadnode Concepts

This skill answers "how does the platform itself work" questions. It complements `dreadnode-cli` (exact commands) and `creating-capabilities` (authoring) by covering the *concepts* an agent needs to explain Dreadnode to users.

## When to use this skill

- "How does Dreadnode organize my work?" — organizations, workspaces, projects
- "What's the difference between a runtime and a sandbox?"
- "Where does Dreadnode store config / capabilities / cache?"
- "What is the `dreadnode` capability — the bundled one?"
- "How does login / profile / scope resolution work?"
- "What can the TUI do out of the box?"

## When *not* to use this skill

- The user wants exact CLI syntax → use `dreadnode-cli`
- The user wants to author or extend a capability → use `creating-capabilities`
- The user is asking about a specific evaluation, AIRT workflow, or domain capability → defer to that capability's own skills

## Reference material

The full platform reference is bundled under `references/` — synced from the public docs. Read on demand:

| If the user asks about… | Read |
|---|---|
| What Dreadnode is, the day-one TUI experience | `references/getting-started/overview.md` |
| Installing, first session, common workflows | `references/getting-started/quickstart.md` |
| Login, profiles, scope resolution, BYOK keys | `references/getting-started/authentication.md` |
| Platform hierarchy: organizations, workspaces, projects, users | `references/platform/{overview,organizations,workspaces,projects,users}.md` |
| Chat models, credits, secrets, settings | `references/platform/{chat-models,credits,secrets,settings}.md` |
| The runtime/sandbox split, lifecycle, states | `references/runtimes/overview.md` |
| Starting, pausing, resuming, resetting runtimes | `references/runtimes/managing.md` |
| Runtime configuration that persists across sandbox replacement | `references/runtimes/configuration.md` |
| Local runtime hosting (`dn serve`) | `references/runtimes/serve.md` |
| Sandbox inspection (logs, usage) | `references/sandboxes/{overview,inspecting}.md` |
| What capabilities are, the install model | `references/capabilities/{overview,installing}.md` |

## Mental model summary

Three independent lifecycles every agent answer should keep straight:

- **Runtime** — the durable thing: holds your sessions, capability bindings, and project context. You control it.
- **Sandbox** — the disposable compute underneath the runtime. You pay for it. Provisioned lazily on `start`.
- **Session** — the conversation thread you resume.

If you talk about them as one object, every reset looks like lost work. They are deliberately split.

## Local file layout

- `~/.dreadnode/` — user config and local data
  - `~/.dreadnode/config.yaml` — platform profiles and authentication
  - `~/.dreadnode/capabilities/` — locally installed capabilities (symlinks for `dn capability install <local-path>`)
  - `~/.dreadnode/cache/` — cached data and sessions
- `.dreadnode/` in a project root — project-local configuration
  - `.dreadnode/capabilities/` — project-scoped capabilities

## The bundled `dreadnode` capability

Bare chat in the TUI talks to the bundled `dreadnode` capability — a real capability that ships inside the SDK wheel and loads automatically. `@dreadnode` is the explicit way to route to it; `default` is only a fallback label for pre-load or degraded states.

For where to edit the bundled capability's behavior, the maintenance contract, and the host-vs-capability ownership split, the canonical doc is the `runtime-default-capability.md` companion in the `creating-capabilities` skill (since that's where someone editing it will be working).

## Answering pattern

1. Identify which concept the user is reaching for.
2. Read the matching `references/**/*.md` page if you're not certain of the current details — the references regenerate from the public docs.
3. Answer in product terms (organizations, workspaces, runtimes, sessions, capabilities, sandboxes).
4. If the answer needs a specific command, hand off to `dreadnode-cli`.
5. If the question is "where do I edit this in code," name the path explicitly.
