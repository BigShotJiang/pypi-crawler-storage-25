<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/sandboxes/inspecting.mdx -->
<!-- public: https://docs.dreadnode.io/sandboxes/inspecting/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Inspecting compute

> List, inspect, fetch logs from, and clean up hosted sandboxes with the dn sandbox CLI.

When an evaluation, optimization job, training run, or runtime looks stuck, the `dn sandbox` CLI is the fastest way to see whether the underlying compute is still alive — and to clean it up when it isn’t.

## What you can do

Terminal window

```
dn sandbox list --state running
dn sandbox get <provider-sandbox-id>
dn sandbox logs <provider-sandbox-id>
dn sandbox usage --json
dn sandbox delete --yes <provider-sandbox-id>
```

All `get`, `logs`, and `delete` commands take the **provider sandbox ID**, not the internal Dreadnode UUID.

Note

A 404 from `dn sandbox get` or `dn sandbox delete` usually means you passed the internal sandbox UUID instead of the `provider_sandbox_id` surfaced on runtime and evaluation records.

## List what’s running

Terminal window

```
# default view: every sandbox, newest first
dn sandbox list

# filter by state — repeatable
dn sandbox list --state running
dn sandbox list --state paused --state killed

# filter by project (explicit UUID only; not the project key)
dn sandbox list --project-id 11111111-2222-3333-4444-555555555555

# scripting
dn sandbox list --json
```

`--state` is repeatable and can also be passed as a comma-separated list. The list uses your active organization scope and does not apply a project filter unless you pass one.

## Inspect one sandbox

Terminal window

```
dn sandbox get <provider-sandbox-id>
dn sandbox get <provider-sandbox-id> --json
```

`get` returns kind, state, provider identity, timing, and billing totals — billed credits, running credits, and estimated total.

## Fetch server logs

Terminal window

```
dn sandbox logs <provider-sandbox-id>
```

Use this when an evaluation sample hangs, an interactive session goes unresponsive, or a training run dies without a clear error. The logs are what the sandbox’s runtime server emitted, streamed back to you.

## See org-level usage

Terminal window

```
dn sandbox usage
dn sandbox usage --json
```

`usage` aggregates runtime seconds, session counts, and current-month usage across every sandbox in your active organization. Use it when you want the compute summary rather than inspecting a single sandbox.

## Clean up

Terminal window

```
# prompts for confirmation
dn sandbox delete <provider-sandbox-id>

# skip the prompt — useful for scripts
dn sandbox delete --yes <provider-sandbox-id>
```

Delete transitions the sandbox to `killed` and releases its provider instance. The record stays for billing and audit; only the compute is gone.

## Common diagnostic flows

* **Evaluation sample stuck** → `dn evaluation list-samples --status running` → find the agent sandbox ID → `dn sandbox logs`
* **Runtime unresponsive** → `dn runtime get <id>` to find the provider sandbox ID → `dn sandbox logs`
* **Unexpected credit burn** → `dn sandbox list --state running` to see what’s live → `dn sandbox usage` for the aggregate
* **Orphaned compute after a failed run** → `dn sandbox list --state running` with `--project-id` → `dn sandbox delete --yes`

## See also

* [Sandboxes overview](./overview.md) — kinds, states, and billing semantics
* [Managing runtimes](../runtimes/managing.md) — when compute belongs to an interactive runtime
* [`dn sandbox` reference](https://docs.dreadnode.io/cli/sandbox/) — every flag and output shape
