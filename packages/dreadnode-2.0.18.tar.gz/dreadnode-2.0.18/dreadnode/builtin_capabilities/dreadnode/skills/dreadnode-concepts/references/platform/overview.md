<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/platform/overview.mdx -->
<!-- public: https://docs.dreadnode.io/platform/overview/ -->
<!-- bundle: dreadnode-concepts.json (regenerate via `just docs sync` or pre-commit) -->

# Manage

> The org, workspace, and project context behind the platform, plus the settings, secrets, credits, and user controls that govern it.

Manage is where the platform’s boundary model and operator controls come together.

Use it when the question is:

* which organization, workspace, or project am I actually working in?
* who can access this area?
* where do settings, chat models, secrets, credits, and user administration live?

Note

This is the context and control layer around the product surfaces. Evaluations, analytics, and training jobs execute elsewhere.

## Context chain

```
Organization
  -> Workspace
     -> Project
        -> Workflow surfaces
```

| Layer or control surface | Primary role                                                     |
| ------------------------ | ---------------------------------------------------------------- |
| Organization             | top-level ownership, membership, and billing boundary            |
| Workspace                | access boundary and collaboration area                           |
| Project                  | grouping context for runs, traces, evaluations, and related work |
| Settings                 | org-facing configuration pages in the app                        |
| Chat Models              | user-scoped assistant model preferences                          |
| Secrets                  | user-owned credentials injected into compute                     |
| Credits                  | SaaS usage and billing controls                                  |
| Users                    | deployment-wide user and platform-admin state                    |

## Where control actually lives

Not every admin-looking surface lives in the same place.

| Surface family | Scope                                  | Typical examples                                                |
| -------------- | -------------------------------------- | --------------------------------------------------------------- |
| Settings shell | current organization plus current user | General, Members, Workspaces, Secrets, Chat Models, Billing     |
| Platform Admin | whole deployment                       | Organizations, Users, and admin Billing under the `/admin` area |

The same person may be an org owner without being a deployment-wide platform admin.

## Common workflows

* confirm the correct org, workspace, and project before launching work
* update access boundaries and sharing rules
* manage provider credentials, model preferences, and billing controls
* answer “why can this person see this?” or “why did this workload run here?”
* leave the org-scoped settings shell and move to `/admin` when the question is deployment-wide rather than tenant-specific

## What agents should assume

* organization, workspace, and project materially change what artifacts and runs are visible
* projects are context, not permission boundaries
* settings is a shell that groups several operator surfaces rather than one API object
* deployment admin is a separate surface from org settings, even if both feel administrative

For the individual control surfaces, use [Settings](./settings.md), [Organizations](./organizations.md), [Workspaces](./workspaces.md), [Projects](./projects.md), [Secrets](./secrets.md), [Chat models](./chat-models.md), [Credits](./credits.md), and [Users](./users.md).
