<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/sandbox.mdx -->
<!-- public: https://docs.dreadnode.io/cli/sandbox/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Sandboxes

> Inspect and manage platform sandboxes.

Terminal window

```
$ dn sandbox <command>
```

Inspect platform sandboxes.

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## list

Terminal window

```
$ dn sandbox list
```

List sandboxes for the active organization.

**Options**

* `--state`, `--status` — Filter by sandbox state (repeatable: running, paused, killed)
* `--limit` *(default `50`)* — Maximum sandboxes to return
* `--cursor` — Pagination cursor from a previous list response
* `--project-id` — Optional explicit project UUID to filter sandboxes
* `--json` *(default `False`)*

## get

Terminal window

```
$ dn sandbox get <sandbox-id>
```

Get sandbox details by provider sandbox ID.

**Options**

* `<sandbox-id>`, `--sandbox-id` *(**Required**)*
* `--json` *(default `False`)*

## logs

Terminal window

```
$ dn sandbox logs <sandbox-id>
```

Get sandbox server logs by provider sandbox ID.

**Options**

* `<sandbox-id>`, `--sandbox-id` *(**Required**)*

## usage

Terminal window

```
$ dn sandbox usage
```

Get aggregate sandbox usage for the active organization.

**Options**

* `--json` *(default `False`)*

## delete

*Aliases: `rm`*

Terminal window

```
$ dn sandbox delete <sandbox-id>
```

Delete (kill) a sandbox by provider sandbox ID.

**Options**

* `<sandbox-id>`, `--sandbox-id` *(**Required**)*
* `--yes`, `-y` *(default `False`)*
