<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/runtime.mdx -->
<!-- public: https://docs.dreadnode.io/cli/runtime/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Runtimes

> Manage agent runtime environments.

Terminal window

```
$ dn runtime <command>
```

Manage agent runtime environments.

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## list

*Aliases: `ls`*

Terminal window

```
$ dn runtime list
```

List available runtimes.

**Options**

* `--json` *(default `False`)*

## get

Terminal window

```
$ dn runtime get <runtime-id>
```

Get details of a runtime.

**Options**

* `<runtime-id>`, `--runtime-id` *(**Required**)*
* `--json` *(default `False`)*

## create

*Aliases: `new`*

Terminal window

```
$ dn runtime create
```

Ensure a runtime exists for a project or the workspace default project.

**Options**

* `<project-ref>`, `--project-ref` — Project key or UUID. Defaults to the active project scope, then workspace default.
* `--key` — Runtime key. Required with —name when no project is resolved.
* `--name` — Runtime display name. Required with —key when no project is resolved.
* `--description` — Optional runtime description.
* `--file` — Load runtime.yaml from a file or directory.
* `--json` *(default `False`)*

## start

Terminal window

```
$ dn runtime start
```

Start a runtime, creating it first when the target flow requires it.

**Options**

* `<target>`, `--target` — Runtime UUID or project key/UUID. Defaults to the active project scope.
* `--runtime-id` — Start a specific runtime by UUID.
* `--key` — Runtime key to ensure before starting.
* `--name` — Runtime name to ensure before starting.
* `--description` — Optional runtime description when ensuring a runtime.
* `--file` — Load runtime.yaml from a file or directory.
* `--json` *(default `False`)*
