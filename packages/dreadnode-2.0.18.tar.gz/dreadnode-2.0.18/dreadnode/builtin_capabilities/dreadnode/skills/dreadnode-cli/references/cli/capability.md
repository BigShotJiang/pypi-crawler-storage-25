<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/capability.mdx -->
<!-- public: https://docs.dreadnode.io/cli/capability/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Capabilities

> Build, package, and share composable agent capabilities.

Terminal window

```
$ dn capability <command>
```

Composable packages of agents, tools, and skills — capture domain expertise, share it, and refine it over time.

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## init

*Aliases: `new`*

Terminal window

```
$ dn capability init <name>
```

Scaffold a new capability directory ready for development.

Creates a capability.yaml manifest and a starter agent definition. The result passes `capability validate` immediately. Use `capability install` to make it available to local agents.

**Options**

* `<name>`, `--name` *(**Required**)* — Capability name (e.g. my-recon-cap). Lowercase letters, digits, and hyphens only.
* `--description` *(default `A new capability`)* — One-line description of what this capability does.
* `--initial-version` *(default `0.1.0`)* — Initial semver version.
* `--author` — Author name to include in the manifest.
* `--with-skills` *(default `False`)* — Also create a starter skill directory.
* `--with-mcp` *(default `False`)* — Also create a starter .mcp.json file.
* `--path` *(default `.`)* — Parent directory to create the capability folder in.

## install

Terminal window

```
$ dn capability install <ref>
```

Install a capability so agents can use it.

If the argument is a path to a directory on disk, the capability is validated and symlinked into \~/.dreadnode/capabilities/ so edits are live. Use —copy to create a frozen snapshot instead.

Otherwise the argument is treated as a registry reference and the capability is downloaded from the platform.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Capability reference or local path. Registry: my-cap, my-cap\@1.0.0, acme/my-cap. Local: ./my-cap, /abs/path/to/cap.
* `--force` *(default `False`)* — Overwrite if already installed.
* `--copy` *(default `False`)* — Copy files instead of symlinking (local installs only).

## uninstall

Terminal window

```
$ dn capability uninstall <name>
```

Uninstall a locally-installed capability.

Removes the entry from the local user store (symlink or directory) and its state record. Idempotent: succeeds even if the capability was already partially removed.

To delete a published capability version from the platform registry, use `rm` instead.

**Options**

* `<name>`, `--name` *(**Required**)* — Bare or org-qualified capability name (e.g. `my-cap` or `acme/my-cap`).

## push

*Aliases: `upload`*

Terminal window

```
$ dn capability push <path>
```

Publish a capability to your organization’s registry.

**Options**

* `<path>`, `--path` *(**Required**)* — Capability directory containing capability.yaml.
* `--name` — Override the registry name. Bare names are auto-prefixed with the active organization.
* `--skip-upload` *(default `False`)* — Build and validate locally without publishing.
* `--force` *(default `False`)* — Overwrite even if this version already exists with different content.
* `--publish` *(default `False`)* — Ensure the capability is publicly discoverable after publishing.

## publish

Terminal window

```
$ dn capability publish <refs>
```

Make one or more capability families visible to other organizations.

**Options**

* `<refs>`, `--refs` *(**Required**)*

## unpublish

Terminal window

```
$ dn capability unpublish <refs>
```

Make one or more capability families private.

**Options**

* `<refs>`, `--refs` *(**Required**)*

## list

*Aliases: `ls`*

Terminal window

```
$ dn capability list
```

Show capabilities in your organization.

**Options**

* `--search`, `--query` — Search by name or description.
* `--limit` *(default `50`)* — Maximum results to show.
* `--include-public` *(default `False`)* — Include public capabilities from other organizations.
* `--json` *(default `False`)* — Output raw JSON instead of a summary.

## status

Terminal window

```
$ dn capability status
```

Show capabilities installed locally and whether they’re enabled.

Reads the local install state (`~/.dreadnode/capabilities/` plus the state file) so agents and humans can see at a glance what the running runtime will pick up on the next reload.

**Options**

* `--json` *(default `False`)* — Output raw JSON instead of a summary.

## info

Terminal window

```
$ dn capability info <ref>
```

Show details and available versions for a capability.

Version is optional — defaults to the latest. Use org/name to inspect public capabilities from other organizations.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Capability to inspect (e.g. my-cap, my-cap\@1.0.0, or acme/my-cap).
* `--json` *(default `False`)* — Output raw JSON instead of a summary.

## pull

*Aliases: `download`*

Terminal window

```
$ dn capability pull <ref>
```

Download a capability to a local directory.

Fetches the capability from the registry and writes it to disk. Defaults to a folder named after the capability in the current directory. Use `--output` to choose a different destination.

This does **not** install or activate the capability — use `install` for that.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Capability to pull (e.g. my-cap, my-cap\@1.0.0, or acme/my-cap).
* `--output`, `-o` — Destination directory. Defaults to ./\<capability-name>.
* `--force` *(default `False`)* — Overwrite the destination if it already exists.

## delete

*Aliases: `rm`*

Terminal window

```
$ dn capability delete <ref>
```

Remove a published capability version from the registry.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Capability to delete (e.g. my-cap\@1.0.0). Version is required.
* `--yes`, `-y` *(default `False`)* — Skip the confirmation prompt.

## sync

Terminal window

```
$ dn capability sync <directory>
```

Publish all capabilities from a directory — ideal for CI pipelines.

Discovers subdirectories containing capability.yaml, compares each against the registry by content hash, and only publishes those that changed.

**Options**

* `<directory>`, `--directory` *(**Required**)* — Root directory containing capability subdirectories.
* `--force` *(default `False`)* — Publish all capabilities even if unchanged.
* `--publish` *(default `False`)* — Ensure published capabilities are publicly discoverable.

## improve

Terminal window

```
$ dn capability improve <--dataset> <path> <--scorer> <list[str]> <path>
```

Improve a local capability against a local dataset with stack-aware optimization.

**Options**

* `<path>`, `--path` *(**Required**)*
* `--dataset` *(**Required**)* — Local dataset file or dataset directory used for optimization
* `--scorer` *(**Required**)* — Repeatable scorer identifier (path.py:name or package.module.name)
* `--agent` — Optional agent name when the capability exports multiple agents
* `--model` — Execution model override; required for inheriting agents
* `--reflection-model` — Reflection model override; defaults to the execution model
* `--proposer-capability` — Optional capability path or ref used to propose candidate text updates. Defaults to dreadnode/capability-improver when available from local capability roots.
* `--proposer-agent` — Optional agent name inside the proposer capability
* `--proposer-model` — Model override for the proposer capability agent
* `--holdout-dataset` — Optional held-out local dataset used for keep/discard gating
* `--surface` — Mutable capability-owned surfaces to optimize (repeatable)
* `--score-name` — Metric name to optimize when scorers emit multiple metrics
* `--goal-field` *(default `goal`)* — Dataset field to map to the agent goal when no explicit mapping is provided
* `--dataset-input` — Repeatable dataset input mapping as DATASET\_KEY=TASK\_PARAM
* `--objective` — Optional natural-language optimization objective
* `--max-metric-calls` *(default `40`)* — Metric-call budget for the local search
* `--max-trials` *(default `8`)* — Maximum number of local search trials
* `--max-trials-without-improvement` *(default `3`)* — Stop after this many finished trials without a better score
* `--seed` *(default `0`)* — Deterministic seed for the local optimization run
* `--output-dir` — Directory for the optimization ledger and candidate artifacts
* `--json` *(default `False`)*

## validate

*Aliases: `check`*

Terminal window

```
$ dn capability validate <path>
```

Check that a capability is well-formed before publishing.

Loads and validates agents, tools, skills, MCP server, and worker definitions. Validates a single capability if the path contains capability.yaml, otherwise discovers and validates all capability subdirectories.

**Options**

* `<path>`, `--path` *(**Required**)* — Capability directory or parent directory containing multiple capabilities.
* `--strict` *(default `False`)* — Treat warnings as failures (exit code 1).
