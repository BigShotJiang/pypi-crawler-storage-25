<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/secret.mdx -->
<!-- public: https://docs.dreadnode.io/cli/secret/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Secrets

> Discover user secrets for selector-based injection.

Terminal window

```
$ dn secret <command>
```

Discover user secrets (read-only).

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## list

*Aliases: `ls`*

Terminal window

```
$ dn secret list
```

List configured user secrets.

Names returned here are the values accepted by `--secret` selectors. Glob selectors (`*`, `?`) are matched best-effort by the API; exact names are strict. Manage secret values via the TUI secrets screen or the platform web app.

**Options**

* `--json` *(default `False`)* — Output as JSON (list-row projection).
