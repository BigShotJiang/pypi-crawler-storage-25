<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/main.mdx -->
<!-- public: https://docs.dreadnode.io/cli/main/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Core

> Root-level dreadnode CLI commands — login, whoami, and the local runtime server.

Root-level commands that don’t live under a subgroup. For shared flags, environment variables, and the conventions every subcommand inherits, see the [CLI overview](./overview.md).

Terminal window

```
$ dn <command>
```

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## login

Terminal window

```
$ dn login
```

Authenticate with the Dreadnode platform.

**Options**

* `<api-key>`, `--api-key` — API key to save locally. Omit to use browser-based device login.
* `--server` — Platform API URL override for login and profile storage
* `--profile`, `-p` — Profile name to create or update. Defaults to your username.
* `--organization`
* `--workspace`
* `--project`
* `--poll-interval-sec` *(default `2.0`)* — Polling interval for browser-based device login
* `--timeout-sec` — Optional timeout for browser-based device login

## whoami

Terminal window

```
$ dn whoami
```

Show current user, organization, and profile context.

**Options**

* `--json` *(default `False`)*

## serve

Terminal window

```
$ dn serve
```

Host a runtime server for the TUI.

**Options**

* `--host` — Server bind host
* `--port` — Server bind port
* `--working-dir` — Working directory for the server
* `--platform-server` — Platform API URL override
* `--api-key` — API key for platform authentication
* `--organization` — Organization slug override
* `--workspace` — Workspace slug override
* `--project` — Project slug override
* `--verbose` *(default `False`)* — Enable verbose trace logging for the local server
