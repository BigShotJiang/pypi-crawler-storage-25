<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/inference-model.mdx -->
<!-- public: https://docs.dreadnode.io/cli/inference-model/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Inference Models

> Discover platform inference models and validate model IDs.

Terminal window

```
$ dn inference-model <command>
```

Discover platform inference models and validate model IDs.

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## list

*Aliases: `ls`*

Terminal window

```
$ dn inference-model list
```

List platform-managed inference models.

Use these IDs with `--model` on `dn evaluation create`, `dn optimize submit`, and other commands that take a runtime model selector. BYOK models are not listed — pass their IDs directly after configuring credentials with `dn secret list` / set.

**Options**

* `--json` *(default `False`)* — Output as JSON (list-row projection).

## validate

Terminal window

```
$ dn inference-model validate <model-id>
```

Validate a model ID against the platform’s LiteLLM catalog.

Works for system (`dn/...`) and BYOK identifiers. Returns the extracted provider and any required user-secret env vars.

**Options**

* `<model-id>`, `--model-id` *(**Required**)* — Model identifier (e.g. `dn/gpt-5`, `mistral/mistral-large-latest`).
* `--json` *(default `False`)* — Output as JSON.
