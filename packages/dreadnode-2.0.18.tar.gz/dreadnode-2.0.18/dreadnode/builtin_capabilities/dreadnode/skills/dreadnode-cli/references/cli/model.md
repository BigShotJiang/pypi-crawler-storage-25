<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/model.mdx -->
<!-- public: https://docs.dreadnode.io/cli/model/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Models

> Fine-tuned weights and adapters — checkpoints, LoRAs, and quantized models.

Terminal window

```
$ dn model <command>
```

Fine-tuned weights and adapters — checkpoints from training, LoRAs, and quantized models ready for deployment.

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## inspect

Terminal window

```
$ dn model inspect <path>
```

Preview a local model directory before publishing.

Reads model.yaml and the artifact files to show framework, task, architecture, and file listing — so you can catch problems before pushing.

**Options**

* `<path>`, `--path` *(**Required**)* — Model directory containing model.yaml.
* `--json` *(default `False`)* — Output raw JSON instead of a table.

## push

*Aliases: `upload`*

Terminal window

```
$ dn model push <path>
```

Publish a model to your organization’s registry.

Packages a model directory (with model.yaml manifest) and uploads it as a versioned artifact. Supports LoRA adapters, quantized checkpoints, and full model weights.

**Options**

* `<path>`, `--path` *(**Required**)* — Model directory containing model.yaml.
* `--name` — Override the registry name.
* `--skip-upload` *(default `False`)* — Build and validate locally without publishing.
* `--publish` *(default `False`)* — Ensure the model is publicly discoverable after publishing.

## publish

Terminal window

```
$ dn model publish <refs>
```

Make one or more model families visible to other organizations.

**Options**

* `<refs>`, `--refs` *(**Required**)*

## unpublish

Terminal window

```
$ dn model unpublish <refs>
```

Make one or more model families private.

**Options**

* `<refs>`, `--refs` *(**Required**)*

## list

*Aliases: `ls`*

Terminal window

```
$ dn model list
```

Show models in your organization.

**Options**

* `--search`, `--query` — Search by name or description.
* `--limit` *(default `50`)* — Maximum results to show.
* `--include-public` *(default `False`)* — Include public models from other organizations.
* `--json` *(default `False`)* — Output raw JSON instead of a summary.

## info

Terminal window

```
$ dn model info <ref>
```

Show details and available versions for a model.

Version is optional — defaults to the latest.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Model to inspect (e.g. my-model, my-model\@1.0.0).
* `--json` *(default `False`)* — Output raw JSON instead of a summary.

## compare

Terminal window

```
$ dn model compare <ref> <versions>
```

Compare model versions side-by-side with metrics.

Shows a table of framework, task, metrics, aliases, and more across 2-5 versions. Essential for picking the best checkpoint after a training run.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Model name (e.g. my-model).
* `<versions>`, `--versions` *(**Required**)* — Versions to compare (2-5, e.g. 1.0.0 2.0.0 3.0.0).
* `--json` *(default `False`)* — Output raw JSON instead of a table.

## alias

Terminal window

```
$ dn model alias <ref> <name>
```

Tag a model version with a named alias like ‘champion’ or ‘staging’.

Aliases let you reference a model version by role instead of number. Setting an alias that already exists on another version moves it automatically.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Model version (e.g. my-model\@1.0.0). Version is required.
* `<name>`, `--name` *(**Required**)* — Alias name (e.g. champion, staging, latest-stable).
* `--remove` *(default `False`)* — Remove the alias instead of setting it.

## metrics

Terminal window

```
$ dn model metrics <ref> <[args...]>
```

Attach evaluation metrics to a model version.

Pass metrics as key=value pairs. Numeric values are stored as numbers. Existing metrics are merged — keys you don’t mention are preserved.

**Arguments**

* `<args>` — Metrics as key=value pairs (e.g. accuracy=0.95 f1=0.88).

**Options**

* `<ref>`, `--ref` *(**Required**)* — Model version (e.g. my-model\@1.0.0). Version is required.
* `--json` *(default `False`)* — Output updated model detail as JSON.

## delete

*Aliases: `rm`*

Terminal window

```
$ dn model delete <ref>
```

Remove a model version from the registry.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Model to delete (e.g. my-model\@1.0.0). Version is required.
* `--yes`, `-y` *(default `False`)* — Skip the confirmation prompt.

## pull

*Aliases: `download`*

Terminal window

```
$ dn model pull <ref>
```

Pull a model to your local machine.

Version is optional — defaults to the latest. Without —output, prints a pre-signed download URL you can use with curl or a browser.

**Options**

* `<ref>`, `--ref` *(**Required**)* — Model to pull (e.g. my-model, my-model\@1.0.0).
* `--output` — Save to this path instead of printing the URL.
