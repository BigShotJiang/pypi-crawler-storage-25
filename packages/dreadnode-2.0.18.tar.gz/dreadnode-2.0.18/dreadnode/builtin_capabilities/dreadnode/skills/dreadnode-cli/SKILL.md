---
name: dreadnode-cli
description: Use when the user asks for exact `dn` or `dreadnode` commands, asks "how do I do X with the CLI", needs the right command group for a workflow, mixes up local vs hosted operations, or wants to know the nearest TUI equivalent of a CLI flow.
---

# Dreadnode CLI

This skill routes user intent to the right `dn` command group, then defers to the auto-synced reference for exact syntax.

## Reference material

The full CLI is bundled under `references/cli/` — one page per command group, generated from the live cyclopts CLI tree. Read on demand:

| If the user asks about… | Read |
|---|---|
| Shared flags, env-vars, registry verbs, profile precedence | `references/cli/overview.md` |
| Authentication, profile setup, scope flags | `references/getting-started/authentication.md` |
| `dn login`, `dn whoami`, `dn serve`, bare `dn` | `references/cli/main.md` |
| Capability authoring (`init`, `validate`, `install`, `push`, `improve`, `sync`) | `references/cli/capability.md` |
| Datasets / tasks / models — local + registry | `references/cli/{dataset,task,model}.md` |
| Evaluation runs and inspection | `references/cli/evaluation.md` |
| Hosted optimization | `references/cli/optimize.md` |
| Hosted training (SFT, RL) | `references/cli/train.md` |
| Hosted runtime records | `references/cli/runtime.md` |
| Backing compute (sandbox inspection, logs, usage) | `references/cli/sandbox.md` |
| Task environments (provision, list, exec, tear down lab targets) | `references/cli/env.md` |
| AIRT (assessments, attacks, transforms, findings) | `references/cli/airt.md` |
| Worlds (manifests, trajectories, principals) | `references/cli/worlds.md` |

Always reach for these before answering with command syntax. The CLI evolves between releases; the references regenerate from the live tree.

## Operating rules

- **Identify the workflow first, syntax second.** Map the user's intent to the owning command group, then look up the exact command.
- **Prefer workflow-shaped commands.** If a command group has `init`, `validate`, `push` — that's the path; don't paste raw API calls.
- **Local vs hosted matters.** `dn capability improve` is local and stack-aware. `dn optimize submit` is hosted and currently mutates only `instructions`. `dn serve` runs a local runtime; `dn runtime list` inspects hosted ones.
- **If a feature is planned but not shipped, say so.** Don't imply syntax that doesn't exist.
- **For domain workflows, search capabilities first.** "Run a web-app pentest" is not a CLI question — it starts with `dn capability list --search ... --include-public`.

## Intent → command group

| User intent | Command group / command |
|---|---|
| Talk to an agent right now | bare `dn` (TUI) or `dn --print --prompt "..."` (headless) |
| Authenticate / inspect identity | `dn login`, `dn whoami` |
| Host a local runtime server | `dn serve` |
| Local capability iteration | `dn capability {init,install,validate,improve}` |
| Find the right capability for a domain task | `dn capability list --include-public --search ...` then `dn capability install` |
| Publish a capability / dataset / model / task | `<group> push`, `<group> publish`, `<group> sync` |
| Run a repeatable benchmark or scored run | `dn evaluation create` |
| Inspect a past evaluation run | `dn evaluation {get,list-samples,get-sample,get-transcript}` |
| Hosted optimization of a published capability | `dn optimize submit` |
| Hosted SFT or RL fine-tuning | `dn train {sft,rl}` |
| Inspect hosted runtime records | `dn runtime {list,get}` |
| Inspect backing compute / logs / usage | `dn sandbox {list,get,logs,usage}` |
| Provision a task environment as a lab target / exec into it | `dn env {create,list,get,status,exec,delete}` |
| AI red teaming workflows | `dn airt {create,run,reports,findings,...}` |
| Generate simulated network manifests / trajectories | `dn worlds ...` |

For the full subcommand inventory of any group, read the matching `references/cli/<group>.md`.

## TUI equivalents

The CLI is the source of truth for exact syntax. The TUI is a convenience surface — give the CLI answer first when precision matters, then name the closest TUI affordance:

| CLI group | Closest TUI surface |
|---|---|
| `dn capability ...` | `/capabilities` screen |
| `dn task ...` | (no dedicated TUI screen for task authoring — handled inside evaluation flows) |
| `dn env ...` | `/environments` screen |
| `dn evaluation ...` | `/evaluations` |
| `dn runtime ...` | `/runtimes` |
| `dn model ...` | `/models` |
| `dn dataset ...` | (no dedicated screen — handled inside evaluation/workflow screens) |
| `dn optimize ...` | (no direct equivalent for hosted submission — give the CLI path) |
| Session switching, agent routing | `/sessions`, `/agents`, or `@agent-name` mention |

If no solid TUI equivalent exists, say so directly.

## Answering pattern

1. Identify the owning workflow and command group.
2. Read the matching `references/cli/<group>.md` if you're not already certain of the syntax.
3. Give the exact command.
4. If the user asked for TUI help, append the closest slash command or screen.
5. If the workflow is design-only and unshipped, say so directly.
