<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/cli/worlds.mdx -->
<!-- public: https://docs.dreadnode.io/cli/worlds/ -->
<!-- bundle: dreadnode-cli.json (regenerate via `just docs sync` or pre-commit) -->

# Worlds

> Work with simulated network environments.

Terminal window

```
$ dn worlds <command>
```

Work with simulated network environments.

Shared options

Commands that hit the platform or a runtime server accept these flags:

* `--profile`, `--server`, `--api-key`, `--organization`, `--workspace`, `--project` — authenticate and scope against a Dreadnode platform. See [Authentication](../getting-started/authentication.md).

## manifest-create

Terminal window

```
$ dn worlds manifest-create
```

Create a new world manifest.

**Options**

* `--name` — Manifest name
* `--project-id` — Project ID to associate
* `--preset` — *\[choices: small, medium, large, enterprise]*
* `--seed` — Random seed for reproducibility
* `--num-users` — Number of users to generate
* `--num-hosts` — Number of hosts to generate
* `--domain` — Domain name (repeatable)
* `--json` *(default `False`)*

## manifest-list

Terminal window

```
$ dn worlds manifest-list
```

List world manifests.

**Options**

* `--project-id` — Project ID filter
* `--created-by` — Filter by creator
* `--limit` *(default `50`)*
* `--json` *(default `False`)*

## manifest-get

Terminal window

```
$ dn worlds manifest-get <manifest-id>
```

Get a world manifest by ID.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `--json` *(default `False`)*

## graph-nodes

Terminal window

```
$ dn worlds graph-nodes <manifest-id>
```

Get graph nodes for a world manifest.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `--limit` *(default `1000`)*
* `--offset` *(default `0`)*
* `--json` *(default `False`)*

## graph-edges

Terminal window

```
$ dn worlds graph-edges <manifest-id>
```

Get graph edges for a world manifest.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `--limit` *(default `5000`)*
* `--offset` *(default `0`)*
* `--json` *(default `False`)*

## subgraph

Terminal window

```
$ dn worlds subgraph <manifest-id> <center>
```

Get a subgraph centered on a node.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `<center>`, `--center` *(**Required**)*
* `--depth` *(default `2`)*
* `--json` *(default `False`)*

## principals

Terminal window

```
$ dn worlds principals <manifest-id>
```

Search principals in a world manifest.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `--query`, `--search` — Search query
* `--principal-type` — Filter by principal type
* `--limit` *(default `50`)*
* `--json` *(default `False`)*

## principal

Terminal window

```
$ dn worlds principal <manifest-id> <principal-id>
```

Get a principal by ID.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `<principal-id>`, `--principal-id` *(**Required**)*
* `--json` *(default `False`)*

## principal-details

Terminal window

```
$ dn worlds principal-details <manifest-id> <principal-id>
```

Get detailed info for a principal.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `<principal-id>`, `--principal-id` *(**Required**)*
* `--json` *(default `False`)*

## host

Terminal window

```
$ dn worlds host <manifest-id> <host-id>
```

Get a host by ID.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `<host-id>`, `--host-id` *(**Required**)*
* `--json` *(default `False`)*

## host-details

Terminal window

```
$ dn worlds host-details <manifest-id> <host-id>
```

Get detailed info for a host.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `<host-id>`, `--host-id` *(**Required**)*
* `--json` *(default `False`)*

## commands

Terminal window

```
$ dn worlds commands <manifest-id>
```

List commands for a world manifest.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `--json` *(default `False`)*

## manifest-trajectories

Terminal window

```
$ dn worlds manifest-trajectories <manifest-id>
```

List trajectories for a world manifest.

**Options**

* `<manifest-id>`, `--manifest-id` *(**Required**)*
* `--limit` *(default `50`)*
* `--json` *(default `False`)*

## trajectory-create

Terminal window

```
$ dn worlds trajectory-create <--manifest-id> <str>
```

Create a new world trajectory.

**Options**

* `--manifest-id` *(**Required**)*
* `--name` — Trajectory name
* `--project-id` — Project ID to associate
* `--goal` *(default `Domain Admins`)* — Target goal for trajectory
* `--count` *(default `1`)* — Number of trajectories to generate
* `--strategy` *(default `random`)* — *\[choices: random, greedy, recon-first, smart-random]*
* `--max-steps` *(default `100`)* — Maximum steps per trajectory
* `--seed` *(default `42`)* — Random seed for reproducibility
* `--threads` *(default `1`)* — Number of parallel threads
* `--only-successful` *(default `False`)*
* `--mode` *(default `kali`)* — *\[choices: kali, c2, agent]*
* `--runtime-id` — Runtime environment ID
* `--capability-name` — Capability to use
* `--agent-name` — Agent name within capability
* `--agent-model` — Model for the agent
* `--json` *(default `False`)*

## trajectory-list

Terminal window

```
$ dn worlds trajectory-list
```

List world trajectories.

**Options**

* `--manifest-id` — Filter by manifest ID
* `--project-id` — Project ID filter
* `--created-by` — Filter by creator
* `--limit` *(default `50`)*
* `--json` *(default `False`)*

## trajectory-get

Terminal window

```
$ dn worlds trajectory-get <trajectory-id>
```

Get a world trajectory by ID.

**Options**

* `<trajectory-id>`, `--trajectory-id` *(**Required**)*
* `--json` *(default `False`)*

## job-list

Terminal window

```
$ dn worlds job-list
```

List world jobs.

**Options**

* `--project-id` — Project ID filter
* `--created-by` — Filter by creator
* `--kind` — *\[choices: manifest\_generation, trajectory\_generation]*
* `--status`, `--state` — *\[choices: queued, running, completed, failed, cancelled]*
* `--limit` *(default `50`)*
* `--json` *(default `False`)*

## job-get

Terminal window

```
$ dn worlds job-get <job-id>
```

Get a world job by ID.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--json` *(default `False`)*

## job-wait

Terminal window

```
$ dn worlds job-wait <job-id>
```

Wait for a world job to complete.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--poll-interval-sec` *(default `5.0`)* — Polling interval in seconds
* `--timeout-sec` — Timeout in seconds for waiting
* `--json` *(default `False`)*

## job-cancel

Terminal window

```
$ dn worlds job-cancel <job-id>
```

Cancel a world job.

**Options**

* `<job-id>`, `--job-id` *(**Required**)*
* `--json` *(default `False`)*
