# Promoting a scratch capability

A scratch capability earned its keep in one session. Now the user wants to share it. The temptation is to throw out the scratch and "do it right" — don't. The thing that worked is the only reliable signal you have about what this capability is for.

This page covers when to promote, what to keep verbatim, and how to avoid turning a promotion into a rewrite.

## When to promote

Promote when *all* of these are true:

- The scratch capability helped the user finish the original work.
- The user has said, implicitly or explicitly, that they'd reach for it again.
- There's a second user — a teammate, a project, their future self — who would benefit from it in the same shape.

If the capability didn't work, don't promote. Fix the scratch first or discard it.

If the capability worked but is specific to a one-off target (a single host, a single dataset), it's likely not promotable — the work was one-shot. Offer to save the *transcript* instead and move on.

## What to keep from the scratch

The scratch is the contract. When promoting:

- **Keep the skill body.** This is the part that proved it works. Any rewrite here risks breaking the behavior you're trying to promote. Copy-edit for clarity, not content.
- **Keep the description.** It triggered correctly for at least one real prompt. Refine the wording, don't rewrite from scratch.
- **Keep the tool and CLI choices.** If bash + `skopeo` was enough, don't reach for an MCP wrapper just because you're now "polishing."

## What to add or rewrite

- **Manifest fields** — populate `description`, `version`, author metadata. Pick a stable name if the scratch name is throwaway.
- **Test prompts** — draft 2–3 realistic prompts that cover the cases you expect other users to hit. Run them and read the transcripts.
- **Edge cases from the session** — if the user hit a wrinkle during the scratch run that the skill silently worked through, capture it explicitly now. The next user won't have the same context.
- **Bundled scripts** — if the session produced a helper the agent re-derived multiple times, drop it in `scripts/` and have the skill call it.
- **Description tightening** — when the scratch was used once, any description worked. For shared use, it competes against every other installed skill in a shared metadata budget. Target ~130 characters and front-load the trigger keywords.

## What the upgrade path looks like

1. Pick a real name. Rename the directory and the manifest `name` field in one step.
2. Move it out of the scratch location (if it was in a working tree directory) into a permanent home — a dedicated `capabilities/` directory in the user's project, or somewhere they'd keep a `git` repo for shared capabilities.
3. Re-install: `dn capability install ./<name>`.
4. Run `dn capability validate ./<name>`. Fix any manifest warnings.
5. Run the 2–3 test prompts. Read the transcripts, not just the outputs.
6. Publish with `dn capability push`.

From here, the user is in the ship-it path. For evaluation-driven optimization beyond this point, read `references/guides/capability-optimization-loop.md`.

## Avoiding the "promotion becomes a rewrite" trap

Most of the value of the scratch is that it's specific, minimal, and battle-tested on one real piece of work. Common ways promotions go wrong:

- **Generalization beyond the use case.** Don't add arguments, modes, or branches the scratch didn't need. Ship the narrow version; users can extend it later.
- **Ceremony over substance.** A long docstring, a README, five test prompts, a CI workflow — none of these make the capability better for its actual job. They make it look like an open-source library. Skip unless the user asked.
- **Rewriting the skill in "proper" voice.** If the scratch skill reads like a terse note to self and it worked, leave the voice. Skills that sound like documentation often perform worse than skills that sound like a colleague explaining something over a shoulder.

If a promotion is taking more than a short pass to land, stop and ask whether the scratch was actually ready.
