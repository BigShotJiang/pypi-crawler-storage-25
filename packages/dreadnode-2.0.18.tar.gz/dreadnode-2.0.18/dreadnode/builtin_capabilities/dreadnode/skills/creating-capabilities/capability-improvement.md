# Improving capabilities

The hosted optimization path (`dn optimize submit`) currently mutates only an agent's `instructions` string. That is useful — but the layers that often matter more sit outside it: skill descriptions, skill bodies, capability prompts, tool rules. This page covers when to reach beyond hosted optimization, and what surfaces are actually safe to mutate.

## Two levels of improvement

The improver an agent reaches for depends on what is being held constant.

| Goal | Tool | Mutates | Holds constant |
|---|---|---|---|
| Make one published capability score better | `dn capability improve` (local, stack-aware) | capability-owned surfaces | runtime, default tools, native skills, target model |
| Improve the shared default agent every capability sits on top of | `dn runtime improve` (planned) | runtime-owned surfaces | a benchmark suite of representative capabilities |

Without that ownership split, full-stack search produces misleading wins: one bad layer compensates for another and you can't tell where the improvement actually came from.

## Mutation order, cheapest first

When iterating manually or guiding a structured improver, prefer surfaces in this order. The earlier ones are higher leverage and cheaper to evaluate.

1. **Skill `description`** — most skill failures are routing failures.
2. **Skill body in `SKILL.md`** — easier to validate than code.
3. **Agent definition prompt** — when the issue is posture, not procedure.
4. **Capability `system-prompt.md`** — when a single rule applies to every agent in the capability.
5. **Tool rules (allow/deny)** — when the agent reaches for the wrong tool.
6. **Delegation and orchestration** — when single-agent prompting can't get there.
7. **MCP configuration** — when the integration itself is wrong.
8. **Custom tool code** — last resort; tools cost ongoing maintenance.

## Ownership boundaries

A capability improver should never touch runtime-owned surfaces, and vice versa.

**Capability-owned (safe to mutate per-capability):** agent definitions, capability `system-prompt.md`, skill descriptions and bodies, tool rules, delegation links, MCP config, capability-local tool code.

**Runtime-owned (only `dn runtime improve` should touch):** the host runtime prompt, default tools, native SDK skills.

The bundled `dreadnode` capability is the line between the two: it ships in the SDK and is the runtime default, so changes to *it* are runtime changes. See `runtime-default-capability.md` for the layout.

## Keep / discard rules

A candidate is kept only when:

- the train metric improves past the configured threshold
- holdout does not regress past tolerance
- guardrail metrics stay green
- the change stayed within allowed mutation scope

Tie-breakers (apply in order):

1. equal score → prefer the simpler candidate
2. prompt-only beats prompt + code when outcomes are equivalent
3. fewer changed files beats more changed files

These rules are conservative on purpose. The point is reliable compounding improvement, not flashy one-off prompt edits.

## Eval-driven workflow

For the full evaluation pipeline — datasets, scorers, the optimization loop wiring — read `references/guides/capability-optimization-loop.md`. That page is the canonical workflow.

This file covers the *why* and the *boundaries*; the optimization-loop guide covers the *how*.
