# The bundled `dreadnode` capability

The runtime default agent is a real capability that ships inside the SDK wheel. It loads automatically and serves as the agent the user gets when they open the TUI without selecting a `@capability`.

This page is for two situations:

1. The user is asking what the bundled `dreadnode` capability *is* and how it relates to the legacy `default` agent label.
2. The user wants to extend or replace the runtime default behavior.

For everything else (authoring a normal user capability), this file is not what you want — use the main `SKILL.md` and the `references/`.

## Where it lives

```
packages/sdk/dreadnode/builtin_capabilities/dreadnode/
├── capability.yaml                 manifest
├── agents/
│   └── dreadnode.md                the default agent prompt (incl. routing overlay)
├── skills/
│   ├── creating-capabilities/      this skill
│   ├── research-capabilities/      parallel research + recommendation
│   ├── dreadnode-cli/              CLI workflow guidance
│   └── dreadnode-concepts/           platform terminology and key paths
└── MAINTAINING.md                  contributor notes
```

The loader is `packages/sdk/dreadnode/builtin_capabilities/__init__.py`. Wiring into the runtime registry happens in `packages/sdk/dreadnode/app/server/app.py`.

## Ownership split

Some default behavior lives in the bundled capability; some lives in host code. Knowing which is which prevents fights with the runtime.

**Bundled-capability assets (editable, ship as data):**

- the default agent prompt (`agents/dreadnode.md`, which carries the routing overlay inline)
- the bundled skills under `skills/`
- the manifest

**Host code (editable only via Python changes):**

- dynamic platform context injection (`packages/sdk/dreadnode/app/server/prompt.py`)
- default tool implementations
- session, registry, and runtime-info plumbing
- subagent routing and pooled skill tools

The rule of thumb: **behavior** lives in the bundled capability; **infrastructure** lives in host code.

## What `default` means now

`default` is a fallback label, not a routable agent name.

- When the bundled `dreadnode` capability loads, the registry sets `default_capability_name = "dreadnode"` and bare chat resolves to it.
- `@dreadnode` is the explicit way to route a single message to the built-in core agent.
- `default` only appears in pre-load or degraded states, as a placeholder so the UI has a safe label.

Legacy `"default"` strings on inbound API requests are normalized to "no override" — new sessions never write `"default"` back.

## Editing the runtime default

Treat changes here like production prompt changes — they ship to every Dreadnode user the moment the SDK is published.

- Behavior change → edit `agents/dreadnode.md`.
- Routing or registry change → edit `packages/sdk/dreadnode/app/server/app.py`.
- Dynamic context (current org/workspace, available capabilities, etc.) → edit `packages/sdk/dreadnode/app/server/prompt.py`.

Run `dn capability validate packages/sdk/dreadnode/builtin_capabilities/dreadnode` after edits. A broken manifest will silently fall back to the legacy hardcoded prompt.
