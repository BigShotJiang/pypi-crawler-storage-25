<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/capabilities/agents.mdx -->
<!-- public: https://docs.dreadnode.io/capabilities/agents/ -->
<!-- bundle: capability-authoring.json (regenerate via `just docs sync` or pre-commit) -->

# Agents

> Markdown files with frontmatter that define the agents a capability ships — model, tool access, and skills.

An agent in a capability is a markdown file. Frontmatter declares identity and runtime configuration; the body is the system prompt the model sees.

```
---
name: triage
description: Decide which tools and skills to use for indicator triage.
model: anthropic/claude-sonnet-4-5-20250929
tools:
  '*': false
  lookup_indicator: true
skills: [report]
---

You are a threat hunting triage agent. Decide what to investigate next and explain why.
```

Agent files live under `agents/` by default. The loader auto-discovers every `*.md` in that directory; list them explicitly under `agents:` in the manifest if you want a subset.

## Frontmatter fields

| Field         | Required | Purpose                                                         |
| ------------- | -------- | --------------------------------------------------------------- |
| `name`        | yes      | Unique within the capability. Falls back to the filename stem.  |
| `description` | yes      | One-line summary shown in selection UIs.                        |
| `model`       | no       | Default model for the agent, or `inherit` to use the session’s. |
| `tools`       | no       | Tool access rules — see [Tool gating](#tool-gating) below.      |
| `skills`      | no       | Skill names the agent can load on demand.                       |
| `metadata`    | no       | Free-form dict passed through to the runtime.                   |

The body — everything after the closing `---` — becomes the agent’s system prompt. An empty body is logged as a warning at load time.

## Model resolution

The `model` field accepts a literal model id or the special string `inherit`:

| Value                         | Behavior                                                      |
| ----------------------------- | ------------------------------------------------------------- |
| `inherit` (default)           | Use whichever model the session is configured with.           |
| `anthropic/claude-sonnet-4-5` | Pin to a specific model regardless of session settings.       |
| Any LiteLLM-supported id      | Same — the runtime hands the string to the generator factory. |

`inherit` is the right choice for most agents. Use a pinned model when the prompt has been tuned for a specific family or when an agent needs different cost/latency characteristics than the session default.

## Tool gating

The `tools` field is a map of glob pattern to boolean. Rules evaluate in order; the **last matching rule wins**. Tools with no matching rule are allowed.

```
# Allow everything except bash
tools:
  bash: false

# Start with nothing, opt in by name
tools:
  '*': false
  lookup_indicator: true
  fetch_intel: true

# Allow most MCP tools, block one
tools:
  '*': true
  'mcp_*': true
  mcp_filesystem_write: false
```

Pattern matching is `fnmatch`-style (`*`, `?`, `[seq]`) and case-insensitive. The `'*': false` opt-out is the most common shape — it forces the agent to only see tools you’ve explicitly enabled.

Note

Tools the runtime exposes (built-ins, MCP tools, capability tools) all flow through the same gate. An agent doesn’t distinguish where a tool came from — only whether the rules let it through.

## Skills

The `skills` field lists skill names the agent can load. Every listed skill’s name and description appear in the agent’s context; the body of the skill loads only when the agent decides to use it.

```
skills: [incident-response, report]
```

Skill names are the directory name under `skills/` — see [Skills](./skills.md) for how the files are structured.

## Where the file lives

Default location is `agents/<name>.md` under the capability root. Manifest control:

```
# Auto-discover every agents/*.md
agents:    # (omit entirely)

# Load only these
agents:
  - agents/triage.md
  - agents/responder.md

# Disable agents even if agents/ exists
agents: []
```

The filename stem is used as the agent name when frontmatter omits `name`. Match the two when you can — debugging is simpler when `agents/triage.md` defines the agent named `triage`.

## Selecting an agent at runtime

A capability that ships multiple agents lets the user pick one per session:

Terminal window

```
# Launch the TUI on a specific agent
dn --agent triage

# Switch agents inside the TUI
/agent triage
```

Agents are addressed by bare name — every installed capability contributes its agents to a single shared namespace. Pick distinct names if you ship multiple capabilities side-by-side.
