<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/capabilities/installing.mdx -->
<!-- public: https://docs.dreadnode.io/capabilities/installing/ -->
<!-- bundle: capability-authoring.json (regenerate via `just docs sync` or pre-commit) -->

# Installing

> Install capabilities from a local directory, the registry, or the TUI capability manager.

Install a capability and the runtime picks up its agents, tools, skills, MCP servers, and workers on the next load. Three paths: a local directory you’re developing, a published registry version, or a click in the TUI.

Terminal window

```
# Local development — symlinks for live editing
dn capability install ./capabilities/threat-hunting

# Published version
dn capability install acme/threat-hunting@0.1.0
```

## Install from disk

`dn capability install ./path` validates the manifest, then symlinks the source directory into `~/.dreadnode/capabilities/`. Edits to the source appear on the next runtime reload — no re-install needed.

Terminal window

```
dn capability install ./capabilities/threat-hunting
```

Two flags change the default:

* `--copy` — snapshot the source instead of symlinking. Use this when you want a frozen install that won’t follow source edits.
* `--force` — replace an existing install. Without it, re-running `install` against the same name fails.

## Browse the web catalog

The web app has a catalog at `/capabilities` — grid view for scanning, table view for sorting by version or author, and filters for author and keyword.

Click any capability to open its detail drawer. That’s where you’ll find the exact install commands for the CLI and the TUI, along with the full manifest metadata and link to docs:

Copy the `dn capability install` command from the drawer, or paste the `/capabilities → <name>` path into an active TUI session.

## Install from the registry

Terminal window

```
dn capability install acme/threat-hunting@0.1.0
```

`install` downloads the bundle, validates it, and registers it for the active project. `pull` downloads without registering — useful when you want to read or fork the bundle.

Terminal window

```
dn capability pull acme/threat-hunting@0.1.0 --output ./forks/
```

## Install from the TUI

Terminal window

```
dn
```

Press `Ctrl+P` to open the capability manager.

* **Installed** tab — capabilities bound to the active project, with toggles to enable, disable, or edit flags
* **Available** tab — capabilities you can install from your org inventory and the public catalog

Tab over to **Available** to see what your org and the public catalog expose:

Select an available capability and press **Enter** to install. The manager runs the same validation path as the CLI.

For loading capabilities programmatically from Python, see the [SDK overview](https://docs.dreadnode.io/sdk/overview/) and [`dreadnode.capabilities`](../sdk/capabilities.md).

## Where the runtime looks

A **local runtime** searches three sources in order; the first match on a given name wins:

1. Project-local — `.dreadnode/capabilities/` in the project root
2. User-local — `~/.dreadnode/capabilities/` (where `install` puts things)
3. Override — directories listed in `DREADNODE_CAPABILITY_DIRS` (`:` on Unix, `;` on Windows)

A **sandbox runtime** loads only capabilities synced from your workspace — local directories are not consulted. Local and workspace sources never coexist on the same runtime, so there is no shadowing between them.

Terminal window

```
export DREADNODE_CAPABILITY_DIRS="/opt/capabilities:$HOME/dev/capabilities"
dn
```

Entries resolve to absolute paths and are searched after project-local and user-local directories.
