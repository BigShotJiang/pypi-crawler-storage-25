<!-- AUTO-GENERATED — do not hand-edit. -->
<!-- source: packages/docs/src/content/docs/capabilities/skills.mdx -->
<!-- public: https://docs.dreadnode.io/capabilities/skills/ -->
<!-- bundle: capability-authoring.json (regenerate via `just docs sync` or pre-commit) -->

# Skills

> Ship SKILL.md instruction packs that agents load on demand.

A skill is a folder with a `SKILL.md` file. Agents see the skill’s name and description by default; when they decide the skill applies, they load its full instructions as context. Skills are how you ship reusable procedures — triage playbooks, report templates, incident response steps — without bloating every system prompt.

```
skills/
  incident-response/
    SKILL.md
    scripts/
      triage.py
    references/
      playbook.md
```

```
---
name: incident-response
description: Triage host compromise signals and summarize next actions.
allowed-tools: read_logs run_skill_script
license: MIT
---

Follow this process:

1. Identify the host and timeframe.
2. Run the triage script for baseline indicators.
3. Summarize findings and next actions.
```

The directory name and `name` in frontmatter must match.

## Frontmatter fields

| Field           | Purpose                                                                                              |
| --------------- | ---------------------------------------------------------------------------------------------------- |
| `name`          | Unique within the capability; must match the directory name.                                         |
| `description`   | One-line summary shown when the agent lists available skills.                                        |
| `allowed-tools` | Space-delimited or list form. Advisory — agents see it as guidance; the runtime does not enforce it. |
| `license`       | Optional attribution.                                                                                |
| `metadata`      | Free-form map attached to the skill.                                                                 |

Note

`allowed-tools` is advisory in v1. The skill content includes it as an `<allowed_tools>` hint for the agent, but no permission gate stops a tool call that isn’t listed.

## Ship skills in a capability

Declare them in the manifest:

```
skills:
  - skills/incident-response/
  - skills/report/
```

If `skills:` is omitted, the loader auto-discovers every subdirectory of `skills/` that contains a `SKILL.md`. Set `skills: []` to disable.

## Reference skills from an agent

Agents opt in by name in frontmatter:

```
---
name: responder
description: Handle incident tickets from triage to summary.
model: anthropic/claude-sonnet-4-5-20250929
skills: [incident-response, report]
---

You are an incident responder. Use the listed skills when they apply.
```

Every skill listed is visible to the agent. Content only loads when the agent explicitly asks for it, keeping the system prompt small.
