---
name: creating-capabilities
description: Use when the user wants tooling, a skill, an MCP integration, or an agent to help with the work they're about to do — whether that's a quick scratch capability for the next hour or a polished capability they plan to share. Includes "build/scaffold/improve a capability", "wrap this CLI", "give me a skill for X", and any request where a working skill in front of the user right now is more useful than a polished skill later.
---

# Creating Capabilities

A capability packages tooling and methodology so an agent can apply it on demand. Most of the time the user is not asking you to publish an artifact — they are asking you to **tool up for the next hour of work**. Treat that as the default. The ship-it-for-others arc is still here, but it's a second mode you reach for only when the user explicitly wants to polish, review, and publish.

Two modes:

- **Fast path** — "I want to do X." You scout, pick a shape, write the thinnest skill that helps, load it into the current session, and do X. The capability is the receipt of the work, not the point of the work.
- **Ship-it path** — "I want to build a capability for team X that does Y." You draft, test against realistic prompts, iterate, and publish.

The fast path is the default. Drop into ship-it only when the user asks, or when a scratch capability has proven itself and the user wants to promote it.

## References, at a glance

The `references/` directory is auto-synced from `docs.dreadnode.io`. Read on demand at the decision points called out below; do not pre-load.

| Question | Read |
|---|---|
| What goes in `capability.yaml`? | `references/capabilities/manifest.md` |
| What syntax does a skill / tool / MCP server / agent use? | `references/capabilities/{skills,tools,mcp-servers,agents,workers}.md` |
| How do I write a *good* skill? | `references/capabilities/writing-skills.md` |
| How do I scaffold, install, or publish? | `references/capabilities/{quickstart,installing,publishing}.md` |
| What tools does every agent already have? | `references/tui/default-tools.md` |
| Programmatic SDK surface (`dreadnode.Capability`, `Agent`, `tool`) | `references/sdk/{capabilities,agents}.md` |
| Evaluation-driven improvement workflow | `references/guides/capability-optimization-loop.md` |

Three hand-written companions sit next to this skill:

- `promoting-capabilities.md` — read when a scratch capability has earned its keep and the user wants to turn it into a proper, shared one.
- `capability-improvement.md` — read when the user wants to optimize a capability beyond agent `instructions`: stack-aware mutation across skills, prompts, and tool rules.
- `runtime-default-capability.md` — read when the user is asking how the bundled `dreadnode` capability fits into the runtime, or wants to replace the legacy hardcoded default.

A sibling skill, `research-capabilities`, owns the "what's out there for this work" research mechanic. This skill invokes it from Step 2 of both paths; it can also be used standalone when a user asks "what tools exist for X" without committing to building anything.

---

## Fast path: tool up and go

Use when the user's ask is "help me do X" or "build a capability so I can do X." Goal: get them doing X as quickly and effectively as possible.

### 1. Restate the work in one sentence

Confirm you understood. Do not interview.

> "Got it — you want to sweep your Packagist extensions for leaked secrets in old image tags. Let me find the right tools."

If the domain is actually ambiguous, one clarifying question — not three.

### 2. Research the space — invoke `research-capabilities`

Hand off to the `research-capabilities` skill. It owns the parallel query fan-out (methodology, CLIs, MCP servers, existing Dreadnode capabilities, recent signal), provenance tiers, and the fixed output shape. Target is ~30–60 seconds and a confident recommendation.

The recommendation you get back drives Step 3. If `research-capabilities` returns "not enough signal," stop and surface that to the user — don't fabricate a shape.

Quick sanity rules that apply regardless:

- Methodologies beat greenfield design. A respected write-up that already encodes the workflow is worth more than any tool.
- An expert CLI + bash beats a new Python wrapper almost always.
- MCP is worth it when the agent will call the same operation many times in a run, or when the CLI is genuinely awkward (GUI tools, stateful sessions).
- Never auto-install external MCP servers or skills you haven't eyeballed. The shortlist from research is a recommendation, not a dependency graph.

### 3. Decide shape, cheapest first

```
Can the agent do this with bash + an existing CLI?
  YES → a short skill teaching the methodology is enough. Stop here.
  NO  → Is there a trustworthy MCP server or library?
    YES → reference it in the manifest, skill teaches the workflow.
    NO  → write a minimal tool (Python or MCP). Keep it scoped to this session.
         Only consider a custom agent definition if the default agent's posture is genuinely wrong.
```

Most fast-path capabilities bottom out at the first arrow: one skill, no custom tools.

### 4. Write the thinnest skill that helps

Don't reach for `dn capability init`'s full scaffold unless you're already in ship-it mode. A fast-path capability is usually:

```
scratch-<slug>/
├── capability.yaml       # 4 lines: schema, name, version, description
└── skills/<slug>/
    └── SKILL.md          # half a page — workflow, invocations, what to look for
```

Two ways to bootstrap:

- `dn capability init scratch-<slug> --with-skills`, then delete `agents/example.md` and anything else you don't need. You're left with manifest + one skill.
- Or hand-write the two files directly in the user's working directory.

To load it into the current session, either:

- `dn capability install ./scratch-<slug>` — symlinks into `~/.dreadnode/capabilities/`, live edits, easy to uninstall.
- Or set `DREADNODE_CAPABILITY_DIRS=./` so the runtime picks up any capability folder in the working tree without touching the user-local store.

For skill-writing craft, read `references/capabilities/writing-skills.md`. If the agent already knows the tool well (common CLIs), a skill of 40 lines is plenty — resist the urge to write a manual.

### 5. Do the work

Run `/reload` in the TUI so the session picks up the new capability, then run the user's actual request. The session is the test — if the skill helps the agent produce good work on the user's real target, it's working. If not, edit in place and `/reload` again. The symlink install means your edits are already on disk; `/reload` re-reads the capability registry so they take effect on the next turn.

Two patterns worth watching for:

- **The agent ignores the skill.** Description is likely the culprit — rewrite the "Use when…" line with the user's actual phrasing. Skills undertrigger more often than overtrigger.
- **The agent uses the skill but re-derives the workflow each time.** The body has too much preamble and not enough working instruction. Cut the preamble; the agent already knows the domain.

### 6. Offer to promote — only when it worked

At a natural stopping point, if the capability earned its keep:

> "This worked on the first three tags. Want me to flesh this out into a proper capability you could share? I'd tighten the description, add a couple of test prompts, and set up the publish path."

If yes, see `promoting-capabilities.md` for the upgrade path, then jump to the ship-it section below. If no, leave the scratch capability where it is — the user can delete it, keep it as a workbench, or come back to it later.

Do not push this. Most scratch capabilities should stay scratch.

---

## Ship-it path: authoring a shared capability

Use when the user explicitly wants to design, polish, and publish a capability for reuse — their team, their org, the public catalog. Also use when a scratch capability from the fast path has proven its value and the user wants to promote it (see `promoting-capabilities.md`).

The difference from the fast path is posture: now you *are* building an artifact. Research is deeper, testing is structured, the description gets optimized, the publish step matters.

### 1. Research deliberately

Invoke `research-capabilities` with a wider lens — same mechanic, longer budget. The fan-out returns candidates; pick the most relevant authoritative methodology and read it end-to-end before writing. That deeper read is a second, deliberate pass — not part of the initial recommendation. Read one well-structured bundled capability (`ls ~/.dreadnode/capabilities/`) before writing new patterns. Identify existing tools you should be wrapping instead of reimplementing.

### 2. Decide architecture

Same decision tree as the fast path, worth taking longer over. The mutation cost goes up once a capability is published. Prefer skills over tools, MCP over Python toolsets, and leave custom agent definitions for cases where the default agent's behavior is genuinely wrong. See `references/capabilities/writing-skills.md` for why the ordering matters.

### 3. Scaffold, install for live development

`dn capability init <name>` (with `--with-skills` if you'll include skills — you almost always should). `dn capability --help` lists the full set of options. Trim what you don't need from the scaffold — an empty `tools/` directory is a promise to yourself that rots.

`dn capability install ./<name>` to symlink into `~/.dreadnode/capabilities/`. Edits are live; no reinstall between changes.

### 4. Write the skills

The full craft is in `references/capabilities/writing-skills.md`. Summary:

- Description triggers; body teaches.
- Match body shape to the kind of work (research / integration / process).
- Explain *why*. Heavy `MUST`/`ALWAYS`/`NEVER` is a smell.
- One excellent example beats many mediocre ones.
- Bundle reference detail and scripts beside `SKILL.md` for on-demand loading — don't inline everything.

### 5. Test, iterate, and publish

A skill you haven't tested against a real prompt is a guess.

- Run 2–3 realistic prompts — things a real user would actually say.
- Read the transcripts, not just the outputs. Intermediate steps reveal wasted effort and skipped decisions.
- **Cut what isn't pulling weight.** If the agent ignores a section, remove it. Shorter skills are better skills.
- **Sharpen at decision points.** If the agent went off-track, the skill was unclear *there*. Add a sentence explaining why, not a paragraph of new rules.
- **Bundle repeated work.** If every run independently produces the same helper script, drop it in `scripts/` and have the skill call it.

Complexity should decrease over iterations. If the body grows on every pass, you're patching instead of fixing.

Publish with `dn capability push` once the capability is working. `dn capability --help` covers visibility, versioning, and CI sync.

For evaluation-driven scaling — formal datasets, scorers, the optimization loop — read `references/guides/capability-optimization-loop.md`. The hosted `dn optimize submit` path currently mutates only agent `instructions`; for stack-aware improvement across skills, prompts, and tool rules, read `capability-improvement.md`.

---

## Common pitfalls

- **Over-scaffolding on the first pass.** A Python toolset, an MCP server, a custom agent, and three skills before the user has done the work once is a cathedral when you need a tent.
- **Duplicating reference docs.** If it's in `--help` or a file the agent can read, point at it. Duplicated content drifts and wastes tokens.
- **Promoting a scratch capability that didn't actually work.** If the session was rough, fix or discard — don't paper over with polish.
