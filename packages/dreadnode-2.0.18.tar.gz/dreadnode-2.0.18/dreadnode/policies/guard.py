"""Guard session policy — headless mode plus LLM-judged tool gating.

Subclasses :class:`HeadlessSessionPolicy` so the inherited
``is_autonomous=True``, ``max_steps`` budget, and per-turn step counter
all carry over via MRO. Adds a ``ToolStart`` gate backed by a
:class:`ProcessJudge` that consults an LLM before each tool call.

Composition: holds the judge in a private attribute, builds the
gating hook via :func:`process_judge_hook`, and merges it with the
parent's hooks in the :meth:`hooks` property override. The hook
closure captures messages from ``GenerationStart`` and gates on
``ToolStart``; the policy itself stays declarative.
"""

import typing as t
from pathlib import Path

from pydantic import Field, PrivateAttr, model_validator

from dreadnode.agents.hooks import (
    OnDeny,
    OnJudgeError,
    TranscriptStrategy,
    process_judge_hook,
)
from dreadnode.agents.process_judge import ProcessJudge
from dreadnode.core.hook import Hook
from dreadnode.policies import HeadlessSessionPolicy


class GuardSessionPolicy(HeadlessSessionPolicy):
    """Headless mode + LLM-judged tool-call gating.

    The runtime auto-denies ``ask_user()`` (inherited
    ``is_autonomous=True``), enforces a per-turn step budget (inherited
    ``max_steps``), and runs every tool call past a
    :class:`ProcessJudge` for allow/deny.

    Example::

        # Mid-session swap from the TUI:
        # /policy guard judge_model=anthropic/claude-haiku-4-5

        # Or from the API:
        POST /api/sessions/{id}/policy
        {
          "name": "guard",
          "judge_model": "anthropic/claude-haiku-4-5",
          "rubric": "In-scope: api.example.com only",
          "max_steps": 20
        }
    """

    name: t.ClassVar[str] = "guard"
    display_label: t.ClassVar[str] = "guard"

    judge_model: str = Field(min_length=1, description="Model identifier for the process judge.")
    rubric: str | Path | None = Field(
        default=None,
        description=(
            "Optional user rubric layered on top of the safety-floor default "
            "unless ``replace_default_rubric`` is true."
        ),
    )
    replace_default_rubric: bool = False

    transcript_strategy: TranscriptStrategy = "intent_only"
    on_deny: OnDeny = "retry"
    on_judge_error: OnJudgeError = "deny"
    always_allow: tuple[str, ...] = ()
    always_deny: tuple[str, ...] = ()

    _judge: ProcessJudge = PrivateAttr()
    _judge_hook: Hook = PrivateAttr()

    @model_validator(mode="after")
    def _check_short_circuit_lists(self) -> "GuardSessionPolicy":
        overlap = set(self.always_allow) & set(self.always_deny)
        if overlap:
            raise ValueError(f"always_allow and always_deny share entries: {sorted(overlap)}")
        return self

    def model_post_init(self, _ctx: t.Any) -> None:
        # Route the judge through the same model-resolution layer the agent
        # uses for its turn generator. ``dn/<provider>/<name>`` resolves to
        # the platform's LiteLLM proxy (DREADNODE_LLM_BASE / DREADNODE_LLM_API_KEY
        # or local LITELLM_PUBLIC_URL / LITELLM_MASTER_KEY fallbacks). Direct
        # provider strings pass through as-is so the user's own provider
        # API key is honored. The intent: judge billing semantics match the
        # agent's — pay-via-platform if you picked a dn/ model, pay your
        # provider directly if you picked an explicit one.
        from dreadnode.app.server.model_resolution import (
            build_turn_generator,
            resolve_turn_model_config,
        )

        judge_model_config = resolve_turn_model_config(
            requested_model=self.judge_model,
            remembered_model=None,
            agent_def=None,
        )
        resolved_judge_model = build_turn_generator(judge_model_config)

        self._judge = ProcessJudge(
            model=resolved_judge_model,
            rubric=self.rubric,
            replace_default_rubric=self.replace_default_rubric,
        )
        self._judge_hook = process_judge_hook(
            self._judge,
            transcript_strategy=self.transcript_strategy,
            on_deny=self.on_deny,
            on_judge_error=self.on_judge_error,
            always_allow=self.always_allow,
            always_deny=self.always_deny,
        )

    @property
    def hooks(self) -> list[Hook]:
        """Inherited step-budget hooks plus the judge gate."""
        return [*super().hooks, self._judge_hook]


__all__ = ["GuardSessionPolicy"]
