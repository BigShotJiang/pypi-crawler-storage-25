"""Unit tests for the native_views package.

Tests the registry, base handler protocol, and shared utility functions.
Platform-specific handlers (android/ios) are not tested here since they
require their respective runtime environments; they are exercised by
E2E tests on device.
"""

from typing import Any, Dict, Tuple

import pytest

from pythonnative.layout import LAYOUT_STYLE_KEYS
from pythonnative.native_views import NativeViewRegistry, set_registry
from pythonnative.native_views.base import (
    ViewHandler,
    is_vertical,
    parse_color_int,
    resolve_padding,
)

# ======================================================================
# parse_color_int
# ======================================================================


def test_parse_color_hex6() -> None:
    result = parse_color_int("#FF0000")
    assert result == parse_color_int("FF0000")
    expected = int("FFFF0000", 16)
    if expected > 0x7FFFFFFF:
        expected -= 0x100000000
    assert result == expected


def test_parse_color_hex8() -> None:
    result = parse_color_int("#80FF0000")
    raw = int("80FF0000", 16)
    expected = raw - 0x100000000  # signed conversion
    assert result == expected


def test_parse_color_int_passthrough() -> None:
    assert parse_color_int(0x00FF00) == 0x00FF00


def test_parse_color_signed_conversion() -> None:
    result = parse_color_int("#FFFFFFFF")
    assert result < 0


def test_parse_color_with_whitespace() -> None:
    assert parse_color_int("  #FF0000  ") == parse_color_int("#FF0000")


# ======================================================================
# resolve_padding (legacy helper retained for handlers that still need it)
# ======================================================================


def test_resolve_padding_none() -> None:
    assert resolve_padding(None) == (0, 0, 0, 0)


def test_resolve_padding_int() -> None:
    assert resolve_padding(16) == (16, 16, 16, 16)


def test_resolve_padding_float() -> None:
    assert resolve_padding(8.5) == (8, 8, 8, 8)


def test_resolve_padding_dict_horizontal_vertical() -> None:
    result = resolve_padding({"horizontal": 10, "vertical": 20})
    assert result == (10, 20, 10, 20)


def test_resolve_padding_dict_individual() -> None:
    result = resolve_padding({"left": 1, "top": 2, "right": 3, "bottom": 4})
    assert result == (1, 2, 3, 4)


def test_resolve_padding_dict_all() -> None:
    result = resolve_padding({"all": 12})
    assert result == (12, 12, 12, 12)


def test_resolve_padding_unsupported_type() -> None:
    assert resolve_padding("invalid") == (0, 0, 0, 0)


# ======================================================================
# is_vertical
# ======================================================================


def test_is_vertical_column() -> None:
    assert is_vertical("column") is True


def test_is_vertical_column_reverse() -> None:
    assert is_vertical("column_reverse") is True


def test_is_vertical_row() -> None:
    assert is_vertical("row") is False


def test_is_vertical_row_reverse() -> None:
    assert is_vertical("row_reverse") is False


# ======================================================================
# Layout-engine ownership
# ======================================================================


def test_layout_style_keys_includes_flex_props() -> None:
    """All flex / sizing props are owned by the layout engine, not handlers."""
    for key in (
        "width",
        "height",
        "flex",
        "flex_grow",
        "flex_shrink",
        "flex_basis",
        "flex_direction",
        "justify_content",
        "align_items",
        "align_self",
        "padding",
        "margin",
        "spacing",
        "gap",
        "position",
        "top",
        "right",
        "bottom",
        "left",
        "aspect_ratio",
    ):
        assert key in LAYOUT_STYLE_KEYS


# ======================================================================
# ViewHandler protocol
# ======================================================================


def test_view_handler_create_raises() -> None:
    handler = ViewHandler()
    with pytest.raises(NotImplementedError):
        handler.create({})


def test_view_handler_update_raises() -> None:
    handler = ViewHandler()
    with pytest.raises(NotImplementedError):
        handler.update(None, {})


def test_view_handler_add_child_noop() -> None:
    handler = ViewHandler()
    handler.add_child(None, None)


def test_view_handler_remove_child_noop() -> None:
    handler = ViewHandler()
    handler.remove_child(None, None)


def test_view_handler_insert_child_delegates() -> None:
    calls: list = []

    class TestHandler(ViewHandler):
        def add_child(self, parent: Any, child: Any) -> None:
            calls.append(("add", parent, child))

    handler = TestHandler()
    handler.insert_child("parent", "child", 0)
    assert calls == [("add", "parent", "child")]


def test_view_handler_set_frame_default_noop() -> None:
    """Default ``set_frame`` is a no-op so virtual nodes can opt out."""
    handler = ViewHandler()
    handler.set_frame(None, 0, 0, 100, 50)


def test_view_handler_measure_intrinsic_default_zero() -> None:
    """Default ``measure_intrinsic`` returns ``(0, 0)`` for handlers without intrinsic size."""
    handler = ViewHandler()
    assert handler.measure_intrinsic(None, 100.0, 100.0) == (0.0, 0.0)


# ======================================================================
# NativeViewRegistry
# ======================================================================


class StubView:
    def __init__(self, type_name: str, props: Dict[str, Any]) -> None:
        self.type_name = type_name
        self.props = dict(props)
        self.frame: Tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)


class StubHandler(ViewHandler):
    def create(self, props: Dict[str, Any]) -> StubView:
        return StubView("Stub", props)

    def update(self, native_view: Any, changed_props: Dict[str, Any]) -> None:
        native_view.props.update(changed_props)

    def set_frame(self, native_view: Any, x: float, y: float, width: float, height: float) -> None:
        native_view.frame = (x, y, width, height)

    def measure_intrinsic(self, native_view: Any, max_width: float, max_height: float) -> Tuple[float, float]:
        # Pretend the stub view is 40x10 plus its content length.
        return (min(40.0 + len(native_view.props.get("text", "")), max_width), 10.0)


def test_registry_create_view() -> None:
    reg = NativeViewRegistry()
    reg.register("Text", StubHandler())
    view = reg.create_view("Text", {"text": "hello"})
    assert isinstance(view, StubView)
    assert view.props["text"] == "hello"


def test_registry_unknown_type_raises() -> None:
    reg = NativeViewRegistry()
    with pytest.raises(ValueError, match="Unknown element type"):
        reg.create_view("NonExistent", {})


def test_registry_update_view() -> None:
    reg = NativeViewRegistry()
    reg.register("Text", StubHandler())
    view = reg.create_view("Text", {"text": "old"})
    reg.update_view(view, "Text", {"text": "new"})
    assert view.props["text"] == "new"


def test_registry_update_unknown_type_noop() -> None:
    reg = NativeViewRegistry()
    reg.update_view(StubView("X", {}), "X", {"a": 1})


def test_registry_child_ops_unknown_type_noop() -> None:
    reg = NativeViewRegistry()
    reg.add_child(None, None, "Unknown")
    reg.remove_child(None, None, "Unknown")
    reg.insert_child(None, None, "Unknown", 0)


def test_registry_set_frame_dispatches_to_handler() -> None:
    reg = NativeViewRegistry()
    reg.register("Text", StubHandler())
    view = reg.create_view("Text", {"text": "x"})
    reg.set_frame(view, "Text", 5.0, 10.0, 100.0, 50.0)
    assert view.frame == (5.0, 10.0, 100.0, 50.0)


def test_registry_set_frame_unknown_type_noop() -> None:
    reg = NativeViewRegistry()
    reg.set_frame(None, "Unknown", 0, 0, 100, 50)


def test_registry_measure_intrinsic_dispatches() -> None:
    reg = NativeViewRegistry()
    reg.register("Text", StubHandler())
    view = reg.create_view("Text", {"text": "abc"})
    w, h = reg.measure_intrinsic(view, "Text", 1000.0, 1000.0)
    assert w == 43.0  # 40 + 3
    assert h == 10.0


def test_registry_measure_intrinsic_unknown_type_zero() -> None:
    reg = NativeViewRegistry()
    assert reg.measure_intrinsic(None, "Unknown", 1000.0, 1000.0) == (0.0, 0.0)


def test_set_registry_injects() -> None:
    reg = NativeViewRegistry()
    set_registry(reg)
    from pythonnative.native_views import _registry

    assert _registry is reg
    set_registry(None)
