from __future__ import annotations

from typing import Any, Callable
from urllib.parse import unquote

from typing_extensions import override

from aws_lambda_powertools.shared.headers_serializer import (
    BaseHeadersSerializer,
    MultiValueHeadersSerializer,
    SingleValueHeadersSerializer,
)
from aws_lambda_powertools.utilities.data_classes.common import (
    BaseProxyEvent,
    CaseInsensitiveDict,
    DictWrapper,
)


class ALBEventRequestContext(DictWrapper):
    @property
    def elb_target_group_arn(self) -> str:
        """Target group arn for your Lambda function"""
        return self["elb"]["targetGroupArn"]


class ALBEvent(BaseProxyEvent):
    """Application load balancer event

    Documentation:
    --------------
    - https://docs.aws.amazon.com/lambda/latest/dg/services-alb.html
    - https://docs.aws.amazon.com/elasticloadbalancing/latest/application/lambda-functions.html
    """

    @override
    def __init__(self, data: dict[str, Any], json_deserializer: Callable | None = None):
        super().__init__(data, json_deserializer)
        self.decode_query_parameters = False

    @property
    def request_context(self) -> ALBEventRequestContext:
        return ALBEventRequestContext(self["requestContext"])

    @property
    def resolved_query_string_parameters(self) -> dict[str, list[str]]:
        multi_value = self.multi_value_query_string_parameters
        single_value = super().resolved_query_string_parameters

        if not multi_value:
            params = single_value
        elif not single_value:
            params = multi_value
        else:
            # Merge both: multi_value takes precedence, single_value fills missing keys
            params = {**single_value, **multi_value}

        if not self.decode_query_parameters:
            return params

        # Decode the parameter keys and values
        decoded_params = {}
        for k, vals in params.items():
            decoded_params[unquote(k)] = [unquote(v) for v in vals]

        return decoded_params

    @property
    def multi_value_headers(self) -> dict[str, list[str]]:
        return CaseInsensitiveDict(self.get("multiValueHeaders"))

    @property
    def resolved_headers_field(self) -> dict[str, Any]:
        return self.multi_value_headers or self.headers

    def header_serializer(self) -> BaseHeadersSerializer:
        # When using the ALB integration, the `multiValueHeaders` feature can be disabled (default) or enabled.
        # We can determine if the feature is enabled by looking if the event has a `multiValueHeaders` key.
        if self.multi_value_headers:
            return MultiValueHeadersSerializer()

        return SingleValueHeadersSerializer()
