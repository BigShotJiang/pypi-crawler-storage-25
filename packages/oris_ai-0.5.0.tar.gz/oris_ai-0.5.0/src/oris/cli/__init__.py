"""CLI package for Oris."""
