# 5bb-suite

One-command install of the full **5 Bare Bones** developer toolbox.

```bash
pip install 5bb-suite
# or
uv add 5bb-suite
```

This meta-package installs:

| Tool | Description | Upstream |
|---|---|---|
| `micro` | Modern terminal text editor | [micro-editor/micro](https://github.com/micro-editor/micro) |
| `task` | Fast task runner (Taskfile) | [go-task/task](https://github.com/go-task/task) |
| `yamlquery` | YAML / JSON / XML processor | [mikefarah/yq](https://github.com/mikefarah/yq) |

Each tool downloads its pre-built binary on first use and caches it in `~/.cache/`.
