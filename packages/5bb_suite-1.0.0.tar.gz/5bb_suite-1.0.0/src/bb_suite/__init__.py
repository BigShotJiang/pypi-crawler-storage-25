"""
5bb-suite – meta-package that installs the full 5 Bare Bones developer toolbox.

Installing this package pulls in:
  - 5bb-micro  : micro terminal editor   (https://micro-editor.github.io)
  - 5bb-task   : Task runner / Taskfile  (https://taskfile.dev)
  - 5bb-yaml   : yamlquery YAML toolkit  (https://mikefarah.gitbook.io/yq/)
"""

__version__ = "1.0.0"
