# yfd

Offline Yahoo Finance data for 17,000+ US-listed securities (stocks, ETFs, REITs). Daily OHLCV prices, financial statements, holders, analyst estimates, and 40 data types — served from Cloudflare R2, updated nightly.

No API keys. No rate limits. No Yahoo dependency at query time.

## Install

```
pip install yfd
```

## Python API

```python
import yfd

# Get price history
df = yfd.get("AAPL", "price", start="2026-01-01")

# Get annual income statement
inc = yfd.get("AAPL", "income_stmt")

# Get company info
info = yfd.get("AAPL", "info")

# Works for ETFs too
spy = yfd.get("SPY", "price", start="2026-03-01")

# List all data types
yfd.types()

# List all symbols
yfd.symbols()  # ["A", "AA", "AAPL", ..., "SPY", "QQQ", ...]
```

`get()` returns a DataFrame for tabular data, dict/list/str for other types, or `None` if not found. All data stored as zstd-compressed parquet.

## CLI

```bash
yfd price AAPL --start 2026-03-01
yfd income-stmt AAPL
yfd info AAPL --json
yfd balance-sheet MSFT
yfd types                          # list all 40 data types
yfd symbols                        # list all symbols
```

Hyphens and underscores both work: `income-stmt` = `income_stmt`.

## Data Types

### Price & Actions
| Type | Description |
|------|-------------|
| `price` | Daily OHLCV (Open, High, Low, Close, Volume) |
| `dividends` | Dividend payment history |
| `splits` | Stock split history |
| `actions` | Dividends and splits combined |
| `capital_gains` | Capital gains distributions (ETFs/funds) |

### Financial Statements
| Type | Description |
|------|-------------|
| `income_stmt` | Annual income statement |
| `income_stmt_quarterly` | Quarterly income statement |
| `income_stmt_ttm` | Trailing 12-month income statement |
| `balance_sheet` | Annual balance sheet |
| `balance_sheet_quarterly` | Quarterly balance sheet |
| `cashflow` | Annual cash flow statement |
| `cashflow_quarterly` | Quarterly cash flow statement |
| `cashflow_ttm` | Trailing 12-month cash flow |

### Holders
| Type | Description |
|------|-------------|
| `major_holders` | Insider/institution ownership % |
| `institutional_holders` | Top institutional holders |
| `mutualfund_holders` | Top mutual fund holders |
| `insider_transactions` | Insider buy/sell transactions |
| `insider_purchases` | Net insider purchase activity |
| `insider_roster` | Insider roster with positions |

### Analyst & Estimates
| Type | Description |
|------|-------------|
| `recommendations` | Analyst recommendation trend |
| `upgrades_downgrades` | Analyst upgrade/downgrade history |
| `earnings_estimate` | EPS estimates by period |
| `revenue_estimate` | Revenue estimates by period |
| `earnings_history` | Historical EPS vs estimates |
| `eps_trend` | EPS trend |
| `eps_revisions` | EPS revision history |
| `growth_estimates` | Growth estimates (stock/industry/sector) |
| `analyst_price_targets` | Target high/low/mean/median price |

### Company
| Type | Description |
|------|-------------|
| `info` | Full company information |
| `fast_info` | Quick price/volume stats |
| `sustainability` | ESG scores |
| `calendar` | Upcoming earnings/dividend dates |
| `history_metadata` | Exchange, currency, trading hours |
| `news` | Latest news articles |
| `sec_filings` | SEC 10-K/10-Q filing history |

### TradingView Screener
| Type | Description |
|------|-------------|
| `screener` | 1,000+ fields: classification, fundamentals, daily technicals (RSI, MACD, EMA...), analyst ratings |

### Other
| Type | Description |
|------|-------------|
| `earnings` | Earnings dates with EPS surprise |
| `options` | Full options chain (all expiries) |
| `isin` | ISIN identifier |
| `funds_data` | ETF/mutual fund details |

## How It Works

Two GitHub Actions pipelines run every weeknight:

1. **Price + screener update** (10 PM ET) — fetches daily OHLCV for all 17,000+ symbols via Yahoo Finance chart API, plus 1,000+ TradingView fields, uploads to R2
2. **Fundamentals update** (midnight ET) — fetches 40 data types per symbol via Yahoo Finance quoteSummary/timeseries APIs, uploads to R2

The client library reads directly from R2 public URLs. No Yahoo calls at query time.

## Architecture

```
Yahoo Finance APIs ──→ GitHub Actions (nightly) ──→ Cloudflare R2
                                                         │
                                    yfd CLI / Python ◄───┘
```

Symbol universe sourced from [TradingView screener](https://github.com/deepentropy/tvscreener) covering NYSE, NASDAQ, AMEX, CBOE, and OTC markets.
