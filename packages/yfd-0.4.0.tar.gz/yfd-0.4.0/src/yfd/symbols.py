"""Fetch US-listed symbols (stocks, ETFs, REITs) from TradingView screener."""

from tvscreener import StockScreener
from tvscreener.field import Market, SymbolType


def fetch_symbols() -> list[str]:
    """Fetch all US-listed symbols and format for Yahoo Finance."""
    ss = StockScreener()
    ss.set_markets(Market.AMERICA)
    ss.set_range(0, 25000)
    ss.set_symbol_types(
        SymbolType.COMMON_STOCK,
        SymbolType.ETF,
        SymbolType.DEPOSITORY_RECEIPT,
        SymbolType.PREFERRED_STOCK,
        SymbolType.REIT,
    )
    df = ss.get()
    raw = [s.split(":")[1] for s in df["Symbol"].tolist() if ":" in s]
    return [to_yahoo_symbol(s) for s in raw]


def to_yahoo_symbol(symbol: str) -> str:
    """Convert standard ticker to Yahoo Finance format (dots/slashes become dashes)."""
    return symbol.replace(".", "-").replace("/", "-")
