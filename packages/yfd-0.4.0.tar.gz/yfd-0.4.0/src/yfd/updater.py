"""Nightly updater: fetch latest daily data and merge into R2."""

import io
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone

import pandas as pd

from yfd.r2 import R2
from yfd.symbols import fetch_symbols
from yfd.yahoo import Yahoo


def get_r2_latest_date(r2: R2, sample: list[str]) -> str | None:
    """Check a sample of symbols in R2 to find the latest date we already have."""
    latest = None
    for sym in sample:
        try:
            resp = r2.s3.get_object(Bucket=r2.bucket, Key=f"daily/{sym}.parquet")
            df = pd.read_parquet(io.BytesIO(resp["Body"].read()), columns=["Close"])
            last = df.index[-1]
            if latest is None or last > latest:
                latest = last
        except Exception:
            continue
    return latest


def fetch_latest(
    symbols: list[str],
    start: str,
    workers: int = 20,
) -> tuple[dict[str, pd.DataFrame], list[str]]:
    """Fetch daily data from *start* for all symbols using direct Yahoo API."""
    print(f"Downloading {len(symbols)} symbols from {start} (workers={workers})...")

    yahoo = Yahoo()
    results: dict[str, pd.DataFrame] = {}
    no_data: list[str] = []

    def _fetch(sym):
        df, _, _ = yahoo.chart(sym, start=start)
        return sym, df

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_fetch, s): s for s in symbols}
        done = 0
        for fut in as_completed(futures):
            sym = futures[fut]
            try:
                _, df = fut.result()
                if df is not None and not df.empty:
                    results[sym] = df
                else:
                    no_data.append(sym)
            except Exception:
                no_data.append(sym)

            done += 1
            if done % 500 == 0:
                print(f"  {done}/{len(symbols)} downloaded...")

    return results, no_data


def _merge_one(symbol: str, new_df: pd.DataFrame, r2: R2) -> bool:
    """Download existing parquet from R2, merge new rows, re-upload. All in memory."""
    key = f"daily/{symbol}.parquet"

    try:
        resp = r2.s3.get_object(Bucket=r2.bucket, Key=key)
        existing = pd.read_parquet(io.BytesIO(resp["Body"].read()))
        combined = pd.concat([existing, new_df])
        combined = combined[~combined.index.duplicated(keep="last")]
        combined = combined.sort_index()
    except Exception:
        combined = new_df

    buf = io.BytesIO()
    combined.to_parquet(buf, compression="zstd")
    r2.s3.put_object(Bucket=r2.bucket, Key=key, Body=buf.seek(0) or buf.read())
    return True


def merge_and_upload(new_data: dict[str, pd.DataFrame], r2: R2, workers: int = 80) -> tuple[list[str], list[str]]:
    """Merge new data with existing R2 parquets concurrently. Returns ([uploaded], [failed])."""
    uploaded = []
    failed = []

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_merge_one, sym, df, r2): sym for sym, df in new_data.items()}
        for fut in as_completed(futures):
            sym = futures[fut]
            try:
                fut.result()
                uploaded.append(sym)
            except Exception as e:
                failed.append((sym, str(e)))

            done = len(uploaded) + len(failed)
            if done % 200 == 0:
                print(f"  {done}/{len(new_data)} merged...")

    return uploaded, failed


def write_report(symbols: list[str], start: str, new_data: dict, no_data: list[str], uploaded: list[str], failed: list):
    """Write run report to reports/price/{date}.txt."""
    from datetime import date
    from pathlib import Path

    lines = []
    lines.append(f"NIGHTLY PRICE REPORT — {date.today()}")
    lines.append(f"Symbols: {len(symbols)}, Start date: {start}")
    lines.append(f"Fetched: {len(new_data)}, No data: {len(no_data)}, Uploaded: {len(uploaded)}, Upload failed: {len(failed)}")

    if failed:
        lines.append(f"\nUPLOAD FAILURES ({len(failed)}):")
        for sym, err in sorted(failed):
            lines.append(f"  {sym}: {err}")

    if no_data:
        lines.append(f"\nNO DATA ({len(no_data)} symbols, likely delisted):")
        lines.append(f"  {', '.join(sorted(no_data))}")

    report = "\n".join(lines)
    print(report)

    out = Path("reports/price")
    out.mkdir(parents=True, exist_ok=True)
    (out / f"{date.today()}.txt").write_text(report)


def main():
    from dotenv import load_dotenv

    load_dotenv()

    print("Fetching symbols...")
    symbols = fetch_symbols()
    print(f"Found {len(symbols)} symbols")

    r2 = R2.from_env()

    # Determine start date from R2 (sample 5 liquid symbols)
    sample = [s for s in ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA"] if s in symbols]
    latest = get_r2_latest_date(r2, sample)
    if latest is not None:
        # Fetch from the day after the latest date in R2
        start = (latest + timedelta(days=1)).strftime("%Y-%m-%d")
        print(f"R2 latest: {latest.date()}, fetching from {start}")
    else:
        # Fallback: last 5 days
        start = (datetime.now(timezone.utc) - timedelta(days=5)).strftime("%Y-%m-%d")
        print(f"No R2 data found, fetching from {start}")

    new_data, no_data = fetch_latest(symbols, start)
    print(f"Got data for {len(new_data)}/{len(symbols)} symbols")

    if not new_data:
        print("Nothing new to upload")
        write_report(symbols, start, new_data, no_data, [], [])
        return

    print("Merging and uploading to R2...")
    uploaded, failed = merge_and_upload(new_data, r2)

    # Update public symbols index from all daily/ keys in R2
    all_symbols = []
    paginator = r2.s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=r2.bucket, Prefix="daily/"):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if key.endswith(".parquet"):
                all_symbols.append(key.removeprefix("daily/").removesuffix(".parquet"))
    r2.s3.put_object(
        Bucket=r2.bucket,
        Key="symbols.json",
        Body=json.dumps(sorted(all_symbols)).encode(),
        ContentType="application/json",
    )
    print(f"Updated symbols.json with {len(all_symbols)} symbols")

    write_report(symbols, start, new_data, no_data, uploaded, failed)


if __name__ == "__main__":
    main()
