"""Fetch full daily OHLCV history and save as per-symbol parquet files."""

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from yfd.yahoo import Yahoo


def fetch_daily_history(
    symbols: list[str],
    output_dir: Path,
    batch_size: int = 50,
    pause: float = 1.0,
    end: str | None = None,
    workers: int = 10,
) -> list[str]:
    """Fetch full daily OHLCV history and save as per-symbol parquet files.

    Returns list of symbols that failed.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    existing = {p.stem for p in output_dir.glob("*.parquet")}
    remaining = [s for s in symbols if s not in existing]
    if existing:
        print(f"Skipping {len(existing)} already fetched, {len(remaining)} remaining")

    yahoo = Yahoo()
    failed: list[str] = []
    total_batches = -(-len(remaining) // batch_size)

    for i in range(0, len(remaining), batch_size):
        batch = remaining[i : i + batch_size]
        batch_num = i // batch_size + 1
        print(f"[{batch_num}/{total_batches}] Fetching {len(batch)} symbols...")

        saved = 0

        def _fetch(sym):
            df, _, _ = yahoo.chart(sym, end=end, period="max")
            return sym, df

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_fetch, s): s for s in batch}
            for fut in as_completed(futures):
                sym = futures[fut]
                try:
                    _, df = fut.result()
                    if df is not None and not df.empty:
                        df.to_parquet(output_dir / f"{sym}.parquet")
                        saved += 1
                    else:
                        failed.append(sym)
                except Exception:
                    failed.append(sym)

        print(f"  Saved {saved}/{len(batch)} symbols")

        if batch_num < total_batches:
            time.sleep(pause)

    return failed
