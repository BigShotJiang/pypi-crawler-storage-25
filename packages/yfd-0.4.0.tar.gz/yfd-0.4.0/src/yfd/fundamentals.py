"""Fetch non-price data (financials, holders, analysis, etc.) and upload to R2.

Uses direct Yahoo Finance API calls instead of yfinance.
"""

import io
import json
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd

from yfd.r2 import R2
from yfd.symbols import fetch_symbols
from yfd.yahoo import (
    BALANCE_SHEET_KEYS,
    CASH_FLOW_KEYS,
    INCOME_KEYS,
    Yahoo,
)

# All quoteSummary modules we need, fetched in a single API call per symbol.
QS_MODULES = [
    "majorHoldersBreakdown", "institutionOwnership", "fundOwnership",
    "insiderTransactions", "insiderHolders", "netSharePurchaseActivity",
    "recommendationTrend", "upgradeDowngradeHistory",
    "earningsTrend", "earningsHistory",
    "industryTrend", "sectorTrend", "indexTrend",
    "esgScores", "financialData", "calendarEvents", "secFilings",
    "quoteType", "defaultKeyStatistics", "assetProfile", "summaryDetail",
    "summaryProfile", "topHoldings", "fundProfile",
]

# (keys, timeseries prefix, R2 prefixes to upload to)
TIMESERIES_MAP = [
    (INCOME_KEYS,        "annual",    ["financials", "income_stmt"]),
    (INCOME_KEYS,        "quarterly", ["financials_quarterly", "income_stmt_quarterly"]),
    (INCOME_KEYS,        "trailing",  ["ttm_financials", "ttm_income_stmt"]),
    (BALANCE_SHEET_KEYS, "annual",    ["balance_sheet"]),
    (BALANCE_SHEET_KEYS, "quarterly", ["balance_sheet_quarterly"]),
    (CASH_FLOW_KEYS,     "annual",    ["cashflow"]),
    (CASH_FLOW_KEYS,     "quarterly", ["cashflow_quarterly"]),
    (CASH_FLOW_KEYS,     "trailing",  ["ttm_cashflow"]),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _raw(val):
    """Unwrap Yahoo's ``{raw, fmt}`` value wrapper."""
    if isinstance(val, dict) and "raw" in val:
        return val["raw"]
    return val


def _put_df(df: pd.DataFrame | pd.Series | None, r2: R2, key: str):
    if df is None or (hasattr(df, "empty") and df.empty):
        return
    if isinstance(df, pd.Series):
        df = df.to_frame()
    buf = io.BytesIO()
    df.to_parquet(buf, compression="zstd")
    r2.s3.put_object(Bucket=r2.bucket, Key=key, Body=buf.seek(0) or buf.read())



def _safe(fn, errors: list, label: str):
    """Call *fn*; on error, append to *errors* and return ``None``."""
    try:
        return fn()
    except Exception as e:
        errors.append(f"{label}: {e}")
        return None


# ---------------------------------------------------------------------------
# Parsers — chart events
# ---------------------------------------------------------------------------

def _parse_dividends(events):
    divs = events.get("dividends", {})
    if not divs:
        return None
    rows = [
        {"Date": pd.Timestamp(int(ts), unit="s"), "Dividends": d["amount"]}
        for ts, d in divs.items()
    ]
    return pd.DataFrame(rows).set_index("Date").sort_index()


def _parse_splits(events):
    splits = events.get("splits", {})
    if not splits:
        return None
    rows = [
        {
            "Date": pd.Timestamp(int(ts), unit="s"),
            "Stock Splits": s["numerator"] / s["denominator"],
        }
        for ts, s in splits.items()
    ]
    return pd.DataFrame(rows).set_index("Date").sort_index()


def _parse_actions(events):
    d = _parse_dividends(events)
    s = _parse_splits(events)
    if d is None and s is None:
        return None
    parts = [x for x in (d, s) if x is not None]
    return pd.concat(parts, axis=1).fillna(0)


def _parse_capital_gains(events):
    cg = events.get("capitalGains", {})
    if not cg:
        return None
    rows = [
        {"Date": pd.Timestamp(int(ts), unit="s"), "Capital Gains": d["amount"]}
        for ts, d in cg.items()
    ]
    return pd.DataFrame(rows).set_index("Date").sort_index()


# ---------------------------------------------------------------------------
# Parsers — quoteSummary → DataFrames
# ---------------------------------------------------------------------------

def _qs_list_df(qs, module, key):
    """Generic: extract a list from a quoteSummary module → DataFrame."""
    items = qs.get(module, {}).get(key, [])
    if not items:
        return None
    # Unwrap {raw, fmt} values in each row
    clean = [{k: _raw(v) for k, v in row.items() if k != "maxAge"} for row in items]
    return pd.DataFrame(clean)


def _qs_flat_df(qs, module):
    """Generic: flat dict → single-column DataFrame."""
    data = {k: _raw(v) for k, v in qs.get(module, {}).items() if k != "maxAge"}
    if not data:
        return None
    return pd.DataFrame.from_dict(data, orient="index", columns=["Value"])


def _parse_upgrades_downgrades(qs):
    items = qs.get("upgradeDowngradeHistory", {}).get("history", [])
    if not items:
        return None
    clean = [{k: _raw(v) for k, v in row.items() if k != "maxAge"} for row in items]
    df = pd.DataFrame(clean)
    if "epochGradeDate" in df.columns:
        df["GradeDate"] = pd.to_datetime(df["epochGradeDate"], unit="s")
        df = df.drop(columns=["epochGradeDate"]).set_index("GradeDate")
    return df


def _parse_trend_sub(qs, sub_key):
    """Extract a sub-dict from each earningsTrend period."""
    trend = qs.get("earningsTrend", {}).get("trend", [])
    if not trend:
        return None
    rows = []
    for item in trend[:4]:
        sub = item.get(sub_key, {})
        row = {"period": item.get("period")}
        for k, v in sub.items():
            if k != "maxAge":
                row[k] = _raw(v)
        rows.append(row)
    df = pd.DataFrame(rows)
    return df.set_index("period") if "period" in df.columns else df


def _parse_earnings_history(qs):
    items = qs.get("earningsHistory", {}).get("history", [])
    if not items:
        return None
    rows = []
    for item in items:
        row = {}
        for k, v in item.items():
            if k != "maxAge":
                row[k] = _raw(v)
        rows.append(row)
    return pd.DataFrame(rows)


def _parse_growth_estimates(qs):
    trend = qs.get("earningsTrend", {}).get("trend", [])
    if not trend:
        return None
    rows = []
    for item in trend:
        rows.append({
            "period": item.get("period"),
            "stockTrend": _raw(item.get("growth")),
        })
    df = pd.DataFrame(rows)
    for module, col in [
        ("industryTrend", "industryTrend"),
        ("sectorTrend", "sectorTrend"),
        ("indexTrend", "indexTrend"),
    ]:
        estimates = qs.get(module, {}).get("estimates", [])
        gmap = {e.get("period"): _raw(e.get("growth")) for e in estimates}
        df[col] = df["period"].map(gmap)
    return df.set_index("period") if "period" in df.columns else df


# ---------------------------------------------------------------------------
# Parsers — quoteSummary → JSON
# ---------------------------------------------------------------------------

def _parse_analyst_price_targets(qs):
    data = qs.get("financialData", {})
    result = {}
    for k, v in data.items():
        if k.startswith("target") or k == "currentPrice":
            clean = k.replace("target", "").lower() if k.startswith("target") else k
            result[clean] = _raw(v)
    return result or None


def _parse_calendar(qs):
    cal = qs.get("calendarEvents", {})
    if not cal:
        return None
    result = {}
    for k in ("dividendDate", "exDividendDate"):
        v = cal.get(k)
        if v is not None:
            result[k] = _raw(v)
    earnings = cal.get("earnings", {})
    for k in (
        "earningsDate", "earningsHigh", "earningsLow", "earningsAverage",
        "revenueHigh", "revenueLow", "revenueAverage",
    ):
        v = earnings.get(k)
        if v is not None:
            result[k] = [_raw(x) for x in v] if isinstance(v, list) else _raw(v)
    return result or None


def _parse_fast_info(qs, meta):
    result = {}
    for k in ("currency", "instrumentType", "exchangeName", "exchangeTimezoneName",
              "regularMarketPrice"):
        if k in meta:
            result[k] = meta[k]
    sd = qs.get("summaryDetail", {})
    for k in ("previousClose", "fiftyTwoWeekHigh", "fiftyTwoWeekLow",
              "fiftyDayAverage", "twoHundredDayAverage", "volume",
              "averageVolume", "averageVolume10days", "marketCap"):
        v = sd.get(k)
        if v is not None:
            result[k] = _raw(v)
    return result or None


def _parse_funds_data(qs):
    result = {}
    profile = qs.get("summaryProfile", {})
    if profile.get("longBusinessSummary"):
        result["description"] = profile["longBusinessSummary"]

    fp = qs.get("fundProfile", {})
    if fp:
        overview = {k: fp[k] for k in ("categoryName", "family", "legalType") if k in fp}
        if overview:
            result["fund_overview"] = overview
        ops = fp.get("feesExpensesInvestment", {})
        if ops:
            result["fund_operations"] = ops

    top = qs.get("topHoldings", {})
    if top:
        ac = {k: _raw(top[k]) for k in (
            "cashPosition", "stockPosition", "bondPosition",
            "preferredPosition", "convertiblePosition", "otherPosition",
        ) if k in top}
        if ac:
            result["asset_classes"] = ac
        for k in ("holdings", "equityHoldings", "bondHoldings",
                   "bondRatings", "sectorWeightings"):
            if k in top:
                result[k] = top[k]
    return result or None


def _build_info(qs, quote_data):
    """Assemble info dict from quoteSummary modules + v7 quote."""
    info = {}
    for module in ("financialData", "quoteType", "defaultKeyStatistics",
                    "assetProfile", "summaryDetail"):
        for k, v in qs.get(module, {}).items():
            if k == "maxAge":
                continue
            info[k] = _raw(v)
    if quote_data:
        for k, v in quote_data.items():
            info[k] = _raw(v)
    return info


# ---------------------------------------------------------------------------
# Per-symbol processing
# ---------------------------------------------------------------------------

def _process_symbol(yahoo: Yahoo, symbol: str, r2: R2) -> dict:
    """Fetch all data for one symbol. Uploads parquet per-symbol, returns JSON for bulk upload."""
    errors: list[str] = []
    json_data: dict[str, object] = {}

    # ---- Batch API calls ----
    qs = _safe(lambda: yahoo.quote_summary(symbol, QS_MODULES), errors, "quoteSummary") or {}
    chart_result = _safe(lambda: yahoo.chart(symbol, period="max"), errors, "chart")
    events = chart_result[1] if chart_result else {}
    meta = chart_result[2] if chart_result else {}

    # ---- Financial statements (timeseries) — per-symbol parquet ----
    ts_cache: dict[tuple, pd.DataFrame | None] = {}
    for keys, prefix, r2_prefixes in TIMESERIES_MAP:
        cache_key = (id(keys), prefix)
        if cache_key not in ts_cache:
            ts_cache[cache_key] = _safe(
                lambda k=keys, p=prefix: yahoo.timeseries(symbol, k, p),
                errors, f"timeseries-{prefix}",
            )
        df = ts_cache[cache_key]
        for rp in r2_prefixes:
            _safe(lambda d=df, r=rp: _put_df(d, r2, f"{r}/{symbol}.parquet"), errors, rp)

    # ---- Chart events — per-symbol parquet ----
    _safe(lambda: _put_df(_parse_dividends(events), r2, f"dividends/{symbol}.parquet"), errors, "dividends")
    _safe(lambda: _put_df(_parse_splits(events), r2, f"splits/{symbol}.parquet"), errors, "splits")
    _safe(lambda: _put_df(_parse_actions(events), r2, f"actions/{symbol}.parquet"), errors, "actions")
    _safe(lambda: _put_df(_parse_capital_gains(events), r2, f"capital_gains/{symbol}.parquet"), errors, "capital_gains")

    # ---- Holders — per-symbol parquet ----
    _safe(lambda: _put_df(_qs_flat_df(qs, "majorHoldersBreakdown"), r2, f"major_holders/{symbol}.parquet"), errors, "major_holders")
    _safe(lambda: _put_df(_qs_list_df(qs, "institutionOwnership", "ownershipList"), r2, f"institutional_holders/{symbol}.parquet"), errors, "institutional_holders")
    _safe(lambda: _put_df(_qs_list_df(qs, "fundOwnership", "ownershipList"), r2, f"mutualfund_holders/{symbol}.parquet"), errors, "mutualfund_holders")
    _safe(lambda: _put_df(_qs_list_df(qs, "insiderTransactions", "transactions"), r2, f"insider_transactions/{symbol}.parquet"), errors, "insider_transactions")
    _safe(lambda: _put_df(_qs_flat_df(qs, "netSharePurchaseActivity"), r2, f"insider_purchases/{symbol}.parquet"), errors, "insider_purchases")
    _safe(lambda: _put_df(_qs_list_df(qs, "insiderHolders", "holders"), r2, f"insider_roster_holders/{symbol}.parquet"), errors, "insider_roster_holders")

    # ---- Analysis — per-symbol parquet ----
    _safe(lambda: _put_df(_qs_list_df(qs, "recommendationTrend", "trend"), r2, f"recommendations/{symbol}.parquet"), errors, "recommendations")
    _safe(lambda: _put_df(_qs_list_df(qs, "recommendationTrend", "trend"), r2, f"recommendations_summary/{symbol}.parquet"), errors, "recommendations_summary")
    _safe(lambda: _put_df(_parse_upgrades_downgrades(qs), r2, f"upgrades_downgrades/{symbol}.parquet"), errors, "upgrades_downgrades")
    _safe(lambda: _put_df(_parse_trend_sub(qs, "earningsEstimate"), r2, f"earnings_estimate/{symbol}.parquet"), errors, "earnings_estimate")
    _safe(lambda: _put_df(_parse_trend_sub(qs, "revenueEstimate"), r2, f"revenue_estimate/{symbol}.parquet"), errors, "revenue_estimate")
    _safe(lambda: _put_df(_parse_earnings_history(qs), r2, f"earnings_history/{symbol}.parquet"), errors, "earnings_history")
    _safe(lambda: _put_df(_parse_trend_sub(qs, "epsTrend"), r2, f"eps_trend/{symbol}.parquet"), errors, "eps_trend")
    _safe(lambda: _put_df(_parse_trend_sub(qs, "epsRevisions"), r2, f"eps_revisions/{symbol}.parquet"), errors, "eps_revisions")
    _safe(lambda: _put_df(_parse_growth_estimates(qs), r2, f"growth_estimates/{symbol}.parquet"), errors, "growth_estimates")
    _safe(lambda: _put_df(_qs_flat_df(qs, "esgScores"), r2, f"sustainability/{symbol}.parquet"), errors, "sustainability")

    # ---- Earnings dates — per-symbol parquet ----
    _safe(lambda: _put_df(yahoo.earnings_dates(symbol), r2, f"earnings/{symbol}.parquet"), errors, "earnings")

    # ---- Options — per-symbol parquet ----
    _safe(lambda: _put_df(yahoo.options_chain(symbol), r2, f"options/{symbol}.parquet"), errors, "options")

    # ---- JSON types — collect for bulk upload ----
    json_data["analyst_price_targets"] = _safe(lambda: _parse_analyst_price_targets(qs), errors, "analyst_price_targets")
    json_data["calendar"] = _safe(lambda: _parse_calendar(qs), errors, "calendar")
    json_data["history_metadata"] = meta or None
    json_data["news"] = _safe(lambda: yahoo.news(symbol), errors, "news")
    json_data["sec_filings"] = qs.get("secFilings", {}).get("filings", []) or None
    json_data["fast_info"] = _safe(lambda: _parse_fast_info(qs, meta), errors, "fast_info")
    json_data["isin"] = _safe(lambda: yahoo.isin(symbol), errors, "isin")
    json_data["funds_data"] = _safe(lambda: _parse_funds_data(qs), errors, "funds_data")
    json_data["info"] = _safe(lambda: _build_info(qs, yahoo.quote(symbol)), errors, "info")

    status = "failed" if any(e.startswith(("quoteSummary:", "chart:")) for e in errors) else "ok"
    return {"status": status, "errors": errors, "json_data": json_data}


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

BULK_JSON_TYPES = [
    "info", "fast_info", "calendar", "news", "sec_filings",
    "analyst_price_targets", "history_metadata", "isin", "funds_data",
]


def _upload_bulk_json(report: dict[str, dict], r2: R2):
    """Collect per-symbol JSON data and upload as bulk parquet files."""
    for jtype in BULK_JSON_TYPES:
        rows = {}
        for sym, r in report.items():
            val = r.get("json_data", {}).get(jtype)
            if val:
                rows[sym] = json.dumps(val, default=str)
        if not rows:
            continue
        df = pd.DataFrame({"data": rows})
        df.index.name = "symbol"
        buf = io.BytesIO()
        df.to_parquet(buf, compression="zstd")
        size_kb = buf.tell() / 1024
        r2.s3.put_object(Bucket=r2.bucket, Key=f"{jtype}.parquet", Body=buf.seek(0) or buf.read())
        print(f"  {jtype}.parquet: {len(rows)} symbols, {size_kb:.0f} KB")


def fetch_fundamentals(
    symbols: list[str],
    r2: R2,
    workers: int = 20,
) -> dict[str, dict]:
    """Fetch all non-price data and upload to R2 concurrently."""
    print(f"Processing {len(symbols)} symbols with {workers} workers...")
    yahoo = Yahoo()
    report: dict[str, dict] = {}

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(_process_symbol, yahoo, sym, r2): sym
            for sym in symbols
        }
        for fut in as_completed(futures):
            sym = futures[fut]
            try:
                report[sym] = fut.result()
            except Exception as e:
                report[sym] = {"status": "failed", "errors": [str(e)]}

            done = len(report)
            if done % 500 == 0:
                print(f"  {done}/{len(symbols)} done...")

    # Upload JSON types as bulk parquet files
    print("Uploading bulk parquet files...")
    _upload_bulk_json(report, r2)

    return report


def write_report(report: dict[str, dict]):
    """Write run report to reports/fundamentals/{date}.txt."""
    from datetime import date
    from pathlib import Path

    total = len(report)
    failed = {s: r for s, r in report.items() if r["status"] == "failed"}
    with_errors = {s: r for s, r in report.items() if r["errors"] and r["status"] == "ok"}

    lines = []
    lines.append(f"FUNDAMENTALS REPORT — {date.today()}")
    lines.append(f"Symbols: {total}")
    lines.append(f"OK: {total - len(failed)}, Failed: {len(failed)}, Partial errors: {len(with_errors)}")

    if failed:
        lines.append(f"\nFAILED ({len(failed)}):")
        for sym, r in sorted(failed.items()):
            lines.append(f"  {sym}: {r['errors'][0]}")

    if with_errors:
        lines.append(f"\nPARTIAL ERRORS ({len(with_errors)}):")
        for sym, r in sorted(with_errors.items()):
            lines.append(f"  {sym}: {', '.join(r['errors'])}")

    text = "\n".join(lines)
    print(text)

    out = Path("reports/fundamentals")
    out.mkdir(parents=True, exist_ok=True)
    (out / f"{date.today()}.txt").write_text(text)


def main():
    from dotenv import load_dotenv

    load_dotenv()

    symbols = fetch_symbols()
    print(f"Found {len(symbols)} symbols")

    r2 = R2.from_env()
    report = fetch_fundamentals(symbols, r2)
    write_report(report)


if __name__ == "__main__":
    main()
