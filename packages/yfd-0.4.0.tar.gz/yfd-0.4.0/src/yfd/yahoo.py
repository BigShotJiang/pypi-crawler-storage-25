"""Direct Yahoo Finance API client — replaces yfinance dependency.

Uses curl_cffi for TLS fingerprinting (required by Yahoo since mid-2024).
"""

import threading
import time
from datetime import datetime, timezone

import pandas as pd
from curl_cffi.requests import Session

# fmt: off
# ---------------------------------------------------------------------------
# Financial-statement field names for the timeseries API
# ---------------------------------------------------------------------------

INCOME_KEYS = [
    "TaxEffectOfUnusualItems", "TaxRateForCalcs", "NormalizedEBITDA", "NormalizedDilutedEPS",
    "NormalizedBasicEPS", "TotalUnusualItems", "TotalUnusualItemsExcludingGoodwill",
    "NetIncomeFromContinuingOperationNetMinorityInterest", "ReconciledDepreciation",
    "ReconciledCostOfRevenue", "EBITDA", "EBIT", "NetInterestIncome", "InterestExpense",
    "InterestIncome", "ContinuingAndDiscontinuedDilutedEPS", "ContinuingAndDiscontinuedBasicEPS",
    "NormalizedIncome", "NetIncomeFromContinuingAndDiscontinuedOperation", "TotalExpenses",
    "RentExpenseSupplemental", "ReportedNormalizedDilutedEPS", "ReportedNormalizedBasicEPS",
    "TotalOperatingIncomeAsReported", "DividendPerShare", "DilutedAverageShares", "BasicAverageShares",
    "DilutedEPS", "DilutedEPSOtherGainsLosses", "TaxLossCarryforwardDilutedEPS",
    "DilutedAccountingChange", "DilutedExtraordinary", "DilutedDiscontinuousOperations",
    "DilutedContinuousOperations", "BasicEPS", "BasicEPSOtherGainsLosses", "TaxLossCarryforwardBasicEPS",
    "BasicAccountingChange", "BasicExtraordinary", "BasicDiscontinuousOperations",
    "BasicContinuousOperations", "DilutedNIAvailtoComStockholders", "AverageDilutionEarnings",
    "NetIncomeCommonStockholders", "OtherunderPreferredStockDividend", "PreferredStockDividends",
    "NetIncome", "MinorityInterests", "NetIncomeIncludingNoncontrollingInterests",
    "NetIncomeFromTaxLossCarryforward", "NetIncomeExtraordinary", "NetIncomeDiscontinuousOperations",
    "NetIncomeContinuousOperations", "EarningsFromEquityInterestNetOfTax", "TaxProvision",
    "PretaxIncome", "OtherIncomeExpense", "OtherNonOperatingIncomeExpenses", "SpecialIncomeCharges",
    "GainOnSaleOfPPE", "GainOnSaleOfBusiness", "OtherSpecialCharges", "WriteOff",
    "ImpairmentOfCapitalAssets", "RestructuringAndMergernAcquisition", "SecuritiesAmortization",
    "EarningsFromEquityInterest", "GainOnSaleOfSecurity", "NetNonOperatingInterestIncomeExpense",
    "TotalOtherFinanceCost", "InterestExpenseNonOperating", "InterestIncomeNonOperating",
    "OperatingIncome", "OperatingExpense", "OtherOperatingExpenses", "OtherTaxes",
    "ProvisionForDoubtfulAccounts", "DepreciationAmortizationDepletionIncomeStatement",
    "DepletionIncomeStatement", "DepreciationAndAmortizationInIncomeStatement", "Amortization",
    "AmortizationOfIntangiblesIncomeStatement", "DepreciationIncomeStatement", "ResearchAndDevelopment",
    "SellingGeneralAndAdministration", "SellingAndMarketingExpense", "GeneralAndAdministrativeExpense",
    "OtherGandA", "InsuranceAndClaims", "RentAndLandingFees", "SalariesAndWages", "GrossProfit",
    "CostOfRevenue", "TotalRevenue", "ExciseTaxes", "OperatingRevenue", "LossAdjustmentExpense",
    "NetPolicyholderBenefitsAndClaims", "PolicyholderBenefitsGross", "PolicyholderBenefitsCeded",
    "OccupancyAndEquipment", "ProfessionalExpenseAndContractServicesExpense", "OtherNonInterestExpense",
]

BALANCE_SHEET_KEYS = [
    "TreasurySharesNumber", "PreferredSharesNumber", "OrdinarySharesNumber", "ShareIssued", "NetDebt",
    "TotalDebt", "TangibleBookValue", "InvestedCapital", "WorkingCapital", "NetTangibleAssets",
    "CapitalLeaseObligations", "CommonStockEquity", "PreferredStockEquity", "TotalCapitalization",
    "TotalEquityGrossMinorityInterest", "MinorityInterest", "StockholdersEquity",
    "OtherEquityInterest", "GainsLossesNotAffectingRetainedEarnings", "OtherEquityAdjustments",
    "FixedAssetsRevaluationReserve", "ForeignCurrencyTranslationAdjustments",
    "MinimumPensionLiabilities", "UnrealizedGainLoss", "TreasuryStock", "RetainedEarnings",
    "AdditionalPaidInCapital", "CapitalStock", "OtherCapitalStock", "CommonStock", "PreferredStock",
    "TotalPartnershipCapital", "GeneralPartnershipCapital", "LimitedPartnershipCapital",
    "TotalLiabilitiesNetMinorityInterest", "TotalNonCurrentLiabilitiesNetMinorityInterest",
    "OtherNonCurrentLiabilities", "LiabilitiesHeldforSaleNonCurrent", "RestrictedCommonStock",
    "PreferredSecuritiesOutsideStockEquity", "DerivativeProductLiabilities", "EmployeeBenefits",
    "NonCurrentPensionAndOtherPostretirementBenefitPlans", "NonCurrentAccruedExpenses",
    "DuetoRelatedPartiesNonCurrent", "TradeandOtherPayablesNonCurrent",
    "NonCurrentDeferredLiabilities", "NonCurrentDeferredRevenue",
    "NonCurrentDeferredTaxesLiabilities", "LongTermDebtAndCapitalLeaseObligation",
    "LongTermCapitalLeaseObligation", "LongTermDebt", "LongTermProvisions", "CurrentLiabilities",
    "OtherCurrentLiabilities", "CurrentDeferredLiabilities", "CurrentDeferredRevenue",
    "CurrentDeferredTaxesLiabilities", "CurrentDebtAndCapitalLeaseObligation",
    "CurrentCapitalLeaseObligation", "CurrentDebt", "OtherCurrentBorrowings", "LineOfCredit",
    "CommercialPaper", "CurrentNotesPayable", "PensionandOtherPostRetirementBenefitPlansCurrent",
    "CurrentProvisions", "PayablesAndAccruedExpenses", "CurrentAccruedExpenses", "InterestPayable",
    "Payables", "OtherPayable", "DuetoRelatedPartiesCurrent", "DividendsPayable", "TotalTaxPayable",
    "IncomeTaxPayable", "AccountsPayable", "TotalAssets", "TotalNonCurrentAssets",
    "OtherNonCurrentAssets", "DefinedPensionBenefit", "NonCurrentPrepaidAssets",
    "NonCurrentDeferredAssets", "NonCurrentDeferredTaxesAssets", "DuefromRelatedPartiesNonCurrent",
    "NonCurrentNoteReceivables", "NonCurrentAccountsReceivable", "FinancialAssets",
    "InvestmentsAndAdvances", "OtherInvestments", "InvestmentinFinancialAssets",
    "HeldToMaturitySecurities", "AvailableForSaleSecurities",
    "FinancialAssetsDesignatedasFairValueThroughProfitorLossTotal", "TradingSecurities",
    "LongTermEquityInvestment", "InvestmentsinJointVenturesatCost",
    "InvestmentsInOtherVenturesUnderEquityMethod", "InvestmentsinAssociatesatCost",
    "InvestmentsinSubsidiariesatCost", "InvestmentProperties", "GoodwillAndOtherIntangibleAssets",
    "OtherIntangibleAssets", "Goodwill", "NetPPE", "AccumulatedDepreciation", "GrossPPE", "Leases",
    "ConstructionInProgress", "OtherProperties", "MachineryFurnitureEquipment",
    "BuildingsAndImprovements", "LandAndImprovements", "Properties", "CurrentAssets",
    "OtherCurrentAssets", "HedgingAssetsCurrent", "AssetsHeldForSaleCurrent", "CurrentDeferredAssets",
    "CurrentDeferredTaxesAssets", "RestrictedCash", "PrepaidAssets", "Inventory",
    "InventoriesAdjustmentsAllowances", "OtherInventories", "FinishedGoods", "WorkInProcess",
    "RawMaterials", "Receivables", "ReceivablesAdjustmentsAllowances", "OtherReceivables",
    "DuefromRelatedPartiesCurrent", "TaxesReceivable", "AccruedInterestReceivable", "NotesReceivable",
    "LoansReceivable", "AccountsReceivable", "AllowanceForDoubtfulAccountsReceivable",
    "GrossAccountsReceivable", "CashCashEquivalentsAndShortTermInvestments",
    "OtherShortTermInvestments", "CashAndCashEquivalents", "CashEquivalents", "CashFinancial",
    "CashCashEquivalentsAndFederalFundsSold",
]

CASH_FLOW_KEYS = [
    "ForeignSales", "DomesticSales", "AdjustedGeographySegmentData", "FreeCashFlow",
    "RepurchaseOfCapitalStock", "RepaymentOfDebt", "IssuanceOfDebt", "IssuanceOfCapitalStock",
    "CapitalExpenditure", "InterestPaidSupplementalData", "IncomeTaxPaidSupplementalData",
    "EndCashPosition", "OtherCashAdjustmentOutsideChangeinCash", "BeginningCashPosition",
    "EffectOfExchangeRateChanges", "ChangesInCash", "OtherCashAdjustmentInsideChangeinCash",
    "CashFlowFromDiscontinuedOperation", "FinancingCashFlow", "CashFromDiscontinuedFinancingActivities",
    "CashFlowFromContinuingFinancingActivities", "NetOtherFinancingCharges", "InterestPaidCFF",
    "ProceedsFromStockOptionExercised", "CashDividendsPaid", "PreferredStockDividendPaid",
    "CommonStockDividendPaid", "NetPreferredStockIssuance", "PreferredStockPayments",
    "PreferredStockIssuance", "NetCommonStockIssuance", "CommonStockPayments", "CommonStockIssuance",
    "NetIssuancePaymentsOfDebt", "NetShortTermDebtIssuance", "ShortTermDebtPayments",
    "ShortTermDebtIssuance", "NetLongTermDebtIssuance", "LongTermDebtPayments", "LongTermDebtIssuance",
    "InvestingCashFlow", "CashFromDiscontinuedInvestingActivities",
    "CashFlowFromContinuingInvestingActivities", "NetOtherInvestingChanges", "InterestReceivedCFI",
    "DividendsReceivedCFI", "NetInvestmentPurchaseAndSale", "SaleOfInvestment", "PurchaseOfInvestment",
    "NetInvestmentPropertiesPurchaseAndSale", "SaleOfInvestmentProperties",
    "PurchaseOfInvestmentProperties", "NetBusinessPurchaseAndSale", "SaleOfBusiness",
    "PurchaseOfBusiness", "NetIntangiblesPurchaseAndSale", "SaleOfIntangibles", "PurchaseOfIntangibles",
    "NetPPEPurchaseAndSale", "SaleOfPPE", "PurchaseOfPPE", "CapitalExpenditureReported",
    "OperatingCashFlow", "CashFromDiscontinuedOperatingActivities",
    "CashFlowFromContinuingOperatingActivities", "TaxesRefundPaid", "InterestReceivedCFO",
    "InterestPaidCFO", "DividendReceivedCFO", "DividendPaidCFO", "ChangeInWorkingCapital",
    "ChangeInOtherWorkingCapital", "ChangeInOtherCurrentLiabilities", "ChangeInOtherCurrentAssets",
    "ChangeInPayablesAndAccruedExpense", "ChangeInAccruedExpense", "ChangeInInterestPayable",
    "ChangeInPayable", "ChangeInDividendPayable", "ChangeInAccountPayable", "ChangeInTaxPayable",
    "ChangeInIncomeTaxPayable", "ChangeInPrepaidAssets", "ChangeInInventory", "ChangeInReceivables",
    "ChangesInAccountReceivables", "OtherNonCashItems", "ExcessTaxBenefitFromStockBasedCompensation",
    "StockBasedCompensation", "UnrealizedGainLossOnInvestmentSecurities", "ProvisionandWriteOffofAssets",
    "AssetImpairmentCharge", "AmortizationOfSecurities", "DeferredTax", "DeferredIncomeTax",
    "DepreciationAmortizationDepletion", "Depletion", "DepreciationAndAmortization",
    "AmortizationCashFlow", "AmortizationOfIntangibles", "Depreciation", "OperatingGainsLosses",
    "PensionAndEmployeeBenefitExpense", "EarningsLossesFromEquityInvestments",
    "GainLossOnInvestmentSecurities", "NetForeignCurrencyExchangeGainLoss", "GainLossOnSaleOfPPE",
    "GainLossOnSaleOfBusiness", "NetIncomeFromContinuingOperations",
    "CashFlowsfromusedinOperatingActivitiesDirect", "TaxesRefundPaidDirect", "InterestReceivedDirect",
    "InterestPaidDirect", "DividendsReceivedDirect", "DividendsPaidDirect", "ClassesofCashPayments",
    "OtherCashPaymentsfromOperatingActivities", "PaymentsonBehalfofEmployees",
    "PaymentstoSuppliersforGoodsandServices", "ClassesofCashReceiptsfromOperatingActivities",
    "OtherCashReceiptsfromOperatingActivities", "ReceiptsfromGovernmentGrants", "ReceiptsfromCustomers",
]
# fmt: on


class Yahoo:
    """Yahoo Finance HTTP API client with cookie/crumb authentication."""

    BASE = "https://query2.finance.yahoo.com"
    BASE1 = "https://query1.finance.yahoo.com"

    def __init__(self):
        self._session = Session(impersonate="chrome")
        self._crumb: str | None = None
        self._lock = threading.Lock()
        self._authenticate()

    # ------------------------------------------------------------------ auth

    def _authenticate(self):
        self._session.get("https://fc.yahoo.com", allow_redirects=True)
        resp = self._session.get(f"{self.BASE1}/v1/test/getcrumb")
        if resp.status_code != 200:
            raise RuntimeError(f"Crumb fetch failed: HTTP {resp.status_code}")
        text = resp.text.strip()
        if not text or "<html" in text.lower():
            raise RuntimeError("Crumb fetch returned empty or HTML")
        self._crumb = text

    def _get(self, url, params=None):
        """Authenticated GET with retry on 401/403/429."""
        params = dict(params or {})
        params["crumb"] = self._crumb
        for attempt in range(3):
            resp = self._session.get(url, params=params)
            if resp.status_code in (401, 403):
                with self._lock:
                    self._authenticate()
                params["crumb"] = self._crumb
                continue
            if resp.status_code == 429:
                time.sleep(2**attempt)
                continue
            resp.raise_for_status()
            return resp
        raise RuntimeError(f"Failed after retries: {url} (last status {resp.status_code})")

    def _json(self, url, params=None):
        return self._get(url, params).json()

    # ------------------------------------------------------------- chart API

    def chart(self, symbol, start=None, end=None, period="max", auto_adjust=True):
        """Fetch OHLCV history for one symbol.

        Returns ``(dataframe | None, events_dict, meta_dict)``.
        """
        params = {"interval": "1d", "events": "div,splits,capitalGains"}
        if start:
            params["period1"] = int(pd.Timestamp(start).timestamp())
            params["period2"] = (
                int(pd.Timestamp(end).timestamp()) if end else int(time.time())
            )
        else:
            params["range"] = period

        data = self._json(f"{self.BASE}/v8/finance/chart/{symbol}", params)
        chart = data.get("chart", {})
        if chart.get("error"):
            return None, {}, {}

        result = chart.get("result")
        if not result:
            return None, {}, {}

        r = result[0]
        meta = r.get("meta", {})
        events = r.get("events", {})
        ts = r.get("timestamp")
        if not ts:
            return None, events, meta

        q = r["indicators"]["quote"][0]
        df = pd.DataFrame(
            {
                "Open": q.get("open"),
                "High": q.get("high"),
                "Low": q.get("low"),
                "Close": q.get("close"),
                "Volume": q.get("volume"),
            },
            index=pd.to_datetime(ts, unit="s"),
        )
        df.index = df.index.normalize()
        df.index.name = "Date"

        if auto_adjust:
            ac = r["indicators"].get("adjclose")
            if ac and ac[0].get("adjclose"):
                adj = pd.Series(ac[0]["adjclose"], index=df.index)
                safe_close = df["Close"].replace(0, float("nan"))
                ratio = (adj / safe_close).fillna(1.0)
                df["Open"] *= ratio
                df["High"] *= ratio
                df["Low"] *= ratio
                df["Close"] = adj

        return df.dropna(how="all"), events, meta

    # ------------------------------------------------------- quote summary

    def quote_summary(self, symbol, modules):
        """Fetch one or more quoteSummary modules. Returns merged result dict."""
        params = {
            "modules": ",".join(modules),
            "corsDomain": "finance.yahoo.com",
            "formatted": "false",
            "symbol": symbol,
        }
        data = self._json(f"{self.BASE}/v10/finance/quoteSummary/{symbol}", params)
        qs = data.get("quoteSummary", {})
        if qs.get("error"):
            raise RuntimeError(f"quoteSummary: {qs['error']}")
        result = qs.get("result")
        return result[0] if result else {}

    # ------------------------------------ timeseries (financial statements)

    def timeseries(self, symbol, keys, prefix):
        """Fetch fundamentals timeseries.

        *prefix*: ``'annual'``, ``'quarterly'``, or ``'trailing'``.
        Returns DataFrame with line-items as rows and dates as columns
        (newest first), or ``None``.
        """
        typed = [f"{prefix}{k}" for k in keys]
        params = {
            "symbol": symbol,
            "type": ",".join(typed),
            "period1": "493590046",
            "period2": str(int(time.time())),
        }
        data = self._json(
            f"{self.BASE}/ws/fundamentals-timeseries/v1/finance/timeseries/{symbol}",
            params,
        )
        entries = data.get("timeseries", {}).get("result", [])
        if not entries:
            return None

        all_dates: set[pd.Timestamp] = set()
        rows: dict[str, dict] = {}

        for entry in entries:
            data_keys = [k for k in entry if k not in ("meta", "timestamp")]
            if not data_keys:
                continue
            typed_key = data_keys[0]
            values = entry.get(typed_key)
            if not values:
                continue
            clean_key = typed_key[len(prefix):]
            row = {}
            for item in values:
                if isinstance(item, dict) and "reportedValue" in item:
                    dt = pd.Timestamp(item["asOfDate"])
                    row[dt] = item["reportedValue"]["raw"]
                    all_dates.add(dt)
            if row:
                rows[clean_key] = row

        if not rows:
            return None

        dates = sorted(all_dates, reverse=True)
        df = pd.DataFrame(rows).T.reindex(columns=dates)

        if prefix == "trailing":
            df = df.iloc[:, :1]

        ordered = [k for k in keys if k in df.index]
        return df.loc[ordered] if ordered else None

    # ------------------------------------------------------------- quote

    def quote(self, symbol):
        """Fetch real-time quote via v7 endpoint."""
        data = self._json(
            f"{self.BASE1}/v7/finance/quote",
            {"symbols": symbol, "formatted": "false"},
        )
        result = data.get("quoteResponse", {}).get("result", [])
        return result[0] if result else {}

    # ----------------------------------------------------------- options

    def options_chain(self, symbol):
        """Fetch all options chains as a single DataFrame, or ``None``."""
        data = self._json(f"{self.BASE}/v7/finance/options/{symbol}", {})
        result = data.get("optionChain", {}).get("result", [])
        if not result:
            return None
        expiries = result[0].get("expirationDates", [])
        if not expiries:
            return None

        frames = []
        for exp_ts in expiries:
            try:
                d = self._json(
                    f"{self.BASE}/v7/finance/options/{symbol}",
                    {"date": str(exp_ts)},
                )
                opts = d["optionChain"]["result"][0]["options"][0]
                exp_str = datetime.fromtimestamp(
                    exp_ts, tz=timezone.utc
                ).strftime("%Y-%m-%d")
                for otype, key in [("call", "calls"), ("put", "puts")]:
                    items = opts.get(key, [])
                    if items:
                        df = pd.DataFrame(items)
                        df["expiry"] = exp_str
                        df["type"] = otype
                        frames.append(df)
            except Exception:
                continue

        return pd.concat(frames, ignore_index=True) if frames else None

    # -------------------------------------------------------------- news

    def news(self, symbol, count=25):
        """Fetch latest news articles."""
        try:
            resp = self._session.post(
                "https://finance.yahoo.com/xhr/ncp",
                params={"queryRef": "latestNews", "serviceKey": "ncp_fin"},
                json={"serviceConfig": {"snippetCount": count, "s": [symbol]}},
            )
            if resp.status_code != 200:
                return []
            stream = (
                resp.json()
                .get("data", {})
                .get("tickerStream", {})
                .get("stream", [])
            )
            return [item for item in stream if not item.get("ad")]
        except Exception:
            return []

    # -------------------------------------------------- earnings dates

    def earnings_dates(self, symbol, limit=12):
        """Scrape earnings calendar HTML page. Returns DataFrame or ``None``."""
        try:
            resp = self._session.get(
                "https://finance.yahoo.com/calendar/earnings",
                params={
                    "symbol": symbol,
                    "offset": "0",
                    "size": str(min(limit, 100)),
                },
            )
            if resp.status_code != 200:
                return None
            dfs = pd.read_html(resp.text)
            if not dfs:
                return None
            df = dfs[0]
            if "Earnings Date" in df.columns:
                df["Earnings Date"] = pd.to_datetime(
                    df["Earnings Date"], errors="coerce"
                )
                df = df.set_index("Earnings Date")
            return df
        except Exception:
            return None

    # ------------------------------------------------------------ isin

    def isin(self, symbol):
        """Look up ISIN via Business Insider search."""
        try:
            resp = self._session.get(
                "https://markets.businessinsider.com/ajax/SearchController_Suggest",
                params={"max_results": "25", "query": symbol},
            )
            for line in resp.text.split("\n"):
                if f"|{symbol}|" in line:
                    for part in line.split("|"):
                        if len(part) == 12 and part[:2].isalpha():
                            return part
        except Exception:
            pass
        return None
