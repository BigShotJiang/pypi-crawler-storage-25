"""Fetch TradingView screener data and upload as a single parquet to R2.

Fetches all base fields (no intraday timeframe variants) for every US-listed
symbol and stores as ``screener.parquet`` in R2.
"""

import io
import math

import pandas as pd
from tvscreener import StockScreener
from tvscreener.field import Market, SymbolType
from tvscreener.field.stock import StockField

from yfd.r2 import R2

# Base fields only (exclude intraday timeframe variants like RSI|5, EMA|15)
BASE_FIELDS = [f for f in StockField if "|" not in f.field_name]
BATCH_SIZE = 400


def _fetch_all() -> pd.DataFrame:
    """Fetch all base fields in batches, return merged DataFrame keyed by ticker."""
    n_batches = math.ceil(len(BASE_FIELDS) / BATCH_SIZE)
    print(f"Fetching {len(BASE_FIELDS)} fields in {n_batches} batches for US market...")

    frames = []
    for i in range(n_batches):
        batch = BASE_FIELDS[i * BATCH_SIZE : (i + 1) * BATCH_SIZE]
        print(f"  Batch {i + 1}/{n_batches}: {len(batch)} fields...", end=" ", flush=True)

        ss = StockScreener()
        ss.set_markets(Market.AMERICA)
        ss.set_range(0, 25000)
        ss.set_symbol_types(
            SymbolType.COMMON_STOCK,
            SymbolType.ETF,
            SymbolType.DEPOSITORY_RECEIPT,
            SymbolType.PREFERRED_STOCK,
            SymbolType.REIT,
        )
        ss.select(*batch)
        df = ss.get()

        # Use technical field names as columns
        field_names = ["symbol"] + [f.field_name for f in batch]
        actual = min(len(df.columns), len(field_names))
        df = df.iloc[:, :actual]
        df.columns = field_names[:actual]
        print(f"{len(df)} rows")
        frames.append(df.set_index("symbol"))

    merged = pd.concat(frames, axis=1)
    merged = merged.loc[:, ~merged.columns.duplicated()]

    # Convert exchange:SYMBOL index to Yahoo-format ticker
    merged.index = [
        (s.split(":")[1] if ":" in s else s).replace(".", "-").replace("/", "-")
        for s in merged.index
    ]
    merged.index.name = "symbol"

    # Only coerce object columns that are actually numeric
    for col in merged.columns:
        if merged[col].dtype == "object":
            numeric = pd.to_numeric(merged[col], errors="coerce")
            if numeric.notna().any():
                merged[col] = numeric

    print(f"Merged: {merged.shape[0]} symbols × {merged.shape[1]} fields")
    return merged


def main():
    from dotenv import load_dotenv

    load_dotenv()

    df = _fetch_all()
    r2 = R2.from_env()

    buf = io.BytesIO()
    df.to_parquet(buf, compression="zstd")
    size_mb = buf.tell() / 1024 / 1024
    print(f"Uploading screener.parquet ({size_mb:.1f} MB)...")
    buf.seek(0)
    r2.s3.put_object(Bucket=r2.bucket, Key="screener.parquet", Body=buf.read())
    print("Done")


if __name__ == "__main__":
    main()
