"""Read market data from R2 public storage.

Single entry point: ``get(symbol, data_type)`` returns a DataFrame, dict, or str.
"""

import io
import json

import pandas as pd
import requests

R2_BASE = "https://pub-7e83ae863f9e4909bc0d8325d6f01726.r2.dev"

# Canonical data types: name → (r2_prefix, format, description)
# format: "parquet" = per-symbol parquet, "parquet-bulk" = single bulk parquet, "json" (legacy)
DATA_TYPES: dict[str, tuple[str, str, str]] = {
    # Price & Actions — per-symbol parquet
    "price":                    ("daily",                   "parquet", "Daily OHLCV price history"),
    "dividends":                ("dividends",               "parquet", "Dividend payment history"),
    "splits":                   ("splits",                  "parquet", "Stock split history"),
    "actions":                  ("actions",                 "parquet", "Dividends and splits combined"),
    "capital_gains":            ("capital_gains",           "parquet", "Capital gains (ETFs/funds)"),
    # Financial Statements — per-symbol parquet
    "income_stmt":              ("financials",              "parquet", "Annual income statement"),
    "income_stmt_quarterly":    ("financials_quarterly",    "parquet", "Quarterly income statement"),
    "income_stmt_ttm":          ("ttm_financials",          "parquet", "Trailing 12-month income statement"),
    "balance_sheet":            ("balance_sheet",           "parquet", "Annual balance sheet"),
    "balance_sheet_quarterly":  ("balance_sheet_quarterly", "parquet", "Quarterly balance sheet"),
    "cashflow":                 ("cashflow",                "parquet", "Annual cash flow statement"),
    "cashflow_quarterly":       ("cashflow_quarterly",      "parquet", "Quarterly cash flow statement"),
    "cashflow_ttm":             ("ttm_cashflow",            "parquet", "Trailing 12-month cash flow"),
    # Holders — per-symbol parquet
    "major_holders":            ("major_holders",           "parquet", "Insider/institution ownership %"),
    "institutional_holders":    ("institutional_holders",   "parquet", "Top institutional holders"),
    "mutualfund_holders":       ("mutualfund_holders",      "parquet", "Top mutual fund holders"),
    "insider_transactions":     ("insider_transactions",    "parquet", "Insider buy/sell transactions"),
    "insider_purchases":        ("insider_purchases",       "parquet", "Net insider purchase activity"),
    "insider_roster":           ("insider_roster_holders",  "parquet", "Insider roster with positions"),
    # Analyst & Estimates — per-symbol parquet
    "recommendations":          ("recommendations",         "parquet", "Analyst recommendation trend"),
    "upgrades_downgrades":      ("upgrades_downgrades",     "parquet", "Analyst upgrade/downgrade history"),
    "earnings_estimate":        ("earnings_estimate",       "parquet", "EPS estimates by period"),
    "revenue_estimate":         ("revenue_estimate",        "parquet", "Revenue estimates by period"),
    "earnings_history":         ("earnings_history",        "parquet", "Historical EPS vs estimates"),
    "eps_trend":                ("eps_trend",               "parquet", "EPS trend"),
    "eps_revisions":            ("eps_revisions",           "parquet", "EPS revision history"),
    "growth_estimates":         ("growth_estimates",        "parquet", "Growth estimates (stock/industry/sector)"),
    "earnings":                 ("earnings",                "parquet", "Earnings dates with EPS surprise"),
    "options":                  ("options",                 "parquet", "Full options chain"),
    "sustainability":           ("sustainability",          "parquet", "ESG scores"),
    # Company — bulk parquet (one file, all symbols)
    "info":                     ("info",                    "parquet-bulk", "Full company information"),
    "fast_info":                ("fast_info",               "parquet-bulk", "Quick price/volume stats"),
    "calendar":                 ("calendar",                "parquet-bulk", "Upcoming earnings/dividend dates"),
    "history_metadata":         ("history_metadata",        "parquet-bulk", "Exchange, currency, trading hours"),
    "news":                     ("news",                    "parquet-bulk", "Latest news articles"),
    "sec_filings":              ("sec_filings",             "parquet-bulk", "SEC filing history"),
    "analyst_price_targets":    ("analyst_price_targets",   "parquet-bulk", "Analyst price target summary"),
    "isin":                     ("isin",                    "parquet-bulk", "ISIN identifier"),
    "funds_data":               ("funds_data",              "parquet-bulk", "ETF/mutual fund details"),
    # TradingView Screener — bulk parquet
    "screener":                 ("screener",                "parquet-bulk", "TradingView screener (1000+ fields: fundamentals, technicals, classification)"),
}

# In-process cache for bulk files (downloaded once per session)
_cache: dict[str, pd.DataFrame] = {}


def _get_bulk(prefix: str, symbol: str):
    """Download bulk parquet (cached), return one symbol's data."""
    if prefix not in _cache:
        try:
            resp = requests.get(f"{R2_BASE}/{prefix}.parquet")
            resp.raise_for_status()
            _cache[prefix] = pd.read_parquet(io.BytesIO(resp.content))
        except Exception:
            return None
    df = _cache[prefix]
    if symbol not in df.index:
        return None
    row = df.loc[symbol]
    # Screener: row is a Series of field values → return as dict (drop NaN)
    if prefix == "screener":
        return {k: v for k, v in row.items() if pd.notna(v)}
    # JSON bulk types: single "data" column with JSON string
    return json.loads(row["data"])


def get(
    symbol: str,
    data_type: str = "price",
    start: str | None = None,
    end: str | None = None,
) -> pd.DataFrame | dict | list | str | None:
    """Fetch data for a symbol from R2.

    Args:
        symbol: Ticker symbol (e.g. ``"AAPL"``).
        data_type: One of the keys in ``DATA_TYPES``.
        start: Filter rows ``>= start`` (price data only).
        end: Filter rows ``<= end`` (price data only).

    Returns:
        DataFrame for parquet types, dict/list/str for JSON types,
        or ``None`` if not found.
    """
    if data_type not in DATA_TYPES:
        raise ValueError(
            f"Unknown data type: {data_type!r}. "
            f"Valid types: {', '.join(sorted(DATA_TYPES))}"
        )

    prefix, fmt, _ = DATA_TYPES[data_type]

    if fmt == "parquet-bulk":
        return _get_bulk(prefix, symbol)

    ext = "parquet" if fmt == "parquet" else "json"
    url = f"{R2_BASE}/{prefix}/{symbol}.{ext}"

    try:
        resp = requests.get(url)
        resp.raise_for_status()
    except Exception:
        return None

    if fmt == "parquet":
        df = pd.read_parquet(io.BytesIO(resp.content))
        if data_type == "price":
            if start:
                df = df[df.index >= pd.Timestamp(start)]
            if end:
                df = df[df.index <= pd.Timestamp(end)]
        return df

    return json.loads(resp.content)


def symbols() -> list[str]:
    """List all available ticker symbols."""
    try:
        resp = requests.get(f"{R2_BASE}/symbols.json")
        resp.raise_for_status()
        return resp.json()
    except Exception:
        return []


def types() -> dict[str, str]:
    """Return ``{data_type: description}`` for every available type."""
    return {name: desc for name, (_, _, desc) in DATA_TYPES.items()}
