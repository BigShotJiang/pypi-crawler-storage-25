"""CLI entry point: ``yfd <data_type> <symbol> [--start] [--end] [--json]``."""

import argparse
import json
import sys

import pandas as pd

from yfd.store import DATA_TYPES, get, symbols, types


def _format_df(df: pd.DataFrame, as_json: bool) -> str:
    if as_json:
        return df.to_json(orient="split", date_format="iso", indent=2)
    return df.to_string()


def _format_value(val, as_json: bool) -> str:
    if as_json:
        return json.dumps(val, default=str, indent=2)
    if isinstance(val, dict):
        return "\n".join(f"{k}: {v}" for k, v in val.items())
    if isinstance(val, list):
        return json.dumps(val, default=str, indent=2)
    return str(val)


def main():
    parser = argparse.ArgumentParser(
        prog="yfd",
        description="Yahoo Finance data — read from R2 storage",
    )
    parser.add_argument(
        "command",
        help="Data type (e.g. price, income-stmt, info) or: types, symbols",
    )
    parser.add_argument("symbol", nargs="?", help="Ticker symbol (e.g. AAPL)")
    parser.add_argument("--start", help="Start date filter (price only)")
    parser.add_argument("--end", help="End date filter (price only)")
    parser.add_argument("--json", action="store_true", dest="as_json", help="JSON output")

    args = parser.parse_args()

    if args.command == "types":
        for name, desc in sorted(types().items()):
            print(f"  {name:<25} {desc}")
        return

    if args.command == "symbols":
        syms = symbols()
        print(f"{len(syms)} symbols: {', '.join(syms[:20])}{'...' if len(syms) > 20 else ''}")
        return

    data_type = args.command.replace("-", "_")

    if data_type not in DATA_TYPES:
        print(f"Unknown: {args.command}. Run 'yfd types' for valid types.", file=sys.stderr)
        sys.exit(1)

    if not args.symbol:
        print(f"Usage: yfd {args.command} <SYMBOL>", file=sys.stderr)
        sys.exit(1)

    result = get(args.symbol.upper(), data_type, start=args.start, end=args.end)

    if result is None:
        print(f"No data for {args.symbol.upper()}/{data_type}", file=sys.stderr)
        sys.exit(1)

    if isinstance(result, pd.DataFrame):
        print(_format_df(result, args.as_json))
    else:
        print(_format_value(result, args.as_json))


if __name__ == "__main__":
    main()
