"""Integration tests — download from R2 and validate data."""

import pandas as pd
import pytest

import yfd

SYMBOL = "AAPL"


# ---------------------------------------------------------------------------
# Price & Actions
# ---------------------------------------------------------------------------

class TestPrice:
    def test_returns_dataframe(self):
        df = yfd.get(SYMBOL, "price")
        assert isinstance(df, pd.DataFrame)

    def test_has_ohlcv_columns(self):
        df = yfd.get(SYMBOL, "price")
        for col in ("Open", "High", "Low", "Close", "Volume"):
            assert col in df.columns

    def test_has_years_of_history(self):
        df = yfd.get(SYMBOL, "price")
        assert len(df) > 1000  # AAPL should have 5+ years

    def test_date_filter(self):
        df = yfd.get(SYMBOL, "price", start="2026-03-01", end="2026-03-28")
        assert len(df) > 0
        assert len(df) < 25  # max ~20 trading days in March

    def test_dividends(self):
        df = yfd.get(SYMBOL, "dividends")
        assert isinstance(df, pd.DataFrame)
        assert len(df) > 10  # AAPL has years of dividends

    def test_splits(self):
        df = yfd.get(SYMBOL, "splits")
        assert isinstance(df, pd.DataFrame)
        assert len(df) >= 4  # AAPL has had multiple splits


# ---------------------------------------------------------------------------
# Financial Statements
# ---------------------------------------------------------------------------

class TestFinancials:
    def test_income_stmt(self):
        df = yfd.get(SYMBOL, "income_stmt")
        assert isinstance(df, pd.DataFrame)
        assert df.shape[0] > 5  # multiple line items
        assert df.shape[1] >= 3  # at least 3 years

    def test_income_stmt_quarterly(self):
        df = yfd.get(SYMBOL, "income_stmt_quarterly")
        assert isinstance(df, pd.DataFrame)
        assert df.shape[1] >= 4  # at least 4 quarters

    def test_balance_sheet(self):
        df = yfd.get(SYMBOL, "balance_sheet")
        assert isinstance(df, pd.DataFrame)
        assert df.shape[0] > 10

    def test_cashflow(self):
        df = yfd.get(SYMBOL, "cashflow")
        assert isinstance(df, pd.DataFrame)
        assert df.shape[0] > 10

    def test_income_stmt_ttm(self):
        df = yfd.get(SYMBOL, "income_stmt_ttm")
        assert isinstance(df, pd.DataFrame)
        assert df.shape[1] == 1  # trailing = single column


# ---------------------------------------------------------------------------
# Holders
# ---------------------------------------------------------------------------

class TestHolders:
    def test_major_holders(self):
        df = yfd.get(SYMBOL, "major_holders")
        assert isinstance(df, pd.DataFrame)
        assert len(df) > 0

    def test_institutional_holders(self):
        df = yfd.get(SYMBOL, "institutional_holders")
        assert isinstance(df, pd.DataFrame)
        assert len(df) >= 5

    def test_insider_transactions(self):
        df = yfd.get(SYMBOL, "insider_transactions")
        assert isinstance(df, pd.DataFrame)
        assert len(df) >= 10


# ---------------------------------------------------------------------------
# Analyst & Estimates
# ---------------------------------------------------------------------------

class TestAnalyst:
    def test_recommendations(self):
        df = yfd.get(SYMBOL, "recommendations")
        assert isinstance(df, pd.DataFrame)
        assert len(df) > 0

    def test_upgrades_downgrades(self):
        df = yfd.get(SYMBOL, "upgrades_downgrades")
        assert isinstance(df, pd.DataFrame)
        assert len(df) > 10

    def test_earnings_estimate(self):
        df = yfd.get(SYMBOL, "earnings_estimate")
        assert isinstance(df, pd.DataFrame)

    def test_analyst_price_targets(self):
        data = yfd.get(SYMBOL, "analyst_price_targets")
        if data is None:
            pytest.skip("analyst_price_targets.parquet not yet in R2")
        assert isinstance(data, dict)


# ---------------------------------------------------------------------------
# Company Info (bulk parquet)
# ---------------------------------------------------------------------------

class TestCompanyInfo:
    """Bulk parquet types — require nightly pipeline to have run with new format."""

    def test_info_is_dict(self):
        data = yfd.get(SYMBOL, "info")
        assert data is None or isinstance(data, dict)

    def test_info_has_key_fields(self):
        data = yfd.get(SYMBOL, "info")
        if data is None:
            pytest.skip("info.parquet not yet in R2")
        assert data.get("sector") or data.get("sectorDisp")

    def test_fast_info(self):
        data = yfd.get(SYMBOL, "fast_info")
        if data is None:
            pytest.skip("fast_info.parquet not yet in R2")
        assert "currency" in data or "regularMarketPrice" in data

    def test_calendar(self):
        data = yfd.get(SYMBOL, "calendar")
        assert data is None or isinstance(data, dict)

    def test_news(self):
        data = yfd.get(SYMBOL, "news")
        assert data is None or isinstance(data, list)

    def test_history_metadata(self):
        data = yfd.get(SYMBOL, "history_metadata")
        assert data is None or isinstance(data, dict)


# ---------------------------------------------------------------------------
# Screener (bulk parquet)
# ---------------------------------------------------------------------------

class TestScreener:
    """Requires screener.parquet in R2 (uploaded by nightly pipeline)."""

    def _get(self, symbol=SYMBOL):
        data = yfd.get(symbol, "screener")
        if data is None:
            pytest.skip("screener.parquet not yet in R2")
        return data

    def test_returns_dict(self):
        assert isinstance(self._get(), dict)

    def test_has_classification(self):
        data = self._get()
        assert "type" in data
        assert "subtype" in data
        assert "sector" in data

    def test_has_technicals(self):
        data = self._get()
        assert "RSI" in data or "RSI9" in data

    def test_has_fundamentals(self):
        data = self._get()
        assert "market_cap_basic" in data

    def test_etf_works(self):
        data = self._get("SPY")
        assert data.get("subtype") == "etf"


# ---------------------------------------------------------------------------
# Symbols & Types
# ---------------------------------------------------------------------------

class TestMeta:
    def test_symbols_returns_list(self):
        syms = yfd.symbols()
        assert isinstance(syms, list)
        assert len(syms) > 5000

    def test_symbols_contains_known_tickers(self):
        syms = yfd.symbols()
        assert "AAPL" in syms
        assert "MSFT" in syms

    def test_types_returns_dict(self):
        t = yfd.types()
        assert isinstance(t, dict)
        assert len(t) == 40

    def test_unknown_type_raises(self):
        with pytest.raises(ValueError):
            yfd.get(SYMBOL, "nonexistent_type")

    def test_missing_symbol_returns_none(self):
        result = yfd.get("ZZZZZZNOTREAL", "price")
        assert result is None
