class Abort(BaseException):
    pass
