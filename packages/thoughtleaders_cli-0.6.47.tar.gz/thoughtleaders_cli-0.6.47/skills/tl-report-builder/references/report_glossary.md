# Report Glossary

Phase 1 + 2 disambiguation: report-type synonyms, TL terminology, field-pair choices, deal-stage jargon, common pitfalls. Schemas (`*_filterset_schema.json`) define what's available; this file defines what to prefer when terms overlap. If a term isn't here, default to the schema's `_tl_intent_hints` or ask.

## Report-type synonyms

| Type | Canonical | Common synonyms / aliases | Notes |
|---|---|---|---|
| **1** | CONTENT | "uploads", "videos", "content", "video search", "individual videos", "per-video" | Each row is one upload (video / podcast / article). |
| **2** | BRANDS | "brands", "advertisers", "sponsors" *(loose)*, "competitor research" | Each row is one brand, aggregated across mentions. |
| **3** | THOUGHTLEADERS / CHANNELS | "channels", "creators", "youtubers", "publishers", "channel discovery", "TL report" *(loose)* | Each row is one channel. **Default when "report" + creators context.** |
| **8** | CAMPAIGN_MANAGEMENT / SPONSORSHIPS | "sponsorships", "deals", "adlinks", "deal pipeline", "sales pipeline" | Each row is one sponsorship deal. Internal users only. |

### Ambiguous terms — ask, don't guess

| Term | Could mean | Clarifying question |
|---|---|---|
| **"campaign"** / **"campaign report"** | Type 8 (most common in deal-tracking) **OR** generic Django sense (any report) | "Do you want a sponsorship-deal report (one row per deal), or a different report type?" |
| **"sponsors report"** | Type 2 (brands) **OR** type 8 (deals) | "List the brands (one row per brand) or the deals (one row per deal)?" |
| **"creator report"** *(singular)* | Type 3 of one creator **OR** type 1 uploads from one creator | "Filter to one channel and show their videos, or surface them inside a channels list?" |
| **"performance report"** | Type 8 (deal performance) **OR** type 3 (channel engagement) | "Deal-level performance (won/lost) or channel-level (engagement, growth)?" |
| **"pipeline"** *(no other context)* | Type 8 with active-stage filter | Default to type 8; confirm. |
| **"book of business"** | Type 8 with `tl_sponsorships_only: true` | Default to type 8 + filter; confirm scope. |

### TL role / pool synonyms + TL terminology

> **Canonical source**: [`tl/references/business-glossary.md`](../../tl/references/business-glossary.md) — the canonical home for TL business terminology (MSN, TPP, MBN, AM/TM ownership, View Guarantees, Net revenue, TL profit, performance grade, industry-vs-TL vocabulary translations). Do NOT redefine these terms here; this skill defers to the glossary.

Quick **FilterSet-mapping reference** (where these business terms appear in the report-builder context — for full definitions see the canonical glossary):

| Term | FilterSet / `filters_json` mapping in this skill |
|---|---|
| **MSN** | `msn_channels_only: true` |
| **TPP** | resolve-and-pin pattern — `SELECT id FROM thoughtleaders_channel WHERE is_tl_channel = TRUE AND is_active = TRUE ORDER BY id` → put IDs in `filterset.channels` |
| **MBN** | `cross_references` type `include_sponsored_by_mbn` |
| **AM** / Account Manager | `owner_advertiser_name` (in `filters_json` for type 8) |
| **TM** / Talent Manager | `owner_publisher_name` (in `filters_json` for type 8) |
| **Reach** | `reach_from` / `reach_to` (narrate as "subscribers" per business-glossary) |
| **Projected Views (PV)** | `projected_views_from` / `projected_views_to`; column `Projected Views` |
| **View Guarantee (VG)** | Type 8 columns: `Views Guaranteed`, `Views Guarantee Days` |
| **Net revenue** | Type 8 column: `Revenue` |
| **TL profit** | Custom formula `{Price} - {Cost}` (NOT "margin" — see glossary) |
| **Sold sponsorship / Match / Proposal / Deal** | `filters_json.publish_status` (see "Deal-stage jargon" below for ID mapping) |

### Industry terms — DON'T emit in config

Industry-default terms that don't translate; never put in field names, formulas, columns, or user-facing copy:

- ❌ **"flight"** (MarTech) → say "campaign" or "date range" (full flight-variant translation lives in [`business-glossary.md`](../../tl/references/business-glossary.md) "Industry Terms vs TL Vocabulary")
- ❌ **"hero / hero-tier / hero channel"** → say "high-priority" or "TPP" if appropriate
- ❌ **"margin"** (accounting) → say `Net revenue` or `TL profit`
- ❌ **"impressions"** in YouTube context → say `Views` or `Projected Views`

Mirror the user's language in the *clarifying question*; emit TL terms in the config.

## Deal-stage jargon (type 8)

Map informal descriptions → `filters_json.publish_status` IDs (integer; platform doesn't accept string labels):

| User says | `publish_status` ID(s) | Other `filters_json` | Status name |
|---|---|---|---|
| "booked" / "sold" / "closed" / "won" | `3` | — | Sold |
| "proposed" / "approved by creator" | `0` | — | Creator Approved |
| "pending" | `2` | — | Pending |
| "rejected" *(any side)* | `4, 5, 9` | — | Rejected by Brand / Creator / Agency |
| "matched" | `7` | — | Matched |
| "reached out" / "outreach" | `8` | — | Reached Out |
| **"pipeline"** *(default)* | `0, 2, 6, 7, 8` | — | All active non-sold |
| **"in progress"** / **"active"** | `0, 2, 3, 6` | — | Active incl. sold |
| **"live"** / **"currently running"** | `3` | `ad_publish_status: "0"` | Sold AND published |

Full `publish_status` enum (all 12 codes incl. CLIENT_SIDE_* and pipeline weights) lives at the canonical schema home: [`tl/references/postgres-schema.md` → `publish_status` Constants](../../tl/references/postgres-schema.md#publish_status-constants). The NL → ID mapping above is what this skill consumes; refer to the schema doc for the full enum and Django-side constants.

## Field-pair disambiguation

### Date scopes

| User intent | Fields | Why |
|---|---|---|
| "Last 90 days" / rolling | `days_ago` (+ optionally `days_ago_to`) | Rolling = relative to now |
| "Between Jan 1 and Mar 31" | `start_date` + `end_date` | Absolute window |
| "Channels created on TL since X" | `createdat_from` (+ `createdat_to`) | TL-side record creation, not YouTube publish |
| Sponsorship send/publish | `start_date` / `end_date` (type 8 reuses for send_date) | Type 8 semantics shift — see schema |

### Channel-size signals

> SQL/internal term = `reach`; user-facing term = **subscribers** (see business-glossary canonical mapping). Emit `reach_from` / `reach_to` in FilterSet; narrate as "subscribers" everywhere user-facing (sample headers, takeaways, summaries).

| User intent | Field | Narrate as |
|---|---|---|
| "100K+ subscribers" / size floor | `reach_from` (+ `reach_to`) | "subscribers" / "channel size" |
| "Channels expecting >X projected views" | `projected_views_from` (+ `projected_views_to`) | "projected views" — forward-looking pricing estimate |
| Raw YouTube views per video | `youtube_views_from` (+ `youtube_views_to`) | "views per video" — per-upload, type 1 only |

### Demographic shares

| User intent | Fields | Why |
|---|---|---|
| "Mostly US audience" (single threshold) | `demographic_usa_share` | Interpreted as ≥ this share |
| "USA share between 40 and 80" (range) | `min_demographic_usa_share` + `max_demographic_usa_share` | Range variant |
| Same pattern for male / mobile / computer / TV / tablet / game-console | `min_*_share` + `max_*_share` | Prefer min/max pair on ranges |

### Keyword surfaces

| User intent | Fields | Why |
|---|---|---|
| Match keywords in video transcripts/titles | `content_fields` includes `content`, `title`, `transcript` | Standard type 1 |
| Match channel descriptions only | `content_fields = ["channel_description", "channel_description_ai", "channel_topic_description"]` | Standard type 3 |
| Different keywords need different fields | `keyword_content_fields_map` (per-position) | E.g., brand name → `channel.channel_name`; topic → descriptions |
| "But not X" | `keywords` includes `X` + `keyword_exclude_map["<index>"] = true` | Substring negation per-position |
| User wants ALL keywords to match | `keyword_operator = "AND"` | Default is OR |

### Sponsorship status (type 8)

No first-class status field — encode in `filters_json.publish_status` only. See "Deal-stage jargon" for the NL → ID mapping.

## Defaults (unless contradicted)

| Field | Default | Why |
|---|---|---|
| `languages` | `["en"]` | TL's working market |
| `channel_formats` | `[4]` (Video) | TL's working format |
| `days_ago` for type 8 | `365` | Type 8 without date scope is unbounded |
| `sort` | Per-type default — see `_tl_default_by_report_type` | Reports must be sortable |

Drop a default only if the user contradicts it ("include Spanish too", "look at TikTok").

## Filter-source decisions: typed field vs `filters_json`

Always prefer typed fields. `filters_json` is the catch-all (no validation, no type checks). Use ONLY when:

1. No first-class field exists (e.g., type-8 `publish_status`)
2. A field exists but its semantics don't match the request

Never put something in `filters_json` that has a typed field — confuses precedence, may silently override.

## Common pitfalls

- **Date upper bounds** — `start_date`/`end_date` are `DateField`; platform uses `__lt next_day`, not `__lte`. "Through Feb 28" → `end_date = "2026-02-28"`. Don't be clever.
- **`is_offline`** — 5-char string, not boolean. Preserve platform encoding.
- **`topics` is a real field** — `topic_matcher` can emit `topics: [<id>]` directly, OR expand to `keywords[]`. Both valid; pick by intent (topic-bounded vs keyword-bounded precision).
- **Brand/channel names ≠ IDs** — always run `name_resolver` before emitting `channels: [...]` / `brands: [...]`. Type 8 with unresolved names is a hard failure.
- **`tl_sponsorships_only`** ≠ `msn_channels_only`. First restricts to channels with TL sponsorship history; second to MSN-network channels. Pick by intent.
- **"Campaign" is colliding** — Django umbrella model vs TL business sense (type 8). Phase 1 must clarify on "campaign report".
- **Free-text niches → keywords only, NEVER `content_categories` as pre-filter.** Niches like "motorcycle vlogging" scatter across LIFESTYLE / SPORTS / HOWTO / ENTERTAINMENT. Using `content_categories` as a pre-filter excludes channels that fit the niche but are tagged in a sibling bucket. Only use `content_categories` when the user explicitly names a TL category label (e.g., "Lifestyle channels"). Otherwise match via `keyword_groups` against `content_fields`.
