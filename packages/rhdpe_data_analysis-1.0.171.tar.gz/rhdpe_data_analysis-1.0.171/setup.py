from setuptools import setup, find_packages
setup(
name='rhdpe_data_analysis',
version='1.0.171',
author='Phil Smith',
author_email='pvsmith100@btinternet.com',
description='Package for analysing data relating to recycled HDPE',
packages=find_packages(),
classifiers=[
'Programming Language :: Python :: 3',
'License :: OSI Approved :: MIT License',
'Operating System :: OS Independent',
],
python_requires='>=3.6',
)
