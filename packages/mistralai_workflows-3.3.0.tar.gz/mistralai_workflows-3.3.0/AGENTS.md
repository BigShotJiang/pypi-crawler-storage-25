# Mistral Workflows SDK — Development Guidelines

## Project Context

`workflow_sdk` is the Python SDK for defining and running Mistral Workflows. It provides the decorator-based API and the client for submitting and querying workflow executions.

## Code Style Guidelines

### Formatting
- Do not put import statements inside functions or classes unless strictly required to avoid circular imports.

### Comments and Documentation

**Add docstrings only when:**
- The function is part of the public API (exported from the SDK surface).
- The logic is genuinely complex and not self-explanatory.

**Do not add comments that:**
- Restate what the code obviously does.
- Announce what was just added or changed.

### General Guidelines

- Write self-documenting code with clear variable and function names.
- Follow existing patterns in the codebase.
- Keep the public API surface minimal — internal helpers should not leak.

## Testing

The SDK has two test layers:

| Layer | When to use |
|-------|-------------|
| Unit (`make test`) | Default — tests SDK behavior in-process without Docker |
| Integration (`make integration-tests`) | Only for SDK↔API contract (registration, execution, auth) |

Unit tests use Temporal's `WorkflowEnvironment` (in-process) via the `temporal_env` fixture in `conftest.py`. No Docker required.

**Rules:**
- Mock only external side effects inside activities (HTTP, filesystem, third-party clients). Never mock Temporal.
- Test observable behavior, not implementation details.
- Never mix SDK concerns and API concerns in a single test.
- Tests must be runnable anywhere: dev machines, CI, staging, on-prem.
- Group related tests with classes and methods.
- Use `pytest.mark.parametrize` to share test logic across multiple inputs.

## Tooling and Setup

- Use `uv` for dependency management and running tools.

### Standard Makefile Targets

- `make lint`: Run linting, formatting validation, and type checks.
- `make format`: Auto-format code.
- `make typecheck`: Run static type checking only.
- `make test`: Run the unit test suite.
- `make integration-tests`: Run integration tests against the local stack.
- `make installdeps`: Install dependencies and update lock files.
- `make check-api-surface`: Detect breaking changes to the public API surface.
- `make lock`: Regenerate `uv.lock` for `workflow_sdk` only (see below).

### Locking dependencies

After editing `pyproject.toml`, regenerate the lockfile with:

```
make lock
# or
uv run invoke lock
```

This first runs `uv lock` to update `workflow_sdk`'s own lockfile, then runs `../scripts/renovate/cascade_uv_lock.py workflow_sdk`, which builds a reverse dependency graph from `[tool.uv.sources]` path entries and re-locks all transitive dependents (editable local deps only).

### Updating the `mistralai` version

If you bump the `mistralai` version constraint in `pyproject.toml`, you must also update the `override-dependencies` entry in the nuage v2 plugin so its lockfile pins the same version:

- `plugins/nuage_v2/pyproject.toml` → `[tool.uv] override-dependencies`

This override exists because the nuage plugin depends on a version of `mistral-vibe` that is not compatible with the latest `mistralai` release. Keeping it in sync prevents resolution conflicts when running `make lock`.

For more granular control, use `uv run invoke` directly. For example, to run a specific test:

```
uv run invoke tests -k test_specific_name
```

### Changelog

Every PR that touches `workflow_sdk` must include a changelog fragment or it will fail CI. Use `ovide` to create one:

```
uv run ovide new
```

This creates a file in `changelog.d/` with a bump level (`patch`, `minor`, `major`) and a kind (`Added`, `Changed`, `Fixed`, etc.). If the change genuinely does not warrant a changelog entry (e.g. CI or tooling fixes), add the `no-changelog` label to the PR instead.
