# Changelog

## [3.3.0] - 2026-04-23

### Added

- Add example workflows for partial encryption and weighted payloads
- Add `on_behalf_of` flag to the `@workflow.define` decorator to mark workflows that must run associated to a user's identity
- Publish root worker events over the v2 route-token transport while keeping child workflow events on the existing v1 path.
- Add LocationType enum to protocol and surface deployment location (location_type, k8s_cluster, k8s_namespace) in DeploymentLocationConfig

### Changed

- Route read_file and grep to structured workflow tool UIs
- hide warning if no heartbeat endpoint is available in API in worker heartbeat loop
- Change next_cursor type from uuid.UUID to str in WorkflowListResponse, WorkflowListResponseInternal, and WorkflowRegistrationListResponse
- Include connector_id and connector_name in connector-auth failure message for easier debugging
- Update mistralai to 2.4.2:
  - `request.encoded_input` removed from execute_workflow.
  - `execute_workflow_and_wait` arguments are now more consistent with `execute_workflow`.
- Add `max_workflow_task_pollers` / `max_activity_task_pollers` settings to `WorkerConfig` for manual tuning.

### Removed

- Exclude encoded_input from generated client code for execute_workflow

### Fixed

- Remove by default on-behalf-of workflows when starting all workflows using all_workflows_worker.py
- Fix event ordering not being preserved when falling back to single-event sending
- Limit event emission local activities to 3 retry attempts and catch `CancelledError` so that workflow execution is never blocked by event publishing failures

## [3.2.0] - 2026-04-20

### Added

- Added workflow event route token protocol primitives and JWT support for Phase 1 routing.
- Add prefilled_value parameter to form field helpers (TextField, NumberField, DateTimeField, DateField, SingleChoice, MultiChoice) as a schema-only UI hint that pre-fills form fields without making them optional — unlike a runtime default, the field remains required and must be explicitly submitted.
- Add /executor-identity-token endpoint to abraxas and regenerate the worker client
- Add `ExecutorIdentityHook` to replace the worker's API key with a short-lived executor identity JWT on outgoing requests. Opt in via `use_executor_credentials=True` on `get_mistral_client`.
- add connectors integration in workflows
- Add `include_metadata` parameter to `FileField` for file uploads with structured metadata (filename, url, content_type)
- Added WorkflowRunWithoutResultResponse and WorkflowRunListResponse, and WorkflowRunResponse as type alias
- Added `blob_storage_configs` field to `WorkerConfig`, allowing teams to declare named blob storage backends via env vars (`BLOB_STORAGE_CONFIGS__<name>__*`) and reference them by name using the existing `get_blob_storage` primitive.
- Add `discover_all_workflows_in_package(package_name, skip_modules)` helper to `all_workflows_worker` for scanning an arbitrary package for workflow classes, with deduplication and structured logging.
- Add integration tests for executor credentials: abraxas workflows list, chat completions, and connectors list (staging/prod-gated)
- Add a long-running execution-token example workflow for route-token integration testing.

### Changed

- Removed `WorkerClient` abstraction layer. Use `get_worker_client()` which returns a `PrivateWorkerClient` directly. Callers should use `PrivateWorkerClient` methods (`whoami_async`, `register_workflow_definitions_async`, `heartbeat_async`) instead of the removed wrapper methods.
- Migrates encoding logic (payload offloading, encryption, blob storage) from workflow_sdk into the mistralai Python package (v2.4.0+). This reduces code duplication and centralizes encoding capabilities.

### Fixed

- `__submit_input` update handler now raises `ApplicationError` instead of returning an error in the result payload, surfacing proper 422 responses for unknown task IDs and invalid input
- Reject empty string values in workflow event route token claims for workflow names and execution identifiers.
- transform SANDBOX_RESTRICTIONS to get_sandbox_restrictions to avoid circular imports when launching individual tests
- Add `arrayValue` support to Tempo trace attribute models. Traces containing array-typed span attributes (e.g. message lists, finish reasons) no longer fail validation.
- Update the Temporal Python SDK support window to 1.24.0 to pick up the patched quinn-proto dependency.
- Fix an issue causing infinite running execution when a workflow's return value doesn't match its declared return type
- Propagate execution token through continue-as-new so identity extraction no longer fails after Temporal history compaction.

## [3.1.1] - 2026-04-08

### Fixed

- Remove unused opentelemetry-instrumentation-fastapi dependency and pin otel instrumentation packages to <0.61b0 to resolve conflict with mistralai

## [3.1.0] - 2026-04-07

### Added

- Allow primitive and multi-param types in execute_activities_in_parallel, with upfront input validation
- Add `wf-diagnose` CLI command for support triage. Prints a self-contained diagnostic report covering system info, installed package versions, worker env vars, full parsed config, plugins, `/whoami` response, and connectivity checks against the Mistral API and Temporal.
- Add `activity_heartbeat` wrapper to avoid direct `temporalio` imports in user code. Exported from `mistralai.workflows`.
- Add a signal based streaming example workflow
- Add workflow.now(), workflow.uuid4(), and workflow.random() helpers to avoid direct temporalio imports in user code.

### Changed

- `WorkflowRegistration.task_queue` is now deprecated and will be removed in a future release.

  **What changed:** the field is no longer stored on the registration. It is kept in the SDK model as `None` for now so that existing code reading `registration.task_queue` does not get an `AttributeError`. `task_queue` is the same value as the deployment name.

  **Migration:**
  - Replace any usage of `registration.task_queue` with `registration.deployment_id` and resolve the deployment name through the `Deployment` object. The `deployment_id` field on `WorkflowRegistration` is the stable reference going forward.
  - If you configure your worker with `task_queue` only (no `deployment_name`), the SDK continues to work as before for backwards compatibility, using the single task queue as the deployment name. Workers sending multiple distinct task queues without a `deployment_name` are no longer accepted — set `deployment_name` explicitly in the worker configuration instead.

- Exclude `mistralai.workflows.*.examples` modules from sandbox passthrough
- Update mistralai to 2.3.0:
  - to accept BaseModel when calling client.workflows.execute_workflows
  - use code with speakeasy version updated (1.754.0 -> 1.761.1) which fixes:
    - default timeout on http requests
    - some pagination code
  - removed whoami from public client
- Updated streaming workflow example to include a child workflow execution

### Deprecated

- Importing 'Mistral' from 'mistralai.workflows.plugins.mistralai' is deprecated. Import it directly from 'mistralai.client' instead.

### Fixed

- Configured get_mistral_client's sync client to use the same headers as the async one
- Change WorkflowExecutionRequest.input json_schema_extra to allow BaseModel in generated client
- Set speakeasy version to 1.761.1
- Fix an issue related to span propagation in `Task` causing some workflow errors
- Default `mistral_client_server_url` to `server_url` when not explicitly set

## [3.0.1] - 2026-04-01

### Added

- Tasks now emit 0-time OTEL spans during their lifecycle

### Fixed

- Fixed calling activities in parralel when determinism is enforced
- Fixed published Workflows package documentation links to use the public Workflows docs URL

## [3.0.0] - 2026-03-30

> **Breaking:** The SDK namespace has moved from `mistralai_workflows` to `mistralai.workflows`.
> Update all imports (e.g. `from mistralai.workflows import workflow, activity`).

---

### Added

#### Package & Namespace

- The SDK package namespace has been migrated from `mistralai_workflows` to `mistralai.workflows`.
- Re-exported `imports_passed_through` and `sandbox_unrestricted` from `temporalio.workflow.unsafe` so users don't need to depend on Temporal internals directly.
- Prefixed internal implementation files with a leading underscore to clearly distinguish them from public API modules. This is a breaking change for any code importing directly from these internal module paths.
- Migrate workflows client core to mistralai SDK: removed WorkflowsClient in favor of the generated mistralai client for all workflow operations (execute, schedule, query, traces, registrations, etc.)

#### Workers & Deployment

- Workers now register under a named deployment identity, enabling per-deployment task queue routing and versioning.
- Worker now uses `DEPLOYMENT_NAME` as the Temporal task queue name. `TEMPORAL_TASK_QUEUE` is kept for backwards compatibility but raises if it conflicts with `DEPLOYMENT_NAME`.
- Workers now fail fast at startup when `DEPLOYMENT_NAME` is not set and no meaningful deployment identity can be derived from the config, instead of silently registering under the `"default"` queue.
- Versioned workers (with `deployment_name` and `build_id`) are now forbidden from using the `default` task queue to prevent Temporal versioning conflicts.
- Validate `deployment_name` on register and heartbeat requests: names must match `^[a-zA-Z0-9_\-\.]+$`; invalid names return a 422 error.
- Add deployment location metadata (local/k8s) to worker registration.
- Added a worker health HTTP endpoint to replace log-based health checks.

#### Determinism enforcement

- Enable determinism enforcement by default. Use `DEFAULT_ENFORCE_DETERMINISM=0` on your worker, or `enforce_determinism=False` in your workflow decorator to disable it.

#### Workflow Execution

- Added `wait=False` support to `execute_workflow()` for fire-and-forget child workflow execution, returning a `ChildWorkflowHandle` that can be awaited later.
- Added a default `execution_timeout` of 1 hour on workflow executions to prevent infinite retries when no workers are active.
- Added batch cancel and terminate endpoints for cancelling or terminating multiple workflow executions at once.
- Added execution token metadata injection for cross-workflow tracing and observability.
- Workflow events are now sent in batches instead of one-by-one, reducing HTTP overhead for activities that emit many events.

#### Activities & Handlers

- Added `**kwargs` support for query, signal, and update handlers, allowing extra keyword arguments to be forwarded from callers.
- Added support for multiple resources in workflow output.
- Handle bare union of workflow input schemas.

#### API & Client

- Expose Workflows API (runs, executions, events, schedules) in the mistralai SDK.
- Added the `fetch_executor_identity` method to the client.
- `WorkflowsClient` now sends a `User-Agent` header with the SDK version on all API requests.
- Replaced hand-written HTTP calls in `WorkflowsClient` with a Speakeasy-generated `worker_client` SDK for improved reliability and maintainability.
- Implemented the runtime identity-fetching mechanism for nuage_v2's workflow start-up.
- Renamed `WorkflowVersion` to `WorkflowRegistration` across the SDK to better reflect what it represents.
- Relax `WorkflowScheduleRequest` validator: `workflow_identifier` alone is now valid without `workflow_task_queue`.
- Added optional HTTP proxy configuration for the Temporal client connection.

#### UI & Forms

- Moved conversational UI utilities (forms, chat inputs, todo lists, confirmations, canvas) from the mistralai plugin to the main SDK. Mistral-specific components (canvas, UI components, assistant messages) remain in the lechat plugin module.
- Added `DateField` helper for workflow forms, supporting date-only picker UI alongside the existing date-time field.
- Support `UIComponentResource` in `ResourceOutput`.
- Add `CommandToolUIState` in list of available `ToolUIState`.
- Add `@input_tag` decorator to annotate workflow input schemas with `x-input-tag`, and `@conversational_input` shorthand for Le Chat usage.

#### Plugins

- Added HTTP/webhook plugin, enabling workflows to receive HTTP requests from external services (GitHub, Linear, Slack, etc.).
- Relaxed plugin version bounds from `<3.0.0` to `>=3.0.0a1,<4.0.0`, allowing co-installation of pre-release SDK and plugin versions.
- Upgraded `mistralai` SDK dependency to v2.0.0 in the workflows mistralai and nuage plugins.

---

### Removed

- Removed the dead `publish_stream_event` client method which had no server-side implementation.
- Removed deprecated APIs: `display_name` and `extends` activity fields, `record_event` tracing utility, and `workflow_name` workflow parameter (use `name` instead).

---

### Fixed

#### Activities

- Activities called as agent tools can now return any JSON-serializable value, not just Pydantic models.
- Fixed activity argument type validation when activities have optional parameters with default values.
- Allow keyword arguments when calling activities with typed parameters. Previously, any keyword argument was rejected even for valid named parameters. Now only unknown kwargs or duplicate positional/keyword arguments are rejected.

#### Workers & Temporal

- Use `TEMPORAL_DEPLOYMENT_NAME` for Temporal worker versioning in controller mode so workers register under the same deployment name the controller uses. `DEPLOYMENT_NAME` (task queue) is used for the heartbeat API only.
- Fixed child workflow `execution_timeout` parameter which was incorrectly passed as `task_timeout` to Temporal, changing its semantics from single-task timeout to full execution timeout.

#### Payload & Storage

- Added read-only support for the legacy `json/abraxas_v1` payload encoding to prevent 500 errors when decoding old Temporal payloads.
- Fixed payload decoding failure when combining offloaded and partially encrypted payloads.
- Fixed storage key prefix to properly URL-quote execution IDs and namespaces, preventing key collisions with special characters.

#### Plugins & Client

- Fixed streaming truncation bug in the mistralai plugin where the first tool call chunk's arguments were dropped.
- Fixed `HTTPRouterWorkflow` entrypoint generation for inherited router workflow subclasses.
- Fixed `WorkflowSpecsRegisterResponse` to accept both old (`workflow_version_*`) and new (`workflow_registration_*`) field names from the server.
- Fix calls to mistralai client for Agent in workflows.

#### Error Messages

- Improved error message when a workflow event payload exceeds the maximum size, making the root cause easier to diagnose.

---

### Security

- API key is no longer logged in full in debug output; only the first 8 characters are shown.

---

## [2.0.0] - 2026-03-04

Initial public release of mistralai-workflows v2.
