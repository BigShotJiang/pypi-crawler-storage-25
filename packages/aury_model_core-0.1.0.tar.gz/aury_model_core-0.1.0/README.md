# aury-model-core

`aury-model-core` is rebuilding as the protocol and canonical model kernel for the Aury stack.

Current status:

- package name: `aury-model-core`
- Python import path: `aury.model.core`
- status: local v1 release gate is complete
- goal: keep the SDK centered on canonical messages, protocol conversion, and provider adapters
- core JSON codec: `msgspec`

Install:

```bash
uv sync --group dev
```

Sanity check:

```bash
uv run pytest -q
uv run python scripts/release_readiness.py
```

Current import:

```python
from aury.model.core import ModelClient, msg
```
