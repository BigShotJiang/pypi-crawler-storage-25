"""Public option bags for request shaping."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal

from pydantic import Field

from ._base import CoreModel
from .canonical import ToolSpec
from .families import ApiFamily


class StructuredOutputMethod(StrEnum):
    function_calling = "function_calling"
    json_schema = "json_schema"
    json_mode = "json_mode"
    auto = "auto"


class ReasoningOptions(CoreModel):
    enabled: bool | None = None
    effort: Literal["minimal", "low", "medium", "high"] | None = None
    budget_tokens: int | None = None
    return_thinking: bool = False


class StructuredOutputSpec(CoreModel):
    schema_: Any = Field(alias="schema", serialization_alias="schema")
    method: StructuredOutputMethod = StructuredOutputMethod.auto
    strict: bool | None = None
    include_raw: bool = False


class CachePolicy(CoreModel):
    namespace: str | None = None
    provider_native: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class StreamOptions(CoreModel):
    enabled: bool | None = None
    include_usage: bool = True
    include_raw_frames: bool = False


class CallOptions(CoreModel):
    provider: str | None = None
    model: str | None = None
    base_url: str | None = None
    api_key: str | None = None
    headers: dict[str, str] = Field(default_factory=dict)

    api_family: ApiFamily | None = None
    dialect: str | None = None

    tools: list[ToolSpec] | None = None
    tool_choice: str | dict[str, Any] | None = None

    reasoning: ReasoningOptions | None = None
    response: StructuredOutputSpec | None = None
    caching: CachePolicy | None = None
    stream: StreamOptions | None = None

    metadata: dict[str, Any] = Field(default_factory=dict)
    extra_body: dict[str, Any] | None = None
    native: dict[str, Any] | None = None

    timeout: float | None = None
    max_retries: int | None = None

    max_tokens: int | None = None
    temperature: float | None = None
    top_p: float | None = None
    stop: str | list[str] | None = None
    seed: int | None = None

    def merge(self, override: CallOptions | None) -> CallOptions:
        if override is None:
            return self

        data = {field_name: getattr(self, field_name) for field_name in type(self).model_fields}
        fields_set = set(self.model_fields_set)
        for field_name in override.model_fields_set:
            value = getattr(override, field_name)
            if field_name in {"headers", "metadata"}:
                merged = dict(data.get(field_name) or {})
                if value:
                    merged.update(value)
                data[field_name] = merged
                fields_set.add(field_name)
                continue
            data[field_name] = value
            fields_set.add(field_name)
        return CallOptions.model_construct(_fields_set=fields_set, **data)
