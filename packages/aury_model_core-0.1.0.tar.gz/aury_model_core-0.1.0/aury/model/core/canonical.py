"""Canonical message, part, and event types."""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Any, Literal

from pydantic import Field, TypeAdapter

from ._base import CoreModel
from ._json import json_dumps


class Role(StrEnum):
    system = "system"
    developer = "developer"
    user = "user"
    assistant = "assistant"


class AssetKind(StrEnum):
    image = "image"
    audio = "audio"
    document = "document"
    file = "file"


class AssetSourceType(StrEnum):
    url = "url"
    data_url = "data_url"
    file_path = "file_path"
    file_id = "file_id"
    bytes_ref = "bytes_ref"


class AssetRef(CoreModel):
    """Stable asset reference used by the canonical layer."""

    kind: Literal["image", "audio", "document", "file"]
    source_type: Literal["url", "data_url", "file_path", "file_id", "bytes_ref"]
    value: str
    mime_type: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class TextPart(CoreModel):
    type: Literal["text"] = "text"
    text: str


class ThinkingPart(CoreModel):
    type: Literal["thinking"] = "thinking"
    text: str
    signature: str | None = None
    provider_metadata: dict[str, Any] = Field(default_factory=dict)


class ImagePart(CoreModel):
    type: Literal["image"] = "image"
    asset: AssetRef
    detail: Literal["auto", "low", "high"] | None = None


class DocumentPart(CoreModel):
    type: Literal["document"] = "document"
    asset: AssetRef


class AudioPart(CoreModel):
    type: Literal["audio"] = "audio"
    asset: AssetRef


class FilePart(CoreModel):
    type: Literal["file"] = "file"
    asset: AssetRef


class ToolCallPart(CoreModel):
    type: Literal["tool_call"] = "tool_call"
    id: str
    name: str
    arguments: dict[str, Any] | list[Any] | str | None = None
    tool_type: str = "function"
    provider_metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def arguments_json(self) -> str:
        if isinstance(self.arguments, str):
            return self.arguments
        return json_dumps(self.arguments or {})


class ToolResultPart(CoreModel):
    type: Literal["tool_result"] = "tool_result"
    tool_call_id: str
    output: Any = None
    is_error: bool = False


Part = Annotated[
    TextPart
    | ThinkingPart
    | ImagePart
    | DocumentPart
    | AudioPart
    | FilePart
    | ToolCallPart
    | ToolResultPart,
    Field(discriminator="type"),
]
PART_ADAPTER = TypeAdapter(Part)


class Message(CoreModel):
    role: Role
    parts: list[Part] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def text(self) -> str:
        return "".join(part.text for part in self.parts if isinstance(part, TextPart))

    @property
    def thinking(self) -> str:
        return "".join(part.text for part in self.parts if isinstance(part, ThinkingPart))

    @property
    def tool_calls(self) -> list[ToolCallPart]:
        return [part for part in self.parts if isinstance(part, ToolCallPart)]

    @property
    def tool_results(self) -> list[ToolResultPart]:
        return [part for part in self.parts if isinstance(part, ToolResultPart)]


class Usage(CoreModel):
    input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    total_tokens: int = 0
    estimated: bool = False


class Evt(StrEnum):
    response_start = "response_start"
    message_start = "message_start"
    part_start = "part_start"
    content = "content"
    thinking = "thinking"
    signature = "signature"
    thinking_completed = "thinking_completed"
    tool_call_start = "tool_call_start"
    tool_call_delta = "tool_call_delta"
    tool_call_complete = "tool_call_complete"
    tool_result = "tool_result"
    part_complete = "part_complete"
    usage = "usage"
    response_complete = "response_complete"
    error = "error"


class StreamEvent(CoreModel):
    type: Evt
    delta: str | None = None
    part: Part | None = None
    usage: Usage | None = None
    tool_call_id: str | None = None
    error: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class FunctionToolSpec(CoreModel):
    name: str
    description: str | None = None
    parameters: dict[str, Any] = Field(
        default_factory=lambda: {"type": "object", "properties": {}}
    )


class ToolSpec(CoreModel):
    kind: Literal["function"] = "function"
    function: FunctionToolSpec


class msg:
    """Thin message factory helpers."""

    @staticmethod
    def _asset_to_part(asset: AssetRef) -> Part:
        if asset.kind == AssetKind.image:
            return ImagePart(asset=asset)
        if asset.kind == AssetKind.document:
            return DocumentPart(asset=asset)
        if asset.kind == AssetKind.audio:
            return AudioPart(asset=asset)
        return FilePart(asset=asset)

    @staticmethod
    def _to_part(item: str | AssetRef | Part | dict[str, Any]) -> Part:
        if isinstance(item, str):
            return TextPart(text=item)
        if isinstance(item, AssetRef):
            return msg._asset_to_part(item)
        if isinstance(
            item,
            (
                TextPart,
                ThinkingPart,
                ImagePart,
                DocumentPart,
                AudioPart,
                FilePart,
                ToolCallPart,
                ToolResultPart,
            ),
        ):
            return item
        return PART_ADAPTER.validate_python(item)

    @staticmethod
    def _message(
        role: Role,
        *items: str | AssetRef | Part | dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> Message:
        return Message(
            role=role,
            parts=[msg._to_part(item) for item in items],
            metadata=metadata or {},
        )

    @staticmethod
    def system(text: str, *, metadata: dict[str, Any] | None = None) -> Message:
        return msg._message(Role.system, text, metadata=metadata)

    @staticmethod
    def system_parts(
        *items: str | AssetRef | Part | dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> Message:
        return msg._message(Role.system, *items, metadata=metadata)

    @staticmethod
    def developer(text: str, *, metadata: dict[str, Any] | None = None) -> Message:
        return msg._message(Role.developer, text, metadata=metadata)

    @staticmethod
    def developer_parts(
        *items: str | AssetRef | Part | dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> Message:
        return msg._message(Role.developer, *items, metadata=metadata)

    @staticmethod
    def user(text: str, *, metadata: dict[str, Any] | None = None) -> Message:
        return msg._message(Role.user, text, metadata=metadata)

    @staticmethod
    def user_parts(
        *items: str | AssetRef | Part | dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> Message:
        return msg._message(Role.user, *items, metadata=metadata)

    @staticmethod
    def assistant(
        text: str | None = None,
        *,
        thinking: str | None = None,
        tool_calls: list[ToolCallPart | dict[str, Any]] | None = None,
        tool_results: list[ToolResultPart | dict[str, Any]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Message:
        parts: list[Part] = []
        if thinking:
            parts.append(ThinkingPart(text=thinking))
        if text:
            parts.append(TextPart(text=text))
        for tool_call in tool_calls or []:
            parts.append(msg._to_part(tool_call))
        for tool_result in tool_results or []:
            parts.append(msg._to_part(tool_result))
        return Message(role=Role.assistant, parts=parts, metadata=metadata or {})

    @staticmethod
    def assistant_parts(
        *items: str | AssetRef | Part | dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> Message:
        return msg._message(Role.assistant, *items, metadata=metadata)

    @staticmethod
    def tool_call(
        *,
        id: str,
        name: str,
        arguments: dict[str, Any] | list[Any] | str | None = None,
        tool_type: str = "function",
        provider_metadata: dict[str, Any] | None = None,
    ) -> ToolCallPart:
        return ToolCallPart(
            id=id,
            name=name,
            arguments=arguments,
            tool_type=tool_type,
            provider_metadata=provider_metadata or {},
        )

    @staticmethod
    def tool_result(
        tool_call_id: str,
        output: Any,
        *,
        is_error: bool = False,
    ) -> ToolResultPart:
        return ToolResultPart(
            tool_call_id=tool_call_id,
            output=output,
            is_error=is_error,
        )
