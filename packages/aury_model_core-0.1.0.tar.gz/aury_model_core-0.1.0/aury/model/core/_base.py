"""Shared model base classes for aury-model-core."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class CoreModel(BaseModel):
    """Frozen, strict-by-default base model for public and internal types."""

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        arbitrary_types_allowed=True,
        populate_by_name=True,
    )
