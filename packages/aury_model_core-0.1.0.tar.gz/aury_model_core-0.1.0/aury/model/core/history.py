"""History compaction primitives for canonical transcripts."""

from __future__ import annotations

from pydantic import Field

from ._base import CoreModel
from .canonical import Message, Role, ToolCallPart, ToolResultPart, msg


class HistoryCompaction(CoreModel):
    messages: list[Message]
    original_count: int
    kept_count: int
    dropped_count: int
    preserved_prefix_count: int = 0
    summary_inserted: bool = False
    warnings: list[str] = Field(default_factory=list)


def compact_messages(
    messages: list[Message],
    *,
    keep_last: int = 20,
    summary: str | Message | None = None,
    preserve_system: bool = True,
    preserve_tool_pairs: bool = True,
) -> HistoryCompaction:
    """Compact a transcript without executing summarization or tool work."""

    if keep_last < 1:
        raise ValueError("keep_last must be at least 1")

    initial_cutoff = max(0, len(messages) - keep_last)
    cutoff = initial_cutoff

    if preserve_tool_pairs:
        cutoff = _expand_cutoff_to_preserve_tool_results(messages, cutoff, preserve_system=preserve_system)

    preserved_prefix_indices = _prefix_indices(messages, cutoff) if preserve_system else []
    preserved_prefix = [messages[index] for index in preserved_prefix_indices]
    suffix = messages[cutoff:]

    dropped_indices = {index for index in range(cutoff) if index not in preserved_prefix_indices}
    summary_message = _coerce_summary(summary) if dropped_indices else None

    compacted = [*preserved_prefix]
    if summary_message is not None:
        compacted.append(summary_message)
    compacted.extend(suffix)

    warnings: list[str] = []
    if dropped_indices and summary_message is None:
        warnings.append("messages were dropped without a summary")
    if cutoff < initial_cutoff:
        warnings.append("cutoff moved earlier to preserve tool-call/tool-result pairs")

    return HistoryCompaction(
        messages=compacted,
        original_count=len(messages),
        kept_count=len(compacted),
        dropped_count=len(dropped_indices),
        preserved_prefix_count=len(preserved_prefix),
        summary_inserted=summary_message is not None,
        warnings=warnings,
    )


def _expand_cutoff_to_preserve_tool_results(
    messages: list[Message],
    cutoff: int,
    *,
    preserve_system: bool,
) -> int:
    while cutoff > 0 and _has_orphan_tool_result(messages, cutoff, preserve_system=preserve_system):
        cutoff -= 1
    return cutoff


def _has_orphan_tool_result(messages: list[Message], cutoff: int, *, preserve_system: bool) -> bool:
    seen_tool_calls: set[str] = set()
    included_indices = set(range(cutoff, len(messages)))
    if preserve_system:
        included_indices.update(_prefix_indices(messages, cutoff))

    for index in sorted(included_indices):
        for part in messages[index].parts:
            if isinstance(part, ToolCallPart):
                seen_tool_calls.add(part.id)
            elif isinstance(part, ToolResultPart) and part.tool_call_id not in seen_tool_calls:
                return True
    return False


def _prefix_indices(messages: list[Message], cutoff: int) -> list[int]:
    return [index for index, message in enumerate(messages[:cutoff]) if message.role in {Role.system, Role.developer}]


def _coerce_summary(summary: str | Message | None) -> Message | None:
    if summary is None or isinstance(summary, Message):
        return summary
    return msg.system(summary, metadata={"aury_compaction": "summary"})
