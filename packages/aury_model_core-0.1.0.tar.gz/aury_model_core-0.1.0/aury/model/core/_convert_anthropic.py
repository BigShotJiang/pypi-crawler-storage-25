"""Anthropic codec helpers."""

from __future__ import annotations

from typing import Any

from .analysis import ModelRequest
from .canonical import (
    AssetRef,
    AssetSourceType,
    AudioPart,
    DocumentPart,
    FilePart,
    FunctionToolSpec,
    ImagePart,
    Message,
    Role,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolResultPart,
    ToolSpec,
    Usage,
)
from .errors import UnsupportedModalityError
from .families import ApiFamily
from .options import CallOptions, ReasoningOptions, StreamOptions, StructuredOutputMethod, StructuredOutputSpec
from ._convert_common import (
    DecodedResponse,
    _coerce_role,
    _json_loads_or_keep,
    _parse_tool_output,
    _schema_to_json_schema,
    _stringify_output,
)
from ._json import json_dumps

_STRUCTURED_OUTPUT_TOOL_NAME = "structured_output"
_STRUCTURED_OUTPUT_TOOL_DESCRIPTION = "Return the final answer as structured JSON matching the requested schema."


def _decode_anthropic_request(payload: dict[str, Any]) -> ModelRequest:
    messages: list[Message] = []
    system = payload.get("system")
    if system:
        system_text = _anthropic_system_to_text(system)
        if system_text:
            messages.append(Message(role=Role.system, parts=[TextPart(text=system_text)]))

    for raw in payload.get("messages", []):
        if not isinstance(raw, dict):
            continue
        role = _coerce_role(str(raw.get("role") or "user"))
        parts = _decode_anthropic_content(raw.get("content"))
        messages.append(Message(role=role, parts=parts))

    raw_tool_choice = payload.get("tool_choice")
    response = _decode_anthropic_response_spec(payload.get("tools"), raw_tool_choice)
    tools = _decode_anthropic_tools(payload.get("tools"), exclude_structured_output=response is not None)
    tool_choice = None if _is_structured_output_tool_choice(raw_tool_choice, response) else _decode_anthropic_tool_choice(raw_tool_choice)

    return ModelRequest(
        messages=messages,
        options=CallOptions(
            model=payload.get("model"),
            api_family=ApiFamily.anthropic_messages,
            tools=tools or None,
            tool_choice=tool_choice,
            response=response,
            reasoning=_decode_anthropic_reasoning(payload.get("thinking")),
            stream=StreamOptions(enabled=True) if payload.get("stream") else None,
            max_tokens=payload.get("max_tokens"),
            temperature=payload.get("temperature"),
            top_p=payload.get("top_p"),
            stop=payload.get("stop_sequences"),
        ),
    )


def _encode_anthropic_request(request: ModelRequest) -> dict[str, Any]:
    options = request.options
    result: dict[str, Any] = {
        "model": options.model or "",
        "max_tokens": options.max_tokens or 4096,
    }
    system_lines: list[str] = []
    messages: list[dict[str, Any]] = []

    for message in request.messages:
        if message.role == Role.system:
            if message.text:
                system_lines.append(message.text)
            continue
        if message.role == Role.developer:
            if message.text:
                system_lines.append(f"[developer]\n{message.text}")
            continue
        messages.append(_encode_anthropic_message(message))

    if system_lines:
        result["system"] = "\n\n".join(system_lines)
    result["messages"] = messages

    tools = _encode_anthropic_tools(options.tools or [])
    structured_tool = _encode_anthropic_structured_output_tool(
        options.response,
        used_names={tool["name"] for tool in tools},
    )
    if structured_tool is not None:
        tools.append(structured_tool)
    if tools:
        result["tools"] = tools
    if options.tool_choice is not None:
        result["tool_choice"] = _encode_anthropic_tool_choice(options.tool_choice)
    elif structured_tool is not None:
        result["tool_choice"] = {"type": "tool", "name": structured_tool["name"]}
    if options.reasoning and (options.reasoning.enabled or options.reasoning.budget_tokens):
        result["thinking"] = {
            "type": "enabled",
            "budget_tokens": options.reasoning.budget_tokens or 1024,
        }
    if options.stream and options.stream.enabled is not False:
        result["stream"] = True
    if options.temperature is not None:
        result["temperature"] = options.temperature
    if options.top_p is not None:
        result["top_p"] = options.top_p
    if options.stop is not None:
        result["stop_sequences"] = options.stop if isinstance(options.stop, list) else [options.stop]
    if options.extra_body:
        result.update(options.extra_body)
    if options.native:
        result.update(options.native)

    return result


def _decode_anthropic_response(payload: dict[str, Any]) -> DecodedResponse:
    message = Message(
        role=Role.assistant,
        parts=_decode_anthropic_content(payload.get("content")),
    )
    return DecodedResponse(
        message=message,
        model=payload.get("model"),
        response_id=payload.get("id"),
        usage=_decode_usage_from_anthropic(payload.get("usage")),
        finish_reason=payload.get("stop_reason"),
    )


def _encode_anthropic_response(response: DecodedResponse) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "id": response.response_id or "converted-msg",
        "type": "message",
        "role": "assistant",
        "model": response.model or "unknown",
        "content": _encode_anthropic_content_blocks(response.message.parts, role=Role.assistant),
        "stop_reason": response.finish_reason or "end_turn",
    }
    if response.usage:
        payload["usage"] = {
            "input_tokens": response.usage.input_tokens,
            "output_tokens": response.usage.output_tokens,
            "cache_read_input_tokens": response.usage.cache_read_tokens,
            "cache_creation_input_tokens": response.usage.cache_write_tokens,
        }
    return payload


def _decode_anthropic_content(content: Any) -> list[Any]:
    if content is None:
        return []
    if isinstance(content, str):
        return [TextPart(text=content)] if content else []
    if not isinstance(content, list):
        return [TextPart(text=str(content))]

    parts: list[Any] = []
    for block in content:
        if not isinstance(block, dict):
            parts.append(TextPart(text=str(block)))
            continue

        block_type = block.get("type")
        if block_type == "text":
            parts.append(TextPart(text=str(block.get("text") or "")))
        elif block_type in {"thinking", "redacted_thinking"}:
            parts.append(
                ThinkingPart(
                    text=str(block.get("thinking") or block.get("text") or ""),
                    signature=block.get("signature"),
                )
            )
        elif block_type == "tool_use":
            parts.append(
                ToolCallPart(
                    id=str(block.get("id") or ""),
                    name=str(block.get("name") or ""),
                    arguments=block.get("input"),
                )
            )
        elif block_type == "tool_result":
            parts.append(
                ToolResultPart(
                    tool_call_id=str(block.get("tool_use_id") or ""),
                    output=_parse_tool_output(block.get("content")),
                    is_error=bool(block.get("is_error")),
                )
            )
        elif block_type == "image":
            source = block.get("source") or {}
            if source.get("type") == "base64":
                data_url = f"data:{source.get('media_type')};base64,{source.get('data')}"
                parts.append(
                    ImagePart(
                        asset=AssetRef(
                            kind="image",
                            source_type=AssetSourceType.data_url,
                            value=data_url,
                        )
                    )
                )
            elif source.get("url"):
                parts.append(
                    ImagePart(
                        asset=AssetRef(
                            kind="image",
                            source_type=AssetSourceType.url,
                            value=str(source["url"]),
                        )
                    )
                )
        elif block_type == "document":
            source = block.get("source") or {}
            if source.get("type") == "base64":
                data_url = f"data:{source.get('media_type')};base64,{source.get('data')}"
                parts.append(
                    DocumentPart(
                        asset=AssetRef(
                            kind="document",
                            source_type=AssetSourceType.data_url,
                            value=data_url,
                        )
                    )
                )
            elif source.get("url"):
                parts.append(
                    DocumentPart(
                        asset=AssetRef(
                            kind="document",
                            source_type=AssetSourceType.url,
                            value=str(source["url"]),
                        )
                    )
                )
        else:
            parts.append(TextPart(text=json_dumps(block)))
    return parts


def _encode_anthropic_message(message: Message) -> dict[str, Any]:
    return {
        "role": "assistant" if message.role == Role.assistant else "user",
        "content": _encode_anthropic_content_blocks(message.parts, role=message.role),
    }


def _encode_anthropic_content_blocks(parts: list[Any], *, role: Role) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    for part in parts:
        if isinstance(part, TextPart):
            blocks.append({"type": "text", "text": part.text})
        elif isinstance(part, ThinkingPart):
            block: dict[str, Any] = {"type": "thinking", "thinking": part.text}
            if part.signature:
                block["signature"] = part.signature
            blocks.append(block)
        elif isinstance(part, ToolCallPart):
            blocks.append(
                {
                    "type": "tool_use",
                    "id": part.id,
                    "name": part.name,
                    "input": _json_loads_or_keep(part.arguments_json),
                }
            )
        elif isinstance(part, ToolResultPart):
            blocks.append(
                {
                    "type": "tool_result",
                    "tool_use_id": part.tool_call_id,
                    "content": _stringify_output(part.output),
                    "is_error": part.is_error,
                }
            )
        elif isinstance(part, ImagePart):
            blocks.append(
                {
                    "type": "image",
                    "source": _anthropic_source_from_asset(part.asset),
                }
            )
        elif isinstance(part, DocumentPart):
            blocks.append(
                {
                    "type": "document",
                    "source": _anthropic_source_from_asset(part.asset),
                }
            )
        elif isinstance(part, (FilePart, AudioPart)):
            raise UnsupportedModalityError(
                "anthropic_messages encoding currently supports text, thinking, tool, image, and document parts only"
            )
    return blocks


def _decode_anthropic_tools(raw_tools: Any, *, exclude_structured_output: bool = False) -> list[ToolSpec]:
    if not isinstance(raw_tools, list):
        return []
    tools: list[ToolSpec] = []
    for raw_tool in raw_tools:
        if not isinstance(raw_tool, dict):
            continue
        if exclude_structured_output and _is_anthropic_structured_output_tool(raw_tool):
            continue
        name = raw_tool.get("name")
        if not name:
            continue
        tools.append(
            ToolSpec(
                function=FunctionToolSpec(
                    name=str(name),
                    description=raw_tool.get("description"),
                    parameters=raw_tool.get("input_schema")
                    or {"type": "object", "properties": {}},
                )
            )
        )
    return tools


def _encode_anthropic_tools(tools: list[ToolSpec]) -> list[dict[str, Any]]:
    return [
        {
            "name": tool.function.name,
            "description": tool.function.description or "",
            "input_schema": tool.function.parameters,
        }
        for tool in tools
    ]


def _encode_anthropic_structured_output_tool(
    spec: StructuredOutputSpec | None,
    *,
    used_names: set[str],
) -> dict[str, Any] | None:
    if spec is None:
        return None

    tool_name = _unique_structured_output_tool_name(used_names)
    schema = _schema_to_json_schema(spec.schema_)
    if spec.method == StructuredOutputMethod.json_mode and not schema:
        schema = {"type": "object", "properties": {}, "additionalProperties": True}

    return {
        "name": tool_name,
        "description": _STRUCTURED_OUTPUT_TOOL_DESCRIPTION,
        "input_schema": schema or {"type": "object", "properties": {}},
    }


def _unique_structured_output_tool_name(used_names: set[str]) -> str:
    if _STRUCTURED_OUTPUT_TOOL_NAME not in used_names:
        return _STRUCTURED_OUTPUT_TOOL_NAME
    index = 2
    while f"{_STRUCTURED_OUTPUT_TOOL_NAME}_{index}" in used_names:
        index += 1
    return f"{_STRUCTURED_OUTPUT_TOOL_NAME}_{index}"


def _decode_anthropic_response_spec(raw_tools: Any, tool_choice: Any) -> StructuredOutputSpec | None:
    if not isinstance(raw_tools, list):
        return None
    chosen_name = _anthropic_tool_choice_name(tool_choice)
    for raw_tool in raw_tools:
        if not isinstance(raw_tool, dict):
            continue
        if not _is_anthropic_structured_output_tool(raw_tool):
            continue
        if chosen_name is not None and raw_tool.get("name") != chosen_name:
            continue
        return StructuredOutputSpec(
            schema=raw_tool.get("input_schema") or {"type": "object", "properties": {}},
            method=StructuredOutputMethod.function_calling,
        )
    return None


def _is_anthropic_structured_output_tool(raw_tool: dict[str, Any]) -> bool:
    return (
        str(raw_tool.get("name") or "").startswith(_STRUCTURED_OUTPUT_TOOL_NAME)
        and raw_tool.get("description") == _STRUCTURED_OUTPUT_TOOL_DESCRIPTION
    )


def _anthropic_tool_choice_name(tool_choice: Any) -> str | None:
    if not isinstance(tool_choice, dict):
        return None
    if tool_choice.get("type") not in {"tool", "function"}:
        return None
    name = tool_choice.get("name")
    if not name and isinstance(tool_choice.get("function"), dict):
        name = tool_choice["function"].get("name")
    return str(name) if name else None


def _is_structured_output_tool_choice(tool_choice: Any, response: StructuredOutputSpec | None) -> bool:
    if response is None:
        return False
    name = _anthropic_tool_choice_name(tool_choice)
    return name is not None and name.startswith(_STRUCTURED_OUTPUT_TOOL_NAME)


def _decode_usage_from_anthropic(raw_usage: Any) -> Usage | None:
    if not isinstance(raw_usage, dict):
        return None
    input_tokens = int(raw_usage.get("input_tokens") or 0)
    output_tokens = int(raw_usage.get("output_tokens") or 0)
    return Usage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cache_read_tokens=int(raw_usage.get("cache_read_input_tokens") or 0),
        cache_write_tokens=int(raw_usage.get("cache_creation_input_tokens") or 0),
        total_tokens=input_tokens + output_tokens,
    )


def _encode_anthropic_tool_choice(value: Any) -> Any:
    if isinstance(value, str):
        mapping = {
            "auto": {"type": "auto"},
            "none": {"type": "none"},
            "required": {"type": "any"},
        }
        return mapping.get(value, {"type": "tool", "name": value})
    if isinstance(value, dict):
        choice_type = value.get("type")
        if choice_type in {"auto", "none", "any"}:
            return {"type": choice_type}
        if choice_type in {"function", "tool"}:
            name = value.get("name")
            if not name and isinstance(value.get("function"), dict):
                name = value["function"].get("name")
            if name:
                return {"type": "tool", "name": str(name)}
            return {"type": "any"}
    return value


def _decode_anthropic_tool_choice(value: Any) -> Any:
    if isinstance(value, str):
        mapping = {
            "auto": "auto",
            "none": "none",
            "any": "required",
            "required": "required",
        }
        return mapping.get(value, value)
    if isinstance(value, dict):
        choice_type = value.get("type")
        if choice_type == "auto":
            return "auto"
        if choice_type == "none":
            return "none"
        if choice_type == "any":
            return "required"
        if choice_type in {"tool", "function"}:
            name = value.get("name")
            if not name and isinstance(value.get("function"), dict):
                name = value["function"].get("name")
            if name:
                return {"type": "function", "function": {"name": str(name)}}
            return "required"
    return value


def _decode_anthropic_reasoning(thinking: Any) -> ReasoningOptions | None:
    if not isinstance(thinking, dict):
        return None
    thinking_type = thinking.get("type")
    enabled = None
    return_thinking = False
    if thinking_type == "disabled":
        enabled = False
    elif thinking_type == "enabled" or thinking.get("budget_tokens") is not None:
        enabled = True
        return_thinking = True
    budget_tokens = thinking.get("budget_tokens")
    if enabled is None and budget_tokens is None:
        return None
    return ReasoningOptions(
        enabled=enabled,
        budget_tokens=budget_tokens,
        return_thinking=return_thinking,
    )


def _anthropic_system_to_text(system: Any) -> str:
    if isinstance(system, str):
        return system
    if isinstance(system, list):
        return "".join(
            str(part.get("text") or "")
            for part in system
            if isinstance(part, dict) and part.get("type") == "text"
        )
    return str(system)


def _anthropic_source_from_asset(asset: AssetRef) -> dict[str, Any]:
    if asset.source_type == "url":
        return {"type": "url", "url": asset.value}
    if asset.source_type == "data_url":
        prefix, _, data = asset.value.partition(",")
        media_type = prefix.removeprefix("data:").removesuffix(";base64")
        return {
            "type": "base64",
            "media_type": media_type,
            "data": data,
        }
    raise UnsupportedModalityError(
        f"anthropic_messages does not directly encode asset source_type={asset.source_type}"
    )
