"""Public SDK surface."""

from __future__ import annotations

import asyncio
import re
import time
from typing import Any, AsyncIterator, Awaitable, Callable, Literal, Protocol, TypeVar, runtime_checkable

import httpx
from pydantic import Field, TypeAdapter

from ._base import CoreModel
from ._identity import json_fingerprintable, stable_id
from .analysis import (
    CapabilityRegistry,
    CompiledRequest,
    InspectionReport,
    LossReport,
    ModelRequest,
    PreprocessingStep,
    ProviderRoute,
    compile_request,
    inspect_request,
)
from .canonical import Message, StreamEvent, ToolSpec, Usage, msg
from .convert import RequestConversionBuilder, _decode_response
from .errors import ProtocolError, ProviderHTTPError, StructuredParseError, TransportError, TransportNotConfiguredError
from .families import ApiFamily
from ._json import json_dumps, json_loads
from .options import (
    CachePolicy,
    CallOptions,
    ReasoningOptions,
    StreamOptions,
    StructuredOutputMethod,
    StructuredOutputSpec,
)
from .transport import ainvoke_http, astream_http, invoke_http, stream_http

T = TypeVar("T")
SyncExecutor = Callable[[list[Message], CallOptions, CompiledRequest], Message]
AsyncExecutor = Callable[[list[Message], CallOptions, CompiledRequest], Awaitable[Message]]
SyncStreamExecutor = Callable[[list[Message], CallOptions, CompiledRequest], Any]
AsyncStreamExecutor = Callable[[list[Message], CallOptions, CompiledRequest], Any]
Observer = Callable[[str, dict[str, Any]], None]


@runtime_checkable
class ProviderAdapter(Protocol):
    """Transport adapter boundary for gateway/runtime integrations."""

    def route(self, request: ModelRequest) -> ProviderRoute: ...

    async def generate(self, request: ModelRequest) -> Message: ...

    async def stream(self, request: ModelRequest) -> AsyncIterator[StreamEvent]: ...


class StructuredOutputResult(CoreModel):
    parsed: Any
    raw: Message


class BatchItem(CoreModel):
    messages: list[Message]
    options: CallOptions | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class BatchOptions(CoreModel):
    provider_native: bool = False
    poll: bool = True
    max_concurrency: int | None = None
    stop_on_error: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class BatchResult(CoreModel):
    index: int
    message: Message | None = None
    error: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.error is None


class BatchHandle(CoreModel):
    id: str
    status: Literal["submitted", "running", "completed", "failed"]
    results: list[BatchResult] = Field(default_factory=list)
    provider_native: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class BatchRequestItem(CoreModel):
    custom_id: str
    messages: list[Message]
    options: CallOptions
    route: ProviderRoute
    payload: dict[str, Any]
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_provider_request(self) -> dict[str, Any]:
        return {
            "custom_id": self.custom_id,
            "method": "POST",
            "url": _batch_endpoint_path(self.route.api_family, model=self.options.model),
            "body": self.payload,
        }


class BatchManifest(CoreModel):
    id: str
    items: list[BatchRequestItem] = Field(default_factory=list)
    provider_native: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_jsonl(self) -> str:
        return "\n".join(json_dumps(item.to_provider_request()) for item in self.items)


ProviderBatchExecutor = Callable[[BatchManifest, BatchOptions], BatchHandle]
AsyncProviderBatchExecutor = Callable[[BatchManifest, BatchOptions], Awaitable[BatchHandle]]


class RequestSnapshot(CoreModel):
    manifest_schema: Literal["aury.model.core.snapshot.v1"] = Field(
        default="aury.model.core.snapshot.v1",
        alias="schema",
        serialization_alias="schema",
    )
    id: str
    messages: list[Message]
    options: CallOptions
    route: ProviderRoute
    payload: dict[str, Any]
    loss_report: LossReport
    required_preprocessing: list[PreprocessingStep] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    usage: Usage | None = None
    stream_timeline: list[StreamEvent] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_manifest(self, *, include_secrets: bool = False) -> dict[str, Any]:
        manifest = json_fingerprintable(self.model_dump(mode="python", by_alias=True))
        if not include_secrets:
            _redact_manifest_secrets(manifest)
        return manifest

    @classmethod
    def from_manifest(cls, manifest: dict[str, Any] | str | bytes | bytearray | memoryview) -> RequestSnapshot:
        raw_manifest = json_loads(manifest) if isinstance(manifest, (str, bytes, bytearray, memoryview)) else manifest
        return cls.model_validate(raw_manifest)


class ReplayResult(CoreModel):
    id: str
    snapshot_id: str
    message: Message
    request_snapshot: RequestSnapshot
    metadata: dict[str, Any] = Field(default_factory=dict)


class StructuredModelClient:
    """Thin structured-output wrapper over ModelClient."""

    def __init__(
        self,
        client: ModelClient,
        schema: Any,
        *,
        method: StructuredOutputMethod = StructuredOutputMethod.auto,
        strict: bool | None = None,
        include_raw: bool = False,
    ) -> None:
        self._client = client
        self._spec = StructuredOutputSpec(
            schema=schema,
            method=method,
            strict=strict,
            include_raw=include_raw,
        )

    def invoke(
        self,
        messages: list[Message],
        *,
        options: CallOptions | None = None,
    ) -> Any:
        message = self._client.invoke(messages, options=self._merge_options(options))
        return self._parse(message)

    async def ainvoke(
        self,
        messages: list[Message],
        *,
        options: CallOptions | None = None,
    ) -> Any:
        message = await self._client.ainvoke(messages, options=self._merge_options(options))
        return self._parse(message)

    def ask(
        self,
        text: str,
        *,
        options: CallOptions | None = None,
    ) -> Any:
        return self.invoke([msg.user(text)], options=options)

    async def aask(
        self,
        text: str,
        *,
        options: CallOptions | None = None,
    ) -> Any:
        return await self.ainvoke([msg.user(text)], options=options)

    def _merge_options(self, options: CallOptions | None) -> CallOptions:
        base = options or CallOptions()
        return base.merge(CallOptions(response=self._spec))

    def _parse(self, message: Message) -> Any:
        adapter = TypeAdapter(self._spec.schema_)
        last_error: Exception | None = None

        for candidate in _structured_candidates_from_message(message, self._spec.method):
            try:
                if isinstance(candidate, str):
                    parsed = adapter.validate_python(json_loads(candidate))
                else:
                    parsed = adapter.validate_python(candidate)
                if self._spec.include_raw:
                    return StructuredOutputResult(parsed=parsed, raw=message)
                return parsed
            except Exception as exc:
                last_error = exc
        raise StructuredParseError(f"structured parse failed: {last_error or 'no JSON candidate found'}")


class ModelClient(CoreModel):
    provider: str | None = None
    model: str | None = None
    base_url: str | None = None
    api_key: str | None = None
    headers: dict[str, str] = Field(default_factory=dict)

    api_family: ApiFamily | None = None
    dialect: str | None = None

    default_tools: list[ToolSpec] | None = None
    default_tool_choice: str | dict[str, Any] | None = None
    default_reasoning: ReasoningOptions | None = None
    default_response: StructuredOutputSpec | None = None
    default_caching: CachePolicy | None = None
    default_stream: StreamOptions | None = None

    metadata: dict[str, Any] = Field(default_factory=dict)
    extra_body: dict[str, Any] | None = None
    native: dict[str, Any] | None = None

    timeout: float | None = None
    max_retries: int | None = None
    enable_http_transport: bool = False
    http_transport: Any | None = Field(default=None, exclude=True, repr=False)

    executor: SyncExecutor | None = Field(default=None, exclude=True, repr=False)
    async_executor: AsyncExecutor | None = Field(default=None, exclude=True, repr=False)
    stream_executor: SyncStreamExecutor | None = Field(default=None, exclude=True, repr=False)
    astream_executor: AsyncStreamExecutor | None = Field(default=None, exclude=True, repr=False)
    batch_executor: ProviderBatchExecutor | None = Field(default=None, exclude=True, repr=False)
    async_batch_executor: AsyncProviderBatchExecutor | None = Field(default=None, exclude=True, repr=False)
    observers: list[Observer] = Field(default_factory=list, exclude=True, repr=False)
    registry: CapabilityRegistry = Field(
        default_factory=CapabilityRegistry.builtin,
        exclude=True,
        repr=False,
    )

    def with_options(self, **updates: Any) -> ModelClient:
        return self.model_copy(update=updates)

    def with_retry(self, *, max_attempts: int = 3, **_: Any) -> ModelClient:
        return self.with_options(max_retries=max_attempts)

    def with_family(self, family: ApiFamily) -> ModelClient:
        return self.with_options(api_family=family)

    def with_tools(self, tools: list[ToolSpec]) -> ModelClient:
        return self.with_options(default_tools=tools)

    def with_reasoning(self, effort: str | ReasoningOptions) -> ModelClient:
        reasoning = effort if isinstance(effort, ReasoningOptions) else ReasoningOptions(effort=effort)
        return self.with_options(default_reasoning=reasoning)

    def with_observer(self, observer: Observer) -> ModelClient:
        return self.with_options(observers=[*self.observers, observer])

    def with_structured_output(
        self,
        schema: Any,
        *,
        method: StructuredOutputMethod = StructuredOutputMethod.auto,
        strict: bool | None = None,
        include_raw: bool = False,
    ) -> StructuredModelClient:
        return StructuredModelClient(
            self,
            schema,
            method=method,
            strict=strict,
            include_raw=include_raw,
        )

    def json(
        self,
        schema: Any,
        *,
        method: StructuredOutputMethod = StructuredOutputMethod.auto,
        strict: bool | None = None,
        include_raw: bool = False,
    ) -> StructuredModelClient:
        return self.with_structured_output(
            schema,
            method=method,
            strict=strict,
            include_raw=include_raw,
        )

    def chat(
        self,
        text: str,
        *,
        options: CallOptions | None = None,
    ) -> Message:
        return self.invoke([msg.user(text)], options=options)

    async def achat(
        self,
        text: str,
        *,
        options: CallOptions | None = None,
    ) -> Message:
        return await self.ainvoke([msg.user(text)], options=options)

    def inspect(
        self,
        messages: list[Message],
        options: CallOptions | None = None,
    ):
        merged_options = self._materialize_options(options)
        return inspect_request(messages, merged_options, registry=self.registry)

    def compile(
        self,
        messages: list[Message],
        options: CallOptions | None = None,
    ) -> CompiledRequest:
        merged_options = self._materialize_options(options)
        return compile_request(messages, merged_options, registry=self.registry)

    def explain(
        self,
        messages: list[Message],
        options: CallOptions | None = None,
    ) -> str:
        return _format_explanation(self.inspect(messages, options).report())

    def invoke(
        self,
        messages: list[Message],
        *,
        options: CallOptions | None = None,
    ) -> Message:
        compiled = self.compile(messages, options)
        return self._run_sync_with_retry(compiled, lambda attempt: self._invoke_once(compiled, attempt=attempt))

    def _invoke_once(self, compiled: CompiledRequest, *, attempt: int = 1) -> Message:
        if self.executor is not None:
            return self.executor(compiled.messages, compiled.options, compiled)
        if self.async_executor is not None:
            try:
                asyncio.get_running_loop()
            except RuntimeError:
                return asyncio.run(self.async_executor(compiled.messages, compiled.options, compiled))
            raise TransportNotConfiguredError(
                "invoke() cannot use async_executor while an event loop is already running."
            )
        if self._has_custom_executor():
            raise TransportNotConfiguredError(
                "invoke() requires executor or async_executor when custom executors are configured."
            )
        if self.enable_http_transport:
            return invoke_http(
                compiled,
                transport=self.http_transport,
                observer=self._transport_observer(compiled, attempt=attempt),
            )
        raise TransportNotConfiguredError(
            "invoke() requires executor or async_executor. Set enable_http_transport=True to use the built-in HTTP transport."
        )

    async def ainvoke(
        self,
        messages: list[Message],
        *,
        options: CallOptions | None = None,
    ) -> Message:
        compiled = self.compile(messages, options)
        return await self._run_async_with_retry(
            compiled,
            lambda attempt: self._ainvoke_once(compiled, attempt=attempt),
        )

    async def _ainvoke_once(self, compiled: CompiledRequest, *, attempt: int = 1) -> Message:
        if self.async_executor is not None:
            return await self.async_executor(compiled.messages, compiled.options, compiled)
        if self.executor is not None:
            return self.executor(compiled.messages, compiled.options, compiled)
        if self._has_custom_executor():
            raise TransportNotConfiguredError(
                "ainvoke() requires async_executor or executor when custom executors are configured."
            )
        if self.enable_http_transport:
            return await ainvoke_http(
                compiled,
                transport=self.http_transport,
                observer=self._transport_observer(compiled, attempt=attempt),
            )
        raise TransportNotConfiguredError(
            "ainvoke() requires async_executor or executor. Set enable_http_transport=True to use the built-in HTTP transport."
        )

    def stream(
        self,
        messages: list[Message],
        *,
        options: CallOptions | None = None,
    ):
        compiled = self.compile(messages, options)
        if self.stream_executor is not None:
            return self._observe_stream(
                self.stream_executor(compiled.messages, compiled.options, compiled),
                compiled,
            )
        if self._has_custom_executor():
            raise TransportNotConfiguredError(
                "stream() requires stream_executor when custom executors are configured."
            )
        if self.enable_http_transport:
            return self._observe_stream(
                stream_http(
                    compiled,
                    transport=self.http_transport,
                    observer=self._transport_observer(compiled, attempt=1),
                ),
                compiled,
            )
        raise TransportNotConfiguredError(
            "stream() requires stream_executor. Set enable_http_transport=True to use the built-in HTTP transport."
        )

    async def astream(
        self,
        messages: list[Message],
        *,
        options: CallOptions | None = None,
    ):
        compiled = self.compile(messages, options)
        if self.astream_executor is not None:
            async for event in self._observe_astream(
                _coerce_async_stream(self.astream_executor(compiled.messages, compiled.options, compiled)),
                compiled,
            ):
                yield event
            return
        if self._has_custom_executor():
            raise TransportNotConfiguredError(
                "astream() requires astream_executor when custom executors are configured."
            )
        if self.enable_http_transport:
            async for event in self._observe_astream(
                astream_http(
                    compiled,
                    transport=self.http_transport,
                    observer=self._transport_observer(compiled, attempt=1),
                ),
                compiled,
            ):
                yield event
            return
        raise TransportNotConfiguredError(
            "astream() requires astream_executor. Set enable_http_transport=True to use the built-in HTTP transport."
        )

    def convert_request(
        self,
        payload: Any,
        *,
        source_family: ApiFamily | None = None,
    ) -> RequestConversionBuilder:
        return RequestConversionBuilder(payload, source_family=source_family)

    def submit_batch(
        self,
        items: list[BatchItem],
        *,
        options: BatchOptions | None = None,
    ) -> BatchHandle:
        batch_options = options or BatchOptions()
        if batch_options.provider_native:
            manifest = self.compile_batch(items, options=batch_options)
            if self.batch_executor is not None:
                return self.batch_executor(manifest, batch_options)
            if self.async_batch_executor is not None:
                try:
                    asyncio.get_running_loop()
                except RuntimeError:
                    return asyncio.run(self.async_batch_executor(manifest, batch_options))
                raise TransportNotConfiguredError(
                    "submit_batch() cannot use async_batch_executor while an event loop is already running."
                )
            if self.enable_http_transport:
                return _submit_provider_batch_http(
                    manifest,
                    batch_options,
                    transport=self.http_transport,
                )
            raise TransportNotConfiguredError(
                "submit_batch(..., provider_native=True) requires batch_executor, async_batch_executor, or enable_http_transport=True for a supported built-in batch provider."
            )

        results: list[BatchResult] = []
        for index, item in enumerate(items):
            try:
                results.append(
                    BatchResult(
                        index=index,
                        message=self.invoke(item.messages, options=item.options),
                        metadata=item.metadata,
                    )
                )
            except Exception as exc:
                results.append(BatchResult(index=index, error=str(exc), metadata=item.metadata))
                if batch_options.stop_on_error:
                    break

        return _batch_handle(items, batch_options, results)

    def compile_batch(
        self,
        items: list[BatchItem],
        *,
        options: BatchOptions | None = None,
    ) -> BatchManifest:
        batch_options = options or BatchOptions()
        compiled_items: list[BatchRequestItem] = []
        for index, item in enumerate(items):
            compiled = self.compile(item.messages, item.options)
            custom_id = str(item.metadata.get("custom_id") or f"item_{index}")
            compiled_items.append(
                BatchRequestItem(
                    custom_id=custom_id,
                    messages=compiled.messages,
                    options=compiled.options,
                    route=compiled.route,
                    payload=compiled.payload,
                    metadata=item.metadata,
                )
            )
        return BatchManifest(
            id=_stable_id(
                "batch_manifest",
                {
                    "items": [item.model_dump(mode="json") for item in compiled_items],
                    "provider_native": batch_options.provider_native,
                    "metadata": batch_options.metadata,
                },
            ),
            items=compiled_items,
            provider_native=batch_options.provider_native,
            metadata=batch_options.metadata,
        )

    async def asubmit_batch(
        self,
        items: list[BatchItem],
        *,
        options: BatchOptions | None = None,
    ) -> BatchHandle:
        batch_options = options or BatchOptions()
        if batch_options.provider_native:
            manifest = self.compile_batch(items, options=batch_options)
            if self.async_batch_executor is not None:
                return await self.async_batch_executor(manifest, batch_options)
            if self.batch_executor is not None:
                return self.batch_executor(manifest, batch_options)
            if self.enable_http_transport:
                return await _asubmit_provider_batch_http(
                    manifest,
                    batch_options,
                    transport=self.http_transport,
                )
            raise TransportNotConfiguredError(
                "asubmit_batch(..., provider_native=True) requires async_batch_executor, batch_executor, or enable_http_transport=True for a supported built-in batch provider."
            )

        semaphore = asyncio.Semaphore(batch_options.max_concurrency or len(items) or 1)

        async def run_item(index: int, item: BatchItem) -> BatchResult:
            async with semaphore:
                try:
                    return BatchResult(
                        index=index,
                        message=await self.ainvoke(item.messages, options=item.options),
                        metadata=item.metadata,
                    )
                except Exception as exc:
                    return BatchResult(index=index, error=str(exc), metadata=item.metadata)

        results: list[BatchResult] = []
        if batch_options.stop_on_error:
            for index, item in enumerate(items):
                result = await run_item(index, item)
                results.append(result)
                if not result.ok:
                    break
        else:
            results = list(await asyncio.gather(*(run_item(index, item) for index, item in enumerate(items))))

        return _batch_handle(items, batch_options, results)

    def snapshot(
        self,
        messages: list[Message],
        options: CallOptions | None = None,
        *,
        stream_timeline: list[StreamEvent] | None = None,
        usage: Usage | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> RequestSnapshot:
        compiled = self.compile(messages, options)
        snapshot_metadata = metadata or {}
        payload = compiled.payload
        return RequestSnapshot(
            id=_stable_id(
                "snapshot",
                {
                    "messages": [message.model_dump(mode="json") for message in compiled.messages],
                    "options": compiled.options.model_dump(mode="python"),
                    "route": compiled.route.model_dump(mode="json"),
                    "payload": payload,
                    "metadata": snapshot_metadata,
                },
            ),
            messages=compiled.messages,
            options=compiled.options,
            route=compiled.route,
            payload=payload,
            loss_report=compiled.compatibility.loss_report,
            required_preprocessing=compiled.compatibility.required_preprocessing,
            warnings=compiled.warnings,
            usage=usage,
            stream_timeline=stream_timeline or [],
            metadata=snapshot_metadata,
        )

    def replay(
        self,
        snapshot: RequestSnapshot | dict[str, Any] | str | bytes | bytearray | memoryview,
        *,
        options: CallOptions | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ReplayResult:
        request_snapshot = _coerce_snapshot(snapshot)
        replay_options = request_snapshot.options.merge(options)
        message = self.invoke(request_snapshot.messages, options=replay_options)
        return _replay_result(request_snapshot, message, metadata or {})

    async def areplay(
        self,
        snapshot: RequestSnapshot | dict[str, Any] | str | bytes | bytearray | memoryview,
        *,
        options: CallOptions | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ReplayResult:
        request_snapshot = _coerce_snapshot(snapshot)
        replay_options = request_snapshot.options.merge(options)
        message = await self.ainvoke(request_snapshot.messages, options=replay_options)
        return _replay_result(request_snapshot, message, metadata or {})

    def _materialize_options(self, options: CallOptions | None) -> CallOptions:
        defaults = CallOptions(
            provider=self.provider,
            model=self.model,
            base_url=self.base_url,
            api_key=self.api_key,
            headers=self.headers,
            api_family=self.api_family,
            dialect=self.dialect,
            tools=self.default_tools,
            tool_choice=self.default_tool_choice,
            reasoning=self.default_reasoning,
            response=self.default_response,
            caching=self.default_caching,
            stream=self.default_stream,
            metadata=self.metadata,
            extra_body=self.extra_body,
            native=self.native,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        return defaults.merge(options)

    def _has_custom_executor(self) -> bool:
        return any(
            executor is not None
            for executor in (
                self.executor,
                self.async_executor,
                self.stream_executor,
                self.astream_executor,
            )
        )

    def _run_sync_with_retry(self, compiled: CompiledRequest, operation: Callable[[int], Message]) -> Message:
        max_attempts = _max_attempts(compiled.options)
        for attempt in range(1, max_attempts + 1):
            self._emit_attempt_start(compiled, attempt=attempt)
            try:
                result = operation(attempt)
                self._emit_observer("on_finish", compiled, attempt=attempt)
                return result
            except Exception as exc:
                self._emit_observer("on_error", compiled, attempt=attempt, error=exc)
                if attempt >= max_attempts or not _is_retryable_exception(exc):
                    raise
                self._emit_observer("on_retry", compiled, attempt=attempt, error=exc)
        raise RuntimeError("unreachable retry state")

    async def _run_async_with_retry(
        self,
        compiled: CompiledRequest,
        operation: Callable[[int], Awaitable[Message]],
    ) -> Message:
        max_attempts = _max_attempts(compiled.options)
        for attempt in range(1, max_attempts + 1):
            self._emit_attempt_start(compiled, attempt=attempt)
            try:
                result = await operation(attempt)
                self._emit_observer("on_finish", compiled, attempt=attempt)
                return result
            except Exception as exc:
                self._emit_observer("on_error", compiled, attempt=attempt, error=exc)
                if attempt >= max_attempts or not _is_retryable_exception(exc):
                    raise
                self._emit_observer("on_retry", compiled, attempt=attempt, error=exc)
        raise RuntimeError("unreachable retry state")

    def _observe_stream(self, source: Any, compiled: CompiledRequest):
        self._emit_attempt_start(compiled, attempt=1)
        try:
            for event in source:
                frame_payload = _stream_frame_payload(event)
                if frame_payload is not None:
                    self._emit_observer(
                        "on_stream_frame",
                        compiled,
                        attempt=1,
                        extra=frame_payload,
                    )
                self._emit_observer(
                    "on_stream_event",
                    compiled,
                    attempt=1,
                    extra={"event_type": event.type.value},
                )
                if event.usage is not None:
                    self._emit_observer(
                        "on_usage",
                        compiled,
                        attempt=1,
                        extra={"usage": event.usage.model_dump(mode="json")},
                    )
                yield event
            self._emit_observer("on_finish", compiled, attempt=1)
        except Exception as exc:
            self._emit_observer("on_error", compiled, attempt=1, error=exc)
            raise

    async def _observe_astream(self, source: Any, compiled: CompiledRequest):
        self._emit_attempt_start(compiled, attempt=1)
        try:
            async for event in source:
                frame_payload = _stream_frame_payload(event)
                if frame_payload is not None:
                    self._emit_observer(
                        "on_stream_frame",
                        compiled,
                        attempt=1,
                        extra=frame_payload,
                    )
                self._emit_observer(
                    "on_stream_event",
                    compiled,
                    attempt=1,
                    extra={"event_type": event.type.value},
                )
                if event.usage is not None:
                    self._emit_observer(
                        "on_usage",
                        compiled,
                        attempt=1,
                        extra={"usage": event.usage.model_dump(mode="json")},
                    )
                yield event
            self._emit_observer("on_finish", compiled, attempt=1)
        except Exception as exc:
            self._emit_observer("on_error", compiled, attempt=1, error=exc)
            raise

    def _emit_attempt_start(self, compiled: CompiledRequest, *, attempt: int) -> None:
        self._emit_observer("on_request_start", compiled, attempt=attempt)
        self._emit_observer("on_route_selected", compiled, attempt=attempt)
        self._emit_observer(
            "on_request_encoded",
            compiled,
            attempt=attempt,
            extra={"payload_keys": sorted(compiled.payload.keys())},
        )
        self._emit_observer(
            "on_cache",
            compiled,
            attempt=attempt,
            extra={"cache_key": compiled.cache_key.key},
        )

    def _transport_observer(
        self,
        compiled: CompiledRequest,
        *,
        attempt: int,
    ) -> Callable[[str, dict[str, Any]], None] | None:
        if not self.observers:
            return None

        def observe(event_name: str, payload: dict[str, Any]) -> None:
            self._emit_observer(event_name, compiled, attempt=attempt, extra=payload)

        return observe

    def _emit_observer(
        self,
        event_name: str,
        compiled: CompiledRequest,
        *,
        attempt: int,
        error: Exception | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        if not self.observers:
            return
        request_id = _request_id(compiled)
        payload = {
            "trace_id": str(compiled.options.metadata.get("trace_id") or request_id),
            "request_id": request_id,
            "provider": compiled.route.provider,
            "model": compiled.route.model,
            "api_family": compiled.route.api_family.value,
            "dialect": compiled.route.dialect,
            "cache_namespace": compiled.route.cache_namespace,
            "cache_key": compiled.cache_key.key,
            "attempt": attempt,
        }
        if error is not None:
            payload["error"] = str(error)
            payload["error_type"] = type(error).__name__
        if extra:
            payload.update(extra)
        for observer in self.observers:
            observer(event_name, dict(payload))


def _structured_candidates(text: str) -> list[str]:
    candidates = [text]
    fenced = re.findall(r"```(?:json)?\s*([\s\S]*?)\s*```", text)
    candidates.extend(candidate for candidate in fenced if candidate.strip())
    brace_match = re.search(r"(\{[\s\S]*\}|\[[\s\S]*\])", text)
    if brace_match:
        candidates.append(brace_match.group(1))
    deduped: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        normalized = candidate.strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        deduped.append(normalized)
    return deduped


def _structured_candidates_from_message(
    message: Message,
    method: StructuredOutputMethod,
) -> list[str | dict[str, Any] | list[Any]]:
    candidates: list[str | dict[str, Any] | list[Any]] = []
    if method == StructuredOutputMethod.function_calling:
        candidates.extend(_structured_tool_call_candidates(message))
        candidates.extend(_structured_candidates(message.text.strip()))
        return candidates

    candidates.extend(_structured_candidates(message.text.strip()))
    candidates.extend(_structured_tool_call_candidates(message))
    return candidates


def _structured_tool_call_candidates(message: Message) -> list[str | dict[str, Any] | list[Any]]:
    candidates: list[str | dict[str, Any] | list[Any]] = []
    for tool_call in message.tool_calls:
        arguments = tool_call.arguments
        if isinstance(arguments, str):
            normalized = arguments.strip()
            if normalized:
                candidates.append(normalized)
            continue
        if arguments is not None:
            candidates.append(arguments)
    return candidates


def _stream_frame_payload(event: StreamEvent) -> dict[str, Any] | None:
    if "raw_frame" not in event.metadata and "normalized_frame" not in event.metadata:
        return None
    return {
        "event_type": event.type.value,
        "raw_frame": event.metadata.get("raw_frame"),
        "normalized_frame": event.metadata.get("normalized_frame"),
    }


async def _coerce_async_stream(source: Any):
    if hasattr(source, "__aiter__"):
        async for event in source:
            yield event
        return
    if hasattr(source, "__await__"):
        resolved = await source
        if hasattr(resolved, "__aiter__"):
            async for event in resolved:
                yield event
            return
    raise TypeError("astream source must be an async iterator or resolve to one.")


def _max_attempts(options: CallOptions) -> int:
    return max(1, int(options.max_retries or 1))


def _is_retryable_exception(exc: Exception) -> bool:
    if isinstance(exc, ProviderHTTPError):
        return exc.status_code in {408, 409, 425, 429} or exc.status_code >= 500
    return isinstance(exc, TransportError)


def _batch_handle(
    items: list[BatchItem],
    options: BatchOptions,
    results: list[BatchResult],
) -> BatchHandle:
    return BatchHandle(
        id=_stable_id(
            "batch",
            {
                "items": [_batch_item_fingerprint(item) for item in items],
                "results": [result.model_dump(mode="json") for result in results],
                "metadata": options.metadata,
            },
        ),
        status="failed" if any(not result.ok for result in results) else "completed",
        results=results,
        metadata=options.metadata,
    )


def _batch_item_fingerprint(item: BatchItem) -> dict[str, Any]:
    return {
        "messages": [message.model_dump(mode="json") for message in item.messages],
        "options": item.options.model_dump(mode="json") if item.options is not None else None,
        "metadata": item.metadata,
    }


def _batch_endpoint_path(family: ApiFamily, *, model: str | None = None) -> str:
    if family == ApiFamily.openai_chat:
        return "/v1/chat/completions"
    if family == ApiFamily.openai_responses:
        return "/v1/responses"
    if family == ApiFamily.anthropic_messages:
        return "/v1/messages"
    if family == ApiFamily.google_genai:
        model_name = str(model or "{model}").strip()
        resource = model_name if model_name.startswith(("models/", "tunedModels/")) else f"models/{model_name}"
        return f"/v1beta/{resource}:generateContent"
    return f"/{family.value}"


def _submit_provider_batch_http(
    manifest: BatchManifest,
    options: BatchOptions,
    *,
    transport: Any | None = None,
) -> BatchHandle:
    context = _openai_batch_context(manifest)
    headers = _batch_http_headers(context["options"], include_content_type=False)
    base_url = context["base_url"]
    jsonl = manifest.to_jsonl()

    with httpx.Client(transport=transport, timeout=_timeout_from_metadata(options)) as client:
        upload = client.post(
            f"{base_url}/files",
            headers=headers,
            data={"purpose": "batch"},
            files={"file": ("batch.jsonl", jsonl, "application/jsonl")},
        )
        _raise_batch_http_error(upload)
        upload_body = _json_response(upload)
        input_file_id = _required_provider_id(upload_body, "file upload")

        create = client.post(
            f"{base_url}/batches",
            headers=_batch_http_headers(context["options"]),
            json=_batch_create_payload(input_file_id, context["endpoint"], options),
        )
        _raise_batch_http_error(create)
        batch_body = _json_response(create)

        if not options.poll:
            return _batch_handle_from_provider(manifest, options, batch_body, input_file_id=input_file_id)

        batch_body = _poll_batch_status(client, base_url, headers, batch_body, options)
        results = _download_batch_results(
            client,
            base_url,
            headers,
            manifest,
            batch_body,
        )
        return _batch_handle_from_provider(
            manifest,
            options,
            batch_body,
            input_file_id=input_file_id,
            results=results,
        )


async def _asubmit_provider_batch_http(
    manifest: BatchManifest,
    options: BatchOptions,
    *,
    transport: Any | None = None,
) -> BatchHandle:
    context = _openai_batch_context(manifest)
    headers = _batch_http_headers(context["options"], include_content_type=False)
    base_url = context["base_url"]
    jsonl = manifest.to_jsonl()

    async with httpx.AsyncClient(transport=transport, timeout=_timeout_from_metadata(options)) as client:
        upload = await client.post(
            f"{base_url}/files",
            headers=headers,
            data={"purpose": "batch"},
            files={"file": ("batch.jsonl", jsonl, "application/jsonl")},
        )
        _raise_batch_http_error(upload)
        upload_body = _json_response(upload)
        input_file_id = _required_provider_id(upload_body, "file upload")

        create = await client.post(
            f"{base_url}/batches",
            headers=_batch_http_headers(context["options"]),
            json=_batch_create_payload(input_file_id, context["endpoint"], options),
        )
        _raise_batch_http_error(create)
        batch_body = _json_response(create)

        if not options.poll:
            return _batch_handle_from_provider(manifest, options, batch_body, input_file_id=input_file_id)

        batch_body = await _apoll_batch_status(client, base_url, headers, batch_body, options)
        results = await _adownload_batch_results(
            client,
            base_url,
            headers,
            manifest,
            batch_body,
        )
        return _batch_handle_from_provider(
            manifest,
            options,
            batch_body,
            input_file_id=input_file_id,
            results=results,
        )


def _openai_batch_context(manifest: BatchManifest) -> dict[str, Any]:
    if not manifest.items:
        raise ProtocolError("provider-native batch requires at least one item.")
    endpoints = {item.to_provider_request()["url"] for item in manifest.items}
    if len(endpoints) != 1:
        raise ProtocolError("built-in provider-native batch requires all items to use the same endpoint.")
    endpoint = next(iter(endpoints))
    if endpoint not in {"/v1/chat/completions", "/v1/responses"}:
        raise TransportNotConfiguredError(
            f"built-in provider-native batch does not support endpoint {endpoint}; use batch_executor for this provider."
        )
    for item in manifest.items:
        if item.route.dialect:
            raise TransportNotConfiguredError(
                f"built-in provider-native batch does not support dialect {item.route.dialect}; use batch_executor."
            )
        if item.route.api_family not in {ApiFamily.openai_chat, ApiFamily.openai_responses}:
            raise TransportNotConfiguredError(
                f"built-in provider-native batch does not support {item.route.api_family.value}; use batch_executor."
            )
    options = manifest.items[0].options
    return {
        "endpoint": endpoint,
        "options": options,
        "base_url": _batch_base_url(options),
    }


def _batch_base_url(options: CallOptions) -> str:
    base_url = (options.base_url or "https://api.openai.com/v1").rstrip("/")
    for suffix in ("/chat/completions", "/responses", "/batches", "/files"):
        if base_url.endswith(suffix):
            return base_url[: -len(suffix)]
    return base_url


def _batch_http_headers(options: CallOptions, *, include_content_type: bool = True) -> dict[str, str]:
    headers = {
        key: value
        for key, value in options.headers.items()
        if key.lower() != "content-type"
    }
    if options.api_key and not any(key.lower() == "authorization" for key in headers):
        headers["authorization"] = f"Bearer {options.api_key}"
    headers.setdefault("accept", "application/json")
    if include_content_type:
        headers.setdefault("content-type", "application/json")
    return headers


def _batch_create_payload(input_file_id: str, endpoint: str, options: BatchOptions) -> dict[str, Any]:
    metadata = dict(options.metadata)
    completion_window = str(metadata.pop("completion_window", "24h"))
    for internal_key in ("poll_interval_seconds", "poll_timeout_seconds"):
        metadata.pop(internal_key, None)
    payload: dict[str, Any] = {
        "input_file_id": input_file_id,
        "endpoint": endpoint,
        "completion_window": completion_window,
    }
    if metadata:
        payload["metadata"] = {str(key): str(value) for key, value in metadata.items()}
    return payload


def _poll_batch_status(
    client: httpx.Client,
    base_url: str,
    headers: dict[str, str],
    batch_body: dict[str, Any],
    options: BatchOptions,
) -> dict[str, Any]:
    batch_id = _required_provider_id(batch_body, "batch")
    deadline = time.monotonic() + _poll_timeout_seconds(options)
    while True:
        response = client.get(f"{base_url}/batches/{batch_id}", headers=headers)
        _raise_batch_http_error(response)
        batch_body = _json_response(response)
        if _provider_batch_status(batch_body) in {"completed", "failed"}:
            return batch_body
        if time.monotonic() >= deadline:
            return batch_body
        time.sleep(_poll_interval_seconds(options))


async def _apoll_batch_status(
    client: httpx.AsyncClient,
    base_url: str,
    headers: dict[str, str],
    batch_body: dict[str, Any],
    options: BatchOptions,
) -> dict[str, Any]:
    batch_id = _required_provider_id(batch_body, "batch")
    deadline = time.monotonic() + _poll_timeout_seconds(options)
    while True:
        response = await client.get(f"{base_url}/batches/{batch_id}", headers=headers)
        _raise_batch_http_error(response)
        batch_body = _json_response(response)
        if _provider_batch_status(batch_body) in {"completed", "failed"}:
            return batch_body
        if time.monotonic() >= deadline:
            return batch_body
        await asyncio.sleep(_poll_interval_seconds(options))


def _poll_timeout_seconds(options: BatchOptions) -> float:
    value = options.metadata.get("poll_timeout_seconds", 0.0)
    return max(0.0, float(value or 0.0))


def _poll_interval_seconds(options: BatchOptions) -> float:
    value = options.metadata.get("poll_interval_seconds", 2.0)
    return max(0.05, float(value or 2.0))


def _timeout_from_metadata(options: BatchOptions) -> float:
    value = options.metadata.get("http_timeout_seconds", 60.0)
    return max(0.1, float(value or 60.0))


def _download_batch_results(
    client: httpx.Client,
    base_url: str,
    headers: dict[str, str],
    manifest: BatchManifest,
    batch_body: dict[str, Any],
) -> list[BatchResult]:
    output_file_id = batch_body.get("output_file_id")
    if not output_file_id or _provider_batch_status(batch_body) != "completed":
        return []
    response = client.get(f"{base_url}/files/{output_file_id}/content", headers=headers)
    _raise_batch_http_error(response)
    return _decode_batch_output_jsonl(response.text, manifest)


async def _adownload_batch_results(
    client: httpx.AsyncClient,
    base_url: str,
    headers: dict[str, str],
    manifest: BatchManifest,
    batch_body: dict[str, Any],
) -> list[BatchResult]:
    output_file_id = batch_body.get("output_file_id")
    if not output_file_id or _provider_batch_status(batch_body) != "completed":
        return []
    response = await client.get(f"{base_url}/files/{output_file_id}/content", headers=headers)
    _raise_batch_http_error(response)
    return _decode_batch_output_jsonl(response.text, manifest)


def _decode_batch_output_jsonl(text: str, manifest: BatchManifest) -> list[BatchResult]:
    items_by_custom_id = {item.custom_id: (index, item) for index, item in enumerate(manifest.items)}
    results: list[BatchResult] = []
    for line in text.splitlines():
        if not line.strip():
            continue
        raw = json_loads(line)
        if not isinstance(raw, dict):
            continue
        custom_id = str(raw.get("custom_id") or "")
        index, item = items_by_custom_id.get(custom_id, (len(results), None))
        metadata = {"custom_id": custom_id}
        if item is not None:
            metadata.update(item.metadata)
        error = raw.get("error")
        if error:
            results.append(BatchResult(index=index, error=_batch_line_error(error), metadata=metadata))
            continue
        response = raw.get("response") or {}
        if not isinstance(response, dict):
            results.append(BatchResult(index=index, error="missing response body", metadata=metadata))
            continue
        status_code = int(response.get("status_code") or 0)
        body = response.get("body")
        if status_code >= 400:
            results.append(BatchResult(index=index, error=_batch_line_error(body or response), metadata=metadata))
            continue
        if not isinstance(body, dict) or item is None:
            results.append(BatchResult(index=index, error="missing response body", metadata=metadata))
            continue
        decoded = _decode_response(body, item.route.api_family)
        results.append(BatchResult(index=index, message=decoded.message, metadata=metadata))
    return sorted(results, key=lambda result: result.index)


def _batch_line_error(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("message") or value.get("error") or value)
    return str(value)


def _batch_handle_from_provider(
    manifest: BatchManifest,
    options: BatchOptions,
    batch_body: dict[str, Any],
    *,
    input_file_id: str,
    results: list[BatchResult] | None = None,
) -> BatchHandle:
    metadata = {
        **options.metadata,
        "manifest_id": manifest.id,
        "input_file_id": input_file_id,
        "provider_status": str(batch_body.get("status") or ""),
        "provider_response": json_fingerprintable(batch_body),
    }
    for key in ("output_file_id", "error_file_id"):
        if batch_body.get(key):
            metadata[key] = str(batch_body[key])
    return BatchHandle(
        id=str(batch_body.get("id") or manifest.id),
        status=_provider_batch_status(batch_body),
        results=results or [],
        provider_native=True,
        metadata=metadata,
    )


def _provider_batch_status(batch_body: dict[str, Any]) -> Literal["submitted", "running", "completed", "failed"]:
    status = str(batch_body.get("status") or "").lower()
    if status == "completed":
        return "completed"
    if status in {"failed", "expired", "cancelled", "canceled"}:
        return "failed"
    if status in {"validating", "in_progress", "finalizing", "cancelling", "canceling"}:
        return "running"
    return "submitted"


def _json_response(response: httpx.Response) -> dict[str, Any]:
    try:
        body = json_loads(response.content)
    except Exception as exc:
        raise ProtocolError(f"Provider returned a non-JSON batch response: {exc}") from exc
    if not isinstance(body, dict):
        raise ProtocolError("Provider returned a non-dict batch response.")
    return body


def _required_provider_id(body: dict[str, Any], context: str) -> str:
    provider_id = body.get("id")
    if not provider_id:
        raise ProtocolError(f"Provider {context} response did not include an id.")
    return str(provider_id)


def _raise_batch_http_error(response: httpx.Response) -> None:
    if response.status_code < 400:
        return
    raise ProviderHTTPError(response.status_code, response.text, url=str(response.request.url))


def _stable_id(prefix: str, payload: dict[str, Any]) -> str:
    return stable_id(prefix, payload)


def _request_id(compiled: CompiledRequest) -> str:
    explicit = compiled.options.metadata.get("request_id")
    if explicit:
        return str(explicit)
    return _stable_id(
        "request",
        {
            "cache_key": compiled.cache_key.key,
            "messages": [message.model_dump(mode="json") for message in compiled.messages],
            "metadata": compiled.options.metadata,
            "route": compiled.route.model_dump(mode="json"),
        },
    )


def _coerce_snapshot(
    snapshot: RequestSnapshot | dict[str, Any] | str | bytes | bytearray | memoryview,
) -> RequestSnapshot:
    if isinstance(snapshot, RequestSnapshot):
        return snapshot
    return RequestSnapshot.from_manifest(snapshot)


def _replay_result(
    snapshot: RequestSnapshot,
    message: Message,
    metadata: dict[str, Any],
) -> ReplayResult:
    return ReplayResult(
        id=_stable_id(
            "replay",
            {
                "snapshot_id": snapshot.id,
                "message": message.model_dump(mode="json"),
                "metadata": metadata,
            },
        ),
        snapshot_id=snapshot.id,
        message=message,
        request_snapshot=snapshot,
        metadata=metadata,
    )


def _redact_manifest_secrets(manifest: dict[str, Any]) -> None:
    options = manifest.get("options")
    if not isinstance(options, dict):
        return
    if options.get("api_key"):
        options["api_key"] = None

    headers = options.get("headers")
    if isinstance(headers, dict):
        for key in list(headers):
            if _is_secret_header(key):
                headers[key] = "<redacted>"


def _is_secret_header(key: str) -> bool:
    normalized = key.lower()
    return normalized in {"authorization", "proxy-authorization", "x-api-key", "api-key"} or normalized.endswith(
        "-api-key"
    )


def _format_explanation(report: InspectionReport) -> str:
    lines = [
        "Model request explanation",
        f"- provider: {_explain_value(report.provider)}",
        f"- model: {_explain_value(report.model)}",
        f"- api_family: {report.chosen_api_family.value}",
        f"- dialect: {_explain_value(report.chosen_dialect)}",
        f"- route_reason: {report.route_reason}",
        f"- compatibility: {'ok' if report.compatibility_ok else 'not ok'}",
    ]

    cost = report.estimated_cost_shape
    lines.extend(
        [
            f"- estimated_input_tokens: {cost.estimated_input_tokens}",
            f"- estimated_output_tokens: {cost.estimated_output_tokens}",
            f"- estimated_total_tokens: {cost.estimated_total_tokens}",
            f"- estimated_tool_schema_tokens: {cost.estimated_tool_schema_tokens}",
            f"- estimated_response_schema_tokens: {cost.estimated_response_schema_tokens}",
            f"- estimated_reasoning_tokens: {cost.estimated_reasoning_tokens}",
            f"- modalities: {_explain_list(cost.modalities)}",
            f"- tool_calls: {cost.tool_calls}",
            f"- tool_results: {cost.tool_results}",
            f"- reasoning: {_explain_bool(cost.reasoning)}",
            f"- structured_output: {_explain_bool(cost.structured_output)}",
            f"- streaming: {_explain_bool(cost.streaming)}",
        ]
    )

    if report.loss_report.issues:
        lines.append("Loss issues:")
        for issue in report.loss_report.issues:
            location = f" at {issue.location}" if issue.location else ""
            lines.append(f"- [{issue.severity}] {issue.code}{location}: {issue.message}")
    else:
        lines.append("Loss issues: none")

    if report.required_preprocessing:
        lines.append("Required preprocessing:")
        for step in report.required_preprocessing:
            asset = f" ({step.asset.kind}:{step.asset.source_type})" if step.asset else ""
            lines.append(f"- {step.kind}{asset}: {step.reason}")
    else:
        lines.append("Required preprocessing: none")

    if report.warnings:
        lines.append("Warnings:")
        lines.extend(f"- {warning}" for warning in report.warnings)
    else:
        lines.append("Warnings: none")

    return "\n".join(lines)


def _explain_value(value: Any) -> str:
    if value is None or value == "":
        return "none"
    return str(value)


def _explain_list(values: list[Any]) -> str:
    return ", ".join(str(value) for value in values) if values else "none"


def _explain_bool(value: bool) -> str:
    return "yes" if value else "no"
