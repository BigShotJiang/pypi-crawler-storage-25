"""Shared OpenAI codec helpers."""

from __future__ import annotations

from typing import Any

from .canonical import FunctionToolSpec, ToolSpec, Usage
from .options import StructuredOutputMethod, StructuredOutputSpec
from ._convert_common import _schema_to_json_schema


def _decode_openai_tools(raw_tools: Any) -> list[ToolSpec]:
    if not isinstance(raw_tools, list):
        return []
    tools: list[ToolSpec] = []
    for raw_tool in raw_tools:
        if not isinstance(raw_tool, dict):
            continue
        fn = raw_tool.get("function") if isinstance(raw_tool.get("function"), dict) else raw_tool
        name = fn.get("name")
        if not name:
            continue
        tools.append(
            ToolSpec(
                function=FunctionToolSpec(
                    name=str(name),
                    description=fn.get("description"),
                    parameters=fn.get("parameters") or {"type": "object", "properties": {}},
                )
            )
        )
    return tools


def _decode_usage_from_openai(raw_usage: Any) -> Usage | None:
    if not isinstance(raw_usage, dict):
        return None
    input_tokens = int(raw_usage.get("prompt_tokens") or 0)
    output_tokens = int(raw_usage.get("completion_tokens") or 0)
    return Usage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=int(raw_usage.get("total_tokens") or (input_tokens + output_tokens)),
    )


def _decode_usage_from_openai_responses(raw_usage: Any) -> Usage | None:
    if not isinstance(raw_usage, dict):
        return None
    input_tokens = int(raw_usage.get("input_tokens") or 0)
    output_tokens = int(raw_usage.get("output_tokens") or 0)
    input_details = raw_usage.get("input_tokens_details") or {}
    output_details = raw_usage.get("output_tokens_details") or {}
    total_tokens = int(raw_usage.get("total_tokens") or (input_tokens + output_tokens))
    return Usage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        reasoning_tokens=int(
            output_details.get("reasoning_tokens") or raw_usage.get("reasoning_tokens") or 0
        ),
        cache_read_tokens=int(input_details.get("cached_tokens") or 0),
        total_tokens=total_tokens,
    )


def _decode_response_spec_from_openai(raw_response_format: Any) -> StructuredOutputSpec | None:
    if not isinstance(raw_response_format, dict):
        return None
    response_type = raw_response_format.get("type")
    if response_type == "json_schema":
        json_schema = raw_response_format.get("json_schema") or {}
        return StructuredOutputSpec(
            schema=json_schema.get("schema") or {},
            method=StructuredOutputMethod.json_schema,
            strict=json_schema.get("strict"),
        )
    if response_type == "json_object":
        return StructuredOutputSpec(
            schema={},
            method=StructuredOutputMethod.json_mode,
        )
    return None


def _decode_response_spec_from_openai_responses(
    raw_response_format: Any,
) -> StructuredOutputSpec | None:
    if not isinstance(raw_response_format, dict):
        return None
    format_config = raw_response_format.get("format")
    if isinstance(format_config, dict):
        raw_response_format = format_config
    response_type = raw_response_format.get("type")
    if response_type == "json_schema":
        json_schema = raw_response_format.get("json_schema") or {}
        schema = json_schema.get("schema") if isinstance(json_schema, dict) else {}
        return StructuredOutputSpec(
            schema=schema or {},
            method=StructuredOutputMethod.json_schema,
            strict=json_schema.get("strict") if isinstance(json_schema, dict) else None,
        )
    if response_type == "json_object":
        return StructuredOutputSpec(schema={}, method=StructuredOutputMethod.json_mode)
    return None


def _encode_openai_response_format(spec: StructuredOutputSpec) -> dict[str, Any]:
    schema = _schema_to_json_schema(spec.schema_)
    if spec.method in {StructuredOutputMethod.auto, StructuredOutputMethod.json_schema}:
        return {
            "type": "json_schema",
            "json_schema": {
                "name": "structured_output",
                "schema": schema,
                "strict": spec.strict,
            },
        }
    if spec.method == StructuredOutputMethod.json_mode:
        return {"type": "json_object"}
    if spec.method == StructuredOutputMethod.function_calling:
        return {
            "type": "json_schema",
            "json_schema": {
                "name": "structured_output",
                "schema": schema,
                "strict": spec.strict,
            },
        }
    return {"type": "json_object"}


def _encode_openai_responses_text_format(spec: StructuredOutputSpec) -> dict[str, Any]:
    if spec.method == StructuredOutputMethod.json_mode:
        return {"format": {"type": "json_object"}}
    if spec.method in {
        StructuredOutputMethod.auto,
        StructuredOutputMethod.json_schema,
        StructuredOutputMethod.function_calling,
    }:
        return {
            "format": {
                "type": "json_schema",
                "json_schema": {
                    "name": "structured_output",
                    "schema": _schema_to_json_schema(spec.schema_),
                    "strict": spec.strict,
                },
            }
        }
    return {"format": {"type": "text"}}


def _encode_usage_for_openai_responses(usage: Usage) -> dict[str, Any]:
    return {
        "input_tokens": usage.input_tokens,
        "input_tokens_details": {"cached_tokens": usage.cache_read_tokens},
        "output_tokens": usage.output_tokens,
        "output_tokens_details": {"reasoning_tokens": usage.reasoning_tokens},
        "total_tokens": usage.total_tokens or (usage.input_tokens + usage.output_tokens),
    }
