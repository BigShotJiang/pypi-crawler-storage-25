"""Capability, compatibility, and planning helpers."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

from ._base import CoreModel
from ._identity import stable_id
from .canonical import (
    AssetRef,
    AudioPart,
    DocumentPart,
    FilePart,
    ImagePart,
    Message,
    Role,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolResultPart,
)
from ._convert_common import _schema_to_json_schema
from .families import ApiFamily
from ._json import json_dumps
from .options import CallOptions


class ModelRequest(CoreModel):
    messages: list[Message]
    options: CallOptions


class PreprocessingStep(CoreModel):
    kind: Literal["upload_asset", "transcribe_audio", "extract_ocr", "resolve_document"]
    reason: str
    asset: AssetRef | None = None


class LossIssue(CoreModel):
    code: str
    severity: Literal["info", "warning", "error"] = "warning"
    message: str
    location: str | None = None
    detail: dict[str, Any] = Field(default_factory=dict)


class LossReport(CoreModel):
    issues: list[LossIssue] = Field(default_factory=list)

    def has_errors(self) -> bool:
        return any(issue.severity == "error" for issue in self.issues)

    def warnings(self) -> list[LossIssue]:
        return [issue for issue in self.issues if issue.severity == "warning"]


class CapabilityProfile(CoreModel):
    family: ApiFamily
    supports_developer_role: bool = False
    supports_tools: bool = False
    supports_reasoning: bool = False
    supports_images: bool = False
    supports_documents: bool = False
    supports_audio: bool = False
    supports_files: bool = False
    supports_structured_output: bool = False
    supports_prompt_cache: bool = False


class CapabilityRegistry:
    """Registry of family capability profiles."""

    def __init__(self, profiles: dict[ApiFamily, CapabilityProfile] | None = None) -> None:
        self._profiles = profiles or self.builtin()._profiles

    @classmethod
    def builtin(cls) -> CapabilityRegistry:
        return cls(
            profiles={
                ApiFamily.openai_chat: CapabilityProfile(
                    family=ApiFamily.openai_chat,
                    supports_developer_role=True,
                    supports_tools=True,
                    supports_reasoning=True,
                    supports_images=True,
                    supports_structured_output=True,
                ),
                ApiFamily.openai_responses: CapabilityProfile(
                    family=ApiFamily.openai_responses,
                    supports_developer_role=True,
                    supports_tools=True,
                    supports_reasoning=True,
                    supports_images=True,
                    supports_documents=True,
                    supports_audio=True,
                    supports_files=True,
                    supports_structured_output=True,
                ),
                ApiFamily.anthropic_messages: CapabilityProfile(
                    family=ApiFamily.anthropic_messages,
                    supports_tools=True,
                    supports_reasoning=True,
                    supports_images=True,
                    supports_documents=True,
                    supports_prompt_cache=True,
                    supports_structured_output=True,
                ),
                ApiFamily.google_genai: CapabilityProfile(
                    family=ApiFamily.google_genai,
                    supports_tools=True,
                    supports_reasoning=True,
                    supports_images=True,
                    supports_documents=True,
                    supports_audio=True,
                    supports_files=True,
                    supports_structured_output=True,
                ),
            }
        )

    def get(self, family: ApiFamily) -> CapabilityProfile:
        return self._profiles[family]


class CompatibilityResult(CoreModel):
    ok: bool
    profile: CapabilityProfile
    normalized_messages: list[Message]
    loss_report: LossReport
    required_preprocessing: list[PreprocessingStep] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class ProviderRoute(CoreModel):
    provider: str | None = None
    model: str | None = None
    api_family: ApiFamily
    dialect: str | None = None
    channel: str = "http"
    cache_namespace: str
    reason: str


class CacheKey(CoreModel):
    namespace: str
    key: str
    provider: str | None = None
    model: str | None = None
    api_family: ApiFamily
    dialect: str | None = None


class CostShape(CoreModel):
    estimated_input_tokens: int
    estimated_output_tokens: int = 0
    estimated_total_tokens: int = 0
    estimated_tool_schema_tokens: int = 0
    estimated_response_schema_tokens: int = 0
    estimated_reasoning_tokens: int = 0
    modalities: list[str] = Field(default_factory=list)
    tool_calls: int = 0
    tool_results: int = 0
    reasoning: bool = False
    structured_output: bool = False
    streaming: bool = False


class InspectionReport(CoreModel):
    provider: str | None = None
    model: str | None = None
    chosen_api_family: ApiFamily
    chosen_dialect: str | None = None
    compatibility_ok: bool
    route_reason: str
    estimated_cost_shape: CostShape
    loss_report: LossReport
    required_preprocessing: list[PreprocessingStep] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class InspectionResult(CoreModel):
    normalized_messages: list[Message]
    options: CallOptions
    route: ProviderRoute
    compatibility: CompatibilityResult
    cost_shape: CostShape

    def report(self) -> InspectionReport:
        return InspectionReport(
            provider=self.options.provider,
            model=self.options.model,
            chosen_api_family=self.route.api_family,
            chosen_dialect=self.route.dialect,
            compatibility_ok=self.compatibility.ok,
            route_reason=self.route.reason,
            estimated_cost_shape=self.cost_shape,
            loss_report=self.compatibility.loss_report,
            required_preprocessing=self.compatibility.required_preprocessing,
            warnings=self.compatibility.warnings,
        )


class CompiledRequest(CoreModel):
    messages: list[Message]
    options: CallOptions
    route: ProviderRoute
    compatibility: CompatibilityResult
    warnings: list[str] = Field(default_factory=list)

    @property
    def payload(self) -> dict[str, Any]:
        """Encode the compiled canonical request for the selected API family."""

        from .convert import _encode_request

        return _encode_request(
            ModelRequest(messages=self.messages, options=self.options),
            self.route.api_family,
        )

    @property
    def cache_key(self) -> CacheKey:
        """Stable, secret-free key material for external request caches."""

        return CacheKey(
            namespace=self.route.cache_namespace,
            key=stable_id(
                "cache",
                {
                    "messages": [message.model_dump(mode="json") for message in self.messages],
                    "options": _cache_options_fingerprint(self.options),
                    "route": self.route.model_dump(mode="json"),
                },
            ),
            provider=self.route.provider,
            model=self.route.model,
            api_family=self.route.api_family,
            dialect=self.route.dialect,
        )


class CompatibilityChecker:
    """Checks whether a canonical request fits a selected family."""

    def __init__(self, registry: CapabilityRegistry | None = None) -> None:
        self._registry = registry or CapabilityRegistry.builtin()

    def check(
        self,
        messages: list[Message],
        options: CallOptions,
        family: ApiFamily,
    ) -> CompatibilityResult:
        profile = self._registry.get(family)
        normalized_messages = normalize_messages(messages)
        issues: list[LossIssue] = []
        preprocessing: list[PreprocessingStep] = []
        warnings: list[str] = []
        seen_tool_calls: set[str] = set()

        for message_index, message in enumerate(normalized_messages):
            if message.role == Role.developer and not profile.supports_developer_role:
                issues.append(
                    LossIssue(
                        code="developer_role_downgrade",
                        severity="warning",
                        message=f"{family.value} does not natively preserve developer role semantics.",
                        location=f"messages[{message_index}]",
                    )
                )

            for part_index, part in enumerate(message.parts):
                location = f"messages[{message_index}].parts[{part_index}]"
                if isinstance(part, ThinkingPart) and not profile.supports_reasoning:
                    issues.append(
                        LossIssue(
                            code="reasoning_drop",
                            severity="warning",
                            message=f"{family.value} may drop or flatten reasoning content.",
                            location=location,
                        )
                    )
                elif isinstance(part, ToolCallPart):
                    if not profile.supports_tools:
                        issues.append(
                            LossIssue(
                                code="tool_call_unsupported",
                                severity="error",
                                message=f"{family.value} does not support tool calls.",
                                location=location,
                            )
                        )
                    else:
                        seen_tool_calls.add(part.id)
                elif isinstance(part, ToolResultPart):
                    if not profile.supports_tools:
                        issues.append(
                            LossIssue(
                                code="tool_result_unsupported",
                                severity="error",
                                message=f"{family.value} does not support tool results.",
                                location=location,
                            )
                        )
                    elif part.tool_call_id not in seen_tool_calls:
                        issues.append(
                            LossIssue(
                                code="orphan_tool_result",
                                severity="warning",
                                message="Tool result has no prior matching tool call in the normalized transcript.",
                                location=location,
                            )
                        )
                elif isinstance(part, ImagePart):
                    self._check_asset_part(
                        profile,
                        preprocessing,
                        issues,
                        location,
                        part.asset,
                        supports_native=profile.supports_images,
                        fallback_kind="upload_asset",
                        unsupported_code="image_unsupported",
                        unsupported_message=f"{family.value} does not support image inputs.",
                    )
                elif isinstance(part, DocumentPart):
                    self._check_asset_part(
                        profile,
                        preprocessing,
                        issues,
                        location,
                        part.asset,
                        supports_native=profile.supports_documents,
                        fallback_kind="resolve_document",
                        unsupported_code="document_preprocess_required",
                        unsupported_message=f"{family.value} requires document preprocessing or upload references.",
                    )
                elif isinstance(part, AudioPart):
                    self._check_asset_part(
                        profile,
                        preprocessing,
                        issues,
                        location,
                        part.asset,
                        supports_native=profile.supports_audio,
                        fallback_kind="transcribe_audio",
                        unsupported_code="audio_preprocess_required",
                        unsupported_message=f"{family.value} requires audio preprocessing or transcription.",
                    )
                elif isinstance(part, FilePart):
                    self._check_asset_part(
                        profile,
                        preprocessing,
                        issues,
                        location,
                        part.asset,
                        supports_native=profile.supports_files,
                        fallback_kind="upload_asset",
                        unsupported_code="file_preprocess_required",
                        unsupported_message=f"{family.value} requires file uploads or host-side resolution.",
                    )

        if options.response and not profile.supports_structured_output:
            issues.append(
                LossIssue(
                    code="structured_output_fallback",
                    severity="warning",
                    message=f"{family.value} does not have a strong native structured-output path yet.",
                )
            )

        if preprocessing:
            warnings.append("Preprocessing is required before this request can be executed.")

        report = LossReport(issues=issues)
        return CompatibilityResult(
            ok=not report.has_errors(),
            profile=profile,
            normalized_messages=normalized_messages,
            loss_report=report,
            required_preprocessing=preprocessing,
            warnings=warnings,
        )

    @staticmethod
    def _check_asset_part(
        profile: CapabilityProfile,
        preprocessing: list[PreprocessingStep],
        issues: list[LossIssue],
        location: str,
        asset: AssetRef,
        *,
        supports_native: bool,
        fallback_kind: Literal["upload_asset", "transcribe_audio", "extract_ocr", "resolve_document"],
        unsupported_code: str,
        unsupported_message: str,
    ) -> None:
        if asset.source_type in {"file_path", "bytes_ref"}:
            preprocessing.append(
                PreprocessingStep(
                    kind="upload_asset",
                    reason="Host-side resolution is required for local or opaque asset references.",
                    asset=asset,
                )
            )
        if supports_native:
            return
        preprocessing.append(
            PreprocessingStep(
                kind=fallback_kind,
                reason=unsupported_message,
                asset=asset,
            )
        )
        issues.append(
            LossIssue(
                code=unsupported_code,
                severity="warning",
                message=unsupported_message,
                location=location,
            )
        )


class CostEstimator:
    """Rough cost-shape estimator used by inspect/compile."""

    def estimate(self, messages: list[Message], options: CallOptions) -> CostShape:
        modalities: list[str] = []
        message_chars = 0
        tool_calls = 0
        tool_results = 0

        for message in messages:
            for part in message.parts:
                if isinstance(part, TextPart):
                    message_chars += len(part.text)
                    if "text" not in modalities:
                        modalities.append("text")
                elif isinstance(part, ThinkingPart):
                    message_chars += len(part.text)
                    if "thinking" not in modalities:
                        modalities.append("thinking")
                elif isinstance(part, ImagePart):
                    message_chars += 512
                    if "image" not in modalities:
                        modalities.append("image")
                elif isinstance(part, DocumentPart):
                    message_chars += 1024
                    if "document" not in modalities:
                        modalities.append("document")
                elif isinstance(part, AudioPart):
                    message_chars += 2048
                    if "audio" not in modalities:
                        modalities.append("audio")
                elif isinstance(part, FilePart):
                    message_chars += 1024
                    if "file" not in modalities:
                        modalities.append("file")
                elif isinstance(part, ToolCallPart):
                    tool_calls += 1
                    message_chars += len(part.name) + len(part.arguments_json)
                    if "tool_call" not in modalities:
                        modalities.append("tool_call")
                elif isinstance(part, ToolResultPart):
                    tool_results += 1
                    message_chars += len(_stringify_cost_value(part.output))
                    if "tool_result" not in modalities:
                        modalities.append("tool_result")

        message_tokens = _estimate_tokens_from_chars(message_chars)
        tool_schema_tokens = _estimate_tool_schema_tokens(options)
        response_schema_tokens = _estimate_response_schema_tokens(options)
        input_tokens = max(1, message_tokens + tool_schema_tokens + response_schema_tokens)
        output_tokens = max(0, int(options.max_tokens or 0))
        reasoning_tokens = _estimate_reasoning_tokens(options)

        return CostShape(
            estimated_input_tokens=input_tokens,
            estimated_output_tokens=output_tokens,
            estimated_total_tokens=input_tokens + output_tokens + reasoning_tokens,
            estimated_tool_schema_tokens=tool_schema_tokens,
            estimated_response_schema_tokens=response_schema_tokens,
            estimated_reasoning_tokens=reasoning_tokens,
            modalities=modalities,
            tool_calls=tool_calls,
            tool_results=tool_results,
            reasoning=bool(options.reasoning),
            structured_output=options.response is not None,
            streaming=bool(options.stream and options.stream.enabled is not False),
        )


def _estimate_tool_schema_tokens(options: CallOptions) -> int:
    if not options.tools:
        return 0
    chars = sum(
        len(
            json_dumps(
                {
                    "name": tool.function.name,
                    "description": tool.function.description or "",
                    "parameters": tool.function.parameters,
                }
            )
        )
        for tool in options.tools
    )
    return _estimate_tokens_from_chars(chars)


def _estimate_response_schema_tokens(options: CallOptions) -> int:
    if options.response is None:
        return 0
    schema = _schema_to_json_schema(options.response.schema_)
    return _estimate_tokens_from_chars(len(json_dumps(schema)))


def _estimate_reasoning_tokens(options: CallOptions) -> int:
    reasoning = options.reasoning
    if reasoning is None or reasoning.enabled is False:
        return 0
    if reasoning.budget_tokens is not None:
        return max(0, int(reasoning.budget_tokens))
    if reasoning.effort:
        return {
            "minimal": 256,
            "low": 1024,
            "medium": 2048,
            "high": 4096,
        }.get(str(reasoning.effort), 0)
    return 0


def _estimate_tokens_from_chars(chars: int) -> int:
    if chars <= 0:
        return 0
    return max(1, (chars + 3) // 4)


def _stringify_cost_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json_dumps(value)


def normalize_messages(messages: list[Message]) -> list[Message]:
    """Normalize the transcript by dropping empty content and merging safe same-role runs."""

    normalized: list[Message] = []
    for message in messages:
        cleaned_parts = [
            part
            for part in message.parts
            if not (
                isinstance(part, (TextPart, ThinkingPart))
                and not part.text.strip()
            )
        ]
        if not cleaned_parts:
            continue

        cleaned = Message(role=message.role, parts=cleaned_parts, metadata=message.metadata)
        if normalized and _can_merge_messages(normalized[-1], cleaned):
            prev = normalized[-1]
            normalized[-1] = Message(
                role=prev.role,
                parts=[*prev.parts, *cleaned.parts],
                metadata={**prev.metadata, **cleaned.metadata},
            )
            continue
        normalized.append(cleaned)
    return normalized


def _can_merge_messages(previous: Message, current: Message) -> bool:
    if previous.role != current.role:
        return False
    if _contains_tool_results(previous) or _contains_tool_results(current):
        return _is_tool_result_only(previous) and _is_tool_result_only(current)
    return True


def _contains_tool_results(message: Message) -> bool:
    return any(isinstance(part, ToolResultPart) for part in message.parts)


def _is_tool_result_only(message: Message) -> bool:
    return bool(message.parts) and all(isinstance(part, ToolResultPart) for part in message.parts)


def choose_api_family(messages: list[Message], options: CallOptions) -> tuple[ApiFamily, str]:
    """Select the best family for the request using documented precedence."""

    if options.api_family is not None:
        return options.api_family, "explicit options.api_family"

    provider = (options.provider or "").strip().lower()
    base_url = (options.base_url or "").strip().lower()
    model = (options.model or "").strip().lower()
    native = options.native or {}
    extra_body = options.extra_body or {}

    if any(key in native or key in extra_body for key in ("previous_response_id", "response_id")):
        return ApiFamily.openai_responses, "request-shape hint"

    if provider in {"google", "gemini", "google_genai"} or "generativelanguage.googleapis.com" in base_url:
        return ApiFamily.google_genai, "provider/base_url hard hint"

    if provider in {"anthropic"} or "/v1/messages" in base_url or (
        "anthropic" in base_url and provider not in _openai_like_providers()
    ):
        return ApiFamily.anthropic_messages, "provider/base_url hard hint"

    if provider in _openai_like_providers() or any(
        token in base_url for token in ("openai", "openrouter", "newapi", "oneapi", "frontis.top")
    ):
        return ApiFamily.openai_chat, "provider/base_url hard hint"

    if "gemini" in model:
        return ApiFamily.google_genai, "model default hint"

    if "claude" in model and provider in {"", "anthropic"}:
        return ApiFamily.anthropic_messages, "model default hint"

    return ApiFamily.openai_chat, "default openai-compatible fallback"


def detect_dialect(options: CallOptions) -> str | None:
    if options.dialect:
        return options.dialect

    haystack = " ".join(
        part.strip().lower()
        for part in (options.provider or "", options.base_url or "")
        if part
    )
    for needle, dialect in (
        ("openrouter", "openrouter"),
        ("doubao", "doubao"),
        ("ark", "doubao"),
        ("moonshot", "kimi"),
        ("kimi", "kimi"),
        ("deepseek", "deepseek"),
        ("minimax", "minimax"),
        ("newapi", "newapi"),
        ("oneapi", "newapi"),
        ("frontis.top", "newapi"),
    ):
        if needle in haystack:
            return dialect
    return None


def build_route(messages: list[Message], options: CallOptions) -> ProviderRoute:
    family, reason = choose_api_family(messages, options)
    dialect = detect_dialect(options)
    cache_namespace = (
        options.caching.namespace
        if options.caching is not None and options.caching.namespace
        else dialect or (options.provider or family.value)
    )
    return ProviderRoute(
        provider=options.provider,
        model=options.model,
        api_family=family,
        dialect=dialect,
        cache_namespace=cache_namespace,
        reason=reason,
    )


def _cache_options_fingerprint(options: CallOptions) -> dict[str, Any]:
    data = options.model_dump(mode="python")
    data["api_key"] = None
    data["headers"] = {}
    data["metadata"] = {}
    data["timeout"] = None
    data["max_retries"] = None
    return data


def inspect_request(
    messages: list[Message],
    options: CallOptions,
    *,
    registry: CapabilityRegistry | None = None,
) -> InspectionResult:
    checker = CompatibilityChecker(registry=registry)
    route = build_route(messages, options)
    compatibility = checker.check(messages, options, route.api_family)
    cost_shape = CostEstimator().estimate(compatibility.normalized_messages, options)
    return InspectionResult(
        normalized_messages=compatibility.normalized_messages,
        options=options,
        route=route,
        compatibility=compatibility,
        cost_shape=cost_shape,
    )


def compile_request(
    messages: list[Message],
    options: CallOptions,
    *,
    registry: CapabilityRegistry | None = None,
) -> CompiledRequest:
    inspection = inspect_request(messages, options, registry=registry)
    return CompiledRequest(
        messages=inspection.normalized_messages,
        options=inspection.options,
        route=inspection.route,
        compatibility=inspection.compatibility,
        warnings=inspection.compatibility.warnings,
    )


def _openai_like_providers() -> set[str]:
    return {
        "openai",
        "openrouter",
        "doubao",
        "ark",
        "kimi",
        "moonshot",
        "deepseek",
        "minimax",
        "newapi",
        "oneapi",
    }
