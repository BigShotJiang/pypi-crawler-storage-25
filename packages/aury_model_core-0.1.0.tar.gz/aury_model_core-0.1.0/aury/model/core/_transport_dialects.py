"""Built-in HTTP transport dialect policies."""

from __future__ import annotations

from typing import Any

from .analysis import CompiledRequest
from .errors import ProtocolError, TransportNotConfiguredError
from .families import ApiFamily
from .options import CallOptions


class BuiltinTransportDialectPolicy:
    family: ApiFamily
    default_base_url: str
    endpoint_path: str

    def resolve_endpoint_path(self, options: CallOptions, *, stream: bool) -> str:
        return self.endpoint_path

    def looks_like_full_endpoint(self, base_url: str, options: CallOptions, *, stream: bool) -> bool:
        endpoint = self.resolve_endpoint_path(options, stream=stream)
        return bool(endpoint) and base_url.endswith(endpoint)

    def resolve_base_url(self, options: CallOptions, *, stream: bool) -> str:
        if self.default_base_url:
            return self.default_base_url
        raise TransportNotConfiguredError(
            f"{self.family.value} transport requires an explicit base_url for this dialect."
        )

    def rewrite_base_url(self, base_url: str, options: CallOptions, *, stream: bool) -> str:
        return base_url

    def prepare_headers(
        self,
        headers: dict[str, str],
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, str]:
        return headers

    def prepare_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        return payload

    def normalize_response_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        return payload

    def stream_frame_normalizer(
        self,
        compiled: CompiledRequest,
        options: CallOptions,
    ) -> BuiltinTransportFrameNormalizer | None:
        return None


class BuiltinTransportFrameNormalizer:
    def feed(self, frame: dict[str, Any]) -> list[dict[str, Any]]:
        return [frame]

    def finish(self) -> list[dict[str, Any]]:
        return []


class _OpenAIChatTransportPolicy(BuiltinTransportDialectPolicy):
    family = ApiFamily.openai_chat
    default_base_url = "https://api.openai.com/v1"
    endpoint_path = "/chat/completions"

    def prepare_headers(
        self,
        headers: dict[str, str],
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, str]:
        if options.api_key:
            _setdefault_header(headers, "authorization", f"Bearer {options.api_key}")
        return headers


class _OpenAICompatibleTransportPolicy(BuiltinTransportDialectPolicy):
    def prepare_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        request = dict(payload)
        request["messages"] = _downgrade_developer_messages(request.get("messages"))
        return request

    def prepare_headers(
        self,
        headers: dict[str, str],
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, str]:
        if options.api_key:
            _setdefault_header(headers, "authorization", f"Bearer {options.api_key}")
        return headers


class _OpenAIResponsesTransportPolicy(BuiltinTransportDialectPolicy):
    family = ApiFamily.openai_responses
    default_base_url = "https://api.openai.com/v1"
    endpoint_path = "/responses"

    def prepare_headers(
        self,
        headers: dict[str, str],
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, str]:
        if options.api_key:
            _setdefault_header(headers, "authorization", f"Bearer {options.api_key}")
        return headers


class _AnthropicTransportPolicy(BuiltinTransportDialectPolicy):
    family = ApiFamily.anthropic_messages
    default_base_url = "https://api.anthropic.com/v1"
    endpoint_path = "/messages"

    def prepare_headers(
        self,
        headers: dict[str, str],
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, str]:
        if options.api_key:
            _setdefault_header(headers, "x-api-key", options.api_key)
        _setdefault_header(headers, "anthropic-version", "2023-06-01")
        return headers


class _GoogleGenAITransportPolicy(BuiltinTransportDialectPolicy):
    family = ApiFamily.google_genai
    default_base_url = "https://generativelanguage.googleapis.com/v1beta"
    endpoint_path = ""

    def resolve_endpoint_path(self, options: CallOptions, *, stream: bool) -> str:
        model = str(options.model or "").strip()
        if not model:
            raise TransportNotConfiguredError("google_genai transport requires a model name.")
        resource = model if model.startswith(("models/", "tunedModels/")) else f"models/{model}"
        suffix = ":streamGenerateContent?alt=sse" if stream else ":generateContent"
        return f"/{resource}{suffix}"

    def looks_like_full_endpoint(self, base_url: str, options: CallOptions, *, stream: bool) -> bool:
        return super().looks_like_full_endpoint(base_url, options, stream=stream)

    def rewrite_base_url(self, base_url: str, options: CallOptions, *, stream: bool) -> str:
        endpoint = self.resolve_endpoint_path(options, stream=stream)
        alternate_endpoint = self.resolve_endpoint_path(options, stream=not stream)
        if base_url.endswith(alternate_endpoint):
            return f"{base_url[:-len(alternate_endpoint)]}{endpoint}"
        return base_url

    def prepare_headers(
        self,
        headers: dict[str, str],
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, str]:
        if options.api_key:
            _setdefault_header(headers, "x-goog-api-key", options.api_key)
        return headers

    def prepare_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        request = dict(payload)
        request.pop("model", None)
        config = request.pop("config", None)
        if not isinstance(config, dict):
            return request

        generation_config = dict(config)
        system_instruction = generation_config.pop("systemInstruction", None) or generation_config.pop(
            "system_instruction", None
        )
        if system_instruction is not None and not _has_any_key(
            request, "systemInstruction", "system_instruction"
        ):
            request["systemInstruction"] = system_instruction
        tools = generation_config.pop("tools", None)
        if tools is not None and "tools" not in request:
            request["tools"] = tools
        tool_config = generation_config.pop("toolConfig", None) or generation_config.pop("tool_config", None)
        if tool_config is not None and not _has_any_key(request, "toolConfig", "tool_config"):
            request["toolConfig"] = tool_config
        if generation_config:
            existing_generation_config = _first_dict(request, "generationConfig", "generation_config")
            if existing_generation_config is None:
                request["generationConfig"] = generation_config
            else:
                merged_generation_config = dict(generation_config)
                merged_generation_config.update(existing_generation_config)
                request["generationConfig"] = merged_generation_config
                request.pop("generation_config", None)
        return request


class _OpenRouterOpenAITransportPolicy(_OpenAICompatibleTransportPolicy):
    default_base_url = "https://openrouter.ai/api/v1"

    def prepare_headers(
        self,
        headers: dict[str, str],
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, str]:
        headers = super().prepare_headers(headers, options, stream=stream)
        referer = _string_metadata(
            options.metadata,
            "http_referer",
            "referer",
            "site_url",
            "app_url",
        )
        if referer:
            _setdefault_header(headers, "http-referer", referer)
        title = _string_metadata(
            options.metadata,
            "x_openrouter_title",
            "x_title",
            "site_name",
            "app_name",
        )
        if title:
            _setdefault_header(headers, "x-openrouter-title", title)
        categories = options.metadata.get("openrouter_categories")
        if categories:
            _setdefault_header(headers, "x-openrouter-categories", _header_list_value(categories))
        return headers

    def normalize_response_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        response = dict(payload)
        choices = response.get("choices")
        if not isinstance(choices, list):
            return response
        response["choices"] = [
            _normalize_openrouter_choice(choice) if isinstance(choice, dict) else choice
            for choice in choices
        ]
        return response

    def stream_frame_normalizer(
        self,
        compiled: CompiledRequest,
        options: CallOptions,
    ) -> BuiltinTransportFrameNormalizer | None:
        return _OpenRouterReasoningFrameNormalizer()


class _DoubaoOpenAITransportPolicy(_OpenAICompatibleTransportPolicy):
    default_base_url = "https://ark.cn-beijing.volces.com/api/v3"


class _DeepSeekOpenAIChatTransportPolicy(_OpenAICompatibleTransportPolicy):
    default_base_url = "https://api.deepseek.com"

    def prepare_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        request = dict(payload)
        if compiled.options.reasoning is not None:
            request.pop("reasoning_effort", None)
        request["messages"] = _normalize_deepseek_reasoning_messages(
            _downgrade_developer_messages(request.get("messages"))
        )
        if _has_any_key(request, "thinking"):
            return request
        thinking = _thinking_toggle_from_reasoning(compiled.options)
        if thinking is not None:
            request["thinking"] = thinking
        return request


class _KimiOpenAIChatTransportPolicy(_OpenAICompatibleTransportPolicy):
    default_base_url = "https://api.moonshot.ai/v1"

    def prepare_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        request = dict(payload)
        request["messages"] = _downgrade_developer_messages(request.get("messages"))
        if not _has_any_key(request, "thinking"):
            thinking = _thinking_toggle_from_reasoning(compiled.options)
            if thinking is not None:
                request["thinking"] = thinking
        if _kimi_thinking_enabled(request.get("thinking")) and not _kimi_tool_choice_allowed(
            request.get("tool_choice")
        ):
            raise ProtocolError(
                'kimi thinking mode only supports tool_choice="auto" or "none".'
            )
        if compiled.options.reasoning is not None:
            request.pop("reasoning_effort", None)
        return request


class _MiniMaxOpenAIChatTransportPolicy(_OpenAICompatibleTransportPolicy):
    default_base_url = "https://api.minimaxi.com/v1"

    def prepare_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        request = dict(payload)
        request["messages"] = _downgrade_developer_messages(request.get("messages"))
        reasoning = compiled.options.reasoning
        if reasoning and reasoning.return_thinking and "reasoning_split" not in request:
            request["reasoning_split"] = True
        return request

    def normalize_response_payload(
        self,
        payload: dict[str, Any],
        compiled: CompiledRequest,
        options: CallOptions,
        *,
        stream: bool,
    ) -> dict[str, Any]:
        response = dict(payload)
        choices = response.get("choices")
        if not isinstance(choices, list):
            return response
        normalized_choices: list[Any] = []
        for choice in choices:
            if not isinstance(choice, dict):
                normalized_choices.append(choice)
                continue
            normalized_choices.append(_normalize_minimax_choice(choice))
        response["choices"] = normalized_choices
        return response

    def stream_frame_normalizer(
        self,
        compiled: CompiledRequest,
        options: CallOptions,
    ) -> BuiltinTransportFrameNormalizer | None:
        return _MiniMaxThinkTagFrameNormalizer()


class _NewAPIOpenAITransportPolicy(_OpenAICompatibleTransportPolicy):
    default_base_url = ""

    def resolve_base_url(self, options: CallOptions, *, stream: bool) -> str:
        raise TransportNotConfiguredError("newapi transport requires an explicit base_url.")


_FAMILY_POLICIES: dict[ApiFamily, BuiltinTransportDialectPolicy] = {
    ApiFamily.openai_chat: _OpenAIChatTransportPolicy(),
    ApiFamily.openai_responses: _OpenAIResponsesTransportPolicy(),
    ApiFamily.anthropic_messages: _AnthropicTransportPolicy(),
    ApiFamily.google_genai: _GoogleGenAITransportPolicy(),
}

_DIALECT_POLICIES: dict[tuple[ApiFamily, str], BuiltinTransportDialectPolicy] = {
    (ApiFamily.openai_chat, "openrouter"): type(
        "_OpenRouterOpenAIChatTransportPolicy",
        (_OpenRouterOpenAITransportPolicy,),
        {"family": ApiFamily.openai_chat, "endpoint_path": "/chat/completions"},
    )(),
    (ApiFamily.openai_responses, "openrouter"): type(
        "_OpenRouterOpenAIResponsesTransportPolicy",
        (_OpenRouterOpenAITransportPolicy,),
        {"family": ApiFamily.openai_responses, "endpoint_path": "/responses"},
    )(),
    (ApiFamily.openai_chat, "doubao"): type(
        "_DoubaoOpenAIChatTransportPolicy",
        (_DoubaoOpenAITransportPolicy,),
        {"family": ApiFamily.openai_chat, "endpoint_path": "/chat/completions"},
    )(),
    (ApiFamily.openai_responses, "doubao"): type(
        "_DoubaoOpenAIResponsesTransportPolicy",
        (_DoubaoOpenAITransportPolicy,),
        {"family": ApiFamily.openai_responses, "endpoint_path": "/responses"},
    )(),
    (ApiFamily.openai_chat, "deepseek"): type(
        "_DeepSeekChatTransportPolicy",
        (_DeepSeekOpenAIChatTransportPolicy,),
        {"family": ApiFamily.openai_chat, "endpoint_path": "/chat/completions"},
    )(),
    (ApiFamily.openai_chat, "kimi"): type(
        "_KimiChatTransportPolicy",
        (_KimiOpenAIChatTransportPolicy,),
        {"family": ApiFamily.openai_chat, "endpoint_path": "/chat/completions"},
    )(),
    (ApiFamily.openai_chat, "minimax"): type(
        "_MiniMaxChatTransportPolicy",
        (_MiniMaxOpenAIChatTransportPolicy,),
        {"family": ApiFamily.openai_chat, "endpoint_path": "/chat/completions"},
    )(),
    (ApiFamily.openai_chat, "newapi"): type(
        "_NewAPIChatTransportPolicy",
        (_NewAPIOpenAITransportPolicy,),
        {"family": ApiFamily.openai_chat, "endpoint_path": "/chat/completions"},
    )(),
    (ApiFamily.openai_responses, "newapi"): type(
        "_NewAPIResponsesTransportPolicy",
        (_NewAPIOpenAITransportPolicy,),
        {"family": ApiFamily.openai_responses, "endpoint_path": "/responses"},
    )(),
}


def resolve_transport_dialect_policy(
    family: ApiFamily,
    *,
    dialect: str | None = None,
) -> BuiltinTransportDialectPolicy:
    if dialect:
        policy = _DIALECT_POLICIES.get((family, dialect))
        if policy is not None:
            return policy
        raise TransportNotConfiguredError(
            f"No built-in transport dialect policy is defined for {family.value} with dialect {dialect}."
        )
    policy = _FAMILY_POLICIES.get(family)
    if policy is None:
        raise TransportNotConfiguredError(f"No built-in transport dialect policy is defined for {family.value}.")
    return policy


def _setdefault_header(headers: dict[str, str], name: str, value: str) -> None:
    if any(existing.lower() == name.lower() for existing in headers):
        return
    headers[name] = value


def _has_any_key(payload: dict[str, Any], *keys: str) -> bool:
    return any(key in payload for key in keys)


def _downgrade_developer_messages(raw_messages: Any) -> list[Any]:
    if not isinstance(raw_messages, list):
        return raw_messages if isinstance(raw_messages, list) else []
    messages = []
    for message in raw_messages:
        if not isinstance(message, dict):
            messages.append(message)
            continue
        normalized = dict(message)
        if normalized.get("role") == "developer":
            normalized["role"] = "system"
        messages.append(normalized)
    return messages


def _first_dict(payload: dict[str, Any], *keys: str) -> dict[str, Any] | None:
    for key in keys:
        value = payload.get(key)
        if isinstance(value, dict):
            return value
    return None


def _string_metadata(metadata: dict[str, Any], *keys: str) -> str | None:
    for key in keys:
        value = metadata.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return None


def _header_list_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple, set)):
        return ",".join(str(item) for item in value if str(item))
    return str(value)


def _thinking_toggle_from_reasoning(options: CallOptions) -> dict[str, str] | None:
    reasoning = options.reasoning
    if reasoning is None:
        return None
    if reasoning.enabled is False or reasoning.budget_tokens == 0:
        return {"type": "disabled"}
    return {"type": "enabled"}


def _normalize_openrouter_choice(choice: dict[str, Any]) -> dict[str, Any]:
    normalized_choice = dict(choice)
    message = normalized_choice.get("message")
    if isinstance(message, dict):
        normalized_choice["message"] = _normalize_openrouter_reasoning_container(message)
    delta = normalized_choice.get("delta")
    if isinstance(delta, dict):
        normalized_choice["delta"] = _normalize_openrouter_reasoning_container(delta)
    return normalized_choice


class _OpenRouterReasoningFrameNormalizer(BuiltinTransportFrameNormalizer):
    def feed(self, frame: dict[str, Any]) -> list[dict[str, Any]]:
        if frame.get("done"):
            return [frame]
        normalized = _normalize_openrouter_stream_frame(frame)
        return _split_openrouter_reasoning_content_frame(normalized)


def _normalize_openrouter_stream_frame(frame: dict[str, Any]) -> dict[str, Any]:
    normalized_frame = dict(frame)
    choices = normalized_frame.get("choices")
    if not isinstance(choices, list):
        return normalized_frame
    normalized_frame["choices"] = [
        _normalize_openrouter_choice(choice) if isinstance(choice, dict) else choice
        for choice in choices
    ]
    return normalized_frame


def _split_openrouter_reasoning_content_frame(frame: dict[str, Any]) -> list[dict[str, Any]]:
    choices = frame.get("choices")
    if not isinstance(choices, list):
        return [frame]
    reasoning_choices: list[Any] = []
    content_choices: list[Any] = []
    split_needed = False

    for choice in choices:
        if not isinstance(choice, dict):
            content_choices.append(choice)
            continue
        delta = choice.get("delta")
        if not isinstance(delta, dict):
            content_choices.append(choice)
            continue
        reasoning_content = delta.get("reasoning_content")
        content = delta.get("content")

        if reasoning_content:
            reasoning_choice = dict(choice)
            reasoning_delta = dict(delta)
            reasoning_delta.pop("content", None)
            reasoning_choice["delta"] = reasoning_delta
            reasoning_choice.pop("finish_reason", None)
            reasoning_choices.append(reasoning_choice)
        if content or (not reasoning_content):
            content_choice = dict(choice)
            content_delta = dict(delta)
            content_delta.pop("reasoning_content", None)
            content_choice["delta"] = content_delta
            content_choices.append(content_choice)
        if reasoning_content and content:
            split_needed = True

    if not split_needed:
        return [frame]

    frames: list[dict[str, Any]] = []
    if reasoning_choices:
        reasoning_frame = dict(frame)
        reasoning_frame.pop("usage", None)
        reasoning_frame["choices"] = reasoning_choices
        frames.append(reasoning_frame)
    if content_choices:
        finish_indices = [
            index
            for index, choice in enumerate(content_choices)
            if isinstance(choice, dict) and choice.get("finish_reason")
        ]
        if len(finish_indices) > 1:
            last_finish_index = finish_indices[-1]
            for index in finish_indices[:-1]:
                content_choices[index] = dict(content_choices[index])
                content_choices[index].pop("finish_reason", None)
        content_frame = dict(frame)
        content_frame["choices"] = content_choices
        frames.append(content_frame)
    return frames or [frame]


def _normalize_openrouter_reasoning_container(container: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(container)
    reasoning_text = ""
    if normalized.get("reasoning_content"):
        reasoning_text = str(normalized["reasoning_content"])
    elif normalized.get("reasoning"):
        reasoning_text = _openrouter_reasoning_payload_text(normalized["reasoning"])
    else:
        reasoning_text = _openrouter_reasoning_text(normalized.get("reasoning_details"))
    if reasoning_text and not normalized.get("reasoning_content"):
        normalized["reasoning_content"] = reasoning_text
    normalized.pop("reasoning", None)
    if "reasoning_content" in normalized:
        normalized.pop("reasoning_details", None)
    return normalized


def _openrouter_reasoning_text(reasoning_details: Any) -> str:
    if not isinstance(reasoning_details, list):
        return ""
    chunks: list[str] = []
    for item in reasoning_details:
        if not isinstance(item, dict):
            continue
        if item.get("summary"):
            chunks.append(str(item["summary"]))
            continue
        if item.get("text"):
            chunks.append(str(item["text"]))
    return "".join(chunks)


def _openrouter_reasoning_payload_text(reasoning: Any) -> str:
    if isinstance(reasoning, str):
        return reasoning
    if isinstance(reasoning, dict):
        chunks: list[str] = []
        for key in ("summary", "text"):
            value = reasoning.get(key)
            if value:
                chunks.append(str(value))
        if chunks:
            return "".join(chunks)
        details = reasoning.get("reasoning_details")
        if details is not None:
            return _openrouter_reasoning_text(details)
        return ""
    if isinstance(reasoning, list):
        return _openrouter_reasoning_text(reasoning)
    return str(reasoning) if reasoning else ""


def _kimi_thinking_enabled(thinking: Any) -> bool:
    if not isinstance(thinking, dict):
        return False
    return str(thinking.get("type") or "enabled") != "disabled"


def _kimi_tool_choice_allowed(tool_choice: Any) -> bool:
    if tool_choice is None:
        return True
    if isinstance(tool_choice, str):
        return tool_choice in {"auto", "none"}
    return False


def _normalize_deepseek_reasoning_messages(raw_messages: Any) -> list[Any]:
    if not isinstance(raw_messages, list):
        return raw_messages if isinstance(raw_messages, list) else []
    messages = [dict(message) if isinstance(message, dict) else message for message in raw_messages]
    preserve_indices = _deepseek_reasoning_preserve_indices(messages)
    for index, message in enumerate(messages):
        if not isinstance(message, dict):
            continue
        if str(message.get("role") or "") != "assistant":
            continue
        if index in preserve_indices:
            continue
        message.pop("reasoning_content", None)
        message.pop("reasoning_details", None)
    return messages


def _deepseek_reasoning_preserve_indices(messages: list[Any]) -> set[int]:
    tail_role = None
    for message in reversed(messages):
        if not isinstance(message, dict):
            continue
        role = str(message.get("role") or "")
        if role in {"user", "assistant", "tool"}:
            tail_role = role
            break
    if tail_role != "tool":
        return set()

    last_user_index = -1
    for index, message in enumerate(messages):
        if isinstance(message, dict) and str(message.get("role") or "") == "user":
            last_user_index = index

    for index in range(len(messages) - 1, last_user_index, -1):
        message = messages[index]
        if not isinstance(message, dict):
            continue
        if str(message.get("role") or "") != "assistant":
            continue
        tool_calls = message.get("tool_calls")
        if isinstance(tool_calls, list) and tool_calls:
            return {index}
    return set()


def _normalize_minimax_choice(choice: dict[str, Any]) -> dict[str, Any]:
    message = choice.get("message")
    if not isinstance(message, dict):
        return choice
    if message.get("reasoning_content") or message.get("reasoning_details"):
        return choice
    content = message.get("content")
    if not isinstance(content, str) or "<think>" not in content:
        return choice
    thinking, text = _split_minimax_think_content(content)
    if thinking is None:
        return choice
    normalized_choice = dict(choice)
    normalized_message = dict(message)
    normalized_message["content"] = text
    normalized_message["reasoning_content"] = thinking
    normalized_choice["message"] = normalized_message
    return normalized_choice


class _MiniMaxThinkTagFrameNormalizer(BuiltinTransportFrameNormalizer):
    def __init__(self) -> None:
        self._states: dict[int, _MiniMaxThinkParser] = {}

    def feed(self, frame: dict[str, Any]) -> list[dict[str, Any]]:
        if frame.get("done"):
            return [frame]
        choices = frame.get("choices")
        if not isinstance(choices, list):
            return [frame]
        emitted: list[dict[str, Any]] = []
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            emitted.extend(self._normalize_choice(frame, choice))
        if emitted:
            return emitted
        return [frame]

    def finish(self) -> list[dict[str, Any]]:
        frames: list[dict[str, Any]] = []
        for index, parser in list(self._states.items()):
            remainder = parser.finish()
            if not remainder["reasoning"] and not remainder["content"]:
                continue
            delta: dict[str, Any] = {}
            if remainder["reasoning"]:
                delta["reasoning_content"] = remainder["reasoning"]
            if remainder["content"]:
                delta["content"] = remainder["content"]
            frames.append({"choices": [{"index": index, "delta": delta}]})
        return frames

    def _normalize_choice(self, frame: dict[str, Any], choice: dict[str, Any]) -> list[dict[str, Any]]:
        delta = choice.get("delta")
        if not isinstance(delta, dict):
            return [{**frame, "choices": [choice]}]
        content = delta.get("content")
        if not isinstance(content, str):
            return [{**frame, "choices": [choice]}]

        index = int(choice.get("index") or 0)
        parser = self._states.setdefault(index, _MiniMaxThinkParser())
        chunks = parser.feed(content)
        base_delta = dict(delta)
        base_delta.pop("content", None)
        frames: list[dict[str, Any]] = []

        for chunk_index, chunk in enumerate(chunks):
            choice_payload = dict(choice)
            next_delta = dict(base_delta) if chunk_index == 0 else {}
            if chunk["reasoning"]:
                next_delta["reasoning_content"] = chunk["reasoning"]
            if chunk["content"]:
                next_delta["content"] = chunk["content"]
            if not next_delta and chunk_index == 0:
                next_delta = dict(base_delta)
            choice_payload["delta"] = next_delta
            if chunk_index != len(chunks) - 1:
                choice_payload.pop("finish_reason", None)
            normalized_frame = dict(frame)
            if chunk_index != len(chunks) - 1:
                normalized_frame.pop("usage", None)
            normalized_frame["choices"] = [choice_payload]
            frames.append(normalized_frame)

        if not frames:
            choice_payload = dict(choice)
            choice_payload["delta"] = base_delta
            normalized_frame = dict(frame)
            normalized_frame["choices"] = [choice_payload]
            frames.append(normalized_frame)
        return frames


class _MiniMaxThinkParser:
    def __init__(self) -> None:
        self._buffer = ""
        self._inside_think = False

    def feed(self, chunk: str) -> list[dict[str, str]]:
        self._buffer += chunk
        output: list[dict[str, str]] = []
        while True:
            tag = "</think>" if self._inside_think else "<think>"
            index = self._buffer.find(tag)
            if index >= 0:
                text = self._buffer[:index]
                self._emit(output, text)
                self._buffer = self._buffer[index + len(tag):]
                self._inside_think = not self._inside_think
                continue
            safe, pending = _split_tag_boundary(self._buffer, tag)
            self._emit(output, safe)
            self._buffer = pending
            break
        return output

    def finish(self) -> dict[str, str]:
        remainder = {"reasoning": "", "content": ""}
        if self._buffer:
            key = "reasoning" if self._inside_think else "content"
            remainder[key] = self._buffer
            self._buffer = ""
        return remainder

    def _emit(self, output: list[dict[str, str]], text: str) -> None:
        if not text:
            return
        key = "reasoning" if self._inside_think else "content"
        output.append({"reasoning": text if key == "reasoning" else "", "content": text if key == "content" else ""})


def _split_minimax_think_content(content: str) -> tuple[str | None, str]:
    parser = _MiniMaxThinkParser()
    chunks = parser.feed(content)
    remainder = parser.finish()
    thinking = "".join(chunk["reasoning"] for chunk in chunks) + remainder["reasoning"]
    text = "".join(chunk["content"] for chunk in chunks) + remainder["content"]
    if not thinking:
        return None, content
    return thinking, text


def _split_tag_boundary(text: str, tag: str) -> tuple[str, str]:
    max_suffix = min(len(text), len(tag) - 1)
    for size in range(max_suffix, 0, -1):
        if text.endswith(tag[:size]):
            return text[:-size], text[-size:]
    return text, ""
