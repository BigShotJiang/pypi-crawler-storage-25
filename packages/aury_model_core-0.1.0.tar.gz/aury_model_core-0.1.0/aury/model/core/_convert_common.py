"""Shared conversion helpers."""

from __future__ import annotations

import re
from typing import Any

from ._base import CoreModel
from .canonical import (
    AssetRef,
    AssetSourceType,
    AudioPart,
    DocumentPart,
    FilePart,
    ImagePart,
    Message,
    Role,
    Usage,
)
from .errors import UnsupportedModalityError
from ._json import json_dumps, json_loads_or_keep


class DecodedResponse(CoreModel):
    message: Message
    model: str | None = None
    response_id: str | None = None
    usage: Usage | None = None
    finish_reason: str | None = None


def _first_defined(*values: Any) -> Any:
    for value in values:
        if value is not None:
            return value
    return None


def _asset_from_value(kind: str, value: str) -> AssetRef:
    source_type = AssetSourceType.data_url if value.startswith("data:") else AssetSourceType.url
    mime_type = None
    if source_type == AssetSourceType.data_url:
        match = re.match(r"^data:(?P<mime>[^;]+);base64,", value)
        mime_type = match.group("mime") if match else None
    return AssetRef(kind=kind, source_type=source_type, value=value, mime_type=mime_type)


def _asset_to_urlish(asset: AssetRef) -> str:
    if asset.source_type in {AssetSourceType.url, AssetSourceType.data_url}:
        return asset.value
    raise UnsupportedModalityError(
        f"openai_chat does not directly encode asset source_type={asset.source_type}"
    )


def _parse_tool_output(value: Any) -> Any:
    if isinstance(value, list):
        texts = [
            str(item.get("text") or "")
            for item in value
            if isinstance(item, dict) and item.get("type") == "text"
        ]
        if texts:
            return "".join(texts)
        return value
    return _json_loads_or_keep(value)


def _json_loads_or_keep(value: Any) -> Any:
    return json_loads_or_keep(value)


def _stringify_output(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json_dumps(value)


def _schema_to_json_schema(schema: Any) -> dict[str, Any]:
    if isinstance(schema, dict):
        return schema
    if hasattr(schema, "model_json_schema"):
        return schema.model_json_schema()
    return {}


def _kind_from_mime(mime_type: str) -> str:
    lowered = mime_type.lower()
    if lowered.startswith("image/"):
        return "image"
    if lowered.startswith("audio/"):
        return "audio"
    if lowered in {"application/pdf"}:
        return "document"
    return "file"


def _part_from_asset_kind(
    kind: str,
    asset: AssetRef,
) -> ImagePart | AudioPart | DocumentPart | FilePart:
    if kind == "image":
        return ImagePart(asset=asset)
    if kind == "audio":
        return AudioPart(asset=asset)
    if kind == "document":
        return DocumentPart(asset=asset)
    return FilePart(asset=asset)


def _default_mime_for_kind(kind: str) -> str:
    if kind == "image":
        return "image/*"
    if kind == "audio":
        return "audio/*"
    if kind == "document":
        return "application/pdf"
    return "application/octet-stream"


def _google_inline_data_to_data_url(mime_type: str, data: str) -> str:
    return f"data:{mime_type};base64,{data}"


def _coerce_role(value: str) -> Role:
    if value == "developer":
        return Role.developer
    if value == "system":
        return Role.system
    if value == "assistant":
        return Role.assistant
    return Role.user
