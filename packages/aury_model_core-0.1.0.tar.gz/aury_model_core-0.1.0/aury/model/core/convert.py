"""Public protocol conversion helpers."""

from __future__ import annotations

import copy
from typing import Any, Iterable, Iterator

from .analysis import ModelRequest
from .errors import ProtocolError
from .families import ApiFamily
from ._convert_anthropic import (
    _decode_anthropic_request,
    _decode_anthropic_response,
    _decode_usage_from_anthropic,
    _encode_anthropic_request,
    _encode_anthropic_response,
)
from ._convert_common import DecodedResponse, _json_loads_or_keep
from ._convert_google import (
    _decode_google_genai_request,
    _decode_google_genai_response,
    _decode_usage_from_google_genai,
    _encode_google_genai_request,
    _encode_google_genai_response,
)
from ._convert_openai import (
    _decode_openai_chat_request,
    _decode_openai_chat_response,
    _decode_openai_responses_request,
    _decode_openai_responses_response,
    _decode_usage_from_openai,
    _decode_usage_from_openai_responses,
    _encode_openai_chat_request,
    _encode_openai_chat_response,
    _encode_openai_responses_request,
    _encode_openai_responses_response,
    _finish_reason_from_openai_responses,
)
from .canonical import Usage
from ._json import json_dumps


class RequestConversionBuilder:
    def __init__(self, payload: Any, source_family: ApiFamily | None = None) -> None:
        self._payload = payload
        self._source_family = source_family

    def to(self, target_family: ApiFamily) -> Any:
        return convert_request(
            self._payload,
            source_family=self._source_family,
            target_family=target_family,
        )


def detect_api_family(payload: Any) -> ApiFamily:
    """Detect the likely protocol family for a request or response payload."""

    if not isinstance(payload, dict):
        raise ProtocolError("Only dict payloads can be auto-detected.")

    if "contents" in payload or "candidates" in payload:
        return ApiFamily.google_genai

    if "input" in payload or payload.get("object") == "response":
        return ApiFamily.openai_responses

    if payload.get("type") == "message":
        return ApiFamily.anthropic_messages

    if "choices" in payload or payload.get("object") == "chat.completion":
        return ApiFamily.openai_chat

    if "messages" in payload:
        if "system" in payload:
            return ApiFamily.anthropic_messages
        if _looks_like_anthropic_messages_payload(payload):
            return ApiFamily.anthropic_messages
        return ApiFamily.openai_chat

    raise ProtocolError("Could not detect api_family from payload shape.")


def convert_request(
    payload: Any,
    *,
    source_family: ApiFamily | None = None,
    target_family: ApiFamily,
) -> Any:
    """Convert a request payload between supported families."""

    resolved_source = source_family or detect_api_family(payload)
    if resolved_source == target_family:
        return copy.deepcopy(payload)
    canonical = _decode_request(payload, resolved_source)
    return _encode_request(canonical, target_family)


def convert_response(
    payload: Any,
    *,
    source_family: ApiFamily | None = None,
    target_family: ApiFamily,
) -> Any:
    """Convert a response payload between supported families."""

    resolved_source = source_family or detect_api_family(payload)
    if resolved_source == target_family:
        return copy.deepcopy(payload)
    decoded = _decode_response(payload, resolved_source)
    return _encode_response(decoded, target_family)


def convert_stream(
    stream: Iterable[dict[str, Any]],
    *,
    source_family: ApiFamily,
    target_family: ApiFamily,
) -> Iterator[dict[str, Any]]:
    """Convert provider stream frames through an OpenAI Chat-shaped stream pivot."""

    if source_family == target_family:
        yield from stream
        return

    state = _StreamConversionState()
    for frame in stream:
        for chat_frame in _stream_frame_to_openai_chat(frame, source_family, state):
            yield from _openai_chat_stream_frame_to_target(chat_frame, target_family, state)


class _StreamConversionState:
    def __init__(self) -> None:
        self.responses_tool_calls: dict[str, dict[str, Any]] = {}
        self.anthropic_tool_calls: dict[int, dict[str, Any]] = {}
        self.anthropic_stop_reason: str | None = None
        self.google_tool_calls: dict[int, dict[str, Any]] = {}
        self.chat_tool_calls: dict[int, dict[str, Any]] = {}
        self.pending_openai_usage: dict[str, int] | None = None


def _stream_frame_to_openai_chat(
    frame: dict[str, Any],
    source_family: ApiFamily,
    state: _StreamConversionState | None = None,
) -> list[dict[str, Any]]:
    if source_family == ApiFamily.openai_chat:
        return [frame]

    if source_family == ApiFamily.anthropic_messages:
        state = state or _StreamConversionState()
        frame_type = str(frame.get("type") or "")
        if frame_type == "content_block_start":
            block = frame.get("content_block") or {}
            if block.get("type") == "tool_use":
                return [_anthropic_tool_call_start_to_openai_chat(frame, block, state)]
        if frame_type == "content_block_delta":
            delta = frame.get("delta") or {}
            if delta.get("type") == "input_json_delta":
                return _anthropic_tool_call_delta_to_openai_chat(frame, delta, state)
            if delta.get("type") == "thinking_delta" and delta.get("thinking"):
                return [{"choices": [{"index": int(frame.get("index") or 0), "delta": {"reasoning_content": str(delta["thinking"])}}]}]
            text = delta.get("text")
            if text:
                return [{"choices": [{"index": int(frame.get("index") or 0), "delta": {"content": str(text)}}]}]
        if frame_type == "content_block_stop":
            index = int(frame.get("index") or 0)
            return _anthropic_tool_call_stop_to_openai_chat(index, state)
        if frame_type == "message_delta":
            delta = frame.get("delta") or {}
            if isinstance(delta, dict) and delta.get("stop_reason"):
                state.anthropic_stop_reason = str(delta["stop_reason"])
            if frame.get("usage"):
                usage = _decode_usage_from_anthropic(frame.get("usage"))
                return [{"usage": _usage_to_openai_usage(usage)}] if usage is not None else []
        if frame_type == "message_stop":
            return [{"choices": [{"index": 0, "delta": {}, "finish_reason": _anthropic_finish_reason_to_openai(state)}]}]
        return []

    if source_family == ApiFamily.openai_responses:
        state = state or _StreamConversionState()
        frame_type = str(frame.get("type") or frame.get("_sse_event") or "")
        if frame_type in {"response.output_text.delta", "response.refusal.delta"} and frame.get("delta"):
            return [{"choices": [{"index": int(frame.get("output_index") or 0), "delta": {"content": str(frame["delta"])}}]}]
        if frame_type in {"response.reasoning_summary_text.delta", "response.reasoning_text.delta"} and frame.get("delta"):
            return [{"choices": [{"index": int(frame.get("output_index") or 0), "delta": {"reasoning_content": str(frame["delta"])}}]}]
        if frame_type == "response.output_item.added":
            item = frame.get("item") or {}
            if item.get("type") == "function_call":
                return [_responses_tool_call_start_to_openai_chat(frame, item, state)]
        if frame_type == "response.function_call_arguments.delta":
            item_id = str(frame.get("item_id") or f"tool_{int(frame.get('output_index') or 0)}")
            tool_state = state.responses_tool_calls.setdefault(
                item_id,
                _responses_tool_call_state(frame, {"id": item_id}),
            )
            delta = str(frame.get("delta") or "")
            if delta:
                tool_state.setdefault("arguments_chunks", []).append(delta)
            return [
                {
                    "choices": [
                        {
                            "index": 0,
                            "delta": {
                                "tool_calls": [
                                    {
                                        "index": int(tool_state.get("output_index") or 0),
                                        "function": {"arguments": delta},
                                    }
                                ]
                            },
                        }
                    ]
                }
            ] if delta else []
        if frame_type == "response.output_item.done":
            item = frame.get("item") or {}
            if item.get("type") == "function_call":
                return _responses_tool_call_done_to_openai_chat(frame, item, state)
        if frame_type == "response.function_call_arguments.done":
            item_id = str(frame.get("item_id") or f"tool_{int(frame.get('output_index') or 0)}")
            item = {"id": item_id, "call_id": item_id, "type": "function_call", "name": frame.get("name"), "arguments": frame.get("arguments")}
            return _responses_tool_call_done_to_openai_chat(frame, item, state)
        if frame_type in {"response.completed", "response.incomplete"}:
            response = frame.get("response") or {}
            chat_frame = {
                "choices": [
                    {
                        "index": 0,
                        "delta": {},
                        "finish_reason": _responses_finish_reason(response, state),
                    }
                ]
            }
            usage = _decode_usage_from_openai_responses(response.get("usage"))
            if usage is not None:
                chat_frame["usage"] = _usage_to_openai_usage(usage)
            return [chat_frame]
        if frame_type in {"response.failed", "error"}:
            return [{"error": _stream_error_message(frame)}]
        return []

    if source_family == ApiFamily.google_genai:
        state = state or _StreamConversionState()
        result: list[dict[str, Any]] = []
        for index, candidate in enumerate(frame.get("candidates") or []):
            if not isinstance(candidate, dict):
                continue
            content = candidate.get("content") or {}
            for part in content.get("parts") or []:
                if not isinstance(part, dict):
                    continue
                function_call = part.get("functionCall") or part.get("function_call")
                if isinstance(function_call, dict):
                    result.append(_google_tool_call_to_openai_chat(function_call, index, state))
                    continue
                if "text" not in part:
                    continue
                delta_key = "reasoning_content" if part.get("thought") else "content"
                result.append({"choices": [{"index": index, "delta": {delta_key: str(part["text"])}}]})
            if candidate.get("finishReason"):
                result.append(
                    {
                        "choices": [
                            {
                                "index": index,
                                "delta": {},
                                "finish_reason": _google_finish_reason_to_openai(candidate.get("finishReason"), state),
                            }
                        ]
                    }
                )
        usage = _decode_usage_from_google_genai(frame.get("usageMetadata"))
        if usage is not None:
            openai_usage = _usage_to_openai_usage(usage)
            for item in reversed(result):
                choices = item.get("choices") or []
                if choices and any(isinstance(choice, dict) and choice.get("finish_reason") for choice in choices):
                    item["usage"] = openai_usage
                    break
            else:
                result.append({"usage": openai_usage})
        return result

    raise NotImplementedError(f"stream decoding for {source_family.value} is not implemented yet")


def _openai_chat_stream_frame_to_target(
    frame: dict[str, Any],
    target_family: ApiFamily,
    state: _StreamConversionState | None = None,
) -> list[dict[str, Any]]:
    if target_family == ApiFamily.openai_chat:
        return [frame]

    if target_family == ApiFamily.anthropic_messages:
        state = state or _StreamConversionState()
        result: list[dict[str, Any]] = []
        choices = frame.get("choices") or []
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            index = int(choice.get("index") or 0)
            delta = choice.get("delta") or {}
            result.extend(_openai_chat_tool_calls_to_anthropic(delta.get("tool_calls"), state))
            if delta.get("reasoning_content"):
                result.append(
                    {
                        "type": "content_block_delta",
                        "index": index,
                        "delta": {"type": "thinking_delta", "thinking": str(delta["reasoning_content"])},
                    }
                )
            if delta.get("content"):
                result.append(
                    {
                        "type": "content_block_delta",
                        "index": index,
                        "delta": {"type": "text_delta", "text": str(delta["content"])},
                    }
                )
            if choice.get("finish_reason"):
                result.extend(_complete_openai_chat_tool_calls_for_anthropic(state))
                message_delta: dict[str, Any] = {
                    "type": "message_delta",
                    "delta": {"stop_reason": _openai_finish_reason_to_anthropic(choice.get("finish_reason"))},
                }
                if frame.get("usage"):
                    message_delta["usage"] = _openai_usage_to_anthropic_usage(frame["usage"])
                result.append(message_delta)
                result.append({"type": "message_stop"})
        if frame.get("usage") and not choices:
            result.append({"type": "message_delta", "usage": _openai_usage_to_anthropic_usage(frame["usage"])})
        return result

    if target_family == ApiFamily.openai_responses:
        state = state or _StreamConversionState()
        result = []
        choices = frame.get("choices") or []
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            output_index = int(choice.get("index") or 0)
            delta = choice.get("delta") or {}
            result.extend(_openai_chat_tool_calls_to_responses(delta.get("tool_calls"), state))
            if delta.get("reasoning_content"):
                result.append(
                    {
                        "type": "response.reasoning_summary_text.delta",
                        "output_index": output_index,
                        "summary_index": 0,
                        "delta": str(delta["reasoning_content"]),
                    }
                )
            if delta.get("content"):
                result.append(
                    {
                        "type": "response.output_text.delta",
                        "output_index": output_index,
                        "content_index": 0,
                        "delta": str(delta["content"]),
                    }
                )
            if choice.get("finish_reason"):
                result.extend(_complete_openai_chat_tool_calls_for_responses(state))
                response: dict[str, Any] = {"status": "completed", "output": []}
                tool_outputs = _openai_chat_tool_call_outputs(state)
                if tool_outputs:
                    response["output"] = tool_outputs
                usage = frame.get("usage") or state.pending_openai_usage
                if usage:
                    response["usage"] = _openai_usage_to_responses_usage(usage)
                result.append({"type": "response.completed", "response": response})
        if frame.get("usage") and not choices:
            state.pending_openai_usage = frame["usage"]
        return result

    if target_family == ApiFamily.google_genai:
        state = state or _StreamConversionState()
        result = []
        choices = frame.get("choices") or []
        finished = False
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            delta = choice.get("delta") or {}
            parts = []
            parts.extend(_openai_chat_tool_calls_to_google(delta.get("tool_calls"), state))
            if choice.get("finish_reason"):
                finished = True
                parts.extend(_complete_openai_chat_tool_calls_for_google(state))
            if delta.get("reasoning_content"):
                parts.append({"text": str(delta["reasoning_content"]), "thought": True})
            if delta.get("content"):
                parts.append({"text": str(delta["content"])})
            candidate: dict[str, Any] = {"content": {"role": "model", "parts": parts}}
            if choice.get("finish_reason"):
                candidate["finishReason"] = _openai_finish_reason_to_google(choice.get("finish_reason"))
            if parts or choice.get("finish_reason"):
                result.append({"candidates": [candidate]})
        if frame.get("usage") and not choices:
            state.pending_openai_usage = frame["usage"]
        usage = frame.get("usage") or (state.pending_openai_usage if finished else None)
        if usage and (choices or finished):
            result.append({"usageMetadata": _openai_usage_to_google_usage(usage)})
            state.pending_openai_usage = None
        return result

    raise NotImplementedError(f"stream encoding for {target_family.value} is not implemented yet")


def _responses_tool_call_state(
    frame: dict[str, Any],
    item: dict[str, Any],
) -> dict[str, Any]:
    output_index = int(frame.get("output_index") or 0)
    item_id = str(item.get("id") or frame.get("item_id") or f"tool_{output_index}")
    return {
        "item_id": item_id,
        "call_id": str(item.get("call_id") or item.get("id") or item_id),
        "name": str(item.get("name") or ""),
        "output_index": output_index,
        "arguments_chunks": [],
        "started": True,
        "completed": False,
    }


def _anthropic_tool_call_start_to_openai_chat(
    frame: dict[str, Any],
    block: dict[str, Any],
    state: _StreamConversionState,
) -> dict[str, Any]:
    index = int(frame.get("index") or 0)
    arguments = block.get("input")
    arguments_text = "" if arguments in (None, {}) else _tool_arguments_text(arguments)
    state.anthropic_tool_calls[index] = {
        "id": str(block.get("id") or f"tool_{index}"),
        "name": str(block.get("name") or ""),
        "arguments_chunks": [arguments_text] if arguments_text else [],
        "completed": False,
    }
    return {
        "choices": [
            {
                "index": 0,
                "delta": {
                    "tool_calls": [
                        {
                            "index": index,
                            "id": state.anthropic_tool_calls[index]["id"],
                            "type": "function",
                            "function": {
                                "name": state.anthropic_tool_calls[index]["name"],
                                "arguments": arguments_text,
                            },
                        }
                    ]
                },
            }
        ]
    }


def _anthropic_tool_call_delta_to_openai_chat(
    frame: dict[str, Any],
    delta: dict[str, Any],
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    index = int(frame.get("index") or 0)
    tool_state = state.anthropic_tool_calls.setdefault(
        index,
        {"id": f"tool_{index}", "name": "", "arguments_chunks": [], "completed": False},
    )
    arguments_delta = str(delta.get("partial_json") or "")
    if not arguments_delta:
        return []
    tool_state.setdefault("arguments_chunks", []).append(arguments_delta)
    return [
        {
            "choices": [
                {
                    "index": 0,
                    "delta": {
                        "tool_calls": [
                            {
                                "index": index,
                                "function": {"arguments": arguments_delta},
                            }
                        ]
                    },
                }
            ]
        }
    ]


def _anthropic_tool_call_stop_to_openai_chat(
    index: int,
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    tool_state = state.anthropic_tool_calls.get(index)
    if tool_state is None:
        return []
    tool_state["completed"] = True
    return []


def _anthropic_finish_reason_to_openai(state: _StreamConversionState) -> str:
    stop_reason = (state.anthropic_stop_reason or "").strip()
    if stop_reason == "tool_use" or any(item.get("completed") for item in state.anthropic_tool_calls.values()):
        return "tool_calls"
    if stop_reason == "max_tokens":
        return "length"
    if stop_reason in {"stop_sequence", "end_turn"}:
        return "stop"
    return stop_reason or "stop"


def _google_tool_call_to_openai_chat(
    function_call: dict[str, Any],
    index: int,
    state: _StreamConversionState,
) -> dict[str, Any]:
    tool_call_id = str(function_call.get("id") or function_call.get("callId") or f"call_{index}")
    name = str(function_call.get("name") or "")
    arguments_text = _tool_arguments_text(function_call.get("args") or {})
    state.google_tool_calls[index] = {
        "id": tool_call_id,
        "name": name,
        "arguments": arguments_text,
    }
    return {
        "choices": [
            {
                "index": 0,
                "delta": {
                    "tool_calls": [
                        {
                            "index": index,
                            "id": tool_call_id,
                            "type": "function",
                            "function": {"name": name, "arguments": arguments_text},
                        }
                    ]
                },
            }
        ]
    }


def _responses_tool_call_start_to_openai_chat(
    frame: dict[str, Any],
    item: dict[str, Any],
    state: _StreamConversionState,
) -> dict[str, Any]:
    tool_state = _responses_tool_call_state(frame, item)
    state.responses_tool_calls[tool_state["item_id"]] = tool_state
    return {
        "choices": [
            {
                "index": 0,
                "delta": {
                    "tool_calls": [
                        {
                            "index": tool_state["output_index"],
                            "id": tool_state["call_id"],
                            "type": "function",
                            "function": {"name": tool_state["name"], "arguments": ""},
                        }
                    ]
                },
            }
        ]
    }


def _responses_tool_call_done_to_openai_chat(
    frame: dict[str, Any],
    item: dict[str, Any],
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    tool_state = state.responses_tool_calls.setdefault(
        str(item.get("id") or frame.get("item_id") or f"tool_{int(frame.get('output_index') or 0)}"),
        _responses_tool_call_state(frame, item),
    )
    if item.get("name"):
        tool_state["name"] = str(item["name"])
    arguments = str(item.get("arguments") or "")
    if not arguments or tool_state.get("arguments_chunks"):
        return []
    tool_state.setdefault("arguments_chunks", []).append(arguments)
    return [
        {
            "choices": [
                {
                    "index": 0,
                    "delta": {
                        "tool_calls": [
                            {
                                "index": int(tool_state.get("output_index") or 0),
                                "function": {"arguments": arguments},
                            }
                        ]
                    },
                }
            ]
        }
    ]


def _responses_finish_reason(response: dict[str, Any], state: _StreamConversionState) -> str:
    finish_reason = _finish_reason_from_openai_responses(response)
    if finish_reason:
        return finish_reason
    if state.responses_tool_calls:
        return "tool_calls"
    return "stop"


def _openai_chat_tool_calls_to_anthropic(
    raw_tool_calls: Any,
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    if not isinstance(raw_tool_calls, list):
        return result
    for raw_tool_call in raw_tool_calls:
        if not isinstance(raw_tool_call, dict):
            continue
        index = int(raw_tool_call.get("index") or 0)
        function = raw_tool_call.get("function") or {}
        tool_state = state.chat_tool_calls.setdefault(
            index,
            {
                "item_id": str(raw_tool_call.get("id") or f"tool_{index}"),
                "call_id": str(raw_tool_call.get("id") or f"tool_{index}"),
                "name": "",
                "output_index": index,
                "arguments_chunks": [],
                "started": False,
                "completed": False,
            },
        )
        if raw_tool_call.get("id"):
            tool_state["item_id"] = str(raw_tool_call["id"])
            tool_state["call_id"] = str(raw_tool_call["id"])
        if function.get("name"):
            tool_state["name"] = str(function["name"])
        if not tool_state["started"]:
            tool_state["started"] = True
            result.append(
                {
                    "type": "content_block_start",
                    "index": index,
                    "content_block": {
                        "type": "tool_use",
                        "id": tool_state["call_id"],
                        "name": tool_state["name"],
                        "input": {},
                    },
                }
            )
        arguments_delta = function.get("arguments")
        if arguments_delta:
            arguments_text = str(arguments_delta)
            tool_state.setdefault("arguments_chunks", []).append(arguments_text)
            result.append(
                {
                    "type": "content_block_delta",
                    "index": index,
                    "delta": {"type": "input_json_delta", "partial_json": arguments_text},
                }
            )
    return result


def _complete_openai_chat_tool_calls_for_anthropic(
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for index in sorted(state.chat_tool_calls):
        tool_state = state.chat_tool_calls[index]
        if tool_state["completed"] or not tool_state["started"]:
            continue
        result.append({"type": "content_block_stop", "index": index})
        tool_state["completed"] = True
    return result


def _openai_chat_tool_calls_to_google(
    raw_tool_calls: Any,
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    if not isinstance(raw_tool_calls, list):
        return result
    for raw_tool_call in raw_tool_calls:
        if not isinstance(raw_tool_call, dict):
            continue
        index = int(raw_tool_call.get("index") or 0)
        function = raw_tool_call.get("function") or {}
        tool_state = state.chat_tool_calls.setdefault(
            index,
            {
                "item_id": str(raw_tool_call.get("id") or f"tool_{index}"),
                "call_id": str(raw_tool_call.get("id") or f"tool_{index}"),
                "name": "",
                "output_index": index,
                "arguments_chunks": [],
                "started": False,
                "completed": False,
            },
        )
        if raw_tool_call.get("id"):
            tool_state["item_id"] = str(raw_tool_call["id"])
            tool_state["call_id"] = str(raw_tool_call["id"])
        if function.get("name"):
            tool_state["name"] = str(function["name"])
        arguments_delta = function.get("arguments")
        if arguments_delta:
            tool_state.setdefault("arguments_chunks", []).append(str(arguments_delta))
        argument_chunks = tool_state.get("arguments_chunks") or []
        if not argument_chunks:
            continue
        arguments = _json_loads_or_keep("".join(argument_chunks))
        if tool_state.get("google_emitted") or not isinstance(arguments, dict):
            continue
        result.append(
            {
                "functionCall": {
                    "id": tool_state["call_id"],
                    "name": tool_state["name"],
                    "args": arguments if isinstance(arguments, dict) else {},
                }
            }
        )
        tool_state["google_emitted"] = True
    return result


def _complete_openai_chat_tool_calls_for_google(
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for index in sorted(state.chat_tool_calls):
        tool_state = state.chat_tool_calls[index]
        if tool_state.get("google_emitted"):
            continue
        arguments = _json_loads_or_keep("".join(tool_state.get("arguments_chunks") or []))
        result.append(
            {
                "functionCall": {
                    "id": tool_state["call_id"],
                    "name": tool_state["name"],
                    "args": arguments if isinstance(arguments, dict) else {},
                }
            }
        )
        tool_state["google_emitted"] = True
    return result


def _openai_chat_tool_calls_to_responses(
    raw_tool_calls: Any,
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    if not isinstance(raw_tool_calls, list):
        return result

    for raw_tool_call in raw_tool_calls:
        if not isinstance(raw_tool_call, dict):
            continue
        index = int(raw_tool_call.get("index") or 0)
        function = raw_tool_call.get("function") or {}
        tool_state = state.chat_tool_calls.setdefault(
            index,
            {
                "item_id": str(raw_tool_call.get("id") or f"tool_{index}"),
                "call_id": str(raw_tool_call.get("id") or f"tool_{index}"),
                "name": "",
                "output_index": index,
                "arguments_chunks": [],
                "started": False,
                "completed": False,
            },
        )
        if raw_tool_call.get("id"):
            tool_state["item_id"] = str(raw_tool_call["id"])
            tool_state["call_id"] = str(raw_tool_call["id"])
        if function.get("name"):
            tool_state["name"] = str(function["name"])
        if not tool_state["started"] and (tool_state["call_id"] or tool_state["name"]):
            tool_state["started"] = True
            result.append(
                {
                    "type": "response.output_item.added",
                    "output_index": tool_state["output_index"],
                    "item": _openai_chat_tool_call_output_item(tool_state, arguments=""),
                }
            )

        arguments_delta = function.get("arguments")
        if arguments_delta:
            arguments_text = str(arguments_delta)
            tool_state.setdefault("arguments_chunks", []).append(arguments_text)
            result.append(
                {
                    "type": "response.function_call_arguments.delta",
                    "item_id": tool_state["item_id"],
                    "output_index": tool_state["output_index"],
                    "delta": arguments_text,
                }
            )
    return result


def _complete_openai_chat_tool_calls_for_responses(
    state: _StreamConversionState,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for index in sorted(state.chat_tool_calls):
        tool_state = state.chat_tool_calls[index]
        if tool_state["completed"] or not tool_state["started"]:
            continue
        arguments = "".join(tool_state.get("arguments_chunks") or [])
        result.append(
            {
                "type": "response.function_call_arguments.done",
                "item_id": tool_state["item_id"],
                "output_index": tool_state["output_index"],
                "name": tool_state["name"],
                "arguments": arguments,
            }
        )
        result.append(
            {
                "type": "response.output_item.done",
                "output_index": tool_state["output_index"],
                "item": _openai_chat_tool_call_output_item(tool_state, arguments=arguments),
            }
        )
        tool_state["completed"] = True
    return result


def _openai_chat_tool_call_outputs(state: _StreamConversionState) -> list[dict[str, Any]]:
    return [
        _openai_chat_tool_call_output_item(tool_state, arguments="".join(tool_state.get("arguments_chunks") or []))
        for _index, tool_state in sorted(state.chat_tool_calls.items())
        if tool_state["started"]
    ]


def _openai_chat_tool_call_output_item(
    tool_state: dict[str, Any],
    *,
    arguments: str,
) -> dict[str, Any]:
    return {
        "type": "function_call",
        "id": tool_state["item_id"],
        "call_id": tool_state["call_id"],
        "name": tool_state["name"],
        "arguments": arguments,
    }


def _tool_arguments_text(arguments: Any) -> str:
    if isinstance(arguments, str):
        return arguments
    return json_dumps(arguments or {})


def _usage_to_openai_usage(usage: Usage) -> dict[str, int]:
    return {
        "prompt_tokens": usage.input_tokens,
        "completion_tokens": usage.output_tokens,
        "total_tokens": usage.total_tokens or (usage.input_tokens + usage.output_tokens),
    }


def _openai_usage_to_responses_usage(raw_usage: Any) -> dict[str, int]:
    usage = _decode_usage_from_openai(raw_usage)
    if usage is None:
        return {}
    return {
        "input_tokens": usage.input_tokens,
        "output_tokens": usage.output_tokens,
        "total_tokens": usage.total_tokens,
    }


def _openai_usage_to_google_usage(raw_usage: Any) -> dict[str, int]:
    usage = _decode_usage_from_openai(raw_usage)
    if usage is None:
        return {}
    return {
        "promptTokenCount": usage.input_tokens,
        "candidatesTokenCount": usage.output_tokens,
        "totalTokenCount": usage.total_tokens,
    }


def _stream_error_message(frame: dict[str, Any]) -> str:
    error = frame.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error)
    response = frame.get("response")
    if isinstance(response, dict) and isinstance(response.get("error"), dict):
        return str(response["error"].get("message") or response["error"])
    return str(error or frame)


def _google_finish_reason_to_openai(value: Any, state: _StreamConversionState | None = None) -> str:
    if state is not None and state.google_tool_calls:
        return "tool_calls"
    normalized = str(value or "").strip().upper()
    if normalized == "MAX_TOKENS":
        return "length"
    if normalized in {"STOP", "FINISH_REASON_STOP"}:
        return "stop"
    if normalized in {"SAFETY", "RECITATION", "BLOCKLIST", "PROHIBITED_CONTENT"}:
        return "content_filter"
    return normalized.lower() if normalized else "stop"


def _openai_finish_reason_to_google(value: Any) -> str:
    normalized = str(value or "").strip().lower()
    if normalized == "length":
        return "MAX_TOKENS"
    if normalized == "content_filter":
        return "SAFETY"
    return "STOP"


def _openai_finish_reason_to_anthropic(value: Any) -> str:
    normalized = str(value or "").strip().lower()
    if normalized == "tool_calls":
        return "tool_use"
    if normalized == "length":
        return "max_tokens"
    if normalized == "content_filter":
        return "stop_sequence"
    return "end_turn"


def _openai_usage_to_anthropic_usage(raw_usage: Any) -> dict[str, int]:
    usage = _decode_usage_from_openai(raw_usage)
    if usage is None:
        return {}
    return {
        "input_tokens": usage.input_tokens,
        "output_tokens": usage.output_tokens,
    }


def _decode_request(payload: Any, source_family: ApiFamily) -> ModelRequest:
    if not isinstance(payload, dict):
        raise ProtocolError("Request payload must be a dict.")
    if source_family == ApiFamily.openai_chat:
        return _decode_openai_chat_request(payload)
    if source_family == ApiFamily.openai_responses:
        return _decode_openai_responses_request(payload)
    if source_family == ApiFamily.anthropic_messages:
        return _decode_anthropic_request(payload)
    if source_family == ApiFamily.google_genai:
        return _decode_google_genai_request(payload)
    raise NotImplementedError(f"request decoding for {source_family.value} is not implemented yet")


def _encode_request(request: ModelRequest, target_family: ApiFamily) -> dict[str, Any]:
    if target_family == ApiFamily.openai_chat:
        return _encode_openai_chat_request(request)
    if target_family == ApiFamily.openai_responses:
        return _encode_openai_responses_request(request)
    if target_family == ApiFamily.anthropic_messages:
        return _encode_anthropic_request(request)
    if target_family == ApiFamily.google_genai:
        return _encode_google_genai_request(request)
    raise NotImplementedError(f"request encoding for {target_family.value} is not implemented yet")


def _decode_response(payload: Any, source_family: ApiFamily) -> DecodedResponse:
    if not isinstance(payload, dict):
        raise ProtocolError("Response payload must be a dict.")
    if source_family == ApiFamily.openai_chat:
        return _decode_openai_chat_response(payload)
    if source_family == ApiFamily.openai_responses:
        return _decode_openai_responses_response(payload)
    if source_family == ApiFamily.anthropic_messages:
        return _decode_anthropic_response(payload)
    if source_family == ApiFamily.google_genai:
        return _decode_google_genai_response(payload)
    raise NotImplementedError(f"response decoding for {source_family.value} is not implemented yet")


def _encode_response(response: DecodedResponse, target_family: ApiFamily) -> dict[str, Any]:
    if target_family == ApiFamily.openai_chat:
        return _encode_openai_chat_response(response)
    if target_family == ApiFamily.openai_responses:
        return _encode_openai_responses_response(response)
    if target_family == ApiFamily.anthropic_messages:
        return _encode_anthropic_response(response)
    if target_family == ApiFamily.google_genai:
        return _encode_google_genai_response(response)
    raise NotImplementedError(f"response encoding for {target_family.value} is not implemented yet")


def _looks_like_anthropic_messages_payload(payload: dict[str, Any]) -> bool:
    raw_messages = [item for item in payload.get("messages", []) if isinstance(item, dict)]
    raw_tools = payload.get("tools") or []
    if any(_is_openai_tool_spec(tool) for tool in raw_tools):
        return False
    if any(_is_anthropic_tool_spec(tool) for tool in raw_tools):
        return True

    tool_choice = payload.get("tool_choice")
    if _is_openai_tool_choice(tool_choice):
        return False
    if isinstance(tool_choice, dict) and tool_choice.get("type") in {"auto", "any", "tool", "none"}:
        return True

    saw_ambiguous_text_blocks = False
    for raw_message in raw_messages:
        content = raw_message.get("content")
        if not isinstance(content, list):
            continue
        classification = _classify_message_blocks(content)
        if classification == "anthropic":
            return True
        if classification == "openai":
            return False
        if classification == "ambiguous_text":
            saw_ambiguous_text_blocks = True

    model_name = str(payload.get("model") or "").strip().lower()
    if saw_ambiguous_text_blocks and model_name.startswith("claude") and "/" not in model_name:
        return True

    return False


def _is_anthropic_tool_spec(tool: Any) -> bool:
    return isinstance(tool, dict) and "name" in tool and "input_schema" in tool


def _is_openai_tool_spec(tool: Any) -> bool:
    return (
        isinstance(tool, dict)
        and tool.get("type") == "function"
        and isinstance(tool.get("function"), dict)
    )


def _is_openai_tool_choice(tool_choice: Any) -> bool:
    if isinstance(tool_choice, str):
        return True
    if isinstance(tool_choice, dict) and tool_choice.get("type") == "function":
        return True
    return False


def _classify_message_blocks(content: list[Any]) -> str | None:
    saw_text_block = False
    for part in content:
        if not isinstance(part, dict):
            continue
        part_type = part.get("type")
        if part_type in {"tool_use", "tool_result", "thinking", "redacted_thinking"}:
            return "anthropic"
        if part_type == "image" and "source" in part:
            return "anthropic"
        if part_type == "document" and "source" in part:
            return "anthropic"
        if part_type in {"image_url", "input_text", "input_image", "input_audio", "input_file", "file"}:
            return "openai"
        if part_type == "text":
            saw_text_block = True
    if saw_text_block:
        return "ambiguous_text"
    return None
