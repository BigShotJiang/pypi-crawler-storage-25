"""msgspec-backed JSON helpers for core protocol hot paths."""

from __future__ import annotations

from typing import Any

import msgspec

_JSON_ENCODER = msgspec.json.Encoder()


def json_loads(data: str | bytes | bytearray | memoryview) -> Any:
    """Decode JSON using msgspec."""

    return msgspec.json.decode(data)


def json_dumps(value: Any) -> str:
    """Encode JSON using msgspec and return text for provider payload fields."""

    return _JSON_ENCODER.encode(value).decode()


def json_loads_or_keep(value: Any) -> Any:
    """Decode a JSON string, returning the original value when it is not JSON."""

    if not isinstance(value, str):
        return value
    text = value.strip()
    if not text:
        return {}
    try:
        return json_loads(text)
    except msgspec.DecodeError:
        return value
