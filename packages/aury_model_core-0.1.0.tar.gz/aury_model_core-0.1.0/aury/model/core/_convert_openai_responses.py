"""OpenAI Responses codec helpers."""

from __future__ import annotations

import time
from typing import Any

from .analysis import ModelRequest
from .canonical import (
    AssetRef,
    AssetSourceType,
    AudioPart,
    DocumentPart,
    FilePart,
    ImagePart,
    Message,
    Role,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolResultPart,
    msg,
)
from .errors import UnsupportedModalityError
from .families import ApiFamily
from .options import CallOptions, ReasoningOptions, StreamOptions
from ._convert_common import (
    DecodedResponse,
    _asset_from_value,
    _asset_to_urlish,
    _coerce_role,
    _json_loads_or_keep,
    _parse_tool_output,
    _stringify_output,
)
from ._convert_openai_shared import (
    _decode_openai_tools,
    _decode_response_spec_from_openai_responses,
    _decode_usage_from_openai_responses,
    _encode_openai_responses_text_format,
    _encode_usage_for_openai_responses,
)
from ._json import json_dumps


def _decode_openai_responses_request(payload: dict[str, Any]) -> ModelRequest:
    messages: list[Message] = []
    instructions = payload.get("instructions")
    if instructions:
        messages.append(msg.system(str(instructions)))

    raw_input = payload.get("input")
    if isinstance(raw_input, str):
        if raw_input:
            messages.append(msg.user(raw_input))
    elif isinstance(raw_input, dict):
        messages.extend(_decode_openai_responses_input_items([raw_input]))
    elif isinstance(raw_input, list):
        messages.extend(_decode_openai_responses_input_items(raw_input))

    tools = _decode_openai_tools(payload.get("tools"))
    response_spec = _decode_response_spec_from_openai_responses(
        payload.get("text") or payload.get("response_format")
    )

    return ModelRequest(
        messages=messages,
        options=CallOptions(
            model=payload.get("model"),
            api_family=ApiFamily.openai_responses,
            tools=tools or None,
            tool_choice=_decode_openai_responses_tool_choice(payload.get("tool_choice")),
            reasoning=_decode_reasoning_from_openai_responses(payload.get("reasoning")),
            response=response_spec,
            stream=StreamOptions(enabled=True) if payload.get("stream") else None,
            max_tokens=payload.get("max_output_tokens") or payload.get("max_tokens"),
            temperature=payload.get("temperature"),
            top_p=payload.get("top_p"),
            metadata=payload.get("metadata") or {},
            native=_extract_openai_responses_native_fields(payload),
        ),
    )


def _encode_openai_responses_request(request: ModelRequest) -> dict[str, Any]:
    options = request.options
    result: dict[str, Any] = {"model": options.model or ""}
    instructions: list[str] = []
    input_items: list[dict[str, Any]] = []

    for message in request.messages:
        if message.role == Role.system:
            if message.text:
                instructions.append(message.text)
            continue
        if message.role == Role.developer:
            if message.text:
                instructions.append(f"[developer]\n{message.text}")
            continue
        input_items.extend(_encode_openai_responses_message_items(message))

    result["input"] = input_items if input_items else ""

    if instructions:
        result["instructions"] = "\n\n".join(instructions)
    if options.tools:
        result["tools"] = [
            {
                "type": "function",
                "name": tool.function.name,
                "description": tool.function.description or "",
                "parameters": tool.function.parameters,
            }
            for tool in options.tools
        ]
    if options.tool_choice is not None:
        result["tool_choice"] = _encode_openai_responses_tool_choice(options.tool_choice)
    if options.reasoning:
        reasoning = _encode_openai_responses_reasoning(options.reasoning)
        if reasoning:
            result["reasoning"] = reasoning
    if options.response:
        result["text"] = _encode_openai_responses_text_format(options.response)
    if options.stream and options.stream.enabled is not False:
        result["stream"] = True
    if options.max_tokens is not None:
        result["max_output_tokens"] = options.max_tokens
    if options.temperature is not None:
        result["temperature"] = options.temperature
    if options.top_p is not None:
        result["top_p"] = options.top_p
    if options.metadata:
        result["metadata"] = {str(key): str(value) for key, value in options.metadata.items()}
    if options.extra_body:
        result.update(options.extra_body)
    if options.native:
        result.update(options.native)

    return result


def _decode_openai_responses_response(payload: dict[str, Any]) -> DecodedResponse:
    output = payload.get("output") or []
    message = Message(
        role=Role.assistant,
        parts=_decode_openai_responses_output_items(output),
    )
    return DecodedResponse(
        message=message,
        model=payload.get("model"),
        response_id=payload.get("id"),
        usage=_decode_usage_from_openai_responses(payload.get("usage")),
        finish_reason=_finish_reason_from_openai_responses(payload),
    )


def _encode_openai_responses_response(response: DecodedResponse) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "id": response.response_id or "resp_converted",
        "object": "response",
        "created_at": int(time.time()),
        "status": "completed",
        "model": response.model or "unknown",
        "output": _encode_openai_responses_output_items(response.message),
    }
    if response.usage:
        payload["usage"] = _encode_usage_for_openai_responses(response.usage)
    return payload


def _decode_openai_responses_input_items(raw_items: list[Any]) -> list[Message]:
    messages: list[Message] = []
    assistant_parts: list[Any] = []

    def flush_assistant() -> None:
        nonlocal assistant_parts
        if assistant_parts:
            messages.append(Message(role=Role.assistant, parts=assistant_parts))
            assistant_parts = []

    for raw in raw_items:
        if isinstance(raw, str):
            flush_assistant()
            if raw:
                messages.append(msg.user(raw))
            continue
        if not isinstance(raw, dict):
            continue

        item_type = raw.get("type")
        if item_type in {None, "message"} and raw.get("role"):
            role = _coerce_role(str(raw.get("role") or "user"))
            parts = _decode_openai_responses_content(raw.get("content"))
            if role == Role.assistant:
                assistant_parts.extend(parts)
            else:
                flush_assistant()
                messages.append(Message(role=role, parts=parts))
            continue
        if item_type == "function_call":
            assistant_parts.append(
                ToolCallPart(
                    id=str(raw.get("call_id") or raw.get("id") or ""),
                    name=str(raw.get("name") or ""),
                    arguments=_json_loads_or_keep(raw.get("arguments")),
                )
            )
            continue
        if item_type == "function_call_output":
            flush_assistant()
            messages.append(
                Message(
                    role=Role.user,
                    parts=[
                        ToolResultPart(
                            tool_call_id=str(raw.get("call_id") or ""),
                            output=_parse_tool_output(raw.get("output")),
                        )
                    ],
                    metadata={"source_role": "tool"},
                )
            )
            continue
        if item_type == "reasoning":
            thinking_text = _decode_openai_responses_reasoning_text(raw)
            if thinking_text:
                assistant_parts.append(ThinkingPart(text=thinking_text))
    flush_assistant()
    return messages


def _decode_openai_responses_output_items(raw_items: Any) -> list[Any]:
    if not isinstance(raw_items, list):
        return []

    parts: list[Any] = []
    for raw in raw_items:
        if not isinstance(raw, dict):
            continue
        item_type = raw.get("type")
        if item_type == "message":
            parts.extend(_decode_openai_responses_content(raw.get("content")))
        elif item_type == "reasoning":
            thinking_text = _decode_openai_responses_reasoning_text(raw)
            if thinking_text:
                parts.append(ThinkingPart(text=thinking_text))
        elif item_type == "function_call":
            parts.append(
                ToolCallPart(
                    id=str(raw.get("call_id") or raw.get("id") or ""),
                    name=str(raw.get("name") or ""),
                    arguments=_json_loads_or_keep(raw.get("arguments")),
                )
            )
        elif item_type == "function_call_output":
            parts.append(
                ToolResultPart(
                    tool_call_id=str(raw.get("call_id") or ""),
                    output=_parse_tool_output(raw.get("output")),
                )
            )
    return parts


def _decode_openai_responses_content(content: Any) -> list[Any]:
    if content is None:
        return []
    if isinstance(content, str):
        return [TextPart(text=content)] if content else []
    if not isinstance(content, list):
        return [TextPart(text=str(content))]

    parts: list[Any] = []
    for item in content:
        if isinstance(item, str):
            parts.append(TextPart(text=item))
            continue
        if not isinstance(item, dict):
            parts.append(TextPart(text=str(item)))
            continue

        item_type = item.get("type")
        if item_type in {"text", "input_text", "output_text"}:
            parts.append(TextPart(text=str(item.get("text") or "")))
        elif item_type == "refusal":
            parts.append(TextPart(text=str(item.get("refusal") or "")))
        elif item_type in {"image", "input_image"}:
            if item.get("file_id"):
                parts.append(
                    ImagePart(
                        asset=AssetRef(
                            kind="image",
                            source_type=AssetSourceType.file_id,
                            value=str(item["file_id"]),
                        ),
                        detail=item.get("detail"),
                    )
                )
                continue
            image_value = item.get("image_url") or item.get("image") or item.get("url")
            if image_value:
                parts.append(
                    ImagePart(
                        asset=_asset_from_value("image", str(image_value)),
                        detail=item.get("detail"),
                    )
                )
        elif item_type in {"file", "input_file"}:
            file_value = item.get("file_id") or item.get("file_url") or item.get("file")
            if file_value:
                if item.get("file_id"):
                    parts.append(
                        FilePart(
                            asset=AssetRef(
                                kind="file",
                                source_type=AssetSourceType.file_id,
                                value=str(item["file_id"]),
                            )
                        )
                    )
                else:
                    parts.append(FilePart(asset=_asset_from_value("file", str(file_value))))
        elif item_type in {"audio", "input_audio"}:
            audio_value = item.get("audio")
            if audio_value:
                parts.append(AudioPart(asset=_asset_from_value("audio", str(audio_value))))
        else:
            parts.append(TextPart(text=json_dumps(item)))
    return parts


def _encode_openai_responses_message_items(message: Message) -> list[dict[str, Any]]:
    leading_items: list[dict[str, Any]] = []
    trailing_items: list[dict[str, Any]] = []
    message_content: list[dict[str, Any]] = []

    for part in message.parts:
        if isinstance(part, TextPart):
            if message.role == Role.assistant:
                message_content.append({"type": "output_text", "text": part.text})
            else:
                message_content.append({"type": "input_text", "text": part.text})
        elif isinstance(part, ImagePart):
            image_item: dict[str, Any] = {"type": "input_image"}
            if part.asset.source_type == AssetSourceType.file_id:
                image_item["file_id"] = part.asset.value
            else:
                image_item["image_url"] = _asset_to_urlish(part.asset)
            if part.detail:
                image_item["detail"] = part.detail
            message_content.append(image_item)
        elif isinstance(part, FilePart):
            file_item: dict[str, Any] = {"type": "input_file"}
            if part.asset.source_type == AssetSourceType.file_id:
                file_item["file_id"] = part.asset.value
            else:
                file_item["file_url"] = _asset_to_urlish(part.asset)
            message_content.append(file_item)
        elif isinstance(part, AudioPart):
            raise UnsupportedModalityError(
                "openai_responses encoding currently supports text, image, file, reasoning, and tool parts only"
            )
        elif isinstance(part, ThinkingPart):
            leading_items.append(
                {
                    "type": "reasoning",
                    "summary": [{"type": "summary_text", "text": part.text}],
                }
            )
        elif isinstance(part, ToolCallPart):
            trailing_items.append(
                {
                    "type": "function_call",
                    "call_id": part.id,
                    "name": part.name,
                    "arguments": part.arguments_json,
                }
            )
        elif isinstance(part, ToolResultPart):
            target_items = leading_items if message.role == Role.user else trailing_items
            target_items.append(
                {
                    "type": "function_call_output",
                    "call_id": part.tool_call_id,
                    "output": _stringify_output(part.output),
                }
            )
        elif isinstance(part, DocumentPart):
            raise UnsupportedModalityError(
                "openai_responses encoding currently supports text, image, file, reasoning, and tool parts only"
            )

    items: list[dict[str, Any]] = list(leading_items)
    if message_content:
        items.append(
            {
                "type": "message",
                "role": message.role.value,
                "content": message_content,
            }
        )
    items.extend(trailing_items)
    return items


def _decode_openai_responses_tool_choice(value: Any) -> Any:
    if isinstance(value, str):
        return value
    if isinstance(value, dict) and value.get("type") == "function":
        name = value.get("name")
        if not name and isinstance(value.get("function"), dict):
            name = value["function"].get("name")
        if name:
            return {"type": "function", "function": {"name": str(name)}}
    return value


def _encode_openai_responses_tool_choice(value: Any) -> Any:
    if isinstance(value, str):
        return "required" if value == "any" else value
    if isinstance(value, dict):
        choice_type = value.get("type")
        if choice_type in {"auto", "none"}:
            return choice_type
        if choice_type == "any":
            return "required"
        if choice_type in {"function", "tool"}:
            name = value.get("name")
            if not name and isinstance(value.get("function"), dict):
                name = value["function"].get("name")
            if name:
                return {"type": "function", "name": str(name)}
            return "required"
    return value


def _decode_reasoning_from_openai_responses(raw_reasoning: Any) -> ReasoningOptions | None:
    if not isinstance(raw_reasoning, dict):
        return None
    reasoning_type = raw_reasoning.get("type")
    enabled = None
    if reasoning_type == "enabled":
        enabled = True
    elif reasoning_type == "disabled":
        enabled = False
    budget_tokens = raw_reasoning.get("budget_tokens") or raw_reasoning.get("max_tokens")
    if (
        enabled is None
        and raw_reasoning.get("effort") is None
        and budget_tokens is None
        and not raw_reasoning.get("summary")
    ):
        return None
    return ReasoningOptions(
        enabled=enabled,
        effort=raw_reasoning.get("effort"),
        budget_tokens=budget_tokens,
        return_thinking=bool(raw_reasoning.get("summary")),
    )


def _encode_openai_responses_reasoning(reasoning: ReasoningOptions) -> dict[str, Any] | None:
    payload: dict[str, Any] = {}
    if reasoning.enabled is False:
        payload["type"] = "disabled"
    elif reasoning.enabled is True or reasoning.effort or reasoning.return_thinking:
        payload["type"] = "enabled"
    if reasoning.effort:
        payload["effort"] = reasoning.effort
    if reasoning.return_thinking:
        payload["summary"] = "auto"
    return payload or None


def _decode_openai_responses_reasoning_text(item: Any) -> str:
    if not isinstance(item, dict):
        return ""
    segments: list[str] = []
    for key in ("summary", "content"):
        value = item.get(key)
        if isinstance(value, str):
            if value:
                segments.append(value)
            continue
        if not isinstance(value, list):
            continue
        for part in value:
            if not isinstance(part, dict):
                continue
            text = part.get("text")
            if text:
                segments.append(str(text))
    direct_text = item.get("text")
    if direct_text:
        segments.append(str(direct_text))
    return "\n".join(segment for segment in segments if segment)


def _finish_reason_from_openai_responses(payload: dict[str, Any]) -> str | None:
    output = payload.get("output")
    if isinstance(output, list) and any(
        isinstance(item, dict) and item.get("type") == "function_call" for item in output
    ):
        return "tool_calls"
    status = payload.get("status")
    if status == "completed":
        return "stop"
    if isinstance(payload.get("incomplete_details"), dict):
        reason = payload["incomplete_details"].get("reason")
        if reason:
            return str(reason)
    return str(status) if status else None


def _encode_openai_responses_output_items(message: Message) -> list[dict[str, Any]]:
    return _encode_openai_responses_message_items(message)


def _extract_openai_responses_native_fields(payload: dict[str, Any]) -> dict[str, Any]:
    known_fields = {
        "model",
        "instructions",
        "input",
        "tools",
        "tool_choice",
        "reasoning",
        "text",
        "response_format",
        "stream",
        "max_output_tokens",
        "max_tokens",
        "temperature",
        "top_p",
        "metadata",
    }
    return {
        key: value
        for key, value in payload.items()
        if key not in known_fields
    }
