"""OpenAI Chat codec helpers."""

from __future__ import annotations

import time
from typing import Any

from .analysis import ModelRequest
from .canonical import (
    AudioPart,
    DocumentPart,
    FilePart,
    ImagePart,
    Message,
    Role,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolResultPart,
)
from .errors import ProtocolError, UnsupportedModalityError
from .families import ApiFamily
from .options import CallOptions, ReasoningOptions, StreamOptions
from ._convert_common import (
    DecodedResponse,
    _asset_from_value,
    _asset_to_urlish,
    _coerce_role,
    _json_loads_or_keep,
    _parse_tool_output,
    _stringify_output,
)
from ._convert_openai_shared import (
    _decode_openai_tools,
    _decode_response_spec_from_openai,
    _decode_usage_from_openai,
    _encode_openai_response_format,
)
from ._json import json_dumps


def _decode_openai_chat_request(payload: dict[str, Any]) -> ModelRequest:
    messages: list[Message] = []
    for raw in payload.get("messages", []):
        if not isinstance(raw, dict):
            continue
        role = str(raw.get("role") or "user")
        if role == "tool":
            messages.append(
                Message(
                    role=Role.user,
                    parts=[
                        ToolResultPart(
                            tool_call_id=str(raw.get("tool_call_id") or ""),
                            output=_parse_tool_output(raw.get("content")),
                        )
                    ],
                    metadata={"source_role": "tool"},
                )
            )
            continue

        parts = _decode_openai_content(raw.get("content"))
        if role == "assistant":
            reasoning = raw.get("reasoning_content") or _openai_reasoning_details_text(raw.get("reasoning_details"))
            if reasoning:
                parts.insert(0, ThinkingPart(text=str(reasoning)))
            for tool_call in raw.get("tool_calls") or []:
                if not isinstance(tool_call, dict):
                    continue
                fn = tool_call.get("function") or {}
                parts.append(
                    ToolCallPart(
                        id=str(tool_call.get("id") or ""),
                        name=str(fn.get("name") or ""),
                        arguments=_json_loads_or_keep(fn.get("arguments")),
                    )
                )
        messages.append(
            Message(
                role=_coerce_role(role),
                parts=parts,
                metadata={},
            )
        )

    tools = _decode_openai_tools(payload.get("tools"))
    response_spec = _decode_response_spec_from_openai(payload.get("response_format"))

    return ModelRequest(
        messages=messages,
        options=CallOptions(
            model=payload.get("model"),
            api_family=ApiFamily.openai_chat,
            tools=tools or None,
            tool_choice=payload.get("tool_choice"),
            reasoning=(
                ReasoningOptions(effort=str(payload["reasoning_effort"]))
                if payload.get("reasoning_effort")
                else None
            ),
            response=response_spec,
            stream=(
                StreamOptions(
                    enabled=True,
                    include_usage=bool(
                        (payload.get("stream_options") or {}).get("include_usage", True)
                    ),
                )
                if payload.get("stream")
                else None
            ),
            max_tokens=payload.get("max_tokens") or payload.get("max_completion_tokens"),
            temperature=payload.get("temperature"),
            top_p=payload.get("top_p"),
            stop=payload.get("stop"),
            seed=payload.get("seed"),
        ),
    )


def _encode_openai_chat_request(request: ModelRequest) -> dict[str, Any]:
    options = request.options
    result: dict[str, Any] = {"model": options.model or ""}
    messages: list[dict[str, Any]] = []

    for message in request.messages:
        messages.extend(_encode_openai_chat_message(message))

    result["messages"] = messages

    if options.tools:
        result["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": tool.function.name,
                    "description": tool.function.description or "",
                    "parameters": tool.function.parameters,
                },
            }
            for tool in options.tools
        ]
    if options.tool_choice is not None:
        result["tool_choice"] = options.tool_choice
    if options.reasoning and options.reasoning.effort:
        result["reasoning_effort"] = options.reasoning.effort
    if options.response:
        result["response_format"] = _encode_openai_response_format(options.response)
    if options.stream and options.stream.enabled is not False:
        result["stream"] = True
        result["stream_options"] = {"include_usage": options.stream.include_usage}
    if options.max_tokens is not None:
        result["max_tokens"] = options.max_tokens
    if options.temperature is not None:
        result["temperature"] = options.temperature
    if options.top_p is not None:
        result["top_p"] = options.top_p
    if options.stop is not None:
        result["stop"] = options.stop
    if options.seed is not None:
        result["seed"] = options.seed
    if options.extra_body:
        result.update(options.extra_body)
    if options.native:
        result.update(options.native)

    return result


def _decode_openai_chat_response(payload: dict[str, Any]) -> DecodedResponse:
    choices = payload.get("choices") or []
    if not choices:
        raise ProtocolError("OpenAI chat response has no choices.")
    choice = choices[0]
    raw_message = choice.get("message") or {}
    message = _decode_openai_chat_request({"messages": [raw_message]}).messages[0]
    return DecodedResponse(
        message=Message(role=Role.assistant, parts=message.parts, metadata=message.metadata),
        model=payload.get("model"),
        response_id=payload.get("id"),
        usage=_decode_usage_from_openai(payload.get("usage")),
        finish_reason=choice.get("finish_reason"),
    )


def _encode_openai_chat_response(response: DecodedResponse) -> dict[str, Any]:
    assistant_messages = _encode_openai_chat_message(response.message)
    assistant_message = next(
        (message for message in assistant_messages if message.get("role") == "assistant"),
        {"role": "assistant", "content": ""},
    )
    payload: dict[str, Any] = {
        "id": response.response_id or "converted-chatcmpl",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": response.model or "unknown",
        "choices": [
            {
                "index": 0,
                "message": assistant_message,
                "finish_reason": response.finish_reason or "stop",
            }
        ],
    }
    if response.usage:
        payload["usage"] = {
            "prompt_tokens": response.usage.input_tokens,
            "completion_tokens": response.usage.output_tokens,
            "total_tokens": response.usage.total_tokens or (
                response.usage.input_tokens + response.usage.output_tokens
            ),
        }
    return payload


def _decode_openai_content(content: Any) -> list[Any]:
    if content is None:
        return []
    if isinstance(content, str):
        return [TextPart(text=content)] if content else []
    if not isinstance(content, list):
        return [TextPart(text=str(content))]

    parts: list[Any] = []
    for item in content:
        if isinstance(item, str):
            parts.append(TextPart(text=item))
            continue
        if not isinstance(item, dict):
            parts.append(TextPart(text=str(item)))
            continue

        item_type = item.get("type")
        if item_type in {"text", "input_text"}:
            parts.append(TextPart(text=str(item.get("text") or "")))
        elif item_type in {"image_url", "input_image"}:
            image_url = item.get("image_url")
            url = image_url.get("url") if isinstance(image_url, dict) else image_url
            if url:
                parts.append(ImagePart(asset=_asset_from_value("image", str(url))))
        elif item_type in {"input_file", "file"}:
            file_id = item.get("file_id")
            file_url = item.get("file_url")
            file_value = file_id or file_url
            if file_value:
                asset = _asset_from_value("file", str(file_value))
                parts.append(FilePart(asset=asset))
        elif item_type == "input_audio":
            audio = item.get("audio") or {}
            audio_value = audio.get("url") or audio.get("data")
            if audio_value:
                parts.append(AudioPart(asset=_asset_from_value("audio", str(audio_value))))
        else:
            parts.append(TextPart(text=json_dumps(item)))
    return parts


def _encode_openai_chat_message(message: Message) -> list[dict[str, Any]]:
    if message.role == Role.user:
        return _encode_openai_user_message(message)

    provider_messages: list[dict[str, Any]] = []
    normal_parts = [part for part in message.parts if not isinstance(part, ToolResultPart)]
    tool_results = [part for part in message.parts if isinstance(part, ToolResultPart)]

    if normal_parts or message.role != Role.user or not tool_results:
        encoded_message: dict[str, Any] = {"role": message.role.value}
        if message.role == Role.assistant:
            thinking = "".join(
                part.text for part in normal_parts if isinstance(part, ThinkingPart)
            )
            tool_calls = [
                {
                    "id": part.id,
                    "type": "function",
                    "function": {
                        "name": part.name,
                        "arguments": part.arguments_json,
                    },
                }
                for part in normal_parts
                if isinstance(part, ToolCallPart)
            ]
            encoded_content = _encode_openai_content_parts(
                [
                    part
                    for part in normal_parts
                    if not isinstance(part, (ThinkingPart, ToolCallPart))
                ]
            )
            encoded_message["content"] = encoded_content
            if tool_calls:
                encoded_message["tool_calls"] = tool_calls
            if thinking:
                encoded_message["reasoning_content"] = thinking
        else:
            encoded_message["content"] = _encode_openai_content_parts(normal_parts)
        provider_messages.append(encoded_message)

    for part in tool_results:
        provider_messages.append(
            {
                "role": "tool",
                "tool_call_id": part.tool_call_id,
                "content": _stringify_output(part.output),
            }
        )

    return provider_messages


def _openai_reasoning_details_text(raw: Any) -> str | None:
    if not isinstance(raw, list):
        return None
    chunks: list[str] = []
    for item in raw:
        if isinstance(item, dict) and item.get("text"):
            chunks.append(str(item["text"]))
    if not chunks:
        return None
    return "".join(chunks)


def _encode_openai_user_message(message: Message) -> list[dict[str, Any]]:
    provider_messages: list[dict[str, Any]] = []
    pending_parts: list[Any] = []

    def flush_user_parts() -> None:
        if not pending_parts:
            return
        provider_messages.append(
            {
                "role": "user",
                "content": _encode_openai_content_parts(list(pending_parts)),
            }
        )
        pending_parts.clear()

    for part in message.parts:
        if isinstance(part, ToolResultPart):
            flush_user_parts()
            provider_messages.append(
                {
                    "role": "tool",
                    "tool_call_id": part.tool_call_id,
                    "content": _stringify_output(part.output),
                }
            )
            continue
        pending_parts.append(part)

    flush_user_parts()
    return provider_messages


def _encode_openai_content_parts(parts: list[Any]) -> str | list[dict[str, Any]] | None:
    if not parts:
        return None
    if all(isinstance(part, TextPart) for part in parts):
        return "".join(part.text for part in parts)

    content: list[dict[str, Any]] = []
    for part in parts:
        if isinstance(part, TextPart):
            content.append({"type": "text", "text": part.text})
        elif isinstance(part, ImagePart):
            content.append(
                {
                    "type": "image_url",
                    "image_url": {"url": _asset_to_urlish(part.asset)},
                }
            )
        elif isinstance(part, (DocumentPart, AudioPart, FilePart)):
            raise UnsupportedModalityError(
                "openai_chat encoding currently supports text and image parts only"
            )
    return content
