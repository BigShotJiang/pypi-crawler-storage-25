"""Typed error taxonomy for aury-model-core."""

from __future__ import annotations


class ModelCoreError(RuntimeError):
    """Base class for model-core errors."""


class TransportError(ModelCoreError):
    """Base class for transport and remote execution errors."""


class ProtocolError(ModelCoreError):
    """Raised when protocol payloads are invalid or unsupported."""


class UnsupportedModalityError(ModelCoreError):
    """Raised when a modality cannot be encoded for a target family."""


class TransportNotConfiguredError(ModelCoreError):
    """Raised when invoke/stream is called without an execution backend."""


class StructuredParseError(ModelCoreError):
    """Raised when structured output parsing fails."""


class ProviderHTTPError(TransportError):
    """Raised when a provider returns a non-success HTTP response."""

    def __init__(self, status_code: int, body: str, *, url: str | None = None) -> None:
        self.status_code = status_code
        self.body = body
        self.url = url
        target = f" from {url}" if url else ""
        body_preview = body.strip()[:400]
        super().__init__(f"Provider returned HTTP {status_code}{target}: {body_preview}")
