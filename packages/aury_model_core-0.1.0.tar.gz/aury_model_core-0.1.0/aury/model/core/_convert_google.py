"""Google GenAI codec helpers."""

from __future__ import annotations

import re
from typing import Any

from .analysis import ModelRequest
from .canonical import (
    AssetRef,
    AssetSourceType,
    AudioPart,
    DocumentPart,
    FilePart,
    FunctionToolSpec,
    ImagePart,
    Message,
    Role,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolResultPart,
    ToolSpec,
    Usage,
    msg,
)
from .errors import ProtocolError, UnsupportedModalityError
from .families import ApiFamily
from .options import CallOptions, ReasoningOptions, StructuredOutputMethod, StructuredOutputSpec
from ._convert_common import (
    DecodedResponse,
    _default_mime_for_kind,
    _first_defined,
    _google_inline_data_to_data_url,
    _json_loads_or_keep,
    _kind_from_mime,
    _parse_tool_output,
    _part_from_asset_kind,
    _schema_to_json_schema,
    _coerce_role,
)
from ._json import json_dumps


def _decode_google_genai_request(payload: dict[str, Any]) -> ModelRequest:
    messages: list[Message] = []
    config = _google_genai_request_config(payload)
    system_instruction = (
        payload.get("systemInstruction")
        or payload.get("system_instruction")
        or config.get("systemInstruction")
        or config.get("system_instruction")
    )
    system_text = _google_system_to_text(system_instruction)
    if system_text:
        messages.append(msg.system(system_text))

    messages.extend(_decode_google_genai_contents(payload.get("contents")))

    return ModelRequest(
        messages=messages,
        options=CallOptions(
            model=payload.get("model"),
            api_family=ApiFamily.google_genai,
            tools=_decode_google_genai_tools(config.get("tools") or payload.get("tools")) or None,
            tool_choice=_decode_google_genai_tool_choice(
                _first_defined(
                    config.get("toolConfig"),
                    config.get("tool_config"),
                    payload.get("toolConfig"),
                    payload.get("tool_config"),
                )
            ),
            reasoning=_decode_reasoning_from_google_genai(
                _first_defined(
                    config.get("thinkingConfig"),
                    config.get("thinking_config"),
                    payload.get("thinkingConfig"),
                    payload.get("thinking_config"),
                )
            ),
            response=_decode_response_spec_from_google_genai(config),
            max_tokens=_first_defined(
                config.get("maxOutputTokens"),
                config.get("max_output_tokens"),
                payload.get("maxOutputTokens"),
                payload.get("max_output_tokens"),
            ),
            temperature=_first_defined(config.get("temperature"), payload.get("temperature")),
            top_p=_first_defined(
                config.get("topP"),
                config.get("top_p"),
                payload.get("topP"),
                payload.get("top_p"),
            ),
            stop=_first_defined(
                config.get("stopSequences"),
                config.get("stop_sequences"),
                payload.get("stopSequences"),
                payload.get("stop_sequences"),
            ),
            native=_extract_google_genai_native_fields(payload),
        ),
    )


def _encode_google_genai_request(request: ModelRequest) -> dict[str, Any]:
    options = request.options
    result: dict[str, Any] = {"model": options.model or ""}
    config: dict[str, Any] = {}
    system_lines: list[str] = []
    contents: list[dict[str, Any]] = []
    tool_name_by_call_id: dict[str, str] = {}

    for message in request.messages:
        if message.role == Role.system:
            if message.text:
                system_lines.append(message.text)
            continue
        if message.role == Role.developer:
            if message.text:
                system_lines.append(f"[developer]\n{message.text}")
            continue
        contents.append(
            _encode_google_genai_content(message, tool_name_by_call_id=tool_name_by_call_id)
        )
        for part in message.parts:
            if isinstance(part, ToolCallPart) and part.id:
                tool_name_by_call_id[part.id] = part.name

    result["contents"] = contents if contents else []

    if system_lines:
        config["systemInstruction"] = "\n\n".join(system_lines)
    if options.tools:
        config["tools"] = _encode_google_genai_tools(options.tools)
    if options.tool_choice is not None:
        tool_config = _encode_google_genai_tool_choice(options.tool_choice)
        if tool_config:
            config["toolConfig"] = tool_config
    if options.reasoning:
        thinking_config = _encode_google_genai_reasoning(options.reasoning)
        if thinking_config:
            config["thinkingConfig"] = thinking_config
    if options.response:
        config.update(_encode_google_genai_response_format(options.response))
    if options.max_tokens is not None:
        config["maxOutputTokens"] = options.max_tokens
    if options.temperature is not None:
        config["temperature"] = options.temperature
    if options.top_p is not None:
        config["topP"] = options.top_p
    if options.stop is not None:
        config["stopSequences"] = options.stop if isinstance(options.stop, list) else [options.stop]
    if options.extra_body:
        result.update(options.extra_body)
    if options.native:
        native = dict(options.native)
        native_config = native.pop("config", None)
        if isinstance(native_config, dict):
            config.update(native_config)
        result.update(native)
    if config:
        result["config"] = config

    return result


def _decode_google_genai_response(payload: dict[str, Any]) -> DecodedResponse:
    candidates = payload.get("candidates") or []
    if candidates:
        candidate = candidates[0] if isinstance(candidates[0], dict) else {}
        content = candidate.get("content") or {}
        message = Message(
            role=Role.assistant,
            parts=_decode_google_genai_parts(content.get("parts"), role=str(content.get("role") or "model")),
        )
        finish_reason = _finish_reason_from_google_genai(candidate, message.parts)
    else:
        message = Message(role=Role.assistant, parts=[])
        prompt_feedback = payload.get("promptFeedback") or {}
        finish_reason = str(prompt_feedback.get("blockReason") or "blocked").lower()

    return DecodedResponse(
        message=message,
        model=payload.get("modelVersion") or payload.get("model"),
        response_id=payload.get("responseId"),
        usage=_decode_usage_from_google_genai(payload.get("usageMetadata")),
        finish_reason=finish_reason,
    )


def _encode_google_genai_response(response: DecodedResponse) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "responseId": response.response_id or "google_resp_converted",
        "candidates": [
            {
                "content": _encode_google_genai_content(
                    Message(role=Role.assistant, parts=response.message.parts)
                ),
                "finishReason": _encode_google_genai_finish_reason(response.finish_reason, response.message.parts),
            }
        ],
        "modelVersion": response.model or "unknown",
    }
    if response.usage:
        payload["usageMetadata"] = _encode_usage_for_google_genai(response.usage)
    return payload


def _decode_google_genai_contents(raw_contents: Any) -> list[Message]:
    if raw_contents is None:
        return []
    if isinstance(raw_contents, str):
        return [msg.user(raw_contents)] if raw_contents else []
    if isinstance(raw_contents, dict):
        return [_decode_google_genai_content(raw_contents, content_index=0)]
    if not isinstance(raw_contents, list):
        return [msg.user(str(raw_contents))]

    messages: list[Message] = []
    for index, raw_content in enumerate(raw_contents):
        if isinstance(raw_content, str):
            if raw_content:
                messages.append(msg.user(raw_content))
            continue
        if isinstance(raw_content, dict):
            messages.append(_decode_google_genai_content(raw_content, content_index=index))
    return messages


def _decode_google_genai_content(raw_content: dict[str, Any], *, content_index: int) -> Message:
    role = str(raw_content.get("role") or "user")
    parts = _decode_google_genai_parts(raw_content.get("parts"), role=role, content_index=content_index)
    metadata = {"source_role": role} if role == "function" else {}
    return Message(role=_coerce_google_genai_role(role), parts=parts, metadata=metadata)


def _encode_google_genai_content(
    message: Message,
    *,
    tool_name_by_call_id: dict[str, str] | None = None,
) -> dict[str, Any]:
    all_tool_results = bool(message.parts) and all(
        isinstance(part, ToolResultPart) for part in message.parts
    )
    if message.metadata.get("source_role") in {"function", "tool"} and all_tool_results:
        role = "function"
    elif message.role == Role.assistant:
        role = "model"
    else:
        role = "user"
    return {
        "role": role,
        "parts": _encode_google_genai_parts(
            message.parts,
            tool_name_by_call_id=tool_name_by_call_id,
        ),
    }


def _decode_google_genai_parts(
    raw_parts: Any,
    *,
    role: str,
    content_index: int = 0,
) -> list[Any]:
    if raw_parts is None:
        return []
    if isinstance(raw_parts, str):
        return [TextPart(text=raw_parts)] if raw_parts else []
    if not isinstance(raw_parts, list):
        return [TextPart(text=str(raw_parts))]

    parts: list[Any] = []
    for part_index, item in enumerate(raw_parts):
        if isinstance(item, str):
            parts.append(TextPart(text=item))
            continue
        if not isinstance(item, dict):
            parts.append(TextPart(text=str(item)))
            continue
        if "functionCall" in item:
            function_call = item.get("functionCall") or {}
            name = str(function_call.get("name") or "")
            call_id = str(
                function_call.get("id")
                or function_call.get("callId")
                or item.get("callId")
                or item.get("id")
                or name
                or f"call_{content_index}_{part_index}"
            )
            parts.append(
                ToolCallPart(
                    id=call_id,
                    name=name,
                    arguments=function_call.get("args"),
                    provider_metadata=_google_part_provider_metadata(item),
                )
            )
            continue
        if "functionResponse" in item:
            function_response = item.get("functionResponse") or {}
            tool_call_id = str(
                function_response.get("id")
                or function_response.get("callId")
                or item.get("id")
                or item.get("callId")
                or function_response.get("name")
                or f"call_{content_index}_{part_index}"
            )
            parts.append(
                ToolResultPart(
                    tool_call_id=tool_call_id,
                    output=_decode_google_genai_function_response_output(function_response.get("response")),
                )
            )
            continue
        if "text" in item:
            text = str(item.get("text") or "")
            if item.get("thought"):
                parts.append(
                    ThinkingPart(
                        text=text,
                        signature=item.get("thoughtSignature") or item.get("thought_signature"),
                        provider_metadata=_google_part_provider_metadata(item),
                    )
                )
            else:
                parts.append(TextPart(text=text))
            continue
        if "inlineData" in item or "inline_data" in item:
            part = _decode_google_genai_binary_part(item.get("inlineData") or item.get("inline_data"))
            if part is not None:
                parts.append(part)
            continue
        if "fileData" in item or "file_data" in item:
            part = _decode_google_genai_file_part(item.get("fileData") or item.get("file_data"))
            if part is not None:
                parts.append(part)
            continue
        parts.append(TextPart(text=json_dumps(item)))
    return parts


def _encode_google_genai_parts(
    parts: list[Any],
    *,
    tool_name_by_call_id: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    encoded: list[dict[str, Any]] = []
    tool_name_by_call_id = tool_name_by_call_id or {}
    for part in parts:
        if isinstance(part, TextPart):
            encoded.append({"text": part.text})
        elif isinstance(part, ThinkingPart):
            item: dict[str, Any] = {"text": part.text, "thought": True}
            if part.signature:
                item["thoughtSignature"] = part.signature
            encoded.append(item)
        elif isinstance(part, ToolCallPart):
            item = {
                "functionCall": {
                    "id": part.id,
                    "name": part.name,
                    "args": _json_loads_or_keep(part.arguments_json),
                }
            }
            if part.provider_metadata.get("thoughtSignature"):
                item["thoughtSignature"] = part.provider_metadata["thoughtSignature"]
            encoded.append(item)
        elif isinstance(part, ToolResultPart):
            function_name = tool_name_by_call_id.get(part.tool_call_id) or part.tool_call_id
            encoded.append(
                {
                    "functionResponse": {
                        "id": part.tool_call_id,
                        "name": function_name,
                        "response": _encode_google_genai_function_response_output(part.output),
                    }
                }
            )
        elif isinstance(part, (ImagePart, AudioPart, DocumentPart, FilePart)):
            encoded.append(_encode_google_genai_asset_part(part))
    return encoded


def _decode_usage_from_google_genai(raw_usage: Any) -> Usage | None:
    if not isinstance(raw_usage, dict):
        return None
    input_tokens = int(raw_usage.get("promptTokenCount") or 0)
    output_tokens = int(raw_usage.get("candidatesTokenCount") or 0)
    total_tokens = int(raw_usage.get("totalTokenCount") or (input_tokens + output_tokens))
    return Usage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        reasoning_tokens=int(raw_usage.get("thoughtsTokenCount") or 0),
        cache_read_tokens=int(raw_usage.get("cachedContentTokenCount") or 0),
        total_tokens=total_tokens,
    )


def _decode_response_spec_from_google_genai(config: dict[str, Any]) -> StructuredOutputSpec | None:
    if not isinstance(config, dict):
        return None
    schema = (
        config.get("responseJsonSchema")
        or config.get("response_json_schema")
        or config.get("responseSchema")
        or config.get("response_schema")
    )
    if isinstance(schema, dict):
        return StructuredOutputSpec(schema=schema, method=StructuredOutputMethod.json_schema)

    mime_type = str(
        config.get("responseMimeType")
        or config.get("response_mime_type")
        or ""
    ).lower()
    if mime_type == "application/json":
        return StructuredOutputSpec(schema={}, method=StructuredOutputMethod.json_mode)
    return None


def _encode_google_genai_response_format(spec: StructuredOutputSpec) -> dict[str, Any]:
    if spec.method == StructuredOutputMethod.json_mode:
        return {"responseMimeType": "application/json"}
    if spec.method in {
        StructuredOutputMethod.auto,
        StructuredOutputMethod.json_schema,
        StructuredOutputMethod.function_calling,
    }:
        return {
            "responseMimeType": "application/json",
            "responseJsonSchema": _schema_to_json_schema(spec.schema_),
        }
    return {}


def _decode_google_genai_tool_choice(value: Any) -> Any:
    if not isinstance(value, dict):
        return None
    function_calling = value.get("functionCallingConfig") or value.get("function_calling_config")
    if not isinstance(function_calling, dict):
        return None
    mode = str(function_calling.get("mode") or "").upper()
    allowed = function_calling.get("allowedFunctionNames") or function_calling.get("allowed_function_names") or []
    if mode == "NONE":
        return "none"
    if mode == "ANY":
        if isinstance(allowed, list) and len(allowed) == 1 and allowed[0]:
            return {"type": "function", "function": {"name": str(allowed[0])}}
        return "required"
    if mode in {"AUTO", "VALIDATED"}:
        if isinstance(allowed, list) and len(allowed) == 1 and allowed[0]:
            return {"type": "function", "function": {"name": str(allowed[0])}}
        return "auto"
    return None


def _encode_google_genai_tool_choice(value: Any) -> dict[str, Any] | None:
    if isinstance(value, str):
        mode = {
            "auto": "AUTO",
            "none": "NONE",
            "required": "ANY",
            "any": "ANY",
        }.get(value)
        if mode:
            return {"functionCallingConfig": {"mode": mode}}
        return {
            "functionCallingConfig": {"mode": "ANY", "allowedFunctionNames": [value]}
        }
    if isinstance(value, dict):
        choice_type = value.get("type")
        if choice_type in {"function", "tool"}:
            name = value.get("name")
            if not name and isinstance(value.get("function"), dict):
                name = value["function"].get("name")
            if name:
                return {
                    "functionCallingConfig": {
                        "mode": "ANY",
                        "allowedFunctionNames": [str(name)],
                    }
                }
        if choice_type == "any":
            return {"functionCallingConfig": {"mode": "ANY"}}
        if choice_type in {"auto", "none"}:
            return {"functionCallingConfig": {"mode": str(choice_type).upper()}}
    return None


def _decode_reasoning_from_google_genai(raw_reasoning: Any) -> ReasoningOptions | None:
    if not isinstance(raw_reasoning, dict):
        return None
    budget_tokens = _first_defined(
        raw_reasoning.get("thinkingBudget"),
        raw_reasoning.get("thinking_budget"),
    )
    level = _first_defined(
        raw_reasoning.get("thinkingLevel"),
        raw_reasoning.get("thinking_level"),
    )
    include_thoughts = _first_defined(
        raw_reasoning.get("includeThoughts"),
        raw_reasoning.get("include_thoughts"),
    )
    enabled = None
    if budget_tokens == 0:
        enabled = False
    elif budget_tokens is not None or level is not None or include_thoughts is not None:
        enabled = True
    if enabled is None:
        return None
    effort = str(level).lower() if isinstance(level, str) else None
    return ReasoningOptions(
        enabled=enabled,
        effort=effort if effort in {"minimal", "low", "medium", "high"} else None,
        budget_tokens=budget_tokens,
        return_thinking=bool(include_thoughts),
    )


def _encode_google_genai_reasoning(reasoning: ReasoningOptions) -> dict[str, Any] | None:
    payload: dict[str, Any] = {}
    if reasoning.enabled is False:
        payload["thinkingBudget"] = 0
    elif reasoning.budget_tokens is not None:
        payload["thinkingBudget"] = reasoning.budget_tokens
    if reasoning.effort:
        payload["thinkingLevel"] = reasoning.effort.upper()
    if reasoning.return_thinking:
        payload["includeThoughts"] = True
    return payload or None


def _encode_usage_for_google_genai(usage: Usage) -> dict[str, Any]:
    return {
        "promptTokenCount": usage.input_tokens,
        "cachedContentTokenCount": usage.cache_read_tokens,
        "candidatesTokenCount": usage.output_tokens,
        "thoughtsTokenCount": usage.reasoning_tokens,
        "totalTokenCount": usage.total_tokens or (usage.input_tokens + usage.output_tokens),
    }


def _extract_google_genai_native_fields(payload: dict[str, Any]) -> dict[str, Any]:
    known_top_level = {
        "model",
        "contents",
        "config",
        "generationConfig",
        "generation_config",
        "systemInstruction",
        "system_instruction",
        "tools",
        "toolConfig",
        "tool_config",
        "temperature",
        "topP",
        "top_p",
        "maxOutputTokens",
        "max_output_tokens",
        "stopSequences",
        "stop_sequences",
        "thinkingConfig",
        "thinking_config",
    }
    native = {
        key: value
        for key, value in payload.items()
        if key not in known_top_level
    }

    config = _google_genai_request_config(payload)
    known_config = {
        "systemInstruction",
        "system_instruction",
        "tools",
        "toolConfig",
        "tool_config",
        "thinkingConfig",
        "thinking_config",
        "responseMimeType",
        "response_mime_type",
        "responseJsonSchema",
        "response_json_schema",
        "responseSchema",
        "response_schema",
        "temperature",
        "topP",
        "top_p",
        "maxOutputTokens",
        "max_output_tokens",
        "stopSequences",
        "stop_sequences",
    }
    native_config = {
        key: value
        for key, value in config.items()
        if key not in known_config
    }
    if native_config:
        native["config"] = native_config
    return native


def _google_genai_request_config(payload: dict[str, Any]) -> dict[str, Any]:
    config: dict[str, Any] = {}
    for key in ("generationConfig", "generation_config", "config"):
        raw = payload.get(key)
        if isinstance(raw, dict):
            config.update(raw)
    return config


def _decode_google_genai_tools(raw_tools: Any) -> list[ToolSpec]:
    if not isinstance(raw_tools, list):
        return []
    tools: list[ToolSpec] = []
    for raw_tool in raw_tools:
        if not isinstance(raw_tool, dict):
            continue
        declarations = raw_tool.get("functionDeclarations") or raw_tool.get("function_declarations") or []
        if not isinstance(declarations, list):
            continue
        for declaration in declarations:
            if not isinstance(declaration, dict):
                continue
            name = declaration.get("name")
            if not name:
                continue
            parameters = (
                declaration.get("parameters")
                or declaration.get("parametersJsonSchema")
                or declaration.get("parameters_json_schema")
                or {"type": "object", "properties": {}}
            )
            tools.append(
                ToolSpec(
                    function=FunctionToolSpec(
                        name=str(name),
                        description=declaration.get("description"),
                        parameters=parameters,
                    )
                )
            )
    return tools


def _encode_google_genai_tools(tools: list[ToolSpec]) -> list[dict[str, Any]]:
    return [
        {
            "functionDeclarations": [
                {
                    "name": tool.function.name,
                    "description": tool.function.description or "",
                    "parameters": tool.function.parameters,
                }
            ]
        }
        for tool in tools
    ]


def _google_system_to_text(system: Any) -> str:
    if isinstance(system, str):
        return system
    if isinstance(system, dict):
        parts = _decode_google_genai_parts(system.get("parts"), role=str(system.get("role") or "user"))
        return "".join(part.text for part in parts if isinstance(part, (TextPart, ThinkingPart)))
    if isinstance(system, list):
        return "\n".join(_google_system_to_text(item) for item in system if item)
    return str(system) if system is not None else ""


def _decode_google_genai_binary_part(raw_inline_data: Any) -> ImagePart | AudioPart | DocumentPart | FilePart | None:
    if not isinstance(raw_inline_data, dict):
        return None
    mime_type = raw_inline_data.get("mimeType") or raw_inline_data.get("mime_type")
    data = raw_inline_data.get("data")
    if not mime_type or not data:
        return None
    data_url = _google_inline_data_to_data_url(str(mime_type), str(data))
    kind = _kind_from_mime(str(mime_type))
    asset = AssetRef(
        kind=kind,
        source_type=AssetSourceType.data_url,
        value=data_url,
        mime_type=str(mime_type),
    )
    return _part_from_asset_kind(kind, asset)


def _decode_google_genai_file_part(raw_file_data: Any) -> ImagePart | AudioPart | DocumentPart | FilePart | None:
    if not isinstance(raw_file_data, dict):
        return None
    file_uri = raw_file_data.get("fileUri") or raw_file_data.get("file_uri") or raw_file_data.get("uri")
    mime_type = raw_file_data.get("mimeType") or raw_file_data.get("mime_type")
    if not file_uri:
        return None
    kind = _kind_from_mime(str(mime_type or ""))
    asset = AssetRef(
        kind=kind,
        source_type=AssetSourceType.url,
        value=str(file_uri),
        mime_type=str(mime_type) if mime_type else None,
    )
    return _part_from_asset_kind(kind, asset)


def _encode_google_genai_asset_part(
    part: ImagePart | AudioPart | DocumentPart | FilePart,
) -> dict[str, Any]:
    asset = part.asset
    if asset.source_type == AssetSourceType.data_url:
        match = re.match(r"^data:(?P<mime>[^;]+);base64,(?P<data>.+)$", asset.value, re.DOTALL)
        if not match:
            raise ProtocolError("Invalid data_url asset for google_genai encoding.")
        return {
            "inlineData": {
                "mimeType": match.group("mime"),
                "data": match.group("data"),
            }
        }
    if asset.source_type == AssetSourceType.url:
        return {
            "fileData": {
                "fileUri": asset.value,
                "mimeType": asset.mime_type or _default_mime_for_kind(asset.kind),
            }
        }
    raise UnsupportedModalityError(
        f"google_genai does not directly encode asset source_type={asset.source_type}"
    )


def _google_part_provider_metadata(item: dict[str, Any]) -> dict[str, Any]:
    metadata: dict[str, Any] = {}
    thought_signature = item.get("thoughtSignature") or item.get("thought_signature")
    if thought_signature:
        metadata["thoughtSignature"] = str(thought_signature)
    return metadata


def _decode_google_genai_function_response_output(response: Any) -> Any:
    if isinstance(response, dict):
        if set(response) == {"output"}:
            return _parse_tool_output(response.get("output"))
        if set(response) == {"result"}:
            return response.get("result")
    return response


def _encode_google_genai_function_response_output(output: Any) -> Any:
    if isinstance(output, dict):
        return output
    if isinstance(output, list):
        return {"output": output}
    return {"output": output}


def _finish_reason_from_google_genai(candidate: dict[str, Any], parts: list[Any]) -> str | None:
    if any(isinstance(part, ToolCallPart) for part in parts):
        return "tool_calls"
    finish_reason = str(candidate.get("finishReason") or "").upper()
    mapping = {
        "STOP": "stop",
        "MAX_TOKENS": "length",
    }
    if finish_reason in mapping:
        return mapping[finish_reason]
    return finish_reason.lower() if finish_reason else None


def _encode_google_genai_finish_reason(finish_reason: str | None, parts: list[Any]) -> str:
    if any(isinstance(part, ToolCallPart) for part in parts):
        return "STOP"
    mapping = {
        None: "STOP",
        "stop": "STOP",
        "length": "MAX_TOKENS",
    }
    return mapping.get(finish_reason, str(finish_reason or "STOP").upper())


def _coerce_google_genai_role(value: str) -> Role:
    if value == "model":
        return Role.assistant
    return _coerce_role(value)
