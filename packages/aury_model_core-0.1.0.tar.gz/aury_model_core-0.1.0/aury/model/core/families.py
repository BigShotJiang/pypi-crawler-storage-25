"""Protocol-family definitions."""

from __future__ import annotations

from enum import StrEnum


class ApiFamily(StrEnum):
    """Supported first-class request/response protocol families."""

    openai_chat = "openai_chat"
    openai_responses = "openai_responses"
    anthropic_messages = "anthropic_messages"
    google_genai = "google_genai"
