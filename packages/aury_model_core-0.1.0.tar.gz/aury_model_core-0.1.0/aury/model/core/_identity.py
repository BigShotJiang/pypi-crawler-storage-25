"""Stable identity helpers for snapshots, replay, and cache keys."""

from __future__ import annotations

from typing import Any

import xxhash

from ._json import json_dumps


def stable_id(prefix: str, payload: dict[str, Any]) -> str:
    digest = xxhash.xxh3_128_hexdigest(json_dumps(json_fingerprintable(payload)).encode())
    return f"{prefix}_{digest}"


def json_fingerprintable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).hex()
    if isinstance(value, dict):
        return {str(key): json_fingerprintable(item) for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [json_fingerprintable(item) for item in value]
    if isinstance(value, type):
        return {"__type__": f"{value.__module__}.{value.__qualname__}"}
    if hasattr(value, "model_dump"):
        return json_fingerprintable(value.model_dump(mode="python"))
    return repr(value)
