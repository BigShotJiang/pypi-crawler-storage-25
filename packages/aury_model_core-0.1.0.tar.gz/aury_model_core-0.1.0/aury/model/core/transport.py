"""Built-in HTTP transport for first-wave protocol families."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import Any, Callable

import httpx

from .analysis import CompiledRequest, ModelRequest
from .canonical import Evt, Message, StreamEvent, TextPart, ThinkingPart, ToolCallPart
from ._identity import json_fingerprintable
from .convert import (
    _decode_response,
    _decode_usage_from_anthropic,
    _decode_usage_from_openai,
    _decode_usage_from_openai_responses,
    _encode_request,
    _finish_reason_from_openai_responses,
    _json_loads_or_keep,
)
from ._convert_google import _decode_usage_from_google_genai, _finish_reason_from_google_genai
from ._transport_dialects import BuiltinTransportDialectPolicy, resolve_transport_dialect_policy
from .errors import ProtocolError, ProviderHTTPError, TransportNotConfiguredError
from .families import ApiFamily
from ._json import json_loads
from .options import CallOptions, StreamOptions

TransportObserver = Callable[[str, dict[str, Any]], None]


def invoke_http(
    compiled: CompiledRequest,
    *,
    transport: Any | None = None,
    observer: TransportObserver | None = None,
) -> Message:
    policy = _transport_policy(compiled)
    request_options = _materialize_transport_options(compiled.options, stream=False)
    payload = _encode_transport_payload(compiled, request_options, policy=policy, stream=False)
    url = _resolve_endpoint_url(request_options, policy=policy, stream=False)
    headers = _build_headers(request_options, policy=policy, stream=False)

    _emit_transport_start(observer, url=url, headers=headers, stream=False)
    with httpx.Client(transport=transport, timeout=_timeout(request_options.timeout)) as client:
        response = client.post(url, json=payload, headers=headers)
        _emit_response_headers(observer, response)
        body = _read_json_response(response)
    body = policy.normalize_response_payload(body, compiled, request_options, stream=False)
    return _decode_response(body, compiled.route.api_family).message


async def ainvoke_http(
    compiled: CompiledRequest,
    *,
    transport: Any | None = None,
    observer: TransportObserver | None = None,
) -> Message:
    policy = _transport_policy(compiled)
    request_options = _materialize_transport_options(compiled.options, stream=False)
    payload = _encode_transport_payload(compiled, request_options, policy=policy, stream=False)
    url = _resolve_endpoint_url(request_options, policy=policy, stream=False)
    headers = _build_headers(request_options, policy=policy, stream=False)

    _emit_transport_start(observer, url=url, headers=headers, stream=False)
    async with httpx.AsyncClient(transport=transport, timeout=_timeout(request_options.timeout)) as client:
        response = await client.post(url, json=payload, headers=headers)
        _emit_response_headers(observer, response)
        body = _read_json_response(response)
    body = policy.normalize_response_payload(body, compiled, request_options, stream=False)
    return _decode_response(body, compiled.route.api_family).message


def stream_http(
    compiled: CompiledRequest,
    *,
    transport: Any | None = None,
    observer: TransportObserver | None = None,
) -> Iterator[StreamEvent]:
    policy = _transport_policy(compiled)
    decoder = _stream_decoder(compiled.route.api_family)
    request_options = _materialize_transport_options(compiled.options, stream=True)
    frame_normalizer = policy.stream_frame_normalizer(compiled, request_options)
    payload = _encode_transport_payload(compiled, request_options, policy=policy, stream=True)
    url = _resolve_endpoint_url(request_options, policy=policy, stream=True)
    headers = _build_headers(request_options, policy=policy, stream=True)
    include_raw_frames = bool(request_options.stream and request_options.stream.include_raw_frames)

    def iterator() -> Iterator[StreamEvent]:
        _emit_transport_start(observer, url=url, headers=headers, stream=True)
        with httpx.Client(transport=transport, timeout=_timeout(request_options.timeout)) as client:
            with client.stream("POST", url, json=payload, headers=headers) as response:
                _emit_response_headers(observer, response)
                _raise_for_status(response)
                for frame in _iter_sse_frames(response.iter_lines()):
                    normalized_frames = (
                        frame_normalizer.feed(frame)
                        if frame_normalizer is not None
                        else [frame]
                    )
                    for normalized_frame in normalized_frames:
                        for event in _decode_stream_frame(
                            decoder,
                            normalized_frame,
                            raw_frame=frame,
                            include_raw_frames=include_raw_frames,
                        ):
                            yield event
                if frame_normalizer is not None:
                    for normalized_frame in frame_normalizer.finish():
                        for event in _decode_stream_frame(
                            decoder,
                            normalized_frame,
                            raw_frame=None,
                            include_raw_frames=include_raw_frames,
                        ):
                            yield event
                for event in decoder.finish():
                    yield event

    return iterator()


def astream_http(
    compiled: CompiledRequest,
    *,
    transport: Any | None = None,
    observer: TransportObserver | None = None,
) -> AsyncIterator[StreamEvent]:
    policy = _transport_policy(compiled)
    decoder = _stream_decoder(compiled.route.api_family)
    request_options = _materialize_transport_options(compiled.options, stream=True)
    frame_normalizer = policy.stream_frame_normalizer(compiled, request_options)
    payload = _encode_transport_payload(compiled, request_options, policy=policy, stream=True)
    url = _resolve_endpoint_url(request_options, policy=policy, stream=True)
    headers = _build_headers(request_options, policy=policy, stream=True)
    include_raw_frames = bool(request_options.stream and request_options.stream.include_raw_frames)

    async def iterator() -> AsyncIterator[StreamEvent]:
        _emit_transport_start(observer, url=url, headers=headers, stream=True)
        async with httpx.AsyncClient(transport=transport, timeout=_timeout(request_options.timeout)) as client:
            async with client.stream("POST", url, json=payload, headers=headers) as response:
                _emit_response_headers(observer, response)
                _raise_for_status(response)
                async for frame in _aiter_sse_frames(response.aiter_lines()):
                    normalized_frames = (
                        frame_normalizer.feed(frame)
                        if frame_normalizer is not None
                        else [frame]
                    )
                    for normalized_frame in normalized_frames:
                        for event in _decode_stream_frame(
                            decoder,
                            normalized_frame,
                            raw_frame=frame,
                            include_raw_frames=include_raw_frames,
                        ):
                            yield event
                if frame_normalizer is not None:
                    for normalized_frame in frame_normalizer.finish():
                        for event in _decode_stream_frame(
                            decoder,
                            normalized_frame,
                            raw_frame=None,
                            include_raw_frames=include_raw_frames,
                        ):
                            yield event
                for event in decoder.finish():
                    yield event

    return iterator()


def _encode_transport_payload(
    compiled: CompiledRequest,
    options: CallOptions,
    *,
    policy: BuiltinTransportDialectPolicy,
    stream: bool,
) -> dict[str, Any]:
    payload = _encode_request(
        ModelRequest(messages=compiled.messages, options=options),
        compiled.route.api_family,
    )
    return policy.prepare_payload(payload, compiled, options, stream=stream)


def _materialize_transport_options(options: CallOptions, *, stream: bool) -> CallOptions:
    if stream:
        stream_options = (
            options.stream.model_copy(update={"enabled": True})
            if options.stream is not None
            else StreamOptions(enabled=True)
        )
    else:
        stream_options = StreamOptions(enabled=False)
    return options.merge(CallOptions(stream=stream_options))


def _resolve_endpoint_url(
    options: CallOptions,
    *,
    policy: BuiltinTransportDialectPolicy,
    stream: bool,
) -> str:
    endpoint = policy.resolve_endpoint_path(options, stream=stream)
    base_url = (options.base_url or "").rstrip("/")
    if base_url:
        base_url = policy.rewrite_base_url(base_url, options, stream=stream)
        if policy.looks_like_full_endpoint(base_url, options, stream=stream):
            return base_url
        return f"{base_url}{endpoint}"
    return f"{policy.resolve_base_url(options, stream=stream)}{endpoint}"


def _build_headers(
    options: CallOptions,
    *,
    policy: BuiltinTransportDialectPolicy,
    stream: bool,
) -> dict[str, str]:
    headers = dict(options.headers)
    _setdefault_header(headers, "accept", "text/event-stream" if stream else "application/json")
    _setdefault_header(headers, "content-type", "application/json")
    return policy.prepare_headers(headers, options, stream=stream)


def _setdefault_header(headers: dict[str, str], name: str, value: str) -> None:
    if any(existing.lower() == name.lower() for existing in headers):
        return
    headers[name] = value


def _timeout(value: float | None) -> float:
    return value if value is not None else 60.0


def _read_json_response(response: httpx.Response) -> dict[str, Any]:
    _raise_for_status(response)
    try:
        body = json_loads(response.content)
    except Exception as exc:  # pragma: no cover - httpx implementation detail
        raise ProtocolError(f"Provider returned a non-JSON response: {exc}") from exc
    if not isinstance(body, dict):
        raise ProtocolError("Provider returned a non-dict JSON response.")
    return body


def _emit_transport_start(
    observer: TransportObserver | None,
    *,
    url: str,
    headers: dict[str, str],
    stream: bool,
) -> None:
    if observer is None:
        return
    observer(
        "on_transport_start",
        {
            "method": "POST",
            "url": url,
            "stream": stream,
            "request_headers": _redacted_headers(headers),
        },
    )


def _emit_response_headers(observer: TransportObserver | None, response: httpx.Response) -> None:
    if observer is None:
        return
    observer(
        "on_response_headers",
        {
            "status_code": response.status_code,
            "url": str(response.request.url),
            "response_headers": _redacted_headers(dict(response.headers)),
        },
    )


def _redacted_headers(headers: dict[str, str]) -> dict[str, str]:
    redacted = dict(headers)
    for key in list(redacted):
        if _is_secret_header(key):
            redacted[key] = "<redacted>"
    return redacted


def _is_secret_header(key: str) -> bool:
    normalized = key.lower()
    return normalized in {"authorization", "proxy-authorization", "x-api-key", "api-key"} or normalized.endswith(
        "-api-key"
    )


def _raise_for_status(response: httpx.Response) -> None:
    if response.status_code < 400:
        return
    try:
        body = response.text
    except Exception:  # pragma: no cover - defensive fallback
        body = "<unreadable response body>"
    raise ProviderHTTPError(response.status_code, body, url=str(response.request.url))


def _decode_stream_frame(
    decoder: _BaseStreamDecoder,
    normalized_frame: dict[str, Any],
    *,
    raw_frame: dict[str, Any] | None,
    include_raw_frames: bool,
) -> list[StreamEvent]:
    events = decoder.feed(normalized_frame)
    if not include_raw_frames:
        return events
    return [
        _attach_frame_metadata(
            event,
            raw_frame=raw_frame,
            normalized_frame=normalized_frame,
        )
        for event in events
    ]


def _attach_frame_metadata(
    event: StreamEvent,
    *,
    raw_frame: dict[str, Any] | None,
    normalized_frame: dict[str, Any],
) -> StreamEvent:
    return event.model_copy(
        update={
            "metadata": {
                **event.metadata,
                "raw_frame": json_fingerprintable(raw_frame) if raw_frame is not None else None,
                "normalized_frame": json_fingerprintable(normalized_frame),
            }
        }
    )


def _iter_sse_frames(lines: Iterator[str]) -> Iterator[dict[str, Any]]:
    event_name: str | None = None
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line.decode() if isinstance(raw_line, bytes) else raw_line
        if line == "":
            frame = _finalize_sse_frame(event_name, data_lines)
            if frame is not None:
                yield frame
            event_name = None
            data_lines = []
            continue
        if line.startswith(":"):
            continue
        field, _, value = line.partition(":")
        value = value.lstrip(" ")
        if field == "event":
            event_name = value
        elif field == "data":
            data_lines.append(value)

    frame = _finalize_sse_frame(event_name, data_lines)
    if frame is not None:
        yield frame


async def _aiter_sse_frames(lines: AsyncIterator[str]) -> AsyncIterator[dict[str, Any]]:
    event_name: str | None = None
    data_lines: list[str] = []

    async for raw_line in lines:
        line = raw_line.decode() if isinstance(raw_line, bytes) else raw_line
        if line == "":
            frame = _finalize_sse_frame(event_name, data_lines)
            if frame is not None:
                yield frame
            event_name = None
            data_lines = []
            continue
        if line.startswith(":"):
            continue
        field, _, value = line.partition(":")
        value = value.lstrip(" ")
        if field == "event":
            event_name = value
        elif field == "data":
            data_lines.append(value)

    frame = _finalize_sse_frame(event_name, data_lines)
    if frame is not None:
        yield frame


def _finalize_sse_frame(event_name: str | None, data_lines: list[str]) -> dict[str, Any] | None:
    if not data_lines and event_name is None:
        return None
    data = "\n".join(data_lines)
    if data == "[DONE]":
        return {"done": True}
    if not data:
        return {"_sse_event": event_name} if event_name else None
    try:
        payload = json_loads(data)
    except Exception:
        payload = {"type": "error", "error": {"message": data}}
    if isinstance(payload, dict) and event_name:
        payload.setdefault("_sse_event", event_name)
    if isinstance(payload, dict):
        return payload
    raise ProtocolError("SSE frame decoded to a non-dict payload.")


def _stream_decoder(family: ApiFamily) -> _BaseStreamDecoder:
    if family == ApiFamily.openai_chat:
        return _OpenAIChatStreamDecoder()
    if family == ApiFamily.openai_responses:
        return _OpenAIResponsesStreamDecoder()
    if family == ApiFamily.anthropic_messages:
        return _AnthropicStreamDecoder()
    if family == ApiFamily.google_genai:
        return _GoogleGenAIStreamDecoder()
    raise TransportNotConfiguredError(f"No built-in stream decoder is defined for {family.value}.")


class _BaseStreamDecoder:
    def feed(self, frame: dict[str, Any]) -> list[StreamEvent]:
        raise NotImplementedError

    def finish(self) -> list[StreamEvent]:
        return []


class _OpenAIChatStreamDecoder(_BaseStreamDecoder):
    def __init__(self) -> None:
        self._response_started = False
        self._message_started = False
        self._response_completed = False
        self._tool_calls: dict[int, dict[str, Any]] = {}
        self._reasoning_text = ""

    def feed(self, frame: dict[str, Any]) -> list[StreamEvent]:
        if frame.get("done"):
            return self.finish()

        events: list[StreamEvent] = []
        if not self._response_started:
            events.append(StreamEvent(type=Evt.response_start))
            self._response_started = True

        choices = frame.get("choices") or []
        if choices and not self._message_started:
            events.append(StreamEvent(type=Evt.message_start))
            self._message_started = True

        for choice in choices:
            delta = choice.get("delta") or {}
            content = delta.get("content")
            if content:
                events.append(StreamEvent(type=Evt.content, delta=str(content)))
            thinking = delta.get("reasoning_content")
            if thinking:
                events.append(StreamEvent(type=Evt.thinking, delta=str(thinking)))
            reasoning_details = _openai_reasoning_details_text(delta.get("reasoning_details"))
            if reasoning_details:
                delta_text = _text_delta(self._reasoning_text, reasoning_details)
                if delta_text:
                    events.append(StreamEvent(type=Evt.thinking, delta=delta_text))
                self._reasoning_text = reasoning_details
            tool_calls = delta.get("tool_calls") or []
            events.extend(self._tool_call_events(tool_calls))

            finish_reason = choice.get("finish_reason")
            if finish_reason:
                events.extend(self._complete_tool_calls())
                if not self._response_completed:
                    events.append(
                        StreamEvent(
                            type=Evt.response_complete,
                            metadata={"finish_reason": finish_reason},
                        )
                    )
                    self._response_completed = True

        usage = _decode_usage_from_openai(frame.get("usage"))
        if usage is not None:
            events.append(StreamEvent(type=Evt.usage, usage=usage))
        return events

    def finish(self) -> list[StreamEvent]:
        events = self._complete_tool_calls()
        if self._response_started and not self._response_completed:
            events.append(StreamEvent(type=Evt.response_complete))
            self._response_completed = True
        return events

    def _tool_call_events(self, raw_tool_calls: list[Any]) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        for raw_tool_call in raw_tool_calls:
            if not isinstance(raw_tool_call, dict):
                continue
            index = int(raw_tool_call.get("index") or 0)
            function = raw_tool_call.get("function") or {}
            state = self._tool_calls.setdefault(
                index,
                {"id": "", "name": "", "arguments_chunks": [], "started": False, "completed": False},
            )
            if raw_tool_call.get("id"):
                state["id"] = str(raw_tool_call["id"])
            if function.get("name"):
                state["name"] = str(function["name"])
            tool_call_id = state["id"] or f"tool_{index}"
            if not state["started"] and (state["id"] or state["name"]):
                state["started"] = True
                events.append(
                    StreamEvent(
                        type=Evt.tool_call_start,
                        tool_call_id=tool_call_id,
                        part=ToolCallPart(id=tool_call_id, name=state["name"], arguments=None),
                    )
                )
            arguments_delta = function.get("arguments")
            if arguments_delta:
                state["arguments_chunks"].append(str(arguments_delta))
                events.append(
                    StreamEvent(
                        type=Evt.tool_call_delta,
                        tool_call_id=tool_call_id,
                        delta=str(arguments_delta),
                    )
                )
        return events

    def _complete_tool_calls(self) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        for index, state in self._tool_calls.items():
            if state["completed"] or not state["started"]:
                continue
            state["completed"] = True
            tool_call_id = state["id"] or f"tool_{index}"
            arguments_text = "".join(state["arguments_chunks"])
            arguments = _json_loads_or_keep(arguments_text) if arguments_text else None
            events.append(
                StreamEvent(
                    type=Evt.tool_call_complete,
                    tool_call_id=tool_call_id,
                    part=ToolCallPart(
                        id=tool_call_id,
                        name=state["name"],
                        arguments=arguments,
                    ),
                )
            )
        return events


class _OpenAIResponsesStreamDecoder(_BaseStreamDecoder):
    def __init__(self) -> None:
        self._response_started = False
        self._message_started = False
        self._response_completed = False
        self._response_terminal = False
        self._open_parts: set[tuple[str, str, str, int]] = set()
        self._tool_calls: dict[str, dict[str, Any]] = {}

    def feed(self, frame: dict[str, Any]) -> list[StreamEvent]:
        if frame.get("done"):
            return self.finish()

        frame_type = str(frame.get("type") or frame.get("_sse_event") or "")
        events: list[StreamEvent] = []

        if frame_type == "response.created":
            return self._ensure_response_started()

        if frame_type == "response.output_item.added":
            events.extend(self._ensure_response_started())
            item = frame.get("item") or {}
            item_type = str(item.get("type") or "")
            if item_type == "message" and not self._message_started:
                self._message_started = True
                events.append(StreamEvent(type=Evt.message_start, metadata=_responses_stream_metadata(frame)))
            if item_type == "function_call":
                events.extend(self._start_tool_call(item, output_index=int(frame.get("output_index") or 0)))
            return events

        if frame_type == "response.content_part.added":
            part = frame.get("part") or {}
            part_key = _responses_part_key(frame, "content", "content_index")
            part_value = _responses_content_part_to_part(part)
            if part_value is not None and part_key not in self._open_parts:
                self._open_parts.add(part_key)
                events.append(
                    StreamEvent(
                        type=Evt.part_start,
                        part=part_value,
                        metadata=_responses_stream_metadata(frame, "content_index"),
                    )
                )
            return events

        if frame_type in {"response.output_text.delta", "response.refusal.delta"}:
            delta = str(frame.get("delta") or "")
            if delta:
                return [
                    StreamEvent(
                        type=Evt.content,
                        delta=delta,
                        metadata=_responses_stream_metadata(frame, "content_index"),
                    )
                ]
            return []

        if frame_type in {"response.content_part.done", "response.output_text.done", "response.refusal.done"}:
            event = self._complete_part(frame, "content", "content_index")
            return [event] if event is not None else []

        if frame_type == "response.reasoning_summary_part.added":
            part_key = _responses_part_key(frame, "reasoning", "summary_index")
            part = frame.get("part") or {}
            if part_key not in self._open_parts:
                self._open_parts.add(part_key)
                events.append(
                    StreamEvent(
                        type=Evt.part_start,
                        part=ThinkingPart(text=str(part.get("text") or "")),
                        metadata=_responses_stream_metadata(frame, "summary_index"),
                    )
                )
            return events

        if frame_type in {"response.reasoning_summary_text.delta", "response.reasoning_text.delta"}:
            part_index_name = "summary_index" if "summary_index" in frame else "content_index"
            part_key = _responses_part_key(frame, "reasoning", part_index_name)
            if part_key not in self._open_parts:
                self._open_parts.add(part_key)
                events.append(
                    StreamEvent(
                        type=Evt.part_start,
                        part=ThinkingPart(text=""),
                        metadata=_responses_stream_metadata(frame, part_index_name),
                    )
                )
            delta = str(frame.get("delta") or "")
            if delta:
                events.append(
                    StreamEvent(
                        type=Evt.thinking,
                        delta=delta,
                        metadata=_responses_stream_metadata(frame, part_index_name),
                    )
                )
            return events

        if frame_type in {
            "response.reasoning_summary_part.done",
            "response.reasoning_summary_text.done",
            "response.reasoning_text.done",
        }:
            part_index_name = "summary_index" if "summary_index" in frame else "content_index"
            event = self._complete_part(frame, "reasoning", part_index_name)
            return [event] if event is not None else []

        if frame_type == "response.function_call_arguments.delta":
            state = self._tool_call_state(frame.get("item_id"), output_index=int(frame.get("output_index") or 0))
            events.extend(self._emit_tool_call_start(state, frame))
            delta = str(frame.get("delta") or "")
            if delta:
                state["arguments_chunks"].append(delta)
                events.append(
                    StreamEvent(
                        type=Evt.tool_call_delta,
                        tool_call_id=state["tool_call_id"],
                        delta=delta,
                        metadata=_responses_stream_metadata(frame),
                    )
                )
            return events

        if frame_type == "response.function_call_arguments.done":
            state = self._tool_call_state(frame.get("item_id"), output_index=int(frame.get("output_index") or 0))
            if frame.get("name"):
                state["name"] = str(frame["name"])
            events.extend(self._emit_tool_call_start(state, frame))
            complete = self._complete_tool_call(
                state,
                arguments_text=str(frame.get("arguments") or ""),
                frame=frame,
            )
            if complete is not None:
                events.append(complete)
            return events

        if frame_type == "response.output_item.done":
            item = frame.get("item") or {}
            if item.get("type") == "function_call":
                state = self._tool_call_state(item.get("id"), output_index=int(frame.get("output_index") or 0), item=item)
                complete = self._complete_tool_call(
                    state,
                    arguments_text=str(item.get("arguments") or ""),
                    frame=frame,
                    item=item,
                )
                return [complete] if complete is not None else []
            return []

        if frame_type in {"response.completed", "response.incomplete"}:
            response = frame.get("response") or {}
            events.extend(self._drain_open_parts(response))
            events.extend(self._drain_tool_calls(response))
            if not self._response_completed:
                events.append(
                    StreamEvent(
                        type=Evt.response_complete,
                        metadata={"finish_reason": _finish_reason_from_openai_responses(response)},
                    )
                )
                self._response_completed = True
            self._response_terminal = True
            usage = _decode_usage_from_openai_responses(response.get("usage"))
            if usage is not None:
                events.append(StreamEvent(type=Evt.usage, usage=usage))
            return events

        if frame_type in {"response.failed", "error"}:
            response = frame.get("response") if isinstance(frame.get("response"), dict) else None
            events.extend(self._drain_open_parts(response))
            events.extend(self._drain_tool_calls(response))
            self._response_terminal = True
            events.append(StreamEvent(type=Evt.error, error=_openai_responses_error_message(frame)))
            return events

        return events

    def finish(self) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        if self._response_terminal:
            return events
        events.extend(self._drain_open_parts())
        events.extend(self._drain_tool_calls())
        if self._response_started and not self._response_completed:
            events.append(StreamEvent(type=Evt.response_complete))
            self._response_completed = True
        return events

    def _ensure_response_started(self) -> list[StreamEvent]:
        if self._response_started:
            return []
        self._response_started = True
        return [StreamEvent(type=Evt.response_start)]

    def _complete_part(
        self,
        frame: dict[str, Any],
        kind: str,
        index_name: str,
    ) -> StreamEvent | None:
        part_key = _responses_part_key(frame, kind, index_name)
        return self._complete_part_key(
            part_key,
            metadata=_responses_stream_metadata(frame, index_name),
        )

    def _tool_call_state(
        self,
        item_id: Any,
        *,
        output_index: int,
        item: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        state_item_id = str(item_id or (item or {}).get("id") or f"tool_{output_index}")
        state = self._tool_calls.setdefault(
            state_item_id,
            {
                "item_id": state_item_id,
                "tool_call_id": state_item_id,
                "name": "",
                "arguments_chunks": [],
                "started": False,
                "completed": False,
                "output_index": output_index,
            },
        )
        state["output_index"] = output_index
        if item is not None:
            call_id = item.get("call_id") or item.get("id")
            if call_id and not state["started"]:
                state["tool_call_id"] = str(call_id)
            if item.get("name"):
                state["name"] = str(item["name"])
        return state

    def _start_tool_call(self, item: dict[str, Any], *, output_index: int) -> list[StreamEvent]:
        state = self._tool_call_state(item.get("id"), output_index=output_index, item=item)
        return self._emit_tool_call_start(state, {"item": item, "output_index": output_index})

    def _emit_tool_call_start(
        self,
        state: dict[str, Any],
        frame: dict[str, Any],
    ) -> list[StreamEvent]:
        if state["started"]:
            return []
        state["started"] = True
        return [
            StreamEvent(
                type=Evt.tool_call_start,
                tool_call_id=state["tool_call_id"],
                part=ToolCallPart(
                    id=state["tool_call_id"],
                    name=state["name"],
                    arguments=None,
                ),
                metadata=_responses_stream_metadata(frame),
            )
        ]

    def _complete_tool_call(
        self,
        state: dict[str, Any],
        *,
        arguments_text: str,
        frame: dict[str, Any] | None = None,
        item: dict[str, Any] | None = None,
    ) -> StreamEvent | None:
        if state["completed"]:
            return None
        if item is not None and item.get("name"):
            state["name"] = str(item["name"])
        if not state["started"]:
            state["started"] = True
        if arguments_text:
            arguments = _json_loads_or_keep(arguments_text)
        else:
            chunks = "".join(state["arguments_chunks"])
            arguments = _json_loads_or_keep(chunks) if chunks else None
        state["completed"] = True
        return StreamEvent(
            type=Evt.tool_call_complete,
            tool_call_id=state["tool_call_id"],
            part=ToolCallPart(
                id=state["tool_call_id"],
                name=state["name"],
                arguments=arguments,
            ),
            metadata=_responses_stream_metadata(frame or {"item": item or {}}),
        )

    def _complete_part_key(
        self,
        part_key: tuple[str, str, str, int],
        *,
        metadata: dict[str, Any],
    ) -> StreamEvent | None:
        if part_key not in self._open_parts:
            return None
        self._open_parts.remove(part_key)
        return StreamEvent(type=Evt.part_complete, metadata=metadata)

    def _drain_open_parts(self, response: dict[str, Any] | None = None) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        output = response.get("output") if isinstance(response, dict) else None
        if isinstance(output, list):
            for output_index, item in enumerate(output):
                if not isinstance(item, dict):
                    continue
                item_id = str(item.get("id") or "")
                if not item_id:
                    continue
                item_type = str(item.get("type") or "")
                if item_type == "message":
                    content = item.get("content")
                    if isinstance(content, list):
                        for content_index, _part in enumerate(content):
                            complete = self._complete_part_key(
                                ("content", item_id, "content_index", content_index),
                                metadata={
                                    "output_index": output_index,
                                    "item_id": item_id,
                                    "content_index": content_index,
                                },
                            )
                            if complete is not None:
                                events.append(complete)
                elif item_type == "reasoning":
                    for index_name in ("summary", "content"):
                        parts = item.get(index_name)
                        if not isinstance(parts, list):
                            continue
                        metadata_name = "summary_index" if index_name == "summary" else "content_index"
                        for part_index, _part in enumerate(parts):
                            complete = self._complete_part_key(
                                ("reasoning", item_id, metadata_name, part_index),
                                metadata={
                                    "output_index": output_index,
                                    "item_id": item_id,
                                    metadata_name: part_index,
                                },
                            )
                            if complete is not None:
                                events.append(complete)

        for kind, item_id, index_name, part_index in sorted(self._open_parts):
            complete = self._complete_part_key(
                (kind, item_id, index_name, part_index),
                metadata={"item_id": item_id, index_name: part_index},
            )
            if complete is not None:
                events.append(complete)
        return events

    def _drain_tool_calls(self, response: dict[str, Any] | None = None) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        seen_item_ids: set[str] = set()
        output = response.get("output") if isinstance(response, dict) else None
        if isinstance(output, list):
            for output_index, item in enumerate(output):
                if not isinstance(item, dict) or item.get("type") != "function_call":
                    continue
                state = self._tool_call_state(item.get("id"), output_index=output_index, item=item)
                complete = self._complete_tool_call(
                    state,
                    arguments_text=str(item.get("arguments") or ""),
                    frame={"item": item, "output_index": output_index},
                    item=item,
                )
                if complete is not None:
                    events.append(complete)
                seen_item_ids.add(state["item_id"])

        for item_id, state in self._tool_calls.items():
            if state["completed"] or item_id in seen_item_ids or not state["started"]:
                continue
            frame: dict[str, Any] = {"item_id": state["item_id"]}
            if state.get("output_index") is not None:
                frame["output_index"] = state["output_index"]
            complete = self._complete_tool_call(state, arguments_text="", frame=frame)
            if complete is not None:
                events.append(complete)
        return events


class _AnthropicStreamDecoder(_BaseStreamDecoder):
    def __init__(self) -> None:
        self._response_started = False
        self._message_started = False
        self._response_completed = False
        self._blocks: dict[int, dict[str, Any]] = {}

    def feed(self, frame: dict[str, Any]) -> list[StreamEvent]:
        frame_type = str(frame.get("type") or frame.get("_sse_event") or "")
        events: list[StreamEvent] = []

        if frame_type == "message_start":
            if not self._response_started:
                events.append(StreamEvent(type=Evt.response_start))
                self._response_started = True
            if not self._message_started:
                events.append(StreamEvent(type=Evt.message_start))
                self._message_started = True
            usage = _decode_usage_from_anthropic((frame.get("message") or {}).get("usage"))
            if usage is not None:
                events.append(StreamEvent(type=Evt.usage, usage=usage))
            return events

        if frame_type == "content_block_start":
            index = int(frame.get("index") or 0)
            block = frame.get("content_block") or {}
            self._blocks[index] = _build_anthropic_block_state(block)
            if block.get("type") == "tool_use":
                tool_call_id = self._blocks[index]["id"]
                events.append(
                    StreamEvent(
                        type=Evt.tool_call_start,
                        tool_call_id=tool_call_id,
                        part=ToolCallPart(
                            id=tool_call_id,
                            name=self._blocks[index]["name"],
                            arguments=block.get("input"),
                        ),
                        metadata={"index": index},
                    )
                )
            else:
                part = _anthropic_block_to_part(block)
                if part is not None:
                    events.append(
                        StreamEvent(type=Evt.part_start, part=part, metadata={"index": index})
                    )
            return events

        if frame_type == "content_block_delta":
            index = int(frame.get("index") or 0)
            delta = frame.get("delta") or {}
            delta_type = str(delta.get("type") or "")
            if delta_type == "text_delta":
                return [StreamEvent(type=Evt.content, delta=str(delta.get("text") or ""), metadata={"index": index})]
            if delta_type == "thinking_delta":
                return [StreamEvent(type=Evt.thinking, delta=str(delta.get("thinking") or ""), metadata={"index": index})]
            if delta_type == "signature_delta":
                return [StreamEvent(type=Evt.signature, delta=str(delta.get("signature") or ""), metadata={"index": index})]
            if delta_type == "input_json_delta":
                state = self._blocks.setdefault(index, {"type": "tool_use", "id": f"tool_{index}", "name": "", "arguments_chunks": []})
                partial_json = str(delta.get("partial_json") or "")
                if partial_json:
                    state["arguments_chunks"].append(partial_json)
                    return [
                        StreamEvent(
                            type=Evt.tool_call_delta,
                            tool_call_id=state["id"],
                            delta=partial_json,
                            metadata={"index": index},
                        )
                    ]
            return []

        if frame_type == "content_block_stop":
            index = int(frame.get("index") or 0)
            state = self._blocks.pop(index, None)
            if state and state.get("type") == "tool_use":
                arguments_text = "".join(state.get("arguments_chunks", []))
                arguments = _json_loads_or_keep(arguments_text) if arguments_text else state.get("input")
                return [
                    StreamEvent(
                        type=Evt.tool_call_complete,
                        tool_call_id=state["id"],
                        part=ToolCallPart(
                            id=state["id"],
                            name=state["name"],
                            arguments=arguments,
                        ),
                        metadata={"index": index},
                    )
                ]
            return [StreamEvent(type=Evt.part_complete, metadata={"index": index})]

        if frame_type == "message_delta":
            usage = _decode_usage_from_anthropic(frame.get("usage"))
            if usage is not None:
                events.append(StreamEvent(type=Evt.usage, usage=usage))
            return events

        if frame_type == "message_stop":
            if not self._response_completed:
                self._response_completed = True
                events.append(StreamEvent(type=Evt.response_complete))
            return events

        if frame_type == "error":
            error_message = _anthropic_error_message(frame)
            return [StreamEvent(type=Evt.error, error=error_message)]

        return events

    def finish(self) -> list[StreamEvent]:
        if self._response_started and not self._response_completed:
            self._response_completed = True
            return [StreamEvent(type=Evt.response_complete)]
        return []


class _GoogleGenAIStreamDecoder(_BaseStreamDecoder):
    def __init__(self) -> None:
        self._response_started = False
        self._message_started = False
        self._response_completed = False
        self._parts: dict[int, dict[str, Any]] = {}
        self._tool_calls: dict[int, dict[str, Any]] = {}

    def feed(self, frame: dict[str, Any]) -> list[StreamEvent]:
        if frame.get("done"):
            return self.finish()

        events: list[StreamEvent] = []
        if not self._response_started:
            self._response_started = True
            events.append(StreamEvent(type=Evt.response_start))

        candidates = frame.get("candidates") or []
        candidate = candidates[0] if candidates and isinstance(candidates[0], dict) else None
        content = candidate.get("content") if isinstance(candidate, dict) else None
        parts = content.get("parts") if isinstance(content, dict) else None
        if parts and not self._message_started:
            self._message_started = True
            events.append(StreamEvent(type=Evt.message_start))
        if isinstance(parts, list):
            events.extend(self._part_events(parts))

        if isinstance(candidate, dict):
            finish_reason = _finish_reason_from_google_genai(candidate, _google_candidate_parts(candidate))
            if finish_reason:
                events.extend(self._drain_parts())
                events.extend(self._drain_tool_calls())
                if not self._response_completed:
                    self._response_completed = True
                    events.append(
                        StreamEvent(
                            type=Evt.response_complete,
                            metadata={"finish_reason": finish_reason},
                        )
                    )

        usage = _decode_usage_from_google_genai(frame.get("usageMetadata"))
        if usage is not None:
            events.append(StreamEvent(type=Evt.usage, usage=usage))
        return events

    def finish(self) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        events.extend(self._drain_parts())
        events.extend(self._drain_tool_calls())
        if self._response_started and not self._response_completed:
            self._response_completed = True
            events.append(StreamEvent(type=Evt.response_complete))
        return events

    def _part_events(self, parts: list[Any]) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        for index, part in enumerate(parts):
            if not isinstance(part, dict):
                continue
            function_call = part.get("functionCall")
            if isinstance(function_call, dict):
                state = self._tool_calls.setdefault(
                    index,
                    {
                        "id": str(function_call.get("id") or function_call.get("callId") or f"call_{index}"),
                        "name": str(function_call.get("name") or ""),
                        "arguments": function_call.get("args"),
                        "started": False,
                        "completed": False,
                    },
                )
                state["name"] = str(function_call.get("name") or state["name"])
                state["arguments"] = function_call.get("args", state["arguments"])
                if not state["started"]:
                    state["started"] = True
                    events.append(
                        StreamEvent(
                            type=Evt.tool_call_start,
                            tool_call_id=state["id"],
                            part=ToolCallPart(id=state["id"], name=state["name"], arguments=None),
                            metadata={"index": index},
                        )
                    )
                continue

            text = str(part.get("text") or "")
            is_thinking = bool(part.get("thought"))
            state = self._parts.setdefault(
                index,
                {
                    "kind": Evt.thinking if is_thinking else Evt.content,
                    "text": "",
                    "opened": False,
                },
            )
            if not state["opened"]:
                state["opened"] = True
                state["kind"] = Evt.thinking if is_thinking else Evt.content
                events.append(
                    StreamEvent(
                        type=Evt.part_start,
                        part=ThinkingPart(text="") if is_thinking else TextPart(text=""),
                        metadata={"index": index},
                    )
                )
            delta = _google_text_delta(str(state["text"]), text)
            if delta:
                events.append(
                    StreamEvent(
                        type=Evt.thinking if is_thinking else Evt.content,
                        delta=delta,
                        metadata={"index": index},
                    )
                )
            state["text"] = text
        return events

    def _drain_parts(self) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        for index in sorted(self._parts):
            state = self._parts[index]
            if state["opened"]:
                state["opened"] = False
                events.append(StreamEvent(type=Evt.part_complete, metadata={"index": index}))
        return events

    def _drain_tool_calls(self) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        for index in sorted(self._tool_calls):
            state = self._tool_calls[index]
            if state["completed"] or not state["started"]:
                continue
            state["completed"] = True
            events.append(
                StreamEvent(
                    type=Evt.tool_call_complete,
                    tool_call_id=state["id"],
                    part=ToolCallPart(
                        id=state["id"],
                        name=state["name"],
                        arguments=state["arguments"],
                    ),
                    metadata={"index": index},
                )
            )
        return events


def _build_anthropic_block_state(block: dict[str, Any]) -> dict[str, Any]:
    block_type = str(block.get("type") or "")
    if block_type == "tool_use":
        return {
            "type": "tool_use",
            "id": str(block.get("id") or ""),
            "name": str(block.get("name") or ""),
            "input": block.get("input"),
            "arguments_chunks": [],
        }
    return {"type": block_type}


def _anthropic_block_to_part(block: dict[str, Any]) -> TextPart | ThinkingPart | None:
    block_type = str(block.get("type") or "")
    if block_type == "text":
        return TextPart(text=str(block.get("text") or ""))
    if block_type in {"thinking", "redacted_thinking"}:
        return ThinkingPart(
            text=str(block.get("thinking") or block.get("text") or ""),
            signature=block.get("signature"),
        )
    return None


def _anthropic_error_message(frame: dict[str, Any]) -> str:
    error = frame.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error.get("type") or "unknown anthropic stream error")
    return str(error or "unknown anthropic stream error")


def _responses_content_part_to_part(part: dict[str, Any]) -> TextPart | ThinkingPart | None:
    part_type = str(part.get("type") or "")
    if part_type in {"text", "output_text"}:
        return TextPart(text=str(part.get("text") or ""))
    if part_type == "refusal":
        return TextPart(text=str(part.get("refusal") or ""))
    if part_type in {"reasoning", "summary_text"}:
        return ThinkingPart(text=str(part.get("text") or ""))
    return None


def _responses_part_key(frame: dict[str, Any], kind: str, index_name: str) -> tuple[str, str, str, int]:
    item = frame.get("item") or {}
    item_id = str(frame.get("item_id") or item.get("id") or "")
    index = int(frame.get(index_name) or 0)
    return (kind, item_id, index_name, index)


def _responses_stream_metadata(
    frame: dict[str, Any],
    index_name: str | None = None,
) -> dict[str, Any]:
    metadata: dict[str, Any] = {}
    if frame.get("output_index") is not None:
        metadata["output_index"] = int(frame.get("output_index") or 0)
    item = frame.get("item") or {}
    item_id = frame.get("item_id") or item.get("id")
    if item_id:
        metadata["item_id"] = str(item_id)
    if index_name and frame.get(index_name) is not None:
        metadata[index_name] = int(frame.get(index_name) or 0)
    return metadata


def _openai_responses_error_message(frame: dict[str, Any]) -> str:
    if frame.get("type") == "response.failed":
        response = frame.get("response")
        if isinstance(response, dict):
            error = response.get("error")
            if isinstance(error, dict):
                return str(error.get("message") or error.get("code") or "responses stream failed")
    error = frame.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error.get("type") or "unknown responses stream error")
    return str(error or "unknown responses stream error")


def _google_text_delta(previous: str, current: str) -> str:
    return _text_delta(previous, current)


def _openai_reasoning_details_text(raw: Any) -> str | None:
    if not isinstance(raw, list):
        return None
    chunks: list[str] = []
    for item in raw:
        if isinstance(item, dict) and item.get("text"):
            chunks.append(str(item["text"]))
    if not chunks:
        return None
    return "".join(chunks)


def _text_delta(previous: str, current: str) -> str:
    if not current:
        return ""
    if not previous:
        return current
    if current.startswith(previous):
        return current[len(previous):]
    return current


def _google_candidate_parts(candidate: dict[str, Any]) -> list[ToolCallPart]:
    content = candidate.get("content")
    if not isinstance(content, dict):
        return []
    parts = content.get("parts")
    if not isinstance(parts, list):
        return []
    tool_calls: list[ToolCallPart] = []
    for index, part in enumerate(parts):
        if not isinstance(part, dict):
            continue
        function_call = part.get("functionCall")
        if not isinstance(function_call, dict):
            continue
        tool_calls.append(
            ToolCallPart(
                id=str(function_call.get("id") or function_call.get("callId") or f"call_{index}"),
                name=str(function_call.get("name") or ""),
                arguments=function_call.get("args"),
            )
        )
    return tool_calls


def _transport_policy(compiled: CompiledRequest) -> BuiltinTransportDialectPolicy:
    return resolve_transport_dialect_policy(
        compiled.route.api_family,
        dialect=compiled.route.dialect,
    )
