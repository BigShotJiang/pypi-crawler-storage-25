#!/usr/bin/env python3
"""
kalman_robot_arm.py — Robot seguro para laboratorio Kalman Robotics

Provee la clase KalmanRobotArm: una sola conexión TCP al myCobot Pro 450
con guardian de seguridad integrado como daemon thread.

Dos capas de protección:
  1. Límites en firmware (set_joint_min/max_angle): el robot rechaza
     comandos fuera de rango directamente en el controlador.
  2. Guardian thread: monitorea en background con la misma conexión TCP
     y puede llamar stop() de forma efectiva (mismo stream).

Ante cualquier comando inválido o violación física, el robot regresa a
home automáticamente y el script del alumno se termina con SystemExit.

Uso del alumno:
    from kalman_guardian import KalmanRobotArm

    robot = KalmanRobotArm()
    robot.send_angles([10, 0, 0, 0, 0, 0], 5)
    robot.go_home()

Requisito — tunnel SSH activo:
    ssh -L 4501:192.168.0.232:4500 -N pi5@robot-pi5-instance
"""

import sys
import threading
import time
from pymycobot import Pro450Client

# ---------------------------------------------------------------------------
# Colores ANSI para la terminal
# ---------------------------------------------------------------------------

class _C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    CYAN    = "\033[96m"   # inicio / info
    GREEN   = "\033[92m"   # OK / home alcanzado
    YELLOW  = "\033[93m"   # alerta / rechazado
    RED     = "\033[91m"   # crítico / emergencia
    GRAY    = "\033[90m"   # esperando

def _log(color: str, msg: str):
    print(f"{color}[guardian]{_C.RESET} {msg}")

# ---------------------------------------------------------------------------
# Configuración del laboratorio (ajustar por sesión si es necesario)
# ---------------------------------------------------------------------------

IP             = "127.0.0.1"
PORT           = 4501
LIMITE_JOINTS  = 125.0   # ±30° — rango operativo del laboratorio
HOME           = [0, 0, 0, 0, 0, 0]
VELOCIDAD_HOME = 40
POLL_INTERVAL  = 0.05   # 50ms — ~20 Hz de monitoreo

# ---------------------------------------------------------------------------
# KalmanRobotArm
# ---------------------------------------------------------------------------

class KalmanRobotArm:
    """
    Conexión al myCobot Pro 450 con protección integrada.

    Al instanciar:
      - Conecta al robot
      - Configura fresh_mode y límites en firmware
      - Arranca el guardian thread en background

    El guardian comparte la misma conexión TCP (threading.Lock) para
    garantizar que stop() interrumpa el movimiento en curso.

    Ante cualquier comando inválido (fuera de rango) o violación física
    detectada por el guardian, el robot regresa a home y el script del
    alumno se termina. El alumno debe corregir su código y volver a ejecutar.
    """

    def __init__(self, ip=IP, port=PORT, limite=LIMITE_JOINTS):
        self._limite    = limite
        self._lock      = threading.Lock()

        # Estado interno del guardian
        self._estado    = "NORMAL"   # NORMAL | EMERGENCIA | RECOVERY
        self._historial = []

        # Puerta de seguridad: SET=abierta (alumno puede enviar comandos)
        #                      CLEAR=cerrada (guardian enviando home antes de terminar)
        self._gate = threading.Event()
        self._gate.set()

        # Señal de terminación: el guardian la activa tras completar la recuperación
        self._terminar = threading.Event()

        # Conexión
        _log(_C.CYAN, f"Conectando a {ip}:{port}...")
        self.__mc = Pro450Client(ip, port)
        time.sleep(0.3)

        # Configuración inicial
        self.__mc.set_fresh_mode(1)
        self._configurar_limites_firmware()
        self.__mc.set_max_speed(0, VELOCIDAD_HOME)   # velocidad máxima joints
        self.__mc.set_max_speed(1, VELOCIDAD_HOME)   # velocidad máxima cartesiana
        self.__mc.set_collision_mode(1)              # detección de colisiones activa
        _log(_C.CYAN, f"Velocidad máxima: {VELOCIDAD_HOME} | Colisiones: ON")

        pos = self.__mc.get_angles()
        _log(_C.CYAN, f"Listo | pos inicial: {pos}\n")

        # Arrancar guardian
        threading.Thread(target=self._guardian_loop, daemon=True).start()

    # -----------------------------------------------------------------------
    # Capa 4 — Límites en firmware
    # -----------------------------------------------------------------------

    def _configurar_limites_firmware(self):
        lim = int(self._limite)
        for jid in range(1, 7):
            self.__mc.set_joint_min_angle(jid, -lim)
            self.__mc.set_joint_max_angle(jid,  lim)
        _log(_C.CYAN, f"Límites firmware: ±{int(self._limite)}° en joints 1-6")

    # -----------------------------------------------------------------------
    # Capa 2 — Guardian thread
    # -----------------------------------------------------------------------

    def _guardian_loop(self):
        while True:
            time.sleep(POLL_INTERVAL)

            with self._lock:
                a = self.__mc.get_angles()

            if not (isinstance(a, list) and len(a) == 6 and not all(v == -1 for v in a)):
                continue

            # --- NORMAL: detectar violaciones ---
            if self._estado == "NORMAL":
                criticas = [(i+1, v) for i, v in enumerate(a) if abs(v) >= self._limite]
                if criticas:
                    det = ", ".join(f"J{i}={v:.1f}°" for i, v in criticas)
                    _log(_C.RED, f"{_C.BOLD}CRITICO:{_C.RESET} {_C.RED}{det}{_C.RESET}")
                    self._gate.clear()        # cerrar puerta: alumno espera
                    self._estado    = "EMERGENCIA"
                    self._historial = []

            # --- EMERGENCIA: stop persistente hasta que el robot frene ---
            if self._estado == "EMERGENCIA":
                with self._lock:
                    self.__mc.stop(_async=True)

                self._historial.append(a)
                if len(self._historial) > 4:
                    self._historial.pop(0)

                if self._posicion_estable():
                    _log(_C.YELLOW, f"Detenido en {[round(v,1) for v in a]} → enviando home")
                    with self._lock:
                        self.__mc.send_angles(HOME, VELOCIDAD_HOME)
                    self._estado    = "RECOVERY"
                    self._historial = []

            # --- RECOVERY: esperar que llegue a home y terminar el script ---
            elif self._estado == "RECOVERY":
                if all(abs(v) < 3.0 for v in a):
                    _log(_C.GREEN, "Home alcanzado.")
                    _log(_C.YELLOW, f"{_C.BOLD}Script terminado.{_C.RESET} {_C.YELLOW}Corrige el comando fuera de rango y vuelve a ejecutar.{_C.RESET}")
                    self._terminar.set()      # señal al hilo principal para terminar
                    self._gate.set()          # desbloquear _esperar_si_emergencia

    def _posicion_estable(self, tol=0.5) -> bool:
        if len(self._historial) < 3:
            return False
        return all(
            all(abs(self._historial[i][j] - self._historial[i-1][j]) < tol
                for j in range(6))
            for i in range(1, len(self._historial))
        )

    # -----------------------------------------------------------------------
    # API para el alumno
    # -----------------------------------------------------------------------

    def _terminar_con_home(self):
        """Envía el robot a home desde el hilo principal y termina el script."""
        _log(_C.YELLOW, "Enviando robot a home...")
        with self._lock:
            self.__mc.send_angles(HOME, VELOCIDAD_HOME)
        _log(_C.YELLOW, f"{_C.BOLD}Script terminado.{_C.RESET} {_C.YELLOW}Corrige el comando fuera de rango y vuelve a ejecutar.{_C.RESET}")
        raise SystemExit(1)

    def _esperar_si_emergencia(self):
        """Bloquea si hay emergencia; termina el script cuando el guardian completa home."""
        if not self._gate.is_set():
            _log(_C.GRAY, "Emergencia activa — esperando que el robot llegue a home...")
            self._gate.wait()
        if self._terminar.is_set():
            raise SystemExit(1)

    def send_angles(self, angles, speed):
        """Mueve los 6 joints a los ángulos dados [°] a la velocidad indicada (1–100)."""
        self._esperar_si_emergencia()
        fuera = [(i+1, v) for i, v in enumerate(angles) if abs(v) > self._limite]
        if fuera:
            det = ", ".join(f"J{i}={v}°" for i, v in fuera)
            _log(_C.RED, f"{_C.BOLD}Comando rechazado{_C.RESET} {_C.RED}— fuera de límite (±{int(self._limite)}°): {det}{_C.RESET}")
            self._terminar_con_home()
        if speed > VELOCIDAD_HOME:
            _log(_C.YELLOW, f"Velocidad {speed} → limitada a {VELOCIDAD_HOME} por configuración del laboratorio")
        with self._lock:
            self.__mc.send_angles(angles, speed)

    def send_angle(self, joint_id, degree, speed):
        """Mueve un solo joint (1-6) a degree° a la velocidad indicada."""
        self._esperar_si_emergencia()
        if abs(degree) > self._limite:
            _log(_C.RED, f"{_C.BOLD}Comando rechazado{_C.RESET} {_C.RED}— J{joint_id}={degree}° fuera de límite (±{int(self._limite)}°){_C.RESET}")
            self._terminar_con_home()
        if speed > VELOCIDAD_HOME:
            _log(_C.YELLOW, f"Velocidad {speed} → limitada a {VELOCIDAD_HOME} por configuración del laboratorio")
        with self._lock:
            self.__mc.send_angle(joint_id, degree, speed)

    def get_angles(self):
        """Retorna los ángulos actuales de los 6 joints como lista [°]."""
        with self._lock:
            return self.__mc.get_angles()

    def send_coords(self, coords, speed, mode=0):
        """Mueve el extremo a una posición cartesiana [x, y, z, rx, ry, rz]."""
        self._esperar_si_emergencia()
        if speed > VELOCIDAD_HOME:
            _log(_C.YELLOW, f"Velocidad {speed} → limitada a {VELOCIDAD_HOME} por configuración del laboratorio")
        with self._lock:
            self.__mc.send_coords(coords, speed, mode)

    def send_coord(self, axis_id, coord, speed):
        """Mueve un eje cartesiano individual a la posición dada.

        axis_id: 1=x, 2=y, 3=z (mm) | 4=rx, 5=ry, 6=rz (grados)
        coord: valor objetivo
        speed: 1-100
        """
        self._esperar_si_emergencia()
        if speed > VELOCIDAD_HOME:
            _log(_C.YELLOW, f"Velocidad {speed} → limitada a {VELOCIDAD_HOME} por configuración del laboratorio")
        with self._lock:
            self.__mc.send_coord(axis_id, coord, speed)

    def get_coords(self):
        """Retorna la posición cartesiana actual [x, y, z, rx, ry, rz]."""
        with self._lock:
            return self.__mc.get_coords()

    def go_home(self):
        """Mueve el robot a la posición home [0, 0, 0, 0, 0, 0]."""
        self._esperar_si_emergencia()
        with self._lock:
            self.__mc.send_angles(HOME, VELOCIDAD_HOME)

    def is_moving(self):
        """Retorna True si el robot está en movimiento."""
        with self._lock:
            return self.__mc.is_moving() == 1

    def gripper_open(self):
        """Abre el gripper completamente."""
        with self._lock:
            self.__mc.set_pro_gripper_open()

    def gripper_close(self):
        """Cierra el gripper completamente."""
        with self._lock:
            self.__mc.set_pro_gripper_close()

    def gripper_angle(self, angle):
        """Mueve el gripper a una posición intermedia (0=cerrado, 100=abierto)."""
        with self._lock:
            self.__mc.set_pro_gripper_angle(angle)

    def get_gripper(self):
        """Retorna la posición actual del gripper (0-100)."""
        with self._lock:
            return self.__mc.get_pro_gripper_angle()

    def set_color(self, r, g, b):
        """Establece el color del LED del extremo (r, g, b: 0-255)."""
        with self._lock:
            self.__mc.set_color(r, g, b)

    # --- Alta prioridad ---

    def wait_until_stopped(self, timeout=30):
        """Bloquea hasta que el robot termine su movimiento actual.

        timeout: segundos máximos de espera (default 30).
        Retorna True si detuvo solo, False si se agotó el timeout.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                moving = self.__mc.is_moving()
            if moving == 0:
                return True
            time.sleep(POLL_INTERVAL)
        return False

    def get_gripper_status(self):
        """Retorna el estado de agarre del gripper.

        0 = moviéndose
        1 = detenido, sin objeto
        2 = objeto detectado (agarre exitoso)
        3 = objeto soltado tras detección
        """
        with self._lock:
            return self.__mc.get_pro_gripper_status()

    def get_error_info(self):
        """Retorna el código de error actual (0 = sin error)."""
        with self._lock:
            return self.__mc.get_error_information()

    def clear_errors(self):
        """Limpia el error activo en el controlador."""
        with self._lock:
            self.__mc.clear_error_information()

    # --- Media prioridad ---

    def get_angle(self, joint_id):
        """Retorna el ángulo actual de un joint específico (1-6) en grados."""
        with self._lock:
            return self.__mc.get_angle(joint_id)

    def get_coord(self, axis_id):
        """Retorna el valor actual de un eje cartesiano (1=x, 2=y, 3=z, 4=rx, 5=ry, 6=rz)."""
        with self._lock:
            coords = self.__mc.get_coords()
        if isinstance(coords, list) and len(coords) == 6:
            return coords[axis_id - 1]
        return -1

    def jog_angle(self, joint_id, direction, speed):
        """Movimiento continuo de un joint mientras se mantiene la llamada.

        joint_id: 1-6
        direction: 1=positivo, 0=negativo
        speed: 1-100
        """
        self._esperar_si_emergencia()
        if speed > VELOCIDAD_HOME:
            _log(_C.YELLOW, f"Velocidad {speed} → limitada a {VELOCIDAD_HOME} por configuración del laboratorio")
        with self._lock:
            self.__mc.jog_angle(joint_id, direction, speed)

    def jog_increment(self, joint_id, increment, speed):
        """Mueve un joint un paso fijo en grados desde su posición actual.

        joint_id: 1-6
        increment: grados (positivo o negativo)
        speed: 1-100
        """
        self._esperar_si_emergencia()
        with self._lock:
            current = self.__mc.get_angle(joint_id)
        if not isinstance(current, (int, float)) or current == -1:
            return
        target = current + increment
        if abs(target) > self._limite:
            _log(_C.RED, f"{_C.BOLD}Comando rechazado{_C.RESET} {_C.RED}— jog J{joint_id} llevaría a {target:.1f}° (límite ±{int(self._limite)}°){_C.RESET}")
            self._terminar_con_home()
        if speed > VELOCIDAD_HOME:
            _log(_C.YELLOW, f"Velocidad {speed} → limitada a {VELOCIDAD_HOME} por configuración del laboratorio")
        with self._lock:
            self.__mc.send_angle(joint_id, target, speed)

    def jog_coord(self, axis_id, direction, speed):
        """Movimiento continuo del extremo en un eje cartesiano.

        axis_id: 1=x, 2=y, 3=z, 4=rx, 5=ry, 6=rz
        direction: 1=positivo, 0=negativo
        speed: 1-100
        """
        self._esperar_si_emergencia()
        if speed > VELOCIDAD_HOME:
            _log(_C.YELLOW, f"Velocidad {speed} → limitada a {VELOCIDAD_HOME} por configuración del laboratorio")
        with self._lock:
            self.__mc.jog_coord(axis_id, direction, speed)

    def jog_increment_coord(self, axis_id, increment, speed):
        """Mueve el extremo un paso fijo en un eje cartesiano desde su posición actual.

        axis_id: 1=x, 2=y, 3=z (mm) | 4=rx, 5=ry, 6=rz (grados)
        increment: desplazamiento (positivo o negativo)
        speed: 1-100
        """
        self._esperar_si_emergencia()
        if speed > VELOCIDAD_HOME:
            _log(_C.YELLOW, f"Velocidad {speed} → limitada a {VELOCIDAD_HOME} por configuración del laboratorio")
        with self._lock:
            coords = self.__mc.get_coords()
        if not (isinstance(coords, list) and len(coords) == 6):
            return
        target = list(coords)
        target[axis_id - 1] += increment
        with self._lock:
            self.__mc.send_coords(target, speed, 0)

    def pause(self):
        """Pausa el movimiento en curso. Reanudar con resume()."""
        with self._lock:
            self.__mc.pause()

    def resume(self):
        """Reanuda el movimiento pausado con pause()."""
        with self._lock:
            self.__mc.resume()

    def is_in_position(self, data, flag=0):
        """Verifica si el robot llegó a la posición objetivo.

        data: lista de 6 valores — ángulos (flag=0) o coordenadas (flag=1)
        flag: 0=comparar ángulos, 1=comparar coordenadas cartesianas
        Retorna: True si llegó, False si no, None si error
        """
        with self._lock:
            result = self.__mc.is_in_position(data, flag)
        if result == 1:
            return True
        if result == 0:
            return False
        return None

    def set_fresh_mode(self, enabled):
        """Habilita o deshabilita el modo fresco (fresh_mode) del controlador.

        enabled: True para habilitar, False para deshabilitar
        En modo fresco, el controlador procesa comandos sin esperar a que terminen los anteriores.
        Útil para trazados continuos, pero requiere cuidado con la velocidad y la cantidad de puntos.
        """
        with self._lock:
            self.__mc.set_fresh_mode(1 if enabled else 0)