# kalman-robot-arm

Librería oficial de Kalman Robotics para operar el brazo robótico myCobot Pro 450 en el laboratorio remoto.

## Instalación

```bash
pip install kalman-robot-arm
```

Para actualizar a la última versión:

```bash
pip install --upgrade kalman-robot-arm
```

## Requisito previo

La conexión al robot debe estar activa antes de ejecutar cualquier script.
El laboratorio proporciona las instrucciones específicas de conexión (tunnel SSH + socat).

## Uso básico

```python
from kalman_robot_arm import KalmanRobotArm

robot = KalmanRobotArm()

angulos = robot.get_angles()
print(angulos)

robot.send_angles([10, -10, 0, 0, 10, 0], speed=10)
robot.go_home()
```

## Límites de seguridad

La librería incluye un guardian de seguridad integrado. Los joints tienen un límite de ±21°.
Ante un comando fuera de rango, el robot regresa a home y el script se termina automáticamente.
El alumno debe corregir su código y volver a ejecutar.
