"""Unit tests for autodraft.local_runner that don't require GPU/torch.

These work by injecting a fake ``run_draft`` (and ``set_seed``) into the
``evaluation.eval_opt_classic_draft`` import slot before ``run_local`` does
its lazy import. The fake reads the question file and writes a chat-UI
shaped answer file, so we can verify the full happy-path round-trip.
"""

from __future__ import annotations

import json
import sys
import types
from pathlib import Path

import pytest


def _install_fake_runtime(monkeypatch: pytest.MonkeyPatch, recorder: dict) -> None:
    """Replace evaluation.eval_opt_classic_draft with a stub module."""

    fake_pkg = types.ModuleType("evaluation")
    fake_pkg.__path__ = []  # mark as package
    fake_mod = types.ModuleType("evaluation.eval_opt_classic_draft")

    def fake_set_seed(seed):
        recorder["seed"] = seed

    def fake_run_draft(
        host,
        port,
        base_model_path,
        draft_model_path,
        bench_name,
        question_file,
        limit,
        temperature,
        nodes,
        max_depth,
        device_map,
        load_in_4bit,
        load_in_8bit,
        target_quantization="8bit",
        answer_file=None,
        **kwargs,
    ):
        recorder["call"] = dict(
            host=host,
            port=port,
            base_model_path=base_model_path,
            draft_model_path=draft_model_path,
            bench_name=bench_name,
            question_file=question_file,
            answer_file=answer_file,
            limit=limit,
            temperature=temperature,
            nodes=nodes,
            max_depth=max_depth,
            device_map=device_map,
            load_in_4bit=load_in_4bit,
            load_in_8bit=load_in_8bit,
            target_quantization=target_quantization,
            kwargs=dict(kwargs),
        )

        # Mirror the real run_draft: write the answers to a sibling file
        # named ``{stem}_results_{timestamp}.json``, NOT to answer_file.
        question_path = Path(question_file)
        question_row = json.loads(question_path.read_text(encoding="utf-8").splitlines()[0])
        last_turn = question_row["turns"][-1]
        answer_row = {
            "question_id": question_row["question_id"],
            "answer_id": "fake-uuid",
            "model_id": "fake",
            "choices": [{"index": 0, "turns": [f"echo: {last_turn}"]}],
            "tstamp": 0.0,
        }
        integrated = {"answers": [answer_row]}
        answer_path = Path(answer_file)
        results_path = answer_path.parent / f"{answer_path.stem}_results_20260502_000000.json"
        results_path.write_text(json.dumps(integrated), encoding="utf-8")

    fake_mod.run_draft = fake_run_draft
    fake_mod.set_seed = fake_set_seed
    fake_pkg.eval_opt_classic_draft = fake_mod

    monkeypatch.setitem(sys.modules, "evaluation", fake_pkg)
    monkeypatch.setitem(sys.modules, "evaluation.eval_opt_classic_draft", fake_mod)


def test_run_local_round_trip(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)

    from autodraft.local_runner import run_local

    result = run_local(
        draft_model="draft-id",
        target_model="target-id",
        draft_quantization="8bit",
        target_quantization="8bit",
        input_text="hello world",
    )

    assert result["generated_text"] == "echo: hello world"
    assert result["input_text"] == "hello world"
    assert result["algorithm"] == "MobiTree"
    assert result["answer_row"]["choices"][0]["turns"] == ["echo: hello world"]


def test_run_local_writes_mt_bench_question_file(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="prompt-text",
    )

    call = recorder["call"]
    assert call["bench_name"] == "mt_bench"
    assert call["limit"] == 1
    assert call["base_model_path"] == "t"
    assert call["draft_model_path"] == "d"
    # Quantization None → load_in_4bit / load_in_8bit both False.
    assert call["load_in_4bit"] is False
    assert call["load_in_8bit"] is False
    assert call["target_quantization"] == "none"


def test_run_local_seed_is_set(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        seed=7,
    )
    assert recorder["seed"] == 7


def test_run_local_proactive_flags(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        proactive=True,
        cs=42,
    )

    kwargs = recorder["call"]["kwargs"]
    assert kwargs["proactive_drafting"] is True
    assert kwargs["adaptive_proactive_threshold"] is True
    assert kwargs["cost_sensitivity"] == 42.0


def test_run_local_algorithm_server_only(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        algorithm="Server-Only-AR",
    )
    kwargs = recorder["call"]["kwargs"]
    assert kwargs["force_server_only"] is True
    assert recorder["call"]["nodes"] == 1
    assert recorder["call"]["max_depth"] == 1


def test_run_local_drops_unknown_kwargs(monkeypatch, capsys):
    """Strict-signature fake (no **kwargs) → unknown overlay keys are dropped."""

    seen: dict = {}

    fake_pkg = types.ModuleType("evaluation")
    fake_pkg.__path__ = []
    fake_mod = types.ModuleType("evaluation.eval_opt_classic_draft")

    def fake_set_seed(seed):
        seen["seed"] = seed

    def fake_run_draft(
        host,
        port,
        base_model_path,
        draft_model_path,
        bench_name,
        question_file,
        limit,
        temperature,
        nodes,
        max_depth,
        device_map,
        load_in_4bit,
        load_in_8bit,
        target_quantization="8bit",
        answer_file=None,
    ):
        # No **kwargs — the filter must drop everything else.
        seen["called"] = True
        question_row = json.loads(
            Path(question_file).read_text(encoding="utf-8").splitlines()[0]
        )
        integrated = {
            "answers": [
                {
                    "question_id": question_row["question_id"],
                    "model_id": "fake",
                    "choices": [{"index": 0, "turns": ["ok"]}],
                }
            ]
        }
        answer_path = Path(answer_file)
        results_path = answer_path.parent / f"{answer_path.stem}_results_20260502_000000.json"
        results_path.write_text(json.dumps(integrated), encoding="utf-8")

    fake_mod.run_draft = fake_run_draft
    fake_mod.set_seed = fake_set_seed
    fake_pkg.eval_opt_classic_draft = fake_mod

    monkeypatch.setitem(sys.modules, "evaluation", fake_pkg)
    monkeypatch.setitem(sys.modules, "evaluation.eval_opt_classic_draft", fake_mod)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        nonexistent_kwarg="should-be-dropped",
    )
    captured = capsys.readouterr().out
    assert "nonexistent_kwarg" in captured
    assert seen.get("called") is True


def test_run_local_rejects_empty_input(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)

    from autodraft.local_runner import run_local

    with pytest.raises(ValueError):
        run_local(
            draft_model="d",
            target_model="t",
            draft_quantization=None,
            target_quantization=None,
            input_text="",
        )


def test_run_local_sets_hf_token_env_before_import(monkeypatch):
    """HF_TOKEN / HUGGING_FACE_HUB_TOKEN must be set before run_draft import.

    We assert both env vars are populated by the time ``run_draft`` runs.
    """
    recorder: dict = {}

    fake_pkg = types.ModuleType("evaluation")
    fake_pkg.__path__ = []
    fake_mod = types.ModuleType("evaluation.eval_opt_classic_draft")

    def fake_set_seed(seed):
        recorder["seed_env"] = {
            "HF_TOKEN": Path("/__sentinel").as_posix(),  # not real, just a placeholder
        }

    def fake_run_draft(question_file, answer_file, **_kwargs):
        import os as _os

        recorder["env_at_call"] = {
            "HF_TOKEN": _os.environ.get("HF_TOKEN"),
            "HUGGING_FACE_HUB_TOKEN": _os.environ.get("HUGGING_FACE_HUB_TOKEN"),
        }
        question_row = json.loads(
            Path(question_file).read_text(encoding="utf-8").splitlines()[0]
        )
        integrated = {
            "answers": [
                {
                    "question_id": question_row["question_id"],
                    "model_id": "fake",
                    "choices": [{"index": 0, "turns": ["ok"]}],
                }
            ]
        }
        answer_path = Path(answer_file)
        results_path = answer_path.parent / f"{answer_path.stem}_results_20260502_000000.json"
        results_path.write_text(json.dumps(integrated), encoding="utf-8")

    fake_mod.run_draft = fake_run_draft
    fake_mod.set_seed = fake_set_seed
    fake_pkg.eval_opt_classic_draft = fake_mod

    monkeypatch.setitem(sys.modules, "evaluation", fake_pkg)
    monkeypatch.setitem(sys.modules, "evaluation.eval_opt_classic_draft", fake_mod)
    monkeypatch.delenv("HF_TOKEN", raising=False)
    monkeypatch.delenv("HUGGING_FACE_HUB_TOKEN", raising=False)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        hf_token="hf_test_value",
    )
    assert recorder["env_at_call"]["HF_TOKEN"] == "hf_test_value"
    assert recorder["env_at_call"]["HUGGING_FACE_HUB_TOKEN"] == "hf_test_value"


def test_run_local_passes_device_name(monkeypatch):
    """device_name must be non-empty so the runtime's profile-load path
    actually runs (it early-returns on falsy device_name)."""
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    monkeypatch.setenv("MOBITREE_DEVICE_NAME", "my-gpu-x100")

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
    )
    assert recorder["call"]["kwargs"]["device_name"] == "my-gpu-x100"


def test_run_local_device_name_falls_back_to_unknown(monkeypatch):
    """If env var is unset and torch is unavailable, fall back to a
    non-empty placeholder so profiling still triggers."""
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    monkeypatch.delenv("MOBITREE_DEVICE_NAME", raising=False)

    # Force the lazy torch import to fail.
    import builtins

    real_import = builtins.__import__

    def blocking_import(name, *a, **kw):
        if name == "torch":
            raise ImportError("simulated no torch")
        return real_import(name, *a, **kw)

    monkeypatch.setattr(builtins, "__import__", blocking_import)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
    )
    assert recorder["call"]["kwargs"]["device_name"] == "unknown-gpu"


def test_run_local_sets_default_data_dir(monkeypatch, tmp_path):
    """If MOBITREE_DATA_DIR is unset, run_local defaults to ``./data`` so
    caches land where the user launched the script."""
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("MOBITREE_DATA_DIR", raising=False)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
    )

    expected = tmp_path / "data"
    import os as _os
    assert _os.environ["MOBITREE_DATA_DIR"] == str(expected)
    assert (expected / "profile").is_dir()
    assert (expected / "reference").is_dir()


def test_run_local_honors_existing_mobitree_data_dir(monkeypatch, tmp_path):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    custom = tmp_path / "custom-data"
    monkeypatch.setenv("MOBITREE_DATA_DIR", str(custom))

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
    )

    import os as _os
    assert _os.environ["MOBITREE_DATA_DIR"] == str(custom)
    assert (custom / "profile").is_dir()
    assert (custom / "reference").is_dir()


def test_run_local_falls_back_to_hf_env_token(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    monkeypatch.setenv("HF_TOKEN", "hf_from_env")
    monkeypatch.delenv("HUGGING_FACE_HUB_TOKEN", raising=False)

    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
    )
    import os as _os

    # HF_TOKEN passes through unchanged; HUGGING_FACE_HUB_TOKEN gets mirrored.
    assert _os.environ.get("HF_TOKEN") == "hf_from_env"
    assert _os.environ.get("HUGGING_FACE_HUB_TOKEN") == "hf_from_env"


def test_run_local_picks_integrated_results_not_trimmed(monkeypatch):
    """When run_draft writes both ``_results_*.json`` and a ``_trimmed`` sibling,
    the wrapper must read the non-trimmed file."""
    fake_pkg = types.ModuleType("evaluation")
    fake_pkg.__path__ = []
    fake_mod = types.ModuleType("evaluation.eval_opt_classic_draft")

    def fake_set_seed(_seed):
        pass

    def fake_run_draft(question_file, answer_file, **_kwargs):
        question_row = json.loads(
            Path(question_file).read_text(encoding="utf-8").splitlines()[0]
        )
        answer_path = Path(answer_file)

        full = {
            "answers": [
                {
                    "question_id": question_row["question_id"],
                    "model_id": "fake",
                    "choices": [{"index": 0, "turns": ["FULL_OUTPUT"]}],
                }
            ]
        }
        trimmed = {
            "answers": [
                {
                    "question_id": question_row["question_id"],
                    "model_id": "fake",
                    "choices": [{"index": 0, "turns": ["TRIMMED_OUTPUT"]}],
                }
            ]
        }
        ts = "20260502_000000"
        full_path = answer_path.parent / f"{answer_path.stem}_results_{ts}.json"
        trimmed_path = answer_path.parent / f"{answer_path.stem}_results_{ts}_trimmed.json"
        full_path.write_text(json.dumps(full), encoding="utf-8")
        trimmed_path.write_text(json.dumps(trimmed), encoding="utf-8")

    fake_mod.run_draft = fake_run_draft
    fake_mod.set_seed = fake_set_seed
    fake_pkg.eval_opt_classic_draft = fake_mod
    monkeypatch.setitem(sys.modules, "evaluation", fake_pkg)
    monkeypatch.setitem(sys.modules, "evaluation.eval_opt_classic_draft", fake_mod)

    from autodraft.local_runner import run_local

    result = run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
    )
    assert result["generated_text"] == "FULL_OUTPUT"
    assert result["raw_result"] is not None


def test_cs_presets_translate_to_numeric(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)

    from autodraft.local_runner import run_local

    cases = [("tps", 0.0), ("balanced", 50.0), ("cost", 100.0)]
    for preset, expected in cases:
        recorder.clear()
        _install_fake_runtime(monkeypatch, recorder)
        run_local(
            draft_model="d",
            target_model="t",
            draft_quantization=None,
            target_quantization=None,
            input_text="x",
            cs=preset,
            save_tradeoff=False,
        )
        assert recorder["call"]["kwargs"]["cost_sensitivity"] == expected, preset


def test_cs_default_is_balanced(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        save_tradeoff=False,
    )
    assert recorder["call"]["kwargs"]["cost_sensitivity"] == 50.0


def test_cs_numeric_still_accepted(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        cs=37,
        save_tradeoff=False,
    )
    assert recorder["call"]["kwargs"]["cost_sensitivity"] == 37.0


def test_cs_invalid_string_rejected(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    from autodraft.local_runner import run_local

    with pytest.raises(ValueError):
        run_local(
            draft_model="d",
            target_model="t",
            draft_quantization=None,
            target_quantization=None,
            input_text="x",
            cs="cheap",
            save_tradeoff=False,
        )


def test_cs_out_of_range_rejected(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    from autodraft.local_runner import run_local

    with pytest.raises(ValueError):
        run_local(
            draft_model="d",
            target_model="t",
            draft_quantization=None,
            target_quantization=None,
            input_text="x",
            cs=150,
            save_tradeoff=False,
        )


def test_cost_metric_forwarded(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    from autodraft.local_runner import run_local

    run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        cost="energy_total",
        save_tradeoff=False,
    )
    assert recorder["call"]["kwargs"]["objective_metric"] == "energy_total"


def test_cost_metric_invalid_rejected(monkeypatch):
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    from autodraft.local_runner import run_local

    with pytest.raises(ValueError):
        run_local(
            draft_model="d",
            target_model="t",
            draft_quantization=None,
            target_quantization=None,
            input_text="x",
            cost="my_made_up_cost",
            save_tradeoff=False,
        )


def test_result_includes_stats_extracted_from_generation_stats(monkeypatch):
    """Fake run_draft writes generation_stats with the fields we surface."""
    fake_pkg = types.ModuleType("evaluation")
    fake_pkg.__path__ = []
    fake_mod = types.ModuleType("evaluation.eval_opt_classic_draft")

    def fake_set_seed(_):
        pass

    def fake_run_draft(question_file, answer_file, **_kwargs):
        question_row = json.loads(
            Path(question_file).read_text(encoding="utf-8").splitlines()[0]
        )
        integrated = {
            "answers": [
                {
                    "question_id": question_row["question_id"],
                    "model_id": "fake",
                    "choices": [{"index": 0, "turns": ["ok"]}],
                }
            ],
            "generation_stats": {
                "total_steps": 15,
                "total_new_tokens": 121,
                "total_time_seconds": 1.98,
                "tokens_per_second": 61.10,
                "tokens_per_step": 8.07,
                "avg_tree_width": 6.4,
                "avg_tree_depth": 7.2,
                "avg_final_nodes": 50.5,
                "avg_accept_length": 7.07,
                "acceptance_ratio_avg": 0.98,
                "total_cost": 0.000125,
                "api_cost": 0.0,
                "draft_cost": 0.000031,
                "target_cost": 0.000094,
            },
        }
        answer_path = Path(answer_file)
        results_path = answer_path.parent / f"{answer_path.stem}_results_20260503_000000.json"
        results_path.write_text(json.dumps(integrated), encoding="utf-8")

    fake_mod.run_draft = fake_run_draft
    fake_mod.set_seed = fake_set_seed
    fake_pkg.eval_opt_classic_draft = fake_mod
    monkeypatch.setitem(sys.modules, "evaluation", fake_pkg)
    monkeypatch.setitem(sys.modules, "evaluation.eval_opt_classic_draft", fake_mod)

    from autodraft.local_runner import run_local

    result = run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        save_tradeoff=False,
    )
    stats = result["stats"]
    assert stats["total_steps"] == 15
    assert stats["avg_tree_width"] == 6.4
    assert stats["avg_tree_depth"] == 7.2
    assert stats["avg_nnodes"] == 50.5
    assert stats["avg_accept_length"] == 7.07
    assert stats["total_cost"] == 0.000125
    assert stats["draft_cost"] == 0.000031
    assert result["cost"] == "total_cost"


def test_save_tradeoff_writes_json(monkeypatch, tmp_path):
    """When the runtime emits a curve, JSON snapshot is written."""
    fake_pkg = types.ModuleType("evaluation")
    fake_pkg.__path__ = []
    fake_mod = types.ModuleType("evaluation.eval_opt_classic_draft")

    def fake_set_seed(_):
        pass

    curve = [
        {"cost_sensitivity": 0.0, "predicted_tps": 60.0, "predicted_metric_per_1m_token": 18.0},
        {"cost_sensitivity": 50.0, "predicted_tps": 50.0, "predicted_metric_per_1m_token": 8.0},
        {"cost_sensitivity": 100.0, "predicted_tps": 30.0, "predicted_metric_per_1m_token": 2.0},
    ]

    def fake_run_draft(question_file, answer_file, **_kwargs):
        question_row = json.loads(
            Path(question_file).read_text(encoding="utf-8").splitlines()[0]
        )
        integrated = {
            "answers": [
                {
                    "question_id": question_row["question_id"],
                    "model_id": "fake",
                    "choices": [{"index": 0, "turns": ["ok"]}],
                }
            ],
            "experiment_info": {
                "draft_model": "d",
                "base_model": "t",
                "reference_tradeoff_curve_cs0_100": curve,
            },
        }
        answer_path = Path(answer_file)
        results_path = answer_path.parent / f"{answer_path.stem}_results_20260503_000000.json"
        results_path.write_text(json.dumps(integrated), encoding="utf-8")

    fake_mod.run_draft = fake_run_draft
    fake_mod.set_seed = fake_set_seed
    fake_pkg.eval_opt_classic_draft = fake_mod
    monkeypatch.setitem(sys.modules, "evaluation", fake_pkg)
    monkeypatch.setitem(sys.modules, "evaluation.eval_opt_classic_draft", fake_mod)

    target_dir = tmp_path / "tradeoff-out"

    from autodraft.local_runner import run_local

    result = run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        save_tradeoff=True,
        tradeoff_dir=str(target_dir),
    )
    files = result["tradeoff_files"]
    assert files is not None
    json_path = Path(files["json"])
    assert json_path.is_file()
    saved = json.loads(json_path.read_text(encoding="utf-8"))
    assert saved == curve


def test_save_tradeoff_disabled_returns_none(monkeypatch, tmp_path):
    """save_tradeoff=False skips artifact writing entirely."""
    recorder: dict = {}
    _install_fake_runtime(monkeypatch, recorder)
    monkeypatch.chdir(tmp_path)

    from autodraft.local_runner import run_local

    result = run_local(
        draft_model="d",
        target_model="t",
        draft_quantization=None,
        target_quantization=None,
        input_text="x",
        save_tradeoff=False,
    )
    assert result["tradeoff_files"] is None
    # No tradeoff/ subdir should be created when disabled.
    assert not (tmp_path / "data" / "tradeoff").exists()


def test_run_local_unavailable_when_runtime_missing(monkeypatch):
    monkeypatch.delitem(sys.modules, "evaluation", raising=False)
    monkeypatch.delitem(sys.modules, "evaluation.eval_opt_classic_draft", raising=False)

    # Block the import path entirely.
    import builtins

    real_import = builtins.__import__

    def blocking_import(name, *a, **kw):
        if name.startswith("evaluation"):
            raise ImportError("simulated missing runtime")
        return real_import(name, *a, **kw)

    monkeypatch.setattr(builtins, "__import__", blocking_import)

    from autodraft.errors import LocalRuntimeUnavailableError
    from autodraft.local_runner import run_local

    with pytest.raises(LocalRuntimeUnavailableError):
        run_local(
            draft_model="d",
            target_model="t",
            draft_quantization=None,
            target_quantization=None,
            input_text="x",
        )
