## Typing stubs for www-authenticate

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`www-authenticate`](https://github.com/alexdutton/www-authenticate) package. It can be used by type checkers
to check code that uses `www-authenticate`. This version of
`types-www-authenticate` aims to provide accurate annotations for
`www-authenticate==0.9.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/www-authenticate`](https://github.com/python/typeshed/tree/main/stubs/www-authenticate)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 2.1.0
* [pyright](https://github.com/microsoft/pyright) 1.1.409

It was generated from typeshed commit
[`3402466d17144ed7edfc92940c6973167ba285af`](https://github.com/python/typeshed/commit/3402466d17144ed7edfc92940c6973167ba285af).