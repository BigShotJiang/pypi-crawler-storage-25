from .main import generate

__version__ = "1.0.2"
