import requests
import json

API_URL = "https://flashapi.floxylabs.eu/v1/chat/completions"

def generate(apiKey: str, model: str, prompt: str, streaming: bool):
    headers = {
        "Authorization": f"Bearer {apiKey}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": streaming
    }
    
    if streaming:
        response = requests.post(API_URL, headers=headers, json=payload, stream=True)
        if response.status_code == 200:
            for line in response.iter_lines():
                if line:
                    print(line.decode("utf-8"))
        else:
            print(f"Error: {response.status_code} - {response.text}")
    else:
        response = requests.post(API_URL, headers=headers, json=payload)
        if response.status_code == 200:
            print(json.dumps(response.json(), indent=2))
        else:
            print(f"Error: {response.status_code} - {response.text}")