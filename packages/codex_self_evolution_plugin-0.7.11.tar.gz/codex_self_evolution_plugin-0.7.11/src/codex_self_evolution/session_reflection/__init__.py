"""Session reflection support."""
