import pandas as pd


class sql_builder:
    """ Build SQL Tables and Store Procedures """

    def __init__(self):
        self.dtype_map = {
            "int64": "INT",
            "float64": "DECIMAL(18,5)",
            "object": "NVARCHAR(150)",
            "bool": "BIT",
            "datetime64[ns]": "DATETIME2"
        }

    def df_to_sql_table(self, df, table_name, schema="Staging", identity_id_name=None, guid_name=None,
                        modified_date=False, inserted_date=False, as_file=False):
        """
        Generate a T-SQL CREATE TABLE statement from a pandas DataFrame

        Params             Type/Requirement             Description
        df                 pandas.DataFrame, required   The DataFrame used for column names and data types
        table_name         str, required                Name of the table to be created
        schema             str, required                Target database schema for the table
        identity_id_name   str, optional                Add the name of an identity (auto-increment) column
        guid_name          list[str], optional          List of column names that should be defined as GUIDs (UNIQUEIDENTIFIER)
        modified_date      bool, optional               If True, adds a column to track last modification timestamp
        inserted_date      bool, optional               If True, adds a column to track record insertion timestamp
        as_file            bool, optional               If True, returns the CREATE TABLE statement as a .sql file else returns as a string

        Returns
        str or file if as_file is True
        """

        for i in df:
            if df[i].dtype == 'object':
                converted_col = pd.to_numeric(df[i], errors='coerce')
                if converted_col.notna().sum():
                    df[i] = converted_col
                else:
                    converted_col = pd.to_datetime(df[i], errors='coerce')
                    if converted_col.notna().sum() > 0:
                        df[i] = converted_col

        lines = []
        if identity_id_name is not None:
            lines.append(f"    [{identity_id_name}] [int] NOT NULL IDENTITY(1, 1)")

        if guid_name is not None:
            for guid in guid_name:
                lines.append(f"    [{guid}] UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID()")

        for col, dtype in df.dtypes.items():
            sql_type = self.dtype_map.get(str(dtype), "NVARCHAR(150)")
            nullable = "NOT NULL" if df[col].notna().all() else "NULL"
            lines.append(f"    [{col}] {sql_type} {nullable}")

        if modified_date and schema != "Staging":
            lines.append(f"    [ModifiedDate] DATETIME2 NULL")

        if inserted_date and schema != "Staging":
            lines.append(f"    [InsertedDate] DATETIME2 NOT NULL")

        sql_table = f"CREATE TABLE [{schema}].[{table_name}] (\n" + ",\n".join(lines) + "\n);" + "\n"

        if as_file:
            with open(f"tbl_{schema.lower()}_{table_name.lower()}.sql", "w", encoding="utf-8") as f:
                f.write(sql_table)
        else:
            return sql_table

    def df_to_sql_proc_builder(self, df, source_schema, target_schema, table_name, id_cols,
                               guid_name=None, modified_date=False, inserted_date=False, as_file=False):
        """
        Generate a T-SQL CREATE PROCEDURE statement from a pandas DataFrame

        Params             Type/Requirement             Description
        df                 pandas.DataFrame, required   The DataFrame used for column names and data types
        source_schema      str, required                Source database schema for the staging table
        target_schema      str, required                Target database schema for the Target table
        table_name         str, required                Name of the table to be used as source and target
        id_cols            list[str], required          List of column names that are to be used as id
        guid_name          list[str], optional          List of guids to be added to id_cols
        modified_date      bool, optional               If True, adds modified_date to update and insert
        inserted_date      bool, optional               If True, adds inserted_date to insert
        as_file            bool, optional               If True, returns the CREATE PROCEDURE statement as a .sql file else returns as a string

        Returns
        str or file if as_file is True
        """

        cols = list(df.columns)
        non_ids = [c for c in cols if c not in id_cols]

        if guid_name is not None:
            for guid in guid_name:
                id_cols.append(guid)

        # Staging Select
        select_cols = ",\n          ".join(cols)

        # Update
        update_set = ",\n          ".join(
            [f"Target.{c} = Source.{c}" for c in non_ids]
            + (["Target.ModifiedDate = GETDATE()"] if modified_date else [])
        )

        # Update Where
        comparisons = []
        for i in non_ids:
            if df[i].dtype == "object":
                comparisons.append(f"ISNULL(Source.{i}, '') <> ISNULL(Target.{i}, '')")
            else:
                comparisons.append(f"Source.{i} <> Target.{i}")

        where_clause = "\n              OR ".join(comparisons)

        insert_cols = ",\n            ".join(
            cols + (["ModifiedDate"] if modified_date else []) + (["InsertedDate"] if inserted_date else []))

        insert_select = ",\n            ".join(
            [f"Source.{c}" for c in cols] + (["NULL"] if modified_date else []) + (
                ["GETDATE()"] if insert_cols else []))

        join_condition = " AND ".join([f"Source.{k} = Target.{k}" for k in id_cols])

        sql_proc = f"""
            CREATE PROCEDURE [{target_schema}].[spLoad{table_name}]
            AS
            SET NOCOUNT ON;
        
            BEGIN
                BEGIN TRY
                    BEGIN TRANSACTION;
        
                    DROP TABLE IF EXISTS #Stage;
        
                    -- Create staging table --
                    SELECT
                        {select_cols}
                    INTO #Stage
                    FROM [{source_schema}].[{table_name}];
        
                    -- Create Update --
                    UPDATE Target
                    SET
                        {update_set}
                    FROM #Stage Source
                    JOIN [{target_schema}].[{table_name}] Target
                        ON {join_condition}
                    WHERE {where_clause};
        
                    -- Create Insert --
                    INSERT INTO [{target_schema}].[{table_name}]
                    (
                        {insert_cols}
                    )
                    SELECT
                        {insert_select}
                    FROM #Stage Source
                    LEFT JOIN {target_schema}.{table_name} Target
                        ON {join_condition}
                    WHERE Target.{id_cols[0]} IS NULL;
        
                    -- Delete Staging table --
                    DELETE staging
                    FROM #Stage stage
                    JOIN [{source_schema}].[{table_name}] staging
                        ON {join_condition};
        
                    SELECT Success = 1;
                END TRY
                BEGIN CATCH
                    IF @@TRANCOUNT > 0
                        ROLLBACK TRAN;
        
                    DECLARE @ErrorMessage NVARCHAR(4000);
                    DECLARE @ErrorSeverity INT;
                    DECLARE @ErrorState INT;
                    DECLARE @ErrorProc NVARCHAR(4000);
        
                    SELECT
                        @ErrorMessage  = ERROR_MESSAGE()
                      , @ErrorSeverity = ERROR_SEVERITY()
                      , @ErrorState    = ERROR_STATE()
                      , @ErrorProc     = ERROR_PROCEDURE();
        
                    RAISERROR(   @ErrorMessage  -- Message text.  
                               , @ErrorSeverity -- Severity.  
                               , @ErrorState    -- State.  
                               , @ErrorProc
                             );
                END CATCH;
        
                COMMIT TRANSACTION;
            END;
            GO
        """
        if as_file:
            with open(f"proc_{target_schema.lower()}_{table_name.lower()}.sql", "w", encoding="utf-8") as f:
                f.write(sql_proc)
        else:
            return sql_proc

    def build_all(self, df, source_schema, target_schema, table_name, id_cols=None, identity_id_name=None,
                  guid_name=None, modified_date=False, inserted_date=False, as_file=False):
        """
        Generate a Staging and Target T-SQL CREATE TABLE and T-SQL CREATE PROCEDURE statement from a pandas DataFrame

        Params             Type/Requirement             Description
        df                 pandas.DataFrame, required   The DataFrame used for column names and data types
        source_schema      str, required                Source database schema for the staging table and proc
        target_schema      str, required                Target database schema for the Target table and proc
        table_name         str, required                Name of the table to be used as source and target
        id_cols            list[str], required          List of column names that are to be used as id
        guid_name          list[str], optional          List of column names that should be defined as GUIDs (UNIQUEIDENTIFIER) and added to id_cols
        modified_date      bool, optional               If True, adds modified_date to target table, proc update and insert
        inserted_date      bool, optional               If True, adds inserted_date to target table and proc insert
        as_file            bool, optional               If True, returns the CREATE PROCEDURE statement as a .sql file else returns as a string

        Returns
        str or file if as_file is True
        """

        staging_sql = self.df_to_sql_table(df=df, table_name=table_name, schema=source_schema,
                                           identity_id_name=identity_id_name, guid_name=guid_name,
                                           modified_date=modified_date, inserted_date=inserted_date)

        target_sql = self.df_to_sql_table(df=df, table_name=table_name, schema=target_schema,
                                          identity_id_name=identity_id_name, guid_name=guid_name,
                                          modified_date=modified_date, inserted_date=inserted_date)

        proc_sql = self.df_to_sql_proc_builder(df=df, source_schema=source_schema, target_schema=target_schema,
                                               table_name=table_name, id_cols=id_cols, modified_date=modified_date,
                                               inserted_date=inserted_date)

        full_sql = f"""
        --STAGING TABLE--
        {staging_sql}

        ---TARGET TABLE--
        {target_sql}

        --STORED PROCEDURE--
        {proc_sql}
        """
        if as_file:
            with open(f"all_{target_schema.lower()}_{table_name.lower()}.sql", "w", encoding="utf-8") as f:
                f.write(full_sql)
        else:
            return full_sql