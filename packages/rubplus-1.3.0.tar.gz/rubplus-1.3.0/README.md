# RubPlus 🚀

**Official Rubika Bot API wrapper - Simple, Modern, Powerful**

[![Python Version](https://img.shields.io/badge/python-3.8+-blue.svg)]()
[![License](https://img.shields.io/badge/license-MIT-green.svg)]()
[![Version](https://img.shields.io/badge/version-1.3.0-orange.svg)]()

## ✨ Features

- **Simple** - Short and intuitive method names
- **Modern** - Async/await, type hints
- **Powerful** - All official API methods
- **Text Format** - Bold, Italic, Monospace, Link, Mention
- **Webhook** - Receive updates via webhook

## 📦 Installation

```bash
pip install rubplus