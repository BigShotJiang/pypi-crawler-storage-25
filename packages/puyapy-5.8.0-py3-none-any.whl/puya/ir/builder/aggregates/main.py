import typing

import attrs

from puya import log
from puya.errors import CodeError, InternalError
from puya.ir import (
    encodings,
    models as ir,
    types_ as types,
)
from puya.ir._puya_lib import PuyaLibIR
from puya.ir.avm_ops import AVMOp
from puya.ir.builder.aggregates import arc4_codecs, sequence, tup
from puya.ir.encodings import ArrayEncoding, Encoding, TupleEncoding
from puya.ir.mutating_register_context import MutatingRegisterContext
from puya.ir.op_utils import OpFactory, assert_value

logger = log.get_logger(__name__)


def lower_aggregate_nodes(program: ir.Program) -> None:
    embedded_funcs = {PuyaLibIR(s.id): s for s in program.subroutines if s.id in PuyaLibIR}
    for sub in program.all_subroutines:
        replacer = _AggregateNodeReplacer(
            embedded_funcs=embedded_funcs, subroutine=sub, temp_prefix="aggregate"
        )
        for block in sub.body:
            replacer.visit_block(block)
        sub.validate_with_ssa()


@attrs.define(kw_only=True)
class _AggregateNodeReplacer(MutatingRegisterContext):
    @typing.override
    def visit_bytes_encode(self, encode: ir.BytesEncode) -> ir.ValueProvider:
        return arc4_codecs.encode_to_bytes(
            self,
            values=encode.values,
            values_type=encode.values_type,
            encoding=encode.encoding,
            error_message_override=encode.error_message_override,
            loc=encode.source_location,
        )

    @typing.override
    def visit_decode_bytes(self, decode: ir.DecodeBytes) -> ir.ValueProvider:
        return arc4_codecs.decode_bytes(
            self,
            decode.value,
            encoding=decode.encoding,
            target_type=decode.ir_type,
            error_message_override=decode.error_message_override,
            loc=decode.source_location,
        )

    @typing.override
    def visit_array_length(self, length: ir.ArrayLength) -> ir.ValueProvider:
        return sequence.get_length(
            self, length.array_encoding, length.base, length.source_location
        )

    @typing.override
    def visit_array_pop(self, pop: ir.ArrayPop) -> ir.ValueProvider:
        array_encoding = pop.array_encoding
        assert array_encoding.size is None, "expected DynamicArray encoding"
        factory = OpFactory(self, pop.source_location)
        element_encoding = array_encoding.element
        if not array_encoding.length_header:
            if element_encoding.is_dynamic or element_encoding.is_bit:
                raise CodeError(
                    f"unsupported dynamic array type {array_encoding}", pop.source_location
                )
            return factory.invoke(PuyaLibIR.r_trim, [pop.base, element_encoding.checked_num_bytes])
        elif element_encoding.is_bit:
            return factory.invoke(PuyaLibIR.dynamic_array_pop_bit, [pop.base])
        elif encodings.is_byte_length_dynamic_array(element_encoding):
            return factory.invoke(PuyaLibIR.dynamic_array_pop_byte_length_head, [pop.base])
        elif element_encoding.is_dynamic:
            return factory.invoke(PuyaLibIR.dynamic_array_pop_dynamic_element, [pop.base])
        else:
            return factory.invoke(
                PuyaLibIR.dynamic_array_pop_fixed_size,
                [pop.base, element_encoding.checked_num_bytes],
            )

    @typing.override
    def visit_array_concat(self, concat: ir.ArrayConcat) -> ir.ValueProvider:
        loc = concat.source_location
        array_encoding = concat.array_encoding
        assert array_encoding.size is None, "expected DynamicArray encoding"
        element_encoding = array_encoding.element
        factory = OpFactory(self, loc)
        if not array_encoding.length_header:
            if element_encoding.is_dynamic or element_encoding.is_bit:
                raise CodeError(f"unsupported dynamic array type {array_encoding}", loc)
            return factory.concat(
                concat.base,
                concat.items,
                ir_type=concat.base_type,
                error_message="max array length exceeded",
            )
        elif element_encoding.is_bit:
            element_bits = concat.item_encoding.num_bits
            assert element_bits in (1, 8)
            return factory.invoke(
                PuyaLibIR.dynamic_array_concat_bits,
                [concat.base, concat.items, concat.num_items, element_bits],
            )
        elif encodings.is_byte_length_dynamic_array(array_encoding.element):
            return factory.invoke(
                PuyaLibIR.dynamic_array_concat_byte_length_head,
                [concat.base, concat.items, concat.num_items],
            )
        elif element_encoding.is_dynamic:
            return factory.invoke(
                PuyaLibIR.dynamic_array_concat_dynamic_element,
                [concat.base, concat.items, concat.num_items],
            )
        else:
            return factory.invoke(
                PuyaLibIR.dynamic_array_concat_fixed,
                [concat.base, concat.items, concat.num_items],
            )

    @typing.override
    def visit_extract_value(self, read: ir.ExtractValue) -> ir.Value:
        loc = read.source_location

        aggregate_encoding = read.base_type.encoding
        base = read.base
        base_encoding: Encoding = aggregate_encoding
        for index in read.indexes:
            if isinstance(base_encoding, TupleEncoding):
                assert isinstance(index, int), "expected int"
                base = tup.read_at_index(self, base_encoding, base, index, loc)
                base_encoding = base_encoding.elements[index]
            elif isinstance(base_encoding, ArrayEncoding):
                if isinstance(index, int):
                    index = ir.UInt64Constant(value=index, source_location=loc)
                base = sequence.read_at_index(
                    self, base_encoding, base, index, loc, assert_bounds=read.check_bounds
                )
                base_encoding = base_encoding.element
            else:
                raise InternalError("invalid aggregate encoding and index", loc)

        return base

    @typing.override
    def visit_replace_value(self, write: ir.ReplaceValue) -> ir.Value:
        loc = write.source_location

        base = write.base
        base_encoding = write.base_type.encoding
        bases = [(base, base_encoding)]
        for index in write.indexes[:-1]:
            if isinstance(base_encoding, TupleEncoding):
                assert isinstance(index, int), "expected int"
                base = tup.read_at_index(self, base_encoding, base, index, loc)
                base_encoding = base_encoding.elements[index]
            elif isinstance(base_encoding, ArrayEncoding):
                if isinstance(index, int):
                    index = ir.UInt64Constant(value=index, source_location=loc)
                base = sequence.read_at_index(self, base_encoding, base, index, loc)
                base_encoding = base_encoding.element
            else:
                raise InternalError("invalid aggregate encoding and index", loc)
            bases.append((base, base_encoding))

        value = write.value
        for index in reversed(write.indexes):
            base, base_encoding = bases.pop()
            if isinstance(base_encoding, TupleEncoding):
                assert isinstance(index, int), "expected int"
                value = tup.write_at_index(self, base_encoding, base, index, value, loc)
            elif isinstance(base_encoding, ArrayEncoding):
                if isinstance(index, int):
                    index = ir.UInt64Constant(value=index, source_location=loc)
                value = sequence.write_at_index(self, base_encoding, base, index, value, loc)
            else:
                raise InternalError("invalid aggregate encoding and index", loc)

        return value

    @typing.override
    def visit_box_read(self, read: ir.BoxRead) -> ir.ValueProvider:
        loc = read.source_location

        box_get = ir.Intrinsic(
            op=AVMOp.box_get,
            args=[read.key],
            types=[*read.types, types.bool_],
            source_location=loc,
        )
        box_value, box_exists = self.materialise_value_provider(box_get, "box_get")
        assert_value(
            self, box_exists, error_message=read.exists_assertion_message, source_location=loc
        )
        return box_value

    @typing.override
    def visit_box_write(self, write: ir.BoxWrite) -> ir.Intrinsic:
        if write.delete_first:
            self.add_op(
                ir.Intrinsic(
                    op=AVMOp.box_del,
                    args=[write.key],
                    source_location=write.source_location,
                )
            )
        return ir.Intrinsic(
            op=AVMOp.box_put,
            args=[write.key, write.value],
            source_location=write.source_location,
        )
