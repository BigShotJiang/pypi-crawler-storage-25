import contextlib
import operator
import typing
import warnings
from collections.abc import Callable, Iterator, Mapping, Sequence
from functools import cached_property
from itertools import zip_longest

import attrs
import mypy.nodes
import mypy.types

from puya import log
from puya.errors import CodeError, InternalError
from puya.parse import SourceLocation
from puya.utils import unique
from puyapy.awst_build import pytypes
from puyapy.awst_build.context import ASTConversionModuleContext
from puyapy.awst_build.eb.factories import builder_for_type
from puyapy.awst_build.eb.interface import InstanceBuilder, NodeBuilder, TypeBuilder
from puyapy.models import ArgKind, ConstantValue

logger = log.get_logger(__name__)


def refers_to_fullname(ref_expr: mypy.nodes.RefExpr, *fullnames: str) -> bool:
    """Is node a name or member expression with the given full name?"""
    if isinstance(ref_expr.node, mypy.nodes.TypeAlias):
        return mypy.types.is_named_instance(ref_expr.node.target, fullnames)
    else:
        return ref_expr.fullname in fullnames


def get_unaliased_fullname(ref_expr: mypy.nodes.RefExpr) -> str:
    alias = get_aliased_instance(ref_expr)
    if alias:
        return alias.type.fullname
    return ref_expr.fullname


def get_aliased_instance(ref_expr: mypy.nodes.RefExpr) -> mypy.types.Instance | None:
    if isinstance(ref_expr.node, mypy.nodes.TypeAlias):
        t = mypy.types.get_proper_type(ref_expr.node.target)
        if isinstance(t, mypy.types.Instance):
            return t
        if (
            isinstance(t, mypy.types.TupleType)
            and t.partial_fallback.type.fullname != "builtins.tuple"
        ):
            return t.partial_fallback
    return None


@attrs.frozen(kw_only=True)
class DecoratorArg:
    expr: mypy.nodes.Expression
    kind: ArgKind
    name: str | None


@attrs.frozen(kw_only=True)
class DecoratorInfo:
    callee: mypy.nodes.RefExpr
    args: Sequence[DecoratorArg] | None
    loc: SourceLocation

    @cached_property
    def fullname(self) -> str:
        return _expand_ref_expr(self.callee)


def _expand_ref_expr(expr: mypy.nodes.RefExpr) -> str:
    match expr:
        case mypy.nodes.NameExpr(name=name):
            return name
        case mypy.nodes.MemberExpr(expr=mypy.nodes.RefExpr() as base, name=name):
            return f"{_expand_ref_expr(base)}.{name}"
        case _:
            return expr.fullname


def get_decorators_by_fullname(
    ctx: ASTConversionModuleContext,
    decorator: mypy.nodes.Decorator,
    *,
    original: bool = False,
) -> dict[str, DecoratorInfo]:
    result = dict[str, DecoratorInfo]()
    for d in decorator.original_decorators if original else decorator.decorators:
        args = None
        if isinstance(d, mypy.nodes.CallExpr):
            callee = d.callee
            args = [
                DecoratorArg(expr=expr, kind=kind, name=name)
                for expr, kind, name in zip(d.args, d.arg_kinds, d.arg_names, strict=True)
            ]
        else:
            callee = d
        loc = ctx.node_location(d)
        if not isinstance(callee, mypy.nodes.RefExpr):
            logger.error("unsupported decorator usage", location=loc)
        else:
            full_name = get_unaliased_fullname(callee)
            if full_name in result:
                logger.error("duplicate decorator", location=loc)
            result[full_name] = DecoratorInfo(callee=callee, args=args, loc=loc)
    return result


UNARY_OPS: typing.Final[Mapping[str, Callable[[typing.Any], typing.Any]]] = {
    "~": operator.inv,
    "not": operator.not_,
    "+": operator.pos,
    "-": operator.neg,
}


@contextlib.contextmanager
def _log_warnings(location: SourceLocation) -> Iterator[None]:
    folding_warnings = []
    try:
        with warnings.catch_warnings(record=True, action="always") as folding_warnings:
            yield
    finally:
        for warning in folding_warnings:
            logger.warning(warning.message, location=location)


def fold_unary_expr(location: SourceLocation, op: str, expr: ConstantValue) -> ConstantValue:
    if not (func := UNARY_OPS.get(op)):
        raise InternalError(f"Unhandled unary operator: {op}", location)
    if op == "~" and isinstance(expr, int):
        logger.warning(
            "due to Python ints being signed, bitwise inversion yield a negative number",
            location=location,
        )
    try:
        with _log_warnings(location):
            result = func(expr)
    except Exception as ex:
        raise CodeError(str(ex), location) from ex
    if not isinstance(result, ConstantValue):
        raise CodeError(f"unsupported result type of {type(result).__name__}", location)
    return result


BINARY_OPS: typing.Final[Mapping[str, Callable[[typing.Any, typing.Any], typing.Any]]] = {
    "+": operator.add,
    "-": operator.sub,
    "*": operator.mul,
    "@": operator.matmul,
    "/": operator.truediv,
    "%": operator.mod,
    "**": operator.pow,
    "<<": operator.lshift,
    ">>": operator.rshift,
    "|": operator.or_,
    "^": operator.xor,
    "&": operator.and_,
    "//": operator.floordiv,
    ">": operator.gt,
    "<": operator.lt,
    "==": operator.eq,
    ">=": operator.ge,
    "<=": operator.le,
    "!=": operator.ne,
    "is": operator.is_,
    "is not": operator.is_not,
    "in": lambda a, b: a in b,
    "not in": lambda a, b: a not in b,
    "and": lambda a, b: a and b,
    "or": lambda a, b: a or b,
}


def fold_binary_expr(
    location: SourceLocation,
    op: str,
    lhs: ConstantValue,
    rhs: ConstantValue,
) -> ConstantValue:
    if not (func := BINARY_OPS.get(op)):
        raise InternalError(f"Unhandled binary operator: {op}", location)
    try:
        with _log_warnings(location):
            result = func(lhs, rhs)
    except Exception as ex:
        raise CodeError(str(ex), location) from ex
    if not isinstance(result, ConstantValue):
        raise CodeError(f"unsupported result type of {type(result).__name__}", location)
    return result


def extract_bytes_literal_from_mypy(expr: mypy.nodes.BytesExpr) -> bytes:
    import ast

    bytes_str = expr.value
    # mypy doesn't preserve the value of the quotes, need to reverse it
    if '"' in bytes_str:
        bytes_literal = "b'" + bytes_str + "'"
    else:
        bytes_literal = 'b"' + bytes_str + '"'
    bytes_const: bytes = ast.literal_eval(bytes_literal)
    return bytes_const


TBuilder = typing.TypeVar("TBuilder", bound=NodeBuilder)


def get_arg_mapping(
    *,
    required_positional_names: Sequence[str] | None = None,
    optional_positional_names: Sequence[str] | None = None,
    required_kw_only: Sequence[str] | None = None,
    optional_kw_only: Sequence[str] | None = None,
    args: Sequence[TBuilder],
    arg_names: Sequence[str | None],
    call_location: SourceLocation,
    raise_on_missing: bool,
) -> tuple[dict[str, TBuilder], bool]:
    required_positional_names = required_positional_names or []
    optional_positional_names = optional_positional_names or []
    required_kw_only = required_kw_only or []
    optional_kw_only = optional_kw_only or []
    all_names = [
        *required_positional_names,
        *optional_positional_names,
        *required_kw_only,
        *optional_kw_only,
    ]
    if len(all_names) != len(set(all_names)):
        raise InternalError("duplicate names", call_location)

    arg_mapping = dict[str, TBuilder]()
    num_positionals = arg_names.count(None)
    positional_names = [*required_positional_names, *optional_positional_names]
    for positional_name, positional_arg in zip_longest(positional_names, args[:num_positionals]):
        if positional_name is None:
            logger.error("unexpected positional argument", location=positional_arg.source_location)
        elif positional_arg is None:
            break  # positional arguments could be named
        else:
            arg_mapping[positional_name] = positional_arg
    for arg_name, kw_arg in zip(arg_names[num_positionals:], args[num_positionals:], strict=True):
        if arg_name is None:
            # shouldn't be possible, might happen with type ignore?
            logger.error(
                "non-keyword argument appears after keywords", location=kw_arg.source_location
            )
        elif arg_name in arg_mapping:
            # again, shouldn't be possible, but might happen with type ignore?
            logger.error("duplicate argument name", location=kw_arg.source_location)
        elif arg_name not in all_names:
            logger.error("unrecognised keyword argument", location=kw_arg.source_location)
        else:
            arg_mapping[arg_name] = kw_arg
    any_missing = False
    if missing_args := set(required_positional_names).difference(arg_mapping.keys()):
        msg = f"missing required positional argument(s): {', '.join(sorted(missing_args))}"
        if raise_on_missing:
            raise CodeError(msg, call_location)
        any_missing = True
        logger.error(msg, location=call_location)
    elif missing_kwargs := set(required_kw_only).difference(arg_mapping.keys()):
        msg = f"missing required keyword argument(s): {', '.join(sorted(missing_kwargs))}"
        if raise_on_missing:
            raise CodeError(msg, call_location)
        any_missing = True
        logger.error(msg, location=call_location)
    return arg_mapping, any_missing


def maybe_resolve_literal(
    operand: TBuilder, target_type: pytypes.PyType
) -> TBuilder | InstanceBuilder:
    if not isinstance(operand, InstanceBuilder):
        return operand
    if not (target_type <= operand.pytype):
        target_type_builder = builder_for_type(target_type, operand.source_location)
        if isinstance(target_type_builder, TypeBuilder):
            return operand.resolve_literal(target_type_builder)
    return operand


def resolve_literal(operand: InstanceBuilder, target_type: pytypes.PyType) -> InstanceBuilder:
    target_type_builder = builder_for_type(target_type, operand.source_location)
    assert isinstance(target_type_builder, TypeBuilder)
    return operand.resolve_literal(target_type_builder)


def determine_base_type(
    first: pytypes.PyType, *rest: pytypes.PyType, location: SourceLocation
) -> pytypes.PyType:
    operands = unique((first, *rest))
    if len(operands) == 1:
        return first
    for candidate in operands:
        if all(candidate <= operand for operand in operands):
            return candidate
    return pytypes.UnionType(operands, location)


def extract_decorator_args(
    decorator: DecoratorInfo,
) -> list[tuple[str | None, mypy.nodes.Expression]]:
    if decorator.args is None:
        return []
    return [(arg.name, arg.expr) for arg in decorator.args]


def get_subroutine_decorator_inline_arg(
    context: ASTConversionModuleContext, decorator: DecoratorInfo
) -> bool | None:
    args = extract_decorator_args(decorator)
    for name, expr in args:
        match name, expr:
            case "inline", mypy.nodes.NameExpr(fullname="builtins.True"):
                return True
            case "inline", mypy.nodes.NameExpr(fullname="builtins.False"):
                return False
            case "inline", mypy.nodes.NameExpr(fullname="builtins.None"):
                return None
            case _:
                logger.error("unexpected argument", location=context.node_location(expr))
    return None


def tuple_iterable_item_type(
    pytype: pytypes.TupleLikeType, source_location: SourceLocation
) -> pytypes.PyType:
    if not pytype.items:
        raise CodeError("cannot determine item type of empty tuple", source_location)
    base_type = determine_base_type(*pytype.items, location=source_location)
    if isinstance(base_type, pytypes.UnionType):
        raise CodeError(
            "unable to iterate heterogeneous tuple without common base type", source_location
        )
    return base_type
