import asyncio
from functools import wraps
import types
from typing import Any, AsyncGenerator, Callable, Generator, Literal, TypeVar

from opentelemetry import context as context_api
from opentelemetry.trace import Span, Status, StatusCode

from lmnr.opentelemetry_lib.tracing.context import (
    CONTEXT_METADATA_KEY,
    attach_context,
    detach_context,
    get_event_attributes_from_context,
)
from lmnr.opentelemetry_lib.tracing.span import LaminarSpan
from lmnr.opentelemetry_lib.tracing.utils import set_association_props_in_context
from lmnr.sdk.utils import get_input_from_func_args, is_method
from lmnr.opentelemetry_lib.tracing.tracer import get_tracer_with_context
from lmnr.opentelemetry_lib.tracing.attributes import (
    ASSOCIATION_PROPERTIES,
    METADATA,
    ROLLOUT_SESSION_ID_ATTR,
    SPAN_TYPE,
)
from lmnr.opentelemetry_lib.tracing import TracerWrapper
from lmnr.sdk.log import get_default_logger
from lmnr.sdk.utils import is_otel_attribute_value_type, json_dumps

logger = get_default_logger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def _setup_span(
    span_name: str,
    span_type: str,
    association_properties: dict[str, Any] | None,
    preserve_global_context: bool = False,
    metadata: dict[str, Any] | None = None,
) -> Span | None:
    """Set up a span with the given name, type, and association properties."""
    span = None
    try:
        with get_tracer_with_context() as (tracer, isolated_context):
            # Create span in isolated context
            span = tracer.start_span(
                span_name,
                context=isolated_context if not preserve_global_context else None,
                attributes={SPAN_TYPE: span_type},
            )

            ctx_metadata = context_api.get_value(CONTEXT_METADATA_KEY, isolated_context)
            merged_metadata = {
                **(ctx_metadata or {}),
                **(metadata or {}),
            }
            for key, value in merged_metadata.items():
                span.set_attribute(
                    f"{ASSOCIATION_PROPERTIES}.{METADATA}.{key}",
                    (
                        value
                        if is_otel_attribute_value_type(value)
                        else json_dumps(value)
                    ),
                )

            if association_properties is not None:
                for key, value in association_properties.items():
                    span.set_attribute(f"{ASSOCIATION_PROPERTIES}.{key}", value)
                    if key == "rollout_session_id":
                        # special case, rollout session id is stored in a separate attribute
                        span.set_attribute(ROLLOUT_SESSION_ID_ATTR, value)

            return span
    except Exception:
        logger.warning(f"[observe] failed to setup span: {span_name}", exc_info=True)
        return span


def _process_input(
    span: Span,
    fn: Callable,
    args: tuple,
    kwargs: dict,
    ignore_input: bool,
    ignore_inputs: list[str] | None,
    input_formatter: Callable[..., str] | None,
):
    """Process and set input attributes on the span."""
    if ignore_input:
        return

    try:
        if input_formatter is not None:
            inp = input_formatter(*args, **kwargs)
        else:
            inp = get_input_from_func_args(
                fn,
                is_method=is_method(fn),
                func_args=args,
                func_kwargs=kwargs,
                ignore_inputs=ignore_inputs,
            )

        if not isinstance(span, LaminarSpan):
            span = LaminarSpan(span)
        span.set_input(inp)
    except Exception:
        msg = "Failed to process input, ignoring"
        if input_formatter is not None:
            # Only warn the user if they provided an input formatter
            # because it's their responsibility to make sure it works.
            logger.warning(msg, exc_info=True)
        else:
            logger.debug(msg, exc_info=True)


def _process_output(
    span: Span,
    result: Any,
    ignore_output: bool,
    output_formatter: Callable[..., str] | None,
):
    """Process and set output attributes on the span."""
    if ignore_output:
        return

    try:
        if output_formatter is not None:
            output = output_formatter(result)
        else:
            output = result

        if not isinstance(span, LaminarSpan):
            span = LaminarSpan(span)
        span.set_output(output)
    except Exception:
        msg = "Failed to process output, ignoring"
        if output_formatter is not None:
            # Only warn the user if they provided an output formatter
            # because it's their responsibility to make sure it works.
            logger.warning(msg, exc_info=True)
        else:
            logger.debug(msg, exc_info=True)


def _cleanup_span(span: Span, wrapper: TracerWrapper, do_pop_context: bool = True):
    """Clean up span and context."""
    try:
        span.end()
    except Exception:
        logger.debug("Failed to end span in _cleanup_span", exc_info=True)
    if not do_pop_context:
        return
    try:
        wrapper.pop_span_context()
    except Exception:
        logger.debug("Failed to pop span context in _cleanup_span", exc_info=True)


def observe_base(
    *,
    name: str | None = None,
    ignore_input: bool = False,
    ignore_inputs: list[str] | None = None,
    ignore_output: bool = False,
    span_type: Literal[
        "DEFAULT",
        "LLM",
        "TOOL",
        "EXECUTOR",
        "EVALUATOR",
        "HUMAN_EVALUATOR",
        "EVALUATION",
    ] = "DEFAULT",
    metadata: dict[str, Any] | None = None,
    association_properties: dict[str, Any] | None = None,
    input_formatter: Callable[..., str] | None = None,
    output_formatter: Callable[..., str] | None = None,
    preserve_global_context: bool = False,
) -> Callable[[F], F]:
    def decorate(fn: F) -> F:
        @wraps(fn)
        def wrap(*args, **kwargs):
            if not TracerWrapper.verify_initialized():
                return fn(*args, **kwargs)

            span_name = name or getattr(fn, "__name__", "unknown")
            wrapper = None
            try:
                wrapper = TracerWrapper()
            except Exception:
                logger.debug("Failed to create tracer wrapper", exc_info=True)
                return fn(*args, **kwargs)

            span = _setup_span(
                span_name,
                span_type,
                association_properties,
                preserve_global_context,
                metadata,
            )

            if span is None:
                return fn(*args, **kwargs)

            # Set association props in context before push_span_context
            # so child spans inherit them
            assoc_props_token = set_association_props_in_context(span)
            if assoc_props_token and isinstance(span, LaminarSpan):
                span._lmnr_assoc_props_token = assoc_props_token

            ctx_token = None
            current_task = None
            current_context_id = None
            isolated_ctx_token = None
            did_push_context = False
            try:
                try:
                    current_task = asyncio.current_task()
                except Exception:
                    current_task = None
                current_context_id = id(current_task)
                new_context = wrapper.push_span_context(span)
                did_push_context = True
                # Some auto-instrumentations are not under our control, so they
                # don't have access to our isolated context. We attach the context
                # to the OTEL global context, so that spans know their parent
                # span and trace_id.
                ctx_token = context_api.attach(new_context)
                isolated_ctx_token = attach_context(new_context)
            except Exception:
                logger.debug("Failed to setup span context", exc_info=True)

            _process_input(
                span, fn, args, kwargs, ignore_input, ignore_inputs, input_formatter
            )

            try:
                res = fn(*args, **kwargs)
            except Exception as e:
                _process_exception(span, e)
                _cleanup_span(span, wrapper, did_push_context)
                raise
            finally:
                current_task = None
                try:
                    current_task = asyncio.current_task()
                except Exception:
                    current_task = None
                # Always restore global context if we are in the same asyncio context
                if id(current_task) == current_context_id:
                    try:
                        context_api.detach(ctx_token)
                    except Exception:
                        logger.debug("Failed to detach global context", exc_info=True)
                else:
                    logger.debug(
                        "Not detaching global context, not in the same context"
                    )
                try:
                    detach_context(isolated_ctx_token)
                except Exception:
                    logger.debug("Failed to detach isolated context", exc_info=True)
            # span will be ended in the generator
            if isinstance(res, types.GeneratorType):
                return _handle_generator(
                    span,
                    wrapper,
                    res,
                    ignore_output,
                    output_formatter,
                    did_push_context,
                )
            if isinstance(res, types.AsyncGeneratorType):
                # async def foo() -> AsyncGenerator[int, None]:
                # is not considered async in a classical sense in Python,
                # so we handle this inside the sync wrapper.
                # In particular, CO_COROUTINE is different from CO_ASYNC_GENERATOR.
                # Flags are listed from LSB here:
                # https://docs.python.org/3/library/inspect.html#inspect-module-co-flags
                # See also: https://groups.google.com/g/python-tulip/c/6rWweGXLutU?pli=1
                return _ahandle_generator(
                    span,
                    wrapper,
                    res,
                    ignore_output,
                    output_formatter,
                    did_push_context,
                )

            _process_output(span, res, ignore_output, output_formatter)
            _cleanup_span(span, wrapper, did_push_context)
            return res

        return wrap

    return decorate


# Async Decorators
def async_observe_base(
    *,
    name: str | None = None,
    ignore_input: bool = False,
    ignore_inputs: list[str] | None = None,
    ignore_output: bool = False,
    span_type: Literal[
        "DEFAULT",
        "LLM",
        "TOOL",
        "EXECUTOR",
        "EVALUATOR",
        "HUMAN_EVALUATOR",
        "EVALUATION",
    ] = "DEFAULT",
    metadata: dict[str, Any] | None = None,
    association_properties: dict[str, Any] | None = None,
    input_formatter: Callable[..., str] | None = None,
    output_formatter: Callable[..., str] | None = None,
    preserve_global_context: bool = False,
) -> Callable[[F], F]:
    def decorate(fn: F) -> F:
        @wraps(fn)
        async def wrap(*args, **kwargs):
            if not TracerWrapper.verify_initialized():
                return await fn(*args, **kwargs)

            span_name = name or getattr(fn, "__name__", "unknown")
            wrapper = None
            try:
                wrapper = TracerWrapper()
            except Exception:
                logger.debug("Failed to create tracer wrapper", exc_info=True)
                return await fn(*args, **kwargs)

            span = _setup_span(
                span_name,
                span_type,
                association_properties,
                preserve_global_context,
                metadata,
            )

            if span is None:
                return await fn(*args, **kwargs)

            # Set association props in context before push_span_context
            # so child spans inherit them
            assoc_props_token = set_association_props_in_context(span)
            if assoc_props_token and isinstance(span, LaminarSpan):
                span._lmnr_assoc_props_token = assoc_props_token

            ctx_token = None
            current_task = None
            current_context_id = None
            isolated_ctx_token = None
            did_push_context = False
            try:
                try:
                    current_task = asyncio.current_task()
                except Exception:
                    current_task = None
                current_context_id = id(current_task)
                new_context = wrapper.push_span_context(span)
                did_push_context = True
                # Some auto-instrumentations are not under our control, so they
                # don't have access to our isolated context. We attach the context
                # to the OTEL global context, so that spans know their parent
                # span and trace_id.
                ctx_token = context_api.attach(new_context)
                isolated_ctx_token = attach_context(new_context)
            except Exception:
                logger.debug("Failed to setup span context", exc_info=True)

            _process_input(
                span, fn, args, kwargs, ignore_input, ignore_inputs, input_formatter
            )

            try:
                res = await fn(*args, **kwargs)
            except Exception as e:
                _process_exception(span, e)
                _cleanup_span(span, wrapper, did_push_context)
                raise e
            finally:
                # Always restore global context if we are in the same asyncio context
                current_task = None
                try:
                    current_task = asyncio.current_task()
                except Exception:
                    current_task = None
                if id(current_task) == current_context_id:
                    try:
                        context_api.detach(ctx_token)
                    except Exception:
                        logger.debug("Failed to detach global context", exc_info=True)
                else:
                    logger.debug(
                        "Not detaching global context, not in the same context"
                    )
                try:
                    detach_context(isolated_ctx_token)
                except Exception:
                    logger.debug("Failed to detach isolated context", exc_info=True)

            # span will be ended in the generator
            if isinstance(res, types.AsyncGeneratorType):
                # probably unreachable, read the comment in the similar
                # part of the sync wrapper.
                return _ahandle_generator(
                    span,
                    wrapper,
                    res,
                    ignore_output,
                    output_formatter,
                    did_push_context,
                )

            _process_output(span, res, ignore_output, output_formatter)
            _cleanup_span(span, wrapper, did_push_context)
            return res

        return wrap

    return decorate


def _handle_generator(
    span: Span,
    wrapper: TracerWrapper,
    res: Generator,
    ignore_output: bool = False,
    output_formatter: Callable[..., str] | None = None,
    did_push_context: bool = True,
):
    results = []
    try:
        for part in res:
            results.append(part)
            yield part
    except Exception as e:
        _process_exception(span, e)
        raise
    finally:
        _process_output(span, results, ignore_output, output_formatter)
        _cleanup_span(span, wrapper, did_push_context)


async def _ahandle_generator(
    span: Span,
    wrapper: TracerWrapper,
    res: AsyncGenerator,
    ignore_output: bool = False,
    output_formatter: Callable[..., str] | None = None,
    did_push_context: bool = True,
):
    results = []
    try:
        async for part in res:
            results.append(part)
            yield part
    except Exception as e:
        _process_exception(span, e)
        raise
    finally:
        _process_output(span, results, ignore_output, output_formatter)
        _cleanup_span(span, wrapper, did_push_context)


def _process_exception(span: Span, e: Exception):
    try:
        # Note that this `escaped` is sent as a StringValue("True"), not a boolean.
        span.record_exception(
            e, attributes=get_event_attributes_from_context(), escaped=True
        )
        span.set_status(Status(StatusCode.ERROR, str(e)))
    except Exception:
        logger.debug("Failed to process exception", exc_info=True)
