"""MCP resource implementations."""
