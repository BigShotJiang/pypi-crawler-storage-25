"""MCP prompt implementations."""
