"""Prompts for faithfulness judge."""
