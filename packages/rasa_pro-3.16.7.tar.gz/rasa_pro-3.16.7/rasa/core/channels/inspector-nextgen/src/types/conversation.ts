import type { FlexProps } from "@chakra-ui/react";
import type { IconDefinition } from "@fortawesome/fontawesome-svg-core";

export type InspectorEventType = ConversationEvent | StackEvent | Utterance;

export type StackEvent = {
  __typename: "StackEvent";
  id: string;
  metadata: EventMetadata;
  timestamp: string;
  update?: string;
};

export enum ConversationEventType {
  Action = "ACTION",
  ActiveLoop = "ACTIVE_LOOP",
  AgentCancelled = "AGENT_CANCELLED",
  AgentCompleted = "AGENT_COMPLETED",
  AgentInterrupted = "AGENT_INTERRUPTED",
  AgentResumed = "AGENT_RESUMED",
  AgentStarted = "AGENT_STARTED",
  FlowCancelled = "FLOW_CANCELLED",
  FlowCompleted = "FLOW_COMPLETED",
  FlowInterrupted = "FLOW_INTERRUPTED",
  FlowResumed = "FLOW_RESUMED",
  FlowStarted = "FLOW_STARTED",
  Form = "FORM",
  ResetSlots = "RESET_SLOTS",
  Restart = "RESTART",
  SessionStarted = "SESSION_STARTED",
  Slot = "SLOT",
}

export type Conversation = {
  events: UnionEventType[];
  id: string;
  reviewed: boolean;
  startDate: string;
  totalNumberOfUserMessages: number;
};

type UtteranceEntity = {
  confidence: number;
  endPosition: number;
  id: string;
  name: string;
  startPosition: number;
  value: string;
};

export enum UtteranceType {
  Bot = "BOT",
  User = "USER",
}

type Token = {
  end: number;
  start: number;
  text: string;
};
export type QuickReply = {
  imageUrl?: string;
  payload: string;
  title: string;
};

export type Button = {
  imageUrl?: string;
  payload: string;
  title: string;
};

export type ResponseData = {
  attachment?: string;
  buttons: Button[];
  custom?: Record<string, unknown>;
  elements?: string;
  image?: string;
  quickReplies: QuickReply[];
};

export type UtteranceIntent = {
  confidence: number;
  id: string;
  name: string;
};
export type ConversationEvent = {
  __typename: "ConversationEvent";
  actionText: string;
  conversationEventType: ConversationEventType;
  flowId: string;
  id: string;
  metadata: EventMetadata;
  name: string;
  slotValue: string | null;
  stepId: string;
  timestamp: string;
};

export type Utterance = {
  __typename: "Utterance";
  commands?: unknown;
  id: string;
  metadata: EventMetadata;
  rephrase: boolean;
  rephrasePrompt: string | null;
  responseData?: ResponseData;
  text: string;
  timestamp: string;
  tokens: Token[];
  type: UtteranceType;
  intents?: UtteranceIntent[];
  entities?: UtteranceEntity[];
};

export type UnionEventType = ConversationEvent | Utterance;

export type EventMetadata = {
  active_flow?: string;
  utter_action?: string;
  flow_id?: string;
  execution_success?: boolean;
  execution_error_message?: string;
  step_id?: string;
  rawEvent?: RawEvent;
  reset?: boolean;
  was_modified_by_studio?: boolean;
  domain_ground_truth?: string;
  metadata?: {
    rephrase?: boolean;
    rephrasePrompt?: string;
  };
  parseData: unknown;
};

export type RawEvent = {
  name: string;
  metadata: EventMetadata;
  timestamp: number;
  event: "user" | "stack" | "action" | "bot" | "slot" | "agent" | "agent_started" | "agent_completed" | "agent_interrupted" | "agent_cancelled" | "agent_resumed";
  conversation_id: string;
  text: string;
  data: BackendResponseData;
  update: string;
  flow_id: string;
  step_id: string;
  value: string;
  parse_data: {
    intent_ranking: MessageIntent[];
    commands?: string;
  };
};

export type ModelServiceError = {
  message: string;
  error: string;
  exception?: string;
};

export type RawStack = {
  frame_id: string;
  flow_id: string;
  step_id: string;
  collect?: string;
  utter?: string;
};

export type Stack = {
  frameId: string;
  flowId: string;
  stepId: string;
  collect?: string;
  utter?: string;
  ended: boolean;
};

export type SlotState = {
  name: string;
  value: unknown;
};

export type MessageIntent = {
  name: string;
  confidence: number;
};

export type RasaProError = {
  message: string;
  error: string;
  exception?: string;
};

export type BackendResponseData = {
  attachment: {
    type: string;
    payload: {
      src: string;
      url: string;
      elements: string;
    };
  };
  quick_replies: (QuickReply & { image_url?: string })[];
  buttons: (Button & { image_url?: string })[];
  elements: string;
  image: string;
  text: string;
};

export type TrackerResponseData = {
  sender_id: string;
  events: RawEvent[];
  slots: Record<string, SlotState>;
  stack: RawStack[];
};

export type MessageProps = FlexProps & {
  utterance: Omit<Utterance, "entities">;
  previousUtterance?: Omit<Utterance, "entities">;
  isHighlighted?: boolean;
  isInteractive?: boolean;
  onQuickReply?: (payload: string) => void;
  selectable?: boolean;
  isSelected?: boolean;
  onMessageSelect?: (selection: Utterance) => void;
  inspectorMode?: boolean;
};

export type ConversationEventAction = {
  icon: IconDefinition;
  label: string;
  action: (event: UnionEventType) => void
};

export type MessagePropsWithTopIntentName = MessageProps & {
  topIntentName?: string;
  conversationEventActions?: ConversationEventAction[];
};
