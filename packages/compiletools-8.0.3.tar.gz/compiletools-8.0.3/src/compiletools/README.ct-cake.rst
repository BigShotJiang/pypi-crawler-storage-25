============
ct-cake
============

---------------------------------------------
Swiss army knife for building a C/C++ project
---------------------------------------------

:Author: drgeoffathome@gmail.com
:Date:   2018-02-06
:Copyright: Copyright (C) 2011-2016 Zomojo Pty Ltd
:Version: 8.0.3
:Manual section: 1
:Manual group: developers

SYNOPSIS
========
ct-cake [compilation args] [--variant=<VARIANT>] [--backend=<BACKEND>] filename.cpp

DESCRIPTION
===========
ct-cake is the Swiss army knife of build tools that combines many of the
compiletools into one uber-tool. For many C/C++ projects you can compile
simply using

    ``ct-cake``

ct-cake will automatically determine the correct source files to generate executables
from and also determine the tests to build and run. It works by spidering over
the source code to determine what implementation files to build, what libraries
to link against and what compiler flags to set. Only build what you
need, and throw out your Makefiles.

By default (``--auto``), ct-cake searches for files that will be the "main" file.
From that set of files, ct-cake then uses the header includes to
determine what implementation (cpp) files are also required to be built and
linked into the final executable/s. Use ``--no-auto`` to disable automatic
target detection and specify files explicitly.

ct-cake will make your life easy if you don't arbitrarily name things.
The main rules are:

   * ct-cake only builds C and C++. Everything can be done just fine with
     other tools, so there's no point reinventing them. Anyway, it's easy to
     embed ct-cake into other toolchains, see the last section.
   * All binaries end up in the bin directory, with the same base name as
     their source filename. You can override this at the command-line, but it's
     against the spirit of the tool.
   * The implementation file for point.hpp should be called point.cpp. ct-cake
     supports common C/C++ extensions for headers (.h, .hpp, .hxx, .hh) and
     implementation files (.cpp, .cxx, .cc, .c). This naming convention allows
     ct-cake to compile files and recursively hunt down their dependencies.
   * If a header or implementation file will not work without being linked
     with a certain flag, add a //#LDFLAGS=myflag directly to the source code.
   * Likewise, if a special compiler option is needed, use //#CXXFLAGS=myflag.
   * Minimise the use of "-I" include flags. They make it hard not only for
     cake to generate dependencies, but also autocomplete tools like Eclipse
     and ctags. You can avoid -I flags by structuring your code in the same way
     you refer to paths in your source code.
   * Currently only varieties of Linux are actively supported because that's
     what the compiletools developers have easy access to. That said, it stands
     a good chance of working on \*BSD and macOS. We are interested in receiving
     patches for other platforms including Windows.

ct-cake works off a "pull" philosophy of building, unlike the "push" model
of most build processes. Often, there is the monolithic build script that
rebuilds everything. Users iterate over changing a file, relinking everything
and then rerunning their binary. A hierarchy of libraries is built up and
then linked in to the final executables. All of this takes a lot of time,
particularly for C++.

With ct-cake, you only pull in what is strictly necessary to what you need to
run right now. Say, you are testing a particular tool in a large project, with
a large base of 2000 library files for string handling, sockets, etc. There
is simply no Makefile (by default ct-cake generates one behind the scenes, but
you can also use ``--backend`` to target Ninja, CMake, Bazel, Shake, or Tup).
You might want to create a build.sh for regression testing, but it's not
essential.

The basic workflow is to simply type:

    ``ct-cake``

If there are multiple executables found and you only want to build one specific one:

    ``ct-cake path/to/src/app.cpp``

Only the library cpp files that are needed, directly, or indirectly to create
./bin/app are actually compiled. If you don't #include anything that refers
to a library file, you don't pay for it. Also, only the link options that
are strictly needed to generate the app are included. Its possible to do in
make files, but such fine-level granularity is rarely set up in practice,
because its too error-prone to do manually, or with recursive make goodness.


How it Works
============

ct-cake generates the header dependencies for the "main.cpp"
file you specify at the command line by either examining the "#include" lines in
the source code (or by executing "gcc -MM -MF" if you use the --preprocess flag).
For each header file found in the source file, it looks for
an underlying implementation (c,cpp,cc,cxx,etc) file with the same name, and
adds that implementation file to the build.  ct-cake also reads the entire file
(configurable via --max-file-read-size) for "magic flags" (//#KEY=VALUE)
that indicate needed link and compile flags.  Then it recurses through the
dependencies of the cpp file, and uses this spidering to generate complete
dependency information for the application. This information is collected into a
backend-agnostic build graph, which is then handed to the selected backend
(Make by default) to generate native build files and execute the build.

Magic Comments / Magic Flags
============================

ct-cake works very differently to other build systems, which specify a hierarchy
of link flags and compile options, because ct-cake ties the compiler flags
directly to the source code. If you have compress.hpp that requires "-lzip"
on the link line, add the following comment into the header file:

``//#LDFLAGS=-lzip``

Whenever the header is included (either directly or indirectly), the -lzip
will be automatically added to the link step. If you stop using the header,
for a particular executable, cake will figure that out and not link against it.

If you want to compile a cpp file with a particular optimization enabled,
add, say:

``//#CXXFLAGS=-fstrict-aliasing``

Because the code and build flags are defined so close to each other, its
much easier to tweak the compilation locally.

CPPFLAGS and CXXFLAGS
---------------------

By default, CPPFLAGS and CXXFLAGS are unified into a single deduplicated set.
This means flags specified via ``//#CPPFLAGS=`` or ``--CPPFLAGS`` are also
applied as CXXFLAGS and vice versa. Use ``--separate-flags-CPP-CXX`` to keep
them separate if your build requires different flags for preprocessing and
compilation.

Computed Includes
-----------------

ct-cake's ``direct`` dependency mode (the default) now resolves computed
``#include`` directives where the path is specified via a macro, for example:

.. code-block:: cpp

    #define PLATFORM_HEADER "linux_extra.h"
    #include PLATFORM_HEADER

Previously this required ``--headerdeps=cpp`` to track correctly.

Performance
===========

ct-cake's dependency analysis is fast — one particular (old) example project took
0.04 seconds to build if nothing is out of date, versus 2 seconds for, say,
Boost.Build. The default Make backend is about as fast as a handrolled Makefile
that uses the same lazily generated dependencies; alternative backends like Ninja
can be even faster for large incremental rebuilds.

ct-cake also eliminates the redundant generation of static archive files that
a more hierarchical build process would generate as intermediaries, saving
the cost of running 'ar'.

Note that ct-cake doesn't build all cpp files that you have checked out, only
those strictly needed to build your particular binary, so you only pay for what
you use. This difference alone should see a large improvement on most
projects, especially for incremental rebuilds.

File Locking
------------

ct-cake supports file locking that enables multiple users and build
hosts to share compiled object files. This significantly speeds up builds in
multi-developer and CI/CD environments by reusing object files across builds.

Enable by setting ``file-locking = true`` in your configuration file. This adds
filesystem-aware locking to ensure safe concurrent access (flock on local filesystems,
atomic mkdir on network filesystems). The cache uses content-addressable storage
(files named by hash of source + compiler flags) and includes automatic stale lock
detection for crashed builds.

See the main compiletools README for setup details.

Precompiled Header Caching
---------------------------

ct-cake supports content-addressable caching of precompiled headers (PCH) to
speed up builds that reuse common header files across multiple targets. Mark
headers for precompilation using the ``//#PCH=`` magic flag in your source files:

.. code-block:: cpp

    //#PCH=stdafx.h
    #include "stdafx.h"

The build system compiles PCH-marked headers into ``.gch`` files, cached in
``{git_root}/shared-pchdir/{variant}`` (or a custom path via ``--pchdir``).
The cache key includes compiler, compiler flags, and header path, preventing
collisions across different build configurations.

Enable PCH caching by:

* Setting ``pchdir = {git_root}/shared-pchdir`` in your ``ct.conf.d/ct.conf``
  to enable caching for all builds (default behavior in v8.0+)
* Passing ``--pchdir=/path/to/cache`` on the command line to override
  for a single build

PCH caching is especially effective in multi-developer environments where
the same headers are precompiled many times. Use ``ct-trim-cache --pchdir-only``
to selectively clean aged PCH entries while preserving active builds. Without
``--pchdir``, PCH files fall back to legacy ``.gch`` placement in the object
directory.

Selective build and test
========================

You can instruct ct-cake to only build binaries dependant on a list of
source files using the ``--build-only-changed`` flag. This is helpful for
limiting building and testing in a Continuous Integration pipeline to only
source that has changed from master.

``changed_source=git diff --name-only master | sed "s,^,$(git rev-parse --show-toplevel)/,"
ct-cake --build-only-changed \"$changed_source\"``

Configuration
=============

The compiletools programs require *almost* no configuration. However, it is
still useful to have some shortcut build templates such as 'release',
'profile' etc.

Config files for the ct-* applications are programmatically located using
python-appdirs, which on linux is a wrapper around the XDG specification.  Thus
default locations are /etc/xdg/ct/ and $HOME/.config/ct/.  Configuration parsing
is done using python-configargparse which automatically handles environment
variables, command line arguments, system configs
and user configs.

Specifically, the config files are searched for in the following locations (from
lowest to highest priority):

    * ct/ct.conf.d subdirectory alongside the ct-* executable
    * system config (XDG compliant, so usually /etc/xdg/ct)
    * python virtual environment configs (${python-site-packages}/ct/ct.conf.d)
    * package bundled config (<installed-package>/ct.conf.d)
    * user config (XDG compliant, so usually ~/.config/ct)
    * project config (<gitroot>/ct.conf.d)
    * gitroot directory
    * current working directory
    * environment variables
    * command line arguments

The ct-* applications are aware of two levels of configs.  There is a base level
ct.conf that contains the basic variables that apply no  matter what variant
(i.e, debug/release/etc) is being built.

The second layer of config files are the variant configs that contain the
details for the debug/release/etc.  The variant names are simply a config file
name but without the .conf. There are also variant aliases to make for less
typing. So ``--variant=debug`` looks up the variant alias (specified in ct.conf).
The default aliases are ``{'debug':'blank', 'release':'blank.release'}``, so
"debug" maps to "blank" and uses ``blank.conf``.

The ``blank.conf`` file is intentionally empty, inheriting all settings from the
environment or parent configs. This allows environment variables (CC, CXX,
CFLAGS, etc.) to control the build without explicit config file settings.

To use explicit compiler configs, either specify them directly
(``--variant=gcc.debug``) or customize the aliases in your
``~/.config/ct/ct.conf``:

.. code-block:: ini

    variantaliases = {'debug':'gcc.debug', 'release':'gcc.release'}

If any config value is specified in more than one way then the following
hierarchy is used

* command line > environment variables > config file values > defaults

If you need to append values rather than replace values, this can be
done (currently only for environment variables) by specifying
--variable-handling-method append
or equivalently add an environment variable
VARIABLE_HANDLING_METHOD=append

The example /etc/xdg/ct/gcc.release.conf file looks as follows:

.. code-block:: ini

    ID=GNU
    CC=gcc
    CXX=g++
    LD=g++
    CFLAGS=-fPIC -g -Wall -O3 -DNDEBUG -finline-functions -Wno-inline
    CXXFLAGS=-std=c++11 -fPIC -g -Wall -O3 -DNDEBUG -finline-functions -Wno-inline
    LDFLAGS=-fPIC -Wall -Werror -Xlinker --build-id
    TESTPREFIX=timeout 300 valgrind --quiet --error-exitcode=1

CXXFLAGS lists the flags appended to each compilation job. The value in
/etc/xdg/ct/\*.conf
is overridden by the environment variable, which is in return overridden by
the command-line argument --CXXFLAGS=. Likewise, LDFLAGS sets the default
options used for linking.

TESTPREFIX specifies a command prefix to place in front of unit test runs. This
should ideally be a tool like valgrind, gdb or purify that can be configured
to execute the app and return a non-zero exit code on any failure.


Build variants
==============
A variant is a configuration file that specifies various configurable settings
like the compiler and compiler flags. Common variants are "debug" and "release".
Build variants are used by specifying the variant name at the command-line as
follows:

    ``$ ct-cake --variant=release a.cpp``

Unit Tests
==========

ct-cake integrates with unit tests in a fairly simple (and perhaps simplistic)
way.

By default, ``ct-cake`` automatically builds all executables and unit tests,
then runs the unit tests. This automatic behavior happens when you run
``ct-cake`` without arguments (equivalent to ``ct-cake --auto``). To disable
automatic test discovery and execution, use ``--no-auto``.

If you would prefer to be explicity, ct-cake allows you to specify multiple
build targets on each line, so the following is valid and useful:

    ``$ ct-cake utilities/*.cpp  # builds specified apps into bin/``

To explicitly specify build targets and unit tests to be generated and run
use the following example.  Unit tests are built and when run must return
an exit code of 0 otherwise this will become a build failure. The flag used
to specify that executables are unit tests is --tests.

    ``$ ct-cake utilities/*.cpp --tests tests/*.cpp``

If the *TESTPREFIX* variable is set, you can automatically check
all unit tests with a code purifying tool. For example:

    ``export TESTPREFIX="valgrind --quiet --error-exitcode=1"``

will cause all unit tests to only pass if they run through valgrind with no
memory errors.

Common Options
==============

**--auto / --no-auto**
    Enable or disable automatic target detection. ``--auto`` is the default.
    When enabled, ct-cake searches for source files containing exemarkers
    (like ``main(``) and testmarkers (like ``unit_test.hpp``).

**--disable-tests**
    When ``--auto`` is specified, skip automatic building and running of tests.
    Useful when you only want to build executables.

**--disable-exes**
    When ``--auto`` is specified, skip automatic building of executables.
    Useful when you only want to build and run tests.

**-o, --output**
    When building a single target, rename the output to this name.
    Example: ``ct-cake main.cpp -o myapp``

**--backend**
    Build system backend to use. Choices: ``make`` (default), ``ninja``,
    ``cmake``, ``bazel``, ``shake``, ``tup``.
    Example: ``ct-cake --backend=ninja``

**--clean**
    Remove all build artifacts.

**--realclean, --real-clean**
    Remove bin/ entirely and selectively clean this build's objects from
    the shared objdir. Superset of ``--clean`` -- also removes copied
    executables from the top-level output directory. Unlike ``--clean``,
    only removes object files that belong to the current build, preserving
    other sub-projects' objects in a shared object directory.

**-j, --parallel**
    Number of parallel jobs. Defaults to the output of ``ct-jobs``
    (typically the number of CPU cores). Passed to the selected backend.

**--compilation-database / --no-compilation-database**
    Generate a ``compile_commands.json`` file for clang tooling. Enabled by
    default. The file is placed in the git root directory.

**--compilation-database-output**
    Custom output path for the compilation database.

**--timing**
    Collect and report build timing information.  Writes
    ``.ct-timing.json`` to the object directory and prints a summary
    table after the build.  Analyze the results with ``ct-timing-report``.

**--objdir PATH**
    Use a shared object directory for compiled object files across multiple
    builds. Enables content-addressable object file caching and cross-user
    build sharing. Default: ``{git_root}/shared-objdir``. Requires
    ``file-locking = true`` in ``ct.conf.d/ct.conf`` for safe concurrent access.
    Example: ``ct-cake --objdir=/shared/build/objects``

**--pchdir PATH**
    Use a shared precompiled header (PCH) cache directory. Headers marked with
    the ``//#PCH=`` magic flag are compiled into ``.gch`` files and cached here.
    The cache key includes compiler, flags, and header path, enabling safe reuse
    across builds and developers. Default: ``{git_root}/shared-pchdir/{variant}``.
    Without this flag, PCH files fall back to legacy ``.gch`` placement in the
    object directory. Use ``ct-trim-cache --pchdir-only`` to clean aged entries.
    Example: ``ct-cake --pchdir=/shared/build/pch``

**--prepend-PKG-CONFIG-PATH PATH**
    Prepend PATH to ``PKG_CONFIG_PATH`` before any pkg-config invocation.
    Takes highest priority — overrides both ``ct.conf.d/pkgconfig/`` directory
    layers and the existing environment variable. Useful for CI pipelines or
    one-off debugging where you need a specific ``.pc`` file to take precedence.
    May be repeated to prepend multiple directories.
    Example: ``ct-cake --prepend-PKG-CONFIG-PATH=/opt/custom/pkgconfig``

**--append-PKG-CONFIG-PATH PATH**
    Append PATH to ``PKG_CONFIG_PATH`` after any pkg-config invocation.
    Takes lowest priority — only consulted when the package is not found via
    any other mechanism. Useful for fallback paths or system-wide package
    locations as a last resort. May be repeated to append multiple directories.
    Example: ``ct-cake --append-PKG-CONFIG-PATH=/usr/local/lib/pkgconfig``

**--static / --dynamic**
    Build a static or dynamic library instead of an executable.
    Example: ``ct-cake --static mylib.cpp``

Putting it all together - a typical build setup
===============================================

For most simple projects, a build.sh script that looks like the
following is quite useful. You can simply add more cpp to the apps directory to
generate more tools from the project,
or add test scripts to the regression directory to improve
test coverage.

Code generation steps can be added at the beginning of
the build.sh, before cake runs.

.. code-block:: bash

    #!/bin/sh
    set -e
    python fancypythoncodegenerator.py
    ct-cake "$@"


The special *"$@"* marker is the recommended way
of forwarding arguments to an application. You can then
run the build script like this:

    ``$ ./build.sh --variant=release``

or:

    ``$ ./build.sh --variant=release --append-CXXFLAGS=-DSPECIALMODE``

References
==========

The content-addressable backend architecture was informed by:

* Andrey Mokhov, Neil Mitchell, Simon Peyton Jones. *Build Systems à la Carte*.
  Proc. ACM Program. Lang., Vol. 2, ICFP, Article 79, September 2018.
  https://doi.org/10.1145/3236774

The non-recursive Makefile generation was informed by:

* Peter Miller. *Recursive Make Considered Harmful*. 2008.
  https://api.semanticscholar.org/CorpusID:54117644

SEE ALSO
========
``compiletools`` (1), ``ct-timing-report`` (1), ``ct-list-variants`` (1), ``ct-config`` (1)
