#pragma once

void obtainlock();
