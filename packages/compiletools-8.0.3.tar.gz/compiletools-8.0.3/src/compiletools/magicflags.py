import argparse
import re
import sys
from collections import defaultdict
from types import SimpleNamespace
from typing import Union

import stringzilla as sz

import compiletools.apptools
import compiletools.compiler_macros
import compiletools.configutils
import compiletools.git_utils
import compiletools.headerdeps
import compiletools.namer
import compiletools.utils
import compiletools.wrappedos
from compiletools.file_analyzer import FileAnalysisResult
from compiletools.preprocessing_cache import MacroState, get_or_compute_preprocessing
from compiletools.stringzilla_utils import strip_sz
from compiletools.utils import instance_cache

# Internal key for storing hard ordering constraints in the magic flags dict.
# Shared between magicflags.py (producer) and build_backend.py (consumer).
_HARD_ORDERINGS_KEY = sz.Str("_HARD_ORDERINGS")

# Type aliases for clarity
MacroDict = dict[sz.Str, sz.Str]
FlagsDict = dict[sz.Str, list[sz.Str]]


def create(args, headerdeps, context):
    """MagicFlags Factory"""
    classname = args.magic.title() + "MagicFlags"
    if args.verbose >= 4:
        print("Creating " + classname + " to process magicflags.")
    magicclass = globals()[classname]
    return magicclass(args, headerdeps, context=context)


def add_arguments(cap, variant=None):
    """Add the command line arguments that the MagicFlags classes require"""
    if compiletools.apptools._parser_has_option(cap, "--magic"):
        return
    compiletools.apptools.add_common_arguments(cap, variant=variant)
    compiletools.preprocessor.PreProcessor.add_arguments(cap)
    alldepscls = [st[:-10].lower() for st in dict(globals()) if st.endswith("MagicFlags")]
    cap.add(
        "--magic",
        choices=alldepscls,
        default="direct",
        help="Methodology for reading file when processing magic flags",
    )
    if not compiletools.apptools._parser_has_option(cap, "--max-file-read-size"):
        cap.add(
            "--max-file-read-size",
            type=int,
            default=0,
            help="Maximum bytes to read from files (0 = entire file)",
        )


class MagicFlagsBase:
    """A magic flag in a file is anything that starts
    with a //# and ends with an =
    E.g., //#key=value1 value2

    Note that a magic flag is a C++ comment.

    This class is a map of filenames
    to the map of all magic flags for that file.
    Each magic flag has a list of values preserving order.
    E.g., { '/somepath/libs/base/somefile.hpp':
               {'CPPFLAGS':['-D', 'MYMACRO', '-D', 'MACRO2'],
                'CXXFLAGS':['-fsomeoption'],
                'LDFLAGS':['-lsomelib']}}
    This function will extract all the magics flags from the given
    source (and all its included headers).
    source_filename must be an absolute path

    Magic Flag Dict Structure:
        Each magic flag is represented as a dict with the following fields:

        {
            'line_num': int,              # Line number in file (0-based)
            'key': stringzilla.Str,       # Magic flag key (e.g., 'LDFLAGS', 'CPPFLAGS')
            'value': stringzilla.Str,     # Magic flag value
            'full_line': stringzilla.Str, # Complete source line containing the magic flag
            'byte_pos': int,              # Byte position in original file
                                          # DirectMagicFlags: actual file position
                                          # CppMagicFlags: -1 (unavailable in preprocessed output)
            'source_file_context': str    # (Optional, CppMagicFlags only) Original source file
                                          # for preprocessed output. Used for SOURCE path resolution.
                                          # DirectMagicFlags: not present
        }
    """

    def __init__(
        self,
        args: argparse.Namespace,
        headerdeps: compiletools.headerdeps.HeaderDepsBase,
        context,
    ) -> None:
        self._args = args
        self._headerdeps = headerdeps
        self.context = context

        # Set analyzer args for FileAnalyzer caching
        from compiletools.file_analyzer import set_analyzer_args

        set_analyzer_args(args, context)

        # The magic pattern is //#key=value with whitespace ignored
        self.magicpattern = re.compile(r"^[\s]*//#([\S]*?)[\s]*=[\s]*(.*)", re.MULTILINE)

        # Store final converged MacroState objects by filename.
        # After _parse() runs, the MacroState carries effective compile flags
        # (global + per-file magic) so get_hash(include_core=True) captures everything.
        self._final_macro_states = {}
        self._expander = None

    def _initialize_macro_state(self) -> MacroState:
        """Initialize MacroState with command-line and compiler macros as core.

        Returns:
            MacroState: Initialized with core (compiler + cmdline) and empty variable macros
        """
        core_macros = {}

        # Get compiler built-in macros - these are the stable base (~378 macros)
        compiler_macros = compiletools.compiler_macros.get_compiler_macros(self._args.CXX, self._args.verbose)
        core_macros.update({sz.Str(k): sz.Str(v) for k, v in compiler_macros.items()})

        # Add command-line macros to core - they're also static for the entire build
        cmd_macros = compiletools.apptools.extract_command_line_macros(
            self._args, flag_sources=["CPPFLAGS", "CXXFLAGS"], include_compiler_macros=False, verbose=self._args.verbose
        )
        core_macros.update({sz.Str(k): sz.Str(v) for k, v in cmd_macros.items()})

        # Create MacroState with core macros, empty variable macros
        return MacroState(
            core_macros,
            {},
            compiler_path=self._args.CXX,
            cppflags=self._args.CPPFLAGS,
            cflags=self._args.CFLAGS,
            cxxflags=self._args.CXXFLAGS,
        )

    def get_final_macro_state_key(self, filename: str):
        """Get the final converged macro state key for a specific file.

        Returns the frozenset cache key (variable macros only) for use in
        dependency caching. For object file naming, use get_final_macro_state_hash().

        Args:
            filename: The file path to get the macro state key for

        Returns:
            frozenset: Cache key of variable macros

        Raises:
            KeyError: If file hasn't been processed yet
        """
        abs_filename = compiletools.wrappedos.realpath(filename)
        macro_state = self._final_macro_states.get(abs_filename)
        if macro_state is None:
            raise KeyError(f"No macro state found for {filename} - file not processed")
        return macro_state.get_cache_key()

    def get_final_macro_state_hash(self, filename: str) -> str:
        """Get the full macro state hash (core + variable + build context) for object file naming.

        The MacroState carries all compile-relevant state:
        - Core macros (compiler built-ins + cmdline -D flags)
        - Variable macros (from file #defines)
        - Build context: compiler_path, cppflags, cflags, cxxflags
          (includes both global flags and per-file magic flags after _parse())

        Args:
            filename: The file path to get the full macro state hash for

        Returns:
            str: 16-character hex hash of full macro state

        Raises:
            KeyError: If file hasn't been processed yet
        """
        abs_filename = compiletools.wrappedos.realpath(filename)
        macro_state = self._final_macro_states.get(abs_filename)
        if macro_state is None:
            raise KeyError(f"No macro state found for {filename} - file not processed")

        return macro_state.get_hash(include_core=True)

    def _get_file_analyzer_result(self, filename: str) -> FileAnalysisResult:
        """Get FileAnalysisResult for a file, using module-level cache.

        Args:
            filename: Path to file to analyze

        Returns:
            FileAnalysisResult: Analysis result for the file
        """
        from compiletools.file_analyzer import analyze_file
        from compiletools.global_hash_registry import get_file_hash

        content_hash = get_file_hash(filename, self.context)
        return analyze_file(content_hash, self.context)

    def __call__(self, filename: str) -> FlagsDict:
        return self.parse(filename)

    def _handle_source(self, flag, magic_flag_data, filename, magic):
        """Handle SOURCE magic flag using structured data.

        Args:
            flag: The relative path from the SOURCE magic flag
            magic_flag_data: Dict with magic flag info from FileAnalysisResult.magic_flags
            filename: The file containing the magic flag
            magic: The magic flag name ('SOURCE')
        """
        assert isinstance(magic_flag_data, dict), f"magic_flag_data must be dict, got {type(magic_flag_data)}"

        # Determine the context file for path resolution
        context_file = magic_flag_data.get("source_file_context") or filename

        # Resolve SOURCE path relative to context file
        if compiletools.wrappedos.isabs_sz(flag):
            # Absolute path - use as-is
            newflag = compiletools.wrappedos.realpath_sz(flag)
        else:
            # Relative path - resolve relative to context file's directory
            context_dir = compiletools.wrappedos.dirname(context_file)
            joined_path = compiletools.wrappedos.join_sz(sz.Str(context_dir), strip_sz(flag))
            newflag = compiletools.wrappedos.realpath_sz(joined_path)

        if self._args.verbose >= 9:
            context_info = f", context_file={context_file}" if context_file != filename else ""
            print(f"SOURCE: flag={flag}{context_info} -> {newflag}")

        if not compiletools.wrappedos.isfile_sz(newflag):
            raise OSError(f"{filename} specified {magic}='{newflag}' but it does not exist")

        return newflag

    def _handle_include(self, flag):
        flagsforfilename = defaultdict(list)
        # Use canonical separate-token form for compatibility with deduplicate_compiler_flags
        flagsforfilename[sz.Str("CPPFLAGS")].extend([sz.Str("-I"), flag])
        flagsforfilename[sz.Str("CFLAGS")].extend([sz.Str("-I"), flag])
        flagsforfilename[sz.Str("CXXFLAGS")].extend([sz.Str("-I"), flag])
        if self._args.verbose >= 9:
            print(f"Added -I {flag} to CPPFLAGS, CFLAGS, and CXXFLAGS")
        return flagsforfilename

    def _handle_pkg_config(self, flag):
        flagsforfilename = defaultdict(list)

        # Convert to string for splitting, as we need to iterate over packages
        flag_str = str(flag)
        packages = flag_str.split()

        first_l_per_pkg = []  # Track first -l per package for hard orderings

        for pkg in packages:
            # pkg is str. Call cached_pkg_config directly to avoid unnecessary sz conversions
            cflags_raw = compiletools.apptools.cached_pkg_config(pkg, "--cflags")

            # Use the shared filtering logic from apptools
            cflags_str = compiletools.apptools.filter_pkg_config_cflags(cflags_raw, self._args.verbose)
            cflags_sz = sz.Str(cflags_str)
            if cflags_str and self._expander:
                cflags_sz = self._expander._recursive_expand_macros_sz(cflags_sz)
            cflags_list = compiletools.utils.split_command_cached_sz(cflags_sz)

            libs_raw = compiletools.apptools.cached_pkg_config(pkg, "--libs")
            libs_sz = sz.Str(libs_raw)
            if libs_raw and self._expander:
                libs_sz = self._expander._recursive_expand_macros_sz(libs_sz)
            libs_list = compiletools.utils.split_command_cached_sz(libs_sz)

            # Extract first -l from expanded libs — must use the same
            # post-expansion list that feeds LDFLAGS so names match.
            # Packages whose --libs contain no -l (header-only / linker-script-
            # only / -L-only packages) are silently omitted from
            # first_l_per_pkg: there is no library to express an ordering
            # against. Multi-package PKG-CONFIG=a b c with b library-less
            # therefore degenerates to a single hard edge (A_first, C_first)
            # — i.e. ONE edge per ADJACENT-PAIR-OF-LIBRARIED-PACKAGES, not
            # one per literal package position.
            for token in libs_list:
                token_str = str(token)
                if token_str.startswith("-l") and len(token_str) > 2:
                    first_l_per_pkg.append(token_str[2:])
                    break

            # Add cflags to all C/C++ flag categories
            for key in (sz.Str("CPPFLAGS"), sz.Str("CFLAGS"), sz.Str("CXXFLAGS")):
                flagsforfilename[key].extend(cflags_list)
            flagsforfilename[sz.Str("LDFLAGS")].extend(libs_list)

            if self._args.verbose >= 9:
                print(f"Magic PKG-CONFIG = {pkg}:")
                print(f"\tadded {cflags_list} to CPPFLAGS, CFLAGS, and CXXFLAGS")
                print(f"\tadded {libs_list} to LDFLAGS")

        # For multi-package annotations, store pairwise hard orderings between
        # adjacent libraried packages. See the loop above for what happens
        # when an interior package contributes no -l flag.
        if len(first_l_per_pkg) >= 2:
            for i in range(len(first_l_per_pkg) - 1):
                flagsforfilename[_HARD_ORDERINGS_KEY].append((first_l_per_pkg[i], first_l_per_pkg[i + 1]))

        return flagsforfilename

    def _resolve_readmacros_path(self, flag, source_filename):
        """Resolve READMACROS flag to absolute path (pure path resolution logic).

        Args:
            flag: The flag value from READMACROS magic flag
            source_filename: The file containing the READMACROS flag

        Returns:
            str: Absolute path to the resolved file

        Raises:
            IOError: If resolved file doesn't exist
        """
        # Absolute path - use as-is
        if compiletools.wrappedos.isabs_sz(flag):
            resolved_flag = compiletools.wrappedos.realpath_sz(flag)
        else:
            # Try to resolve as a system header using apptools
            resolved_flag_str = compiletools.apptools.find_system_header(
                str(flag), self._args, verbose=self._args.verbose
            )
            if resolved_flag_str:
                resolved_flag = sz.Str(resolved_flag_str)
            else:
                # Fall back to resolving relative to source file directory
                source_dir = compiletools.wrappedos.dirname(source_filename)
                resolved_flag = compiletools.wrappedos.realpath_sz(
                    compiletools.wrappedos.join_sz(sz.Str(source_dir), flag)
                )

        # Check if file exists
        if not compiletools.wrappedos.isfile_sz(resolved_flag):
            raise OSError(
                f"{source_filename} specified READMACROS='{flag}' but resolved file '{resolved_flag}' does not exist"
            )

        return str(resolved_flag)

    def _collect_explicit_macro_files(self, source_files: list[str]) -> set:
        """Scan files for READMACROS flags and return set of explicit macro files.

        Args:
            source_files: List of source files to scan

        Returns:
            set: Set of resolved paths (str) to files specified by READMACROS flags
        """
        explicit_files = set()

        for source_file in source_files:
            try:
                analysis_result = self._get_file_analyzer_result(source_file)

                for magic_flag in analysis_result.magic_flags:
                    if magic_flag["key"] == sz.Str("READMACROS"):
                        resolved_path = self._resolve_readmacros_path(magic_flag["value"], source_file)
                        explicit_files.add(resolved_path)

                        if self._args.verbose >= 5:
                            print(
                                f"READMACROS: Will process '{resolved_path}' for macro extraction (from {source_file})"
                            )
            except Exception as e:
                if self._args.verbose >= 5:
                    print(f"DirectMagicFlags warning: could not scan {source_file} for READMACROS: {e}")

        return explicit_files

    def _handle_readmacros(self, flag, source_filename):
        """Handle READMACROS magic flag by adding file to explicit macro processing list"""
        resolved_flag = self._resolve_readmacros_path(flag, source_filename)

        # Add to explicit macro files set (store as str for consistency with filename/headers)
        self._explicit_macro_files.add(resolved_flag)

    def _parse(self, filename):
        if self._args.verbose >= 4:
            print("Parsing magic flags for " + filename)

        # We assume that headerdeps _always_ exist
        # before the magic flags are called.
        # When used in the "usual" fashion this is true.
        # However, it is possible to call directly so we must
        # ensure that the headerdeps exist manually.
        # Pass empty frozenset since we haven't computed macros for this file yet
        self._headerdeps.process(filename, frozenset())

        # Both DirectMagicFlags and CppMagicFlags now use structured data approach
        from compiletools.global_hash_registry import get_filepath_by_hash

        flagsforfilename = defaultdict(list)

        file_analysis_data = self.get_structured_data(filename)

        # Expand macros in magic flag values (e.g., LIB_SUFFIX -> O2)
        abs_filename = compiletools.wrappedos.realpath(filename)
        macro_state = self._final_macro_states.get(abs_filename)
        expander = None
        if macro_state:
            from compiletools.simple_preprocessor import SimplePreprocessor

            # Filter out legacy compiler macros (e.g. 'linux', 'unix')
            # that lack a leading underscore — they corrupt path
            # components in pkg-config output.  Conditional compilation
            # is unaffected because it uses a separate preprocessor
            # instance that retains the full macro set.
            all_macros = macro_state.all_macros()
            compiler_predefined = compiletools.compiler_macros.get_compiler_macros(
                getattr(self._args, "CXX", ""), self._args.verbose
            )
            legacy_names = {sz.Str(k) for k in compiler_predefined if not k.startswith("_")}
            if legacy_names:
                all_macros = {k: v for k, v in all_macros.items() if k not in legacy_names or k in macro_state.variable}

            expander = SimplePreprocessor(
                all_macros,
                verbose=self._args.verbose,
                compiler_path=getattr(self._args, "CXX", ""),
                cppflags=getattr(self._args, "CPPFLAGS", ""),
            )
        self._expander = expander

        for file_data in file_analysis_data:
            content_hash = file_data["content_hash"]
            filepath = get_filepath_by_hash(content_hash, self.context)
            active_magic_flags = file_data["active_magic_flags"]

            for magic_flag in active_magic_flags:
                magic = magic_flag["key"]
                flag = magic_flag["value"]
                if expander:
                    flag = expander._recursive_expand_macros_sz(flag)
                # Pass magic_flag data and filepath for structured processing
                self._process_magic_flag(magic, flag, flagsforfilename, magic_flag, filepath)

        # Merge deprecated LINKFLAGS into LDFLAGS before deduplication
        if sz.Str("LINKFLAGS") in flagsforfilename:
            flagsforfilename[sz.Str("LDFLAGS")].extend(flagsforfilename[sz.Str("LINKFLAGS")])
            del flagsforfilename[sz.Str("LINKFLAGS")]

        # Unify CPPFLAGS and CXXFLAGS in magic flags (unless opted out)
        if not getattr(self._args, "separate_flags_CPP_CXX", False):
            cpp_key = sz.Str("CPPFLAGS")
            cxx_key = sz.Str("CXXFLAGS")
            if cpp_key in flagsforfilename or cxx_key in flagsforfilename:
                combined = flagsforfilename[cpp_key] + flagsforfilename[cxx_key]
                flagsforfilename[cpp_key] = list(combined)
                flagsforfilename[cxx_key] = list(combined)

        # Deduplicate all flags while preserving order, with smart compiler flag handling
        for key in flagsforfilename:
            if key == _HARD_ORDERINGS_KEY:
                continue
            flagsforfilename[key] = compiletools.utils.deduplicate_compiler_flags(flagsforfilename[key])

        # Update _final_macro_states to carry effective compile flags
        # (global from self._args + per-file magic flags).  Always computed
        # from self._args.* so this is idempotent if _parse() runs twice.
        abs_filename = compiletools.wrappedos.realpath(filename)
        old_ms = self._final_macro_states.get(abs_filename)
        if old_ms is None:
            raise RuntimeError(
                f"_final_macro_states not populated for {filename} before _parse() update. "
                f"get_structured_data() should have been called first."
            )

        magic_cppflags = " ".join(str(f) for f in flagsforfilename.get(sz.Str("CPPFLAGS"), []))
        magic_cflags = " ".join(str(f) for f in flagsforfilename.get(sz.Str("CFLAGS"), []))
        magic_cxxflags = " ".join(str(f) for f in flagsforfilename.get(sz.Str("CXXFLAGS"), []))

        effective_cppflags = f"{self._args.CPPFLAGS} {magic_cppflags}".strip()
        effective_cflags = f"{self._args.CFLAGS} {magic_cflags}".strip()
        effective_cxxflags = f"{self._args.CXXFLAGS} {magic_cxxflags}".strip()

        self._final_macro_states[abs_filename] = MacroState(
            old_ms.core,
            old_ms.variable,
            compiler_path=old_ms.compiler_path,
            cppflags=effective_cppflags,
            cflags=effective_cflags,
            cxxflags=effective_cxxflags,
        )

        return flagsforfilename

    def _extend_flags_from_dict(self, flagsforfilename, extra_flags_dict):
        """Helper to extend flags from a dict of flag lists."""
        for key, values in extra_flags_dict.items():
            flagsforfilename[key].extend(values)

    def _process_magic_flag(self, magic, flag, flagsforfilename, magic_flag_data, filename):
        """Process a single magic flag entry"""
        # READMACROS is handled during DirectMagicFlags first pass, don't add to output
        if magic == sz.Str("READMACROS"):
            return

        # PCH=path/to/header.h marks a header for precompilation.
        # Resolve the path relative to the file containing the annotation,
        # matching SOURCE semantics.
        if magic == sz.Str("PCH"):
            if compiletools.wrappedos.isabs_sz(flag):
                resolved = compiletools.wrappedos.realpath_sz(flag)
            else:
                context_dir = compiletools.wrappedos.dirname(filename)
                resolved = compiletools.wrappedos.realpath_sz(
                    compiletools.wrappedos.join_sz(sz.Str(context_dir), strip_sz(flag))
                )
            flagsforfilename[magic].append(resolved)
            return

        # If the magic was SOURCE then fix up the path in the flag
        if magic == sz.Str("SOURCE"):
            flag = self._handle_source(flag, magic_flag_data, filename, magic)

        # If the magic was INCLUDE then modify that into the equivalent CPPFLAGS, CFLAGS, and CXXFLAGS
        if magic == sz.Str("INCLUDE"):
            self._extend_flags_from_dict(flagsforfilename, self._handle_include(flag))
            # INCLUDE generates flags for other keys, but also falls through to add to INCLUDE key

        # If the magic was PKG-CONFIG then call pkg-config
        if magic == sz.Str("PKG-CONFIG"):
            self._extend_flags_from_dict(flagsforfilename, self._handle_pkg_config(flag))
            # PKG-CONFIG generates flags for other keys AND adds itself to PKG-CONFIG key

        # Split flag string into individual flags - all magic flags can contain multiple values
        individual_flags = compiletools.utils.split_command_cached_sz(flag)
        flagsforfilename[magic].extend(individual_flags)
        if self._args.verbose >= 5:
            print(f"Using magic flag {magic}={flag} extracted from {filename}")

    @staticmethod
    def clear_cache():
        compiletools.utils.clear_cache()
        compiletools.git_utils.clear_cache()
        compiletools.wrappedos.clear_cache()
        compiletools.apptools.clear_cache()
        DirectMagicFlags.clear_cache()
        CppMagicFlags.clear_cache()
        # Clear LRU caches
        compiletools.utils.split_command_cached.cache_clear()
        compiletools.utils.split_command_cached_sz.cache_clear()


class DirectMagicFlags(MagicFlagsBase):
    def __init__(self, args, headerdeps, context):
        MagicFlagsBase.__init__(self, args, headerdeps, context=context)
        # Create namer instance for dependency hash computation
        self._namer = compiletools.namer.Namer(args, context=context)
        # Compute initial macro state once (compiler built-ins + command-line macros)
        # This is computed once and reused via copy() to avoid redundant initialization
        self._initial_macro_state = self._initialize_macro_state()
        # Track defined macros with values during processing (MacroState with core + variable)
        self.defined_macros = self._initial_macro_state.copy()
        # Track files specified by READMACROS magic flags
        self._explicit_macro_files = set()
        # Cache structured data results by (file_hash, input_macro_key, deps_hash) to avoid redundant convergence
        # deps_hash: XOR of dependency file content hashes (headers + READMACROS)
        # Cached result stores content_hash (not filepath) - current paths resolved via global hash registry
        self._structured_data_cache = {}

    def _extract_macros_from_magic_flags(self, magic_flags_result):
        """Extract -D macros from magic flag CPPFLAGS and CXXFLAGS."""
        # Create minimal args object with magic flag values
        flag_sources = [sz.Str("CPPFLAGS"), sz.Str("CXXFLAGS")]
        temp_args = SimpleNamespace(
            CPPFLAGS=magic_flags_result.get(flag_sources[0], []), CXXFLAGS=magic_flags_result.get(flag_sources[1], [])
        )
        macros = compiletools.apptools.extract_command_line_macros_sz(
            temp_args, flag_sources_sz=flag_sources, verbose=self._args.verbose
        )

        # Update macro state immutably (use empty core since these are variable macros)
        self.defined_macros = self.defined_macros.with_updates(macros)

    @instance_cache
    def _compute_file_processing_result(self, fname: str, macro_key):
        """Pure function: compute file processing result without mutating state.

        Cacheable by (fname, macro_key) to avoid reprocessing shared headers.
        Uses frozenset macro_key as cache key since it's hashable and more efficient.

        NOTE: This method accesses self.defined_macros to get the actual MacroState.
        The macro_key parameter is only used as a cache key for lru_cache.

        Args:
            fname: File path to process
            macro_key: Frozenset cache key of current macro state (from MacroState.get_cache_key())

        Returns:
            Tuple of (active_magic_flags, extracted_variable_macros_dict, cppflags_macros, cxxflags_macros)
            or None if file cannot be processed
        """
        try:
            file_result = self._get_file_analyzer_result(fname)
        except Exception as e:
            if self._args.verbose >= 5:
                print(f"DirectMagicFlags warning: could not process {fname} for macro extraction: {e}")
            return None

        # Process conditional compilation to get active lines using current macro state
        result = get_or_compute_preprocessing(
            file_result,
            self.defined_macros,
            self._args.verbose,
            context=self.context,
        )
        active_line_set = set(result.active_lines)

        # Extract macros from active magic flag CPPFLAGS and CXXFLAGS
        active_magic_flags = [
            magic_flag for magic_flag in file_result.magic_flags if magic_flag["line_num"] in active_line_set
        ]

        # Collect macros from active magic flags for caching
        cppflags_macros = []
        cxxflags_macros = []
        if active_magic_flags:
            for magic_flag in active_magic_flags:
                key = magic_flag["key"]
                value = magic_flag["value"]
                if key == sz.Str("CPPFLAGS") or key == sz.Str("CXXFLAGS"):
                    # Extract -D macros using StringZilla operations
                    from compiletools.stringzilla_utils import parse_d_flags_sz

                    for macro_name, macro_value in parse_d_flags_sz(value):
                        if key == sz.Str("CPPFLAGS"):
                            cppflags_macros.append((macro_name, macro_value))
                        else:
                            cxxflags_macros.append((macro_name, macro_value))

        # Extract variable macros from active #define directives
        extracted_variable_macros = {}
        for define_info in file_result.defines:
            if define_info["line_num"] not in active_line_set:
                continue
            if define_info["is_function_like"]:
                continue

            macro_name = define_info["name"]
            macro_value = define_info["value"] if define_info["value"] is not None else sz.Str("1")
            extracted_variable_macros[macro_name] = macro_value

        return (active_magic_flags, extracted_variable_macros, cppflags_macros, cxxflags_macros, result.file_undefs)

    def _process_file_for_macros(self, fname: str, macro_key=None) -> None:
        """Process a single file to extract macros and active magic flags (mutates state).

        Updates self.defined_macros and self._stored_active_magic_flags based on
        conditional compilation with current macro state. Uses caching to avoid
        reprocessing the same file with the same macro state.

        Args:
            fname: File path to process
            macro_key: Optional pre-computed cache key for current macro state.
                      If None, will compute from self.defined_macros.
        """
        # Get cache key (frozenset) - reuse if provided to avoid redundant computation
        if macro_key is None:
            macro_key = self.defined_macros.get_cache_key()

        # Use cached computation - pass key, function accesses self.defined_macros
        cached_result = self._compute_file_processing_result(fname, macro_key)

        if cached_result is None:
            return

        active_magic_flags, extracted_variable_macros, cppflags_macros, cxxflags_macros, file_undefs = cached_result

        # Store active magic flags for this file to avoid redundant final pass
        self._stored_active_magic_flags[fname] = active_magic_flags

        # Collect updates
        updates = {}
        # Apply extracted macros from magic flags to state
        for macro_name, macro_value in cppflags_macros + cxxflags_macros:
            updates[macro_name] = macro_value

        # Apply extracted variable macros to state
        updates.update(extracted_variable_macros)

        # Update state immutably
        self.defined_macros = self.defined_macros.with_updates(updates)
        if file_undefs:
            self.defined_macros = self.defined_macros.without_keys(file_undefs)

    def _extract_macros_from_file(self, filename):
        """Extract #define macros from a file (unconditionally, no preprocessor evaluation)."""
        try:
            file_result = self._get_file_analyzer_result(filename)
        except Exception as e:
            if self._args.verbose >= 5:
                print(f"DirectMagicFlags warning: could not extract macros from {filename}: {e}")
            return

        updates = {}
        # Extract macros directly from FileAnalyzer's structured defines data
        for define_info in file_result.defines:
            if define_info["is_function_like"]:
                continue

            macro_name = define_info["name"]
            macro_value = define_info["value"] if define_info["value"] is not None else sz.Str("1")
            updates[macro_name] = macro_value

        if updates:
            self.defined_macros = self.defined_macros.with_updates(updates)

    def _build_all_files_list(self, filename, headers):
        """Build deduplicated list of all files to process (explicit macros + main + headers)."""
        return compiletools.utils.ordered_unique(
            list(self._explicit_macro_files) + [filename] + [h for h in headers if h != filename]
        )

    def _reset_state(self):
        """Reset state for new file processing."""
        self.defined_macros = self._initial_macro_state.copy()
        self._explicit_macro_files = set()
        self._stored_active_magic_flags = {}

    def _check_cache(self, filename, cache_key):
        """Check cache and restore state if hit. Returns cached result or None."""
        if cache_key not in self._structured_data_cache:
            return None

        # Restore macro state from previous convergence using absolute path
        abs_filename = compiletools.wrappedos.realpath(filename)

        # Ensure _final_macro_states is populated (required for hunter.macro_state_key())
        if abs_filename not in self._final_macro_states:
            raise RuntimeError(
                f"Cache hit for {filename} but _final_macro_states not populated. "
                f"This indicates a bug in the caching logic."
            )

        # Restore the converged macro state
        self.defined_macros = self._final_macro_states[abs_filename].copy()

        # Verify state consistency in debug mode
        if __debug__:
            expected_key = self._final_macro_states[abs_filename].get_cache_key()
            actual_key = self.defined_macros.get_cache_key()
            assert expected_key == actual_key, (
                f"Macro state restoration failed for {filename}: expected key {expected_key}, got {actual_key}"
            )

        return self._structured_data_cache[cache_key]

    def _setup_explicit_macro_files(self, all_source_files):
        """Collect and process READMACROS files."""
        self._explicit_macro_files = self._collect_explicit_macro_files(all_source_files)

        # Extract macros from explicitly specified files BEFORE processing conditional compilation
        for macro_file in self._explicit_macro_files:
            self._extract_macros_from_file(macro_file)

    def _converge_macro_state(self, all_files, max_iterations=5):
        """Iteratively process files until macro state converges.

        Returns: number of iterations taken
        """
        file_last_macro_version = {}
        iteration = 0

        while iteration < max_iterations:
            iteration += 1
            # Track state object identity to detect convergence
            # with_updates() returns self if no effective changes occur
            macro_state_before = self.defined_macros

            # Determine which files need processing (those not yet processed with current macro state)
            # Use cache key as proxy for version since immutable state usually means different cache key
            current_macro_key = self.defined_macros.get_cache_key()

            files_to_process = [fname for fname in all_files if file_last_macro_version.get(fname) != current_macro_key]

            if not files_to_process:
                break

            # Process files that need reprocessing
            for fname in files_to_process:
                self._process_file_for_macros(fname, current_macro_key)
                # Record current key to avoid reprocessing in next iteration
                # (files that mutate macros are already cached by their input state)
                file_last_macro_version[fname] = current_macro_key

            # Check convergence - identity check works because with_updates returns
            # self if no changes occurred
            if self.defined_macros is macro_state_before:
                break

        return iteration

    def _finalize_and_cache_result(self, filename, headers, cache_key):
        """Store final macro state and build cached result."""
        # Store final converged MacroState (for both cache key and full hash)
        abs_filename = compiletools.wrappedos.realpath(filename)
        self._final_macro_states[abs_filename] = self.defined_macros.copy()

        if self._args.verbose >= 5:
            final_macro_key = self.defined_macros.get_cache_key()
            print(f"DirectMagicFlags: Final converged macro key for {filename}: {final_macro_key}")

        # Build result from stored data
        all_files = self._build_all_files_list(filename, headers)
        result = self._build_structured_result(all_files, self._stored_active_magic_flags)

        # Verify macro state integrity
        if __debug__:
            self._verify_macro_state_unchanged("get_structured_data() completion", filename)

        # Cache result
        self._structured_data_cache[cache_key] = result

        return result

    def get_structured_data(
        self, filename: str
    ) -> list[dict[str, Union[str, sz.Str, list[dict[str, Union[int, sz.Str]]]]]]:
        """Override to handle DirectMagicFlags complex macro processing.

        Cache key: (file_hash, input_macro_key, deps_hash) where:
        - file_hash: SHA1 of source file content (40-char hex)
        - input_macro_key: Initial macro state frozenset
        - deps_hash: 14-char hex hash of dependencies via namer.compute_dep_hash()

        Cached result structure:
            List of dicts: [{'content_hash': str, 'active_magic_flags': List[Dict]}]

            Note: Result stores content_hash (not filepath). Use global_hash_registry.get_filepath_by_hash()
            to resolve current file paths when processing magic flags.

        Returns:
            List of dicts with structure per file (see above)
            See MagicFlagsBase docstring for magic flag dict structure.
        """
        from compiletools.global_hash_registry import get_file_hash

        if self._args.verbose >= 4:
            print("DirectMagicFlags: Setting up structured data with macro processing")

        # Reset state to initial (core) macros
        self._reset_state()

        # Get file hash and initial macro state
        file_hash = get_file_hash(filename, self.context)
        input_macro_key = self.defined_macros.get_cache_key()

        # PASS 1: Initial discovery with core macros (compiler built-ins + command-line)
        headers = self._headerdeps.process(filename, input_macro_key)

        if self._args.verbose >= 9:
            print(f"DirectMagicFlags: PASS 1 headers from headerdeps: {headers}")

        all_source_files = [filename] + headers

        # Collect READMACROS file paths from Pass 1 headers
        explicit_macro_files = self._collect_explicit_macro_files(all_source_files)

        # CRITICAL: Store to instance var - _build_all_files_list() reads from self._explicit_macro_files
        self._explicit_macro_files = explicit_macro_files

        # Check cache with initial deps (optimistic - may be incomplete if Pass 2 needed)
        all_deps = sorted(set(headers) | explicit_macro_files)
        deps_hash = self._namer.compute_dep_hash(all_deps)
        cache_key = (file_hash, input_macro_key, deps_hash)

        if self._args.verbose >= 5:
            print(f"DirectMagicFlags: PASS 1 deps_hash={deps_hash} from {len(all_deps)} dependency files")

        cached_result = self._check_cache(filename, cache_key)
        if cached_result is not None:
            return cached_result

        # Cache miss - extract macros from READMACROS files
        for macro_file in explicit_macro_files:
            self._extract_macros_from_file(macro_file)

        # Converge macro state with Pass 1 file set
        all_files = self._build_all_files_list(filename, headers)
        self._converge_macro_state(all_files)

        # PASS 2: Re-discover if macros changed during convergence
        pass1_macro_key = self.defined_macros.get_cache_key()
        if pass1_macro_key != input_macro_key:
            if self._args.verbose >= 5:
                print("DirectMagicFlags: Macros changed during convergence, re-discovering headers (Pass 2)")
                print(f"DirectMagicFlags: input_macro_key had {len(input_macro_key)} macros")
                print(f"DirectMagicFlags: pass1_macro_key has {len(pass1_macro_key)} macros")
                if len(pass1_macro_key) <= 10:
                    for k, v in sorted(pass1_macro_key)[:10]:
                        print(f"DirectMagicFlags:   {k} = {v}")

            # Clear caches that depend on macro state for Pass 2
            # Invariant caches are preserved - those files have no conditionals
            if self._args.verbose >= 7:
                print("DirectMagicFlags: Clearing variant caches before Pass 2")
            import compiletools.headerdeps
            import compiletools.preprocessing_cache

            compiletools.headerdeps.clear_include_list_cache(context=self.context)
            compiletools.preprocessing_cache.clear_variant_cache(context=self.context)

            # Re-discover headers with converged macros (includes file-defined macros)
            headers = self._headerdeps.process(filename, pass1_macro_key)

            if self._args.verbose >= 9:
                print(f"DirectMagicFlags: PASS 2 headers from headerdeps: {headers}")

            all_source_files = [filename] + headers

            # Re-collect READMACROS with expanded header set
            explicit_macro_files = self._collect_explicit_macro_files(all_source_files)

            # CRITICAL: Update instance var with expanded READMACROS set
            self._explicit_macro_files = explicit_macro_files

            # Re-extract macros from any new READMACROS files
            for macro_file in explicit_macro_files:
                self._extract_macros_from_file(macro_file)

            # Re-converge with expanded file set
            all_files = self._build_all_files_list(filename, headers)
            self._converge_macro_state(all_files)

        # Finalize with FINAL dependency list
        final_all_deps = sorted(set(headers) | self._explicit_macro_files)
        final_deps_hash = self._namer.compute_dep_hash(final_all_deps)
        final_cache_key = (file_hash, input_macro_key, final_deps_hash)

        if self._args.verbose >= 5:
            print(f"DirectMagicFlags: Final deps_hash={final_deps_hash} from {len(final_all_deps)} dependency files")

        return self._finalize_and_cache_result(filename, headers, final_cache_key)

    def _build_structured_result(self, all_files: list[str], stored_active_flags: dict) -> list:
        """Build final structured result from stored active magic flags (pure data transformation).

        Args:
            all_files: List of file paths in desired order
            stored_active_flags: Dict mapping filepath -> list of active magic flags

        Returns:
            list: Structured result with content_hash and active_magic_flags for each file
                  [{'content_hash': str, 'active_magic_flags': List[Dict]}]

        Note:
            Stores content_hash (not filepath) to prevent path staleness. Current file paths
            can be resolved via global_hash_registry.get_filepath_by_hash(content_hash).
        """
        from compiletools.global_hash_registry import get_file_hash

        if self._args.verbose >= 7:
            print(f"DirectMagicFlags: Building result from {len(all_files)} stored files")

        result = []
        for filepath in all_files:
            active_magic_flags = stored_active_flags.get(filepath, [])

            if self._args.verbose >= 9:
                print(f"DirectMagicFlags: Using stored magic flags for {filepath}: {len(active_magic_flags)} active")

            content_hash = get_file_hash(filepath, self.context)
            result.append({"content_hash": content_hash, "active_magic_flags": active_magic_flags})

        return result

    # DirectMagicFlags doesn't implement readfile() - it uses structured data processing only
    # All processing goes through get_structured_data() -> FileAnalyzerResults

    def _verify_macro_state_unchanged(self, context, filename):
        """Verify that the macro state hasn't changed after convergence for a specific file."""
        if __debug__:
            abs_filename = compiletools.wrappedos.realpath(filename)
            if abs_filename in self._final_macro_states:
                current_key = self.defined_macros.get_cache_key()
                converged_macro_state = self._final_macro_states[abs_filename]
                converged_key = converged_macro_state.get_cache_key()
                assert current_key == converged_key, (
                    f"MACRO STATE CORRUPTION DETECTED in {context} for file {filename}!\n"
                    f"Converged key: {converged_key}\n"
                    f"Current key:   {current_key}\n"
                    f"Converged macros: {set(converged_macro_state.keys())}\n"
                    f"Current macros:   {set(self.defined_macros.keys())}"
                )

    def parse(self, filename):
        # Leverage FileAnalyzer data for optimization and validation
        result = self._parse(filename)

        # Verify macro state hasn't been corrupted during parsing
        if __debug__:
            self._verify_macro_state_unchanged("parse() completion", filename)

        return result

    @staticmethod
    def clear_cache():
        pass  # Instance caches are per-instance; nothing class-level to clear


class CppMagicFlags(MagicFlagsBase):
    def __init__(self, args, headerdeps, context):
        MagicFlagsBase.__init__(self, args, headerdeps, context=context)
        # Reuse preprocessor from CppHeaderDeps if available to avoid duplicate instances
        if hasattr(headerdeps, "preprocessor") and headerdeps.__class__.__name__ == "CppHeaderDeps":
            self.preprocessor = headerdeps.preprocessor
        else:
            self.preprocessor = compiletools.preprocessor.PreProcessor(args)

        # Compute initial macro state once (compiler built-ins + command-line macros)
        self._initial_macro_state = self._initialize_macro_state()

    def _extract_macros_from_preprocessor(self, filename: str) -> MacroState:
        """Extract all macro definitions from preprocessor using -dM flag.

        Uses g++ -dM -E to dump all macro definitions after preprocessing.
        This includes compiler built-ins and file-defined macros.

        Args:
            filename: Path to file to process

        Returns:
            MacroState with core (compiler+cmdline) and variable (file-defined) macros
        """
        # Run preprocessor with -dM -E to dump macros
        extraargs = "-dM -E"
        macro_dump = self.preprocessor.process(realpath=filename, extraargs=extraargs, redirect_stderr_to_stdout=True)

        # Parse lines like: #define MACRO_NAME value
        variable_macros = {}
        for line in macro_dump.split("\n"):
            if not line.startswith("#define "):
                continue

            # Extract macro name and value
            after_define = line[8:]  # Skip '#define '

            # Split on first whitespace to separate name from value
            parts = after_define.split(maxsplit=1)
            if len(parts) < 1:
                continue

            macro_name_str = parts[0]

            # Skip function-like macros (have '(' immediately after name)
            if "(" in macro_name_str and macro_name_str.index("(") == len(macro_name_str.rstrip("()")):
                # This is tricky - need to check if '(' is part of the name (function-like)
                # Function-like: FOO(a,b) - '(' immediately follows name
                # Object-like with paren in value: FOO (x) - space before '('
                paren_idx = macro_name_str.find("(")
                if paren_idx > 0 and paren_idx == len(macro_name_str) - 1:
                    # Name ends with '(' - this is function-like
                    continue
                elif "(" in macro_name_str:
                    # '(' is in the middle - function-like macro
                    continue

            macro_name = sz.Str(macro_name_str)
            macro_value = sz.Str(parts[1]) if len(parts) > 1 else sz.Str("1")

            # Skip compiler built-ins (already in core)
            if macro_name not in self._initial_macro_state.core:
                variable_macros[macro_name] = macro_value

        # Return MacroState with variable macros (core already initialized)
        return MacroState(
            core=self._initial_macro_state.core.copy(),
            variable=variable_macros,
            compiler_path=self._initial_macro_state.compiler_path,
            cppflags=self._initial_macro_state.cppflags,
            cflags=self._initial_macro_state.cflags,
            cxxflags=self._initial_macro_state.cxxflags,
        )

    def _readfile(self, filename):
        """Preprocess the given filename but leave comments"""
        extraargs = "-C -E"
        return self.preprocessor.process(realpath=filename, extraargs=extraargs, redirect_stderr_to_stdout=True)

    def get_structured_data(self, filename: str) -> list[dict[str, Union[str, list[dict]]]]:
        """Get magic flags directly from preprocessed text using StringZilla SIMD operations.

        Returns:
            List of dicts with structure: [{'content_hash': str, 'active_magic_flags': List[Dict]}]
            See MagicFlagsBase docstring for magic flag dict structure.
        """

        if self._args.verbose >= 4:
            print("CppMagicFlags: Getting structured data from preprocessed C++ output")

        # Use initial macro state (core macros only) for CppMagicFlags.
        # In cpp mode, the C++ preprocessor handles all conditional compilation,
        # so we don't need to track variable macros. The magic flags are extracted
        # from preprocessed output where all conditionals are already resolved.
        # This avoids an expensive additional preprocessor call (-dM -E).
        abs_filename = compiletools.wrappedos.realpath(filename)
        if abs_filename not in self._final_macro_states:
            self._final_macro_states[abs_filename] = self._initial_macro_state.copy()

        # Get preprocessed text (existing logic)
        preprocessed_text = self._readfile(filename)

        # Bulk-find scan: jump directly to linemarkers and magic flags via SIMD find
        # instead of splitting into ~697K lines and checking each one.
        text = sz.Str(preprocessed_text)
        text_len = len(text)
        magic_flags = []
        current_source_file = None

        # Patterns to search for in the bulk text
        linemarker_pat = sz.Str("\n# ")
        magic_pat = sz.Str("//#")

        # Handle edge case: text starts with a linemarker (no preceding newline)
        scan_pos = 0
        if text_len > 2 and text[0] == "#" and text[1] == " ":
            line_end = text.find("\n", 0)
            if line_end < 0:
                line_end = text_len
            line_sz = text[:line_end]
            first_quote = line_sz.find('"')
            if first_quote >= 0:
                second_quote = line_sz.find('"', first_quote + 1)
                if second_quote > first_quote:
                    current_source_file = str(line_sz[first_quote + 1 : second_quote])

        # Main interleaved scan
        next_lm = text.find(linemarker_pat, scan_pos)
        next_mg = text.find(magic_pat, scan_pos)

        while next_lm >= 0 or next_mg >= 0:
            # Determine which match comes first (-1 means no more matches)
            if next_mg < 0 or (next_lm >= 0 and next_lm < next_mg):
                # Process linemarker: extract filename from # N "file"
                line_start = next_lm + 1  # skip the \n
                line_end = text.find("\n", line_start)
                if line_end < 0:
                    line_end = text_len
                line_sz = text[line_start:line_end]
                first_quote = line_sz.find('"')
                if first_quote >= 0:
                    second_quote = line_sz.find('"', first_quote + 1)
                    if second_quote > first_quote:
                        current_source_file = str(line_sz[first_quote + 1 : second_quote])
                scan_pos = line_end
                next_lm = text.find(linemarker_pat, scan_pos)
            else:
                # Process magic flag: extract full line, then key=value
                line_start_pos = text.rfind("\n", 0, next_mg)
                line_start = 0 if line_start_pos < 0 else line_start_pos + 1
                line_end = text.find("\n", next_mg)
                if line_end < 0:
                    line_end = text_len
                line_sz = text[line_start:line_end]
                magic_offset = next_mg - line_start

                after_marker = line_sz[magic_offset + 3 :]
                eq_pos = after_marker.find("=")
                if eq_pos >= 0:
                    key_trimmed = strip_sz(after_marker[:eq_pos])
                    value_trimmed = strip_sz(after_marker[eq_pos + 1 :])

                    if key_trimmed:
                        magic_flag = {
                            "line_num": -1,
                            "byte_pos": -1,
                            "full_line": line_sz,
                            "key": key_trimmed,
                            "value": value_trimmed,
                        }
                        if current_source_file:
                            magic_flag["source_file_context"] = current_source_file
                        magic_flags.append(magic_flag)

                scan_pos = line_end
                next_mg = text.find(magic_pat, scan_pos)

        if self._args.verbose >= 9:
            print(f"CppMagicFlags: Found {len(magic_flags)} magic flags in preprocessed output")

        from compiletools.global_hash_registry import get_file_hash

        content_hash = get_file_hash(filename, self.context)

        return [{"content_hash": content_hash, "active_magic_flags": magic_flags}]

    def parse(self, filename):
        return self._parse(filename)

    @staticmethod
    def clear_cache():
        pass


class NullStyle(compiletools.git_utils.NameAdjuster):
    def __init__(self, args):
        compiletools.git_utils.NameAdjuster.__init__(self, args)

    def __call__(self, realpath, magicflags):
        print(f"{self.adjust(realpath)}: {magicflags!s}")


class PrettyStyle(compiletools.git_utils.NameAdjuster):
    def __init__(self, args):
        compiletools.git_utils.NameAdjuster.__init__(self, args)

    def __call__(self, realpath, magicflags):
        sys.stdout.write(f"\n{self.adjust(realpath)}")
        try:
            for key in magicflags:
                sys.stdout.write(f"\n\t{key}:")
                for flag in magicflags[key]:
                    sys.stdout.write(f" {flag}")
        except TypeError:
            sys.stdout.write("\n\tNone")


def main(argv=None):
    cap = compiletools.apptools.create_parser("Parse a file and show the magicflags it exports", argv=argv)
    compiletools.headerdeps.add_arguments(cap)
    add_arguments(cap)
    cap.add("filename", help='File/s to extract magicflags from"', nargs="+")

    # Figure out what style classes are available and add them to the command
    # line options
    styles = [st[:-5].lower() for st in dict(globals()) if st.endswith("Style")]
    cap.add("--style", choices=styles, default="pretty", help="Output formatting style")

    from compiletools.build_context import BuildContext

    context = BuildContext()
    args = compiletools.apptools.parseargs(cap, argv, context=context)
    headerdeps = compiletools.headerdeps.create(args, context=context)
    magicparser = create(args, headerdeps, context=context)

    styleclass = globals()[args.style.title() + "Style"]
    styleobject = styleclass(args)

    for fname in args.filename:
        realpath = compiletools.wrappedos.realpath(fname)
        styleobject(realpath, magicparser.parse(realpath))

    print()
    return 0
