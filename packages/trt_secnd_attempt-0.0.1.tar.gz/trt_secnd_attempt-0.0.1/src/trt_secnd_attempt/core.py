# src/pdf_annot_extractor/core.py

import os
import fitz
import pandas as pd
from pdf2image import convert_from_path
import pytesseract
from multiprocessing import Pool, cpu_count
from tqdm import tqdm
import logging

# -------------------------
# Logging setup
# -------------------------
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


# -------------------------
# Internal OCR function
# -------------------------
def _ocr_single_page(args):
    """Run OCR on a single page image."""
    image, lang = args
    try:
        text = pytesseract.image_to_string(image, lang=lang)
        image.close()
        return text.replace("\n\n", "\n")
    except Exception as e:
        logger.error(f"OCR error: {e}")
        return ""


# -------------------------
# OCR extraction
# -------------------------
def extract_text_from_pdf(pdf_path: str, lang: str = "ara", use_mp: bool = True):
    """
    Extract text from a PDF file using OCR.

    Args:
        pdf_path (str): Path to the PDF file.
        lang (str): OCR language code (default: 'ara').
        use_mp (bool): Use multiprocessing for faster OCR (default: True).

    Returns:
        List[str]: List of extracted text for each page.
    """
    images = convert_from_path(pdf_path)

    if use_mp:
        with Pool(cpu_count()) as pool:
            texts = list(tqdm(
                pool.imap(_ocr_single_page, [(img, lang) for img in images]),
                total=len(images),
                desc="OCR"
            ))
    else:
        texts = [_ocr_single_page((img, lang)) for img in tqdm(images, desc="OCR")]

    return texts


# -------------------------
# Extract annotations from PDF
# -------------------------
def extract_annotations(pdf_path: str, lang: str = "ara"):
    """
    Extract annotations and OCR text from a PDF.

    Returns a list of lists: [file_name, page_number, annotation_texts, page_text]
    """
    file_name = os.path.basename(pdf_path)
    results = []

    texts = extract_text_from_pdf(pdf_path, lang)

    with fitz.open(pdf_path) as doc:
        for i, page in enumerate(doc):
            annots = page.annots()
            if not annots:
                continue

            annot_texts = [
                a.info.get("content", "")
                for a in annots
                if a.info.get("content", "")
            ]

            if annot_texts:
                results.append([
                    file_name,
                    i + 1,
                    annot_texts,
                    texts[i] if i < len(texts) else ""
                ])

    return results


# -------------------------
# Directory processing
# -------------------------
def process_directory(input_dir: str, lang: str = "ara"):
    """
    Process all PDFs in a directory and extract annotations.

    Returns:
        List of extracted annotations.
    """
    all_data = []

    pdf_files = [
        os.path.join(input_dir, f)
        for f in os.listdir(input_dir)
        if f.lower().endswith(".pdf")
    ]

    for pdf in tqdm(pdf_files, desc="Processing PDFs"):
        try:
            data = extract_annotations(pdf, lang)
            all_data.extend(data)
        except Exception as e:
            logger.error(f"Failed {pdf}: {e}")

    return all_data


# -------------------------
# Main class for users
# -------------------------
class PDFTextAnnotationExtractor:
    """
    Class to extract OCR text and annotations from a single PDF file.
    """

    def __init__(self, pdf_path: str, output_dir: str = None):
        self.pdf_path = pdf_path
        # Default output directory = current working directory
        self.output_dir = output_dir or os.getcwd()
        os.makedirs(self.output_dir, exist_ok=True)

    def save_text(self, lang: str = "ara"):
        """Save OCR text of each page as separate text files."""
        texts = extract_text_from_pdf(self.pdf_path, lang)

        for i, t in enumerate(texts, start=1):
            path = os.path.join(self.output_dir, f"page_{i:03}.txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write(t)

    def export_annotations_excel(self, output_excel: str = None, lang: str = "ara"):
        """
        Export extracted annotations to an Excel file.

        Args:
            output_excel (str): Output Excel file path. Defaults to 'annotations.xlsx' in output_dir.
        """
        output_excel = output_excel or os.path.join(self.output_dir, "annotations.xlsx")

        data = extract_annotations(self.pdf_path, lang)
        df = pd.DataFrame(data, columns=["File", "Page", "Annotation", "Content"])
        df.to_excel(output_excel, index=False)