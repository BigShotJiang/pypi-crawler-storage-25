# src/pdf_annot_extractor/cli.py
'''
3. CLI (cli.py) — placeholder for now
Even if it’s empty, you need a main() function so the entry point works:

'''
def main():
    print("CLI not implemented yet")
    
 # Later, you’ll replace it with the full argparse logic.