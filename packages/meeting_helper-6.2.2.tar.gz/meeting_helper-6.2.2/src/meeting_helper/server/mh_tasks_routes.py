"""REST endpoints for the embedded task manager (MH-40)."""
from __future__ import annotations

from aiohttp import web

from meeting_helper.trackers.vendors.meeting_helper_store import (
    MeetingHelperStore,
    UNSET,
)


def _store(request: web.Request) -> MeetingHelperStore:
    factory = request.app.get("disk_factory")
    if factory is None:
        raise web.HTTPInternalServerError(text="disk_factory not configured")
    return MeetingHelperStore(factory())


def _int_param(request: web.Request, name: str) -> int:
    """Convert a path-match int param, raising 400 if it isn't a valid int.

    Without this, `int()` raises ValueError which aiohttp surfaces as a bare
    500. Path params come from user input and deserve a real 400.
    """
    raw = request.match_info.get(name, "")
    try:
        return int(raw)
    except (TypeError, ValueError):
        raise web.HTTPBadRequest(text=f"{name} must be an integer")


def _task_payload(t) -> dict:
    return {
        "id": t.id,
        "title": t.title,
        "description": t.description,
        "status": t.status,
        "mr_links": list(t.mr_links),
        "thread_links": list(t.thread_links),
        "parent_id": t.parent_id,
        "created_at": t.created_at,
        "updated_at": t.updated_at,
        "comments": [
            {
                "id": c.id,
                "text": c.text,
                "author": c.author,
                "created_at": c.created_at,
                "updated_at": c.updated_at,
            }
            for c in t.comments
        ],
    }


async def list_tasks(request: web.Request) -> web.Response:
    store = _store(request)
    status = request.query.get("status") or None
    parent_id_raw = request.query.get("parent_id")
    if parent_id_raw is None:
        parent_id = UNSET
    elif parent_id_raw in ("null", "none", ""):
        parent_id = None
    else:
        try:
            parent_id = int(parent_id_raw)
        except ValueError:
            raise web.HTTPBadRequest(text="parent_id must be int or 'null'")
    out = store.list_tasks(status=status, parent_id=parent_id)
    return web.json_response([_task_payload(t) for t in out])


async def get_task(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    try:
        return web.json_response(_task_payload(store.get_task(tid)))
    except KeyError:
        raise web.HTTPNotFound(text=f"task {tid} not found")


async def create_task(request: web.Request) -> web.Response:
    store = _store(request)
    body = await request.json()
    try:
        t = store.create_task(
            title=body.get("title", ""),
            description=body.get("description", ""),
            status=body.get("status", "Todo"),
            parent_id=body.get("parent_id"),
            mr_links=body.get("mr_links") or [],
            thread_links=body.get("thread_links") or [],
        )
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    except KeyError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response(_task_payload(t))


async def patch_task(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    body = await request.json()
    allowed = {
        "title",
        "description",
        "status",
        "parent_id",
        "mr_links",
        "thread_links",
    }
    fields = {k: v for k, v in body.items() if k in allowed}
    try:
        t = store.update_task(tid, **fields)
    except KeyError:
        raise web.HTTPNotFound(text=f"task {tid} not found")
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response(_task_payload(t))


async def delete_task(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    try:
        return web.json_response(store.delete_task(tid))
    except KeyError:
        raise web.HTTPNotFound(text=f"task {tid} not found")


async def add_comment(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    body = await request.json()
    try:
        c = store.add_comment(tid, text=body.get("text", ""), author="user")
    except KeyError:
        raise web.HTTPNotFound(text=f"task {tid} not found")
    return web.json_response(
        {
            "id": c.id,
            "text": c.text,
            "author": c.author,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
    )


async def update_comment(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    cid = _int_param(request, "cid")
    body = await request.json()
    try:
        c = store.update_comment(tid, cid, text=body.get("text", ""))
    except KeyError:
        raise web.HTTPNotFound()
    return web.json_response(
        {
            "id": c.id,
            "text": c.text,
            "author": c.author,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
    )


async def delete_comment(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    cid = _int_param(request, "cid")
    try:
        store.delete_comment(tid, cid)
    except KeyError:
        raise web.HTTPNotFound()
    return web.json_response({"deleted": True})


async def list_statuses(request: web.Request) -> web.Response:
    return web.json_response(_store(request).list_statuses())


async def put_visible_statuses(request: web.Request) -> web.Response:
    body = await request.json()
    names = body.get("visible_statuses") or []
    try:
        _store(request).set_visible_statuses(names)
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response({"ok": True})


async def mcp_info(request: web.Request) -> web.Response:
    cfg = request.app["config"]
    port = getattr(cfg, "port", 7891)
    return web.json_response(
        {
            "url": f"http://127.0.0.1:{port}/mcp",
            "port": port,
        }
    )


async def mcp_workspaces(request: web.Request) -> web.Response:
    """List every workspace on disk with its pinned MCP URL.

    The UI uses this to populate the workspace dropdown on the Settings >
    MCP page. The pinned URL `/mcp/<name>` always serves that workspace's
    tasks regardless of which workspace is active in the desktop app.
    """
    from meeting_helper.config import list_workspaces, load_state

    cfg = request.app["config"]
    port = getattr(cfg, "port", 7891)
    base = f"http://127.0.0.1:{port}"
    active = load_state().get("active_workspace", "")
    workspaces = []
    for name in list_workspaces():
        workspaces.append(
            {
                "name": name,
                "url": f"{base}/mcp/{name}",
                "is_active": name == active,
            }
        )
    return web.json_response(
        {
            "workspaces": workspaces,
            "active_workspace": active,
            "shared_url": f"{base}/mcp",
        }
    )


def register(app: web.Application) -> None:
    app.router.add_get("/api/mh-tasks", list_tasks)
    app.router.add_post("/api/mh-tasks", create_task)
    app.router.add_get("/api/mh-tasks/statuses", list_statuses)
    app.router.add_put("/api/mh-tasks/statuses/visible", put_visible_statuses)
    app.router.add_get("/api/mh-tasks/{id}", get_task)
    app.router.add_patch("/api/mh-tasks/{id}", patch_task)
    app.router.add_delete("/api/mh-tasks/{id}", delete_task)
    app.router.add_post("/api/mh-tasks/{id}/comments", add_comment)
    app.router.add_patch("/api/mh-tasks/{id}/comments/{cid}", update_comment)
    app.router.add_delete("/api/mh-tasks/{id}/comments/{cid}", delete_comment)
    app.router.add_get("/api/mcp/info", mcp_info)
    app.router.add_get("/api/mcp/workspaces", mcp_workspaces)
