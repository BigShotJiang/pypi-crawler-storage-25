"""HTTP MCP endpoint exposing local task CRUD (MH-40).

Implements just enough of the MCP Streamable HTTP transport (single
JSON-RPC POST/response per request) to satisfy Claude Code and similar
clients. We don't use SSE here — every tool call is short and synchronous.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from aiohttp import web

from meeting_helper.trackers.vendors.meeting_helper_store import (
    MeetingHelperStore,
    UNSET,
)

logger = logging.getLogger(__name__)


_TOOLS: list[dict[str, Any]] = [
    {
        "name": "list_tasks",
        "description": "List tasks; optional filters status= and parent_id=",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {"type": "string"},
                "parent_id": {"type": ["integer", "null"]},
            },
        },
    },
    {
        "name": "get_task",
        "description": "Get a task by id (includes comments)",
        "inputSchema": {
            "type": "object",
            "properties": {"id": {"type": "integer"}},
            "required": ["id"],
        },
    },
    {
        "name": "create_task",
        "description": "Create a task",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "description": {"type": "string"},
                "status": {"type": "string"},
                "parent_id": {"type": ["integer", "null"]},
                "mr_links": {"type": "array", "items": {"type": "string"}},
                "thread_links": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["title"],
        },
    },
    {
        "name": "update_task",
        "description": "Update task fields by id",
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "integer"},
                "title": {"type": "string"},
                "description": {"type": "string"},
                "status": {"type": "string"},
                "parent_id": {"type": ["integer", "null"]},
                "mr_links": {"type": "array", "items": {"type": "string"}},
                "thread_links": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["id"],
        },
    },
    {
        "name": "delete_task",
        "description": "Delete a task and cascade its children + comments",
        "inputSchema": {
            "type": "object",
            "properties": {"id": {"type": "integer"}},
            "required": ["id"],
        },
    },
    {
        "name": "add_comment",
        "description": "Append a comment to a task (author=agent)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "integer"},
                "text": {"type": "string"},
            },
            "required": ["task_id", "text"],
        },
    },
    {
        "name": "update_comment",
        "description": "Edit an existing comment's text",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "integer"},
                "comment_id": {"type": "integer"},
                "text": {"type": "string"},
            },
            "required": ["task_id", "comment_id", "text"],
        },
    },
    {
        "name": "delete_comment",
        "description": "Delete a comment",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "integer"},
                "comment_id": {"type": "integer"},
            },
            "required": ["task_id", "comment_id"],
        },
    },
    {
        "name": "list_statuses",
        "description": "List canonical statuses with visibility",
        "inputSchema": {"type": "object", "properties": {}},
    },
]


def _store(request: web.Request) -> MeetingHelperStore:
    """Build a store for the request — pinned workspace if the route matched
    one, otherwise the daemon's currently-active workspace.

    The pinned-workspace path lets multiple Claude Code MCP registrations
    coexist on one daemon (`mh-work`, `mh-personal`, etc.) without the
    agent's writes silently following whatever workspace the desktop app
    happens to have open. Each registration's URL embeds the workspace
    name, and this helper resolves a fresh `Config` for that workspace.
    """
    workspace = request.match_info.get("workspace")
    if workspace:
        from meeting_helper.config import (
            Config,
            WORKSPACE_NAME_RE,
            workspace_path,
        )
        if not WORKSPACE_NAME_RE.match(workspace):
            raise ValueError(f"invalid workspace name: {workspace!r}")
        path = workspace_path(workspace)
        if not path.exists():
            raise KeyError(f"workspace {workspace!r} not found")
        return MeetingHelperStore(Config(config_path=path, workspace=workspace))
    factory = request.app.get("disk_factory")
    if factory is None:
        raise RuntimeError("disk_factory not configured")
    return MeetingHelperStore(factory())


def _task_dict(t) -> dict:
    return {
        "id": t.id,
        "title": t.title,
        "description": t.description,
        "status": t.status,
        "mr_links": list(t.mr_links),
        "thread_links": list(t.thread_links),
        "parent_id": t.parent_id,
        "created_at": t.created_at,
        "updated_at": t.updated_at,
        "comments": [
            {
                "id": c.id,
                "text": c.text,
                "author": c.author,
                "created_at": c.created_at,
                "updated_at": c.updated_at,
            }
            for c in t.comments
        ],
    }


def _dispatch(store: MeetingHelperStore, name: str, args: dict) -> Any:
    if name == "list_tasks":
        kwargs: dict[str, Any] = {}
        if "status" in args:
            kwargs["status"] = args["status"]
        if "parent_id" in args:
            kwargs["parent_id"] = args["parent_id"]
        else:
            kwargs["parent_id"] = UNSET
        return [_task_dict(t) for t in store.list_tasks(**kwargs)]
    if name == "get_task":
        return _task_dict(store.get_task(int(args["id"])))
    if name == "create_task":
        return _task_dict(
            store.create_task(
                title=args["title"],
                description=args.get("description", ""),
                status=args.get("status", "Todo"),
                parent_id=args.get("parent_id"),
                mr_links=args.get("mr_links") or [],
                thread_links=args.get("thread_links") or [],
            )
        )
    if name == "update_task":
        fields = {k: v for k, v in args.items() if k != "id"}
        return _task_dict(store.update_task(int(args["id"]), **fields))
    if name == "delete_task":
        return store.delete_task(int(args["id"]))
    if name == "add_comment":
        c = store.add_comment(
            int(args["task_id"]), text=args["text"], author="agent",
        )
        return {
            "id": c.id,
            "text": c.text,
            "author": c.author,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
    if name == "update_comment":
        c = store.update_comment(
            int(args["task_id"]),
            int(args["comment_id"]),
            text=args["text"],
        )
        return {
            "id": c.id,
            "text": c.text,
            "author": c.author,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
    if name == "delete_comment":
        store.delete_comment(int(args["task_id"]), int(args["comment_id"]))
        return {"deleted": True}
    if name == "list_statuses":
        return store.list_statuses()
    raise ValueError(f"unknown tool: {name}")


async def mcp_handler(request: web.Request) -> web.Response:
    """Single-endpoint MCP Streamable HTTP server (POST JSON-RPC).

    Error mapping:
    - Parse errors / malformed JSON -> JSON-RPC -32700.
    - Unknown method -> -32601.
    - Missing required arg / unknown status / validation -> -32602.
    - Task or comment not found -> tool result with `isError: true` (per MCP
      spec, application-layer tool errors come back inside the result, not
      as JSON-RPC errors).
    - Anything else -> -32603.
    """
    rpc_id: Any = None
    try:
        body = await request.json()
    except Exception as e:
        return web.json_response(
            {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": f"parse error: {e}"},
            },
            status=200,
        )
    if not isinstance(body, dict):
        return web.json_response(
            {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32600, "message": "request must be a JSON object"},
            },
            status=200,
        )
    rpc_id = body.get("id")
    method = body.get("method")
    params = body.get("params") or {}

    def _ok(result: Any) -> web.Response:
        return web.json_response(
            {"jsonrpc": "2.0", "id": rpc_id, "result": result}
        )

    def _err(code: int, message: str) -> web.Response:
        return web.json_response(
            {
                "jsonrpc": "2.0",
                "id": rpc_id,
                "error": {"code": code, "message": message},
            },
            status=200,
        )

    def _tool_error(message: str) -> web.Response:
        return _ok(
            {
                "content": [{"type": "text", "text": message}],
                "isError": True,
            }
        )

    try:
        if method == "initialize":
            return _ok(
                {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "meeting-helper-mh", "version": "1"},
                }
            )
        if method == "tools/list":
            return _ok({"tools": _TOOLS})
        if method == "tools/call":
            tool_name = params.get("name")
            if not isinstance(tool_name, str):
                return _err(-32602, "tools/call requires a string 'name'")
            arguments = params.get("arguments") or {}
            try:
                # Offload to executor: _dispatch does sync workspace-JSON
                # load/mutate/save (`Config.save` writes the whole file).
                # Running it on the asyncio loop blocks transcript
                # broadcasts during sustained MCP traffic (ticket #25).
                import asyncio as _asyncio
                result = await _asyncio.to_thread(
                    _dispatch, _store(request), tool_name, arguments,
                )
            except KeyError as e:
                # Resource not found (task or comment). Per MCP spec this is
                # a tool-level error, surfaced inside the result with
                # isError=true so agents can distinguish "missing resource"
                # from "bad request shape".
                return _tool_error(str(e))
            except ValueError as e:
                # Validation: bad status, blank title, depth violation,
                # unknown tool. JSON-RPC -32602 (invalid params).
                return _err(-32602, str(e))
            except RuntimeError as e:
                # disk_factory not configured — daemon-wiring bug.
                logger.error("mcp_handler: %s", e)
                return _err(-32603, str(e))
            return _ok(
                {
                    "content": [{"type": "text", "text": json.dumps(result)}],
                    "isError": False,
                }
            )
        if method in ("notifications/initialized", "ping"):
            return _ok({})
        return _err(-32601, f"method not found: {method}")
    except Exception as e:
        logger.exception("mcp_handler: unhandled exception")
        return _err(-32603, f"internal error: {e}")


def register(app: web.Application) -> None:
    app.router.add_post("/mcp", mcp_handler)
    # Workspace-pinned variant. Same handler, but `_store(request)` reads
    # the workspace name from the path and builds a fresh Config for it.
    # Lets one daemon serve N Claude Code registrations deterministically.
    app.router.add_post("/mcp/{workspace}", mcp_handler)
