"""HTTP routes: health, config, transcribe, summarize."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import subprocess
import time
from dataclasses import asdict
from pathlib import Path

from aiohttp import web

from meeting_helper.state import state
from meeting_helper.server.websocket import ws_handler, slim_card_for_broadcast
from meeting_helper import speakers as _speakers

logger = logging.getLogger(__name__)


def _hot_moment_window_sec(request) -> float:
    """Resolve the configured Hot Moment window in seconds.

    Reads hot_moment_window_minutes from the request app config.
    Returns 0 if no config is reachable (arm_hot_moment becomes a no-op).
    """
    try:
        cfg = request.app.get("config")
        if cfg is not None:
            return cfg.hot_moment_window_minutes * 60.0
    except Exception:
        pass
    return 0.0



try:
    from anthropic import AsyncAnthropic
except ImportError:
    AsyncAnthropic = None  # tests patch this


def _parse_brief_script_to_sentences(script: str) -> list[str]:
    """Extract first-person bullet sentences from the brief markdown script.

    Each bullet line (lines starting with '-' or '*') is treated as one
    sentence. Section headers (**Today**, etc.) are skipped.
    """
    sentences: list[str] = []
    for raw in script.splitlines():
        line = raw.strip()
        if not line:
            continue
        # Skip section headers
        if line.startswith("**") and line.endswith("**"):
            continue
        # Bullets
        if line.startswith("- ") or line.startswith("* "):
            text = line[2:].strip()
            if text:
                sentences.append(text)
    return sentences


def _ticket_ids_in(text: str) -> list[str]:
    """Extract unique ticket IDs (e.g. PROJ-123) preserving first-occurrence order."""
    seen: list[str] = []
    for m in re.finditer(r"[A-Z]{2,}-\d+", text):
        tid = m.group(0)
        if tid not in seen:
            seen.append(tid)
    return seen


def _seed_warm_cache_from_brief(script: str, brief_cards: list[dict]) -> dict:
    """After /brief succeeds, seed state.self_buffer + state.current_topic +
    state.current_topic_cards so subsequent queries have grounded context.

    Returns the seeded `current_topic` dict (also assigned to state).
    """
    sentences = _parse_brief_script_to_sentences(script)
    if state.self_buffer is not None:
        # AI-authored brief content. Skip listener fan-out so the
        # generated script never lands in `.live.txt` — that file is
        # meant to be a faithful record of what was actually
        # transcribed from mic + system audio, not synthesized text.
        for s in sentences:
            state.self_buffer.append_final(s, fire_listeners=False)

    # Pick the first "Today" bullet as the primary topic statement.
    # The script's structure is:
    #   **Today**
    #   - I'm working on PROJ-123 ...
    #   **Yesterday**
    #   - I finished PROJ-111 ...
    today_bullet = ""
    section = None
    for raw in script.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("**") and line.endswith("**"):
            header = line.strip("*").strip().lower()
            section = header
            continue
        if section == "today" and (line.startswith("- ") or line.startswith("* ")):
            today_bullet = line[2:].strip()
            break  # take the FIRST today bullet

    last_user_statement = today_bullet or (sentences[0] if sentences else "")
    # The brief script no longer prints raw ticket ids (they sound bad read
    # aloud), so harvest them from the source card titles instead.
    ticket_ids: list[str] = []
    for c in (brief_cards or []):
        for tid in _ticket_ids_in(str(c.get("title", ""))):
            if tid not in ticket_ids:
                ticket_ids.append(tid)
    # Fallback: still scan the script in case the model slipped one in.
    for tid in _ticket_ids_in(script):
        if tid not in ticket_ids:
            ticket_ids.append(tid)
    # Topic = a short noun phrase from the today bullet, falling back to the bullet itself
    topic = ""
    if today_bullet:
        # Strip leading first-person "I'm working on " etc.
        cleaned = re.sub(
            r"^(I['’]m\s+(working on|continuing|focused on|on)|I am\s+(working on|continuing|focused on|on))\s+",
            "",
            today_bullet,
            flags=re.IGNORECASE,
        )
        # Take up to the first em-dash or "—" or first 80 chars
        for sep in [" — ", " - ", ": ", ". "]:
            if sep in cleaned:
                topic = cleaned.split(sep, 1)[0].strip()
                break
        if not topic:
            topic = cleaned[:80].strip()

    # Search query — best-effort keywords from the topic
    search_query = topic.lower() if topic else " ".join(ticket_ids[:2])

    current_topic = {
        "topic": topic,
        "ticket_ids": ticket_ids,
        "search_query": search_query,
        "last_user_statement": last_user_statement,
    }
    state.current_topic = current_topic
    state.current_topic_cards = list(brief_cards or [])
    return current_topic


async def health_handler(request: web.Request) -> web.Response:
    meeting_name = ""
    if state.meeting_info:
        meeting_name = getattr(state.meeting_info, "meeting_name", "") or ""
    now = time.time()

    def _age(ts: float):
        return round(now - ts, 1) if ts else None

    aq = state.active_query
    active_query = bool(aq is not None and not aq.done())

    return web.Response(
        text=json.dumps({
            "status": "ok",
            "meeting": meeting_name,
            "session_active": state.session_active,
            "summarizing": state.summarizing,
            "uptime": round(now - state.started_at) if state.started_at else 0,
            "stats": {
                "ai_calls": state.ai_call_count,
                "ai_calls_by_kind": dict(state.ai_calls_by_kind),
                "local_todo_calls": state.local_todo_call_count,
                "local_todo_calls_by_kind": dict(state.local_todo_calls_by_kind),
                "last_local_todo_action": state.last_local_todo_action,
                "last_local_todo_at": state.last_local_todo_at,
            },
            "health": {
                "last_ai_call_at": state.last_ai_call_at or None,
                "last_ai_call_kind": state.last_ai_call_kind,
                "last_ai_call_age_sec": _age(state.last_ai_call_at),
                "active_query": active_query,
                "active_query_age_sec": (
                    _age(state.active_query_started_at) if active_query else None
                ),
                "event_loop_lag_ms": round(state.event_loop_lag_ms, 1),
                "cpu_percent": round(state.proc_cpu_percent, 1),
                "host_cpu_percent": round(state.host_cpu_percent, 1),
                "rss_mb": round(state.proc_rss_mb, 1),
            },
        }),
        content_type="application/json",
    )


async def workspace_handler(request: web.Request) -> web.Response:
    """Return the active workspace name and the daemon's bound port."""
    from meeting_helper.config import get_config, load_state
    state_data = load_state()
    cfg = get_config()
    return web.Response(
        text=json.dumps({
            "name": state_data["active_workspace"],
            "port": cfg.port,
        }),
        content_type="application/json",
    )


async def launcher_command_handler(request: web.Request) -> web.Response:
    """GET /launcher.command — serve the double-click launcher script.

    Returns the bash script bundled in ``meeting_helper.launcher_script``
    with a ``Content-Disposition: attachment`` header so browsers/webview
    save it as ``Meeting Helper.command``. The old Flet sidebar exposed
    this as a download icon; the new sidebar links to this endpoint
    directly via an `<a download>` element.
    """
    from meeting_helper.launcher_script import LAUNCHER_SCRIPT
    return web.Response(
        text=LAUNCHER_SCRIPT,
        content_type="text/x-shellscript",
        headers={
            "Content-Disposition": 'attachment; filename="Meeting Helper.command"',
        },
    )


async def logs_tail_handler(request: web.Request) -> web.Response:
    """GET /logs/tail?n=20 — return the last N lines of the daemon log.

    Used by the workspace-switch failure dialog so the user can see what
    actually broke without hunting through `~/.meeting-helper.log`. We clamp
    `n` to [1, 500] so a stray `?n=999999` cannot blow up the response.
    Missing log files return an empty list rather than 404 — fresh installs
    haven't written one yet.
    """
    from meeting_helper.config import LOG_FILE
    try:
        n = int(request.query.get("n", "20"))
    except ValueError:
        n = 20
    n = max(1, min(500, n))
    try:
        lines = LOG_FILE.read_text(errors="replace").splitlines()[-n:]
    except FileNotFoundError:
        lines = []
    except OSError as exc:
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({"lines": lines, "path": str(LOG_FILE)})


async def version_handler(request: web.Request) -> web.Response:
    """GET /version — daemon runtime version vs on-disk installed vs PyPI latest.

    Three versions, each meaningful:
      version            daemon's in-process __version__ (what's RUNNING)
      installed_version  importlib.metadata version (what's on DISK — pipx may
                         have already swapped this without restarting the daemon)
      latest             latest on PyPI (best-effort, None on fetch failure)

    Two flags the UI acts on:
      restart_needed     daemon < installed → just restart, no download needed
      outdated           installed < latest → pipx upgrade would help

    The old "outdated = version < latest" lumped both into one orange dot,
    which is what made the UI show "update available" even right after a
    successful pipx upgrade — the user had ALREADY updated, they just
    needed to restart. Splitting the two states lets the UI offer the
    right action for each.

    Old keys (`version`, `latest`, `outdated`) are preserved for any
    consumer that still reads them.
    """
    from meeting_helper import __version__ as daemon_version

    installed_version = daemon_version
    try:
        from importlib.metadata import PackageNotFoundError, version as _pkg_version
        try:
            installed_version = _pkg_version("meeting-helper")
        except PackageNotFoundError:
            # Editable / source checkout — metadata not registered. Fall back
            # to in-process __version__ so we don't flag a false restart.
            pass
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("version_handler: installed_version probe failed: %s", exc)

    latest: str | None = None
    restart_needed = False
    outdated = False
    try:
        from meeting_helper.auto_updater import _is_outdated, fetch_latest_version
        latest = await asyncio.to_thread(fetch_latest_version)
        if latest:
            outdated = _is_outdated(installed_version, latest)
        restart_needed = _is_outdated(daemon_version, installed_version)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("version_handler: latest-version probe failed: %s", exc)

    return web.json_response({
        "version": daemon_version,
        "daemon_version": daemon_version,
        "installed_version": installed_version,
        "latest": latest,
        "latest_version": latest,
        "outdated": outdated,
        "update_available": outdated,
        "restart_needed": restart_needed,
    })


async def daemon_restart_handler(request: web.Request) -> web.Response:
    """POST /daemon/restart — gracefully exit so the supervisor respawns us.

    The shell process (pywebview) runs a daemon supervisor that respawns the
    daemon any time it goes down. We just SIGTERM ourselves after a short
    delay so the HTTP response can flush, then let the supervisor pick up
    fresh code from the just-installed package.

    Returns 202 immediately so the UI can start polling /version for the
    new daemon_version.
    """
    import os
    import signal

    async def _die_after_grace() -> None:
        # 250 ms is plenty to flush the response and tear down the connection
        # before the SIGTERM lands. The supervisor's 8 s cooldown means a
        # double-click on the restart button is harmless.
        await asyncio.sleep(0.25)
        try:
            os.kill(os.getpid(), signal.SIGTERM)
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("daemon_restart_handler: SIGTERM self failed: %s", exc)

    asyncio.create_task(_die_after_grace())
    return web.json_response({"ok": True, "restarting": True}, status=202)


async def update_check_handler(request: web.Request) -> web.Response:
    """POST /update/check — force a fresh PyPI poll and report the result.

    Bypasses any cached value the sidebar might be holding so the user can
    confirm "am I really on the latest" without waiting for the next poll
    tick. The auto-updater's regular schedule still runs independently.
    """
    from meeting_helper import __version__
    from meeting_helper.auto_updater import _is_outdated, fetch_latest_version, is_editable_install

    editable, _ = is_editable_install()
    latest = await asyncio.to_thread(fetch_latest_version)
    return web.json_response({
        "current_version": __version__,
        "latest_version": latest,
        "update_available": bool(latest and _is_outdated(__version__, latest)),
        "editable": editable,
    })


async def update_now_handler(request: web.Request) -> web.Response:
    """POST /update/now — install the latest version on disk via pipx.

    Returns 202 right away. Pipx upgrade runs in a worker thread (it's a
    subprocess; we don't want to block the event loop). We deliberately
    DO NOT kill the daemon here — once the new version is on disk,
    /version starts reporting `restart_needed=true` and the sidebar
    surfaces the restart button. The user-clicked restart goes through
    the supervisor (a separate, well-tested path).

    Failure modes (pipx missing, PyPI unreachable, already-on-latest,
    editable install) return their reason in the JSON response so the
    UI can surface it.
    """
    from meeting_helper import __version__
    from meeting_helper.auto_updater import (
        _is_outdated,
        _refresh_or_install_app_bundle,
        fetch_latest_version,
        is_editable_install,
        upgrade_to_latest,
    )

    editable, src_path = is_editable_install()
    if editable:
        return web.json_response(
            {
                "ok": False,
                "reason": "editable_install",
                "message": (
                    f"This build is an editable install at {src_path}. "
                    "Auto-update only works for pipx installs."
                ),
            },
            status=409,
        )
    latest = await asyncio.to_thread(fetch_latest_version)
    if latest is None:
        return web.json_response(
            {"ok": False, "reason": "pypi_unreachable",
             "message": "Couldn't reach PyPI to check the latest version."},
            status=503,
        )
    if not _is_outdated(__version__, latest):
        return web.json_response(
            {"ok": True, "reason": "already_latest",
             "message": f"Already on the latest version (v{__version__}).",
             "current_version": __version__, "latest_version": latest},
        )

    # Install only — don't trigger the kill-and-respawn dance. The sidebar
    # picks up `installed_version != daemon_version` on the next /version
    # poll and renders the "restart" button, which uses the existing clean
    # SIGTERM → supervisor respawn path.
    async def _run() -> None:
        try:
            new_version = await asyncio.to_thread(
                upgrade_to_latest, latest, __version__,
            )
            if new_version:
                await asyncio.to_thread(
                    _refresh_or_install_app_bundle, new_version,
                )
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("update_now_handler: upgrade failed: %s", exc)

    asyncio.create_task(_run())
    return web.json_response(
        {"ok": True, "reason": "started",
         "current_version": __version__, "latest_version": latest},
        status=202,
    )


async def install_app_handler(request: web.Request) -> web.Response:
    """POST /install-app — build and install the Meeting Helper.app bundle.

    Always installs to ~/Applications (no sudo required, Spotlight-indexed).
    Returns {ok, path, version}. The UI uses this to surface a one-click
    install affordance in Settings → General.
    """
    from meeting_helper import __version__
    from meeting_helper.install_app import install_to_applications
    try:
        dest = await asyncio.to_thread(install_to_applications, system=False)
    except Exception as exc:
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({"ok": True, "path": str(dest), "version": __version__})


async def install_app_status_handler(request: web.Request) -> web.Response:
    """GET /install-app/status — whether the .app bundle is installed + its version.

    Returns {installed: bool, path: str|null, version: str|null, current_version: str}.
    `version` is whatever the Info.plist says (may be stale if the user upgraded
    pipx but didn't reinstall the bundle). `current_version` is the running
    daemon's version so the UI can show "Reinstall (out of date)" when they differ.
    """
    import plistlib
    from meeting_helper import __version__
    from meeting_helper.install_app import _user_install_path, _system_install_path

    candidates = [_user_install_path(), _system_install_path()]
    for path in candidates:
        if path.is_dir():
            info_plist = path / "Contents" / "Info.plist"
            installed_version = None
            try:
                with open(info_plist, "rb") as fh:
                    data = plistlib.load(fh)
                installed_version = data.get("CFBundleShortVersionString")
            except Exception:
                pass
            return web.json_response({
                "installed": True,
                "path": str(path),
                "version": installed_version,
                "current_version": __version__,
            })

    return web.json_response({
        "installed": False,
        "path": None,
        "version": None,
        "current_version": __version__,
    })


async def shutdown_handler(request: web.Request) -> web.Response:
    """Trigger graceful daemon shutdown via SIGTERM (handled in run_daemon)."""
    import os
    import signal
    asyncio.get_event_loop().call_later(
        0.1, lambda: os.kill(os.getpid(), signal.SIGTERM)
    )
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def workspaces_handler(request: web.Request) -> web.Response:
    """GET /workspaces — list every workspace on disk + the active one.

    Powers the new shell's workspace switcher dropdown. The Flet GUI did this
    by reading `config.list_workspaces()` + `config.load_state()` in-process;
    the web UI doesn't have that affordance so we surface it over HTTP.
    """
    from meeting_helper.config import list_workspaces, load_state
    return web.json_response({
        "active": load_state()["active_workspace"],
        "available": list_workspaces(),
    })


async def workspace_create_handler(request: web.Request) -> web.Response:
    """POST /workspace/create — create a new workspace.

    Body: ``{"name": "alpha", "copy_from": "default" | null}``.
    `copy_from` is optional; when provided we deep-copy that workspace's
    settings JSON so the new workspace starts with the user's tuned
    transcriber/AI provider/MCP choices instead of stock defaults.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    name = str(body.get("name") or "").strip()
    if not name:
        return web.json_response({"error": "name required"}, status=400)
    copy_from = body.get("copy_from")
    try:
        from meeting_helper.config import create_workspace
        create_workspace(name, copy_from=copy_from if copy_from else None)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    return web.json_response({"ok": True, "name": name})


async def workspace_rename_handler(request: web.Request) -> web.Response:
    """POST /workspace/rename — rename an existing workspace.

    Body: ``{"old": "alpha", "new": "alpha-prod"}``. Active-workspace renames
    are handled by ``rename_workspace`` (it updates state.json so the active
    pointer follows along).
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    old = str(body.get("old") or "").strip()
    new = str(body.get("new") or "").strip()
    if not old or not new:
        return web.json_response({"error": "old and new required"}, status=400)
    try:
        from meeting_helper.config import rename_workspace
        rename_workspace(old, new)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    return web.json_response({"ok": True, "name": new})


async def workspace_delete_handler(request: web.Request) -> web.Response:
    """POST /workspace/delete — delete a workspace by name.

    Refuses the active workspace and the last remaining workspace (both raise
    ``ValueError`` from ``config.delete_workspace``). The shell-side dialog
    also enforces these as a UX safeguard, but the daemon is the source of
    truth.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    name = str(body.get("name") or "").strip()
    if not name:
        return web.json_response({"error": "name required"}, status=400)
    try:
        from meeting_helper.config import delete_workspace
        delete_workspace(name)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    return web.json_response({"ok": True})


async def workspace_activate_handler(request: web.Request) -> web.Response:
    """POST /workspace/activate — swap active workspace IN-PROCESS.

    Reloads config, rebinds the local-todo MCP, clears workspace-scoped
    caches, then broadcasts a `workspace_switched` event so the UI
    invalidates its query caches. The daemon process itself never dies —
    so there's no supervisor race, no port flap, no "Disconnected" stall.
    The previous implementation SIGTERMed the daemon and relied on the
    shell supervisor to respawn it; that flow was fragile when the
    supervisor was slow or unreachable (no shell process running).
    """
    from meeting_helper.config import (
        get_config,
        list_workspaces,
        set_active_workspace,
    )

    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    name = str(body.get("name") or "").strip()
    if not name:
        return web.json_response({"error": "name required"}, status=400)
    if name not in list_workspaces():
        return web.json_response(
            {"error": f"unknown workspace {name!r}"}, status=404,
        )
    if state.session_active:
        return web.json_response(
            {"error": "stop the current recording before switching"},
            status=409,
        )
    try:
        set_active_workspace(name)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)

    # --- In-process reload ---

    # 1. Refresh the cached Config — set_active_workspace already invalidates it,
    #    but calling get_config(reload=True) makes the new disk state visible
    #    right now (and to anything that re-reads the cache later this turn).
    cfg = get_config(reload=True)

    # 2. Mutate the AppConfig in place so handlers that read
    #    `request.app["config"]` (library, transcribe, summarize) pick up
    #    the new recordings_dir + AI keys. Assigning to app[key] on a
    #    running app is deprecated in aiohttp ≥3.10, so update fields on
    #    the existing dataclass instead — same instance, new values.
    try:
        new_cfg = cfg.to_app_config()
        existing = request.app["config"]
        for field_name in new_cfg.__dataclass_fields__:
            setattr(existing, field_name, getattr(new_cfg, field_name))
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("workspace_activate: refresh app config failed: %s", exc)

    # 3. Swap the tracker to the new workspace's active tracker.
    #    Workspace boundary is HARD — every tracker session from the prior
    #    workspace must be torn down before the new workspace's Copilot is
    #    booted. Otherwise a chat-only tracker from the previous workspace
    #    (which `reboot_active_tracker` does NOT touch because it only
    #    handles the prior Copilot id) stays hot in the registry, leaking
    #    cross-workspace MCP access and giving the agent_fetch loop a path
    #    to write the wrong workspace's tickets into the current workspace's
    #    `copilot_learned_memory`.
    try:
        registry = getattr(state, "trackers", None)
        if registry is not None:
            await registry.shutdown()  # close ALL prior-workspace sessions
        from meeting_helper.trackers.registry import reboot_active_tracker
        await reboot_active_tracker(state, cfg, name)
        logger.info(
            "workspace_activate: tracker rebooted for workspace %s (tracker=%s)",
            name,
            getattr(state.tracker, "vendor_id", None),
        )
    except Exception as exc:
        logger.warning("workspace_activate: tracker reboot failed: %s", exc)
        state.tracker = None

    # 4. Clear workspace-scoped caches. The new workspace has its own
    #    tickets, conversation history, and current topic — keeping the
    #    old workspace's state around would surface stale data.
    state.conversation_history = []
    state.sprint_tickets = []
    # Resetting sprint_tickets alone isn't enough — refresh_sprint_tickets
    # short-circuits on `state.sprint_tickets and (now - loaded_at) < 5min`.
    # Without zeroing loaded_at, a fast follow-up that races between the
    # clear and the next agent fetch could see an empty list with a fresh
    # timestamp and skip the fetch, leaving the new workspace empty.
    state.sprint_tickets_loaded_at = 0.0
    state.last_response = ""
    state.last_cards = []
    state.current_topic = {
        "topic": "",
        "ticket_ids": [],
        "search_query": "",
        "last_user_statement": "",
        "manual": False,
    }
    state.current_topic_cards = []
    state.last_user_query_topic = {"topic": "", "ticket_ids": []}
    state.clear_pins()
    # The TopicWorker instance is reused across workspace switches. Its
    # `_last_hash` reflects the PRIOR workspace's transcript hash; if the
    # next workspace happens to load with similar buffer state, the worker
    # would silently skip a tick that should have run. Clear it.
    _tw = getattr(state, "topic_worker", None)
    if _tw is not None:
        try:
            _tw._last_hash = ""
        except Exception:
            pass

    # 5. Update the system prompt + AI model labels.
    try:
        from meeting_helper.ai.prompts import build_system_prompt
        state.system_prompt = build_system_prompt("")
    except Exception:
        pass
    state.ai_provider = cfg.preferred_provider or "claude"
    if cfg.preferred_provider == "local":
        state.ai_model = cfg.local_model
    elif cfg.preferred_provider == "gemini":
        state.ai_model = cfg.gemini_model
    else:
        state.ai_model = cfg.claude_model

    # 6. Broadcast so the UI invalidates queries (workspaces list, topics,
    #    config, provider, tasks, library — anything workspace-scoped).
    try:
        from meeting_helper.server.websocket import broadcast as _broadcast
        await _broadcast({"type": "workspace_switched", "active": name})
    except Exception as exc:  # pragma: no cover
        logger.warning("workspace_activate: broadcast failed: %s", exc)

    # 6a. Re-broadcast the new workspace's action items so any connected
    #     Copilot panel swaps its open-items list immediately. The list is
    #     workspace-scoped (orphans live next to the workspace JSON, sidecars
    #     live in the workspace's recordings_dir).
    try:
        await _broadcast_action_items_snapshot(request.app)
    except Exception as exc:  # pragma: no cover
        logger.warning(
            "workspace_activate: action_items snapshot broadcast failed: %s",
            exc,
        )

    # 7. Pre-warm the topics cache for the new workspace. Without this, the
    #    Copilot panel is empty until the first transcript sentence (or a
    #    manual refresh click) and we'd hand the picker an empty list. Fire
    #    and forget — the UI gets a `topic_refresh` ws event when it's done.
    #
    #    Cancel any in-flight pre-warm from the PRIOR workspace first. On a
    #    rapid switch (A → B → A) two pre-warm tasks could otherwise be
    #    racing and the later finisher would write its tickets into whatever
    #    workspace happens to be active at completion time, contaminating
    #    state.sprint_tickets across the boundary.
    prev_task = getattr(state, "prewarm_task", None)
    if prev_task is not None and not prev_task.done():
        prev_task.cancel()
        try:
            await prev_task
        except (asyncio.CancelledError, Exception):
            pass
    state.prewarm_task = None
    if getattr(state, "tracker", None) is not None:
        try:
            from meeting_helper.ai.client import refresh_sprint_tickets
            state.prewarm_task = asyncio.create_task(refresh_sprint_tickets(state, force=True))
        except Exception as exc:
            logger.warning("workspace_activate: pre-warm topics failed: %s", exc)

    return web.json_response({"ok": True, "active": name, "restarting": False})


def _compute_effective_transcriber_payload(getter) -> dict:
    """Wrap ``compute_effective_transcriber`` for the ``/config`` GET.

    Pulls the four fields it cares about via the same ``_g`` helper the
    rest of the payload uses so an unset field defaults to "" instead
    of crashing on `None`.
    """
    from meeting_helper.audio.transcriber import compute_effective_transcriber

    return compute_effective_transcriber(
        preferred_transcriber=str(getter("preferred_transcriber", "") or ""),
        deepgram_api_key=str(getter("deepgram_api_key", "") or ""),
        whisper_host=str(getter("whisper_host", "") or ""),
        transcription_language=str(getter("transcription_language", "en") or "en"),
    )


async def config_get_handler(request: web.Request) -> web.Response:
    """Return the full live AppConfig snapshot the Settings UI hydrates from.

    Plan 2's Settings tabs render a single form driven by `useConfigForm`,
    which expects every field declared in `web/lib/config-schema.ts` to be
    present on the response — missing keys leave Zod- / hand-typed reads
    pointing at `undefined` and crash the client. We therefore mirror the
    full `AppConfig` dataclass shape (including `recordings_dir` coerced
    to a string so it survives JSON round-tripping). Fields the UI doesn't
    yet write are still safe to expose; the POST handler ignores keys it
    doesn't know about.
    """
    config = request.app["config"]

    # Menubar / autostart toggles live on the disk-backed Config (workspace
    # JSON), not on the live AppConfig dataclass — they only matter on
    # menubar/launchd setup and aren't part of the runtime hot path. Read
    # them via `get_config()._data` for the GET payload so the UI hydrates
    # with the user's persisted choice.
    from meeting_helper.config import get_config
    disk = get_config()

    def _g(name: str, default):
        v = getattr(config, name, default)
        return v if v is not None else default

    payload = {
        "anthropic_api_key": _g("anthropic_api_key", ""),
        "google_api_key": _g("google_api_key", ""),
        "deepgram_api_key": _g("deepgram_api_key", ""),
        "port": int(_g("port", 7891)),
        "recordings_dir": str(_g("recordings_dir", "")),
        "kb_artifacts": list(_g("kb_artifacts", []) or []),
        "kb_max_results": int(_g("kb_max_results", 3)),
        "auto_summarize_on_end": bool(_g("auto_summarize_on_end", False)),
        "auto_rename_on_end": bool(_g("auto_rename_on_end", False)),
        "auto_add_to_kb": bool(_g("auto_add_to_kb", True)),
        "deepgram_diarize_other": bool(_g("deepgram_diarize_other", True)),
        "deepgram_diarize_self": bool(_g("deepgram_diarize_self", False)),
        "auto_name_speakers_on_end": bool(_g("auto_name_speakers_on_end", True)),
        "user_display_name": _g("user_display_name", ""),
        "sentence_window": int(_g("sentence_window", 5)),
        "max_history_turns": int(_g("max_history_turns", 5)),
        "claude_model": _g("claude_model", ""),
        "claude_model_alias": _g("claude_model_alias", "sonnet"),
        "gemini_model": _g("gemini_model", ""),
        "gemini_model_alias": _g("gemini_model_alias", "flash"),
        "max_tokens": int(_g("max_tokens", 2048)),
        "transcription_language": _g("transcription_language", "en"),
        "silence_timeout": int(_g("silence_timeout", 30)),
        "hot_moment_window_minutes": float(_g("hot_moment_window_minutes", 10.0)),
        "proactive_answers": bool(_g("proactive_answers", False)),
        "preferred_provider": _g("preferred_provider", ""),
        "ai_provider_order": list(_g("ai_provider_order", []) or []),
        "ai_failover_delay_ms": int(_g("ai_failover_delay_ms", 2000)),
        "ollama_host": _g("ollama_host", ""),
        "local_model": _g("local_model", ""),
        "preferred_transcriber": _g("preferred_transcriber", ""),
        "whisper_host": _g("whisper_host", ""),
        # Resolved view of what `create_transcriber` would actually start
        # with the current config. The Settings UI renders this as a
        # status badge so users can see (e.g.) "Local Whisper" even when
        # they never explicitly picked anything — Whisper is the
        # batteries-included fallback.
        "effective_transcriber": _compute_effective_transcriber_payload(_g),
        "auto_start_record": bool(_g("auto_start_record", True)),
        "system_prompt": _g("system_prompt", ""),
        "local_todo_mcp": dict(_g("local_todo_mcp", {}) or {}),
        "show_menubar_icon": bool(disk._data.get("show_menubar_icon", True)),
        "menubar_icon": str(disk._data.get("menubar_icon", "MH")),
        "autostart_on_login": bool(disk._data.get("autostart_on_login", False)),
        "copilot_instructions": str(disk._data.get("copilot_instructions", "") or ""),
        "copilot_learned_memory": list(disk._data.get("copilot_learned_memory", []) or []),
        "action_items_extract_after_meeting": bool(
            _g("action_items_extract_after_meeting", False)
        ),
        "action_items_inject_into_copilot": bool(
            _g("action_items_inject_into_copilot", True)
        ),
    }
    return web.Response(
        text=json.dumps(payload),
        content_type="application/json",
    )


async def config_post_handler(request: web.Request) -> web.Response:
    """Update live-tunable workspace config mid-session.

    Accepts every field the new Settings UI writes: API keys, recordings dir,
    auto-on-end toggles, AI provider/model, transcriber settings, hot-moment
    window, MCP config, Ollama host, menubar visibility, and the AI system
    prompt. The daemon caches its `AppConfig` at startup, so without this the
    GUI's saved changes were silently ignored until a full daemon restart —
    here we mutate the in-memory config and, if a session is running, hot-swap
    the transcribers (same path as `/provider`).
    """
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    config = request.app["config"]

    # Load the disk-backed Config once; mirror writes here. Save at the end
    # so a single POST is one fsync rather than one per field. Without this
    # mirror, every field below would only update the in-memory AppConfig
    # snapshot and revert on the next daemon restart.
    from meeting_helper.config import get_config
    disk = get_config()
    disk_dirty = False

    if "hot_moment_window_minutes" in body:
        # Live tunable. Mirror it onto `state` so every Hot Moment armer
        # (TopicWorker on self-speech, query, brief) picks up the change on
        # the next event — `state` is what they read, not this snapshot.
        minutes = float(body["hot_moment_window_minutes"])
        if minutes != config.hot_moment_window_minutes:
            config.hot_moment_window_minutes = minutes
            disk.hot_moment_window_minutes = minutes
            disk_dirty = True
        state.hot_moment_window_sec = minutes * 60.0
    if "local_todo_mcp" in body:
        # MCP config changed — update disk config and reboot the active tracker
        # via the registry so the correct vendor profile is used.
        new_mcp = dict(body["local_todo_mcp"] or {})
        config.local_todo_mcp = new_mcp
        disk.local_todo_mcp = new_mcp
        disk_dirty = True
        try:
            from meeting_helper.trackers.registry import reboot_active_tracker
            workspace_name = getattr(config, "workspace_name", "") or ""
            await reboot_active_tracker(state, disk, workspace_name)
            logger.info(
                "local-todo MCP reconfig: rebooted tracker (vendor=%s)",
                getattr(state.tracker, "vendor_id", None),
            )
        except Exception as exc:
            logger.warning("local-todo MCP reconfig: tracker reboot failed: %s", exc)
            state.tracker = None
        # Push fresh info so Brief-button visibility flips without polling delay.
        from meeting_helper.server.websocket import broadcast_info
        asyncio.ensure_future(broadcast_info())

    # Transcriber settings — the daemon's AppConfig snapshot would otherwise
    # only pick these up on a full restart. Mutate it in place and, if a
    # session is live, hot-swap the transcribers (reuses session.swap_transcriber,
    # the same machinery the /provider toolbar dropdown uses). Only act on
    # values that actually changed so an unrelated settings-save doesn't tear
    # down and rebuild the transcribers mid-meeting.
    _trans_changed = False
    if "preferred_transcriber" in body:
        v = (body["preferred_transcriber"] or "").strip()
        if v != config.preferred_transcriber:
            config.preferred_transcriber = v
            disk.preferred_transcriber = v
            disk_dirty = True
            _trans_changed = True
    if "whisper_host" in body:
        v = (body["whisper_host"] or "").strip()
        if v != config.whisper_host:
            config.whisper_host = v
            disk.whisper_host = v
            disk_dirty = True
            _trans_changed = True
    if "deepgram_api_key" in body:
        v = (body["deepgram_api_key"] or "").strip()
        if v != config.deepgram_api_key:
            config.deepgram_api_key = v
            disk.deepgram_api_key = v
            disk_dirty = True
            _trans_changed = True
    if "transcription_language" in body:
        v = (body["transcription_language"] or "auto").strip()
        if v != config.transcription_language:
            config.transcription_language = v
            disk.transcription_language = v
            disk_dirty = True
            _trans_changed = True
    if _trans_changed:
        if state.session_active and state.meeting_session is not None:
            try:
                t_name = await asyncio.to_thread(
                    state.meeting_session.swap_transcriber,
                    config.preferred_transcriber, config,
                )
                state.transcriber_name = t_name
                logger.info("Transcriber reconfigured live via /config -> %s", t_name)
            except Exception as exc:
                logger.warning("live transcriber swap failed: %s", exc)
        else:
            logger.info("Transcriber config updated via /config (no active session)")
        from meeting_helper.server.websocket import broadcast_info as _bi
        await _bi()

    # Provider credentials, recordings dir, auto-on-end toggles, and other
    # settings the Settings UI writes. Mutates the in-memory AppConfig so
    # downstream readers (LLM clients, recording sink, session lifecycle hooks)
    # pick up the new values without a daemon restart.
    if "anthropic_api_key" in body:
        v = str(body["anthropic_api_key"] or "")
        if v != config.anthropic_api_key:
            config.anthropic_api_key = v
            disk.anthropic_api_key = v
            disk_dirty = True
    if "google_api_key" in body:
        v = str(body["google_api_key"] or "")
        if v != config.google_api_key:
            config.google_api_key = v
            disk.google_api_key = v
            disk_dirty = True
    if "recordings_dir" in body:
        v = str(body["recordings_dir"] or "")
        if v:
            config.recordings_dir = v
            disk.recordings_dir = v
            disk_dirty = True
    if "auto_summarize_on_end" in body:
        v = bool(body["auto_summarize_on_end"])
        if v != config.auto_summarize_on_end:
            config.auto_summarize_on_end = v
            disk.auto_summarize_on_end = v
            disk_dirty = True
    if "auto_rename_on_end" in body:
        v = bool(body["auto_rename_on_end"])
        if v != config.auto_rename_on_end:
            config.auto_rename_on_end = v
            disk.auto_rename_on_end = v
            disk_dirty = True
    if "auto_add_to_kb" in body:
        v = bool(body["auto_add_to_kb"])
        if v != config.auto_add_to_kb:
            config.auto_add_to_kb = v
            disk.auto_add_to_kb = v
            disk_dirty = True
    if "deepgram_diarize_other" in body:
        v = bool(body["deepgram_diarize_other"])
        if v != config.deepgram_diarize_other:
            config.deepgram_diarize_other = v
            disk.deepgram_diarize_other = v
            disk_dirty = True
    if "deepgram_diarize_self" in body:
        v = bool(body["deepgram_diarize_self"])
        if v != config.deepgram_diarize_self:
            config.deepgram_diarize_self = v
            disk.deepgram_diarize_self = v
            disk_dirty = True
    if "auto_name_speakers_on_end" in body:
        v = bool(body["auto_name_speakers_on_end"])
        if v != config.auto_name_speakers_on_end:
            config.auto_name_speakers_on_end = v
            disk.auto_name_speakers_on_end = v
            disk_dirty = True
    if "action_items_extract_after_meeting" in body:
        v = bool(body["action_items_extract_after_meeting"])
        if v != getattr(config, "action_items_extract_after_meeting", False):
            config.action_items_extract_after_meeting = v
            disk.action_items_extract_after_meeting = v
            disk_dirty = True
    if "action_items_inject_into_copilot" in body:
        v = bool(body["action_items_inject_into_copilot"])
        if v != getattr(config, "action_items_inject_into_copilot", True):
            config.action_items_inject_into_copilot = v
            disk.action_items_inject_into_copilot = v
            disk_dirty = True
            # Toggle changed: nudge clients so the Copilot Topics panel
            # picks up the new state without waiting for the next mutation
            # (when off the snapshot is suppressed; clients still receive
            # the absence as a signal via topics-card's invalidate-on-event).
            await _broadcast_action_items_snapshot(request.app)
    if "user_display_name" in body:
        v = str(body["user_display_name"] or "").strip()
        if v != config.user_display_name:
            config.user_display_name = v
            disk.user_display_name = v
            disk_dirty = True
    if "auto_start_record" in body:
        v = bool(body["auto_start_record"])
        if v != config.auto_start_record:
            config.auto_start_record = v
            disk.auto_start_record = v
            disk_dirty = True
    if "ollama_host" in body:
        v = str(body["ollama_host"] or "")
        if v != config.ollama_host:
            config.ollama_host = v
            disk.ollama_host = v
            disk_dirty = True
    if "claude_model_alias" in body:
        v = str(body["claude_model_alias"] or "")
        if v and v != config.claude_model_alias:
            config.claude_model_alias = v
            # Config stores the alias under the `claude_model` key, same
            # pattern the /provider handler uses (routes.py ~1453).
            disk.claude_model = v
            disk_dirty = True
    if "gemini_model_alias" in body:
        v = str(body["gemini_model_alias"] or "")
        if v and v != config.gemini_model_alias:
            config.gemini_model_alias = v
            disk.gemini_model = v
            disk_dirty = True
    if "system_prompt" in body:
        # `system_prompt` is built dynamically by `Config.to_app_config` from
        # `build_system_prompt("")` and is not persisted in the workspace
        # JSON. Update the in-memory snapshot so the current daemon process
        # picks it up; on restart it'll regenerate from the prompts module.
        v = str(body["system_prompt"] or "")
        if v != config.system_prompt:
            config.system_prompt = v

    # Menubar visibility / glyph and macOS LaunchAgent autostart. These live
    # only on `disk._data` (not the runtime AppConfig dataclass) because they
    # affect a sibling process (`meeting_helper.menubar`) and an OS-level
    # plist, not the daemon's own hot path. Old Flet (`screens/settings.py:
    # _autosave + _restart_menubar + _update_autostart`) did the same dance:
    # write the JSON, then kill/respawn the menubar PID and write/remove the
    # `~/Library/LaunchAgents/com.meeting-helper.menubar.plist` file.
    _menubar_state_changed = False
    _autostart_changed_to: bool | None = None
    if "show_menubar_icon" in body:
        v = bool(body["show_menubar_icon"])
        cur = bool(disk._data.get("show_menubar_icon", True))
        if v != cur:
            disk._data["show_menubar_icon"] = v
            disk_dirty = True
            _menubar_state_changed = True
    if "menubar_icon" in body:
        v = str(body["menubar_icon"] or "MH")
        cur = str(disk._data.get("menubar_icon", "MH"))
        if v != cur:
            disk._data["menubar_icon"] = v
            disk_dirty = True
            _menubar_state_changed = True
    if "autostart_on_login" in body:
        v = bool(body["autostart_on_login"])
        cur = bool(disk._data.get("autostart_on_login", False))
        if v != cur:
            disk._data["autostart_on_login"] = v
            disk_dirty = True
            _autostart_changed_to = v

    # AI provider / model — same story: cached at daemon startup, so a Settings
    # change to these used to need a daemon restart. Queries read `config` fresh,
    # so mutating the in-memory snapshot is enough (no transcriber-style swap).
    _ai_changed = False
    if "preferred_provider" in body:
        v = (body["preferred_provider"] or "").strip()
        if v != config.preferred_provider:
            config.preferred_provider = v
            disk.preferred_provider = v
            disk_dirty = True
            _ai_changed = True
    if "claude_model" in body:
        from meeting_helper.config import CLAUDE_MODELS
        alias = (body["claude_model"] or "").strip()
        if alias and alias != config.claude_model_alias:
            config.claude_model_alias = alias
            config.claude_model = CLAUDE_MODELS.get(alias, alias)
            disk.claude_model = alias
            disk_dirty = True
            _ai_changed = True
    if "gemini_model" in body:
        from meeting_helper.config import GEMINI_MODELS
        alias = (body["gemini_model"] or "").strip()
        if alias and alias != config.gemini_model_alias:
            config.gemini_model_alias = alias
            config.gemini_model = GEMINI_MODELS.get(alias, alias)
            disk.gemini_model = alias
            disk_dirty = True
            _ai_changed = True
    if "local_model" in body:
        v = (body["local_model"] or "").strip()
        if v != config.local_model:
            config.local_model = v
            disk.local_model = v
            disk_dirty = True
            _ai_changed = True
    if "ai_provider_order" in body:
        v = body["ai_provider_order"] or []
        if isinstance(v, list):
            normalized = [str(p).strip().lower() for p in v]
            if normalized != list(config.ai_provider_order):
                config.ai_provider_order = normalized
                disk.ai_provider_order = normalized
                disk_dirty = True
                _ai_changed = True
    if "ai_failover_delay_ms" in body:
        try:
            v = max(0, int(body["ai_failover_delay_ms"]))
        except (TypeError, ValueError):
            v = config.ai_failover_delay_ms
        if v != config.ai_failover_delay_ms:
            config.ai_failover_delay_ms = v
            disk.ai_failover_delay_ms = v
            disk_dirty = True
            _ai_changed = True
    if _ai_changed:
        state.ai_provider = config.preferred_provider or "claude"
        state.ai_model = _resolve_ai_model(config)
        logger.info("AI provider/model reconfigured live via /config -> %s / %s",
                    state.ai_provider, state.ai_model)
        from meeting_helper.server.websocket import broadcast_info as _bi2
        await _bi2()

    if "copilot_instructions" in body:
        v = str(body["copilot_instructions"] or "")
        if v != config.copilot_instructions:
            config.copilot_instructions = v
            disk.copilot_instructions = v
            disk_dirty = True

    if "copilot_learned_memory" in body:
        v = list(body["copilot_learned_memory"] or [])
        if v != config.copilot_learned_memory:
            config.copilot_learned_memory = v
            disk.copilot_learned_memory = v
            disk_dirty = True

    # Persist all dataclass-mirrored field writes to the workspace JSON in a
    # single fsync. Without this the in-memory AppConfig snapshot drifts from
    # disk and any saved Settings revert on daemon restart.
    if disk_dirty:
        try:
            disk.save()
        except Exception as exc:
            logger.warning("config disk save failed: %s", exc)

    # Side-effects that must happen *after* disk.save() so the new state is
    # what the menubar (a separate process) reads on respawn.
    if _menubar_state_changed:
        _restart_menubar_process(disk)
    if _autostart_changed_to is not None:
        _apply_autostart_setting(bool(_autostart_changed_to))

    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


def _restart_menubar_process(disk) -> None:
    """Kill the existing menubar PID and respawn iff the icon is enabled.

    Same flow as old Flet's `_restart_menubar` in
    `flet_gui/screens/settings.py`. The menubar reads its glyph from disk
    on startup, so toggling either `show_menubar_icon` or `menubar_icon`
    requires the relaunch — otherwise the bar shows the previous glyph
    until next daemon restart.
    """
    import os
    import signal
    import sys
    from meeting_helper.config import MENUBAR_PID_FILE
    if MENUBAR_PID_FILE.exists():
        try:
            pid = int(MENUBAR_PID_FILE.read_text().strip())
            os.kill(pid, signal.SIGTERM)
        except (ValueError, ProcessLookupError, FileNotFoundError):
            pass
        except Exception as exc:
            logger.warning("menubar kill failed: %s", exc)
        try:
            MENUBAR_PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass
    if disk._data.get("show_menubar_icon", True):
        try:
            subprocess.Popen(
                [sys.executable, "-m", "meeting_helper.menubar"],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )
        except Exception as exc:
            logger.warning("menubar respawn failed: %s", exc)


def _apply_autostart_setting(enabled: bool) -> None:
    """Write or remove the macOS LaunchAgent plist for the menubar.

    Mirrors old Flet's `_update_autostart`: writes
    `~/Library/LaunchAgents/com.meeting-helper.menubar.plist` and runs
    `launchctl load` when enabled; unloads + deletes it when disabled.
    No-op on non-Darwin (launchctl absent — Popen will surface that).
    """
    import shutil
    import sys
    plist_path = Path.home() / "Library" / "LaunchAgents" / "com.meeting-helper.menubar.plist"
    if enabled:
        cli = shutil.which("meeting-helper") or str(Path(sys.executable).parent / "meeting-helper")
        plist_content = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
            '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            '<plist version="1.0">\n'
            '<dict>\n'
            '    <key>Label</key>\n'
            '    <string>com.meeting-helper.menubar</string>\n'
            '    <key>ProgramArguments</key>\n'
            '    <array>\n'
            f'        <string>{cli}</string>\n'
            '        <string>menubar</string>\n'
            '    </array>\n'
            '    <key>RunAtLoad</key>\n'
            '    <true/>\n'
            '    <key>KeepAlive</key>\n'
            '    <false/>\n'
            '</dict>\n'
            '</plist>'
        )
        try:
            plist_path.parent.mkdir(parents=True, exist_ok=True)
            plist_path.write_text(plist_content)
            subprocess.run(
                ["launchctl", "load", str(plist_path)],
                capture_output=True,
            )
        except Exception as exc:
            logger.warning("autostart enable failed: %s", exc)
    else:
        if plist_path.exists():
            try:
                subprocess.run(
                    ["launchctl", "unload", str(plist_path)],
                    capture_output=True,
                )
                plist_path.unlink(missing_ok=True)
            except Exception as exc:
                logger.warning("autostart disable failed: %s", exc)


async def transcript_handler_get(request: web.Request) -> web.Response:
    """GET /transcript — return the last N sentences from the buffer."""
    n = int(request.query.get("n", "10"))
    sentences = []
    if state.sentence_buffer is not None:
        sentences = state.sentence_buffer.get_last_n(n)
    interim = None
    if state.sentence_buffer is not None:
        interim = state.sentence_buffer.get_interim()
    return web.Response(
        text=json.dumps({"sentences": sentences, "interim": interim}),
        content_type="application/json",
    )


async def transcript_clear_handler(request: web.Request) -> web.Response:
    """POST /transcript/clear — clear the accumulated transcript buffer."""
    if state.sentence_buffer is not None:
        state.sentence_buffer.clear()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def last_response_handler(request: web.Request) -> web.Response:
    """GET /last_response — return the last AI response text."""
    return web.Response(
        text=json.dumps({"text": state.last_response or ""}),
        content_type="application/json",
    )


async def last_cards_handler(request: web.Request) -> web.Response:
    """GET /last_cards — returns the last query's local-todo source cards."""
    return web.Response(
        text=json.dumps({"items": state.last_cards or []}),
        content_type="application/json",
    )


async def current_topic_handler(_request: web.Request) -> web.Response:
    """GET /current_topic - current topic + warm-cache info + pinned basket.

    The `pinned` array is the canonical source for manual mode: when empty
    the worker runs over the full sprint cache; when non-empty it narrows
    to this list. UI derives "is manual?" from `pinned.length > 0`.
    """
    topic = state.current_topic or {
        "topic": "",
        "ticket_ids": [],
        "search_query": "",
        "last_user_statement": "",
    }
    return web.json_response({
        "topic": topic,
        "cards_count": len(state.current_topic_cards or []),
        "cards": [
            slim_card_for_broadcast(c) for c in (state.current_topic_cards or [])
        ],
        "pinned": [
            {"kind": p.kind, "id": p.id, "title": p.title, "board_id": p.board_id}
            for p in state.pinned_topics
        ],
    })


async def topics_handler(request: web.Request) -> web.Response:
    """GET /topics — list active sprint tasks pre-fetched by the agent.

    Powers the Topics tab in the Copilot side panel: the user picks one to
    set as the current conversation topic, overriding TopicWorker's
    automatic detection for a brief window.

    Tasks come from state.sprint_tickets, which the agent fetch loop
    populates on a background timer. Columns are omitted — the agent fetch
    doesn't produce column metadata and vendor profiles no longer implement
    that capability.
    """
    tracker = getattr(state, "tracker", None)
    if tracker is None:
        # No tracker wired up — skip the ticket fetch but still surface action
        # items (they're tracker-independent). The empty `raw_tasks` falls
        # through to the action-items append below.
        raw_tasks: list[dict] = []
    else:
        # Use the agent-fetched sprint tickets (dicts, not Task dataclasses).
        raw_tasks = list(getattr(state, "sprint_tickets", None) or [])

    # Slim each task to the fields TopicsPanel renders.
    # Keep status_kind + subtasks so the panel can group by todo/in_progress/done
    # and show the agent-fetched subtask breakdown for parent issues.
    def _slim_subtask(s: dict) -> dict:
        return {
            "id": str(s.get("id") or ""),
            "title": s.get("title") or "",
            "status": (s.get("status") or "").lower(),
            "status_kind": (s.get("status_kind") or "todo").lower(),
            "url": s.get("url") or "",
        }

    slimmed = [
        {
            "id": str(t.get("id") or ""),
            "title": t.get("title") or "",
            "status": (t.get("status") or "todo").lower(),
            "status_kind": (t.get("status_kind") or "todo").lower(),
            "priority": (t.get("priority") or "").lower(),
            "board_id": t.get("board_id") or t.get("workspace_id"),
            "board_name": t.get("board_name") or t.get("workspace_name") or "",
            "sprint_name": t.get("sprint_name") or "",
            "url": t.get("url") or "",
            "subtasks": [_slim_subtask(s) for s in (t.get("subtasks") or [])],
        }
        for t in raw_tasks
        if (t.get("title") or "").strip()
    ]

    # Append open action items so the Copilot Topics panel renders them
    # alongside ticket topics. Gated by the workspace setting; appears as a
    # virtual "Action Items" board so the panel's existing grouping handles
    # it without changes.
    cfg = request.app["config"]
    columns: list[dict] = []
    if getattr(cfg, "action_items_inject_into_copilot", True):
        try:
            from meeting_helper.action_items import store as _ai_store
            disk = _resolve_disk(request)
            recordings = _recordings_dir(cfg)
            ws_json = _workspace_json_path(disk)
            # Offload disk glob+reads from the asyncio loop (ticket #25).
            all_items = await _ai_store.list_all_async(ws_json, recordings)
            open_items = [i for i in all_items if not i.get("completed")]
        except Exception:
            open_items = []
        for it in open_items:
            slimmed.append({
                "id": it["id"],
                "title": it["title"],
                "status": "open",
                "status_kind": "todo",
                "priority": "",
                "board_id": "action_items",
                "board_name": "Action Items",
                "sprint_name": "",
                "url": f"/action-items/?id={it['id']}",
                "subtasks": [],
            })
        if open_items:
            columns.append({
                "board_id": "action_items",
                "key": "open",
                "name": "Action Items",
                "color": "amber",
                "position": 1000,
            })

    # Append KB-flagged notes so the Copilot Topics panel surfaces them as
    # candidate topics. Notes get a virtual "Notes" board, mirroring the
    # action-items pattern above. The user's KB toggle is their explicit
    # curation signal ("treat this as relevant context"); non-KB notes
    # stay invisible here. Click semantics live on the client (TopicsCard
    # routes kind="note" through topic.pin instead of topic/set).
    try:
        disk_for_notes = _resolve_disk(request)
        from meeting_helper.chat.tools.notes import list_notes_for
        all_notes = list_notes_for(disk_for_notes).get("notes", [])
    except Exception:
        all_notes = []
    kb_notes = [n for n in all_notes if n.get("in_kb")]
    for n in kb_notes:
        slimmed.append({
            "id": n["id"],
            "title": n["title"],
            "kind": "note",
            "status": "kb",
            "status_kind": "note",
            "priority": "",
            "board_id": "notes",
            "board_name": "Notes",
            "sprint_name": "",
            "url": n.get("url") or f"/notes/?id={n['id']}",
            "subtasks": [],
        })
    if kb_notes:
        columns.append({
            "board_id": "notes",
            "key": "kb",
            "name": "Notes",
            "color": "emerald",
            "position": 1100,
        })

    return web.json_response({"topics": slimmed, "columns": columns})


async def topics_refresh_handler(request: web.Request) -> web.Response:
    """POST /topics/refresh — force-refresh the agent-fetched topic cache.

    Runs `refresh_sprint_tickets(state, force=True)` which uses the active
    tracker's MCP tools via an LLM agent loop. Slow on first call for a new
    workspace (5-15s); fast on warm runs because the agent caches learned
    facts in `copilot_learned_memory`. Broadcasts `topic_refresh` WS events
    (start + done) so the UI can render a spinner.
    """
    from meeting_helper.ai.client import refresh_sprint_tickets
    try:
        await refresh_sprint_tickets(state, force=True)
    except Exception as exc:
        logger.warning("topics/refresh failed: %s", exc)
        return web.json_response({"ok": False, "error": str(exc)[:300]}, status=500)
    return web.json_response({
        "ok": True,
        "count": len(state.sprint_tickets or []),
    })


async def topic_set_handler(request: web.Request) -> web.Response:
    """POST /topic/set — manually pin the current topic.

    Body: {ticket_id: str, title: str, board_id?: int}

    Side effects:
    - state.current_topic is updated.
    - state.pinned_topics is cleared and the chosen ticket is pinned, so
      TopicWorker narrows to it (basket non-empty == MANUAL mode).
    - WS broadcast fires so the TopicStrip on top + the active-topic
      highlight in TopicsPanel update immediately.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    ticket_id = str(body.get("ticket_id") or "").strip()
    title = (body.get("title") or "").strip()
    board_id = body.get("board_id")
    if not title:
        return web.json_response({"error": "title required"}, status=400)

    # MANUAL mode is sticky — stays on until the user explicitly toggles
    # back to AUTO via POST /topic/auto (or by clicking the indicator pill
    # in the GUI). No countdown.
    state.current_topic = {
        "topic": title,
        "ticket_ids": [ticket_id] if ticket_id else [],
        "search_query": title,
        "last_user_statement": "",
        "manual": True,
    }
    # A manual pin is an explicit user choice — treat it as the new follow-up
    # anchor so the next typed question's picker stays on this ticket.
    state.last_user_query_topic = {
        "topic": title,
        "ticket_ids": [ticket_id] if ticket_id else [],
    }
    # Equivalent to clear+pin(ticket): drop any prior basket, add this one.
    from meeting_helper.state import PinnedItem as _PinnedItem
    state.clear_pins()
    if ticket_id:
        state.pin_topic(_PinnedItem(
            kind="ticket",
            id=ticket_id,
            title=title,
            board_id=str(board_id) if board_id is not None else "",
        ))

    # Look up the card from agent-fetched sprint tickets. If found, use the
    # pre-fetched body + comments so the AI has context without a live MCP
    # round-trip. Fall back to a thin card (title only) when not found.
    hydrated_cards: list[dict] = []
    if ticket_id:
        sprint_tickets: list[dict] = list(getattr(state, "sprint_tickets", None) or [])
        matched = next((t for t in sprint_tickets if str(t.get("id") or "") == ticket_id), None)
        if matched:
            hydrated_cards = [matched]
            logger.info(
                "topic/set: found card %s in sprint_tickets (body=%d chars, %d comments)",
                ticket_id,
                len(matched.get("body_md") or ""),
                len(matched.get("recent_comments") or []),
            )

    if not hydrated_cards:
        # Fall back to a thin card so the AI at least sees the ticket id +
        # title. Cards markdown handles thin cards gracefully (title only).
        thin_card: dict = {"id": ticket_id, "title": title}
        if board_id is not None:
            thin_card["board_id"] = board_id
        hydrated_cards = [thin_card]

    state.current_topic_cards = hydrated_cards

    # Broadcast so all connected GUIs reflect the change immediately.
    # Reuse the shared payload builder so basket-mutating events all carry
    # the same shape (`pinned`, `hot_moment`, `search_query`, ...).
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast(_topic_broadcast_payload())
    except Exception as exc:
        logger.warning("topic/set broadcast failed: %s", exc)

    logger.info(
        "topic/set: pinned ticket_id=%s title=%r indefinite",
        ticket_id, title[:80],
    )
    return web.json_response({
        "ok": True,
        "ticket_id": ticket_id,
        "title": title,
        "manual": True,
    })


_VALID_PIN_KINDS = {"ticket", "note", "action_item"}


def _topic_broadcast_payload() -> dict:
    """Shape the `topic` WS broadcast so all UIs see the same fields.

    Matches the legacy AUTO-leg broadcast in `topic_worker._pick_from_*`
    on `search_query` and `hot_moment` so clients don't reset those fields
    when a basket-driven event arrives.
    """
    topic = state.current_topic or {}
    return {
        "type": "topic",
        "topic": topic.get("topic", ""),
        "ticket_ids": list(topic.get("ticket_ids", [])),
        "search_query": topic.get("search_query", ""),
        "last_user_statement": topic.get("last_user_statement", ""),
        "cards": [
            slim_card_for_broadcast(c) for c in (state.current_topic_cards or [])
        ],
        "pinned": [
            {"kind": p.kind, "id": p.id, "title": p.title, "board_id": p.board_id}
            for p in state.pinned_topics
        ],
        "hot_moment": {
            "active": state.is_hot_moment(),
            "until_wallclock": state.hot_moment_until_wallclock(),
        },
    }


async def topic_pin_handler(request: web.Request) -> web.Response:
    """POST /topic/pin - add an item to the basket.

    Body: `{"kind": "ticket"|"note"|"action_item", "id": str, "title": str,
    "board_id"?: str}`. Dedupe is (kind, id). Daemon state only - no disk.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid json"}, status=400)

    kind = str(body.get("kind") or "").strip()
    item_id = str(body.get("id") or "").strip()
    title = str(body.get("title") or "").strip()
    board_id = str(body.get("board_id") or "").strip()

    if kind not in _VALID_PIN_KINDS:
        return web.json_response(
            {"error": f"kind must be one of {sorted(_VALID_PIN_KINDS)}"}, status=400,
        )
    if not item_id or not title:
        return web.json_response({"error": "id and title required"}, status=400)

    from meeting_helper.state import PinnedItem
    state.pin_topic(PinnedItem(kind=kind, id=item_id, title=title, board_id=board_id))

    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast(_topic_broadcast_payload())
    except Exception as exc:
        logger.warning("topic/pin broadcast failed: %s", exc)

    return web.json_response({"ok": True, "pinned_count": len(state.pinned_topics)})


async def topic_unpin_handler(request: web.Request) -> web.Response:
    """POST /topic/unpin - remove (kind, id) from the basket."""
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid json"}, status=400)

    kind = str(body.get("kind") or "").strip()
    item_id = str(body.get("id") or "").strip()
    if kind not in _VALID_PIN_KINDS or not item_id:
        return web.json_response({"error": "kind and id required"}, status=400)

    removed = state.unpin_topic(kind, item_id)

    if removed:
        try:
            from meeting_helper.server.websocket import broadcast
            await broadcast(_topic_broadcast_payload())
        except Exception as exc:
            logger.warning("topic/unpin broadcast failed: %s", exc)

    return web.json_response({
        "ok": True, "removed": removed, "pinned_count": len(state.pinned_topics),
    })


async def topic_clear_handler(_request: web.Request) -> web.Response:
    """POST /topic/clear - empty the basket. Worker returns to AUTO mode."""
    state.clear_pins()
    state.current_topic = {}
    state.current_topic_cards = []
    state.last_cards = []
    state.last_user_query_topic = {"topic": "", "ticket_ids": []}
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast(_topic_broadcast_payload())
    except Exception as exc:
        logger.warning("topic/clear broadcast failed: %s", exc)
    return web.json_response({"ok": True, "pinned_count": 0})


async def topic_auto_handler(_request: web.Request) -> web.Response:
    """POST /topic/auto - deprecated alias of /topic/clear (kept one release)."""
    return await topic_clear_handler(_request)


async def notes_list_handler(request: web.Request) -> web.Response:
    """GET /notes/list - notes payload for the /notes web page.

    Reads `request.app["disk"]` (CLAUDE.md rule: handlers never call
    `get_config()` directly) and delegates to the shared `list_notes_for`
    helper so chat-tool callers and the HTTP path produce identical
    payloads. Read-only - no state mutation.
    """
    from meeting_helper.chat.tools.notes import list_notes_for

    disk = request.app.get("disk")
    if disk is None:
        # Test path with no shim wired - the shared helper still works
        # against the file-backed singleton as a last resort.
        from meeting_helper.config import get_config
        disk = get_config()
    return web.json_response(list_notes_for(disk))


async def hot_moment_cancel_handler(request: web.Request) -> web.Response:
    """POST /hot_moment/cancel — disarm the current hot moment immediately.

    Sets hot_moment_until to 0 so state.is_hot_moment() returns False
    on the next tick. Idempotent.
    """
    state.hot_moment_until = 0.0
    from meeting_helper.server.websocket import broadcast
    try:
        await broadcast({"type": "hot_moment", "active": False, "until_wallclock": 0})
    except Exception as exc:
        logger.warning("hot_moment/cancel broadcast failed: %s", exc)
    logger.info("hot_moment/cancel: disarmed")
    return web.json_response({"ok": True})


async def query_handler(request: web.Request) -> web.Response:
    """POST /query — send a manual text query to Claude."""
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    text = body.get("text", "").strip()
    if not text:
        return web.Response(status=400, text='{"error": "text required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import handle_manual_query
    config = request.app["config"]

    try:
        await handle_manual_query(state, config, text)
        return web.Response(
            text=json.dumps({"ok": True}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def trigger_query_handler(request: web.Request) -> web.Response:
    """POST /query/trigger — context-only query, equivalent to the 2xCmd hotkey.

    Calls handle_query(state, config) without any user-typed text — the AI
    responds based on current transcript + topic context.
    """
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    from meeting_helper.ai.client import handle_query
    config = request.app["config"]
    try:
        await handle_query(state, config)
        return web.Response(
            text=json.dumps({"ok": True}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def transcribe_handler(request: web.Request) -> web.Response:
    """POST /transcribe — transcribe an MP3 file with Whisper."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    mp3_path = body.get("mp3_path", "")
    if not mp3_path:
        return web.Response(status=400, text='{"error": "mp3_path required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import transcribe_audio_file
    config = request.app["config"]

    try:
        transcript = await asyncio.to_thread(transcribe_audio_file, mp3_path, config)
        return web.Response(
            text=json.dumps({"ok": True, "transcript": transcript}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def summarize_handler(request: web.Request) -> web.Response:
    """POST /summarize — summarize a transcript with Claude."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    transcript_path = body.get("transcript_path", "")
    if not transcript_path:
        return web.Response(status=400, text='{"error": "transcript_path required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import summarize_transcript
    config = request.app["config"]

    try:
        summary = await summarize_transcript(transcript_path, config)
        return web.Response(
            text=json.dumps({"ok": True, "summary": summary}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def extract_task_handler(request: web.Request) -> web.Response:
    """POST /extract-task — extract new action items from the in-memory transcript."""
    from meeting_helper.ai.client import extract_tasks
    from meeting_helper.server.websocket import broadcast

    config = request.app["config"]
    try:
        added = await extract_tasks(state, config)
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )

    await broadcast({"type": "tasks_extracted", "added": len(added)})
    await broadcast({"type": "tasks", "tasks": list(state.session_tasks)})

    return web.Response(
        text=json.dumps({"added": len(added), "total": len(state.session_tasks)}),
        content_type="application/json",
    )


async def tasks_get_handler(request: web.Request) -> web.Response:
    """GET /tasks — return the current session's extracted tasks.

    The Next.js static export also lives at this path
    (`web/dist/tasks/index.html`) once the MH-40 Tasks page ships. API
    routes are registered before the static catch-all, so a browser
    navigation to `/tasks` (no trailing slash, hard reload, or pywebview
    URL-restore on relaunch) would otherwise hit this handler and dump raw
    JSON into the webview. Serve the SPA shell for HTML navigations; JS
    `fetch('/tasks')` sends `Accept: */*` and still gets JSON. Same fix
    shape as `library_get_handler` and `action_items_get_handler`.
    """
    _cache_headers = {"Vary": "Accept", "Cache-Control": "no-store"}
    accept = request.headers.get("Accept", "")
    if "text/html" in accept and "application/json" not in accept:
        from meeting_helper.server.app import WEB_DIST
        index_path = WEB_DIST / "tasks" / "index.html"
        if index_path.is_file():
            return web.FileResponse(index_path, headers=_cache_headers)
    return web.Response(
        text=json.dumps({"tasks": list(state.session_tasks)}),
        content_type="application/json",
        headers=_cache_headers,
    )


async def brief_handler(request: web.Request) -> web.Response:
    """POST /brief — generate a first-person standup script + source cards from local-todo."""
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    from meeting_helper.ai.prompts import BRIEF_SYSTEM_PROMPT
    import httpx

    config = request.app.get("config")
    # Per-Brief timing so the operator can answer "why is Brief slow?" from
    # the log alone. We log a phase-by-phase breakdown at the end (fetch,
    # llm, parse, total). Individual sub-call timings are emitted by the
    # callee modules (agent_loop, refresh_sprint_tickets, picker).
    import time as _time
    brief_t0 = _time.monotonic()
    logger.info("brief: start")
    _brief_tracker = getattr(state, "tracker", None)
    if _brief_tracker is None:
        logger.warning("brief: tracker not configured — early-exit 503")
        return web.json_response(
            {"error": "tracker not configured"}, status=503,
        )
    if not getattr(config, "anthropic_api_key", ""):
        logger.warning("brief: anthropic key missing — early-exit 503")
        return web.json_response(
            {"error": "Anthropic API key not configured"}, status=503,
        )

    # Use the agent-driven cache (pre-populated by refresh_sprint_tickets).
    # If empty, trigger a blocking refresh now.
    fetch_t0 = _time.monotonic()
    try:
        logger.info("brief: fetching active items via agent cache…")
        from meeting_helper.ai.client import refresh_sprint_tickets
        await refresh_sprint_tickets(state, force=False)
        active_tasks = list(state.sprint_tickets or [])
        fetch_ms = int((_time.monotonic() - fetch_t0) * 1000)
        logger.info("brief: got %d active items from agent cache (fetch=%dms)",
                    len(active_tasks), fetch_ms)
    except Exception as exc:
        logger.warning("brief: agent cache refresh failed after %dms: %s",
                       int((_time.monotonic() - fetch_t0) * 1000), exc)
        return web.json_response({"error": f"tracker error: {exc}"}, status=502)

    if not active_tasks:
        logger.warning("brief: no active items — skipping LLM call")
        # If the failure was a Copilot tracker that needs re-auth, point
        # the user at the actual fix instead of a vague "no active items".
        needs_reauth_id = getattr(state, "tracker_needs_reauth", None)
        if needs_reauth_id:
            tracker_label = next(
                (t.get("label") for t in (config.trackers or []) if t.get("id") == needs_reauth_id),
                "the Copilot tracker",
            )
            return web.json_response(
                {
                    "error": (
                        f"Couldn't reach {tracker_label} — OAuth needs "
                        f"re-authentication. Open Settings → Task tracker "
                        f"and click Connect on {tracker_label}."
                    ),
                    "needs_reauth": True,
                    "tracker_id": needs_reauth_id,
                },
                status=502,
            )
        return web.json_response(
            {"error": "No active items found"},
            status=502,
        )

    user_msg = (
        "## My active topics (top-level tasks in active sprints, with their "
        "subtasks, recent comments, and recent history nested inline):\n"
        + json.dumps(active_tasks, indent=2)
        + "\n\nGenerate the standup script as JSON."
    )

    # Explicit timeout — without this, the Anthropic call could hang
    # indefinitely on a slow/wedged network (the GUI eventually gives up
    # at 30s but the daemon would still be holding the request open).
    client = AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False, timeout=httpx.Timeout(30.0)),
    )
    state.record_ai_call("brief")
    # Use the workspace's configured Claude model — never hardcode. The user
    # picks haiku/sonnet/opus in Settings → AI Providers; that choice flows
    # here so Brief uses the same model as the rest of the workspace.
    # AppConfig.claude_model is a dataclass field with a default — always set.
    brief_model = config.claude_model
    llm_t0 = _time.monotonic()
    try:
        logger.info("brief: calling Claude (%s) with %d tasks…", brief_model, len(active_tasks))
        msg = await asyncio.wait_for(
            client.messages.create(
                model=brief_model,
                max_tokens=getattr(config, "max_tokens", 800),
                system=BRIEF_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            ),
            timeout=30.0,
        )
        llm_ms = int((_time.monotonic() - llm_t0) * 1000)
        logger.info("brief: Claude responded (llm=%dms)", llm_ms)
    except asyncio.TimeoutError:
        logger.warning("brief: Claude call timed out after 30s (elapsed=%dms)",
                       int((_time.monotonic() - llm_t0) * 1000))
        return web.json_response({"error": "Claude API timed out (30s)"}, status=504)
    except Exception as exc:
        logger.warning("brief: Claude call failed after %dms: %s",
                       int((_time.monotonic() - llm_t0) * 1000), exc)
        return web.json_response({"error": f"Claude call failed: {exc}"}, status=502)

    parse_t0 = _time.monotonic()
    raw = msg.content[0].text.strip()
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        logger.warning("brief: AI returned non-JSON (%d chars)", len(raw))
        return web.json_response({"error": "AI returned non-JSON", "raw": raw[:500]}, status=502)
    try:
        parsed = json.loads(match.group())
    except json.JSONDecodeError as exc:
        logger.warning("brief: JSON parse failed: %s", exc)
        return web.json_response({"error": f"JSON parse: {exc}", "raw": raw[:500]}, status=502)

    script = parsed.get("script", "").strip()
    card_ids = parsed.get("card_ids", []) or []
    parse_ms = int((_time.monotonic() - parse_t0) * 1000)
    logger.info(
        "brief: parsed (script=%d chars, %d card_ids; parse=%dms)",
        len(script), len(card_ids), parse_ms,
    )
    if not script and not card_ids:
        logger.warning("brief: AI returned empty script and no card_ids — likely no active tasks")
        return web.json_response(
            {"error": "Brief came back empty — no active tasks to summarize"},
            status=502,
        )

    # Build id → task dict lookup from agent-fetched items (already enriched).
    id_to_task: dict[str, dict] = {}
    for t in active_tasks:
        tid = str(t.get("id", ""))
        if tid:
            id_to_task[tid] = t

    cards: list[dict] = []
    for cid in card_ids:
        cid = str(cid)
        record = id_to_task.get(cid)
        if record is None:
            logger.warning("brief: card_id %s not in agent-fetched items; skipping", cid)
            continue
        record = dict(record)
        record.setdefault("kind", "task")
        cards.append(record)
    logger.info("brief: backfill done (%d/%d cards resolved)", len(cards), len(card_ids))

    # Slim cards before broadcasting (full records can blow the WS frame).
    # Full `cards` list is still passed to _seed_warm_cache_from_brief below
    # so AI queries keep their grounding context.
    slim_cards = [slim_card_for_broadcast(c) for c in cards]
    payload = {"script": script, "cards": slim_cards}

    # Seed warm cache so subsequent /query calls have grounded context
    # even before the user speaks aloud.
    try:
        seeded_topic = _seed_warm_cache_from_brief(script, cards)
        try:
            from meeting_helper.server.websocket import broadcast
            # NOTE: don't include `cards` here. The full card payload (with
            # comment threads etc.) can be large enough to disconnect WS
            # clients on the topic broadcast, *before* the brief broadcast
            # below ever lands. The brief broadcast carries cards for the
            # GUI, and the overlay only used `cards` here to compute a
            # count — pass the count instead.
            await broadcast({
                "type": "topic",
                "topic": seeded_topic.get("topic", ""),
                "ticket_ids": seeded_topic.get("ticket_ids", []),
                "last_user_statement": seeded_topic.get("last_user_statement", ""),
                "warm_cards_count": len(cards),
            })
            logger.info("brief: topic broadcast sent")
        except Exception as exc:
            logger.warning("brief: topic broadcast failed: %s", exc)
    except Exception as exc:
        logger.warning("brief: warm-cache seeding failed: %s", exc)

    try:
        from meeting_helper.server.websocket import broadcast
        n_clients = len(state.ws_clients)
        await broadcast({"type": "brief", **payload})
        logger.info("brief: brief broadcast sent to %d ws clients", n_clients)
    except Exception as exc:
        logger.warning("brief: brief broadcast failed: %s", exc)

    # Final TOTAL summary so the operator sees the full attribution in one
    # line: fetch (agent_fetch) vs llm (Brief Claude call) vs parse vs
    # everything-else. Sub-components emit their own TOTAL lines too.
    total_ms = int((_time.monotonic() - brief_t0) * 1000)
    other_ms = total_ms - fetch_ms - llm_ms - parse_ms
    logger.info(
        "brief: done — TOTAL %dms (fetch=%dms llm=%dms parse=%dms other=%dms)",
        total_ms, fetch_ms, llm_ms, parse_ms, other_ms,
    )
    return web.json_response(payload)


async def debug_say_handler(request: web.Request) -> web.Response:
    """POST /debug/say — inject a sentence into self_buffer or other_buffer
    for testing without a mic. Body: {"text": "...", "role": "self"|"other"}.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    text = (body.get("text") or "").strip()
    if not text:
        return web.json_response({"error": "text required"}, status=400)
    role = (body.get("role") or "self").strip().lower()
    if role not in ("self", "other"):
        return web.json_response({"error": "role must be 'self' or 'other'"}, status=400)

    buf = state.self_buffer if role == "self" else state.other_buffer
    if buf is None:
        return web.json_response(
            {"error": f"{role}_buffer not initialized — start a session first"},
            status=409,
        )

    buf.append_final(text)
    logger.info("debug/say: injected '%s' into %s_buffer", text[:80], role)
    return web.json_response({"ok": True, "role": role, "text": text})


async def conversations_handler(request: web.Request) -> web.Response:
    """GET /conversations?repo=<path> — list past Claude Code conversations for a repo."""
    repo = request.query.get("repo", "").strip()
    if not repo:
        return web.Response(
            status=400,
            text=json.dumps({"error": "repo query param required"}),
            content_type="application/json",
        )
    from meeting_helper.claude_history import list_conversations
    convs = await asyncio.to_thread(list_conversations, repo)
    return web.Response(
        text=json.dumps({"conversations": convs}),
        content_type="application/json",
    )


async def conversation_attach_handler(request: web.Request) -> web.Response:
    """POST /conversation/attach — attach a past Claude Code conversation as primary context.

    Body: {"repo": "<absolute path>", "session_id": "<uuid>"}
    """
    try:
        body = await request.json()
    except Exception:
        return web.Response(
            status=400,
            text='{"error": "invalid JSON"}',
            content_type="application/json",
        )

    repo = (body.get("repo") or "").strip()
    session_id = (body.get("session_id") or "").strip()
    if not repo or not session_id:
        return web.Response(
            status=400,
            text='{"error": "repo and session_id required"}',
            content_type="application/json",
        )

    from meeting_helper.claude_history import reconstruct_conversation
    from meeting_helper.ai.prompts import build_system_prompt, build_conversation_context_block
    from pathlib import Path

    try:
        conv = await asyncio.to_thread(reconstruct_conversation, repo, session_id)
    except FileNotFoundError as exc:
        return web.Response(
            status=404,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )

    repo_name = Path(repo).expanduser().resolve().name
    context_block = build_conversation_context_block(
        title=conv["title"],
        repo_name=repo_name,
        body=conv["body"],
        truncated=conv["truncated"],
    )
    state.system_prompt = build_system_prompt(context_block)
    # Clear any prior Q&A turns so answers grounded in the OLD context don't
    # leak into answers for the NEW conversation. Safe whether this is the
    # first attach or a switch from another conversation.
    state.conversation_history = []
    state.attached_conversation = {
        "session_id": conv["session_id"],
        "title": conv["title"],
        "repo": conv["repo"],
        "attached_at": time.time(),
        "chars": conv["chars"],
        "truncated": conv["truncated"],
        "turn_count": conv["turn_count"],
    }

    from meeting_helper.server.websocket import broadcast
    await broadcast({
        "type": "conversation_attached",
        "session_id": conv["session_id"],
        "title": conv["title"],
        "repo": conv["repo"],
        "chars": conv["chars"],
        "truncated": conv["truncated"],
        "turn_count": conv["turn_count"],
    })

    return web.Response(
        text=json.dumps({
            "ok": True,
            "title": conv["title"],
            "chars": conv["chars"],
            "truncated": conv["truncated"],
            "turn_count": conv["turn_count"],
        }),
        content_type="application/json",
    )


async def conversation_detach_handler(request: web.Request) -> web.Response:
    """POST /conversation/detach — clear an attached Claude Code conversation.

    Drops to a bare system prompt — the repos/knowledge auto-context layer
    has been removed (see Phase 2 of "Learn From Conversations").
    """
    if state.attached_conversation is None:
        return web.Response(
            text=json.dumps({"ok": True, "was_attached": False}),
            content_type="application/json",
        )

    state.attached_conversation = None
    # Clear Q&A turns grounded in the conversation we're detaching from.
    state.conversation_history = []

    from meeting_helper.ai.prompts import build_system_prompt
    state.system_prompt = build_system_prompt("")

    from meeting_helper.server.websocket import broadcast
    await broadcast({"type": "conversation_detached"})

    return web.Response(
        text=json.dumps({"ok": True, "was_attached": True}),
        content_type="application/json",
    )


async def session_start_handler(request: web.Request) -> web.Response:
    """POST /session/start — manually start a full recording session."""
    if state.session_active:
        return web.Response(
            text=json.dumps({"ok": True, "already_active": True}),
            content_type="application/json",
        )
    session = state.meeting_session
    if session is None:
        return web.Response(status=400, text='{"error": "no session manager"}',
                            content_type="application/json")
    session.manual_start()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def session_stop_handler(request: web.Request) -> web.Response:
    """POST /session/stop — manually stop the current recording session."""
    if not state.session_active:
        return web.Response(
            text=json.dumps({"ok": True, "was_active": False}),
            content_type="application/json",
        )
    session = state.meeting_session
    if session is None:
        return web.Response(status=400, text='{"error": "no session manager"}',
                            content_type="application/json")
    session.manual_stop()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def proactive_handler(request: web.Request) -> web.Response:
    """POST /proactive — enable or disable proactive answers for current session."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}', content_type="application/json")

    enabled = bool(body.get("enabled", True))
    monitor = state.proactive_monitor
    if monitor is not None:
        monitor.set_enabled(enabled)

    return web.Response(
        text=json.dumps({"ok": True, "enabled": enabled, "monitor_active": monitor is not None}),
        content_type="application/json",
    )


async def proactive_status_handler(request: web.Request) -> web.Response:
    """GET /proactive — return current proactive enabled state."""
    monitor = state.proactive_monitor
    enabled = monitor.is_enabled() if monitor is not None else False
    return web.Response(
        text=json.dumps({"enabled": enabled, "monitor_active": monitor is not None}),
        content_type="application/json",
    )


def _resolve_ai_model(config) -> str:
    """Return the display model string for the current provider config."""
    if config.preferred_provider == "local":
        return config.local_model
    if config.preferred_provider == "gemini":
        return config.gemini_model
    return config.claude_model


async def provider_get_handler(request: web.Request) -> web.Response:
    """GET /provider — return current provider/model/transcriber state.

    Also reports whether the workspace has the prerequisites the GUI needs to
    decide which controls to surface (`local_todo_configured`,
    `provider_configured`). Without these the GUI would have to read the
    daemon's config another way.
    """
    config = request.app["config"]
    return web.Response(
        text=json.dumps({
            "provider": config.preferred_provider or "claude",
            "claude_model": config.claude_model_alias,
            "gemini_model": config.gemini_model_alias,
            "local_model": config.local_model,
            # Return the user's actual stored choice, not a resolved
            # fallback. Empty string means "auto" (let `create_transcriber`
            # pick based on which keys are set). The toolbar chip maps
            # "" → an "auto" sentinel in its own dropdown. Substituting
            # "whisper" here used to mislead the chip into showing
            # "Whisper" even when the user had set Off, and clicking the
            # chip would silently overwrite Off with the picked value.
            "transcriber": config.preferred_transcriber or "",
            # Runtime transcriber display name — e.g. "Whisper (remote: …)" /
            # "Whisper (local)" / "Deepgram" — so the toolbar chip shows what's
            # actually running, not just the configured mode. Empty until a
            # session has started.
            "transcriber_name": state.transcriber_name,
            "ai_model": state.ai_model,
            "local_todo_configured": config.local_todo_configured,
            "provider_configured": config.provider_configured,
        }),
        content_type="application/json",
    )


async def provider_post_handler(request: web.Request) -> web.Response:
    """POST /provider — switch AI provider, model, or transcriber at runtime."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    config = request.app["config"]
    changed = False

    # AI provider switch
    if "provider" in body:
        config.preferred_provider = body["provider"]
        changed = True
    if "claude_model" in body:
        from meeting_helper.config import CLAUDE_MODELS
        alias = body["claude_model"]
        config.claude_model_alias = alias
        config.claude_model = CLAUDE_MODELS.get(alias, alias)
        changed = True
    if "gemini_model" in body:
        from meeting_helper.config import GEMINI_MODELS
        alias = body["gemini_model"]
        config.gemini_model_alias = alias
        config.gemini_model = GEMINI_MODELS.get(alias, alias)
        changed = True
    if "local_model" in body:
        config.local_model = body["local_model"]
        changed = True

    # Transcriber switch
    transcriber_changed = False
    if "transcriber" in body:
        config.preferred_transcriber = body["transcriber"]
        transcriber_changed = True
        changed = True

    if transcriber_changed and state.session_active:
        session = state.meeting_session
        if session is not None:
            t_name = await asyncio.to_thread(
                session.swap_transcriber, body["transcriber"], config
            )
            state.transcriber_name = t_name

    # Update displayed AI provider + model
    if changed:
        state.ai_provider = config.preferred_provider or "claude"
        state.ai_model = _resolve_ai_model(config)

        # Broadcast info update to overlay/dashboard
        from meeting_helper.server.websocket import broadcast_info
        await broadcast_info()

        # Persist to disk config
        from meeting_helper.config import get_config
        disk = get_config()
        disk.preferred_provider = config.preferred_provider
        disk.claude_model = config.claude_model_alias
        disk.gemini_model = config.gemini_model_alias
        disk.local_model = config.local_model
        disk.preferred_transcriber = config.preferred_transcriber
        disk.save()

    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


def _list_library_items(cfg=None) -> dict:
    """Build the GET /library payload. Shared by the HTTP handler and chat tools.

    When ``cfg`` is None we resolve recordings_dir from the active workspace's
    disk config — this lets the chat tool call us without a live aiohttp request.
    """
    from meeting_helper.library_retrieval import list_artifacts
    from meeting_helper.config import get_config

    disk = get_config()
    rec_dir = Path(cfg.recordings_dir) if cfg is not None else disk.recordings_dir
    items = list_artifacts(recordings_dir=rec_dir, config=disk)
    return {"items": [asdict(it) for it in items]}


async def library_get_handler(request: web.Request) -> web.Response:
    """GET /library — list past meetings + notes for the new web Library screen.

    Wraps `library_retrieval.list_artifacts` (which the Flet Library tab
    already used). The serialized shape mirrors the LibraryItem dataclass
    field-for-field so the UI can treat the daemon list as the source of
    truth without per-row enrichment calls.

    The Next.js static export also lives at this path (`web/dist/library/
    index.html`). API routes are registered before the static catch-all,
    so a browser navigation to `/library` would otherwise hit this handler
    and dump raw JSON into the webview — happens when pywebview restores
    the last URL on relaunch. Serve the SPA shell for HTML navigations;
    JS `fetch('/library')` sends `Accept: */*` and still gets JSON.
    """
    accept = request.headers.get("Accept", "")
    if "text/html" in accept and "application/json" not in accept:
        from meeting_helper.server.app import WEB_DIST
        index_path = WEB_DIST / "library" / "index.html"
        if index_path.is_file():
            return web.FileResponse(index_path)
    return web.json_response(_list_library_items(request.app["config"]))


async def library_reveal_handler(request: web.Request) -> web.Response:
    """POST /library/reveal — open a library file in Finder via `open -R`.

    Body: `{ "filename": "<basename>" }`. The daemon resolves the basename
    against `recordings_dir`; absolute paths and any `..`/separator segments
    are rejected up front so the client API itself can't smuggle paths
    outside the recordings directory. The post-resolve `relative_to` check
    is belt-and-braces in case `expanduser` ever surfaces a surprise.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    filename = str(body.get("filename", "")).strip()
    if not filename:
        return web.json_response({"error": "filename required"}, status=400)

    # Reject absolute paths and traversal segments. The basename of a real
    # library item never contains a slash.
    if "/" in filename or "\\" in filename or ".." in filename:
        return web.json_response(
            {"error": "filename must be a basename within recordings_dir"},
            status=400,
        )

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    target = (rec_dir / filename).resolve()
    try:
        target.relative_to(rec_dir)
    except ValueError:
        return web.json_response(
            {"error": "filename resolved outside recordings_dir"},
            status=400,
        )

    if not target.exists():
        return web.json_response({"error": "not found"}, status=404)

    subprocess.run(["open", "-R", str(target)], check=False)
    return web.json_response({"ok": True})


# ---------------------------------------------------------------------------
# Library full feature set — item details, transcribe/summarize, rename,
# delete, favorite, kb, note CRUD, audio stream. Plan 5 — replaces the
# in-process file mutations the Flet Library screen used to do.
# ---------------------------------------------------------------------------

# Read cap for inline file payloads on GET /library/item. 512 KB keeps
# huge transcripts (multi-hour meetings) from blowing the WS-adjacent
# HTTP response budget; the UI shows a "...truncated" marker and the
# user can still reveal the file in Finder.
_LIBRARY_ITEM_READ_LIMIT = 512 * 1024


def _safe_filename(filename: str) -> str:
    """Reject any filename that isn't a bare basename within recordings_dir.

    Mirrors the inline guard in `library_reveal_handler` but raises so the
    handlers below can share one path-traversal check. The post-resolve
    `relative_to` check still happens at each call site after joining
    against `recordings_dir`.
    """
    if not filename or "/" in filename or "\\" in filename or ".." in filename:
        raise ValueError("invalid filename")
    return filename


def _resolve_under_recordings(filename: str, cfg) -> Path:
    """Resolve `filename` against the active recordings_dir or raise ValueError."""
    _safe_filename(filename)
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    target = (rec_dir / filename).resolve()
    try:
        target.relative_to(rec_dir)
    except ValueError as exc:
        raise ValueError("filename resolved outside recordings_dir") from exc
    return target


def _speaker_paths_from_id(item_id: str, cfg) -> tuple[Path, Path, Path]:
    """Resolve (mp3, live_txt, speakers_sidecar) paths for ``item_id``.

    Raises ``ValueError`` if ``item_id`` escapes the recordings directory
    (path traversal guard). Use this helper for every speaker-related
    HTTP handler so the security invariant is enforced in one place.
    """
    mp3 = _resolve_under_recordings(f"{item_id}.mp3", cfg)
    live = _resolve_under_recordings(f"{item_id}.live.txt", cfg)
    return mp3, live, _speakers.speakers_path_for(mp3)


def _read_capped(path: Path) -> str | None:
    """Read a text file up to `_LIBRARY_ITEM_READ_LIMIT`. Returns None if missing."""
    if not path.is_file():
        return None
    try:
        raw = path.read_text(errors="ignore")
    except OSError:
        return None
    if len(raw) > _LIBRARY_ITEM_READ_LIMIT:
        return raw[:_LIBRARY_ITEM_READ_LIMIT] + "\n...truncated"
    return raw


def _timestamp_prefix(stem: str) -> str:
    """Return '<date>_<HHMMSS>_' if stem starts with that pattern, else ''.

    Mirrors `_timestamp_prefix` from the old Flet library so meeting ids
    keep their leading timestamp when the user types a new label.
    """
    parts = stem.split("_", 2)
    if len(parts) >= 2 and len(parts[0]) == 10 and "-" in parts[0]:
        return f"{parts[0]}_{parts[1]}_"
    return ""


def _slug_for_note(title: str, recordings_dir: Path) -> str:
    """Sanitize `title` to a kebab-case slug. Append -2/-3... on collision.

    Matches the old Flet `_slug_for_note`: non-alphanumeric runs collapse
    to a single hyphen, leading/trailing hyphens are stripped, empty
    fallback is 'note'.
    """
    base = re.sub(r"[^a-zA-Z0-9]+", "-", title.strip().lower()).strip("-") or "note"
    candidate = base
    n = 2
    while (recordings_dir / f"{candidate}.note.md").exists():
        candidate = f"{base}-{n}"
        n += 1
    return candidate


def _fetch_library_bundle(item_id: str, kind: str = "meeting", cfg=None) -> dict | None:
    """Return the full /library/item payload, or None when not found.

    Shared by the HTTP handler and the chat ``library.get_meeting`` tool. The
    chat tool only requests meetings, so ``kind`` defaults to "meeting" for
    its no-kwargs call signature.
    """
    from meeting_helper.library_retrieval import list_artifacts
    from meeting_helper.config import get_config

    if kind not in ("meeting", "note"):
        return None
    disk = get_config()
    rec_dir = (
        Path(cfg.recordings_dir).expanduser().resolve()
        if cfg is not None
        else disk.recordings_dir.expanduser().resolve()
    )
    items = list_artifacts(recordings_dir=rec_dir)
    match = next((it for it in items if it.id == item_id and it.kind == kind), None)
    if match is None:
        return None

    payload: dict = {
        "id": match.id,
        "kind": match.kind,
        "title": match.title,
        "date": match.date,
        "summary_filename": match.summary_filename,
        "note_filename": match.note_filename,
        "has_mp3": match.has_mp3,
        "has_live": match.has_live,
        "has_transcript": match.has_transcript,
        "has_summary": match.has_summary,
        "summary_text": None,
        "transcript_text": None,
        "live_text": None,
        "note_body": None,
    }

    if kind == "meeting":
        mp3_name = f"{match.id}.mp3"
        summary_name = f"{match.id}.summary.txt"
        payload["favorited"] = disk.is_favorite(mp3_name)
        payload["in_kb"] = disk.is_kb(summary_name)
        payload["summary_text"] = _read_capped(rec_dir / summary_name)
        payload["transcript_text"] = _read_capped(rec_dir / f"{match.id}.transcript.txt")
        payload["live_text"] = _read_capped(rec_dir / f"{match.id}.live.txt")
        # Speaker-map substitution + label discovery. We never rewrite
        # the source files; substitution happens here at read time so
        # renames are reversible and re-applyable.
        mp3_path = rec_dir / mp3_name
        spk = _speakers.read_speaker_map(_speakers.speakers_path_for(mp3_path))
        labels: list[str] = []
        if payload["live_text"]:
            labels = _speakers.extract_speaker_labels(payload["live_text"])
        if spk.names:
            if payload["summary_text"]:
                payload["summary_text"] = _speakers.apply_speaker_map(
                    payload["summary_text"], spk.names,
                )
            if payload["transcript_text"]:
                payload["transcript_text"] = _speakers.apply_speaker_map(
                    payload["transcript_text"], spk.names,
                )
            if payload["live_text"]:
                payload["live_text"] = _speakers.apply_speaker_map(
                    payload["live_text"], spk.names,
                )
        payload["speaker_map"] = {
            "names": spk.names,
            "evidence": spk.evidence,
            "source": spk.source,
        }
        payload["speaker_labels"] = labels
    else:
        note_name = match.note_filename
        payload["favorited"] = disk.is_favorite(note_name)
        payload["in_kb"] = disk.is_kb(note_name)
        payload["note_body"] = _read_capped(rec_dir / note_name)
        payload["speaker_map"] = {"names": {}, "evidence": {}, "source": {}}
        payload["speaker_labels"] = []

    return payload


async def library_item_handler(request: web.Request) -> web.Response:
    """GET /library/item?id=<id>&kind=<meeting|note> — full row + file bodies.

    Reads file contents up to `_LIBRARY_ITEM_READ_LIMIT` so the UI can
    render the detail pane without a second roundtrip per file. Larger
    files are truncated with a marker; the user can still reveal/download.
    """
    item_id = (request.query.get("id") or "").strip()
    kind = (request.query.get("kind") or "").strip().lower()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    if kind not in ("meeting", "note"):
        return web.json_response({"error": "kind must be meeting or note"}, status=400)

    payload = _fetch_library_bundle(item_id, kind, request.app["config"])
    if payload is None:
        return web.json_response({"error": "not found"}, status=404)
    return web.json_response(payload)


async def library_transcribe_handler(request: web.Request) -> web.Response:
    """POST /library/transcribe — run Whisper on a stored meeting mp3.

    Body: `{"id": "<meeting_id>"}`. Runs `transcribe_audio_file` in a
    thread (it's CPU-bound + sync). Returns the relative transcript filename
    so the UI can refresh the row without re-listing the whole library.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)

    cfg = request.app["config"]
    try:
        mp3_path = _resolve_under_recordings(f"{item_id}.mp3", cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if not mp3_path.is_file():
        return web.json_response({"error": "mp3 not found"}, status=404)

    from meeting_helper.ai.client import transcribe_audio_file
    try:
        await asyncio.to_thread(transcribe_audio_file, str(mp3_path), cfg)
    except Exception as exc:
        logger.warning("library/transcribe failed: %s", exc)
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({"ok": True, "transcript_path": f"{item_id}.transcript.txt"})


async def library_summarize_handler(request: web.Request) -> web.Response:
    """POST /library/summarize — Claude-summarize a meeting's transcript.

    Body: `{"id": "<meeting_id>"}`. Prefers `<id>.transcript.txt`; falls
    back to `<id>.live.txt` so meetings whose transcript never ran can
    still summarize from the live captions.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)

    cfg = request.app["config"]
    try:
        transcript_path = _resolve_under_recordings(f"{item_id}.transcript.txt", cfg)
        live_path = _resolve_under_recordings(f"{item_id}.live.txt", cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)

    if transcript_path.is_file():
        source = transcript_path
    elif live_path.is_file():
        source = live_path
    else:
        return web.json_response({"error": "no transcript or live text"}, status=404)

    from meeting_helper.ai.client import summarize_transcript
    try:
        await summarize_transcript(str(source), cfg)
    except Exception as exc:
        logger.warning("library/summarize failed: %s", exc)
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({"ok": True, "summary_path": f"{item_id}.summary.txt"})


async def library_rename_handler(request: web.Request) -> web.Response:
    """POST /library/rename — rename a meeting (all sibling files) or note.

    Body: `{"id": "...", "kind": "meeting|note", "new_name": "..."}`. For
    meetings, the leading `<date>_<HHMMSS>_` timestamp prefix is preserved
    and `new_name` becomes the trailing label (spaces → underscores). For
    notes, the title is slugified to kebab-case and appended `.note.md`.
    Workspace KB + favorite entries are migrated under the new filename.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    kind = str(body.get("kind") or "").strip().lower()
    new_name = str(body.get("new_name") or "").strip()
    if not item_id or kind not in ("meeting", "note") or not new_name:
        return web.json_response(
            {"error": "id, kind, and new_name required"}, status=400,
        )

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    from meeting_helper.config import get_config
    disk = get_config()

    if kind == "meeting":
        try:
            _safe_filename(f"{item_id}.mp3")
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)
        prefix = _timestamp_prefix(item_id)
        new_label = new_name.replace(" ", "_")
        new_stem = f"{prefix}{new_label}" if prefix else new_label
        # Belt-and-braces: the synthesized stem could include path
        # separators if a caller smuggled them through `new_name`. Reject.
        try:
            _safe_filename(f"{new_stem}.mp3")
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)

        old_mp3 = rec_dir / f"{item_id}.mp3"
        new_mp3 = rec_dir / f"{new_stem}.mp3"
        if new_mp3.exists() and new_mp3 != old_mp3:
            return web.json_response({"error": "name taken"}, status=409)

        for suffix in (
            ".mp3", ".live.txt", ".transcript.txt", ".summary.txt", ".speakers.json",
            ".action_items.json",
        ):
            src = rec_dir / f"{item_id}{suffix}"
            dst = rec_dir / f"{new_stem}{suffix}"
            if src.is_file():
                src.rename(dst)

        # The action_items sidecar embeds meeting_id in every row — rewrite
        # it so chat tools, the workspace-scope list, and the Library tab all
        # resolve the renamed meeting consistently. Skip silently if the
        # sidecar didn't exist or got renamed to a path we just created.
        try:
            from meeting_helper.action_items import store as _ai_store
            existing = _ai_store.load(rec_dir, new_stem)
            if existing:
                for it in existing:
                    it["meeting_id"] = new_stem
                _ai_store.save(rec_dir, new_stem, existing)
                await _broadcast_action_items_snapshot(request.app)
        except Exception:
            logger.warning(
                "rename: failed to rewrite meeting_id in action_items sidecar",
                exc_info=True,
            )

        old_summary = f"{item_id}.summary.txt"
        new_summary = f"{new_stem}.summary.txt"
        if disk.is_kb(old_summary):
            disk.remove_kb(old_summary)
            disk.add_kb(new_summary)
        old_mp3_name = f"{item_id}.mp3"
        new_mp3_name = f"{new_stem}.mp3"
        if disk.is_favorite(old_mp3_name):
            disk.remove_favorite(old_mp3_name)
            disk.add_favorite(new_mp3_name)
        disk.save()
        return web.json_response({"ok": True, "new_id": new_stem})

    # kind == "note"
    try:
        _safe_filename(item_id)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    old_filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
    try:
        old_path = _resolve_under_recordings(old_filename, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if not old_path.is_file():
        return web.json_response({"error": "note not found"}, status=404)

    slug = _slug_for_note(new_name, rec_dir)
    new_filename = f"{slug}.note.md"
    new_path = rec_dir / new_filename
    if new_path.exists() and new_path != old_path:
        return web.json_response({"error": "name taken"}, status=409)

    old_path.rename(new_path)
    if disk.is_kb(old_filename):
        disk.remove_kb(old_filename)
        disk.add_kb(new_filename)
    if disk.is_favorite(old_filename):
        disk.remove_favorite(old_filename)
        disk.add_favorite(new_filename)
    disk.save()
    return web.json_response({
        "ok": True, "new_id": slug, "new_filename": new_filename,
    })


async def library_delete_handler(request: web.Request) -> web.Response:
    """POST /library/delete — remove a meeting's sibling files or a note.

    Body: `{"id": "...", "kind": "meeting|note", "note_filename"?: "..."}`.
    For meetings, removes mp3 + live.txt + transcript.txt + summary.txt if
    present. For notes, deletes `<note_filename>`. KB + favorite entries
    are cleaned up alongside the files.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    kind = str(body.get("kind") or "").strip().lower()
    if not item_id or kind not in ("meeting", "note"):
        return web.json_response({"error": "id and kind required"}, status=400)

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    from meeting_helper.config import get_config
    disk = get_config()

    deleted = 0
    if kind == "meeting":
        try:
            _safe_filename(f"{item_id}.mp3")
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)
        for suffix in (
            ".mp3", ".live.txt", ".transcript.txt", ".summary.txt", ".speakers.json",
            ".action_items.json",
        ):
            p = rec_dir / f"{item_id}{suffix}"
            if p.is_file():
                try:
                    p.unlink()
                    deleted += 1
                except OSError as exc:
                    logger.warning("library/delete: %s failed: %s", p.name, exc)
        summary_name = f"{item_id}.summary.txt"
        mp3_name = f"{item_id}.mp3"
        if disk.is_kb(summary_name):
            disk.remove_kb(summary_name)
        if disk.is_favorite(mp3_name):
            disk.remove_favorite(mp3_name)
        disk.save()
        await _broadcast_action_items_snapshot(request.app)
        return web.json_response({"ok": True, "deleted": deleted})

    # kind == "note"
    note_filename = str(body.get("note_filename") or "").strip()
    if not note_filename:
        # Fall back to deriving from the id when the UI didn't supply one.
        note_filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
    try:
        path = _resolve_under_recordings(note_filename, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if path.is_file():
        try:
            path.unlink()
            deleted = 1
        except OSError as exc:
            logger.warning("library/delete note %s failed: %s", note_filename, exc)
    if disk.is_kb(note_filename):
        disk.remove_kb(note_filename)
    if disk.is_favorite(note_filename):
        disk.remove_favorite(note_filename)
    disk.save()
    return web.json_response({"ok": True, "deleted": deleted})


_LIBRARY_SEARCH_READ_LIMIT = 1024 * 1024


def _read_for_search(path: Path) -> str:
    try:
        if not path.is_file():
            return ""
        with path.open("rb") as fh:
            raw = fh.read(_LIBRARY_SEARCH_READ_LIMIT)
        return raw.decode("utf-8", errors="ignore")
    except OSError:
        return ""


def _scan_items_for_match(items: list[dict], needle: str, cfg) -> list[str]:
    matched: list[str] = []
    for item in items:
        title = str(item.get("title") or "")
        if needle in title.lower():
            matched.append(item["id"])
            continue

        kind = item.get("kind")
        candidate_names: list[str] = []
        if kind == "meeting":
            stem = item["id"]
            candidate_names = [
                f"{stem}.live.txt",
                f"{stem}.transcript.txt",
                f"{stem}.summary.txt",
            ]
        elif kind == "note":
            candidate_names = [
                str(item.get("note_filename") or "").strip() or item["id"],
            ]

        for name in candidate_names:
            try:
                path = _resolve_under_recordings(name, cfg)
            except ValueError:
                continue
            text = _read_for_search(path)
            if text and needle in text.lower():
                matched.append(item["id"])
                break
    return matched


async def library_search_handler(request: web.Request) -> web.Response:
    """POST /library/search — case-insensitive substring search across library items.

    Body: `{"q": "<query>"}`. Empty/whitespace query → 400.
    Returns `{"ids": ["<library-item-id>", ...]}` preserving the canonical
    library listing order (newest first). Matches against meeting title +
    live/transcript/summary text, and note title + note body.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    q = str(body.get("q") or "").strip()
    if not q:
        return web.json_response({"error": "q required"}, status=400)

    cfg = request.app["config"]
    # File I/O on the listing + N adjacent files would block the event loop
    # for a noticeable beat on workspaces with hundreds of meetings; run it
    # off-loop so the daemon stays responsive while a search is in flight.
    matched = await asyncio.to_thread(
        _scan_items_for_match,
        _list_library_items(cfg).get("items", []),
        q.lower(),
        cfg,
    )
    return web.json_response({"ids": matched})


async def library_favorite_handler(request: web.Request) -> web.Response:
    """POST /library/favorite — toggle the favorites flag on a library item.

    Body: `{"id": "...", "kind": "meeting|note", "value": bool,
    "note_filename"?: "..."}`. The favorite key is `<id>.mp3` for meetings
    or `<note_filename>` (or `<id>.note.md` as fallback) for notes.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    kind = str(body.get("kind") or "").strip().lower()
    if not item_id or kind not in ("meeting", "note"):
        return web.json_response({"error": "id and kind required"}, status=400)
    value = bool(body.get("value", True))

    if kind == "meeting":
        key = f"{item_id}.mp3"
    else:
        note_filename = str(body.get("note_filename") or "").strip()
        if not note_filename:
            note_filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
        key = note_filename
    try:
        _safe_filename(key)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)

    from meeting_helper.config import get_config
    disk = get_config()
    if value:
        disk.add_favorite(key)
    else:
        disk.remove_favorite(key)
    disk.save()
    return web.json_response({"ok": True, "favorited": value})


def _fetch_library_kb_entry(kb_id: str, cfg=None) -> dict | None:
    """Load a single KB-flagged artifact by filename.

    ``kb_id`` is the filename stored in ``config.kb_artifacts`` (e.g.
    ``<stem>.summary.txt`` or ``<slug>.note.md``). Returns the artifact's
    metadata + text body, or ``None`` when the file is missing.
    """
    from meeting_helper.library_retrieval import load_artifacts
    from meeting_helper.config import get_config

    disk = get_config()
    rec_dir = (
        Path(cfg.recordings_dir).expanduser().resolve()
        if cfg is not None
        else disk.recordings_dir.expanduser().resolve()
    )
    cards = load_artifacts(recordings_dir=rec_dir, kb_filenames=[kb_id])
    if not cards:
        return None
    card = cards[0]
    return {
        "id": card.id,
        "kind": card.kind,
        "title": card.title,
        "date": card.date,
        "text": card.body,
    }


def _toggle_library_kb(item_id: str, kind: str, value: bool, note_filename: str, cfg) -> tuple[dict, int]:
    """Shared body for POST /library/kb. Returns (payload, http_status)."""
    from meeting_helper.config import get_config

    if not item_id or kind not in ("meeting", "note"):
        return {"error": "id and kind required"}, 400

    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    if kind == "meeting":
        key = f"{item_id}.summary.txt"
        try:
            _safe_filename(key)
        except ValueError as exc:
            return {"error": str(exc)}, 400
        if value and not (rec_dir / key).is_file():
            return {"error": "no summary; run /library/summarize first"}, 409
    else:
        if not note_filename:
            note_filename = item_id if item_id.endswith(".note.md") else f"{item_id}.note.md"
        key = note_filename
        try:
            _safe_filename(key)
        except ValueError as exc:
            return {"error": str(exc)}, 400

    disk = get_config()
    if value:
        disk.add_kb(key)
    else:
        disk.remove_kb(key)
    disk.save()
    return {"ok": True, "in_kb": value}, 200


async def library_kb_handler(request: web.Request) -> web.Response:
    """POST /library/kb — toggle the KB-include flag on a library item.

    Body: `{"id": "...", "kind": "meeting|note", "value": bool,
    "note_filename"?: "..."}`. For meetings the key is `<id>.summary.txt`;
    if `value=true` and the summary file doesn't yet exist we return
    409 so the UI can prompt the user to run `/library/summarize` first
    rather than KB-flagging a file that won't load.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    payload, status = _toggle_library_kb(
        item_id=str(body.get("id") or "").strip(),
        kind=str(body.get("kind") or "").strip().lower(),
        value=bool(body.get("value", True)),
        note_filename=str(body.get("note_filename") or "").strip(),
        cfg=request.app["config"],
    )
    return web.json_response(payload, status=status)


async def library_note_handler(request: web.Request) -> web.Response:
    """POST /library/note — create a new note or update an existing one.

    Two modes (selected by presence of `id` in the body):
    - Create: `{"title": "...", "body": "..."}` → slugs the title via
      `_slug_for_note` (with -2/-3 collision suffix), writes
      `<slug>.note.md` and returns the resulting id/filename.
    - Update: `{"id": "<existing_slug>", "body": "..."}` → overwrites
      `<id>.note.md`. Returns 404 when the file doesn't exist.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    cfg = request.app["config"]
    rec_dir = Path(cfg.recordings_dir).expanduser().resolve()
    rec_dir.mkdir(parents=True, exist_ok=True)

    existing_id = str(body.get("id") or "").strip()
    note_body = body.get("body")
    if note_body is None:
        return web.json_response({"error": "body required"}, status=400)
    note_body = str(note_body)

    if existing_id:
        filename = existing_id if existing_id.endswith(".note.md") else f"{existing_id}.note.md"
        try:
            path = _resolve_under_recordings(filename, cfg)
        except ValueError as exc:
            return web.json_response({"error": str(exc)}, status=400)
        if not path.is_file():
            return web.json_response({"error": "note not found"}, status=404)
        path.write_text(note_body)
        return web.json_response({"ok": True})

    # Create mode
    title = str(body.get("title") or "").strip()
    if not title:
        return web.json_response({"error": "title required"}, status=400)
    slug = _slug_for_note(title, rec_dir)
    filename = f"{slug}.note.md"
    try:
        path = _resolve_under_recordings(filename, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    path.write_text(note_body)
    return web.json_response({"ok": True, "id": slug, "filename": filename})


async def library_text_post_handler(request: web.Request) -> web.Response:
    """POST /library/text — save summary / transcript / live text for a meeting.

    Body: {id: meeting_id, which: "summary"|"transcript"|"live", body: text}
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    item_id = str(body.get("id") or "").strip()
    which = str(body.get("which") or "").strip()
    text = body.get("body", "")

    SUFFIX_BY_KIND = {
        "summary": ".summary.txt",
        "transcript": ".transcript.txt",
        "live": ".live.txt",
    }
    if which not in SUFFIX_BY_KIND:
        return web.json_response(
            {"error": "which must be summary|transcript|live"}, status=400,
        )
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    if not isinstance(text, str):
        return web.json_response({"error": "body must be a string"}, status=400)

    cfg = request.app["config"]
    try:
        target = _resolve_under_recordings(f"{item_id}{SUFFIX_BY_KIND[which]}", cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
    return web.json_response({"ok": True, "filename": target.name})


async def library_audio_handler(request: web.Request) -> web.Response:
    """GET /library/audio?id=<id> — stream a meeting mp3 with Range support.

    Returns a `FileResponse` so aiohttp handles HTTP Range requests
    automatically (the web `<audio>` element seeks via Range). Content-Type
    is set explicitly because aiohttp's mimetypes fallback can return
    `application/octet-stream` for unknown systems.
    """
    item_id = (request.query.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    cfg = request.app["config"]
    try:
        mp3_path = _resolve_under_recordings(f"{item_id}.mp3", cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if not mp3_path.is_file():
        return web.json_response({"error": "mp3 not found"}, status=404)
    return web.FileResponse(
        mp3_path,
        headers={"Content-Type": "audio/mpeg"},
    )


async def library_speakers_get_handler(request: web.Request) -> web.Response:
    """GET /library/speakers?id=<id> — return the speaker-map sidecar.

    Response: ``{"names": {...}, "evidence": {...}, "source": {...}, "labels": [...]}``
    where ``labels`` is the discovered set from the .live.txt (so the UI
    can render rows for labels that have no sidecar entry yet).
    """
    item_id = (request.query.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    cfg = request.app["config"]
    try:
        mp3_path, live_path, sidecar = _speaker_paths_from_id(item_id, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    data = _speakers.read_speaker_map(sidecar)
    labels: list[str] = []
    live_text = _read_capped(live_path) if live_path.is_file() else None
    if live_text:
        labels = _speakers.extract_speaker_labels(live_text)
    return web.json_response({
        "names": data.names,
        "evidence": data.evidence,
        "source": data.source,
        "labels": labels,
    })


async def library_speakers_post_handler(request: web.Request) -> web.Response:
    """POST /library/speakers — overwrite the names map (manual save).

    Body: ``{"id": "<id>", "names": {"OTHER#0": "Maria", ...}}``.
    Every entry in ``names`` is recorded with ``source="manual"`` so a
    later AI re-run never clobbers it. Existing AI evidence is preserved.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    item_id = str(body.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    raw_names = body.get("names")
    if not isinstance(raw_names, dict):
        return web.json_response({"error": "names must be a dict"}, status=400)

    cfg = request.app["config"]
    try:
        mp3_path, _live_path, sidecar = _speaker_paths_from_id(item_id, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if not mp3_path.is_file():
        return web.json_response({"error": "mp3 not found"}, status=404)
    existing = _speakers.read_speaker_map(sidecar)
    names: dict[str, str | None] = dict(existing.names)
    source: dict[str, str] = dict(existing.source)
    for label, raw_value in raw_names.items():
        if not isinstance(label, str):
            continue
        if raw_value is None or (isinstance(raw_value, str) and not raw_value.strip()):
            names[label] = None
        else:
            names[label] = str(raw_value).strip()
        source[label] = "manual"
    try:
        _speakers.write_speaker_map(
            sidecar, names=names, evidence=existing.evidence, source=source,
        )
    except Exception as exc:
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({
        "ok": True,
        "names": names,
        "evidence": existing.evidence,
        "source": source,
    })


async def library_speakers_suggest_handler(request: web.Request) -> web.Response:
    """POST /library/speakers/suggest — ask the AI provider to fill labels.

    Body: ``{"id": "<id>"}``. Manual entries already in the sidecar are
    preserved (see ``merge_speaker_map``). Returns the merged map.
    """
    from meeting_helper.ai.client import name_speakers_from_transcript
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)
    item_id = str(body.get("id") or "").strip()
    if not item_id:
        return web.json_response({"error": "id required"}, status=400)
    cfg = request.app["config"]
    try:
        mp3_path, live_path, sidecar = _speaker_paths_from_id(item_id, cfg)
    except ValueError as exc:
        return web.json_response({"error": str(exc)}, status=400)
    if not live_path.is_file():
        return web.json_response({"error": "no live transcript"}, status=404)
    try:
        ai_map = await name_speakers_from_transcript(str(live_path), cfg)
    except Exception as exc:
        return web.json_response({"error": str(exc)}, status=500)
    if getattr(cfg, "user_display_name", ""):
        ai_map.names["SELF"] = cfg.user_display_name
        ai_map.source["SELF"] = "manual"
        ai_map.evidence.pop("SELF", None)
    existing = _speakers.read_speaker_map(sidecar)
    merged = _speakers.merge_speaker_map(existing, ai_map)
    try:
        _speakers.write_speaker_map(
            sidecar, names=merged.names, evidence=merged.evidence, source=merged.source,
        )
    except Exception as exc:
        return web.json_response({"error": str(exc)}, status=500)
    return web.json_response({
        "ok": True,
        "names": merged.names,
        "evidence": merged.evidence,
        "source": merged.source,
    })


# ---------------------------------------------------------------------------
# Internal action items (MH-32) — per-meeting sidecars + workspace-level
# orphans. Storage lives in `meeting_helper.action_items.store`; extraction
# in `meeting_helper.action_items.extractor`. The handlers below are pure
# CRUD over those modules plus an LLM-backed extract endpoint.
# ---------------------------------------------------------------------------


def _recordings_dir(cfg) -> Path:
    """Resolve recordings_dir as a Path. AppConfig stores it as str|Path."""
    return Path(cfg.recordings_dir)


def _workspace_json_path(disk) -> Path:
    """Resolve the workspace JSON path off the disk-backed Config.

    Falls back to a synthetic in-memory path for the test shim that has no
    real file backing. The shim's `save()` is a no-op, but action items
    storage writes to disk via this path, so test fixtures that need
    orphan-storage must hand back a real Config (not the shim).
    """
    return Path(disk.config_path)


_STORE_CORRUPT_RESPONSE = {
    "error": "action items file was corrupt and reset; see daemon log",
    "code": "corrupt",
}


async def action_items_get_handler(request: web.Request) -> web.Response:
    """GET /action-items[?meeting_id=...] — read action items.

    Meeting scope: returns just the sidecar for that meeting.
    Workspace scope (no query param): merges every per-meeting sidecar with
    the orphan list and joins meeting_title/meeting_date for sidecar rows.

    The Next.js static export also lives at `/action-items/` (Task 17 page).
    API routes are registered before the static catch-all, so a browser
    navigation to `/action-items` (pywebview restoring last URL, a hard
    reload) would otherwise hit this handler and dump raw JSON into the
    webview. Serve the SPA shell for HTML navigations; JS `fetch(...)` sends
    `Accept: */*` and still gets JSON. Same fix shape as `library_get_handler`.
    """
    # Both branches set Vary: Accept + Cache-Control: no-store so a browser
    # navigating to `/action-items` (no trailing slash) caches the HTML response
    # without poisoning later JS fetch() calls that hit the same URL with
    # `Accept: */*`. Without these, WKWebView happily replays the SPA shell on
    # subsequent fetches and the page loads empty.
    _cache_headers = {"Vary": "Accept", "Cache-Control": "no-store"}

    accept = request.headers.get("Accept", "")
    if "text/html" in accept and "application/json" not in accept:
        from meeting_helper.server.app import WEB_DIST
        index_path = WEB_DIST / "action-items" / "index.html"
        if index_path.is_file():
            return web.FileResponse(index_path, headers=_cache_headers)

    from meeting_helper.action_items import store

    cfg = request.app["config"]
    disk = _resolve_disk(request)
    recordings = _recordings_dir(cfg)
    meeting_id = request.query.get("meeting_id")

    if meeting_id:
        try:
            items = store.load(recordings, meeting_id)
        except store.StoreCorruptError:
            return web.json_response(_STORE_CORRUPT_RESPONSE, status=500, headers=_cache_headers)
        # Stamp meeting_id so downstream consumers don't need to infer it.
        for it in items:
            it.setdefault("meeting_id", meeting_id)
        return web.json_response({"items": items}, headers=_cache_headers)

    try:
        # Offload disk glob+reads from the asyncio loop (ticket #25).
        items = await store.list_all_async(_workspace_json_path(disk), recordings)
    except store.StoreCorruptError:
        return web.json_response(_STORE_CORRUPT_RESPONSE, status=500, headers=_cache_headers)
    # Best-effort meeting_title / meeting_date join. `_list_library_items`
    # is the read-only listing helper used by /library; sharing it keeps
    # the joined fields in sync with what the Library screen shows. The
    # join is opportunistic — orphans skip it (meeting_id is None).
    try:
        index = {
            i["id"]: i
            for i in _list_library_items(cfg).get("items", [])
            if i.get("kind") == "meeting"
        }
    except Exception:
        index = {}
    for it in items:
        mid = it.get("meeting_id")
        if mid and mid in index:
            it["meeting_title"] = index[mid].get("title")
            it["meeting_date"] = index[mid].get("date")
    return web.json_response({"items": items}, headers=_cache_headers)


async def action_items_create_handler(request: web.Request) -> web.Response:
    """POST /action-items — append a manual item to a meeting OR orphans.

    Body: `{"title": "...", "description"?: "...", "meeting_id"?: "..."}`.
    `meeting_id` absent OR null routes the row to the workspace orphan list.
    """
    from meeting_helper.action_items import models, store

    try:
        payload = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    title = (payload.get("title") or "").strip()
    if not title:
        return web.json_response({"error": "title required"}, status=400)
    description = (payload.get("description") or "").strip()
    meeting_id = payload.get("meeting_id")

    item = models.new_item(
        title=title,
        description=description,
        meeting_id=meeting_id,
        source="manual",
    )

    cfg = request.app["config"]
    disk = _resolve_disk(request)
    try:
        if meeting_id:
            recordings = _recordings_dir(cfg)
            items = store.load(recordings, meeting_id)
            items.append(item)
            store.save(recordings, meeting_id, items)
        else:
            ws_json = _workspace_json_path(disk)
            items = store.load_orphans(ws_json)
            items.append(item)
            store.save_orphans(ws_json, items)
    except store.StoreCorruptError:
        return web.json_response(_STORE_CORRUPT_RESPONSE, status=500)

    await _broadcast_action_items_snapshot(request.app)
    return web.json_response({"item": item})


def _locate_item(
    recordings: Path, ws_json: Path, item_id: str,
) -> tuple[str | None, list[dict], int]:
    """Find an item by id across all sidecars + the orphan list.

    Returns ``(meeting_id_or_None, items_list, index)``. The caller can
    mutate ``items_list`` in place and persist via ``store.save`` /
    ``store.save_orphans`` depending on whether ``meeting_id`` is set.

    Raises ``KeyError(item_id)`` if no sidecar or orphan contains the id.
    """
    from meeting_helper.action_items import store

    if recordings.exists():
        for path in recordings.glob("*.action_items.json"):
            meeting_id = path.name.removesuffix(".action_items.json")
            items = store.load(recordings, meeting_id)
            for idx, it in enumerate(items):
                if it["id"] == item_id:
                    return meeting_id, items, idx
    items = store.load_orphans(ws_json)
    for idx, it in enumerate(items):
        if it["id"] == item_id:
            return None, items, idx
    raise KeyError(item_id)


async def action_items_patch_handler(request: web.Request) -> web.Response:
    """PATCH /action-items/{item_id} — update title/description/completed.

    The handler refuses to blank out title (still required after edit) and
    auto-stamps `completed_at` on transitions into/out of completed.
    """
    from meeting_helper.action_items import models, store

    item_id = request.match_info["item_id"]
    try:
        payload = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    cfg = request.app["config"]
    disk = _resolve_disk(request)
    recordings = _recordings_dir(cfg)
    ws_json = _workspace_json_path(disk)

    try:
        meeting_id, items, idx = _locate_item(recordings, ws_json, item_id)
    except KeyError:
        return web.json_response({"error": "not found"}, status=404)
    except store.StoreCorruptError:
        return web.json_response(_STORE_CORRUPT_RESPONSE, status=500)

    item = items[idx]
    if "title" in payload:
        t = (payload["title"] or "").strip()
        if not t:
            return web.json_response({"error": "title required"}, status=400)
        item["title"] = t
    if "description" in payload:
        item["description"] = (payload["description"] or "").strip()
    if "completed" in payload:
        new_completed = bool(payload["completed"])
        if new_completed != item.get("completed", False):
            item["completed"] = new_completed
            item["completed_at"] = models._now() if new_completed else None
    item["updated_at"] = models._now()
    items[idx] = item

    try:
        if meeting_id:
            store.save(recordings, meeting_id, items)
        else:
            store.save_orphans(ws_json, items)
    except store.StoreCorruptError:
        return web.json_response(_STORE_CORRUPT_RESPONSE, status=500)

    await _broadcast_action_items_snapshot(request.app)
    return web.json_response({"item": item})


async def action_items_delete_handler(request: web.Request) -> web.Response:
    """DELETE /action-items/{item_id} — remove an item from sidecar or orphans."""
    from meeting_helper.action_items import store

    item_id = request.match_info["item_id"]
    cfg = request.app["config"]
    disk = _resolve_disk(request)
    recordings = _recordings_dir(cfg)
    ws_json = _workspace_json_path(disk)

    try:
        meeting_id, items, idx = _locate_item(recordings, ws_json, item_id)
    except KeyError:
        return web.json_response({"error": "not found"}, status=404)
    except store.StoreCorruptError:
        return web.json_response(_STORE_CORRUPT_RESPONSE, status=500)

    del items[idx]
    try:
        if meeting_id:
            store.save(recordings, meeting_id, items)
        else:
            store.save_orphans(ws_json, items)
    except store.StoreCorruptError:
        return web.json_response(_STORE_CORRUPT_RESPONSE, status=500)

    await _broadcast_action_items_snapshot(request.app)
    return web.json_response({"ok": True})


async def _broadcast_action_items_snapshot(app) -> None:
    """Broadcast the workspace's currently-open action items to every WS client.

    Gated on ``action_items_inject_into_copilot``. When the toggle is off
    the Copilot panel doesn't render the items, and we don't want to
    flood the WebSocket with a payload nothing renders.

    Designed to accept either a live ``aiohttp.web.Application`` or a plain
    dict mirroring its key surface (``config``, ``disk_factory``) so the
    workspace-switch path and tests can call it without standing up a full
    server.
    """
    from meeting_helper.action_items import store
    from meeting_helper.server.websocket import broadcast
    from meeting_helper.trackers.shim import InMemoryDiskShim

    cfg = app["config"] if "config" in app else app.get("config")
    if cfg is None or not getattr(cfg, "action_items_inject_into_copilot", True):
        return

    # Resolve the disk-backed Config the same way request-bound handlers do —
    # via the zero-arg factory if present, else fall back to the shim so
    # tests without a real disk-backed Config still get a path to read from.
    factory = app.get("disk_factory") if hasattr(app, "get") else None
    disk = None
    if factory is not None:
        try:
            disk = factory()
        except Exception:
            logger.warning(
                "disk_factory failed in _broadcast_action_items_snapshot;"
                " falling back to InMemoryDiskShim",
                exc_info=True,
            )
            disk = None
    if disk is None:
        disk = InMemoryDiskShim(cfg)

    recordings = _recordings_dir(cfg)
    ws_json = _workspace_json_path(disk)
    try:
        # Offload: list_all does a glob + N json reads on disk, which
        # blocks the asyncio loop and stalls transcript broadcasts
        # (ticket #25). This snapshot is also fanned out from many
        # mutation routes — keep it off the loop.
        items = await store.list_all_async(ws_json, recordings)
    except store.StoreCorruptError:
        logger.warning(
            "_broadcast_action_items_snapshot: skipping broadcast — store corrupt",
            exc_info=True,
        )
        return
    except Exception:
        logger.warning(
            "_broadcast_action_items_snapshot: list_all failed", exc_info=True,
        )
        return
    open_items = [i for i in items if not i.get("completed")]
    await broadcast({"type": "action_items_context", "open_items": open_items})


class _SingleShotAIClient:
    """Adapter that satisfies the extractor's `AIClient` protocol.

    The extractor calls ``await ai_client.chat(messages)`` with a
    ``[system, user]`` message list. The project's existing non-streaming
    caller is ``meeting_helper.ai.client._call_ai_for_tasks(config, system,
    user, kind=...)`` — we flatten the messages list back into the two
    fields it expects and reuse that path so action item extraction flows
    through the same provider routing (Claude / Gemini / Ollama) as every
    other one-shot LLM call.
    """

    def __init__(self, config) -> None:
        self._config = config

    async def chat(self, messages: list[dict], **_kwargs) -> str:
        from meeting_helper.ai.client import _call_ai_for_tasks

        system = ""
        user_parts: list[str] = []
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content", "") or ""
            if role == "system" and not system:
                system = content
            else:
                user_parts.append(content)
        user_msg = "\n\n".join(p for p in user_parts if p)
        return await _call_ai_for_tasks(
            self._config, system, user_msg, kind="action_items",
        )


async def action_items_extract_handler(request: web.Request) -> web.Response:
    """POST /library/{meeting_id}/action-items/extract — LLM-extract + append.

    Loads the meeting bundle via the same path /library/item uses, hands
    it to the extractor, then appends the new items to the meeting's
    sidecar. Upstream LLM failures bubble up as 502.
    """
    from meeting_helper.action_items import extractor, store

    meeting_id = request.match_info["meeting_id"]
    cfg = request.app["config"]
    recordings = _recordings_dir(cfg)

    bundle = _fetch_library_bundle(meeting_id, cfg=cfg)
    if not bundle:
        return web.json_response({"error": "meeting not found"}, status=404)

    try:
        new_items = await extractor.extract(
            bundle, ai_client=_SingleShotAIClient(cfg),
        )
    except extractor.ExtractionError as exc:
        return web.json_response({"error": str(exc)}, status=502)

    try:
        existing = store.load(recordings, meeting_id)
        existing.extend(new_items)
        store.save(recordings, meeting_id, existing)
    except store.StoreCorruptError:
        return web.json_response(_STORE_CORRUPT_RESPONSE, status=500)

    await _broadcast_action_items_snapshot(request.app)
    return web.json_response({"items": new_items})


async def transcriber_whisper_health_handler(request: web.Request) -> web.Response:
    """GET /transcriber/whisper/health?host=... — proxy-pings a Whisper /health URL.

    Returns {ok: bool, host: str, error?: str}. Used by Settings → Transcription
    to show "● Connected" / "● Not reachable" status next to the host input.
    """
    import urllib.error
    import urllib.request

    host = (request.query.get("host") or "http://localhost:8000").strip().rstrip("/")
    url = f"{host}/health"

    def _check() -> bool:
        with urllib.request.urlopen(url, timeout=3) as resp:
            return resp.status == 200

    try:
        # Block in a thread so we don't tie up the event loop with a sync open.
        ok = await asyncio.to_thread(_check)
        return web.json_response({"ok": ok, "host": host})
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        return web.json_response({"ok": False, "host": host, "error": str(exc)})


async def transcriber_ollama_health_handler(request: web.Request) -> web.Response:
    """GET /transcriber/ollama/health?host=... — proxy-pings Ollama via /api/tags.

    Returns {ok: bool, host: str, error?: str}. Used by Settings → Local model
    to show "● Connected" / "● Not reachable" status next to the host input.
    Mirrors the old Flet `_check_ollama_connection` behavior.
    """
    import urllib.error
    import urllib.request

    host = (request.query.get("host") or "http://localhost:11434").strip().rstrip("/")
    url = f"{host}/api/tags"

    def _check() -> bool:
        with urllib.request.urlopen(url, timeout=3) as resp:
            return resp.status == 200

    try:
        ok = await asyncio.to_thread(_check)
        return web.json_response({"ok": ok, "host": host})
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        return web.json_response({"ok": False, "host": host, "error": str(exc)})


async def ollama_models_handler(request: web.Request) -> web.Response:
    """GET /ollama/models?host=... — proxies Ollama's /api/tags and returns
    just the installed model names. Used by Settings → Local model to surface
    the currently-installed models in a dropdown instead of a free-text field.

    Returns {ok: bool, host: str, models: list[str], error?: str}.
    """
    import urllib.error
    import urllib.request

    host = (request.query.get("host") or "http://localhost:11434").strip().rstrip("/")
    url = f"{host}/api/tags"

    def _fetch() -> list[str]:
        with urllib.request.urlopen(url, timeout=3) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        models = payload.get("models") or []
        # Ollama returns objects like `{"name": "qwen2.5-coder:3b", ...}`.
        # Surface just the names for the dropdown.
        names: list[str] = []
        for m in models:
            name = (m or {}).get("name") if isinstance(m, dict) else None
            if isinstance(name, str) and name:
                names.append(name)
        return names

    try:
        names = await asyncio.to_thread(_fetch)
        return web.json_response({"ok": True, "host": host, "models": names})
    except (urllib.error.URLError, OSError, TimeoutError, ValueError) as exc:
        return web.json_response(
            {"ok": False, "host": host, "models": [], "error": str(exc)},
        )


def _build_reference_items(cfg, query: str, limit: int) -> list[dict]:
    """Build the unified reference list for the @ picker.

    Each entry collapses a meeting's adjacent files (.live / .summary /
    mp3) into ONE row keyed by the meeting id (the stem), mirroring the
    Library view. Notes are one row per file. KB-only artifacts that
    aren't already present as meetings/notes (e.g. KB summary whose mp3
    was deleted) are surfaced once under kind=kb.
    """
    from meeting_helper.library_retrieval import list_artifacts
    from meeting_helper.config import get_config

    rec_dir = Path(cfg.recordings_dir).expanduser()
    # list_artifacts needs the on-disk Config to read favorites / kb flags
    # (AppConfig is the runtime dataclass — different surface). Match the
    # pattern in `_list_library_items`.
    disk = get_config()
    items = list_artifacts(recordings_dir=rec_dir, config=disk)

    q = (query or "").strip().lower()
    out: list[dict] = []
    seen_meeting_ids: set[str] = set()
    seen_note_ids: set[str] = set()

    for it in items:
        title = it.title or ""
        if q and q not in title.lower():
            continue
        if it.kind == "meeting":
            if it.id in seen_meeting_ids:
                continue
            seen_meeting_ids.add(it.id)
            subtitle_parts: list[str] = []
            if it.date:
                subtitle_parts.append(it.date)
            if it.has_summary:
                subtitle_parts.append("summary")
            if it.has_transcript:
                subtitle_parts.append("transcript")
            elif it.has_live:
                subtitle_parts.append("live")
            out.append({
                "kind": "meeting",
                "id": it.id,
                "title": title,
                "subtitle": " · ".join(subtitle_parts),
                "snippet": "",
                # `date` (YYYY-MM-DD) and `sort_key` (YYYY-MM-DD_HHMMSS)
                # let the picker render a relative timestamp matching the
                # Library list ("Today · 10:00", "Yesterday", "May 8").
                "date": it.date or "",
                "sort_key": it.sort_key or "",
                "duration_sec": it.duration_sec,
            })
        elif it.kind == "note":
            if it.id in seen_note_ids:
                continue
            seen_note_ids.add(it.id)
            out.append({
                "kind": "note",
                "id": it.id,
                "title": title,
                "subtitle": "note",
                "snippet": "",
                "date": it.date or "",
                "sort_key": it.sort_key or "",
            })

    # KB entries whose underlying artifact isn't already in the list above
    # (e.g. a KB-flagged summary whose mp3 was deleted). For meetings the
    # KB filename is `<stem>.summary.txt` — match against the seen stem so
    # we don't double-list one meeting under both kinds.
    for kb_filename in list(disk.kb_artifacts or []):
        try:
            from meeting_helper.library_retrieval import load_artifacts
            cards = load_artifacts(recordings_dir=rec_dir, kb_filenames=[kb_filename])
        except Exception:
            cards = []
        if not cards:
            continue
        card = cards[0]
        if card.kind == "meeting":
            stem = kb_filename[: -len(".summary.txt")] if kb_filename.endswith(".summary.txt") else kb_filename
            if stem in seen_meeting_ids:
                continue
        elif card.kind == "note":
            if kb_filename in seen_note_ids:
                continue
        title = card.title or ""
        if q and q not in title.lower():
            continue
        out.append({
            "kind": "kb",
            "id": kb_filename,
            "title": title,
            "subtitle": "knowledge base",
            "snippet": (card.body or "")[:160],
            "date": getattr(card, "date", "") or "",
            "sort_key": getattr(card, "sort_key", "") or "",
            "duration_sec": getattr(card, "duration_sec", None),
        })

    return out[: max(1, min(limit, 50))]


async def references_search_handler(request: web.Request) -> web.Response:
    """GET /references/search?q=<query>&limit=20 — unified picker feed.

    Powers the chat composer's `@` reference picker (ticket #268). Returns a
    flat list `{ items: [{ kind, id, title, subtitle?, snippet? }] }`. Meetings
    are collapsed to ONE entry per recording (no .live/.summary/.audio fan-out)
    so the picker mirrors the Library grouping.

    Filtering is a case-insensitive substring match on title only — the picker
    debounces keystrokes already, so we don't peek into file bodies here.
    Empty `q` returns the most recent items.
    """
    cfg = request.app["config"]
    q = (request.query.get("q") or "").strip()
    try:
        limit = int(request.query.get("limit") or "20")
    except ValueError:
        limit = 20
    try:
        items = await asyncio.to_thread(_build_reference_items, cfg, q, limit)
    except Exception as exc:
        logger.warning("references_search failed: %s", exc, exc_info=True)
        items = []
    return web.json_response({"items": items})


async def vendors_list_handler(request: web.Request) -> web.Response:
    """Return the fixed vendor catalog with auth-form metadata.

    `enabled` flags vendors that are ready for end-user connection. Profiles
    we keep wired up but haven't validated end-to-end (Linear, Trello, GitHub
    Projects) ship as `enabled: false`; the UI shows them as disabled options
    so the user knows they're on the roadmap. The handler also rejects POST
    /trackers for a disabled vendor (`trackers_create_handler`), so flipping
    the flag is the single source of truth.
    """
    from meeting_helper.trackers.vendors import ALL_PROFILES
    payload = {
        "vendors": [
            {
                "id": P.id,
                "label": P.label,
                "auth_form": [
                    {
                        "key": f.key,
                        "label": f.label,
                        "kind": f.kind,
                        "placeholder": f.placeholder,
                        "required": f.required,
                        "secret": f.secret,
                    }
                    for f in P.auth_form
                ],
                "transport_default": {
                    "type": P.transport.type,
                    "command": P.transport.command,
                    "args": list(P.transport.args),
                    "env_template": dict(P.transport.env_template),
                    "url_template": P.transport.url_template,
                    "headers_template": dict(P.transport.headers_template),
                },
                "capabilities": sorted(P.supports),
                "auth_mode": getattr(P, "auth_mode", "manual"),
                "default_url": getattr(P, "default_url", ""),
                "enabled": P.id in _ENABLED_VENDOR_IDS,
            }
            for P in ALL_PROFILES
        ]
    }
    return web.json_response(payload)


# Vendor profiles validated end-to-end against their live MCP servers. Others
# ship but are surfaced as disabled in the picker until they're tested.
_ENABLED_VENDOR_IDS = frozenset({"local_todo", "jira", "notion", "meeting_helper"})


def _resolve_transport_dict(template, auth_values: dict) -> dict:
    """Save a partially-resolved transport: substitute auth values where
    available; leave secret placeholders verbatim — they're filled at
    spawn time from the keychain.
    """
    import re

    def sub(s: str) -> str:
        return re.sub(
            r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}",
            lambda m: auth_values.get(m.group(1), m.group(0)),
            s,
        )

    if template.type == "stdio":
        return {
            "type": "stdio",
            "command": sub(template.command),
            "args": [sub(a) for a in template.args],
            "env": {k: sub(v) for k, v in template.env_template.items()},
        }
    return {
        "type": "http",
        "url": sub(template.url_template),
        "headers": {k: sub(v) for k, v in template.headers_template.items()},
    }


def _resolve_disk(request: web.Request):
    """Return the disk-backed Config for the *current* active workspace.

    In production the app stores a zero-arg factory (``disk_factory``) so each
    request resolves the up-to-date Config even after a workspace switch.  In
    tests ``disk_factory`` is None and we fall back to an in-memory shim that
    mirrors the AppConfig interface with a no-op ``save()``.
    """
    factory = request.app.get("disk_factory")
    if factory is not None:
        try:
            return factory()
        except Exception:
            logger.warning(
                "_resolve_disk: disk_factory raised; falling back to shim",
                exc_info=True,
            )
    from meeting_helper.trackers.shim import InMemoryDiskShim
    return InMemoryDiskShim(request.app["config"])


async def trackers_list_handler(request: web.Request) -> web.Response:
    """GET /trackers — list workspace trackers and the active tracker id.

    Each row gets a runtime ``status`` field the UI can render as a dot:
      - ``connected``: registry has a live MCP session (``_session`` set)
      - ``needs_reauth``: a recent fetch raised ``InteractiveOAuthRequired``
      - ``idle``: no session yet — never opened or already shut down

    The status is computed from the running daemon's state; it isn't on
    disk, so a daemon restart resets every tracker to ``idle`` until its
    next probe. That matches what the UI should show — "we haven't talked
    to this MCP server yet this run."
    """
    config = request.app["config"]
    registry = getattr(state, "trackers", None)
    needs_reauth_id = getattr(state, "tracker_needs_reauth", None) or ""
    out = []
    for t in config.trackers:
        tid = t["id"]
        status = "idle"
        if registry is not None:
            live = registry.get(tid)
            if live is not None and getattr(live, "_session", None) is not None:
                status = "connected"
        if needs_reauth_id == tid:
            status = "needs_reauth"
        out.append({
            "id": tid,
            "vendor": t["vendor"],
            "label": t.get("label", ""),
            "transport": dict(t.get("transport") or {}),
            "auth_values": dict(t.get("auth_values") or {}),
            "secret_keys": list(t.get("secret_keys") or []),
            "chat_enabled": bool(t.get("chat_enabled", True)),
            "status": status,
            # Populated by `_probe_authenticated_account` after a
            # successful OAuth connect. Empty string when we never
            # learned the account (older entries, vendors without an
            # identity tool, probe failure). UI uses this to render
            # "Notion (you@example.com)" so the user can tell at a
            # glance WHICH account is wired up.
            "authenticated_account": t.get("authenticated_account") or "",
        })
    return web.json_response({
        "trackers": out,
        "active_tracker_id": config.active_tracker_id,
    })


async def trackers_create_handler(request: web.Request) -> web.Response:
    """POST /trackers — create a tracker and write secrets to keychain."""
    from meeting_helper.trackers.secrets import write_secrets, KeychainUnavailable
    from meeting_helper.trackers.registry import get_profile, UnknownVendor
    import uuid

    body = await request.json()
    vendor = body.get("vendor", "")
    try:
        ProfileCls = get_profile(vendor)
    except UnknownVendor:
        return web.json_response({"error": f"unknown vendor: {vendor}"}, status=400)
    if vendor not in _ENABLED_VENDOR_IDS:
        return web.json_response({
            "error": f"vendor '{vendor}' is not yet enabled — coming soon",
        }, status=400)

    auth_values = dict(body.get("auth_values") or {})
    secrets = dict(body.get("secrets") or {})
    secret_keys = [f.key for f in ProfileCls.auth_form if f.secret]
    # Drop any secret accidentally placed in auth_values.
    for sk in secret_keys:
        auth_values.pop(sk, None)

    tid = f"{vendor[:3]}-{uuid.uuid4().hex[:8]}"
    config = request.app["config"]

    if secrets:
        try:
            write_secrets(config.workspace_name, tid, {k: v for k, v in secrets.items() if v})
        except KeychainUnavailable as exc:
            return web.json_response({"error": f"keychain unavailable: {exc}"}, status=500)

    entry = {
        "id": tid,
        "vendor": vendor,
        "label": body.get("label") or ProfileCls.label,
        "transport": _resolve_transport_dict(ProfileCls.transport, auth_values),
        "auth_values": auth_values,
        "secret_keys": [k for k in secret_keys if secrets.get(k)],
    }

    # Persist to disk via the per-request disk-backed Config (or in-memory shim in tests).
    disk = _resolve_disk(request)
    disk_trackers = list(disk.trackers)
    disk_trackers.append(entry)
    disk.trackers = disk_trackers
    if disk.active_tracker_id is None:
        disk.active_tracker_id = tid
    try:
        disk.save()
    except Exception as exc:
        logger.warning("trackers_create: disk save failed: %s", exc)

    # Mirror to in-memory AppConfig so subsequent requests in the same process
    # see the updated state without a daemon restart. Keep copilot_tracker_id
    # and active_tracker_id in lockstep — the dataclass doesn't auto-sync them
    # the way the disk-backed Config property setters do.
    config.trackers = list(disk.trackers)
    config.active_tracker_id = disk.active_tracker_id
    config.copilot_tracker_id = disk.active_tracker_id

    # When this is the FIRST tracker (auto-activated above), actually boot
    # the registry so state.tracker is populated — otherwise Brief/Copilot
    # silently see no tracker until the user manually activates or restarts.
    became_active = disk.active_tracker_id == tid
    if became_active:
        try:
            from meeting_helper.trackers.registry import reboot_active_tracker
            await reboot_active_tracker(state, config, config.workspace_name or "")
        except Exception as exc:
            logger.warning("trackers_create: reboot_active_tracker failed: %s", exc)

    # Broadcast so connected clients (including the originating UI) refresh
    # their cached tracker list — without this the user has to navigate away
    # and back to see the new tracker.
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({
            "type": "tracker_changed",
            "tracker_id": disk.active_tracker_id if became_active else None,
            "vendor": vendor if became_active else None,
        })
    except Exception as exc:
        logger.warning("trackers_create: broadcast failed: %s", exc)

    return web.json_response({
        "id": entry["id"],
        "vendor": entry["vendor"],
        "label": entry["label"],
        "transport": entry["transport"],
        "auth_values": entry["auth_values"],
        "secret_keys": entry["secret_keys"],
    }, status=201)


async def trackers_update_handler(request: web.Request) -> web.Response:
    """PUT /trackers/{tracker_id} — update label, auth_values, or secrets."""
    from meeting_helper.trackers.secrets import write_secrets, KeychainUnavailable

    tid = request.match_info["tracker_id"]
    config = request.app["config"]
    disk = _resolve_disk(request)
    disk_trackers = list(disk.trackers)
    entry = next((t for t in disk_trackers if t["id"] == tid), None)
    if entry is None:
        return web.json_response({"error": "not found"}, status=404)

    body = await request.json()
    if "label" in body:
        entry["label"] = body["label"]
    if "auth_values" in body:
        entry["auth_values"] = {**entry.get("auth_values", {}), **(body["auth_values"] or {})}
    if "transport" in body:
        entry["transport"] = dict(body["transport"])
    secrets = body.get("secrets") or {}
    if secrets:
        non_empty = {k: v for k, v in secrets.items() if v}
        if non_empty:
            try:
                write_secrets(config.workspace_name, tid, non_empty)
            except KeychainUnavailable as exc:
                return web.json_response({"error": f"keychain unavailable: {exc}"}, status=500)
            entry["secret_keys"] = sorted(
                set(list(entry.get("secret_keys") or []) + list(non_empty.keys()))
            )

    disk.trackers = disk_trackers
    try:
        disk.save()
    except Exception as exc:
        logger.warning("trackers_update: disk save failed: %s", exc)

    config.trackers = list(disk.trackers)

    # If we just updated the *active* tracker's auth (URL, credentials),
    # reboot the registry so the next call uses the new transport/secrets.
    if config.active_tracker_id == tid and ("auth_values" in body or "transport" in body or secrets):
        try:
            from meeting_helper.trackers.registry import reboot_active_tracker
            await reboot_active_tracker(state, config, config.workspace_name or "")
        except Exception as exc:
            logger.warning("trackers_update: reboot_active_tracker failed: %s", exc)

    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({"type": "tracker_changed", "tracker_id": config.active_tracker_id, "vendor": entry.get("vendor", "")})
    except Exception as exc:
        logger.warning("trackers_update: broadcast failed: %s", exc)

    return web.json_response({"ok": True})


async def trackers_chat_enabled_handler(request: web.Request) -> web.Response:
    """PUT /trackers/{tracker_id}/chat-enabled — flip chat_enabled.

    Cannot disable on the Copilot tracker (UI locks the checkbox; this is the
    server-side enforcement). Broadcasts tracker_changed so other clients
    refresh.
    """
    tid = request.match_info["tracker_id"]
    body = await request.json()
    enabled = bool(body.get("enabled"))

    config = request.app["config"]
    disk = _resolve_disk(request)
    disk_trackers = list(disk.trackers)
    entry = next((t for t in disk_trackers if t["id"] == tid), None)
    if entry is None:
        return web.json_response({"error": "not found"}, status=404)

    copilot_id = getattr(config, "copilot_tracker_id", None) or getattr(config, "active_tracker_id", None)
    if not enabled and tid == copilot_id:
        return web.json_response({
            "error": "cannot disable chat on the Copilot tracker — pick a different Copilot tracker first",
        }, status=409)

    entry["chat_enabled"] = enabled
    disk.trackers = disk_trackers
    try:
        disk.save()
    except Exception as exc:
        logger.warning("trackers_chat_enabled: disk save failed: %s", exc)
    config.trackers = list(disk.trackers)

    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({"type": "tracker_changed", "tracker_id": tid, "vendor": entry.get("vendor")})
    except Exception as exc:
        logger.warning("trackers_chat_enabled: broadcast failed: %s", exc)
    return web.json_response({"ok": True})


async def trackers_delete_handler(request: web.Request) -> web.Response:
    """DELETE /trackers/{tracker_id} — remove tracker and purge keychain secrets.

    If the target is the active tracker, shut it down and clear active_tracker_id
    first, then remove. (No "active tracker required" invariant — workspace can
    have zero connected trackers.)
    """
    from meeting_helper.trackers.secrets import purge_tracker

    tid = request.match_info["tracker_id"]
    config = request.app["config"]

    disk = _resolve_disk(request)
    removed = next((t for t in disk.trackers if t["id"] == tid), None)
    if removed is None:
        return web.json_response({"error": "not found"}, status=404)

    # Always close the session for the removed tracker, regardless of whether
    # it was the Copilot one — otherwise non-Copilot deletes leak MCP sessions.
    registry = getattr(state, "trackers", None)
    if registry is not None:
        try:
            await registry.shutdown(tid)
        except Exception as exc:
            logger.warning("trackers_delete: shutdown %s raised: %s", tid, exc)

    was_active = (config.copilot_tracker_id or config.active_tracker_id) == tid
    if was_active:
        state.tracker = None
        # Try to promote the next chat-enabled tracker (insertion order, excluding
        # the one being removed). The chat_enabled flag defaults to True.
        survivors = [
            t for t in disk.trackers
            if t["id"] != tid and t.get("chat_enabled", True)
        ]
        promoted = survivors[0]["id"] if survivors else None
        disk.copilot_tracker_id = promoted
        config.copilot_tracker_id = promoted
        config.active_tracker_id = promoted  # keep AppConfig alias in sync

    disk.trackers = [t for t in disk.trackers if t["id"] != tid]
    try:
        disk.save()
    except Exception as exc:
        logger.warning("trackers_delete: disk save failed: %s", exc)
    config.trackers = list(disk.trackers)

    # Boot the promoted Copilot tracker (if any) so state.tracker is live.
    if was_active and config.copilot_tracker_id:
        try:
            from meeting_helper.trackers.registry import reboot_copilot_tracker
            await reboot_copilot_tracker(state, config, config.workspace_name or "")
        except Exception as exc:
            logger.warning("trackers_delete: promote reboot failed: %s", exc)

    try:
        purge_tracker(config.workspace_name, tid, removed.get("secret_keys", []) or [])
    except Exception:
        pass

    # Broadcast for ALL deletes (active or not) so other clients refresh their
    # tracker list. The active-id changes only when we just removed the active
    # one — pass that explicitly so listeners can update both views in one shot.
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({
            "type": "tracker_changed",
            "tracker_id": config.active_tracker_id,  # None if was_active, else unchanged
            "vendor": None if was_active else removed.get("vendor"),
            "deleted_id": tid,
        })
    except Exception as exc:
        logger.warning("trackers_delete: broadcast failed: %s", exc)

    return web.json_response({"ok": True})


async def trackers_activate_handler(request: web.Request) -> web.Response:
    """POST /trackers/{tracker_id}/activate — swap the active tracker via the registry."""
    from meeting_helper.trackers.secrets import read_secrets, KeychainUnavailable
    from meeting_helper.trackers.registry import TrackerRegistry

    tid = request.match_info["tracker_id"]
    config = request.app["config"]
    entry = next((t for t in config.trackers if t["id"] == tid), None)
    if entry is None:
        return web.json_response({"error": "not found"}, status=404)

    try:
        secrets = read_secrets(config.workspace_name, tid, entry.get("secret_keys", []) or [])
    except KeychainUnavailable as exc:
        return web.json_response({"error": f"keychain unavailable: {exc}"}, status=500)

    # Use the registry from state if the daemon has booted one; otherwise
    # create a transient registry for this request (e.g. in tests).
    registry = getattr(state, "trackers", None)
    if registry is None:
        registry = TrackerRegistry()

    try:
        await registry.activate(
            tracker_id=tid,
            vendor_id=entry["vendor"],
            auth_values=entry.get("auth_values", {}) or {},
            secrets=secrets,
            workspace_name=getattr(config, "workspace_name", "") or "",
        )
    except Exception as exc:
        return web.json_response({"error": str(exc)}, status=500)

    state.tracker = registry.current

    disk = _resolve_disk(request)
    disk.active_tracker_id = tid
    try:
        disk.save()
    except Exception as exc:
        logger.warning("trackers_activate: disk save failed: %s", exc)

    # AppConfig is a plain dataclass — copilot_tracker_id and active_tracker_id
    # don't auto-sync. Set both explicitly so the chat-enabled guard (which
    # reads copilot_tracker_id) and legacy callers (which read active_tracker_id)
    # agree on which tracker is the Copilot.
    config.active_tracker_id = tid
    config.copilot_tracker_id = tid

    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({"type": "tracker_changed", "tracker_id": tid, "vendor": entry["vendor"]})
    except Exception as exc:
        logger.warning("trackers_activate: broadcast failed: %s", exc)

    return web.json_response({"ok": True, "tracker_id": tid, "vendor": entry["vendor"]})


async def trackers_connect_handler(request: web.Request) -> web.Response:
    """Run the MCP OAuth flow for a tracker. Synchronously blocks until the
    user completes the browser-side authorization (or until 5-minute timeout)."""
    from meeting_helper.trackers.registry import get_profile, UnknownVendor, reboot_active_tracker
    from meeting_helper.trackers.transport import expand_transport
    from meeting_helper.trackers.tracker import Tracker
    from meeting_helper.server.websocket import broadcast

    tid = request.match_info["tracker_id"]
    config = request.app["config"]
    state_obj = state  # module-level

    entry = next((t for t in config.trackers if t["id"] == tid), None)
    if entry is None:
        return web.json_response({"ok": False, "error": "tracker not found"}, status=404)

    try:
        ProfileCls = get_profile(entry["vendor"])
    except UnknownVendor:
        return web.json_response({"ok": False, "error": "unknown vendor"}, status=400)

    if getattr(ProfileCls, "auth_mode", "manual") != "mcp_oauth":
        return web.json_response({
            "ok": False, "error": "vendor does not support OAuth"
        }, status=400)

    workspace_name = config.workspace_name
    transport = expand_transport(ProfileCls.transport, entry.get("auth_values", {}) or {}, {})

    # If the registry has a STALE session for this tracker (e.g. a passive
    # build that raised InteractiveOAuthRequired), evict it so the fresh
    # OAuth flow doesn't fight the broken one. Also purge the stored
    # OAuth client info from the keychain — Atlassian (and others) garbage-
    # collect DCR client_ids after a TTL; reusing a dead client_id makes
    # the authorize endpoint return 500 "Internal Server Error". Wiping
    # client_info forces the SDK to re-register fresh and get a working
    # client_id. The access_token + refresh_token stay (the keychain account
    # is separate); they'll be replaced by the new OAuth exchange.
    registry = getattr(state_obj, "trackers", None)
    if registry is not None:
        try:
            await registry.shutdown(tid)
        except Exception:
            pass
    try:
        from meeting_helper.trackers.oauth import KeychainTokenStorage
        import keyring
        from meeting_helper.trackers.secrets import SERVICE
        storage = KeychainTokenStorage(workspace_name, tid)
        keyring.delete_password(SERVICE, storage._client_account)
        logger.info("trackers_connect: purged stale OAuth client_info for %s (forces fresh DCR)", tid)
    except Exception as exc:
        logger.info("trackers_connect: client_info purge skipped (%s)", exc)

    await broadcast({"type": "tracker_oauth_started", "tracker_id": tid})

    # Connect IS the user-initiated re-auth flow — interactive=True so the
    # SDK is allowed to open a browser if the keychain token has expired.
    transient = Tracker(
        profile=ProfileCls(),
        transport=transport,
        oauth_workspace=workspace_name,
        oauth_tracker_id=tid,
        interactive_oauth=True,
    )
    probe_error: str | None = None
    workspaces_seen: list[str] = []
    authenticated_account: str | None = None
    try:
        # Vendor-agnostic probe: drive _ensure_started (which runs the OAuth
        # flow) then call list_tools() — every MCP server supports it, and
        # it confirms the session is alive + authenticated without leaning
        # on a vendor-specific capability like list_workspaces (only
        # local-todo's profile implements it; Phase C stripped the others).
        # Wrap in a generous timeout (5 minutes for the user to click Authorize).
        try:
            await asyncio.wait_for(transient._ensure_started(), timeout=305.0)
            tools_resp = await transient._session.list_tools()
            workspaces_seen = [t.name for t in (tools_resp.tools or [])[:5]]
            # Identity probe: try a vendor-appropriate tool to learn WHICH
            # account just authenticated, so the tracker entry can display
            # "Notion (you@example.com)" instead of just "Notion". This is
            # best-effort — if the vendor doesn't expose an identity tool,
            # or the call fails, we still consider the connect successful.
            authenticated_account = await _probe_authenticated_account(
                transient._session, tools_resp.tools or [],
            )
            if authenticated_account:
                logger.info(
                    "connect: identified authenticated account for %s: %s",
                    tid, authenticated_account,
                )
        except asyncio.TimeoutError:
            return web.json_response({
                "ok": False, "error": "OAuth timed out — user did not authorize in time"
            }, status=504)
        except Exception as exc:
            # OAuth may have succeeded (token stored in keychain) but the probe
            # call failed (slow first request, MCP server hiccup, transient
            # session glitch). Record the error and fall through to keychain
            # check — if a token landed, treat it as success.
            probe_error = str(exc)[:300]
            logger.info("connect: probe failed after OAuth, checking keychain: %s", probe_error)
    finally:
        try:
            await transient.close(timeout=2.0)
        except Exception:
            pass

    # Did OAuth actually complete? Check the keychain for a stored token.
    from meeting_helper.trackers.oauth import KeychainTokenStorage
    storage = KeychainTokenStorage(workspace_name, tid)
    token = await storage.get_tokens()
    if token is None:
        # No token + probe failed → genuinely no authorization completed.
        await broadcast({"type": "tracker_oauth_failed", "tracker_id": tid, "error": probe_error or "no token"})
        return web.json_response({"ok": False, "error": probe_error or "authorization not completed"}, status=500)

    # Token exists — OAuth completed. Promote and report success.
    try:
        await reboot_active_tracker(state_obj, config, workspace_name)
    except Exception as exc:
        logger.warning("reboot after OAuth failed: %s", exc)

    # Persist the authenticated account onto the tracker entry so the UI
    # can display "Notion (you@example.com)" instead of an opaque label.
    # Only write if we actually learned something — preserves prior value
    # on probe failure.
    if authenticated_account:
        try:
            entry["authenticated_account"] = authenticated_account
            disk = request.app.get("disk")
            if disk is not None:
                disk.trackers = list(config.trackers)
                disk.save()
        except Exception as exc:
            logger.warning("connect: failed to persist authenticated_account: %s", exc)

    # Clear any stale "needs re-auth" hint — Connect just produced fresh
    # tokens, so the next Brief/Topics call should not be told to reconnect.
    if getattr(state_obj, "tracker_needs_reauth", None) == tid:
        state_obj.tracker_needs_reauth = None
    await broadcast({
        "type": "tracker_oauth_connected",
        "tracker_id": tid,
        "vendor": entry["vendor"],
        "authenticated_account": authenticated_account,
    })
    response: dict = {"ok": True, "workspaces": workspaces_seen}
    if authenticated_account:
        response["authenticated_account"] = authenticated_account
    if probe_error:
        response["warning"] = f"Authorized, but workspace probe didn't complete: {probe_error}"
    return web.json_response(response)


# Per-vendor identity probe — looks at the MCP tool list for known
# "who am I?" tools and extracts a human-readable account string from
# the first one that responds. Returning None is fine; OAuth still succeeds.
_IDENTITY_TOOL_NAMES = (
    # Atlassian: confirmed via the deferred-tools list at session start.
    "atlassianUserInfo",
    # Notion: not a named tool; we fall back to a fetch with /users/me.
    # Linear's MCP exposes `viewer` per the public SDK; GitHub uses `me`.
    "viewer",
    "me",
    "getCurrentUser",
    "currentUser",
    "whoami",
)


async def _probe_authenticated_account(session, tools) -> str | None:
    """Best-effort identity probe. Returns an "email" or "name" string,
    or None when the vendor doesn't expose anything we recognise.

    Why best-effort: this runs INSIDE `trackers_connect_handler` after a
    successful OAuth — the user has already authenticated, the OAuth token
    is in the keychain, the connect is going to succeed regardless of
    whether we can label the account nicely. Any exception here gets
    swallowed: identity is a nice-to-have for the UI, not a contract."""
    if session is None or not tools:
        return None
    tool_names = {getattr(t, "name", "") for t in tools}

    async def _call(name: str, args: dict | None = None) -> dict | None:
        try:
            result = await asyncio.wait_for(
                session.call_tool(name, args or {}), timeout=8.0,
            )
        except Exception as exc:
            logger.debug("identity probe: %s failed: %s", name, exc)
            return None
        # MCP CallToolResult — pull out structured content if present,
        # otherwise the text content of the first block.
        sc = getattr(result, "structuredContent", None)
        if isinstance(sc, dict) and sc:
            return sc
        contents = getattr(result, "content", None) or []
        for block in contents:
            text = getattr(block, "text", None)
            if not text:
                continue
            try:
                import json as _json
                parsed = _json.loads(text)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                # Plain-text identity (e.g. just an email) — wrap it.
                return {"_text": text}
        return None

    for name in _IDENTITY_TOOL_NAMES:
        if name not in tool_names:
            continue
        data = await _call(name)
        identity = _extract_identity(data)
        if identity:
            return identity

    # Notion-specific fallback: their MCP uses a single `notion-fetch`
    # tool with a path argument; /users/me returns the current bot/user.
    if "notion-fetch" in tool_names:
        data = await _call("notion-fetch", {"url": "/users/me"})
        identity = _extract_identity(data)
        if identity:
            return identity

    return None


def _extract_identity(data: dict | None) -> str | None:
    """Pick the most human-readable field from an identity response."""
    if not isinstance(data, dict):
        return None
    # Email is the strongest identifier — distinguishes accounts on the
    # same vendor unambiguously.
    for key in ("emailAddress", "email", "user_email"):
        v = data.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    # Display name / login are fine fallbacks.
    for key in ("displayName", "name", "login", "username", "account_id"):
        v = data.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    # Sometimes the identity is nested under "person" / "user" / "data".
    for key in ("person", "user", "data", "bot"):
        nested = data.get(key)
        if isinstance(nested, dict):
            inner = _extract_identity(nested)
            if inner:
                return inner
    # Raw text fallback (only set when the tool returned plain text).
    text = data.get("_text")
    if isinstance(text, str) and text.strip() and len(text) < 200:
        return text.strip()
    return None


async def trackers_test_handler(request: web.Request) -> web.Response:
    """POST /trackers/{tracker_id}/test — probe the tracker.

    Prefers reusing the registry's live session (which already holds a hot
    OAuthContext with the keychain-loaded token) over spawning a fresh
    transient Tracker. A transient Tracker creates a fresh OAuthClientProvider
    with `_initialized=False` — on a 401 from the first request, the SDK can
    re-trigger the full browser OAuth flow even when a perfectly valid token
    sits in the keychain. By going through `registry.ensure_session` we hit
    the cached session first, and on miss we build one ONCE that subsequent
    Test clicks reuse.
    """
    from meeting_helper.trackers.registry import get_profile, UnknownVendor
    from meeting_helper.trackers.tracker import Tracker
    from meeting_helper.trackers.transport import expand_transport
    from meeting_helper.trackers.secrets import read_secrets, KeychainUnavailable

    tid = request.match_info["tracker_id"]
    config = request.app["config"]
    entry = next((t for t in config.trackers if t["id"] == tid), None)
    if entry is None:
        return web.json_response({"error": "not found"}, status=404)

    try:
        get_profile(entry["vendor"])
    except UnknownVendor:
        return web.json_response({"ok": False, "error": "unknown vendor"})

    registry = getattr(state, "trackers", None)
    workspace_name = getattr(config, "workspace_name", "") or ""

    from meeting_helper.trackers.tracker import InteractiveOAuthRequired

    # 1. Fast path — registry already has a LIVE session for this tracker
    #    (i.e. _ensure_started succeeded previously). A cached Tracker whose
    #    _session is None means a prior start raised (typically passive-OAuth
    #    InteractiveOAuthRequired); fall through to the retry path so we
    #    return a real error message instead of AttributeError on .list_tools.
    if registry is not None:
        cached = registry.get(tid)
        if cached is not None and getattr(cached, "_session", None) is not None:
            try:
                tools_resp = await cached._session.list_tools()
                sample = [t.name for t in (tools_resp.tools or [])[:5]]
                return web.json_response({"ok": True, "workspaces": sample, "via": "cached"})
            except Exception as exc:
                logger.info("trackers_test: cached session probe failed (%s) — will retry via registry", exc)
                # Fall through to ensure_session — the cache may be stale.

    # 2. Build (or rebuild) via the registry. ensure_session loads keychain
    #    tokens off the event loop and reuses the cached session next time.
    #    Passive OAuth — Test must NOT open a browser; if the SDK can't
    #    refresh the token, surface a clear "click Connect to re-auth" hint
    #    instead.
    if registry is not None:
        try:
            tracker = await registry.ensure_session(
                entry, workspace_name=workspace_name, interactive_oauth=False,
            )
            await tracker._ensure_started()
            tools_resp = await tracker._session.list_tools()
            sample = [t.name for t in (tools_resp.tools or [])[:5]]
            return web.json_response({"ok": True, "workspaces": sample, "via": "registry"})
        except Exception as exc:
            from meeting_helper.chat.tools.mcp_passthrough import _contains_exception
            if _contains_exception(exc, InteractiveOAuthRequired):
                tracker_label = entry.get("label") or entry["vendor"]
                # Evict the broken session so the next Test call can re-try
                # cleanly (and so Connect builds fresh state).
                try:
                    await registry.shutdown(tid)
                except Exception:
                    pass
                return web.json_response({
                    "ok": False,
                    "error": f"{tracker_label} needs re-authentication — click Connect to fix.",
                    "needs_reauth": True,
                })
            return web.json_response({"ok": False, "error": str(exc)})

    # 3. Test/fallback path (no registry — e.g. unit tests).
    try:
        secrets = read_secrets(workspace_name, tid, entry.get("secret_keys", []) or [])
    except KeychainUnavailable as exc:
        return web.json_response({"ok": False, "error": f"keychain unavailable: {exc}"})
    ProfileCls = get_profile(entry["vendor"])
    transport = expand_transport(ProfileCls.transport, entry.get("auth_values", {}) or {}, secrets)
    transient = Tracker(
        profile=ProfileCls(),
        transport=transport,
        oauth_workspace=workspace_name,
        oauth_tracker_id=tid,
        interactive_oauth=False,  # Test must never open a browser
    )
    try:
        await transient._ensure_started()
        tools_resp = await transient._session.list_tools()
        sample = [t.name for t in (tools_resp.tools or [])[:5]]
        return web.json_response({"ok": True, "workspaces": sample, "via": "transient"})
    except Exception as exc:
        return web.json_response({"ok": False, "error": str(exc)})
    finally:
        await transient.close(timeout=2.0)


def setup_routes(app: web.Application) -> None:
    app.router.add_get("/health", health_handler)
    app.router.add_get(
        "/transcriber/whisper/health",
        transcriber_whisper_health_handler,
    )
    app.router.add_get(
        "/transcriber/ollama/health",
        transcriber_ollama_health_handler,
    )
    app.router.add_get("/ollama/models", ollama_models_handler)
    app.router.add_get("/config", config_get_handler)
    app.router.add_post("/config", config_post_handler)
    app.router.add_get("/transcript", transcript_handler_get)
    app.router.add_post("/transcript/clear", transcript_clear_handler)
    app.router.add_get("/last_response", last_response_handler)
    app.router.add_get("/last_cards", last_cards_handler)
    app.router.add_get("/current_topic", current_topic_handler)
    app.router.add_get("/topics", topics_handler)
    app.router.add_post("/topics/refresh", topics_refresh_handler)
    app.router.add_post("/topic/set", topic_set_handler)
    app.router.add_post("/topic/auto", topic_auto_handler)
    app.router.add_post("/topic/pin", topic_pin_handler)
    app.router.add_post("/topic/unpin", topic_unpin_handler)
    app.router.add_post("/topic/clear", topic_clear_handler)
    app.router.add_get("/notes/list", notes_list_handler)
    app.router.add_post("/hot_moment/cancel", hot_moment_cancel_handler)
    app.router.add_post("/query", query_handler)
    app.router.add_post("/query/trigger", trigger_query_handler)
    app.router.add_post("/transcribe", transcribe_handler)
    app.router.add_post("/summarize", summarize_handler)
    app.router.add_post("/extract-task", extract_task_handler)
    app.router.add_get("/tasks", tasks_get_handler)
    app.router.add_post("/brief", brief_handler)
    app.router.add_post("/debug/say", debug_say_handler)
    app.router.add_get("/conversations", conversations_handler)
    app.router.add_post("/conversation/attach", conversation_attach_handler)
    app.router.add_post("/conversation/detach", conversation_detach_handler)
    app.router.add_post("/proactive", proactive_handler)
    app.router.add_get("/proactive", proactive_status_handler)
    app.router.add_post("/session/start", session_start_handler)
    app.router.add_post("/session/stop", session_stop_handler)
    app.router.add_get("/vendors", vendors_list_handler)
    app.router.add_get("/trackers", trackers_list_handler)
    app.router.add_post("/trackers", trackers_create_handler)
    app.router.add_put("/trackers/{tracker_id}", trackers_update_handler)
    app.router.add_put("/trackers/{tracker_id}/chat-enabled", trackers_chat_enabled_handler)
    app.router.add_delete("/trackers/{tracker_id}", trackers_delete_handler)
    app.router.add_post("/trackers/{tracker_id}/activate", trackers_activate_handler)
    app.router.add_post("/trackers/{tracker_id}/connect", trackers_connect_handler)
    app.router.add_post("/trackers/{tracker_id}/test", trackers_test_handler)
    app.router.add_get("/provider", provider_get_handler)
    app.router.add_post("/provider", provider_post_handler)
    app.router.add_get("/workspace", workspace_handler)
    app.router.add_get("/workspaces", workspaces_handler)
    app.router.add_post("/workspace/activate", workspace_activate_handler)
    app.router.add_post("/workspace/create", workspace_create_handler)
    app.router.add_post("/workspace/rename", workspace_rename_handler)
    app.router.add_post("/workspace/delete", workspace_delete_handler)
    app.router.add_get("/version", version_handler)
    app.router.add_post("/daemon/restart", daemon_restart_handler)
    app.router.add_post("/update/check", update_check_handler)
    app.router.add_post("/update/now", update_now_handler)
    app.router.add_get("/logs/tail", logs_tail_handler)
    app.router.add_get("/launcher.command", launcher_command_handler)
    app.router.add_post("/install-app", install_app_handler)
    app.router.add_get("/install-app/status", install_app_status_handler)
    app.router.add_post("/shutdown", shutdown_handler)
    app.router.add_get("/library", library_get_handler)
    app.router.add_post("/library/reveal", library_reveal_handler)
    app.router.add_get("/library/item", library_item_handler)
    app.router.add_post("/library/transcribe", library_transcribe_handler)
    app.router.add_post("/library/summarize", library_summarize_handler)
    app.router.add_post("/library/rename", library_rename_handler)
    app.router.add_post("/library/delete", library_delete_handler)
    app.router.add_post("/library/search", library_search_handler)
    app.router.add_post("/library/favorite", library_favorite_handler)
    app.router.add_post("/library/kb", library_kb_handler)
    app.router.add_post("/library/note", library_note_handler)
    app.router.add_post("/library/text", library_text_post_handler)
    app.router.add_get("/library/audio", library_audio_handler)
    app.router.add_get("/references/search", references_search_handler)
    app.router.add_get("/library/speakers", library_speakers_get_handler)
    app.router.add_post("/library/speakers", library_speakers_post_handler)
    app.router.add_post("/library/speakers/suggest", library_speakers_suggest_handler)
    app.router.add_get("/action-items", action_items_get_handler)
    app.router.add_post("/action-items", action_items_create_handler)
    app.router.add_patch("/action-items/{item_id}", action_items_patch_handler)
    app.router.add_delete("/action-items/{item_id}", action_items_delete_handler)
    app.router.add_post(
        "/library/{meeting_id}/action-items/extract",
        action_items_extract_handler,
    )
    from meeting_helper.chat import handlers as chat_handlers
    app.router.add_get("/chat/threads", chat_handlers.threads_list_handler)
    app.router.add_post("/chat/threads", chat_handlers.threads_create_handler)
    app.router.add_get("/chat/threads/{thread_id}", chat_handlers.threads_get_handler)
    app.router.add_post("/chat/threads/{thread_id}/rename", chat_handlers.threads_rename_handler)
    app.router.add_post("/chat/threads/{thread_id}/model", chat_handlers.threads_model_handler)
    app.router.add_delete("/chat/threads/{thread_id}", chat_handlers.threads_delete_handler)
    app.router.add_get("/chat/state", chat_handlers.state_get_handler)
    app.router.add_post("/chat/state", chat_handlers.state_set_handler)
    app.router.add_post("/chat/threads/{thread_id}/messages", chat_handlers.messages_post_handler)
    app.router.add_post("/chat/threads/{thread_id}/confirm", chat_handlers.messages_confirm_handler)
    app.router.add_get("/chat/memory", chat_handlers.memory_list_handler)
    app.router.add_post("/chat/memory", chat_handlers.memory_add_handler)
    app.router.add_post("/chat/memory/{mem_id}", chat_handlers.memory_update_handler)
    app.router.add_delete("/chat/memory/{mem_id}", chat_handlers.memory_delete_handler)
    # Skills (ticket #269) — slash-command prompt blueprints.
    app.router.add_get("/skills", chat_handlers.skills_list_handler)
    app.router.add_post("/skills", chat_handlers.skills_create_handler)
    app.router.add_patch("/skills/{skill_id}", chat_handlers.skills_update_handler)
    app.router.add_delete("/skills/{skill_id}", chat_handlers.skills_delete_handler)
    # MH-40 embedded task manager — REST endpoints under /api/mh-tasks/*.
    from meeting_helper.server import mh_tasks_routes as _mh_tasks
    _mh_tasks.register(app)
    # MH-40 local MCP server — POST /mcp JSON-RPC for agent access.
    from meeting_helper.server import mcp_server as _mcp_server
    _mcp_server.register(app)
    app.router.add_get("/ws", ws_handler)
