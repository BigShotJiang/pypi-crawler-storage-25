"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "6.2.2"
