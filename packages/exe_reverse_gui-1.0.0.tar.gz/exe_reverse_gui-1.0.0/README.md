# EXE Reverse GUI

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/)

**EXE Reverse GUI** is a cross‑platform desktop application with a clean graphical interface (inspired by auto‑py‑to‑exe) that extracts and decompiles PyInstaller‑packaged executables.  
It leverages **pyinstxtractor‑ng** to unpack the EXE and **depyo** to decompile the resulting `.pyc` files back to readable Python source code, all running in separate processes so the UI remains responsive.

> **EXE Reverse GUI** 是一个跨平台的桌面应用程序，提供简洁的图形界面，用于提取并反编译 PyInstaller 打包的可执行文件。  
> 它调用 **pyinstxtractor‑ng** 解包 EXE，然后使用 **depyo** 将解包得到的 `.pyc` 字节码反编译为可读的 Python 源代码，所有操作均在独立进程中运行，保证界面流畅。

---

## Features / 功能

- **Unpack EXE** – Supports PyInstaller archives, including encrypted ones.  
  **解包 EXE** – 支持 PyInstaller 归档，包括加密文件。

- **Decompile .pyc** – Automatically decompiles all extracted `.pyc` files to `.py`.  
  **反编译 .pyc** – 自动将所有解包得到的 `.pyc` 文件反编译为 `.py` 源码。

- **Smart Cleanup** – Removes standard‑library files, Python interpreter DLLs, `.pyd` / `.so` extensions, and other non‑user content, keeping only your original source code and resource files (like images, audio, video).  
  **智能清理** – 自动删除标准库文件、Python 解释器 DLL、`.pyd`/`.so` 扩展等非用户内容，只保留您的源代码和资源文件（如图片、音频、视频）。

- **Real‑time Log** – Watch every step in the built‑in console.  
  **实时日志** – 内置控制台实时显示每一步操作。

- **Multi‑language** – Chinese, English, Russian, French.  
  **多语言支持** – 中文、English、Русский、Français。

- **Advanced Options** – Enable debug mode, generate `.pyasm` assembly, keep raw `.pyc` files, etc.  
  **高级选项** – 支持调试模式、生成 `.pyasm` 汇编文件、保留原始 `.pyc` 等。

- **Fault Recovery** – Automatic retry dialog on failure, process timeout detection.  
  **故障恢复** – 失败时自动弹出重试对话框，内置进程超时检测。

---

## Installation / 安装

Make sure you have **Python 3.8 or later** installed.  
请确保已安装 **Python 3.8 或更高版本**。

### From PyPI (recommended) / 通过 PyPI 安装（推荐）
```bash
pip install exe-reverse-gui
```

### From source / 从源码安装
```bash
git clone https://github.com/hyy-aaa/exe-reverse-gui.git
cd exe-reverse-gui
pip install .
```

After installation, the command `exe-reverse-gui` will be available in your terminal.  
安装完成后，终端中会出现 `exe-reverse-gui` 命令。

---

## Usage / 使用方法

Simply run:  
直接运行：

```bash
exe-reverse-gui
```

or via Python module:  
或通过 Python 模块运行：

```bash
python -m exe_reverse_gui
```

### Steps / 操作步骤

1. Choose the EXE file you want to analyse.  
   选择要分析的 EXE 文件。

2. Select an output directory (defaults to the EXE location).  
   选择输出目录（默认为 EXE 所在目录）。

3. (Optional) Click **Advanced Options…** to fine‑tune the extraction/decompilation parameters.  
   可选：点击**高级选项…** 微调提取/反编译参数。

4. Click **Start Extraction** – the tool will unpack the EXE, decompile all `.pyc` files, merge results, and clean up unnecessary files.  
   点击**开始提取** – 工具将自动解包 EXE、反编译所有 `.pyc`、合并输出、并清理多余文件。

5. When finished, a dialog will point you to the folder containing your recovered source code.  
   完成后会弹出对话框，指引您前往存放恢复后源代码的文件夹。

---

## Dependencies / 依赖

- [PyQt6](https://pypi.org/project/PyQt6/) (>=6.5)  
- [pyinstxtractor‑ng](https://github.com/pyinstxtractor/pyinstxtractor-ng)  
- [depyo](https://github.com/erev0s/depyo)

All are installed automatically when you install `exe-reverse-gui`.  
所有依赖都会在安装 `exe-reverse-gui` 时自动安装。

---

## License / 许可证

This project is licensed under the **MIT License** – see the [LICENSE](LICENSE) file for details.  
本项目采用 **MIT 许可证** – 详见 [LICENSE](LICENSE) 文件。

---

## Contributing / 贡献

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.  
欢迎提交 Pull Request。如有重大改动，请先创建 Issue 讨论。

---

## Disclaimer / 免责声明

This tool is intended for **legal reverse engineering and educational purposes only**.  
Respect the intellectual property rights of others.  
本工具仅供**合法的逆向工程和学习研究**使用，请尊重他人的知识产权。