import os
import shutil
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
    QLabel, QLineEdit, QPushButton, QFileDialog, QCheckBox,
    QComboBox, QPlainTextEdit, QSplitter, QDialog, QDialogButtonBox,
    QGridLayout, QMessageBox
)
from PyQt6.QtCore import Qt
from exe_reverse_gui.worker import ExtractorWorker
from exe_reverse_gui.i18n import I18nManager
from exe_reverse_gui.config import ConfigManager

LANG_MAP = {
    "zh_CN": "中文",
    "en": "English",
    "ru": "Русский",
    "fr": "Français"
}

# 需要删除的已知非用户目录（标准库/PyInstaller内部）
NON_USER_DIRS = {
    "email", "importlib", "logging", "PyInstaller", "PyQt6", "urllib",
    "_pyi_rth_utils", "decompiled", "encodings", "collections", "concurrent",
    "ctypes", "curses", "dbm", "distutils", "html", "http", "idlelib",
    "json", "lib2to3", "multiprocessing", "pydoc_data", "site-packages",
    "sqlite3", "tkinter", "turtledemo", "unittest", "venv", "wsgiref",
    "xml", "xmlrpc", "zoneinfo",
}

# 明显不是用户代码的文件名（标准库 + PyInstaller 内部模块）
NON_USER_FILES = {
    "argparse", "ast", "base64", "bisect", "bz2", "calendar", "contextlib",
    "contextvars", "copy", "csv", "dataclasses", "datetime", "decimal", "dis",
    "fnmatch", "fractions", "getopt", "gettext", "gzip", "hashlib", "inspect",
    "ipaddress", "lzma", "numbers", "opcode", "pathlib", "pickle", "pkgutil",
    "pprint", "pyiboot01_bootstrap", "pyimod01_archive", "pyimod02_importers",
    "pyimod03_ctypes", "pyimod04_pywin32", "pyi_rth_inspect", "pyi_rth_pkgutil",
    "pyi_rth_pyqt6", "py_compile", "quopri", "random", "selectors", "shutil",
    "signal", "socket", "statistics", "string", "stringprep", "struct",
    "subprocess", "tarfile", "tempfile", "textwrap", "threading", "token",
    "tokenize", "tracemalloc", "typing", "zipfile", "zipimport",
    "_compat_pickle", "_compression", "_pydecimal", "_py_abc", "_strptime",
    "_threading_local", "abc", "codecs", "collections", "copyreg",
    "encodings", "enum", "functools", "genericpath", "heapq",
    "io", "keyword", "linecache", "locale", "ntpath", "operator",
    "os", "posixpath", "re", "reprlib", "sre_compile", "sre_constants",
    "sre_parse", "stat", "sys", "traceback", "types", "weakref", "warnings",
    "email", "importlib", "logging", "urllib", "PyQt6",
    "_pyi_rth_utils", "PyInstaller",
    "concurrent", "asyncio", "json", "html", "http", "xml",
}

class AdvancedSettingsDialog(QDialog):
    def __init__(self, i18n, config, parent=None):
        super().__init__(parent)
        self.i18n = i18n
        self.config = config
        self.setWindowTitle(i18n.tr('advanced_title', '高级选项'))
        self.setModal(True)
        self.resize(400, 300)
        self.init_ui()
        self.load_settings()

    def init_ui(self):
        layout = QVBoxLayout(self)
        self.group = QGroupBox(self.i18n.tr('advanced_extract_group', '提取与反编译参数'))
        grid = QGridLayout(self.group)

        self.debug_cb = QCheckBox(self.i18n.tr('advanced_debug', '调试模式 (-d)'))
        self.asm_cb = QCheckBox(self.i18n.tr('advanced_asm', '生成汇编文件 (--asm)'))
        self.raw_cb = QCheckBox(self.i18n.tr('advanced_raw', '保留原始 .pyc (--raw)'))
        self.skip_cb = QCheckBox(self.i18n.tr('advanced_skip', '仅反汇编，不生成源码 (--skip-source-gen)'))

        self.pyver_label = QLabel(self.i18n.tr('advanced_pyver', 'Python 字节码版本 (如 3.11, 留空自动):'))
        self.pyver_edit = QLineEdit()
        self.pyver_edit.setPlaceholderText("3.11")

        grid.addWidget(self.debug_cb, 0, 0, 1, 2)
        grid.addWidget(self.asm_cb, 1, 0, 1, 2)
        grid.addWidget(self.raw_cb, 2, 0, 1, 2)
        grid.addWidget(self.skip_cb, 3, 0, 1, 2)
        grid.addWidget(self.pyver_label, 4, 0)
        grid.addWidget(self.pyver_edit, 4, 1)

        layout.addWidget(self.group)

        hint = QLabel(self.i18n.tr('advanced_hint', '注意: 启用 --raw 时，完成后“清理”将保留 .pyc 文件'))
        hint.setWordWrap(True)
        layout.addWidget(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.save_and_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def load_settings(self):
        adv = self.config.get_advanced()
        self.debug_cb.setChecked(adv.get('debug', False))
        self.asm_cb.setChecked(adv.get('asm', False))
        self.raw_cb.setChecked(adv.get('raw', False))
        self.skip_cb.setChecked(adv.get('skip_source_gen', False))
        self.pyver_edit.setText(adv.get('py_version', ''))

    def save_and_accept(self):
        adv = {
            'debug': self.debug_cb.isChecked(),
            'asm': self.asm_cb.isChecked(),
            'raw': self.raw_cb.isChecked(),
            'skip_source_gen': self.skip_cb.isChecked(),
            'py_version': self.pyver_edit.text().strip()
        }
        self.config.set_advanced(adv)
        self.accept()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.i18n = I18nManager()
        self.config = ConfigManager()
        self.i18n.set_language(self.config.get('language', 'zh_CN'))
        self.worker = ExtractorWorker(self)

        self.extract_done = False
        self.decompile_done = False
        self.extract_dir = None
        self.step_in_progress = None
        self.last_extract_args = None
        self.last_decompile_args = None

        self.init_ui()
        self.connect_signals()
        self.update_ui_text()

        # 自动勾选“完成后清理多余资源”
        self.cleanup_cb.setChecked(True)
        self.config.set('cleanup_after', True)

    def init_ui(self):
        self.setWindowTitle("EXE Reverse GUI")
        self.resize(1000, 650)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # 左侧面板
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(10, 10, 10, 10)

        lang_layout = QHBoxLayout()
        self.lang_label = QLabel("语言")
        self.lang_combo = QComboBox()
        for code, name in LANG_MAP.items():
            self.lang_combo.addItem(name, code)
        current_lang = self.i18n.current_lang
        idx = self.lang_combo.findData(current_lang)
        if idx >= 0:
            self.lang_combo.setCurrentIndex(idx)
        lang_layout.addWidget(self.lang_label)
        lang_layout.addWidget(self.lang_combo)
        lang_layout.addStretch()
        left_layout.addLayout(lang_layout)

        file_group = QGroupBox()
        file_layout = QVBoxLayout(file_group)
        exe_layout = QHBoxLayout()
        self.exe_label = QLabel("选择 EXE 文件")
        self.exe_edit = QLineEdit()
        self.exe_edit.setReadOnly(True)
        self.exe_btn = QPushButton("...")
        self.exe_btn.setFixedWidth(30)
        exe_layout.addWidget(self.exe_label)
        exe_layout.addWidget(self.exe_edit)
        exe_layout.addWidget(self.exe_btn)
        file_layout.addLayout(exe_layout)

        out_layout = QHBoxLayout()
        self.out_label = QLabel("输出目录")
        self.out_edit = QLineEdit()
        self.out_edit.setReadOnly(True)
        saved_dir = self.config.get('output_dir', '')
        if saved_dir:
            self.out_edit.setText(saved_dir)
        self.out_btn = QPushButton("...")
        self.out_btn.setFixedWidth(30)
        out_layout.addWidget(self.out_label)
        out_layout.addWidget(self.out_edit)
        out_layout.addWidget(self.out_btn)
        file_layout.addLayout(out_layout)
        left_layout.addWidget(file_group)

        # 基本选项组（只保留清理选项）
        options_group = QGroupBox(self.i18n.tr('options_group', '基本选项'))
        options_layout = QVBoxLayout(options_group)
        self.cleanup_cb = QCheckBox(self.i18n.tr('cleanup_after', '完成后清理多余资源'))
        self.cleanup_cb.setChecked(self.config.get('cleanup_after', True))
        options_layout.addWidget(self.cleanup_cb)
        left_layout.addWidget(options_group)

        self.adv_btn = QPushButton(self.i18n.tr('advanced_btn', '高级选项...'))
        left_layout.addWidget(self.adv_btn)

        self.start_btn = QPushButton(self.i18n.tr('start_btn', '开始提取'))
        self.start_btn.setMinimumHeight(40)
        self.start_btn.setStyleSheet("QPushButton { font-weight: bold; }")
        left_layout.addWidget(self.start_btn)
        left_layout.addStretch()
        splitter.addWidget(left_panel)

        # 右侧日志
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(10, 10, 10, 10)
        self.log_label = QLabel(self.i18n.tr('log_label', '输出日志'))
        self.log_output = QPlainTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("background-color: #1e1e1e; color: #dcdcdc; font-family: Consolas, monospace;")
        right_layout.addWidget(self.log_label)
        right_layout.addWidget(self.log_output)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        self.setCentralWidget(splitter)

    def connect_signals(self):
        self.exe_btn.clicked.connect(self.choose_exe)
        self.out_btn.clicked.connect(self.choose_output_dir)
        self.lang_combo.currentIndexChanged.connect(self.on_language_changed)
        self.cleanup_cb.stateChanged.connect(self.save_checkbox_config)
        self.adv_btn.clicked.connect(self.show_advanced_dialog)
        self.start_btn.clicked.connect(self.start_process)
        self.worker.output_line.connect(self.append_log)
        self.worker.finished.connect(self.on_step_finished)
        self.worker.error_occurred.connect(self.append_error)

    def choose_exe(self):
        file_path, _ = QFileDialog.getOpenFileName(self, self.i18n.tr('select_exe_title', '选择 EXE 文件'), "", "可执行文件 (*.exe);;所有文件 (*)")
        if file_path:
            self.exe_edit.setText(file_path)
            if not self.out_edit.text():
                self.out_edit.setText(os.path.dirname(file_path))

    def choose_output_dir(self):
        dir_path = QFileDialog.getExistingDirectory(self, self.i18n.tr('select_dir_title', '选择输出目录'))
        if dir_path:
            self.out_edit.setText(dir_path)
            self.config.set('output_dir', dir_path)

    def on_language_changed(self, index):
        lang_code = self.lang_combo.currentData()
        if lang_code:
            self.i18n.set_language(lang_code)
            self.config.set('language', lang_code)
            self.update_ui_text()

    def save_checkbox_config(self):
        self.config.set('cleanup_after', self.cleanup_cb.isChecked())

    def show_advanced_dialog(self):
        dialog = AdvancedSettingsDialog(self.i18n, self.config, self)
        dialog.exec()

    def update_ui_text(self):
        self.setWindowTitle(self.i18n.tr('window_title', 'EXE 反编译工具'))
        self.lang_label.setText(self.i18n.tr('lang_label', '语言'))
        self.exe_label.setText(self.i18n.tr('select_exe', '选择 EXE 文件'))
        self.out_label.setText(self.i18n.tr('output_dir', '输出目录'))
        self.cleanup_cb.setText(self.i18n.tr('cleanup_after', '完成后清理多余资源'))
        self.adv_btn.setText(self.i18n.tr('advanced_btn', '高级选项...'))
        self.start_btn.setText(self.i18n.tr('start_btn', '开始提取'))
        self.log_label.setText(self.i18n.tr('log_label', '输出日志'))

    def append_log(self, text):
        self.log_output.appendPlainText(text)

    def append_error(self, text):
        self.log_output.appendPlainText(f"[错误] {text}")

    def start_process(self):
        exe_path = self.exe_edit.text().strip()
        output_dir = self.out_edit.text().strip()

        if not exe_path or not os.path.isfile(exe_path):
            self.append_log("[错误] 请选择有效的EXE文件")
            return
        if not output_dir:
            self.append_log("[错误] 请选择输出目录")
            return

        self.log_output.clear()
        self.extract_done = False
        self.decompile_done = False
        self.extract_dir = None
        self.step_in_progress = None
        self.start_btn.setEnabled(False)

        adv = self.config.get_advanced()
        self.last_extract_args = (exe_path, output_dir, adv.get('debug', False))
        self.last_decompile_args = None

        self.append_log(self.i18n.tr('log_extract_start', '▶ 正在解包 EXE...'))
        self.step_in_progress = 'extract'
        self.worker.start_extract(*self.last_extract_args)

    def on_step_finished(self, exit_code):
        if self.step_in_progress == 'extract':
            if exit_code != 0:
                self.append_log(self.i18n.tr('log_extract_failed', '✗ 解包失败，请检查日志'))
                retry = QMessageBox.question(
                    self,
                    self.i18n.tr('retry_title', '操作失败'),
                    self.i18n.tr('retry_extract_failed', '解包失败，是否重试？'),
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                )
                if retry == QMessageBox.StandardButton.Yes:
                    self.append_log(self.i18n.tr('log_retry', '↻ 正在重试解包...'))
                    self.worker.start_extract(*self.last_extract_args)
                    return
                else:
                    self.start_btn.setEnabled(True)
                    self.step_in_progress = None
                    return

            self.extract_done = True
            self.append_log(self.i18n.tr('log_extract_success', '✓ 解包完成'))

            # 定位提取目录
            exe_basename = os.path.basename(self.exe_edit.text())
            out_dir = self.out_edit.text()
            candidates = [
                os.path.join(out_dir, exe_basename + "_extracted"),
                os.path.join(out_dir, os.path.splitext(exe_basename)[0] + "_extracted")
            ]
            found_dir = None
            for d in candidates:
                if os.path.isdir(d) and self._dir_contains_pyc(d):
                    found_dir = d
                    break
            if not found_dir:
                for item in os.listdir(out_dir):
                    full = os.path.join(out_dir, item)
                    if os.path.isdir(full) and item.endswith('_extracted') and self._dir_contains_pyc(full):
                        found_dir = full
                        break
            if not found_dir and self._dir_contains_pyc(out_dir):
                found_dir = out_dir

            if not found_dir:
                self.append_log("[错误] 未找到包含 .pyc 文件的目录，无法继续反编译。")
                self.start_btn.setEnabled(True)
                self.step_in_progress = None
                return

            self.extract_dir = found_dir
            self.append_log(f"[信息] 反编译目标目录: {self.extract_dir}")

            # 直接收集所有 .pyc 文件并启动反编译（不再检查复选框）
            pyc_files = []
            for root, dirs, files in os.walk(self.extract_dir):
                for f in files:
                    if f.endswith('.pyc'):
                        pyc_files.append(os.path.join(root, f))
            if not pyc_files:
                self.append_log("[错误] 提取目录中没有 .pyc 文件，无法反编译。")
                self.start_btn.setEnabled(True)
                self.step_in_progress = None
                return
            self.append_log(f"[信息] 找到 {len(pyc_files)} 个 .pyc 文件，开始逐个反编译...")
            adv = self.config.get_advanced()
            self.last_decompile_args = (
                pyc_files,
                self.out_edit.text(),
                adv.get('asm', False),
                adv.get('raw', False),
                adv.get('skip_source_gen', False),
                adv.get('py_version') or None
            )
            self.step_in_progress = 'decompile'
            self.worker.start_decompile_file_list(*self.last_decompile_args)

        elif self.step_in_progress == 'decompile':
            if exit_code != 0:
                self.append_log(self.i18n.tr('log_decompile_failed', '✗ 反编译全部失败，请检查日志'))
                retry = QMessageBox.question(
                    self,
                    self.i18n.tr('retry_title', '操作失败'),
                    self.i18n.tr('retry_decompile_failed', '反编译未成功，是否重试？'),
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                )
                if retry == QMessageBox.StandardButton.Yes:
                    self.append_log(self.i18n.tr('log_retry', '↻ 正在重试反编译...'))
                    self.worker.start_decompile_file_list(*self.last_decompile_args)
                    return
                else:
                    self._merge_decompiled_output()
                    self.final_cleanup()
                    self.show_done_message()
                    self.start_btn.setEnabled(True)
                    self.step_in_progress = None
                    return
            else:
                self.decompile_done = True
                self.append_log(self.i18n.tr('log_decompile_success', '✓ 反编译完成'))
                self._merge_decompiled_output()
                self.final_cleanup()
                self.show_done_message()
                self.start_btn.setEnabled(True)
                self.step_in_progress = None

    def _dir_contains_pyc(self, dir_path):
        for root, dirs, files in os.walk(dir_path):
            for f in files:
                if f.endswith('.pyc'):
                    return True
        return False

    def _merge_decompiled_output(self):
        if not self.extract_dir or not os.path.isdir(self.extract_dir):
            return
        for root, dirs, files in os.walk(self.extract_dir, topdown=False):
            if os.path.basename(root) == 'decompiled':
                parent = os.path.dirname(root)
                for item in os.listdir(root):
                    src = os.path.join(root, item)
                    dst = os.path.join(parent, item)
                    if not os.path.exists(dst):
                        shutil.move(src, dst)
                try:
                    os.rmdir(root)
                    self.append_log(f"  已合并 {root}")
                except Exception as e:
                    self.append_log(f"  合并 {root} 时出错: {e}")

    def final_cleanup(self):
        if self.cleanup_cb.isChecked() and self.extract_dir:
            self.append_log(self.i18n.tr('log_cleanup', '▶ 正在清理多余资源...'))
            try:
                build_dir = os.path.join(self.out_edit.text(), 'build')
                if os.path.isdir(build_dir):
                    shutil.rmtree(build_dir)
                    self.append_log("  已删除 build 目录")
                adv = self.config.get_advanced()
                self._clean_non_user_files()
                if not adv.get('raw', False):
                    for root, dirs, files in os.walk(self.extract_dir):
                        for file in files:
                            if file.endswith('.pyc'):
                                try:
                                    os.remove(os.path.join(root, file))
                                except Exception:
                                    pass
                self.append_log(self.i18n.tr('log_cleanup_done', '✓ 清理完成'))
            except Exception as e:
                self.append_log(f"[警告] 清理时发生错误: {e}")

    def _clean_non_user_files(self):
        """删除非用户代码文件、解释器/库文件，并清理空目录"""
        removed_files = 0
        removed_dirs = 0

        # 第一遍：直接删除整个已知非用户目录
        for root, dirs, files in os.walk(self.extract_dir, topdown=False):
            if os.path.basename(root) in NON_USER_DIRS:
                try:
                    shutil.rmtree(root)
                    removed_dirs += 1
                except Exception:
                    pass
                continue

        # 第二遍：删除文件
        for root, dirs, files in os.walk(self.extract_dir):
            for file in files:
                file_path = os.path.join(root, file)
                name, ext = os.path.splitext(file)

                # 标准库/PyInstaller 内部源码
                if ext in ('.py', '.pyc') and name in NON_USER_FILES:
                    try:
                        os.remove(file_path)
                        removed_files += 1
                    except Exception:
                        pass
                # DLL/pyd/so/dylib/pyz/zip
                elif ext in ('.dll', '.pyd', '.so', '.dylib', '.pyz', '.zip'):
                    try:
                        os.remove(file_path)
                        removed_files += 1
                    except Exception:
                        pass
                # 特定解释器/运行时文件
                elif file in ('python3.dll', 'python311.dll', 'VCRUNTIME140.dll',
                              'VCRUNTIME140_1.dll', 'ucrtbase.dll',
                              'libcrypto-1_1.dll', 'libcrypto-3-x64.dll',
                              'libssl-3-x64.dll', 'base_library.zip', 'PYZ-00.pyz'):
                    try:
                        os.remove(file_path)
                        removed_files += 1
                    except Exception:
                        pass

        # 删除空目录
        for root, dirs, files in os.walk(self.extract_dir, topdown=False):
            if root != self.extract_dir and not os.listdir(root):
                try:
                    os.rmdir(root)
                    removed_dirs += 1
                except Exception:
                    pass

        if removed_files > 0:
            self.append_log(f"  已删除 {removed_files} 个非用户文件")
        if removed_dirs > 0:
            self.append_log(f"  已删除 {removed_dirs} 个非用户目录")

    def show_done_message(self):
        msg = self.i18n.tr('done_message', '反编译已完成！\n请到提取目录下查找您的源代码文件。')
        QMessageBox.information(self, self.i18n.tr('window_title', 'EXE 反编译工具'), msg)