import json
import os

class I18nManager:
    def __init__(self, locales_dir=None):
        if locales_dir is None:
            locales_dir = os.path.join(os.path.dirname(__file__), 'locales')
        self.locales_dir = locales_dir
        self.translations = {}
        self.current_lang = 'zh_CN'
        self._load_all()

    def _load_all(self):
        if not os.path.isdir(self.locales_dir):
            return
        for fname in os.listdir(self.locales_dir):
            if fname.endswith('.json'):
                lang = fname[:-5]
                with open(os.path.join(self.locales_dir, fname), 'r', encoding='utf-8') as f:
                    self.translations[lang] = json.load(f)

    def set_language(self, lang):
        if lang in self.translations:
            self.current_lang = lang

    def tr(self, key, default=""):
        return self.translations.get(self.current_lang, {}).get(key, default)

    def available_languages(self):
        return list(self.translations.keys())