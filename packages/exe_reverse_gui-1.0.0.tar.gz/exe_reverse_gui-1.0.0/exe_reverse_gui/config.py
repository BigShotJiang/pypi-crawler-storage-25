import json
import os

CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".exe_reverse_gui_config.json")

DEFAULT_CONFIG = {
    "output_dir": "",
    "decompile_all": False,
    "cleanup_after": True,
    "language": "zh_CN",
    "advanced": {
        "debug": False,
        "asm": False,
        "raw": False,
        "skip_source_gen": False,
        "py_version": ""
    }
}

class ConfigManager:
    def __init__(self):
        self._config = DEFAULT_CONFIG.copy()
        self.load()

    def load(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                    saved = json.load(f)
                self._config = self._deep_merge(DEFAULT_CONFIG.copy(), saved)
            except Exception:
                pass

    def _deep_merge(self, base, override):
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                base[key] = self._deep_merge(base[key], value)
            else:
                base[key] = value
        return base

    def save(self):
        os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(self._config, f, indent=2)

    def get(self, key, default=None):
        return self._config.get(key, default)

    def set(self, key, value):
        self._config[key] = value
        self.save()

    def get_advanced(self):
        return self._config.get("advanced", {}).copy()

    def set_advanced(self, advanced_dict):
        self._config["advanced"] = advanced_dict
        self.save()