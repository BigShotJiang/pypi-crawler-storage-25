from PyQt6.QtCore import QProcess, QTimer, pyqtSignal, QObject

class ExtractorWorker(QObject):
    output_line = pyqtSignal(str)
    finished = pyqtSignal(int)
    error_occurred = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.process = None
        self._current_task = None
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._on_timeout)
        self._decompile_queue = []
        self._decompile_args = {}
        self._failed_count = 0
        self._total_files = 0

    def start_extract(self, exe_path, output_dir, debug=False):
        self._kill_process()
        self.process = QProcess(self)
        self.process.setWorkingDirectory(output_dir)
        self.process.readyReadStandardOutput.connect(self._on_stdout)
        self.process.readyReadStandardError.connect(self._on_stderr)
        self.process.finished.connect(self._on_finished)
        self.process.errorOccurred.connect(self._on_error)
        self._current_task = 'extract'

        args = [exe_path]
        if debug:
            args.insert(0, '-d')
        self.output_line.emit(f"[启动] pyinstxtractor-ng {' '.join(args)}")
        self.process.start('pyinstxtractor-ng', args)
        self._start_timeout(120)

    def start_decompile_file_list(self, file_list, output_dir, asm=False, raw=False, skip_source_gen=False, py_version=None):
        self._kill_process()
        self._current_task = 'decompile'
        self._failed_count = 0
        self._decompile_queue = file_list[:]
        self._total_files = len(file_list)
        self._decompile_args = {
            'output_dir': output_dir,
            'asm': asm,
            'raw': raw,
            'skip_source_gen': skip_source_gen,
        }
        self._process_next_decompile()

    def _process_next_decompile(self):
        if not self._decompile_queue:
            if self._failed_count == self._total_files:
                exit_code = 1
            else:
                exit_code = 0
                if self._failed_count > 0:
                    self.output_line.emit(f"[信息] {self._failed_count}/{self._total_files} 个文件反编译失败，其余成功")
            self._current_task = None
            self.finished.emit(exit_code)
            return

        pyc_file = self._decompile_queue.pop(0)
        self.process = QProcess(self)
        self.process.setWorkingDirectory(self._decompile_args['output_dir'])
        self.process.readyReadStandardOutput.connect(self._on_stdout)
        self.process.readyReadStandardError.connect(self._on_stderr)
        self.process.finished.connect(self._on_single_decompile_finished)
        self.process.errorOccurred.connect(self._on_error)

        args = []
        if self._decompile_args.get('asm'):
            args.append('--asm')
        if self._decompile_args.get('raw'):
            args.append('--raw')
        if self._decompile_args.get('skip_source_gen'):
            args.append('--skip-source-gen')
        args.append(pyc_file)

        self.output_line.emit(f"[启动] depyo {' '.join(args)}")
        self.process.start('depyo', args)
        self._start_timeout(120)

    def _on_single_decompile_finished(self, exit_code):
        self._timer.stop()
        if self.process:
            self._read_remaining_output()
        if exit_code != 0:
            self._failed_count += 1
            self.output_line.emit(f"[错误] 处理失败，退出码 {exit_code}")
        self.process = None
        self._process_next_decompile()

    def stop(self):
        self._kill_process()

    def _kill_process(self):
        self._timer.stop()
        if self.process is not None:
            self.process.kill()
            self.process = None
        self._decompile_queue.clear()

    def _start_timeout(self, seconds):
        self._timer.stop()
        self._timer.start(seconds * 1000)

    def _on_stdout(self):
        data = self.process.readAllStandardOutput()
        text = bytes(data).decode('utf-8', errors='replace')
        for line in text.splitlines():
            if line.strip():
                self.output_line.emit(line.strip())
        self._start_timeout(60)

    def _on_stderr(self):
        data = self.process.readAllStandardError()
        text = bytes(data).decode('utf-8', errors='replace')
        for line in text.splitlines():
            if line.strip():
                self.output_line.emit(line.strip())
        self._start_timeout(60)

    def _on_finished(self, exit_code):
        self._timer.stop()
        self._current_task = None
        self.finished.emit(exit_code)

    def _on_error(self, error):
        self._timer.stop()
        err_msg = self.process.errorString()
        self.error_occurred.emit(f'进程错误: {err_msg}')
        self._current_task = None

    def _on_timeout(self):
        self.output_line.emit("[错误] 进程超时未响应，已自动终止")
        self._kill_process()
        self._current_task = None
        self.finished.emit(-1)

    def _read_remaining_output(self):
        if self.process is not None:
            self._on_stdout()
            self._on_stderr()