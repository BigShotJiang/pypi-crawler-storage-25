"""
EXE Reverse GUI - 基于PyQt6的EXE反编译工具
使用 pyinstxtractor-ng 和 depyo，通过独立进程运行
"""
__version__ = "1.0.0"