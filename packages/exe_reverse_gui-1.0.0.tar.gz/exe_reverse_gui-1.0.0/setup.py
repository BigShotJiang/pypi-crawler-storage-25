from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="exe-reverse-gui",
    version="1.0.0",
    author="hyy",
    author_email="hyy@hyysn.cn",
    description="A PyQt6 GUI tool to extract and decompile PyInstaller EXE files",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/hyy-aaa/exe-reverse-gui",
    packages=find_packages(),
    include_package_data=True,   # 包含 locales/*.json 等非py文件
    package_data={
        "exe_reverse_gui": ["locales/*.json"],
    },
    python_requires=">=3.8",
    install_requires=[
        "PyQt6>=6.5",
        "pyinstxtractor-ng",
        "depyo"
    ],
    entry_points={
        "console_scripts": [
            "exe-reverse-gui = exe_reverse_gui.__main__:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)