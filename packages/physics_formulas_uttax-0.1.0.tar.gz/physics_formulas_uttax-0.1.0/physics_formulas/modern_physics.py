from .constants import h, c

def photon_energy(frequency: float) -> float:
    """E = hf"""
    return h * frequency

def energy_mass(mass: float) -> float:
    """E = mc^2"""
    return mass * c**2

def wavelength_from_energy(E: float) -> float:
    """λ = hc / E"""
    return (h * c) / E