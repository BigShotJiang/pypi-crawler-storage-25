# Mechanics
from .mechanics import (
    force, weight, momentum, impulse,
    kinetic_energy, potential_energy,
    work, power, gravitational_force
)

# Kinematics
from .kinematics import velocity, acceleration

# Electricity
from .electricity import (
    voltage, current, resistance,
    electric_power, power_resistance, power_voltage
)

# Thermodynamics
from .thermodynamics import heat, ideal_gas_pressure, efficiency

# Optics
from .optics import mirror_formula, magnification

# Magnetism
from .magnetism import magnetic_force, force_on_wire

# Modern Physics
from .modern_physics import photon_energy, energy_mass, wavelength_from_energy

# Modules (optional access)
from . import mechanics, kinematics, electricity, thermodynamics
from . import optics, magnetism, modern_physics, constants

__all__ = [
    # Mechanics
    "force", "weight", "momentum", "impulse",
    "kinetic_energy", "potential_energy",
    "work", "power", "gravitational_force",

    # Kinematics
    "velocity", "acceleration",

    # Electricity
    "voltage", "current", "resistance",
    "electric_power", "power_resistance", "power_voltage",

    # Thermodynamics
    "heat", "ideal_gas_pressure", "efficiency",

    # Optics
    "mirror_formula", "magnification",

    # Magnetism
    "magnetic_force", "force_on_wire",

    # Modern Physics
    "photon_energy", "energy_mass", "wavelength_from_energy",

    # Modules
    "mechanics", "kinematics", "electricity",
    "thermodynamics", "optics", "magnetism",
    "modern_physics", "constants"
]