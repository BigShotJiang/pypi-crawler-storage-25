def wave_speed(frequency: float, wavelength: float) -> float:
    """v = fλ"""
    return frequency * wavelength

def frequency(speed: float, wavelength: float) -> float:
    """f = v / λ"""
    return speed / wavelength

def wavelength(speed: float, frequency: float) -> float:
    """λ = v / f"""
    return speed / frequency