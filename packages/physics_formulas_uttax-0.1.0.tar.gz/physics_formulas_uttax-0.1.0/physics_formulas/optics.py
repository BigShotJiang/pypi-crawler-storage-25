def mirror_formula(f: float, u: float) -> float:
    """1/f = 1/v + 1/u → returns v"""
    return 1 / ((1 / f) - (1 / u))

def magnification(v: float, u: float) -> float:
    """m = v/u"""
    return v / u