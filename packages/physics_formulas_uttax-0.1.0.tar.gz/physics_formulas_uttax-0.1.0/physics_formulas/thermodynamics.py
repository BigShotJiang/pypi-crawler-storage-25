from .constants import R

def heat(m: float, c: float, dT: float) -> float:
    """Q = mcΔT"""
    return m * c * dT

def ideal_gas_pressure(n: float, T: float, V: float) -> float:
    """P = nRT / V"""
    return n * R * T / V

def efficiency(output: float, input_energy: float) -> float:
    """η = output/input * 100"""
    return (output / input_energy) * 100