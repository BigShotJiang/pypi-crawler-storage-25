from .constants import g, G
from .utils import validate_nonzero

def force(mass: float, acceleration: float) -> float:
    """F = ma"""
    return mass * acceleration

def weight(mass: float) -> float:
    """W = mg"""
    return mass * g

def momentum(mass: float, velocity: float) -> float:
    """p = mv"""
    return mass * velocity

def impulse(force: float, time: float) -> float:
    """J = Ft"""
    return force * time

def kinetic_energy(mass: float, velocity: float) -> float:
    """KE = 1/2 mv^2"""
    return 0.5 * mass * velocity**2

def potential_energy(mass: float, height: float) -> float:
    """PE = mgh"""
    return mass * g * height

def work(force: float, displacement: float, angle: float = 0) -> float:
    """W = F s cos(theta)"""
    import math
    return force * displacement * math.cos(math.radians(angle))

def power(work: float, time: float) -> float:
    """P = W / t"""
    validate_nonzero(time=time)
    return work / time

def gravitational_force(m1: float, m2: float, r: float) -> float:
    """F = G m1 m2 / r^2"""
    validate_nonzero(r=r)
    return G * m1 * m2 / r**2