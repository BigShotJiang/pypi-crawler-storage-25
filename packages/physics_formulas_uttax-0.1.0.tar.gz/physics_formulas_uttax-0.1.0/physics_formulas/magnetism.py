def magnetic_force(q: float, v: float, B: float, theta: float) -> float:
    """F = qvB sin(theta)"""
    import math
    return q * v * B * math.sin(math.radians(theta))

def force_on_wire(I: float, L: float, B: float, theta: float) -> float:
    """F = BIL sin(theta)"""
    import math
    return B * I * L * math.sin(math.radians(theta))