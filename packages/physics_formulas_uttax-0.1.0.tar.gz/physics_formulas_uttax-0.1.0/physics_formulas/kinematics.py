from .utils import validate_nonzero

def velocity(displacement: float, time: float) -> float:
    """v = s / t"""
    validate_nonzero(time=time)
    return displacement / time

def acceleration(v_final: float, v_initial: float, time: float) -> float:
    """a = (v - u) / t"""
    validate_nonzero(time=time)
    return (v_final - v_initial) / time

def final_velocity(u: float, a: float, t: float) -> float:
    """v = u + at"""
    return u + a * t

def displacement(u: float, t: float, a: float) -> float:
    """s = ut + 0.5at^2"""
    return u * t + 0.5 * a * t**2

def velocity_squared(u: float, a: float, s: float) -> float:
    """v^2 = u^2 + 2as"""
    return u**2 + 2 * a * s