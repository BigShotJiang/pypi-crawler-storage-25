def validate_positive(**kwargs):
    for name, value in kwargs.items():
        if value <= 0:
            raise ValueError(f"{name} must be positive, got {value}")

def validate_nonzero(**kwargs):
    for name, value in kwargs.items():
        if value == 0:
            raise ValueError(f"{name} must not be zero")