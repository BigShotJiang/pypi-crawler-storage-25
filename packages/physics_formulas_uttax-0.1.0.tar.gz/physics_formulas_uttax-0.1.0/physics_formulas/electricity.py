from .utils import validate_nonzero

def voltage(current: float, resistance: float) -> float:
    """V = IR"""
    return current * resistance

def current(voltage: float, resistance: float) -> float:
    """I = V / R"""
    validate_nonzero(resistance=resistance)
    return voltage / resistance

def resistance(voltage: float, current: float) -> float:
    """R = V / I"""
    validate_nonzero(current=current)
    return voltage / current

def electric_power(voltage: float, current: float) -> float:
    """P = VI"""
    return voltage * current

def power_resistance(current: float, resistance: float) -> float:
    """P = I^2 R"""
    return current**2 * resistance

def power_voltage(voltage: float, resistance: float) -> float:
    """P = V^2 / R"""
    return voltage**2 / resistance