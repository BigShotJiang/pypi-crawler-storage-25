# Physics Formulas

A Python library containing 100+ physics formulas.

## Installation
pip install physics-formulas-uttax

## Usage
import physics_formulas as pf

pf.force(10, 9.8)