"""
Main SimplexClient class for the Simplex SDK.

This module provides the SimplexClient, which is the primary entry point
for interacting with the Simplex API.
"""

from __future__ import annotations

import json
from typing import Any

from simplex._http_client import HttpClient
from simplex.errors import WorkflowError
from simplex.types import (
    Add2FAConfigResponse,
    GetClinicalQuestionsResponse,
    SearchDrugsResponse,
    PauseSessionResponse,
    ResumeSessionResponse,
    RunWorkflowResponse,
    SearchWorkflowsResponse,
    SessionStatusResponse,
    StartEditorSessionResponse,
    StartRecordingResponse,
    StopRecordingResponse,
    UpdateWorkflowMetadataResponse,
)


class SimplexClient:
    """
    Main client for interacting with the Simplex API.

    This is the primary entry point for the SDK. It provides a flat API
    for all Simplex API functionality.

    Example:
        >>> from simplex import SimplexClient
        >>> client = SimplexClient(api_key="your-api-key")
        >>>
        >>> # Run a workflow
        >>> result = client.run_workflow("workflow-id", variables={"key": "value"})
        >>>
        >>> # Poll for completion
        >>> import time
        >>> while True:
        ...     status = client.get_session_status(result["session_id"])
        ...     if not status["in_progress"]:
        ...         break
        ...     time.sleep(1)
        >>>
        >>> if status["success"]:
        ...     print("Scraper outputs:", status["scraper_outputs"])
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.simplex.sh",
        timeout: int = 30,
        max_retries: int = 3,
        retry_delay: float = 1.0,
    ):
        """
        Initialize the Simplex client.

        Args:
            api_key: Your Simplex API key (required)
            base_url: Base URL for the API (default: "https://api.simplex.sh")
            timeout: Request timeout in seconds (default: 30)
            max_retries: Maximum number of retry attempts (default: 3)
            retry_delay: Delay between retries in seconds (default: 1.0)

        Raises:
            ValueError: If api_key is not provided
        """
        if not api_key:
            raise ValueError("api_key is required")

        self._http_client = HttpClient(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            retry_delay=retry_delay,
        )

    def run_workflow(
        self,
        workflow_id: str,
        variables: dict[str, Any] | None = None,
        metadata: str | None = None,
        webhook_url: str | None = None,
        files: list[str | tuple[str, Any]] | None = None,
    ) -> RunWorkflowResponse:
        """
        Run a workflow by its ID.

        Args:
            workflow_id: The ID of the workflow to run
            variables: Dictionary of variables to pass to the workflow
            metadata: Optional metadata string to attach to the workflow run
            webhook_url: Optional webhook URL for status updates
            files: Optional list of files to upload. Each item can be:
                - A file path string (e.g. "invoice.pdf")
                - A tuple of (filename, file_object) (e.g. ("invoice.pdf", open("invoice.pdf", "rb")))
                - A tuple of (filename, file_object, content_type) (e.g. ("invoice.pdf", open("invoice.pdf", "rb"), "application/pdf"))

        Returns:
            RunWorkflowResponse with session_id and other details

        Raises:
            WorkflowError: If the workflow fails to start

        Example:
            >>> result = client.run_workflow(
            ...     "workflow-id",
            ...     variables={"email": "user@example.com"},
            ...     files=["invoice.pdf"],
            ... )
            >>> print(f"Session ID: {result['session_id']}")
        """
        request_data: dict[str, Any] = {"workflow_id": workflow_id}

        if variables is not None:
            request_data["variables"] = variables
        if metadata is not None:
            request_data["metadata"] = metadata
        if webhook_url is not None:
            request_data["webhook_url"] = webhook_url

        try:
            if files:
                file_tuples = []
                open_handles = []
                try:
                    for f in files:
                        if isinstance(f, str):
                            fh = open(f, "rb")
                            open_handles.append(fh)
                            filename = f.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
                            file_tuples.append(("files", (filename, fh)))
                        elif isinstance(f, tuple) and len(f) == 2:
                            file_tuples.append(("files", f))
                        elif isinstance(f, tuple) and len(f) == 3:
                            file_tuples.append(("files", f))
                        else:
                            raise ValueError(f"Invalid file entry: {f!r}")

                    response: RunWorkflowResponse = self._http_client.post_multipart(
                        "/run_workflow",
                        data=request_data,
                        files=file_tuples,
                    )
                finally:
                    for fh in open_handles:
                        fh.close()
            else:
                response = self._http_client.post(
                    "/run_workflow",
                    data=request_data,
                )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to run workflow: {e}", workflow_id=workflow_id)

    def get_session_status(self, session_id: str) -> SessionStatusResponse:
        """
        Get the status of a session.

        Use this method to poll for workflow completion. The session is complete
        when `in_progress` is False.

        Args:
            session_id: The session ID to check

        Returns:
            SessionStatusResponse with status, metadata, and scraper outputs

        Raises:
            WorkflowError: If retrieving status fails

        Example:
            >>> status = client.get_session_status("session-123")
            >>> if not status["in_progress"]:
            ...     if status["success"]:
            ...         print("Success! Outputs:", status["scraper_outputs"])
            ...     else:
            ...         print("Failed")
        """
        try:
            response: SessionStatusResponse = self._http_client.get(
                f"/session/{session_id}/status"
            )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to get session status: {e}",
                session_id=session_id,
            )

    def download_session_files(
        self,
        session_id: str,
        filename: str | None = None,
    ) -> bytes:
        """
        Download files from a session.

        Downloads files that were created or downloaded during a workflow session.
        If no filename is specified, all files are downloaded as a zip archive.

        Args:
            session_id: ID of the session to download files from
            filename: Optional specific filename to download

        Returns:
            File content as bytes

        Raises:
            WorkflowError: If file download fails

        Example:
            >>> # Download all files as zip
            >>> zip_data = client.download_session_files("session-123")
            >>> with open("files.zip", "wb") as f:
            ...     f.write(zip_data)
            >>>
            >>> # Download specific file
            >>> pdf_data = client.download_session_files("session-123", "report.pdf")
        """
        try:
            params: dict[str, str] = {"session_id": session_id}
            if filename:
                params["filename"] = filename

            content = self._http_client.download_file("/download_session_files", params=params)

            # Check if the response is a JSON error
            try:
                text = content.decode("utf-8")
                data = json.loads(text)
                if isinstance(data, dict) and data.get("succeeded") is False:
                    raise WorkflowError(
                        data.get("error") or "Failed to download session files",
                        session_id=session_id,
                    )
            except (UnicodeDecodeError, json.JSONDecodeError):
                # Binary data (the file), which is what we want
                pass

            return content
        except WorkflowError:
            raise
        except Exception as e:
            raise WorkflowError(
                f"Failed to download session files: {e}",
                session_id=session_id,
            )

    def retrieve_session_replay(self, session_id: str) -> bytes:
        """
        Retrieve the session replay video for a completed session.

        Downloads a video (MP4) recording of the browser session after it
        has completed.

        Args:
            session_id: ID of the session to retrieve replay for

        Returns:
            Video content as bytes (MP4 format)

        Raises:
            WorkflowError: If retrieving session replay fails

        Example:
            >>> video_data = client.retrieve_session_replay("session-123")
            >>> with open("replay.mp4", "wb") as f:
            ...     f.write(video_data)
        """
        try:
            content = self._http_client.download_file(f"/retrieve_session_replay/{session_id}")
            return content
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to retrieve session replay: {e}",
                session_id=session_id,
            )

    def retrieve_session_logs(self, session_id: str) -> Any | None:
        """
        Retrieve the session logs for a session.

        Returns None if the session is still running or shutting down.
        Logs are only available for completed sessions.

        Args:
            session_id: ID of the session to retrieve logs for

        Returns:
            Parsed JSON logs containing session events and details,
            or None if the session is still running

        Raises:
            WorkflowError: If retrieving session logs fails

        Example:
            >>> logs = client.retrieve_session_logs("session-123")
            >>> if logs is None:
            ...     print("Session is still running, logs not yet available")
            ... else:
            ...     print(f"Got {len(logs)} log entries")
        """
        try:
            content = self._http_client.download_file(f"/retrieve_session_logs/{session_id}")
            text = content.decode("utf-8")
            response = json.loads(text)
            return response.get("logs")
        except json.JSONDecodeError as e:
            raise WorkflowError(
                f"Failed to parse session logs: {e}",
                session_id=session_id,
            )
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to retrieve session logs: {e}",
                session_id=session_id,
            )

    def interrupt(self, session_id: str) -> dict:
        """
        Interrupt a running session's agent.

        Sends an interrupt signal that pauses the agent mid-execution.
        The agent stops its current action and emits an SSE event.

        Args:
            session_id: The session ID to interrupt

        Returns:
            dict with interrupt result

        Raises:
            WorkflowError: If interrupting the session fails
        """
        try:
            response = self._http_client.post(
                "/editor_interrupt",
                data={"session_id": session_id},
            )
            if not response.get("succeeded"):
                raise WorkflowError(
                    response.get("error", "Failed to interrupt session"),
                    session_id=session_id,
                )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to interrupt session: {e}",
                session_id=session_id,
            )

    def pause(self, session_id: str) -> PauseSessionResponse:
        """
        Pause a running session.

        Args:
            session_id: The session ID to pause

        Returns:
            PauseSessionResponse with pause details

        Raises:
            WorkflowError: If pausing the session fails

        Example:
            >>> result = client.pause("session-123")
            >>> print(f"Paused with key: {result['pause_key']}")
        """
        try:
            response: PauseSessionResponse = self._http_client.post(
                "/pause",
                data={"session_id": session_id},
            )
            if not response.get("succeeded"):
                raise WorkflowError(
                    response.get("error", "Failed to pause session"),
                    session_id=session_id,
                )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to pause session: {e}",
                session_id=session_id,
            )

    def resume(self, session_id: str) -> ResumeSessionResponse:
        """
        Resume a paused session.

        Args:
            session_id: The session ID to resume

        Returns:
            ResumeSessionResponse with resume details

        Raises:
            WorkflowError: If resuming the session fails

        Example:
            >>> result = client.resume("session-123")
            >>> print(f"Resumed, pause type: {result['pause_type']}")
        """
        try:
            response: ResumeSessionResponse = self._http_client.post(
                "/resume_session",
                data={"session_id": session_id},
            )
            if not response.get("succeeded"):
                raise WorkflowError(
                    response.get("error", "Failed to resume session"),
                    session_id=session_id,
                )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to resume session: {e}",
                session_id=session_id,
            )

    def search_workflows(
        self,
        workflow_name: str | None = None,
        metadata: str | None = None,
    ) -> SearchWorkflowsResponse:
        """
        Search workflows by name and/or metadata.

        If no parameters are provided, returns all workflows for the organization.

        Args:
            workflow_name: Name of the workflow to search for
            metadata: Metadata string to search for

        Returns:
            SearchWorkflowsResponse with matching workflows

        Raises:
            WorkflowError: If the search fails

        Example:
            >>> results = client.search_workflows(workflow_name="my-workflow")
            >>> for wf in results["workflows"]:
            ...     print(f"{wf['workflow_name']} ({wf['workflow_id']})")
        """

        params: dict[str, str] = {}
        if workflow_name is not None:
            params["workflow_name"] = workflow_name
        if metadata is not None:
            params["metadata"] = metadata

        try:
            response: SearchWorkflowsResponse = self._http_client.get(
                "/search_workflows",
                params=params,
            )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to search workflows: {e}")

    def update_workflow_metadata(
        self,
        workflow_id: str,
        metadata: str,
    ) -> UpdateWorkflowMetadataResponse:
        """
        Update the metadata of a workflow.

        Args:
            workflow_id: The ID of the workflow to update
            metadata: The new metadata string

        Returns:
            UpdateWorkflowMetadataResponse with update confirmation

        Raises:
            WorkflowError: If updating the metadata fails

        Example:
            >>> result = client.update_workflow_metadata(
            ...     "workflow-123",
            ...     "new-metadata-value"
            ... )
            >>> print(f"Updated: {result['message']}")
        """
        try:
            response: UpdateWorkflowMetadataResponse = self._http_client.post(
                "/update_workflow_metadata",
                data={"workflow_id": workflow_id, "metadata": metadata},
            )
            if not response.get("succeeded"):
                raise WorkflowError(
                    "Failed to update workflow metadata",
                    workflow_id=workflow_id,
                )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to update workflow metadata: {e}",
                workflow_id=workflow_id,
            )

    def get_workflow(self, workflow_id: str) -> Any:
        """
        Get a workflow by its ID.

        Args:
            workflow_id: The ID of the workflow to retrieve

        Returns:
            The full workflow object
        """
        try:
            return self._http_client.get(f"/workflow/{workflow_id}")
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to get workflow: {e}", workflow_id=workflow_id)

    def create_workflow(
        self,
        name: str,
        url: str | None = None,
        actions: list[Any] | None = None,
        variables: dict[str, Any] | None = None,
        structured_output: dict[str, Any] | None = None,
        metadata: str | None = None,
    ) -> Any:
        """
        Create a new workflow.

        Args:
            name: Name for the workflow
            url: Starting URL for the workflow
            actions: List of workflow actions
            variables: Workflow variables
            structured_output: Structured output definition
            metadata: Optional metadata string

        Returns:
            The created workflow object
        """
        data: dict[str, Any] = {"name": name}
        if url is not None:
            data["url"] = url
        if actions is not None:
            data["actions"] = actions
        if variables is not None:
            data["variables"] = variables
        if structured_output is not None:
            data["structured_output"] = structured_output
        if metadata is not None:
            data["metadata"] = metadata

        try:
            return self._http_client.post_json("/workflow", data=data)
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to create workflow: {e}")

    def update_workflow(self, workflow_id: str, **fields: Any) -> Any:
        """
        Update a workflow.

        Args:
            workflow_id: The ID of the workflow to update
            **fields: Fields to update (name, url, actions, variables, etc.)

        Returns:
            The updated workflow object
        """
        try:
            return self._http_client.patch_json(f"/workflow/{workflow_id}", data=fields)
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to update workflow: {e}", workflow_id=workflow_id)

    def start_editor_session(
        self,
        name: str,
        url: str,
        test_data: dict[str, Any] | None = None,
        prompt: str | None = None,
    ) -> StartEditorSessionResponse:
        """
        Start an editor session. Creates a workflow and starts a browser session.

        Args:
            name: Name for the workflow
            url: Starting URL
            test_data: Optional test data variables
            prompt: Optional initial prompt to send to the agent after session starts

        Returns:
            StartEditorSessionResponse with session_id, workflow_id, and URLs
        """
        data: dict[str, Any] = {"name": name, "url": url}
        if test_data is not None:
            data["test_data"] = test_data
        if prompt is not None:
            data["prompt"] = prompt

        try:
            response: StartEditorSessionResponse = self._http_client.post_json(
                "/start_editor_session", data=data
            )
            if not response.get("succeeded"):
                raise WorkflowError("Failed to start editor session")
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to start editor session: {e}")

    def stream_session(self, logs_url: str) -> Any:
        """
        Stream SSE events from a live session.

        Args:
            logs_url: The logs_url (SSE endpoint) for the session

        Yields:
            Parsed event dicts from the SSE stream
        """
        return self._http_client.stream_sse(logs_url)

    def poll_events(self, logs_url: str, since: int = 0, limit: int = 100) -> dict:
        """
        Poll for session events (non-streaming alternative to stream_session).

        Args:
            logs_url: The logs_url for the session (the /stream endpoint URL)
            since: Event index to start from (0 = all events). Use `next_index`
                   from the response to get only new events on the next call.
            limit: Max events to return (default 100, max 500)

        Returns:
            Dict with:
                events: list of event dicts
                next_index: index to pass as `since` on next poll
                total: total events in session history
                has_more: whether there are more events beyond this batch
        """
        # Derive events URL from logs URL: replace /stream with /events
        events_url = logs_url.rsplit("/stream", 1)[0] + "/events"
        params = {"since": since, "limit": limit}
        return self._http_client.get_from_url(events_url, params=params)

    def send_message(self, message_url: str, message: str) -> Any:
        """
        Send a message to a live session.

        Args:
            message_url: The message_url for the session
            message: The message text to send

        Returns:
            Response from the message endpoint
        """
        return self._http_client.post_to_url(message_url, json_data={"message": message})

    def get_workflow_active_session(self, workflow_id: str) -> dict:
        """
        Get the active session for a workflow.

        Returns session_id, logs_url, message_url, vnc_url for the most
        recent session associated with the given workflow.

        Args:
            workflow_id: The workflow ID to look up

        Returns:
            Dict with session_id, status, logs_url, message_url, vnc_url
        """
        return self._http_client.get(f"/workflow/{workflow_id}/active_session")

    def add_2fa_config(
        self,
        seed: str,
        name: str | None = None,
        partial_url: str | None = None,
    ) -> Add2FAConfigResponse:
        """
        Add a 2FA TOTP seed configuration for your organization.

        The seed is used to generate TOTP codes during automated browser
        sessions. Either ``name`` or ``partial_url`` must be provided.

        Args:
            seed: The TOTP secret/seed for generating 2FA codes
            name: Friendly name for the configuration (e.g. "GitHub")
            partial_url: URL pattern to auto-match (e.g. "github.com")

        Returns:
            Add2FAConfigResponse with the added config and total count

        Raises:
            WorkflowError: If adding the 2FA config fails

        Example:
            >>> result = client.add_2fa_config(
            ...     seed="JBSWY3DPEHPK3PXP",
            ...     name="GitHub",
            ...     partial_url="github.com"
            ... )
            >>> print(f"Total configs: {result['total_configs']}")
        """
        data: dict[str, Any] = {"seed": seed}
        if name is not None:
            data["name"] = name
        if partial_url is not None:
            data["partial_url"] = partial_url

        try:
            response: Add2FAConfigResponse = self._http_client.post_json(
                "/add_2fa_config", data=data
            )
            if not response.get("succeeded"):
                raise WorkflowError(
                    response.get("error", "Failed to add 2FA config")
                )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to add 2FA config: {e}")

    def close_session(self, session_id: str) -> Any:
        """
        Close a running session. Stops the agent, dumps state, and sets the
        session status to "Stopped". The call blocks until the container
        confirms the close or a timeout forces the status update.

        Args:
            session_id: The session ID to close

        Returns:
            Response from the close endpoint
        """
        try:
            return self._http_client.post(
                "/close_session",
                data={"session_id": session_id},
            )
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to close session: {e}", session_id=session_id)

    def start_recording(self, session_id: str) -> StartRecordingResponse:
        """
        Start recording browser actions and network events in a session.

        The recording captures clicks, inputs, navigation, scroll events,
        and network requests with anti-bot hardening.

        Args:
            session_id: The session ID to start recording on

        Returns:
            StartRecordingResponse with status

        Raises:
            WorkflowError: If starting the recording fails

        Example:
            >>> result = client.start_recording("session-123")
            >>> print(f"Status: {result['status']}")
        """
        try:
            response: StartRecordingResponse = self._http_client.post(
                "/editor_start_recording",
                data={"session_id": session_id},
            )
            if not response.get("succeeded"):
                raise WorkflowError(
                    response.get("error", "Failed to start recording"),
                    session_id=session_id,
                )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to start recording: {e}",
                session_id=session_id,
            )

    def stop_recording(self, session_id: str) -> StopRecordingResponse:
        """
        Stop recording and export the captured actions as an agent-script.

        Returns the export path, action count, network event count, and duration.

        Args:
            session_id: The session ID to stop recording on

        Returns:
            StopRecordingResponse with export details

        Raises:
            WorkflowError: If stopping the recording fails

        Example:
            >>> result = client.stop_recording("session-123")
            >>> print(f"Captured {result['action_count']} actions in {result['duration']}ms")
            >>> print(f"Exported to: {result['path']}")
        """
        try:
            response: StopRecordingResponse = self._http_client.post(
                "/editor_stop_recording",
                data={"session_id": session_id},
            )
            if not response.get("succeeded"):
                raise WorkflowError(
                    response.get("error", "Failed to stop recording"),
                    session_id=session_id,
                )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(
                f"Failed to stop recording: {e}",
                session_id=session_id,
            )

    def search_drugs(
        self,
        query: str,
        *,
        limit: int = 10,
    ) -> SearchDrugsResponse:
        """
        Fuzzy-search the supported fax-PA drug catalog.

        Resolves a free-text drug query (e.g. "wegovy 1mg") into the canonical
        ``Brand Strength Form`` string expected by ``drug_info.medication_strength``
        when calling ``/fill_pa``. Matches are ranked exact > prefix > substring
        > token/fuzzy; weak fuzzy matches below an internal relevance threshold
        are dropped, so an unknown drug returns an empty ``matches`` list.

        Args:
            query: Partial or full drug name (e.g. "wegovy", "zepbound 5mg",
                "mounjaro auto-injectors"). Matched case-insensitively.
            limit: Maximum number of matches to return (1-50). Defaults to 10.

        Returns:
            SearchDrugsResponse with ``succeeded``, echoed ``query``, and a
            ranked list of ``matches`` — each item has a ``full_name`` field.

        Raises:
            WorkflowError: If the request fails.

        Example:
            >>> result = client.search_drugs("wegovy 1mg")
            >>> for match in result["matches"]:
            ...     print(match["full_name"])
            Wegovy 1MG/0.5ML auto-injectors
            Wegovy 1.5MG tablets
            ...
        """
        params: dict[str, Any] = {"query": query, "limit": limit}
        try:
            response: SearchDrugsResponse = self._http_client.get(
                "/search_drugs",
                params=params,
            )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to search drugs: {e}")

    def get_clinical_questions(
        self,
        bin: str,
        state: str,
        drug_name: str,
        icd_code: str,
        *,
        pcn: str = "",
        group_id: str = "",
        member_id: str = "",
    ) -> GetClinicalQuestionsResponse:
        """
        Resolve the payer's prior-auth clinical question set for a pharmacy claim.

        Returns the LOB-specific clinical questions required by the payer's
        policy for the given drug + ICD-10 diagnosis, along with per-question
        structured citations pointing back to the underlying payer policy.

        `bin`, `state`, `drug_name`, and `icd_code` together pin down the
        line of business + indication. Optional `pcn` / `group_id` / `member_id`
        disambiguate shared-processor BINs (e.g. BIN 003858 / PCN A4 hosts
        both ESI Commercial and Humana Part D — the member-ID alpha prefix
        tiebreaks to the correct LOB).

        Args:
            bin: NCPDP BIN from the patient's insurance card (e.g. "003858").
            state: Two-letter USPS state code where the prescription will be filled.
            drug_name: Drug brand or generic name. Supported: "wegovy", "semaglutide",
                "zepbound", "mounjaro". Matched case-insensitively on substring.
            icd_code: Exact ICD-10 diagnosis code (e.g. "E11.9", "E66.01"). Drives
                indication mapping (E66→weight loss, E11→T2D, G47.3→OSA, etc.).
            pcn: NCPDP PCN from the patient's insurance card. Optional.
            group_id: NCPDP Group ID (301-C1). Optional — tiebreaks when
                (BIN, PCN) hits multiple LOBs.
            member_id: NCPDP Cardholder ID (302-C2). Optional — the leading
                alpha prefix tiebreaks shared-processor BINs. PHI: do not log
                the full value downstream.

        Returns:
            GetClinicalQuestionsResponse with `matched`, `routing`, `coverage_status`,
            `lob_id`, `rationale`, `questions`, and `sources`. When
            `coverage_status != "resolved"` the `questions` list is empty and
            `rationale` explains why (e.g. Part D statutory weight-loss exclusion).

        Raises:
            WorkflowError: If the request fails.

        Example:
            >>> result = client.get_clinical_questions(
            ...     bin="003858",
            ...     state="CA",
            ...     drug_name="wegovy",
            ...     icd_code="E66.01",
            ...     pcn="A4",
            ...     member_id="4XS00000523646",
            ... )
            >>> if result["coverage_status"] == "resolved":
            ...     print(f"LOB: {result['lob_id']}")
            ...     for q in result["questions"]:
            ...         print(f"{q['id']}: {q['prompt']}")
            ...         if q.get("citation"):
            ...             print(f"    {q['citation']['policy_id']} — {q['citation']['section']}")
        """
        params: dict[str, Any] = {
            "bin": bin,
            "state": state,
            "drug_name": drug_name,
            "icd_code": icd_code,
        }
        if pcn:
            params["pcn"] = pcn
        if group_id:
            params["group_id"] = group_id
        if member_id:
            params["member_id"] = member_id
        try:
            response: GetClinicalQuestionsResponse = self._http_client.get(
                "/get_clinical_questions",
                params=params,
            )
            return response
        except Exception as e:
            if isinstance(e, WorkflowError):
                raise
            raise WorkflowError(f"Failed to get clinical questions: {e}")
