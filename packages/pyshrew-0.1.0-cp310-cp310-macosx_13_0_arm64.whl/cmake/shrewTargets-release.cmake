#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Shrew::gp" for configuration "Release"
set_property(TARGET Shrew::gp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Shrew::gp PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libgp.a"
  )

list(APPEND _cmake_import_check_targets Shrew::gp )
list(APPEND _cmake_import_check_files_for_Shrew::gp "${_IMPORT_PREFIX}/lib/libgp.a" )

# Import target "Shrew::shrew" for configuration "Release"
set_property(TARGET Shrew::shrew APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Shrew::shrew PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libshrew.a"
  )

list(APPEND _cmake_import_check_targets Shrew::shrew )
list(APPEND _cmake_import_check_files_for_Shrew::shrew "${_IMPORT_PREFIX}/lib/libshrew.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
