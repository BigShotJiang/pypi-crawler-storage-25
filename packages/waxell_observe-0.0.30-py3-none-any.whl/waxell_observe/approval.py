"""Built-in ``on_policy_block`` handlers for common approval patterns.

Usage with the ``@observe`` decorator::

    @waxell.observe(
        workflow_name="delete",
        on_policy_block=waxell.prompt_approval,
    )
    async def delete_records(table: str) -> dict:
        ...

Custom handlers return an :class:`ApprovalDecision`::

    def slack_approval(error: PolicyViolationError) -> ApprovalDecision:
        send_slack_message(channel, build_block(error))
        response = wait_for_reaction(timeout=300)
        return ApprovalDecision(approved=response == "approved", approver="slack")
"""

import inspect
import time

from .errors import PolicyViolationError
from .types import ApprovalDecision


def prompt_approval(error: PolicyViolationError) -> ApprovalDecision:
    """Interactive terminal prompt for human-in-the-loop approval.

    Extracts ``timeout_minutes`` and ``approvers`` from the policy metadata,
    prints a block banner, prompts ``y/n``, and enforces the timeout window.
    """
    meta = extract_block_metadata(error)
    blocked_at = time.monotonic()
    timeout_minutes = meta.get("timeout_minutes")

    print()
    print("  \033[1;31m!! BLOCKED BY APPROVAL POLICY\033[0m")
    print(f"  Reason:    {meta['reason']}")
    print(f"  Operation: {meta['action_type']}")
    approvers = meta.get("approvers", [])
    print(f"  Approvers: {', '.join(approvers) if approvers else '(none configured)'}")
    if timeout_minutes is not None:
        print(f"  Timeout:   {timeout_minutes} min")
    print()

    try:
        if timeout_minutes is not None:
            remaining = (blocked_at + timeout_minutes * 60) - time.monotonic()
            if remaining <= 0:
                print("  \033[1;31m[TIMEOUT] Approval window expired.\033[0m\n")
                elapsed = time.monotonic() - blocked_at
                return ApprovalDecision(
                    approved=False, timed_out=True, elapsed_seconds=elapsed
                )
            print(f"  \033[2mApproval window: {remaining:.0f}s remaining\033[0m")

        answer = input("  \033[1;33mApprove this operation? (y/n): \033[0m")
        answer = answer.strip().lower()

        elapsed = time.monotonic() - blocked_at
        if timeout_minutes is not None and elapsed > timeout_minutes * 60:
            print(
                f"  \033[1;31m[TIMEOUT] Took {elapsed:.1f}s — "
                f"exceeds {timeout_minutes} min window.\033[0m\n"
            )
            return ApprovalDecision(
                approved=False, timed_out=True, elapsed_seconds=elapsed
            )

        if answer in ("y", "yes"):
            return ApprovalDecision(
                approved=True, approver="interactive_user", elapsed_seconds=elapsed
            )
        return ApprovalDecision(approved=False, elapsed_seconds=elapsed)

    except (EOFError, KeyboardInterrupt):
        elapsed = time.monotonic() - blocked_at
        return ApprovalDecision(approved=False, elapsed_seconds=elapsed)


def auto_approve(error: PolicyViolationError) -> ApprovalDecision:
    """Always approve — for testing and dry-run scenarios."""
    return ApprovalDecision(approved=True, approver="auto_approve", elapsed_seconds=0.0)


def auto_deny(error: PolicyViolationError) -> ApprovalDecision:
    """Always deny — for testing."""
    return ApprovalDecision(approved=False, elapsed_seconds=0.0)


def extract_block_metadata(error: PolicyViolationError) -> dict:
    """Extract approval metadata from a :class:`PolicyViolationError`.

    Returns a dict with ``reason``, ``action_type``, ``approvers``, and
    ``timeout_minutes`` keys.  Safe to call even when the error has no
    ``policy_result`` attached.
    """
    policy_result = error.policy_result
    metadata: dict = {}
    if policy_result:
        if hasattr(policy_result, "metadata"):
            metadata = policy_result.metadata or {}
        # Also check individual evaluations for approval-specific metadata
        evaluations = getattr(policy_result, "evaluations", None) or []
        for ev in evaluations:
            if isinstance(ev, dict) and ev.get("category") == "approval":
                ev_meta = ev.get("metadata") or {}
                metadata = {**metadata, **ev_meta}
                break
    return {
        "reason": str(error),
        "action_type": (
            metadata.get("workflow_type", "") or metadata.get("action_type", "unknown")
        ),
        "approvers": metadata.get("approvers", []),
        "timeout_minutes": metadata.get("timeout_minutes"),
    }


# ---------------------------------------------------------------------------
# Shared approval lifecycle orchestration
# ---------------------------------------------------------------------------


async def handle_policy_block(handler, error: PolicyViolationError) -> ApprovalDecision:
    """Invoke an ``on_policy_block`` handler and record the approval lifecycle.

    Records ``approval_request`` before invoking the handler and
    ``approval_response`` after, both on the current (parent) context.

    Used by both the ``@observe()`` decorator and ``WaxellContext``.
    """
    from .instrumentors._context_var import _current_context

    meta = extract_block_metadata(error)
    parent_ctx = _current_context.get()

    if parent_ctx:
        parent_ctx.record_approval_request(
            action_type=meta["action_type"],
            approvers=meta.get("approvers", []),
            timeout_minutes=meta.get("timeout_minutes"),
            reason=meta["reason"],
        )

    blocked_at = time.monotonic()

    # Wrap the handler in a human_turn so the interactive prompt/response
    # shows up as a timed IO span in the trace.
    human_turn_ctx = None
    if parent_ctx:
        human_turn_ctx = parent_ctx.human_turn(
            prompt=meta["reason"],
            channel="terminal",
            action="approval",
            metadata={"operation": meta["action_type"]},
        )
        human_turn_ctx.__enter__()

    try:
        if inspect.iscoroutinefunction(handler):
            decision = await handler(error)
        else:
            decision = handler(error)
    except BaseException:
        if human_turn_ctx is not None:
            human_turn_ctx.set_response("error")
            human_turn_ctx.__exit__(None, None, None)
        raise

    if not isinstance(decision, ApprovalDecision):
        decision = ApprovalDecision(approved=bool(decision))

    if decision.elapsed_seconds is None:
        decision.elapsed_seconds = time.monotonic() - blocked_at

    if human_turn_ctx is not None:
        response_str = (
            "approved"
            if decision.approved
            else ("timeout" if decision.timed_out else "denied")
        )
        human_turn_ctx.set_response(response_str)
        human_turn_ctx.__exit__(None, None, None)

    if parent_ctx:
        if decision.approved:
            decision_str = "approved"
        elif decision.timed_out:
            decision_str = "timeout"
        else:
            decision_str = "denied"
        parent_ctx.record_approval_response(
            action_type=meta["action_type"],
            decision=decision_str,
            approver=decision.approver,
            elapsed_seconds=decision.elapsed_seconds,
        )

    return decision


def handle_policy_block_sync(handler, error: PolicyViolationError) -> ApprovalDecision:
    """Synchronous version of :func:`handle_policy_block`.

    The handler must be synchronous — async handlers raise ``TypeError``.
    """
    from .instrumentors._context_var import _current_context

    meta = extract_block_metadata(error)
    parent_ctx = _current_context.get()

    if parent_ctx:
        parent_ctx.record_approval_request(
            action_type=meta["action_type"],
            approvers=meta.get("approvers", []),
            timeout_minutes=meta.get("timeout_minutes"),
            reason=meta["reason"],
        )

    blocked_at = time.monotonic()
    if inspect.iscoroutinefunction(handler):
        raise TypeError(
            f"Async handler {handler.__name__!r} cannot be used in sync "
            f"context manager. Use 'async with' or provide a sync handler."
        )

    # Wrap the handler in a human_turn so the interactive prompt/response
    # shows up as a timed IO span in the trace.
    human_turn_ctx = None
    if parent_ctx:
        human_turn_ctx = parent_ctx.human_turn(
            prompt=meta["reason"],
            channel="terminal",
            action="approval",
            metadata={"operation": meta["action_type"]},
        )
        human_turn_ctx.__enter__()

    try:
        decision = handler(error)
    except BaseException:
        if human_turn_ctx is not None:
            human_turn_ctx.set_response("error")
            human_turn_ctx.__exit__(None, None, None)
        raise

    if not isinstance(decision, ApprovalDecision):
        decision = ApprovalDecision(approved=bool(decision))

    if decision.elapsed_seconds is None:
        decision.elapsed_seconds = time.monotonic() - blocked_at

    if human_turn_ctx is not None:
        response_str = (
            "approved"
            if decision.approved
            else ("timeout" if decision.timed_out else "denied")
        )
        human_turn_ctx.set_response(response_str)
        human_turn_ctx.__exit__(None, None, None)

    if parent_ctx:
        if decision.approved:
            decision_str = "approved"
        elif decision.timed_out:
            decision_str = "timeout"
        else:
            decision_str = "denied"
        parent_ctx.record_approval_response(
            action_type=meta["action_type"],
            decision=decision_str,
            approver=decision.approver,
            elapsed_seconds=decision.elapsed_seconds,
        )

    return decision
