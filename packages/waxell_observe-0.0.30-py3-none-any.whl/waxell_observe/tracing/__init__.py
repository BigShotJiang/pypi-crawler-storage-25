"""OTel tracing for waxell-observe.

Public API:
    init_tracing()       - Initialize OTel tracing with auto-configured or explicit settings
    flush_tracing()      - Force-flush pending spans (useful for Jupyter notebooks)
    shutdown_tracing()   - Shut down the TracerProvider and flush remaining spans
    is_tracing_enabled() - Check if OTel tracing is active
    get_tracer()         - Get an OTel tracer instance (or NoOpTracer)
"""

import atexit
import logging
import os
from typing import Optional

from ._compat import _HAS_OTEL, get_tracer
import waxell_observe.tracing._compat as _compat_module

logger = logging.getLogger(__name__)

_initialized: bool = False
_provider = None
_log_provider = None
_log_handler = None
_tracer = None
_capture_content: bool = False


class _WaxellContextLogFilter(logging.Filter):
    """Injects WaxellContext metadata and enforces per-context log limits.

    Reads the active WaxellContext from the ContextVar and:
    1. Enforces min_log_level from audit policy (drops records below threshold)
    2. Enforces max_log_entries from audit policy (drops after limit reached)
    3. Injects run_id, agent_name, workflow_name as log record attributes

    These attributes flow through the OTel LoggingHandler → OTLP exporter → Loki
    as structured metadata, enabling precise per-run log filtering.

    When no context is active, all records pass through unchanged.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            from waxell_observe.instrumentors._context_var import _current_context

            ctx = _current_context.get()
            if ctx is not None:
                # Enforce per-context minimum log level
                min_level = getattr(ctx, "_log_min_level", 0)
                if min_level and record.levelno < min_level:
                    return False

                # Enforce per-context max log entries
                max_entries = getattr(ctx, "_log_max_entries", 0)
                if max_entries > 0:
                    lock = getattr(ctx, "_lock", None)
                    if lock:
                        with lock:
                            count = getattr(ctx, "_log_entry_count", 0)
                            if count >= max_entries:
                                return False
                            ctx._log_entry_count = count + 1
                    else:
                        count = getattr(ctx, "_log_entry_count", 0)
                        if count >= max_entries:
                            return False
                        ctx._log_entry_count = count + 1

                run_info = getattr(ctx, "_run_info", None)
                run_id = str(run_info.run_id) if run_info and hasattr(run_info, "run_id") else ""
                agent = getattr(ctx, "agent_name", "") or ""
                workflow = getattr(ctx, "workflow_name", "") or ""

                # OTel LoggingHandler._get_attributes() reads vars(record)
                # directly (excluding _RESERVED_ATTRS) and forwards them as
                # log record attributes → Loki structured metadata.
                if run_id:
                    record.waxell_run_id = run_id  # type: ignore[attr-defined]
                if agent:
                    record.waxell_agent_name = agent  # type: ignore[attr-defined]
                if workflow:
                    record.waxell_workflow_name = workflow  # type: ignore[attr-defined]
        except Exception:
            pass  # Never break logging
        return True


def init_tracing(
    api_url: Optional[str] = None,
    api_key: Optional[str] = None,
    otel_endpoint: Optional[str] = None,
    tenant_id: Optional[str] = None,
    debug: Optional[bool] = None,
    capture_content: bool = False,
    shutdown_on_exit: bool = True,
    resource_attributes: Optional[dict] = None,
) -> None:
    """Initialize OTel tracing for the observe SDK.

    This creates a local TracerProvider (not global) with a
    BatchSpanProcessor that exports spans in a background thread.

    Args:
        api_url: Waxell API URL. Resolved from config if not provided.
        api_key: Waxell API key. Resolved from config if not provided.
        otel_endpoint: Explicit OTel collector endpoint. Auto-discovered if not provided.
        tenant_id: Explicit tenant ID for trace routing. Auto-discovered from API key if not provided.
        debug: Enable debug logging and console span export.
            Defaults to WAXELL_DEBUG env var.
        capture_content: Include prompt/response content in spans.
        shutdown_on_exit: Register atexit handler for clean shutdown.
        resource_attributes: Extra OTel resource attributes.
    """
    global _initialized, _provider, _log_provider, _log_handler, _tracer, _capture_content

    if _initialized:
        return

    if not _HAS_OTEL:
        logger.debug(
            "OTel packages not installed. Tracing disabled. "
            "Install with: pip install waxell-observe[otel]"
        )
        return

    # Resolve debug mode
    if debug is None:
        debug = os.environ.get("WAXELL_DEBUG", "").lower() in ("true", "1", "yes")

    # Resolve config using existing config resolution chain
    from waxell_observe.client import WaxellObserveClient

    config = WaxellObserveClient._resolve_config(api_url, api_key)

    # Resolve OTel config (endpoint + tenant_id) in a single call
    from .exporter import resolve_otel_config

    otel_config = resolve_otel_config(
        explicit_endpoint=otel_endpoint,
        explicit_tenant_id=tenant_id,
        api_url=config.api_url if config.api_url else None,
        api_key=config.api_key if config.api_key else None,
    )

    endpoint = otel_config.endpoint

    # Build resource attributes with tenant_id
    attrs = dict(resource_attributes or {})
    if otel_config.tenant_id:
        from .attributes import WaxellAttributes

        attrs[WaxellAttributes.TENANT_ID] = otel_config.tenant_id

    from .provider import create_resource

    resource = create_resource(resource_attributes=attrs)

    if not endpoint:
        # No OTLP endpoint — create a provider with only the WaxellSpanProcessor
        # so auto-instrumented spans still flow to the Django Span table via HTTP.
        from .provider import create_waxell_only_provider

        _provider = create_waxell_only_provider(resource=resource, debug=debug)

        _tracer = _provider.get_tracer("waxell.observe")
        _capture_content = capture_content
        _compat_module._provider = _provider
        _initialized = True

        if shutdown_on_exit:
            atexit.register(shutdown_tracing)

        _hook_global_provider()

        logger.info(
            "Waxell OTel tracing initialized (no OTLP endpoint — "
            "auto-instrumented spans will flow via HTTP observe API)"
        )
        return

    # Build auth headers for OTLP export.
    # When the endpoint is the Waxell API proxy, the exporter needs the API key.
    # When pointing at a standalone collector, the extra header is harmless.
    otlp_headers = {}
    if config.api_key:
        otlp_headers["X-Wax-Key"] = config.api_key

    # Create trace provider (includes WaxellSpanProcessor + OTLP exporter)
    from .provider import create_provider, create_log_provider

    _provider = create_provider(
        endpoint=endpoint,
        resource=resource,
        debug=debug,
        headers=otlp_headers,
    )

    _tracer = _provider.get_tracer("waxell.observe")
    _capture_content = capture_content

    # Update _compat module so get_tracer() returns the real tracer
    _compat_module._provider = _provider

    # Set up log forwarding (Python logging -> OTel -> Loki)
    _log_provider = create_log_provider(
        endpoint=endpoint, resource=resource, headers=otlp_headers
    )
    if _log_provider is not None:
        from opentelemetry.sdk._logs import LoggingHandler

        _log_handler = LoggingHandler(
            level=logging.INFO, logger_provider=_log_provider
        )
        _log_handler.addFilter(_WaxellContextLogFilter())

        # Attach to a dedicated "waxell" logger rather than root.
        # This avoids fighting with the app's root logger level
        # (e.g. basicConfig(WARNING)) which would block our INFO records.
        # SDK loggers (waxell_observe.*) propagate up to "waxell_observe"
        # which propagates to root — but we also want to capture user logs.
        # Solution: attach to root AND ensure root level doesn't block.
        root = logging.getLogger()
        root.addHandler(_log_handler)
        if root.level > logging.INFO or root.level == logging.NOTSET:
            root.setLevel(logging.INFO)

    _initialized = True

    if shutdown_on_exit:
        atexit.register(shutdown_tracing)

    logger.info(
        "Waxell OTel tracing initialized: endpoint=%s tenant_id=%s logs=%s",
        endpoint,
        otel_config.tenant_id or "(none)",
        _log_provider is not None,
    )

    _hook_global_provider()

    # Warn if endpoint points to a local OTLP proxy (requires Tempo/Loki running)
    if endpoint and ("localhost" in endpoint or "127.0.0.1" in endpoint):
        if "/otlp" in endpoint:
            logger.warning(
                "OTel endpoint %s is a local OTLP proxy. "
                "Ensure Tempo is running (default: localhost:14318) for trace storage. "
                "Spans will still be correlated via trace_id on the run record.",
                endpoint,
            )


def _hook_global_provider() -> None:
    """Add WaxellSpanProcessor to the global TracerProvider.

    Standard OTel instrumentors (redis, psycopg2, httpx, requests,
    SQLAlchemy, etc.) create spans on the GLOBAL TracerProvider, not
    our local one.  By adding our processor there too, any third-party
    instrumentor the user installs automatically flows into the trace tree.

    Safe to call multiple times — checks for existing processor first.
    Does NOT replace or interfere with any existing global provider setup.
    """
    try:
        from opentelemetry import trace as trace_api
        from opentelemetry.sdk.trace import TracerProvider as SdkTracerProvider

        global_provider = trace_api.get_tracer_provider()

        # The global provider might be a ProxyTracerProvider wrapping an
        # SDK TracerProvider, or it might be our own if set_tracer_provider()
        # was called. We need the underlying SDK provider to add a processor.
        actual = getattr(global_provider, "_tracer_provider", global_provider)

        if isinstance(actual, SdkTracerProvider):
            # Check if WaxellSpanProcessor already registered
            multi = getattr(actual, "_active_span_processor", None)
            existing = getattr(multi, "_span_processors", ())
            for sp in existing:
                if type(sp).__name__ == "WaxellSpanProcessor":
                    return  # Already hooked

            from .span_processor import WaxellSpanProcessor

            actual.add_span_processor(WaxellSpanProcessor())
            logger.debug("WaxellSpanProcessor added to global TracerProvider")
        else:
            # No SDK provider set globally yet — create a minimal one
            # with just our processor so future instrumentors have
            # somewhere to send spans.
            from .span_processor import WaxellSpanProcessor
            from opentelemetry.sdk.resources import Resource

            minimal = SdkTracerProvider(
                resource=Resource.create({"service.name": "waxell-observe-sdk"})
            )
            minimal.add_span_processor(WaxellSpanProcessor())
            trace_api.set_tracer_provider(minimal)
            logger.debug(
                "Created global TracerProvider with WaxellSpanProcessor "
                "(standard OTel instrumentors will now flow into traces)"
            )
    except Exception:
        logger.debug("Failed to hook global TracerProvider", exc_info=True)


def flush_tracing(timeout_millis: int = 30000) -> None:
    """Force-flush pending spans and logs.

    Useful in Jupyter notebooks to ensure spans are exported
    before the kernel goes idle.
    """
    if _provider is not None:
        try:
            _provider.force_flush(timeout_millis)
        except Exception as e:
            logger.debug("Error flushing tracing: %s", e)
    if _log_provider is not None:
        try:
            _log_provider.force_flush(timeout_millis)
        except Exception as e:
            logger.debug("Error flushing log provider: %s", e)


def shutdown_tracing() -> None:
    """Shut down the TracerProvider, LoggerProvider, and flush pending data."""
    global _initialized, _provider, _log_provider, _log_handler, _tracer, _capture_content

    if _provider is not None:
        from .provider import shutdown_provider

        shutdown_provider(_provider)
        _compat_module._provider = None

    if _log_handler is not None:
        logging.getLogger().removeHandler(_log_handler)

    if _log_provider is not None:
        from .provider import shutdown_log_provider

        shutdown_log_provider(_log_provider)

    _initialized = False
    _provider = None
    _log_provider = None
    _log_handler = None
    _tracer = None
    _capture_content = False


def is_tracing_enabled() -> bool:
    """Check if OTel tracing is currently active."""
    return _initialized and _HAS_OTEL


__all__ = [
    "init_tracing",
    "flush_tracing",
    "shutdown_tracing",
    "is_tracing_enabled",
    "get_tracer",
]
