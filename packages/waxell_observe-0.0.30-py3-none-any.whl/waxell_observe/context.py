"""WaxellContext — context manager for manual instrumentation.

Usage:
    # Async
    async with WaxellContext(agent_name="my-agent") as ctx:
        result = await my_agent.run(input)
        ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
        ctx.set_result({"output": result})

    # Sync (native — ContextVar stays in calling thread for auto-instrumentation)
    with WaxellContext(agent_name="my-agent") as ctx:
        result = my_agent.run(input)
        ctx.record_llm_call(model="gpt-4o", tokens_in=100, tokens_out=50)
"""

import logging
import threading
import time
import traceback as _traceback_mod
import uuid
from contextvars import Token
from typing import Any, Optional

from .client import WaxellObserveClient
from .cost import estimate_cost
from .errors import PolicyViolationError
from .tracing._compat import _HAS_OTEL, NoOpSpan
from .tracing.attributes import WaxellAttributes
from .tracing.spans import (
    _infer_provider,
    start_agent_span,
    start_decision_span,
    start_governance_span,
    start_llm_span,
    start_reasoning_span,
    start_retrieval_span,
    start_retry_span,
    start_step_span,
    start_tool_span,
)
from .types import PolicyCheckResult, RunInfo

logger = logging.getLogger(__name__)


def generate_session_id() -> str:
    """Generate a random session ID.

    Returns a string like ``sess_a1b2c3d4e5f6g7h8``.
    """
    return f"sess_{uuid.uuid4().hex[:16]}"


import builtins as _builtins

_original_print = print  # Save at import time
_print_logger = logging.getLogger("waxell.stdout")
_ANSI_RE = None


def _strip_ansi(text: str) -> str:
    """Strip ANSI escape codes from text."""
    global _ANSI_RE
    if _ANSI_RE is None:
        import re
        _ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
    return _ANSI_RE.sub("", text)


def _capturing_print(*args, **kwargs):
    """Replacement for builtins.print that also logs to OTel."""
    # Always call the real print so terminal output is unchanged
    _original_print(*args, **kwargs)

    # Build the line the same way print() would
    sep = kwargs.get("sep", " ")
    end = kwargs.get("end", "\n")
    text = sep.join(str(a) for a in args)
    # Only log non-empty content (skip bare print() calls)
    clean = _strip_ansi(text).strip()
    if clean:
        _print_logger.info(clean)


class WaxellContext:
    """Context manager that wraps agent execution with observability and governance.

    On enter:
    - Checks policies (if enforce_policy=True)
    - Starts an execution run on the controlplane
    - Creates an OTel agent span (if tracing is initialized)

    On exit:
    - Flushes buffered LLM calls and steps
    - Completes the run (with result or error)
    - Ends the OTel agent span
    """

    def __init__(
        self,
        agent_name: str,
        workflow_name: str = "default",
        inputs: Optional[dict] = None,
        metadata: Optional[dict] = None,
        client: Optional[WaxellObserveClient] = None,
        enforce_policy: bool = True,
        session_id: str = "",
        user_id: str = "",
        user_group: str = "",
        mid_execution_governance: bool = False,
        auto_grounding: bool = False,
        on_policy_block=None,
    ):
        self.agent_name = agent_name
        self.workflow_name = workflow_name
        self.inputs = inputs or {}
        self.metadata = metadata or {}
        self.enforce_policy = enforce_policy
        self._mid_execution_governance = mid_execution_governance
        self._auto_grounding = auto_grounding

        # Inherit session/user/client from parent context when not provided.
        # This ensures child agents in a nested @observe pipeline share
        # session_id, user_id, user_group, and the observe client with the
        # parent — so all runs appear linked in the controlplane table.
        parent_ctx = self._get_parent_ctx()
        self.client = (
            client
            or (parent_ctx.client if parent_ctx else None)
            or WaxellObserveClient()
        )
        self.session_id = session_id or (parent_ctx.session_id if parent_ctx else "")
        self.user_id = user_id or (parent_ctx.user_id if parent_ctx else "")
        self.user_group = user_group or (parent_ctx.user_group if parent_ctx else "")

        # Resolve on_policy_block: per-context > parent > global default
        if on_policy_block is not None:
            self._on_policy_block = on_policy_block
        elif parent_ctx and getattr(parent_ctx, "_on_policy_block", None):
            self._on_policy_block = parent_ctx._on_policy_block
        else:
            try:
                from ._init import get_default_on_policy_block

                self._on_policy_block = get_default_on_policy_block()
            except Exception:
                self._on_policy_block = None

        self._run_info: Optional[RunInfo] = None
        self._llm_calls: list[dict] = []
        self._steps: list[dict] = []
        self._spans: list[dict] = []
        self._otel_spans: list[dict] = []  # Populated by WaxellSpanProcessor
        self._governance_spans: list[dict] = []
        self._result: dict = {}
        self._step_counter: int = 0
        self._span = None
        self._otel_token = None
        self._otel_trace_id: str = ""
        self._otel_span_id: str = ""
        self._context_start_ms: float = 0.0
        self._context_start_wall_ms: float = 0.0  # wall-clock ms for OTel offset calc
        self._current_step_position: int | None = None
        self._tags: dict[str, str] = {}
        self._metadata_kv: dict[str, Any] = {}
        self._scores: list[dict] = []
        self._governance_blocked: bool = False
        self._governance_reason: str = ""
        self._content_redacted: bool = False
        self._content_redact_fn: Any = None  # Callable[[str], str] when redaction is active
        self._context_token: Optional[Token] = None
        self._root_workflow_id: str = ""
        self._parent_ctx_ref: Optional["WaxellContext"] = None
        self._total_tokens_in: int = 0
        self._total_tokens_out: int = 0
        self._total_cost: float = 0.0
        self._total_llm_calls: int = 0
        self._auto_recorded_counts: dict[tuple, int] = {}  # dedup auto vs manual
        self._detected_integrations: dict[str, str] = {}  # name -> category
        self._lock = threading.Lock()  # Protects mutable state under concurrency

        # Conversation state (auto-populated by instrumentors, readable by devs)
        self._conversation_user_turns: int = 0
        self._conversation_message_count: int = 0
        self._conversation_assistant_turns: int = 0
        self._conversation_tool_results: int = 0
        self._context_tokens_used: int = 0
        self._context_utilization_pct: float = 0.0
        self._system_prompt_hash: str = ""
        self._last_user_msg_hash: str = ""  # For auto-capture dedup
        self._last_agent_resp_hash: str = ""  # For auto-capture dedup

        # Audit policy log capture config (set by _apply_audit_log_config)
        self._log_min_level: int = logging.INFO
        self._log_max_entries: int = 500
        self._log_capture_stdout: bool = False
        self._log_inputs: bool = True
        self._log_outputs: bool = True
        self._log_steps: bool = True
        self._log_tool_calls: bool = True
        self._log_entry_count: int = 0
        self._stdout_capture = None

        # Tool names used (for safety blocked_tools governance)
        self._tools_used_set: set[str] = set()

        # Code execution tracking (for code-execution governance)
        self._code_executions: list[dict] = []
        self._code_review_required: bool = False

        # Communication tracking (for communication governance)
        self._communications: list[dict] = []

        # Category B governance buffers
        self._data_accesses: list[dict] = []
        self._network_requests: list[str] = []
        self._scope_impacts: dict = {
            "records_modified": 0,
            "records_deleted": 0,
            "files_changed": 0,
            "transaction_total": 0.0,
            "api_writes": 0,
        }
        self._grounding_data: list[dict] = []
        self._retrieval_results: list[dict] = []
        self._decisions_buffer: list[dict] = []
        self._reasoning_depth: int = 0
        self._bias_flags: list[str] = []
        self._delegations: list[dict] = []
        self._delegation_depth: int = 0
        self._concurrent_delegates: int = 0
        self._is_delegate: bool = False
        self._parent_agent: str = ""
        self._privacy_context: dict = {}
        self._intermediate_outputs: list[str] = []
        self._output_text: str = ""
        self._memory_state: dict = {}
        self._memory_writes: list[dict] = []

    # -----------------------------------------------------------------
    # Conversation state (read-only properties)
    # -----------------------------------------------------------------

    @property
    def conversation_turns(self) -> int:
        """Number of user turns in the current conversation."""
        return self._conversation_user_turns

    @property
    def context_utilization(self) -> float:
        """Context window utilization as percentage (0-100)."""
        return self._context_utilization_pct

    @property
    def message_count(self) -> int:
        """Total messages currently in the LLM context."""
        return self._conversation_message_count

    def update_conversation_state(
        self,
        *,
        user_turns: int,
        message_count: int,
        assistant_turns: int = 0,
        tool_results: int = 0,
        tokens_in_context: int = 0,
        context_utilization_pct: float = 0.0,
        system_prompt_hash: str = "",
    ) -> None:
        """Update running conversation metrics (called by auto-instrumentors)."""
        with self._lock:
            self._conversation_user_turns = user_turns
            self._conversation_message_count = message_count
            self._conversation_assistant_turns = assistant_turns
            self._conversation_tool_results = tool_results
            self._context_tokens_used = tokens_in_context
            self._context_utilization_pct = context_utilization_pct
            if system_prompt_hash:
                self._system_prompt_hash = system_prompt_hash

    # -----------------------------------------------------------------
    # Shared helpers (pure sync, no I/O — used by both async and sync paths)
    # -----------------------------------------------------------------

    def _build_conversation_state(self) -> Optional[dict]:
        """Build conversation state dict for controlplane policy evaluation.

        Returns None if no trackable state has been recorded.
        """
        has_conversation = (
            self._conversation_user_turns > 0 or self._conversation_message_count > 0
        )
        has_code_executions = bool(self._code_executions)
        has_communications = bool(self._communications)
        has_data_accesses = bool(self._data_accesses)
        has_network_requests = bool(self._network_requests)
        has_scope_impacts = any(v for v in self._scope_impacts.values())
        has_grounding = bool(self._grounding_data)
        has_retrieval = bool(self._retrieval_results)
        has_reasoning = bool(self._decisions_buffer) or self._reasoning_depth > 0 or bool(self._bias_flags)
        has_delegation = bool(self._delegations) or self._is_delegate
        has_privacy = bool(self._privacy_context)
        has_identity = bool(self._intermediate_outputs) or bool(self._output_text)
        has_memory = bool(self._memory_state) or bool(self._memory_writes)
        has_tools_used = bool(self._tools_used_set)

        has_any = (
            has_conversation or has_code_executions or has_communications
            or has_data_accesses or has_network_requests or has_scope_impacts
            or has_grounding or has_retrieval or has_reasoning
            or has_delegation or has_privacy or has_identity or has_memory
            or has_tools_used
        )
        if not has_any:
            return None

        state: dict = {}
        if has_conversation:
            state.update({
                "user_turns": self._conversation_user_turns,
                "message_count": self._conversation_message_count,
                "assistant_turns": self._conversation_assistant_turns,
                "tool_results": self._conversation_tool_results,
                "tokens_in_context": self._context_tokens_used,
                "context_utilization_pct": round(self._context_utilization_pct, 1),
                "system_prompt_hash": self._system_prompt_hash,
            })
        if has_code_executions:
            state["code_executions"] = self._code_executions
        if has_communications:
            state["communications"] = self._communications
        if has_data_accesses:
            state["data_accesses"] = self._data_accesses
        if has_network_requests:
            state["network_requests"] = self._network_requests
        if has_scope_impacts:
            state["scope_impacts"] = self._scope_impacts
        if has_grounding:
            state["grounding_data"] = self._grounding_data
        if has_retrieval:
            state["retrieval_results"] = self._retrieval_results
        if has_reasoning:
            state["reasoning_data"] = {
                "decisions": self._decisions_buffer,
                "reasoning_depth": self._reasoning_depth,
                "bias_flags": self._bias_flags,
            }
        if has_delegation:
            state["delegation_data"] = {
                "delegations": self._delegations,
                "delegation_depth": self._delegation_depth,
                "concurrent_delegates": self._concurrent_delegates,
                "is_delegate": self._is_delegate,
                "parent_agent": self._parent_agent,
            }
        if has_privacy:
            state["privacy_context"] = self._privacy_context
        if has_identity:
            state["identity_context"] = {
                "intermediate_outputs": self._intermediate_outputs,
                "output_text": self._output_text,
            }
        if has_memory:
            mem = dict(self._memory_state)
            if self._memory_writes:
                mem["memory_writes"] = self._memory_writes
            state["memory_state"] = mem
        if has_tools_used:
            state["tools_used"] = list(self._tools_used_set)
        return state

    @staticmethod
    def _get_parent_ctx() -> Optional["WaxellContext"]:
        """Return the active parent WaxellContext, or None."""
        try:
            from .instrumentors._context_var import _current_context

            return _current_context.get()
        except Exception:
            return None

    def _detect_parent_context(self) -> tuple[str, str]:
        """Detect parent WaxellContext for automatic lineage.

        Returns ``(parent_workflow_id, root_workflow_id)``.
        Pure ContextVar read — no I/O.
        """
        parent_workflow_id = ""
        root_workflow_id = ""
        try:
            from .instrumentors._context_var import _current_context

            parent_ctx = _current_context.get()
            if parent_ctx is not None and parent_ctx._run_info:
                parent_workflow_id = parent_ctx._run_info.workflow_id
                root_workflow_id = (
                    getattr(parent_ctx, "_root_workflow_id", "") or parent_workflow_id
                )
        except Exception:
            pass
        return parent_workflow_id, root_workflow_id

    # Map string level names → logging constants
    _LOG_LEVEL_MAP = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }

    def _apply_audit_log_config(self) -> None:
        """Extract log capture config from audit policy evaluation metadata.

        Scans all audit evaluations and merges their log_config settings.
        Later evaluations (higher priority number = more specific) override
        earlier ones, so agent-specific policies win over global baselines.
        """
        for ev in self._pre_execution_evaluations:
            if ev.get("category") == "audit":
                meta = ev.get("metadata", {})
                log_config = meta.get("log_config", {})
                if log_config:
                    level_str = log_config.get("min_log_level", "INFO").upper()
                    self._log_min_level = self._LOG_LEVEL_MAP.get(level_str, logging.INFO)
                    self._log_max_entries = log_config.get("max_log_entries", 500)
                    self._log_capture_stdout = log_config.get("capture_stdout", False)

                # The main audit rules control which SDK log categories are emitted
                audit_rules = meta.get("audit_rules", {})
                if audit_rules:
                    self._log_inputs = audit_rules.get("log_inputs", True)
                    self._log_outputs = audit_rules.get("log_outputs", True)
                    self._log_steps = audit_rules.get("log_steps", True)
                    self._log_tool_calls = audit_rules.get("log_tool_calls", True)

    def _apply_code_execution_config(self) -> None:
        """Extract code-execution policy config from pre-execution evaluations.

        Scans evaluations for category == "code-execution" and extracts
        require_review from metadata. When require_review is true and
        on_policy_block is configured, record_code_execution() will trigger
        a human approval prompt before execution proceeds.
        """
        for ev in self._pre_execution_evaluations:
            if ev.get("category") == "code-execution":
                meta = ev.get("metadata", {})
                if meta.get("require_review", False):
                    self._code_review_required = True

    def _attach_stdout_capture(self) -> None:
        """Patch builtins.print to also log to OTel."""
        if _builtins.print is _capturing_print:
            return  # Already patched (nested context)
        self._stdout_capture = True  # Flag that we own the patch
        _builtins.print = _capturing_print

    def _detach_stdout_capture(self) -> None:
        """Restore original builtins.print."""
        if self._stdout_capture:
            # Only restore if we own the patch
            if _builtins.print is _capturing_print:
                _builtins.print = _original_print
            self._stdout_capture = None

    def _start_run_kwargs(
        self,
        parent_workflow_id: str,
        root_workflow_id: str,
    ) -> dict:
        """Build kwargs dict for start_run / start_run_sync."""
        kwargs: dict = dict(
            agent_name=self.agent_name,
            workflow_name=self.workflow_name,
            inputs=self.inputs,
            metadata=self.metadata,
            user_id=self.user_id,
            user_group=self.user_group,
            session_id=self.session_id,
            parent_workflow_id=parent_workflow_id,
            root_workflow_id=root_workflow_id,
            pre_execution_evaluations=self._pre_execution_evaluations or None,
        )
        return kwargs

    def _post_start_run(self, root_workflow_id: str) -> None:
        """Finalize state after start_run returns. No I/O."""
        self._root_workflow_id = root_workflow_id or (
            self._run_info.workflow_id if self._run_info else ""
        )
        if self._run_info and not self._run_info.run_id:
            logger.warning(
                "start_run returned empty run_id for agent=%s — "
                "the controlplane may be down or returned an error. "
                "Telemetry for this run will be dropped.",
                self.agent_name,
            )

    def _create_otel_span(self) -> None:
        """Create and activate the OTel agent span. No I/O."""
        try:
            extra_attrs = {}
            if self.session_id:
                extra_attrs[WaxellAttributes.SESSION_ID] = self.session_id
            if self.user_id:
                extra_attrs[WaxellAttributes.USER_ID] = self.user_id
            if self.user_group:
                extra_attrs[WaxellAttributes.USER_GROUP] = self.user_group

            self._span = start_agent_span(
                agent_name=self.agent_name,
                workflow_name=self.workflow_name,
                run_id=self._run_info.run_id if self._run_info else "",
                extra_attrs=extra_attrs,
            )
        except Exception:
            self._span = NoOpSpan()

        # Extract OTel trace context for correlation with the HTTP run record
        self._otel_trace_id, self._otel_span_id = self._extract_otel_trace_context()

        # Activate span as current context for child span parenting
        if _HAS_OTEL and self._span and not isinstance(self._span, NoOpSpan):
            try:
                from opentelemetry import trace as trace_api, context as context_api

                ctx = trace_api.set_span_in_context(self._span)
                self._otel_token = context_api.attach(ctx)
            except Exception:
                pass

    def _extract_otel_trace_context(self) -> tuple[str, str]:
        """Extract trace_id and span_id from the OTel agent span.

        Returns (trace_id_hex, span_id_hex) or ("", "") if unavailable.
        """
        if _HAS_OTEL and self._span and not isinstance(self._span, NoOpSpan):
            try:
                ctx = self._span.get_span_context()
                if ctx and ctx.trace_id:
                    trace_id = format(ctx.trace_id, "032x")
                    span_id = format(ctx.span_id, "016x")
                    return trace_id, span_id
            except Exception:
                pass
        return "", ""

    def _elapsed_ms(self) -> int:
        """Milliseconds elapsed since context entry."""
        if self._context_start_ms == 0.0:
            return 0
        return int(time.monotonic() * 1000 - self._context_start_ms)

    def _activate_context_var(self) -> None:
        """Set self as current WaxellContext for instrumentor dual-path recording."""
        try:
            from .instrumentors._context_var import _current_context

            self._context_token = _current_context.set(self)
        except Exception:
            pass

    def _emit_governance_otel_spans(self) -> None:
        """Emit OTel spans for pre-execution policy evaluations.

        Server stores governance events+spans during start_run; here we only
        emit OTel spans for non-allow results to avoid flooding the console
        and Tempo with routine allow spans.
        """
        for ev in self._pre_execution_evaluations:
            action = ev.get("action", "allow")
            if action == "allow":
                continue
            try:
                span = start_governance_span(
                    policy_name=ev.get("policy_name", "unknown"),
                    action=action,
                    category=ev.get("category", ""),
                )
                reason = ev.get("reason", "")
                if reason:
                    span.set_attribute("waxell.policy.reason", reason)
                span.end()
            except Exception:
                pass

    def _determine_exit_status(
        self, exc_type, exc_val, exc_tb=None
    ) -> tuple[str, str, str, str]:
        """Compute run status, error message, error type, and traceback on exit.

        Returns (status, error_message, error_type, traceback_str).
        """
        if self._governance_blocked and not exc_type:
            return (
                "blocked",
                self._governance_reason,
                "PolicyViolationError",
                "",
            )
        # Mid-execution policy blocks (e.g. code-execution governance) raise
        # PolicyViolationError — treat these as "blocked", not runtime errors.
        if exc_type and issubclass(exc_type, PolicyViolationError):
            return (
                "blocked",
                str(exc_val) if exc_val else "Policy violation",
                "PolicyViolationError",
                "",
            )
        status = "error" if exc_type else "success"
        error = str(exc_val) if exc_val else ""
        error_type = exc_type.__name__ if exc_type else ""
        tb_str = ""
        if exc_type and exc_val and exc_tb:
            try:
                tb_str = "".join(
                    _traceback_mod.format_exception(exc_type, exc_val, exc_tb)
                )
            except Exception:
                tb_str = ""
        return status, error, error_type, tb_str

    def _end_otel_span(self, exc_type, exc_val) -> None:
        """End the OTel span and set status."""
        if self._span and not isinstance(self._span, NoOpSpan):
            try:
                if _HAS_OTEL:
                    from opentelemetry.trace import StatusCode, Status

                    # Policy blocks are expected — mark span OK, not ERROR
                    is_policy_block = exc_type and issubclass(
                        exc_type, PolicyViolationError
                    )
                    if exc_type and not is_policy_block:
                        self._span.set_status(Status(StatusCode.ERROR, str(exc_val)))
                        self._span.record_exception(exc_val)
                    else:
                        self._span.set_status(Status(StatusCode.OK))
                self._span.end()
            except Exception:
                pass

    def _detach_otel_context(self) -> None:
        """Detach OTel context token."""
        if self._otel_token is not None:
            try:
                from opentelemetry import context as context_api

                context_api.detach(self._otel_token)
            except Exception:
                pass
            self._otel_token = None

    def _clear_context_var(self) -> None:
        """Reset the ContextVar token."""
        if self._context_token is not None:
            try:
                from .instrumentors._context_var import _current_context

                _current_context.reset(self._context_token)
            except Exception:
                pass
            self._context_token = None

    def _inject_summary_into_parent(self, status: str) -> None:
        """Inject a summary span into the parent context's span buffer.

        Called from __aexit__/__exit__ after flushing own data. The parent
        has not yet exited, so its _spans buffer is still collecting spans
        that will be flushed when the parent exits.

        Uses parent._lock to prevent race conditions when multiple children
        exit concurrently (e.g. via asyncio.gather with run_in_executor).
        """
        parent = self._parent_ctx_ref
        if not parent or not parent._run_info:
            return

        # Calculate time offset relative to parent's start (read-only, no lock needed)
        start_offset = 0
        if parent._context_start_ms and self._context_start_ms:
            start_offset = max(
                0, int(self._context_start_ms - parent._context_start_ms)
            )

        with parent._lock:
            parent._step_counter += 1

            parent._spans.append(
                {
                    "name": f"{self.agent_name}.{self.workflow_name}",
                    "kind": "agent",
                    "status": "error" if status == "error" else "ok",
                    "duration_ms": self._elapsed_ms(),
                    "position": parent._step_counter,
                    "start_offset_ms": start_offset,
                    "parent_position": parent._current_step_position,
                    "attributes": {
                        "agent_name": self.agent_name,
                        "workflow_name": self.workflow_name,
                        "child_run_id": self.run_id,
                        "tokens_in": self._total_tokens_in,
                        "tokens_out": self._total_tokens_out,
                        "total_tokens": self._total_tokens_in + self._total_tokens_out,
                        "cost": round(self._total_cost, 6),
                        "llm_calls": self._total_llm_calls,
                    },
                    "input_data": self.inputs if self.inputs else None,
                    "output_data": self._result if self._result else None,
                }
            )

            # Transitive rollup: grandchild -> child -> parent
            parent._total_tokens_in += self._total_tokens_in
            parent._total_tokens_out += self._total_tokens_out
            parent._total_cost += self._total_cost
            parent._total_llm_calls += self._total_llm_calls

    # -----------------------------------------------------------------
    # Blocked-run helpers (shared by __aenter__ and __enter__)
    # -----------------------------------------------------------------

    async def _record_blocked_and_raise(
        self, policy, parent_workflow_id, root_workflow_id
    ):
        """Record a blocked run on the controlplane and raise PolicyViolationError."""
        try:
            run_info = await self.client.start_run(
                **self._start_run_kwargs(parent_workflow_id, root_workflow_id),
            )
            if run_info and run_info.run_id:
                await self.client.complete_run(
                    run_id=run_info.run_id,
                    status="blocked",
                    error=f"Policy violation: {policy.reason}",
                    result={"blocked_by": policy.reason},
                )
        except Exception:
            logger.debug(
                "Failed to record blocked run for agent=%s: %s",
                self.agent_name,
                policy.reason,
                exc_info=True,
            )
        raise PolicyViolationError(policy.reason, policy)

    def _record_blocked_and_raise_sync(
        self, policy, parent_workflow_id, root_workflow_id
    ):
        """Sync version of _record_blocked_and_raise."""
        try:
            run_info = self.client.start_run_sync(
                **self._start_run_kwargs(parent_workflow_id, root_workflow_id),
            )
            if run_info and run_info.run_id:
                self.client.complete_run_sync(
                    run_id=run_info.run_id,
                    status="blocked",
                    error=f"Policy violation: {policy.reason}",
                    result={"blocked_by": policy.reason},
                )
        except Exception:
            logger.debug(
                "Failed to record blocked run for agent=%s: %s",
                self.agent_name,
                policy.reason,
                exc_info=True,
            )
        raise PolicyViolationError(policy.reason, policy)

    # -----------------------------------------------------------------
    # Async context manager
    # -----------------------------------------------------------------

    async def __aenter__(self) -> "WaxellContext":
        # 1. Save parent reference + detect lineage (needed for both
        #    blocked and normal paths so blocked runs get proper lineage)
        try:
            from .instrumentors._context_var import _current_context

            self._parent_ctx_ref = _current_context.get()
        except Exception:
            self._parent_ctx_ref = None

        parent_workflow_id, root_workflow_id = self._detect_parent_context()

        # 1b. Auto-record delegation on parent context.
        # When a child @waxell.observe agent starts inside a parent context,
        # automatically record the delegation so the parent's delegation
        # policy handler can evaluate it (and block if needed).
        if self._parent_ctx_ref is not None:
            self._parent_ctx_ref.record_delegation(
                delegate=self.agent_name,
                depth=self._parent_ctx_ref._delegation_depth + 1,
            )

        # 2. Check policy
        self._pre_execution_evaluations: list[dict] = []
        if self.enforce_policy:
            policy = await self.client.check_policy(
                agent_name=self.agent_name,
                workflow_name=self.workflow_name,
                inputs=self.inputs or None,
                user_id=self.user_id,
                user_group=self.user_group,
            )
            self._pre_execution_evaluations = policy.evaluations or []
            if policy.blocked:
                if self._on_policy_block is not None:
                    from .approval import handle_policy_block

                    error = PolicyViolationError(policy.reason, policy)
                    decision = await handle_policy_block(self._on_policy_block, error)
                    if decision.approved:
                        self.enforce_policy = False
                        # Fall through to normal startup below
                    else:
                        await self._record_blocked_and_raise(
                            policy, parent_workflow_id, root_workflow_id
                        )
                else:
                    await self._record_blocked_and_raise(
                        policy, parent_workflow_id, root_workflow_id
                    )
            elif policy.should_redact and policy.redacted_inputs:
                # Replace inputs with redacted version so the agent
                # function receives sanitised data (no PII/creds).
                self._setup_content_redaction(self.inputs, policy.redacted_inputs)
                self.inputs = policy.redacted_inputs
                self._content_redacted = True

        # 2b. Apply policy config from evaluations
        self._apply_audit_log_config()
        self._apply_code_execution_config()

        # 3. Start run (lineage already detected above)
        self._run_info = await self.client.start_run(
            **self._start_run_kwargs(parent_workflow_id, root_workflow_id),
        )
        self._post_start_run(root_workflow_id)

        # 4. OTel span, ContextVar activation, governance spans
        self._create_otel_span()
        self._activate_context_var()
        self._emit_governance_otel_spans()
        self._context_start_ms = time.monotonic() * 1000
        self._context_start_wall_ms = time.time() * 1000

        # 5. Attach stdout capture if audit policy requests it
        if self._log_capture_stdout:
            self._attach_stdout_capture()

        if self._log_inputs:
            logger.info(
                "Agent execution started: %s.%s (run_id=%s)",
                self.agent_name,
                self.workflow_name,
                self._run_info.run_id if self._run_info else "?",
            )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        status, error, error_type, tb_str = self._determine_exit_status(
            exc_type, exc_val, exc_tb
        )

        elapsed = self._elapsed_ms()
        if exc_type and issubclass(exc_type, PolicyViolationError):
            if self._log_outputs:
                logger.info(
                    "Agent execution blocked by policy: %s.%s (%s) [%.1fs]",
                    self.agent_name,
                    self.workflow_name,
                    error,
                    (elapsed or 0) / 1000,
                )
        elif exc_type:
            if self._log_outputs:
                logger.error(
                    "Agent execution failed: %s.%s (%s: %s) [%.1fs]",
                    self.agent_name,
                    self.workflow_name,
                    error_type,
                    error,
                    (elapsed or 0) / 1000,
                )
        else:
            if self._log_outputs:
                logger.info(
                    "Agent execution completed: %s.%s [%.1fs, %d LLM calls, %d tokens, $%.4f]",
                    self.agent_name,
                    self.workflow_name,
                    (elapsed or 0) / 1000,
                    self._total_llm_calls,
                    self._total_tokens_in + self._total_tokens_out,
                    self._total_cost,
                )

        # Detach stdout capture before flushing
        self._detach_stdout_capture()

        # Force-flush logs while trace context is still active so
        # BatchLogRecordProcessor exports before the span ends.
        try:
            from .tracing import flush_tracing
            flush_tracing(timeout_millis=5000)
        except Exception:
            pass

        self._end_otel_span(exc_type, exc_val)
        self._detach_otel_context()
        self._clear_context_var()

        if not self._run_info or not self._run_info.run_id:
            return False

        try:
            if self._llm_calls:
                await self.client.record_llm_calls(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                )
            if self._steps:
                await self.client.record_steps(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                )
            if self._scores:
                await self.client.record_scores(
                    run_id=self._run_info.run_id,
                    scores=self._scores,
                )
            # Merge auto-instrumented OTel spans (deduplicating LLM spans
            # that were already recorded via record_llm_call)
            self._merge_otel_spans()
            # Remove placeholder retrieval spans from auto-instrumentors
            # when the user has explicit @waxell.retrieval with real data
            self._deduplicate_retrieval_spans()

            # Insert root agent span with total duration
            # Policy blocks are expected control flow, not errors
            is_policy_block = exc_type and issubclass(
                exc_type, PolicyViolationError
            )
            is_real_error = exc_type and not is_policy_block
            root_attrs: dict[str, Any] = {
                "agent_name": self.agent_name,
                "workflow_name": self.workflow_name,
            }
            if self._detected_integrations:
                root_attrs["waxell.integrations"] = self._detected_integrations
            root_span = {
                "name": f"{self.agent_name}.{self.workflow_name}",
                "kind": "agent",
                "status": "error" if is_real_error else "ok",
                "duration_ms": self._elapsed_ms(),
                "position": 0,
                "start_offset_ms": 0,
                "parent_position": None,
                "attributes": root_attrs,
                "input_data": self.inputs if self.inputs else None,
                "output_data": self._result if self._result else None,
            }
            if is_real_error:
                root_span["attributes"]["error.type"] = error_type
                root_span["attributes"]["error.message"] = error
                root_span["events"] = [
                    {
                        "name": "exception",
                        "attributes": {
                            "exception.type": error_type,
                            "exception.message": error,
                            "exception.stacktrace": tb_str,
                        },
                    }
                ]
            self._spans.insert(0, root_span)
            if self._spans:
                await self.client.record_spans(
                    run_id=self._run_info.run_id,
                    spans=self._spans,
                )
            complete_result = await self.client.complete_run(
                run_id=self._run_info.run_id,
                result=self._result,
                status=status,
                error=error,
                error_type=error_type,
                traceback=tb_str,
                trace_id=self._otel_trace_id,
                root_span_id=self._otel_span_id,
                conversation_state=self._build_conversation_state(),
            )
        except PolicyViolationError:
            raise
        except Exception as e:
            logger.warning(f"Failed to flush observe context: {e}")
            complete_result = None

        # Inject summary span into parent's trace buffer
        try:
            self._inject_summary_into_parent(status)
        except Exception:
            logger.debug(
                "Failed to inject summary into parent for agent=%s",
                self.agent_name,
                exc_info=True,
            )

        # After-workflow governance: if the server returned BLOCK and
        # the original function succeeded, raise PolicyViolationError
        # so the caller knows the output should not be used.
        if (
            complete_result
            and not exc_type
            and self.enforce_policy
            and complete_result.governance_action == "block"
        ):
            raise PolicyViolationError(complete_result.governance_reason)

        return False  # Don't suppress exceptions

    # -----------------------------------------------------------------
    # Sync context manager
    # -----------------------------------------------------------------

    def __enter__(self) -> "WaxellContext":
        # 1. Save parent reference + detect lineage (needed for both
        #    blocked and normal paths so blocked runs get proper lineage)
        try:
            from .instrumentors._context_var import _current_context

            self._parent_ctx_ref = _current_context.get()
        except Exception:
            self._parent_ctx_ref = None

        parent_workflow_id, root_workflow_id = self._detect_parent_context()

        # 1b. Auto-record delegation on parent context.
        if self._parent_ctx_ref is not None:
            self._parent_ctx_ref.record_delegation(
                delegate=self.agent_name,
                depth=self._parent_ctx_ref._delegation_depth + 1,
            )

        # 2. Check policy (sync I/O)
        self._pre_execution_evaluations: list[dict] = []
        if self.enforce_policy:
            policy = self.client.check_policy_sync(
                agent_name=self.agent_name,
                workflow_name=self.workflow_name,
                inputs=self.inputs or None,
                user_id=self.user_id,
                user_group=self.user_group,
            )
            self._pre_execution_evaluations = policy.evaluations or []
            if policy.blocked:
                if self._on_policy_block is not None:
                    from .approval import handle_policy_block_sync

                    error = PolicyViolationError(policy.reason, policy)
                    decision = handle_policy_block_sync(self._on_policy_block, error)
                    if decision.approved:
                        self.enforce_policy = False
                        # Fall through to normal startup below
                    else:
                        self._record_blocked_and_raise_sync(
                            policy, parent_workflow_id, root_workflow_id
                        )
                else:
                    self._record_blocked_and_raise_sync(
                        policy, parent_workflow_id, root_workflow_id
                    )
            elif policy.should_redact and policy.redacted_inputs:
                self._setup_content_redaction(self.inputs, policy.redacted_inputs)
                self.inputs = policy.redacted_inputs
                self._content_redacted = True

        # 2b. Apply policy config from evaluations
        self._apply_audit_log_config()
        self._apply_code_execution_config()

        # 3. Start run (lineage already detected above)
        self._run_info = self.client.start_run_sync(
            **self._start_run_kwargs(parent_workflow_id, root_workflow_id),
        )
        self._post_start_run(root_workflow_id)

        # 4. OTel span, ContextVar activation, governance spans
        #    All pure sync — executed in the calling thread so auto-instrumentors
        #    see _current_context via ContextVar.
        self._create_otel_span()
        self._activate_context_var()
        self._emit_governance_otel_spans()
        self._context_start_ms = time.monotonic() * 1000
        self._context_start_wall_ms = time.time() * 1000

        # 5. Attach stdout capture if audit policy requests it
        if self._log_capture_stdout:
            self._attach_stdout_capture()

        if self._log_inputs:
            logger.info(
                "Agent execution started: %s.%s (run_id=%s)",
                self.agent_name,
                self.workflow_name,
                self._run_info.run_id if self._run_info else "?",
            )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        status, error, error_type, tb_str = self._determine_exit_status(
            exc_type, exc_val, exc_tb
        )

        elapsed = self._elapsed_ms()
        if exc_type and issubclass(exc_type, PolicyViolationError):
            if self._log_outputs:
                logger.info(
                    "Agent execution blocked by policy: %s.%s (%s) [%.1fs]",
                    self.agent_name,
                    self.workflow_name,
                    error,
                    (elapsed or 0) / 1000,
                )
        elif exc_type:
            if self._log_outputs:
                logger.error(
                    "Agent execution failed: %s.%s (%s: %s) [%.1fs]",
                    self.agent_name,
                    self.workflow_name,
                    error_type,
                    error,
                    (elapsed or 0) / 1000,
                )
        else:
            if self._log_outputs:
                logger.info(
                    "Agent execution completed: %s.%s [%.1fs, %d LLM calls, %d tokens, $%.4f]",
                    self.agent_name,
                    self.workflow_name,
                    (elapsed or 0) / 1000,
                    self._total_llm_calls,
                    self._total_tokens_in + self._total_tokens_out,
                    self._total_cost,
                )

        # Detach stdout capture before flushing
        self._detach_stdout_capture()

        # Force-flush logs while trace context is still active so
        # BatchLogRecordProcessor exports before the span ends.
        try:
            from .tracing import flush_tracing
            flush_tracing(timeout_millis=5000)
        except Exception:
            pass

        self._end_otel_span(exc_type, exc_val)
        self._detach_otel_context()
        self._clear_context_var()

        if not self._run_info or not self._run_info.run_id:
            return False

        try:
            if self._llm_calls:
                self.client.record_llm_calls_sync(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                )
            if self._steps:
                self.client.record_steps_sync(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                )
            if self._scores:
                self.client.record_scores_sync(
                    run_id=self._run_info.run_id,
                    scores=self._scores,
                )
            # Merge auto-instrumented OTel spans (deduplicating LLM spans
            # that were already recorded via record_llm_call)
            self._merge_otel_spans()
            # Remove placeholder retrieval spans from auto-instrumentors
            # when the user has explicit @waxell.retrieval with real data
            self._deduplicate_retrieval_spans()

            # Insert root agent span with total duration
            # Policy blocks are expected control flow, not errors
            is_policy_block = exc_type and issubclass(
                exc_type, PolicyViolationError
            )
            is_real_error = exc_type and not is_policy_block
            root_attrs: dict[str, Any] = {
                "agent_name": self.agent_name,
                "workflow_name": self.workflow_name,
            }
            if self._detected_integrations:
                root_attrs["waxell.integrations"] = self._detected_integrations
            root_span = {
                "name": f"{self.agent_name}.{self.workflow_name}",
                "kind": "agent",
                "status": "error" if is_real_error else "ok",
                "duration_ms": self._elapsed_ms(),
                "position": 0,
                "start_offset_ms": 0,
                "parent_position": None,
                "attributes": root_attrs,
                "input_data": self.inputs if self.inputs else None,
                "output_data": self._result if self._result else None,
            }
            if is_real_error:
                root_span["attributes"]["error.type"] = error_type
                root_span["attributes"]["error.message"] = error
                root_span["events"] = [
                    {
                        "name": "exception",
                        "attributes": {
                            "exception.type": error_type,
                            "exception.message": error,
                            "exception.stacktrace": tb_str,
                        },
                    }
                ]
            self._spans.insert(0, root_span)
            if self._spans:
                self.client.record_spans_sync(
                    run_id=self._run_info.run_id,
                    spans=self._spans,
                )
            complete_result = self.client.complete_run_sync(
                run_id=self._run_info.run_id,
                result=self._result,
                status=status,
                error=error,
                error_type=error_type,
                traceback=tb_str,
                trace_id=self._otel_trace_id,
                root_span_id=self._otel_span_id,
                conversation_state=self._build_conversation_state(),
            )
        except PolicyViolationError:
            raise
        except Exception as e:
            logger.warning(f"Failed to flush observe context: {e}")
            complete_result = None

        # Inject summary span into parent's trace buffer
        try:
            self._inject_summary_into_parent(status)
        except Exception:
            logger.debug(
                "Failed to inject summary into parent for agent=%s",
                self.agent_name,
                exc_info=True,
            )

        # After-workflow governance: if the server returned BLOCK and
        # the original function succeeded, raise PolicyViolationError
        # so the caller knows the output should not be used.
        if (
            complete_result
            and not exc_type
            and self.enforce_policy
            and complete_result.governance_action == "block"
        ):
            raise PolicyViolationError(complete_result.governance_reason)

        return False  # Don't suppress exceptions

    # -----------------------------------------------------------------
    # Recording methods
    # -----------------------------------------------------------------

    @property
    def run_id(self) -> str:
        """The run ID from the controlplane, or empty string if not started."""
        return self._run_info.run_id if self._run_info else ""

    def record_llm_call(
        self,
        *,
        model: str,
        tokens_in: int,
        tokens_out: int,
        cost: float = 0.0,
        task: str = "",
        prompt_preview: str = "",
        response_preview: str = "",
        duration_ms: int | None = None,
        provider: str = "",
        framework: str = "",
        _auto_instrumented: bool = False,
    ) -> None:
        """Buffer an LLM call for later flushing and emit an OTel span.

        Args:
            provider: Explicit provider name (e.g. "groq", "openai").
                When empty, inferred from model name.
            framework: AI framework name (e.g. "langchain", "crewai").
                Stored as ``waxell.framework`` on the span so the
                controlplane can detect which framework was used.
            _auto_instrumented: Internal flag set by auto-instrumentors.
                Enables dedup when both auto and manual recording fire
                for the same call.
        """
        # Apply content redaction to previews before storage
        prompt_preview = self._redact_text(prompt_preview)
        response_preview = self._redact_text(response_preview)

        # Dedup + counter mutations under lock to prevent race conditions
        # when multiple LLM calls fire concurrently (e.g. run_in_executor).
        with self._lock:
            sig = (model, tokens_in, tokens_out)
            if _auto_instrumented:
                self._auto_recorded_counts[sig] = (
                    self._auto_recorded_counts.get(sig, 0) + 1
                )
            elif self._auto_recorded_counts.get(sig, 0) > 0:
                # Manual call for something auto-instrumentor already captured
                self._auto_recorded_counts[sig] -= 1
                return

            if cost == 0.0:
                cost = estimate_cost(model, tokens_in, tokens_out)
            self._total_tokens_in += tokens_in
            self._total_tokens_out += tokens_out
            self._total_cost += cost
            self._total_llm_calls += 1
            self._step_counter += 1
            self._llm_calls.append(
                {
                    "model": model,
                    "tokens_in": tokens_in,
                    "tokens_out": tokens_out,
                    "cost": cost,
                    "task": task,
                    "prompt_preview": prompt_preview,
                    "response_preview": response_preview,
                }
            )

            # Also buffer as a behavior span for the Django Span table
            resolved_provider = provider or _infer_provider(model)
            span_attrs = {
                "model": model,
                "waxell.llm.model": model,
                "gen_ai.provider.name": resolved_provider,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "waxell.llm.input_tokens": tokens_in,
                "waxell.llm.output_tokens": tokens_out,
                "total_tokens": tokens_in + tokens_out,
                "cost": cost,
                "waxell.llm.cost": cost,
                "task": task or None,
                "waxell.context.message_count": self._conversation_message_count,
                "waxell.context.user_turns": self._conversation_user_turns,
                "waxell.context.tokens_used": self._context_tokens_used,
                "waxell.context.utilization_pct": self._context_utilization_pct,
            }
            if framework:
                span_attrs["waxell.framework"] = framework
            self._spans.append(
                {
                    "name": f"chat {model}",
                    "kind": "llm",
                    "status": "ok",
                    "duration_ms": duration_ms,
                    "position": self._step_counter,
                    "start_offset_ms": self._elapsed_ms(),
                    "parent_position": self._current_step_position,
                    "attributes": span_attrs,
                    "input_data": {"prompt_preview": prompt_preview}
                    if prompt_preview
                    else None,
                    "output_data": {"response_preview": response_preview}
                    if response_preview
                    else None,
                }
            )

        # Emit OTel LLM span (dual data path)
        try:
            capture = False
            try:
                from .tracing import _capture_content

                capture = _capture_content
            except ImportError:
                pass

            span = start_llm_span(
                model=model,
                provider_name=resolved_provider,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                cost=cost,
                task=task,
                capture_content=capture,
                input_messages=prompt_preview,
                output_messages=response_preview,
            )
            span.end()
        except Exception:
            pass

        if self._log_steps:
            logger.info(
                "LLM call: %s (%s) %d+%d tokens $%.4f%s",
                model,
                resolved_provider,
                tokens_in,
                tokens_out,
                cost,
                f" task={task}" if task else "",
            )

    def _record_integration(self, name: str, category: str) -> None:
        """Register an auto-detected integration (called by instrumentors).

        Stored on the root agent span so the controlplane can show every
        library that was auto-instrumented during this execution.

        Args:
            name: Integration display name (e.g. "OpenAI", "LangChain", "FAISS").
            category: One of "llm", "framework", "retrieval", "embedding",
                "safety", "eval", "reranking", "speech", "tool".
        """
        with self._lock:
            self._detected_integrations[name] = category

    def _annotate_framework(self, framework: str, model: str = "") -> None:
        """Tag the most recent LLM span with the AI framework that invoked it.

        Called by framework instrumentors (e.g. LangChain) AFTER the LLM
        instrumentor has already recorded the call.  Searches ``_spans``
        in reverse for a matching LLM span and adds ``waxell.framework``.
        """
        with self._lock:
            for s in reversed(self._spans):
                if s.get("kind") != "llm":
                    continue
                s_attrs = s.get("attributes") or {}
                if model and s_attrs.get("model") != model:
                    continue
                if "waxell.framework" not in s_attrs:
                    s_attrs["waxell.framework"] = framework
                break

    def record_step(self, step_name: str, output: Optional[dict] = None) -> None:
        """Buffer an execution step and optionally flush for mid-execution governance."""
        with self._lock:
            self._step_counter += 1
            self._current_step_position = self._step_counter
            self._steps.append(
                {
                    "step_name": step_name,
                    "output": output or {},
                    "position": self._step_counter,
                }
            )

            # Also buffer as a behavior span for the Django Span table (Trace tab)
            self._spans.append(
                {
                    "name": step_name,
                    "kind": "chain",
                    "status": "ok",
                    "duration_ms": None,
                    "position": self._step_counter,
                    "start_offset_ms": self._elapsed_ms(),
                    "parent_position": None,
                    "attributes": {},
                    "input_data": None,
                    "output_data": output if output else None,
                }
            )

            step_position = self._step_counter

        # Emit OTel step span (dual data path) — outside lock (no shared state)
        try:
            span = start_step_span(
                step_name=step_name,
                position=step_position,
            )
            span.end()
        except Exception:
            pass

        if self._log_steps:
            logger.info("Step: %s", step_name)

        # Mid-execution governance: flush and check policy
        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def set_result(self, result: dict) -> None:
        """Set the result to include when the run is completed."""
        self._result = result

    def record_score(
        self,
        name: str,
        value: float | str | bool,
        data_type: str = "numeric",
        comment: str = "",
    ) -> None:
        """Buffer a score (user feedback) for the current run.

        Args:
            name: Score name (e.g. "thumbs_up", "accuracy", "relevance").
            value: Score value — float for numeric, str for categorical, bool for boolean.
            data_type: One of "numeric", "categorical", "boolean".
            comment: Optional free-text comment.
        """
        score: dict = {
            "name": name,
            "data_type": data_type,
            "comment": comment,
        }
        if data_type == "numeric":
            score["numeric_value"] = float(value)
        elif data_type == "boolean":
            score["numeric_value"] = 1.0 if value else 0.0
            score["string_value"] = str(bool(value)).lower()
        else:
            score["string_value"] = str(value)
        self._scores.append(score)

    # -----------------------------------------------------------------
    # Content redaction
    # -----------------------------------------------------------------

    def _setup_content_redaction(
        self, original_inputs: dict | None, redacted_inputs: dict,
    ) -> None:
        """Build a redaction function from the diff between original and redacted inputs.

        Extracts sensitive fragments from the original values and builds a
        replacement map.  The resulting ``_content_redact_fn`` applies all
        replacements to any string — used by ``record_user_message``,
        ``record_llm_call`` (prompt_preview), and span data so raw PII /
        credentials never reach storage.
        """
        if not original_inputs:
            return

        import re as _re

        replacements: list[tuple[str, str]] = []
        for key in redacted_inputs:
            orig = original_inputs.get(key)
            redd = redacted_inputs.get(key)
            if isinstance(orig, str) and isinstance(redd, str) and orig != redd:
                # Extract sensitive fragments by aligning the redacted string
                # (with [REDACTED:type] markers) against the original.
                parts = _re.split(r"(\[REDACTED:\w+\])", redd)
                pos = 0
                for i, part in enumerate(parts):
                    if part.startswith("[REDACTED:"):
                        # Find the next non-empty literal after this marker
                        next_literal = ""
                        for j in range(i + 1, len(parts)):
                            if parts[j] and not parts[j].startswith("[REDACTED:"):
                                next_literal = parts[j]
                                break

                        if next_literal:
                            end_idx = orig.find(next_literal, pos)
                            if end_idx >= 0:
                                sensitive = orig[pos:end_idx]
                                if sensitive:
                                    replacements.append((sensitive, part))
                                pos = end_idx
                        else:
                            # Marker is at the end (no trailing literal)
                            sensitive = orig[pos:]
                            if sensitive:
                                replacements.append((sensitive, part))
                            pos = len(orig)
                    elif part:
                        idx = orig.find(part, pos)
                        if idx >= 0:
                            pos = idx + len(part)

        if not replacements:
            return

        # Sort by length descending so longer matches replace first
        replacements.sort(key=lambda t: len(t[0]), reverse=True)

        def _redact(text: str) -> str:
            for sensitive, replacement in replacements:
                text = text.replace(sensitive, replacement)
            return text

        self._content_redact_fn = _redact

    def _redact_text(self, text: str) -> str:
        """Apply content redaction if active. No-op otherwise."""
        if self._content_redact_fn and text:
            return self._content_redact_fn(text)
        return text

    def _redact_dict(self, data: dict | str | None) -> dict | str | None:
        """Recursively redact string values in a dict."""
        if data is None:
            return None
        if isinstance(data, str):
            return self._redact_text(data)
        if isinstance(data, dict):
            return {k: self._redact_dict(v) for k, v in data.items()}
        if isinstance(data, list):
            return [self._redact_dict(item) for item in data]
        return data

    # -----------------------------------------------------------------
    # Pre-execution tool governance
    # -----------------------------------------------------------------

    def check_tool_before_execution(self, tool_name: str) -> None:
        """Check governance BEFORE a tool executes.

        Adds the tool to ``_tools_used_set`` and flushes a governance check.
        If the server returns a block action (e.g. blocked_tools policy),
        raises ``PolicyViolationError`` so the tool never runs.

        Called by:
          - ``@waxell.tool()`` decorator (before ``func()``)
          - LangChain instrumentor ``on_tool_start`` callback
        """
        if not self._mid_execution_governance or not self._run_info:
            return
        self._tools_used_set.add(tool_name)
        self._flush_and_check_governance()

    # -----------------------------------------------------------------
    # Behavior tracking methods
    # -----------------------------------------------------------------

    def record_tool_call(
        self,
        *,
        name: str,
        input: dict | str = "",
        output: dict | str = "",
        duration_ms: int | None = None,
        status: str = "ok",
        tool_type: str = "function",
        error: str = "",
        _skip_otel: bool = False,
        _skip_step: bool = False,
    ) -> None:
        """Buffer a tool call event and emit an OTel span.

        Args:
            name: Tool name (e.g. "web_search", "database_query").
            input: Tool input parameters.
            output: Tool output/result.
            duration_ms: Execution time in milliseconds.
            status: "ok" or "error".
            tool_type: Classification ("function", "api", "database", "retriever").
            error: Error message if status is "error".
            _skip_otel: If True, skip creating an OTel span (caller already
                created one that wraps the execution).
            _skip_step: If True, skip adding to the ``_steps`` buffer (only
                add to ``_spans``). Use this for auto-instrumented tool calls
                where the step entry would duplicate the span entry in the
                trace UI.
        """
        # Redact sensitive content from tool inputs/outputs
        input = self._redact_dict(input)
        output = self._redact_dict(output)

        self._step_counter += 1
        self._tools_used_set.add(name)
        if not _skip_step:
            self._steps.append(
                {
                    "step_name": f"tool:{name}",
                    "output": {
                        "_kind": "tool_call",
                        "name": name,
                        "status": status,
                        "error": error,
                    },
                    "position": self._step_counter,
                }
            )
        self._spans.append(
            {
                "name": name,
                "kind": "tool",
                "status": status,
                "duration_ms": duration_ms,
                "position": self._step_counter,
                "start_offset_ms": self._elapsed_ms(),
                "parent_position": self._current_step_position,
                "attributes": {"tool_type": tool_type, "error": error}
                if error
                else {"tool_type": tool_type},
                "input_data": input
                if isinstance(input, dict)
                else {"raw": input}
                if input
                else None,
                "output_data": output
                if isinstance(output, dict)
                else {"raw": output}
                if output
                else None,
            }
        )

        if not _skip_otel:
            try:
                span = start_tool_span(tool_name=name, tool_type=tool_type)
                if error:
                    span.set_attribute("error.message", error)
                span.end()
            except Exception:
                pass

        if self._log_tool_calls:
            if status == "error":
                logger.warning("Tool call failed: %s (%s) %s", name, tool_type, error)
            else:
                logger.info(
                    "Tool call: %s (%s)%s",
                    name,
                    tool_type,
                    f" {duration_ms}ms" if duration_ms else "",
                )

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_code_execution(
        self,
        *,
        language: str,
        code: str,
        execution_time: float = 0,
        output_size_kb: int = 0,
        output: str = "",
        error: str = "",
        paths: list[str] | None = None,
        packages: list[str] | None = None,
        _skip_otel: bool = False,
    ) -> None:
        """Buffer a code execution event with span + governance enforcement.

        Creates a span in the trace tree (visible in execution detail),
        buffers for the Django Span table, and triggers mid-execution
        governance so the code-execution handler can validate language,
        commands, paths, packages, execution time, and output size.

        Args:
            language: Programming language (e.g. "python", "javascript").
            code: The code that was/will be executed.
            execution_time: Execution duration in seconds.
            output_size_kb: Size of execution output in KB.
            output: Execution stdout/result text (for trace display).
            error: Execution error text (for trace display).
            paths: File system paths accessed by the code.
            packages: Packages imported or installed by the code.
            _skip_otel: If True, skip OTel span (caller already created one).
        """
        execution = {
            "language": language,
            "code": code,
            "execution_time": execution_time,
            "output_size_kb": output_size_kb,
            "paths": paths or [],
            "packages": packages or [],
        }

        # If require_review is set, gate execution on human approval
        if self._code_review_required and self._on_policy_block:
            from .approval import handle_policy_block_sync
            from .types import PolicyCheckResult as _PCR

            review_reason = (
                f"Code execution review required.\n"
                f"Language: {language}\n"
                f"Code:\n{code[:1000]}"
            )
            review_policy = _PCR(
                action="block",
                reason=review_reason,
                metadata={"action_type": "code_execution", "language": language},
            )
            pve = PolicyViolationError(review_reason, review_policy)
            decision = handle_policy_block_sync(self._on_policy_block, pve)
            if not decision.approved:
                raise PolicyViolationError(
                    f"Code execution denied by reviewer ({language})"
                )

        duration_ms = int(execution_time * 1000) if execution_time else None

        with self._lock:
            self._code_executions.append(execution)
            self._step_counter += 1
            step_pos = self._step_counter

            # Buffer step for controlplane
            self._steps.append(
                {
                    "step_name": f"code_exec:{language}",
                    "output": {
                        "_kind": "code_execution",
                        "language": language,
                        "code_preview": code[:500],
                        "output_preview": output[:500] if output else "",
                        "error": error[:500] if error else "",
                        "packages": packages or [],
                    },
                    "position": step_pos,
                }
            )

            # Buffer span for Django Span table (Trace tab)
            self._spans.append(
                {
                    "name": f"code_exec:{language}",
                    "kind": "tool",
                    "status": "error" if error else "ok",
                    "duration_ms": duration_ms,
                    "position": step_pos,
                    "start_offset_ms": self._elapsed_ms(),
                    "parent_position": self._current_step_position,
                    "attributes": {
                        "tool_type": "code_execution",
                        "language": language,
                        "code_length": len(code),
                    },
                    "input_data": {
                        "language": language,
                        "code": code[:2000],
                        "packages": packages or [],
                        "paths": paths or [],
                    },
                    "output_data": {
                        "output": output[:2000] if output else None,
                        "error": error[:500] if error else None,
                        "execution_time": execution_time,
                        "output_size_kb": output_size_kb,
                    }
                    if (output or error)
                    else None,
                }
            )

        # Emit OTel span (dual data path) — outside lock
        if not _skip_otel:
            try:
                span = start_tool_span(
                    tool_name=f"code_exec:{language}",
                    tool_type="code_execution",
                )
                span.set_attribute("waxell.code.language", language)
                span.set_attribute("waxell.code.length", len(code))
                span.set_attribute("waxell.code.preview", code[:500])
                if output:
                    span.set_attribute("waxell.code.output_preview", output[:500])
                if error:
                    span.set_attribute("waxell.code.error", error[:500])
                span.end()
            except Exception:
                pass

        logger.info(
            "Code execution: %s (%d bytes)%s",
            language,
            len(code),
            f" | {error[:100]}" if error else "",
        )

        # Mid-execution governance: flush and check policy
        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_communication(
        self,
        *,
        channel: str,
        recipient: str = "",
        body: str = "",
        subject: str = "",
        metadata: dict | None = None,
        _skip_otel: bool = False,
    ) -> None:
        """Record an outbound communication for governance evaluation.

        Each call buffers the communication for policy checks (allowed/blocked
        channels, message limits, disclaimer requirements).

        Args:
            channel: Communication channel (e.g. "slack", "email", "sms").
            recipient: Target of the communication (e.g. "#general", "user@acme.com").
            body: Message body text.
            subject: Optional subject line (email, etc.).
            metadata: Optional extra metadata.
            _skip_otel: If True, skip OTel span emission (used by instrumentors).
        """
        comm: dict = {
            "channel": channel,
            "recipient": recipient,
            "body": body,
            "subject": subject,
        }
        if metadata:
            comm["metadata"] = metadata

        with self._lock:
            self._communications.append(comm)
            self._step_counter += 1
            step_pos = self._step_counter

            self._steps.append(
                {
                    "step_name": f"comm:{channel}",
                    "output": {
                        "_kind": "communication",
                        "channel": channel,
                        "recipient": recipient,
                        "preview": body[:500],
                    },
                    "position": step_pos,
                }
            )

            self._spans.append(
                {
                    "name": f"comm:{channel}",
                    "kind": "tool",
                    "status": "ok",
                    "duration_ms": 0,
                    "position": step_pos,
                    "start_offset_ms": self._elapsed_ms(),
                    "parent_position": self._current_step_position,
                    "attributes": {
                        "io.direction": "outbound",
                        "io.channel": channel,
                    },
                    "input_data": {
                        "channel": channel,
                        "recipient": recipient,
                        "subject": subject,
                        "body": body[:2000],
                    },
                    "output_data": None,
                }
            )

        # OTel trace span
        if not _skip_otel:
            try:
                span = start_tool_span(
                    tool_name=f"comm:{channel}",
                    tool_type="communication",
                )
                span.set_attribute("waxell.comm.channel", channel)
                if recipient:
                    span.set_attribute("waxell.comm.recipient", recipient)
                if body:
                    span.set_attribute("waxell.comm.body_preview", body[:500])
                if subject:
                    span.set_attribute("waxell.comm.subject", subject)
                span.end()
            except Exception:
                pass

        # Log (picked up by OTel LoggingHandler → Loki)
        logger.info(
            "Communication: %s → %s (%s)",
            channel,
            recipient or "broadcast",
            body[:100] if body else "empty",
        )

        # Mid-execution governance: flush and check policy
        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    # -----------------------------------------------------------------
    # Category B governance record methods
    # -----------------------------------------------------------------

    def record_data_access(
        self,
        *,
        source: str,
        operation: str = "read",
        records: int = 0,
    ) -> None:
        """Record a data access event for data-access governance.

        Args:
            source: Data source name (e.g. "postgres", "s3", "redis").
            operation: Access type — "read" or "write".
            records: Number of records accessed.
        """
        with self._lock:
            self._data_accesses.append({
                "source": source,
                "operation": operation,
                "records": records,
            })

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_network_request(self, *, url: str) -> None:
        """Record an outbound network request for network governance.

        Args:
            url: The URL or domain accessed.
        """
        with self._lock:
            self._network_requests.append(url)

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_scope_impact(
        self,
        *,
        records_modified: int = 0,
        records_deleted: int = 0,
        files_changed: int = 0,
        transaction_total: float = 0.0,
        api_writes: int = 0,
    ) -> None:
        """Record scope/blast-radius impact for scope governance.

        Values are additive — each call increments the running totals.

        Args:
            records_modified: Number of records modified in this operation.
            records_deleted: Number of records deleted.
            files_changed: Number of files changed.
            transaction_total: Dollar amount of transactions.
            api_writes: Number of external API write operations.
        """
        with self._lock:
            self._scope_impacts["records_modified"] += records_modified
            self._scope_impacts["records_deleted"] += records_deleted
            self._scope_impacts["files_changed"] += files_changed
            self._scope_impacts["transaction_total"] += transaction_total
            self._scope_impacts["api_writes"] += api_writes

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_grounding(
        self,
        *,
        grounding_scores: list[float] | None = None,
        citations: list[str] | None = None,
        unsupported_claims: list[str] | None = None,
        output_confidence: float | None = None,
    ) -> None:
        """Record grounding/citation data for grounding governance.

        Each call appends a new entry to the grounding data list. For
        multi-step agents, call once per retrieval+synthesis step so
        mid_execution governance can evaluate each step independently.

        Args:
            grounding_scores: Per-claim grounding scores (0.0-1.0).
            citations: List of source citations.
            unsupported_claims: Claims without source support.
            output_confidence: Overall output confidence (0.0-1.0).
        """
        entry: dict = {}
        if grounding_scores is not None:
            entry["grounding_scores"] = grounding_scores
        if citations is not None:
            entry["citations"] = citations
        if unsupported_claims is not None:
            entry["unsupported_claims"] = unsupported_claims
        if output_confidence is not None:
            entry["output_confidence"] = output_confidence

        with self._lock:
            self._grounding_data.append(entry)

            # Buffer a step so mid_execution governance has something to flush.
            # Without this, record_grounding() updates conversation_state but
            # there may be no pending LLM calls or steps to trigger a flush.
            self._step_counter += 1
            self._steps.append({
                "step_name": "grounding_check",
                "output": {
                    "_kind": "grounding_data",
                    "grounding_scores": grounding_scores or [],
                    "citation_count": len(citations) if citations else 0,
                    "output_confidence": output_confidence,
                },
                "position": self._step_counter,
            })

        # Auto-surface as scores (latest entry)
        if grounding_scores:
            avg = sum(grounding_scores) / len(grounding_scores)
            self.record_score("grounding_score", round(avg, 4), comment=f"Avg of {len(grounding_scores)} claims")
        if output_confidence is not None:
            self.record_score("output_confidence", round(output_confidence, 4))
        if citations is not None:
            self.record_score("citation_count", float(len(citations)))
        if unsupported_claims is not None and len(unsupported_claims) > 0:
            self.record_score("unsupported_claims", float(len(unsupported_claims)))

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_retrieval_result(
        self,
        *,
        relevance_score: float = 0.0,
        source: str = "",
        collection: str = "",
        age_days: int = 0,
    ) -> None:
        """Record a retrieval result for retrieval governance.

        Call once per retrieved document to build the retrieval_results
        buffer that the retrieval handler evaluates.

        Args:
            relevance_score: Relevance score (0.0-1.0).
            source: Source identifier (e.g. document name, URL).
            collection: Collection/index name.
            age_days: Age of the source in days.
        """
        with self._lock:
            self._retrieval_results.append({
                "relevance_score": relevance_score,
                "source": source,
                "collection": collection,
                "age_days": age_days,
            })
            n = len(self._retrieval_results)

        # Auto-surface as scores — running average across all recorded results
        if relevance_score > 0:
            all_scores = [r["relevance_score"] for r in self._retrieval_results if r["relevance_score"] > 0]
            avg = sum(all_scores) / len(all_scores)
            self.record_score("retrieval_relevance", round(avg, 4), comment=f"Avg across {n} documents")

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_bias_flag(self, *, flag: str) -> None:
        """Record a bias flag for reasoning governance.

        Args:
            flag: Bias type detected (e.g. "gender_bias", "age_bias").
        """
        with self._lock:
            self._bias_flags.append(flag)

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_delegation(
        self,
        *,
        delegate: str,
        depth: int = 1,
        approved: bool = True,
        policies_inherited: bool = True,
    ) -> None:
        """Record an agent delegation for delegation governance.

        Args:
            delegate: Name of the delegate agent.
            depth: Delegation depth (nesting level).
            approved: Whether delegation was pre-approved.
            policies_inherited: Whether parent policies are inherited.
        """
        with self._lock:
            self._delegations.append({
                "delegate": delegate,
                "depth": depth,
                "approved": approved,
                "policies_inherited": policies_inherited,
            })
            self._delegation_depth = max(self._delegation_depth, depth)
            self._concurrent_delegates = len(self._delegations)

            # Buffer a step so mid-execution governance flush has data to send.
            # Without this, _flush_and_check_governance() short-circuits because
            # there are no pending _steps or _llm_calls to transmit.
            self._step_counter += 1
            self._steps.append({
                "step_name": f"delegate:{delegate}",
                "output": {
                    "_kind": "delegation",
                    "delegate": delegate,
                    "depth": depth,
                },
                "position": self._step_counter,
            })

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def set_privacy_context(
        self,
        *,
        consent_token: str = "",
        execution_region: str = "",
        data_purpose: str = "",
    ) -> None:
        """Set privacy context for privacy governance.

        Triggers a mid-execution governance flush so the privacy handler
        can check consent, region, and purpose immediately — before any
        LLM calls happen.

        Args:
            consent_token: User consent token or identifier.
            execution_region: Data processing region (e.g. "eu-west-1").
            data_purpose: Purpose of data processing (e.g. "analytics").
        """
        with self._lock:
            if consent_token:
                self._privacy_context["consent_token"] = consent_token
            if execution_region:
                self._privacy_context["execution_region"] = execution_region
            if data_purpose:
                self._privacy_context["data_purpose"] = data_purpose
        if self._mid_execution_governance:
            self._flush_and_check_governance()

    def record_intermediate_output(self, *, output: str) -> None:
        """Record an intermediate output for identity governance.

        Triggers a mid-execution governance flush so the identity handler
        can check intermediate outputs for impersonation patterns.

        Args:
            output: Intermediate text output from the agent.
        """
        with self._lock:
            self._intermediate_outputs.append(output)
        if self._mid_execution_governance:
            self._flush_and_check_governance()

    def set_output_text(self, *, text: str) -> None:
        """Set the final output text for identity governance.

        Triggers a mid-execution governance flush so the identity handler
        can check the output for impersonation patterns before the agent
        returns the response.

        Args:
            text: The final output text to check for AI disclosure.
        """
        with self._lock:
            self._output_text = text
        if self._mid_execution_governance:
            self._flush_and_check_governance()

    async def check_governance(self) -> None:
        """Async mid-execution governance check.

        Sends current conversation state to the server for policy evaluation.
        Raises PolicyViolationError if any policy returns BLOCK.

        Use this after :meth:`record_intermediate_output` or
        :meth:`set_output_text` to enforce governance before the agent
        returns a response.  Unlike the sync flush path, this works
        correctly inside ``async def`` agent functions.
        """
        if self._governance_blocked:
            raise PolicyViolationError(self._governance_reason)
        if not self._run_info or not self.enforce_policy:
            return

        conv_state = self._build_conversation_state()
        if not conv_state:
            return

        try:
            resp = await self.client.record_steps(
                run_id=self._run_info.run_id,
                steps=[{
                    "step_name": "__governance_check",
                    "output": {},
                    "position": self._step_counter,
                }],
                conversation_state=conv_state,
            )
            gov = resp.get("governance", {}) if resp else {}

            # Record evaluations as governance spans
            for ev in gov.get("evaluations", []):
                try:
                    self.record_policy_check(
                        policy_name=ev.get("policy_name", "unknown"),
                        action=ev.get("action", "allow"),
                        category=ev.get("category", ""),
                        reason=ev.get("reason", ""),
                        duration_ms=ev.get("duration_ms", 0),
                        phase="mid_execution",
                    )
                except Exception:
                    pass

            if gov.get("action") == "block":
                self._governance_blocked = True
                self._governance_reason = gov.get("reason", "Policy violation")
                raise PolicyViolationError(self._governance_reason)
        except PolicyViolationError:
            raise
        except Exception as e:
            logger.warning(f"Async governance check failed: {e}")

    def set_memory_state(
        self,
        *,
        memory_items: list[dict] | None = None,
        cross_session_loaded: bool = False,
        memory_item_count: int = 0,
    ) -> None:
        """Set memory state for memory governance.

        Args:
            memory_items: List of memory items loaded into context.
            cross_session_loaded: Whether cross-session memory was loaded.
            memory_item_count: Total number of memory items.
        """
        with self._lock:
            if memory_items is not None:
                self._memory_state["memory_items"] = memory_items
            self._memory_state["cross_session_loaded"] = cross_session_loaded
            self._memory_state["memory_item_count"] = memory_item_count

    def record_memory_write(
        self,
        *,
        memory_type: str,
        content: str = "",
    ) -> None:
        """Record a memory write operation for memory governance.

        Args:
            memory_type: Type of memory being written (e.g. "fact", "preference").
            content: Content being written to memory.
        """
        with self._lock:
            self._memory_writes.append({
                "memory_type": memory_type,
                "content": content,
            })

        if self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_retrieval(
        self,
        *,
        query: str,
        documents: list[dict],
        source: str = "",
        duration_ms: int | None = None,
        top_k: int | None = None,
        scores: list[float] | None = None,
    ) -> None:
        """Buffer a retrieval operation (RAG document fetch).

        Args:
            query: The retrieval query string.
            documents: List of retrieved docs [{id, title, score, snippet}].
            source: Data source name (e.g. "pinecone", "elasticsearch").
            duration_ms: Retrieval time in milliseconds.
            top_k: Number of documents requested.
            scores: Relevance scores for each retrieved document.
        """
        self._step_counter += 1
        self._steps.append(
            {
                "step_name": f"retrieval:{source or 'search'}",
                "output": {
                    "_kind": "retrieval",
                    "query": query,
                    "doc_count": len(documents),
                },
                "position": self._step_counter,
            }
        )
        attrs: dict[str, Any] = {"source": source}
        if source:
            attrs["waxell.retrieval.source"] = source
        if top_k is not None:
            attrs["top_k"] = top_k
        attrs["doc_count"] = len(documents)
        attrs["waxell.retrieval.results_count"] = len(documents)
        if scores:
            attrs["top_score"] = max(scores)
            attrs["avg_score"] = sum(scores) / len(scores)
        output_data: dict[str, Any] = {"documents": documents}
        if scores:
            output_data["scores"] = scores
        self._spans.append(
            {
                "name": f"retrieve:{source or 'search'}",
                "kind": "retriever",
                "status": "ok",
                "duration_ms": duration_ms,
                "position": self._step_counter,
                "start_offset_ms": self._elapsed_ms(),
                "parent_position": self._current_step_position,
                "attributes": attrs,
                "input_data": {"query": query, "top_k": top_k},
                "output_data": output_data,
            }
        )

        try:
            span = start_retrieval_span(query=query, source=source)
            span.end()
        except Exception:
            pass

        if self._auto_grounding and scores:
            # Auto-bridge: retrieval scores → grounding governance.
            # record_grounding() handles its own mid_execution flush.
            # If governance returns BLOCK (e.g. score_relevance_floor filters
            # out all results, or scores below min_grounding_score),
            # PolicyViolationError is raised HERE — before the agent
            # reaches the synthesis step.
            self.record_grounding(grounding_scores=scores)
        elif self._mid_execution_governance and self._run_info:
            self._flush_and_check_governance()

    def record_decision(
        self,
        *,
        name: str,
        options: list[str],
        chosen: str,
        reasoning: str = "",
        confidence: float | None = None,
        metadata: Optional[dict] = None,
        instrumentation_type: str = "manual",
    ) -> None:
        """Buffer a decision point (branching logic, routing).

        Args:
            name: Decision name (e.g. "route_to_agent", "select_model").
            options: Available choices.
            chosen: The selected option.
            reasoning: Why this option was chosen.
            confidence: Confidence score (0.0-1.0) if applicable.
            metadata: Additional context for the decision.
            instrumentation_type: How this decision was captured —
                ``"manual"`` (record_decision/decide), ``"decorator"``
                (@decision), or ``"auto"`` (from LLM tool_calls).
        """
        self._step_counter += 1
        self._steps.append(
            {
                "step_name": f"decision:{name}",
                "output": {
                    "_kind": "decision",
                    "name": name,
                    "chosen": chosen,
                    "confidence": confidence,
                },
                "position": self._step_counter,
            }
        )
        attrs: dict[str, Any] = {
            "instrumentation_source": instrumentation_type,
        }
        if confidence is not None:
            attrs["confidence"] = confidence
        if metadata:
            attrs.update(metadata)
        self._spans.append(
            {
                "name": name,
                "kind": "decision",
                "status": "ok",
                "duration_ms": None,
                "position": self._step_counter,
                "start_offset_ms": self._elapsed_ms(),
                "parent_position": self._current_step_position,
                "attributes": attrs,
                "input_data": {"options": options, "reasoning": reasoning},
                "output_data": {"chosen": chosen, "confidence": confidence},
            }
        )

        try:
            span = start_decision_span(
                decision_name=name, options=options, chosen=chosen
            )
            span.end()
        except Exception:
            pass

        # Populate reasoning governance buffer
        with self._lock:
            self._decisions_buffer.append({
                "decision": name,
                "explanation": reasoning,
                "alternatives": options,
                "confidence": confidence,
            })

        # Auto-surface decision confidence as a score
        if confidence is not None:
            self.record_score(
                f"decision_confidence:{name}", round(confidence, 4),
                comment=f"Chose '{chosen}' from {len(options)} options",
            )

    def record_reasoning(
        self,
        *,
        step: str,
        thought: str,
        evidence: list[str] | None = None,
        conclusion: str = "",
    ) -> None:
        """Buffer a reasoning step (chain-of-thought, reflection).

        Args:
            step: Reasoning step name (e.g. "evaluate_sources", "check_consistency").
            thought: The reasoning text/thought process.
            evidence: Supporting evidence or references.
            conclusion: Conclusion reached at this step.
        """
        self._step_counter += 1
        self._steps.append(
            {
                "step_name": f"reasoning:{step}",
                "output": {
                    "_kind": "reasoning",
                    "thought": thought[:200],
                    "conclusion": conclusion,
                },
                "position": self._step_counter,
            }
        )
        self._spans.append(
            {
                "name": step,
                "kind": "reasoning",
                "status": "ok",
                "duration_ms": None,
                "position": self._step_counter,
                "start_offset_ms": self._elapsed_ms(),
                "parent_position": self._current_step_position,
                "attributes": {},
                "input_data": {"thought": thought, "evidence": evidence or []},
                "output_data": {"conclusion": conclusion} if conclusion else None,
            }
        )

        try:
            span = start_reasoning_span(step_name=step)
            span.end()
        except Exception:
            pass

        # Increment reasoning governance depth
        with self._lock:
            self._reasoning_depth += 1

    def record_retry(
        self,
        *,
        attempt: int,
        reason: str,
        strategy: str = "retry",
        original_error: str = "",
        fallback_to: str = "",
        max_attempts: int | None = None,
    ) -> None:
        """Buffer a retry or fallback event.

        Args:
            attempt: Current attempt number (1-based).
            reason: Why a retry/fallback occurred.
            strategy: "retry", "fallback", or "circuit_break".
            original_error: The error that triggered the retry.
            fallback_to: Name of fallback target (model, agent, tool).
            max_attempts: Maximum attempts configured.
        """
        self._step_counter += 1
        self._steps.append(
            {
                "step_name": f"retry:{strategy}",
                "output": {
                    "_kind": "retry",
                    "attempt": attempt,
                    "reason": reason,
                    "strategy": strategy,
                    "fallback_to": fallback_to,
                },
                "position": self._step_counter,
            }
        )
        attrs: dict[str, Any] = {
            "attempt": attempt,
            "strategy": strategy,
        }
        if max_attempts is not None:
            attrs["max_attempts"] = max_attempts
        if fallback_to:
            attrs["fallback_to"] = fallback_to
        self._spans.append(
            {
                "name": f"{strategy}:{attempt}",
                "kind": "retry",
                "status": "error" if original_error else "ok",
                "duration_ms": None,
                "position": self._step_counter,
                "start_offset_ms": self._elapsed_ms(),
                "parent_position": self._current_step_position,
                "attributes": attrs,
                "input_data": {"reason": reason, "original_error": original_error},
                "output_data": {"fallback_to": fallback_to} if fallback_to else None,
            }
        )

        try:
            span = start_retry_span(attempt=attempt, strategy=strategy)
            if original_error:
                span.set_attribute("error.message", original_error)
            span.end()
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Conversation IO recording
    # -----------------------------------------------------------------

    def record_user_message(
        self,
        content: str,
        *,
        metadata: dict | None = None,
    ) -> None:
        """Record an inbound user message in the conversation trace.

        Use this in interactive agents (chat, REPL) to make user inputs
        visible in the trace UI alongside LLM calls and tool invocations.

        The user message always gets ``position=0`` so it appears first in the
        trace, regardless of when the auto-conversation instrumentor fires
        (which is typically after the first LLM call completes).

        Args:
            content: The user's message text.
            metadata: Optional extra context (e.g. channel, user_id).
        """
        with self._lock:
            content = self._redact_text(content)
            preview = content[:500] if content else ""
            self._steps.append(
                {
                    "step_name": "io:user_message",
                    "output": {
                        "_kind": "user_message",
                        "preview": preview,
                    },
                    "position": 0,
                }
            )
            attrs: dict[str, Any] = {"io.direction": "inbound"}
            if metadata:
                attrs.update(metadata)
            self._spans.append(
                {
                    "name": "user_message",
                    "kind": "io",
                    "status": "ok",
                    "duration_ms": None,
                    "position": 0,
                    "start_offset_ms": 0,
                    "parent_position": self._current_step_position,
                    "attributes": attrs,
                    "input_data": {"content": content},
                    "output_data": None,
                }
            )

    def record_agent_response(
        self,
        content: str,
        *,
        metadata: dict | None = None,
    ) -> None:
        """Record an outbound agent response in the conversation trace.

        Use this in interactive agents to trace what the agent communicated
        back to the user — distinct from the raw LLM API response.

        Args:
            content: The agent's response text shown to the user.
            metadata: Optional extra context (e.g. citations, confidence).
        """
        with self._lock:
            self._step_counter += 1
            preview = content[:500] if content else ""
            self._steps.append(
                {
                    "step_name": "io:agent_response",
                    "output": {
                        "_kind": "agent_response",
                        "preview": preview,
                    },
                    "position": self._step_counter,
                }
            )
            attrs: dict[str, Any] = {"io.direction": "outbound"}
            if metadata:
                attrs.update(metadata)
            self._spans.append(
                {
                    "name": "agent_response",
                    "kind": "io",
                    "status": "ok",
                    "duration_ms": None,
                    "position": self._step_counter,
                    "start_offset_ms": self._elapsed_ms(),
                    "parent_position": self._current_step_position,
                    "attributes": attrs,
                    "input_data": None,
                    "output_data": {"content": content},
                }
            )

    # -----------------------------------------------------------------
    # Human-in-the-loop recording
    # -----------------------------------------------------------------

    @staticmethod
    def _strip_ansi(text: str) -> str:
        """Remove ANSI escape sequences from text for clean storage."""
        import re

        return re.sub(r"\x1b\[[0-9;]*m", "", text)

    def input(self, prompt: str = "", *, action: str = "input") -> str:
        """Drop-in replacement for ``input()`` that auto-records a human_turn span.

        Usage::

            answer = ctx.input("Approve? (y/n): ")

        Same signature as the built-in ``input()`` — swap ``input`` for
        ``ctx.input`` (or ``waxell.input``) and the prompt, response, and
        wait time are captured automatically.  ANSI escape codes in the
        prompt are stripped before recording.
        """
        start = time.monotonic()
        response = input(prompt)
        elapsed_ms = round((time.monotonic() - start) * 1000)
        self.record_human_interaction(
            prompt=self._strip_ansi(prompt).strip(),
            response=response,
            channel="terminal",
            action=action,
            elapsed_ms=elapsed_ms,
        )
        return response

    def human_turn(
        self,
        prompt: str = "",
        channel: str = "terminal",
        action: str = "",
        metadata: dict | None = None,
    ) -> "HumanTurn":
        """Return a context manager that captures a human interaction as a timed IO span.

        Use for non-terminal channels (Slack, webhooks, UI) where the
        interaction pattern varies. For terminal ``input()``, prefer
        :meth:`input` instead.

        Usage::

            with ctx.human_turn(prompt="Review PR", channel="github") as turn:
                result = await wait_for_webhook()
                turn.set_response(result)
        """
        return HumanTurn(
            self, prompt=prompt, channel=channel, action=action, metadata=metadata
        )

    def record_human_interaction(
        self,
        prompt: str = "",
        response: str = "",
        channel: str = "terminal",
        action: str = "",
        elapsed_ms: float | int | None = None,
        metadata: dict | None = None,
    ) -> None:
        """Record a human-in-the-loop interaction as an IO span.

        Use this for any interactive pattern — terminal prompts, Slack messages,
        UI dialogs, webhook callbacks, coding agent confirmations, etc.

        Args:
            prompt: What was shown to the human.
            response: What the human replied.
            channel: Where the interaction happened (terminal, slack, ui, etc.).
            action: What kind of interaction (confirmation, input, approval, etc.).
            elapsed_ms: How long the human took to respond.
            metadata: Arbitrary extra context.
        """
        if elapsed_ms is not None:
            elapsed_ms = round(elapsed_ms)
        with self._lock:
            self._step_counter += 1
            name = f"human_turn:{action}" if action else "human_turn"
            preview = response[:500] if response else prompt[:500]
            self._steps.append(
                {
                    "step_name": f"io:{name}",
                    "output": {
                        "_kind": "human_interaction",
                        "preview": preview,
                    },
                    "position": self._step_counter,
                }
            )
            attrs: dict[str, Any] = {
                "io.direction": "interactive",
                "io.channel": channel,
            }
            if action:
                attrs["io.action"] = action
            if metadata:
                attrs.update(metadata)
            self._spans.append(
                {
                    "name": name,
                    "kind": "io",
                    "status": "ok",
                    "duration_ms": elapsed_ms,
                    "position": self._step_counter,
                    "start_offset_ms": self._elapsed_ms(),
                    "parent_position": self._current_step_position,
                    "attributes": attrs,
                    "input_data": {"prompt": prompt} if prompt else None,
                    "output_data": {"response": response} if response else None,
                }
            )

    # -----------------------------------------------------------------
    # Governance recording
    # -----------------------------------------------------------------

    def record_policy_check(
        self,
        *,
        policy_name: str,
        action: str,
        category: str = "",
        reason: str = "",
        duration_ms: float = 0,
        phase: str = "pre_execution",
        priority: int = 100,
    ) -> None:
        """Buffer a policy evaluation result as a governance span.

        Args:
            policy_name: Name of the policy evaluated.
            action: Evaluation result ("allow", "warn", "block", etc.).
            category: Policy category (e.g. "budget", "rate-limit").
            reason: Reason for the action (empty for allow).
            duration_ms: Evaluation time in milliseconds.
            phase: "pre_execution", "mid_execution", or "post_execution".
            priority: Policy priority (lower = first).
        """
        # Governance data is NOT appended to _steps or _spans.
        # Server-side observe_views creates governance events + spans during
        # policy evaluation. Putting them in _steps triggers duplicate mid-exec
        # checks, and _spans serializer rejects kind="governance" which would
        # fail the entire behavior span batch. Buffer in _governance_spans for
        # OTel emission only.
        self._governance_spans.append(
            {
                "name": f"policy:{policy_name}",
                "kind": "governance",
                "status": "ok" if action == "allow" else action,
                "duration_ms": duration_ms or None,
                "position": self._step_counter,
                "attributes": {
                    "policy_name": policy_name,
                    "category": category,
                    "action": action,
                    "priority": priority,
                    "phase": phase,
                },
                "input_data": {"phase": phase},
                "output_data": {"action": action, "reason": reason}
                if reason
                else {"action": action},
            }
        )

        # Only emit OTel spans for non-allow results (block/warn/redact).
        # Allow results are the common path and create excessive noise in
        # the console exporter and Tempo. The data is already buffered in
        # _governance_spans for the HTTP path.
        if action != "allow":
            try:
                span = start_governance_span(
                    policy_name=policy_name, action=action, category=category
                )
                if reason:
                    span.set_attribute("waxell.policy.reason", reason)
                span.end()
            except Exception:
                pass

    # -----------------------------------------------------------------
    # Approval lifecycle recording
    # -----------------------------------------------------------------

    def record_approval_request(
        self,
        *,
        action_type: str,
        approvers: list | None = None,
        timeout_minutes: float | None = None,
        reason: str = "",
        metadata: dict | None = None,
    ) -> None:
        """Record that an approval request was initiated after a policy block.

        Call after catching :class:`PolicyViolationError` when the policy
        metadata indicates approval is required.  The event appears in the
        governance timeline alongside the original policy block.

        Args:
            action_type: The action requiring approval (e.g. ``"delete"``).
            approvers: Who should approve (emails, group names).
            timeout_minutes: How long the approval window stays open.
            reason: Why approval is needed.
            metadata: Additional context for the approval request.
        """
        event_metadata: dict = {
            "action_type": action_type,
            "approvers": approvers or [],
            **(
                {"timeout_minutes": timeout_minutes}
                if timeout_minutes is not None
                else {}
            ),
            **(metadata or {}),
        }

        self._governance_spans.append(
            {
                "name": f"approval:request:{action_type}",
                "kind": "governance",
                "status": "pending",
                "duration_ms": None,
                "position": self._step_counter,
                "attributes": {
                    "approval.action_type": action_type,
                    "approval.phase": "request",
                },
                "input_data": {
                    "action_type": action_type,
                    "approvers": approvers or [],
                },
                "output_data": {"event": "approval_requested", "reason": reason}
                if reason
                else {"event": "approval_requested"},
            }
        )

        try:
            span = start_governance_span(
                policy_name=f"approval:{action_type}",
                action="approval_requested",
                category="approval",
            )
            if reason:
                span.set_attribute("waxell.approval.reason", reason)
            span.set_attribute("waxell.approval.action_type", action_type)
            span.end()
        except Exception:
            pass

        if self._run_info and self.client:
            try:
                self.client.record_events_sync(
                    events=[
                        {
                            "workflow_id": self._run_info.workflow_id,
                            "agent_name": self.agent_name,
                            "workflow_name": self.workflow_name,
                            "event": "approval_requested",
                            "metadata": event_metadata,
                        }
                    ]
                )
            except Exception:
                pass

    def record_approval_response(
        self,
        *,
        action_type: str,
        decision: str,
        approver: str = "",
        elapsed_seconds: float | None = None,
        metadata: dict | None = None,
    ) -> None:
        """Record the outcome of an approval request.

        Call after the human-in-the-loop decides or the timeout expires.

        Args:
            action_type: The action that was awaiting approval.
            decision: ``"approved"``, ``"denied"``, or ``"timeout"``.
            approver: Who approved/denied (email, username).
            elapsed_seconds: Time from block to decision.
            metadata: Additional context.
        """
        event_name = {
            "approved": "approval_granted",
            "denied": "approval_denied",
            "timeout": "approval_timeout",
        }.get(decision, f"approval_{decision}")

        event_metadata: dict = {
            "action_type": action_type,
            "decision": decision,
            **({"approver": approver} if approver else {}),
            **(
                {"elapsed_seconds": elapsed_seconds}
                if elapsed_seconds is not None
                else {}
            ),
            **(metadata or {}),
        }

        self._governance_spans.append(
            {
                "name": f"approval:{decision}:{action_type}",
                "kind": "governance",
                "status": "ok" if decision == "approved" else decision,
                "duration_ms": (elapsed_seconds * 1000) if elapsed_seconds else None,
                "position": self._step_counter,
                "attributes": {
                    "approval.action_type": action_type,
                    "approval.phase": decision,
                },
                "input_data": {"action_type": action_type},
                "output_data": event_metadata,
            }
        )

        try:
            span = start_governance_span(
                policy_name=f"approval:{action_type}",
                action=event_name,
                category="approval",
            )
            span.set_attribute("waxell.approval.action_type", action_type)
            span.set_attribute("waxell.approval.phase", decision)
            if approver:
                span.set_attribute("waxell.approval.approver", approver)
            if elapsed_seconds is not None:
                span.set_attribute("waxell.approval.elapsed_seconds", elapsed_seconds)
            span.end()
        except Exception:
            pass

        if self._run_info and self.client:
            try:
                self.client.record_events_sync(
                    events=[
                        {
                            "workflow_id": self._run_info.workflow_id,
                            "agent_name": self.agent_name,
                            "workflow_name": self.workflow_name,
                            "event": event_name,
                            "metadata": event_metadata,
                        }
                    ]
                )
            except Exception:
                pass

    # -----------------------------------------------------------------
    # Incremental flush
    # -----------------------------------------------------------------

    async def flush(self) -> None:
        """Send buffered spans, LLM calls, steps, and scores to the controlplane.

        Use this in long-running contexts (REPLs, chat sessions) to make
        child run summaries visible in the UI before the parent context exits.

        Safe to call multiple times — each call sends only data buffered
        since the last flush (or since context entry).
        """
        if not self._run_info or not self._run_info.run_id:
            return

        with self._lock:
            self._merge_otel_spans()
            self._deduplicate_retrieval_spans()
            llm_calls = list(self._llm_calls)
            self._llm_calls.clear()
            steps = list(self._steps)
            self._steps.clear()
            scores = list(self._scores)
            self._scores.clear()
            spans = list(self._spans)
            self._spans.clear()
            otel_spans = list(self._otel_spans)
            self._otel_spans.clear()

        # Build conversation state so the controlplane can evaluate
        # context-management policies (max turns, utilization, etc.)
        conv_state = self._build_conversation_state()

        try:
            # Send spans and scores first — they don't trigger governance
            # and must be recorded even if governance blocks below.
            if scores:
                await self.client.record_scores(
                    run_id=self._run_info.run_id, scores=scores
                )
            if spans:
                await self.client.record_spans(
                    run_id=self._run_info.run_id, spans=spans
                )
            # Governance-checked sends: may raise PolicyViolationError
            if llm_calls:
                resp = await self.client.record_llm_calls(
                    run_id=self._run_info.run_id,
                    calls=llm_calls,
                    conversation_state=conv_state,
                )
                self._check_governance_response(resp)
            if steps:
                resp = await self.client.record_steps(
                    run_id=self._run_info.run_id,
                    steps=steps,
                    conversation_state=conv_state,
                )
                self._check_governance_response(resp)
        except PolicyViolationError:
            raise  # Enforce governance blocks
        except Exception as e:
            logger.warning(f"Incremental flush failed: {e}")

    def flush_sync(self) -> None:
        """Synchronous version of :meth:`flush`.

        Safe to call from sync contexts or outside an event loop.
        """
        if not self._run_info or not self._run_info.run_id:
            return

        with self._lock:
            self._merge_otel_spans()
            self._deduplicate_retrieval_spans()
            llm_calls = list(self._llm_calls)
            self._llm_calls.clear()
            steps = list(self._steps)
            self._steps.clear()
            scores = list(self._scores)
            self._scores.clear()
            spans = list(self._spans)
            self._spans.clear()
            otel_spans = list(self._otel_spans)
            self._otel_spans.clear()

        # Build conversation state so the controlplane can evaluate
        # context-management policies (max turns, utilization, etc.)
        conv_state = self._build_conversation_state()

        try:
            # Send spans and scores first — they don't trigger governance
            # and must be recorded even if governance blocks below.
            if scores:
                self.client.record_scores_sync(
                    run_id=self._run_info.run_id, scores=scores
                )
            if spans:
                self.client.record_spans_sync(run_id=self._run_info.run_id, spans=spans)
            # Governance-checked sends: may raise PolicyViolationError
            if llm_calls:
                resp = self.client.record_llm_calls_sync(
                    run_id=self._run_info.run_id,
                    calls=llm_calls,
                    conversation_state=conv_state,
                )
                self._check_governance_response(resp)
            if steps:
                resp = self.client.record_steps_sync(
                    run_id=self._run_info.run_id,
                    steps=steps,
                    conversation_state=conv_state,
                )
                self._check_governance_response(resp)
        except PolicyViolationError:
            raise  # Enforce governance blocks
        except Exception as e:
            logger.warning(f"Incremental flush failed: {e}")

    # -----------------------------------------------------------------
    # Tag and metadata methods
    # -----------------------------------------------------------------

    def set_tag(self, key: str, value: str) -> None:
        """Set a searchable tag on the current agent span.

        Tags become OTel span attributes prefixed with ``waxell.tag.``
        and are queryable in Grafana TraceQL:
        ``{ span.waxell.tag.user_id = "u_123" }``

        Args:
            key: Tag name (alphanumeric, underscores, hyphens).
            value: Tag value (string).
        """
        self._tags[key] = value
        if self._span and not isinstance(self._span, NoOpSpan):
            try:
                self._span.set_attribute(f"{WaxellAttributes.TAG_PREFIX}{key}", value)
            except Exception:
                pass

    def set_metadata(self, key: str, value: Any) -> None:
        """Set metadata on the current agent span.

        Complex values are JSON-serialized. Queryable in Grafana TraceQL:
        ``{ span.waxell.meta.request != nil }``

        Args:
            key: Metadata key.
            value: Any JSON-serializable value.
        """
        self._metadata_kv[key] = value
        if self._span and not isinstance(self._span, NoOpSpan):
            try:
                from .tracing._compat import _safe_attr

                self._span.set_attribute(
                    f"{WaxellAttributes.META_PREFIX}{key}", _safe_attr(value)
                )
            except Exception:
                pass

    def _merge_otel_spans(self) -> None:
        """Merge auto-instrumented OTel spans into _spans, deduplicating.

        The WaxellSpanProcessor captures OTel spans into _otel_spans.
        Many instrumentors (e.g. OpenAI) ALSO call record_llm_call() which
        adds to _spans. We detect duplicates by checking if an OTel LLM span
        overlaps with a manually-recorded LLM span for the same model.

        Non-LLM OTel spans (tool calls, HTTP, DB, etc.) are always added
        since they're not recorded manually.

        Parent-child relationships are preserved: if an OTel span's
        ``_otel_parent_id`` matches another OTel span's ``_otel_span_id``,
        the child gets the parent's position as ``parent_position``.
        This allows HTTP/DB auto-instrumented spans to nest under
        @waxell.tool decorator spans in the trace tree.
        """
        if not self._otel_spans:
            return

        # Snapshot lists under lock to prevent concurrent modification
        with self._lock:
            spans_snapshot = list(self._spans)
            otel_snapshot = list(self._otel_spans)

        # Build sets from existing manual spans for dedup
        existing_llm_models: set[str] = set()
        existing_retrieval_sources: set[str] = set()
        for s in spans_snapshot:
            if s.get("kind") == "llm":
                model = (s.get("attributes") or {}).get("model", "")
                if model:
                    existing_llm_models.add(model)
            elif s.get("kind") == "retriever":
                source = (s.get("attributes") or {}).get("retrieval.source", "")
                if source:
                    existing_retrieval_sources.add(source)

        # Use wall-clock ms for OTel offset calculation.  OTel spans use
        # epoch-based time.time_ns() while _context_start_ms uses monotonic
        # time — mixing them produces huge offsets (year 2082 bug).
        run_started_at_wall_ms = self._context_start_wall_ms

        # Two-pass merge to resolve OTel parent-child → position-based hierarchy.
        #
        # Pass 1: Assign positions to all OTel spans, build otel_id → position map.
        # Pass 2: Resolve parent_position using the otel_id → position map.

        otel_id_to_position: dict[str, int] = {}
        merged_entries: list[tuple[dict, dict]] = []  # (otel_span, merged_dict)

        for otel_span in otel_snapshot:
            kind = otel_span.get("kind", "chain")

            # Skip governance spans — server creates those
            if kind == "governance":
                continue

            # Skip agent-level spans — we insert our own root agent span
            if kind == "agent":
                continue

            # Deduplicate LLM spans: if we already have a manual span for
            # the same model, the OTel span is a duplicate from the instrumentor
            if kind == "llm":
                model = (otel_span.get("attributes") or {}).get("model", "")
                if model and model in existing_llm_models:
                    # This is a duplicate — but enrich the existing manual span
                    # with any extra attributes from the OTel span
                    self._enrich_manual_span(model, otel_span)
                    continue

            # Deduplicate retriever spans: auto-instrumentors (e.g. ES)
            # create retrieval spans with generic placeholder documents.
            # When the user has an explicit @waxell.retrieval with the same
            # source, drop the auto-instrumentor duplicates.
            if kind == "retriever" and existing_retrieval_sources:
                source = (otel_span.get("attributes") or {}).get("retrieval.source", "")
                if source and source in existing_retrieval_sources:
                    continue

            # Convert OTel absolute timestamps to offset from context start
            start_ns = otel_span.get("_otel_start_ns", 0)
            end_ns = otel_span.get("_otel_end_ns", 0)
            duration_ms = otel_span.get("duration_ms")

            if start_ns and run_started_at_wall_ms:
                start_ms = start_ns / 1_000_000
                offset_ms = int(start_ms - run_started_at_wall_ms)
                if offset_ms < 0:
                    offset_ms = 0
            else:
                offset_ms = self._elapsed_ms()

            self._step_counter += 1
            position = self._step_counter

            merged = {
                "name": otel_span.get("name", "otel-span"),
                "kind": kind,
                "status": otel_span.get("status", "ok"),
                "duration_ms": duration_ms,
                "position": position,
                "start_offset_ms": offset_ms,
                "parent_position": self._current_step_position,  # default
                "attributes": otel_span.get("attributes", {}),
                "input_data": otel_span.get("input_data"),
                "output_data": otel_span.get("output_data"),
            }

            # Track OTel span ID → position for parent resolution
            otel_span_id = otel_span.get("_otel_span_id", "")
            if otel_span_id:
                otel_id_to_position[otel_span_id] = position

            merged_entries.append((otel_span, merged))

        # Pass 2: Resolve parent_position from _otel_parent_id and
        # deduplicate stacked instrumentor spans (e.g. httpx + urllib3
        # both fire for the same HTTP request, producing a parent-child
        # pair with identical names like DELETE localhost → DELETE localhost).
        otel_id_to_name: dict[str, str] = {
            otel_span.get("_otel_span_id", ""): merged["name"]
            for otel_span, merged in merged_entries
            if otel_span.get("_otel_span_id")
        }

        for otel_span, merged in merged_entries:
            otel_parent_id = otel_span.get("_otel_parent_id", "")
            if otel_parent_id and otel_parent_id in otel_id_to_position:
                # Check for duplicate: parent is another OTel span with
                # the same display name → drop this child as redundant.
                parent_name = otel_id_to_name.get(otel_parent_id, "")
                if parent_name and parent_name == merged["name"]:
                    continue  # Skip duplicate

                merged["parent_position"] = otel_id_to_position[otel_parent_id]

            self._spans.append(merged)

    # Framework attribute prefixes used by auto-instrumentors.  When an OTel
    # LLM span is deduplicated against a manual span, attributes with these
    # prefixes are copied so framework detection works in the controlplane.
    _FRAMEWORK_ATTR_PREFIXES = (
        "waxell.langchain.",
        "waxell.crewai.",
        "waxell.autogen.",
        "waxell.agno.",
        "waxell.langroid.",
        "waxell.composio.",
        "waxell.camel.",
        "waxell.pydanticai.",
        "waxell.smolagents.",
        "waxell.letta.",
    )

    def _enrich_manual_span(self, model: str, otel_span: dict) -> None:
        """Enrich an existing manual LLM span with extra OTel attributes."""
        otel_attrs = otel_span.get("attributes", {})
        for s in self._spans:
            if s.get("kind") != "llm":
                continue
            s_attrs = s.get("attributes") or {}
            if s_attrs.get("model") != model:
                continue
            # Merge attributes we don't already have
            for key in ("finish_reasons", "response_model", "system"):
                if key in otel_attrs and key not in s_attrs:
                    s_attrs[key] = otel_attrs[key]
            # Copy framework-specific attributes so the controlplane can
            # detect which AI framework was used (LangChain, CrewAI, etc.)
            for key, val in otel_attrs.items():
                if key.startswith(self._FRAMEWORK_ATTR_PREFIXES) and key not in s_attrs:
                    s_attrs[key] = val
            # Update duration if the OTel span has one and manual doesn't
            if not s.get("duration_ms") and otel_span.get("duration_ms"):
                s["duration_ms"] = otel_span["duration_ms"]
            break  # Only enrich first match

    def _deduplicate_retrieval_spans(self) -> None:
        """Remove placeholder retrieval spans when real ones exist for the same source.

        Auto-instrumentors (e.g. Elasticsearch) call ctx.record_retrieval()
        with placeholder documents like [{"id": "hit_0"}, {"id": "hit_1"}].
        When the user has an explicit @waxell.retrieval decorator with real
        document data for the same source, the placeholder spans are redundant.

        This runs after _merge_otel_spans() so all spans are in _spans.
        """
        # Group retriever spans by source
        retriever_spans_by_source: dict[str, list[int]] = {}
        for i, span in enumerate(self._spans):
            if span.get("kind") != "retriever":
                continue
            attrs = span.get("attributes") or {}
            source = attrs.get("waxell.retrieval.source") or attrs.get("source", "")
            if source:
                retriever_spans_by_source.setdefault(source, []).append(i)

        # For each source with multiple retriever spans, identify placeholders
        indices_to_remove: set[int] = set()
        for source, indices in retriever_spans_by_source.items():
            if len(indices) < 2:
                continue

            # Separate real vs placeholder spans
            real_indices = []
            placeholder_indices = []
            for idx in indices:
                if self._is_placeholder_retrieval(self._spans[idx]):
                    placeholder_indices.append(idx)
                else:
                    real_indices.append(idx)

            # Only remove placeholders if at least one real span exists
            if real_indices and placeholder_indices:
                indices_to_remove.update(placeholder_indices)

        if indices_to_remove:
            self._spans = [
                s for i, s in enumerate(self._spans) if i not in indices_to_remove
            ]

    # Prefixes used by auto-instrumentors for placeholder document IDs.
    _PLACEHOLDER_ID_PREFIXES = ("hit_", "match_", "row_", "result_")

    @staticmethod
    def _is_placeholder_retrieval(span: dict) -> bool:
        """Check if a retrieval span has placeholder documents from auto-instrumentors.

        Auto-instrumentors create documents like [{"id": "hit_0"}],
        [{"id": "match_0"}], [{"id": "row_0"}], etc. which contain no real
        content — just a synthetic ID.
        """
        output_data = span.get("output_data") or {}
        documents = output_data.get("documents", [])
        if not documents:
            return True  # Empty documents = placeholder
        # Check if all documents are simple placeholder objects
        for doc in documents:
            if not isinstance(doc, dict):
                continue
            keys = set(doc.keys())
            if keys == {"id"} and isinstance(doc.get("id"), str):
                doc_id = doc["id"]
                if any(
                    doc_id.startswith(p) for p in WaxellContext._PLACEHOLDER_ID_PREFIXES
                ):
                    continue
            # Has real content beyond just a placeholder id
            return False
        return True

    def _flush_and_check_governance(self) -> None:
        """Flush buffered data and check governance response.

        Called from record_*() methods when mid_execution_governance=True.
        Raises PolicyViolationError if server returns block action.
        """
        if self._governance_blocked:
            raise PolicyViolationError(self._governance_reason)

        if not self._run_info:
            return

        try:
            conv_state = self._build_conversation_state()
            flushed = False

            # Flush LLM calls
            if self._llm_calls:
                resp = self.client.record_llm_calls_sync(
                    run_id=self._run_info.run_id,
                    calls=self._llm_calls,
                    conversation_state=conv_state,
                )
                self._llm_calls.clear()
                self._check_governance_response(resp)
                flushed = True

            # Flush steps
            if self._steps:
                resp = self.client.record_steps_sync(
                    run_id=self._run_info.run_id,
                    steps=self._steps,
                    conversation_state=conv_state,
                )
                self._steps.clear()
                self._check_governance_response(resp)
                flushed = True

            # If no LLM calls or steps were pending, send a lightweight
            # governance-only step so the server evaluates mid_execution
            # handlers against the current conversation state (e.g.,
            # intermediate_outputs for identity impersonation checks).
            if not flushed and conv_state:
                resp = self.client.record_steps_sync(
                    run_id=self._run_info.run_id,
                    steps=[{
                        "step_name": "__governance_check",
                        "output": {},
                        "position": self._step_counter,
                    }],
                    conversation_state=conv_state,
                )
                self._check_governance_response(resp)
        except PolicyViolationError:
            raise  # Re-raise policy violations
        except Exception as e:
            logger.warning(f"Mid-execution governance flush failed: {e}")

    def _check_governance_response(self, response: dict) -> None:
        """Check governance field in server response. Record evaluations. Raise if blocked."""
        gov = response.get("governance", {}) if response else {}

        # Record mid-execution evaluations as governance spans
        for ev in gov.get("evaluations", []):
            try:
                self.record_policy_check(
                    policy_name=ev.get("policy_name", "unknown"),
                    action=ev.get("action", "allow"),
                    category=ev.get("category", ""),
                    reason=ev.get("reason", ""),
                    duration_ms=ev.get("duration_ms", 0),
                    phase="mid_execution",
                )
            except Exception:
                pass

        if gov.get("action") == "block":
            self._governance_blocked = True
            self._governance_reason = gov.get("reason", "Policy violation")
            raise PolicyViolationError(self._governance_reason)

    async def check_policy(self) -> PolicyCheckResult:
        """Manually check policy (useful for mid-execution checks)."""
        return await self.client.check_policy(
            agent_name=self.agent_name,
            workflow_name=self.workflow_name,
        )

    def check_policy_sync(self) -> PolicyCheckResult:
        """Synchronous version of check_policy for mid-execution checks."""
        return self.client.check_policy_sync(
            agent_name=self.agent_name,
            workflow_name=self.workflow_name,
        )


class HumanTurn:
    """Captures a human-in-the-loop interaction as a timed IO span.

    Usage::

        with ctx.human_turn(prompt="Refactor?", channel="terminal") as turn:
            answer = input("Refactor? (y/n): ")
            turn.set_response(answer)

    Works for any interactive pattern — terminal input, Slack messages,
    UI dialogs, webhook callbacks, coding agent confirmations.
    """

    def __init__(
        self,
        ctx: "WaxellContext",
        prompt: str,
        channel: str,
        action: str,
        metadata: dict | None,
    ):
        self._ctx = ctx
        self._prompt = prompt
        self._channel = channel
        self._action = action
        self._metadata = metadata or {}
        self._response: str | None = None
        self._start: float = 0.0

    def set_response(self, response: str) -> None:
        """Record what the human replied."""
        self._response = response

    def __enter__(self):
        self._start = time.monotonic()
        return self

    def __exit__(self, *exc_info):
        elapsed_ms = round((time.monotonic() - self._start) * 1000)
        self._ctx.record_human_interaction(
            prompt=self._prompt,
            response=self._response or "",
            channel=self._channel,
            action=self._action,
            elapsed_ms=elapsed_ms,
            metadata=self._metadata,
        )
        return False
