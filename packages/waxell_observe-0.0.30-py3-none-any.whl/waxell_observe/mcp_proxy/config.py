"""Configuration models for the MCP governance proxy.

Provides Pydantic models for proxy configuration, YAML/JSON config file loading
with environment variable substitution, and helpers to convert proxy config into
formats expected by GovernanceMiddleware and ``create_proxy()``.
"""

from __future__ import annotations

import json
import os
from typing import Any

from pydantic import BaseModel


class ToolPolicyConfig(BaseModel):
    """Per-tool governance policy from config file.

    Maps tool names to governance rules for platform teams governing
    third-party MCP servers where ``@governance`` decorators are not available.

    Attributes:
        pii_scan: PII scanning mode -- ``"none"``, ``"standard"``, or ``"strict"``.
        policy_action: Override policy action -- ``"allow"``, ``"block"``, ``"warn"``,
            or ``None`` (use server default).
        rate_limit: Per-tool rate limit config. Example:
            ``{"max_per_minute": 10, "max_per_hour": 100}``.
        approval_required: Whether the tool call requires approval before execution.
    """

    pii_scan: str = "standard"
    policy_action: str | None = None
    rate_limit: dict[str, Any] | None = None
    approval_required: bool = False


class ProxyConfig(BaseModel):
    """Full proxy configuration from YAML/JSON config file.

    Defines the target server, proxy settings, governance defaults,
    per-tool policies, and security features.

    Attributes:
        target: Target server specification. Accepts:
            - ``{"url": "http://..."}`` for HTTP servers
            - ``{"command": "...", "args": [...], "env": {...}}`` for stdio servers
            - ``{"path": "..."}`` for local Python/JS server scripts
        name: Proxy server name for MCP server metadata and OTel attribution.
        transport: Inbound transport -- ``"stdio"`` or ``"http"``.
        host: Host to bind for HTTP transport.
        port: Port to bind for HTTP transport.
        api_key: Waxell API key for controlplane policy checks. Optional.
        api_url: Waxell API URL. Optional.
        default_pii_scan: Default PII scanning mode for unconfigured tools.
        default_policy_action: Default policy action for unconfigured tools.
        fail_open: If ``True``, governance errors let tool calls proceed.
        tools: Per-tool governance policies by tool name.
        fingerprinting: Enable tool fingerprint capture on first ``tools/list``.
        rug_pull_detection: Enable rug pull detection (tool definition change alerts).
    """

    # Target server
    target: dict[str, Any]

    # Proxy server settings
    name: str = "waxell-proxy"
    transport: str = "stdio"
    host: str = "0.0.0.0"
    port: int = 8080

    # Governance
    api_key: str | None = None
    api_url: str | None = None
    default_pii_scan: str = "standard"
    default_policy_action: str = "allow"
    fail_open: bool = True

    # Per-tool policies
    tools: dict[str, ToolPolicyConfig] = {}

    # Security
    fingerprinting: bool = True
    rug_pull_detection: bool = True


def load_config(path: str) -> ProxyConfig:
    """Load proxy configuration from a YAML or JSON file.

    Environment variables referenced as ``${VAR_NAME}`` in the config file
    are resolved via ``os.path.expandvars()`` before parsing.

    YAML files require ``pyyaml`` to be installed. JSON files do not require
    any additional dependencies.

    Args:
        path: Path to the config file (``.yaml``, ``.yml``, or ``.json``).

    Returns:
        Validated :class:`ProxyConfig` instance.

    Raises:
        FileNotFoundError: If the config file does not exist.
        ValueError: If the file extension is unsupported.
        ImportError: If a YAML file is loaded but ``pyyaml`` is not installed.
    """
    with open(path) as f:
        raw = f.read()

    # Resolve ${ENV_VAR} references before parsing
    raw = os.path.expandvars(raw)

    lower_path = path.lower()
    if lower_path.endswith((".yaml", ".yml")):
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "PyYAML is required to load YAML config files. "
                "Install it with: pip install pyyaml"
            )
        data = yaml.safe_load(raw)
    elif lower_path.endswith(".json"):
        data = json.loads(raw)
    else:
        raise ValueError(
            f"Unsupported config file extension: {path!r}. Use .yaml, .yml, or .json."
        )

    return ProxyConfig(**data)


def build_tool_configs(config: ProxyConfig) -> dict:
    """Convert proxy per-tool policies to GovernanceMiddleware tool_configs.

    Maps :class:`ToolPolicyConfig` instances from the proxy config into
    :class:`~waxell_observe.mcp.config.ToolGovernanceConfig` instances
    expected by ``GovernanceMiddleware``.

    Args:
        config: Proxy configuration with per-tool policies.

    Returns:
        Dict mapping tool names to ``ToolGovernanceConfig`` instances.
    """
    from waxell_observe.mcp.config import ToolGovernanceConfig

    result: dict = {}
    for tool_name, policy in config.tools.items():
        result[tool_name] = ToolGovernanceConfig(
            pii_scan=policy.pii_scan,
            policy_action=policy.policy_action,
            rate_limit=policy.rate_limit,
            approval_required=policy.approval_required,
        )
    return result


def build_target_spec(config: ProxyConfig) -> str | dict:
    """Convert proxy target config into a spec for ``create_proxy()``.

    Translates the ``target`` dict from the config file into the format
    expected by FastMCP's ``create_proxy()`` function.

    Args:
        config: Proxy configuration with target specification.

    Returns:
        A URL string for HTTP targets, an MCPConfig-format dict for stdio
        targets, or a file path string for local script targets.

    Raises:
        ValueError: If the target dict does not contain ``url``, ``command``,
            or ``path``.
    """
    target = config.target

    if "url" in target:
        return target["url"]

    if "command" in target:
        return {
            "mcpServers": {
                "target": {
                    "command": target["command"],
                    "args": target.get("args", []),
                    "env": target.get("env", {}),
                }
            }
        }

    if "path" in target:
        return target["path"]

    raise ValueError(
        "Invalid target config: must have 'url', 'command', or 'path'. "
        f"Got keys: {list(target.keys())}"
    )
