"""Security middleware for proxy-specific tool fingerprinting and rug pull detection.

Captures tool fingerprints on first ``tools/list`` request and logs warnings
when tool definitions change. Designed for third-party MCP servers where
tool stability cannot be guaranteed.

This module imports ``fastmcp`` at the top level because it is only loaded
by ``server.py`` which already requires ``fastmcp``.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone

from fastmcp.server.middleware import Middleware

logger = logging.getLogger("waxell")


class SecurityMiddleware(Middleware):
    """Middleware that captures tool fingerprints on first tools/list request.

    Integrates with the ``waxell_observe.instrumentors.mcp_security`` module
    to compute, store, and compare tool fingerprints. Changes are logged as
    warnings with unified diffs.

    This middleware never blocks tool listing -- fingerprinting is observational.
    It runs before GovernanceMiddleware in the middleware chain so fingerprints
    are captured before governance checks.

    Args:
        server_name: Name of the proxied server (used as fingerprint store key).
        fingerprinting: Enable tool fingerprint capture.
        rug_pull_detection: Enable rug pull detection (alerts on tool changes).
    """

    def __init__(
        self,
        server_name: str,
        fingerprinting: bool = True,
        rug_pull_detection: bool = True,
    ) -> None:
        self._server_name = server_name
        self._fingerprinting = fingerprinting
        self._rug_pull_detection = rug_pull_detection
        self._fingerprinted = False

    async def on_list_tools(self, context, call_next):
        """Intercept tools/list to capture tool fingerprints.

        On the first call, computes and stores fingerprints for all tools.
        On subsequent calls, compares against stored baselines and logs
        warnings for any changes.

        Always returns the tool list from the target -- never blocks.
        """
        tools = await call_next(context)

        if not self._fingerprinting or self._fingerprinted:
            return tools

        self._fingerprinted = True

        try:
            from waxell_observe.instrumentors.mcp_security import (
                ToolFingerprint,
                _fingerprint_store,
                _store_lock,
                compute_tool_fingerprint,
                generate_description_diff,
                get_stored_fingerprint,
                store_fingerprint,
            )

            # tools is a Sequence[Tool] from on_list_tools
            tool_list = list(tools) if tools else []
            current_tool_names: set[str] = set()
            now = datetime.now(timezone.utc).isoformat()

            for tool in tool_list:
                tool_name = getattr(tool, "name", "unknown")
                current_tool_names.add(tool_name)

                new_hash = compute_tool_fingerprint(tool)
                if not new_hash:
                    continue

                new_fp = ToolFingerprint(
                    server_name=self._server_name,
                    tool_name=tool_name,
                    fingerprint_hash=new_hash,
                    description=getattr(tool, "description", None) or "",
                    input_schema_json=json.dumps(
                        getattr(tool, "inputSchema", None) or {},
                        sort_keys=True,
                        default=str,
                    ),
                    output_schema_json=json.dumps(
                        getattr(tool, "outputSchema", None) or {},
                        sort_keys=True,
                        default=str,
                    ),
                    first_seen=now,
                )

                stored = get_stored_fingerprint(self._server_name, tool_name)

                if stored is None:
                    # First observation -- store silently
                    store_fingerprint(new_fp)
                    continue

                if stored.fingerprint_hash == new_hash:
                    # No change
                    continue

                # Change detected -- log warning with diff
                diff_text = generate_description_diff(stored, tool)
                logger.warning(
                    "MCP proxy fingerprint change detected: %s:%s\n%s",
                    self._server_name,
                    tool_name,
                    diff_text,
                )

                if self._rug_pull_detection:
                    logger.warning(
                        "Rug pull detection: tool '%s' on server '%s' has changed "
                        "definition since last observation (old hash: %s, new hash: %s)",
                        tool_name,
                        self._server_name,
                        stored.fingerprint_hash[:16],
                        new_hash[:16],
                    )

                # Update stored fingerprint to new baseline
                store_fingerprint(new_fp)

            # Detect removed tools
            try:
                prefix = f"{self._server_name}:"
                with _store_lock:
                    stored_keys = [
                        k for k in _fingerprint_store if k.startswith(prefix)
                    ]
                for key in stored_keys:
                    stored_tool_name = key[len(prefix) :]
                    if stored_tool_name not in current_tool_names:
                        logger.warning(
                            "MCP proxy: tool '%s' removed from server '%s'",
                            stored_tool_name,
                            self._server_name,
                        )
            except Exception as exc:
                logger.debug("MCP proxy tool removal detection failed: %s", exc)

        except Exception as exc:
            logger.warning(
                "MCP proxy fingerprint capture failed for %s: %s -- skipping (fail-open)",
                self._server_name,
                exc,
            )

        return tools

    async def on_call_tool(self, context, call_next):
        """Passthrough -- GovernanceMiddleware handles tool call governance."""
        return await call_next(context)
