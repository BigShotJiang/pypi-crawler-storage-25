"""ProxyServer orchestration for MCP governance proxy.

Combines FastMCP's ``create_proxy()`` with ``GovernanceMiddleware`` and
optional ``SecurityMiddleware`` to create a runnable governance proxy
for third-party MCP servers.

All ``fastmcp`` imports are lazy (inside methods) so this module can
be imported without ``fastmcp`` installed.
"""

from __future__ import annotations

import logging
from typing import Any

from .config import ProxyConfig, build_target_spec, build_tool_configs, load_config

logger = logging.getLogger("waxell")


class ProxyServer:
    """Governance proxy for third-party MCP servers.

    Wraps a target MCP server with GovernanceMiddleware for policy checks,
    PII scanning, rate limiting, and OTel span recording. Optionally adds
    SecurityMiddleware for tool fingerprinting and rug pull detection.

    Args:
        config: Proxy configuration specifying target, governance, and security settings.

    Example::

        from waxell_observe.mcp_proxy import ProxyServer, ProxyConfig

        config = ProxyConfig(
            target={"url": "http://localhost:9000/mcp"},
            api_key="wax_sk_...",
        )
        proxy = ProxyServer(config)
        proxy.run(transport="stdio")
    """

    def __init__(self, config: ProxyConfig) -> None:
        from fastmcp.server import create_proxy

        from waxell_observe.mcp import GovernanceMiddleware

        self.config = config

        # Build proxy targeting the backend server
        target_spec = build_target_spec(config)
        self._proxy = create_proxy(target_spec, name=config.name)

        # Add SecurityMiddleware first (runs on list_tools before governance)
        if config.fingerprinting or config.rug_pull_detection:
            from .security import SecurityMiddleware

            security_mw = SecurityMiddleware(
                server_name=config.name,
                fingerprinting=config.fingerprinting,
                rug_pull_detection=config.rug_pull_detection,
            )
            self._proxy.add_middleware(security_mw)

        # Add GovernanceMiddleware
        governance_mw = GovernanceMiddleware(
            api_key=config.api_key or "",
            api_url=config.api_url or "",
            policy_config={
                "default_pii_scan": config.default_pii_scan,
                "default_policy_action": config.default_policy_action,
                "fail_open": config.fail_open,
            },
            tool_configs=build_tool_configs(config),
        )
        self._proxy.add_middleware(governance_mw)

    @property
    def proxy(self):
        """Access the underlying FastMCPProxy for advanced use (testing, extension)."""
        return self._proxy

    def run(self, transport: str | None = None, **kwargs: Any) -> None:
        """Run the proxy server.

        Args:
            transport: Override inbound transport (``"stdio"`` or ``"http"``).
                Defaults to ``self.config.transport``.
            **kwargs: Additional arguments passed to ``FastMCPProxy.run()``.
        """
        effective_transport = transport or self.config.transport
        if effective_transport == "http":
            kwargs.setdefault("host", self.config.host)
            kwargs.setdefault("port", self.config.port)
        self._proxy.run(transport=effective_transport, **kwargs)

    async def run_async(self, transport: str | None = None, **kwargs: Any) -> None:
        """Run the proxy server asynchronously.

        Args:
            transport: Override inbound transport (``"stdio"`` or ``"http"``).
                Defaults to ``self.config.transport``.
            **kwargs: Additional arguments passed to ``FastMCPProxy.run_async()``.
        """
        effective_transport = transport or self.config.transport
        if effective_transport == "http":
            kwargs.setdefault("host", self.config.host)
            kwargs.setdefault("port", self.config.port)
        await self._proxy.run_async(transport=effective_transport, **kwargs)


def create_proxy_server(
    config_path: str | None = None,
    target: str | None = None,
    **overrides: Any,
) -> ProxyServer:
    """Convenience factory for creating a ProxyServer.

    Supports two modes:
    - Config file mode: Load full config from YAML/JSON file
    - Quick target mode: Create minimal config from a target URL or path

    Args:
        config_path: Path to a YAML/JSON config file.
        target: Target server URL or local file path (for quick-start mode).
        **overrides: Override any ProxyConfig field (e.g., ``transport="http"``).

    Returns:
        Configured :class:`ProxyServer` ready to run.

    Raises:
        ValueError: If neither ``config_path`` nor ``target`` is provided.
    """
    if config_path:
        config = load_config(config_path)
        # Apply overrides to loaded config
        if overrides:
            data = config.model_dump()
            data.update(overrides)
            config = ProxyConfig(**data)
        return ProxyServer(config)

    if target:
        # Determine target type from string
        if target.startswith(("http://", "https://")):
            target_dict: dict[str, Any] = {"url": target}
        else:
            target_dict = {"path": target}

        config = ProxyConfig(target=target_dict, **overrides)
        return ProxyServer(config)

    raise ValueError("Provide either config_path or target to create a proxy server.")
