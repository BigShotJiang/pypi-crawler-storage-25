"""Entry point for ``python -m waxell_observe.mcp_proxy``."""

from __future__ import annotations

import sys

import click


@click.command()
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    help="Config file (YAML/JSON)",
)
@click.option("--target", "-t", help="Target server URL or path")
@click.option(
    "--transport",
    default=None,
    type=click.Choice(["stdio", "http"]),
    help="Inbound transport (default: from config or stdio)",
)
@click.option("--port", default=None, type=int, help="Port for HTTP transport")
@click.option("--host", default=None, help="Host for HTTP transport")
@click.option(
    "--api-key",
    envvar="WAXELL_API_KEY",
    help="Waxell API key",
)
@click.option(
    "--api-url",
    envvar="WAXELL_API_URL",
    help="Waxell API URL",
)
@click.option("--name", default=None, help="Proxy server name")
def main(config, target, transport, port, host, api_key, api_url, name):
    """Run a governance proxy for a third-party MCP server."""
    from .server import create_proxy_server

    overrides: dict = {}
    if transport:
        overrides["transport"] = transport
    if port:
        overrides["port"] = port
    if host:
        overrides["host"] = host
    if api_key:
        overrides["api_key"] = api_key
    if api_url:
        overrides["api_url"] = api_url
    if name:
        overrides["name"] = name

    if not config and not target:
        click.echo("Error: provide --config or --target", err=True)
        sys.exit(1)

    server = create_proxy_server(config_path=config, target=target, **overrides)
    server.run(transport=transport)


if __name__ == "__main__":
    main()
