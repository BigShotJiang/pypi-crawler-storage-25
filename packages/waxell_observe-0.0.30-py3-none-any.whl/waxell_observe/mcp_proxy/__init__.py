"""MCP governance proxy for third-party MCP servers.

Wraps any MCP server transparently with policy checks, PII scanning,
rate limiting, OTel span recording, and security features (tool
fingerprinting, rug pull detection).

Usage::

    from waxell_observe.mcp_proxy import ProxyServer, ProxyConfig

    config = ProxyConfig(target={"url": "http://localhost:9000/mcp"})
    proxy = ProxyServer(config)
    proxy.run(transport="stdio")
"""

from .config import ProxyConfig, ToolPolicyConfig, load_config
from .server import ProxyServer, create_proxy_server

__all__ = [
    "ProxyServer",
    "ProxyConfig",
    "ToolPolicyConfig",
    "load_config",
    "create_proxy_server",
]
