"""Click command for ``wax observe mcp-proxy``."""

from __future__ import annotations

import sys

import click


@click.command(name="mcp-proxy")
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    help="Config file (YAML/JSON)",
)
@click.option(
    "--target",
    "-t",
    help="Target server URL or path (e.g. http://localhost:8080/mcp or ./server.py)",
)
@click.option(
    "--transport",
    default=None,
    type=click.Choice(["stdio", "http"]),
    help="Inbound transport (default: stdio)",
)
@click.option(
    "--port", default=None, type=int, help="Port for HTTP transport (default: 8080)"
)
@click.option("--host", default=None, help="Host for HTTP transport (default: 0.0.0.0)")
@click.option(
    "--api-key",
    envvar="WAXELL_API_KEY",
    help="Waxell API key for controlplane policy checks",
)
@click.option(
    "--api-url",
    envvar="WAXELL_API_URL",
    help="Waxell API URL",
)
@click.option("--name", default=None, help="Proxy server name (default: waxell-proxy)")
@click.option("--no-fingerprint", is_flag=True, help="Disable tool fingerprinting")
@click.option(
    "--no-rug-pull-detection", is_flag=True, help="Disable rug pull detection"
)
@click.pass_context
def mcp_proxy(
    ctx,
    config,
    target,
    transport,
    port,
    host,
    api_key,
    api_url,
    name,
    no_fingerprint,
    no_rug_pull_detection,
):
    """Run a governance proxy for a third-party MCP server.

    Wraps any MCP server with policy checks, PII scanning, OTel span recording,
    and security features (tool fingerprinting, rug pull detection).

    \b
    Examples:
      wax observe mcp-proxy --config proxy.yaml
      wax observe mcp-proxy --target http://remote-server/mcp
      wax observe mcp-proxy --target ./my_server.py --api-key wax_sk_...
      wax observe mcp-proxy --config proxy.yaml --transport http --port 8080
    """
    if not config and not target:
        click.echo("Error: provide --config or --target", err=True)
        ctx.exit(1)

    # Build overrides dict from provided flags (skip None values)
    overrides: dict = {}
    if transport:
        overrides["transport"] = transport
    if port is not None:
        overrides["port"] = port
    if host:
        overrides["host"] = host
    if api_key:
        overrides["api_key"] = api_key
    if api_url:
        overrides["api_url"] = api_url
    if name:
        overrides["name"] = name
    if no_fingerprint:
        overrides["fingerprinting"] = False
    if no_rug_pull_detection:
        overrides["rug_pull_detection"] = False

    try:
        from rich.console import Console

        console = Console(stderr=True)
    except ImportError:
        console = None

    try:
        from waxell_observe.mcp_proxy.server import create_proxy_server

        server = create_proxy_server(config_path=config, target=target, **overrides)

        # Print startup info
        cfg = server.config
        target_info = config or target or "unknown"
        effective_transport = transport or cfg.transport

        if console:
            console.print()
            console.print(f"[bold cyan]{cfg.name}[/bold cyan] starting")
            console.print(f"  Target:     {target_info}")
            console.print(f"  Transport:  {effective_transport}", end="")
            if effective_transport == "http":
                console.print(f" ({cfg.host}:{cfg.port})")
            else:
                console.print()
            console.print(f"  PII scan:   {cfg.default_pii_scan}")
            console.print(f"  Fail-open:  {cfg.fail_open}")

            features = []
            if cfg.fingerprinting:
                features.append("fingerprinting")
            if cfg.rug_pull_detection:
                features.append("rug-pull-detection")
            if cfg.api_key:
                features.append("controlplane-policy")
            if features:
                console.print(f"  Security:   {', '.join(features)}")
            else:
                console.print("  Security:   none")
            console.print()
        else:
            click.echo(
                f"{cfg.name} starting (target={target_info}, transport={effective_transport})"
            )

        server.run(transport=transport)

    except KeyboardInterrupt:
        if console:
            console.print("\n[dim]Proxy stopped.[/dim]")
        else:
            click.echo("\nProxy stopped.")
    except Exception as exc:
        if console:
            console.print(f"\n[bold red]Error:[/bold red] {exc}")
        else:
            click.echo(f"\nError: {exc}", err=True)
        sys.exit(1)
