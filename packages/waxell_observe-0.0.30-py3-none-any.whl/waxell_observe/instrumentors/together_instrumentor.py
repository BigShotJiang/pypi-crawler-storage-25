"""Together AI auto-instrumentor for waxell-observe.

Patches the native Together AI Python SDK chat completions method.
Most Together users go through the OpenAI-compatible API (handled by
the OpenAI instrumentor's provider detection), but some use the native
``together`` package directly.

The native SDK response format is OpenAI-compatible:
  - ``response.usage.prompt_tokens`` / ``completion_tokens``
  - ``response.choices[].finish_reason``
  - ``response.model``

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class TogetherInstrumentor(BaseInstrumentor):
    """Instrumentor for the Together AI Python SDK (``together`` package).

    Patches ``together.resources.chat.completions.CompletionsResource.create``
    (Together SDK >= 2.2.0) with fallback to the legacy
    ``ChatCompletions.create`` class name for older SDK versions.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import together  # noqa: F401
        except ImportError:
            logger.debug("together package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping Together instrumentation"
            )
            return False

        patched = False

        # Sync: Together SDK >= 2.2.0 renamed ChatCompletions → CompletionsResource
        try:
            wrapt.wrap_function_wrapper(
                "together.resources.chat.completions",
                "CompletionsResource.create",
                _sync_chat_wrapper,
            )
            patched = True
            logger.debug("Patched Together sync via CompletionsResource (SDK >= 2.2.0)")
        except Exception:
            # Fallback: Together SDK < 2.2.0 uses ChatCompletions
            try:
                wrapt.wrap_function_wrapper(
                    "together.resources.chat.completions",
                    "ChatCompletions.create",
                    _sync_chat_wrapper,
                )
                patched = True
                logger.debug("Patched Together sync via ChatCompletions (SDK < 2.2.0)")
            except Exception:
                pass

        # Async: Together SDK >= 2.2.0 renamed AsyncChatCompletions → AsyncCompletionsResource
        try:
            wrapt.wrap_function_wrapper(
                "together.resources.chat.completions",
                "AsyncCompletionsResource.create",
                _async_chat_wrapper,
            )
            logger.debug(
                "Patched Together async via AsyncCompletionsResource (SDK >= 2.2.0)"
            )
        except Exception:
            # Fallback: Together SDK < 2.2.0 uses AsyncChatCompletions
            try:
                wrapt.wrap_function_wrapper(
                    "together.resources.chat.completions",
                    "AsyncChatCompletions.create",
                    _async_chat_wrapper,
                )
                logger.debug(
                    "Patched Together async via AsyncChatCompletions (SDK < 2.2.0)"
                )
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find Together chat completion methods to patch")
            return False

        self._instrumented = True
        logger.debug("Together chat.completions instrumented (sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import together.resources.chat.completions as mod

            # Sync: try new name first, then legacy
            for cls_name in ("CompletionsResource", "ChatCompletions"):
                cls = getattr(mod, cls_name, None)
                if cls is not None and hasattr(
                    getattr(cls, "create", None), "__wrapped__"
                ):
                    cls.create = cls.create.__wrapped__  # type: ignore[attr-defined]
                    break

            # Async: try new name first, then legacy
            for cls_name in ("AsyncCompletionsResource", "AsyncChatCompletions"):
                cls = getattr(mod, cls_name, None)
                if cls is not None and hasattr(
                    getattr(cls, "create", None), "__wrapped__"
                ):
                    cls.create = cls.create.__wrapped__  # type: ignore[attr-defined]
                    break
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Together chat.completions uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Together ``CompletionsResource.create`` (or legacy ``ChatCompletions.create``)."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []),
            model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    try:
        span = start_llm_span(model=model, provider_name="together")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Together uses OpenAI-compatible response format
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            choices = getattr(response, "choices", None)
            finish_reasons = (
                [c.finish_reason for c in choices if c.finish_reason] if choices else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(
                WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out
            )
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_together(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Together ``AsyncCompletionsResource.create`` (or legacy ``AsyncChatCompletions.create``)."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []),
            model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    try:
        span = start_llm_span(model=model, provider_name="together")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(response, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
            response_model = getattr(response, "model", model)
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            choices = getattr(response, "choices", None)
            finish_reasons = (
                [c.finish_reason for c in choices if c.finish_reason] if choices else []
            )

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(
                WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out
            )
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_together(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_together(response, request_model: str, kwargs: dict) -> None:
    """Record a Together AI LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    usage = getattr(response, "usage", None)
    tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
    tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
    response_model = getattr(response, "model", request_model)
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    from ._base import extract_prompt_preview
    messages = kwargs.get("messages", [])
    prompt_preview = extract_prompt_preview(messages)

    response_preview = ""
    choices = getattr(response, "choices", None)
    if choices:
        msg = choices[0].message
        if msg and getattr(msg, "content", None):
            response_preview = msg.content[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "chat.completions",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)

    # Auto-capture conversation IO
    try:
        from ._auto_conversation import record_conversation_io
        is_final = bool(
            choices
            and choices[0].finish_reason == "stop"
        )
        record_conversation_io(
            messages=messages,
            response_preview=response_preview,
            is_final_response=is_final,
            tokens_in_context=tokens_in,
            model=response_model,
            ctx=ctx,
        )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
