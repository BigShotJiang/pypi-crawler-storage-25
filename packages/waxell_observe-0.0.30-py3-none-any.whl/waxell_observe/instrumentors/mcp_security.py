"""Security helpers for MCP tool fingerprinting, server identity tracking, and rug pull detection.

Used by _call_tool_wrapper in mcp_instrumentor.py. All public functions follow the
wrapper's safety discipline: every function has its own try/except and will never
raise an exception that could break user code.
"""

from __future__ import annotations

import difflib
import hashlib
import inspect
import json
import logging
import threading
from dataclasses import dataclass
from datetime import datetime, timezone

logger = logging.getLogger("waxell")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DIFF_TRUNCATE_AT = 2048  # 2KB truncation for diff text on span attributes


# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------


@dataclass
class ToolFingerprint:
    """Stored fingerprint for a single tool."""

    server_name: str
    tool_name: str
    fingerprint_hash: str
    description: str  # Stored for diff generation
    input_schema_json: str  # Canonical JSON for diff
    output_schema_json: str  # Canonical JSON for diff
    first_seen: str  # ISO 8601 timestamp
    acknowledged: bool = False  # True after user accepts new fingerprint


@dataclass
class ToolChange:
    """Describes a detected change in a tool definition."""

    server_name: str
    tool_name: str
    change_type: (
        str  # "description_changed", "schema_changed", "tool_added", "tool_removed"
    )
    old_fingerprint: ToolFingerprint | None
    new_fingerprint: ToolFingerprint | None
    diff_text: str  # unified diff output


@dataclass
class DescriptionChangeEvent:
    """Event passed to on_description_change callback."""

    server_name: str
    tool_name: str
    change_type: str
    diff_text: str
    old_hash: str
    new_hash: str


@dataclass
class ChangeDecision:
    """Return from on_description_change callback."""

    allow: bool = True  # False = block this tool call
    acknowledge: bool = False  # True = accept new fingerprint as baseline


@dataclass
class ServerIdentity:
    """Captured server metadata."""

    name: str
    version: str
    transport: str
    capabilities: dict  # Serialized ServerCapabilities
    connection_info: str  # URL or command


# ---------------------------------------------------------------------------
# Process-global state
# ---------------------------------------------------------------------------

_fingerprint_store: dict[str, ToolFingerprint] = {}  # key: "{server_name}:{tool_name}"
_server_versions: dict[str, str] = {}  # key: server_name, value: last-seen version
_store_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Fingerprint Computation
# ---------------------------------------------------------------------------


def compute_tool_fingerprint(tool) -> str:
    """Compute SHA256 fingerprint of a tool definition.

    Hash includes: name, description, inputSchema, outputSchema.
    Uses canonical JSON (sort_keys=True) for deterministic hashing
    regardless of key ordering.

    Args:
        tool: An MCP Tool object (or anything with .name, .description,
            .inputSchema, and optionally .outputSchema).

    Returns:
        SHA256 hex digest string (64 chars).
    """
    try:
        canonical = json.dumps(
            {
                "name": tool.name,
                "description": getattr(tool, "description", None) or "",
                "inputSchema": getattr(tool, "inputSchema", None) or {},
                "outputSchema": getattr(tool, "outputSchema", None) or {},
            },
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(canonical.encode()).hexdigest()
    except Exception as exc:
        logger.warning("MCP fingerprint computation failed: %s", exc)
        return ""


# ---------------------------------------------------------------------------
# Diff Generation
# ---------------------------------------------------------------------------


def generate_description_diff(old_fingerprint: ToolFingerprint, new_tool) -> str:
    """Generate unified diff between old stored fingerprint and new tool definition.

    Diffs description, input schema, and output schema if any changed.
    Truncates result to 2KB to prevent span attribute bloat.

    Args:
        old_fingerprint: Previously stored :class:`ToolFingerprint`.
        new_tool: New MCP Tool object with .name, .description, .inputSchema.

    Returns:
        Unified diff text, or empty string if identical. Never raises.
    """
    try:
        parts: list[str] = []

        # Diff descriptions
        old_desc = old_fingerprint.description or ""
        new_desc = getattr(new_tool, "description", None) or ""
        if old_desc != new_desc:
            desc_diff = difflib.unified_diff(
                old_desc.splitlines(keepends=True),
                new_desc.splitlines(keepends=True),
                fromfile="old/description",
                tofile="new/description",
            )
            parts.extend(desc_diff)

        # Diff input schemas
        old_input = old_fingerprint.input_schema_json or "{}"
        new_input = json.dumps(
            getattr(new_tool, "inputSchema", None) or {},
            sort_keys=True,
            default=str,
            indent=2,
        )
        old_input_pretty = json.dumps(json.loads(old_input), sort_keys=True, indent=2)
        if old_input_pretty != new_input:
            schema_diff = difflib.unified_diff(
                old_input_pretty.splitlines(keepends=True),
                new_input.splitlines(keepends=True),
                fromfile="old/inputSchema",
                tofile="new/inputSchema",
            )
            parts.extend(schema_diff)

        # Diff output schemas
        old_output = old_fingerprint.output_schema_json or "{}"
        new_output = json.dumps(
            getattr(new_tool, "outputSchema", None) or {},
            sort_keys=True,
            default=str,
            indent=2,
        )
        old_output_pretty = json.dumps(json.loads(old_output), sort_keys=True, indent=2)
        if old_output_pretty != new_output:
            output_diff = difflib.unified_diff(
                old_output_pretty.splitlines(keepends=True),
                new_output.splitlines(keepends=True),
                fromfile="old/outputSchema",
                tofile="new/outputSchema",
            )
            parts.extend(output_diff)

        diff_text = "\n".join(parts)
        return diff_text[:_DIFF_TRUNCATE_AT]

    except Exception as exc:
        logger.warning("MCP description diff generation failed: %s", exc)
        return ""


# ---------------------------------------------------------------------------
# Store Operations (thread-safe)
# ---------------------------------------------------------------------------


def get_stored_fingerprint(server_name: str, tool_name: str) -> ToolFingerprint | None:
    """Retrieve a stored fingerprint for a server:tool pair.

    Thread-safe read from the process-global fingerprint store.

    Args:
        server_name: MCP server name.
        tool_name: MCP tool name.

    Returns:
        :class:`ToolFingerprint` if found, None otherwise. Never raises.
    """
    try:
        key = f"{server_name}:{tool_name}"
        with _store_lock:
            return _fingerprint_store.get(key)
    except Exception as exc:
        logger.warning("MCP fingerprint store read failed: %s", exc)
        return None


def store_fingerprint(fp: ToolFingerprint) -> None:
    """Store a fingerprint in the process-global store.

    Thread-safe write to the fingerprint store.

    Args:
        fp: :class:`ToolFingerprint` to store.
    """
    try:
        key = f"{fp.server_name}:{fp.tool_name}"
        with _store_lock:
            _fingerprint_store[key] = fp
    except Exception as exc:
        logger.warning("MCP fingerprint store write failed: %s", exc)


def acknowledge_fingerprint(server_name: str, tool_name: str) -> bool:
    """Mark a stored fingerprint as acknowledged (user accepted the change).

    Thread-safe update of the acknowledged flag.

    Args:
        server_name: MCP server name.
        tool_name: MCP tool name.

    Returns:
        True if fingerprint was found and acknowledged, False otherwise.
        Never raises.
    """
    try:
        key = f"{server_name}:{tool_name}"
        with _store_lock:
            fp = _fingerprint_store.get(key)
            if fp is not None:
                fp.acknowledged = True
                return True
            return False
    except Exception as exc:
        logger.warning("MCP fingerprint acknowledge failed: %s", exc)
        return False


# ---------------------------------------------------------------------------
# Server Identity
# ---------------------------------------------------------------------------


def extract_server_identity(session) -> ServerIdentity:
    """Extract all available server metadata from an MCP session.

    Reads ``_server_info`` (from ``initialize()`` response) and transport
    metadata from session internals.

    Args:
        session: An ``mcp.client.session.ClientSession`` instance.

    Returns:
        :class:`ServerIdentity` with available metadata. Fields default to
        empty strings/dicts if unavailable. Never raises.
    """
    try:
        name = ""
        version = ""
        transport = ""
        capabilities: dict = {}
        connection_info = ""

        # Server info from initialize() response
        server_info = getattr(session, "_server_info", None)
        if server_info:
            name = getattr(server_info, "name", "") or ""
            version = getattr(server_info, "version", "") or ""
        else:
            logger.debug(
                "MCP session has no _server_info -- server identity unavailable"
            )

        # Transport type detection (reuse existing _detect_transport)
        try:
            from .mcp_instrumentor import _detect_transport

            transport = _detect_transport(session)
        except Exception:
            pass

        # Server capabilities (if available)
        server_caps = getattr(session, "_server_capabilities", None)
        if server_caps is None:
            # Try method if attribute not available
            get_caps = getattr(session, "get_server_capabilities", None)
            if get_caps is not None:
                try:
                    server_caps = get_caps()
                except Exception:
                    pass

        if server_caps is not None:
            try:
                capabilities = {
                    "tools": bool(getattr(server_caps, "tools", None)),
                    "resources": bool(getattr(server_caps, "resources", None)),
                    "prompts": bool(getattr(server_caps, "prompts", None)),
                    "logging": bool(getattr(server_caps, "logging", None)),
                }
            except Exception:
                pass

        # Connection info: try to extract from session transport
        try:
            read_stream = getattr(session, "_read_stream", None)
            if read_stream is not None:
                # For HTTP/SSE: look for URL
                url = getattr(read_stream, "url", None)
                if url:
                    connection_info = str(url)
                # For stdio: look for command
                cmd = getattr(read_stream, "command", None)
                if cmd:
                    connection_info = str(cmd)
        except Exception:
            pass

        return ServerIdentity(
            name=name,
            version=version,
            transport=transport,
            capabilities=capabilities,
            connection_info=connection_info,
        )

    except Exception as exc:
        logger.warning("MCP server identity extraction failed: %s", exc)
        return ServerIdentity(
            name="",
            version="",
            transport="",
            capabilities={},
            connection_info="",
        )


def check_server_version_change(server_name: str, version: str) -> tuple[bool, str]:
    """Check if a server's version has changed since last observation.

    Thread-safe check and update of the process-global version store.

    Args:
        server_name: MCP server name.
        version: Current server version string.

    Returns:
        Tuple of (changed: bool, old_version: str).
        On first observation, returns (False, "").
        Never raises.
    """
    try:
        with _store_lock:
            old_version = _server_versions.get(server_name)
            if old_version is None:
                # First observation
                _server_versions[server_name] = version
                return (False, "")
            if old_version == version:
                return (False, "")
            # Version changed
            _server_versions[server_name] = version
            return (True, old_version)
    except Exception as exc:
        logger.warning("MCP server version check failed: %s", exc)
        return (False, "")


# ---------------------------------------------------------------------------
# Fingerprint Capture
# ---------------------------------------------------------------------------


async def capture_fingerprints(
    session,
    server_name: str,
    fingerprint_config: dict | None = None,
) -> list[ToolChange]:
    """Capture and compare tool fingerprints for an MCP session.

    Called once per session on first ``call_tool`` invocation.
    Calls ``session.list_tools()`` to get current tool definitions,
    computes hashes, and compares against the process-global baseline.

    Args:
        session: An ``mcp.client.session.ClientSession`` instance.
        server_name: MCP server name.
        fingerprint_config: Optional config dict with keys:
            - ``enabled`` (bool): Enable/disable fingerprinting (default True).
            - ``acknowledged_hashes`` (dict[str, str]): Pre-acknowledged hashes.

    Returns:
        List of :class:`ToolChange` objects for actual changes
        (not first observations). Empty list on failure (fail-open).
        Never raises.
    """
    try:
        config = fingerprint_config or {}

        # Check if fingerprinting is disabled
        if not config.get("enabled", True):
            logger.debug("MCP fingerprinting disabled for server %s", server_name)
            return []

        # Get current tool definitions
        try:
            tools_result = await session.list_tools()
        except Exception as exc:
            logger.warning(
                "MCP list_tools() failed for %s: %s -- skipping fingerprint capture (fail-open)",
                server_name,
                exc,
            )
            return []

        tools = getattr(tools_result, "tools", []) or []
        acknowledged_hashes = config.get("acknowledged_hashes", {}) or {}

        # Set tool count as side effect so the wrapper can record it on the span
        try:
            session._waxell_tool_count = len(tools)
        except Exception:
            pass

        changes: list[ToolChange] = []
        current_tool_names: set[str] = set()
        now = datetime.now(timezone.utc).isoformat()

        for tool in tools:
            tool_name = getattr(tool, "name", "unknown")
            current_tool_names.add(tool_name)

            # Compute hash for this tool
            new_hash = compute_tool_fingerprint(tool)
            if not new_hash:
                continue

            # Build new fingerprint
            new_fp = ToolFingerprint(
                server_name=server_name,
                tool_name=tool_name,
                fingerprint_hash=new_hash,
                description=getattr(tool, "description", None) or "",
                input_schema_json=json.dumps(
                    getattr(tool, "inputSchema", None) or {},
                    sort_keys=True,
                    default=str,
                ),
                output_schema_json=json.dumps(
                    getattr(tool, "outputSchema", None) or {},
                    sort_keys=True,
                    default=str,
                ),
                first_seen=now,
            )

            # Check against stored baseline
            stored = get_stored_fingerprint(server_name, tool_name)

            if stored is None:
                # First observation -- store but don't alert
                store_fingerprint(new_fp)
                continue

            if stored.fingerprint_hash == new_hash:
                # No change
                continue

            # Check if new hash is pre-acknowledged
            ack_key = f"{server_name}:{tool_name}"
            if acknowledged_hashes.get(ack_key) == new_hash:
                # Pre-acknowledged change -- update store silently
                new_fp.acknowledged = True
                store_fingerprint(new_fp)
                continue

            # Change detected -- determine type
            diff_text = generate_description_diff(stored, tool)
            old_desc = stored.description or ""
            new_desc = getattr(tool, "description", None) or ""

            if old_desc != new_desc:
                change_type = "description_changed"
            else:
                change_type = "schema_changed"

            changes.append(
                ToolChange(
                    server_name=server_name,
                    tool_name=tool_name,
                    change_type=change_type,
                    old_fingerprint=stored,
                    new_fingerprint=new_fp,
                    diff_text=diff_text,
                )
            )

        # Detect removed tools: tools in store for this server but not in current list
        try:
            prefix = f"{server_name}:"
            with _store_lock:
                stored_keys = [k for k in _fingerprint_store if k.startswith(prefix)]
            for key in stored_keys:
                stored_tool_name = key[len(prefix) :]
                if stored_tool_name not in current_tool_names:
                    stored_fp = get_stored_fingerprint(server_name, stored_tool_name)
                    changes.append(
                        ToolChange(
                            server_name=server_name,
                            tool_name=stored_tool_name,
                            change_type="tool_removed",
                            old_fingerprint=stored_fp,
                            new_fingerprint=None,
                            diff_text=f"Tool '{stored_tool_name}' removed from server '{server_name}'",
                        )
                    )
        except Exception as exc:
            logger.warning("MCP tool removal detection failed: %s", exc)

        # Log pagination warning if applicable
        next_cursor = getattr(tools_result, "nextCursor", None)
        if next_cursor:
            logger.warning(
                "MCP server %s has paginated tool list (nextCursor=%s) -- "
                "only first page fingerprinted",
                server_name,
                next_cursor,
            )

        # Set fingerprint status as side effect for the wrapper
        try:
            if changes:
                session._waxell_fingerprint_status = "changed"
            else:
                session._waxell_fingerprint_status = "first_observation"
        except Exception:
            pass

        return changes

    except Exception as exc:
        logger.warning(
            "MCP fingerprint capture failed for %s: %s -- skipping (fail-open)",
            server_name,
            exc,
        )
        return []


# ---------------------------------------------------------------------------
# Change Handling
# ---------------------------------------------------------------------------


async def handle_tool_changes(
    changes: list[ToolChange],
    session,
    governance_config: dict | None,
    span,
    fingerprint_config: dict | None = None,
) -> bool:
    """Process detected tool changes -- log, record, callback, and decide.

    For each change: logs a warning with diff text, sets security attributes
    on the span, calls ``on_description_change`` callback if configured,
    and checks per-server/per-tool block config.

    Args:
        changes: List of :class:`ToolChange` objects from :func:`capture_fingerprints`.
        session: MCP ``ClientSession`` instance.
        governance_config: Governance configuration dict from session (may be None).
        span: OTel span to record attributes on.
        fingerprint_config: Per-server fingerprint settings (may be None).

    Returns:
        True if ANY change triggered a block (tool call should not proceed).
        False on no block or on error (fail-open). Never raises.
    """
    try:
        if not changes:
            return False

        from ..tracing.attributes import MCPAttributes

        config = fingerprint_config or {}
        blocked = False

        # Record change count on span
        try:
            span.set_attribute(MCPAttributes.FINGERPRINT_CHANGES_DETECTED, len(changes))
        except Exception:
            pass

        # Collect added/removed tool names
        added_tools: list[str] = []
        removed_tools: list[str] = []

        # Collect all diffs for the span
        all_diffs: list[str] = []

        for change in changes:
            # Log warning with diff
            logger.warning(
                "MCP tool change detected: %s:%s [%s]\n%s",
                change.server_name,
                change.tool_name,
                change.change_type,
                change.diff_text,
            )

            if change.diff_text:
                all_diffs.append(change.diff_text)

            if change.change_type == "tool_added":
                added_tools.append(change.tool_name)
            elif change.change_type == "tool_removed":
                removed_tools.append(change.tool_name)

            # Record governance event via audit pipeline
            try:
                from .mcp_governance import record_audit_attributes

                # Build a minimal policy result for audit
                _AuditResult = type(
                    "_AuditResult", (), {"action": "warn", "reason": ""}
                )
                audit_result = _AuditResult()
                audit_result.action = "warn"
                audit_result.reason = (
                    f"tool_change:{change.change_type}:{change.tool_name}"
                )

                record_audit_attributes(
                    span,
                    governance_config or {},
                    audit_result,
                    change.tool_name,
                    change.server_name,
                    None,
                )
            except Exception as exc:
                logger.debug("MCP security audit recording failed: %s", exc)

            # Call on_description_change callback if configured
            handler = getattr(session, "_waxell_on_description_change", None)
            if handler is not None:
                try:
                    event = DescriptionChangeEvent(
                        server_name=change.server_name,
                        tool_name=change.tool_name,
                        change_type=change.change_type,
                        diff_text=change.diff_text,
                        old_hash=change.old_fingerprint.fingerprint_hash
                        if change.old_fingerprint
                        else "",
                        new_hash=change.new_fingerprint.fingerprint_hash
                        if change.new_fingerprint
                        else "",
                    )

                    # Handle async and sync callbacks
                    if inspect.iscoroutinefunction(handler):
                        decision = await handler(event)
                    else:
                        decision = handler(event)

                    if isinstance(decision, ChangeDecision):
                        if decision.acknowledge and change.new_fingerprint:
                            acknowledge_fingerprint(
                                change.server_name, change.tool_name
                            )
                            store_fingerprint(change.new_fingerprint)
                        if not decision.allow:
                            blocked = True
                except Exception as exc:
                    logger.warning(
                        "MCP on_description_change callback failed: %s -- allowing (fail-open)",
                        exc,
                    )

            # Check per-server/per-tool block config
            default_action = config.get("action", "warn")
            per_tool_actions = config.get("per_tool_actions", {}) or {}
            tool_action = per_tool_actions.get(change.tool_name, default_action)
            if tool_action == "block":
                blocked = True

        # Set aggregate span attributes
        try:
            if all_diffs:
                combined_diff = "\n---\n".join(all_diffs)
                span.set_attribute(
                    MCPAttributes.FINGERPRINT_DIFF,
                    combined_diff[:_DIFF_TRUNCATE_AT],
                )
            if added_tools:
                span.set_attribute(MCPAttributes.TOOLS_ADDED, ",".join(added_tools))
            if removed_tools:
                span.set_attribute(MCPAttributes.TOOLS_REMOVED, ",".join(removed_tools))
        except Exception:
            pass

        return blocked

    except Exception as exc:
        logger.warning(
            "MCP tool change handling failed: %s -- allowing (fail-open)", exc
        )
        return False
