"""Governance helpers for MCP tool call policy enforcement, PII scanning, and audit trail.

Used by _call_tool_wrapper in mcp_instrumentor.py. All public functions follow the
wrapper's safety discipline: every function has its own try/except and will never
raise an exception that could break user code.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from datetime import datetime, timezone

logger = logging.getLogger("waxell")

# ---------------------------------------------------------------------------
# Re-exports from scanning module (backwards compatibility)
# ---------------------------------------------------------------------------

from waxell_observe.scanning import PIIScanner, RegexPIIScanner, scan_text_for_pii
from waxell_observe.scanning.scanner import _ACTION_SEVERITY, _TRUNCATE_SCAN_AT

__all__ = [
    "PIIScanner",
    "RegexPIIScanner",
    "scan_text_for_pii",
    "_ACTION_SEVERITY",
    "_TRUNCATE_SCAN_AT",
    "do_policy_check",
    "apply_throttle",
    "record_audit_attributes",
    "build_synthetic_error_result",
]


# ---------------------------------------------------------------------------
# Policy Check
# ---------------------------------------------------------------------------


async def do_policy_check(
    client, policy_id: str, governance_config: dict, span
) -> object:
    """Run async policy check against controlplane.

    Args:
        client: :class:`WaxellObserveClient` instance.
        policy_id: Policy identifier (e.g. ``mcp:{server}:{tool}``).
        governance_config: Governance configuration dict from session.
        span: OTel span to record attributes on.

    Returns:
        :class:`PolicyCheckResult`. On any error, returns allow result (fail-open)
        and sets ``POLICY_SKIPPED`` on the span.
    """
    try:
        from ..tracing.attributes import MCPAttributes
        from ..types import PolicyCheckResult

        result = await client.check_policy(
            agent_name=governance_config.get("agent_name", ""),
            workflow_name=policy_id,
        )
        span.set_attribute(MCPAttributes.GOVERNANCE_ACTION, result.action)
        if result.reason:
            span.set_attribute(MCPAttributes.POLICY_REASON, result.reason)
        return result
    except Exception as exc:
        logger.warning(
            "MCP policy check failed for %s: %s -- allowing (fail-open)",
            policy_id,
            exc,
        )
        try:
            from ..tracing.attributes import MCPAttributes
            from ..types import PolicyCheckResult

            span.set_attribute(MCPAttributes.POLICY_SKIPPED, True)
            return PolicyCheckResult(action="allow", reason="policy_check_failed")
        except Exception:
            # If even the fallback fails, return a minimal object
            from ..types import PolicyCheckResult

            return PolicyCheckResult(action="allow", reason="policy_check_failed")


# ---------------------------------------------------------------------------
# Throttle
# ---------------------------------------------------------------------------


async def apply_throttle(policy_result, span) -> float:
    """Apply throttle delay if policy action is ``throttle``.

    Args:
        policy_result: :class:`PolicyCheckResult` from policy check.
        span: OTel span to record throttle delay on.

    Returns:
        Delay applied in seconds. 0.0 if not throttled or on error.
    """
    try:
        if policy_result.action != "throttle":
            return 0.0

        from ..tracing.attributes import MCPAttributes

        metadata = getattr(policy_result, "metadata", None) or {}
        delay_seconds = float(metadata.get("throttle_delay_seconds", 1.0))

        # Cap delay to prevent abuse
        delay_seconds = min(delay_seconds, 30.0)

        span.set_attribute(MCPAttributes.THROTTLE_DELAY_MS, int(delay_seconds * 1000))
        logger.info("MCP throttle: delaying %s for %.1fs", span.name, delay_seconds)
        await asyncio.sleep(delay_seconds)
        return delay_seconds
    except Exception as exc:
        logger.warning("MCP throttle failed: %s -- skipping delay (fail-open)", exc)
        return 0.0


# ---------------------------------------------------------------------------
# Audit Trail
# ---------------------------------------------------------------------------


def record_audit_attributes(
    span,
    governance_config: dict,
    policy_result,
    tool_name: str,
    server_name: str,
    arguments: dict | None,
    pii_input_result: dict | None = None,
    pii_output_result: dict | None = None,
) -> None:
    """Record full governance audit trail on the span.

    All attributes are recorded on the MCP tool span for audit purposes.
    This function never raises -- errors are logged and swallowed.

    Args:
        span: OTel span to record attributes on.
        governance_config: Governance configuration dict from session.
        policy_result: :class:`PolicyCheckResult` from policy check.
        tool_name: MCP tool name.
        server_name: MCP server name.
        arguments: Tool call arguments (used for params hash).
        pii_input_result: PII scan result for inputs (optional).
        pii_output_result: PII scan result for outputs (optional).
    """
    try:
        from ..tracing.attributes import MCPAttributes

        # Core audit attributes
        span.set_attribute(MCPAttributes.GOVERNANCE_CHECKED, True)
        span.set_attribute(
            MCPAttributes.GOVERNANCE_TIMESTAMP,
            datetime.now(timezone.utc).isoformat(),
        )
        span.set_attribute(MCPAttributes.GOVERNANCE_ACTION, policy_result.action)

        # Policy rule info
        evaluations = getattr(policy_result, "evaluations", None) or []
        if evaluations:
            rule_ids = [
                str(e.get("id", ""))
                for e in evaluations
                if isinstance(e, dict) and e.get("id")
            ]
            if rule_ids:
                span.set_attribute(MCPAttributes.POLICY_RULE_IDS, ",".join(rule_ids))

        # Initiator context
        agent_name = governance_config.get("agent_name", "")
        if agent_name:
            span.set_attribute(MCPAttributes.AUDIT_AGENT, agent_name)
        user_id = governance_config.get("user_id", "")
        if user_id:
            span.set_attribute(MCPAttributes.AUDIT_USER, user_id)

        # Params hash for audit (SHA256, truncated to 16 chars)
        if arguments:
            params_json = json.dumps(arguments, sort_keys=True, default=str)
            params_hash = hashlib.sha256(params_json.encode()).hexdigest()[:16]
            span.set_attribute(MCPAttributes.PARAMS_HASH, params_hash)

        # PII scan summary (details NOT on span to avoid leaking PII)
        _record_pii_summary(span, pii_input_result, pii_output_result)

    except Exception as exc:
        logger.warning("MCP audit attribute recording failed: %s", exc)


def _record_pii_summary(
    span,
    pii_input_result: dict | None,
    pii_output_result: dict | None,
) -> None:
    """Record PII scan summary attributes on the span.

    Internal helper for :func:`record_audit_attributes`.
    """
    from ..tracing.attributes import MCPAttributes

    input_detected = pii_input_result and pii_input_result.get("detected", False)
    output_detected = pii_output_result and pii_output_result.get("detected", False)

    if not input_detected and not output_detected:
        return

    span.set_attribute(MCPAttributes.PII_DETECTED, True)

    # Total PII count across input and output
    input_count = pii_input_result.get("count", 0) if pii_input_result else 0
    output_count = pii_output_result.get("count", 0) if pii_output_result else 0
    span.set_attribute(MCPAttributes.PII_COUNT, input_count + output_count)

    # Scan direction
    if input_detected and output_detected:
        direction = "both"
    elif input_detected:
        direction = "inputs"
    else:
        direction = "outputs"
    span.set_attribute(MCPAttributes.PII_SCAN_DIRECTION, direction)

    # Highest severity action taken across all findings
    all_findings = []
    if pii_input_result:
        all_findings.extend(pii_input_result.get("findings", []))
    if pii_output_result:
        all_findings.extend(pii_output_result.get("findings", []))

    if all_findings:
        highest_action = max(
            (f.get("action", "warn") for f in all_findings),
            key=lambda a: _ACTION_SEVERITY.get(a, 0),
        )
        span.set_attribute(MCPAttributes.PII_ACTION_TAKEN, highest_action)


# ---------------------------------------------------------------------------
# Synthetic Error Result
# ---------------------------------------------------------------------------


def build_synthetic_error_result(reason: str):
    """Build a synthetic CallToolResult for blocked calls (return-error-result mode).

    Args:
        reason: Human-readable block reason.

    Returns:
        ``CallToolResult`` with ``isError=True`` if ``mcp`` package is available,
        otherwise ``None`` (caller should fall back to raising ``PolicyViolationError``).
    """
    try:
        from mcp.types import CallToolResult, TextContent

        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"Tool call blocked by policy: {reason}",
                )
            ],
            isError=True,
        )
    except ImportError:
        return None
    except Exception as exc:
        logger.warning("Failed to build synthetic CallToolResult: %s", exc)
        return None
