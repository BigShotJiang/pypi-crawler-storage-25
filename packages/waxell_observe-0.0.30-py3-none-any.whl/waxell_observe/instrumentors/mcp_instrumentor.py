"""MCP (Model Context Protocol) auto-instrumentor for waxell-observe.

Monkey-patches ``mcp.client.session.ClientSession.call_tool`` to emit
OTel tool spans with proper naming, attributes, error classification,
timeout handling, and structured logging.

MCP tool call pattern:
  - ``session.call_tool(name="tool_name", arguments={...})``
  - Returns ``CallToolResult`` with ``content`` list and ``isError`` flag

Span naming follows the locked convention:
  ``tools/call {server}:{tool}`` when server_name is known,
  ``tools/call {tool}`` otherwise.

Each call_tool invocation produces exactly ONE OTel span. The old
dual-recording bug (span + context recording) is eliminated.

All wrapper code is wrapped in try/except -- never breaks the user's code.

Phase 2 adds conditional governance: policy enforcement, approval workflows,
PII scanning, and audit trail. Governance activates only when
configure_session() sets governance_config on the session.

Phase 3 adds security: server identity tracking, tool definition
fingerprinting, and rug pull detection. On the first tool call per session,
tool definitions are captured via list_tools(), hashed, and compared against
a process-global baseline. Description/schema changes trigger alerts with
diffs, log warnings, and an optional on_description_change callback.
Server version changes between sessions are flagged. All security code is
fail-open: errors in the security layer never block tool calls.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger("waxell")

# ---------------------------------------------------------------------------
# Module-level configuration
# ---------------------------------------------------------------------------

_DEFAULT_TIMEOUT_S: float = 30.0

_mcp_config: dict = {
    "timeout": _DEFAULT_TIMEOUT_S,
    "capture_content": True,
}

_TRUNCATE_AT: int = 4096  # 4KB per locked decision


# ---------------------------------------------------------------------------
# MCPInstrumentor
# ---------------------------------------------------------------------------


class MCPInstrumentor(BaseInstrumentor):
    """Instrumentor for MCP client (``mcp`` package).

    Patches ``ClientSession.call_tool`` to trace MCP tool calls with
    proper OTel spans, error classification, configurable timeout, and
    structured logging.
    """

    _instrumented: bool = False

    def instrument(self, config: dict | None = None) -> bool:
        """Apply monkey-patch to ``ClientSession.call_tool``.

        Args:
            config: Optional global MCP settings. Supported keys:
                - ``timeout`` (float): Default timeout in seconds.
                - ``capture_content`` (bool): Whether to capture I/O content.

        Returns:
            True if instrumentation was applied successfully.
        """
        if self._instrumented:
            return True

        try:
            import mcp.client.session  # noqa: F401
        except ImportError:
            logger.debug("mcp package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt  # noqa: F401
        except ImportError:
            logger.debug("wrapt not installed -- skipping MCP instrumentation")
            return False

        # Apply global config if provided
        if config:
            configure_global(
                **{
                    k: v
                    for k, v in config.items()
                    if k in ("timeout", "capture_content")
                }
            )

        try:
            wrapt.wrap_function_wrapper(
                "mcp.client.session",
                "ClientSession.call_tool",
                _call_tool_wrapper,
            )
        except Exception as exc:
            logger.warning("Failed to patch ClientSession.call_tool: %s", exc)
            return False

        self._instrumented = True
        logger.debug("MCP ClientSession.call_tool instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import mcp.client.session as mod

            if hasattr(mod.ClientSession.call_tool, "__wrapped__"):
                mod.ClientSession.call_tool = mod.ClientSession.call_tool.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("MCP ClientSession.call_tool uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Per-session and global configuration
# ---------------------------------------------------------------------------


def configure_session(
    session,
    server_name: str = "",
    timeout: float | None = None,
    on_policy_block=None,
    governance_config: dict | None = None,
    # Phase 3 additions:
    on_description_change=None,
    fingerprint_config: dict | None = None,
) -> None:
    """Configure per-session MCP governance and security settings.

    Sets attributes on the ClientSession instance that the wrapper reads.
    Must be called AFTER ``session.initialize()`` and BEFORE making tool calls.

    Args:
        session: A ``mcp.client.session.ClientSession`` instance.
        server_name: Human-readable name for the MCP server (e.g., "composio").
            Used in span names and policy IDs.
        timeout: Per-session timeout in seconds. Overrides global default.
        on_policy_block: Per-session policy block handler (Phase 2).
        governance_config: Per-session governance settings dict (Phase 2).
        on_description_change: Callback invoked when tool description/schema
            changes are detected (Phase 3). Receives a
            ``DescriptionChangeEvent``, may return ``ChangeDecision``. Can be
            sync or async.
        fingerprint_config: Per-server fingerprint settings dict (Phase 3).
            Keys: ``enabled`` (bool, default True), ``action`` (str, default
            "warn" -- "warn" or "block"), ``per_tool_actions``
            (dict[str, str] -- override action per tool name),
            ``acknowledged_hashes`` (dict[str, str] -- pre-acknowledged
            hashes keyed by ``{server_name}:{tool_name}``).
    """
    if server_name:
        session._waxell_server_name = server_name
    if timeout is not None:
        session._waxell_timeout = timeout
    if on_policy_block is not None:
        session._waxell_on_policy_block = on_policy_block
    if governance_config is not None:
        session._waxell_governance = governance_config
    if on_description_change is not None:
        session._waxell_on_description_change = on_description_change
    if fingerprint_config is not None:
        session._waxell_fingerprint_config = fingerprint_config


def configure_global(
    timeout: float = _DEFAULT_TIMEOUT_S,
    capture_content: bool = True,
) -> None:
    """Configure global MCP instrumentation settings.

    Args:
        timeout: Default timeout in seconds for MCP tool calls.
        capture_content: Whether to capture tool arguments and results on spans.
    """
    _mcp_config["timeout"] = timeout
    _mcp_config["capture_content"] = capture_content


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _record_mcp_error(span, error_type: str, description: str) -> None:
    """Record an MCP-specific error on a span with typed error classification."""
    try:
        from ..tracing.attributes import MCPAttributes

        span.set_attribute(MCPAttributes.ERROR_TYPE, error_type)
        span.set_attribute(MCPAttributes.IS_ERROR, True)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, description[:500])
    except Exception:
        pass


def _detect_transport(session) -> str:
    """Best-effort detection of MCP transport type from session internals."""
    try:
        read_stream = getattr(session, "_read_stream", None)
        if read_stream is not None:
            cls_name = (
                type(read_stream).__module__ + "." + type(read_stream).__qualname__
            )
            if "stdio" in cls_name.lower():
                return "stdio"
            if "sse" in cls_name.lower():
                return "sse"
            if "http" in cls_name.lower() or "streamable" in cls_name.lower():
                return "http"
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# Wrapper function
# ---------------------------------------------------------------------------


async def _call_tool_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``ClientSession.call_tool``.

    Produces exactly one OTel span per call with:
    - Span name: ``tools/call {server}:{tool}``
    - Error classification: transport_error, server_error, timeout, tool_execution_error
    - Configurable timeout via ``asyncio.wait_for``
    - INFO-level structured logging per call
    - DEBUG-level full I/O logging

    All instrumentation code is wrapped in try/except. If ANY
    instrumentation code fails, the original ``wrapped(*args, **kwargs)``
    is called unmodified.
    """
    # ------------------------------------------------------------------
    # 1. Extract tool name and arguments from args/kwargs
    # ------------------------------------------------------------------
    tool_name = "unknown"
    arguments = {}
    if args:
        tool_name = str(args[0]) if args else "unknown"
        if len(args) > 1:
            arguments = args[1] if isinstance(args[1], dict) else {}
    tool_name = kwargs.get("name", tool_name)
    arguments = kwargs.get("arguments", arguments)

    # ------------------------------------------------------------------
    # 2. Try to import span helper; fall through on failure
    # ------------------------------------------------------------------
    try:
        from ..tracing.spans import start_mcp_tool_span
        from ..tracing.attributes import MCPAttributes
    except Exception:
        return await wrapped(*args, **kwargs)

    # ------------------------------------------------------------------
    # 3. Extract server name from ClientSession instance
    # ------------------------------------------------------------------
    server_name = ""
    try:
        if hasattr(instance, "_server_info") and instance._server_info:
            server_name = getattr(instance._server_info, "name", "") or ""
        if not server_name:
            server_name = getattr(instance, "_waxell_server_name", "")
    except Exception:
        pass

    # ------------------------------------------------------------------
    # 3a. Extract full server metadata (Phase 3: SEC-01)
    # ------------------------------------------------------------------
    server_version = ""
    server_identity = None
    try:
        from .mcp_security import extract_server_identity

        server_identity = extract_server_identity(instance)
        server_version = server_identity.version
    except Exception:
        pass

    # ------------------------------------------------------------------
    # 4. Extract session_id and transport
    # ------------------------------------------------------------------
    session_id = ""
    transport = ""
    try:
        session_id = str(id(instance))
        if hasattr(instance, "_read_stream"):
            transport = _detect_transport(instance)
    except Exception:
        pass

    # ------------------------------------------------------------------
    # 5. Create MCP span (relies on OTel automatic context propagation)
    # ------------------------------------------------------------------
    try:
        span = start_mcp_tool_span(
            tool_name=tool_name,
            server_name=server_name,
            method="tools/call",
            session_id=session_id,
            transport=transport,
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    # ------------------------------------------------------------------
    # 5a. Set server identity attributes on span (Phase 3: SEC-01)
    # ------------------------------------------------------------------
    try:
        if server_version:
            span.set_attribute(MCPAttributes.SERVER_VERSION, server_version)
        # Check for server version change between sessions
        if server_name and server_version:
            from .mcp_security import check_server_version_change

            version_changed, old_version = check_server_version_change(
                server_name, server_version
            )
            if version_changed:
                span.set_attribute(MCPAttributes.SERVER_VERSION_CHANGED, True)
                logger.warning(
                    "MCP server version changed: %s %s -> %s",
                    server_name,
                    old_version,
                    server_version,
                )
    except Exception:
        pass

    # ------------------------------------------------------------------
    # 5b. First-call fingerprint capture (Phase 3: SEC-02, SEC-03)
    # ------------------------------------------------------------------
    _security_blocked = False
    try:
        _fingerprinted = getattr(instance, "_waxell_fingerprinted", False)
        if not _fingerprinted:
            # Set flag BEFORE calling list_tools() to prevent race condition
            # (concurrent calls see flag and skip; at worst list_tools called twice)
            instance._waxell_fingerprinted = True

            fingerprint_config = getattr(instance, "_waxell_fingerprint_config", None)
            _sec_governance_config = getattr(instance, "_waxell_governance", None)

            from .mcp_security import capture_fingerprints, handle_tool_changes

            changes = await capture_fingerprints(
                instance, server_name, fingerprint_config
            )

            # Record fingerprint metadata on span
            tool_count = getattr(instance, "_waxell_tool_count", 0)
            if tool_count:
                span.set_attribute(MCPAttributes.FINGERPRINT_TOOL_COUNT, tool_count)

            if changes:
                span.set_attribute(
                    MCPAttributes.FINGERPRINT_CHANGES_DETECTED, len(changes)
                )
                _security_blocked = await handle_tool_changes(
                    changes,
                    instance,
                    _sec_governance_config,
                    span,
                    fingerprint_config,
                )
            else:
                # First observation or all matching
                fp_status = getattr(
                    instance,
                    "_waxell_fingerprint_status",
                    "first_observation",
                )
                span.set_attribute(MCPAttributes.FINGERPRINT_STATUS, fp_status)

            # Emit session-level info span with full server metadata
            # Only if fingerprint capture actually ran (tool_count > 0)
            try:
                if tool_count and (server_name or server_version):
                    from ..tracing._compat import get_tracer
                    import json as _json

                    tracer = get_tracer()
                    session_span = tracer.start_span(
                        name=f"mcp_session_info {server_name or 'unknown'}",
                        attributes={
                            MCPAttributes.SERVER_NAME: server_name,
                            MCPAttributes.SERVER_VERSION: server_version,
                            MCPAttributes.TRANSPORT: transport,
                        },
                    )
                    # Add full identity details
                    if server_identity:
                        if server_identity.capabilities:
                            session_span.set_attribute(
                                MCPAttributes.SERVER_CAPABILITIES,
                                _json.dumps(server_identity.capabilities, default=str),
                            )
                        if server_identity.connection_info:
                            session_span.set_attribute(
                                MCPAttributes.SERVER_CONNECTION,
                                server_identity.connection_info,
                            )
                    session_span.end()
            except Exception:
                pass

    except Exception as exc:
        logger.debug(
            "MCP security fingerprint capture failed: %s -- continuing (fail-open)",
            exc,
        )
        _security_blocked = False

    # If security blocked the call (rug pull detected with block action)
    if _security_blocked:
        try:
            span.set_attribute(MCPAttributes.FINGERPRINT_STATUS, "blocked")
            from opentelemetry.trace import StatusCode

            span.set_status(
                StatusCode.ERROR,
                "Blocked: tool description change detected (rug pull)",
            )
        except Exception:
            pass
        try:
            span.end()
        except Exception:
            pass
        from ..errors import PolicyViolationError

        raise PolicyViolationError(
            "Tool description change detected (potential rug pull attack)", None
        )

    # ------------------------------------------------------------------
    # 6. Set input attributes on span
    # ------------------------------------------------------------------
    try:
        if arguments:
            args_str = json.dumps(arguments, default=str)[:_TRUNCATE_AT]
            span.set_attribute(MCPAttributes.ARGUMENTS, args_str)
    except Exception:
        pass

    # ------------------------------------------------------------------
    # 6a. Check governance config (fast path when not configured)
    # ------------------------------------------------------------------
    governance_config = None
    _governance_blocked = False
    _governance_synthetic_result = None
    _pii_input_result = None
    _pii_output_result = None
    _policy_result = None
    _throttle_delay = 0.0
    try:
        governance_config = getattr(instance, "_waxell_governance", None)
    except Exception:
        pass

    if governance_config:
        # --------------------------------------------------------------
        # 6b. Policy check
        # --------------------------------------------------------------
        try:
            from .mcp_governance import do_policy_check
            from ..client import WaxellObserveClient

            policy_id = (
                f"mcp:{server_name}:{tool_name}" if server_name else f"mcp::{tool_name}"
            )
            span.set_attribute(MCPAttributes.POLICY_ID, policy_id)

            client = WaxellObserveClient()
            if not client.config.is_configured:
                logger.warning(
                    "Waxell client not configured -- skipping MCP policy check"
                )
                span.set_attribute(MCPAttributes.POLICY_SKIPPED, True)
                _policy_result = None
            else:
                _policy_result = await do_policy_check(
                    client, policy_id, governance_config, span
                )
        except Exception as exc:
            logger.warning(
                "MCP governance policy check setup failed: %s -- allowing (fail-open)",
                exc,
            )
            try:
                span.set_attribute(MCPAttributes.POLICY_SKIPPED, True)
            except Exception:
                pass

        # --------------------------------------------------------------
        # 6c. Handle policy result (allow/block/warn/throttle)
        # --------------------------------------------------------------
        if _policy_result is not None:
            try:
                if _policy_result.action == "block":
                    # Check for approval handler
                    handler = getattr(instance, "_waxell_on_policy_block", None)
                    if handler is not None:
                        from ..errors import PolicyViolationError
                        from ..approval import handle_policy_block

                        error = PolicyViolationError(
                            _policy_result.reason, _policy_result
                        )
                        decision = await handle_policy_block(handler, error)
                        if decision.approved:
                            span.set_attribute(
                                MCPAttributes.APPROVAL_STATUS, "approved"
                            )
                            if decision.approver:
                                span.set_attribute(
                                    MCPAttributes.APPROVAL_APPROVER,
                                    decision.approver,
                                )
                            if decision.elapsed_seconds is not None:
                                span.set_attribute(
                                    MCPAttributes.APPROVAL_ELAPSED_MS,
                                    int(decision.elapsed_seconds * 1000),
                                )
                        else:
                            _governance_blocked = True
                            status_str = "timeout" if decision.timed_out else "denied"
                            span.set_attribute(
                                MCPAttributes.APPROVAL_STATUS, status_str
                            )
                            if decision.elapsed_seconds is not None:
                                span.set_attribute(
                                    MCPAttributes.APPROVAL_ELAPSED_MS,
                                    int(decision.elapsed_seconds * 1000),
                                )
                    else:
                        _governance_blocked = True
                        span.set_attribute(
                            MCPAttributes.APPROVAL_STATUS, "not_required"
                        )

                    if _governance_blocked:
                        block_mode = governance_config.get("block_mode", "raise")
                        from opentelemetry.trace import StatusCode

                        span.set_status(
                            StatusCode.ERROR,
                            f"Blocked by policy: {_policy_result.reason}",
                        )
                        span.set_attribute(MCPAttributes.GOVERNANCE_ACTION, "block")

                        if block_mode == "error_result":
                            from .mcp_governance import build_synthetic_error_result

                            _governance_synthetic_result = build_synthetic_error_result(
                                _policy_result.reason
                            )
                            if _governance_synthetic_result is not None:
                                span.set_attribute(
                                    MCPAttributes.BLOCKED_SYNTHETIC, True
                                )

                elif _policy_result.action == "warn":
                    logger.warning(
                        "MCP governance warning for %s:%s -- %s",
                        server_name or "unknown",
                        tool_name,
                        _policy_result.reason,
                    )
                    span.set_attribute(MCPAttributes.APPROVAL_STATUS, "not_required")

                elif _policy_result.action == "throttle":
                    from .mcp_governance import apply_throttle

                    _throttle_delay = await apply_throttle(_policy_result, span)
                    span.set_attribute(MCPAttributes.APPROVAL_STATUS, "not_required")

                else:
                    # "allow" or any other action
                    span.set_attribute(MCPAttributes.APPROVAL_STATUS, "not_required")

            except Exception as exc:
                logger.warning(
                    "MCP governance action handling failed: %s -- allowing (fail-open)",
                    exc,
                )
                _governance_blocked = False
                _governance_synthetic_result = None

        # --------------------------------------------------------------
        # 6d. PII scan on inputs
        # --------------------------------------------------------------
        if not _governance_blocked:
            try:
                scan_inputs = governance_config.get("scan_inputs", True)
                if scan_inputs and arguments:
                    from .mcp_governance import scan_text_for_pii

                    scanner = governance_config.get("pii_scanner", None)
                    pii_actions = governance_config.get("pii_actions", None)
                    if scanner is None and pii_actions:
                        from .mcp_governance import RegexPIIScanner

                        scanner = RegexPIIScanner(actions=pii_actions)
                    args_text = json.dumps(arguments, default=str)
                    _pii_input_result = scan_text_for_pii(args_text, scanner=scanner)
                    if _pii_input_result.get("detected"):
                        block_findings = [
                            f
                            for f in _pii_input_result.get("findings", [])
                            if f.get("action") == "block"
                        ]
                        if block_findings:
                            _governance_blocked = True
                            span.set_attribute(MCPAttributes.PII_ACTION_TAKEN, "block")
                            from opentelemetry.trace import StatusCode

                            span.set_status(
                                StatusCode.ERROR,
                                "Blocked: PII detected in tool inputs",
                            )
            except Exception as exc:
                logger.warning(
                    "MCP PII input scan failed: %s -- allowing (fail-open)", exc
                )

        # --------------------------------------------------------------
        # 6e. Governance exit: if blocked, record audit and return/raise
        # --------------------------------------------------------------
        if _governance_blocked:
            try:
                from .mcp_governance import record_audit_attributes

                record_audit_attributes(
                    span,
                    governance_config,
                    _policy_result,
                    tool_name,
                    server_name,
                    arguments,
                    pii_input_result=_pii_input_result,
                )
            except Exception:
                pass
            # End span before early exit (not inside the section 8 try/finally)
            try:
                span.end()
            except Exception:
                pass
            if _governance_synthetic_result is not None:
                return _governance_synthetic_result
            from ..errors import PolicyViolationError

            reason = (
                _policy_result.reason if _policy_result else "Blocked by governance"
            )
            raise PolicyViolationError(reason, _policy_result)

    # ------------------------------------------------------------------
    # 7. Resolve timeout (per-session override > global config > default)
    # ------------------------------------------------------------------
    timeout = _mcp_config.get("timeout", _DEFAULT_TIMEOUT_S)
    try:
        session_timeout = getattr(instance, "_waxell_timeout", None)
        if session_timeout is not None:
            timeout = session_timeout
    except Exception:
        pass

    try:
        span.set_attribute(MCPAttributes.TIMEOUT_MS, int(timeout * 1000))
    except Exception:
        pass

    # Adjust timeout for throttle delay (ensure at least 1s remaining)
    if _throttle_delay > 0:
        timeout = max(timeout - _throttle_delay, 1.0)

    # ------------------------------------------------------------------
    # 8. Execute with timeout and error classification
    # ------------------------------------------------------------------
    start_time = time.monotonic()
    try:
        try:
            result = await asyncio.wait_for(wrapped(*args, **kwargs), timeout=timeout)
        except asyncio.TimeoutError:
            duration_ms = (time.monotonic() - start_time) * 1000
            _record_mcp_error(
                span,
                "timeout",
                f"MCP call_tool timed out after {timeout}s",
            )
            logger.info(
                "MCP tool %s:%s TIMEOUT (%.0fms, server=%s)",
                server_name or "unknown",
                tool_name,
                duration_ms,
                server_name,
            )
            if governance_config:
                try:
                    from .mcp_governance import record_audit_attributes

                    record_audit_attributes(
                        span,
                        governance_config,
                        _policy_result,
                        tool_name,
                        server_name,
                        arguments,
                        pii_input_result=_pii_input_result,
                    )
                except Exception:
                    pass
            raise
        except ConnectionError as exc:
            duration_ms = (time.monotonic() - start_time) * 1000
            _record_mcp_error(span, "transport_error", str(exc))
            logger.info(
                "MCP tool %s:%s TRANSPORT_ERROR (%.0fms, server=%s): %s",
                server_name or "unknown",
                tool_name,
                duration_ms,
                server_name,
                exc,
            )
            if governance_config:
                try:
                    from .mcp_governance import record_audit_attributes

                    record_audit_attributes(
                        span,
                        governance_config,
                        _policy_result,
                        tool_name,
                        server_name,
                        arguments,
                        pii_input_result=_pii_input_result,
                    )
                except Exception:
                    pass
            raise
        except Exception as exc:
            duration_ms = (time.monotonic() - start_time) * 1000
            _record_mcp_error(span, "server_error", str(exc))
            logger.info(
                "MCP tool %s:%s SERVER_ERROR (%.0fms, server=%s): %s",
                server_name or "unknown",
                tool_name,
                duration_ms,
                server_name,
                exc,
            )
            if governance_config:
                try:
                    from .mcp_governance import record_audit_attributes

                    record_audit_attributes(
                        span,
                        governance_config,
                        _policy_result,
                        tool_name,
                        server_name,
                        arguments,
                        pii_input_result=_pii_input_result,
                    )
                except Exception:
                    pass
            raise

        # ------------------------------------------------------------------
        # 9. Record result attributes (success path)
        # ------------------------------------------------------------------
        duration_ms = (time.monotonic() - start_time) * 1000
        result_text = (
            ""  # initialized here so 9a/9b can access it even if section 9 fails
        )

        try:
            is_error = getattr(result, "isError", False)
            content = getattr(result, "content", [])

            span.set_attribute(MCPAttributes.IS_ERROR, bool(is_error))
            span.set_attribute(MCPAttributes.CONTENT_COUNT, len(content))

            # Capture result content (truncated)
            result_text = ""
            for item in content:
                text = getattr(item, "text", None)
                if text:
                    result_text = str(text)[:_TRUNCATE_AT]
                    break
            if result_text:
                span.set_attribute(MCPAttributes.RESULT, result_text)

            if is_error:
                _record_mcp_error(
                    span,
                    "tool_execution_error",
                    result_text or "Tool returned isError=True",
                )
                logger.info(
                    "MCP tool %s:%s TOOL_ERROR (%.0fms, server=%s)",
                    server_name or "unknown",
                    tool_name,
                    duration_ms,
                    server_name,
                )
            else:
                try:
                    from opentelemetry.trace import StatusCode

                    span.set_status(StatusCode.OK)
                except Exception:
                    pass
                logger.info(
                    "MCP tool %s:%s OK (%.0fms, server=%s)",
                    server_name or "unknown",
                    tool_name,
                    duration_ms,
                    server_name,
                )

            # DEBUG level: full I/O
            logger.debug(
                "MCP tool %s:%s I/O -- args=%s result=%s",
                server_name or "unknown",
                tool_name,
                json.dumps(arguments, default=str)[:_TRUNCATE_AT]
                if arguments
                else "{}",
                result_text[:500],
            )
        except Exception:
            # Instrumentation failure on result recording -- still return result
            pass

        # ------------------------------------------------------------------
        # 9a. PII scan on outputs (governance)
        # ------------------------------------------------------------------
        if governance_config and not _governance_blocked:
            try:
                scan_outputs = governance_config.get("scan_outputs", True)
                if scan_outputs and result_text:
                    from .mcp_governance import scan_text_for_pii

                    scanner = governance_config.get("pii_scanner", None)
                    pii_actions = governance_config.get("pii_actions", None)
                    if scanner is None and pii_actions:
                        from .mcp_governance import RegexPIIScanner

                        scanner = RegexPIIScanner(actions=pii_actions)
                    _pii_output_result = scan_text_for_pii(result_text, scanner=scanner)
                    if _pii_output_result and _pii_output_result.get("detected"):
                        block_findings = [
                            f
                            for f in _pii_output_result.get("findings", [])
                            if f.get("action") == "block"
                        ]
                        if block_findings:
                            logger.warning(
                                "MCP PII blocking-level finding in output of %s:%s"
                                " (tool already executed)",
                                server_name or "unknown",
                                tool_name,
                            )
            except Exception as exc:
                logger.warning("MCP PII output scan failed: %s", exc)

        # ------------------------------------------------------------------
        # 9b. Record governance audit trail
        # ------------------------------------------------------------------
        if governance_config:
            try:
                from .mcp_governance import record_audit_attributes

                record_audit_attributes(
                    span,
                    governance_config,
                    _policy_result,
                    tool_name,
                    server_name,
                    arguments,
                    pii_input_result=_pii_input_result,
                    pii_output_result=_pii_output_result,
                )
            except Exception as exc:
                logger.warning("MCP governance audit recording failed: %s", exc)

        return result
    finally:
        # Always end the span (better incomplete span than no span)
        try:
            span.end()
        except Exception:
            pass
