# Changelog

## 1.8.0 (2026-05-01)

### Layer 13 (Connector + Marketplace) — graduate to stable

**Layer 13 is now stable.** `ConnectorManager`, `FederationProtocol`, `MarketplacePublisher`, and `MarketplaceDiscovery` now use `@stable(since="1.8.0")` — no more preview warnings on import.

### Fixed — access control across the layer (P0)

Non-creators could drive connectors through their full lifecycle and attach traffic policies; non-publishers could yank marketplace listings; private listings could be installed by anyone with the listing ID. Every state-changing API now enforces ownership:

- `ConnectorManager._transition()` (covers submit/approve/reject/suspend/reactivate/revoke) and `add_policy()` require `actor_id == connector.created_by`.
- `MarketplacePublisher.update_version`, `deprecate`, `remove`, `update_visibility` require `actor_id == listing.publisher_id`.
- `MarketplaceDiscovery.install()` honors visibility — `PRIVATE` listings are publisher-only; `PUBLIC` and `UNLISTED` install for anyone with the listing ID.
- Publishers can no longer review their own listing.

### Fixed — actor_id no longer recorded as connector_id

`ConnectorManager.record_traffic()` and `sync_object()` previously wrote audit entries with `actor_id=connector_id`. They now require an explicit `actor_id` from the caller and place the connector ID in audit metadata.

### Fixed — audit gaps (Invariant #4)

Six previously silent operations now emit audit entries: `add_policy`, `update_version`, `deprecate`, `remove`, `update_visibility`, `add_review`. New `ActionType` values:

- `CONNECTOR_SUBMIT`, `CONNECTOR_SUSPEND`, `CONNECTOR_REJECT`, `CONNECTOR_POLICY_ADD`
- `MARKETPLACE_VERSION_UPDATE`, `MARKETPLACE_DEPRECATE`, `MARKETPLACE_REMOVE`, `MARKETPLACE_VISIBILITY_CHANGE`, `MARKETPLACE_REVIEW`

Connector state transitions no longer collapse under shared actions (`submit_for_approval`/`reject` had been reusing `CONNECTOR_PROPOSE`/`CONNECTOR_REVOKE`). `marketplace_install` audit now targets the install record, not the listing — installs are individually addressable.

### Fixed — secret-leakage block was fragile

`check_policy()` used `object_type.lower() == "secret"` only, which let `SecretRef`, `credential`, `api_key`, `private_key`, `password`, and similar variants flow through the connector. The block is now a frozenset of secret-like type names matched case-insensitively.

### Added — FederationProtocol replay protection (m0016)

`FederationProtocol` previously kept its sender sequence in process memory and never checked sequence numbers on the receiver. Replays of captured valid messages were undetectable.

- New tables `federation_sequences` (per-connector sender counter) and `federation_seen_messages` (receiver ledger keyed by `(connector_id, sender_org_id, sequence)`) added by migration `m0016`.
- `FederationProtocol(shared_key, backend=...)` persists the sender counter across restarts and rejects replays at the database level.
- New `accept_message()` is the recommended receiver entry point: signature verification + replay check in one call. `mark_seen()` is the standalone replay step.
- In-memory fallback when no backend is wired keeps tests simple.
- `negotiate_schema()` now compares major version semver-style — `"1.0"` ↔ `"1.0.0"` no longer false-flags as a mismatch.

### Fixed — exception leakage (P1)

- Duplicate `MarketplacePublisher.add_review()` (same reviewer + listing) raises a clean `MarketplaceError("Reviewer ... already reviewed listing ...")` instead of leaking `sqlalchemy.exc.IntegrityError`.
- `update_version()` validates new versions: must be valid semver, strictly greater than the current version, and the listing must be `ACTIVE`. Downgrades, equal-version bumps, non-semver strings, and version-bumps on deprecated/archived listings raise `MarketplaceError`.

### Added — module-level namespaces: `scoped.connectors`, `scoped.marketplace`

Two new namespaces with the usual context-aware defaults (acting principal inferred from `ScopedContext`):

- `scoped.connectors.propose(...)`, `.submit(c)`, `.approve(c)`, `.reject(c)`, `.suspend(c)`, `.reactivate(c)`, `.revoke(c)`, `.add_policy(c, ...)`, `.policies(c)`, `.check_policy(c, type)`, `.sync(c, ...)`, `.traffic(c)`, `.federation(shared_key)`, `.get(id)`, `.list(...)`
- `scoped.marketplace.publish(...)`, `.update_version(l, ...)`, `.deprecate(l)`, `.remove(l)`, `.update_visibility(l, ...)`, `.review(l, rating=...)`, `.reviews(l)`, `.average_rating(l)`, `.browse(...)`, `.search(query, ...)`, `.by_publisher(p)`, `.install(l)`, `.installs(l)`, `.my_installs()`, `.get(id)`

`client.connectors`, `client.marketplace` are exposed on `ScopedClient` directly. `services.connectors`, `services.marketplace_publisher`, `services.marketplace_discovery`, and the factory `services.federation_protocol(shared_key)` are wired into `ScopedServices`.

### Added — rule-engine deny hooks

`ConnectorManager`, `MarketplacePublisher`, and `MarketplaceDiscovery` now accept an optional `rule_engine=...` (auto-injected by `ScopedServices`) and evaluate Layer 5 rules before key operations. DENY rules raise `AccessDeniedError`:

- `connector_propose` (object_type=`connector`)
- `connector_submit`, `connector_approve`, `connector_reject`, `connector_suspend`, `connector_revoke` (object_id=connector)
- `connector_sync` (object_id=connector, scope_id=connector.local_scope_id)
- `marketplace_publish` (object_type=`marketplace_listing`)
- `marketplace_install` (object_id=listing)

Default-permit when no rules are bound, mirroring the Layer 9 pattern.

## 1.7.0 (2026-04-30)

### Layer 12 (Integrations) — graduate to stable

**Layer 12 is now stable.** `PluginLifecycleManager`, `IntegrationManager`, `HookRegistry`, and `PluginSandbox` now use `@stable(since="1.7.0")` — no more warnings on import.

### Fixed — access control across the layer (P0)

Non-owners could mutate plugins, integrations, hooks, and permissions. Every state-changing API now enforces ownership:

- `PluginLifecycleManager._transition()` (called by `activate`/`suspend`/`uninstall`) raises `AccessDeniedError` when `actor_id != plugin.owner_id`.
- `PluginLifecycleManager.grant_permission()` requires `granted_by == plugin.owner_id`. `revoke_permission()` now takes a required `actor_id` (and raises `PluginError` on missing permissions).
- `HookRegistry.register_hook()` and `deactivate_hook()` now take a required `actor_id` and enforce ownership.
- `IntegrationManager.update_config()` and `archive_integration()` now enforce `actor_id == integration.owner_id`. `archive_integration()` raises `IntegrationError` on missing integration instead of silently no-opping.

### Fixed — audit gaps (P0, Invariant #4)

Permission grant/revoke and hook register/deactivate were silent. They now emit audit entries via four new `ActionType` values:

- `PLUGIN_PERMISSION_GRANT`, `PLUGIN_PERMISSION_REVOKE`, `HOOK_REGISTER`, `HOOK_DEACTIVATE`.

### Fixed — sandbox is no longer a paper tiger

`PluginSandbox` was defined but never invoked. `HookRegistry.dispatch()` now calls `sandbox.require_active(plugin_id)` before each handler — suspended/uninstalled plugins are skipped through the explicit boundary instead of an inline state check.

`HookRegistry(backend, enforce_hook_permissions=True)` opt-in flag adds a `sandbox.check_hook_access()` gate so plugins can only fire hooks for which they hold a `permission_type="hook"` grant.

### Fixed — exception leakage

- Duplicate `install_plugin(name=...)` raises a clean `PluginError("Plugin name '...' is already in use")` instead of leaking `sqlalchemy.exc.IntegrityError`.

### Added — module-level namespaces: `scoped.plugins`, `scoped.integrations`, `scoped.hooks`

Three new namespaces with the usual context-aware defaults (acting principal inferred from `ScopedContext`):

- `scoped.plugins.install(...)`, `.activate(p)`, `.suspend(p)`, `.uninstall(p)`, `.grant_permission(p, ...)`, `.revoke_permission(perm_id)`, `.permissions(p)`, `.has_permission(p, ...)`, `.get(id)`, `.get_by_name(name)`, `.list(...)`
- `scoped.integrations.create(...)`, `.update_config(i, config)`, `.archive(i)`, `.get(id)`, `.list(...)`
- `scoped.hooks.register_handler(ref, fn)`, `.register(p, hook_point=..., handler_ref=...)`, `.deactivate(hook_id)`, `.for_plugin(p)`, `.for_point(point)`, `.dispatch(point, context=...)`, `.dispatch_or_raise(point)`

`client.plugins`, `client.integrations`, `client.hooks` are exposed on `ScopedClient` directly, and `services.integrations`, `services.hooks`, `services.plugin_sandbox` are wired into `ScopedServices` (the existing `services.plugins` was the only piece previously wired).

### Added — rule-engine deny hooks

`PluginLifecycleManager`, `IntegrationManager`, and `HookRegistry` now accept an optional `rule_engine=...` (auto-injected by `ScopedServices`) and evaluate Layer 5 rules before key operations. DENY rules raise `AccessDeniedError`:

- `plugin_install` (object_type=`plugin`, scope_id=plugin scope)
- `plugin_activate`, `plugin_suspend`, `plugin_uninstall` (object_id=plugin)
- `integration_connect` (object_type=`integration`, scope_id=integration scope)
- `hook_dispatch` (object_type=`hook`, object_id=hook point)

Default-permit when no rules are bound, mirroring the Layer 9 pattern.

## 1.6.0 (2026-04-29)

### Layer 11 (Secrets) — graduate to stable

**Layer 11 is now stable.** `SecretVault` and `SecretPolicyManager` now use `@stable(since="1.6.0")`, and the default service wiring attaches secret policies to the vault automatically.

### Fixed — vault lifecycle, policy, and API hardening

- `SecretVault.create_secret()` now requires a real `object_manager` so `secrets.object_id` always points at a valid backing scoped object instead of silently fabricating an invalid foreign key.
- Secret classification values are now validated before write-time side effects in both vault and policy APIs.
- Archived and expired secrets can no longer be rotated or granted new refs.
- Secret policies are now enforced during ref grant and resolve, not just exposed as a separate helper API.
- `SecretPolicyManager.create_policy()` now validates its target, classification, max age, and scope/environment restriction lists before persisting malformed policies.

### Changed

- `ScopedServices.secrets` now wires `SecretPolicyManager` into `SecretVault` by default, so namespace and client users get policy-aware enforcement without manual construction.

## 1.5.0 (2026-04-29)

### Layer 10 (Deployments) — graduate to stable

**Layer 10 is now stable.** The `@experimental` decorators on `DeploymentExecutor`, `GateChecker`, and `DeploymentRollbackManager` have been replaced with `@stable(since="1.5.0")`.

### Fixed — deployment validation and state-machine hardening

- `DeploymentExecutor.create_target()`, `create_deployment()`, `GateChecker.record_gate()`, and `DeploymentRollbackManager.rollback_deployment()` now validate config / metadata / gate details as JSON-serializable dicts with string keys before persisting them.
- `DeploymentExecutor.create_deployment()` now pre-validates referenced targets, objects, scopes, and rollback sources, raising scoped errors instead of leaking storage-level failures.
- Archived deployment targets can no longer accept new deployments or execute pending ones.
- Deployment state transitions now enforce an explicit state machine: `pending -> deploying -> deployed|failed`, with `deployed -> rolled_back` reserved for rollback.
- Rollback chains now guard against cycles and read deterministically by version order.

### Changed

- Layer 8 (Environments) is now explicitly marked stable in code. `EnvironmentLifecycle`, `EnvironmentContainer`, and `SnapshotManager` now use `@stable(since="1.1.0")`, matching the earlier production-hardening releases.

### Docs

- Backfilled missing changelog entries for `1.0.5`, `1.1.0`, and `1.2.0` so the public release history matches the tagged releases.

## 1.4.1 (2026-04-17)

### Fixed — Layer 3 ↔ Layer 4 visibility integration

`ScopedManager.get()` and `list_objects()` (the `client.objects.get()` / `client.objects.list()` paths) were owner-only — they ignored scope projections entirely, contradicting the documented "scope members see projected objects" invariant. Promoted objects, projected objects, and hierarchy-inherited projections were all invisible through the public API even though `VisibilityEngine.can_see()` correctly returned `True`.

- `ScopedManager.get()` and `get_or_raise()` now consult the wired `VisibilityEngine` when the owner check fails, returning the object if any active projection grants visibility.
- `ScopedManager.list_objects()` and `count()` now return owned + projected objects (including via ancestor-scope inheritance).
- `VisibilityEngine._projected_object_ids()` (and therefore `visible_object_ids()`) now uses a recursive CTE to walk ancestor scopes, matching the hierarchy semantics already implemented in `can_see()`.
- Backward compat: callers who construct a bare `ScopedManager(backend)` without injecting a `visibility_engine` keep the historical owner-only behavior — no change to direct test fixtures.

This unblocks every Layer 9 promotion scenario (post-promotion, scope members can finally read promoted objects via the documented `client.objects.get()` API).

## 1.4.0 (2026-04-17)

### Layer 9 (Flow) — Phase 2 integration + Phase 3 graduate

**Layer 9 is now stable.** The `@experimental` decorators on `PipelineManager`, `FlowEngine`, and `PromotionManager` have been replaced with `@stable(since="1.4.0")` — no more warnings on import, and the API contract is now covered by the usual semver guarantees.

### Added — `env.promote()` auto-chains to promotions

- `EnvironmentLifecycle.promote()` accepts `target_scope_id`, `target_stage_id`, and `access_level`. When `target_scope_id` is provided, every object tracked with `origin=CREATED` is auto-promoted (projected) into that scope before the env state flips to `PROMOTED`. Projected-origin objects are left untouched (they belong elsewhere).
- If any per-object promotion fails, the env stays in `COMPLETED` so the caller can retry or discard — no partial state flip.
- `EnvironmentLifecycle.__init__` takes new optional `container=` and `promotion_manager=` deps; the default service wiring pre-injects both, so `scoped.environments.promote(env, target_scope_id=team)` just works.

### Added — module-level namespaces: `scoped.pipelines`, `scoped.flow`, `scoped.promotions`

- `scoped.pipelines.create(...)`, `.add_stage(pipeline, ...)`, `.transition(obj, to_stage, from_stage=...)`, `.current_stage(obj)`, `.history(obj)`, `.archive(pipeline)`
- `scoped.flow.create_channel(...)`, `.can_flow(...)`, `.can_flow_or_raise(...)`, `.list_channels(...)`, `.archive_channel(channel)`, `.find_routes(...)`
- `scoped.promotions.promote(obj=..., source_env=..., target_scope=..., target_stage=..., access_level=...)`, `.list(source_env=...)`, `.count(source_env)`

All three accept model instances or string IDs for references, and infer `owner_id`/`transitioned_by`/`promoted_by` from the active `ScopedContext` when omitted.

### Added — rule-engine deny hooks

- `PipelineManager(rule_engine=...)` now evaluates rules before every `transition()` with `action="stage_transition"`, binding targets `object`, `object_type`, `principal`, and the pipeline as `scope_id`. DENY raises `StageTransitionDeniedError`.
- `PromotionManager(rule_engine=...)` evaluates rules before every `promote()` with `action="promotion"`, binding targets `scope` (target), `environment` (source), `object`, `object_type`, and `principal`. DENY raises `PromotionDeniedError`.
- The default service wiring injects `rule_engine` into both managers.

### Changed — `FlowEngine.archive_channel()` signature

- `archived_by` is now required (was optional, with audit silently skipped when omitted). Archival now always emits an audit entry.

## 1.3.0 (2026-04-17)

### Layer 9 (Flow) — Phase 1 hardening

**Behavior changes** (previously-broken or missing functionality now works):

- **`PromotionManager.promote()` now actually promotes.** Before, it wrote a row to `promotions` but never projected the object into the target scope — so nothing became visible. It now creates a real `ScopeProjection` via an injected `ProjectionManager`, so the promoted object shows up under `VisibilityEngine.can_see(principal, object)` as intended. Accepts an optional `access_level` (defaults to `READ`) controlling the projection's grant level.
- **Missing references raise scoped exceptions** instead of leaking `sqlalchemy.IntegrityError`. `promote()` now pre-validates env/scope/object/stage existence and raises `EnvironmentNotFoundError`, `ScopeNotFoundError`, or `PromotionDeniedError` with useful context.
- **`PipelineManager.transition()` now enforces invariants** that were silently ignored:
  - Stages must share a pipeline. Cross-pipeline transitions raise `StageTransitionDeniedError`.
  - The pipeline must be `ACTIVE`. Archived pipelines reject transitions.
  - `from_stage_id` must equal the object's actual current stage (no more fake transition histories).
  - Initial placement (no `from_stage_id`) is rejected if the object already has a current stage.
  - Callers must own the object (`AccessDeniedError` otherwise).
  - Missing target objects raise `FlowError` instead of silently inserting.

### Added

- **`services.promotions`** — `PromotionManager` is now wired into `ScopedServices` with the default `ProjectionManager` already attached, so `client.services.promotions.promote(...)` works out of the box. Flow-channel enforcement remains opt-in: construct your own `PromotionManager(flow_engine=...)` if every promotion must be gated by an active channel.
- **`PromotionManager(projection_manager=...)` constructor arg** — inject a `ProjectionManager` to make promotions create real scope projections.

## 1.2.1 (2026-04-17)

### Fixed
- **Rollback now actually reverts object versions.** `RollbackExecutor.rollback_action()` on a real object-update trace previously reported `success=True` but left `current_version` unchanged — the restore path looked for `current_version` inside `before_state`, but the object manager records the version's data dict there, not a metadata pointer. Fixed by recording `before_version`/`after_version` in the audit trace's `metadata` field (which is not part of the hash chain, so audit integrity is unaffected) and having `_apply_rollback_state` read from metadata. The rolled-back version row in `object_versions` is now also removed, so the freed version number is reused by the next update and no longer collides with the `UniqueConstraint("object_id", "version")`.
- **`scoped.objects` no longer gets shadowed by the submodule.** The documented `scoped.objects.create(...)` quick-start form would fail after the first call because lazy imports of `scoped.objects.blobs` / `search` / etc. caused Python's import machinery to install the submodule as an attribute on the package, shadowing the `ObjectsNamespace` returned by the package-level `__getattr__`. The package now uses a `ModuleType` subclass whose `__getattribute__` always routes namespace names through the default client, so the documented quick-start works end-to-end regardless of import order.

## 1.2.0 (2026-04-06)

### Added
- **`scoped.environments` namespace.** Layer 8 now has a module-level namespace with context-aware lifecycle, container, template, and snapshot operations, matching the simplified APIs used elsewhere in the SDK.
- **Snapshot retention management.** `SnapshotManager.apply_retention(max_age_days, max_snapshots)` can prune old environment snapshots by age and count.
- **Environment storage indexes.** Migration `m0015` adds indexes for common Layer 8 query paths on environment ownership, state, object origin, and snapshot history.

### Changed
- **Layer 8 rule integration.** The rule engine now accepts `environment_id`, evaluates `BindingTargetType.ENVIRONMENT` bindings, and `EnvironmentContainer.add_object()` consults rules when a `rule_engine` is wired.
- **Metadata validation for environment inputs.** `spawn()` and `create_template()` now validate metadata/config dicts for string keys and JSON-serializability before writing invalid payloads.
- **Default service wiring expanded.** `ScopedServices` now exposes environment container and snapshot managers with the usual audit and rule-engine dependencies injected.

### Fixed
- **Environment rollback support.** Layer 7 rollback now restores environment state transitions from audit `before_state`, and rolling back an environment spawn marks the environment discarded instead of leaving inconsistent state behind.

## 1.1.0 (2026-04-06)

### Layer 8 (Environments) — production hardening

### Fixed
- **Lifecycle transaction safety.** `spawn()` now cleans up the auto-created scope if environment creation fails, and `discard()` restores the previous environment state if the scope archive step fails.
- **Ownership enforcement across Layer 8.** Lifecycle transitions, container mutations, and snapshot operations now consistently require the environment owner and raise `AccessDeniedError` on misuse.
- **Environment discard cleanup.** Discarding an environment now tombstones objects created inside it while leaving projected-in external objects untouched.
- **Snapshot restore correctness.** `SnapshotManager.restore()` now reinstates object `current_version` pointers, resynchronizes `environment_objects`, and verifies snapshot checksums during restore.

### Changed
- **Layer 8 audit coverage.** Container add/remove operations and snapshot capture/restore now emit audit records, closing earlier trace gaps in environment activity.

## 1.0.5 (2026-04-06)

### Fixed
- **Typed object versions deserialize correctly.** `list_versions()` and `get_version()` now pass `object_type` through version row decoding, so `typed_data` returns hydrated custom instances instead of raw dict payloads.
- **Rollback works for custom object types.** `RollbackExecutor` now resolves rollback targets through `scoped_objects` instead of assuming `target_type == "object"`, fixing rollback for typed models such as `invoice`.

## 1.0.4 (2026-04-03)

### Docs
- **Deep documentation audit** — fixed 55+ stale references across 14 doc files:
  - Replaced all `from pyscoped.*` imports with `from scoped.*` (the correct Python module name)
  - Replaced all `import pyscoped` / `pyscoped.init()` with `import scoped` / `scoped.init()`
  - Fixed `RuleDeniedError` → `AccessDeniedError` in objects API reference (exception never existed)
  - Fixed `from scoped.audit import ActionType` → `from scoped.types import ActionType`
  - Fixed `scoped.storage.tenant` → `scoped.storage.tenant_router` for TenantRouter import
  - Replaced all `async def` signatures and `await` calls in storage API reference with sync equivalents (the entire storage layer is synchronous)
  - Replaced `__aenter__`/`__aexit__` with `__enter__`/`__exit__` in StorageTransaction
  - Updated all deprecated `SQLiteBackend` → `SASQLiteBackend` and `PostgresBackend` → `SAPostgresBackend` references in code examples across getting-started, multi-tenant, security, adapters, migrations, and API reference docs
  - Updated constructor args from old `pool_min_size`/`pool_max_size` to `pool_size`/`max_overflow`
  - Added deprecation notices for legacy backend sections in storage API reference

## 1.0.3 (2026-04-03)

### Docs
- Fixed "zero runtime dependencies" claims — pyscoped requires pydantic and sqlalchemy as core dependencies
- Fixed `pip install scoped[django]` → `pip install pyscoped[django]` in API reference
- Fixed `from scoped import Client` → `from scoped.client import ScopedClient` across 5 doc files (scheduling, operations, events-webhooks, connectors, testing)
- Fixed `from scoped import current_client` → `scoped.scopes.list()` in testing docs
- Fixed `from scoped import ScopedContext` / `Principal` → correct import paths in FastAPI docs
- Fixed OTel import path `scoped.telemetry` → `scoped.contrib.otel` in operations docs

## 1.0.2 (2026-04-03)

### Fixed
- **Django backend initialization** — `_initialize_backend()` now catches exceptions during `AppConfig.ready()`, tolerating fresh databases where tables don't exist yet (e.g., first Heroku deploy before migrations run)

## 1.0.1 (2026-04-02)

### Fixed
- **Default API base URL** — `ManagementPlaneClient.DEFAULT_BASE_URL` updated from `api.pyscoped.dev` to `kwip.tech`

## 1.0.0 (2026-04-02)

### Security
- **Timing attack fix** — Audit hash chain verification now uses `hmac.compare_digest()` for constant-time comparison instead of `!=`. Prevents character-by-character timing attacks on audit entry hashes
- **Path traversal fix** — `LocalBlobBackend` now validates all `storage_path` inputs via `resolve()` + root containment check. Prevents `../../` traversal in `retrieve()`, `delete()`, `exists()`, and `retrieve_stream()`
- **Crypto exception handling** — `decrypt_config()` now catches `InvalidToken` and `JSONDecodeError` specifically instead of bare `Exception`. Prevents silent swallowing of unexpected errors

### Changed
- **`descendants()` bounded** — `ScopeLifecycle.descendants()` now accepts `max_total=10000` parameter capping total results, preventing memory exhaustion on deep hierarchies
- **Classifier** — `Development Status :: 5 - Production/Stable`

### Docs
- Fixed `docs/testing.md` fixture names (`scoped_backend`, `scoped_services` instead of stale `sqlite_backend`, `storage_backend`)
- Fixed `README.md` backend examples to use `SASQLiteBackend`/`SAPostgresBackend` instead of deprecated backends
- Fixed `docs/operations.md` migration inventory to match actual migration files
- Removed non-existent `compliance/` from project structure in `CLAUDE.md`
- Documented membership expiration enforcement in `docs/layers/04-tenancy.md`

## 0.9.6 (2026-04-02)

### Added
- **Archive streaming (NDJSON)** — `Exporter.stream_export(object_ids, principal_id=)` and `stream_export_by_type(object_type, principal_id=, batch_size=100)` yield NDJSON lines (one manifest header + one line per object with all versions). Memory usage is O(single_object). `Importer.stream_import(lines, principal_id=)` consumes an `Iterator[str]`, recognizes manifest lines, supports type filtering. `stream_export_by_type` paginates object IDs in configurable batches

## 0.9.5 (2026-04-02)

### Added
- **Typed webhook config** — `WebhookConfig` Pydantic model with `RetryPolicy`. `WebhookEndpoint.typed_config` property with fallback. `parse_webhook_config()` / `webhook_config_to_dict()` helpers in `scoped.events.config_types`
- **Typed gate details** — `StageCheckDetails`, `RuleCheckDetails`, `ApprovalDetails`, `CustomGateDetails` models. `DeploymentGate.typed_details` property. Discriminated by `GateType`. In `scoped.deployments.gate_types`
- **Typed plugin manifest/metadata** — `PluginManifest` and `PluginMetadata` models with `PluginPermissionSpec`. `Plugin.typed_manifest` and `Plugin.typed_metadata` properties. In `scoped.integrations.plugin_types`
- **Typed scope settings** — Setting type registry via `register_setting_type(key, model_cls)`. `ConfigStore.set()` accepts Pydantic models. `setting_value_to_dict()` serializer. In `scoped.tenancy.config_types`

## 0.9.4 (2026-04-02)

### Added
- **CI/CD pipeline** — GitHub Actions workflow with 4 jobs: `lint` (ruff on Python 3.13), `test` (pytest matrix across 3.11/3.12/3.13 with SQLite), `test-postgres` (Postgres 16 service container on 3.13), `build` (wheel + sdist with artifact upload). Concurrency groups cancel stale runs. Build gates on lint + test passing

## 0.9.3 (2026-04-02)

### Added
- **Config inheritance transparency** — `ResolvedSetting.resolution_chain` shows all ancestor values encountered during hierarchy traversal, ordered root-to-leaf. Each entry is a `(scope_id, value)` tuple. Populated by both `ConfigResolver.resolve()` and `resolve_all()`. Enables UIs and debugging tools to show exactly where a setting comes from and what it overrides
- **Blob streaming** — `BlobBackend.store_stream(blob_id, fp)` and `retrieve_stream(storage_path)` for streaming binary content without loading entire blobs into memory. `InMemoryBlobBackend` implements both (single chunk). `LocalBlobBackend` reads/writes in 64KB chunks. `BlobManager.store_stream()` computes incremental SHA-256 during upload. `BlobManager.read_stream()` returns an `Iterator[bytes]` with isolation enforcement

## 0.9.2 (2026-04-02)

### Quality

- **URN validation at construction** — `URN.__post_init__()` now validates that `kind`, `namespace`, and `name` are non-empty and `version >= 1`. Invalid URNs raise `ValueError` immediately. `URN.parse()` inherits the same validation
- **Redaction performance** — `RedactionEngine.apply()` uses shallow copy (`dict(data)`) instead of `copy.deepcopy(data)`. Safe because redaction only assigns new values to top-level keys, never mutates nested objects
- **Structured logging in core modules** — Six key modules now emit structured JSON logs via `get_logger()`: `objects.manager` (create/update/tombstone), `audit.writer` (record), `rules.engine` (evaluate), `secrets.vault` (create/rotate/resolve — never logs values), `tenancy.lifecycle` (create_scope/freeze/archive), `sync.transport` (push_batch)
- **Pytest-native testing helpers** — New assertion functions: `assert_access_denied(fn)`, `assert_can_read(backend, oid, pid)`, `assert_cannot_read(backend, oid, pid)`, `assert_trace_exists(backend, **criteria)`. New markers: `@sqlite_only`, `@postgres_only` (registered in `pyproject.toml`). New `scoped_txn` fixture for transactional test isolation

## 0.9.1 (2026-04-02)

### Security
- **Membership expiration enforcement** — `scope_memberships.expires_at` is now checked in all 6 visibility query sites: `is_member()`, `can_see()`, `scope_member_ids()`, `get_memberships()`, `get_principal_scopes()`, `_projected_object_ids()`. Expired memberships are lazily archived on access. New `ScopeMembership.is_expired` property and `active_membership_condition()` helper
- **Projection access level enforcement** — `AccessLevel` (READ/WRITE/ADMIN) stored on projections is now enforced: `update()` requires WRITE, `tombstone()` requires ADMIN. Opt-in via `visibility_engine` parameter on `ScopedManager`. Owners always have full access regardless of projection
- **Webhook secrets encryption** — `config_json` sensitive fields (`headers`, `auth_token`, `secret`) are Fernet-encrypted at rest. `encrypt_config()` / `decrypt_config()` in `scoped.events.crypto`. Backward compatible with existing plaintext configs

## 0.9.0 (2026-04-02)

### Added
- **Pagination on all unbounded queries** — `Registry.by_kind()`, `by_namespace()`, `by_tag()`, `by_lifecycle()`, `all()`, `query()` now accept `limit`/`offset`. `ScopeLifecycle.list_scopes()` default changed from `None` to `1000`. `RollbackExecutor._collect_descendants()` bounded by `max_depth=100`
- **Rule engine caching** — `RuleEngine(cache_ttl=60.0)` enables TTL-based in-memory cache for rule lookups. `RuleCache` is thread-safe with `get()`/`put()`/`invalidate()`/`stats()`. Shared between `RuleStore` and `RuleEngine` via `ScopedServices` wiring. Cache invalidated on all mutations (create/update/archive/bind/unbind)
- **Audit chain optimization** — `verify_chain()` now selects only 9 hash-relevant columns instead of `SELECT *`, eliminating I/O for `before_state`/`after_state`/`metadata_json`. New `VerificationEntry` lightweight dataclass. `AuditNamespace.verify(chunk_size=5000)` parameter exposed
- **Audit retention** — `AuditRetention` class with `apply(policy)`, `estimate(policy)`, `compact()`. `RetentionPolicy` supports `max_age_days`, `max_entries`, `compact_before_state`, `compact_after_state`. Compaction nulls state columns while preserving hash chain integrity

## 0.8.1 (2026-04-02)

### Added
- **Rollback preview (dry-run)** — `rollback_action()`, `rollback_to_timestamp()`, and `rollback_cascade()` now accept `dry_run=True`, returning a `RollbackPreview` with `would_rollback`, `would_deny`, and `entry_count` without modifying any data
- **Rule evaluation debugging** — `RuleEngine.evaluate_with_explanation()` returns `EvaluationExplanation` with per-rule `RuleExplanation` (condition matches, binding info, human-readable reason) and a summary string. New models: `ConditionMatch`, `RuleExplanation`, `EvaluationExplanation`
- **Namespace API completeness** — `PrincipalsNamespace`: `archive()`, `add_relationship()`, `relationships()`, `list()` with `limit`/`offset`. `ScopesNamespace`: `children()`, `ancestors()`, `descendants()`, `path()` hierarchy traversal, `members()`/`projections()` with `limit`/`offset`. `AuditNamespace`: `count()`, `export(format="json"|"csv")`
- **Service-layer pagination** — `PrincipalStore.list_principals()`, `ScopeLifecycle.get_memberships()`, `get_principal_scopes()`, `ProjectionManager.get_projections()` now accept `limit`/`offset`

## 0.8.0 (2026-04-02)

### Added
- **Typed IDs** — `scoped.ids` module with 13 thin `str` subclasses: `PrincipalId`, `ObjectId`, `ScopeId`, `RuleId`, `TraceId`, `SecretId`, `VersionId`, `BindingId`, `MembershipId`, `ProjectionId`, `ConnectorId`, `ScheduleId`, `JobId`. All are `isinstance(x, str)` — zero breakage. `PrincipalId.generate()` replaces `generate_id()` for typed ID creation. Re-exported from `scoped.types`
- **Typed rule conditions** — `scoped.rules.conditions` module with Pydantic models for each rule type: `AccessCondition`, `RateLimitCondition`, `QuotaCondition`, `RedactionCondition`, `FeatureFlagCondition`. Validated at creation time (not evaluation time). `Rule.typed_conditions` property for typed access. `RuleStore.create_rule()` accepts typed models or raw dicts
- **Enum coercion helpers** — `coerce_role()` and `coerce_access_level()` in `scoped.tenancy.models` validate string inputs with descriptive `ValueError` messages. Namespace APIs now accept `str | ScopeRole` and `str | AccessLevel`
- **`Scope.lifecycle_display`** property — returns `"FROZEN"` instead of the internal `"DEPRECATED"` name

## 0.7.1 (2026-04-02)

### Changed
- **Default backends switched** — `scoped.init()` and `ScopedClient(database_url=...)` now create `SASQLiteBackend`/`SAPostgresBackend` instead of the legacy backends
- **`StorageBackend.engine` property** — Optional property returning the SQLAlchemy engine for SA-backed backends (`None` for legacy backends)

### Deprecated
- **`SQLiteBackend`** — Use `SASQLiteBackend` instead. Emits `DeprecationWarning` on construction. Will be removed in v1.0
- **`PostgresBackend`** — Use `SAPostgresBackend` instead. Emits `DeprecationWarning` on construction. Will be removed in v1.0

## 0.7.0 (2026-04-02)

### Added
- **SQLAlchemy Core query layer** — All 462 raw SQL strings across 58 consumer files converted to `sa.select()`, `sa.insert()`, `sa.update()`, `sa.delete()` constructs compiled via `compile_for(stmt, dialect)`. Queries are dialect-portable across SQLite and PostgreSQL. Raw SQL preserved only for FTS5/tsvector full-text search and dynamic quota table queries with allowlist validation
- **SQLAlchemy Core schema** — `scoped.storage._schema` defines 63 `sa.Table` objects matching all DDL from migrations m0001–m0014 plus `scoped_migrations`. Used for query building only (not DDL)
- **Query compilation bridge** — `scoped.storage._query.compile_for(stmt, dialect)` compiles SQLAlchemy Core statements to `(sql, params)` tuples compatible with the existing `StorageBackend.execute/fetch_*` interface. Supports `render_postcompile=True` for IN clause expansion. `dialect_insert()` helper for dialect-aware UPSERT via `on_conflict_do_update()`
- **SASQLiteBackend** — `scoped.storage.sa_sqlite.SASQLiteBackend` — SQLAlchemy Core-backed SQLite storage, drop-in replacement for `SQLiteBackend`. Uses `StaticPool` for in-memory, `metadata.create_all()` for schema, DBAPI `executescript()` for scripts. Pragma setting via SA event listener
- **SAPostgresBackend** — `scoped.storage.sa_postgres.SAPostgresBackend` — SQLAlchemy Core-backed PostgreSQL storage with connection pooling (`QueuePool`), RLS support via `SET [LOCAL] app.current_principal_id`, drop-in replacement for `PostgresBackend`
- **Typed Object Protocol** — `scoped.register_type("invoice", InvoiceModel)` registers Pydantic models, dataclasses, or `ScopedSerializable` protocol types. `ScopedManager.create()` and `update()` auto-serialize typed instances. `ObjectVersion.typed_data` property auto-deserializes back to the registered type
- **Type adapters** — `scoped._type_adapters` with `PydanticAdapter` (`model_dump`/`model_validate`), `DataclassAdapter` (`asdict`/`cls(**data)`), `ScopedSerializableAdapter` (protocol methods), auto-detection in `TypeRegistry.register()`
- **`ScopedSerializable` protocol** — `scoped.types.ScopedSerializable` with `to_scoped_dict()` and `from_scoped_dict()` for custom serialization
- **Stability markers** — `@experimental()`, `@preview()`, `@stable()` decorators in `scoped._stability`. Emit `ExperimentalAPIWarning` or `PreviewAPIWarning` (both `FutureWarning` subclasses) on first use. Suppressible via `warnings.filterwarnings("ignore", category=...)`. `get_stability_level()` introspection helper
- **Django ScopedModel** — `scoped.contrib.django.models.ScopedModel` abstract base for Django models that auto-sync with pyscoped's object layer. `save()` creates/updates ScopedObjects atomically. `delete()` tombstones. `_to_scoped_dict()` handles DateTimeField, DecimalField, UUIDField, ForeignKey serialization. `ScopedMeta.scoped_fields` controls which fields sync
- **Django ScopedQuerySet** — `ScopedQuerySet.for_principal(principal_id)` filters by pyscoped visibility (owner + scope projections), falls back to `scoped_owner_id` filtering when no client
- **Django ScopedDjangoManager** — Secondary manager on `ScopedModel` with `for_principal()` shortcut. Default `objects` manager untouched
- **`scoped_context_for()` helper** — Context manager for non-HTTP code (management commands, Celery tasks) that sets `ScopedContext` from a principal ID
- **DjangoORMBackend dialect** — `dialect` property now returns the actual Django connection vendor (`"sqlite"` or `"postgres"`) instead of `"generic"`

### Changed
- **`sqlalchemy>=2.0` dependency** — Added to `pyproject.toml`. All storage consumers now build queries via SQLAlchemy Core instead of string interpolation
- **Stability decorations** — 21 classes marked `@experimental` (Layers 8-16), 4 classes marked `@preview` (Layer 13 connector/marketplace)

## 0.6.2 (2026-04-02)

### Security
- **SQL injection fix** — `QuotaChecker` now validates `count_column` and `scope_column` against an allowlist (`_ALLOWED_COLUMNS`) before interpolating into SQL. Previously only table names were validated. Also fixes `table == "objects"` comparison (should be `"scoped_objects"`)
- **Webhook config** — noted as requiring encryption at rest (tracked for follow-up)

### Fixed
- **Registry thread safety** — all 13 read methods now acquire `RLock`. Listener callbacks execute outside the lock to prevent deadlocks. `archive()` performs index cleanup atomically under a single lock hold. `CustomKind._registered` is now protected by a module-level `threading.Lock`
- **Transaction boundaries** — `archive_scope()`, `freeze_scope()`, `_add_membership()`, `update()`, and `tombstone()` now wrap multi-step operations in explicit database transactions. Audit entries are recorded after the business transaction commits
- **Audit sequence collisions** — new migration **m0014** adds a `UNIQUE` constraint on `audit_trail.sequence`. `AuditWriter.record()` now uses a database transaction with bounded retry (3 attempts) on sequence collision. `record_batch()` saves and restores in-memory state on transaction failure. New `AuditSequenceCollisionError` exception
- **Notification preferences** — replaced indirect `datetime_fromisoformat()` helper with direct `datetime.fromisoformat()` call
- **Event-notification pipeline** — `NotificationEngine.process_event()` is now automatically wired as a wildcard listener on `EventBus` when `ScopedServices.notifications` is accessed. Previously the pipeline was disconnected

### Added
- **Quota enforcement in write path** — `ScopedManager` accepts optional `quota_checker` and `rate_limit_checker`. Quota checks run inside the write transaction (TOCTOU-safe). Rate limit checks run before the transaction (approximate, acceptable for soft limits). New `QuotaChecker.check_in_txn()` method
- **Wildcard event listeners** — `EventBus.on_any(listener)` and `off_any(listener)` register listeners that receive all event types
- **Pluggable cron parser** — `Scheduler` accepts an optional `cron_parser: Callable[[str, datetime], datetime]` for real cron expression evaluation. Without it, cron schedules fall back to a 1-hour placeholder with a `warnings.warn()`

## 0.6.1 (2026-04-02)

### Added
- **Integration smoke test** — `scoped.testing.integration.PlatformSmokeTest` exercises the full SDK → Platform round-trip: object CRUD, audit chain, sync batch push, chain verification, usage reporting, and key listing. Runnable via `python -m scoped.testing.integration --base-url ... --api-key ...`

## 0.6.0 (2026-04-01)

### Added
- **Entity update methods** — `PrincipalStore.update_principal()` and `ScopeLifecycle.update_scope()` for updating display names, descriptions, and metadata with audit trails. Metadata merges (additive, not replace). Exposed via `principals.update()` and `scopes.update()` namespaces
- **Bulk operations** — `ScopedManager.create_many()` for atomic batch object creation in a single transaction with batched audit entries. `ScopeLifecycle.add_members()` for adding multiple members at once. Exposed via `objects.create_many()` and `scopes.add_members()`
- **Rules enforcement** — `RuleEngine` wired into `ScopedServices` and injected into `ScopedManager`. DENY rules are now enforced before `create()`, `update()`, and `tombstone()` operations, raising `AccessDeniedError`. No-op when no rules are configured (backward compatible)
- **Paginated list_versions()** — accepts `limit` and `offset` parameters to avoid loading all version data into memory
- **Chunked verify_chain()** — processes audit entries in configurable `chunk_size` chunks (default 5000) instead of loading the entire trail. Maintains chain linkage across chunk boundaries
- **Django async middleware** — `ScopedContextMiddleware` now supports both sync and async views via `@sync_and_async_middleware` (Django 4.1+)
- **Django REST Framework integration** — new `scoped.contrib.django.rest_framework` module with `ScopedAuthentication` (resolves from resolver, header, or Django auth), `IsScopedPrincipal` and `HasScopeAccess` permission classes, and `ScopedUser` wrapper
- **FastAPI WebSocket support** — middleware handles `scope["type"] == "websocket"`, sets `ScopedContext` from handshake headers for the connection lifetime
- **Proper return type hints** — all namespace methods now return specific types (`Principal`, `Scope`, `ScopedObject`, `TraceEntry`, etc.) instead of `Any`, using `TYPE_CHECKING` guards to avoid circular imports
- **Structured logging** — new `scoped.logging` module with `ScopedLogger` (JSON structured output), `get_logger()` factory, auto-enrichment with principal_id from context, `SCOPED_LOG_LEVEL` env var
- **Extended OpenTelemetry** — `instrument()` now covers 21 operations: scope lifecycle (create, rename, update, add_member, revoke_member, freeze, archive, list), principal management (create, get, update, list), and rule evaluation, in addition to existing object CRUD, audit, and secret operations
- **Webhook HTTP transport** — `WebhookDelivery.http_transport` static method using stdlib `urllib.request` for production webhook delivery. Supports custom headers from endpoint config
- **Exponential backoff retries** — `retry_failed(backoff_base=60)` enforces delay between retry attempts: `backoff_base * 2^(attempt-1)` seconds. `backoff_base=0` disables for testing
- **Scheduler → JobQueue bridge** — `Scheduler.process_due_actions(queue)` enqueues all due actions, advances recurring schedules by interval, and archives one-shot actions
- **Connector federation transport** — `ConnectorManager` accepts a pluggable `transport` callable for HTTP push to remote endpoints. `sync_object()` now pushes data for outbound syncs, records `FAILED` traffic on transport errors. `ConnectorManager.http_transport` static method provided
- **Postgres Row-Level Security** — `PostgresBackend(enable_rls=True)` sets `app.current_principal_id` per-connection from `ScopedContext`. Migration m0013 creates RLS policies on 21+ tables with `FORCE ROW LEVEL SECURITY`. Uses `SET LOCAL` for transactions, `SET` + `RESET` for autocommit
- **Database-per-tenant isolation** — new `TenantRouter` storage backend routes operations to per-tenant databases based on `ScopedContext`. Thread-safe backend cache, tenant lifecycle management (`provision_tenant`, `teardown_tenant`, `list_tenants`)
- **Composite indexes** — migration m0012 adds `(scope_id, lifecycle)`, `(principal_id, lifecycle)`, and `(action, timestamp)` indexes for visibility JOINs and rate-limit queries
- **CLAUDE.md** — comprehensive LLM workspace context file (520 lines) covering full API surface, architecture, isolation model, and integration guides
- **Full documentation** — 21 new docs (9,100+ lines) across guides, API reference, integrations, features, and reference categories with `manifest.json` for platform export

### Changed
- **Recursive CTE hierarchy traversal** — `ancestor_scope_ids()`, `descendant_scope_ids()`, and `_visible_via_hierarchy()` rewritten from N+1 query loops to single `WITH RECURSIVE` queries (both SQLite and Postgres)
- **Thread-safe global client** — `scoped.init()` protected by `threading.Lock` to prevent race conditions on `_default_client`
- **Multi-process audit safety** — `AuditWriter` re-seeds sequence from database before each write to handle multi-process scenarios (e.g. gunicorn workers)
- **`inspect.isawaitable()`** — FastAPI middleware uses `inspect.isawaitable()` instead of `hasattr(result, "__await__")` for async principal resolver detection

## 0.5.0 (2026-04-01)

### Added
- **Scope rename** — `ScopeLifecycle.rename_scope()` and `client.scopes.rename()` for renaming scopes with full audit trail (before/after state via `SCOPE_MODIFY`). Validates scope is mutable (not frozen/archived)
- **Scope pagination** — `list_scopes()` now accepts `limit` and `offset` parameters for pagination. Previously returned all matching scopes with no limit
- **Scope count** — `ScopeLifecycle.count_scopes()` and `client.scopes.count()` for efficient scope counting without loading full rows
- **Order-by for scopes** — `list_scopes()` accepts `order_by` parameter with `-` prefix for descending (e.g. `"-name"`, `"created_at"`). Allowed columns: `created_at`, `name`
- **Order-by for objects** — `list_objects()` accepts `order_by` parameter. Allowed columns: `created_at`, `object_type`
- **Order-by for audit queries** — `AuditQuery.query()` accepts `order_by` parameter. Allowed columns: `sequence`, `timestamp`. Enables native descending queries (e.g. `"-sequence"` for most-recent-first) without client-side reversal

## 0.4.0 (2026-03-31)

### Added
- **Management plane contract** — 30 Pydantic models defining the complete API between SDK and hosted management plane: account provisioning, API key management, sync batches, billing/usage, and health checks. Both sides import from `scoped.sync.models` — zero contract drift
- **Sync agent** — `SyncAgent` background thread pushes audit metadata to the management plane. Full lifecycle: `start()`, `pause()`, `resume()`, `stop()`, `status()`, `verify()`. Watermark persisted in `_sync_state` table for crash recovery
- **Transport security** — HMAC-SHA256 signed batches with derived signing key, content hashes, chain hashes tying to the tamper-evident audit trail. 5-layer security: TLS, Bearer auth, HMAC signing, content hash, chain hash
- **`_sync_state` table** — migration m0011, colocated with user data for backup/restore. Tracks watermark position, sync status, error state with exponential backoff
- **Sync exceptions** — `SyncError`, `SyncNotConfiguredError`, `SyncTransportError`, `SyncAuthenticationError`, `SyncBatchRejectedError`, `SyncVerificationError`
- **`SyncConfig`** — configurable interval, batch size, retries, backoff, timeout
- **`SyncEntryMetadata`** — audit entry model that deliberately excludes `before_state`/`after_state`. Customer data never leaves their infrastructure
- **`ResourceCounts`** — active objects, principals, scopes snapshot for usage-based billing metering
- **Billing models** — `PlanLimits`, `UsageSnapshot`, `UsageHistoryResponse`, `PlanInfoResponse` for usage-based pricing
- **Account models** — `ProvisionRequest/Response`, `AccountInfo`, `ApiKeyMetadata`, key create/revoke/rotate models

### Changed
- **Pydantic is now a core dependency** (`pydantic>=2.0`). Required for the shared contract models between SDK and management plane
- **`ScopedClient.start_sync()`** — now creates a real `SyncAgent` instead of raising `NotImplementedError`. Requires `api_key`
- **`ScopedClient.sync_status()`** — returns `SyncStateSnapshot` dict when agent is active
- **`ScopedClient.close()`** — stops the sync agent if running
- SQLite and Postgres inline schemas include `_sync_state` table

## 0.3.0 (2026-03-31)

### Added
- **Simplified SDK** — `scoped.init()` single entry point with URL-based backend selection (`sqlite:///`, `postgresql://`). After init, use `scoped.objects.create()`, `scoped.principals.create()`, etc. at module level
- **`ScopedClient`** — instance-based client with namespace proxies (`.objects`, `.principals`, `.scopes`, `.audit`, `.secrets`), context manager support, and `as_principal()` for setting the acting user
- **Context-aware defaults** — all namespace methods infer `principal_id`, `owner_id`, `granted_by`, `projected_by` from the active `ScopedContext` when not passed explicitly
- **Merged scopes namespace** — `client.scopes` unifies `ScopeLifecycle` and `ProjectionManager` into one API: `create()`, `add_member()`, `project()`, `unproject()`, `freeze()`, `archive()`
- **API key validation** — `psc_live_<32hex>` / `psc_test_<32hex>` format, validated on init, stored for future management plane sync
- **Sync method stubs** — `client.start_sync()`, `pause_sync()`, `resume_sync()`, `stop_sync()`, `sync_status()`, `verify_sync()` defined for the management plane (implementation in a future release)
- **Object/ID flexibility** — all namespace methods accept model objects or string IDs interchangeably
- **String enum acceptance** — pass `role="editor"` instead of importing `ScopeRole.EDITOR`

### Changed
- **Flask extension** — now accepts `SCOPED_DATABASE_URL` config key, creates a `ScopedClient` internally, sets the global default so `scoped.objects` works in route handlers
- **FastAPI middleware** — now accepts `database_url` and `api_key` constructor args, creates a `ScopedClient` internally, sets the global default
- **Django adapter** — `get_client()` creates a `ScopedClient` from `DjangoORMBackend` and sets the global default on `AppConfig.ready()`
- **MCP server** — `create_scoped_server()` accepts a `ScopedClient` directly; tools and resources use the namespace API instead of dict-based service access
- **OTel instrumentation** — `instrument()` now accepts both `ScopedClient` and `ScopedServices`
- **FastAPI dependencies** — `get_services()` kept for backward compat; new `get_client()` dependency added

## 0.2.0 (2026-03-31)

### Added
- **PostgreSQL backend** — production-grade `PostgresBackend` with psycopg v3 connection pooling, full schema DDL, and `tsvector` full-text search. Install with `pip install pyscoped[postgres]`
- **AWS KMS encryption backend** — `AWSKMSBackend` for Layer 11 secrets, server-side encrypt/decrypt via AWS Key Management Service
- **GCP Cloud KMS encryption backend** — `GCPKMSBackend` for Layer 11 secrets via Google Cloud KMS
- **S3 blob storage** — `S3BlobBackend` for Extension A4, stores binary content in Amazon S3 with sharded key layout
- **GCS blob storage** — `GCSBlobBackend` for Extension A4 via Google Cloud Storage
- **Automatic secret rotation** — `make_rotation_executor()`, `schedule_auto_rotations()`, and `run_pending_rotations()` wire Layer 11 policies to Layer 16 scheduling
- **OpenTelemetry instrumentation** — `instrument(services)` wraps object CRUD, audit recording, and secret operations with OTel spans. Silent no-op when `opentelemetry-api` is not installed
- **Testing utilities for downstream users** — `ScopedFactory` for quick test data creation, 7 domain-specific assertion helpers (`assert_isolated`, `assert_visible`, `assert_audit_recorded`, etc.), importable pytest fixtures (`scoped_services`, `alice`, `bob`, `sample_object`, `sample_scope`)
- **`dialect` property on `StorageBackend`** — returns `"sqlite"`, `"postgres"`, or `"generic"` for backend-aware code
- **Search strategy abstraction** — `SQLiteFTS5Strategy` and `PostgresFTSStrategy` for pluggable full-text search backends
- **Migration dialect support** — migrations 0001, 0005, 0007 branch on `backend.dialect` for Postgres-compatible DDL
- Optional dependency extras: `pyscoped[postgres]`, `pyscoped[aws]`, `pyscoped[gcp]`, `pyscoped[otel]`

### Changed
- `INSERT OR REPLACE` in registry store replaced with portable `ON CONFLICT DO UPDATE` syntax (works on both SQLite 3.24+ and Postgres 9.5+)
- Django ORM backend now imports `translate_placeholders` from shared `scoped.storage._sql_utils` module
- Health checker is dialect-aware — uses `information_schema` on Postgres instead of `sqlite_master`
- Flask extension supports `SCOPED_STORAGE_BACKEND = "postgres"` with `SCOPED_POSTGRES_DSN` config
- `ScopedConfig` gains `postgres_dsn` field

## 0.1.3 (2026-03-31)

### Fixed
- All documentation links now point to correct GitHub repository (kwip-info/pyscoped)
- Clean repository structure — library-only, no application code

## 0.1.1 (2026-03-31)

### Fixed
- ScopedManager now initialized with audit_writer for proper hash-chained audit trails
- Workflow transitions use ScopedManager.update() instead of raw SQL for correct versioning
- Removed duplicate audit entries from runtime data API
- Import pipeline resolves principal FK constraints by importing identities first
- Scope and object creation APIs resolve 'system' owner to real principal for FK compliance

### Added
- Runtime workflow engine: state machine transitions with validation
- Compliance test suite: 16 tests covering versioning, audit integrity, isolation, and rule enforcement
- Scope filtering on data list and widget APIs

### Documentation
- Comprehensive PyPI README with correct code examples
- Getting Started guide with end-to-end walkthrough
- API Reference covering all 16 layers
- Framework Adapters guide (Django, FastAPI, Flask, MCP)

## 0.1.0 (2026-03-28)

### Added
- Initial release
- 16 layers: Registry through Scheduling
- 9 extensions: Migrations through Import/Export
- 4 framework adapters: Django, FastAPI, Flask, MCP
- Compliance engine with 17+ invariant checks
- 1,493 tests
