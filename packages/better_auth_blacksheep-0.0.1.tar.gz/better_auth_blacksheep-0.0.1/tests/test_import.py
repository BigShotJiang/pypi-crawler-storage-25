import better_auth.blacksheep


def test_import():
    assert better_auth.blacksheep.__name__ == "better_auth.blacksheep"
