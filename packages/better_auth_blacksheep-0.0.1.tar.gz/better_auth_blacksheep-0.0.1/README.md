# better-auth-blacksheep

BlackSheep integration package scaffold for `better-auth-py`.

This package reserves the public distribution and import namespace. Runtime
integration will be added when the BlackSheep integration API is implemented.
