"""BlackSheep integration namespace."""
