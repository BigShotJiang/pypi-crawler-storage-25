"""Internationalization (i18n) support for udsxml2tex templates."""

from __future__ import annotations

__all__ = [
    "TRANSLATIONS",
    "Translator",
    "SUPPORTED_LANGS",
    "t",
]

#: Supported language codes.
SUPPORTED_LANGS: list[str] = ["en", "ja", "de"]

#: Translation dictionary: ``TRANSLATIONS[lang][key] = translated_string``.
TRANSLATIONS: dict[str, dict[str, str]] = {
    "en": {
        "sessions": "Sessions",
        "security_levels": "Security Levels",
        "services": "Diagnostic Services",
        "dids": "Data Identifiers (DIDs)",
        "routines": "Routine Controls",
        "dtcs": "Diagnostic Trouble Codes (DTCs)",
        "memory_ranges": "Memory Ranges",
        "transport": "Transport Layer (CanTp)",
        "dem": "Diagnostic Event Manager (DEM)",
        "session_id": "Session ID",
        "security_level": "Security Level",
        "service_id": "Service ID",
        "sub_function": "Sub-Function",
        "description": "Description",
        "supported_sessions": "Supported Sessions",
        "required_security": "Required Security",
        "nrc": "Negative Response Codes",
        "did_id": "DID ID",
        "data_elements": "Data Elements",
        "byte_position": "Byte Position",
        "bit_size": "Bit Size",
        "data_type": "Data Type",
        "read_access": "Read Access",
        "write_access": "Write Access",
        "dtc_id": "DTC ID",
        "severity": "Severity",
        "ecu_name": "ECU Name",
        "protocol": "Protocol",
        "can_rx_id": "CAN RX ID",
        "can_tx_id": "CAN TX ID",
        "yes": "Yes",
        "no": "No",
        "table_of_contents": "Table of Contents",
        "introduction": "Introduction",
        "revision_history": "Revision History",
        "change_history": "Change History",
        "version": "Version",
        "date": "Date",
        "author": "Author",
        "change_description": "Change Description",
        "added": "Added",
        "removed": "Removed",
        "changed": "Changed",
    },
    "de": {
        "sessions": "Diagnosesitzungen",
        "security_levels": "Sicherheitsstufen",
        "services": "Diagnosedienste",
        "dids": "Datenkennungen (DIDs)",
        "routines": "Routinesteuerungen",
        "dtcs": "Diagnosefehlercode (DTCs)",
        "memory_ranges": "Speicherbereiche",
        "transport": "Transportschicht (CanTp)",
        "dem": "Diagnoseereignis-Manager (DEM)",
        "session_id": "Sitzungs-ID",
        "security_level": "Sicherheitsstufe",
        "service_id": "Dienst-ID",
        "sub_function": "Unterfunktion",
        "description": "Beschreibung",
        "supported_sessions": "Unterstützte Sitzungen",
        "required_security": "Erforderliche Sicherheit",
        "nrc": "Negative Antwortcodes",
        "did_id": "DID-ID",
        "data_elements": "Datenelemente",
        "byte_position": "Byte-Position",
        "bit_size": "Bit-Größe",
        "data_type": "Datentyp",
        "read_access": "Lesezugriff",
        "write_access": "Schreibzugriff",
        "dtc_id": "DTC-Code",
        "severity": "Schweregrad",
        "ecu_name": "ECU-Name",
        "protocol": "Protokoll",
        "can_rx_id": "CAN-Empfangs-ID",
        "can_tx_id": "CAN-Sende-ID",
        "yes": "Ja",
        "no": "Nein",
        "table_of_contents": "Inhaltsverzeichnis",
        "introduction": "Einleitung",
        "revision_history": "Revisionshistorie",
        "change_history": "Änderungshistorie",
        "version": "Version",
        "date": "Datum",
        "author": "Autor",
        "change_description": "Änderungsbeschreibung",
        "added": "Hinzugefügt",
        "removed": "Entfernt",
        "changed": "Geändert",
    },
    "ja": {
        "sessions": "診断セッション",
        "security_levels": "セキュリティレベル",
        "services": "診断サービス",
        "dids": "データ識別子 (DID)",
        "routines": "ルーティン制御",
        "dtcs": "故障診断コード (DTC)",
        "memory_ranges": "メモリアドレス範囲",
        "transport": "トランスポート層 (CanTp)",
        "dem": "診断イベントマネージャ (DEM)",
        "session_id": "セッション ID",
        "security_level": "セキュリティレベル",
        "service_id": "サービス ID",
        "sub_function": "サブファンクション",
        "description": "説明",
        "supported_sessions": "対応セッション",
        "required_security": "必要セキュリティ",
        "nrc": "否定応答コード",
        "did_id": "DID ID",
        "data_elements": "データ要素",
        "byte_position": "バイト位置",
        "bit_size": "ビットサイズ",
        "data_type": "データ型",
        "read_access": "読み取りアクセス",
        "write_access": "書き込みアクセス",
        "dtc_id": "DTC コード",
        "severity": "重大度",
        "ecu_name": "ECU 名",
        "protocol": "プロトコル",
        "can_rx_id": "CAN 受信 ID",
        "can_tx_id": "CAN 送信 ID",
        "yes": "あり",
        "no": "なし",
        "table_of_contents": "目次",
        "introduction": "はじめに",
        "revision_history": "改訂履歴",
        "change_history": "変更履歴",
        "version": "バージョン",
        "date": "日付",
        "author": "担当者",
        "change_description": "変更内容",
        "added": "追加",
        "removed": "削除",
        "changed": "変更",
    },
}


class Translator:
    """Translates keys to strings for a given language.

    Example::

        tr = Translator("ja")
        print(tr.t("sessions"))   # "診断セッション"
        print(tr.t("unknown"))    # "unknown"  (key used as fallback)
    """

    def __init__(self, lang: str = "en") -> None:
        self._lang = lang

    @property
    def lang(self) -> str:
        """The active language code."""
        return self._lang

    def set_lang(self, lang: str) -> None:
        """Change the active language.

        Args:
            lang: A language code, e.g. ``"en"`` or ``"ja"``.
        """
        self._lang = lang

    def t(self, key: str, fallback: str = "") -> str:
        """Translate *key* to the active language.

        Args:
            key: The translation key to look up.
            fallback: Value returned when *key* is not found.  If empty string
                (the default), the *key* itself is returned as the fallback.

        Returns:
            The translated string, or *fallback* (or *key*) when not found.
        """
        lang_map = TRANSLATIONS.get(self._lang, {})
        if key in lang_map:
            return lang_map[key]
        # Try English as secondary fallback before using the key/fallback
        en_map = TRANSLATIONS.get("en", {})
        if key in en_map and self._lang != "en":
            return en_map[key]
        return fallback if fallback else key


#: Module-level default :class:`Translator` (English).
_default_translator = Translator("en")


def t(key: str, lang: str = "en", fallback: str = "") -> str:
    """Module-level convenience translation function.

    Args:
        key: The translation key to look up.
        lang: Language code (``"en"`` or ``"ja"``).  Defaults to ``"en"``.
        fallback: Value returned when *key* is not found.  If empty string
            (the default), the *key* itself is returned as the fallback.

    Returns:
        The translated string for *lang*, or *fallback* (or *key*) when not found.
    """
    lang_map = TRANSLATIONS.get(lang, {})
    if key in lang_map:
        return lang_map[key]
    en_map = TRANSLATIONS.get("en", {})
    if key in en_map and lang != "en":
        return en_map[key]
    return fallback if fallback else key
