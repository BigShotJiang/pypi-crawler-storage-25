import pytest

from relational_calculus.domain_calculus import *


def test_track_refs(session):
    r = session.execute("SELECT circuitRef FROM circuits;")
    solution = set(r.fetchall())
    assert len(solution) > 0

    cR = Variable("circuitRef")
    dc = DomainCalculus(
        Result([cR]), Tuple("circuits", [None, cR, None, None, None, None, None])
    )
    r = session.execute(dc.to_sql())
    result = set(r.fetchall())

    assert solution == result


def test_tracks_germany(session):
    r = session.execute(
        "SELECT Name, Location FROM circuits WHERE Country = 'Germany';"
    )
    solution = set(r.fetchall())
    assert len(solution) > 0

    name = Variable("name")
    location = Variable("location")
    dc = DomainCalculus(
        Result([name, location]),
        Tuple("circuits", [None, None, name, location, "Germany", None, None]),
    )
    r = session.execute(dc.to_sql())
    result = set(r.fetchall())

    assert solution == result


def test_tracks_northeast_southwest(session):
    r = session.execute(
        "SELECT * FROM circuits WHERE (Lat >= 0 AND Lng >= 0) OR (Lat < 0 AND Lng < 0);"
    )
    solution = set(r.fetchall())
    assert len(solution) > 0

    circuitId = Variable("id")
    circuitRef = Variable("red")
    name = Variable("ref")
    location = Variable("loc")
    country = Variable("country")
    lat = Variable("lat")
    lng = Variable("lng")
    dc = DomainCalculus(
        Result([circuitId, circuitRef, name, location, country, lat, lng]),
        And(
            Tuple(
                "circuits", [circuitId, circuitRef, name, location, country, lat, lng]
            ),
            Or(
                And(GreaterEquals(lat, 0), GreaterEquals(lng, 0)),
                And(LessThan(lat, 0), LessThan(lng, 0)),
            ),
        ),
    )
    r = session.execute(dc.to_sql())
    result = set(r.fetchall())

    assert solution == result


def test_forall_rename_variable(session):
    # This test targets the two bugs in Forall._rename_variable (single-variable branch):
    #   Bug 1: when self.variable == old_variable, the child was returned un-renamed.
    #   Bug 2: when self.variable != old_variable, new_variable was used instead of self.variable.
    #
    # The rename is triggered by And._to_normal_form() when a Not(Exists(v, P)) (which
    # normalises to Forall(v, Not(P))) sits next to a sibling that already contains v.
    # Here, the inner Exists re-uses the name "raceId" — the same name as the outer
    # existentially-quantified race identifier.  Normalization must rename one of them.
    #
    # Correct semantics of this formula:
    #   { circuitName | ∃circuitId ∃raceId.
    #       CIRCUITS(circuitId, ?, circuitName, ?, ?, ?, ?)
    #     ∧ RACES(raceId, ?, ?, circuitId, ?, ?, ?)
    #     ∧ ¬∃raceId. LAPTIMES(raceId, ?, ?, ?, ?, ?) }
    #
    # The inner ¬∃raceId is UN-CORRELATED with the outer raceId, so the condition reads
    # "the lapTimes table is globally empty".  Our test database has lap times, so the
    # result must be the empty set.
    #
    # With the old buggy Forall._rename_variable the inner Tuple kept the OUTER raceId,
    # effectively turning the condition into "the outer race has no lap times" — which
    # would return a non-empty result and cause the assertion to fail.
    cN = Variable("cN")
    cI = Variable("cI")
    rI = Variable("rI")
    rI_inner = Variable("rI")  # deliberately same name — triggers the rename path

    dc = DomainCalculus(
        Result([cN]),
        Exists(
            {cI, rI},
            And(
                Tuple("circuits", [cI, None, cN, None, None, None, None]),
                And(
                    Tuple("races", [rI, None, None, cI, None, None, None]),
                    Not(
                        Exists(
                            rI_inner,
                            Tuple("lapTimes", [rI_inner, None, None, None, None, None]),
                        )
                    ),
                ),
            ),
        ),
    )
    r = session.execute(dc.to_sql())
    result = set(r.fetchall())

    # The lapTimes table is non-empty, so "¬∃raceId. LAPTIMES(raceId, …)" is false,
    # and the overall formula is unsatisfiable → empty result.
    ref = session.execute(
        "SELECT DISTINCT circuits.name FROM circuits "
        "JOIN races ON circuits.circuitId = races.circuitId "
        "WHERE NOT EXISTS (SELECT 1 FROM lapTimes);"
    )
    solution = set(ref.fetchall())
    assert solution == set()  # sanity-check: lapTimes is non-empty in the test DB
    assert result == solution


def test_circuits_with_races(session):
    r = session.execute(
        "SELECT DISTINCT circuits.name FROM circuits "
        "JOIN races ON circuits.circuitId = races.circuitId;"
    )
    solution = set(r.fetchall())
    assert len(solution) > 0

    name = Variable("name")
    circuitId = Variable("circuitId")
    raceId = Variable("raceId")
    dc = DomainCalculus(
        Result([name]),
        Exists(
            {circuitId, raceId},
            And(
                Tuple("circuits", [circuitId, None, name, None, None, None, None]),
                Tuple("races", [raceId, None, None, circuitId, None, None, None]),
            ),
        ),
    )
    r = session.execute(dc.to_sql())
    result = set(r.fetchall())

    assert solution == result


def test_not_tuple_shared_result_variable(session):
    # Regression test for result_tuples misclassification:
    # Not(Tuple('races', [..., circuitId, ...])) must generate NOT EXISTS, not NATURAL JOIN,
    # even though circuitId is also a result variable that appears in the circuits tuple.
    r = session.execute(
        "SELECT DISTINCT circuitId FROM circuits "
        "WHERE NOT EXISTS (SELECT 1 FROM races WHERE races.circuitId = circuits.circuitId);"
    )
    solution = set(r.fetchall())

    circuitId = Variable("circuitId")
    dc = DomainCalculus(
        Result([circuitId]),
        And(
            Tuple("circuits", [circuitId, None, None, None, None, None, None]),
            Not(Tuple("races", [None, None, None, circuitId, None, None, None])),
        ),
    )
    r = session.execute(dc.to_sql())
    result = set(r.fetchall())

    assert solution == result


def test_or_not_tuple_not_exists_shared_result_variable(session):
    # Regression test: Or(Not(Tuple), Not(Exists(...))) where the inner tuple shares a
    # result variable must correctly use NOT EXISTS for both branches.
    # Expression A: circuits with no races at all.
    # Expression B: circuits with no races OR no races before 2010.
    # Since A implies B, Or(A, B) = B, so B should return >= results than A.
    circuitId = Variable("circuitId")
    raceId = Variable("raceId")
    year = Variable("year")

    expr_a = DomainCalculus(
        Result([circuitId]),
        And(
            Tuple("circuits", [circuitId, None, None, None, None, None, None]),
            Not(Tuple("races", [None, None, None, circuitId, None, None, None])),
        ),
    )

    expr_b = DomainCalculus(
        Result([circuitId]),
        And(
            Tuple("circuits", [circuitId, None, None, None, None, None, None]),
            Or(
                Not(Tuple("races", [None, None, None, circuitId, None, None, None])),
                Not(
                    Exists(
                        {raceId, year},
                        And(
                            Tuple(
                                "races", [raceId, year, None, circuitId, None, None, None]
                            ),
                            LessThan(year, 2010),
                        ),
                    )
                ),
            ),
        ),
    )

    result_a = set(session.execute(expr_a.to_sql()).fetchall())
    result_b = set(session.execute(expr_b.to_sql()).fetchall())

    # B has an extra Or branch so it must return at least as many results as A
    assert result_a.issubset(result_b)

    # B should match the reference SQL (Or(A,B)=B since A⊆B semantically)
    r = session.execute(
        "SELECT DISTINCT circuitId FROM circuits "
        "WHERE NOT EXISTS ("
        "    SELECT 1 FROM races"
        "    WHERE races.circuitId = circuits.circuitId AND year < 2010"
        ");"
    )
    solution = set(r.fetchall())
    assert len(solution) > 0
    assert result_b == solution


def test_fastest_race_laps(session):
    r = session.execute(
        """SELECT circuits.name, drivers.forename, drivers.surname, lapTimes.milliseconds
        FROM circuits
        JOIN races ON circuits.circuitId = races.circuitId
        JOIN lapTimes ON races.raceId = lapTimes.raceId
        JOIN drivers ON lapTimes.driverId = drivers.driverId
        WHERE NOT EXISTS (
            SELECT *
            FROM lapTimes lT
            WHERE lT.raceId = lapTimes.raceId
            AND (lapTimes.driverID != lT.driverID OR lapTimes.lap != lT.lap)
            AND lapTimes.milliseconds < lT.milliseconds
        );"""
    )
    solution = set(r.fetchall())
    assert len(solution) > 0

    cN = Variable("cN")
    dF = Variable("dF")
    dS = Variable("dS")
    lM = Variable("lM")
    lL = Variable("lL")

    cI = Variable("cI")
    dI = Variable("dI")
    rI = Variable("rI")

    dI2 = Variable("dI2")
    lM2 = Variable("lM2")
    lL2 = Variable("lL2")
    dc = DomainCalculus(
        Result([cN, dF, dS, lM]),
        Exists(
            {cI, dI, rI},
            And(
                Tuple("races", [rI, None, None, cI, None, None, None]),
                And(
                    Tuple("circuits", [cI, None, cN, None, None, None, None]),
                    And(
                        Tuple("drivers", [dI, None, None, None, dF, dS, None, None]),
                        And(
                            Tuple("lapTimes", [rI, dI, lL, None, None, lM]),
                            Not(
                                Exists(
                                    {dI2, lM2, lL2},
                                    And(
                                        Tuple(
                                            "lapTimes", [rI, dI2, lL2, None, None, lM2]
                                        ),
                                        And(
                                            Or(
                                                Not(Equals(dI, dI2)),
                                                Not(Equals(lL, lL2)),
                                            ),
                                            LessThan(lM, lM2),
                                        ),
                                    ),
                                )
                            ),
                        ),
                    ),
                ),
            ),
        ),
    )
    r = session.execute(dc.to_sql())
    result = set(r.fetchall())

    assert solution == result


def test_issue_1():
    playername = Variable('playername')
    playerid = Variable('playerid')

    # p2 = Variable('p2')
    w1 = Variable('w1')
    w2 = Variable('w2')

    result = Result([playername, playerid])
    # , p2, w1, w2, w3, w4

    formula = And(
        Tuple('Player', [playerid, playername, None, None, None, None, None]),

        Not(Tuple('HeadToHead', [None, playerid, None, None, None, None]))

    )

    expression = DomainCalculus(result, formula)
    print(expression.to_sql())