from relational_calculus.domain_calculus import *


def test_or_nested_and():
    a, b, c = Equals(1, 2), Equals(3, 4), Equals(5, 6)
    result = repr(Or(And(a, b), c))
    assert result == f"({a} \\land {b}) \\lor {c}"


def test_or_nested_left():
    a, b, c = Equals(1, 2), Equals(3, 4), Equals(5, 6)
    result = repr(Or(Or(a, b), c))
    assert r"\land" not in result
    assert result == f"{a} \\lor {b} \\lor {c}"


def test_or_nested_right():
    a, b, c = Equals(1, 2), Equals(3, 4), Equals(5, 6)
    result = repr(Or(a, Or(b, c)))
    assert r"\land" not in result
    assert result == f"{a} \\lor {b} \\lor {c}"
