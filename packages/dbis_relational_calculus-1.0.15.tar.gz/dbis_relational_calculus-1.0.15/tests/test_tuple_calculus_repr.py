from relational_calculus.tuple_calculus import *


def test_forall_single_variable_atom_child():
    v = Variable("x", "Rel")
    result = repr(Forall(v, Equals(1, 1)))
    assert result == r"\forall \text{x} \in \text{REL} (\text{1} = \text{1})"


def test_forall_single_variable_and_child():
    v = Variable("x", "Rel")
    result = repr(Forall(v, And(Equals(1, 1), Equals(2, 2))))
    assert result == (
        r"\forall \text{x} \in \text{REL} "
        r"(\text{1} = \text{1} \land \text{2} = \text{2})"
    )


def test_forall_single_variable_nested_forall():
    v1 = Variable("x", "Rel")
    v2 = Variable("y", "Rel2")
    result = repr(Forall(v1, Forall(v2, Equals(1, 1))))
    assert result == (
        r"\forall \text{x} \in \text{REL} "
        r"(\forall \text{y} \in \text{REL2} (\text{1} = \text{1}))"
    )


def test_forall_single_variable_exists_child():
    v1 = Variable("x", "Rel")
    v2 = Variable("y", "Rel2")
    result = repr(Forall(v1, Exists(v2, Equals(1, 1))))
    assert result == (
        r"\forall \text{x} \in \text{REL} "
        r"(\exists \text{y} \in \text{REL2} (\text{1} = \text{1}))"
    )


def test_forall_set_one_variable():
    # Single-element set exercises the set code path but produces deterministic output.
    v = Variable("x", "Rel")
    result = repr(Forall({v}, Equals(1, 1)))
    assert result == r"\forall \text{x} \in \text{REL} (\text{1} = \text{1})"


def test_exists_single_variable_atom_child():
    v = Variable("x", "Rel")
    result = repr(Exists(v, Equals(1, 1)))
    assert result == r"\exists \text{x} \in \text{REL} (\text{1} = \text{1})"


def test_exists_set_one_variable():
    v = Variable("x", "Rel")
    result = repr(Exists({v}, Equals(1, 1)))
    assert result == r"\exists \text{x} \in \text{REL} (\text{1} = \text{1})"


def test_exists_set_multiple_variables():
    vx = Variable("x", "T1")
    vy = Variable("y", "T2")
    result = repr(Exists({vx, vy}, Equals(1, 1)))
    assert result.startswith(r"\exists ")
    assert result.endswith(r"(\text{1} = \text{1})")
    assert r"\text{x} \in \text{T1}" in result
    assert r"\text{y} \in \text{T2}" in result


def test_forall_set_multiple_variables():
    # set iteration order is non-deterministic, so check structure instead of exact string.
    vx = Variable("x", "T1")
    vy = Variable("y", "T2")
    result = repr(Forall({vx, vy}, Equals(1, 1)))

    assert result.startswith(r"\forall ")
    assert result.endswith(r"(\text{1} = \text{1})")
    assert r"\text{x} \in \text{T1}" in result
    assert r"\text{y} \in \text{T2}" in result
