from __future__ import annotations

import json
import time

from mycel_cli.identity_store import IdentityStore
from mycel_cli.daemon.inbox_cache import status_path
from mycel_cli.daemon.surfaces import lookup
from mycel_cli.daemon.task_status import read_task_status


def identity_summary() -> str:
    local_ids = sorted(IdentityStore.from_env().identities())
    if not local_ids:
        return "Identities: none"
    return "Identities: " + ", ".join(local_ids)


def identity_backend_summary() -> str:
    identities = IdentityStore.from_env().identities()
    if not identities:
        return "Identity Backends: none"
    values = [
        f"{local_id} -> {identity['base_url']}"
        for local_id, identity in sorted(identities.items())
    ]
    return "Identity Backends: " + ", ".join(values)


def subscriber_summary(
    *,
    now: float | None = None,
    stale_after_seconds: float = 90.0,
    daemon_running: bool = False,
) -> str:
    local_ids = sorted(IdentityStore.from_env().identities())
    if not local_ids:
        return "Inbox Subscribers: none"
    checked_at = time.time() if now is None else now
    return "Inbox Subscribers: " + ", ".join(
        _subscriber_label(
            local_id,
            now=checked_at,
            stale_after_seconds=stale_after_seconds,
            daemon_running=daemon_running,
        )
        for local_id in local_ids
    )


def _subscriber_label(
    local_id: str,
    *,
    now: float,
    stale_after_seconds: float,
    daemon_running: bool,
) -> str:
    path = status_path(local_id)
    if not path.exists():
        if daemon_running:
            return f"{local_id} restart needed"
        return f"{local_id} missing"
    payload = json.loads(path.read_text(encoding="utf-8") or "{}")
    backend = str(payload.get("backend_base_url") or "unknown backend")
    last_error = str(payload.get("last_error") or "").strip()
    if payload.get("state") == "dead":
        detail = f": {last_error}" if last_error else ""
        return f"{local_id} dead at {backend}{detail}"
    if payload.get("state") == "degraded" and last_error:
        count = int(payload.get("consecutive_error_count") or 1)
        return (
            f"{local_id} degraded at {backend} "
            f"({count} consecutive errors): {last_error}"
        )
    if last_error:
        return f"{local_id} error at {backend}: {last_error}"
    if payload.get("state") == "streaming":
        return f"{local_id} ok at {backend}"
    latest = (
        payload.get("last_stream_started_at")
        or payload.get("last_drain_started_at")
        or payload.get("last_error_at")
        or payload.get("last_event_at")
    )
    if latest is None or now - float(latest) > stale_after_seconds:
        return f"{local_id} stale at {backend}"
    return f"{local_id} ok at {backend}"


def freeform_surface_summary() -> str:
    local_ids = sorted(IdentityStore.from_env().identities())
    if not local_ids:
        return "Freeform Surfaces: none"
    return "Freeform Surfaces: " + ", ".join(
        _surface_label(local_id) for local_id in local_ids
    )


def _surface_label(local_id: str) -> str:
    ref = lookup(local_id)
    if ref is None:
        return f"{local_id} missing"
    return f"{local_id} tracked {ref.terminal_type} {ref.target_id}"


def group_loop_summary(*, daemon_running: bool = False) -> str:
    if not daemon_running:
        return "Group Loop: stopped"
    payload = read_task_status("group-loop")
    if payload is None:
        return "Group Loop: unknown"
    state = str(payload.get("state") or "unknown")
    if state in {"degraded", "fatal"}:
        return f"Group Loop: {state} ({_group_loop_error_label(payload)})"
    return f"Group Loop: {state}"


def _group_loop_error_label(payload: dict) -> str:
    group = str(payload.get("group") or "main")
    error_type = str(payload.get("error_type") or "Error")
    last_error = str(payload.get("last_error") or "").strip()
    detail = f": {last_error}" if last_error else ""
    return f"{group}: {error_type}{detail}"
