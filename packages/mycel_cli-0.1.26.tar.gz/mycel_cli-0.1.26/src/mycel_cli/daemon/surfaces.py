from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Mapping

from mycel_cli.group.terminal import get_terminal, terminal_type_from_env
from mycel_cli.daemon.paths import surface_path


@dataclass(frozen=True)
class SurfaceRef:
    local_id: str
    terminal_type: str
    target_id: str
    wrapper_pid: int
    wrapper_start_time: float
    registered_at: float


def register_from_env(
    env: Mapping[str, str], *, pid: int | None = None
) -> SurfaceRef | None:
    local_id = str(env.get("MYCEL_LOCAL_ID") or "")
    if not local_id or is_group_role_identity(local_id):
        return None
    terminal_type = terminal_type_from_env(env)
    if terminal_type is None:
        return None
    wrapper_pid = os.getpid() if pid is None else pid
    target_id = get_terminal(terminal_type).resolve_target_id(wrapper_pid)
    if target_id is None:
        return None
    ref = SurfaceRef(
        local_id=local_id,
        terminal_type=terminal_type,
        target_id=target_id,
        wrapper_pid=wrapper_pid,
        wrapper_start_time=process_start_time(wrapper_pid),
        registered_at=time.time(),
    )
    path = surface_path(local_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(asdict(ref), ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)
    return ref


def lookup(local_id: str) -> SurfaceRef | None:
    path = surface_path(local_id)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        ref = SurfaceRef(
            local_id=str(payload["local_id"]),
            terminal_type=str(payload["terminal_type"]),
            target_id=str(payload["target_id"]),
            wrapper_pid=int(payload["wrapper_pid"]),
            wrapper_start_time=float(payload["wrapper_start_time"]),
            registered_at=float(payload["registered_at"]),
        )
        _assert_same_process(ref.wrapper_pid, ref.wrapper_start_time)
        _assert_same_target(ref)
    except Exception:
        path.unlink(missing_ok=True)
        return None
    return ref


def drop(local_id: str) -> None:
    surface_path(local_id).unlink(missing_ok=True)


def unregister_from_env(
    env: Mapping[str, str],
    *,
    pid: int | None = None,
    start_time: float | None = None,
) -> None:
    local_id = str(env.get("MYCEL_LOCAL_ID") or "")
    if not local_id:
        return
    path = surface_path(local_id)
    if not path.exists():
        return
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        path.unlink(missing_ok=True)
        return
    wrapper_pid = os.getpid() if pid is None else pid
    wrapper_start_time = (
        process_start_time(wrapper_pid) if start_time is None else start_time
    )
    if (
        int(payload.get("wrapper_pid") or -1) == wrapper_pid
        and abs(float(payload.get("wrapper_start_time") or -1) - wrapper_start_time)
        < 0.5
    ):
        path.unlink(missing_ok=True)


def is_group_role_identity(local_id: str) -> bool:
    from mycel_cli.group._state.groups import list_groups, load_group
    from mycel_cli.group._state.roles import iter_roles

    for group_id in list_groups():
        group = load_group(group_id)
        if not group:
            continue
        for user in iter_roles(group):
            if user.get("session") == local_id or user.get("local_id") == local_id:
                return True
    return False


def process_start_time(pid: int) -> float:
    proc_stat = Path("/proc") / str(pid) / "stat"
    if proc_stat.exists():
        ticks = os.sysconf(os.sysconf_names["SC_CLK_TCK"])
        boot_time = _linux_boot_time()
        stat_fields = proc_stat.read_text(encoding="utf-8").split()
        return boot_time + (int(stat_fields[21]) / ticks)
    completed = subprocess.run(
        ["ps", "-o", "lstart=", "-p", str(pid)],
        text=True,
        capture_output=True,
        check=False,
    )
    text = completed.stdout.strip()
    if completed.returncode != 0 or not text:
        raise RuntimeError(f"process {pid} is not running")
    return datetime.strptime(text, "%a %b %d %H:%M:%S %Y").timestamp()


def _assert_same_process(pid: int, start_time: float) -> None:
    os.kill(pid, 0)
    if abs(process_start_time(pid) - start_time) >= 0.5:
        raise RuntimeError("surface wrapper process identity changed")


def _assert_same_target(ref: SurfaceRef) -> None:
    # @@@surface-proof - runtime surfaces are valid only while the terminal backend can rediscover the same target.
    current_target = get_terminal(ref.terminal_type).resolve_target_id(ref.wrapper_pid)
    if current_target != ref.target_id:
        raise RuntimeError("surface terminal target changed")


def _linux_boot_time() -> float:
    for line in Path("/proc/stat").read_text(encoding="utf-8").splitlines():
        if line.startswith("btime "):
            return float(line.split()[1])
    raise RuntimeError("could not read Linux boot time")
