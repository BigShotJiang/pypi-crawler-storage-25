from __future__ import annotations

import threading
import time
from collections.abc import Callable
from typing import Any

from mycel_sdk import Client

from mycel_cli.identity_store import IdentityStore
from mycel_cli.daemon.ipc import serve as serve_ipc
from mycel_cli.daemon.subscriber import run_loop as run_subscriber_loop
from mycel_cli.daemon.task_status import write_task_status


SubscriberLoop = Callable[..., None]
ClientFactory = Callable[..., Any]
GroupLoop = Callable[[], None]
IpcServer = Callable[..., None]


def run_daemon(
    *,
    client_factory: ClientFactory = Client,
    subscriber_loop: SubscriberLoop = run_subscriber_loop,
    ipc_server: IpcServer = serve_ipc,
    group_loop: GroupLoop | None = None,
) -> None:
    stop_event = threading.Event()
    _start_ipc_thread(stop_event=stop_event, ipc_server=ipc_server)
    _start_subscriber_threads(
        client_factory=client_factory,
        subscriber_loop=subscriber_loop,
    )
    if group_loop is None:
        from mycel_cli.group._workflow.loop import run_group_workflow_loop as group_loop

    group_failed = threading.Event()
    group_task = _start_group_thread(group_loop=group_loop, failed_event=group_failed)
    try:
        while not stop_event.is_set():
            group_task.join(timeout=0.25)
            if group_task.is_alive():
                continue
            if group_failed.is_set():
                # @@@daemon-owner - keep IPC/subscribers alive so status can expose the failed sibling task.
                stop_event.wait(0.25)
                continue
            break
    finally:
        stop_event.set()


def _start_subscriber_threads(
    *,
    client_factory: ClientFactory,
    subscriber_loop: SubscriberLoop,
) -> list[threading.Thread]:
    threads: list[threading.Thread] = []
    for local_id, identity in sorted(IdentityStore.from_env().identities().items()):
        base_url = str(identity["base_url"])
        client = client_factory(
            auth_token=str(identity["auth_token"]),
            base_url=base_url,
        )
        thread = threading.Thread(
            target=subscriber_loop,
            kwargs={
                "client": client,
                "local_id": local_id,
                "backend_base_url": base_url,
            },
            name=f"mycel-subscriber-{local_id}",
            daemon=True,
        )
        thread.start()
        threads.append(thread)
    return threads


def _start_ipc_thread(
    *, stop_event: threading.Event, ipc_server: IpcServer
) -> threading.Thread:
    ready_event = threading.Event()
    thread = threading.Thread(
        target=ipc_server,
        kwargs={"stop_event": stop_event, "ready_event": ready_event},
        name="mycel-daemon-ipc",
        daemon=True,
    )
    thread.start()
    if not ready_event.wait(1.0):
        raise RuntimeError("daemon IPC server did not start")
    return thread


def _start_group_thread(
    *, group_loop: GroupLoop, failed_event: threading.Event
) -> threading.Thread:
    thread = threading.Thread(
        target=_run_group_loop,
        kwargs={"group_loop": group_loop, "failed_event": failed_event},
        name="mycel-group-loop",
        daemon=True,
    )
    thread.start()
    return thread


def _run_group_loop(*, group_loop: GroupLoop, failed_event: threading.Event) -> None:
    try:
        group_loop()
    except Exception as exc:
        failed_event.set()
        write_task_status(
            "group-loop",
            {
                "state": "fatal",
                "group": "main",
                "last_tick_at": time.time(),
                "error_type": exc.__class__.__name__,
                "last_error": str(exc),
            },
        )


if __name__ == "__main__":
    run_daemon()
