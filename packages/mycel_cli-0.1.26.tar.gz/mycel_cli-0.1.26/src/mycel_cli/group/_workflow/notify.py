"""Outbound notifications to supervisor / reviewers.

All `send_text` calls are wrapped in `send_to_surface`: best-effort, exceptions
logged with traceback, never raised to the group workflow loop.

Terminal routing goes through `mycel_cli.group.terminal`; tests patch that owner
directly instead of a group workflow facade.
"""

from __future__ import annotations

from typing import Any
from xml.sax.saxutils import escape as xml_escape

from mycel_cli.group import terminal as _terminal
from mycel_cli.group._cli.chat_transport import (
    user_id_for,
    group_chat_for,
)
from mycel_cli.group._workflow.constants import log
from mycel_cli.group._workflow.xml_format import build_event_xml
from mycel_cli.group._state.groups import group_terminal_type
from mycel_cli.group._state.tasks import list_tasks
from mycel_cli.group._state.roles import (
    find_supervisor,
    iter_reviewer_roles,
    role_ready,
    role_target_id,
)


def send_to_surface(terminal_type: str, target_id: str, message: str) -> bool:
    """Best-effort send. Returns True on success, False on failure (logged with traceback)."""
    try:
        _terminal.get_terminal(terminal_type).send_text(target_id, message)
        return True
    except Exception:
        log.exception(
            "send to terminal=%s target=%s failed (msg head=%r)",
            terminal_type,
            target_id,
            message[:80],
        )
        return False


def notify_supervisor(group: dict[str, Any], message: str) -> None:
    """通知 group 的 supervisor。claim 缺失或 target_id 未缓存则丢事件。"""
    group_name = group.get("name", "?")
    sup = find_supervisor(group)
    if not sup:
        # 主循环理应过滤 unclaimed group，到这就是 invariant 破了。warning 而不是 debug。
        log.warning(
            "notify_supervisor called on group %r with no supervisor — invariant violation, dropping: %s",
            group_name,
            message[:80],
        )
        return
    terminal_type = group_terminal_type(group)
    target_id = role_target_id(sup)
    if not target_id:
        log.warning(
            "Supervisor for group %r has no target_id in cache, dropping event",
            group_name,
        )
        return
    # 替换换行符，避免 Escape 打断 Supervisor 正在运行的 generation
    safe_message = message.replace("\n", " ")
    log.info(
        "→ Supervisor[%s] %s: %s",
        group_name,
        target_id[:8],
        safe_message[:120],
    )
    send_to_surface(terminal_type, target_id, safe_message)


def notify_supervisor_from_role(
    *,
    group_id: str,
    group: dict[str, Any],
    sender: dict[str, Any],
    message: str,
) -> None:
    """Send a role-originated daemon event through Mycel chat, then wake supervisor."""
    supervisor = find_supervisor(group)
    if not supervisor:
        log.warning(
            "notify_supervisor_from_role called on group %r with no supervisor",
            group_id,
        )
        return
    sender_role = str(sender["role"])
    sender_session = str(sender["session"])
    try:
        client, chat_id = group_chat_for(
            group_id=group_id,
            sender=sender,
            recipient=supervisor,
        )
        client.messages.send(
            chat_id,
            message,
            delivery_scope="addressed",
            addressed_to_user_ids=[user_id_for(supervisor)],
        )
    except Exception:
        log.exception(
            "role-originated supervisor chat failed [%s/%s -> %s]",
            group_id,
            sender.get("session"),
            supervisor.get("session"),
        )
        return

    target_id = role_target_id(supervisor)
    if not target_id:
        log.info(
            "Supervisor for group %r has no target_id; chat event stored without terminal wake",
            group_id,
        )
        return

    wake = (
        f"New Mycel group message from {sender_role} in chat {chat_id} "
        f"for group {group_id}. Read it with "
        f"`cel group {group_id} supervisor read {sender_session}`."
    )
    send_to_surface(group_terminal_type(group), target_id, wake)


def notify_reviewer(
    group: dict[str, Any], reviewer: dict[str, Any], message: str
) -> None:
    """通知单个 reviewer。reviewer 必须有 cache.target_id。"""
    group_name = group.get("name", "?")
    reviewer_id = reviewer.get("id", "?")
    terminal_type = group_terminal_type(group)
    target_id = role_target_id(reviewer)
    if not target_id:
        log.warning(
            "Reviewer %s/%s has no target_id in cache, dropping message",
            group_name,
            reviewer_id,
        )
        return
    safe_message = message.replace("\n", " ")
    log.info(
        "→ Reviewer[%s/%s] %s: %s",
        group_name,
        reviewer_id,
        target_id[:8],
        safe_message[:120],
    )
    send_to_surface(terminal_type, target_id, safe_message)


def notify_all_reviewers(
    group: dict[str, Any],
    message: str,
    *,
    reviewer_ids: set[str] | None = None,
) -> None:
    """通知 group 的所有 reviewers。session 不可达的 reviewer 静默跳过。"""
    group_name = group.get("name", "?")
    reviewers = [
        {
            **user,
            "id": user.get("session"),
        }
        for user in iter_reviewer_roles(group)
        if user.get("status") == "active" and role_ready(user)
    ]
    if not reviewers:
        log.debug("No reviewers for group %r", group_name)
        return
    for reviewer in reviewers:
        reviewer_id = reviewer.get("id")
        if reviewer_ids is not None and reviewer_id not in reviewer_ids:
            continue
        try:
            notify_reviewer(group, reviewer, message)
        except Exception as e:
            log.warning("Failed to notify reviewer %s: %s", reviewer_id, e)


def sync_group_to_reviewers(group_name: str, group: dict[str, Any]) -> None:
    """推送最新 group 内容（prompt + tasks 摘要）给所有 reviewers。纯信息同步，无判决。"""
    reviewers = [
        {
            **user,
            "id": user.get("session"),
        }
        for user in iter_reviewer_roles(group)
        if user.get("status") == "active" and role_ready(user)
    ]
    if not reviewers:
        return

    prompt = group.get("group_prompt") or "(未设置)"
    tasks = list_tasks(group_name)
    if tasks:
        lines = [f"#{t['id']} [{t['status']}] {t['subject']}" for t in tasks]
        tasks_summary = "\n".join(lines)
    else:
        tasks_summary = "(无 task)"

    body = xml_escape(
        f"Group {group_name} 信息同步:\nPrompt: {prompt}\nTasks:\n{tasks_summary}"
    )
    msg = build_event_xml(
        "group_sync",
        {"group": group_name},
        body,
    )
    for reviewer in reviewers:
        try:
            notify_reviewer(group, reviewer, msg)
        except Exception as e:
            log.warning(
                "Failed to sync group to reviewer %s: %s", reviewer.get("id"), e
            )
