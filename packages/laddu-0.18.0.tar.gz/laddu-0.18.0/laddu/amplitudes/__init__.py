# ruff: noqa: RUF002
"""High-level amplitude construction helpers.

This module re-exports the Rust-backed amplitude building blocks as a cohesive Python API.

Examples
--------
>>> from laddu.amplitudes import common, parameter
>>> scalar = common.Scalar('mag', parameter('mag'))  # overall magnitude
>>> rho = common.ComplexScalar('rho', (parameter('rho_re'), parameter('rho_im')))
>>> expr = scalar * rho
>>> expr
×
├─ mag(id=0)
└─ rho(id=1)
<BLANKLINE>

Use :mod:`laddu.amplitudes.breit_wigner` or the other submodules for concrete physics models.
"""

from laddu.laddu import (
    CompiledExpression,
    Evaluator,
    Expression,
    One,
    Parameter,
    TestAmplitude,
    Zero,
    expr_product,
    expr_sum,
    parameter,
)

from . import (
    breit_wigner,
    common,
    flatte,
    kmatrix,
    lookup_table,
    phase_space,
    spin_factors,
    voigt,
    ylm,
    zlm,
)

__all__ = [
    'CompiledExpression',
    'Evaluator',
    'Expression',
    'One',
    'Parameter',
    'TestAmplitude',
    'Zero',
    'breit_wigner',
    'common',
    'expr_product',
    'expr_sum',
    'flatte',
    'kmatrix',
    'lookup_table',
    'parameter',
    'phase_space',
    'spin_factors',
    'voigt',
    'ylm',
    'zlm',
]
