"""Shared fixtures for external agent E2E tests.

These tests verify that external agent frameworks can connect to
Volnix via HTTP and MCP transports, discover tools, and execute
actions through the full 7-step governance pipeline.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from volnix.engines.adapter.protocols.http_rest import HTTPRestAdapter


def _make_gateway_with_tools(
    *,
    tools: list[dict[str, Any]] | None = None,
    handle_result: dict[str, Any] | None = None,
):
    """Create a mock Gateway with realistic ticket/email tools."""
    from volnix.core.context import StepResult
    from volnix.core.types import StepVerdict

    gateway = MagicMock()

    mcp_tools = tools or [
        {
            "name": "tickets.list",
            "description": "List tickets with optional filters",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "status": {"type": "string"},
                    "page": {"type": "integer"},
                },
            },
        },
        {
            "name": "tickets.read",
            "description": "Show a single ticket by ID",
            "inputSchema": {
                "type": "object",
                "properties": {"id": {"type": "string"}},
                "required": ["id"],
            },
        },
        {
            "name": "tickets.update",
            "description": "Update ticket fields",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "status": {"type": "string"},
                },
                "required": ["id"],
            },
        },
        {
            "name": "tickets.comment_create",
            "description": "Add a comment to a ticket",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "body": {"type": "string"},
                    "public": {"type": "boolean"},
                },
                "required": ["id", "body"],
            },
        },
        {
            "name": "customers.read",
            "description": "Show a user by ID",
            "inputSchema": {
                "type": "object",
                "properties": {"id": {"type": "string"}},
                "required": ["id"],
            },
        },
        {
            "name": "users.messages.send",
            "description": "Send an email message",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "to": {"type": "string"},
                    "subject": {"type": "string"},
                    "body": {"type": "string"},
                },
                "required": ["to", "subject", "body"],
            },
        },
    ]
    gateway.get_tool_manifest = AsyncMock(return_value=mcp_tools)

    # Realistic ticket response (Zendesk-style wrapper)
    default_result = handle_result or {
        "ticket": {
            "id": "ticket-001",
            "subject": "Broken API integration",
            "status": "open",
            "requester_id": "user-042",
            "priority": "high",
            "created_at": "2026-03-23T10:00:00Z",
            "updated_at": "2026-03-23T10:00:00Z",
        },
    }
    gateway.handle_request = AsyncMock(return_value=default_result)

    # Mock app internals
    permission_engine = AsyncMock()
    permission_engine.execute = AsyncMock(
        return_value=StepResult(step_name="permission", verdict=StepVerdict.ALLOW)
    )
    registry = MagicMock()
    registry.get = MagicMock(return_value=permission_engine)

    bus = MagicMock()
    bus.subscribe = AsyncMock()
    bus.unsubscribe = AsyncMock()

    mock_app = MagicMock()
    mock_app.registry = registry
    mock_app.bus = bus
    gateway._app = mock_app

    return gateway


@pytest.fixture
async def volnix_http_adapter():
    """HTTPRestAdapter with mock gateway returning realistic ticket data."""
    gateway = _make_gateway_with_tools()
    adapter = HTTPRestAdapter(gateway)
    await adapter.start_server()
    yield adapter, gateway
    await adapter.stop_server()


@pytest.fixture
def http_transport(volnix_http_adapter):
    """httpx ASGITransport for direct ASGI testing (no real server)."""
    adapter, _gw = volnix_http_adapter
    return httpx.ASGITransport(app=adapter.fastapi_app)
