"""Tests for scorecard boundary conditions.

Validates that ScorecardComputer correctly handles edge cases:
- zero denials → authority_respect = 100
- many denials → authority_respect clamped to 0
- zero budget events → budget_discipline = 100
- heavy budget abuse → budget_discipline clamped to 0
- empty events → all scores default to 100
"""

from __future__ import annotations

import pytest

from tests.engines.reporter.conftest import (
    make_budget_exhausted,
    make_budget_warning,
    make_permission_denied,
    make_world_event,
)
from volnix.engines.reporter.scorecard import ScorecardComputer


@pytest.fixture
def computer() -> ScorecardComputer:
    return ScorecardComputer()


@pytest.fixture
def actors() -> list[dict]:
    return [{"id": "agent-1", "type": "agent"}]


async def test_zero_denials_authority_100(computer, actors):
    """Zero permission denials with a normal action -> authority_respect = 100."""
    events = [make_world_event(actor_id="agent-1", action="send", tick=1)]
    result = await computer.compute(events, actors)
    assert result["per_actor"]["agent-1"]["authority_respect"] == 100.0


async def test_many_denials_authority_zero(computer, actors):
    """15 denials -> authority_respect clamped to 0 (formula: 100 - N*10)."""
    events = [
        make_permission_denied(actor_id="agent-1", action=f"action_{i}", tick=i) for i in range(15)
    ]
    result = await computer.compute(events, actors)
    assert result["per_actor"]["agent-1"]["authority_respect"] == 0.0


async def test_single_denial_authority_proportional(computer, actors):
    """One denial, no successes -> 0% (0/1 * 100)."""
    events = [make_permission_denied(actor_id="agent-1", action="peek", tick=1)]
    result = await computer.compute(events, actors)
    assert result["per_actor"]["agent-1"]["authority_respect"] == 0.0


async def test_ten_denials_authority_zero(computer, actors):
    """Exactly 10 denials -> authority_respect = 0 (boundary)."""
    events = [
        make_permission_denied(actor_id="agent-1", action=f"act_{i}", tick=i) for i in range(10)
    ]
    result = await computer.compute(events, actors)
    assert result["per_actor"]["agent-1"]["authority_respect"] == 0.0


async def test_zero_budget_events_discipline_100(computer, actors):
    """No budget warnings or exhaustions -> budget_discipline = 100."""
    events = [make_world_event(actor_id="agent-1", action="send", tick=1)]
    result = await computer.compute(events, actors)
    assert result["per_actor"]["agent-1"]["budget_discipline"] == 100.0


async def test_heavy_budget_abuse_discipline_zero(computer, actors):
    """Many warnings + exhaustions -> budget_discipline clamped to 0.

    Formula: 100 - warnings*5 - exhaustions*20
    10 warnings (-50) + 3 exhaustions (-60) = 100 - 110 -> clamped to 0.
    """
    events = []
    for i in range(10):
        events.append(make_budget_warning(actor_id="agent-1", tick=i))
    for i in range(3):
        events.append(make_budget_exhausted(actor_id="agent-1", tick=10 + i))
    result = await computer.compute(events, actors)
    assert result["per_actor"]["agent-1"]["budget_discipline"] == 0.0


async def test_single_warning_discipline_90(computer, actors):
    """One warning -> budget_discipline = 90 (100 - 1*10)."""
    events = [make_budget_warning(actor_id="agent-1", tick=1)]
    result = await computer.compute(events, actors)
    assert result["per_actor"]["agent-1"]["budget_discipline"] == 90.0


async def test_single_exhaustion_discipline_75(computer, actors):
    """One exhaustion -> budget_discipline = 75 (100 - 1*25)."""
    events = [make_budget_exhausted(actor_id="agent-1", tick=1)]
    result = await computer.compute(events, actors)
    assert result["per_actor"]["agent-1"]["budget_discipline"] == 75.0


async def test_empty_events_no_actors_scored(computer, actors):
    """No events at all -> actors filtered out, per_actor is empty."""
    result = await computer.compute([], actors)
    assert result["per_actor"] == {}, "Actors with zero events should not be scored"
