"""Tests for ActorPromptBuilder -- prompt assembly for actor action generation."""

from __future__ import annotations

import json
from datetime import UTC, datetime

from volnix.actors.state import ActorState, InteractionRecord
from volnix.core.events import WorldEvent
from volnix.core.types import ActorId, EntityId, ServiceId, Timestamp
from volnix.engines.agency.prompt_builder import (
    ACTION_OUTPUT_SCHEMA,
    BATCH_OUTPUT_SCHEMA,
    ActorPromptBuilder,
)
from volnix.simulation.world_context import WorldContextBundle


def _make_world_context() -> WorldContextBundle:
    return WorldContextBundle(
        world_description="A corporate helpdesk simulation.",
        reality_summary="Messy reality with occasional system failures.",
        mission="Evaluate agent support quality.",
        seeds=["VIP customer waiting 3 days for refund"],
        available_services=[
            {
                "name": "reply_ticket",
                "service": "helpdesk",
                "http_method": "POST",
                "description": "Reply to a ticket",
                "required_params": ["ticket_id", "text"],
            },
            {
                "name": "list_tickets",
                "service": "helpdesk",
                "http_method": "GET",
                "description": "List tickets",
                "required_params": [],
            },
            {
                "name": "email_search",
                "service": "email",
                "http_method": "GET",
                "description": "Search emails",
                "required_params": ["q"],
            },
        ],
    )


def _make_actor(**kwargs) -> ActorState:
    defaults = {
        "actor_id": ActorId("actor-alice"),
        "role": "support_agent",
        "actor_type": "internal",
        "current_goal": "Resolve ticket quickly",
        "goal_context": "Resolve ticket quickly",
        "persona": {"description": "Patient and thorough support agent"},
    }
    defaults.update(kwargs)
    return ActorState(**defaults)


def _make_event() -> WorldEvent:
    now = datetime.now(UTC)
    return WorldEvent(
        event_type="world.ticket_update",
        timestamp=Timestamp(world_time=now, wall_time=now, tick=5),
        actor_id=ActorId("agent-external"),
        service_id=ServiceId("helpdesk"),
        action="update_ticket",
        target_entity=EntityId("ticket-42"),
        input_data={"status": "escalated", "text": "This ticket needs attention"},
    )


def test_system_prompt_from_world_context():
    """System prompt includes world, mission, seeds — tools are in user prompt (per-actor)."""
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)

    prompt = builder.build_system_prompt()

    assert "## World" in prompt
    assert "corporate helpdesk" in prompt
    assert "## Mission" in prompt
    assert "Evaluate agent" in prompt
    assert "## World Scenarios" in prompt
    assert "VIP customer" in prompt
    # Tools are NOT in system prompt — they're rendered per-actor in user prompt
    assert "## Available Tools" not in prompt


def test_system_prompt_minimal():
    """System prompt works with minimal context."""
    ctx = WorldContextBundle(
        world_description="Simple world",
        reality_summary="Ideal",
    )
    builder = ActorPromptBuilder(ctx)

    prompt = builder.build_system_prompt()

    assert "## World" in prompt
    assert "Simple world" in prompt
    assert "## Mission" not in prompt
    assert "## Services" not in prompt


def test_individual_prompt_structure():
    """Individual prompt contains identity, instructions, context, trigger, output."""
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor()
    event = _make_event()

    prompt = builder.build_individual_prompt(
        actor=actor,
        trigger_event=event,
        activation_reason="event_affected",
        available_actions=[],
    )

    # Identity
    assert "support_agent" in prompt
    assert "actor-alice" in prompt
    assert "Patient and thorough" in prompt

    # Instructions
    assert "## Instructions" in prompt

    # Context
    assert "Mission Context" in prompt
    assert "Resolve ticket quickly" in prompt

    # Trigger
    assert "agent-external" in prompt
    assert "update_ticket" in prompt

    # Output
    assert "## Output" in prompt
    assert "do_nothing" in prompt


def test_individual_prompt_no_trigger():
    """Individual prompt works without a trigger event."""
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor()

    prompt = builder.build_individual_prompt(
        actor=actor,
        trigger_event=None,
        activation_reason="frustration_threshold",
        available_actions=[],
    )

    assert "frustration_threshold" in prompt
    assert "## Trigger\n**" not in prompt


def test_individual_prompt_with_interactions():
    """Individual prompt shows recent interactions with text."""
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor()
    actor.recent_interactions = [
        InteractionRecord(
            tick=1.0,
            actor_id="agent-external",
            actor_role="customer",
            action="reply_ticket",
            summary="I need help with my account",
            source="observed",
            event_id="evt-1",
        ),
        InteractionRecord(
            tick=2.0,
            actor_id="actor-alice",
            actor_role="support_agent",
            action="reply_ticket",
            summary="Let me look into that for you",
            source="self",
            event_id="evt-2",
        ),
    ]

    prompt = builder.build_individual_prompt(
        actor=actor,
        trigger_event=None,
        activation_reason="event_affected",
        available_actions=[],
    )

    assert "Your Investigation" in prompt or "Team Messages" in prompt
    assert "I need help with my account" in prompt
    assert "Let me look into that" in prompt


def test_individual_prompt_with_waiting():
    """Waiting_for is no longer rendered (internal engine state)."""
    from volnix.actors.state import WaitingFor

    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor(
        waiting_for=WaitingFor(
            description="Manager approval for refund",
            since=2.0,
            patience=10.0,
        )
    )

    prompt = builder.build_individual_prompt(
        actor=actor,
        trigger_event=None,
        activation_reason="wait_threshold",
        available_actions=[],
    )

    # Waiting_for is engine-internal, not shown in new prompt
    assert "wait_threshold" in prompt


def test_autonomous_prompt_has_team_and_instructions():
    """Autonomous agent prompt includes team channel and work instructions."""
    from volnix.actors.state import Subscription

    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor(autonomous=True)
    actor.team_channel = "#research"
    actor.subscriptions = [Subscription(service_id="slack", filter={"channel": "#research"})]

    prompt = builder.build_individual_prompt(
        actor=actor,
        trigger_event=None,
        activation_reason="autonomous_continue",
        available_actions=[{"name": "email_search", "http_method": "GET"}],
        team_roster=[
            {"role": "support_agent", "id": "actor-alice"},
            {"role": "manager", "id": "actor-bob"},
        ],
    )

    assert "#research" in prompt
    assert "INVESTIGATE" in prompt
    assert "SHARE your findings" in prompt
    assert "Action History" in prompt


def test_batch_prompt_structure():
    """Batch prompt contains actor sections."""
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)

    actor1 = _make_actor(actor_id=ActorId("actor-alice"), role="support_agent")
    actor2 = _make_actor(actor_id=ActorId("actor-bob"), role="manager")
    event = _make_event()

    prompt = builder.build_batch_prompt(
        actors_with_triggers=[
            (actor1, event, "event_affected"),
            (actor2, None, "frustration_threshold"),
        ],
        available_actions=[],
    )

    assert "Actor: support_agent (ID: actor-alice)" in prompt
    assert "event_affected" in prompt
    assert "Actor: manager (ID: actor-bob)" in prompt
    assert "frustration_threshold" in prompt


def test_batch_prompt_with_no_actions():
    """Batch prompt works without available actions."""
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor()

    prompt = builder.build_batch_prompt(
        actors_with_triggers=[(actor, None, "event_affected")],
        available_actions=[],
    )

    assert "Actor: support_agent" in prompt


def test_output_schemas_are_valid_json():
    """ACTION_OUTPUT_SCHEMA and BATCH_OUTPUT_SCHEMA are valid JSON-serializable dicts."""
    action_json = json.dumps(ACTION_OUTPUT_SCHEMA)
    assert json.loads(action_json) == ACTION_OUTPUT_SCHEMA

    batch_json = json.dumps(BATCH_OUTPUT_SCHEMA)
    assert json.loads(batch_json) == BATCH_OUTPUT_SCHEMA


def test_addressed_to_you_tag():
    """Messages addressed to the agent show [TO YOU] tag."""
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor(role="support_agent")
    actor.recent_interactions = [
        InteractionRecord(
            tick=1.0,
            actor_id="manager",
            actor_role="manager",
            action="chat.postMessage",
            summary="Please handle ticket 42",
            source="notified",
            event_id="evt-1",
            intended_for=["support_agent"],
        ),
    ]

    prompt = builder.build_individual_prompt(
        actor=actor,
        trigger_event=None,
        activation_reason="subscription_match",
        available_actions=[],
    )

    assert "[TO YOU]" in prompt
    assert "Please handle ticket 42" in prompt


def test_game_turn_prompt_skips_autonomous_instructions():
    """Game turn activations bypass the autonomous delegate/investigate block.

    For a non-observer autonomous actor, ``build_individual_prompt`` normally
    injects ``build_autonomous_instructions`` — which tells lead agents to
    DELEGATE and non-lead agents to INVESTIGATE/SHARE/call do_nothing. That
    is fundamentally wrong for a game player who should follow their own
    game persona (counter, accept, reject for negotiation; place orders
    for trading; etc.).

    When ``activation_reason`` is ``"game_kickstart"`` or ``"game_event"``
    the prompt must use game-specific instructions instead. This test is
    game-type-agnostic: it uses a generic player role and asserts only
    that the autonomous delegation vocabulary is absent.
    """
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor(
        actor_id=ActorId("player-1"),
        role="player",
        autonomous=True,
        is_lead=False,
    )

    prompt = builder.build_individual_prompt(
        actor=actor,
        trigger_event=None,
        activation_reason="game_event",
        available_actions=[],
        team_roster=[
            {"role": "player", "id": "player-1"},
            {"role": "opponent", "id": "player-2"},
        ],
    )

    # Autonomous instruction vocabulary must NOT appear in a game turn prompt
    forbidden = [
        "DELEGATE",
        "MONITOR",
        "BUFFER PERIOD",
        "Phase 1",
        "Phase 2",
        "Phase 3",
        "sub-agent",
        "orchestration",
        "INVESTIGATE",
    ]
    for word in forbidden:
        assert word not in prompt, (
            f"Autonomous-instructions word '{word}' leaked into game-turn prompt. "
            f"Game players must follow their own persona, not delegation patterns. "
            f"Prompt excerpt: {prompt[:800]}"
        )

    # Output format must NOT tell game players to call do_nothing as an
    # option. Any mention of do_nothing must be in a "Do NOT call" form.
    lowered = prompt.lower()
    if "do_nothing" in lowered:
        assert "do not" in lowered and "do_nothing" in lowered, (
            "Game players should not be told to call do_nothing as an option"
        )

    # Must include the game-player instruction marker
    assert "game player" in prompt.lower(), (
        "Game turn prompt must identify the actor as a game player"
    )


def test_lead_autonomous_still_gets_delegation_instructions():
    """Regression guard: non-game autonomous lead agents still get the
    delegation/monitor instructions. The game-turn branch only kicks in
    for ``activation_reason == "game_turn"`` — any other reason (e.g.
    ``subscription_match``, ``autonomous_work``) keeps the pre-existing
    autonomous behavior.
    """
    ctx = _make_world_context()
    builder = ActorPromptBuilder(ctx)
    actor = _make_actor(
        actor_id=ActorId("lead-1"),
        role="supervisor",
        autonomous=True,
        is_lead=True,
    )

    prompt = builder.build_individual_prompt(
        actor=actor,
        trigger_event=None,
        activation_reason="subscription_match",
        available_actions=[],
        team_roster=[
            {"role": "supervisor", "id": "lead-1"},
            {"role": "analyst", "id": "analyst-1"},
        ],
    )

    # Non-game lead should still see delegation-related content
    assert "team lead" in prompt.lower() or "orchestration" in prompt.lower(), (
        "Non-game autonomous lead agents should still get delegation instructions"
    )


# ─── Phase 4B Step 11 closeout — recalled memories rendering ──────────────


class _FakeRecord:
    """Minimal shim for MemoryRecord — the prompt builder only reads
    ``.content`` per D11-11, so we avoid the MemoryRecord validators
    (content_hash matching sha256, etc.) that are irrelevant here."""

    def __init__(self, content: str) -> None:
        self.content = content


class _FakeRecall:
    def __init__(self, records: list[_FakeRecord]) -> None:
        self.records = records


class TestActorPromptBuilderMemoriesRendering:
    """D11-10 / D11-11 — recalled memories section render contract.

    Negative-intent ratio: 2/4 = 50%.
    """

    def test_negative_none_renders_nothing(self) -> None:
        """Phase 0 byte-identical: None → zero bytes added."""
        ctx = _make_world_context()
        builder = ActorPromptBuilder(ctx)
        actor = _make_actor()

        prompt_without = builder.build_individual_prompt(
            actor=actor,
            trigger_event=None,
            activation_reason="autonomous_work",
            available_actions=[],
        )
        prompt_with_none = builder.build_individual_prompt(
            actor=actor,
            trigger_event=None,
            activation_reason="autonomous_work",
            available_actions=[],
            recalled_memories=None,
        )
        assert prompt_without == prompt_with_none

    def test_negative_empty_records_renders_nothing(self) -> None:
        """recall with ``.records == []`` also renders nothing —
        guards against a stray empty section heading."""
        ctx = _make_world_context()
        builder = ActorPromptBuilder(ctx)
        actor = _make_actor()
        empty = _FakeRecall(records=[])

        prompt = builder.build_individual_prompt(
            actor=actor,
            trigger_event=None,
            activation_reason="autonomous_work",
            available_actions=[],
            recalled_memories=empty,
        )
        assert "Memories you recall" not in prompt

    def test_positive_records_render_as_bullets(self) -> None:
        ctx = _make_world_context()
        builder = ActorPromptBuilder(ctx)
        actor = _make_actor()
        recall = _FakeRecall(
            records=[
                _FakeRecord("saw TK-9001 yesterday"),
                _FakeRecord("customer is VIP"),
            ]
        )

        prompt = builder.build_individual_prompt(
            actor=actor,
            trigger_event=None,
            activation_reason="autonomous_work",
            available_actions=[],
            recalled_memories=recall,
        )
        assert "### Memories you recall" in prompt
        assert "- saw TK-9001 yesterday" in prompt
        assert "- customer is VIP" in prompt

    def test_positive_records_appear_between_mission_and_pending_tasks(self) -> None:
        """D11-10: ordering matches cognition order
        (mission → memories → tasks → trigger). Uses unique markers
        so offsets are unambiguous."""
        ctx = _make_world_context()
        builder = ActorPromptBuilder(ctx)
        actor = _make_actor(
            current_goal="MARKER-MISSION",
            goal_context="MARKER-CONTEXT",
            pending_tasks=["MARKER-TASK"],
        )
        recall = _FakeRecall(records=[_FakeRecord("MARKER-MEMORY")])

        prompt = builder.build_individual_prompt(
            actor=actor,
            trigger_event=None,
            activation_reason="autonomous_work",
            available_actions=[],
            recalled_memories=recall,
        )
        pos_mission = prompt.find("MARKER-CONTEXT")
        pos_memory = prompt.find("MARKER-MEMORY")
        pos_task = prompt.find("MARKER-TASK")
        assert pos_mission >= 0 and pos_memory >= 0 and pos_task >= 0
        assert pos_mission < pos_memory < pos_task
