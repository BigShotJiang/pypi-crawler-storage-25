import os
from typing import Optional

from fastmcp import FastMCP
import psycopg2

conn_params = {
    'host': os.environ.get('PG_HOST', 'localhost'),
    'database': os.environ.get('PG_DATABASE', ''),
    'user': os.environ.get('PG_USER', ''),
    'password': os.environ.get('PG_PASSWORD', ''),
    'port': int(os.environ.get('PG_PORT', 5432))
}

DEFAULT_HOST = os.environ.get('MCP_HOST', '0.0.0.0')
DEFAULT_PORT = int(os.environ.get('MCP_PORT', 8000))

mcp = FastMCP("pg-mcp")

@mcp.tool()
def get_tables() -> Optional[list[str]]:
    """获取数据库中的所有表名

    Returns:
        数据库中的表名列表
    """
    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public'
            ORDER BY table_name
        """)

        tables = [row[0] for row in cursor.fetchall()]
        return tables

    except Exception as e:
        return [f"Error: {str(e)}"]
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@mcp.tool()
def get_table_columns(table_name: str) -> Optional[list[dict]]:
    """获取指定表的列名、数据类型和描述信息

    Args:
        table_name: 要查询的表名

    Returns:
        包含列信息的字典列表，每个字典包含column_name、data_type、description等字段
        如果表不存在或发生错误，返回包含错误信息的列表
    """
    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                AND table_name = %s
            )
        """, (table_name,))

        table_exists = cursor.fetchone()[0]
        if not table_exists:
            return [{"error": f"Table '{table_name}' does not exist in the public schema"}]

        cursor.execute("""
            SELECT
                c.column_name,
                c.data_type,
                c.is_nullable,
                c.column_default,
                CASE
                    WHEN pk.constraint_type = 'PRIMARY KEY' THEN TRUE
                    ELSE FALSE
                END as is_primary_key
            FROM information_schema.columns c
            LEFT JOIN (
                SELECT kcu.column_name, tc.constraint_type
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu
                    ON tc.constraint_name = kcu.constraint_name
                WHERE tc.table_schema = 'public'
                    AND tc.table_name = %s
                    AND tc.constraint_type = 'PRIMARY KEY'
            ) pk ON c.column_name = pk.column_name
            WHERE c.table_schema = 'public'
                AND c.table_name = %s
            ORDER BY c.ordinal_position
        """, (table_name, table_name))

        columns_info = []
        for row in cursor.fetchall():
            columns_info.append({
                "column_name": row[0],
                "data_type": row[1],
                "is_nullable": row[2] == 'YES',
                "column_default": row[3],
                "is_primary_key": row[4]
            })

        cursor.execute("""
            SELECT
                a.attname as column_name,
                pg_catalog.col_description(c.oid, a.attnum) as description
            FROM pg_class c
            JOIN pg_attribute a ON c.oid = a.attrelid
            WHERE c.relname = %s
                AND a.attnum > 0
                AND NOT a.attisdropped
            ORDER BY a.attnum
        """, (table_name,))

        descriptions = {}
        for row in cursor.fetchall():
            if row[1]:
                descriptions[row[0]] = row[1]

        for col_info in columns_info:
            col_info["description"] = descriptions.get(col_info["column_name"], "")

        return columns_info

    except Exception as e:
        return [{"error": f"Database error: {str(e)}"}]
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@mcp.tool()
def get_distinct_values_list(table_name: str, column_name: str, limit: int = 100) -> Optional[list]:
    """获取指定表中某一列的所有不同值列表

    Args:
        table_name: 表名
        column_name: 列名
        limit: 返回的最大不同值数量，默认100

    Returns:
        不同值的列表，如果数量超过限制，只返回前N个
    """
    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.columns
                WHERE table_schema = 'public'
                AND table_name = %s
                AND column_name = %s
            )
        """, (table_name, column_name))

        if not cursor.fetchone()[0]:
            return [f"Error: Column '{column_name}' does not exist in table '{table_name}'"]

        cursor.execute(f"""
            SELECT COUNT(DISTINCT {column_name})
            FROM {table_name}
        """)

        distinct_count = cursor.fetchone()[0]

        if distinct_count > limit:
            cursor.execute(f"""
                SELECT DISTINCT {column_name}
                FROM {table_name}
                WHERE {column_name} IS NOT NULL
                ORDER BY {column_name}
                LIMIT %s
            """, (limit,))

            values = [row[0] for row in cursor.fetchall()]

            return [f"Note: This column has {distinct_count} distinct values. Showing first {limit} values."] + values

        else:
            cursor.execute(f"""
                SELECT DISTINCT {column_name}
                FROM {table_name}
                WHERE {column_name} IS NOT NULL
                ORDER BY {column_name}
            """)

            values = [row[0] for row in cursor.fetchall()]

            cursor.execute(f"""
                SELECT EXISTS (
                    SELECT 1 FROM {table_name} WHERE {column_name} IS NULL
                )
            """)

            has_null = cursor.fetchone()[0]
            if has_null:
                values.append("NULL")

            return values

    except Exception as e:
        return [f"Error: {str(e)}"]
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@mcp.tool()
def get_ordered_gdp(district: str='宝安区', value_type: int = 1, limit: int = None, order_desc: bool = True) -> Optional[list[dict]]:
    """获取某一地区GDP数据，默认按统计日期降序排列

    Args:
        district: 地区，字符串类型，默认为宝安区
        value_type: 数值类型，对应于gdp表中的value_type字段，默认为1
        limit: 返回记录数量限制，默认不限制，默认为None
        order_desc: 是否按统计日期降序排列，默认为True，False则是按统计日期升序

    Returns:
        包含查询结果的字典列表，每个字典对应一行记录
    """
    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        sql = '''
            SELECT stat_date, current_growth, current_value, value_name, unit
            FROM "gdp"
            WHERE district = %s
                AND stat_freq = %s
                AND value_type = %s
        '''

        params = [district, '季度', value_type]

        if order_desc:
            sql += ' ORDER BY stat_date DESC'
        else:
            sql += ' ORDER BY stat_date ASC'

        if limit and limit > 0:
            sql += ' LIMIT %s'
            params.append(limit)

        cursor.execute(sql, tuple(params))

        column_names = [desc[0] for desc in cursor.description]

        results = []
        for row in cursor.fetchall():
            row_dict = {}
            for i, col_name in enumerate(column_names):
                row_dict[col_name] = row[i]
            results.append(row_dict)

        return results

    except Exception as e:
        return [{"error": f"Database error: {str(e)}"}]
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@mcp.tool()
def get_gdp_structure(district: str='宝安区', limit: int = None, order_desc: bool = True) -> Optional[list[dict]]:
    """获取某一地区GDP结构数据，默认按统计日期降序排列

    Args:
        district: 地区，字符串类型，默认为宝安区
        limit: 返回记录数量限制，默认不限制
        order_desc: 是否按统计日期降序排列，默认为True，False则是按统计日期升序

    Returns:
        包含查询结果的字典列表，每个字典对应一行记录
    """
    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        sql = '''
            SELECT stat_date, current_growth, current_value, value_name, unit
            FROM "gdp"
            WHERE district = %s
                AND stat_freq = %s
                AND value_type in (2,3,4)
        '''

        params = [district, '季度']

        if order_desc:
            sql += ' ORDER BY stat_date DESC'
        else:
            sql += ' ORDER BY stat_date ASC'

        if limit and limit > 0:
            sql += ' LIMIT %s'
            params.append(limit)

        cursor.execute(sql, tuple(params))

        column_names = [desc[0] for desc in cursor.description]

        results = []
        for row in cursor.fetchall():
            row_dict = {}
            for i, col_name in enumerate(column_names):
                row_dict[col_name] = row[i]
            results.append(row_dict)

        return results

    except Exception as e:
        return [{"error": f"Database error: {str(e)}"}]
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@mcp.tool()
def get_gdp_basic_aspects(district: str='宝安区', limit: int = None, order_desc: bool = True) -> Optional[list[dict]]:
    """获取某一地区GDP季度基础指标数据，默认按统计日期降序排列

    Args:
        district: 地区，字符串类型，默认为宝安区
        limit: 返回记录数量限制，默认不限制
        order_desc: 是否按统计日期降序排列，默认为True，False则是按统计日期升序

    Returns:
        包含查询结果的字典列表，每个字典对应一行记录
    """
    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        sql = '''
            SELECT stat_date, current_growth, value_name
            FROM "accounting_index"
            WHERE district = %s
                AND stat_freq in (%s)
        '''

        params = [district, '季度']

        if order_desc:
            sql += ' ORDER BY stat_date DESC'
        else:
            sql += ' ORDER BY stat_date ASC'

        if limit and limit > 0:
            sql += ' LIMIT %s'
            params.append(limit)

        cursor.execute(sql, tuple(params))

        column_names = [desc[0] for desc in cursor.description]

        results = []
        for row in cursor.fetchall():
            row_dict = {}
            for i, col_name in enumerate(column_names):
                row_dict[col_name] = row[i]
            results.append(row_dict)

        return results

    except Exception as e:
        return [{"error": f"Database error: {str(e)}"}]
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@mcp.tool()
def get_gdp_of_each_district(year: str = '', month: str='12', limit: int = None, order_desc: bool = True) -> Optional[list[dict]]:
    """获取各区gdp对比数据，默认按统计日期降序排列

    Args:
        year: gdp数据对应年份，如'2025'
        month: gdp数据对应月份，如'12'，对于前三季度，月份为'09'，需要有前面的0，以此类推
        limit: 返回记录数量限制，默认不限制
        order_desc: 是否按统计日期降序排列，默认为True，False则是按统计日期升序

    Returns:
        包含查询结果的字典列表，每个字典对应一行记录
    """
    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        sql = '''
            SELECT stat_date, district, current_growth, current_value, value_name, unit
            FROM "gdp"
            WHERE stat_freq = %s
                AND value_type = %s
        '''

        params = ['季度', 1]

        if year:
            stat_date = f"{year}-{month}-01"
            sql += f" AND stat_date = '{stat_date}' "

        if order_desc:
            sql += ' ORDER BY stat_date DESC'
        else:
            sql += ' ORDER BY stat_date ASC'

        if limit and limit > 0:
            sql += ' LIMIT %s'
            params.append(limit)

        cursor.execute(sql, tuple(params))

        column_names = [desc[0] for desc in cursor.description]

        results = []
        for row in cursor.fetchall():
            row_dict = {}
            for i, col_name in enumerate(column_names):
                row_dict[col_name] = row[i]
            results.append(row_dict)

        return results

    except Exception as e:
        return [{"error": f"Database error: {str(e)}"}]
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

@mcp.tool()
def get_accounting_by_years(year: str, month: str='12', district: str='宝安区') -> Optional[list[dict]]:
    """获取gdp相关行业指标数据

        Args:
            year: 指标数据对应年份，如'2025'
            month: 指标数据对应月份，如'12'，对于前三季度，月份为'09'，需要有前面的0，以此类推
            district： 指标对应的地区名称，默认为'宝安区'

        Returns:
            包含查询结果的字典列表，每个字典对应一行记录
    """
    conn = None
    cursor = None
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        sql = '''
                SELECT value_name, industry, current_growth
                FROM accounting_index
                WHERE district = %s AND stat_date = %s AND stat_freq = %s
                ORDER BY current_growth DESC;
            '''
        stat_date = f"{year}-{month}-01"
        params = [district, stat_date, '月度']

        cursor.execute(sql, tuple(params))

        column_names = [desc[0] for desc in cursor.description]

        results = []
        for row in cursor.fetchall():
            row_dict = {}
            for i, col_name in enumerate(column_names):
                row_dict[col_name] = row[i]
            results.append(row_dict)

        return results

    except Exception as e:
        return str(e)
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

def run(host: str = None, port: int = None):
    actual_host = host if host is not None else DEFAULT_HOST
    actual_port = port if port is not None else DEFAULT_PORT
    mcp.run(transport="streamable-http", host=actual_host, port=actual_port, path="/mcp")

if __name__ == "__main__":
    run()