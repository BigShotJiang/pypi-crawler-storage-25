"""Setup configuration for PromptZip."""

from setuptools import setup, find_packages
from pathlib import Path

# Read the long description from README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="PromptZip",
    version="0.1.0",
    author="PromptZip Contributors",
    author_email="your-email@example.com",
    description="Compress prompts without changing their meaning - works offline",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/vineet454/PromptZip",
    project_urls={
        "Bug Tracker": "https://github.com/vineet454/PromptZip/issues",
        "Documentation": "https://github.com/vineet454/PromptZip/docs",
        "Source Code": "https://github.com/vineet454/PromptZip",
    },
    packages=find_packages(exclude=["tests", "docs", "examples"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    keywords="prompt compression optimization nlp text-processing offline",
    zip_safe=False,
)
