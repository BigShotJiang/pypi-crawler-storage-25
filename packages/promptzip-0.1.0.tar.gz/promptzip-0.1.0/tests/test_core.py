"""Tests for PromptZip core functionality."""

import unittest
from promptzip.core import PromptZip, compress
from promptzip.strategies import (
    WhitespaceStrategy,
    URLRemovalStrategy,
    AbbreviationStrategy,
)


class TestPromptZip(unittest.TestCase):
    """Test PromptZip core functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.compressor = PromptZip()
        self.sample_text = """
        This is a very long and unnecessarily verbose prompt
        with   multiple    spaces    and
        
        
        multiple newlines that could be optimized for better performance.
        """
    
    def test_initialization(self):
        """Test PromptZip initialization."""
        compressor = PromptZip()
        self.assertIsNotNone(compressor)
        self.assertTrue(len(compressor.strategies) > 0)
    
    def test_compress_reduces_size(self):
        """Test that compression reduces text size."""
        result = self.compressor.compress(self.sample_text)
        self.assertLess(len(result['compressed']), len(self.sample_text))
    
    def test_compress_returns_dict(self):
        """Test that compress returns proper dictionary."""
        result = self.compressor.compress("Test text.")
        self.assertIn('compressed', result)
        self.assertIn('original_size', result)
        self.assertIn('compressed_size', result)
        self.assertIn('compression_ratio', result)
    
    def test_compress_with_stats(self):
        """Test compression with statistics."""
        result = self.compressor.compress(self.sample_text, return_stats=True)
        self.assertIn('stats', result)
        self.assertIn('original', result['stats'])
        self.assertIn('compressed', result['stats'])
    
    def test_compress_empty_string(self):
        """Test compressing empty string."""
        result = self.compressor.compress("")
        self.assertEqual(result['compressed'], "")
        self.assertEqual(result.get('original_size', 0), 0)
    
    def test_add_strategy(self):
        """Test adding custom strategy."""
        initial_count = len(self.compressor.strategies)
        self.compressor.add_strategy(WhitespaceStrategy())
        self.assertEqual(len(self.compressor.strategies), initial_count + 1)
    
    def test_remove_strategy(self):
        """Test removing strategy by name."""
        initial_count = len(self.compressor.strategies)
        self.compressor.remove_strategy('WhitespaceStrategy')
        self.assertLess(len(self.compressor.strategies), initial_count)
    
    def test_set_strategies(self):
        """Test setting specific strategies."""
        strategies = [WhitespaceStrategy(), AbbreviationStrategy()]
        self.compressor.set_strategies(strategies)
        self.assertEqual(len(self.compressor.strategies), 2)
    
    def test_compress_batch(self):
        """Test batch compression."""
        texts = [
            "First very long prompt with unnecessary words",
            "Second prompt with lots of extra spaces",
            "Third prompt for batch testing"
        ]
        results = self.compressor.compress_batch(texts)
        self.assertEqual(len(results), 3)
        for result in results:
            self.assertIn('compressed', result)
    
    def test_compression_stats(self):
        """Test compression statistics."""
        self.compressor.compress("Test 1")
        self.compressor.compress("Test 2")
        stats = self.compressor.get_compression_stats()
        
        self.assertEqual(stats['total_compressions'], 2)
        self.assertIn('average_ratio', stats)
        self.assertIn('total_time', stats)
    
    def test_reset_history(self):
        """Test resetting compression history."""
        self.compressor.compress("Test")
        self.compressor.reset_history()
        stats = self.compressor.get_compression_stats()
        self.assertEqual(stats['total_compressions'], 0)
    
    def test_compress_function(self):
        """Test convenience compress function."""
        result = compress("Test  text   with   unnecessary    spaces")
        self.assertIn('compressed', result)
        self.assertLessEqual(len(result['compressed']), len("Test  text   with   unnecessary    spaces"))


class TestCompressionWithURLs(unittest.TestCase):
    """Test URL removal strategy."""
    
    def test_url_removal(self):
        """Test URL removal."""
        text = "Check this link: https://example.com/page for more info"
        strategy = URLRemovalStrategy()
        result = strategy.compress(text)
        self.assertNotIn("https://", result)


class TestAbbreviations(unittest.TestCase):
    """Test abbreviation strategy."""
    
    def test_common_abbreviations(self):
        """Test common phrase abbreviations."""
        text = "for example, this is very important, etc."
        strategy = AbbreviationStrategy()
        result = strategy.compress(text)
        
        # Should contain abbreviations
        self.assertIn("e.g.", result.lower())
        self.assertIn("etc.", result.lower())
    
    def test_custom_abbreviations(self):
        """Test custom abbreviations."""
        custom = {'machine learning': 'ML', 'deep learning': 'DL'}
        strategy = AbbreviationStrategy(custom_abbreviations=custom)
        text = "machine learning and deep learning are related"
        result = strategy.compress(text)
        
        self.assertIn("ML", result)
        self.assertIn("DL", result)


if __name__ == '__main__':
    unittest.main()
