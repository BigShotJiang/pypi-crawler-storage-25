"""Tests for PromptZip utility functions."""

import unittest
from promptzip.utils import (
    remove_extra_whitespace,
    get_word_frequency,
    find_repeated_patterns,
    truncate_decimal_numbers,
    remove_urls,
    remove_emails,
    extract_statistics,
)


class TestWhitespaceUtilities(unittest.TestCase):
    """Test whitespace utility functions."""
    
    def test_remove_extra_spaces(self):
        """Test removing extra spaces."""
        text = "This  has   multiple    spaces"
        result = remove_extra_whitespace(text)
        self.assertEqual(result, "This has multiple spaces")
    
    def test_remove_extra_newlines(self):
        """Test removing extra newlines."""
        text = "Line 1\n\n\nLine 2"
        result = remove_extra_whitespace(text)
        self.assertEqual(result, "Line 1\nLine 2")
    
    def test_strip_trailing_whitespace(self):
        """Test stripping trailing whitespace."""
        text = "Line 1   \nLine 2   "
        result = remove_extra_whitespace(text)
        lines = result.split('\n')
        for line in lines:
            self.assertFalse(line.endswith(' '))


class TestWordFrequency(unittest.TestCase):
    """Test word frequency functions."""
    
    def test_word_frequency(self):
        """Test word frequency calculation."""
        text = "apple banana apple cherry apple"
        freq = get_word_frequency(text)
        
        self.assertEqual(freq['apple'], 3)
        self.assertEqual(freq['banana'], 1)
        self.assertEqual(freq['cherry'], 1)
    
    def test_case_insensitive(self):
        """Test case-insensitive frequency."""
        text = "Apple APPLE apple"
        freq = get_word_frequency(text)
        self.assertEqual(freq['apple'], 3)


class TestPatternFinding(unittest.TestCase):
    """Test pattern finding functions."""
    
    def test_find_repeated_patterns(self):
        """Test finding repeated patterns."""
        text = "The quick brown fox jumps over the quick brown fox"
        patterns = find_repeated_patterns(text)
        
        # Should find repeated patterns
        self.assertTrue(len(patterns) > 0)


class TestNumberTruncation(unittest.TestCase):
    """Test number truncation functions."""
    
    def test_truncate_decimals(self):
        """Test decimal truncation."""
        text = "The value is 3.14159 and 2.71828"
        result = truncate_decimal_numbers(text, decimal_places=2)
        
        self.assertIn("3.14", result)
        self.assertIn("2.72", result)
        self.assertNotIn("3.14159", result)


class TestURLRemoval(unittest.TestCase):
    """Test URL removal functions."""
    
    def test_remove_urls(self):
        """Test URL removal."""
        text = "Visit https://example.com for more info"
        result = remove_urls(text)
        
        self.assertNotIn("https://", result)
        self.assertIn("[URL]", result)
    
    def test_replace_urls_custom(self):
        """Test URL replacement with custom text."""
        text = "Check https://example.com here"
        result = remove_urls(text, replace_with="<LINK>")
        
        self.assertIn("<LINK>", result)


class TestEmailRemoval(unittest.TestCase):
    """Test email removal functions."""
    
    def test_remove_emails(self):
        """Test email removal."""
        text = "Contact me at john@example.com for details"
        result = remove_emails(text)
        
        self.assertNotIn("@", result)
        self.assertIn("[EMAIL]", result)
    
    def test_replace_emails_custom(self):
        """Test email replacement with custom text."""
        text = "Email: test@domain.com"
        result = remove_emails(text, replace_with="<CONTACT>")
        
        self.assertIn("<CONTACT>", result)


class TestStatistics(unittest.TestCase):
    """Test statistics extraction."""
    
    def test_extract_statistics(self):
        """Test statistics extraction."""
        text = "Hello world.\nThis is a test."
        stats = extract_statistics(text)
        
        self.assertIn('total_characters', stats)
        self.assertIn('total_words', stats)
        self.assertIn('total_lines', stats)
        self.assertIn('avg_word_length', stats)
        self.assertGreater(stats['total_characters'], 0)
        self.assertGreater(stats['total_words'], 0)


if __name__ == '__main__':
    unittest.main()
