# PromptZip 📦

**Compress prompts without changing their meaning - Works completely offline!**

![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![Python 3.7+](https://img.shields.io/badge/Python-3.7%2B-blue)
![No Dependencies](https://img.shields.io/badge/Dependencies-None-brightgreen)
![GitHub](https://img.shields.io/badge/GitHub-vineet454/PromptZip-blue?logo=github)

PromptZip is a lightweight, open-source Python library designed to reduce the size of prompts for large language models (LLMs) without using RAG, fine-tuning, or any LLM processing. It works **100% offline** with zero external dependencies.

## 🎯 Why PromptZip?

- **Reduce API Costs**: Smaller prompts = fewer tokens = lower API costs
- **Faster Processing**: Shorter prompts process faster
- **Offline**: Works completely offline - no API calls, no LLM dependency
- **Lightweight**: Zero external dependencies
- **Flexible**: Multiple compression strategies you can mix and match
- **Customizable**: Create your own compression strategies
- **Fast**: Compression happens in milliseconds

## 📊 Key Features

- **Whitespace Optimization**: Remove unnecessary spaces and newlines
- **URL/Email Removal**: Strip out or minimize URLs and emails
- **Decimal Truncation**: Round numbers intelligently
- **Redundancy Removal**: Eliminate duplicate phrases and sentences
- **Auto-Abbreviation**: Convert common phrases to abbreviations (e.g., "for example" → "e.g.")
- **Content Compression**: Minimize structured content
- **Compression Statistics**: Track compression ratios and performance
- **Batch Processing**: Compress multiple prompts efficiently
- **Extensible**: Create custom strategies easily

## 📦 Installation

### From PyPI (recommended)
```bash
pip install PromptZip
```

### From Source
```bash
git clone https://github.com/yourusername/PromptZip.git
cd PromptZip
pip install -e .
```

### From Tarball
```bash
pip install PromptZip-0.1.0.tar.gz
```

## 🚀 Quick Start

### Basic Usage

```python
from promptzip import compress

# Simple compression using default settings
prompt = "This is a very long prompt that contains lots of unnecessary information..."
result = compress(prompt)

print(result['compressed'])
print(f"Compression ratio: {result['compression_ratio']:.2f}%")
```

### Using PromptZip Class

```python
from promptzip import PromptZip

# Create a compressor instance
compressor = PromptZip()

# Compress with statistics
result = compressor.compress(
    "Your long prompt here...",
    return_stats=True,
    verbose=True
)

print(result['compressed'])
print(f"Original: {result['original_size']} chars")
print(f"Compressed: {result['compressed_size']} chars")
print(f"Reduction: {result['compression_ratio']:.2f}%")
```

## 📖 Advanced Usage

### Custom Strategies

```python
from promptzip import PromptZip
from promptzip.strategies import (
    WhitespaceStrategy,
    URLRemovalStrategy,
    AbbreviationStrategy
)

# Create with specific strategies
compressor = PromptZip()
compressor.set_strategies([
    WhitespaceStrategy(),
    URLRemovalStrategy(replace_with=""),
    AbbreviationStrategy(),
])

result = compressor.compress("Your prompt...")
```

### Add Custom Abbreviations

```python
from promptzip import PromptZip
from promptzip.strategies import AbbreviationStrategy

compressor = PromptZip()

# Add custom abbreviations
custom_abbrev = {
    'reinforcement learning': 'RL',
    'supervised learning': 'SL',
    'computer vision': 'CV',
    'recommendation system': 'RS',
}

custom_strategy = AbbreviationStrategy(custom_abbrev)
compressor.set_strategies([custom_strategy])

result = compressor.compress("Text about reinforcement learning...")
```

### Create Custom Strategy

```python
from promptzip import PromptZip
from promptzip.strategies import CompressionStrategy

class MyCustomStrategy(CompressionStrategy):
    def compress(self, text: str) -> str:
        # Your compression logic
        return text.replace("very ", "")

compressor = PromptZip()
compressor.add_strategy(MyCustomStrategy())

result = compressor.compress("This is very important...")
```

### Batch Processing

```python
from promptzip import PromptZip

compressor = PromptZip()

prompts = [
    "First long prompt...",
    "Second long prompt...",
    "Third long prompt...",
]

results = compressor.compress_batch(prompts, return_stats=True)

for i, result in enumerate(results):
    print(f"Prompt {i+1}: {result['compression_ratio']:.2f}% reduction")
```

### Get Compression Statistics

```python
from promptzip import PromptZip

compressor = PromptZip()

# Compress some prompts
compressor.compress("Prompt 1...")
compressor.compress("Prompt 2...")
compressor.compress("Prompt 3...")

# Get aggregate statistics
stats = compressor.get_compression_stats()
print(f"Total compressions: {stats['total_compressions']}")
print(f"Average ratio: {stats['average_ratio']:.2f}%")
print(f"Total time: {stats['total_time']:.4f}s")
```

## 🎓 Available Strategies

| Strategy | Purpose |
|----------|---------|
| `WhitespaceStrategy` | Removes extra spaces and newlines |
| `URLRemovalStrategy` | Removes or replaces URLs |
| `EmailRemovalStrategy` | Removes or replaces emails |
| `DecimalTruncationStrategy` | Truncates decimal numbers |
| `RedundancyRemovalStrategy` | Removes duplicate phrases |
| `AbbreviationStrategy` | Converts phrases to abbreviations |
| `ContentCompressionStrategy` | Compresses content structure |
| `JSONCompressionStrategy` | Minimizes JSON format |

## 💡 Examples

### Example 1: Basic API Documentation Prompt

```python
from promptzip import compress

prompt = """
Please explain the following API endpoint in detail:

The GET /api/v1/users/{userId}/profile endpoint is a very important endpoint 
that retrieves the user profile information. For example, it fetches the user's 
personal data including their name, email address, and phone number. The endpoint 
returns HTTP 200 OK on success and should be used for getting user information, etc.

URL: https://api.example.com/docs/users
Contact: support@example.com
"""

result = compress(prompt, return_stats=True)
print(result['compressed'])
print(f"Saved {result['original_size'] - result['compressed_size']} characters!")
```

### Example 2: System Prompt Compression

```python
from promptzip import PromptZip

compressor = PromptZip()

system_prompt = """
You are a very helpful and intelligent AI assistant. Your role is to help users 
with various tasks such as writing, coding, analysis, and more. For example, you 
can help write essays, debug code, analyze data, etc. You should always be polite 
and respectful. However, you should not help with illegal or unethical activities. 
For instance, you should refuse to help with hacking, fraud, or other illegal activities.
"""

result = compressor.compress(system_prompt, verbose=True)
```

## 📊 Performance

PromptZip is extremely fast:

- Compression overhead: < 1ms for typical prompts
- No external API calls
- Works with prompts of any size
- Minimal memory footprint

## 🛠️ Development

### Clone the Repository
```bash
git clone https://github.com/yourusername/PromptZip.git
cd PromptZip
```

### Install Development Dependencies
```bash
pip install -e ".[dev]"
```

### Run Tests
```bash
python -m pytest tests/
```

### Run Linting
```bash
python -m black promptzip/
python -m isort promptzip/
```

## 📝 White Paper / Documentation

For detailed technical documentation, see [docs/README.md](docs/README.md)

Key Papers and References:
- Text compression algorithms
- NLP preprocessing techniques
- Token optimization for LLMs

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

### How to Contribute:
1. Fork the repository: https://github.com/vineet454/PromptZip
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🐛 Bug Reports

Found a bug? Please create an issue on GitHub: [Issues](https://github.com/vineet454/PromptZip/issues)

## 💬 Questions & Discussions

Have questions? Start a discussion on [GitHub Discussions](https://github.com/vineet454/PromptZip/discussions)

## 🙏 Acknowledgments

- Inspired by the need to optimize LLM prompt usage
- Built with Python and ❤️

## 📈 Roadmap

- [ ] Add more compression strategies
- [ ] Semantic compression using linguistic analysis
- [ ] Multi-language support
- [ ] CLI tool for command-line usage
- [ ] Web interface for online compression
- [ ] Integration with popular LLM libraries (LangChain, etc.)
- [ ] Performance benchmarking suite
- [ ] Advanced metrics and analytics

## 📞 Contact

- GitHub: [@vineet454](https://github.com/vineet454)
- Repository: [PromptZip](https://github.com/vineet454/PromptZip)

---

**Made with ❤️ for the open-source community**
