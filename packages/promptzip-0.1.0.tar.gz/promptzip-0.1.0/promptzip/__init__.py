"""
PromptZip - Compress prompts without changing their meaning.

A lightweight, offline-capable library to reduce prompt size for large language models
without RAG or LLM processing. Works completely offline.

Example:
    >>> from promptzip import PromptZip
    >>> compressor = PromptZip()
    >>> result = compressor.compress("Your long prompt here...")
    >>> print(result['compressed'])
"""

from .core import PromptZip, compress
from .__version__ import __version__

__all__ = [
    'PromptZip',
    'compress',
    '__version__',
]
