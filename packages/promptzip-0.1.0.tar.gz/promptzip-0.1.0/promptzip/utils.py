"""Utility functions for PromptZip."""

import re
from typing import List, Dict, Tuple
import json


def remove_extra_whitespace(text: str) -> str:
    """
    Remove extra whitespace while preserving structure.
    
    Args:
        text: Input text
        
    Returns:
        Text with normalized whitespace
    """
    # Remove multiple spaces
    text = re.sub(r' +', ' ', text)
    # Remove multiple newlines
    text = re.sub(r'\n\n+', '\n', text)
    # Remove trailing whitespace on each line
    text = '\n'.join(line.rstrip() for line in text.split('\n'))
    return text.strip()


def get_word_frequency(text: str) -> Dict[str, int]:
    """
    Calculate word frequency in text.
    
    Args:
        text: Input text
        
    Returns:
        Dictionary with word frequencies
    """
    words = re.findall(r'\b\w+\b', text.lower())
    freq = {}
    for word in words:
        freq[word] = freq.get(word, 0) + 1
    return freq


def find_repeated_patterns(text: str, min_length: int = 3) -> List[Tuple[str, int]]:
    """
    Find repeated text patterns.
    
    Args:
        text: Input text
        min_length: Minimum pattern length to consider
        
    Returns:
        List of (pattern, frequency) tuples
    """
    patterns = {}
    
    # Find repeated words
    words = text.split()
    for i in range(len(words) - 1):
        for j in range(i + 1, min(i + 5, len(words))):
            pattern = ' '.join(words[i:j])
            if len(pattern) >= min_length:
                patterns[pattern] = patterns.get(pattern, 0) + 1
    
    # Return patterns that appear more than once, sorted by frequency
    repeated = [(p, f) for p, f in patterns.items() if f > 1]
    return sorted(repeated, key=lambda x: x[1], reverse=True)


def truncate_decimal_numbers(text: str, decimal_places: int = 2) -> str:
    """
    Truncate decimal numbers to reduce size.
    
    Args:
        text: Input text
        decimal_places: Number of decimal places to keep
        
    Returns:
        Text with truncated decimals
    """
    pattern = rf'(\d+\.\d{{{decimal_places + 1},}})'
    
    def truncate(match):
        num = float(match.group(1))
        return str(round(num, decimal_places))
    
    return re.sub(pattern, truncate, text)


def remove_urls(text: str, replace_with: str = "[URL]") -> str:
    """
    Remove or replace URLs.
    
    Args:
        text: Input text
        replace_with: Replacement string for URLs
        
    Returns:
        Text with URLs removed or replaced
    """
    url_pattern = r'https?://[^\s]+'
    return re.sub(url_pattern, replace_with, text)


def remove_emails(text: str, replace_with: str = "[EMAIL]") -> str:
    """
    Remove or replace email addresses.
    
    Args:
        text: Input text
        replace_with: Replacement string for emails
        
    Returns:
        Text with emails removed or replaced
    """
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    return re.sub(email_pattern, replace_with, text)


def extract_statistics(text: str) -> Dict:
    """
    Extract useful statistics from text.
    
    Args:
        text: Input text
        
    Returns:
        Dictionary with text statistics
    """
    lines = text.split('\n')
    words = text.split()
    chars = len(text)
    
    return {
        'total_characters': chars,
        'total_words': len(words),
        'total_lines': len(lines),
        'avg_word_length': sum(len(w) for w in words) / len(words) if words else 0,
        'compression_potential': f"{(len(text) / 1000):.2f}KB"
    }
