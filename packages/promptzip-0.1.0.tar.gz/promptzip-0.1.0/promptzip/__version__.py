"""PromptZip version information."""

__version__ = "0.1.0"
__author__ = "PromptZip Contributors"
__license__ = "MIT"
