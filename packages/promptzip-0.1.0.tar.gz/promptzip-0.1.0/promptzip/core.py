"""Core PromptZip compression engine."""

from typing import List, Dict, Optional, Tuple
from .strategies import (
    CompressionStrategy,
    WhitespaceStrategy,
    URLRemovalStrategy,
    EmailRemovalStrategy,
    DecimalTruncationStrategy,
    RedundancyRemovalStrategy,
    AbbreviationStrategy,
    ContentCompressionStrategy
)
from .utils import extract_statistics
import time


class PromptZip:
    """Main compression engine for reducing prompt size."""
    
    def __init__(self):
        """Initialize PromptZip with default strategies."""
        self.strategies: List[CompressionStrategy] = [
            WhitespaceStrategy(),
            URLRemovalStrategy(),
            EmailRemovalStrategy(),
            DecimalTruncationStrategy(),
            RedundancyRemovalStrategy(),
            AbbreviationStrategy(),
            ContentCompressionStrategy(),
        ]
        self.compression_history: List[Dict] = []
    
    def add_strategy(self, strategy: CompressionStrategy) -> None:
        """
        Add a custom compression strategy.
        
        Args:
            strategy: CompressionStrategy instance
        """
        self.strategies.append(strategy)
    
    def remove_strategy(self, strategy_name: str) -> None:
        """
        Remove a strategy by class name.
        
        Args:
            strategy_name: Name of the strategy class to remove
        """
        self.strategies = [
            s for s in self.strategies 
            if s.__class__.__name__ != strategy_name
        ]
    
    def set_strategies(self, strategies: List[CompressionStrategy]) -> None:
        """
        Set specific strategies to use.
        
        Args:
            strategies: List of CompressionStrategy instances
        """
        self.strategies = strategies
    
    def compress(
        self, 
        text: str, 
        return_stats: bool = False,
        verbose: bool = False
    ) -> Dict:
        """
        Compress a prompt while preserving meaning.
        
        Args:
            text: Input prompt text
            return_stats: Whether to return compression statistics
            verbose: Whether to print compression progress
            
        Returns:
            Dictionary with compressed text and optional statistics
        """
        if not text:
            return {
                'compressed': '',
                'stats': extract_statistics(''),
                'ratio': 0.0
            }
        
        start_time = time.time()
        original_size = len(text)
        result = text
        
        if verbose:
            print(f"Starting compression. Original size: {original_size} chars")
        
        # Apply each strategy sequentially
        for strategy in self.strategies:
            strategy_name = strategy.__class__.__name__
            before_size = len(result)
            result = strategy.compress(result)
            after_size = len(result)
            
            if verbose:
                reduction = before_size - after_size
                if reduction > 0:
                    print(f"  {strategy_name}: -{reduction} chars ({before_size} → {after_size})")
        
        compressed_size = len(result)
        compression_ratio = (1 - compressed_size / original_size) * 100
        elapsed_time = time.time() - start_time
        
        compression_record = {
            'original_size': original_size,
            'compressed_size': compressed_size,
            'compression_ratio': compression_ratio,
            'time_taken': elapsed_time,
            'strategies_used': [s.__class__.__name__ for s in self.strategies]
        }
        
        self.compression_history.append(compression_record)
        
        if verbose:
            print(f"\nCompression complete!")
            print(f"  Final size: {compressed_size} chars")
            print(f"  Reduction: {compression_ratio:.2f}%")
            print(f"  Time: {elapsed_time:.4f}s")
        
        output = {
            'compressed': result,
            'original_size': original_size,
            'compressed_size': compressed_size,
            'compression_ratio': compression_ratio,
        }
        
        if return_stats:
            output['stats'] = {
                'original': extract_statistics(text),
                'compressed': extract_statistics(result),
                'time_taken': elapsed_time,
                'strategies': compression_record['strategies_used']
            }
        
        return output
    
    def compress_batch(
        self, 
        texts: List[str], 
        return_stats: bool = False,
        verbose: bool = False
    ) -> List[Dict]:
        """
        Compress multiple prompts.
        
        Args:
            texts: List of prompt texts
            return_stats: Whether to return statistics
            verbose: Whether to print progress
            
        Returns:
            List of compression results
        """
        return [
            self.compress(text, return_stats=return_stats, verbose=verbose)
            for text in texts
        ]
    
    def get_compression_stats(self) -> Dict:
        """
        Get aggregate compression statistics.
        
        Returns:
            Dictionary with compression history and statistics
        """
        if not self.compression_history:
            return {
                'total_compressions': 0,
                'average_ratio': 0.0,
                'total_time': 0.0
            }
        
        total_time = sum(h['time_taken'] for h in self.compression_history)
        avg_ratio = sum(h['compression_ratio'] for h in self.compression_history) / len(self.compression_history)
        total_original = sum(h['original_size'] for h in self.compression_history)
        total_compressed = sum(h['compressed_size'] for h in self.compression_history)
        
        return {
            'total_compressions': len(self.compression_history),
            'average_ratio': avg_ratio,
            'total_original_size': total_original,
            'total_compressed_size': total_compressed,
            'total_time': total_time,
            'average_time': total_time / len(self.compression_history),
            'history': self.compression_history
        }
    
    def reset_history(self) -> None:
        """Clear compression history."""
        self.compression_history = []


# Create a default instance
_default_compressor = PromptZip()


def compress(text: str, return_stats: bool = False, verbose: bool = False) -> Dict:
    """
    Convenience function for quick compression using default instance.
    
    Args:
        text: Input prompt text
        return_stats: Whether to return compression statistics
        verbose: Whether to print compression progress
        
    Returns:
        Compression result dictionary
    """
    return _default_compressor.compress(text, return_stats=return_stats, verbose=verbose)
