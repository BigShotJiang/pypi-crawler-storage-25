"""Compression strategies for PromptZip."""

import re
from typing import Dict, List
from .utils import (
    remove_extra_whitespace,
    find_repeated_patterns,
    truncate_decimal_numbers,
    remove_urls,
    remove_emails
)


class CompressionStrategy:
    """Base class for compression strategies."""
    
    def compress(self, text: str) -> str:
        """Compress text while preserving meaning."""
        raise NotImplementedError


class WhitespaceStrategy(CompressionStrategy):
    """Remove unnecessary whitespace."""
    
    def compress(self, text: str) -> str:
        """Remove extra whitespace."""
        return remove_extra_whitespace(text)


class URLRemovalStrategy(CompressionStrategy):
    """Remove or minimize URLs."""
    
    def __init__(self, replace_with: str = "[URL]"):
        self.replace_with = replace_with
    
    def compress(self, text: str) -> str:
        """Remove URLs."""
        return remove_urls(text, self.replace_with)


class EmailRemovalStrategy(CompressionStrategy):
    """Remove or minimize email addresses."""
    
    def __init__(self, replace_with: str = "[EMAIL]"):
        self.replace_with = replace_with
    
    def compress(self, text: str) -> str:
        """Remove emails."""
        return remove_emails(text, self.replace_with)


class DecimalTruncationStrategy(CompressionStrategy):
    """Truncate decimal numbers."""
    
    def __init__(self, decimal_places: int = 2):
        self.decimal_places = decimal_places
    
    def compress(self, text: str) -> str:
        """Truncate decimals."""
        return truncate_decimal_numbers(text, self.decimal_places)


class RedundancyRemovalStrategy(CompressionStrategy):
    """Remove redundant phrases and repetition."""
    
    def compress(self, text: str) -> str:
        """Remove redundancy."""
        # Remove common filler phrases
        fillers = [
            r'\b(please|kindly|very|really|actually|basically|essentially)\b',
            r'\b(in order to|so that|the fact that)\b',
            r'\b(it is|it\'s)\b(?= (clear|obvious|evident|important))',
        ]
        
        result = text
        for filler in fillers:
            result = re.sub(filler, '', result, flags=re.IGNORECASE)
        
        # Remove duplicate sentences
        sentences = re.split(r'(?<=[.!?])\s+', result)
        unique_sentences = []
        seen = set()
        
        for sentence in sentences:
            normalized = sentence.strip().lower()
            if normalized and normalized not in seen:
                unique_sentences.append(sentence.strip())
                seen.add(normalized)
        
        return ' '.join(unique_sentences)


class AbbreviationStrategy(CompressionStrategy):
    """Replace common phrases with abbreviations."""
    
    def __init__(self, custom_abbreviations: Dict[str, str] = None):
        self.abbreviations = {
            'for example': 'e.g.',
            'that is': 'i.e.',
            'et cetera': 'etc.',
            'and so on': 'etc.',
            'application programming interface': 'API',
            'artificial intelligence': 'AI',
            'machine learning': 'ML',
            'natural language processing': 'NLP',
            'question and answer': 'Q&A',
            'as soon as possible': 'ASAP',
            'thank you': 'thx',
            'please': 'plz',
            'information': 'info',
            'example': 'ex.',
            'usually': 'usu.',
            'versus': 'vs.',
            'therefore': 'therefore',
            'however': 'but',
            'nevertheless': 'but',
            'regarding': 're:',
        }
        
        if custom_abbreviations:
            self.abbreviations.update(custom_abbreviations)
    
    def compress(self, text: str) -> str:
        """Apply abbreviations."""
        result = text
        
        for phrase, abbrev in self.abbreviations.items():
            # Case-insensitive replacement
            pattern = re.compile(re.escape(phrase), re.IGNORECASE)
            result = pattern.sub(abbrev, result)
        
        return result


class JSONCompressionStrategy(CompressionStrategy):
    """Compress JSON structures."""
    
    def compress(self, text: str) -> str:
        """Minimize JSON by removing whitespace."""
        try:
            # Try to parse as JSON
            data = eval(text)  # Using eval is not recommended in production
            # For production, use json.loads()
            import json
            return json.dumps(data, separators=(',', ':'), ensure_ascii=False)
        except (ValueError, SyntaxError):
            # Not JSON, return as-is
            return text


class ContentCompressionStrategy(CompressionStrategy):
    """Intelligently compress content structure."""
    
    def compress(self, text: str) -> str:
        """Compress content while maintaining meaning."""
        result = text
        
        # Convert lists to compact format
        result = re.sub(
            r'(?:^|\n)\s*(?:[-*•]|[0-9]+[.):])\s+',
            ', ',
            result
        )
        
        # Remove common prefix/suffix patterns
        result = re.sub(r'^\s*', '', result)
        result = re.sub(r'\s*$', '', result)
        
        return result
