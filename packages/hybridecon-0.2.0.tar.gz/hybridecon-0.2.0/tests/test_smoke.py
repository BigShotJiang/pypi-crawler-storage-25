"""Smoke tests — every module imports and key APIs run on a tiny series."""
from __future__ import annotations

import numpy as np
import pytest


def test_imports():
    import hybridecon as he
    assert he.__author__ == "Dr Merwan Roudane"
    assert he.__email__ == "merwanroudane920@gmail.com"
    for sub in ("data", "diagnostics", "econometric", "evaluate",
                "regime", "viz", "hybrids", "utils"):
        getattr(he, sub)


def test_demo_data_and_diagnostics():
    from hybridecon.data import load_demo_returns
    from hybridecon.diagnostics import pre_estimation_battery
    r = load_demo_returns(n=600)
    df = pre_estimation_battery(r)
    assert {"name", "statistic", "pvalue", "decision"}.issubset(df.columns)
    assert len(df) >= 5


def test_garch_only():
    from hybridecon.data import load_demo_returns
    from hybridecon.econometric import GARCH
    r = load_demo_returns(n=600)
    m = GARCH(vol="GARCH", p=1, q=1, dist="t").fit(r)
    assert m.conditional_volatility.shape[0] == len(r)
    f = m.forecast(horizon=5)
    assert f.shape == (5,)


def test_evaluate_metrics():
    from hybridecon.evaluate import (rmse, mae, qlike, model_confidence_set,
                                     trading_metrics)
    rng = np.random.default_rng(0)
    y = rng.standard_normal(500); p = y + 0.1 * rng.standard_normal(500)
    assert rmse(y, p) > 0 and mae(y, p) > 0
    assert qlike(y ** 2 + 1, p ** 2 + 1) > -1e6
    import pandas as pd
    losses = pd.DataFrame({f"m{i}": rng.standard_normal(200) ** 2 for i in range(4)})
    mcs = model_confidence_set(losses, alpha=0.1, B=200, block=4)
    assert {"model", "rank", "p_value", "in_MCS"}.issubset(mcs.columns)
    tm = trading_metrics(0.001 * rng.standard_normal(252))
    assert "ARC" in tm and "Sortino" in tm


def test_regime_kmeans():
    from hybridecon.regime import KMeansRegime
    rng = np.random.default_rng(1)
    feats = rng.standard_normal((500, 2))
    res = KMeansRegime(n_states=3).fit(feats)
    assert res.states.shape == (500,)
    assert len(res.labels) == 3


@pytest.mark.skipif(
    pytest.importorskip("torch", reason="torch not installed") is None,
    reason="torch missing")
def test_hybrid_garch_lstm_smoke():
    from hybridecon.data import load_demo_returns
    from hybridecon.hybrids import GARCHLSTM
    from hybridecon.deep import TrainConfig
    r = load_demo_returns(n=800)
    m = GARCHLSTM(lookback=10, hidden=8,
                  train_cfg=TrainConfig(epochs=2, batch_size=32)).fit(r)
    assert m.forecast_ is not None
    assert "RMSE" in m.metrics_
    m.diagnose()
    assert "pre" in m.diagnostics_


@pytest.mark.skipif(
    pytest.importorskip("torch", reason="torch not installed") is None,
    reason="torch missing")
def test_new_hybrids_smoke():
    from hybridecon.data import load_demo_returns
    from hybridecon.hybrids import (ARFIMALSTM, MIDASLSTM,
                                    MIDASCNNBiLSTMAttention, DeepTVAR)
    from hybridecon.deep import TrainConfig
    cfg = TrainConfig(epochs=2, batch_size=32)
    r = load_demo_returns(n=600)
    rng = np.random.default_rng(0)

    # ARFIMA-LSTM on returns
    m1 = ARFIMALSTM(lookback=10, hidden=8, train_cfg=cfg).fit(r)
    assert m1.forecast_ is not None and "RMSE" in m1.metrics_

    # MIDAS-LSTM with synthetic monthly factors
    macro = rng.standard_normal((30, 3))
    m2 = MIDASLSTM(K=6, lookback=10, hidden=8, top_k=2,
                   train_cfg=cfg).fit(r, macro)
    assert m2.forecast_ is not None and "RMSE" in m2.metrics_

    # MIDAS-CNN-BiLSTM-Attention with a single low-freq series
    low = rng.standard_normal(40)
    m3 = MIDASCNNBiLSTMAttention(K=6, lookback=10, hidden=8, conv_filters=4,
                                 n_heads=2, train_cfg=cfg).fit(r, low)
    assert m3.forecast_ is not None and "RMSE" in m3.metrics_

    # DeepTVAR on a tiny 2-D macro panel
    Y = rng.standard_normal((400, 2)).cumsum(axis=0)
    m4 = DeepTVAR(lookback=10, hidden=8,
                  train_cfg=TrainConfig(epochs=3, lr=1e-2, patience=5)).fit(Y)
    assert m4.forecast_ is not None and "RMSE" in m4.metrics_
    assert m4.rho_t_.max() <= 1.0 + 1e-6


def test_garman_klass_and_es():
    from hybridecon.utils import garman_klass_volatility
    from hybridecon.evaluate import expected_shortfall
    rng = np.random.default_rng(0)
    n = 300
    o = 100 + rng.standard_normal(n).cumsum()
    h = o + np.abs(rng.standard_normal(n))
    l = o - np.abs(rng.standard_normal(n))
    c = o + 0.1 * rng.standard_normal(n)
    sd = garman_klass_volatility(o, h, l, c)
    assert sd.shape == (n,)
    assert (sd.dropna() >= 0).all()

    r = 0.01 * rng.standard_normal(500)
    var = -0.02 * np.ones_like(r)
    es = expected_shortfall(r, var, alpha=0.05)
    assert {"ES_emp", "ES_avg", "n_breaches", "breach_rate"}.issubset(es.keys())
