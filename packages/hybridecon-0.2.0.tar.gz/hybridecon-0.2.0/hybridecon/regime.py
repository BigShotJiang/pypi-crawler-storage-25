"""Regime detection: Gaussian HMM and K-means on (|r|, σ̂)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans


@dataclass
class RegimeResult:
    states: np.ndarray
    centers: np.ndarray | None
    labels: list[str]
    proba: Optional[np.ndarray] = None
    method: str = ""

    def to_frame(self) -> pd.DataFrame:
        out = pd.DataFrame({"state": self.states})
        out["label"] = [self.labels[s] for s in self.states]
        if self.proba is not None:
            for k in range(self.proba.shape[1]):
                out[f"P(state={k})"] = self.proba[:, k]
        return out


class HMMRegime:
    """Gaussian HMM regime detector on a feature matrix."""

    def __init__(self, n_states: int = 2, covariance_type: str = "full",
                 n_iter: int = 100, random_state: int = 42):
        self.n_states = n_states
        self.covariance_type = covariance_type
        self.n_iter = n_iter
        self.random_state = random_state

    def fit(self, features: np.ndarray) -> RegimeResult:
        from hmmlearn.hmm import GaussianHMM
        X = np.asarray(features, dtype=float)
        if X.ndim == 1: X = X[:, None]
        self.model_ = GaussianHMM(n_components=self.n_states,
                                  covariance_type=self.covariance_type,
                                  n_iter=self.n_iter,
                                  random_state=self.random_state)
        self.model_.fit(X)
        states = self.model_.predict(X)
        proba = self.model_.predict_proba(X)
        # remap: 0 = lowest-volatility regime
        means = self.model_.means_[:, -1]                # last col is volatility
        order = np.argsort(means)
        remap = np.empty_like(order); remap[order] = np.arange(self.n_states)
        states = remap[states]
        proba = proba[:, order]
        labels = ["calm", "normal", "stressed", "crisis"][:self.n_states]
        return RegimeResult(states=states, centers=self.model_.means_[order],
                            proba=proba, labels=labels, method="HMM")


class KMeansRegime:
    """K-means on (volatility-proxy, return-MA) — used by the 'Regime-Aware'
    repo's notebook. Returns a hand-labelled ribbon (Bull / Choppy / Crisis)."""

    def __init__(self, n_states: int = 3, random_state: int = 42):
        self.n_states = n_states
        self.random_state = random_state

    def fit(self, features: np.ndarray) -> RegimeResult:
        X = np.asarray(features, dtype=float)
        if X.ndim == 1: X = X[:, None]
        km = KMeans(n_clusters=self.n_states, n_init=10,
                    random_state=self.random_state).fit(X)
        order = np.argsort(km.cluster_centers_[:, -1])      # by vol
        remap = np.empty_like(order); remap[order] = np.arange(self.n_states)
        labels_pool = ["bull", "choppy", "crisis", "panic"][:self.n_states]
        states = remap[km.labels_]
        return RegimeResult(states=states,
                            centers=km.cluster_centers_[order],
                            labels=labels_pool, method="KMeans")
