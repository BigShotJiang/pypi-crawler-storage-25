"""
Hybrid AI + Econometric models.

Every class exposes the same chainable interface so they can be swapped in
benchmarks without changing user code:

    m = SomeHybrid(...).fit(returns, ...)
    f = m.forecast(horizon=5)
    m.diagnose().plot().report("md")

Methods
-------
fit(returns, [exog])      → self
forecast(horizon)         → np.ndarray  (point forecast on the natural target)
predict_volatility()      → np.ndarray  (in-sample σ̂_t, when available)
diagnose()                → self        (populates self.diagnostics_)
plot(prefix="")           → self        (saves figures to OUTDIR/figures)
report(fmt="md")          → str         (markdown / latex / html summary)
summary()                 → str         (one-line text summary)

Implemented hybrids
-------------------
GARCHLSTM, GARCHGRU, GARCHBiLSTM, GARCHCNNBiLSTM, GARCHAttentionLSTM
ARIMALSTM                (Zhang 2003 additive residual hybrid)
ARFIMALSTM               (long-memory variant of ARIMA-LSTM)
HARLSTMGARCH             (3-stage cascade: HAR baseline + LSTM residual + GARCH)
KANGARCHMIDAS            (KAN nonlinear correction on top of GARCH-MIDAS)
MIDASCNNBiLSTMAttention  (CNN-BiLSTM-Attention on GARCH-MIDAS components)
MIDASLSTM                (mixed-frequency mean forecaster: MIDAS + LSTM)
GASATTLSTM               (GAS state + multi-head attention LSTM)
DeepBEKK                 (Diagonal BEKK + LSTM residual on each component)
DeepVAR                  (VAR baseline + per-equation LSTM residual)
DeepTVAR                 (LSTM emits time-varying VAR coefficients with
                          Ansley-Kohn-style spectral-radius stability constraint)
DeepQuantileVaR          (LSTM with pinball loss → conditional VaR)
RegimeAwareLSTMGARCH     (HMM regime → regime-specific LSTM heads on top of GARCH)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from . import diagnostics as diag
from . import evaluate as ev
from . import viz
from .econometric import (GARCH, GARCHMIDAS, HAR, ARIMAWrapper, VARWrapper,
                          DiagonalBEKK, GAS)
from .deep import (TrainConfig, Trainer, make_lstm, make_gru, make_bilstm,
                   make_cnn_bilstm, make_cnn_bilstm_attention,
                   make_attention_lstm, make_kan, pinball_loss_factory)
from .regime import HMMRegime
from .utils import build_sequences, train_val_test_split, standardize, OUTDIR


# ===========================================================================
# Base class
# ===========================================================================
@dataclass
class HybridBase:
    """Common scaffolding for every hybrid model."""
    name: str = "HybridBase"
    diagnostics_: dict = field(default_factory=dict)
    metrics_: dict = field(default_factory=dict)
    history_: dict = field(default_factory=dict)
    forecast_: Optional[np.ndarray] = None

    def diagnose(self):
        """Run pre/post-estimation diagnostic battery on residuals (if any)."""
        r = getattr(self, "residuals_", None)
        if r is None or len(np.asarray(r)) == 0:
            return self
        r = np.asarray(r, dtype=float); r = r[np.isfinite(r)]
        pre = diag.pre_estimation_battery(r)
        self.diagnostics_["pre"] = pre
        return self

    def plot(self, prefix: Optional[str] = None):
        prefix = prefix or self.name.lower()
        # training curves
        if self.history_:
            viz.plot_training_curve(self.history_, filename=f"{prefix}_training.png")
        # residuals
        r = getattr(self, "residuals_", None)
        if r is not None and len(np.asarray(r)) > 5:
            viz.residual_diagnostic_panel(r, filename=f"{prefix}_residuals.png")
        # in-sample volatility
        v = getattr(self, "vol_in_sample_", None)
        if v is not None:
            viz.plot_series(np.asarray(v), title=f"{self.name} — fitted σ̂",
                            ylabel="σ̂_t", filename=f"{prefix}_vol.png")
        # forecast vs actual (if held out)
        if self.forecast_ is not None and getattr(self, "y_test_", None) is not None:
            viz.plot_forecast(self.y_test_, self.forecast_,
                              title=f"{self.name} — forecast vs actual",
                              filename=f"{prefix}_forecast.png")
        return self

    def report(self, fmt: str = "md") -> str:
        lines = [f"# {self.name}"]
        if self.metrics_:
            df = pd.DataFrame(self.metrics_, index=["value"]).T.reset_index().rename(
                columns={"index": "metric"})
            lines.append(viz.table(df, fmt="github" if fmt == "md" else fmt,
                                   caption=f"{self.name} metrics",
                                   filename=f"{self.name.lower()}_metrics"))
        if "pre" in self.diagnostics_:
            lines.append(viz.diagnostic_table(self.diagnostics_["pre"],
                                              caption="Residual diagnostics",
                                              filename=f"{self.name.lower()}_diag"))
        return "\n\n".join(lines)

    def summary(self) -> str:
        m = ", ".join(f"{k}={v:.4g}" for k, v in self.metrics_.items()) or "no metrics"
        return f"<{self.name}: {m}>"


# ===========================================================================
# 1.  GARCH-DL family   (LSTM / GRU / BiLSTM / CNN-BiLSTM / Attention)
# ===========================================================================
class _GARCHDeepBase(HybridBase):
    """Two-stage hybrid: GARCH provides a volatility filter; a deep net learns
    the residual mean / nonlinearity."""

    factory = staticmethod(make_lstm)
    factory_kwargs: dict = {}
    name = "GARCH-Deep"

    def __init__(self, lookback: int = 20, hidden: int = 64, layers: int = 1,
                 dropout: float = 0.1,
                 garch_kwargs: Optional[dict] = None,
                 train_cfg: Optional[TrainConfig] = None):
        super().__init__(name=self.__class__.__name__)
        self.lookback = lookback
        self.hidden = hidden
        self.layers = layers
        self.dropout = dropout
        self.garch_kwargs = garch_kwargs or {"vol": "GARCH", "p": 1, "q": 1, "dist": "t"}
        self.train_cfg = train_cfg or TrainConfig()

    def fit(self, returns):
        r = np.asarray(returns, dtype=float).ravel()
        # 1) econometric stage
        self.garch_ = GARCH(**self.garch_kwargs).fit(r)
        sigma = self.garch_.conditional_volatility
        eps = self.garch_.standardized_residuals
        self.vol_in_sample_ = sigma
        # 2) build features = (r, sigma, eps) windowed
        feat = np.column_stack([r, sigma, eps]).astype(np.float32)
        # target: next-step squared standardized return (i.e. variance proxy)
        target = (r / np.maximum(sigma, 1e-8)) ** 2
        X, y = build_sequences(feat[:, 0], self.lookback, target=target)
        # rebuild X with multivariate feature matrix
        X = np.lib.stride_tricks.sliding_window_view(feat, (self.lookback, feat.shape[1]))
        X = X.squeeze(1)[:-1].astype(np.float32)
        y = target[self.lookback:].astype(np.float32)
        # split
        (Xtr, Xv, Xte), (ytr, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, mu, sd = standardize(Xtr, Xv, Xte)
        self._scaler = (mu, sd)
        # 3) deep stage
        net = self.factory(input_size=feat.shape[1], hidden=self.hidden,
                           layers=self.layers, dropout=self.dropout,
                           **self.factory_kwargs)
        self.trainer_ = Trainer(net, loss="huber", cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, ytr, Xv_s, yv)
        self.history_ = self.trainer_.history_
        # 4) test-set evaluation
        pred_var = self.trainer_.predict(Xte_s)
        # back out predicted vol = sigma_test * sqrt(predicted z²)
        sigma_te = sigma[-len(yte):]
        vol_pred = np.sqrt(np.maximum(pred_var, 1e-12)) * sigma_te
        rv_true = np.abs(r[-len(yte):])           # |r_t| as a vol proxy
        self.metrics_ = ev.evaluate_volatility_forecast(rv_true, vol_pred)
        self.forecast_ = vol_pred
        self.y_test_ = rv_true
        self.residuals_ = (rv_true - vol_pred)
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        # iterate 1-step rolling: feed last lookback feature window through net
        torch_pred = self.trainer_.predict
        sigma_path = self.garch_.forecast(horizon=horizon)
        # use deep net only for the immediate horizon, scale with sigma_path
        return np.asarray(sigma_path)


class GARCHLSTM(_GARCHDeepBase):
    factory = staticmethod(make_lstm); name = "GARCH-LSTM"


class GARCHGRU(_GARCHDeepBase):
    factory = staticmethod(make_gru); name = "GARCH-GRU"


class GARCHBiLSTM(_GARCHDeepBase):
    factory = staticmethod(make_bilstm); name = "GARCH-BiLSTM"


class GARCHCNNBiLSTM(_GARCHDeepBase):
    factory = staticmethod(make_cnn_bilstm); name = "GARCH-CNN-BiLSTM"


class GARCHAttentionLSTM(_GARCHDeepBase):
    """LSTM + (additive or multi-head) attention on top of GARCH features."""
    name = "GARCH-Attention-LSTM"

    def __init__(self, n_heads: int = 4, **kwargs):
        super().__init__(**kwargs)
        self.factory_kwargs = {"n_heads": n_heads}
        self.factory = staticmethod(make_attention_lstm)


# ===========================================================================
# 2.  ARIMA-LSTM (Zhang 2003 additive)
# ===========================================================================
class ARIMALSTM(HybridBase):
    """Zhang's additive hybrid:  y = ARIMA(y) + LSTM(residual)."""
    name = "ARIMA-LSTM"

    def __init__(self, lookback: int = 20, hidden: int = 64, layers: int = 1,
                 dropout: float = 0.1, train_cfg: Optional[TrainConfig] = None,
                 arima_order=None):
        super().__init__(name=self.name)
        self.lookback = lookback
        self.hidden = hidden; self.layers = layers; self.dropout = dropout
        self.train_cfg = train_cfg or TrainConfig()
        self.arima_order = arima_order

    def fit(self, y):
        y = np.asarray(y, dtype=float).ravel()
        self.arima_ = ARIMAWrapper(order=self.arima_order).fit(y)
        resid = np.asarray(self.arima_.residuals).ravel()
        # pad to length T
        if len(resid) < len(y):
            resid = np.r_[np.zeros(len(y) - len(resid)), resid]
        X, ytr = build_sequences(resid, self.lookback)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, ytr, val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, mu, sd = standardize(Xtr, Xv, Xte)
        self._scaler = (mu, sd)
        net = make_lstm(input_size=1, hidden=self.hidden,
                        layers=self.layers, dropout=self.dropout)
        self.trainer_ = Trainer(net, loss="mse", cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, yt, Xv_s, yv)
        self.history_ = self.trainer_.history_
        # test
        nl_pred = self.trainer_.predict(Xte_s)
        ar_pred_in = np.asarray(y[-len(yte):])      # we evaluate on the natural y
        # we need the ARIMA prediction for those samples; emulate via y - resid
        ar_pred = y[-len(yte):] - resid[-len(yte):]
        full_pred = ar_pred + nl_pred
        self.metrics_ = ev.evaluate_point_forecast(y[-len(yte):], full_pred)
        self.forecast_ = full_pred
        self.y_test_ = y[-len(yte):]
        self.residuals_ = self.y_test_ - full_pred
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        return np.asarray(self.arima_.forecast(horizon=horizon))


# ===========================================================================
# 3.  HAR-LSTM-GARCH cascade
# ===========================================================================
class HARLSTMGARCH(HybridBase):
    """Three-stage cascade for realized-volatility forecasting:

        stage 1:  HAR(RV)              → RV-baseline forecast
        stage 2:  LSTM on residual     → nonlinear correction
        stage 3:  GARCH on returns     → daily risk component
    """
    name = "HAR-LSTM-GARCH"

    def __init__(self, lookback: int = 22, hidden: int = 64,
                 train_cfg: Optional[TrainConfig] = None,
                 garch_kwargs: Optional[dict] = None,
                 rv_window: int = 22):
        super().__init__(name=self.name)
        self.lookback = lookback; self.hidden = hidden
        self.train_cfg = train_cfg or TrainConfig()
        self.garch_kwargs = garch_kwargs or {"vol": "GARCH", "p": 1, "q": 1, "dist": "t"}
        self.rv_window = rv_window

    def fit(self, returns):
        r = np.asarray(returns, dtype=float).ravel()
        # daily realized vol proxy
        rv = pd.Series(r).rolling(self.rv_window).std().bfill().to_numpy()
        # 1) HAR
        self.har_ = HAR().fit(rv)
        har_resid = self.har_.resid_
        # pad
        if len(har_resid) < len(rv):
            har_resid = np.r_[np.zeros(len(rv) - len(har_resid)), har_resid]
        # 2) LSTM on residuals
        X, y = build_sequences(har_resid, self.lookback)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, mu, sd = standardize(Xtr, Xv, Xte)
        net = make_lstm(input_size=1, hidden=self.hidden, layers=1, dropout=0.1)
        self.trainer_ = Trainer(net, loss="huber", cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, yt, Xv_s, yv)
        self.history_ = self.trainer_.history_
        # 3) GARCH on returns
        self.garch_ = GARCH(**self.garch_kwargs).fit(r)
        self.vol_in_sample_ = self.garch_.conditional_volatility
        # combined RV forecast
        nl = self.trainer_.predict(Xte_s)
        har_part = self.har_.predict(rv)[-len(yte):]
        rv_pred = har_part + nl
        rv_true = rv[-len(yte):]
        self.metrics_ = ev.evaluate_point_forecast(rv_true, rv_pred)
        self.forecast_ = rv_pred
        self.y_test_ = rv_true
        self.residuals_ = rv_true - rv_pred
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        return self.har_.forecast(horizon=horizon)


# ===========================================================================
# 4.  KAN + GARCH-MIDAS
# ===========================================================================
class KANGARCHMIDAS(HybridBase):
    """GARCH-MIDAS provides (g_t, τ_t); a KAN learns a nonlinear correction
    of the long-term component from a low-frequency macro regressor."""
    name = "KAN-GARCH-MIDAS"

    def __init__(self, K: int = 12, hidden: int = 16, grid: int = 5,
                 train_cfg: Optional[TrainConfig] = None):
        super().__init__(name=self.name)
        self.K = K; self.hidden = hidden; self.grid = grid
        self.train_cfg = train_cfg or TrainConfig(epochs=80, batch_size=64, lr=5e-3)

    def fit(self, returns, low_freq):
        r = np.asarray(returns, dtype=float).ravel()
        x = np.asarray(low_freq, dtype=float).ravel()
        self.gm_ = GARCHMIDAS(K=self.K, w_restricted=True).fit(r, x)
        self.vol_in_sample_ = self.gm_.conditional_volatility
        # KAN target = log(τ) — long-term component
        log_tau = np.log(self.gm_.tau_ + 1e-12)
        # broadcast x to length T
        if len(x) < len(r):
            x = np.repeat(x, int(np.ceil(len(r) / len(x))))[:len(r)]
        Xfull = np.column_stack([x, np.arange(len(r)) / len(r)]).astype(np.float32)
        ytr_full = log_tau.astype(np.float32)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(Xfull, ytr_full,
                                                              val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, mu, sd = standardize(Xtr, Xv, Xte)
        net = make_kan(input_size=Xfull.shape[1], hidden=self.hidden,
                       output=1, grid_size=self.grid)
        self.trainer_ = Trainer(net, loss="mse", cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, yt, Xv_s, yv)
        self.history_ = self.trainer_.history_
        # KAN-corrected long-term vol on test set
        log_tau_pred = self.trainer_.predict(Xte_s)
        tau_pred = np.exp(log_tau_pred)
        g_te = self.gm_.g_[-len(yte):]
        vol_pred = np.sqrt(np.maximum(g_te * tau_pred, 1e-12))
        rv_true = np.abs(r[-len(yte):])
        self.metrics_ = ev.evaluate_volatility_forecast(rv_true, vol_pred)
        self.forecast_ = vol_pred
        self.y_test_ = rv_true
        self.residuals_ = rv_true - vol_pred
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        # holds last τ flat (low-freq); g_t evolves slightly through the GARCH filter
        last = float(self.vol_in_sample_[-1])
        return np.full(horizon, last)


# ===========================================================================
# 5.  GAS + Multi-head Attention LSTM
# ===========================================================================
class GASATTLSTM(HybridBase):
    """GAS score-driven volatility filter + multi-head attention LSTM
    learning the residual nonlinearity."""
    name = "GAS-Attention-LSTM"

    def __init__(self, lookback: int = 20, hidden: int = 64, n_heads: int = 4,
                 train_cfg: Optional[TrainConfig] = None):
        super().__init__(name=self.name)
        self.lookback = lookback; self.hidden = hidden; self.n_heads = n_heads
        self.train_cfg = train_cfg or TrainConfig()

    def fit(self, returns):
        r = np.asarray(returns, dtype=float).ravel()
        self.gas_ = GAS().fit(r)
        sigma = self.gas_.conditional_volatility
        self.vol_in_sample_ = sigma
        feat = np.column_stack([r, sigma, r ** 2]).astype(np.float32)
        target = (r / np.maximum(sigma, 1e-8)) ** 2
        # multivariate windowing
        X = np.lib.stride_tricks.sliding_window_view(feat, (self.lookback, feat.shape[1])).squeeze(1)
        X = X[:-1].astype(np.float32)
        y = target[self.lookback:].astype(np.float32)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, mu, sd = standardize(Xtr, Xv, Xte)
        net = make_attention_lstm(input_size=feat.shape[1], hidden=self.hidden,
                                  layers=1, n_heads=self.n_heads, dropout=0.1)
        self.trainer_ = Trainer(net, loss="huber", cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, yt, Xv_s, yv)
        self.history_ = self.trainer_.history_
        z2 = self.trainer_.predict(Xte_s)
        sigma_te = sigma[-len(yte):]
        vol_pred = np.sqrt(np.maximum(z2, 1e-12)) * sigma_te
        rv_true = np.abs(r[-len(yte):])
        self.metrics_ = ev.evaluate_volatility_forecast(rv_true, vol_pred)
        self.forecast_ = vol_pred; self.y_test_ = rv_true
        self.residuals_ = rv_true - vol_pred
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        last = float(self.vol_in_sample_[-1])
        return np.full(horizon, last)


# ===========================================================================
# 6.  Deep BEKK   (Diagonal-BEKK + per-component LSTM residual)
# ===========================================================================
class DeepBEKK(HybridBase):
    """Diagonal BEKK MGARCH augmented with an LSTM residual on each marginal."""
    name = "Deep-BEKK"

    def __init__(self, lookback: int = 20, hidden: int = 32,
                 train_cfg: Optional[TrainConfig] = None):
        super().__init__(name=self.name)
        self.lookback = lookback; self.hidden = hidden
        self.train_cfg = train_cfg or TrainConfig(epochs=40, batch_size=64, lr=1e-3)

    def fit(self, returns_2d):
        R = np.asarray(returns_2d, dtype=float)
        if R.ndim != 2:
            raise ValueError("DeepBEKK needs a 2-D matrix (T, k)")
        T, k = R.shape
        self.bekk_ = DiagonalBEKK().fit(R)
        H = self.bekk_.H_                            # (T, k, k)
        self.cond_corr_ = self.bekk_.conditional_correlation()
        sigma = np.sqrt(np.diagonal(H, axis1=1, axis2=2))     # (T, k)
        self.vol_in_sample_ = sigma
        # train one LSTM per asset on (r_i / sigma_i)² target
        self.trainers_ = []
        self.y_test_per_ = []
        self.forecast_per_ = []
        for i in range(k):
            feat = np.column_stack([R[:, i], sigma[:, i]]).astype(np.float32)
            target = (R[:, i] / np.maximum(sigma[:, i], 1e-8)) ** 2
            X = np.lib.stride_tricks.sliding_window_view(feat, (self.lookback, 2)).squeeze(1)
            X = X[:-1].astype(np.float32)
            y = target[self.lookback:].astype(np.float32)
            (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
            Xtr_s, Xv_s, Xte_s, *_ = standardize(Xtr, Xv, Xte)
            net = make_lstm(input_size=2, hidden=self.hidden, layers=1, dropout=0.1)
            tr = Trainer(net, loss="huber", cfg=self.train_cfg).fit(Xtr_s, yt, Xv_s, yv)
            self.trainers_.append(tr)
            z2 = tr.predict(Xte_s)
            vol_pred = np.sqrt(np.maximum(z2, 1e-12)) * sigma[-len(yte):, i]
            rv_true = np.abs(R[-len(yte):, i])
            self.y_test_per_.append(rv_true)
            self.forecast_per_.append(vol_pred)
        # aggregate metrics: avg across assets
        per = [ev.evaluate_volatility_forecast(t, p)
               for t, p in zip(self.y_test_per_, self.forecast_per_)]
        self.metrics_ = {k: float(np.mean([d[k] for d in per])) for k in per[0]}
        self.forecast_ = np.column_stack(self.forecast_per_)
        self.y_test_ = np.column_stack(self.y_test_per_)
        self.residuals_ = (self.y_test_ - self.forecast_).ravel()
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        last = self.vol_in_sample_[-1]
        return np.tile(last, (horizon, 1))


# ===========================================================================
# 7.  Deep VAR (per-equation LSTM residual)
# ===========================================================================
class DeepVAR(HybridBase):
    """VAR baseline + LSTM residual on each equation."""
    name = "Deep-VAR"

    def __init__(self, lags: int | str = "aic", lookback: int = 20,
                 hidden: int = 32, train_cfg: Optional[TrainConfig] = None):
        super().__init__(name=self.name)
        self.lags = lags; self.lookback = lookback; self.hidden = hidden
        self.train_cfg = train_cfg or TrainConfig(epochs=40)

    def fit(self, df):
        Y = pd.DataFrame(df).astype(float)
        T, k = Y.shape
        self.var_ = VARWrapper(lags=self.lags).fit(Y)
        resid = np.asarray(self.var_.residuals)
        # pad to T
        if len(resid) < T:
            resid = np.vstack([np.zeros((T - len(resid), k)), resid])
        self.trainers_ = []
        self.metrics_per_ = []
        forecasts = []
        for i in range(k):
            X, y = build_sequences(resid[:, i], self.lookback)
            (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
            Xtr_s, Xv_s, Xte_s, *_ = standardize(Xtr, Xv, Xte)
            net = make_lstm(input_size=1, hidden=self.hidden, layers=1, dropout=0.1)
            tr = Trainer(net, loss="mse", cfg=self.train_cfg).fit(Xtr_s, yt, Xv_s, yv)
            self.trainers_.append(tr)
            pred = tr.predict(Xte_s)
            self.metrics_per_.append(ev.evaluate_point_forecast(yte, pred))
            forecasts.append(pred)
        self.metrics_ = {k_: float(np.mean([d[k_] for d in self.metrics_per_]))
                         for k_ in self.metrics_per_[0]}
        self.forecast_ = np.column_stack(forecasts)
        self.residuals_ = (resid[-len(forecasts[0]):, :] - self.forecast_).ravel()
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        return self.var_.forecast(horizon=horizon)


# ===========================================================================
# 8.  Deep Quantile VaR  (LSTM with pinball loss → conditional VaR)
# ===========================================================================
class DeepQuantileVaR(HybridBase):
    """LSTM trained with pinball loss to produce conditional VaR forecasts.
    Pre-conditions on GARCH conditional volatility as an auxiliary feature."""
    name = "Deep-Quantile-VaR"

    def __init__(self, alpha: float = 0.05, lookback: int = 20, hidden: int = 64,
                 train_cfg: Optional[TrainConfig] = None,
                 garch_kwargs: Optional[dict] = None):
        super().__init__(name=self.name)
        self.alpha = alpha
        self.lookback = lookback; self.hidden = hidden
        self.train_cfg = train_cfg or TrainConfig(epochs=80)
        self.garch_kwargs = garch_kwargs or {"vol": "GARCH", "dist": "t"}

    def fit(self, returns):
        r = np.asarray(returns, dtype=float).ravel()
        self.garch_ = GARCH(**self.garch_kwargs).fit(r)
        sigma = self.garch_.conditional_volatility
        self.vol_in_sample_ = sigma
        feat = np.column_stack([r, sigma]).astype(np.float32)
        X = np.lib.stride_tricks.sliding_window_view(feat, (self.lookback, 2)).squeeze(1)
        X = X[:-1].astype(np.float32)
        y = r[self.lookback:].astype(np.float32)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, *_ = standardize(Xtr, Xv, Xte)
        net = make_lstm(input_size=2, hidden=self.hidden, layers=1, dropout=0.1)
        loss = pinball_loss_factory(self.alpha)
        self.trainer_ = Trainer(net, loss=loss, cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, yt, Xv_s, yv)
        self.history_ = self.trainer_.history_
        var_pred = self.trainer_.predict(Xte_s)
        self.forecast_ = var_pred
        self.y_test_ = yte
        # backtest
        self.diagnostics_["var_backtest"] = ev.var_backtest_table(
            yte, var_pred, alpha=self.alpha)
        self.metrics_ = {"hit_rate": float(np.mean(yte < var_pred)),
                         "alpha": self.alpha,
                         "MAE": ev.mae(yte, var_pred)}
        self.residuals_ = yte - var_pred
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        last = float(self.forecast_[-1]) if self.forecast_ is not None else 0.0
        return np.full(horizon, last)


# ===========================================================================
# 9.  Regime-Aware LSTM-GARCH
# ===========================================================================
class RegimeAwareLSTMGARCH(HybridBase):
    """HMM regime detector → regime-specific LSTM heads on top of GARCH features."""
    name = "Regime-Aware-LSTM-GARCH"

    def __init__(self, n_states: int = 2, lookback: int = 20, hidden: int = 64,
                 train_cfg: Optional[TrainConfig] = None,
                 garch_kwargs: Optional[dict] = None):
        super().__init__(name=self.name)
        self.n_states = n_states; self.lookback = lookback; self.hidden = hidden
        self.train_cfg = train_cfg or TrainConfig(epochs=50)
        self.garch_kwargs = garch_kwargs or {"vol": "GJR-GARCH", "dist": "t"}

    def fit(self, returns):
        r = np.asarray(returns, dtype=float).ravel()
        self.garch_ = GARCH(**self.garch_kwargs).fit(r)
        sigma = self.garch_.conditional_volatility
        self.vol_in_sample_ = sigma
        # regime detection on (|r|, sigma)
        feats = np.column_stack([np.abs(r), sigma])
        self.regime_ = HMMRegime(n_states=self.n_states).fit(feats)
        self.states_ = self.regime_.states
        # build per-regime LSTMs
        feat = np.column_stack([r, sigma]).astype(np.float32)
        target = (r / np.maximum(sigma, 1e-8)) ** 2
        X = np.lib.stride_tricks.sliding_window_view(feat, (self.lookback, 2)).squeeze(1)
        X = X[:-1].astype(np.float32)
        y = target[self.lookback:].astype(np.float32)
        s = self.states_[self.lookback:]
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
        ntr = len(Xtr); nv = len(Xv)
        s_tr, s_v, s_te = s[:ntr], s[ntr:ntr + nv], s[-len(yte):]
        Xtr_s, Xv_s, Xte_s, *_ = standardize(Xtr, Xv, Xte)
        self.trainers_ = {}
        for k in range(self.n_states):
            mtr = (s_tr == k); mv = (s_v == k)
            if mtr.sum() < 50 or mv.sum() < 5:
                continue
            net = make_lstm(input_size=2, hidden=self.hidden, layers=1, dropout=0.1)
            self.trainers_[k] = Trainer(net, loss="huber", cfg=self.train_cfg).fit(
                Xtr_s[mtr], yt[mtr], Xv_s[mv], yv[mv])
        # forecast on test by regime
        z2 = np.zeros(len(yte))
        for k, tr in self.trainers_.items():
            mte = (s_te == k)
            if mte.any():
                z2[mte] = tr.predict(Xte_s[mte])
        # fall-back: when a state has no model, use sigma directly
        z2 = np.where(z2 > 0, z2, 1.0)
        sigma_te = sigma[-len(yte):]
        vol_pred = np.sqrt(np.maximum(z2, 1e-12)) * sigma_te
        rv_true = np.abs(r[-len(yte):])
        self.metrics_ = ev.evaluate_volatility_forecast(rv_true, vol_pred)
        self.forecast_ = vol_pred; self.y_test_ = rv_true
        self.residuals_ = rv_true - vol_pred
        # take the longest available history list
        h = max((tr.history_ for tr in self.trainers_.values()),
                key=lambda d: len(d.get("train", [])), default={})
        self.history_ = h
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        last = float(self.vol_in_sample_[-1])
        return np.full(horizon, last)

    def plot(self, prefix: Optional[str] = None):
        super().plot(prefix=prefix)
        # extra: regime ribbon
        try:
            r_series = pd.Series(self.y_test_)
            viz.plot_regime_ribbon(r_series, self.states_[-len(self.y_test_):],
                                   labels=self.regime_.labels,
                                   filename=f"{(prefix or self.name.lower())}_regime.png")
        except Exception:
            pass
        return self


# ===========================================================================
# 10.  ARFIMA-LSTM   (long-memory additive hybrid; Stempień & Ślepaczuk 2025)
# ===========================================================================
class ARFIMALSTM(ARIMALSTM):
    """ARFIMA(p,d,q) baseline + LSTM residual. Uses ARFIMAWrapper which
    estimates d via the GPH log-periodogram regression, then fits ARMA(p,q)
    on the fractionally-differenced series. The LSTM corrects nonlinear
    residual patterns (Zhang-2003 additive composition)."""
    name = "ARFIMA-LSTM"

    def fit(self, y):
        from .econometric import ARFIMAWrapper
        y = np.asarray(y, dtype=float).ravel()
        self.arima_ = ARFIMAWrapper(p=1, q=1).fit(y)
        # mimic an ARIMAWrapper's residual API
        try:
            resid = np.asarray(self.arima_._fit.resid).ravel()
        except Exception:
            resid = np.zeros_like(y)
        if len(resid) < len(y):
            resid = np.r_[np.zeros(len(y) - len(resid)), resid]
        X, ytr = build_sequences(resid, self.lookback)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, ytr, val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, *_ = standardize(Xtr, Xv, Xte)
        net = make_lstm(input_size=1, hidden=self.hidden,
                        layers=self.layers, dropout=self.dropout)
        self.trainer_ = Trainer(net, loss="mse", cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, yt, Xv_s, yv)
        self.history_ = self.trainer_.history_
        nl_pred = self.trainer_.predict(Xte_s)
        ar_pred = y[-len(yte):] - resid[-len(yte):]
        full_pred = ar_pred + nl_pred
        self.metrics_ = ev.evaluate_point_forecast(y[-len(yte):], full_pred)
        self.forecast_ = full_pred
        self.y_test_ = y[-len(yte):]
        self.residuals_ = self.y_test_ - full_pred
        return self


# ===========================================================================
# 11.  MIDAS-LSTM   (mixed-frequency mean forecaster, Du et al. 2025)
# ===========================================================================
class MIDASLSTM(HybridBase):
    """Mixed-frequency mean forecasting hybrid.

    Pipeline:
        1.  Beta-weighted MIDAS aggregation of one or more low-frequency
            macro variables to the high-frequency target index.
        2.  Pearson-correlation feature selection (top-k by |ρ|).
        3.  LSTM on (high-freq target lags, MIDAS-aggregated factors)
            → next-step level forecast.

    Mirrors Du, Ji, Du & Wang (2025) — minus the PSO hyperparameter search
    which is left to the user (hyperparameters are passed in `train_cfg`).
    """
    name = "MIDAS-LSTM"

    def __init__(self, K: int = 12, lookback: int = 20, hidden: int = 64,
                 top_k: int = 5, w1: float = 1.0, w2: float = 5.0,
                 train_cfg: Optional[TrainConfig] = None):
        super().__init__(name=self.name)
        self.K = K; self.lookback = lookback; self.hidden = hidden
        self.top_k = top_k; self.w1 = w1; self.w2 = w2
        self.train_cfg = train_cfg or TrainConfig()

    @staticmethod
    def _beta_weights(K, w1, w2):
        k = np.arange(1, K + 1) / (K + 1)
        w = (k ** (w1 - 1)) * ((1 - k) ** (w2 - 1))
        return w / w.sum()

    def _midas_aggregate(self, low_freq_2d, T):
        """Beta-weighted MIDAS: collapse a (T_low, p) panel into (T, p) at high-freq."""
        X = np.asarray(low_freq_2d, dtype=float)
        if X.ndim == 1: X = X[:, None]
        Tl, p = X.shape
        # broadcast each col to length T
        Xhi = np.empty((T, p))
        for j in range(p):
            Xhi[:, j] = np.repeat(X[:, j], int(np.ceil(T / Tl)))[:T]
        # MIDAS-weighted lag aggregation
        wts = self._beta_weights(self.K, self.w1, self.w2)
        out = np.zeros((T, p))
        for t in range(T):
            window = Xhi[max(t - self.K, 0):t]
            if len(window) < self.K:
                pad = np.zeros((self.K - len(window), p))
                window = np.vstack([pad, window])
            out[t] = wts @ window[::-1]
        return out

    def fit(self, y, low_freq):
        y = np.asarray(y, dtype=float).ravel()
        T = len(y)
        Z = self._midas_aggregate(low_freq, T)            # (T, p)
        # 2) Pearson selection: keep top_k columns by |ρ| with y
        if Z.shape[1] > self.top_k:
            rho = np.array([abs(np.corrcoef(Z[:, j], y)[0, 1]) for j in range(Z.shape[1])])
            sel = np.argsort(rho)[::-1][:self.top_k]
            Z = Z[:, sel]; self.selected_ = sel
        else:
            self.selected_ = np.arange(Z.shape[1])
        # 3) feature matrix per timestep = [y_lag, Z_t]
        feat = np.column_stack([y, Z]).astype(np.float32)
        X = np.lib.stride_tricks.sliding_window_view(feat, (self.lookback, feat.shape[1])).squeeze(1)
        X = X[:-1].astype(np.float32)
        target = y[self.lookback:].astype(np.float32)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, target, val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, *_ = standardize(Xtr, Xv, Xte)
        net = make_lstm(input_size=feat.shape[1], hidden=self.hidden,
                        layers=1, dropout=0.1)
        self.trainer_ = Trainer(net, loss="mse", cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, yt, Xv_s, yv)
        self.history_ = self.trainer_.history_
        pred = self.trainer_.predict(Xte_s)
        self.metrics_ = ev.evaluate_point_forecast(yte, pred)
        self.forecast_ = pred; self.y_test_ = yte
        self.residuals_ = yte - pred
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        last = float(self.forecast_[-1]) if self.forecast_ is not None else 0.0
        return np.full(horizon, last)


# ===========================================================================
# 12.  MIDAS-CNN-BiLSTM-Attention   (Zhang, Zhang & Hu 2025)
# ===========================================================================
class MIDASCNNBiLSTMAttention(HybridBase):
    """GARCH-MIDAS components (g_t, τ_t) → CNN → BiLSTM → multi-head attention
    architecture for stock-market volatility forecasting with macro features."""
    name = "MIDAS-CNN-BiLSTM-Attention"

    def __init__(self, K: int = 12, lookback: int = 20, hidden: int = 64,
                 conv_filters: int = 32, kernel: int = 3, n_heads: int = 4,
                 train_cfg: Optional[TrainConfig] = None):
        super().__init__(name=self.name)
        self.K = K; self.lookback = lookback; self.hidden = hidden
        self.conv_filters = conv_filters; self.kernel = kernel
        self.n_heads = n_heads
        self.train_cfg = train_cfg or TrainConfig()

    def fit(self, returns, low_freq):
        r = np.asarray(returns, dtype=float).ravel()
        x = np.asarray(low_freq, dtype=float).ravel()
        self.gm_ = GARCHMIDAS(K=self.K, w_restricted=True).fit(r, x)
        sigma = self.gm_.conditional_volatility
        g = self.gm_.g_; tau = self.gm_.tau_
        self.vol_in_sample_ = sigma
        # features = [r, sigma, log g, log τ]
        feat = np.column_stack([r, sigma,
                                np.log(g + 1e-12),
                                np.log(tau + 1e-12)]).astype(np.float32)
        target = (r / np.maximum(sigma, 1e-8)) ** 2
        X = np.lib.stride_tricks.sliding_window_view(feat, (self.lookback, feat.shape[1])).squeeze(1)
        X = X[:-1].astype(np.float32)
        y = target[self.lookback:].astype(np.float32)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
        Xtr_s, Xv_s, Xte_s, *_ = standardize(Xtr, Xv, Xte)
        net = make_cnn_bilstm_attention(input_size=feat.shape[1],
                                        conv_filters=self.conv_filters,
                                        kernel=self.kernel, hidden=self.hidden,
                                        layers=1, dropout=0.1, n_heads=self.n_heads)
        self.trainer_ = Trainer(net, loss="huber", cfg=self.train_cfg)
        self.trainer_.fit(Xtr_s, yt, Xv_s, yv)
        self.history_ = self.trainer_.history_
        z2 = self.trainer_.predict(Xte_s)
        sigma_te = sigma[-len(yte):]
        vol_pred = np.sqrt(np.maximum(z2, 1e-12)) * sigma_te
        rv_true = np.abs(r[-len(yte):])
        self.metrics_ = ev.evaluate_volatility_forecast(rv_true, vol_pred)
        self.forecast_ = vol_pred; self.y_test_ = rv_true
        self.residuals_ = rv_true - vol_pred
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        last = float(self.vol_in_sample_[-1])
        return np.full(horizon, last)


# ===========================================================================
# 13.  Deep-TVAR   (Li & Yuan 2023 — LSTM-driven time-varying VAR
#                  with Ansley-Kohn-style spectral-radius stability)
# ===========================================================================
class DeepTVAR(HybridBase):
    """LSTM-generated time-varying VAR(1) coefficients.

    For each t the LSTM emits a raw matrix M_t ∈ ℝ^{k×k}. To enforce stability
    (eigenvalues of the VAR(1) coefficient matrix inside the unit circle) we
    apply a spectral-radius rescaling — a practical proxy for the
    Ansley & Kohn (1986) PACF-based parameterization used in the original paper.

        A_t = M_t / max(1, ρ(M_t) / ρ_max)        with ρ_max = 0.99

    Innovations are assumed Gaussian with diagonal Σ. Loss = log-likelihood.
    """
    name = "Deep-TVAR"

    def __init__(self, lookback: int = 20, hidden: int = 32,
                 rho_max: float = 0.99,
                 train_cfg: Optional[TrainConfig] = None):
        super().__init__(name=self.name)
        self.lookback = lookback; self.hidden = hidden
        self.rho_max = rho_max
        self.train_cfg = train_cfg or TrainConfig(epochs=40, batch_size=32, lr=5e-3)

    def _build_net(self, k):
        from .deep import _torch
        torch = _torch(); nn = torch.nn

        rho_max = self.rho_max

        class _DeepTVAR(nn.Module):
            def __init__(self, k, hidden):
                super().__init__()
                self.k = k
                self.lstm = nn.LSTM(k, hidden, batch_first=True)
                self.proj = nn.Linear(hidden, k * k + k)   # k*k for A_t, k for log-σ

            def stable(self, M):
                # M: (B, k, k) — divide by max(1, ρ/ρ_max)
                # use power iteration approximation: ρ ≈ max singular value
                u, s, v = torch.linalg.svd(M)
                rho = s[..., 0]
                scale = torch.clamp(rho / rho_max, min=1.0)
                return M / scale.unsqueeze(-1).unsqueeze(-1)

            def forward(self, x):                          # x: (B, T, k)
                o, _ = self.lstm(x)                        # (B, T, H)
                last = o[:, -1, :]
                out = self.proj(last)
                A = out[:, :self.k * self.k].reshape(-1, self.k, self.k)
                A = self.stable(A)
                log_sigma = out[:, -self.k:]
                return A, log_sigma
        return _DeepTVAR(k, self.hidden)

    def fit(self, df):
        from .deep import _torch
        torch = _torch()
        Y = np.asarray(pd.DataFrame(df).astype(float))
        T, k = Y.shape
        # build sliding windows: predict y_{t+1} from window of length L
        X = np.lib.stride_tricks.sliding_window_view(Y, (self.lookback, k)).squeeze(1)
        X = X[:-1].astype(np.float32)                       # (N, L, k)
        y = Y[self.lookback:].astype(np.float32)            # (N, k)
        (Xtr, Xv, Xte), (yt, yv, yte) = train_val_test_split(X, y, val=0.1, test=0.2)
        net = self._build_net(k)
        device = "cuda" if torch.cuda.is_available() else "cpu"
        net = net.to(device)
        opt = torch.optim.Adam(net.parameters(), lr=self.train_cfg.lr)
        Xtr_t = torch.from_numpy(Xtr).to(device); yt_t = torch.from_numpy(yt).to(device)
        Xv_t = torch.from_numpy(Xv).to(device);   yv_t = torch.from_numpy(yv).to(device)
        history = {"train": [], "val": []}
        best, best_state, bad = float("inf"), None, 0
        for ep in range(self.train_cfg.epochs):
            net.train(); opt.zero_grad()
            A, log_sig = net(Xtr_t)                         # A:(N,k,k)
            last_lag = Xtr_t[:, -1, :]                      # (N, k)
            mu_hat = torch.einsum("nij,nj->ni", A, last_lag)
            sig2 = torch.exp(2 * log_sig).clamp(min=1e-6)
            ll = -0.5 * (((yt_t - mu_hat) ** 2 / sig2) + 2 * log_sig).sum(dim=1)
            loss = -ll.mean()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), self.train_cfg.grad_clip)
            opt.step()
            history["train"].append(float(loss.detach()))
            net.eval()
            with torch.no_grad():
                Av, lsv = net(Xv_t)
                muv = torch.einsum("nij,nj->ni", Av, Xv_t[:, -1, :])
                vloss = ((yv_t - muv) ** 2).mean()
            history["val"].append(float(vloss))
            if float(vloss) < best - 1e-6:
                best = float(vloss); bad = 0
                best_state = {kk: v.detach().clone() for kk, v in net.state_dict().items()}
            else:
                bad += 1
                if bad >= self.train_cfg.patience: break
        if best_state is not None: net.load_state_dict(best_state)
        self.history_ = history
        self.net_ = net
        # test
        Xte_t = torch.from_numpy(Xte).to(device)
        net.eval()
        with torch.no_grad():
            Ate, _ = net(Xte_t)
            mute = torch.einsum("nij,nj->ni", Ate, Xte_t[:, -1, :]).cpu().numpy()
        self.A_test_ = Ate.cpu().numpy()
        self.forecast_ = mute
        self.y_test_ = yte
        per = [ev.evaluate_point_forecast(yte[:, j], mute[:, j]) for j in range(k)]
        self.metrics_ = {key: float(np.mean([d[key] for d in per])) for key in per[0]}
        self.residuals_ = (yte - mute).ravel()
        # save spectral radius series for diagnostic
        self.rho_t_ = np.array([np.max(np.abs(np.linalg.eigvals(M))) for M in self.A_test_])
        return self

    def forecast(self, horizon: int = 1) -> np.ndarray:
        # use most recent A_t and last observation; iterate the VAR
        from .deep import _torch
        torch = _torch()
        last_A = self.A_test_[-1]
        last_y = self.y_test_[-1]
        out = np.empty((horizon, last_A.shape[0]))
        cur = last_y.copy()
        for h in range(horizon):
            cur = last_A @ cur
            out[h] = cur
        return out

    def plot(self, prefix: Optional[str] = None):
        super().plot(prefix=prefix)
        try:
            viz.plot_series(self.rho_t_, title="Deep-TVAR — spectral radius ρ(A_t)",
                            ylabel="ρ", filename=f"{(prefix or self.name.lower())}_rho.png")
        except Exception:
            pass
        return self


# ===========================================================================
# 14.  Convenience benchmark runner
# ===========================================================================
def run_benchmark(returns, models: Optional[list] = None,
                  alpha_mcs: float = 0.10) -> pd.DataFrame:
    """Fit a list of hybrid models on the same series and rank them via MCS.

    Each model must follow the HybridBase contract.
    """
    if models is None:
        models = [GARCHLSTM(), GARCHGRU(), GARCHBiLSTM(), GARCHAttentionLSTM(),
                  HARLSTMGARCH()]
    losses = {}
    summary_rows = []
    for m in models:
        m.fit(returns)
        # squared error on the volatility proxy as the loss series
        losses[m.name] = (np.asarray(m.y_test_) - np.asarray(m.forecast_)) ** 2
        summary_rows.append({"model": m.name, **m.metrics_})
    # truncate to common length
    L = min(len(v) for v in losses.values())
    loss_df = pd.DataFrame({k: v[-L:] for k, v in losses.items()})
    mcs = ev.model_confidence_set(loss_df, alpha=alpha_mcs)
    viz.plot_mcs_heatmap(mcs, filename="benchmark_mcs.png")
    metrics_df = pd.DataFrame(summary_rows)
    viz.table(metrics_df, fmt="github", caption="Benchmark — point metrics",
              filename="benchmark_metrics")
    viz.table(mcs, fmt="github", caption="Benchmark — Model Confidence Set",
              filename="benchmark_mcs")
    return metrics_df.merge(mcs, on="model", how="left")
