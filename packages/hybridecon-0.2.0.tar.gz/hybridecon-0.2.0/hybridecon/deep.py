"""
Deep-learning building blocks: LSTM, GRU, BiLSTM, CNN-BiLSTM, Additive Attention,
Multi-Head Attention, Kolmogorov-Arnold Network (KAN), and a generic Trainer
with early stopping, ReduceLROnPlateau and gradient clipping.

PyTorch is the backend. Import is lazy so that users without `torch` can still
use the econometric and diagnostics modules.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np


def _torch():
    try:
        import torch
        return torch
    except ImportError as e:                                            # pragma: no cover
        raise ImportError("install torch:  pip install torch") from e


# ===========================================================================
# 1.  Backbones
# ===========================================================================
def make_lstm(input_size=1, hidden=64, layers=1, dropout=0.0, bidir=False):
    torch = _torch(); nn = torch.nn

    class _Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(input_size, hidden, layers, batch_first=True,
                                dropout=dropout if layers > 1 else 0.0,
                                bidirectional=bidir)
            self.head = nn.Linear(hidden * (2 if bidir else 1), 1)
        def forward(self, x):
            out, _ = self.lstm(x)
            return self.head(out[:, -1, :])
    return _Net()


def make_gru(input_size=1, hidden=64, layers=1, dropout=0.0):
    torch = _torch(); nn = torch.nn
    class _Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.gru = nn.GRU(input_size, hidden, layers, batch_first=True,
                              dropout=dropout if layers > 1 else 0.0)
            self.head = nn.Linear(hidden, 1)
        def forward(self, x):
            out, _ = self.gru(x); return self.head(out[:, -1, :])
    return _Net()


def make_bilstm(input_size=1, hidden=64, layers=1, dropout=0.0):
    return make_lstm(input_size, hidden, layers, dropout, bidir=True)


def make_cnn_bilstm(input_size=1, conv_filters=32, kernel=3,
                    hidden=64, layers=1, dropout=0.1):
    torch = _torch(); nn = torch.nn

    class _Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.conv = nn.Sequential(
                nn.Conv1d(input_size, conv_filters, kernel, padding=kernel // 2),
                nn.ReLU(),
                nn.Dropout(dropout),
            )
            self.bilstm = nn.LSTM(conv_filters, hidden, layers, batch_first=True,
                                  bidirectional=True,
                                  dropout=dropout if layers > 1 else 0.0)
            self.head = nn.Linear(hidden * 2, 1)
        def forward(self, x):
            # x: (B, T, F) -> conv expects (B, F, T)
            h = self.conv(x.transpose(1, 2)).transpose(1, 2)
            o, _ = self.bilstm(h)
            return self.head(o[:, -1, :])
    return _Net()


def make_cnn_bilstm_attention(input_size=1, conv_filters=32, kernel=3,
                              hidden=64, layers=1, dropout=0.1,
                              n_heads: int = 4):
    """CNN → BiLSTM → multi-head attention (Zhang, Zhang & Hu 2025 architecture)."""
    torch = _torch(); nn = torch.nn

    class _Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.conv = nn.Sequential(
                nn.Conv1d(input_size, conv_filters, kernel, padding=kernel // 2),
                nn.ReLU(),
                nn.Dropout(dropout),
            )
            self.bilstm = nn.LSTM(conv_filters, hidden, layers, batch_first=True,
                                  bidirectional=True,
                                  dropout=dropout if layers > 1 else 0.0)
            self.attn = nn.MultiheadAttention(hidden * 2, num_heads=n_heads,
                                              batch_first=True, dropout=dropout)
            self.head = nn.Linear(hidden * 2, 1)

        def forward(self, x):
            h = self.conv(x.transpose(1, 2)).transpose(1, 2)
            o, _ = self.bilstm(h)
            ctx, _ = self.attn(o, o, o)
            return self.head(ctx[:, -1, :])
    return _Net()


# ===========================================================================
# 2.  Attention
# ===========================================================================
def make_attention_lstm(input_size=1, hidden=64, layers=1,
                        dropout=0.0, n_heads: int = 0):
    """LSTM whose final prediction uses additive (Bahdanau) attention if
    `n_heads==0`, otherwise multi-head self-attention."""
    torch = _torch(); nn = torch.nn
    class _Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(input_size, hidden, layers, batch_first=True,
                                dropout=dropout if layers > 1 else 0.0)
            if n_heads:
                self.attn = nn.MultiheadAttention(hidden, num_heads=n_heads,
                                                  batch_first=True, dropout=dropout)
                self.is_mha = True
            else:
                self.W = nn.Linear(hidden, hidden)
                self.v = nn.Linear(hidden, 1, bias=False)
                self.is_mha = False
            self.head = nn.Linear(hidden, 1)
        def forward(self, x):
            o, _ = self.lstm(x)                  # (B, T, H)
            if self.is_mha:
                ctx, _ = self.attn(o, o, o)
                z = ctx[:, -1, :]
            else:
                e = self.v(torch.tanh(self.W(o))).squeeze(-1)   # (B, T)
                a = torch.softmax(e, dim=1).unsqueeze(-1)
                z = (a * o).sum(dim=1)
            return self.head(z)
    return _Net()


# ===========================================================================
# 3.  Kolmogorov-Arnold Network  (compact spline-on-edges variant)
# ===========================================================================
def make_kan(input_size: int = 1, hidden: int = 16, output: int = 1,
             grid_size: int = 5):
    """Minimal KAN layer: each edge has a learnable cubic-spline activation.
    Two-layer (hidden, output)."""
    torch = _torch(); nn = torch.nn

    class _SplineLinear(nn.Module):
        def __init__(self, in_f, out_f, grid):
            super().__init__()
            self.in_f, self.out_f, self.grid = in_f, out_f, grid
            # one set of grid coefs per (in,out) edge
            self.coef = nn.Parameter(torch.randn(in_f, out_f, grid) * 0.05)
            self.scale = nn.Parameter(torch.ones(in_f, out_f))
            self.base = nn.Parameter(torch.randn(in_f, out_f) * 0.05)

        def forward(self, x):                                   # x: (B, in_f)
            # piecewise-linear "spline" on a fixed grid in [-1, 1]
            grid = torch.linspace(-1, 1, self.grid, device=x.device)
            # broadcast: (B, in, 1) - (grid,) -> (B, in, G)
            d = (x.unsqueeze(-1) - grid).clamp(min=0)
            phi = d / (1.0 + d)                                   # smooth basis
            # contract: (B, in, G) × (in, out, G) -> (B, in, out)
            edge = torch.einsum("big,iog->bio", phi, self.coef)
            edge = edge * self.scale + self.base
            return edge.sum(dim=1)                              # (B, out)

    class _KAN(nn.Module):
        def __init__(self):
            super().__init__()
            self.l1 = _SplineLinear(input_size, hidden, grid_size)
            self.l2 = _SplineLinear(hidden, output, grid_size)
        def forward(self, x):                       # x: (B, in_f)  or (B, T, F)
            if x.dim() == 3: x = x.mean(dim=1)
            return self.l2(torch.tanh(self.l1(x)))
    return _KAN()


# ===========================================================================
# 4.  Trainer
# ===========================================================================
@dataclass
class TrainConfig:
    epochs: int = 60
    batch_size: int = 64
    lr: float = 1e-3
    weight_decay: float = 0.0
    grad_clip: float = 1.0
    patience: int = 10
    factor: float = 0.5
    min_lr: float = 1e-6
    verbose: bool = False


class Trainer:
    """Generic supervised trainer used by every hybrid model."""

    def __init__(self, model, loss="mse", cfg: Optional[TrainConfig] = None,
                 device: Optional[str] = None):
        torch = _torch()
        self.cfg = cfg or TrainConfig()
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = model.to(self.device)
        if loss == "mse":
            self.loss_fn = torch.nn.MSELoss()
        elif loss == "mae":
            self.loss_fn = torch.nn.L1Loss()
        elif loss == "huber":
            self.loss_fn = torch.nn.SmoothL1Loss()
        elif callable(loss):
            self.loss_fn = loss
        else:
            raise ValueError(loss)
        self.history_ = {"train": [], "val": []}

    def fit(self, X, y, X_val=None, y_val=None):
        torch = _torch()
        ds = torch.utils.data.TensorDataset(torch.from_numpy(np.asarray(X, np.float32)),
                                            torch.from_numpy(np.asarray(y, np.float32)))
        dl = torch.utils.data.DataLoader(ds, batch_size=self.cfg.batch_size, shuffle=True)
        opt = torch.optim.Adam(self.model.parameters(),
                               lr=self.cfg.lr, weight_decay=self.cfg.weight_decay)
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(
            opt, mode="min", factor=self.cfg.factor,
            patience=self.cfg.patience // 2, min_lr=self.cfg.min_lr)
        best, best_state, bad = float("inf"), None, 0
        for ep in range(self.cfg.epochs):
            self.model.train(); train_loss = 0.0
            for xb, yb in dl:
                xb, yb = xb.to(self.device), yb.to(self.device).reshape(-1, 1)
                opt.zero_grad()
                pred = self.model(xb)
                loss = self.loss_fn(pred, yb)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.grad_clip)
                opt.step()
                train_loss += float(loss.detach()) * xb.size(0)
            train_loss /= len(ds)
            self.history_["train"].append(train_loss)
            val_loss = self._eval(X_val, y_val) if X_val is not None else train_loss
            self.history_["val"].append(val_loss)
            sched.step(val_loss)
            if val_loss < best - 1e-6:
                best = val_loss; bad = 0
                best_state = {k: v.detach().clone() for k, v in self.model.state_dict().items()}
            else:
                bad += 1
                if bad >= self.cfg.patience:
                    if self.cfg.verbose: print(f"early stop @ epoch {ep}")
                    break
            if self.cfg.verbose:
                print(f"ep {ep:03d}  train={train_loss:.5f}  val={val_loss:.5f}")
        if best_state is not None:
            self.model.load_state_dict(best_state)
        return self

    def _eval(self, X, y):
        torch = _torch()
        self.model.eval()
        with torch.no_grad():
            xb = torch.from_numpy(np.asarray(X, np.float32)).to(self.device)
            yb = torch.from_numpy(np.asarray(y, np.float32)).to(self.device).reshape(-1, 1)
            return float(self.loss_fn(self.model(xb), yb))

    def predict(self, X):
        torch = _torch()
        self.model.eval()
        with torch.no_grad():
            xb = torch.from_numpy(np.asarray(X, np.float32)).to(self.device)
            return self.model(xb).cpu().numpy().ravel()


# ===========================================================================
# 5.  Pinball / quantile loss
# ===========================================================================
def pinball_loss_factory(tau: float):
    torch = _torch()
    def _loss(pred, target):
        diff = target - pred
        return torch.maximum(tau * diff, (tau - 1) * diff).mean()
    return _loss
