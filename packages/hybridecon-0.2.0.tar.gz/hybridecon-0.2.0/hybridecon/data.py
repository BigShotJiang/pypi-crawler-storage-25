"""Data loaders: CSV, demo synthetic series, optional Yahoo Finance."""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd

from .utils import log_returns, realized_volatility


def load_csv(path: str | Path,
             date_col: str = "Date",
             price_col: str = "Close") -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=[date_col])
    df = df.sort_values(date_col).set_index(date_col)
    out = pd.DataFrame({"price": df[price_col].astype(float)})
    out["return"] = log_returns(out["price"], dropna=False)
    out["rv22"] = realized_volatility(out["return"], window=22)
    return out


def load_yahoo(ticker: str, start: str = "2000-01-01",
               end: Optional[str] = None) -> pd.DataFrame:
    """Optional convenience loader. Requires `yfinance`."""
    try:
        import yfinance as yf
    except ImportError as e:
        raise ImportError("install yfinance:  pip install yfinance") from e
    raw = yf.download(ticker, start=start, end=end, auto_adjust=True, progress=False)
    df = pd.DataFrame({"price": raw["Close"].astype(float)})
    df["return"] = log_returns(df["price"], dropna=False)
    df["rv22"] = realized_volatility(df["return"], window=22)
    return df.dropna()


def load_demo_returns(asset: str = "SPX", n: int = 3000, seed: int = 42) -> pd.Series:
    """Synthetic mean-reverting log-returns with stochastic-volatility bursts.

    Returns a 1-D pd.Series of log-returns (no NaNs). For the full
    price/return/rv panel use :func:`load_demo_panel`.
    """
    rng = np.random.default_rng(seed)
    sigma = np.empty(n)
    sigma[0] = 0.01
    for t in range(1, n):
        sigma[t] = 0.0001 + 0.92 * sigma[t - 1] + 0.07 * abs(rng.standard_t(df=6)) * 0.01
    r = rng.standard_t(df=6, size=n) * sigma
    idx = pd.bdate_range("2010-01-01", periods=n)
    s = pd.Series(r, index=idx, name="return")
    s.attrs["asset"] = asset
    return s


def load_demo_panel(asset: str = "SPX", n: int = 3000, seed: int = 42) -> pd.DataFrame:
    """Synthetic OHLC-style panel with `return`, `price`, `rv22` columns."""
    s = load_demo_returns(asset=asset, n=n, seed=seed)
    df = pd.DataFrame({"return": s})
    df["price"] = 100 * np.exp(df["return"].cumsum())
    df["rv22"] = realized_volatility(df["return"], window=22).bfill()
    df.attrs["asset"] = asset
    return df


def load_demo_macro(n: int = 3000, seed: int = 0) -> pd.DataFrame:
    """Synthetic mixed-frequency macro panel (monthly) for GARCH-MIDAS demos."""
    rng = np.random.default_rng(seed)
    months = pd.date_range("2010-01-31", periods=max(n // 21, 24), freq="ME")
    df = pd.DataFrame({
        "ip_growth": rng.normal(0.001, 0.01, len(months)).cumsum(),
        "epu":       np.abs(rng.normal(100, 25, len(months))),
        "vix":       np.abs(rng.normal(20, 6,  len(months))),
        "nfci":      rng.normal(0, 0.5, len(months)),
    }, index=months)
    return df


def align_mixed_frequency(high_freq: pd.Series, low_freq: pd.DataFrame,
                          method: str = "ffill") -> pd.DataFrame:
    """Align low-freq macro series onto high-freq dates by forward-filling."""
    out = low_freq.reindex(high_freq.index, method=method)
    out["target"] = high_freq.values
    return out
