"""
hybridecon
==========

Hybrid AI + Econometric library for volatility, risk and macro forecasting.

Author: Dr Merwan Roudane <merwanroudane920@gmail.com>
GitHub: https://github.com/merwanroudane/hybridecon
"""

from importlib import metadata as _md

__author__ = "Dr Merwan Roudane"
__email__ = "merwanroudane920@gmail.com"
__url__ = "https://github.com/merwanroudane/hybridecon"

try:
    __version__ = _md.version("hybridecon")
except _md.PackageNotFoundError:
    __version__ = "0.2.0"

# top-level convenience re-exports
from . import data, diagnostics, econometric, deep, hybrids, regime, evaluate, viz
from .utils import set_seed, OUTDIR

__all__ = [
    "__version__", "__author__", "__email__", "__url__",
    "data", "diagnostics", "econometric", "deep",
    "hybrids", "regime", "evaluate", "viz",
    "set_seed", "OUTDIR",
]
