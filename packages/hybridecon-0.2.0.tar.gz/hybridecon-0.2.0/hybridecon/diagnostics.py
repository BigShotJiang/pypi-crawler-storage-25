"""
Pre-estimation and post-estimation diagnostic tests.

Pre-tests:  stationarity, white-noise, ARCH effects, normality, BDS,
            structural break (CUSUM, Bai-Perron-style binary segmentation).
Post-tests: residual diagnostics, Diebold-Mariano, Giacomini-White,
            Wilcoxon signed-rank, Mincer-Zarnowitz, Kupiec POF,
            Christoffersen IND/CC, Dynamic Quantile.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Iterable, Mapping

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.stats.diagnostic import (
    acorr_ljungbox, het_arch, breaks_cusumolsresid,
)
from statsmodels.stats.stattools import jarque_bera

# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------
@dataclass
class TestResult:
    name: str
    statistic: float
    pvalue: float
    null: str
    decision: str
    extras: dict = field(default_factory=dict)

    def to_row(self) -> dict:
        d = asdict(self); d.pop("extras"); d.update(self.extras); return d


def _decide(pvalue: float, alpha: float, reject_msg: str, fail_msg: str) -> str:
    return reject_msg if pvalue < alpha else fail_msg


# ===========================================================================
# 1.  PRE-ESTIMATION TESTS
# ===========================================================================
def adf_test(x, regression: str = "c", alpha: float = 0.05) -> TestResult:
    stat, p, *_ = adfuller(np.asarray(x), regression=regression, autolag="AIC")
    return TestResult(
        name=f"ADF ({regression})", statistic=float(stat), pvalue=float(p),
        null="unit root present",
        decision=_decide(p, alpha, "stationary", "non-stationary"),
    )


def kpss_test(x, regression: str = "c", alpha: float = 0.05) -> TestResult:
    stat, p, *_ = kpss(np.asarray(x), regression=regression, nlags="auto")
    return TestResult(
        name=f"KPSS ({regression})", statistic=float(stat), pvalue=float(p),
        null="series is stationary",
        decision=_decide(p, alpha, "non-stationary", "stationary"),
    )


def phillips_perron_test(x, alpha: float = 0.05) -> TestResult:
    """Phillips-Perron via the `arch` package (avoids reimplementation)."""
    from arch.unitroot import PhillipsPerron
    pp = PhillipsPerron(np.asarray(x))
    return TestResult(
        name="Phillips-Perron", statistic=float(pp.stat), pvalue=float(pp.pvalue),
        null="unit root present",
        decision=_decide(pp.pvalue, alpha, "stationary", "non-stationary"),
    )


def zivot_andrews_test(x, alpha: float = 0.05) -> TestResult:
    """Zivot-Andrews structural-break unit-root."""
    from arch.unitroot import ZivotAndrews
    za = ZivotAndrews(np.asarray(x))
    return TestResult(
        name="Zivot-Andrews", statistic=float(za.stat), pvalue=float(za.pvalue),
        null="unit root with one break",
        decision=_decide(za.pvalue, alpha, "stationary w/ break", "non-stationary"),
    )


def ljungbox_test(x, lags: int = 20, alpha: float = 0.05) -> TestResult:
    res = acorr_ljungbox(np.asarray(x), lags=[lags], return_df=True)
    stat = float(res["lb_stat"].iloc[0]); p = float(res["lb_pvalue"].iloc[0])
    return TestResult(
        name=f"Ljung-Box(lag={lags})", statistic=stat, pvalue=p,
        null="no autocorrelation",
        decision=_decide(p, alpha, "autocorrelated", "white noise"),
    )


def arch_lm_test(x, lags: int = 12, alpha: float = 0.05) -> TestResult:
    stat, p, _, _ = het_arch(np.asarray(x), nlags=lags)
    return TestResult(
        name=f"Engle ARCH-LM(lag={lags})", statistic=float(stat), pvalue=float(p),
        null="no ARCH effect",
        decision=_decide(p, alpha, "ARCH effect present", "no ARCH effect"),
    )


def mcleod_li_test(x, lags: int = 20, alpha: float = 0.05) -> TestResult:
    """Equivalent to Ljung-Box on squared series."""
    return TestResult(**{**ljungbox_test(np.asarray(x) ** 2, lags, alpha).__dict__,
                          "name": f"McLeod-Li(lag={lags})"})


def jarque_bera_test(x, alpha: float = 0.05) -> TestResult:
    stat, p, sk, kurt = jarque_bera(np.asarray(x))
    return TestResult(
        name="Jarque-Bera", statistic=float(stat), pvalue=float(p),
        null="normal", decision=_decide(p, alpha, "non-normal", "normal"),
        extras={"skew": float(sk), "kurtosis": float(kurt)},
    )


def shapiro_wilk_test(x, alpha: float = 0.05) -> TestResult:
    arr = np.asarray(x)
    if len(arr) > 5000:
        arr = np.random.default_rng(0).choice(arr, 5000, replace=False)
    stat, p = stats.shapiro(arr)
    return TestResult(
        name="Shapiro-Wilk", statistic=float(stat), pvalue=float(p),
        null="normal", decision=_decide(p, alpha, "non-normal", "normal"),
    )


def anderson_darling_test(x) -> TestResult:
    res = stats.anderson(np.asarray(x), dist="norm")
    p = 0.05  # implicit critical value at 5%
    return TestResult(
        name="Anderson-Darling", statistic=float(res.statistic),
        pvalue=float("nan"), null="normal",
        decision="non-normal" if res.statistic > res.critical_values[2] else "normal",
        extras={"crit_5pct": float(res.critical_values[2])},
    )


def bds_test(x, m: int = 2, eps: float | None = None, alpha: float = 0.05) -> TestResult:
    """BDS independence test (returns m=2 statistic)."""
    from statsmodels.tsa.stattools import bds
    if eps is None:
        eps = float(0.5 * np.std(np.asarray(x)))
    stat, p = bds(np.asarray(x), max_dim=m, epsilon=eps)
    s = float(np.atleast_1d(stat)[-1]); pv = float(np.atleast_1d(p)[-1])
    return TestResult(
        name=f"BDS(m={m})", statistic=s, pvalue=pv,
        null="iid", decision=_decide(pv, alpha, "non-linear dependence", "iid"),
    )


def cusum_break_test(resid, alpha: float = 0.05) -> TestResult:
    """CUSUM-of-OLS-residuals structural-break test."""
    stat, p, _ = breaks_cusumolsresid(np.asarray(resid))
    return TestResult(
        name="CUSUM (Brown-Durbin-Evans)", statistic=float(stat), pvalue=float(p),
        null="parameter stability",
        decision=_decide(p, alpha, "structural break", "stable"),
    )


# convenience batch -----------------------------------------------------------
def pre_estimation_battery(returns, lags: int = 20) -> pd.DataFrame:
    """Run *all* pre-estimation tests on a return series and return a tidy
    DataFrame ready for `viz.tables.diagnostic_table()`."""
    r = np.asarray(returns).astype(float)
    r = r[np.isfinite(r)]
    tests = [
        adf_test(r), kpss_test(r), phillips_perron_test(r),
        zivot_andrews_test(r),
        ljungbox_test(r, lags), ljungbox_test(r ** 2, lags),
        arch_lm_test(r, 12), mcleod_li_test(r, lags),
        jarque_bera_test(r), shapiro_wilk_test(r), anderson_darling_test(r),
        bds_test(r, m=2),
    ]
    return pd.DataFrame([t.to_row() for t in tests])


# ===========================================================================
# 2.  POST-ESTIMATION TESTS
# ===========================================================================
def diebold_mariano(e1, e2, h: int = 1, loss: str = "mse") -> TestResult:
    """Diebold-Mariano test on forecast errors e1, e2 (h-step ahead)."""
    e1 = np.asarray(e1).astype(float); e2 = np.asarray(e2).astype(float)
    if loss == "mse":
        d = e1 ** 2 - e2 ** 2
    elif loss == "mae":
        d = np.abs(e1) - np.abs(e2)
    elif loss == "qlike":
        # only valid if forecasts are variances (positive)
        d = np.log(e1) + e2 / e1 - (np.log(e2) + e2 / e2)
    else:
        raise ValueError(loss)
    n = len(d); mean_d = float(np.mean(d))
    # Newey-West HAC variance
    gamma0 = float(np.var(d, ddof=0))
    var_d = gamma0
    for k in range(1, h):
        gk = float(np.cov(d[:-k], d[k:], ddof=0)[0, 1])
        var_d += 2 * (1 - k / h) * gk
    stat = mean_d / np.sqrt(var_d / n)
    p = 2 * (1 - stats.norm.cdf(abs(stat)))
    return TestResult(
        name=f"Diebold-Mariano(h={h},{loss})", statistic=float(stat), pvalue=float(p),
        null="equal predictive accuracy",
        decision="model 2 better" if stat > 0 else "model 1 better",
    )


def giacomini_white(e1, e2, h: int = 1) -> TestResult:
    """Two-sided Giacomini-White conditional predictive ability test."""
    d = np.asarray(e1) ** 2 - np.asarray(e2) ** 2
    z = np.column_stack([np.ones_like(d), np.r_[0, d[:-1]]])
    beta = np.linalg.lstsq(z, d, rcond=None)[0]
    resid = d - z @ beta
    cov = np.linalg.pinv(z.T @ z) * (resid @ resid) / (len(d) - 2)
    stat = beta @ np.linalg.pinv(cov) @ beta
    p = 1 - stats.chi2.cdf(stat, df=2)
    return TestResult(
        name=f"Giacomini-White(h={h})", statistic=float(stat), pvalue=float(p),
        null="equal conditional predictive ability",
        decision=_decide(p, 0.05, "different", "equal"),
    )


def wilcoxon_loss_diff(e1, e2, loss: str = "mse") -> TestResult:
    if loss == "mse":
        a = np.asarray(e1) ** 2; b = np.asarray(e2) ** 2
    else:
        a = np.abs(np.asarray(e1)); b = np.abs(np.asarray(e2))
    res = stats.wilcoxon(a, b, zero_method="wilcox", alternative="two-sided")
    return TestResult(
        name=f"Wilcoxon(loss={loss})", statistic=float(res.statistic),
        pvalue=float(res.pvalue),
        null="median loss difference = 0",
        decision=_decide(res.pvalue, 0.05, "different", "equal"),
    )


def mincer_zarnowitz(actual, forecast) -> dict:
    """Regression actual = a + b * forecast + e; tests (a,b) = (0,1)."""
    y = np.asarray(actual).astype(float); x = np.asarray(forecast).astype(float)
    X = np.column_stack([np.ones_like(x), x])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    e = y - X @ beta
    sse = float(e @ e); sst = float(((y - y.mean()) ** 2).sum())
    r2 = 1 - sse / sst
    n, k = len(y), 2
    sigma2 = sse / (n - k)
    cov = sigma2 * np.linalg.pinv(X.T @ X)
    R = np.eye(2); q = np.array([0.0, 1.0])
    diff = R @ beta - q
    wald = float(diff @ np.linalg.pinv(R @ cov @ R.T) @ diff)
    p = 1 - stats.chi2.cdf(wald, df=2)
    return {"intercept": float(beta[0]), "slope": float(beta[1]),
            "MZ_R2": float(r2), "Wald_stat": wald, "Wald_p": float(p),
            "decision": "unbiased & efficient" if p > 0.05 else "biased / inefficient"}


# VaR backtests ---------------------------------------------------------------
def kupiec_pof(hits, alpha: float = 0.05) -> TestResult:
    """Kupiec proportion-of-failures test."""
    hits = np.asarray(hits).astype(int)
    n, x = len(hits), int(hits.sum())
    pi_hat = x / n if n else 0
    if pi_hat in (0, 1):
        return TestResult(name="Kupiec POF", statistic=float("nan"),
                          pvalue=float("nan"), null=f"hit rate = {alpha}",
                          decision="degenerate")
    lr = -2 * (
        x * np.log(alpha) + (n - x) * np.log(1 - alpha)
        - x * np.log(pi_hat) - (n - x) * np.log(1 - pi_hat)
    )
    p = 1 - stats.chi2.cdf(lr, df=1)
    return TestResult(
        name="Kupiec POF", statistic=float(lr), pvalue=float(p),
        null=f"hit rate = {alpha}",
        decision=_decide(p, 0.05, "miscalibrated", "calibrated"),
        extras={"hit_rate": float(pi_hat), "expected": alpha},
    )


def christoffersen_independence(hits) -> TestResult:
    """Christoffersen independence test for clustering of VaR violations."""
    h = np.asarray(hits).astype(int)
    n00 = int(((h[:-1] == 0) & (h[1:] == 0)).sum())
    n01 = int(((h[:-1] == 0) & (h[1:] == 1)).sum())
    n10 = int(((h[:-1] == 1) & (h[1:] == 0)).sum())
    n11 = int(((h[:-1] == 1) & (h[1:] == 1)).sum())
    pi01 = n01 / (n00 + n01) if (n00 + n01) else 0
    pi11 = n11 / (n10 + n11) if (n10 + n11) else 0
    pi   = (n01 + n11) / max(n00 + n01 + n10 + n11, 1)
    if pi in (0, 1) or pi01 in (0, 1) or pi11 in (0, 1):
        return TestResult(name="Christoffersen IND", statistic=float("nan"),
                          pvalue=float("nan"), null="violations independent",
                          decision="degenerate")
    lr = -2 * (
        (n00 + n10) * np.log(1 - pi) + (n01 + n11) * np.log(pi)
        - n00 * np.log(1 - pi01) - n01 * np.log(pi01)
        - n10 * np.log(1 - pi11) - n11 * np.log(pi11)
    )
    p = 1 - stats.chi2.cdf(lr, df=1)
    return TestResult(
        name="Christoffersen IND", statistic=float(lr), pvalue=float(p),
        null="violations independent",
        decision=_decide(p, 0.05, "clustered", "independent"),
    )


def post_estimation_battery(residuals, lags: int = 20) -> pd.DataFrame:
    """Standard residual battery on standardized residuals."""
    r = np.asarray(residuals).astype(float); r = r[np.isfinite(r)]
    tests = [
        ljungbox_test(r, lags), ljungbox_test(r ** 2, lags),
        arch_lm_test(r, 12), jarque_bera_test(r),
        shapiro_wilk_test(r), bds_test(r, m=2),
    ]
    return pd.DataFrame([t.to_row() for t in tests])
