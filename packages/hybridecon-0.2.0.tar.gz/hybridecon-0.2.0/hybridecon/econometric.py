"""
Econometric backbone models.

Wrappers around `arch`, `statsmodels`, `pmdarima` so that every model exposes
the same `.fit(returns)`, `.forecast(horizon)`, `.conditional_volatility`,
`.residuals`, `.summary()` interface. This makes the hybrid-model code in
`hybridecon.hybrids` agnostic to which econometric engine sits underneath.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd
from arch import arch_model

# ===========================================================================
# 1.  GARCH FAMILY
# ===========================================================================
class GARCH:
    """Wrapper around `arch.arch_model` covering GARCH/EGARCH/GJR/APARCH/TARCH.

    Parameters
    ----------
    vol : {"GARCH","EGARCH","GJR-GARCH","APARCH","TARCH","FIGARCH","HARCH"}
    p, o, q : int
    dist    : {"normal","t","skewt","ged"}
    mean    : {"Constant","Zero","ARX"}
    """
    _MAP = {"GARCH": "Garch", "EGARCH": "EGarch", "GJR-GARCH": "Garch",
            "APARCH": "APARCH", "TARCH": "Garch", "FIGARCH": "FIGarch",
            "HARCH": "HARCH"}

    def __init__(self, vol: str = "GARCH", p: int = 1, o: int = 0, q: int = 1,
                 dist: str = "normal", mean: str = "Constant", power: float = 2.0,
                 rescale: bool = True):
        self.vol_kind = vol.upper()
        self.p, self.o, self.q = p, o, q
        self.dist, self.mean, self.power = dist, mean, power
        self.rescale = rescale
        self._fit = None
        self._scale = 1.0

    def fit(self, returns):
        r = np.asarray(returns, dtype=float).ravel()
        # arch likes log-returns scaled by 100 for stability
        if self.rescale and np.std(r) < 1.0:
            self._scale = 100.0
            r = r * self._scale
        kw = dict(p=self.p, q=self.q, dist=self.dist, mean=self.mean,
                  power=self.power)
        if self.vol_kind == "GJR-GARCH":
            kw["o"] = max(self.o, 1); kw["vol"] = "Garch"
        elif self.vol_kind == "TARCH":
            kw["o"] = max(self.o, 1); kw["vol"] = "Garch"; kw["power"] = 1.0
        else:
            kw["vol"] = self._MAP[self.vol_kind]
            if self.o:
                kw["o"] = self.o
        # avoid warnings when not relevant
        if self.vol_kind not in ("APARCH",):
            kw.pop("power", None)
        am = arch_model(r, **kw)
        self._fit = am.fit(disp="off", show_warning=False)
        return self

    @property
    def conditional_volatility(self) -> np.ndarray:
        return np.asarray(self._fit.conditional_volatility) / self._scale

    @property
    def residuals(self) -> np.ndarray:
        return np.asarray(self._fit.resid) / self._scale

    @property
    def standardized_residuals(self) -> np.ndarray:
        return np.asarray(self._fit.std_resid)

    def forecast(self, horizon: int = 1, reindex: bool = False) -> np.ndarray:
        f = self._fit.forecast(horizon=horizon, reindex=reindex)
        var = np.asarray(f.variance.iloc[-1].values)
        return np.sqrt(var) / self._scale

    def summary(self) -> str:
        return str(self._fit.summary())

    @property
    def params(self) -> pd.Series:
        return self._fit.params

    @property
    def loglik(self) -> float:
        return float(self._fit.loglikelihood)

    def aic_bic(self) -> dict:
        return {"AIC": float(self._fit.aic), "BIC": float(self._fit.bic),
                "loglik": self.loglik}


# ===========================================================================
# 2.  GARCH-MIDAS
# ===========================================================================
class GARCHMIDAS:
    """GARCH-MIDAS volatility decomposition.

    Total variance σ²_t = g_t · τ_t where
        g_t = (1-α-β) + α (r_{t-1} - μ)² / τ_{t-1} + β g_{t-1}      (short)
        log τ_t = m + θ Σ_{k=1..K} φ_k(ω) X_{t-k}                    (long)
    with Beta-weighting   φ_k(ω) ∝ (k/K)^{ω₁-1}(1-k/K)^{ω₂-1}.
    Estimated by MLE; supports `w_restricted=True` (ω₁ = 1).
    """
    def __init__(self, K: int = 12, w_restricted: bool = True):
        self.K = K
        self.w_restricted = w_restricted
        self.params_: dict | None = None
        self.g_: np.ndarray | None = None
        self.tau_: np.ndarray | None = None

    @staticmethod
    def _beta_weights(K: int, w1: float, w2: float) -> np.ndarray:
        k = np.arange(1, K + 1) / (K + 1)
        w = (k ** (w1 - 1)) * ((1 - k) ** (w2 - 1))
        return w / w.sum()

    def _negloglik(self, theta, r, X):
        if self.w_restricted:
            mu, alpha, beta, m, the, w2 = theta; w1 = 1.0
        else:
            mu, alpha, beta, m, the, w1, w2 = theta
        if alpha < 0 or beta < 0 or alpha + beta >= 0.999 or w2 <= 1:
            return 1e12
        K, T = self.K, len(r)
        weights = self._beta_weights(K, w1, w2)
        # long-term tau over the high-frequency dimension
        tau = np.empty(T)
        # MIDAS lag of last K low-frequency obs at each time t
        for t in range(T):
            xs = X[max(t - K, 0):t]
            if len(xs) < K:
                xs = np.r_[np.zeros(K - len(xs)), xs]
            tau[t] = np.exp(m + the * np.dot(weights, xs[::-1]))
        # short-term g via filter
        g = np.ones(T)
        eps = (r - mu) ** 2
        for t in range(1, T):
            g[t] = (1 - alpha - beta) + alpha * eps[t - 1] / max(tau[t - 1], 1e-8) + beta * g[t - 1]
        sigma2 = g * tau
        sigma2 = np.maximum(sigma2, 1e-12)
        ll = -0.5 * (np.log(2 * np.pi) + np.log(sigma2) + (r - mu) ** 2 / sigma2).sum()
        return -ll

    def fit(self, returns, low_freq):
        from scipy.optimize import minimize
        r = np.asarray(returns, dtype=float).ravel()
        # broadcast low-freq variable to same length as r
        x = np.asarray(low_freq, dtype=float).ravel()
        if len(x) < len(r):
            x = np.repeat(x, int(np.ceil(len(r) / len(x))))[:len(r)]
        x = (x - np.mean(x)) / (np.std(x) + 1e-12)
        if self.w_restricted:
            x0 = np.array([np.mean(r), 0.05, 0.9, np.log(np.var(r)), 0.05, 5.0])
            bnds = [(None, None), (1e-4, 0.5), (1e-4, 0.99),
                    (None, None), (None, None), (1.01, 50)]
        else:
            x0 = np.array([np.mean(r), 0.05, 0.9, np.log(np.var(r)), 0.05, 1.0, 5.0])
            bnds = [(None, None), (1e-4, 0.5), (1e-4, 0.99),
                    (None, None), (None, None), (1.01, 50), (1.01, 50)]
        res = minimize(self._negloglik, x0, args=(r, x), method="L-BFGS-B", bounds=bnds)
        self.loglik_ = -float(res.fun); self._x = x; self._r = r
        keys = ["mu", "alpha", "beta", "m", "theta", "w2"] if self.w_restricted else \
               ["mu", "alpha", "beta", "m", "theta", "w1", "w2"]
        self.params_ = dict(zip(keys, res.x))
        self._compute_components()
        return self

    def _compute_components(self):
        r, x = self._r, self._x
        K, T = self.K, len(r)
        if self.w_restricted:
            mu = self.params_["mu"]; alpha = self.params_["alpha"]; beta = self.params_["beta"]
            m = self.params_["m"]; the = self.params_["theta"]; w1, w2 = 1.0, self.params_["w2"]
        else:
            mu = self.params_["mu"]; alpha = self.params_["alpha"]; beta = self.params_["beta"]
            m = self.params_["m"]; the = self.params_["theta"]
            w1, w2 = self.params_["w1"], self.params_["w2"]
        weights = self._beta_weights(K, w1, w2)
        tau = np.empty(T)
        for t in range(T):
            xs = x[max(t - K, 0):t]
            if len(xs) < K:
                xs = np.r_[np.zeros(K - len(xs)), xs]
            tau[t] = np.exp(m + the * np.dot(weights, xs[::-1]))
        g = np.ones(T); eps = (r - mu) ** 2
        for t in range(1, T):
            g[t] = (1 - alpha - beta) + alpha * eps[t - 1] / max(tau[t - 1], 1e-8) + beta * g[t - 1]
        self.g_, self.tau_ = g, tau

    @property
    def conditional_volatility(self) -> np.ndarray:
        return np.sqrt(self.g_ * self.tau_)

    def variance_ratio(self) -> float:
        """Fraction of total variance explained by long-term component."""
        return float(np.var(np.log(self.tau_)) /
                     (np.var(np.log(self.tau_)) + np.var(np.log(self.g_) + 1e-12)))


# ===========================================================================
# 3.  HAR-RV
# ===========================================================================
class HAR:
    """Heterogeneous Autoregressive model of Realized Volatility (Corsi 2009).
        RV_t = β0 + βd RV_{t-1} + βw RV_{t-1:t-5} + βm RV_{t-1:t-22} + ε_t
    """
    def __init__(self):
        self.beta_: np.ndarray | None = None
        self.fitted_: np.ndarray | None = None
        self.resid_: np.ndarray | None = None

    @staticmethod
    def _features(rv: np.ndarray):
        rv = np.asarray(rv, dtype=float).ravel()
        n = len(rv)
        d = rv[:-1]
        w = pd.Series(rv).rolling(5).mean().shift(1).to_numpy()[:-0]
        m = pd.Series(rv).rolling(22).mean().shift(1).to_numpy()[:-0]
        # align
        T = min(len(d), len(w) - 1, len(m) - 1)
        X = np.column_stack([np.ones(T), d[-T:], w[-T:], m[-T:]])
        y = rv[-T:]
        return X, y

    def fit(self, rv):
        X, y = self._features(rv)
        self.beta_, *_ = np.linalg.lstsq(X, y, rcond=None)
        self.fitted_ = X @ self.beta_
        self.resid_ = y - self.fitted_
        self._last_rv = np.asarray(rv).astype(float).ravel()
        return self

    def predict(self, rv_new=None) -> np.ndarray:
        rv = np.asarray(rv_new if rv_new is not None else self._last_rv).ravel()
        X, _ = self._features(rv)
        return X @ self.beta_

    def forecast(self, horizon: int = 1) -> np.ndarray:
        out = []
        rv = self._last_rv.copy()
        for _ in range(horizon):
            X = np.array([1.0, rv[-1], rv[-5:].mean(), rv[-22:].mean()])
            yhat = float(X @ self.beta_)
            out.append(yhat); rv = np.append(rv, yhat)
        return np.asarray(out)


# ===========================================================================
# 4.  ARIMA / ARFIMA wrappers
# ===========================================================================
class ARIMAWrapper:
    def __init__(self, order=None, seasonal: bool = False):
        self.order = order; self.seasonal = seasonal; self._fit = None

    def fit(self, y):
        import pmdarima as pm
        y = np.asarray(y, dtype=float).ravel()
        if self.order is not None:
            from statsmodels.tsa.arima.model import ARIMA
            self._fit = ARIMA(y, order=self.order).fit()
            self.order_ = self.order
        else:
            self._fit = pm.auto_arima(y, seasonal=self.seasonal,
                                      suppress_warnings=True, error_action="ignore")
            self.order_ = getattr(self._fit, "order", None)
        return self

    def forecast(self, horizon: int = 1):
        return np.asarray(self._fit.forecast(horizon)) if hasattr(self._fit, "forecast") \
               else np.asarray(self._fit.predict(n_periods=horizon))

    @property
    def residuals(self):
        return np.asarray(self._fit.resid()) if callable(getattr(self._fit, "resid", None)) \
               else np.asarray(self._fit.resid)


class ARFIMAWrapper:
    """Lightweight ARFIMA via fractional differencing + ARMA on the d-differenced series."""
    def __init__(self, p: int = 1, q: int = 1):
        self.p, self.q = p, q
        self._d = None

    @staticmethod
    def _frac_diff(x, d, thresh: float = 1e-4):
        weights = [1.0]; k = 1
        while True:
            w = -weights[-1] * (d - k + 1) / k
            if abs(w) < thresh: break
            weights.append(w); k += 1
        weights = np.asarray(weights[::-1])
        out = np.full_like(x, np.nan, dtype=float)
        for i in range(len(weights) - 1, len(x)):
            out[i] = np.dot(weights, x[i - len(weights) + 1:i + 1])
        return out

    def fit(self, y):
        from statsmodels.tsa.arima.model import ARIMA
        y = np.asarray(y, dtype=float).ravel()
        # GPH log-periodogram estimator of d
        n = len(y); m = int(np.sqrt(n))
        I = np.abs(np.fft.rfft(y - y.mean())) ** 2 / n
        lam = 2 * np.pi * np.arange(1, m + 1) / n
        x = -2 * np.log(2 * np.sin(lam / 2))
        ymid = np.log(I[1:m + 1])
        d_hat = np.polyfit(x, ymid, 1)[0]
        d_hat = float(np.clip(d_hat, 0.0, 0.49))
        self._d = d_hat
        yfd = self._frac_diff(y, d_hat); yfd = yfd[~np.isnan(yfd)]
        self._fit = ARIMA(yfd, order=(self.p, 0, self.q)).fit()
        self._lastfd = yfd
        return self

    def forecast(self, horizon: int = 1):
        return np.asarray(self._fit.forecast(horizon))


# ===========================================================================
# 5.  VAR
# ===========================================================================
class VARWrapper:
    def __init__(self, lags: int | str = "aic"):
        self.lags = lags

    def fit(self, df):
        from statsmodels.tsa.api import VAR
        self._df = pd.DataFrame(df).astype(float)
        self._model = VAR(self._df.values)
        if isinstance(self.lags, str):
            sel = self._model.select_order(maxlags=12)
            self.p_ = max(int(getattr(sel, self.lags)), 1)
        else:
            self.p_ = int(self.lags)
        self._fit = self._model.fit(self.p_)
        return self

    def forecast(self, horizon: int = 1):
        return self._fit.forecast(self._df.values[-self.p_:], horizon)

    @property
    def residuals(self):
        return self._fit.resid


# ===========================================================================
# 6.  Diagonal BEKK MGARCH (light implementation)
# ===========================================================================
class DiagonalBEKK:
    """Diagonal BEKK(1,1):  H_t = CC' + a a' ⊙ ε_{t-1}ε_{t-1}' + b b' ⊙ H_{t-1}
    with C lower-triangular. Estimated by Gaussian QML.
    """
    def __init__(self):
        self.params_ = None
        self.H_ = None

    def _negloglik(self, theta, R):
        T, k = R.shape
        nC = k * (k + 1) // 2
        cvec, a, b = theta[:nC], theta[nC:nC + k], theta[nC + k:]
        if np.any(a < 0) or np.any(b < 0) or np.any(a ** 2 + b ** 2 >= 0.999):
            return 1e12
        C = np.zeros((k, k))
        idx = np.tril_indices(k); C[idx] = cvec
        H = np.empty((T, k, k))
        H[0] = np.cov(R.T)
        ll = 0.0
        for t in range(1, T):
            eps = R[t - 1][:, None]
            H[t] = C @ C.T + np.outer(a, a) * (eps @ eps.T) + np.outer(b, b) * H[t - 1]
            sign, logdet = np.linalg.slogdet(H[t])
            inv = np.linalg.pinv(H[t])
            ll += -0.5 * (k * np.log(2 * np.pi) + logdet + R[t] @ inv @ R[t])
        self._H = H
        return -ll

    def fit(self, returns):
        from scipy.optimize import minimize
        R = np.asarray(returns, dtype=float)
        if R.ndim != 2:
            raise ValueError("returns must be 2-D (T, k)")
        T, k = R.shape
        nC = k * (k + 1) // 2
        x0 = np.r_[np.linalg.cholesky(np.cov(R.T))[np.tril_indices(k)],
                   np.full(k, 0.2), np.full(k, 0.7)]
        res = minimize(self._negloglik, x0, args=(R,), method="L-BFGS-B")
        self.params_ = res.x
        self._negloglik(res.x, R)        # populate self._H
        self.H_ = self._H
        self.loglik_ = -float(res.fun)
        return self

    def conditional_correlation(self) -> np.ndarray:
        H = self.H_; T, k, _ = H.shape
        out = np.empty_like(H)
        for t in range(T):
            d = np.sqrt(np.diag(H[t])); out[t] = H[t] / np.outer(d, d)
        return out


# ===========================================================================
# 7.  GAS / Score-driven model (univariate volatility)
# ===========================================================================
class GAS:
    """Generalised Autoregressive Score model with Student-t innovations.

        f_t = ω + α s_{t-1} + β f_{t-1}            (log-variance)
        s_t = (1 + ν) (r_t - μ)² / ((ν-2) e^{f_t} + (r_t - μ)²) - 1
    """
    def __init__(self):
        self.params_ = None; self.f_ = None

    def _negloglik(self, theta, r):
        mu, omega, alpha, beta, nu = theta
        if not (0 < alpha < 1 and 0 < beta < 1 and nu > 2):
            return 1e12
        T = len(r); f = np.empty(T); f[0] = np.log(np.var(r))
        ll = 0.0
        for t in range(T):
            sig2 = np.exp(f[t])
            x = (r[t] - mu) ** 2
            denom = (nu - 2) * sig2 + x
            ll += (np.log(np.math.gamma((nu + 1) / 2)) - np.log(np.math.gamma(nu / 2))
                   - 0.5 * np.log(np.pi * (nu - 2) * sig2)
                   - 0.5 * (nu + 1) * np.log(1 + x / denom))
            s = (1 + nu) * x / denom - 1
            if t < T - 1:
                f[t + 1] = omega + alpha * s + beta * f[t]
        self._f = f
        return -ll

    def fit(self, returns):
        from scipy.optimize import minimize
        r = np.asarray(returns, dtype=float).ravel()
        x0 = np.array([np.mean(r), 0.0, 0.05, 0.9, 8.0])
        bnds = [(None, None), (None, None), (1e-4, 0.999), (1e-4, 0.999), (2.1, 60)]
        res = minimize(self._negloglik, x0, args=(r,), method="L-BFGS-B", bounds=bnds)
        self.params_ = dict(zip(["mu", "omega", "alpha", "beta", "nu"], res.x))
        self._negloglik(res.x, r)
        self.f_ = self._f
        self.loglik_ = -float(res.fun)
        return self

    @property
    def conditional_volatility(self) -> np.ndarray:
        return np.exp(self.f_ / 2)
