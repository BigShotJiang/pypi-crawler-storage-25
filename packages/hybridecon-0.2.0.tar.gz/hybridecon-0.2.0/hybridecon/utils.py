"""Common utilities: seeding, output directory, sequence builders, scalers."""
from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

OUTDIR = Path(os.environ.get("HYBRIDECON_OUTDIR", "./hybridecon_outputs")).resolve()
OUTDIR.mkdir(parents=True, exist_ok=True)


def set_seed(seed: int = 42) -> None:
    """Set seeds for numpy, random and (if available) torch."""
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def to_numpy(x) -> np.ndarray:
    if isinstance(x, (pd.Series, pd.DataFrame)):
        return x.to_numpy()
    return np.asarray(x)


def log_returns(prices, dropna: bool = True) -> pd.Series:
    p = pd.Series(np.asarray(prices, dtype=float)).replace(0, np.nan)
    r = np.log(p).diff()
    return r.dropna() if dropna else r


def garman_klass_volatility(open_, high, low, close,
                            window: int | None = None,
                            annualize: int | None = 252) -> pd.Series:
    """Garman-Klass range-based volatility estimator.

    σ²_t = 0.5 (log H/L)² - (2 log 2 - 1)(log C/O)²
    Returns a per-period σ̂. If `window` is given, the rolling mean of the
    daily variance is taken before sqrt'ing.
    """
    o = pd.Series(np.asarray(open_, dtype=float))
    h = pd.Series(np.asarray(high, dtype=float))
    l = pd.Series(np.asarray(low, dtype=float))
    c = pd.Series(np.asarray(close, dtype=float))
    daily_var = 0.5 * (np.log(h / l)) ** 2 - (2 * np.log(2) - 1) * (np.log(c / o)) ** 2
    if window:
        daily_var = daily_var.rolling(window).mean()
    sd = np.sqrt(daily_var.clip(lower=0))
    if annualize:
        sd = sd * np.sqrt(annualize)
    return sd


def realized_volatility(returns, window: int = 22, annualize: int | None = 252) -> pd.Series:
    r = pd.Series(np.asarray(returns, dtype=float))
    rv = r.rolling(window).std()
    if annualize:
        rv = rv * np.sqrt(annualize)
    return rv


def build_sequences(x: np.ndarray, lookback: int, target: Optional[np.ndarray] = None):
    """Convert a 1-D array to (N, lookback, 1) tensors and aligned targets."""
    x = np.asarray(x, dtype=np.float32).ravel()
    n = len(x) - lookback
    if n <= 0:
        raise ValueError(f"series length {len(x)} <= lookback {lookback}")
    X = np.lib.stride_tricks.sliding_window_view(x, lookback)[:n]
    X = X[..., None]                               # (N, lookback, 1)
    if target is None:
        y = x[lookback:]
    else:
        target = np.asarray(target, dtype=np.float32).ravel()
        y = target[lookback:]
    return X.astype(np.float32), y.astype(np.float32)


def train_val_test_split(*arrays, val: float = 0.1, test: float = 0.2):
    """Chronological split — no shuffling."""
    n = len(arrays[0])
    n_test = int(n * test)
    n_val = int(n * val)
    n_train = n - n_val - n_test
    out = []
    for a in arrays:
        out.append((a[:n_train], a[n_train:n_train + n_val], a[-n_test:]))
    return out if len(arrays) > 1 else out[0]


def standardize(train, *others):
    mu, sd = float(np.mean(train)), float(np.std(train) + 1e-12)
    fn = lambda a: (a - mu) / sd
    return (fn(train), *(fn(o) for o in others), mu, sd)
