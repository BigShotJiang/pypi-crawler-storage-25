"""
Forecast evaluation, Model Confidence Set, and trading metrics.
"""
from __future__ import annotations

from typing import Iterable, Mapping

import numpy as np
import pandas as pd
from scipy import stats


# ===========================================================================
# 1.  Point-forecast metrics
# ===========================================================================
def rmse(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
def mae (y, p): return float(np.mean(np.abs(np.asarray(y) - np.asarray(p))))
def mape(y, p):
    y = np.asarray(y, dtype=float); p = np.asarray(p, dtype=float)
    mask = np.abs(y) > 1e-12
    return float(np.mean(np.abs((y[mask] - p[mask]) / y[mask])) * 100)
def smape(y, p):
    y = np.asarray(y, dtype=float); p = np.asarray(p, dtype=float)
    return float(np.mean(2 * np.abs(p - y) / (np.abs(y) + np.abs(p) + 1e-12)) * 100)

def qlike(true_var, pred_var):
    """Robust loss for variance forecasts (Patton 2011)."""
    tv = np.asarray(true_var, dtype=float); pv = np.asarray(pred_var, dtype=float)
    pv = np.maximum(pv, 1e-12)
    return float(np.mean(tv / pv - np.log(tv / pv) - 1))


def medae(y, p): return float(np.median(np.abs(np.asarray(y) - np.asarray(p))))


def evaluate_point_forecast(y_true, y_pred) -> dict:
    return {"RMSE": rmse(y_true, y_pred), "MAE": mae(y_true, y_pred),
            "MAPE": mape(y_true, y_pred), "sMAPE": smape(y_true, y_pred),
            "MedAE": medae(y_true, y_pred)}


def evaluate_volatility_forecast(rv_true, vol_pred) -> dict:
    """Use squared vol as variance proxy."""
    var_pred = np.asarray(vol_pred) ** 2
    base = evaluate_point_forecast(rv_true, vol_pred)
    base["QLIKE"] = qlike(np.asarray(rv_true) ** 2 + 1e-12, var_pred)
    return base


# ===========================================================================
# 2.  Model Confidence Set (Hansen, Lunde, Nason 2011)
# ===========================================================================
def model_confidence_set(loss_matrix: pd.DataFrame, alpha: float = 0.10,
                         B: int = 5000, block: int = 5,
                         random_state: int = 42) -> pd.DataFrame:
    """Hansen's MCS via stationary-bootstrap of relative losses.

    Parameters
    ----------
    loss_matrix : DataFrame of shape (T, M) — column m = loss series of model m
    alpha       : MCS level (0.10 = 90% MCS)

    Returns
    -------
    DataFrame with columns ["model", "rank", "p_value", "in_MCS"].
    """
    rng = np.random.default_rng(random_state)
    L = np.asarray(loss_matrix, dtype=float)
    T, M = L.shape
    models = list(loss_matrix.columns)
    eliminated, p_eq = [], {}
    surviving = list(range(M))

    def _stationary_bootstrap_indices():
        idx = np.empty(T, dtype=int); idx[0] = rng.integers(0, T)
        for t in range(1, T):
            if rng.random() < 1.0 / block:
                idx[t] = rng.integers(0, T)
            else:
                idx[t] = (idx[t - 1] + 1) % T
        return idx

    while len(surviving) > 1:
        Lc = L[:, surviving]
        m = Lc.shape[1]
        d = Lc - Lc.mean(axis=1, keepdims=True)            # vs avg
        d_bar = d.mean(axis=0)                             # (m,)
        # bootstrap distribution of t-stat
        t_boot = np.empty(B)
        for b in range(B):
            ix = _stationary_bootstrap_indices()
            db = d[ix].mean(axis=0) - d_bar
            t_boot[b] = (np.abs(db) / (db.std(ddof=1) + 1e-12)).max()
        t_obs = (np.abs(d_bar) / (d.std(axis=0, ddof=1) + 1e-12)).max()
        p = float((t_boot >= t_obs).mean())
        if p >= alpha:
            for s in surviving: p_eq.setdefault(s, p)
            break
        # eliminate the worst
        worst = surviving[int(np.argmax(d_bar))]
        eliminated.append((worst, p))
        p_eq[worst] = p
        surviving.remove(worst)
    if len(surviving) == 1:
        p_eq[surviving[0]] = 1.0

    rows = []
    rank_map = {m: r + 1 for r, m in enumerate(
        sorted(range(M), key=lambda i: L[:, i].mean()))}
    for i, name in enumerate(models):
        rows.append({"model": name, "rank": rank_map[i],
                     "p_value": float(p_eq.get(i, 0.0)),
                     "in_MCS": (i in surviving) or (p_eq.get(i, 0.0) >= alpha)})
    return pd.DataFrame(rows).sort_values("rank").reset_index(drop=True)


# ===========================================================================
# 3.  Trading metrics
# ===========================================================================
def annualised_return_compound(returns, periods: int = 252) -> float:
    r = np.asarray(returns, dtype=float)
    return float((1 + r).prod() ** (periods / len(r)) - 1)


def annualised_volatility(returns, periods: int = 252) -> float:
    return float(np.std(np.asarray(returns, dtype=float)) * np.sqrt(periods))


def max_drawdown(returns) -> float:
    eq = (1 + np.asarray(returns, dtype=float)).cumprod()
    peak = np.maximum.accumulate(eq)
    return float(((eq - peak) / peak).min())


def sortino(returns, rf: float = 0.0, periods: int = 252) -> float:
    r = np.asarray(returns, dtype=float) - rf / periods
    downside = np.std(r[r < 0]) * np.sqrt(periods)
    return float(r.mean() * periods / (downside + 1e-12))


def information_ratio(returns, periods: int = 252) -> float:
    arc = annualised_return_compound(returns, periods)
    asd = annualised_volatility(returns, periods)
    return float(arc / (asd + 1e-12))


def adjusted_information_ratio(returns, periods: int = 252) -> float:
    arc = annualised_return_compound(returns, periods)
    asd = annualised_volatility(returns, periods)
    md = abs(max_drawdown(returns))
    return float(arc ** 2 * np.sign(arc) / ((asd + 1e-12) * (md + 1e-12)))


def trading_metrics(strategy_returns) -> dict:
    return {
        "ARC":     annualised_return_compound(strategy_returns),
        "ASD":     annualised_volatility(strategy_returns),
        "MD":      max_drawdown(strategy_returns),
        "IR":      information_ratio(strategy_returns),
        "IR*":     adjusted_information_ratio(strategy_returns),
        "Sortino": sortino(strategy_returns),
    }


# ===========================================================================
# 4.  VaR backtest summary
# ===========================================================================
def var_backtest_table(returns, var_forecasts, alpha: float = 0.05) -> pd.DataFrame:
    from .diagnostics import kupiec_pof, christoffersen_independence
    r = np.asarray(returns, dtype=float)
    v = np.asarray(var_forecasts, dtype=float)
    hits = (r < -np.abs(v)).astype(int)
    rows = [kupiec_pof(hits, alpha), christoffersen_independence(hits)]
    return pd.DataFrame([t.to_row() for t in rows])


def expected_shortfall(returns, var_forecasts, alpha: float = 0.05) -> dict:
    """Empirical and model-implied Expected Shortfall (Conditional VaR).

    Returns
    -------
    dict with:
        ES_emp : average loss given a VaR breach
        ES_avg : mean of |VaR| forecasts on breach days
        n_breaches, breach_rate
    """
    r = np.asarray(returns, dtype=float)
    v = np.asarray(var_forecasts, dtype=float)
    losses = -r                                         # losses are positive
    var_mag = np.abs(v)
    breach = losses > var_mag
    n = int(breach.sum())
    if n == 0:
        return {"ES_emp": float("nan"), "ES_avg": float("nan"),
                "n_breaches": 0, "breach_rate": 0.0, "alpha": alpha}
    return {"ES_emp": float(losses[breach].mean()),
            "ES_avg": float(var_mag[breach].mean()),
            "n_breaches": n, "breach_rate": float(n / len(r)), "alpha": alpha}
