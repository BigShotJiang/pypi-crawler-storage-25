"""
Plots and tables.

All figures are saved to `OUTDIR/figures/` and tables to `OUTDIR/tables/`.
The styling defaults to a clean white grid; users can override via mpl rc.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, Mapping, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter
from tabulate import tabulate

from .utils import OUTDIR

FIG_DIR = OUTDIR / "figures"; FIG_DIR.mkdir(parents=True, exist_ok=True)
TAB_DIR = OUTDIR / "tables";  TAB_DIR.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "figure.figsize": (10, 5),
    "figure.dpi": 110,
    "savefig.dpi": 130,
    "axes.grid": True,
    "grid.alpha": 0.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
})


# ===========================================================================
# 1.  Time-series plots
# ===========================================================================
def plot_series(series: pd.Series | np.ndarray, title: str = "Series",
                ylabel: str = "", filename: str = "series.png",
                ax=None, color="#2c3e50"):
    own = ax is None
    fig, ax = (plt.subplots() if own else (ax.figure, ax))
    if isinstance(series, pd.Series):
        ax.plot(series.index, series.values, lw=1.2, color=color)
    else:
        ax.plot(series, lw=1.2, color=color)
    ax.set_title(title); ax.set_ylabel(ylabel)
    if own:
        fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)
    return ax


def plot_returns_and_volatility(returns: pd.Series, vol: pd.Series,
                                title: str = "Returns and conditional volatility",
                                filename: str = "returns_volatility.png"):
    fig, axes = plt.subplots(2, 1, sharex=True, figsize=(11, 6))
    axes[0].plot(returns.index, returns.values, color="#34495e", lw=0.7)
    axes[0].set_title(title); axes[0].set_ylabel("returns")
    axes[1].plot(vol.index, vol.values, color="#c0392b", lw=1.0)
    axes[1].set_ylabel("σ̂_t"); axes[1].set_xlabel("date")
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


def plot_acf_pacf(x, lags: int = 40, filename: str = "acf_pacf.png"):
    from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    plot_acf(x, lags=lags, ax=axes[0]); axes[0].set_title("ACF")
    plot_pacf(x, lags=lags, method="ywm", ax=axes[1]); axes[1].set_title("PACF")
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


def plot_qq(residuals, filename: str = "qq.png"):
    from scipy import stats
    r = np.asarray(residuals, dtype=float); r = r[np.isfinite(r)]
    fig, ax = plt.subplots()
    stats.probplot(r, dist="norm", plot=ax)
    ax.set_title("Q-Q plot of residuals")
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


def residual_diagnostic_panel(residuals, filename: str = "residual_panel.png"):
    """4-panel: residuals, ACF of residuals, ACF of squared, Q-Q."""
    from scipy import stats
    from statsmodels.graphics.tsaplots import plot_acf
    r = np.asarray(residuals, dtype=float); r = r[np.isfinite(r)]
    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    axes[0, 0].plot(r, lw=0.6, color="#2c3e50"); axes[0, 0].set_title("Standardized residuals")
    plot_acf(r, lags=40, ax=axes[0, 1]); axes[0, 1].set_title("ACF of residuals")
    plot_acf(r ** 2, lags=40, ax=axes[1, 0]); axes[1, 0].set_title("ACF of squared residuals")
    stats.probplot(r, dist="norm", plot=axes[1, 1]); axes[1, 1].set_title("Q-Q plot")
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


# ===========================================================================
# 2.  Forecast plots
# ===========================================================================
def plot_forecast(actual, predicted, ci_lo=None, ci_hi=None,
                  title: str = "Forecast vs actual",
                  filename: str = "forecast.png"):
    fig, ax = plt.subplots()
    idx = (actual.index if isinstance(actual, pd.Series)
           else np.arange(len(actual)))
    ax.plot(idx, np.asarray(actual), label="actual", color="#2c3e50", lw=1.0)
    ax.plot(idx, np.asarray(predicted), label="forecast", color="#c0392b", lw=1.2)
    if ci_lo is not None and ci_hi is not None:
        ax.fill_between(idx, ci_lo, ci_hi, color="#c0392b", alpha=0.15,
                        label="95% CI")
    ax.set_title(title); ax.legend(loc="best")
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


def plot_volatility_decomposition(g, tau, filename: str = "volatility_decomposition.png"):
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(np.sqrt(g * tau), label="total σ̂", color="#34495e", lw=1.0)
    ax.plot(np.sqrt(tau), label="long-term √τ", color="#c0392b", lw=1.0)
    ax.plot(np.sqrt(g),   label="short-term √g", color="#2980b9", lw=0.7, alpha=0.7)
    ax.legend(); ax.set_title("GARCH-MIDAS volatility decomposition")
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


def plot_regime_ribbon(returns: pd.Series, states: np.ndarray,
                       labels: list[str],
                       title: str = "Regime ribbon",
                       filename: str = "regime_ribbon.png"):
    fig, ax = plt.subplots(figsize=(12, 5))
    cmap = plt.get_cmap("RdYlGn_r", len(labels))
    idx = (returns.index if isinstance(returns, pd.Series)
           else np.arange(len(returns)))
    ax.plot(idx, np.asarray(returns), lw=0.7, color="#2c3e50")
    for k, lab in enumerate(labels):
        mask = (states == k)
        ax.fill_between(idx, *ax.get_ylim(), where=mask, alpha=0.15,
                        color=cmap(k), label=lab)
    ax.set_title(title); ax.legend(loc="upper right")
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


def plot_training_curve(history: Mapping[str, list],
                        filename: str = "training_curve.png"):
    fig, ax = plt.subplots()
    if "train" in history: ax.plot(history["train"], label="train")
    if "val"   in history: ax.plot(history["val"],   label="val")
    ax.set_title("Training curves"); ax.set_xlabel("epoch"); ax.set_ylabel("loss")
    ax.legend(); fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


def plot_mcs_heatmap(mcs_df: pd.DataFrame, filename: str = "mcs.png"):
    fig, ax = plt.subplots(figsize=(7, 0.5 + 0.4 * len(mcs_df)))
    arr = mcs_df.set_index("model")[["p_value"]].values
    ax.imshow(arr, aspect="auto", cmap="YlGn")
    ax.set_yticks(range(len(mcs_df))); ax.set_yticklabels(mcs_df["model"])
    ax.set_xticks([0]); ax.set_xticklabels(["MCS p-value"])
    for i, v in enumerate(arr.ravel()):
        ax.text(0, i, f"{v:.3f}", ha="center", va="center", fontsize=9,
                color="black" if v > 0.5 else "white")
    ax.set_title(f"Model Confidence Set (in_MCS = ✓)")
    for i, in_mcs in enumerate(mcs_df["in_MCS"]):
        if in_mcs:
            ax.add_patch(plt.Rectangle((-0.5, i - 0.5), 1, 1, fill=False,
                                       edgecolor="#27ae60", lw=2))
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


def plot_correlation_surface(rho_t: np.ndarray, asset_names: list[str],
                             filename: str = "correlation_surface.png"):
    """Plot pairwise time-varying correlations from BEKK/DCC."""
    T, k, _ = rho_t.shape
    pairs = [(i, j) for i in range(k) for j in range(i + 1, k)]
    fig, axes = plt.subplots(len(pairs), 1, figsize=(11, 1.7 * len(pairs)),
                              sharex=True)
    if len(pairs) == 1: axes = [axes]
    for ax, (i, j) in zip(axes, pairs):
        ax.plot(rho_t[:, i, j], color="#2980b9", lw=1.0)
        ax.set_ylabel(f"{asset_names[i]}-{asset_names[j]}")
        ax.set_ylim(-1, 1); ax.axhline(0, color="grey", lw=0.5)
    axes[-1].set_xlabel("t")
    fig.suptitle("Time-varying conditional correlations")
    fig.tight_layout(); fig.savefig(FIG_DIR / filename); plt.close(fig)


# ===========================================================================
# 3.  Pretty tables
# ===========================================================================
def table(df: pd.DataFrame, fmt: str = "github", caption: str | None = None,
          filename: str | None = None) -> str:
    """Return a formatted table; optionally save to file.

    fmt: any tabulate format — 'github', 'pipe', 'latex', 'html', 'simple_outline', 'fancy_grid'.
    """
    s = tabulate(df, headers="keys", tablefmt=fmt, showindex=False,
                 floatfmt=".4f")
    if caption:
        s = f"**{caption}**\n\n" + s if fmt in ("github", "pipe") else s
    if filename:
        ext = {"latex": "tex", "html": "html"}.get(fmt, "md")
        (TAB_DIR / f"{filename}.{ext}").write_text(s, encoding="utf-8")
    return s


def diagnostic_table(df: pd.DataFrame, caption: str = "Diagnostics",
                     filename: str | None = "diagnostics") -> str:
    cols = ["name", "statistic", "pvalue", "decision"]
    cols += [c for c in df.columns if c not in cols]
    return table(df[cols], fmt="github", caption=caption, filename=filename)


def metrics_table(metrics: Mapping[str, Mapping[str, float]],
                  caption: str = "Forecast metrics",
                  filename: str | None = "metrics") -> str:
    df = pd.DataFrame(metrics).T.reset_index().rename(columns={"index": "model"})
    return table(df, fmt="github", caption=caption, filename=filename)
