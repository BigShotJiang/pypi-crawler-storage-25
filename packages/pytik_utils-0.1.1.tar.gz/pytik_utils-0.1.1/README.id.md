<!-- Language Switcher -->
<p align="right">
  🌐 <a href="README.md">English</a>
</p>

<!-- Banner -->
<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/faisalaffan/pytik/dev/assets/01_BANNER_DARK.png">
    <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/faisalaffan/pytik/dev/assets/02_BANNER_LIGHT.png">
    <img alt="Pytik Banner" src="https://raw.githubusercontent.com/faisalaffan/pytik/dev/assets/02_BANNER_LIGHT.png" width="100%">
  </picture>
</p>

<!-- Logo -->
<p align="center">
  <img alt="Pytik Logo" src="https://raw.githubusercontent.com/faisalaffan/pytik/dev/assets/03_ICON_DARK.png" width="120">
</p>

<h1 align="center">Pytik</h1>
<p align="center"><em>Python yang memakan habis pipeline.</em></p>

<p align="center">
  <a href="https://pypi.org/project/pytik-utils/"><img alt="PyPI" src="https://img.shields.io/pypi/v/pytik-utils?color=blue"></a>
  <a href="#"><img alt="Python" src="https://img.shields.io/badge/python-3.10%2B-3776AB?logo=python"></a>
  <a href="LICENSE"><img alt="License" src="https://img.shields.io/badge/license-MIT-green"></a>
</p>

---

## Apa itu Pytik?

> "Python tidak bernegosiasi dengan ayam. Ia mengonsumsi sepenuhnya."

**Pytik** adalah framework data ingestion predatoris untuk Python — dibangun untuk mengonsumsi, memproses, membersihkan, dan menyelesaikan workflow data secara total, tanpa residu.

Nama ini menggabungkan **Py** (Python) dengan **pitik** — sebuah metafora di mana ular python (pipeline kamu) menelan pitik (data kamu) bulat-bulat.

Bayangkan sebagai predator yang efisien, percaya diri, dan tidak menyisakan edge case.

---

## Filosofi

| Prinsip              | Makna                               |
| -------------------- | ----------------------------------- |
| **Konsumsi Penuh**   | Tidak ada ingestion parsial, tidak ada kegagalan senyap |
| **Deterministik**     | Output yang selalu bisa diprediksi   |
| **Boilerplate Minimal** | `from pytik import consume` sudah cukup |
| **Streaming First**   | Dibangun untuk file besar dan event stream |
| **Backpressure Aware** | Memori terkendali, tekanan terkontrol |

Baca selengkapnya: [Filosofi Brand & PRD →](docs/PRD.md)

---

## Instalasi

```bash
pip install pytik-utils
```

## Mulai Cepat

```python
from pytik_utils import consume

# Satu baris. Ingestion penuh.
consume("data.csv")
```

---

## Fitur (MVP)

- **CSV ingestion** — parsing sadar-skema
- **JSON normalization** — ratakan nested chaos
- **Deduplication** — hapus baris duplikat
- **Schema enforcement** — validasi tipe data saat masuk
- **Streaming iterator** — aman memori untuk file besar
- **Async pipeline** — eksekusi non-blocking

---

## Brand

| Dimensi     | Nilai                                   |
| ----------- | --------------------------------------- |
| **Energi**  | Diam tapi berbahaya                     |
| **Identitas** | Kultur hacker Indonesia/Jawa           |
| **Audiens** | Developer yang ingin tools yang *menyelesaikan pekerjaan* |

**Slogan:**
- *"Don't be the pitik."*
- *"Everything in. Nothing left."*
- *"Coil. Process. Finish."*

---

## Kontribusi

Kontribusi terbuka setelah rilis v0.1.0.

---

## Lisensi

MIT © Muhammad Faisal Affan
