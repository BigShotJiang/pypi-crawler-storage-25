<!-- Language Switcher -->
<p align="right">
  🌐 <a href="README.id.md">Bahasa Indonesia</a>
</p>

<!-- Banner -->
<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/faisalaffan/pytik/dev/assets/01_BANNER_DARK.png">
    <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/faisalaffan/pytik/dev/assets/02_BANNER_LIGHT.png">
    <img alt="Pytik Banner" src="https://raw.githubusercontent.com/faisalaffan/pytik/dev/assets/02_BANNER_LIGHT.png" width="100%">
  </picture>
</p>

<!-- Logo -->
<p align="center">
  <img alt="Pytik Logo" src="https://raw.githubusercontent.com/faisalaffan/pytik/dev/assets/03_ICON_DARK.png" width="120">
</p>

<h1 align="center">Pytik</h1>
<p align="center"><em>The python that eats the pipeline.</em></p>

<p align="center">
  <a href="https://pypi.org/project/pytik-utils/"><img alt="PyPI" src="https://img.shields.io/pypi/v/pytik-utils?color=blue"></a>
  <a href="#"><img alt="Python" src="https://img.shields.io/badge/python-3.10%2B-3776AB?logo=python"></a>
  <a href="LICENSE"><img alt="License" src="https://img.shields.io/badge/license-MIT-green"></a>
</p>

---

## What is Pytik?

> "Python doesn't negotiate with the chicken. It consumes completely."

**Pytik** is a predatory data ingestion framework for Python — built to consume, process, clean, and finish your data workflows entirely, with zero residue.

The name fuses **Py** (Python) with **pitik** (Javanese for "chicken") — a metaphor where the python (your pipeline) swallows the pitik (your data) whole.

Think of it as a confident, efficient predator that leaves no edge case behind.

---

## Philosophy

| Principle         | Meaning                            |
| ----------------- | ---------------------------------- |
| **Full Consumption** | No partial ingestion, no silent failures |
| **Deterministic**    | Predictable output, every time      |
| **Minimal Boilerplate** | `from pytik import consume` is all you need |
| **Streaming First**  | Built for huge files and event streams |
| **Backpressure Aware** | Bounded memory, controlled pressure |

Read more: [Brand Philosophy & PRD →](docs/PRD.md)

---

## Installation

```bash
pip install pytik-utils
```

## Quick Start

```python
from pytik_utils import consume

# One line. Full ingestion.
consume("data.csv")
```

---

## Features (MVP)

- **CSV ingestion** — schema-aware parsing
- **JSON normalization** — flatten nested chaos
- **Deduplication** — remove duplicate rows
- **Schema enforcement** — validate types on entry
- **Streaming iterator** — memory-safe for large files
- **Async pipeline** — non-blocking execution

---

## Brand

| Dimension     | Value                                 |
| ------------- | ------------------------------------- |
| **Energy**    | Quietly dangerous                     |
| **Identity**  | Indonesian/Javanese hacker culture    |
| **Audience**  | Developers who want tools that *finish the job* |

**Slogans:**
- *"Don't be the pitik."*
- *"Everything in. Nothing left."*
- *"Coil. Process. Finish."*

---

## Contributing

Contributions welcome once we hit v0.1.0.

---

## License

MIT © Muhammad Faisal Affan
