"""
Pytik — The python that eats the pipeline.

A predatory data ingestion framework for Python.
"""

__version__ = "0.1.0"
__author__ = "Muhammad Faisal Affan"
__license__ = "MIT"

from pytik_utils._core import consume, ingest


__all__ = ["consume", "ingest", "__version__"]
