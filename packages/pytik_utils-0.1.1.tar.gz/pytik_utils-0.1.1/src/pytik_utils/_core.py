from __future__ import annotations

import csv
import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any


def consume(source: str | Path) -> list[dict[str, Any]]:
    """Consume a data file completely — no partial ingestion, no silent failures.

    Supports CSV and JSON. Automatically detects format from extension.
    """
    path = Path(source)
    if not path.exists():
        raise FileNotFoundError(f"Source not found: {source}")

    suffix = path.suffix.lower()
    if suffix == ".csv":
        return _consume_csv(path)
    if suffix == ".json":
        return _consume_json(path)

    raise ValueError(
        f"Unsupported format: {suffix}. Supported: .csv, .json"
    )


def ingest(source: str | Path) -> Iterator[dict[str, Any]]:
    """Stream rows one at a time — memory-safe for large files."""
    path = Path(source)
    if not path.exists():
        raise FileNotFoundError(f"Source not found: {source}")

    suffix = path.suffix.lower()
    if suffix == ".csv":
        yield from _ingest_csv(path)
    elif suffix == ".json":
        yield from _ingest_json(path)
    else:
        raise ValueError(
            f"Unsupported format: {suffix}. Supported: .csv, .json"
        )


def _consume_csv(path: Path) -> list[dict[str, Any]]:
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)


def _consume_json(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return [data]
    raise ValueError("JSON must be an object or array of objects")


def _ingest_csv(path: Path) -> Iterator[dict[str, Any]]:
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        yield from reader


def _ingest_json(path: Path) -> Iterator[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    items = data if isinstance(data, list) else [data]
    yield from items
