<!--
SPDX-FileCopyrightText: Logan Connolly

SPDX-License-Identifier: CC-BY-SA-4.0
-->

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.0.1 - 2026-03-28

### Added

- Add the `CC-BY-SA-4.0` license identifier to the `pyproject.toml`.

## 1.0.0 - 2026-03-15

### Added

- Initial implementation of the `haitchify` CLI tool which supports converting
  HTML into compliant [haitch](https://pypi.org/project/haitch/) code. You can
  either pass in a file path as a positional argument or pipe content in as
  standard input.
