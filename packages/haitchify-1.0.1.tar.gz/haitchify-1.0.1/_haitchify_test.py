# SPDX-FileCopyrightText: Logan Connolly
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import pathlib
import subprocess

import pytest
from bs4 import BeautifulSoup as bs
from bs4.formatter import HTMLFormatter


def test_haitchify() -> None:
    haitchify_result = subprocess.run(
        ["haitchify"],
        input=EXAMPLE_HTML,
        capture_output=True,
        text=True,
    )
    ruff_result = subprocess.run(
        ["ruff", "format", "-"],
        input=haitchify_result.stdout,
        capture_output=True,
        text=True,
    )

    got = ruff_result.stdout.rstrip()
    want = """\
H.html(lang="en-us")(
    H.head(
        H.meta(charset="utf-8"),
        H.title("Test"),
    ),
    H.body(
        H.main(class_="content")(
            H.button(extra_attrs={"hx-get": "/count"})("Active"),
            H.button(disabled=True)("Inactive"),
        ),
    ),
)"""

    assert got == want


def test_haitchify_with_prepend_option() -> None:
    haitchify_result = subprocess.run(
        ["haitchify", "--prepend"],
        input=EXAMPLE_HTML,
        capture_output=True,
        text=True,
    )
    assert "import haitch as H" in haitchify_result.stdout


def test_haitchify_round_trip_example() -> None:
    import haitch as H  # noqa: F401

    haitchify_result = subprocess.run(
        ["haitchify"],
        input=EXAMPLE_HTML,
        capture_output=True,
        text=True,
    )
    generated_haitch_code = haitchify_result.stdout.rstrip()
    evaluated_haitch_code = eval(generated_haitch_code)

    got = prettify_html(str(evaluated_haitch_code))
    want = EXAMPLE_HTML

    assert got == want


@pytest.mark.parametrize(
    "snapshot_path",
    [
        pytest.param(snapshot_path, id=snapshot_path.name)
        for snapshot_path in pathlib.Path("snapshots").glob("*.html")
    ],
)
def test_haitchify_round_trip_snapshots(snapshot_path: pathlib.Path) -> None:
    import haitch as H  # noqa: F401

    html_content = read_html_snapshot(snapshot_path)
    haitchify_result = subprocess.run(
        ["haitchify"],
        input=html_content,
        capture_output=True,
        text=True,
    )
    generated_haitch_code = haitchify_result.stdout.rstrip()
    evaluated_haitch_code = eval(generated_haitch_code)

    got = prettify_html(str(evaluated_haitch_code))
    want = html_content

    assert got == want, f"Failed processing: {snapshot_path.name}"


def prettify_html(content: str) -> str | bytes:
    formatter = HTMLFormatter(indent=2, empty_attributes_are_booleans=True)
    soup = bs(content, features="html.parser")
    return soup.prettify(formatter=formatter)


def read_html_snapshot(path: pathlib.Path) -> str:
    raw_content = path.read_text()
    license_header = """\
<!--
SPDX-FileCopyrightText: Logan Connolly

SPDX-License-Identifier: AGPL-3.0-or-later
-->

"""
    _, html_content = raw_content.split(license_header, maxsplit=1)
    return html_content


EXAMPLE_HTML = """\
<!DOCTYPE html>
<html lang="en-us">
  <head>
    <meta charset="utf-8"/>
    <title>
      Test
    </title>
  </head>
  <body>
    <main class="content">
      <button hx-get="/count">
        Active
      </button>
      <button disabled>
        Inactive
      </button>
    </main>
  </body>
</html>
"""
