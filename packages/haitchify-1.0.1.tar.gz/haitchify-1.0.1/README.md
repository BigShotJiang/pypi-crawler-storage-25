<!--
SPDX-FileCopyrightText: Logan Connolly

SPDX-License-Identifier: CC-BY-SA-4.0
-->

[![builds.sr.ht status](https://builds.sr.ht/~loges/haitchify.svg)](https://builds.sr.ht/~loges/haitchify?)
[![REUSE status](https://api.reuse.software/badge/git.sr.ht/~loges/haitchify)](https://api.reuse.software/info/git.sr.ht/~loges/haitchify)
[![PyPI - Version](https://img.shields.io/pypi/v/haitchify.svg)](https://pypi.org/project/haitchify)

# haitchify

> Convert HTML into compliant [haitch](https://pypi.org/project/haitch/) code.

## Quickstart

The easiest way to use this tool is with [pipx](https://github.com/pypa/pipx)
(or the [uvx](https://docs.astral.sh/uv/guides/tools/) variant).

```shell
$ pipx install haitchify
```

Now that the package is installed, you can call the `haitchify` program.

There are two ways to use it:

- provide a file path argument.
- pass in HTML content via standard input.

When program is called with no arguments, you will be presented with a prompt
where you can type in some HTML. When you are done, type `<C-d>` to exit.
However, the more common approach would be to use the pipe operator to pass in
the input:

```shell
$ echo "<h1>Hello, world</h1>" | haitchify
```

Which outputs to:

```console
H.h1("Hello, world")
```

You can also optionally add the `--prepend` flag which will also add an import
to the `haitch` library to the top of the output.

## Demo

[![asciicast](https://asciinema.org/a/0qKOIEjwI6WHeU0s.svg)](https://asciinema.org/a/0qKOIEjwI6WHeU0s)

## License

`haitchify` is distributed under the terms of the
[AGPLv3](https://spdx.org/licenses/AGPL-3.0-or-later.html) license and adheres
to the [REUSE Specification](https://reuse.software/spec-3.3/).
