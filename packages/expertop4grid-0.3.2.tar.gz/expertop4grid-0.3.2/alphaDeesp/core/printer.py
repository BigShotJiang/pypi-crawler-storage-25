# Copyright (c) 2019-2020, RTE (https://www.rte-france.com)
# See AUTHORS.txt
# This Source Code Form is subject to the terms of the Mozilla Public License, version 2.0.
# If a copy of the Mozilla Public License, version 2.0 was not distributed with this file,
# you can obtain one at http://mozilla.org/MPL/2.0/.
# SPDX-License-Identifier: MPL-2.0
# This file is part of ExpertOp4Grid, an expert system approach to solve flow congestions in power grids

"""This file contains all the possible displays for graph from NetworkX"""

import datetime
import logging
import os
import subprocess
from typing import List, Optional, Tuple

import networkx as nx

from alphaDeesp.core.interactive_html import build_interactive_html
from alphaDeesp.core.twin_nodes import twin_node_id

logger = logging.getLogger(__name__)


class Printer:
    save_id_number: int = 0

    def __init__(self, output_path: Optional[str] = None) -> None:
        if output_path is None:
            self.default_output_path = "alphaDeesp/ressources/output"
        else:
            self.default_output_path = output_path
        self.base_output_path = os.path.join(self.default_output_path,"Base graph")
        os.makedirs(self.base_output_path, exist_ok=True)
        self.results_output_path = os.path.join(self.default_output_path,"Result graph")
        os.makedirs(self.results_output_path, exist_ok=True)
        logger.debug("self.default output path = %s", self.default_output_path)

    def plot_graphviz(
        self,
        g: nx.DiGraph,
        custom_layout: Optional[List[Tuple[float, float]]] = None,
        rescale_factor: Optional[float] = None,
        allow_overlap: bool = True,
        fontsize: Optional[int] = None,
        node_thickness: int = 3,
        axial_symetry: bool = False,
        save: bool = False,
        name: Optional[str] = None,
    ) -> bytes:
        "filenames are pathlib.Paths objects"

        dic_pos_attributes = {}
        if custom_layout is not None:
            if rescale_factor is not None:
                custom_layout=[(e[0]/rescale_factor,e[1]/rescale_factor) for e in custom_layout]
            assert isinstance(custom_layout, list) is True
            # we create a dictionary to add a position attribute to the nodes
            ii = 0
            n_layout=len(custom_layout)
            for i, node in enumerate(g.nodes):#(custom_layout):
                # i += 1
                # print(f"i:{i} value:{value}")
                value=custom_layout[i%n_layout]
                if i < len(custom_layout):
                    dic_pos_attributes[node] = {"pos": (str(value[0]) + ", " + str(value[1]) + "!")}
                else:
                    node = twin_node_id(ii)
                    dic_pos_attributes[node] = {"pos": (str(value[0]) + ", " + str(value[1]) + "!")}
                    ii += 1

            # we update the graph with some specific position
            # see here "node_attributes" for more attributes you can update in the drawing https://github.com/pydot/pydot/blob/a892962a2db1a71f5e0aa83cfa734720ce2bb077/src/pydot/core.py#L61
            nx.set_node_attributes(g, dic_pos_attributes)

        if fontsize is not None:
            nx.set_node_attributes(g, fontsize,"fontsize")
            nx.set_node_attributes(g, 0, "margin")

        nx.set_node_attributes(g, node_thickness, "penwidth")#size of nodes thickness

            #nx.set_edge_attributes(g,overlap_margin,"len")

        graph = nx.drawing.nx_pydot.to_pydot(g)

        if custom_layout is not None:
            prog=["neato","-n","-x"] #-n to minimize overlap, -x to prune isolated components
            if not allow_overlap:
                graph.set_overlap(False)
            output_graphviz_svg = graph.create_svg(prog=prog)
        else:
            output_graphviz_svg = graph.create_svg(prog="dot")#(prog="dot")

        return output_graphviz_svg



    def display_geo(
        self,
        g: nx.DiGraph,
        custom_layout: Optional[List[Tuple[float, float]]] = None,
        rescale_factor: Optional[float] = None,
        fontsize: Optional[int] = None,
        node_thickness: int = 3,
        axial_symetry: bool = False,
        save: bool = False,
        name: Optional[str] = None,
    ) -> None:
        """This function displays the graph g in a "geographical" way"""

        "filenames are pathlib.Paths objects"
        type_ = "results"
        if name in ["g_pow", "g_overflow_print", "g_pow_prime"]:
            type_ = "base"
        filename_dot, filename_pdf = self.create_namefile("geo", name=name, type = type_)

        dic_pos_attributes = {}
        if custom_layout is not None:
            if rescale_factor is not None:
                custom_layout=[(e[0]/rescale_factor,e[1]/rescale_factor) for e in custom_layout]
            assert isinstance(custom_layout, list) is True
            # we create a dictionary to add a position attribute to the nodes
            ii = 0
            n_layout=len(custom_layout)
            for i, node in enumerate(g.nodes):#(custom_layout):
                # i += 1
                # print(f"i:{i} value:{value}")
                value=custom_layout[i%n_layout]
                if i < len(custom_layout):
                    dic_pos_attributes[node] = {"pos": (str(value[0]) + ", " + str(value[1]) + "!")}
                else:
                    node = twin_node_id(ii)
                    dic_pos_attributes[node] = {"pos": (str(value[0]) + ", " + str(value[1]) + "!")}
                    ii += 1

            # we update the graph with some specific position
            # see here "node_attributes" for more attributes you can update in the drawing https://github.com/pydot/pydot/blob/a892962a2db1a71f5e0aa83cfa734720ce2bb077/src/pydot/core.py#L61
            nx.set_node_attributes(g, dic_pos_attributes)

        if fontsize is not None:
            nx.set_node_attributes(g, fontsize,"fontsize")
            nx.set_node_attributes(g, 0, "margin")

        nx.set_node_attributes(g, node_thickness, "penwidth")#size of nodes thickness

            #nx.set_edge_attributes(g,overlap_margin,"len")

        nx.drawing.nx_pydot.write_dot(g, filename_dot)

        if custom_layout is None:

            cmd_line = 'dot -Tpdf "' + str(filename_dot) + '" -o "' + str(filename_pdf) + '"'#'neato -Tpdf "' + str(filename_dot) + '" -o "' + str(filename_pdf) + '"'
            html_prog = "dot"
        else:
            cmd_line = 'neato -n -Tpdf "' + str(filename_dot) + '" -o "' + str(filename_pdf) + '"'
            html_prog = ["neato", "-n", "-x"]
        logger.debug("we print the cmd line = %s", cmd_line)

        assert execute_command(cmd_line)

        # Also emit a self-contained interactive HTML viewer alongside the
        # PDF. Failure here must not break the existing PDF flow — the HTML
        # viewer is an additive convenience, not a hard dependency.
        try:
            filename_html = filename_pdf[:-4] + ".html" if filename_pdf.endswith(".pdf") else filename_pdf + ".html"
            pydot_graph = nx.drawing.nx_pydot.to_pydot(g)
            html = build_interactive_html(pydot_graph, prog=html_prog, title=os.path.basename(filename_html))
            with open(filename_html, "w", encoding="utf-8") as fh:
                fh.write(html)
            logger.debug("interactive HTML written to %s", filename_html)
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("interactive HTML export failed: %s", exc)


        #cmd_line = f"evince {str(filename_pdf)} &"
        #os.system(cmd_line)
#
        #os.system(cmd_line)
        #os.system("evince " + str(filename_pdf) + " &")

        # if save is False:
        #     assert(alphadeesp.execute_command(f"rm {filename_dot}"))
        #     assert(alphadeesp.execute_command(f"rm {filename_pdf}"))

        # if save is False:
        #     os.system("rm " + filename_dot)
        #     os.system("rm " + filename_pdf)

    def display_elec(self, g: nx.DiGraph, save: bool = False) -> None:
        pass

    def create_namefile(
        self,
        display_type: str,
        name: Optional[str] = None,
        type: str = "results",
    ) -> Tuple[str, str]:
        """return dot and pdf filenames"""
        # filename_dot = "graph_result_" + display_type + "_" + current_date + ".dot"
        # filename_pdf = "graph_result_" + display_type + "_" + current_date + ".pdf"
        current_date_no_filter = datetime.datetime.now()
        current_date = current_date_no_filter.strftime("%Y-%m-%d_%H-%M")
        if type == 'results':
            current_date += "_" + str(Printer.save_id_number) + "_"
            Printer.save_id_number += 1

        if name is None:
            name = ""
        logger.debug("name = %s", name)
        filename_dot = name + "_" + display_type + "_" + current_date + ".dot"
        filename_pdf = name + "_" + display_type + "_" + current_date + ".pdf"

        if type == "results":
            output_path = self.results_output_path
        elif type == "base":
            output_path = self.base_output_path
        else:
            output_path = self.default_output_path
        hard_filename_dot = os.path.join(output_path,filename_dot)
        # hard_filename_dot = filename_dot
        hard_filename_pdf = os.path.join(output_path,filename_pdf)

        logger.debug("============================= FUNCTION create_namefile =============================")
        logger.debug("hard_filename = %s", hard_filename_pdf)

        return hard_filename_dot, hard_filename_pdf


def shell_print_project_header() -> None:
    os.system("cat ./print_header.txt")

########################################################################################################################
# ######################################### EXTERNAL COMMANDS ##########################################################
########################################################################################################################


def execute_command(command: str) -> bool:
    """
    This function executes a command on the local machine, and fill self.output and self.error with results of
    command.
    @return True if command went through
    """

    # # print("command = ", command)
    sub_p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    _stdout, stderr = sub_p.communicate()
    error = stderr.decode()

    # print("--------------------\n exit code is:", sub_p.returncode)

    if not error:
        # string error is empty
        return True
    else:
        # string error is full
        # # print(f"Error {error}")
        return False
