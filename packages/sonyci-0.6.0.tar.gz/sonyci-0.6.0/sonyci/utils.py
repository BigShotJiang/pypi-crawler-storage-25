from time import sleep

from requests import HTTPError, post
from requests_oauth2client import BearerToken, TokenSerializer

from sonyci.config import TOKEN_URL
from sonyci.exceptions import RetryError
from sonyci.log import log


def get_token(
    username: str,
    password: str,
    client_id: str,
    client_secret: str,
    token_url: str = TOKEN_URL,
) -> BearerToken:
    """Login to SonyCI and return a BearerToken."""
    response = post(
        token_url,
        auth=(username, password),
        data={
            'grant_type': 'password',
            'client_id': client_id,
            'client_secret': client_secret,
        },
    )
    log.debug(f'token response status: {response.status_code}')
    if response.status_code != 200:
        log.error(f'Token returned {response.status_code}: {response.text}')
        raise Exception(
            f'Token did not return 200. Returned: {response.status_code}: {response.text}'
        )
    return BearerToken(**response.json())


def get_token_from_file(filename: str = '.token'):
    with open(filename) as f:
        return TokenSerializer().loads(f.read())


def save_token_to_file(token: BearerToken, filename: str = '.token'):
    with open(filename, 'wb') as f:
        f.write(TokenSerializer().dumps(token))


def json(func):
    """Decorator for calling .json() on Response objects."""

    def inner(*args, **kwargs):
        return func(*args, **kwargs).json()

    return inner


def retry(func):
    """Decorator for retrying a function call after a rate limit error."""

    def inner(*args, **kwargs):
        max_tries: int = (
            args[0].max_tries if args and hasattr(args[0], 'max_tries') else 5
        )
        for _ in range(max_tries):
            try:
                return func(*args, **kwargs)
            except HTTPError as e:
                if e.response.status_code != 429:
                    log.error(f'HTTPError {e.response.status_code}: {e}')
                    raise e

                # Get the retry-after header, if it exists
                retry_after = e.response.headers.get('Retry-After')
                if not retry_after:
                    log.error('No Retry-After header found')
                    raise e
                retry_after = int(retry_after)
                log.warning(f'Rate limited. Retrying after {retry_after} seconds...')
                sleep(retry_after + 1)
        log.error(f'Failed after {max_tries} tries')
        raise RetryError(f'Failed after {max_tries} tries')

    return inner
