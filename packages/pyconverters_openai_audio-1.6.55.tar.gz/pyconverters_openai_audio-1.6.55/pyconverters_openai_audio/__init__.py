"""OpenAIAudio converter"""

__version__ = "1.6.55"
