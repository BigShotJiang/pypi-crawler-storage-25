#!/usr/bin/env python3

"""
Entry point for SpeciesFinder.
Configures logging and delegates execution to SpeciesFinder().
"""
from speciesfinder.speciesfinder_run import speciesfinder
from speciesfinder.speciesfinder_args_functions import parse_arguments

import logging
import sys
import os

args = parse_arguments()
out_folder = args.output_folder

# Ensure output directory exists
os.makedirs(out_folder, exist_ok=True)

# Logging config
log_path = os.path.join(out_folder, "speciesfinder.log")

logging.basicConfig(
    filename=log_path,
    encoding="utf-8",
    filemode="a",
    format="{asctime} - {levelname} - {message}",
    style="{",
    datefmt="%Y-%m-%d %H:%M",
    level=logging.INFO,
    force=True)

# Initial log message
logging.info("###############################################################")
logging.info("###############################################################")
logging.info("########################NEW SPECIESFINDER RUN#####################")

def main():

    try:
        return speciesfinder()
    except Exception:
        logging.exception(f"Fatal error in SpeciesFinder")
        return 1

if __name__=="__main__":
    sys.exit(main())
