"""Pandas-related helpers shared across checks."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Iterator

import pandas as pd


def ensure_list(value: str | list[str] | tuple[str, ...]) -> list[str]:
    """Return a list representation for a single item or list-like value."""
    if isinstance(value, str):
        return [value]
    if isinstance(value, Iterable):
        return list(value)
    return [value]


def format_group_value(value: object, group_cols: list[str] | None = None) -> str:
    """Create a stable string label for a group key."""
    if isinstance(value, tuple):
        if len(value) == 1:
            return str(value[0])
        if group_cols and len(group_cols) == len(value):
            return " | ".join(
                f"{column}={item}" for column, item in zip(group_cols, value, strict=True)
            )
        return " | ".join(str(item) for item in value)
    return str(value)


def iter_group_frames(
    df: pd.DataFrame,
    group_cols: list[str],
) -> Iterator[tuple[str, pd.DataFrame]]:
    """Yield stable group labels and grouped dataframes for grouped analysis."""
    if not group_cols:
        yield "__all__", df
        return

    grouped = df.groupby(group_cols, dropna=False, sort=True)
    for key, group_df in grouped:
        yield format_group_value(key, group_cols), group_df
