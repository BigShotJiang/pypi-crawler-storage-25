"""Shared type aliases."""

from __future__ import annotations

from typing import Any

SummaryDict = dict[str, Any]
