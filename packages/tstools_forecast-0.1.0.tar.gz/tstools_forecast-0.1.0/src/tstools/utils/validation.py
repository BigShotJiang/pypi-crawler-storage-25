"""Validation helpers for public API inputs."""

from __future__ import annotations


def validate_column_name(value: str, *, field_name: str) -> str:
    """Validate that a column-like argument is a non-empty string."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")
    return value


def validate_column_names(values: list[str], *, field_name: str) -> list[str]:
    """Validate a list of column names."""
    if not isinstance(values, list):
        raise ValueError(f"{field_name} must be a list of strings.")
    return [validate_column_name(value, field_name=field_name) for value in values]


def validate_min_history(min_history: int) -> int:
    """Validate the minimum history threshold."""
    if not isinstance(min_history, int) or min_history < 1:
        raise ValueError("min_history must be an integer greater than or equal to 1.")
    return min_history
