"""Utility helpers for TSTools."""
