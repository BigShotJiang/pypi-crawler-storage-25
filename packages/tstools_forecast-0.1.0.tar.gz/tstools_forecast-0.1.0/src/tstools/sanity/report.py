"""Report builders and formatters."""

from __future__ import annotations

import pandas as pd

from tstools.sanity.config import SanityCheckConfig
from tstools.sanity.models import CheckResult, SanityReport
from tstools.utils.typing import SummaryDict


SECTION_ORDER = [
    ("Schema", "schema"),
    ("Dates", "dates"),
    ("Duplicates", "duplicates"),
    ("Target Quality", "targets"),
    ("Group Health", "groups"),
]


def _compute_overall_status(check_results: list[CheckResult]) -> str:
    if any(result.status == "FAIL" for result in check_results):
        return "NOT_READY"
    if any(result.status == "WARN" for result in check_results):
        return "READY_WITH_WARNINGS"
    return "READY"


def build_report(
    *,
    df: pd.DataFrame,
    config: SanityCheckConfig,
    check_results: list[CheckResult],
    summary: SummaryDict,
) -> SanityReport:
    """Build the final report object."""
    return SanityReport(
        overall_status=_compute_overall_status(check_results),
        dataset_shape=df.shape,
        date_col=config.date_col,
        target_cols=config.target_cols,
        group_cols=config.group_cols,
        expected_freq=config.expected_freq,
        min_history=config.min_history,
        check_results=check_results,
        summary=summary,
    )


def _collect_top_affected_groups(summary: SummaryDict) -> list[str]:
    lines: list[str] = []
    for group, count in summary.get("top_missing_groups", []):
        lines.append(f"{group} -> {count} missing dates")
    for group in summary.get("duplicate_groups", []):
        lines.append(f"{group} -> duplicate keys")
    for target, groups in sorted(summary.get("missing_target_groups", {}).items()):
        for group in groups:
            lines.append(f"{group} -> missing target values ({target})")
    for target, groups in sorted(summary.get("constant_groups", {}).items()):
        for group in groups:
            lines.append(f"{group} -> constant series ({target})")
    for target, groups in sorted(summary.get("all_zero_groups", {}).items()):
        for group in groups:
            lines.append(f"{group} -> all-zero series ({target})")
    for group in summary.get("short_history_groups", []):
        lines.append(f"{group} -> short history")
    seen: set[str] = set()
    ordered: list[str] = []
    for line in lines:
        if line not in seen:
            seen.add(line)
            ordered.append(line)
    return ordered[:5]


def format_report(report: SanityReport) -> str:
    """Format a report for terminal or notebook output."""
    lines = [
        "=" * 50,
        "TSTools Sanity Check Report",
        "=" * 50,
        "",
        f"Dataset shape     : {report.dataset_shape[0]:,} rows x {report.dataset_shape[1]} columns",
        f"Date column       : {report.date_col}",
        f"Target column(s)  : {', '.join(report.target_cols)}",
        f"Group column(s)   : {report.group_cols if report.group_cols else '[]'}",
        f"Expected frequency: {report.expected_freq if report.expected_freq else 'None'}",
        f"Min history       : {report.min_history}",
        "",
        f"Overall status    : {report.overall_status}",
        "",
    ]

    for index, (title, check_name) in enumerate(SECTION_ORDER, start=1):
        lines.append(f"[{index}] {title}")
        section_results = [result for result in report.check_results if result.name == check_name]
        for result in section_results:
            lines.append(f"  {result.status:<5} {result.message}")
        if not section_results:
            lines.append("  INFO  No results recorded.")
        lines.append("")

    top_affected = _collect_top_affected_groups(report.summary)
    if top_affected:
        lines.append("Top affected groups:")
        for line in top_affected:
            lines.append(f"  {line}")

    return "\n".join(lines).rstrip()


def print_report(report: SanityReport) -> None:
    """Print the formatted report."""
    print(format_report(report))
