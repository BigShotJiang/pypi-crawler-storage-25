"""Target-quality checks."""

from __future__ import annotations

import pandas as pd

from tstools.sanity.config import SanityCheckConfig
from tstools.sanity.models import CheckResult
from tstools.utils.pandas_helpers import iter_group_frames
from tstools.utils.typing import SummaryDict


def run_target_checks(
    df: pd.DataFrame,
    config: SanityCheckConfig,
) -> tuple[list[CheckResult], SummaryDict]:
    """Validate target numeric quality and series shape signals."""
    results: list[CheckResult] = []
    summary: SummaryDict = {
        "missing_target_rows": {},
        "constant_groups": {},
        "all_zero_groups": {},
        "missing_target_groups": {},
    }

    for target_col in config.target_cols:
        original = df[target_col]
        coerced = pd.to_numeric(original, errors="coerce")
        invalid_mask = original.notna() & coerced.isna()
        invalid_count = int(invalid_mask.sum())

        if invalid_count:
            results.append(
                CheckResult(
                    name="targets",
                    status="FAIL",
                    message=f"Target column '{target_col}' has {invalid_count} non-numeric values.",
                    details={"target": target_col, "invalid_numeric_entries": invalid_count},
                )
            )
        else:
            results.append(
                CheckResult(
                    name="targets",
                    status="PASS",
                    message=f"Target column '{target_col}' is numeric.",
                    details={"target": target_col, "invalid_numeric_entries": 0},
                )
            )

        numeric_df = df.assign(**{target_col: coerced})
        missing_count = int(coerced.isna().sum())
        summary["missing_target_rows"][target_col] = missing_count
        missing_groups: list[str] = []
        if missing_count:
            for group_label, group_df in iter_group_frames(numeric_df, config.group_cols):
                if group_df[target_col].isna().any():
                    missing_groups.append(group_label)
            results.append(
                CheckResult(
                    name="targets",
                    status="INFO" if config.allow_missing_target else "WARN",
                    message=f"Missing target values found in {missing_count} rows for '{target_col}'.",
                    details={"target": target_col, "missing_rows": missing_count},
                )
            )
        summary["missing_target_groups"][target_col] = missing_groups

        constant_groups: list[str] = []
        all_zero_groups: list[str] = []
        for group_label, group_df in iter_group_frames(numeric_df, config.group_cols):
            non_null = group_df[target_col].dropna()
            if non_null.empty:
                continue
            if non_null.nunique(dropna=True) == 1:
                constant_groups.append(group_label)
                if (non_null == 0).all():
                    all_zero_groups.append(group_label)

        summary["constant_groups"][target_col] = constant_groups
        summary["all_zero_groups"][target_col] = all_zero_groups

        if constant_groups:
            results.append(
                CheckResult(
                    name="targets",
                    status="WARN",
                    message=f"Constant series found for '{target_col}' in {len(constant_groups)} groups.",
                    details={"target": target_col, "constant_groups": constant_groups},
                )
            )
        if all_zero_groups:
            results.append(
                CheckResult(
                    name="targets",
                    status="WARN",
                    message=f"All-zero series found for '{target_col}' in {len(all_zero_groups)} groups.",
                    details={"target": target_col, "all_zero_groups": all_zero_groups},
                )
            )

    return results, summary
