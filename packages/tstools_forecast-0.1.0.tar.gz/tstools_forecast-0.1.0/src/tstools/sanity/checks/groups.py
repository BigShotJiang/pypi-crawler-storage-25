"""Group-level health checks."""

from __future__ import annotations

import pandas as pd

from tstools.sanity.config import SanityCheckConfig
from tstools.sanity.models import CheckResult
from tstools.utils.pandas_helpers import format_group_value
from tstools.utils.typing import SummaryDict


def run_group_checks(
    df: pd.DataFrame,
    config: SanityCheckConfig,
) -> tuple[list[CheckResult], SummaryDict]:
    """Summarize group counts and history lengths."""
    if config.group_cols:
        grouped = df.groupby(config.group_cols, dropna=False, sort=True)
        history_by_group = {
            format_group_value(key, config.group_cols): int(group_df[config.date_col].nunique())
            for key, group_df in grouped
        }
    else:
        history_by_group = {"__all__": int(df[config.date_col].nunique())}

    history_lengths = sorted(history_by_group.values())
    group_count = len(history_by_group)
    history_min = min(history_lengths) if history_lengths else 0
    history_median = int(pd.Series(history_lengths).median()) if history_lengths else 0
    history_max = max(history_lengths) if history_lengths else 0
    short_history_groups = sorted(
        [group for group, count in history_by_group.items() if count < config.min_history]
    )

    results = [
        CheckResult(
            name="groups",
            status="INFO",
            message=f"Total groups: {group_count}.",
            details={"group_count": group_count},
        ),
        CheckResult(
            name="groups",
            status="INFO",
            message=(
                f"History length min/median/max: {history_min} / "
                f"{history_median} / {history_max}."
            ),
            details={
                "history_length_min": history_min,
                "history_length_median": history_median,
                "history_length_max": history_max,
            },
        ),
    ]
    if short_history_groups:
        results.append(
            CheckResult(
                name="groups",
                status="WARN",
                message=(
                    f"Short-history groups (<{config.min_history}): {len(short_history_groups)}."
                ),
                details={"short_history_groups": short_history_groups},
            )
        )
    else:
        results.append(
            CheckResult(
                name="groups",
                status="PASS",
                message=f"All groups meet the minimum history threshold of {config.min_history}.",
            )
        )

    summary: SummaryDict = {
        "group_count": group_count,
        "history_length_min": history_min,
        "history_length_median": history_median,
        "history_length_max": history_max,
        "short_history_groups": short_history_groups,
    }
    return results, summary
