"""Duplicate key checks."""

from __future__ import annotations

import pandas as pd

from tstools.sanity.config import SanityCheckConfig
from tstools.sanity.models import CheckResult
from tstools.utils.pandas_helpers import format_group_value
from tstools.utils.typing import SummaryDict


def run_duplicate_checks(
    df: pd.DataFrame,
    config: SanityCheckConfig,
) -> tuple[list[CheckResult], SummaryDict]:
    """Detect duplicate keys in grouped or ungrouped series data."""
    key_cols = [*config.group_cols, config.date_col] if config.group_cols else [config.date_col]
    duplicate_mask = df.duplicated(subset=key_cols, keep=False)
    duplicate_rows = df.loc[duplicate_mask].copy()
    duplicate_count = int(duplicate_mask.sum())

    duplicate_groups: list[str] = []
    if not duplicate_rows.empty and config.group_cols:
        grouped = duplicate_rows.groupby(config.group_cols, dropna=False, sort=True)
        duplicate_groups = sorted(
            format_group_value(key, config.group_cols) for key, _ in grouped
        )
    elif duplicate_count:
        duplicate_groups = ["__all__"]

    if duplicate_count:
        status = "WARN" if config.allow_duplicates else "FAIL"
        message = f"Found {duplicate_count} duplicate rows on key {key_cols}."
    else:
        status = "PASS"
        message = f"No duplicate keys found on {key_cols}."

    results = [
        CheckResult(
            name="duplicates",
            status=status,
            message=message,
            details={
                "duplicate_key_count": duplicate_count,
                "duplicate_key_columns": key_cols,
                "duplicate_groups": duplicate_groups,
            },
        )
    ]

    summary: SummaryDict = {
        "duplicate_key_count": duplicate_count,
        "duplicate_key_columns": key_cols,
        "duplicate_groups": duplicate_groups,
    }
    return results, summary
