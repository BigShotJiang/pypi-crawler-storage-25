"""Schema and precondition checks."""

from __future__ import annotations

import pandas as pd

from tstools.sanity.config import SanityCheckConfig
from tstools.sanity.models import CheckResult


def run_schema_checks(df: object, config: SanityCheckConfig) -> list[CheckResult]:
    """Validate preconditions before other checks run."""
    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be a pandas DataFrame.")

    required_columns = [config.date_col, *config.target_cols, *config.group_cols]
    missing_columns = sorted(set(required_columns) - set(df.columns))
    if missing_columns:
        missing = ", ".join(missing_columns)
        raise ValueError(f"Missing required columns: {missing}")

    return [
        CheckResult(
            name="schema",
            status="PASS",
            message="Required columns found.",
            details={"required_columns": required_columns},
        )
    ]
