"""Date parsing, frequency, and missing timestamp checks."""

from __future__ import annotations

from collections import Counter

import pandas as pd

from tstools.sanity.config import SanityCheckConfig
from tstools.sanity.models import CheckResult
from tstools.utils.pandas_helpers import iter_group_frames
from tstools.utils.typing import SummaryDict


def parse_date_column(df: pd.DataFrame, date_col: str) -> tuple[pd.DataFrame, CheckResult]:
    """Parse the date column and report parse failures."""
    parsed_df = df.copy()
    parsed_df[date_col] = pd.to_datetime(parsed_df[date_col], errors="coerce")
    invalid_count = int(parsed_df[date_col].isna().sum())
    if invalid_count:
        result = CheckResult(
            name="dates",
            status="FAIL",
            message=f"Found {invalid_count} unparseable date rows in '{date_col}'.",
            details={"invalid_date_rows": invalid_count},
        )
    else:
        result = CheckResult(
            name="dates",
            status="PASS",
            message="Date column parsed successfully.",
            details={"invalid_date_rows": 0},
        )
    return parsed_df, result


def _infer_group_frequency(dates: pd.Series) -> str | None:
    unique_dates = pd.Series(sorted(pd.unique(dates.dropna())))
    if len(unique_dates) < 2:
        return None
    if len(unique_dates) >= 3:
        inferred = pd.infer_freq(unique_dates)
        if inferred:
            return inferred

    deltas = unique_dates.diff().dropna()
    if deltas.empty:
        return None
    unique_deltas = deltas.unique()
    if len(unique_deltas) != 1:
        return None

    delta = unique_deltas[0]
    if delta == pd.Timedelta(days=1):
        return "D"
    if delta == pd.Timedelta(weeks=1):
        return "W"
    return None


def run_date_checks(
    df: pd.DataFrame,
    config: SanityCheckConfig,
) -> tuple[pd.DataFrame, list[CheckResult], SummaryDict]:
    """Run parsing, frequency, and missing-date checks."""
    parsed_df, parse_result = parse_date_column(df, config.date_col)
    valid_df = parsed_df.loc[parsed_df[config.date_col].notna()].copy()

    groups_checked = 0
    groups_with_missing_dates = 0
    missing_dates_by_group: dict[str, int] = {}
    inferred_freq_counts: Counter[str] = Counter()
    mismatched_groups: list[str] = []
    unknown_groups: list[str] = []

    for group_label, group_df in iter_group_frames(valid_df, config.group_cols):
        groups_checked += 1
        unique_dates = pd.Series(group_df[config.date_col].drop_duplicates().sort_values())
        inferred_freq = _infer_group_frequency(unique_dates)
        inferred_freq_counts[inferred_freq or "unknown"] += 1

        if inferred_freq is None:
            unknown_groups.append(group_label)
        if config.expected_freq and inferred_freq and inferred_freq != config.expected_freq:
            mismatched_groups.append(group_label)

        active_freq = config.expected_freq or inferred_freq
        if active_freq is None or unique_dates.empty:
            continue

        expected_range = pd.date_range(
            start=unique_dates.iloc[0],
            end=unique_dates.iloc[-1],
            freq=active_freq,
        )
        actual_dates = set(unique_dates.tolist())
        missing_count = sum(1 for value in expected_range if value not in actual_dates)
        if missing_count > 0:
            groups_with_missing_dates += 1
            missing_dates_by_group[group_label] = missing_count

    results = [parse_result]
    if missing_dates_by_group:
        results.append(
            CheckResult(
                name="dates",
                status="WARN",
                message=(
                    f"Missing dates detected in {groups_with_missing_dates}/{groups_checked} groups."
                ),
                details={"missing_dates_by_group": missing_dates_by_group},
            )
        )
    else:
        results.append(
            CheckResult(
                name="dates",
                status="PASS",
                message="No missing dates detected in analyzed groups.",
            )
        )

    if config.expected_freq and mismatched_groups:
        results.append(
            CheckResult(
                name="dates",
                status="WARN",
                message=(
                    f"Observed cadence mismatches expected frequency '{config.expected_freq}' "
                    f"in {len(mismatched_groups)} groups."
                ),
                details={"mismatched_groups": mismatched_groups},
            )
        )

    if unknown_groups:
        results.append(
            CheckResult(
                name="dates",
                status="WARN",
                message=f"Frequency inference is unclear for {len(unknown_groups)} groups.",
                details={"unknown_frequency_groups": unknown_groups},
            )
        )

    summary: SummaryDict = {
        "groups_checked": groups_checked,
        "groups_with_missing_dates": groups_with_missing_dates,
        "missing_dates_by_group": missing_dates_by_group,
        "top_missing_groups": sorted(
            missing_dates_by_group.items(),
            key=lambda item: (-item[1], item[0]),
        )[:5],
        "inferred_freq_counts": dict(sorted(inferred_freq_counts.items())),
        "frequency_mismatch_groups": mismatched_groups,
        "unknown_frequency_groups": unknown_groups,
        "invalid_date_rows": parse_result.details.get("invalid_date_rows", 0),
    }
    return valid_df, results, summary
