"""Public sanity-check API."""

from __future__ import annotations

import pandas as pd

from tstools.sanity.checks.dates import run_date_checks
from tstools.sanity.checks.duplicates import run_duplicate_checks
from tstools.sanity.checks.groups import run_group_checks
from tstools.sanity.checks.schema import run_schema_checks
from tstools.sanity.checks.targets import run_target_checks
from tstools.sanity.config import normalize_config
from tstools.sanity.models import SanityReport
from tstools.sanity.report import build_report, print_report as emit_report


def sanity_checks(
    df: pd.DataFrame,
    date_col: str,
    target_col: str | list[str],
    group_cols: list[str] | None = None,
    expected_freq: str | None = None,
    min_history: int = 12,
    allow_missing_target: bool = False,
    allow_duplicates: bool = False,
    print_report: bool = True,
    return_report: bool = True,
) -> SanityReport | None:
    """Run sanity checks on a time series forecasting dataset."""
    config = normalize_config(
        date_col=date_col,
        target_col=target_col,
        group_cols=group_cols,
        expected_freq=expected_freq,
        min_history=min_history,
        allow_missing_target=allow_missing_target,
        allow_duplicates=allow_duplicates,
    )

    schema_results = run_schema_checks(df, config)
    working_df = df

    all_results = list(schema_results)
    summary: dict[str, object] = {}

    working_df, date_results, date_summary = run_date_checks(working_df, config)
    all_results.extend(date_results)
    summary.update(date_summary)

    duplicate_results, duplicate_summary = run_duplicate_checks(working_df, config)
    all_results.extend(duplicate_results)
    summary.update(duplicate_summary)

    target_results, target_summary = run_target_checks(working_df, config)
    all_results.extend(target_results)
    summary.update(target_summary)

    group_results, group_summary = run_group_checks(working_df, config)
    all_results.extend(group_results)
    summary.update(group_summary)

    report = build_report(
        df=df,
        config=config,
        check_results=all_results,
        summary=summary,
    )

    if print_report:
        emit_report(report)
    if return_report:
        return report
    return None
