"""Configuration model and normalization for sanity checks."""

from __future__ import annotations

from dataclasses import dataclass

from tstools.utils.pandas_helpers import ensure_list
from tstools.utils.validation import (
    validate_column_name,
    validate_column_names,
    validate_min_history,
)


@dataclass(slots=True)
class SanityCheckConfig:
    """Normalized configuration for a sanity-check run."""

    date_col: str
    target_cols: list[str]
    group_cols: list[str]
    expected_freq: str | None = None
    min_history: int = 12
    allow_missing_target: bool = False
    allow_duplicates: bool = False


def normalize_config(
    *,
    date_col: str,
    target_col: str | list[str],
    group_cols: list[str] | None = None,
    expected_freq: str | None = None,
    min_history: int = 12,
    allow_missing_target: bool = False,
    allow_duplicates: bool = False,
) -> SanityCheckConfig:
    """Normalize public function inputs into a typed config object."""
    normalized_targets = validate_column_names(
        ensure_list(target_col),
        field_name="target_col",
    )
    normalized_groups = validate_column_names(group_cols or [], field_name="group_cols")
    return SanityCheckConfig(
        date_col=validate_column_name(date_col, field_name="date_col"),
        target_cols=normalized_targets,
        group_cols=normalized_groups,
        expected_freq=expected_freq,
        min_history=validate_min_history(min_history),
        allow_missing_target=allow_missing_target,
        allow_duplicates=allow_duplicates,
    )
