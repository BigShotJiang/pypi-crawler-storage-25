"""Result models for sanity checks."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class CheckResult:
    """Represents the outcome of a single check."""

    name: str
    status: str
    message: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SanityReport:
    """Structured report returned by the sanity-check API."""

    overall_status: str
    dataset_shape: tuple[int, int]
    date_col: str
    target_cols: list[str]
    group_cols: list[str]
    expected_freq: str | None
    min_history: int
    check_results: list[CheckResult] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Return a dictionary representation of the report."""
        return asdict(self)
