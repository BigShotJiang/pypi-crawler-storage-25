"""Load lightweight real datasets from secure open sources."""

from __future__ import annotations

from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen
from zipfile import ZipFile

import pandas as pd


TOURISM_MONTHLY_URL = (
    "https://zenodo.org/records/4656096/files/tourism_monthly_dataset.zip?download=1"
)
TOURISM_MONTHLY_ARCHIVE_NAME = "tourism_monthly_dataset.zip"
TOURISM_MONTHLY_TSF_NAME = "tourism_monthly_dataset.tsf"


def get_default_cache_dir() -> Path:
    """Return the default on-disk cache location for downloaded datasets."""
    return Path.home() / ".tstools" / "datasets"


def _resolve_cache_dir(cache_dir: str | Path | None) -> Path:
    resolved = Path(cache_dir) if cache_dir is not None else get_default_cache_dir()
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def _download_file(url: str, destination: Path) -> None:
    """Download a remote file to a local cache path."""
    try:
        with urlopen(url) as response:
            data = response.read()
    except URLError as exc:
        raise RuntimeError(f"Failed to download dataset from {url}") from exc
    destination.write_bytes(data)


def _extract_tsf_text(archive_path: Path, tsf_name: str) -> str:
    """Read the TSF dataset file from a cached zip archive."""
    try:
        with ZipFile(archive_path) as archive:
            with archive.open(tsf_name) as dataset_file:
                raw_bytes = dataset_file.read()
                for encoding in ("utf-8", "cp1252", "latin-1"):
                    try:
                        return raw_bytes.decode(encoding)
                    except UnicodeDecodeError:
                        continue
                raise UnicodeDecodeError(
                    "utf-8",
                    raw_bytes,
                    0,
                    1,
                    "Unable to decode TSF dataset with supported encodings.",
                )
    except Exception as exc:  # pragma: no cover - defensive error wrapping
        raise RuntimeError(
            f"Failed to read '{tsf_name}' from cached dataset archive '{archive_path}'."
        ) from exc


def _parse_tsf_to_long_df(tsf_text: str) -> pd.DataFrame:
    """Parse a minimal TSF file into a long-form dataframe."""
    in_data = False
    rows: list[dict[str, object]] = []

    for raw_line in tsf_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if not in_data:
            if line.lower() == "@data":
                in_data = True
            continue

        parts = line.split(":", maxsplit=2)
        if len(parts) != 3:
            raise RuntimeError("Malformed TSF data row encountered while parsing dataset.")

        series_id, start_timestamp, raw_values = parts
        values = [float(value) for value in raw_values.split(",") if value]
        start_date = pd.Timestamp(start_timestamp.split()[0])
        date_index = pd.date_range(start=start_date, periods=len(values), freq="MS")

        rows.extend(
            {
                "series_id": series_id,
                "date": date,
                "target": value,
            }
            for date, value in zip(date_index, values, strict=True)
        )

    if not rows:
        raise RuntimeError("Parsed real dataset is empty.")

    return pd.DataFrame(rows)


def load_tourism_monthly_sample(
    *,
    refresh: bool = False,
    cache_dir: str | Path | None = None,
) -> pd.DataFrame:
    """Load the Monash Tourism Monthly dataset as a normalized long dataframe."""
    archive_dir = _resolve_cache_dir(cache_dir)
    archive_path = archive_dir / TOURISM_MONTHLY_ARCHIVE_NAME

    if refresh or not archive_path.exists():
        _download_file(TOURISM_MONTHLY_URL, archive_path)

    tsf_text = _extract_tsf_text(archive_path, TOURISM_MONTHLY_TSF_NAME)
    return _parse_tsf_to_long_df(tsf_text)
