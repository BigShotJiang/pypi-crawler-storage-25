"""Public API for built-in sample datasets."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from tstools.datasets.generators import (
    generate_daily_series_clean,
    generate_panel_clean,
    generate_panel_with_issues,
)
from tstools.datasets.real import load_tourism_monthly_sample


_DATASET_GENERATORS = {
    "daily_series_clean": generate_daily_series_clean,
    "panel_clean": generate_panel_clean,
    "panel_with_issues": generate_panel_with_issues,
}
_REAL_DATASET_LOADERS = {
    "tourism_monthly": load_tourism_monthly_sample,
}


def list_sample_data() -> list[str]:
    """Return the supported built-in dataset names."""
    return sorted([*_DATASET_GENERATORS, *_REAL_DATASET_LOADERS])


def load_sample_data(
    name: str,
    *,
    refresh: bool = False,
    cache_dir: str | Path | None = None,
) -> pd.DataFrame:
    """Load a built-in or cached real sample dataset by name."""
    if name in _DATASET_GENERATORS:
        return _DATASET_GENERATORS[name]().copy()
    if name in _REAL_DATASET_LOADERS:
        return _REAL_DATASET_LOADERS[name](refresh=refresh, cache_dir=cache_dir).copy()

    if name not in _DATASET_GENERATORS and name not in _REAL_DATASET_LOADERS:
        allowed = ", ".join(list_sample_data())
        raise ValueError(f"Unknown sample dataset '{name}'. Allowed names: {allowed}")
    raise AssertionError("Unreachable dataset loader branch.")
