"""Dataset public exports."""

from tstools.datasets.api import load_sample_data

__all__ = ["load_sample_data"]
