"""Programmatic sample dataset generators."""

from __future__ import annotations

import pandas as pd


def generate_daily_series_clean() -> pd.DataFrame:
    """Return a clean single-series daily dataset."""
    dates = pd.date_range("2024-01-01", periods=30, freq="D")
    return pd.DataFrame({"date": dates, "sales": [100 + index for index in range(30)]})


def generate_panel_clean() -> pd.DataFrame:
    """Return a clean multi-series daily dataset."""
    rows: list[dict[str, object]] = []
    for offset, dfu in enumerate(["DFU_A", "DFU_B", "DFU_C"], start=1):
        dates = pd.date_range("2024-01-01", periods=30, freq="D")
        for index, date in enumerate(dates):
            rows.append({"dfu": dfu, "date": date, "sales": 50 * offset + index})
    return pd.DataFrame(rows)


def generate_panel_with_issues() -> pd.DataFrame:
    """Return a deterministic panel dataset with representative issues."""
    rows: list[dict[str, object]] = []
    base_dates = pd.date_range("2024-01-01", periods=10, freq="D")
    extended_dates = pd.date_range("2024-01-01", periods=12, freq="D")

    for index, date in enumerate(base_dates):
        rows.append({"dfu": "DFU_01", "date": date, "sales": 100 + index})

    missing_dates = [
        date for date in extended_dates if date not in {extended_dates[3], extended_dates[7]}
    ]
    for index, date in enumerate(missing_dates):
        rows.append({"dfu": "DFU_02", "date": date, "sales": 120 + index})

    for index, date in enumerate(base_dates):
        rows.append({"dfu": "DFU_03", "date": date, "sales": 140 + index})
    rows.append({"dfu": "DFU_03", "date": base_dates[4], "sales": 999})

    for index, date in enumerate(base_dates):
        value = None if index == 5 else 160 + index
        rows.append({"dfu": "DFU_04", "date": date, "sales": value})

    for date in base_dates:
        rows.append({"dfu": "DFU_05", "date": date, "sales": 77})

    for date in base_dates:
        rows.append({"dfu": "DFU_06", "date": date, "sales": 0})

    for index, date in enumerate(pd.date_range("2024-01-01", periods=5, freq="D")):
        rows.append({"dfu": "DFU_07", "date": date, "sales": 200 + index})

    return pd.DataFrame(rows)
