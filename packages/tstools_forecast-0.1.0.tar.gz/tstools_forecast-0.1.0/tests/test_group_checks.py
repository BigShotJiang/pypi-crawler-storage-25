from tstools.datasets.api import load_sample_data
from tstools.sanity.checks.groups import run_group_checks
from tstools.sanity.config import normalize_config


def test_short_history_groups_warn() -> None:
    df = load_sample_data("panel_with_issues")
    config = normalize_config(
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        min_history=10,
    )
    results, summary = run_group_checks(df, config)
    assert any(result.status == "WARN" and "Short-history groups" in result.message for result in results)
    assert summary["short_history_groups"] == ["DFU_07"]


def test_group_summary_values_populated() -> None:
    df = load_sample_data("panel_clean")
    config = normalize_config(
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        min_history=10,
    )
    _, summary = run_group_checks(df, config)
    assert summary["group_count"] == 3
    assert summary["history_length_min"] == 30
    assert summary["history_length_median"] == 30
    assert summary["history_length_max"] == 30
