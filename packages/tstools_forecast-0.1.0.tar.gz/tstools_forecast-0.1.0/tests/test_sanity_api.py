from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

from tstools import load_sample_data, sanity_checks
from tstools.datasets import real


def _fake_tourism_download(url: str, destination) -> None:
    tsf_text = "\n".join(
        [
            "# fake tourism dataset",
            "@relation Tourism",
            "@attribute series_name string",
            "@attribute start_timestamp date",
            "@frequency monthly",
            "@horizon 24",
            "@missing false",
            "@equallength false",
            "@data",
            "T1:2020-01-01 00-00-00:1.0,2.0,3.0,4.0",
            "T2:2020-01-01 00-00-00:10.0,11.0,12.0,13.0",
        ]
    )
    buffer = BytesIO()
    with ZipFile(buffer, "w") as archive:
        archive.writestr(real.TOURISM_MONTHLY_TSF_NAME, tsf_text)
    destination.write_bytes(buffer.getvalue())


def test_root_import_and_clean_grouped_dataset_ready() -> None:
    df = load_sample_data("panel_clean")
    report = sanity_checks(
        df,
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        expected_freq="D",
        print_report=False,
    )
    assert report is not None
    assert report.overall_status == "READY"


def test_clean_ungrouped_dataset_ready() -> None:
    df = load_sample_data("daily_series_clean")
    report = sanity_checks(
        df,
        date_col="date",
        target_col="sales",
        expected_freq="D",
        print_report=False,
    )
    assert report is not None
    assert report.overall_status == "READY"


def test_issue_dataset_not_ready_by_default() -> None:
    df = load_sample_data("panel_with_issues")
    report = sanity_checks(
        df,
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        expected_freq="D",
        print_report=False,
    )
    assert report is not None
    assert report.overall_status == "NOT_READY"


def test_issue_dataset_ready_with_warnings_when_duplicates_and_missing_allowed() -> None:
    df = load_sample_data("panel_with_issues")
    report = sanity_checks(
        df,
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        expected_freq="D",
        allow_duplicates=True,
        allow_missing_target=True,
        print_report=False,
    )
    assert report is not None
    assert report.overall_status == "READY_WITH_WARNINGS"


def test_return_report_false_returns_none() -> None:
    df = load_sample_data("daily_series_clean")
    result = sanity_checks(
        df,
        date_col="date",
        target_col="sales",
        print_report=False,
        return_report=False,
    )
    assert result is None


def test_real_tourism_sample_runs_through_sanity_checks(monkeypatch) -> None:
    monkeypatch.setattr(real, "_download_file", _fake_tourism_download)
    cache_dir = Path(".tmp") / "tourism_cache_api"
    cache_dir.mkdir(parents=True, exist_ok=True)
    df = load_sample_data("tourism_monthly", cache_dir=cache_dir, refresh=True)
    report = sanity_checks(
        df,
        date_col="date",
        target_col="target",
        group_cols=["series_id"],
        expected_freq="MS",
        min_history=3,
        print_report=False,
    )
    assert report is not None
    assert report.dataset_shape == df.shape
