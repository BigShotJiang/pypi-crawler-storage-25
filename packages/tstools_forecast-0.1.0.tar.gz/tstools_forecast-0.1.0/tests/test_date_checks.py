import pandas as pd

from tstools.datasets.api import load_sample_data
from tstools.sanity.checks.dates import run_date_checks
from tstools.sanity.config import normalize_config


def test_valid_dates_pass() -> None:
    df = load_sample_data("daily_series_clean")
    config = normalize_config(date_col="date", target_col="sales", expected_freq="D")
    _, results, _ = run_date_checks(df, config)
    assert results[0].status == "PASS"


def test_invalid_dates_fail() -> None:
    df = pd.DataFrame({"date": ["2024-01-01", "bad-date"], "sales": [1, 2]})
    config = normalize_config(date_col="date", target_col="sales")
    _, results, summary = run_date_checks(df, config)
    assert results[0].status == "FAIL"
    assert summary["invalid_date_rows"] == 1


def test_missing_date_detection_works() -> None:
    df = load_sample_data("panel_with_issues")
    config = normalize_config(
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        expected_freq="D",
    )
    _, results, summary = run_date_checks(df, config)
    assert any(result.status == "WARN" and "Missing dates" in result.message for result in results)
    assert summary["missing_dates_by_group"]["DFU_02"] == 2


def test_expected_frequency_mismatch_warns() -> None:
    df = pd.DataFrame(
        {
            "dfu": ["A", "A", "A", "A"],
            "date": pd.date_range("2024-01-01", periods=4, freq="W"),
            "sales": [1, 2, 3, 4],
        }
    )
    config = normalize_config(
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        expected_freq="D",
    )
    _, results, _ = run_date_checks(df, config)
    assert any("mismatches expected frequency" in result.message for result in results)


def test_unknown_frequency_warns_without_failing() -> None:
    df = pd.DataFrame(
        {
            "dfu": ["A", "A", "A"],
            "date": pd.to_datetime(["2024-01-01", "2024-01-04", "2024-01-10"]),
            "sales": [1, 2, 3],
        }
    )
    config = normalize_config(date_col="date", target_col="sales", group_cols=["dfu"])
    _, results, _ = run_date_checks(df, config)
    assert any(result.status == "WARN" and "unclear" in result.message for result in results)
    assert results[0].status != "FAIL"
