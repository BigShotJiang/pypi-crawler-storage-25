from tstools.datasets.api import load_sample_data
from tstools.sanity.checks.duplicates import run_duplicate_checks
from tstools.sanity.config import normalize_config


def test_duplicates_fail_by_default() -> None:
    df = load_sample_data("panel_with_issues")
    config = normalize_config(date_col="date", target_col="sales", group_cols=["dfu"])
    results, summary = run_duplicate_checks(df, config)
    assert results[0].status == "FAIL"
    assert summary["duplicate_groups"] == ["DFU_03"]


def test_duplicates_warn_when_allowed() -> None:
    df = load_sample_data("panel_with_issues")
    config = normalize_config(
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        allow_duplicates=True,
    )
    results, _ = run_duplicate_checks(df, config)
    assert results[0].status == "WARN"
