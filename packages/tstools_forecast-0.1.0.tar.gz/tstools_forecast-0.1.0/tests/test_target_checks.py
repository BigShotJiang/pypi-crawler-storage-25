import pandas as pd

from tstools.datasets.api import load_sample_data
from tstools.sanity.checks.targets import run_target_checks
from tstools.sanity.config import normalize_config


def test_non_numeric_targets_fail() -> None:
    df = pd.DataFrame({"date": pd.date_range("2024-01-01", periods=2), "sales": ["1", "bad"]})
    config = normalize_config(date_col="date", target_col="sales")
    results, _ = run_target_checks(df, config)
    assert results[0].status == "FAIL"


def test_missing_targets_warn_by_default() -> None:
    df = load_sample_data("panel_with_issues")
    config = normalize_config(date_col="date", target_col="sales", group_cols=["dfu"])
    results, summary = run_target_checks(df, config)
    assert any(result.status == "WARN" and "Missing target values" in result.message for result in results)
    assert summary["missing_target_rows"]["sales"] == 1


def test_missing_targets_info_when_allowed() -> None:
    df = load_sample_data("panel_with_issues")
    config = normalize_config(
        date_col="date",
        target_col="sales",
        group_cols=["dfu"],
        allow_missing_target=True,
    )
    results, _ = run_target_checks(df, config)
    assert any(result.status == "INFO" and "Missing target values" in result.message for result in results)


def test_constant_series_warn() -> None:
    df = load_sample_data("panel_with_issues")
    config = normalize_config(date_col="date", target_col="sales", group_cols=["dfu"])
    results, summary = run_target_checks(df, config)
    assert any("Constant series" in result.message for result in results)
    assert "DFU_05" in summary["constant_groups"]["sales"]


def test_all_zero_series_warn() -> None:
    df = load_sample_data("panel_with_issues")
    config = normalize_config(date_col="date", target_col="sales", group_cols=["dfu"])
    results, summary = run_target_checks(df, config)
    assert any("All-zero series" in result.message for result in results)
    assert "DFU_06" in summary["all_zero_groups"]["sales"]
