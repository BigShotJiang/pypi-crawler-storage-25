from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

import pandas as pd

from tstools.datasets.api import list_sample_data, load_sample_data
from tstools.datasets import real


def _build_fake_tourism_archive() -> bytes:
    tsf_text = "\n".join(
        [
            "# fake tourism dataset",
            "@relation Tourism",
            "@attribute series_name string",
            "@attribute start_timestamp date",
            "@frequency monthly",
            "@horizon 24",
            "@missing false",
            "@equallength false",
            "@data",
            "T1:2020-01-01 00-00-00:1.0,2.0,3.0",
            "T2:2020-02-01 00-00-00:4.0,5.0",
        ]
    )
    buffer = BytesIO()
    with ZipFile(buffer, "w") as archive:
        archive.writestr(real.TOURISM_MONTHLY_TSF_NAME, tsf_text)
    return buffer.getvalue()


def test_each_generated_dataset_loads_successfully() -> None:
    for name in ["daily_series_clean", "panel_clean", "panel_with_issues"]:
        df = load_sample_data(name)
        assert not df.empty


def test_expected_columns_exist() -> None:
    assert list(load_sample_data("daily_series_clean").columns) == ["date", "sales"]
    assert list(load_sample_data("panel_clean").columns) == ["dfu", "date", "sales"]
    assert list(load_sample_data("panel_with_issues").columns) == ["dfu", "date", "sales"]


def test_tourism_monthly_loads_from_cached_download(monkeypatch) -> None:
    fake_archive = _build_fake_tourism_archive()

    def fake_download(url: str, destination) -> None:
        destination.write_bytes(fake_archive)

    monkeypatch.setattr(real, "_download_file", fake_download)
    cache_dir = Path(".tmp") / "tourism_cache_success"
    cache_dir.mkdir(parents=True, exist_ok=True)
    df = load_sample_data("tourism_monthly", cache_dir=cache_dir, refresh=True)
    assert not df.empty
    assert list(df.columns) == ["series_id", "date", "target"]
    assert pd.api.types.is_datetime64_any_dtype(df["date"])
    assert df["series_id"].nunique() == 2


def test_tourism_monthly_download_failure_raises_helpful_error(monkeypatch) -> None:
    def fake_download(url: str, destination) -> None:
        raise RuntimeError("download failed")

    monkeypatch.setattr(real, "_download_file", fake_download)
    cache_dir = Path(".tmp") / "tourism_cache_failure"
    cache_dir.mkdir(parents=True, exist_ok=True)
    try:
        load_sample_data("tourism_monthly", cache_dir=cache_dir, refresh=True)
    except RuntimeError as exc:
        assert "download failed" in str(exc)
    else:
        raise AssertionError("Expected runtime error for failed real dataset download.")


def test_tourism_monthly_tsf_decode_fallback_supports_cp1252() -> None:
    tsf_text = (
        "# fake tourism dataset with cp1252 dash – note\n"
        "@relation Tourism\n"
        "@attribute series_name string\n"
        "@attribute start_timestamp date\n"
        "@frequency monthly\n"
        "@horizon 24\n"
        "@missing false\n"
        "@equallength false\n"
        "@data\n"
        "T1:2020-01-01 00-00-00:1.0,2.0,3.0\n"
    ).encode("cp1252")
    archive_path = Path(".tmp") / "tourism_decode_test.zip"
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(archive_path, "w") as archive:
        archive.writestr(real.TOURISM_MONTHLY_TSF_NAME, tsf_text)

    extracted = real._extract_tsf_text(archive_path, real.TOURISM_MONTHLY_TSF_NAME)

    assert "dash" in extracted
    assert "T1:2020-01-01 00-00-00:1.0,2.0,3.0" in extracted


def test_invalid_dataset_name_raises_value_error() -> None:
    try:
        load_sample_data("nope")
    except ValueError as exc:
        assert "Allowed names" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid dataset name.")


def test_list_sample_data_is_deterministic() -> None:
    assert list_sample_data() == [
        "daily_series_clean",
        "panel_clean",
        "panel_with_issues",
        "tourism_monthly",
    ]
