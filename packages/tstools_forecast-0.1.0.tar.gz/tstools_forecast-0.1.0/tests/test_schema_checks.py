import pandas as pd
import pytest

from tstools.sanity.checks.schema import run_schema_checks
from tstools.sanity.config import normalize_config


def test_missing_columns_raise_value_error() -> None:
    df = pd.DataFrame({"date": ["2024-01-01"]})
    config = normalize_config(date_col="date", target_col="sales")
    with pytest.raises(ValueError, match="sales"):
        run_schema_checks(df, config)


def test_bad_df_type_raises_type_error() -> None:
    config = normalize_config(date_col="date", target_col="sales")
    with pytest.raises(TypeError):
        run_schema_checks([], config)
