"""
Zado MCP Tools — budget tools for AI agents via HTTP bridge.

Meta:
    purpose: Expose envelope budgets to AI agents via MCP protocol
    when_to_use: Registered by server.py on startup
    domain: agent-trust
    business_rules:
        - All tools delegate to zadofi.ai REST API via ZadoAPIClient
        - All auth, spending guards, and audit enforced server-side
        - No direct database access — MCP is a pure transport layer
        - Response shapes preserved for backward compatibility
"""

from datetime import datetime, timezone

from mcp.server.fastmcp import FastMCP

from zado_mcp.client import ZadoAPIClient, ZadoAPIError


def register_tools(mcp: FastMCP):
    """Register all Zado MCP tools."""

    @mcp.tool()
    async def check_budget(category: str) -> dict:
        """
        Check how much is left in an envelope for a spending category.

        Args:
            category: The category slug (e.g., "groceries", "dining", "fun-money")

        Returns:
            Envelope name, budgeted amount, spent amount, and remaining balance.
        """
        try:
            async with ZadoAPIClient() as client:
                data = await client.check_budget(category)
        except ZadoAPIError as e:
            return {"error": e.detail}

        envelope = data.get("envelope") or {}
        return {
            "category": data.get("category", {}).get("name", category),
            "remaining": envelope.get("available", 0),
            "budgeted": envelope.get("budgeted", 0),
            "spent": envelope.get("spent", 0),
            "percentage_used": envelope.get("percentage_used", 0),
        }

    @mcp.tool()
    async def get_daily_status() -> dict:
        """
        Get today's spending status across all envelopes.

        Returns:
            Total available, daily allowance, and any critical alerts.
            Does NOT return bank account details, account numbers, or transaction history.
        """
        try:
            async with ZadoAPIClient() as client:
                data = await client.get_daily_status()
        except ZadoAPIError as e:
            return {"error": e.detail}

        return {
            "total_available": data.get("total_available", 0),
            "daily_allowance": data.get("daily_allowance", 0),
            "days_remaining": data.get("days_remaining", 0),
            "alerts": [
                {
                    "category": a.get("category", ""),
                    "type": a.get("alert_type", ""),
                    "message": a.get("message", ""),
                }
                for a in data.get("alerts", [])
            ],
        }

    @mcp.tool()
    async def authorize_purchase(amount: float, category: str, vendor: str) -> dict:
        """
        Authorize and log a purchase if the envelope has enough funds.

        This is the core "envelopes as permissions" pattern:
        the envelope balance IS the spending limit.

        Requires agent scope="spend". Enforces per-transaction cap,
        session spending cap, and rate limits before checking the envelope.

        Args:
            amount: Purchase amount in dollars (e.g., 43.50)
            category: Category slug (e.g., "groceries", "dining")
            vendor: Vendor/merchant name (e.g., "Whole Foods")

        Returns:
            authorized=True with transaction_id and remaining balance, or
            authorized=False with reason for rejection.
        """
        try:
            async with ZadoAPIClient() as client:
                return await client.authorize_purchase(amount, category, vendor)
        except ZadoAPIError as e:
            return {"authorized": False, "reason": "api_error", "detail": e.detail}

    @mcp.tool()
    async def check_pending_authorization(pending_id: str) -> dict:
        """
        Check the status of a parked agent purchase request.

        When authorize_purchase returns reason="pending_human_approval",
        poll this tool with the pending_id to learn whether the user
        approved, denied, or let the request expire.

        Args:
            pending_id: UUID returned by authorize_purchase.

        Returns:
            {pending_id, status: pending|approved|denied|expired|completed,
             amount, category, vendor, requested_at, expires_at, resolved_at,
             resolution_note}, or {status: "not_found"} if the pending
            id does not exist or does not belong to this agent's user.
        """
        try:
            async with ZadoAPIClient() as client:
                return await client.check_pending_authorization(pending_id)
        except ZadoAPIError as e:
            if e.status_code == 404:
                return {"status": "not_found"}
            return {"error": e.detail}

    @mcp.tool()
    async def complete_pending_authorization(pending_id: str) -> dict:
        """
        Claim a user-approved pending authorization to debit the envelope.

        After authorize_purchase returns reason="pending_human_approval"
        and check_pending_authorization shows status="approved", call
        this tool to redeem the approval. The envelope debit and
        Transaction record happen atomically; until you claim, no money
        moves in Zado's view of the budget.

        Idempotent: re-calling on the same pending_id after a successful
        completion returns the cached response (same transaction_id, no
        second debit, no second activity event).

        After this tool returns authorized=True, proceed with the actual
        purchase via your own rail (Stripe, card, etc.). Bank sync will
        reconcile the real transaction against this Zado record later.

        Args:
            pending_id: UUID of the approved pending authorization.

        Returns:
            On success (200): {authorized: true, transaction_id, amount,
                category, vendor, envelope_remaining, pending_id}.
            On 404 (cross-tenant, cross-agent, or unknown):
                {status: "not_found"}.
            On 409 (status not 'approved'):
                {status: "invalid_state", current_status: "<x>"}.
            On 410 (expired or agent_token_missing):
                {status: "expired", reason: "<reason>"}.
            On other errors: {error: "<detail>"}.
        """
        try:
            async with ZadoAPIClient() as client:
                return await client.complete_pending_authorization(pending_id)
        except ZadoAPIError as e:
            if e.status_code == 404:
                return {"status": "not_found"}
            if e.status_code == 409:
                # Service surfaces {reason, current_status, message} via
                # FastAPI's `detail` envelope. Detail may be a dict (preferred)
                # or a string (when other layers raise). Tolerate both so the
                # agent always sees a usable shape.
                detail = e.detail if isinstance(e.detail, dict) else {}
                return {
                    "status": "invalid_state",
                    "current_status": detail.get("current_status"),
                    "reason": detail.get("reason", "pending_status_invalid"),
                    "message": detail.get("message", str(e.detail)),
                }
            if e.status_code == 410:
                detail = e.detail if isinstance(e.detail, dict) else {}
                return {
                    "status": "expired",
                    "reason": detail.get("reason", "expired"),
                    "message": detail.get("message", str(e.detail)),
                }
            return {"error": e.detail}

    @mcp.tool()
    async def list_envelopes() -> dict:
        """
        List all envelope balances for the current month.

        Returns:
            List of envelopes with name, budgeted, spent, and remaining amounts.
            Does NOT return bank tokens, account numbers, or transaction details.
        """
        month = datetime.now(timezone.utc).strftime("%Y-%m")

        try:
            async with ZadoAPIClient() as client:
                data = await client.list_envelopes(month)
        except ZadoAPIError as e:
            return {"error": e.detail}

        return {
            "month": data.get("month", month),
            "total_budgeted": data.get("total_budgeted", 0),
            "total_spent": data.get("total_spent", 0),
            "total_available": data.get("total_available", 0),
            "envelopes": [
                {
                    "name": e.get("category_name", ""),
                    "budgeted": e.get("budgeted_amount", 0),
                    "spent": e.get("spent_amount", 0),
                    "remaining": e.get("available", 0),
                    "percentage_used": e.get("percentage_used", 0),
                    "status": e.get("status", ""),
                }
                for e in data.get("envelopes", [])
            ],
        }
