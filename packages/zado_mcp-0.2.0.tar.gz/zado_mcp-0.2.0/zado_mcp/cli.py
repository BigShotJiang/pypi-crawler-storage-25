"""zado-mcp CLI — entry point for the `zado-mcp` console script.

Subcommands:
    init     interactive setup: writes ~/.config/zado-mcp/config.json + emits
             a .mcp.json snippet for Claude Code / Claude Desktop / etc.
    serve    runs the MCP server over stdio (default transport).
    version  prints the package version.
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from pathlib import Path

from . import __version__

CONFIG_DIR = Path.home() / ".config" / "zado-mcp"
CONFIG_PATH = CONFIG_DIR / "config.json"
DEFAULT_API_URL = "https://zadofi.ai"


def _cmd_version(_args: argparse.Namespace) -> int:
    print(f"zado-mcp {__version__}")
    return 0


def _cmd_serve(_args: argparse.Namespace) -> int:
    # Stdio transport reserves stdout for protocol JSON — startup banner goes to stderr.
    print(f"zado-mcp {__version__} — stdio transport ready", file=sys.stderr)

    from .server import mcp

    mcp.run(transport="stdio")
    return 0


def _cmd_init(_args: argparse.Namespace) -> int:
    print("zado-mcp setup\n")

    api_url = input(f"Zado instance URL [{DEFAULT_API_URL}]: ").strip() or DEFAULT_API_URL
    api_url = api_url.rstrip("/")

    print(
        "\nAgent token (paste from Settings > Agent Access — input is hidden):"
    )
    agent_token = getpass.getpass("Token: ").strip()
    if not agent_token:
        print("Aborted: agent token is required.", file=sys.stderr)
        return 1

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    payload = {"api_url": api_url, "agent_token": agent_token}
    CONFIG_PATH.write_text(json.dumps(payload, indent=2) + "\n")
    os.chmod(CONFIG_PATH, 0o600)

    print(f"\n✓ Wrote {CONFIG_PATH} (mode 0600)\n")
    print("Paste the following into your agent's .mcp.json (Claude Code, Claude Desktop, etc.):\n")
    # Token deliberately NOT echoed — it lives in the 0600 config file above.
    # `zado-mcp serve` reads from that file when env vars are unset, so most
    # hosts need no env block at all.
    snippet = {
        "mcpServers": {
            "zado": {
                "command": "zado-mcp",
                "args": ["serve"],
            }
        }
    }
    print(json.dumps(snippet, indent=2))
    print(
        "\nThe server reads URL + token from the config file above. "
        "To override (e.g. point at a local backend), set ZADO_API_URL and "
        "ZADO_AGENT_TOKEN in the host's env block — env vars take precedence."
    )
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="zado-mcp",
        description="Zado MCP server — AI agent access to envelope budgets.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init", help="Interactive setup: configure agent token + emit .mcp.json snippet.")
    sub.add_parser("serve", help="Run the MCP server over stdio (default transport for Claude Code / Desktop).")
    sub.add_parser("version", help="Print the zado-mcp package version.")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    handlers = {
        "init": _cmd_init,
        "serve": _cmd_serve,
        "version": _cmd_version,
    }
    return handlers[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
