"""
Zado MCP HTTP Client — thin bridge to zadofi.ai REST API.

Meta:
    purpose: Translate MCP tool calls into HTTP requests to the Zado API
    when_to_use: Called by MCP tools instead of direct DB access
    domain: agent-trust
    business_rules:
        - All auth, spending guards, and audit enforced server-side
        - Config resolution order: explicit kwargs > env vars > config file
          (~/.config/zado-mcp/config.json, written by `zado-mcp init`)
        - Bearer token auth on every request
        - Raises on missing config (any source), HTTP errors, auth failures
"""

import json
import os
from pathlib import Path
from typing import Any

import httpx

CONFIG_PATH = Path.home() / ".config" / "zado-mcp" / "config.json"


def _read_config_file() -> dict:
    """Read api_url + agent_token from ~/.config/zado-mcp/config.json (if present)."""
    if not CONFIG_PATH.is_file():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text())
    except (OSError, ValueError):
        return {}


class ZadoAPIError(Exception):
    """Raised when the Zado API returns an error."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"Zado API error {status_code}: {detail}")


class ZadoAPIClient:
    """Async HTTP client for the Zado REST API."""

    def __init__(
        self,
        api_url: str | None = None,
        agent_token: str | None = None,
    ):
        config_file = _read_config_file()
        self.api_url = (
            api_url
            or os.environ.get("ZADO_API_URL", "")
            or config_file.get("api_url", "")
        ).rstrip("/")
        self.agent_token = (
            agent_token
            or os.environ.get("ZADO_AGENT_TOKEN", "")
            or config_file.get("agent_token", "")
        )

        if not self.api_url:
            raise ValueError(
                "Zado instance URL not configured. "
                "Run `zado-mcp init` or set ZADO_API_URL "
                "(e.g. https://zadofi.ai)."
            )
        if not self.agent_token:
            raise ValueError(
                "Zado agent token not configured. "
                "Run `zado-mcp init` or set ZADO_AGENT_TOKEN. "
                "Register an agent at Settings > Agent Access."
            )

        self._client = httpx.AsyncClient(
            base_url=self.api_url,
            headers={"Authorization": f"Bearer {self.agent_token}"},
            timeout=30.0,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "ZadoAPIClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        """Make an HTTP request and return parsed JSON."""
        resp = await self._client.request(method, path, **kwargs)
        if resp.status_code == 401:
            raise ZadoAPIError(401, "Invalid or revoked agent token")
        if resp.status_code == 403:
            raise ZadoAPIError(403, "Agent scope does not permit this operation")
        if resp.status_code >= 400:
            detail = resp.text
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                pass
            raise ZadoAPIError(resp.status_code, str(detail))
        return resp.json()

    async def list_envelopes(self, month: str) -> dict:
        """GET /api/envelopes/summary?month=YYYY-MM"""
        return await self._request("GET", "/api/envelopes/summary", params={"month": month})

    async def check_budget(self, category: str) -> dict:
        """GET /api/spending/category/{slug}"""
        return await self._request("GET", f"/api/spending/category/{category}")

    async def get_daily_status(self) -> dict:
        """GET /api/spending/status"""
        return await self._request("GET", "/api/spending/status")

    async def authorize_purchase(self, amount: float, category: str, vendor: str) -> dict:
        """POST /api/agents/purchase"""
        return await self._request(
            "POST",
            "/api/agents/purchase",
            json={"amount": amount, "category": category, "vendor": vendor},
        )

    async def check_pending_authorization(self, pending_id: str) -> dict:
        """GET /api/agents/pending-authorizations/{pending_id}"""
        return await self._request(
            "GET",
            f"/api/agents/pending-authorizations/{pending_id}",
        )

    async def complete_pending_authorization(self, pending_id: str) -> dict:
        """POST /api/agents/pending-authorizations/{pending_id}/complete

        Claims a user-approved pending authorization, debiting the envelope
        and recording the transaction. Idempotent — re-calling on a row in
        status=completed returns the same response without re-debiting.
        """
        return await self._request(
            "POST",
            f"/api/agents/pending-authorizations/{pending_id}/complete",
        )
