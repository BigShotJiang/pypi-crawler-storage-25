"""zado-mcp — AI agent access to Zado envelope budgets via the Model Context Protocol."""

__version__ = "0.2.0"
