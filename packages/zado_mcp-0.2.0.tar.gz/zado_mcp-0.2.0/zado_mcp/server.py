"""
Zado MCP Server — AI agent access to budget data via HTTP bridge.

Meta:
    purpose: Expose envelope budgets to AI agents via MCP protocol
    when_to_use: When an AI agent needs to check budgets or authorize purchases
    domain: agent-trust
    business_rules:
        - Tools delegate to zadofi.ai REST API (no direct DB access)
        - All auth, spending guards, and audit enforced server-side
        - No bank tokens, account numbers, or raw transaction data exposed
"""

from mcp.server.fastmcp import FastMCP

from zado_mcp.tools import register_tools

mcp = FastMCP(
    "Zado Budget",
    instructions=(
        "Zado is an ADHD-friendly personal finance app. "
        "Use these tools to check envelope budgets and authorize purchases. "
        "Envelopes are spending categories with allocated amounts — "
        "when an envelope is empty, spending in that category stops."
    ),
)

register_tools(mcp)


def main():
    """Run the MCP server via stdio transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
