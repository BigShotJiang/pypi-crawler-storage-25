from __future__ import annotations

import dataclasses
import uuid
from typing import ClassVar, NewType, TypedDict

from typing_extensions import override

from . import _viser_private as impl
from ._types import BlockManifestPayload, RuntimePayload

RuntimeSceneMessage = NewType("RuntimeSceneMessage", RuntimePayload)


def runtime_scene_message(message: RuntimePayload) -> RuntimeSceneMessage:
    return RuntimeSceneMessage(message)


def runtime_scene_messages(
    messages: list[RuntimePayload],
) -> list[RuntimeSceneMessage]:
    return [runtime_scene_message(message) for message in messages]


class RuntimeSceneEntry(TypedDict):
    key: str
    message: RuntimeSceneMessage


class RuntimeStatePatch(TypedDict):
    scenePuts: list[RuntimeSceneEntry]
    sceneDeleteNodes: list[str]
    audioMessages: list[RuntimeSceneMessage]


class RuntimeStepPatchUpdate(TypedDict):
    stepOffset: int
    patch: RuntimeStatePatch


class _RuntimeMessageBase(impl.Message):
    _tags: ClassVar[tuple[str, ...]] = tuple()

    @override
    def redundancy_key(self) -> str:
        return str(uuid.uuid4())

    def __init_subclass__(cls, tag: str | None = None) -> None:
        super().__init_subclass__()
        if tag is not None:
            cls._tags = cls._tags + (tag,)


class _RuntimeControlMessage(_RuntimeMessageBase, tag="RuntimeControlMessage"):
    pass


class RuntimeEventMessage(_RuntimeMessageBase, tag="RuntimeEventMessage"):
    pass


@dataclasses.dataclass
class RuntimeClearMessage(_RuntimeControlMessage):
    pass


@dataclasses.dataclass
class RuntimeConfigureMessage(_RuntimeControlMessage):
    numSteps: int
    blockSize: int
    timelineFps: float
    speed: float
    loop: bool
    clientChunkCacheBytes: int
    blockManifests: list[BlockManifestPayload]
    timelineSliderUuid: str
    speedSliderUuid: str
    stepButtonsUuid: str
    playButtonUuid: str
    pauseButtonUuid: str


@dataclasses.dataclass
class RuntimeManifestsMessage(_RuntimeControlMessage):
    blockManifests: list[BlockManifestPayload]


@dataclasses.dataclass
class RuntimeLoadBlockMessage(_RuntimeControlMessage):
    block: int
    checkpointSceneEntries: list[RuntimeSceneEntry]
    checkpointAudioMessages: list[RuntimeSceneMessage]
    stepPatches: list[RuntimeStatePatch]


@dataclasses.dataclass
class RuntimeSeekMessage(_RuntimeControlMessage):
    step: int


@dataclasses.dataclass
class RuntimeRefreshMessage(_RuntimeControlMessage):
    pass


@dataclasses.dataclass
class RuntimePlayMessage(_RuntimeControlMessage):
    speed: float
    loop: bool


@dataclasses.dataclass
class RuntimePauseMessage(_RuntimeControlMessage):
    pass


@dataclasses.dataclass
class RuntimeSetSpeedMessage(_RuntimeControlMessage):
    speed: float
    loop: bool


@dataclasses.dataclass
class RuntimePatchBlockMessage(_RuntimeControlMessage):
    block: int
    checkpointScenePuts: list[RuntimeSceneEntry]
    checkpointSceneDeletes: list[str]
    checkpointAudioPuts: list[RuntimeSceneMessage]
    checkpointAudioDeletes: list[str]
    stepPatchUpdates: list[RuntimeStepPatchUpdate]


@dataclasses.dataclass
class RuntimeApplyMessageUpdateMessage(_RuntimeControlMessage):
    key: str
    message: RuntimeSceneMessage


@dataclasses.dataclass
class RuntimeBlockRequestMessage(RuntimeEventMessage):
    blockIndex: int


@dataclasses.dataclass
class RuntimeBlockDiscardMessage(RuntimeEventMessage):
    blockIndex: int


@dataclasses.dataclass
class RuntimeTimestepMessage(RuntimeEventMessage):
    step: int


@dataclasses.dataclass
class RuntimeSpeedMessage(RuntimeEventMessage):
    speed: float


@dataclasses.dataclass
class RuntimePlaybackStateMessage(RuntimeEventMessage):
    isPlaying: bool


@dataclasses.dataclass
class RuntimeReadyMessage(RuntimeEventMessage):
    pass


RUNTIME_EVENT_MESSAGE_TYPES = (
    RuntimeBlockRequestMessage,
    RuntimeBlockDiscardMessage,
    RuntimeTimestepMessage,
    RuntimeSpeedMessage,
    RuntimePlaybackStateMessage,
    RuntimeReadyMessage,
)
