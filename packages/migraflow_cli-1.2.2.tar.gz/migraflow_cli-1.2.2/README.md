# MigraFlow CLI

Ferramenta de linha de comando para análise de migração de schema de banco de dados com IA.

## Documentação

https://docs.wimeisoftwares.com

## Instalação

```
pip install migraflow-cli
```

## Uso

```
migraflow schema.sql "ERP Oracle 11g" --api-key mk_consultant_xxx
```

### Variável de ambiente (recomendado)

```
# Windows
set MIGRAFLOW_API_KEY=mk_consultant_xxx

# Linux/Mac
export MIGRAFLOW_API_KEY=mk_consultant_xxx

migraflow schema.sql "ERP Oracle 11g"
```

### Opções

```
migraflow --help

positional arguments:
  sql_file    Arquivo .sql com o schema legado
  context     Contexto de negocio (ex: 'ERP Oracle 11g')

options:
  --api-key   Consultant API key
  --target    Dialeto de destino: postgresql (default), mysql, sqlserver
  --output    Diretorio de saida (default: entrega_TIMESTAMP/)
  --version   Versão do CLI
```

## Artefatos gerados

Após a análise, uma pasta `entrega_TIMESTAMP/` é criada com:

- `migration.sql` — script SQL pronto para produção
- `rollback.sql` — script de rollback automático
- `risk_report.md` — relatório de riscos com score e findings
- `resultado_completo.json` — resultado completo da análise

## Suporte

contato@migraflow.com.br
