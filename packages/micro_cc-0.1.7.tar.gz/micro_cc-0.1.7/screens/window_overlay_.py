from textual.app import RenderableType
from textual.widget import Widget
from rich.text import Text
from rich.console import Group
from screens.md_render_ import render_md

BANNER = """\
[bold white]███╗   ███╗ ██████╗ ██████╗ ███████╗██╗[/]
[bold white]████╗ ████║██╔═══██╗██╔══██╗██╔════╝██║[/]
[bold white]██╔████╔██║██║   ██║██║  ██║█████╗  ██║[/]
[dim]██║╚██╔╝██║██║   ██║██║  ██║██╔══╝  ██║[/]
[dim]██║ ╚═╝ ██║╚██████╔╝██████╔╝███████╗███████╗[/]
[dim]╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝[/]
[dim]───────[/] [bold]on the metal[/] [dim]─────────────────────[/]
[dim italic]Knowledge work is by extension a coding problem.[/]

[white]enter[/] [dim]submit[/] [dim]·[/] [white]esc[/] [dim]interrupt[/] [dim]·[/] [white]/model[/] [dim]switch[/] [dim]·[/] [white]/clear[/] [dim]reset[/] [dim]·[/] [white]/exit[/] [dim]quit[/]
"""

class MessageList(Widget):
    """Reads app.messages, renders everything"""

    def render(self) -> RenderableType:
        """Called by Textual whenever refresh() is triggered"""
        parts = []
        for msg in self.app.messages:
            if msg["type"] == "user":
                parts.append(Text(f"› {msg['content']}", style="bold"))
            elif msg["type"] == "text":
                parts.append(render_md(msg["content"]))
            elif msg["type"] == "thinking":
                parts.append(Text("∴ Thinking", style="dim italic"))
                parts.append(render_md(msg["content"], dim=True))
            elif msg["type"] == "tool_call":
                if msg["result"] is None:
                    parts.append(Text(f"🔧 {msg['name']} ⋯", style="yellow"))
                else:
                    parts.append(Text(f"✓ {msg['name']}", style="green"))
                    parts.append(Text(f"  {msg['result']}", style="dim"))
            elif msg["type"] == "error":
                parts.append(Text(f"⚠️ {msg['content']}", style="red"))
            elif msg["type"] == "approval":
                parts.append(Text(f"⚠️ {msg['name']}  [y/N]", style="bold yellow"))
                parts.append(Text(f"  {msg['input']}", style="dim"))
        return Group(*parts) if parts else Text("")
