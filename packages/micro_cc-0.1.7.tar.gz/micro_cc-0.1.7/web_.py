import asyncio
import json
import os
import shutil
import uuid

from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from utils.msg_store_ import (
    load_msgs,
    summarize_and_trim,
    store_msgs,
    erase_msgs,
    erase_summary,
)


from claude_loop_ import claude_loop
from utils.file_watcher_ import FileWatcher
from cache.redis_cache import RedisStateManager

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

watchers = {}   # project_dir → FileWatcher
pending = {}    # project_dir → {"generator": async_gen, "approval": dict, "state": dict}


# ─── Session + Upload ─────────────────────────────────────────────

@app.post("/session")
async def create_session(request: Request):
    """Initialize a project session — starts file watcher."""
    data = await request.json()
    project_dir = data.get("project_dir", "")
    if not project_dir:
        return {"status": "error", "message": "project_dir required"}

    os.makedirs(project_dir, exist_ok=True)
    if project_dir not in watchers:
        w = FileWatcher(project_dir)
        w.start()
        watchers[project_dir] = w
    return {"status": "ok", "project_dir": project_dir}


@app.post("/upload")
async def upload_files(
    project_dir: str = Form(...),
    files: list[UploadFile] = File(...),
):
    """Upload files into the project directory."""
    uploaded = []
    for f in files:
        dest = os.path.join(project_dir, f.filename)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as out:
            shutil.copyfileobj(f.file, out)
        uploaded.append(f.filename)
    return {"uploaded": uploaded}


# ─── SSE Chat (Vercel AI SDK v5 — UI Message Stream Protocol) ─────
#
# Format: data: {json}\n\n   (standard SSE)
# Header: x-vercel-ai-ui-message-stream: v1
#
# Chunk types:
#   start              → {type:"start", messageId}
#   start-step         → {type:"start-step"}
#   reasoning-start    → {type:"reasoning-start", id}
#   reasoning-delta    → {type:"reasoning-delta", id, delta}
#   reasoning-end      → {type:"reasoning-end", id}
#   text-start         → {type:"text-start", id}
#   text-delta         → {type:"text-delta", id, delta}
#   text-end           → {type:"text-end", id}
#   tool-input-available  → {type:"tool-input-available", toolCallId, toolName, input, dynamic:true}
#   tool-approval-request → {type:"tool-approval-request", approvalId, toolCallId}
#   tool-output-available → {type:"tool-output-available", toolCallId, output}
#   tool-output-denied    → {type:"tool-output-denied", toolCallId}
#   source              -> {type: 'source-url', sourceId, url, title }
#   source-doc          ->   {type: 'source-document', sourceId, mediaType, title, filename }
#   data                ->  {type: 'data-{name}, id, data }
#   finish-step        → {type:"finish-step"}
#   finish             → {type:"finish", finishReason}
#   abort              → {type:"abort", reason?}
#   [DONE]             → signals stream end
#

SSE_HEADERS = {
    "x-vercel-ai-ui-message-stream": "v1",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}


def sse(chunk: dict) -> str:
    """Format a chunk as an SSE data line."""
    return f"data: {json.dumps(chunk)}\n\n"


async def sse_claude_loop(query, project_dir, watcher, resume=False):
    """Async generator: consumes claude_loop events, yields Vercel AI SDK v5 SSE lines.

    When resume=True, picks up a paused generator from pending[] instead of
    starting a new claude_loop. The approval dict is resolved before resuming.
    """

    redis_state = RedisStateManager()

    # ── Resume existing paused generator ──
    if resume and project_dir in pending:
        p = pending.pop(project_dir)
        _loop_msgs = p["loop_msgs"]  # restore the live reference, don't reload from disk
        gen = p["generator"]
        p["approval"]["approved"] = True
        # We emitted finish-step + finish before [DONE], so start clean
        in_thinking = False
        in_text = False
        step_open = False
        thinking_id = None
        text_id = None
        msg_id = p["state"]["msg_id"]
    else:
        # ── Fresh generator ──
        _loop_msgs = load_msgs(project_dir)
        gen = claude_loop(
            query=query,
            msgs=_loop_msgs,
            project_dir=project_dir,
            watcher=watcher,
        )
        in_thinking = False
        in_text = False
        step_open = False
        thinking_id = None
        text_id = None
        msg_id = f"msg-{uuid.uuid4().hex[:12]}"

    # ── State tracking helpers ──
    def close_thinking():
        nonlocal in_thinking
        if in_thinking:
            tid = thinking_id
            in_thinking = False
            return sse({"type": "reasoning-end", "id": tid})
        return None

    def close_text():
        nonlocal in_text
        if in_text:
            tid = text_id
            in_text = False
            return sse({"type": "text-end", "id": tid})
        return None

    def open_step():
        nonlocal step_open
        if not step_open:
            step_open = True
            return sse({"type": "start-step"})
        return None

    def close_step():
        nonlocal step_open
        if step_open:
            step_open = False
            return sse({"type": "finish-step"})
        return None

    # ── Message start (only for fresh streams, not resume) ──
    if not resume:
        yield sse({"type": "start", "messageId": msg_id})

    async for event in gen:
        # ── Check if frontend requested stop ──
        if not redis_state.get_streaming_state(project_dir):
            line = close_thinking()
            if line:
                yield line
            line = close_text()
            if line:
                yield line
            line = close_step()
            if line:
                yield line
            yield sse({"type": "finish", "finishReason": "stop"})
            yield "data: [DONE]\n\n"
            store_msgs(project_dir, _loop_msgs)
            return

        etype = event.get("type")

        # ── Approval: pause the generator, end this SSE stream ──
        if etype == "approval_request":
            tool_call_id = event.get("id", f"call-{uuid.uuid4().hex[:8]}")
            approval_id = f"approval-{uuid.uuid4().hex[:8]}"
            tool_name = event.get("name", "")
            tool_input = event.get("input", {})
            print(f"[approval] pausing generator — tool={tool_name} callId={tool_call_id} approvalId={approval_id}")

            # Close any open thinking/text (step already open from tool_call)
            line = close_thinking()
            if line:
                yield line
            line = close_text()
            if line:
                yield line

            # tool-input-available was already emitted by the tool_call handler
            # just emit tool-approval-request targeting the same toolCallId

            pending[project_dir] = {
                "generator": gen,
                "approval": event["approval"],
                "loop_msgs": _loop_msgs,
                "state": {
                    "in_thinking": in_thinking,
                    "in_text": in_text,
                    "step_open": step_open,
                    "thinking_id": thinking_id,
                    "text_id": text_id,
                    "msg_id": msg_id,
                },
                "tool_name": tool_name,
                "tool_input": tool_input,
                "tool_id": tool_call_id,
                "approval_id": approval_id,
            }

            # NOW emit approval request — SDK can find the tool invocation
            yield sse({
                "type": "tool-approval-request",
                "approvalId": approval_id,
                "toolCallId": tool_call_id,
            })
            # Must close step + finish so SDK considers message complete
            # (sendAutomaticallyWhen won't fire on an incomplete message)
            yield sse({"type": "finish-step"})
            yield sse({"type": "finish", "finishReason": "stop"})
            yield "data: [DONE]\n\n"
            return

        if etype == "cancelled":
            line = close_step()
            if line:
                yield line
            yield sse({"type": "finish", "finishReason": "stop"})
            yield "data: [DONE]\n\n"
            return

        # ── Thinking deltas ──
        if etype == "thinking_delta":
            line = close_text()
            if line:
                yield line
            line = open_step()
            if line:
                yield line

            if not in_thinking:
                in_thinking = True
                thinking_id = f"think-{uuid.uuid4().hex[:8]}"
                yield sse({"type": "reasoning-start", "id": thinking_id})

            content = event.get("content", "")
            if content:
                for char in content:
                    yield sse({"type": "reasoning-delta", "id": thinking_id, "delta": char})
                    await asyncio.sleep(0.01)
            continue

        # ── Text deltas ──
        if etype == "text_delta":
            line = close_thinking()
            if line:
                yield line

            line = open_step()
            if line:
                yield line

            content = event.get("content", "")
            if not content:
                continue

            if not in_text:
                in_text = True
                text_id = f"text-{uuid.uuid4().hex[:8]}"
                yield sse({"type": "text-start", "id": text_id})

            for char in content:
                yield sse({"type": "text-delta", "id": text_id, "delta": char})
                await asyncio.sleep(0.01)
            continue

        # ── Tool call ──
        if etype == "tool_call":
            line = close_thinking()
            if line:
                yield line
            line = close_text()
            if line:
                yield line

            line = open_step()
            if line:
                yield line

            tool_call_id = event.get("id", f"call-{uuid.uuid4().hex[:8]}")
            tool_name = event.get("name", "unknown")
            tool_input = event.get("input", {})

            yield sse({
                "type": "tool-input-available",
                "toolCallId": tool_call_id,
                "toolName": tool_name,
                "input": tool_input,
                "dynamic": True,
            })
            store_msgs(project_dir, _loop_msgs)
            continue

        # ── Tool result ──
        if etype == "tool_result":
            tool_call_id = event.get("id", "")
            output = event.get("output", "")

            yield sse({
                "type": "tool-output-available",
                "toolCallId": tool_call_id,
                "output": output,
            })
            store_msgs(project_dir, _loop_msgs)
            continue

        # ── Status messages ──
        if etype == "status":
            continue

        # ── Error ──
        if etype == "error":
            error_msg = event.get("message", "Unknown error")
            line = close_thinking()
            if line:
                yield line
            yield sse({"type": "error", "errorText": f"⚠️ {error_msg}"})
            continue

        # ── Final text signal ──
        if etype == "final_text":
            store_msgs(project_dir, _loop_msgs)
            asyncio.create_task(summarize_and_trim(project_dir, _loop_msgs))
            line = close_thinking()
            if line:
                yield line
            line = close_text()
            if line:
                yield line
            line = close_step()
            if line:
                yield line
            continue

        # ── Done ──
        if etype == "done":
            line = close_thinking()
            if line:
                yield line
            line = close_text()
            if line:
                yield line
            line = close_step()
            if line:
                yield line
            continue

    # ── Message finish ──
    yield sse({"type": "finish", "finishReason": "stop"})
    yield "data: [DONE]\n\n"


@app.post("/api/chat")
async def chat(request: Request):
    data = await request.json()
    project_dir = data.get("project_dir", "")
    messages = data.get("messages", [])

    # ── Resume pending approval (SDK re-submits here after addToolApprovalResponse) ──
    if project_dir in pending:
        print(f"[chat] resuming pending approval for {project_dir}")
        redis_state = RedisStateManager()
        redis_state.set_streaming_state(project_dir, True)
        return StreamingResponse(
            sse_claude_loop(
                query="",
                project_dir=project_dir,
                watcher=watchers.get(project_dir),
                resume=True,
            ),
            media_type="text/event-stream",
            headers=SSE_HEADERS,
        )

    # useChat sends full message history as UIMessage[] (with parts[]).
    # We only need the latest user message text.
    # claude_loop manages its own message history via msg_store.
    latest_message = ""
    if messages:
        last = messages[-1]
        # v6 UIMessage format: {id, role, parts: [{type:"text", text:"..."}, ...]}
        parts = last.get("parts", [])
        if parts:
            text_parts = [p.get("text", "") for p in parts if p.get("type") == "text"]
            latest_message = "\n".join(text_parts)
        else:
            # Fallback for plain string content (shouldn't happen with v6 but defensive)
            content = last.get("content", "")
            if isinstance(content, str):
                latest_message = content

    if not latest_message:
        print(f"[chat] no text content, returning DONE")
        return StreamingResponse(
            iter(["data: [DONE]\n\n"]),
            media_type="text/event-stream",
        )

    # Ensure session is initialized
    if project_dir not in watchers:
        os.makedirs(project_dir, exist_ok=True)
        w = FileWatcher(project_dir)
        w.start()
        watchers[project_dir] = w

    watcher = watchers.get(project_dir)

    # Mark stream as active
    redis_state = RedisStateManager()
    redis_state.set_streaming_state(project_dir, True)

    print(f"[chat] new query for {project_dir}: {latest_message[:80]}...")
    return StreamingResponse(
        sse_claude_loop(
            query=latest_message,
            project_dir=project_dir,
            watcher=watcher,
        ),
        media_type="text/event-stream",
        headers=SSE_HEADERS,
    )


# ─── Deny ─────────────────────────────────────────────────────────

@app.post("/api/chat/deny")
async def deny_tool(request: Request):
    """Reject a pending tool call — cleans up the paused generator."""
    data = await request.json()
    project_dir = data.get("project_dir", "")

    if project_dir not in pending:
        return {"status": "error", "message": "no pending approval for this project"}

    p = pending.pop(project_dir)
    p["approval"]["approved"] = False
    if "loop_msgs" in p:
        store_msgs(project_dir, p["loop_msgs"])

    tool_call_id = p.get("tool_id", "")

    async def denied_stream():
        yield sse({"type": "tool-output-denied", "toolCallId": tool_call_id})
        yield sse({"type": "finish-step"})
        yield sse({"type": "finish", "finishReason": "stop"})
        yield "data: [DONE]\n\n"

    # Drain the generator in background so it can clean up
    async def drain_cancelled():
        async for event in p["generator"]:
            break

    asyncio.create_task(drain_cancelled())

    return StreamingResponse(
        denied_stream(),
        media_type="text/event-stream",
        headers=SSE_HEADERS,
    )


# ─── Stop / Clear ─────────────────────────────────────────────────

@app.post("/api/chat/stop")
async def stop_stream(request: Request):
    """Signal the active stream to stop."""
    redis_state = RedisStateManager()
    data = await request.json()
    project_dir = data.get("project_dir", "")

    redis_state.set_streaming_state(project_dir, False)
    return {"status": "stopping", "project_dir": project_dir}


@app.post("/clear")
async def clear(request: Request):
    data = await request.json()
    project_dir = data.get("project_dir", "")
    erase_msgs(project_dir)
    erase_summary(project_dir)
    return {"status": "cleared"}


# ─── Run ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
