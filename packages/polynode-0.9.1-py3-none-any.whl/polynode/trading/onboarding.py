"""Onboarding logic for Safe deployment, wallet type detection, approvals, and CLOB credentials."""

from __future__ import annotations

from typing import Any

import httpx

from .constants import (
    CHAIN_ID,
    CLOB_HOST,
    CLOB_HOST_V2,
    COLLATERAL_OFFRAMP,
    COLLATERAL_ONRAMP,
    CTF,
    CTF_EXCHANGE,
    CTF_EXCHANGE_V2,
    NEG_RISK_ADAPTER,
    NEG_RISK_CTF_EXCHANGE,
    NEG_RISK_CTF_EXCHANGE_V2_A,
    NEG_RISK_CTF_EXCHANGE_V2_B,
    POLY_USD,
    PROXY_FACTORY,
    PROXY_INIT_CODE_HASH,
    RELAYER_HOST,
    SAFE_FACTORY,
    SAFE_INIT_CODE_HASH,
    SPENDERS,
    USDC,
    V2_SPENDERS,
    FEE_ESCROW_ADDRESS,
)
from .types import ApprovalStatus, BalanceInfo, ExchangeVersion, SignatureType


def derive_safe_address(eoa: str) -> str:
    """Derive the CREATE2 Safe address for an EOA."""
    try:
        from eth_abi import encode
        from eth_utils import keccak, to_checksum_address
    except ImportError:
        raise ImportError("eth-account/web3 required. Install with: pip install polynode[trading]")

    eoa_lower = eoa.lower()
    if eoa_lower.startswith("0x"):
        eoa_lower = eoa_lower[2:]

    # Salt = keccak256(abi.encode(["address"], [eoa]))
    encoded = encode(["address"], [eoa])
    salt = keccak(encoded)

    factory_bytes = bytes.fromhex(SAFE_FACTORY[2:])
    init_code_hash = bytes.fromhex(SAFE_INIT_CODE_HASH[2:])

    addr_bytes = keccak(b"\xff" + factory_bytes + salt + init_code_hash)
    return to_checksum_address("0x" + addr_bytes[-20:].hex())


def derive_proxy_address(eoa: str) -> str:
    """Derive the CREATE2 Proxy address for an EOA."""
    try:
        from eth_abi.packed import encode_packed
        from eth_utils import keccak, to_checksum_address
    except ImportError:
        raise ImportError("eth-account/web3 required. Install with: pip install polynode[trading]")

    # Salt = keccak256(encodePacked(["address"], [eoa]))
    packed = encode_packed(["address"], [eoa])
    salt = keccak(packed)

    factory_bytes = bytes.fromhex(PROXY_FACTORY[2:])
    init_code_hash = bytes.fromhex(PROXY_INIT_CODE_HASH[2:])

    addr_bytes = keccak(b"\xff" + factory_bytes + salt + init_code_hash)
    return to_checksum_address("0x" + addr_bytes[-20:].hex())


async def derive_funder_address(eoa: str, sig_type: SignatureType) -> str:
    """Derive the funder address based on signature type."""
    if sig_type == SignatureType.POLY_GNOSIS_SAFE:
        return derive_safe_address(eoa)
    elif sig_type == SignatureType.POLY_PROXY:
        return derive_proxy_address(eoa)
    return eoa


async def detect_wallet_type(eoa: str) -> dict:
    """Auto-detect if a Safe or Proxy is deployed for this EOA."""
    safe_addr = derive_safe_address(eoa)
    proxy_addr = derive_proxy_address(eoa)

    async with httpx.AsyncClient(timeout=10.0) as http:
        # Check Safe first (most common)
        try:
            resp = await http.get(f"{RELAYER_HOST}/deployed?owner={eoa}&salt={eoa}")
            if resp.is_success:
                data = resp.json()
                if data.get("deployed"):
                    return {
                        "signature_type": SignatureType.POLY_GNOSIS_SAFE,
                        "funder_address": safe_addr,
                    }
        except Exception:
            pass

        # Check Proxy
        try:
            resp = await http.get(f"{RELAYER_HOST}/deployed?owner={eoa}&salt={eoa}&type=proxy")
            if resp.is_success:
                data = resp.json()
                if data.get("deployed"):
                    return {
                        "signature_type": SignatureType.POLY_PROXY,
                        "funder_address": proxy_addr,
                    }
        except Exception:
            pass

    # Neither deployed — default to Safe
    return {
        "signature_type": SignatureType.POLY_GNOSIS_SAFE,
        "funder_address": safe_addr,
    }


async def is_safe_deployed(funder_address: str) -> bool:
    """Check if a Safe/Proxy is deployed at the given address."""
    async with httpx.AsyncClient(timeout=10.0) as http:
        try:
            resp = await http.get(f"{RELAYER_HOST}/deployed?address={funder_address}")
            if resp.is_success:
                return resp.json().get("deployed", False)
        except Exception:
            pass
    return False


async def check_approvals(
    funder_address: str,
    rpc_url: str,
    version: ExchangeVersion = ExchangeVersion.V1,
) -> ApprovalStatus:
    """Check token approvals for all spender contracts.

    V1: checks USDC allowance to SPENDERS (CTF Exchange, NegRisk, Adapter)
    V2: checks PolyUSD allowance to V2_SPENDERS (V2 Exchange, NegRisk V2 A/B)
    Both: checks CTF isApprovedForAll to the respective spenders
    """
    try:
        from web3 import Web3
    except ImportError:
        raise ImportError("web3 required. Install with: pip install polynode[trading]")

    w3 = Web3(Web3.HTTPProvider(rpc_url))
    erc20_abi = [{"inputs": [{"name": "owner", "type": "address"}, {"name": "spender", "type": "address"}], "name": "allowance", "outputs": [{"name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"}]
    erc1155_abi = [{"inputs": [{"name": "account", "type": "address"}, {"name": "operator", "type": "address"}], "name": "isApprovedForAll", "outputs": [{"name": "", "type": "bool"}], "stateMutability": "view", "type": "function"}]

    if version == ExchangeVersion.V2:
        # V2 CLOB validates three pUSD allowances during order placement:
        # CTF_EXCHANGE_V2 (standard), NEG_RISK_CTF_EXCHANGE_V2_A (neg-risk),
        # and V1 NEG_RISK_ADAPTER (V2 neg-risk delegates settlement to it).
        collateral_token = POLY_USD
        spender_list = [
            (CTF_EXCHANGE_V2, "ctf_exchange_v2"),
            (NEG_RISK_CTF_EXCHANGE_V2_A, "neg_risk_ctf_exchange_v2_a"),
            (NEG_RISK_ADAPTER, "neg_risk_adapter"),
        ]
    else:
        collateral_token = USDC
        spender_list = [
            (CTF_EXCHANGE, "ctf_exchange"),
            (NEG_RISK_CTF_EXCHANGE, "neg_risk_ctf_exchange"),
            (NEG_RISK_ADAPTER, "neg_risk_adapter"),
        ]

    token_contract = w3.eth.contract(address=Web3.to_checksum_address(collateral_token), abi=erc20_abi)
    ctf_contract = w3.eth.contract(address=Web3.to_checksum_address(CTF), abi=erc1155_abi)

    funder = Web3.to_checksum_address(funder_address)
    max_uint = 2**256 - 1
    threshold = max_uint // 2

    usdc_status = {}
    ctf_status = {}
    for spender, name in spender_list:
        spender_addr = Web3.to_checksum_address(spender)
        allowance = token_contract.functions.allowance(funder, spender_addr).call()
        usdc_status[name] = allowance >= threshold
        approved = ctf_contract.functions.isApprovedForAll(funder, spender_addr).call()
        ctf_status[name] = approved

    # Fee Escrow USDC approval (always USDC.e regardless of exchange version)
    usdc_contract = w3.eth.contract(address=Web3.to_checksum_address(USDC), abi=erc20_abi)
    escrow_allowance = usdc_contract.functions.allowance(funder, Web3.to_checksum_address(FEE_ESCROW_ADDRESS)).call()
    usdc_status["fee_escrow"] = escrow_allowance >= threshold

    all_approved = all(usdc_status.values()) and all(ctf_status.values())

    return ApprovalStatus(
        funder_address=funder_address,
        usdc=usdc_status,
        ctf=ctf_status,
        all_approved=all_approved,
    )


async def set_approvals(
    signer_key: str,
    funder_address: str,
    rpc_url: str,
    version: ExchangeVersion = ExchangeVersion.V1,
) -> list[str]:
    """Set max approvals for collateral and CTF tokens to exchange spenders.

    V1: approve USDC to SPENDERS
    V2: approve PolyUSD to V2_SPENDERS
    Both: setApprovalForAll on CTF to the respective spenders

    Returns a list of submitted transaction hashes.
    """
    try:
        from web3 import Web3
        from eth_account import Account
    except ImportError:
        raise ImportError("web3 required. Install with: pip install polynode[trading]")

    w3 = Web3(Web3.HTTPProvider(rpc_url))
    account = Account.from_key(signer_key if signer_key.startswith("0x") else f"0x{signer_key}")
    max_uint = 2**256 - 1

    erc20_abi = [
        {"inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "name": "approve", "outputs": [{"name": "", "type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
    ]
    erc1155_abi = [
        {"inputs": [{"name": "operator", "type": "address"}, {"name": "approved", "type": "bool"}], "name": "setApprovalForAll", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    ]

    if version == ExchangeVersion.V2:
        collateral_token = POLY_USD
        spender_list = V2_SPENDERS
    else:
        collateral_token = USDC
        spender_list = SPENDERS

    token_contract = w3.eth.contract(address=Web3.to_checksum_address(collateral_token), abi=erc20_abi)
    ctf_contract = w3.eth.contract(address=Web3.to_checksum_address(CTF), abi=erc1155_abi)

    tx_hashes: list[str] = []
    nonce = w3.eth.get_transaction_count(account.address)

    for spender in spender_list:
        spender_addr = Web3.to_checksum_address(spender)

        # Approve collateral token
        tx = token_contract.functions.approve(spender_addr, max_uint).build_transaction({
            "from": account.address,
            "nonce": nonce,
            "chainId": CHAIN_ID,
        })
        signed = account.sign_transaction(tx)
        tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
        tx_hashes.append(tx_hash.hex())
        nonce += 1

        # Approve CTF (ERC-1155)
        tx = ctf_contract.functions.setApprovalForAll(spender_addr, True).build_transaction({
            "from": account.address,
            "nonce": nonce,
            "chainId": CHAIN_ID,
        })
        signed = account.sign_transaction(tx)
        tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
        tx_hashes.append(tx_hash.hex())
        nonce += 1

    # Fee Escrow USDC approval (always USDC.e regardless of exchange version)
    escrow_contract = w3.eth.contract(address=Web3.to_checksum_address(USDC), abi=erc20_abi)
    tx = escrow_contract.functions.approve(Web3.to_checksum_address(FEE_ESCROW_ADDRESS), max_uint).build_transaction({
        "from": account.address,
        "nonce": nonce,
        "chainId": CHAIN_ID,
    })
    signed = account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    tx_hashes.append(tx_hash.hex())

    return tx_hashes


async def check_balance(
    funder_address: str,
    rpc_url: str,
    version: ExchangeVersion = ExchangeVersion.V1,
) -> BalanceInfo:
    """Check collateral and MATIC balance. V1 reads USDC.e, V2 reads pUSD."""
    try:
        from web3 import Web3
    except ImportError:
        raise ImportError("web3 required. Install with: pip install polynode[trading]")

    w3 = Web3(Web3.HTTPProvider(rpc_url))
    erc20_abi = [{"inputs": [{"name": "account", "type": "address"}], "name": "balanceOf", "outputs": [{"name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"}]

    collateral_token = POLY_USD if version == ExchangeVersion.V2 else USDC
    token_contract = w3.eth.contract(address=Web3.to_checksum_address(collateral_token), abi=erc20_abi)
    funder = Web3.to_checksum_address(funder_address)

    usdc_raw = token_contract.functions.balanceOf(funder).call()
    matic_raw = w3.eth.get_balance(funder)

    return BalanceInfo(
        funder_address=funder_address,
        usdc=f"{usdc_raw / 1_000_000:.2f}",
        usdc_raw=str(usdc_raw),
        matic=f"{matic_raw / 10**18:.4f}",
    )


async def _build_l1_headers(signer: Any, _funder_address: str) -> dict[str, str]:
    """Build L1 auth headers for the Polymarket CLOB API.

    Uses the signer's EOA address (not Safe/Proxy funder) for both POLY_ADDRESS
    and the EIP-712 message, matching the official py-clob-client and TS SDK.
    """
    from .types import Eip712Payload

    timestamp = str(int(__import__("time").time()))
    nonce = 0
    eoa_address = signer.address  # EOA, not funder

    payload = Eip712Payload(
        domain={
            "name": "ClobAuthDomain",
            "version": "1",
            "chainId": CHAIN_ID,
        },
        types={
            "ClobAuth": [
                {"name": "address", "type": "address"},
                {"name": "timestamp", "type": "string"},
                {"name": "nonce", "type": "uint256"},
                {"name": "message", "type": "string"},
            ],
        },
        primary_type="ClobAuth",
        message={
            "address": eoa_address,
            "timestamp": timestamp,
            "nonce": nonce,
            "message": "This message attests that I control the given wallet",
        },
    )

    signature = await signer.sign_typed_data(payload)
    if not signature.startswith("0x"):
        signature = f"0x{signature}"

    return {
        "POLY_ADDRESS": eoa_address,
        "POLY_SIGNATURE": signature,
        "POLY_TIMESTAMP": timestamp,
        "POLY_NONCE": str(nonce),
    }


def _parse_clob_credentials(data: dict) -> dict[str, str]:
    """Parse CLOB credential response (handles both 'apiKey'/'key' variants)."""
    return {
        "apiKey": data.get("apiKey") or data.get("key", ""),
        "apiSecret": data["secret"],
        "apiPassphrase": data["passphrase"],
    }


async def create_clob_credentials(
    signer: Any,
    funder_address: str,
    version: ExchangeVersion = ExchangeVersion.V1,
) -> dict[str, str]:
    """Create or derive CLOB API credentials via the Polymarket CLOB API.

    Tries POST /auth/api-key first (create new), falls back to
    GET /auth/derive-api-key (derive existing). Matches Rust SDK flow.

    Same API key works on both V1 and V2 CLOBs (shared database),
    but we route to the correct CLOB host for the version.
    """
    host = CLOB_HOST_V2 if version == ExchangeVersion.V2 else CLOB_HOST

    async with httpx.AsyncClient(timeout=10.0) as http:
        # Step 1: Try creating a new API key
        headers = await _build_l1_headers(signer, funder_address)
        resp = await http.post(
            f"{host}/auth/api-key",
            headers={**headers, "Accept": "*/*", "Content-Type": "application/json"},
        )
        if resp.is_success:
            data = resp.json()
            creds = _parse_clob_credentials(data)
            if creds["apiKey"]:
                return creds

        # Step 2: Fall back to deriving existing key
        headers = await _build_l1_headers(signer, funder_address)
        resp = await http.get(
            f"{host}/auth/derive-api-key",
            headers={**headers, "Accept": "*/*", "Content-Type": "application/json"},
        )
        if not resp.is_success:
            raise RuntimeError(f"Failed to create CLOB credentials: {resp.status_code} {resp.text}")

        return _parse_clob_credentials(resp.json())
