"""Polymarket builder-relayer client (Python port).

Ports the minimum needed from @polymarket/builder-relayer-client +
@polymarket/builder-signing-sdk to submit gasless Safe transactions.

Flow:
  1. GET  {relayer}/nonce?address={eoa}&type=SAFE           → next SafeTx nonce
  2. Build multisend (if >1 tx) or single tx
  3. EIP-712 hash SafeTx(domain={chainId, verifyingContract=safe}, types, msg)
  4. EIP-191 personal_sign the hash with EOA private key
  5. Pack r||s||v (v adjusted by +4 for Gnosis)
  6. POST {relayer}/submit with builder HMAC headers
  7. Poll {relayer}/transaction?id=... until STATE_MINED / STATE_CONFIRMED
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Any

import httpx

from .constants import CHAIN_ID, RELAYER_HOST, SAFE_FACTORY, SAFE_MULTISEND
from .onboarding import derive_safe_address


@dataclass
class BuilderCreds:
    key: str
    secret: str
    passphrase: str


ZERO_ADDR = "0x" + "0" * 40


# ── EIP-712 helpers ──

def _keccak(data: bytes) -> bytes:
    from eth_utils import keccak as _k
    return _k(data)


# Compute once on module load
def _safe_tx_type_hash() -> bytes:
    return _keccak(
        b"SafeTx(address to,uint256 value,bytes data,uint8 operation,"
        b"uint256 safeTxGas,uint256 baseGas,uint256 gasPrice,address gasToken,"
        b"address refundReceiver,uint256 nonce)"
    )


def _domain_type_hash() -> bytes:
    return _keccak(b"EIP712Domain(uint256 chainId,address verifyingContract)")


def _pad32(h: bytes) -> bytes:
    return h if len(h) == 32 else (b"\x00" * (32 - len(h))) + h


def _encode_address(addr: str) -> bytes:
    return _pad32(bytes.fromhex(addr.lower().removeprefix("0x")))


def _encode_uint256(n: int) -> bytes:
    return int(n).to_bytes(32, "big", signed=False)


def _domain_separator(chain_id: int, verifying_contract: str) -> bytes:
    return _keccak(
        _domain_type_hash() + _encode_uint256(chain_id) + _encode_address(verifying_contract)
    )


def _safe_tx_struct_hash(
    to: str, value: int, data: bytes, operation: int,
    safe_tx_gas: int, base_gas: int, gas_price: int,
    gas_token: str, refund_receiver: str, nonce: int,
) -> bytes:
    data_hash = _keccak(data)
    encoded = (
        _safe_tx_type_hash()
        + _encode_address(to)
        + _encode_uint256(value)
        + data_hash
        + _encode_uint256(operation)
        + _encode_uint256(safe_tx_gas)
        + _encode_uint256(base_gas)
        + _encode_uint256(gas_price)
        + _encode_address(gas_token)
        + _encode_address(refund_receiver)
        + _encode_uint256(nonce)
    )
    return _keccak(encoded)


def _eip712_digest(chain_id: int, safe_addr: str, struct_hash: bytes) -> bytes:
    domain_sep = _domain_separator(chain_id, safe_addr)
    return _keccak(b"\x19\x01" + domain_sep + struct_hash)


# ── Safe multisend encoding ──

def _encode_multisend(txns: list[dict[str, Any]]) -> bytes:
    """Encode txns into the multiSend bytes arg.
    Each tx packed as: uint8 operation | address to | uint256 value | uint256 dataLen | bytes data
    """
    parts: list[bytes] = []
    for tx in txns:
        op = int(tx.get("operation", 0))
        to = tx["to"]
        value = int(tx.get("value", 0))
        data = tx["data"]
        if isinstance(data, str):
            data_bytes = bytes.fromhex(data.removeprefix("0x"))
        else:
            data_bytes = data
        parts.append(
            op.to_bytes(1, "big")
            + bytes.fromhex(to.lower().removeprefix("0x"))
            + value.to_bytes(32, "big")
            + len(data_bytes).to_bytes(32, "big")
            + data_bytes
        )
    return b"".join(parts)


def _encode_multisend_calldata(txns: list[dict[str, Any]]) -> str:
    """Wrap encoded txns in multiSend(bytes) ABI call."""
    # multiSend(bytes) selector = keccak256("multiSend(bytes)")[:4] = 0x8d80ff0a
    inner = _encode_multisend(txns)
    # ABI-encode single `bytes` arg: offset(32) + length(32) + data (padded to 32)
    padded_len = ((len(inner) + 31) // 32) * 32
    padded = inner + b"\x00" * (padded_len - len(inner))
    encoded = (
        bytes.fromhex("8d80ff0a")
        + _encode_uint256(32)   # offset to bytes arg
        + _encode_uint256(len(inner))
        + padded
    )
    return "0x" + encoded.hex()


# ── Builder HMAC ──

def _build_hmac_headers(creds: BuilderCreds, method: str, path: str, body: str | None = None) -> dict[str, str]:
    timestamp = str(int(time.time()))
    message = timestamp + method + path + (body or "")
    # Secret may be url-safe base64 (`-` / `_`); normalize before decoding.
    secret_norm = creds.secret.replace("-", "+").replace("_", "/")
    key_bytes = base64.b64decode(secret_norm)
    mac = hmac.new(key_bytes, message.encode(), hashlib.sha256).digest()
    sig = base64.b64encode(mac).decode().replace("+", "-").replace("/", "_")
    return {
        "POLY_BUILDER_API_KEY": creds.key,
        "POLY_BUILDER_PASSPHRASE": creds.passphrase,
        "POLY_BUILDER_SIGNATURE": sig,
        "POLY_BUILDER_TIMESTAMP": timestamp,
    }


# ── Signature packing ──

def _pack_sig(sig_hex: str) -> str:
    """Split 65-byte sig into r||s||v with Gnosis v-adjustment (+4)."""
    raw = bytes.fromhex(sig_hex.removeprefix("0x"))
    assert len(raw) == 65, f"expected 65-byte sig, got {len(raw)}"
    r, s, v = raw[:32], raw[32:64], raw[64]
    # Adjust v: 0/1 → 31/32, 27/28 → 31/32 (eth_sign variant per Gnosis spec)
    if v in (0, 1):
        v += 31
    elif v in (27, 28):
        v += 4
    else:
        raise ValueError(f"invalid sig v byte: {v}")
    return "0x" + (r + s + v.to_bytes(1, "big")).hex()


# ── RelayClient ──

class RelayClient:
    """Minimal Polymarket relayer client for Safe transactions."""

    def __init__(self, builder_creds: BuilderCreds, relayer_url: str = RELAYER_HOST, chain_id: int = CHAIN_ID):
        self.relayer_url = relayer_url.rstrip("/")
        self.chain_id = chain_id
        self.builder_creds = builder_creds

    async def execute_safe(
        self,
        signer_pk: str,
        eoa_address: str,
        txns: list[dict[str, Any]],
    ) -> str:
        """Build, sign, submit, and wait for a batch of Safe transactions.

        Returns the on-chain transaction hash.
        """
        if not txns:
            raise ValueError("no transactions to execute")

        try:
            from eth_account import Account
            from eth_account.messages import encode_defunct
        except ImportError:
            raise ImportError("eth-account required for Safe relayer")

        safe_addr = derive_safe_address(eoa_address)

        # 1. Get nonce
        async with httpx.AsyncClient(timeout=20.0) as client:
            r = await client.get(
                f"{self.relayer_url}/nonce",
                params={"address": eoa_address, "type": "SAFE"},
            )
            r.raise_for_status()
            nonce_payload = r.json()
            nonce = int(nonce_payload["nonce"])

        # 2. Aggregate (single tx → direct, multi → multisend DelegateCall)
        if len(txns) == 1:
            tx = txns[0]
            to_addr = tx["to"]
            data = tx["data"]
            operation = int(tx.get("operation", 0))
        else:
            to_addr = SAFE_MULTISEND
            data = _encode_multisend_calldata(
                [{**t, "operation": int(t.get("operation", 0))} for t in txns]
            )
            operation = 1  # DelegateCall

        # 3. Compute EIP-712 digest
        data_bytes = bytes.fromhex(data.removeprefix("0x")) if isinstance(data, str) else data
        struct_hash = _safe_tx_struct_hash(
            to=to_addr, value=0, data=data_bytes, operation=operation,
            safe_tx_gas=0, base_gas=0, gas_price=0,
            gas_token=ZERO_ADDR, refund_receiver=ZERO_ADDR,
            nonce=nonce,
        )
        digest = _eip712_digest(self.chain_id, safe_addr, struct_hash)

        # 4. EIP-191 personal_sign on the digest
        account = Account.from_key(signer_pk if signer_pk.startswith("0x") else f"0x{signer_pk}")
        signed = account.sign_message(encode_defunct(primitive=digest))
        packed_sig = _pack_sig(signed.signature.hex())

        # 5. Build submit payload
        req = {
            "from": eoa_address,
            "to": to_addr,
            "proxyWallet": safe_addr,
            "data": data if isinstance(data, str) else "0x" + data.hex(),
            "nonce": str(nonce),
            "signature": packed_sig,
            "signatureParams": {
                "gasPrice": "0",
                "operation": str(operation),
                "safeTxnGas": "0",
                "baseGas": "0",
                "gasToken": ZERO_ADDR,
                "refundReceiver": ZERO_ADDR,
            },
            "type": "SAFE",
            "metadata": "",
        }
        body = json.dumps(req, separators=(",", ":"))

        # 6. POST /submit with builder HMAC headers
        headers = _build_hmac_headers(self.builder_creds, "POST", "/submit", body)
        headers["Content-Type"] = "application/json"
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(f"{self.relayer_url}/submit", content=body, headers=headers)
            if not r.is_success:
                raise RuntimeError(f"relayer /submit failed: {r.status_code} {r.text}")
            resp = r.json()
            tx_id = resp["transactionID"]

        # 7. Poll /transaction until mined
        for _ in range(30):  # up to 60s
            await asyncio.sleep(2)
            async with httpx.AsyncClient(timeout=10.0) as client:
                r = await client.get(
                    f"{self.relayer_url}/transaction",
                    params={"id": tx_id},
                )
                if not r.is_success:
                    continue
                rows = r.json()
                if not rows:
                    continue
                row = rows[0] if isinstance(rows, list) else rows
                state = row.get("state")
                if state in ("STATE_MINED", "STATE_CONFIRMED"):
                    return row["transactionHash"]
                if state in ("STATE_FAILED", "STATE_REVERTED"):
                    raise RuntimeError(f"tx {tx_id} failed on-chain: state={state} hash={row.get('transactionHash')}")
        raise RuntimeError(f"tx {tx_id} timed out waiting for mined state")
