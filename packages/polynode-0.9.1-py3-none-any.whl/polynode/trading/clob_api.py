"""Direct CLOB HTTP calls for order management."""

from __future__ import annotations

from typing import Any

import httpx

from .constants import CLOB_HOST, CLOB_HOST_V2
from .cosigner import build_l2_headers
from .types import ExchangeVersion


async def post_order(
    cosigner_url: str,
    polynode_key: str,
    fallback_direct: bool,
    credentials: dict[str, str],
    wallet_address: str,
    order_body: str,
    builder_credentials: Any | None = None,
    clob_host: str | None = None,
) -> dict[str, Any]:
    """Submit a signed order to the CLOB."""
    from .cosigner import send_via_cosigner

    headers = build_l2_headers(
        credentials["apiKey"],
        credentials["apiSecret"],
        credentials["apiPassphrase"],
        wallet_address,
        "POST",
        "/order",
        order_body,
    )

    return await send_via_cosigner(
        cosigner_url,
        polynode_key,
        fallback_direct,
        {"method": "POST", "path": "/order", "body": order_body, "headers": headers},
        builder_credentials=builder_credentials,
        clob_host=clob_host,
    )


async def cancel_order(
    cosigner_url: str,
    polynode_key: str,
    fallback_direct: bool,
    credentials: dict[str, str],
    wallet_address: str,
    order_id: str,
    builder_credentials: Any | None = None,
    clob_host: str | None = None,
) -> dict[str, Any]:
    """Cancel a specific order."""
    from .cosigner import send_via_cosigner
    import json

    body = json.dumps({"orderID": order_id})
    headers = build_l2_headers(
        credentials["apiKey"],
        credentials["apiSecret"],
        credentials["apiPassphrase"],
        wallet_address,
        "DELETE",
        "/order",
        body,
    )

    return await send_via_cosigner(
        cosigner_url,
        polynode_key,
        fallback_direct,
        {"method": "DELETE", "path": "/order", "body": body, "headers": headers},
        builder_credentials=builder_credentials,
        clob_host=clob_host,
    )


async def cancel_all_orders(
    cosigner_url: str,
    polynode_key: str,
    fallback_direct: bool,
    credentials: dict[str, str],
    wallet_address: str,
    market: str | None = None,
    builder_credentials: Any | None = None,
    clob_host: str | None = None,
) -> dict[str, Any]:
    """Cancel all orders, optionally for a specific market."""
    from .cosigner import send_via_cosigner
    import json

    path = "/cancel-market-orders" if market else "/cancel-all"
    body = json.dumps({"market": market}) if market else None
    headers = build_l2_headers(
        credentials["apiKey"],
        credentials["apiSecret"],
        credentials["apiPassphrase"],
        wallet_address,
        "DELETE",
        path,
        body,
    )

    return await send_via_cosigner(
        cosigner_url,
        polynode_key,
        fallback_direct,
        {"method": "DELETE", "path": path, "body": body, "headers": headers},
        builder_credentials=builder_credentials,
        clob_host=clob_host,
    )


async def get_open_orders(
    cosigner_url: str,
    polynode_key: str,
    fallback_direct: bool,
    credentials: dict[str, str],
    wallet_address: str,
    market: str | None = None,
    asset_id: str | None = None,
    builder_credentials: Any | None = None,
    clob_host: str | None = None,
) -> list[dict[str, Any]]:
    """Get open orders from the CLOB."""
    from .cosigner import send_via_cosigner

    path = "/data/orders"
    params = []
    if market:
        params.append(f"market={market}")
    if asset_id:
        params.append(f"asset_id={asset_id}")
    if params:
        path += "?" + "&".join(params)

    headers = build_l2_headers(
        credentials["apiKey"],
        credentials["apiSecret"],
        credentials["apiPassphrase"],
        wallet_address,
        "GET",
        path,
    )

    result = await send_via_cosigner(
        cosigner_url,
        polynode_key,
        fallback_direct,
        {"method": "GET", "path": path, "headers": headers},
        builder_credentials=builder_credentials,
        clob_host=clob_host,
    )

    if isinstance(result, list):
        return result
    return result.get("data") or result.get("orders") or []


def _clob_host(version: ExchangeVersion = ExchangeVersion.V1) -> str:
    """Return the CLOB host URL for the given exchange version."""
    return CLOB_HOST_V2 if version == ExchangeVersion.V2 else CLOB_HOST


async def fetch_tick_size(
    token_id: str,
    version: ExchangeVersion = ExchangeVersion.V1,
) -> str:
    """Fetch tick size for a token from the CLOB."""
    host = _clob_host(version)
    async with httpx.AsyncClient(timeout=5.0) as http:
        resp = await http.get(f"{host}/tick-size?token_id={token_id}")
        data = resp.json()
        return str(data.get("minimum_tick_size", data) if isinstance(data, dict) else data)


async def fetch_neg_risk(
    token_id: str,
    version: ExchangeVersion = ExchangeVersion.V1,
) -> bool:
    """Fetch neg-risk flag for a token from the CLOB."""
    host = _clob_host(version)
    async with httpx.AsyncClient(timeout=5.0) as http:
        resp = await http.get(f"{host}/neg-risk?token_id={token_id}")
        data = resp.json()
        if isinstance(data, dict):
            # Read the .neg_risk field directly — `bool(dict)` is always True for non-empty dicts.
            return bool(data.get("neg_risk", False))
        return bool(data)


async def refresh_balance_allowance(
    credentials: dict[str, str],
    wallet_address: str,
    signature_type: int,
    asset_type: str = "COLLATERAL",
) -> tuple[bool, int]:
    """Ask the V2 CLOB to refresh its cached balance/allowance view.

    The CLOB caches on-chain balance + allowance per-API-key. Changes on-chain
    are invisible until this endpoint is pinged. Call after setting approvals.

    Returns (ok, status_code).
    """
    path = "/balance-allowance/update"
    headers = build_l2_headers(
        credentials["apiKey"],
        credentials["apiSecret"],
        credentials["apiPassphrase"],
        wallet_address,
        "GET",
        path,  # HMAC uses base path only (NO query string)
    )
    url = f"{CLOB_HOST_V2}{path}?asset_type={asset_type}&signature_type={signature_type}"
    async with httpx.AsyncClient(timeout=10.0) as http:
        resp = await http.get(url, headers=headers)
        return resp.is_success, resp.status_code


async def get_balance_allowance(
    credentials: dict[str, str],
    wallet_address: str,
    signature_type: int,
    asset_type: str = "COLLATERAL",
) -> dict[str, Any] | None:
    """Read the V2 CLOB's current cached view of balance + allowance.

    Returns dict with {balance, allowances} or None on failure.
    """
    path = "/balance-allowance"
    headers = build_l2_headers(
        credentials["apiKey"],
        credentials["apiSecret"],
        credentials["apiPassphrase"],
        wallet_address,
        "GET",
        path,  # HMAC uses base path only
    )
    url = f"{CLOB_HOST_V2}{path}?asset_type={asset_type}&signature_type={signature_type}"
    async with httpx.AsyncClient(timeout=10.0) as http:
        resp = await http.get(url, headers=headers)
        if not resp.is_success:
            return None
        return resp.json()
