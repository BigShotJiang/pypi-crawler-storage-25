"""Contract addresses and constants for Polymarket on Polygon (chain 137)."""

CHAIN_ID = 137
RELAYER_HOST = "https://relayer-v2.polymarket.com"
DEFAULT_RPC = "https://polygon-bor-rpc.publicnode.com"
DEFAULT_COSIGNER = "https://trade.polynode.dev"

# ── V1 ──
CLOB_HOST = "https://clob.polymarket.com"
CTF_EXCHANGE = "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E"
NEG_RISK_CTF_EXCHANGE = "0xC5d563A36AE78145C45a50134d48A1215220f80a"
NEG_RISK_ADAPTER = "0xd91E80cF2E7be2e162c6513ceD06f1dD0dA35296"

# ── V2 ──
CLOB_HOST_V2 = "https://clob-v2.polymarket.com"
CTF_EXCHANGE_V2 = "0xe111180000d2663c0091e4f400237545b87b996b"
NEG_RISK_CTF_EXCHANGE_V2_A = "0xe2222d279d744050d28e00520010520000310f59"
NEG_RISK_CTF_EXCHANGE_V2_B = "0xe2222d002000ba0053cef3375333610f64600036"

# Token contracts
USDC = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
CTF = "0x4D97DCd97eC945f40cF65F87097ACe5EA0476045"

# Safe derivation
SAFE_FACTORY = "0xaacFeEa03eb1561C4e67d661e40682Bd20E3541b"
SAFE_MULTISEND = "0xA238CBeb142c10Ef7Ad8442C6D1f9E89e07e7761"
SAFE_INIT_CODE_HASH = "0x2bce2127ff07fb632d16c8347c4ebf501f4841168bed00d9e6ef715ddb6fcecf"

# Proxy derivation
PROXY_FACTORY = "0xaB45c5A4B0c941a2F231C04C3f49182e1A254052"
PROXY_INIT_CODE_HASH = "0xd21df8dc65880a8606f09fe0ce3df9b8869287ab0b058be05aa9e8af6330a00b"

# All spender contracts that need approval
SPENDERS = [CTF_EXCHANGE, NEG_RISK_CTF_EXCHANGE, NEG_RISK_ADAPTER]

# V2 spenders that need pUSD approval.
# Order matters: [0..2] are the three spenders the V2 CLOB validates during order placement.
# [0] CTF_EXCHANGE_V2              — standard market orders
# [1] NEG_RISK_CTF_EXCHANGE_V2_A   — neg-risk market orders
# [2] NEG_RISK_ADAPTER (V1!)       — V2 neg-risk delegates settlement to V1 NRA, so the CLOB
#                                    requires pUSD allowance here even though it's a V1 contract.
#                                    Without this, every order fails with "not enough balance / allowance".
# [3] NEG_RISK_CTF_EXCHANGE_V2_B   — reserved variant
V2_SPENDERS = [
    CTF_EXCHANGE_V2,
    NEG_RISK_CTF_EXCHANGE_V2_A,
    NEG_RISK_ADAPTER,
    NEG_RISK_CTF_EXCHANGE_V2_B,
]

# PolyUSD wrapping contracts
POLY_USD = "0xc011a7e12a19f7b1f670d46f03b03f3342e82dfb"
COLLATERAL_ONRAMP = "0x93070a847efef7f70739046a929d47a521f5b8ee"
COLLATERAL_OFFRAMP = "0x2957922eb93258b93368531d39facca3b4dc5854"

# Fee Escrow
FEE_ESCROW_ADDRESS = "0xa11D28433B79D0A88F3119b16A090075752258EA"

# Metadata cache TTL (5 minutes)
META_TTL_SECONDS = 300
