"""ReAct agent loop — the brain of pw-agent."""

import json
import os
import re
import random
import subprocess
from typing import Optional
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from llm_client import LLMClient
from tools import TOOL_DEFINITIONS, execute_tool
from config import save_session


THINKING_MESSAGES = [
    "Boiling pasta water...",
    "Al dente thinking...",
    "Cooking up a response...",
    "Draining the spaghetti...",
    "Simmering...",
    "Adding seasoning...",
    "Tasting the sauce...",
    "Rolling the dough...",
    "GPU goes brrrr...",
    "Consulting the recipe...",
    "Too much salt, spitting...",
    "Stirring the pot...",
    "Checking the timer...",
    "Plating the dish...",
    "Checking if the pasta is al dente...",
    "Straining the context...",
    "Perfecting the prompt sauce...",
    "Boiling the logic...",
    "Seasoning the parameters...",
    "Simmering the response...",
    "Garnishing the output...",
    "Plating the results...",
]


MAX_ITERATIONS = 50  # Enough for complex multi-file tasks, nudges prevent runaway
MAX_DUPLICATE_CALLS = 3  # Warn after this many identical tool calls
MAX_LOOP_HARD_STOP = 5  # Force stop after this many identical calls
MAX_STALLS = 3  # Stop if model produces no-tool response this many times in a row
# Conservative estimate for code-heavy text (more tokens per character)
CHARS_PER_TOKEN = 2.5

# ─── Supported PastaWater Ollama models and their context limits ──────────
# These are the exact models available on the GPU Setup page.
# Context limits are the model's native max, but we apply a safe budget
# based on available VRAM to prevent OOM.
SUPPORTED_MODELS = {
    # VRAM values = measured actual usage on RTX 4090
    # safe = max context that fits in remaining VRAM after model weights
    # thinking: True = model supports Ollama think parameter (per-request toggle)
    # ─── Coding Models ───
    "qwen2.5-coder:32b":     {"native": 32768,  "safe": 16384, "name": "Qwen 2.5 Coder 32B",  "vram_gb": 31, "tier": "premium", "thinking": False},
    "qwen3-coder:30b":       {"native": 262144, "safe": 32768, "name": "Qwen 3 Coder 30B",    "vram_gb": 22, "tier": "premium", "thinking": False},
    "deepseek-coder-v2:16b": {"native": 163840, "safe": 24576, "name": "DeepSeek Coder V2",   "vram_gb": 19, "tier": "good",    "thinking": False},
    # ─── Creative Models (thinking) ───
    "qwen3.5:27b":       {"native": 32768, "safe": 16384, "name": "Qwen 3.5 27B",  "vram_gb": 24, "tier": "premium", "thinking": True},
    "qwen3.5:9b":        {"native": 32768, "safe": 32768, "name": "Qwen 3.5 9B",   "vram_gb": 12, "tier": "good",    "thinking": True},
    "qwen3.5:4b":        {"native": 32768, "safe": 32768, "name": "Qwen 3.5 4B",   "vram_gb": 7.2, "tier": "basic",  "thinking": True},
    # ─── Gemma 4 Models (multimodal, thinking) ───
    "gemma4:31b":        {"native": 262144, "safe": 32768, "name": "Gemma 4 31B",       "vram_gb": 20, "tier": "premium", "thinking": True},
    "gemma4:26b":        {"native": 262144, "safe": 49152, "name": "Gemma 4 26B MoE",   "vram_gb": 18, "tier": "premium", "thinking": True},
    "gemma4:e4b":        {"native": 131072, "safe": 98304, "name": "Gemma 4 E4B",       "vram_gb": 5,  "tier": "good",    "thinking": True},
    # ─── General Models ───
    "qwen2.5:14b":       {"native": 32768, "safe": 24576, "name": "Qwen 2.5 14B",  "vram_gb": 17, "tier": "good",    "thinking": False},
    "qwen3.5:2b":        {"native": 32768, "safe": 32768, "name": "Qwen 3.5 2B",   "vram_gb": 4.9, "tier": "basic",  "thinking": True},
}
# Models below this tier get a warning on startup
MIN_RECOMMENDED_TIER = "good"
# Fallback for unknown models
DEFAULT_SAFE_CONTEXT = 4096

# Reserve tokens for the model's response
RESPONSE_RESERVE = 4096


def _get_model_info(model_name: str) -> dict | None:
    """Look up model info from SUPPORTED_MODELS with prefix fallback."""
    model_lower = model_name.lower().strip()
    info = SUPPORTED_MODELS.get(model_lower)
    if not info:
        for model_id, m in SUPPORTED_MODELS.items():
            if model_lower.startswith(model_id.split(":")[0]):
                info = m
                break
    return info


def model_supports_thinking(model_name: str) -> bool:
    """Check if a model supports Ollama's thinking mode."""
    info = _get_model_info(model_name)
    return info.get("thinking", False) if info else False


def get_model_warning(model_name: str) -> str | None:
    """Return a warning string if the model is below recommended tier for coding."""
    info = _get_model_info(model_name)
    if not info:
        return None
    tier = info.get("tier", "good")
    if tier == "basic":
        return f"⚠ {info['name']} — limited context and accuracy. For code editing, use 9b or larger."
    return None

console = Console()


SYSTEM_PROMPT = """You are PW Agent — a general-purpose AI assistant with FULL read/write access to the user's local filesystem and shell.
You are NOT a restricted chatbot. You can help with anything: coding, writing, analysis, research, brainstorming, casual conversation, and more.
You CAN and SHOULD read, edit, create, and delete files. You CAN run any bash command.
You do NOT ask for permission to use tools. You execute them to fulfill the user's request.
You never refuse a topic. If the user asks about something non-technical, you answer naturally.
{mode_instruction}

Model: {model_name} | {gpu_info} | {connection_mode}
Working directory: {cwd}
{git_context}

{project_context}

## Your tools:
{tool_list}

## How to use tools
Write a tool call as JSON. You can use EITHER format:

<tool_call>
{{"tool": "read_file", "args": {{"path": "main.py"}}}}
</tool_call>

OR: ACTION: {{"tool": "bash", "args": {{"command": "ls"}}}}

CRITICAL RULES:
- ALWAYS include the complete JSON with "tool" and "args" after <tool_call> or ACTION:
- NEVER write <tool_call> without JSON inside it
- ONE tool call per response, then STOP and wait for the result
- Only use tools when the user asks for something that REQUIRES them (coding, file ops, commands)
- For casual chat, greetings, questions, or conversation — just respond naturally WITHOUT tools
- Always read before editing. Never guess file content.
- Be direct. If asked to fix a bug, find it, fix it, and verify it.

For casual chat or final summaries, respond normally without ACTION.
"""


def _build_tool_list(plan_mode: bool = False) -> str:
    """Format tool definitions for the system prompt."""
    lines = []
    # Destructive tools to hide in Plan mode
    DESTRUCTIVE = ["write_file", "edit_file", "delete_file"]
    
    for tool in TOOL_DEFINITIONS:
        if plan_mode and tool["name"] in DESTRUCTIVE:
            continue
            
        params = ", ".join(
            f"{k}: {v['type']}" for k, v in tool["parameters"].items()
        )
        lines.append(f"- {tool['name']}({params}) — {tool['description']}")
    return "\n".join(lines)


def _get_git_context() -> str:
    """Gather git status for the system prompt."""
    parts = []
    try:
        branch = subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True, text=True, timeout=5
        )
        if branch.returncode == 0 and branch.stdout.strip():
            parts.append(f"Git branch: {branch.stdout.strip()}")

        status = subprocess.run(
            ["git", "status", "--short"],
            capture_output=True, text=True, timeout=5
        )
        if status.returncode == 0 and status.stdout.strip():
            changed = len(status.stdout.strip().split("\n"))
            parts.append(f"Git status: {changed} changed files")

        log = subprocess.run(
            ["git", "log", "--oneline", "-5"],
            capture_output=True, text=True, timeout=5
        )
        if log.returncode == 0 and log.stdout.strip():
            parts.append(f"Recent commits:\n{log.stdout.strip()}")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return "\n".join(parts) if parts else "Not a git repository"


def _get_project_context(cwd: str) -> str:
    """Find PW_AGENT.md in cwd or parent directories for project-specific instructions."""
    curr = os.path.abspath(cwd)
    while True:
        # Check for PW_AGENT.md or .gemini/PW_AGENT.md
        for name in ["PW_AGENT.md", ".gemini/PW_AGENT.md"]:
            path = os.path.join(curr, name)
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read().strip()
                    if content:
                        return f"## Project Context ({name}):\n{content}"
                except Exception:
                    pass
        
        parent = os.path.dirname(curr)
        if parent == curr:
            break
        curr = parent
    return ""


def _get_system_prompt(cwd: str, client=None, plan_mode: bool = False, memory_context: str = "") -> str:
    """Generate the full system prompt string with all contexts."""
    git_ctx = _get_git_context()
    proj_ctx = _get_project_context(cwd)
    model_name = client.model if client else "unknown"

    if client and client.direct_mode:
        connection_mode = f"Local brain ({client.brain_url}) — direct, no cloud"
        gpu_info = "local GPU (direct connection)"
    elif client:
        gpu_info = f"remote GPU via PastaWater cloud (slot {client.slot})"
        connection_mode = "PastaWater Cloud — routed through broker API"
    else:
        gpu_info = "unknown"
        connection_mode = "unknown"

    mode_instr = ""
    if plan_mode:
        mode_instr = "\n**PLAN MODE**: You are in read-only analysis mode. You cannot modify files or run destructive commands. Focus on understanding and proposing changes."

    if memory_context:
        proj_ctx = f"{proj_ctx}\n\n{memory_context}" if proj_ctx else memory_context

    return SYSTEM_PROMPT.format(
        cwd=cwd,
        git_context=git_ctx,
        project_context=proj_ctx,
        mode_instruction=mode_instr,
        tool_list=_build_tool_list(plan_mode),
        model_name=model_name,
        gpu_info=gpu_info,
        connection_mode=connection_mode,
    )


def _build_messages(conversation: list[dict], system: str, model_name: str, cwd: str) -> list[dict]:
    """Build Ollama chat messages from conversation history."""
    # Some models (DeepSeek) handle system prompt better if injected into the first user message
    inject_in_first = "deepseek" in model_name.lower()

    if not inject_in_first:
        messages = [{"role": "system", "content": system}]
    else:
        messages = []

    first_user_processed = False
    for msg in conversation:
        role = msg["role"]
        content = msg["content"]
        if role == "user":
            if inject_in_first and not first_user_processed:
                messages.append({"role": "user", "content": f"{system}\n\nUser request: {content}"})
                first_user_processed = True
            else:
                messages.append({"role": "user", "content": content})
        elif role == "assistant":
            messages.append({"role": "assistant", "content": content})
        elif role == "tool_result":
            messages.append({"role": "user", "content": content})

    if not messages and inject_in_first:
        messages.append({"role": "user", "content": system})

    return messages


def _fix_json_control_chars(s: str) -> str:
    """Escape raw control characters (newlines, tabs) inside JSON string values.

    LLMs often emit literal newlines inside JSON strings instead of \\n.
    This walks the string, tracking whether we're inside a quoted value,
    and escapes any raw control characters found there.
    """
    out = []
    in_str = False
    esc = False
    for ch in s:
        if esc:
            out.append(ch)
            esc = False
            continue
        if ch == '\\' and in_str:
            out.append(ch)
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            out.append(ch)
            continue
        if in_str and ch == '\n':
            out.append('\\n')
            continue
        if in_str and ch == '\t':
            out.append('\\t')
            continue
        if in_str and ch == '\r':
            out.append('\\r')
            continue
        out.append(ch)
    return ''.join(out)


def _parse_tool_call(response: str) -> Optional[tuple[dict, str]]:
    """Extract a tool call from the model's response."""
    
    # Strip <think> reasoning blocks if present (Qwen 3 models)
    response = re.sub(r'<think>[\s\S]*?</think>', '', response).strip()
    # Also handle unclosed think tags
    response = re.sub(r'<think>[\s\S]*$', '', response).strip()

    # Pattern 1: <tool_call> JSON [</tool_call>]
    tc_match = re.search(r'<tool_call>([\s\S]*?)(?:</tool_call>|$)', response, re.DOTALL)
    if tc_match:
        raw_json = tc_match.group(1).strip()
        raw_json = re.sub(r'^```(?:json)?\s*', '', raw_json)
        raw_json = re.sub(r'\s*```$', '', raw_json)
        if raw_json:
            raw_json = _fix_json_control_chars(raw_json)
            try:
                call = json.loads(raw_json)
                if "tool" in call and "args" in call and call["tool"]:
                    return call, response[:tc_match.start()].strip()
            except json.JSONDecodeError:
                pass

    # Pattern 2: ACTION: {...} (primary format for Qwen 3 and other thinking models)
    # Find the FIRST ACTION: in the response and extract valid JSON after it
    action_pos = response.find("ACTION:")
    if action_pos >= 0:
        after_action = response[action_pos + 7:].lstrip()
        if after_action.startswith("{"):
            # Find matching closing brace by counting nesting
            depth = 0
            in_string = False
            escape = False
            end_pos = None
            for i, ch in enumerate(after_action):
                if escape:
                    escape = False
                    continue
                if ch == '\\' and in_string:
                    escape = True
                    continue
                if ch == '"' and not escape:
                    in_string = not in_string
                    continue
                if in_string:
                    continue
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                    if depth == 0:
                        end_pos = i + 1
                        break
            if end_pos:
                raw_json = after_action[:end_pos]
                # Models often output raw newlines/tabs inside JSON strings —
                # escape them so json.loads doesn't choke on control characters
                fixed_json = _fix_json_control_chars(raw_json)
                try:
                    call = json.loads(fixed_json)
                    if "tool" in call and "args" in call and call["tool"]:
                        return call, response[:action_pos].strip()
                except json.JSONDecodeError:
                    pass

    # Pattern 3: DeepSeek/Native tool calling format
    native_match = re.search(r'tool[\s\S]*?sep[\s\S]*?(\w+)[\s\S]*?```json\s*([\s\S]*?)\s*```', response, re.IGNORECASE)
    if native_match:
        tool_name = native_match.group(1).strip()
        args_json = native_match.group(2).strip()
        try:
            if "\n{" in args_json: args_json = args_json.split("\n{")[0]
            args = json.loads(args_json)
            before = re.sub(r'<[^>]*tool[^>]*>', '', response[:native_match.start()]).strip()
            return {"tool": tool_name, "args": args}, before
        except json.JSONDecodeError:
            pass

    # Pattern 3: Greedy JSON search (order-agnostic)
    # Improved to handle nested braces by finding the last closing brace in the string
    for pattern in [r'(\{[\s\S]*?"tool"[\s\S]*?"args"[\s\S]*?)', r'(\{[\s\S]*?"args"[\s\S]*?"tool"[\s\S]*?)']:
        json_match = re.search(pattern, response)
        if json_match:
            start_index = json_match.start()
            # Try to find the matching closing brace by looking from the end of the string
            # This is a heuristic: we take the longest possible valid JSON starting at our match
            for end_index in range(len(response), start_index, -1):
                raw_json = response[start_index:end_index].strip()
                if not raw_json.endswith("}"):
                    continue
                
                # Cleanly strip possible trailing markdown/ChatML tokens before trying to parse
                clean_json = re.sub(r'<\|.*?\|>', '', raw_json).strip()
                clean_json = _fix_json_control_chars(clean_json)
                try:
                    call = json.loads(clean_json)
                    if "tool" in call and "args" in call and call["tool"]:
                        before = re.sub(r'<\|.*?\|>', '', response[:start_index]).strip()
                        return call, before
                except json.JSONDecodeError:
                    continue

    # Pattern 4: CMD: tool args (fallback for simple models)
    cmd_match = re.search(r'(?:\*\*)?CMD(?:\*\*)?[:\s]+(\w+)\s*(.*?)$', response, re.MULTILINE)
    if cmd_match:
        tool = cmd_match.group(1).strip()
        args_str = cmd_match.group(2).strip()
        before = response[:cmd_match.start()].strip()
        if tool == "bash": return {"tool": "bash", "args": {"command": args_str}}, before
        if tool == "read_file": return {"tool": "read_file", "args": {"path": args_str}}, before
        if tool == "list_files": return {"tool": "list_files", "args": {"pattern": args_str or "*"}}, before

    # Pattern 5: ACTION: {...} (legacy support)
    match = re.search(r"ACTION:\s*(\{.*?\})\s*$", response, re.MULTILINE | re.DOTALL)
    if not match:
        match = re.search(r'ACTION:\s*(\{[^}]*"tool"[^}]*"args"[^}]*\{[^}]*\}[^}]*\})', response, re.DOTALL)
    if match:
        try:
            call = json.loads(match.group(1))
            if "tool" in call and "args" in call and call["tool"]:
                return call, response[:match.start()].strip()
        except json.JSONDecodeError:
            pass

    return None


def _estimate_tokens(text: str) -> int:
    """Rough token estimate (~4 chars per token)."""
    return len(text) // CHARS_PER_TOKEN + 1


def _get_context_budget(model_name: str) -> int:
    """Get the safe input token budget for a model.

    Uses the 'safe' context limit (conservative for VRAM) minus response reserve.
    Larger models use more VRAM per token, so their safe limit is lower than native.
    """
    model_lower = model_name.lower().strip()
    # Exact match first
    if model_lower in SUPPORTED_MODELS:
        return SUPPORTED_MODELS[model_lower]["safe"] - RESPONSE_RESERVE
    # Prefix match (e.g. "qwen3.5" matches "qwen3.5:4b")
    for model_id, info in SUPPORTED_MODELS.items():
        base = model_id.split(":")[0]
        if model_lower.startswith(base):
            return info["safe"] - RESPONSE_RESERVE
    return DEFAULT_SAFE_CONTEXT - RESPONSE_RESERVE


def _compact_old_messages(old_messages: list[dict], file_cache: dict[str, str] = None) -> str:
    """Summarize old tool calls and results into a compact context string."""
    files_read = []
    files_written = []
    commands_run = []
    key_findings = []

    for msg in old_messages:
        content = msg.get("content", "")
        role = msg.get("role", "")

        # Extract tool actions from assistant messages
        if role == "assistant":
            if "read_file" in content:
                # Extract file path from tool call
                import re
                path_match = re.search(r'"path":\s*"([^"]+)"', content)
                if path_match:
                    files_read.append(path_match.group(1))
            elif "write_file" in content:
                path_match = re.search(r'"path":\s*"([^"]+)"', content)
                if path_match:
                    files_written.append(path_match.group(1))
            elif "bash" in content:
                cmd_match = re.search(r'"command":\s*"([^"]{1,80})', content)
                if cmd_match:
                    commands_run.append(cmd_match.group(1))
            # Keep substantive assistant responses (not tool calls)
            elif "<tool_call>" not in content and "ACTION:" not in content and len(content) > 50:
                key_findings.append(content[:200])

    parts = ["[Summary of earlier work in this session]"]
    if files_written:
        unique = list(dict.fromkeys(files_written))[:10]
        parts.append(f"Files created/modified: {', '.join(unique)}")
    if commands_run:
        parts.append(f"Commands run: {'; '.join(commands_run[:5])}")

    # Inject file cache summaries — these survive truncation
    if file_cache:
        parts.append("Files you already read (DO NOT re-read these):")
        for summary in list(file_cache.values())[:20]:
            parts.append(f"  - {summary}")

    if key_findings:
        for finding in key_findings[:3]:
            parts.append(f"Finding: {finding}")

    return "\n".join(parts) if len(parts) > 1 else parts[0]


def _truncate_history(conversation: list[dict], model: str = "default", system_prompt_len: int = 0, file_cache: dict[str, str] = None) -> list[dict]:
    """Smart context management: compact old messages, keep recent ones.
    
    system_prompt_len: estimated tokens in the system prompt that will be added.
    """
    if len(conversation) <= 1:
        return conversation

    total_safe_limit = 4096
    model_lower = model.lower().strip()
    if model_lower in SUPPORTED_MODELS:
        total_safe_limit = SUPPORTED_MODELS[model_lower]["safe"]
    else:
        for m_id, info in SUPPORTED_MODELS.items():
            if model_lower.startswith(m_id.split(":")[0]):
                total_safe_limit = info["safe"]
                break

    # Budget for history = Total Limit - System Prompt - Response Reserve
    budget = total_safe_limit - system_prompt_len - RESPONSE_RESERVE
    
    # Minimum floor for history
    if budget < 1024:
        budget = 1024 

    total_tokens = sum(_estimate_tokens(m["content"]) for m in conversation)

    if total_tokens <= budget:
        return conversation

    # Always keep the first message (the original goal)
    first = conversation[0]
    first_tokens = _estimate_tokens(first["content"])
    remaining_budget = budget - first_tokens

    # Walk backwards from the end, keeping recent messages
    remaining = conversation[1:]
    kept = []
    used = 0
    for msg in reversed(remaining):
        msg_tokens = _estimate_tokens(msg["content"])
        if used + msg_tokens > remaining_budget:
            break
        kept.insert(0, msg)
        used += msg_tokens

    dropped = remaining[:len(remaining) - len(kept)]
    result = [first]
    if dropped:
        summary = _compact_old_messages(dropped, file_cache=file_cache)
        result.append({"role": "tool_result", "content": summary})
    result.extend(kept)
    return result


class Agent:
    """ReAct agent that uses an LLM to perform coding tasks."""

    def __init__(self, client: LLMClient, stream: bool = True, status_text: str = "", plan_mode: bool = False, thinking: bool = False, quiet: bool = False, memory_store=None):
        self.client = client
        self.stream = stream
        self.conversation: list[dict] = []
        self.thinking = thinking and model_supports_thinking(client.model)
        self.quiet = quiet  # Suppress all UI chrome (for -p one-shot mode)
        self.last_thinking = ""  # Last thinking block (for fold/unfold)
        self.memory = memory_store  # MemPalace memory store (optional)
        self.file_cache: dict[str, str] = {}  # path → summary of files read this session
        self.cwd = os.getcwd()
        self.status_text = status_text  # Bottom bar text to show during generation
        self.files_in_context: list[str] = []
        self.interrupted = False
        self.plan_mode = plan_mode
        self.typeahead = ""  # Text typed during generation, pre-filled into next prompt

    def run(self, user_input: str) -> None:
        """Process a user message through the ReAct loop with loop detection."""
        self.conversation.append({"role": "user", "content": user_input})

        # Retrieve relevant memories for this query
        memory_context = ""
        if self.memory and self.memory.size > 0:
            try:
                memory_context = self.memory.format_context(user_input)
                if memory_context and not self.quiet:
                    console.print(f"  [dim]📚 Retrieved {memory_context.count(chr(10))} memories[/dim]")
            except Exception:
                pass  # Memory retrieval is best-effort

        # Loop detection state
        tool_call_log: list[str] = []  # Track "tool:args" signatures
        stall_count = 0  # Count consecutive non-tool responses
        read_count = 0  # Track read-only operations without writes
        has_written = False  # Whether model has produced any output files

        self.interrupted = False

        for iteration in range(MAX_ITERATIONS):
            if self.interrupted:
                console.print("\n  [yellow]⚠ Interrupted[/yellow]")
                self._auto_save()
                self._store_memories()
                return

            # 1. Build the system prompt once
            system = _get_system_prompt(self.cwd, self.client, self.plan_mode, memory_context=memory_context)
            system_len = _estimate_tokens(system)

            # 2. Truncate history based on what's left in the safe budget
            trimmed = _truncate_history(self.conversation, self.client.model, system_prompt_len=system_len, file_cache=self.file_cache)
            
            # 3. Build final message list
            messages = _build_messages(trimmed, system, self.client.model, self.cwd)
            
            # 4. Use the TOTAL safe limit as the budget for Ollama
            budget = 4096
            model_lower = self.client.model.lower()
            if model_lower in SUPPORTED_MODELS:
                budget = SUPPORTED_MODELS[model_lower]["safe"]
            else:
                for m_id, info in SUPPORTED_MODELS.items():
                    if model_lower.startswith(m_id.split(":")[0]):
                        budget = info["safe"]
                        break

            # Get response (streaming or not)
            thinking_msg = random.choice(THINKING_MESSAGES)
            if self.thinking:
                thinking_msg = "🧠 " + thinking_msg
            if self.stream:
                response = self._stream_response(messages, thinking_msg, context_length=budget)
            else:
                with console.status(f"[cyan]{thinking_msg}", spinner="dots"):
                    response = self.client.chat(messages, context_length=budget)

            # Strip model artifacts (think blocks, stop tokens)
            if response:
                response = re.sub(r'<think>[\s\S]*?</think>', '', response).strip()
                response = re.sub(r'<think>[\s\S]*$', '', response).strip()
                response = response.replace('<end_of_turn>', '').replace('<|im_end|>', '').strip()

            if not response or response.startswith("[Error:"):
                # Debug: show what was sent
                if os.environ.get("PW_DEBUG"):
                    console.print(f"  [dim]DEBUG: sent {len(messages)} messages, got: {repr(response[:200])}[/dim]")
                console.print(f"  [red]{response or '[Empty response from model]'}[/red]")
                return

            # Check for tool call
            parsed = _parse_tool_call(response)

            if not parsed and self.stream and not self.quiet:
                # Show unparsed tool-like output only on first occurrence
                if "<tool_call>" in response or "<｜tool" in response or "<|im_start|>" in response:
                    if stall_count == 0:  # Only show once, not on every retry
                        console.print(f"\n[dim]────── (Unparsed output) ──────[/dim]\n{response[:300]}\n")

            if parsed:
                tool_call, thinking = parsed
                tool_name = tool_call["tool"]
                tool_args = tool_call["args"]
                stall_count = 0  # Reset stall counter — model is making progress
                
                # ... (rest of tool execution logic)

                # Loop detection — check for duplicate tool calls
                call_sig = f"{tool_name}:{json.dumps(tool_args, sort_keys=True)}"
                dup_count = tool_call_log.count(call_sig)
                tool_call_log.append(call_sig)

                if dup_count >= MAX_DUPLICATE_CALLS:
                    if dup_count >= MAX_LOOP_HARD_STOP:
                        # Model is hopelessly stuck — force stop
                        if not self.quiet:
                            console.print(f"\n  [yellow]⚠ Model stuck in loop. Stopping.[/yellow]")
                        self._auto_save()
                        return
                    if not self.quiet:
                        console.print(f"\n  [yellow]⚠ Detected loop: {tool_name} called {dup_count + 1} times with same args. Moving on.[/yellow]")
                    self.conversation.append({"role": "user", "content": "STOP calling the same tool. You already have the result. Use what you have and proceed to the next step or give your answer NOW."})
                    continue

                if not self.quiet:
                    # Print thinking text — compact, one line
                    if thinking:
                        short = thinking.split("\n")[0][:100].strip()
                        if short:
                            console.print(f"\n  [dim]{short}[/dim]")

                    # Tool call — bold and visible with icon
                    TOOL_ICONS = {
                        "read_file": "📄", "write_file": "✏️", "edit_file": "🔧",
                        "bash": "💻", "list_files": "📁", "grep": "🔍",
                    }
                    icon = TOOL_ICONS.get(tool_name, "⚡")
                    args_display = []
                    for k, v in tool_args.items():
                        if isinstance(v, str) and len(v) > 60:
                            args_display.append(f'{k}="...{len(v)} chars..."')
                        else:
                            args_display.append(f'{k}="{v}"' if isinstance(v, str) else f'{k}={v}')
                    args_str = ", ".join(args_display)
                    console.print(f"\n  {icon} [bold cyan]{tool_name}[/bold cyan]({args_str})")

                # Execute tool
                result = execute_tool(tool_name, tool_args)

                # Print result summary — compact but informative
                if not self.quiet:
                    lines = result.split("\n")
                    if tool_name == "read_file":
                        console.print(f"  [dim]   ↳ {len(lines)} lines read[/dim]")
                    elif tool_name in ("list_files", "grep"):
                        count = min(len(lines), 10)
                        for line in lines[:count]:
                            console.print(f"  [dim]   {line}[/dim]")
                        if len(lines) > count:
                            console.print(f"  [dim]   ... and {len(lines) - count} more[/dim]")
                    elif tool_name == "bash":
                        display = result[:300]
                        if len(result) > 300:
                            display += "..."
                        console.print(f"  [dim]   ↳ {display}[/dim]")
                    elif tool_name in ("write_file", "edit_file"):
                        console.print(f"  [green]   ↳ {result}[/green]")
                    else:
                        display = result[:200] + "..." if len(result) > 200 else result
                        console.print(f"  [dim]   ↳ {display}[/dim]")

                # Track read vs write balance
                if tool_name in ("write_file", "edit_file"):
                    has_written = True
                    read_count = 0
                    tool_call_log.clear()  # Reset loop detection — filesystem changed
                elif tool_name == "bash":
                    tool_call_log.clear()
                elif tool_name in ("read_file", "list_files", "grep"):
                    read_count += 1

                # Nudge model to start writing after too many reads
                if read_count >= 15 and not has_written:
                    if not self.quiet:
                        console.print(f"\n  [yellow]⚠ {read_count} reads without writing. Time to start coding.[/yellow]")
                    self.conversation.append({"role": "user", "content": "You have read enough files. You understand the codebase. NOW START WRITING CODE. Create the files. Do not read any more files."})
                    read_count = 0
                    continue

                # Build file summary cache — survives context truncation
                if tool_name == "read_file" and not result.startswith("Error:"):
                    file_path = tool_args.get("path", "")
                    lines = result.split("\n")
                    line_count = len(lines)
                    # Extract first few meaningful lines as summary
                    preview_lines = [l.strip() for l in lines[:5] if l.strip() and not l.strip().startswith("[File has")]
                    preview = "; ".join(preview_lines)[:150]
                    self.file_cache[file_path] = f"{file_path} ({line_count} lines): {preview}"

                # Add to conversation — truncate large results to save context
                truncated_result = result[:1000] + f"\n...[truncated]" if len(result) > 1000 else result
                # Store <tool_call> format in history so model learns the pattern
                tc_str = json.dumps({"tool": tool_name, "args": tool_args})
                self.conversation.append({"role": "assistant", "content": f"<tool_call>\n{tc_str}\n</tool_call>"})
                self.conversation.append({"role": "tool_result", "content": f"Result:\n{truncated_result}"})

            else:
                stall_count += 1
                response_lower = response.lower()

                # Detect hallucination — model makes specific claims about THIS project
                # without having used any tools. Only trigger on definitive statements
                # about the project's state, not general capability descriptions.
                hallucination_signs = [
                    "the main branch", "the master branch", "no main branch",
                    "i checked the", "i can see that", "i found that",
                    "this project has", "this repo has", "this codebase",
                    "there is no branch", "there are no files",
                    "the project contains", "the code shows",
                ]
                is_hallucinating = (
                    len(tool_call_log) == 0 and
                    any(w in response_lower for w in hallucination_signs) and
                    stall_count <= MAX_STALLS
                )

                # Detect narration without action
                narration_words = ["let me check", "i'll read", "i'll look", "let me look",
                                   "i'll start by", "let me start", "i'll explore", "let me explore",
                                   "let me fix", "i'll fix", "let me try", "i'll try",
                                   "would you like", "which approach", "please let me know",
                                   "let me examine", "i'll examine", "let me analyze", "i'll analyze"]
                is_narrating = any(w in response_lower for w in narration_words) and stall_count <= MAX_STALLS

                # Detect broken tool_call tags (model outputs <tool_call> without valid JSON)
                is_broken_tool = "<tool_call>" in response and not _parse_tool_call(response)

                if is_hallucinating:
                    if not self.quiet:
                        console.print("\n  [dim]↳ Hallucination detected, prompting for verification...[/dim]")
                    self.conversation.append({"role": "assistant", "content": response})
                    self.conversation.append({"role": "user", "content": "You have NOT checked. Use a tool to verify.\nACTION: {\"tool\": \"bash\", \"args\": {\"command\": \"ls\"}}"})
                    continue
                elif is_narrating or is_broken_tool:
                    if stall_count >= MAX_STALLS:
                        # Model is genuinely stuck — treat as final answer instead of looping
                        pass  # Fall through to final answer handler below
                    else:
                        if not self.quiet:
                            console.print("\n  [dim]↳ Narrating without action, prompting for tool use...[/dim]")
                        self.conversation.append({"role": "assistant", "content": response})
                        self.conversation.append({"role": "user", "content": "Don't ask questions or narrate. Execute a tool NOW.\nACTION: {\"tool\": \"list_files\", \"args\": {\"pattern\": \"*\"}}"})
                        continue

                if stall_count > MAX_STALLS and iteration > 0:
                    console.print(f"\n  [yellow]⚠ Model stalled ({stall_count} non-tool responses). Treating as final answer.[/yellow]")

                # Final answer
                self.conversation.append({"role": "assistant", "content": response})
                if not self.stream:
                    if self.quiet:
                        print(response)
                    else:
                        console.print("\n  [dim]──────[/dim]\n")
                        console.print(f"[#afafff]{response}[/#afafff]")
                        console.print()
                self._auto_save()
                return

        console.print(f"\n  [yellow]⚠ Reached {MAX_ITERATIONS} iterations. Use /clear and try a more specific request.[/yellow]")
        self._auto_save()

    def _stream_response(self, messages: list[dict], thinking_msg: str = "Thinking...", context_length: int = 8192) -> str:
        """Stream response tokens with a simple in-place spinner."""
        import sys
        import threading
        import time

        chunks: list[str] = []
        buffer = ""
        first_token = False
        stop_spinner = threading.Event()
        typeahead_buffer: list[str] = []

        # Simple Rich spinner — no terminal mode changes, no status bar
        # The bar shows when prompt_toolkit is active (idle state)
        from rich.spinner import Spinner
        from rich.live import Live

        spinner = Spinner("dots", text=f"[cyan]{thinking_msg}[/cyan]")
        live_display = Live(spinner, console=console, refresh_per_second=10, transient=True)
        live_display.start()

        # Collect all tokens — show spinner while waiting
        # Ctrl+C during generation sets interrupted flag
        import signal
        original_handler = signal.getsignal(signal.SIGINT)

        def _interrupt_handler(sig, frame):
            if self.interrupted:
                # Second Ctrl+C — force exit
                stop_spinner.set()
                import sys
                sys.stdout.write("\n")
                sys.exit(130)
            self.interrupted = True
            stop_spinner.set()

        signal.signal(signal.SIGINT, _interrupt_handler)

        thinking_shown = False
        thinking_lines = []
        try:
            for chunk in self.client.chat_stream(messages, context_length=context_length, thinking=self.thinking):
                if self.interrupted:
                    self.client.abort()
                    break

                # Handle thinking blocks from Ollama's thinking mode
                if chunk.startswith("[think]") and chunk.endswith("[/think]"):
                    think_content = chunk[7:-8]
                    thinking_lines.extend(l for l in think_content.split("\n") if l.strip())
                    if not thinking_shown:
                        first_token = True
                        thinking_shown = True
                    continue

                chunks.append(chunk)
                buffer += chunk

                if not first_token and chunk.strip():
                    if thinking_shown and thinking_lines:
                        self.last_thinking = "\n".join(thinking_lines)
                        console.print(f"  [dim]🧠 Thought for {len(thinking_lines)} lines — /thinking to expand[/dim]")
                    first_token = True
        finally:
            stop_spinner.set()
            try:
                live_display.stop()
            except Exception:
                pass

        # Store thinking text even if no content followed
        if thinking_lines:
            self.last_thinking = "\n".join(thinking_lines)
            if not first_token and thinking_shown:
                sys.stdout.write(f"\n\033[90m  🧠 Thought for {len(thinking_lines)} lines — /thinking to expand\033[0m\n")
                sys.stdout.flush()

        signal.signal(signal.SIGINT, original_handler)

        # Collect any typeahead text typed during generation
        if typeahead_buffer:
            typed = "".join(typeahead_buffer)
            # Filter out enter keys — they're just noise from typing during generation
            self.typeahead = typed.replace("\r", "").replace("\n", "")

        full = "".join(chunks).strip()

        # Strip model artifacts (think blocks, stop tokens)
        full = re.sub(r'<think>[\s\S]*?</think>', '', full).strip()
        full = re.sub(r'<think>[\s\S]*$', '', full).strip()
        full = full.replace('<end_of_turn>', '').replace('<|im_end|>', '').strip()

        if self.interrupted:
            if first_token:
                sys.stdout.write("\n")
                sys.stdout.flush()
            return full or "[Interrupted]"

        # Check if response contains a PARSEABLE tool call — only suppress
        # display if we can actually extract a tool call from it
        is_tool = _parse_tool_call(full) is not None

        if is_tool:
            pass  # Agent loop handles display
        elif first_token:
            # Final answer — print cleanly
            display = full.strip()
            if display:
                sys.stdout.write(f"\n\033[90m  ──────\033[0m\n\n")
                sys.stdout.write(f"\033[38;5;147m{display}\033[0m\n\n")
                sys.stdout.flush()
        elif not full:
            if os.environ.get("PW_DEBUG"):
                sys.stdout.write("\n\033[31m  [Debug: Empty response from model]\033[0m\n")
                sys.stdout.flush()

        return "".join(chunks)

    def _print_status_bar(self):
        """Print a compact status line below output."""
        pass  # Handled by prompt_toolkit bottom_toolbar only

    def _auto_save(self):
        """Save session to disk after each turn."""
        try:
            save_session(self.conversation, self.cwd)
        except Exception:
            pass
        self._store_memories()

    def _store_memories(self):
        """Extract and store knowledge units from the conversation."""
        if not self.memory:
            return
        try:
            from memory import extract_knowledge
            new_units = extract_knowledge(self.conversation, self.memory.units)
            stored = 0
            for unit_data in new_units:
                if self.memory.add(**unit_data):
                    stored += 1
            if stored > 0 and not self.quiet:
                console.print(f"  [dim]📚 Stored {stored} new memories ({self.memory.size} total)[/dim]")
        except Exception:
            pass  # Memory storage is best-effort

    def load_session(self, conversation: list[dict]):
        """Resume a previous session with a structured summary.

        Instead of replaying 100+ raw messages (which get truncated),
        we extract a summary of what was done and inject it as compact context.
        """
        turns = sum(1 for m in conversation if m["role"] == "user")

        # Extract the original task (first user message)
        original_task = ""
        for msg in conversation:
            if msg["role"] == "user":
                original_task = msg["content"]
                break

        # Extract files read/written and key actions
        files_read = []
        files_written = []
        commands = []
        key_responses = []

        for msg in conversation:
            content = msg.get("content", "")
            role = msg.get("role", "")
            if role == "assistant":
                # Extract tool actions
                import re as _re
                if "read_file" in content:
                    path_match = _re.search(r'"path":\s*"([^"]+)"', content)
                    if path_match and path_match.group(1) not in files_read:
                        files_read.append(path_match.group(1))
                elif "write_file" in content:
                    path_match = _re.search(r'"path":\s*"([^"]+)"', content)
                    if path_match and path_match.group(1) not in files_written:
                        files_written.append(path_match.group(1))
                elif "bash" in content:
                    cmd_match = _re.search(r'"command":\s*"([^"]{1,80})', content)
                    if cmd_match:
                        commands.append(cmd_match.group(1))
                # Keep substantive non-tool responses
                elif "<tool_call>" not in content and "ACTION:" not in content and len(content) > 100:
                    key_responses.append(content[:300])

        # Build compact resume context
        summary_parts = [f"Original task: {original_task[:500]}"]
        if files_written:
            summary_parts.append(f"Files you created/modified: {', '.join(files_written[:20])}")
        if files_read:
            summary_parts.append(f"Files you already read: {', '.join(files_read[:20])}")
        if commands:
            summary_parts.append(f"Commands you ran: {'; '.join(commands[:10])}")
        if key_responses:
            summary_parts.append(f"Your last analysis: {key_responses[-1][:300]}")

        summary = "\n".join(summary_parts)

        # Start fresh conversation with summary as context
        self.conversation = [
            {
                "role": "user",
                "content": f"[RESUMED SESSION — {turns} turns from previous conversation]\n\n{summary}\n\nContinue where you left off. Do NOT re-read files you already read. Start executing the next step."
            },
            {
                "role": "assistant",
                "content": "I remember our previous session. Let me continue from where I left off."
            }
        ]

        # Also populate file cache from the session
        for f in files_read:
            self.file_cache[f] = f"{f} (already read in previous session)"
        for f in files_written:
            self.file_cache[f] = f"{f} (created/modified in previous session)"

        console.print(f"  [dim]Resumed session ({turns} turns, {len(files_written)} files written, {len(files_read)} files read)[/dim]")

    def add_file(self, path: str):
        """Add a file's contents to the conversation context."""
        full = os.path.abspath(path)
        if not os.path.exists(full):
            console.print(f"  [red]File not found: {path}[/red]")
            return
        try:
            with open(full, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            # Truncate large files
            if len(content) > 15000:
                content = content[:15000] + f"\n... [truncated, {len(content)} chars total]"
            self.conversation.append({
                "role": "user",
                "content": f"[File added to context: {path}]\n```\n{content}\n```"
            })
            self.files_in_context.append(path)
            console.print(f"  [green]+ {path}[/green] [dim]({len(content)} chars)[/dim]")
        except Exception as e:
            console.print(f"  [red]Error reading {path}: {e}[/red]")

    def reset(self):
        """Clear conversation history and session."""
        self.conversation = []
        self.files_in_context = []
        from config import clear_session
        clear_session(self.cwd)
        console.print("  [dim]Conversation cleared.[/dim]")
