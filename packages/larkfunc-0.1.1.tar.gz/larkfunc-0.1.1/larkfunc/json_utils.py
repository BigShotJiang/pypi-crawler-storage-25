"""
larkfunc.json_utils - JSON 处理工具模块

提供安全的 JSON 解析功能，避免因格式错误导致程序崩溃。
"""

import json


def parse_json_safely(json_str: str) -> dict:
    """
    安全解析 JSON 字符串，解析失败时返回空字典而非抛出异常。

    适用于处理来源不可控的 JSON 数据（如 LLM 输出、外部 API 响应等），
    避免因格式问题导致程序中断。

    Args:
        json_str (str): 待解析的 JSON 格式字符串。

    Returns:
        dict: 解析成功返回对应的字典；解析失败返回空字典 {}。

    Raises:
        无异常抛出，解析失败时打印错误信息并返回空字典。

    Note:
        若需小心处理 LLM 返回内容，建议先调用 clean_llm_response() 去除代码块标记再传入本函数。
        返回空字典 {} 而非 None，方便直接调用 dict 方法而无需先检查 None。

    Example:
        >>> parse_json_safely('{"name": "lark", "version": 1}')
        {'name': 'lark', 'version': 1}
        >>> parse_json_safely('invalid json')
        {}
    """
    try:
        return json.loads(json_str)
    except json.JSONDecodeError as e:
        print(f"[ERROR] JSON 解析失败: {e}")
        print(f"原始内容: {json_str[:200]}...")
        return {}
