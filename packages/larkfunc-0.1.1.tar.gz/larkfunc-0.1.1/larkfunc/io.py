"""
larkfunc.io - 文件读写工具模块

提供常用的文件读取、写入和目录管理功能。
"""

import os
import json
from typing import Optional, List


def read_txt_data(filepath: str) -> Optional[str]:
    """
    读取文本文件的全部内容并返回字符串。

    Args:
        filepath (str): 文本文件的路径（支持相对路径和绝对路径）。

    Returns:
        Optional[str]: 文件内容字符串；若读取失败则返回 None。

    Raises:
        无异常抛出，错误信息通过 print 输出。

    Example:
        >>> content = read_txt_data("data/sample.txt")
        >>> if content:
        ...     print(content[:100])
    """
    try:
        with open(filepath, 'r', encoding='utf8') as f:
            return f.read()
    except FileNotFoundError:
        print(f"[ERROR] 文件未找到: {filepath}")
        return None
    except Exception as e:
        print(f"[ERROR] 读取文件时发生错误: {e}")
        return None


def read_txt_to_list(filepath: str) -> List[str]:
    """
    读取文本文件，将每一行作为列表元素返回（自动去除首尾空白）。

    Args:
        filepath (str): 文本文件的路径。

    Returns:
        List[str]: 每行内容组成的列表；若读取失败则返回空列表。

    Raises:
        无异常抛出，错误信息通过 print 输出。

    Note:
        空行也会被保留为空字符串（strip 后），可根据需要用
        list comprehension 过滤：[l for l in lines if l]

    Example:
        >>> lines = read_txt_to_list("urls.txt")
        >>> for line in lines:
        ...     print(line)
    """
    try:
        with open(filepath, 'r', encoding='utf8') as f:
            return [line.strip() for line in f]
    except FileNotFoundError:
        print(f"[ERROR] 文件未找到: {filepath}")
        return []
    except Exception as e:
        print(f"[ERROR] 读取文件时发生错误: {e}")
        return []


def save_json_to_file(data: dict, output_path: str) -> bool:
    """
    将字典数据保存为格式化的 JSON 文件。

    Args:
        data (dict): 要保存的字典数据。
        output_path (str): 输出文件路径。

    Returns:
        bool: 保存成功返回 True，失败返回 False。

    Raises:
        无异常抛出，错误信息通过 print 输出。

    Note:
        输出文件使用 UTF-8 编码，中文字符可正常保存（ensure_ascii=False）。
        JSON 格式为 indent=2 的美化输出，便于人工阅读。

    Example:
        >>> result = save_json_to_file({"name": "lark"}, "output.json")
        >>> print(result)  # True
    """
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"[SUCCESS] JSON 已保存: {output_path}")
        return True
    except Exception as e:
        print(f"[ERROR] 保存文件失败 {output_path}: {e}")
        return False


def ensure_directory_exists(path: str) -> None:
    """
    确保指定目录存在，若不存在则自动创建（支持多级目录）。

    Args:
        path (str): 目录路径。

    Returns:
        None

    Raises:
        无异常抛出，目录已存在时静默跳过。

    Note:
        等价于 os.makedirs(path, exist_ok=True)，但会额外打印创建信息。
        适用于在写文件前预先保证目录存在。

    Example:
        >>> ensure_directory_exists("output/reports/2024")
    """
    if not os.path.exists(path):
        os.makedirs(path)
        print(f"[INFO] 目录已创建: {path}")
