"""
larkfunc.llm - LLM 调用工具模块

提供带重试机制的 LLM 调用封装，适用于需要可靠调用大语言模型的场景。
"""

from typing import Callable, Optional


def call_llm_with_retry(
    content: str,
    prompt_template: str,
    chat_func: Callable[[str], str],
    max_retries: int = 3
) -> str:
    """
    调用 LLM 并支持自动重试机制。

    将 content 与 prompt_template 拼接后传入 chat_func 调用 LLM，
    若调用失败或返回无效结果，会自动重试直到达到最大次数。

    Args:
        content (str): 输入文本内容（如简历、文章等）。
        prompt_template (str): 提示词模板，将拼接在 content 之后。
        chat_func (Callable[[str], str]): LLM 调用函数，接收字符串参数并返回字符串。
            用户需自行提供此函数的实现，例如 OpenAI API 的封装。
        max_retries (int): 最大重试次数，默认为 3。

    Returns:
        str: LLM 返回的原始文本；若所有重试均失败则返回空字符串。

    Example:
        >>> def my_chat(prompt: str) -> str:
        ...     # 你的 LLM 调用实现
        ...     return "LLM 的回复"
        >>> result = call_llm_with_retry(
        ...     content="这是一份简历...",
        ...     prompt_template="请提取关键信息：",
        ...     chat_func=my_chat,
        ...     max_retries=3
        ... )
    """
    full_prompt = content + prompt_template

    for attempt in range(max_retries):
        try:
            print(f"[INFO] 正在调用 LLM（第 {attempt + 1}/{max_retries} 次尝试）...")
            response = chat_func(full_prompt)
            if response and isinstance(response, str):
                print(f"[INFO] LLM 调用成功，返回长度: {len(response)}")
                return response
            else:
                print(f"[WARNING] LLM 返回无效（空或非字符串）")
        except Exception as e:
            print(f"[ERROR] LLM 调用失败（第 {attempt + 1} 次）: {e}")

        if attempt == max_retries - 1:
            print(f"[FATAL] LLM 调用失败，已达到最大重试次数 {max_retries}")
            return ""

    return ""
