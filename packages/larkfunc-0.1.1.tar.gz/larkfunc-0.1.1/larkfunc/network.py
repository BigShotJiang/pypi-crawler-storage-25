"""
larkfunc.network - 网络请求工具模块

提供 HTTP 响应内容的解码与处理功能。
"""

from typing import Optional


def decode_response_content(response) -> Optional[str]:
    """
    将 HTTP 响应对象的二进制内容解码为 UTF-8 字符串。

    适用于处理 requests 库返回的 Response 对象，
    当响应编码不确定时，使用 'replace' 策略处理无法解码的字符。

    Args:
        response: requests.Response 对象或任何具有 .content 属性的对象。

    Returns:
        Optional[str]: 解码后的字符串；解码失败时返回 None。

    Raises:
        无异常抛出，解码失败时错误信息通过 print 输出并返回 None。
        注意：若 response 对象无 .content 属性，则会抛出 AttributeError。

    Note:
        使用 errors='replace' 策略，无法解码的字节会被替换为 U+FFFD (�)，
        而非抛出异常，适合对网页内容进行尺尺解析而非严格要求完整性的场景。

    Example:
        >>> import requests
        >>> resp = requests.get("https://example.com")
        >>> text = decode_response_content(resp)
        >>> print(text[:100])
    """
    try:
        return response.content.decode('utf-8', errors='replace')
    except UnicodeDecodeError as e:
        print(f"[ERROR] 解码失败: {e}")
        return None
