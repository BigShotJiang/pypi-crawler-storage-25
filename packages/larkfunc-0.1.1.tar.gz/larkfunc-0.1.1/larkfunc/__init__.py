"""
larkfunc - 实用 Python 函数工具库

一个轻量级的 Python 工具函数集合，涵盖文件读写、文本处理、JSON 解析、
网络响应处理和 LLM 调用等常见场景，帮助你快速构建数据处理流水线。

基本用法::

    from larkfunc import read_txt_data, parse_json_safely, clean_llm_response

子模块用法::

    from larkfunc.io import save_json_to_file
    from larkfunc.text import extract_linkedin_id
    from larkfunc.llm import call_llm_with_retry
"""

__version__ = "0.1.0"
__author__ = "lark"

# 子模块与函数映射表（为 help_doc 提供元数据）
_MODULE_MAP = {
    "io": [
        "read_txt_data",
        "read_txt_to_list",
        "save_json_to_file",
        "ensure_directory_exists",
    ],
    "text": [
        "clean_llm_response",
        "extract_filename_without_extension",
        "extract_linkedin_id",
    ],
    "network": [
        "decode_response_content",
    ],
    "json_utils": [
        "parse_json_safely",
    ],
    "llm": [
        "call_llm_with_retry",
    ],
}

# === 文件读写 (io) ===
from larkfunc.io import (
    read_txt_data,
    read_txt_to_list,
    save_json_to_file,
    ensure_directory_exists,
)

# === 文本处理 (text) ===
from larkfunc.text import (
    clean_llm_response,
    extract_filename_without_extension,
    extract_linkedin_id,
)

# === 网络请求 (network) ===
from larkfunc.network import (
    decode_response_content,
)

# === JSON 处理 (json_utils) ===
from larkfunc.json_utils import (
    parse_json_safely,
)

# === LLM 调用 (llm) ===
from larkfunc.llm import (
    call_llm_with_retry,
)

__all__ = [
    # io
    "read_txt_data",
    "read_txt_to_list",
    "save_json_to_file",
    "ensure_directory_exists",
    # text
    "clean_llm_response",
    "extract_filename_without_extension",
    "extract_linkedin_id",
    # network
    "decode_response_content",
    # json_utils
    "parse_json_safely",
    # llm
    "call_llm_with_retry",
]


def help_doc(func_name: str = None) -> None:
    """
    显示 larkfunc 函数的帮助文档。

    不传参数时打印所有可用函数的概览（按子模块分组）；
    传入函数名时打印该函数的完整 docstring 。

    Args:
        func_name (str, optional): 要查询的函数名称字符串，不传则显示所有函数列表。

    Returns:
        None

    Raises:
        函数名不存在时打印错误提示，不抛出异常。

    Example:
        >>> import larkfunc
        >>> larkfunc.help_doc()                      # 查看所有函数概览
        >>> larkfunc.help_doc("read_txt_data")       # 查看指定函数详情
        >>> larkfunc.help_doc("parse_json_safely")   # 查看 JSON 解析函数详情
    """
    import inspect
    import larkfunc as _self

    if func_name is None:
        # 显示所有函数概览
        print(f"larkfunc v{__version__} 函数列表")
        print("=" * 50)
        for module, funcs in _MODULE_MAP.items():
            print(f"\n[子模块] larkfunc.{module}")
            for fname in funcs:
                fn = getattr(_self, fname, None)
                if fn:
                    first_line = (fn.__doc__ or "").strip().splitlines()[0]
                    print(f"  {fname:40s} - {first_line}")
        print("\n查看函数详情： larkfunc.help_doc('<函数名>')")
        print("或直接使用： help(larkfunc.<函数名>)")
    else:
        fn = getattr(_self, func_name, None)
        if fn is None:
            print(f"[ERROR] 函数 '{func_name}' 不存在。")
            print(f"可用函数：{', '.join(__all__)}")
            return
        print(f"larkfunc.{func_name}")
        print("=" * 50)
        print(f"定义位置： larkfunc.{_MODULE_MAP_REVERSE.get(func_name, '?')}")
        print(inspect.signature(fn))
        print()
        print(fn.__doc__ or "暂无文档")


# 函数名 → 子模块 反查表（为 help_doc 内部使用）
_MODULE_MAP_REVERSE = {
    fname: module
    for module, funcs in _MODULE_MAP.items()
    for fname in funcs
}
