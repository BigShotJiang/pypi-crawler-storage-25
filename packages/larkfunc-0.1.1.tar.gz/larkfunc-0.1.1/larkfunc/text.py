"""
larkfunc.text - 文本处理工具模块

提供文本清理、路径解析和 URL 信息提取等功能。
"""

import os


def clean_llm_response(response: str) -> str:
    """
    清理 LLM 返回的响应文本，移除常见的 Markdown 代码块标记。

    常见场景：LLM 返回 JSON 时可能被包裹在 ```json ... ``` 中，
    此函数可自动去除这些标记，返回纯净内容。

    Args:
        response (str): LLM 原始返回文本。

    Returns:
        str: 清理后的纯文本内容。
    
    Raises:
        无异常抛出，输入不含代码块标记时返回原字符串。
    
    Note:
        仅移除开头和结尾的 ```json 和 ``` 标记，不修改内容中间的任何内容。
        建议配合 parse_json_safely() 一起使用：clean_llm_response 先清理再解析。
    
    Example:
        >>> raw = '```json\n{"name": "lark"}\n```'
        >>> clean_llm_response(raw)
        '{"name": "lark"}'
    """
    cleaned = response.strip()
    if cleaned.startswith("```json"):
        cleaned = cleaned[7:].strip()
    if cleaned.startswith("```"):
        cleaned = cleaned[3:].strip()
    if cleaned.endswith("```"):
        cleaned = cleaned[:-3].strip()
    return cleaned


def extract_filename_without_extension(filepath: str) -> str:
    """
    从文件路径中提取不带扩展名的文件名。

    Args:
        filepath (str): 文件的完整路径或相对路径。

    Returns:
        str: 不含扩展名的文件名。

    Raises:
        无异常抛出，传入空字符串时返回空字符串。

    Note:
        只去掉最后一个扩展名，外如 "archive.tar.gz" 返回 "archive.tar"。
        若需完全去除所有扩展名，请循环调用本函数。

    Example:
        >>> extract_filename_without_extension("/data/reports/summary.pdf")
        'summary'
        >>> extract_filename_without_extension("archive.tar.gz")
        'archive.tar'
    """
    return os.path.splitext(os.path.basename(filepath))[0]


def extract_linkedin_id(url: str) -> str:
    """
    从 LinkedIn 个人主页 URL 中提取用户 ID。

    支持以 '/' 结尾或不以 '/' 结尾的 URL 格式。

    Args:
        url (str): LinkedIn 个人主页的完整 URL。
            例如: "https://www.linkedin.com/in/johndoe/"

    Returns:
        str: 提取出的 LinkedIn 用户 ID。

    Raises:
        ValueError: 当 URL 格式不正确或无法提取 ID 时抛出。

    Example:
        >>> extract_linkedin_id("https://www.linkedin.com/in/johndoe/")
        'johndoe'
        >>> extract_linkedin_id("https://www.linkedin.com/in/janedoe")
        'janedoe'
    """
    try:
        if url.endswith('/'):
            url = url[:-1]
        linkedin_id = url.split('/')[-1]
        if not linkedin_id:
            raise ValueError("无法从 URL 中提取有效的 linkedin_id，请检查 URL 是否正确。")
        return linkedin_id
    except Exception as e:
        print(f"[ERROR] 提取 linkedin_id 时发生错误: {e}")
        raise ValueError("无法从 URL 中提取 linkedin_id，请检查 URL 的合法性。")
