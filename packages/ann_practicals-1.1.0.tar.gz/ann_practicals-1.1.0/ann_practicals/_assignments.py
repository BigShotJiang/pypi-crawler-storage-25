ASSIGNMENTS = {
    1: {
        "title": "Plot activation functions (Sigmoid, ReLU, Tanh) using a Neuron class",
        "code": '''\
import numpy as np
import matplotlib.pyplot as plt

class Neuron:
    def __init__(self, weights, bias, activation):
        self.weights = np.array(weights)
        self.bias = bias
        self.activation = activation

    def forward(self, inputs):
        inputs = np.array(inputs)
        z = np.dot(inputs, self.weights) + self.bias
        return self.activation(z)

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def relu(x):
    return np.maximum(0, x)

def tanh(x):
    return np.tanh(x)

weights = [1.0]
bias = 0.0
sigmoid_neuron = Neuron(weights, bias, sigmoid)
relu_neuron = Neuron(weights, bias, relu)
tanh_neuron = Neuron(weights, bias, tanh)

x = np.linspace(-10, 10, 400)

y_sigmoid = [sigmoid_neuron.forward([i]) for i in x]
y_relu = [relu_neuron.forward([i]) for i in x]
y_tanh = [tanh_neuron.forward([i]) for i in x]

plt.figure(figsize=(10, 6))
plt.subplot(3, 1, 1)
plt.plot(x, y_sigmoid, label="Sigmoid", color="blue")
plt.title("Sigmoid Neuron Output")
plt.grid(True)
plt.legend()

plt.subplot(3, 1, 2)
plt.plot(x, y_relu, label="ReLU", color="green")
plt.title("ReLU Neuron Output")
plt.grid(True)
plt.legend()

plt.subplot(3, 1, 3)
plt.plot(x, y_tanh, label="Tanh", color="red")
plt.title("Tanh Neuron Output")
plt.grid(True)
plt.legend()

plt.tight_layout()
plt.show()
''',
    },
    2: {
        "title": "Generate ANDNOT function using McCulloch-Pitts neural net",
        "code": '''\
# McCulloch-Pitts Neuron for AND-NOT Function
def mp_neuron(A, B):
    w1 = 1   # weight for A
    w2 = -1  # weight for B (NOT operation)
    threshold = 1
    net_input = A * w1 + B * w2
    if net_input >= threshold:
        return 1
    else:
        return 0

inputs = [(0, 0), (0, 1), (1, 0), (1, 1)]
print("A B | Output (A AND NOT B)")
print("--------------------------")
for A, B in inputs:
    output = mp_neuron(A, B)
    print(A, B, "|", output)
''',
    },
    3: {
        "title": "Perceptron Neural Network to recognise even and odd numbers (ASCII 0-9)",
        "code": '''\
import numpy as np

ascii_values = list(range(48, 58))

inputs = [list(map(int, format(a, \'06b\'))) for a in ascii_values]

targets = [1 if (a % 2 == 0) else 0 for a in ascii_values]

weights = np.zeros(6)
bias = 0
learning_rate = 0.1

def step(x):
    return 1 if x >= 0 else 0

for epoch in range(25):
    for x, target in zip(inputs, targets):
        net_input = np.dot(weights, x) + bias
        output = step(net_input)
        error = target - output
        weights += learning_rate * error * np.array(x)
        bias += learning_rate * error

print("Training Completed")
print("Final Weights:", weights)
print("Final Bias:", bias)

print("\\nASCII | Digit | Prediction (1=Even, 0=Odd)")
print("-------------------------------------------")
for a in ascii_values:
    x = list(map(int, format(a, \'06b\')))
    prediction = step(np.dot(weights, x) + bias)
    print(" ", a, " | ", chr(a), " | ", prediction)
''',
    },
    4: {
        "title": "Perceptron learning law with decision regions (graphical)",
        "code": '''\
import numpy as np
import matplotlib.pyplot as plt

X_or = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])
y_or = np.array([0, 1, 1, 1])

class Perceptron:
    def __init__(self, learning_rate=0.1, epochs=20):
        self.lr = learning_rate
        self.epochs = epochs
        self.weights = None
        self.bias = None
        self.errors_per_epoch = []

    def predict(self, X):
        linear_output = np.dot(X, self.weights) + self.bias
        return np.where(linear_output >= 0, 1, 0)

    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0.0
        for _ in range(self.epochs):
            errors = 0
            for xi, target in zip(X, y):
                linear_output = np.dot(xi, self.weights) + self.bias
                y_pred = 1 if linear_output >= 0 else 0
                update = self.lr * (target - y_pred)
                self.weights += update * xi
                self.bias += update
                errors += int(update != 0)
            self.errors_per_epoch.append(errors)

p_or = Perceptron(learning_rate=0.1, epochs=20)
p_or.fit(X_or, y_or)
print("Weights:", p_or.weights)
print("Bias:", p_or.bias)
print("Predictions:", p_or.predict(X_or))

def plot_decision_boundary(X, y, model, title):
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(
        np.linspace(x_min, x_max, 300),
        np.linspace(y_min, y_max, 300)
    )
    grid = np.c_[xx.ravel(), yy.ravel()]
    Z = model.predict(grid)
    Z = Z.reshape(xx.shape)
    plt.figure(figsize=(6, 5))
    plt.contourf(xx, yy, Z, alpha=0.3, cmap="coolwarm")
    for label in np.unique(y):
        pts = X[y == label]
        plt.scatter(pts[:, 0], pts[:, 1], s=100, edgecolor=\'black\', label=f"Class {label}")
    plt.title(title)
    plt.xlabel("x1")
    plt.ylabel("x2")
    plt.legend()
    plt.grid(True)
    plt.show()

plot_decision_boundary(X_or, y_or, p_or, "Perceptron Decision Boundary (OR)")
''',
    },
    5: {
        "title": "ANN training process using Forward Propagation and Back Propagation",
        "code": '''\
import numpy as np

X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])
Y = np.array([
    [0],
    [1],
    [1],
    [0]
])

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

np.random.seed(42)
W1 = np.random.rand(2, 2)
b1 = np.random.rand(1, 2)
W2 = np.random.rand(2, 1)
b2 = np.random.rand(1, 1)

learning_rate = 0.5
epochs = 5000

for epoch in range(epochs):
    Z1 = np.dot(X, W1) + b1
    A1 = sigmoid(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = sigmoid(Z2)

    error = Y - A2
    loss = np.mean(np.square(error))

    dA2 = error * sigmoid_derivative(A2)
    error_hidden = dA2.dot(W2.T)
    dA1 = error_hidden * sigmoid_derivative(A1)

    W2 += A1.T.dot(dA2) * learning_rate
    b2 += np.sum(dA2, axis=0, keepdims=True) * learning_rate
    W1 += X.T.dot(dA1) * learning_rate
    b1 += np.sum(dA1, axis=0, keepdims=True) * learning_rate

    if epoch % 1000 == 0:
        print(f"Epoch {epoch}, Loss: {loss:.4f}")

print("\\nFinal Output:")
print(np.round(A2))
''',
    },
    6: {
        "title": "Neural network from scratch for multi-class classification (Iris dataset, ReLU)",
        "code": '''\
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

data = load_iris()
X = data.data
y = data.target

num_classes = len(np.unique(y))
y_onehot = np.zeros((y.shape[0], num_classes))
y_onehot[np.arange(y.shape[0]), y] = 1

scaler = StandardScaler()
X = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
    X, y_onehot, test_size=0.2, random_state=42
)

X_train = X_train + 0.1 * np.random.randn(*X_train.shape)

def relu(x):
    return np.maximum(0, x)

def relu_derivative(x):
    return (x > 0).astype(float)

def softmax(x):
    exp = np.exp(x - np.max(x, axis=1, keepdims=True))
    return exp / np.sum(exp, axis=1, keepdims=True)

input_size = X.shape[1]
hidden_size = 20
output_size = num_classes
np.random.seed(42)
W1 = np.random.randn(input_size, hidden_size) * 0.01
b1 = np.zeros((1, hidden_size))
W2 = np.random.randn(hidden_size, output_size) * 0.01
b2 = np.zeros((1, output_size))

learning_rate = 0.02
epochs = 20

for epoch in range(epochs):
    Z1 = np.dot(X_train, W1) + b1
    A1 = relu(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = softmax(Z2)

    loss = -np.mean(y_train * np.log(A2 + 1e-8))

    dZ2 = A2 - y_train
    dW2 = np.dot(A1.T, dZ2)
    db2 = np.sum(dZ2, axis=0, keepdims=True)
    dA1 = np.dot(dZ2, W2.T)
    dZ1 = dA1 * relu_derivative(Z1)
    dW1 = np.dot(X_train.T, dZ1)
    db1 = np.sum(dZ1, axis=0, keepdims=True)

    W2 -= learning_rate * dW2
    b2 -= learning_rate * db2
    W1 -= learning_rate * dW1
    b1 -= learning_rate * db1

    print(f"Epoch {epoch+1}, Loss: {loss:.4f}")

def predict(X):
    Z1 = np.dot(X, W1) + b1
    A1 = relu(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = softmax(Z2)
    return np.argmax(A2, axis=1)

y_pred = predict(X_test)
y_true = np.argmax(y_test, axis=1)
accuracy = np.mean(y_pred == y_true)
print("\\nFinal Accuracy:", accuracy)
''',
    },
    7: {
        "title": "Back Propagation Network for XOR function with Binary Input and Output",
        "code": '''\
import numpy as np

X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])
Y = np.array([
    [0],
    [1],
    [1],
    [0]
])

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

np.random.seed(1)
W1 = np.random.rand(2, 2)  # input -> hidden
b1 = np.random.rand(1, 2)
W2 = np.random.rand(2, 1)  # hidden -> output
b2 = np.random.rand(1, 1)

learning_rate = 0.5
epochs = 10000

for epoch in range(epochs):
    Z1 = np.dot(X, W1) + b1
    A1 = sigmoid(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = sigmoid(Z2)

    error = Y - A2

    dA2 = error * sigmoid_derivative(A2)
    error_hidden = dA2.dot(W2.T)
    dA1 = error_hidden * sigmoid_derivative(A1)

    W2 += A1.T.dot(dA2) * learning_rate
    b2 += np.sum(dA2, axis=0, keepdims=True) * learning_rate
    W1 += X.T.dot(dA1) * learning_rate
    b1 += np.sum(dA1, axis=0, keepdims=True) * learning_rate

print("Final Output:")
print(np.round(A2))
''',
    },
    8: {
        "title": "ART (Adaptive Resonance Theory) neural network",
        "code": '''\
import numpy as np

num_features = 4
num_clusters = 3
vigilance = 0.6  # similarity threshold

X = np.array([
    [1, 1, 0, 0],
    [1, 1, 0, 1],
    [0, 0, 1, 1],
    [0, 0, 1, 0]
])

W = np.ones((num_clusters, num_features)) / (1 + num_features)
T = np.ones((num_clusters, num_features))

def art1(X, W, T, vigilance):
    clusters = []
    for i, x in enumerate(X):
        print(f"\\nInput Pattern {i+1}: {x}")
        while True:
            net = np.dot(W, x)
            j = np.argmax(net)
            match = np.sum(np.minimum(x, T[j])) / np.sum(x)
            if match >= vigilance:
                print(f"Assigned to cluster {j}")
                T[j] = np.minimum(x, T[j])
                W[j] = T[j] / (0.5 + np.sum(T[j]))
                clusters.append(j)
                break
            else:
                W[j] = -1
            if np.all(W == -1):
                print("No suitable cluster found")
                clusters.append(-1)
                break
    return clusters

cluster_result = art1(X, W.copy(), T.copy(), vigilance)
print("\\nFinal Cluster Assignments:", cluster_result)
''',
    },
    9: {
        "title": "Back Propagation Feedforward neural network (XOR)",
        "code": '''\
import numpy as np

X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])
Y = np.array([
    [0],
    [1],
    [1],
    [0]
])

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

np.random.seed(42)
input_neurons = 2
hidden_neurons = 3
output_neurons = 1

W1 = np.random.rand(input_neurons, hidden_neurons)
b1 = np.random.rand(1, hidden_neurons)
W2 = np.random.rand(hidden_neurons, output_neurons)
b2 = np.random.rand(1, output_neurons)

learning_rate = 0.5
epochs = 10000

for epoch in range(epochs):
    Z1 = np.dot(X, W1) + b1
    A1 = sigmoid(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = sigmoid(Z2)

    error = Y - A2

    dA2 = error * sigmoid_derivative(A2)
    error_hidden = dA2.dot(W2.T)
    dA1 = error_hidden * sigmoid_derivative(A1)

    W2 += A1.T.dot(dA2) * learning_rate
    b2 += np.sum(dA2, axis=0, keepdims=True) * learning_rate
    W1 += X.T.dot(dA1) * learning_rate
    b1 += np.sum(dA1, axis=0, keepdims=True) * learning_rate

    if epoch % 2000 == 0:
        loss = np.mean(np.square(error))
        print(f"Epoch {epoch}, Loss: {loss:.4f}")

print("\\nFinal Output:")
print(np.round(A2))
''',
    },
    10: {
        "title": "Hopfield Network storing 4 vectors",
        "code": '''\
import numpy as np

def sign(x):
    return np.where(x >= 0, 1, -1)

patterns = np.array([
    [1, -1, 1, -1],
    [-1, 1, -1, 1],
    [1, 1, -1, -1],
    [-1, -1, 1, 1]
])

n = patterns.shape[1]
W = np.zeros((n, n))
for p in patterns:
    W += np.outer(p, p)
np.fill_diagonal(W, 0)
print("Weight Matrix W:\\n", W)

def recall(input_pattern, W, steps=5):
    x = input_pattern.copy()
    for _ in range(steps):
        x = sign(np.dot(W, x))
    return x

test_pattern = np.array([1, -1, -1, -1])  # noisy version
recalled = recall(test_pattern, W)
print("\\nNoisy Input:", test_pattern)
print("Recalled Pattern:", recalled)
''',
    },
    11: {
        "title": "Train a Neural Network with TensorFlow and evaluate logistic regression",
        "code": '''\
import tensorflow as tf
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

data = load_iris()
X, y = data.data, data.target

scaler = StandardScaler()
X = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

nn_model = tf.keras.Sequential([
    tf.keras.layers.Dense(100, activation=\'relu\', input_shape=(4,)),
    tf.keras.layers.Dense(3, activation=\'softmax\')
])
nn_model.compile(
    optimizer=\'adam\',
    loss=\'sparse_categorical_crossentropy\',
    metrics=[\'accuracy\']
)
nn_model.fit(X_train, y_train, epochs=50, verbose=0)
nn_loss, nn_acc = nn_model.evaluate(X_test, y_test, verbose=0)

log_model = tf.keras.Sequential([
    tf.keras.layers.Dense(3, activation=\'softmax\', input_shape=(4,))
])
log_model.compile(
    optimizer=\'adam\',
    loss=\'sparse_categorical_crossentropy\',
    metrics=[\'accuracy\']
)
log_model.fit(X_train, y_train, epochs=50, verbose=0)
log_loss, log_acc = log_model.evaluate(X_test, y_test, verbose=0)

print("Neural Network Accuracy :", nn_acc)
print("Logistic Regression Accuracy :", log_acc)
''',
    },
    12: {
        "title": "PyTorch implementation of CNN on MNIST",
        "code": '''\
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

transform = transforms.Compose([transforms.ToTensor()])
train_data = datasets.MNIST(root=\'./data\', train=True, download=True, transform=transform)
test_data = datasets.MNIST(root=\'./data\', train=False, download=True, transform=transform)
train_loader = DataLoader(train_data, batch_size=64, shuffle=True)
test_loader = DataLoader(test_data, batch_size=64)

class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, 3)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(32, 64, 3)
        self.fc1 = nn.Linear(64 * 5 * 5, 100)
        self.fc2 = nn.Linear(100, 10)

    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = x.view(-1, 64 * 5 * 5)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = CNN()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

for epoch in range(5):
    for images, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

correct = 0
total = 0
with torch.no_grad():
    for images, labels in test_loader:
        outputs = model(images)
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

print("PyTorch CNN Accuracy:", correct / total)
''',
    },
    13: {
        "title": "MNIST Handwritten Character Detection using PyTorch",
        "code": '''\
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

transform = transforms.ToTensor()
train_data = datasets.MNIST(\'./data\', train=True, download=True, transform=transform)
test_data = datasets.MNIST(\'./data\', train=False, download=True, transform=transform)
train_loader = DataLoader(train_data, batch_size=64, shuffle=True)
test_loader = DataLoader(test_data, batch_size=64)

class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, 3)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(32, 64, 3)
        self.fc1 = nn.Linear(64 * 5 * 5, 100)
        self.fc2 = nn.Linear(100, 10)

    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = x.view(-1, 64 * 5 * 5)
        x = torch.relu(self.fc1(x))
        return self.fc2(x)

model = CNN()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

for epoch in range(5):
    for images, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

correct = 0
total = 0
with torch.no_grad():
    for images, labels in test_loader:
        outputs = model(images)
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

print("PyTorch Accuracy:", correct / total)
''',
    },
}

# Keyword tags for each assignment — used by Practicals.get_practical_by_string()
_TAGS = {
    1:  ["activation", "activation function", "sigmoid", "relu", "tanh", "plot", "neuron"],
    2:  ["andnot", "and not", "mcculloch", "pitts", "mcculloch-pitts", "mp neuron", "logical"],
    3:  ["perceptron", "even", "odd", "ascii", "parity"],
    4:  ["perceptron", "decision", "boundary", "decision region", "graphical", "or gate"],
    5:  ["forward propagation", "backpropagation", "back propagation", "xor", "ann", "training"],
    6:  ["multiclass", "multi-class", "classification", "iris", "relu", "scratch", "softmax"],
    7:  ["backpropagation", "back propagation", "xor", "binary"],
    8:  ["art", "adaptive resonance", "art1", "clustering", "unsupervised"],
    9:  ["backpropagation", "back propagation", "feedforward", "feed forward", "xor"],
    10: ["hopfield", "recurrent", "memory", "bipolar", "hebbian", "recall"],
    11: ["tensorflow", "keras", "logistic regression", "logistic", "iris", "tf"],
    12: ["cnn", "convolutional", "pytorch", "mnist", "torch"],
    13: ["mnist", "handwritten", "character", "detection", "pytorch", "torch", "cnn", "convolutional"],
}

for _n, _tags in _TAGS.items():
    ASSIGNMENTS[_n]["tags"] = _tags

