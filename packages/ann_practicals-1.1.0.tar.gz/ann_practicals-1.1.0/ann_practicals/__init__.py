"""ann-practicals: retrieve ANN practical assignment code by number."""

from ._assignments import ASSIGNMENTS
from ._practicals import Practicals

__version__ = "1.1.0"
__all__ = ["get_code", "get_title", "get_assignment", "list_assignments", "Practicals"]


def _validate(n: int) -> None:
    if not isinstance(n, int) or n < 1 or n > 13:
        raise ValueError(f"Assignment number must be an integer between 1 and 13, got {n!r}")


def get_code(n: int) -> str:
    """Return the source code for assignment n (1–13)."""
    _validate(n)
    return ASSIGNMENTS[n]["code"]


def get_title(n: int) -> str:
    """Return the title for assignment n (1–13)."""
    _validate(n)
    return ASSIGNMENTS[n]["title"]


def get_assignment(n: int) -> dict:
    """Return a dict with 'title' and 'code' for assignment n (1–13)."""
    _validate(n)
    a = ASSIGNMENTS[n]
    return {"title": a["title"], "code": a["code"]}


def list_assignments() -> list:
    """Return a list of (n, title) tuples for all 13 assignments."""
    return [(n, ASSIGNMENTS[n]["title"]) for n in sorted(ASSIGNMENTS)]
