"""Per-assignment section data for notebook export.

Each entry: {"objective": str, "sections": [{"heading", "explanation", "code"}, ...]}
"""

SECTIONS = {
    1: {
        "objective": (
            "Plot the **Sigmoid**, **ReLU**, and **Tanh** activation functions by building "
            "a reusable `Neuron` class that accepts any activation function as an argument."
        ),
        "sections": [
            {
                "heading": "1. Import Libraries",
                "explanation": (
                    "- **NumPy** handles array math and the dot-product computation inside the neuron.\n"
                    "- **Matplotlib** renders the activation curves side-by-side."
                ),
                "code": (
                    "import numpy as np\n"
                    "import matplotlib.pyplot as plt"
                ),
            },
            {
                "heading": "2. Define the Neuron Class",
                "explanation": (
                    "A generic `Neuron` class models a single artificial neuron.\n\n"
                    "| Attribute | Role |\n"
                    "|-----------|------|\n"
                    "| `weights` | Strength of each input connection |\n"
                    "| `bias` | Shifts the activation threshold |\n"
                    "| `activation` | Any callable — sigmoid, relu, tanh, … |\n\n"
                    "**`forward(inputs)`** computes **z = W·x + b** and passes `z` "
                    "through the stored activation function."
                ),
                "code": (
                    "class Neuron:\n"
                    "    def __init__(self, weights, bias, activation):\n"
                    "        self.weights = np.array(weights)\n"
                    "        self.bias = bias\n"
                    "        self.activation = activation\n"
                    "\n"
                    "    def forward(self, inputs):\n"
                    "        inputs = np.array(inputs)\n"
                    "        z = np.dot(inputs, self.weights) + self.bias\n"
                    "        return self.activation(z)"
                ),
            },
            {
                "heading": "3. Define Activation Functions",
                "explanation": (
                    "Three activation functions are defined as standalone callables:\n\n"
                    "| Function | Formula | Output range |\n"
                    "|----------|---------|-------------|\n"
                    "| **Sigmoid** | 1 / (1 + e^−x) | (0, 1) |\n"
                    "| **ReLU** | max(0, x) | [0, ∞) |\n"
                    "| **Tanh** | (e^x − e^−x) / (e^x + e^−x) | (−1, 1) |"
                ),
                "code": (
                    "def sigmoid(x):\n"
                    "    return 1 / (1 + np.exp(-x))\n"
                    "\n"
                    "def relu(x):\n"
                    "    return np.maximum(0, x)\n"
                    "\n"
                    "def tanh(x):\n"
                    "    return np.tanh(x)"
                ),
            },
            {
                "heading": "4. Instantiate Neurons",
                "explanation": (
                    "Three neurons are created with **identical weights and bias** "
                    "but different activation functions. This ensures the only variable "
                    "in the plot is the activation itself."
                ),
                "code": (
                    "weights = [1.0]\n"
                    "bias = 0.0\n"
                    "sigmoid_neuron = Neuron(weights, bias, sigmoid)\n"
                    "relu_neuron    = Neuron(weights, bias, relu)\n"
                    "tanh_neuron    = Neuron(weights, bias, tanh)"
                ),
            },
            {
                "heading": "5. Compute Activation Outputs",
                "explanation": (
                    "An input range of 400 evenly spaced values between −10 and 10 is generated. "
                    "Each neuron's `forward()` method is called for every input to produce "
                    "the Y-axis data for plotting."
                ),
                "code": (
                    "x = np.linspace(-10, 10, 400)\n"
                    "\n"
                    "y_sigmoid = [sigmoid_neuron.forward([i]) for i in x]\n"
                    "y_relu    = [relu_neuron.forward([i]) for i in x]\n"
                    "y_tanh    = [tanh_neuron.forward([i]) for i in x]"
                ),
            },
            {
                "heading": "6. Plot the Activation Functions",
                "explanation": (
                    "The three curves are drawn in stacked subplots with distinct colors. "
                    "`tight_layout()` prevents label overlap between subplots."
                ),
                "code": (
                    "plt.figure(figsize=(10, 6))\n"
                    "\n"
                    "plt.subplot(3, 1, 1)\n"
                    "plt.plot(x, y_sigmoid, label='Sigmoid', color='blue')\n"
                    "plt.title('Sigmoid Neuron Output')\n"
                    "plt.grid(True); plt.legend()\n"
                    "\n"
                    "plt.subplot(3, 1, 2)\n"
                    "plt.plot(x, y_relu, label='ReLU', color='green')\n"
                    "plt.title('ReLU Neuron Output')\n"
                    "plt.grid(True); plt.legend()\n"
                    "\n"
                    "plt.subplot(3, 1, 3)\n"
                    "plt.plot(x, y_tanh, label='Tanh', color='red')\n"
                    "plt.title('Tanh Neuron Output')\n"
                    "plt.grid(True); plt.legend()\n"
                    "\n"
                    "plt.tight_layout()\n"
                    "plt.show()"
                ),
            },
        ],
    },

    2: {
        "objective": (
            "Implement the **ANDNOT** (A AND NOT B) logical function using a "
            "McCulloch-Pitts (MP) neuron — the simplest model of a biological neuron."
        ),
        "sections": [
            {
                "heading": "1. Define the McCulloch-Pitts Neuron",
                "explanation": (
                    "The MP neuron computes a **weighted sum** of its binary inputs and "
                    "fires (output = 1) if the sum meets or exceeds a threshold.\n\n"
                    "For **A AND NOT B**:\n"
                    "- `w1 = +1` (excitatory input for A)\n"
                    "- `w2 = -1` (inhibitory input for B — implements NOT)\n"
                    "- `threshold = 1`\n\n"
                    "The neuron fires only when A=1 and B=0, matching the ANDNOT truth table."
                ),
                "code": (
                    "def mp_neuron(A, B):\n"
                    "    w1 = 1   # excitatory weight for A\n"
                    "    w2 = -1  # inhibitory weight for B (NOT)\n"
                    "    threshold = 1\n"
                    "    net_input = A * w1 + B * w2\n"
                    "    return 1 if net_input >= threshold else 0"
                ),
            },
            {
                "heading": "2. Test All Input Combinations",
                "explanation": (
                    "All four binary input pairs are tested. The expected truth table:\n\n"
                    "| A | B | A AND NOT B |\n"
                    "|---|---|-------------|\n"
                    "| 0 | 0 | 0 |\n"
                    "| 0 | 1 | 0 |\n"
                    "| 1 | 0 | **1** |\n"
                    "| 1 | 1 | 0 |"
                ),
                "code": (
                    "inputs = [(0, 0), (0, 1), (1, 0), (1, 1)]\n"
                    "print('A B | Output (A AND NOT B)')\n"
                    "print('--------------------------')\n"
                    "for A, B in inputs:\n"
                    "    output = mp_neuron(A, B)\n"
                    "    print(A, B, '|', output)"
                ),
            },
        ],
    },

    3: {
        "objective": (
            "Train a **Perceptron** to classify digits 0–9 (given as 6-bit ASCII binary) "
            "as even (1) or odd (0) using the perceptron learning rule."
        ),
        "sections": [
            {
                "heading": "1. Import NumPy",
                "explanation": "NumPy provides vectorized array operations needed for the dot product and weight update.",
                "code": "import numpy as np",
            },
            {
                "heading": "2. Prepare the Dataset",
                "explanation": (
                    "ASCII codes 48–57 represent characters '0'–'9'.\n\n"
                    "- Each ASCII value is converted to a **6-bit binary vector** (the input features).\n"
                    "- The **target** is 1 if the digit is even, 0 if odd."
                ),
                "code": (
                    "ascii_values = list(range(48, 58))\n"
                    "inputs  = [list(map(int, format(a, '06b'))) for a in ascii_values]\n"
                    "targets = [1 if (a % 2 == 0) else 0 for a in ascii_values]"
                ),
            },
            {
                "heading": "3. Initialise Weights and Hyperparameters",
                "explanation": (
                    "Weights and bias start at zero. The **learning rate** controls "
                    "how much weights shift on each error.\n\n"
                    "The **step activation** fires (1) when the net input ≥ 0."
                ),
                "code": (
                    "weights = np.zeros(6)\n"
                    "bias = 0\n"
                    "learning_rate = 0.1\n"
                    "\n"
                    "def step(x):\n"
                    "    return 1 if x >= 0 else 0"
                ),
            },
            {
                "heading": "4. Train the Perceptron",
                "explanation": (
                    "For each training example the perceptron:\n"
                    "1. Computes the net input: **z = W·x + b**\n"
                    "2. Applies the step function to get a prediction\n"
                    "3. Calculates the error: **e = target − prediction**\n"
                    "4. Updates weights: **W += η × e × x**, bias: **b += η × e**\n\n"
                    "This is the classic **perceptron learning rule**."
                ),
                "code": (
                    "for epoch in range(25):\n"
                    "    for x, target in zip(inputs, targets):\n"
                    "        net_input = np.dot(weights, x) + bias\n"
                    "        output    = step(net_input)\n"
                    "        error     = target - output\n"
                    "        weights  += learning_rate * error * np.array(x)\n"
                    "        bias     += learning_rate * error\n"
                    "\n"
                    "print('Training Completed')\n"
                    "print('Final Weights:', weights)\n"
                    "print('Final Bias:', bias)"
                ),
            },
            {
                "heading": "5. Test and Display Predictions",
                "explanation": (
                    "Each ASCII digit is passed through the trained perceptron. "
                    "A correct model outputs **1 for even digits** (0,2,4,6,8) "
                    "and **0 for odd digits** (1,3,5,7,9)."
                ),
                "code": (
                    "print('\\nASCII | Digit | Prediction (1=Even, 0=Odd)')\n"
                    "print('-------------------------------------------')\n"
                    "for a in ascii_values:\n"
                    "    x = list(map(int, format(a, '06b')))\n"
                    "    prediction = step(np.dot(weights, x) + bias)\n"
                    "    print(' ', a, ' | ', chr(a), ' | ', prediction)"
                ),
            },
        ],
    },

    4: {
        "objective": (
            "Implement the **Perceptron learning law** for the OR gate and visualise "
            "the learned **decision boundary** as a 2D colour-filled region."
        ),
        "sections": [
            {
                "heading": "1. Import Libraries",
                "explanation": "NumPy for matrix operations; Matplotlib for the decision-boundary plot.",
                "code": (
                    "import numpy as np\n"
                    "import matplotlib.pyplot as plt"
                ),
            },
            {
                "heading": "2. Define OR Gate Training Data",
                "explanation": (
                    "The OR gate returns 1 unless both inputs are 0.\n\n"
                    "| x1 | x2 | y |\n"
                    "|----|----|-|\n"
                    "| 0  | 0  | 0 |\n"
                    "| 0  | 1  | 1 |\n"
                    "| 1  | 0  | 1 |\n"
                    "| 1  | 1  | 1 |"
                ),
                "code": (
                    "X_or = np.array([[0,0],[0,1],[1,0],[1,1]])\n"
                    "y_or = np.array([0, 1, 1, 1])"
                ),
            },
            {
                "heading": "3. Implement the Perceptron Class",
                "explanation": (
                    "**`fit(X, y)`** runs the perceptron learning rule:\n"
                    "- For each sample, predict using the current weights\n"
                    "- Compute update = η × (target − prediction)\n"
                    "- Adjust weights and bias by that update\n\n"
                    "**`predict(X)`** uses `np.where` for vectorised step activation."
                ),
                "code": (
                    "class Perceptron:\n"
                    "    def __init__(self, learning_rate=0.1, epochs=20):\n"
                    "        self.lr = learning_rate\n"
                    "        self.epochs = epochs\n"
                    "        self.weights = None\n"
                    "        self.bias = None\n"
                    "        self.errors_per_epoch = []\n"
                    "\n"
                    "    def predict(self, X):\n"
                    "        return np.where(np.dot(X, self.weights) + self.bias >= 0, 1, 0)\n"
                    "\n"
                    "    def fit(self, X, y):\n"
                    "        n_samples, n_features = X.shape\n"
                    "        self.weights = np.zeros(n_features)\n"
                    "        self.bias = 0.0\n"
                    "        for _ in range(self.epochs):\n"
                    "            errors = 0\n"
                    "            for xi, target in zip(X, y):\n"
                    "                y_pred = 1 if np.dot(xi, self.weights) + self.bias >= 0 else 0\n"
                    "                update = self.lr * (target - y_pred)\n"
                    "                self.weights += update * xi\n"
                    "                self.bias    += update\n"
                    "                errors += int(update != 0)\n"
                    "            self.errors_per_epoch.append(errors)"
                ),
            },
            {
                "heading": "4. Train the Perceptron",
                "explanation": (
                    "The perceptron is trained on the OR dataset. "
                    "Since OR is **linearly separable**, the perceptron is guaranteed to converge."
                ),
                "code": (
                    "p_or = Perceptron(learning_rate=0.1, epochs=20)\n"
                    "p_or.fit(X_or, y_or)\n"
                    "print('Weights:', p_or.weights)\n"
                    "print('Bias:', p_or.bias)\n"
                    "print('Predictions:', p_or.predict(X_or))"
                ),
            },
            {
                "heading": "5. Plot the Decision Boundary",
                "explanation": (
                    "A meshgrid of points covers the input space. "
                    "Each point is classified by the trained perceptron and the result is "
                    "colour-filled with `contourf`. Training points are overlaid as scatter dots.\n\n"
                    "The boundary separating the two colours is the **learned decision hyperplane** "
                    "(a straight line in 2D)."
                ),
                "code": (
                    "def plot_decision_boundary(X, y, model, title):\n"
                    "    x_min, x_max = X[:,0].min()-1, X[:,0].max()+1\n"
                    "    y_min, y_max = X[:,1].min()-1, X[:,1].max()+1\n"
                    "    xx, yy = np.meshgrid(np.linspace(x_min,x_max,300),\n"
                    "                         np.linspace(y_min,y_max,300))\n"
                    "    Z = model.predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)\n"
                    "    plt.figure(figsize=(6,5))\n"
                    "    plt.contourf(xx, yy, Z, alpha=0.3, cmap='coolwarm')\n"
                    "    for label in np.unique(y):\n"
                    "        pts = X[y==label]\n"
                    "        plt.scatter(pts[:,0], pts[:,1], s=100, edgecolor='black', label=f'Class {label}')\n"
                    "    plt.title(title); plt.xlabel('x1'); plt.ylabel('x2')\n"
                    "    plt.legend(); plt.grid(True); plt.show()\n"
                    "\n"
                    "plot_decision_boundary(X_or, y_or, p_or, 'Perceptron Decision Boundary (OR)')"
                ),
            },
        ],
    },

    5: {
        "objective": (
            "Build a two-layer ANN from scratch and train it to solve the **XOR problem** "
            "using **forward propagation** and **backpropagation** with sigmoid activations."
        ),
        "sections": [
            {
                "heading": "1. Import NumPy and Define XOR Data",
                "explanation": (
                    "XOR is the classic non-linearly-separable problem — a single perceptron "
                    "cannot solve it. A hidden layer is needed.\n\n"
                    "| x1 | x2 | y |\n|----|----|-|\n| 0 | 0 | 0 |\n"
                    "| 0 | 1 | 1 |\n| 1 | 0 | 1 |\n| 1 | 1 | 0 |"
                ),
                "code": (
                    "import numpy as np\n"
                    "\n"
                    "X = np.array([[0,0],[0,1],[1,0],[1,1]])\n"
                    "Y = np.array([[0],[1],[1],[0]])"
                ),
            },
            {
                "heading": "2. Activation Function",
                "explanation": (
                    "**Sigmoid** σ(x) = 1/(1+e^−x) squashes any value to (0,1).\n\n"
                    "Its derivative σ'(x) = σ(x)·(1−σ(x)) is used during backpropagation "
                    "to compute how much each neuron contributed to the error."
                ),
                "code": (
                    "def sigmoid(x):\n"
                    "    return 1 / (1 + np.exp(-x))\n"
                    "\n"
                    "def sigmoid_derivative(x):\n"
                    "    return x * (1 - x)"
                ),
            },
            {
                "heading": "3. Initialise Weights Randomly",
                "explanation": (
                    "The network has:\n"
                    "- **Layer 1** (hidden): 2 inputs → 2 neurons → weight matrix W1 (2×2)\n"
                    "- **Layer 2** (output): 2 inputs → 1 neuron → weight matrix W2 (2×1)\n\n"
                    "Random initialisation breaks symmetry so neurons learn different features. "
                    "`np.random.seed(42)` ensures reproducibility."
                ),
                "code": (
                    "np.random.seed(42)\n"
                    "W1 = np.random.rand(2, 2)\n"
                    "b1 = np.random.rand(1, 2)\n"
                    "W2 = np.random.rand(2, 1)\n"
                    "b2 = np.random.rand(1, 1)\n"
                    "\n"
                    "learning_rate = 0.5\n"
                    "epochs = 5000"
                ),
            },
            {
                "heading": "4. Training Loop — Forward & Backward Pass",
                "explanation": (
                    "**Forward pass** (top-down):\n"
                    "1. Z1 = X·W1 + b1 → A1 = sigmoid(Z1)  *(hidden layer)*\n"
                    "2. Z2 = A1·W2 + b2 → A2 = sigmoid(Z2) *(output layer)*\n\n"
                    "**Loss** = Mean Squared Error between target Y and prediction A2.\n\n"
                    "**Backward pass** (chain rule):\n"
                    "- Output delta: dA2 = error × σ'(A2)\n"
                    "- Hidden delta: dA1 = (dA2 · W2ᵀ) × σ'(A1)\n\n"
                    "**Weight update** (gradient descent):\n"
                    "- W2 += A1ᵀ · dA2 × η ; W1 += Xᵀ · dA1 × η"
                ),
                "code": (
                    "for epoch in range(epochs):\n"
                    "    # Forward propagation\n"
                    "    Z1 = np.dot(X, W1) + b1\n"
                    "    A1 = sigmoid(Z1)\n"
                    "    Z2 = np.dot(A1, W2) + b2\n"
                    "    A2 = sigmoid(Z2)\n"
                    "\n"
                    "    error = Y - A2\n"
                    "    loss  = np.mean(np.square(error))\n"
                    "\n"
                    "    # Backpropagation\n"
                    "    dA2          = error * sigmoid_derivative(A2)\n"
                    "    error_hidden = dA2.dot(W2.T)\n"
                    "    dA1          = error_hidden * sigmoid_derivative(A1)\n"
                    "\n"
                    "    # Weight updates\n"
                    "    W2 += A1.T.dot(dA2) * learning_rate\n"
                    "    b2 += np.sum(dA2, axis=0, keepdims=True) * learning_rate\n"
                    "    W1 += X.T.dot(dA1) * learning_rate\n"
                    "    b1 += np.sum(dA1, axis=0, keepdims=True) * learning_rate\n"
                    "\n"
                    "    if epoch % 1000 == 0:\n"
                    "        print(f'Epoch {epoch}, Loss: {loss:.4f}')"
                ),
            },
            {
                "heading": "5. Final Predictions",
                "explanation": (
                    "After training, `np.round(A2)` converts the sigmoid output "
                    "(a probability) to a hard 0/1 label. "
                    "A well-trained network should output `[[0],[1],[1],[0]]`."
                ),
                "code": (
                    "print('\\nFinal Output:')\n"
                    "print(np.round(A2))"
                ),
            },
        ],
    },

    6: {
        "objective": (
            "Build a **multi-class neural network from scratch** (no TensorFlow/PyTorch) "
            "using ReLU hidden activation and Softmax output to classify the Iris dataset into 3 species."
        ),
        "sections": [
            {
                "heading": "1. Import Libraries and Load Iris Dataset",
                "explanation": (
                    "The **Iris dataset** has 150 samples, 4 features, and 3 classes. "
                    "`StandardScaler` normalises features to zero-mean unit-variance, "
                    "which helps gradient descent converge faster."
                ),
                "code": (
                    "import numpy as np\n"
                    "from sklearn.datasets import load_iris\n"
                    "from sklearn.model_selection import train_test_split\n"
                    "from sklearn.preprocessing import StandardScaler\n"
                    "\n"
                    "data = load_iris()\n"
                    "X = data.data\n"
                    "y = data.target"
                ),
            },
            {
                "heading": "2. Preprocess — One-Hot Encode and Normalise",
                "explanation": (
                    "**One-hot encoding** converts integer class labels (0,1,2) into "
                    "binary vectors `[1,0,0]`, `[0,1,0]`, `[0,0,1]` — required for the "
                    "softmax output layer.\n\n"
                    "A small amount of Gaussian noise is added to training data to act as regularisation."
                ),
                "code": (
                    "num_classes = len(np.unique(y))\n"
                    "y_onehot = np.zeros((y.shape[0], num_classes))\n"
                    "y_onehot[np.arange(y.shape[0]), y] = 1\n"
                    "\n"
                    "scaler = StandardScaler()\n"
                    "X = scaler.fit_transform(X)\n"
                    "\n"
                    "X_train, X_test, y_train, y_test = train_test_split(\n"
                    "    X, y_onehot, test_size=0.2, random_state=42)\n"
                    "\n"
                    "X_train = X_train + 0.1 * np.random.randn(*X_train.shape)"
                ),
            },
            {
                "heading": "3. Define Activation Functions",
                "explanation": (
                    "- **ReLU** in the hidden layer introduces non-linearity and avoids the vanishing-gradient problem.\n"
                    "- **Softmax** in the output layer converts raw scores into a probability distribution over 3 classes. "
                    "Subtracting `max(x)` before exponentiation prevents numerical overflow."
                ),
                "code": (
                    "def relu(x):             return np.maximum(0, x)\n"
                    "def relu_derivative(x):  return (x > 0).astype(float)\n"
                    "\n"
                    "def softmax(x):\n"
                    "    exp = np.exp(x - np.max(x, axis=1, keepdims=True))\n"
                    "    return exp / np.sum(exp, axis=1, keepdims=True)"
                ),
            },
            {
                "heading": "4. Initialise Network Weights",
                "explanation": (
                    "Architecture: **4 inputs → 20 hidden neurons → 3 outputs**.\n\n"
                    "Weights are initialised with small random values (`* 0.01`) to keep "
                    "activations in the linear region at the start of training."
                ),
                "code": (
                    "input_size, hidden_size, output_size = X.shape[1], 20, num_classes\n"
                    "np.random.seed(42)\n"
                    "W1 = np.random.randn(input_size, hidden_size) * 0.01\n"
                    "b1 = np.zeros((1, hidden_size))\n"
                    "W2 = np.random.randn(hidden_size, output_size) * 0.01\n"
                    "b2 = np.zeros((1, output_size))\n"
                    "\n"
                    "learning_rate = 0.02\n"
                    "epochs = 20"
                ),
            },
            {
                "heading": "5. Training Loop",
                "explanation": (
                    "**Loss** = categorical cross-entropy: −Σ y·log(ŷ).\n\n"
                    "**Backprop through softmax + cross-entropy**: the gradient `dZ2 = A2 − y_train` "
                    "is a clean closed form, which is one reason softmax+CE is preferred over "
                    "softmax+MSE."
                ),
                "code": (
                    "for epoch in range(epochs):\n"
                    "    Z1 = np.dot(X_train, W1) + b1\n"
                    "    A1 = relu(Z1)\n"
                    "    Z2 = np.dot(A1, W2) + b2\n"
                    "    A2 = softmax(Z2)\n"
                    "\n"
                    "    loss = -np.mean(y_train * np.log(A2 + 1e-8))\n"
                    "\n"
                    "    dZ2 = A2 - y_train\n"
                    "    dW2 = np.dot(A1.T, dZ2)\n"
                    "    db2 = np.sum(dZ2, axis=0, keepdims=True)\n"
                    "    dA1 = np.dot(dZ2, W2.T)\n"
                    "    dZ1 = dA1 * relu_derivative(Z1)\n"
                    "    dW1 = np.dot(X_train.T, dZ1)\n"
                    "    db1 = np.sum(dZ1, axis=0, keepdims=True)\n"
                    "\n"
                    "    W2 -= learning_rate * dW2;  b2 -= learning_rate * db2\n"
                    "    W1 -= learning_rate * dW1;  b1 -= learning_rate * db1\n"
                    "    print(f'Epoch {epoch+1}, Loss: {loss:.4f}')"
                ),
            },
            {
                "heading": "6. Evaluate on Test Set",
                "explanation": (
                    "Predictions are made with a forward pass on `X_test`. "
                    "`np.argmax` converts softmax probabilities back to class indices "
                    "for accuracy comparison."
                ),
                "code": (
                    "def predict(X):\n"
                    "    A1 = relu(np.dot(X, W1) + b1)\n"
                    "    A2 = softmax(np.dot(A1, W2) + b2)\n"
                    "    return np.argmax(A2, axis=1)\n"
                    "\n"
                    "y_pred = predict(X_test)\n"
                    "y_true = np.argmax(y_test, axis=1)\n"
                    "print('Final Accuracy:', np.mean(y_pred == y_true))"
                ),
            },
        ],
    },

    7: {
        "objective": (
            "Train a backpropagation network with **binary inputs and outputs** to learn "
            "the XOR function, demonstrating the complete gradient-descent training cycle."
        ),
        "sections": [
            {
                "heading": "1. Setup — Data and Activation Functions",
                "explanation": (
                    "XOR binary data is defined. The sigmoid function and its derivative are used "
                    "throughout forward and backward passes."
                ),
                "code": (
                    "import numpy as np\n"
                    "\n"
                    "X = np.array([[0,0],[0,1],[1,0],[1,1]])\n"
                    "Y = np.array([[0],[1],[1],[0]])\n"
                    "\n"
                    "def sigmoid(x):            return 1 / (1 + np.exp(-x))\n"
                    "def sigmoid_derivative(x): return x * (1 - x)"
                ),
            },
            {
                "heading": "2. Initialise Weights",
                "explanation": (
                    "Weights for input→hidden (W1, 2×2) and hidden→output (W2, 2×1) are "
                    "randomly seeded with `seed(1)` for reproducibility. "
                    "Biases b1 and b2 are also randomly initialised."
                ),
                "code": (
                    "np.random.seed(1)\n"
                    "W1 = np.random.rand(2, 2)  # input -> hidden\n"
                    "b1 = np.random.rand(1, 2)\n"
                    "W2 = np.random.rand(2, 1)  # hidden -> output\n"
                    "b2 = np.random.rand(1, 1)\n"
                    "\n"
                    "learning_rate = 0.5\n"
                    "epochs = 10000"
                ),
            },
            {
                "heading": "3. Forward and Backward Pass (10 000 epochs)",
                "explanation": (
                    "10 000 epochs are used because XOR requires the network to develop "
                    "non-linear internal representations, which takes more iterations than "
                    "linearly separable problems."
                ),
                "code": (
                    "for epoch in range(epochs):\n"
                    "    A1 = sigmoid(np.dot(X, W1) + b1)\n"
                    "    A2 = sigmoid(np.dot(A1, W2) + b2)\n"
                    "\n"
                    "    error        = Y - A2\n"
                    "    dA2          = error * sigmoid_derivative(A2)\n"
                    "    dA1          = dA2.dot(W2.T) * sigmoid_derivative(A1)\n"
                    "\n"
                    "    W2 += A1.T.dot(dA2) * learning_rate\n"
                    "    b2 += np.sum(dA2, axis=0, keepdims=True) * learning_rate\n"
                    "    W1 += X.T.dot(dA1) * learning_rate\n"
                    "    b1 += np.sum(dA1, axis=0, keepdims=True) * learning_rate"
                ),
            },
            {
                "heading": "4. Output",
                "explanation": (
                    "`np.round` converts sigmoid probabilities to binary 0/1. "
                    "Expected output: `[[0],[1],[1],[0]]`."
                ),
                "code": (
                    "print('Final Output:')\n"
                    "print(np.round(A2))"
                ),
            },
        ],
    },

    8: {
        "objective": (
            "Implement the **ART1 (Adaptive Resonance Theory)** algorithm, "
            "which performs unsupervised clustering on binary patterns while "
            "balancing *plasticity* (learning new patterns) and *stability* (preserving old ones)."
        ),
        "sections": [
            {
                "heading": "1. Setup — Parameters and Input Patterns",
                "explanation": (
                    "Key ART1 parameter:\n\n"
                    "**Vigilance (ρ)** controls cluster tightness:\n"
                    "- High ρ → strict matching → more, smaller clusters\n"
                    "- Low ρ → loose matching → fewer, broader clusters\n\n"
                    "Four 4-bit binary patterns are used as input."
                ),
                "code": (
                    "import numpy as np\n"
                    "\n"
                    "vigilance = 0.6\n"
                    "num_features, num_clusters = 4, 3\n"
                    "\n"
                    "X = np.array([[1,1,0,0],[1,1,0,1],[0,0,1,1],[0,0,1,0]])"
                ),
            },
            {
                "heading": "2. Initialise Bottom-Up and Top-Down Weights",
                "explanation": (
                    "ART1 maintains **two weight matrices**:\n\n"
                    "| Matrix | Direction | Role |\n"
                    "|--------|-----------|------|\n"
                    "| **W** (bottom-up) | input → cluster | Selects the best-matching cluster |\n"
                    "| **T** (top-down) | cluster → input | Verifies the match against vigilance |"
                ),
                "code": (
                    "W = np.ones((num_clusters, num_features)) / (1 + num_features)  # bottom-up\n"
                    "T = np.ones((num_clusters, num_features))                        # top-down"
                ),
            },
            {
                "heading": "3. ART1 Algorithm",
                "explanation": (
                    "For each input pattern:\n"
                    "1. **Activation**: score each cluster node with W · x\n"
                    "2. **Select**: pick the highest-scoring cluster j\n"
                    "3. **Match test**: if |x AND T[j]| / |x| ≥ ρ → resonance → update weights\n"
                    "4. **Mismatch reset**: inhibit cluster j, try next best\n\n"
                    "The AND operation (`np.minimum` on binary vectors) measures feature overlap."
                ),
                "code": (
                    "def art1(X, W, T, vigilance):\n"
                    "    clusters = []\n"
                    "    for i, x in enumerate(X):\n"
                    "        print(f'\\nInput Pattern {i+1}: {x}')\n"
                    "        while True:\n"
                    "            j     = np.argmax(np.dot(W, x))\n"
                    "            match = np.sum(np.minimum(x, T[j])) / np.sum(x)\n"
                    "            if match >= vigilance:\n"
                    "                print(f'Assigned to cluster {j}')\n"
                    "                T[j] = np.minimum(x, T[j])\n"
                    "                W[j] = T[j] / (0.5 + np.sum(T[j]))\n"
                    "                clusters.append(j); break\n"
                    "            else:\n"
                    "                W[j] = -1\n"
                    "            if np.all(W == -1):\n"
                    "                print('No suitable cluster found')\n"
                    "                clusters.append(-1); break\n"
                    "    return clusters"
                ),
            },
            {
                "heading": "4. Run ART1 and Show Cluster Assignments",
                "explanation": (
                    "Copies of W and T are passed so the originals are preserved for re-runs. "
                    "The output shows which cluster each input pattern is assigned to."
                ),
                "code": (
                    "result = art1(X, W.copy(), T.copy(), vigilance)\n"
                    "print('\\nFinal Cluster Assignments:', result)"
                ),
            },
        ],
    },

    9: {
        "objective": (
            "Build a **3-layer feedforward network** (2 inputs, 3 hidden, 1 output) "
            "and train it on XOR via backpropagation, printing loss every 2000 epochs."
        ),
        "sections": [
            {
                "heading": "1. Data and Activation Functions",
                "explanation": "XOR dataset and sigmoid activations — same as Assignment 5 but with a wider hidden layer (3 neurons).",
                "code": (
                    "import numpy as np\n"
                    "\n"
                    "X = np.array([[0,0],[0,1],[1,0],[1,1]])\n"
                    "Y = np.array([[0],[1],[1],[0]])\n"
                    "\n"
                    "def sigmoid(x):            return 1 / (1 + np.exp(-x))\n"
                    "def sigmoid_derivative(x): return x * (1 - x)"
                ),
            },
            {
                "heading": "2. Initialise a 3-Neuron Hidden Layer",
                "explanation": (
                    "Architecture: **2 → 3 → 1**. "
                    "W1 is now (2×3) and W2 is (3×1). "
                    "More hidden neurons give the network more capacity to learn complex mappings."
                ),
                "code": (
                    "np.random.seed(42)\n"
                    "W1 = np.random.rand(2, 3)  # input -> hidden (3 neurons)\n"
                    "b1 = np.random.rand(1, 3)\n"
                    "W2 = np.random.rand(3, 1)  # hidden -> output\n"
                    "b2 = np.random.rand(1, 1)\n"
                    "\n"
                    "learning_rate = 0.5\n"
                    "epochs = 10000"
                ),
            },
            {
                "heading": "3. Training with Loss Monitoring",
                "explanation": (
                    "Loss (MSE) is printed every 2000 epochs to verify the network is converging. "
                    "A decreasing loss confirms gradient descent is working correctly."
                ),
                "code": (
                    "for epoch in range(epochs):\n"
                    "    A1 = sigmoid(np.dot(X, W1) + b1)\n"
                    "    A2 = sigmoid(np.dot(A1, W2) + b2)\n"
                    "    error = Y - A2\n"
                    "\n"
                    "    dA2 = error * sigmoid_derivative(A2)\n"
                    "    dA1 = dA2.dot(W2.T) * sigmoid_derivative(A1)\n"
                    "\n"
                    "    W2 += A1.T.dot(dA2) * learning_rate\n"
                    "    b2 += np.sum(dA2, axis=0, keepdims=True) * learning_rate\n"
                    "    W1 += X.T.dot(dA1) * learning_rate\n"
                    "    b1 += np.sum(dA1, axis=0, keepdims=True) * learning_rate\n"
                    "\n"
                    "    if epoch % 2000 == 0:\n"
                    "        print(f'Epoch {epoch}, Loss: {np.mean(np.square(error)):.4f}')"
                ),
            },
            {
                "heading": "4. Final Predictions",
                "explanation": "Rounded sigmoid output should match XOR truth table: `[[0],[1],[1],[0]]`.",
                "code": (
                    "print('\\nFinal Output:')\n"
                    "print(np.round(A2))"
                ),
            },
        ],
    },

    10: {
        "objective": (
            "Implement a **Hopfield Network** that stores 4 bipolar patterns using "
            "Hebbian learning and can recall a stored pattern from a noisy/partial input."
        ),
        "sections": [
            {
                "heading": "1. Sign Activation and Stored Patterns",
                "explanation": (
                    "Hopfield networks use **bipolar** representations (−1 and +1) instead of binary (0 and 1). "
                    "The sign function maps ≥0 → +1 and <0 → −1.\n\n"
                    "Four 4-bit patterns are stored as the network's memory."
                ),
                "code": (
                    "import numpy as np\n"
                    "\n"
                    "def sign(x): return np.where(x >= 0, 1, -1)\n"
                    "\n"
                    "patterns = np.array([\n"
                    "    [ 1, -1,  1, -1],\n"
                    "    [-1,  1, -1,  1],\n"
                    "    [ 1,  1, -1, -1],\n"
                    "    [-1, -1,  1,  1]\n"
                    "])"
                ),
            },
            {
                "heading": "2. Compute the Weight Matrix (Hebbian Learning)",
                "explanation": (
                    "The weight matrix is computed as: **W = Σ pᵢpᵢᵀ** (outer product sum over all patterns).\n\n"
                    "Self-connections are removed by zeroing the diagonal — "
                    "a neuron should not excite itself."
                ),
                "code": (
                    "n = patterns.shape[1]\n"
                    "W = np.zeros((n, n))\n"
                    "for p in patterns:\n"
                    "    W += np.outer(p, p)\n"
                    "np.fill_diagonal(W, 0)\n"
                    "print('Weight Matrix W:\\n', W)"
                ),
            },
            {
                "heading": "3. Recall Function (Synchronous Update)",
                "explanation": (
                    "Starting from a noisy input, the network iteratively updates all neurons "
                    "simultaneously (**synchronous** update): **x ← sign(W·x)**.\n\n"
                    "The state converges to the nearest stored pattern (an *attractor*)."
                ),
                "code": (
                    "def recall(input_pattern, W, steps=5):\n"
                    "    x = input_pattern.copy()\n"
                    "    for _ in range(steps):\n"
                    "        x = sign(np.dot(W, x))\n"
                    "    return x"
                ),
            },
            {
                "heading": "4. Test with a Noisy Pattern",
                "explanation": (
                    "The test pattern `[1, -1, -1, -1]` is a corrupted version of `[1, -1, 1, -1]` "
                    "(pattern 1). The network should recover the original stored pattern."
                ),
                "code": (
                    "test_pattern = np.array([1, -1, -1, -1])  # noisy input\n"
                    "recalled = recall(test_pattern, W)\n"
                    "print('\\nNoisy Input:    ', test_pattern)\n"
                    "print('Recalled Pattern:', recalled)"
                ),
            },
        ],
    },

    11: {
        "objective": (
            "Use **TensorFlow/Keras** to build and compare two models on the Iris dataset:\n"
            "1. A 2-layer **Neural Network** (Dense + ReLU)\n"
            "2. A single-layer **Logistic Regression** model"
        ),
        "sections": [
            {
                "heading": "1. Import Libraries and Load Data",
                "explanation": (
                    "TensorFlow's Keras API is used for model building. "
                    "The Iris dataset (150 samples, 4 features, 3 classes) is loaded "
                    "from scikit-learn and split 80/20 into train/test."
                ),
                "code": (
                    "import tensorflow as tf\n"
                    "from sklearn.datasets import load_iris\n"
                    "from sklearn.model_selection import train_test_split\n"
                    "from sklearn.preprocessing import StandardScaler\n"
                    "\n"
                    "data = load_iris()\n"
                    "X, y = data.data, data.target\n"
                    "\n"
                    "scaler = StandardScaler()\n"
                    "X = scaler.fit_transform(X)\n"
                    "X_train, X_test, y_train, y_test = train_test_split(\n"
                    "    X, y, test_size=0.2, random_state=42)"
                ),
            },
            {
                "heading": "2. Build and Train the Neural Network",
                "explanation": (
                    "Architecture: `Dense(100, relu)` → `Dense(3, softmax)`\n\n"
                    "- **Adam** optimizer adapts learning rates per parameter\n"
                    "- **Sparse categorical cross-entropy** works with integer labels (no one-hot needed)\n"
                    "- `verbose=0` suppresses per-epoch output"
                ),
                "code": (
                    "nn_model = tf.keras.Sequential([\n"
                    "    tf.keras.layers.Dense(100, activation='relu', input_shape=(4,)),\n"
                    "    tf.keras.layers.Dense(3,   activation='softmax')\n"
                    "])\n"
                    "nn_model.compile(optimizer='adam',\n"
                    "                 loss='sparse_categorical_crossentropy',\n"
                    "                 metrics=['accuracy'])\n"
                    "nn_model.fit(X_train, y_train, epochs=50, verbose=0)\n"
                    "nn_loss, nn_acc = nn_model.evaluate(X_test, y_test, verbose=0)"
                ),
            },
            {
                "heading": "3. Build and Train Logistic Regression",
                "explanation": (
                    "Logistic regression is simply a **single Dense layer with softmax**. "
                    "It can only learn linear decision boundaries, so it typically underperforms "
                    "the NN on non-linear data."
                ),
                "code": (
                    "log_model = tf.keras.Sequential([\n"
                    "    tf.keras.layers.Dense(3, activation='softmax', input_shape=(4,))\n"
                    "])\n"
                    "log_model.compile(optimizer='adam',\n"
                    "                  loss='sparse_categorical_crossentropy',\n"
                    "                  metrics=['accuracy'])\n"
                    "log_model.fit(X_train, y_train, epochs=50, verbose=0)\n"
                    "log_loss, log_acc = log_model.evaluate(X_test, y_test, verbose=0)"
                ),
            },
            {
                "heading": "4. Compare Results",
                "explanation": (
                    "Both accuracies are printed for direct comparison. "
                    "The NN typically achieves ≥97% while logistic regression achieves ~93–95% "
                    "on Iris, illustrating the benefit of a hidden non-linear layer."
                ),
                "code": (
                    "print('Neural Network Accuracy :', nn_acc)\n"
                    "print('Logistic Regression Accuracy :', log_acc)"
                ),
            },
        ],
    },

    12: {
        "objective": (
            "Train a **Convolutional Neural Network (CNN)** in PyTorch on the MNIST handwritten "
            "digit dataset and evaluate its classification accuracy."
        ),
        "sections": [
            {
                "heading": "1. Import Libraries and Load MNIST",
                "explanation": (
                    "`torchvision.datasets.MNIST` downloads the dataset automatically. "
                    "`DataLoader` batches the data into mini-batches of 64 for efficient GPU/CPU training."
                ),
                "code": (
                    "import torch, torch.nn as nn, torch.optim as optim\n"
                    "from torchvision import datasets, transforms\n"
                    "from torch.utils.data import DataLoader\n"
                    "\n"
                    "transform = transforms.Compose([transforms.ToTensor()])\n"
                    "train_data   = datasets.MNIST('./data', train=True,  download=True, transform=transform)\n"
                    "test_data    = datasets.MNIST('./data', train=False, download=True, transform=transform)\n"
                    "train_loader = DataLoader(train_data, batch_size=64, shuffle=True)\n"
                    "test_loader  = DataLoader(test_data,  batch_size=64)"
                ),
            },
            {
                "heading": "2. Define the CNN Architecture",
                "explanation": (
                    "| Layer | Type | Output shape |\n"
                    "|-------|------|--------------|\n"
                    "| conv1 | Conv2d(1,32,3) + ReLU | 32×26×26 |\n"
                    "| pool  | MaxPool2d(2,2) | 32×13×13 |\n"
                    "| conv2 | Conv2d(32,64,3) + ReLU | 64×11×11 |\n"
                    "| pool  | MaxPool2d(2,2) | 64×5×5 |\n"
                    "| fc1   | Linear(1600,100) + ReLU | 100 |\n"
                    "| fc2   | Linear(100,10) | 10 (logits) |"
                ),
                "code": (
                    "class CNN(nn.Module):\n"
                    "    def __init__(self):\n"
                    "        super().__init__()\n"
                    "        self.conv1 = nn.Conv2d(1, 32, 3)\n"
                    "        self.pool  = nn.MaxPool2d(2, 2)\n"
                    "        self.conv2 = nn.Conv2d(32, 64, 3)\n"
                    "        self.fc1   = nn.Linear(64*5*5, 100)\n"
                    "        self.fc2   = nn.Linear(100, 10)\n"
                    "\n"
                    "    def forward(self, x):\n"
                    "        x = self.pool(torch.relu(self.conv1(x)))\n"
                    "        x = self.pool(torch.relu(self.conv2(x)))\n"
                    "        x = x.view(-1, 64*5*5)\n"
                    "        x = torch.relu(self.fc1(x))\n"
                    "        return self.fc2(x)"
                ),
            },
            {
                "heading": "3. Loss Function and Optimiser",
                "explanation": (
                    "- **CrossEntropyLoss** combines log-softmax and NLL loss — the standard for classification.\n"
                    "- **Adam** adapts per-parameter learning rates; `lr=0.001` is a safe default."
                ),
                "code": (
                    "model     = CNN()\n"
                    "criterion = nn.CrossEntropyLoss()\n"
                    "optimizer = optim.Adam(model.parameters(), lr=0.001)"
                ),
            },
            {
                "heading": "4. Training Loop (5 Epochs)",
                "explanation": (
                    "For each mini-batch:\n"
                    "1. **Zero** accumulated gradients\n"
                    "2. **Forward** pass → compute loss\n"
                    "3. **Backward** pass → `loss.backward()` computes gradients\n"
                    "4. **Step** → optimizer updates weights"
                ),
                "code": (
                    "for epoch in range(5):\n"
                    "    for images, labels in train_loader:\n"
                    "        optimizer.zero_grad()\n"
                    "        loss = criterion(model(images), labels)\n"
                    "        loss.backward()\n"
                    "        optimizer.step()"
                ),
            },
            {
                "heading": "5. Evaluate Accuracy",
                "explanation": (
                    "`torch.no_grad()` disables gradient computation during inference, "
                    "saving memory and speeding up evaluation. "
                    "Expected accuracy: **~99%** after just 5 epochs."
                ),
                "code": (
                    "correct = total = 0\n"
                    "with torch.no_grad():\n"
                    "    for images, labels in test_loader:\n"
                    "        _, predicted = torch.max(model(images), 1)\n"
                    "        total   += labels.size(0)\n"
                    "        correct += (predicted == labels).sum().item()\n"
                    "print('PyTorch CNN Accuracy:', correct / total)"
                ),
            },
        ],
    },

    13: {
        "objective": (
            "Detect **MNIST handwritten digits** (0–9) using a PyTorch CNN — "
            "similar to Assignment 12 but with a slightly different `forward()` structure, "
            "reinforcing the CNN workflow end-to-end."
        ),
        "sections": [
            {
                "heading": "1. Load MNIST Dataset",
                "explanation": (
                    "`transforms.ToTensor()` converts PIL images (0–255 uint8) to float tensors "
                    "in the range [0.0, 1.0] and adds a channel dimension: **(1×28×28)**."
                ),
                "code": (
                    "import torch, torch.nn as nn, torch.optim as optim\n"
                    "from torchvision import datasets, transforms\n"
                    "from torch.utils.data import DataLoader\n"
                    "\n"
                    "transform    = transforms.ToTensor()\n"
                    "train_data   = datasets.MNIST('./data', train=True,  download=True, transform=transform)\n"
                    "test_data    = datasets.MNIST('./data', train=False, download=True, transform=transform)\n"
                    "train_loader = DataLoader(train_data, batch_size=64, shuffle=True)\n"
                    "test_loader  = DataLoader(test_data,  batch_size=64)"
                ),
            },
            {
                "heading": "2. Define the CNN Model",
                "explanation": (
                    "The `forward()` method is written more compactly — the final fully connected "
                    "layer's output is returned directly without an extra ReLU, which is correct "
                    "since `CrossEntropyLoss` applies log-softmax internally."
                ),
                "code": (
                    "class CNN(nn.Module):\n"
                    "    def __init__(self):\n"
                    "        super().__init__()\n"
                    "        self.conv1 = nn.Conv2d(1, 32, 3)\n"
                    "        self.pool  = nn.MaxPool2d(2, 2)\n"
                    "        self.conv2 = nn.Conv2d(32, 64, 3)\n"
                    "        self.fc1   = nn.Linear(64*5*5, 100)\n"
                    "        self.fc2   = nn.Linear(100, 10)\n"
                    "\n"
                    "    def forward(self, x):\n"
                    "        x = self.pool(torch.relu(self.conv1(x)))\n"
                    "        x = self.pool(torch.relu(self.conv2(x)))\n"
                    "        x = x.view(-1, 64*5*5)\n"
                    "        x = torch.relu(self.fc1(x))\n"
                    "        return self.fc2(x)  # logits — no softmax here"
                ),
            },
            {
                "heading": "3. Initialise Model, Loss and Optimiser",
                "explanation": "Standard setup: CrossEntropyLoss + Adam optimiser with default learning rate.",
                "code": (
                    "model     = CNN()\n"
                    "criterion = nn.CrossEntropyLoss()\n"
                    "optimizer = optim.Adam(model.parameters(), lr=0.001)"
                ),
            },
            {
                "heading": "4. Train for 5 Epochs",
                "explanation": (
                    "The training loop follows the standard PyTorch pattern:\n"
                    "**zero_grad → forward → loss → backward → step**."
                ),
                "code": (
                    "for epoch in range(5):\n"
                    "    for images, labels in train_loader:\n"
                    "        optimizer.zero_grad()\n"
                    "        loss = criterion(model(images), labels)\n"
                    "        loss.backward()\n"
                    "        optimizer.step()"
                ),
            },
            {
                "heading": "5. Evaluate — Count Correct Predictions",
                "explanation": (
                    "`torch.max(output, 1)` returns the class index with the highest logit "
                    "(the predicted digit). Comparing with ground-truth `labels` gives correct count."
                ),
                "code": (
                    "correct = total = 0\n"
                    "with torch.no_grad():\n"
                    "    for images, labels in test_loader:\n"
                    "        _, predicted = torch.max(model(images), 1)\n"
                    "        total   += labels.size(0)\n"
                    "        correct += (predicted == labels).sum().item()\n"
                    "print('PyTorch Accuracy:', correct / total)"
                ),
            },
        ],
    },
}
