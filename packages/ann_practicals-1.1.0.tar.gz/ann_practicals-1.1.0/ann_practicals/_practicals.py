import json
import os
from ._assignments import ASSIGNMENTS
from ._sections import SECTIONS


def _validate(n):
    if not isinstance(n, int) or n < 1 or n > 13:
        raise ValueError(f"Assignment number must be an integer between 1 and 13, got {n!r}")


class Practicals:
    """Class-based interface to ANN practical assignments."""

    # ------------------------------------------------------------------ #
    # Functional API (mirrored from module level)                         #
    # ------------------------------------------------------------------ #

    def get_code(self, n: int) -> str:
        """Return the source code for assignment n (1–13)."""
        _validate(n)
        return ASSIGNMENTS[n]["code"]

    def get_title(self, n: int) -> str:
        """Return the title for assignment n (1–13)."""
        _validate(n)
        return ASSIGNMENTS[n]["title"]

    def get_assignment(self, n: int) -> dict:
        """Return a dict with 'title' and 'code' for assignment n (1–13)."""
        _validate(n)
        a = ASSIGNMENTS[n]
        return {"title": a["title"], "code": a["code"]}

    def list_assignments(self) -> list:
        """Return a list of (n, title) tuples for all 13 assignments."""
        return [(n, ASSIGNMENTS[n]["title"]) for n in sorted(ASSIGNMENTS)]

    # ------------------------------------------------------------------ #
    # Original class methods                                              #
    # ------------------------------------------------------------------ #

    def get_practical(self, n: int) -> dict:
        """Return assignment n as a dict with number, title, and code."""
        _validate(n)
        a = ASSIGNMENTS[n]
        return {"number": n, "title": a["title"], "code": a["code"]}

    def get_practical_by_string(self, query: str) -> list:
        """Return a list of assignments whose title or tags match the query.

        Matching is case-insensitive. Raises ValueError if nothing matches.
        """
        if not isinstance(query, str) or not query.strip():
            raise ValueError("query must be a non-empty string")
        q = query.strip().lower()
        results = []
        for n, a in ASSIGNMENTS.items():
            title_lower = a["title"].lower()
            tags = [t.lower() for t in a.get("tags", [])]
            if q in title_lower or any(q in tag or tag in q for tag in tags):
                results.append({"number": n, "title": a["title"], "code": a["code"]})
        if not results:
            raise ValueError(
                f"No assignments found matching {query!r}. "
                "Try: activation, perceptron, xor, hopfield, art, cnn, mnist, tensorflow, pytorch."
            )
        return results

    def list_all(self) -> list:
        """Return a list of (number, title) tuples for all 13 assignments."""
        return [(n, a["title"]) for n, a in sorted(ASSIGNMENTS.items())]

    # ------------------------------------------------------------------ #
    # Notebook export                                                      #
    # ------------------------------------------------------------------ #

    def export_to_notebook(self, n: int, filepath: str = None) -> str:
        """Export assignment n as a Jupyter notebook with block-by-block explanations.

        Each code section is preceded by a markdown cell explaining what it does.
        The notebook requires zero extra dependencies — it is plain JSON (nbformat 4).

        Args:
            n:        Assignment number (1–13).
            filepath: Destination path.  Defaults to ``assignment_<n>.ipynb``
                      in the current working directory.

        Returns:
            Absolute path to the saved notebook file.
        """
        _validate(n)

        if filepath is None:
            filepath = os.path.join(os.getcwd(), f"assignment_{n}.ipynb")

        filepath = os.path.abspath(filepath)
        a = ASSIGNMENTS[n]
        sec_data = SECTIONS[n]

        cells = []

        # ── Title / header cell ──────────────────────────────────────────
        cells.append(_md_cell(
            f"# Assignment {n}: {a['title']}\n\n"
            f"**Objective:** {sec_data['objective']}\n\n"
            "---"
        ))

        # ── Section cells ────────────────────────────────────────────────
        for sec in sec_data["sections"]:
            cells.append(_md_cell(f"## {sec['heading']}\n\n{sec['explanation']}"))
            cells.append(_code_cell(sec["code"]))

        nb = {
            "nbformat": 4,
            "nbformat_minor": 5,
            "metadata": {
                "kernelspec": {
                    "display_name": "Python 3",
                    "language": "python",
                    "name": "python3",
                },
                "language_info": {
                    "name": "python",
                    "version": "3.8.0",
                },
            },
            "cells": cells,
        }

        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(nb, f, indent=1, ensure_ascii=False)

        return filepath


# ── Helpers ──────────────────────────────────────────────────────────────

def _md_cell(source: str) -> dict:
    return {
        "cell_type": "markdown",
        "metadata": {},
        "source": source,
    }


def _code_cell(source: str) -> dict:
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source,
    }
