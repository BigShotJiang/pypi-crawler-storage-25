import unittest
import sys
import os
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ann_practicals import get_code, get_title, get_assignment, list_assignments, Practicals


class TestListAssignments(unittest.TestCase):
    def test_length(self):
        self.assertEqual(len(list_assignments()), 13)

    def test_ordering(self):
        nums = [n for n, _ in list_assignments()]
        self.assertEqual(nums, list(range(1, 14)))

    def test_titles_are_strings(self):
        for n, title in list_assignments():
            self.assertIsInstance(title, str)
            self.assertTrue(len(title) > 0)


class TestGetTitle(unittest.TestCase):
    def test_returns_string_for_all(self):
        for n in range(1, 14):
            result = get_title(n)
            self.assertIsInstance(result, str)
            self.assertTrue(len(result) > 0)

    def test_known_title(self):
        self.assertIn("activation", get_title(1).lower())

    def test_invalid_low(self):
        with self.assertRaises(ValueError):
            get_title(0)

    def test_invalid_high(self):
        with self.assertRaises(ValueError):
            get_title(14)

    def test_invalid_type(self):
        with self.assertRaises(ValueError):
            get_title("1")  # type: ignore


class TestGetCode(unittest.TestCase):
    def test_returns_string_for_all(self):
        for n in range(1, 14):
            result = get_code(n)
            self.assertIsInstance(result, str)
            self.assertTrue(len(result) > 0)

    def test_known_snippet_assignment2(self):
        self.assertIn("mp_neuron", get_code(2))

    def test_known_snippet_assignment10(self):
        self.assertIn("hopfield", get_code(10).lower() + get_title(10).lower())

    def test_invalid_low(self):
        with self.assertRaises(ValueError):
            get_code(0)

    def test_invalid_high(self):
        with self.assertRaises(ValueError):
            get_code(14)


class TestGetAssignment(unittest.TestCase):
    def test_keys(self):
        for n in range(1, 14):
            a = get_assignment(n)
            self.assertEqual(set(a.keys()), {"title", "code"})

    def test_returns_copy(self):
        a1 = get_assignment(1)
        a1["title"] = "mutated"
        a2 = get_assignment(1)
        self.assertNotEqual(a2["title"], "mutated")

    def test_invalid(self):
        with self.assertRaises(ValueError):
            get_assignment(0)


class TestPracticals(unittest.TestCase):
    def setUp(self):
        self.p = Practicals()

    def test_get_practical_returns_dict(self):
        a = self.p.get_practical(1)
        self.assertEqual(set(a.keys()), {"number", "title", "code"})
        self.assertEqual(a["number"], 1)

    def test_get_practical_all_valid(self):
        for n in range(1, 14):
            a = self.p.get_practical(n)
            self.assertEqual(a["number"], n)

    def test_get_practical_invalid(self):
        with self.assertRaises(ValueError):
            self.p.get_practical(0)
        with self.assertRaises(ValueError):
            self.p.get_practical(14)

    def test_list_all_length(self):
        self.assertEqual(len(self.p.list_all()), 13)

    def test_get_practical_by_string_activation(self):
        results = self.p.get_practical_by_string("activation function")
        self.assertTrue(len(results) >= 1)
        self.assertEqual(results[0]["number"], 1)

    def test_get_practical_by_string_hopfield(self):
        results = self.p.get_practical_by_string("hopfield")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["number"], 10)

    def test_get_practical_by_string_perceptron(self):
        results = self.p.get_practical_by_string("perceptron")
        nums = [r["number"] for r in results]
        self.assertIn(3, nums)
        self.assertIn(4, nums)

    def test_get_practical_by_string_cnn(self):
        results = self.p.get_practical_by_string("cnn")
        nums = [r["number"] for r in results]
        self.assertIn(12, nums)
        self.assertIn(13, nums)

    def test_get_practical_by_string_no_match(self):
        with self.assertRaises(ValueError):
            self.p.get_practical_by_string("zzznomatch")

    def test_get_practical_by_string_case_insensitive(self):
        results_lower = self.p.get_practical_by_string("hopfield")
        results_upper = self.p.get_practical_by_string("HOPFIELD")
        self.assertEqual(results_lower[0]["number"], results_upper[0]["number"])

    # -- mirrored functional methods on class --
    def test_class_get_code(self):
        self.assertEqual(self.p.get_code(2), self.p.get_practical(2)["code"])

    def test_class_get_title(self):
        self.assertEqual(self.p.get_title(1), self.p.get_practical(1)["title"])

    def test_class_get_assignment_keys(self):
        a = self.p.get_assignment(5)
        self.assertEqual(set(a.keys()), {"title", "code"})

    def test_class_list_assignments(self):
        lst = self.p.list_assignments()
        self.assertEqual(len(lst), 13)
        self.assertEqual([n for n, _ in lst], list(range(1, 14)))


class TestNotebookExport(unittest.TestCase):
    def setUp(self):
        self.p = Practicals()
        self.tmp = os.path.join(os.path.dirname(__file__), "_test_nb.ipynb")

    def tearDown(self):
        if os.path.exists(self.tmp):
            os.remove(self.tmp)

    def test_creates_file(self):
        path = self.p.export_to_notebook(1, self.tmp)
        self.assertTrue(os.path.exists(path))

    def test_returns_absolute_path(self):
        path = self.p.export_to_notebook(1, self.tmp)
        self.assertTrue(os.path.isabs(path))

    def test_valid_json(self):
        self.p.export_to_notebook(1, self.tmp)
        with open(self.tmp, encoding="utf-8") as f:
            nb = json.load(f)
        self.assertIn("cells", nb)
        self.assertEqual(nb["nbformat"], 4)

    def test_has_markdown_and_code_cells(self):
        self.p.export_to_notebook(1, self.tmp)
        with open(self.tmp, encoding="utf-8") as f:
            nb = json.load(f)
        types = [c["cell_type"] for c in nb["cells"]]
        self.assertIn("markdown", types)
        self.assertIn("code", types)

    def test_title_in_first_cell(self):
        self.p.export_to_notebook(1, self.tmp)
        with open(self.tmp, encoding="utf-8") as f:
            nb = json.load(f)
        first = nb["cells"][0]["source"]
        self.assertIn("Assignment 1", first)

    def test_all_assignments_export(self):
        for n in range(1, 14):
            path = self.p.export_to_notebook(n, self.tmp)
            with open(path, encoding="utf-8") as f:
                nb = json.load(f)
            self.assertTrue(len(nb["cells"]) >= 3)

    def test_invalid_raises(self):
        with self.assertRaises(ValueError):
            self.p.export_to_notebook(0, self.tmp)

    def test_default_filename(self):
        path = self.p.export_to_notebook(5)
        try:
            self.assertIn("assignment_5.ipynb", path)
        finally:
            if os.path.exists(path):
                os.remove(path)


if __name__ == "__main__":
    unittest.main()
