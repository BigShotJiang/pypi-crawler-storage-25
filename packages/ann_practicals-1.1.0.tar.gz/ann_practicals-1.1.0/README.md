# ann-practicals

A zero-dependency Python package to retrieve ANN (Artificial Neural Network) practical
assignment codes and titles by number.

## Installation

```bash
pip install ann-practicals
```

## Usage

```python
from ann_practicals import get_code, get_title, get_assignment, list_assignments

# List all 13 assignments
for n, title in list_assignments():
    print(n, title)

# Get title for assignment 1
print(get_title(1))
# → "Plot activation functions (Sigmoid, ReLU, Tanh) using a Neuron class"

# Get code for assignment 2
print(get_code(2))

# Get both title and code as a dict
a = get_assignment(3)
print(a["title"])
print(a["code"])
```

## Assignments

| # | Title |
|---|-------|
| 1 | Plot activation functions (Sigmoid, ReLU, Tanh) using a Neuron class |
| 2 | Generate ANDNOT function using McCulloch-Pitts neural net |
| 3 | Perceptron Neural Network to recognise even and odd numbers (ASCII 0-9) |
| 4 | Perceptron learning law with decision regions (graphical) |
| 5 | ANN training process using Forward Propagation and Back Propagation |
| 6 | Neural network from scratch for multi-class classification (Iris dataset, ReLU) |
| 7 | Back Propagation Network for XOR function with Binary Input and Output |
| 8 | ART (Adaptive Resonance Theory) neural network |
| 9 | Back Propagation Feedforward neural network (XOR) |
| 10 | Hopfield Network storing 4 vectors |
| 11 | Train a Neural Network with TensorFlow and evaluate logistic regression |
| 12 | PyTorch implementation of CNN on MNIST |
| 13 | MNIST Handwritten Character Detection using PyTorch |

## License

MIT
