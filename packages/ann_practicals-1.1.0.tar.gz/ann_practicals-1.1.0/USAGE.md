# ann-practicals — Usage Guide

## Installation

```bash
pip install ann-practicals
```

---

## Two Ways to Use

The package provides two styles of API:

| Style | When to use |
|-------|-------------|
| **Functional** (`get_code`, `get_title`, …) | Quick one-liners, scripting |
| **Class-based** (`Practicals`) | When you want an object to work with |

---

## Functional API

### Import

```python
from ann_practicals import get_code, get_title, get_assignment, list_assignments
```

### List all assignments

```python
for n, title in list_assignments():
    print(n, title)
```

Output:
```
1  Plot activation functions (Sigmoid, ReLU, Tanh) using a Neuron class
2  Generate ANDNOT function using McCulloch-Pitts neural net
3  Perceptron Neural Network to recognise even and odd numbers (ASCII 0-9)
...
13 MNIST Handwritten Character Detection using PyTorch
```

### Get a title

```python
print(get_title(1))
# Plot activation functions (Sigmoid, ReLU, Tanh) using a Neuron class
```

### Get the code

```python
print(get_code(2))
```

```python
# McCulloch-Pitts Neuron for AND-NOT Function
def mp_neuron(A, B):
    w1 = 1
    w2 = -1
    ...
```

### Get title + code together

```python
a = get_assignment(5)
print(a["title"])
print(a["code"])
```

---

## Class-based API

### Import and initialise

```python
from ann_practicals import Practicals

p = Practicals()
```

### Get by number — `get_practical(n)`

```python
a = p.get_practical(10)

print(a["number"])  # 10
print(a["title"])   # Hopfield Network storing 4 vectors
print(a["code"])    # full Python code
```

### Search by keyword — `get_practical_by_string(query)`

Returns a **list** of matching assignments (there can be more than one).

```python
# Single match
results = p.get_practical_by_string("hopfield")
print(results[0]["title"])
# → Hopfield Network storing 4 vectors

# Multiple matches
results = p.get_practical_by_string("perceptron")
for r in results:
    print(r["number"], r["title"])
# → 3  Perceptron Neural Network to recognise even and odd numbers (ASCII 0-9)
# → 4  Perceptron learning law with decision regions (graphical)

# More examples
p.get_practical_by_string("cnn")                # → assignments 12, 13
p.get_practical_by_string("xor")                # → assignments 5, 7, 9
p.get_practical_by_string("activation")         # → assignment 1
p.get_practical_by_string("activation function")# → assignment 1
p.get_practical_by_string("tensorflow")         # → assignment 11
p.get_practical_by_string("pytorch")            # → assignments 12, 13
p.get_practical_by_string("art")                # → assignment 8
p.get_practical_by_string("backpropagation")    # → assignments 5, 7, 9
```

> Matching is **case-insensitive**, so `"CNN"`, `"cnn"`, and `"Cnn"` all work.

### Print the code directly

```python
results = p.get_practical_by_string("hopfield")
print(results[0]["code"])
```

### List all assignments

```python
for n, title in p.list_all():
    print(n, title)
```

---

## Searchable Keywords

| Keyword(s) | Matches assignment(s) |
|---|---|
| `activation`, `activation function`, `sigmoid`, `relu`, `tanh` | 1 |
| `andnot`, `mcculloch`, `pitts`, `mp neuron` | 2 |
| `perceptron`, `even`, `odd`, `ascii` | 3, 4 |
| `decision`, `boundary`, `decision region` | 4 |
| `forward propagation`, `backpropagation`, `xor`, `ann` | 5, 7, 9 |
| `multiclass`, `classification`, `iris`, `softmax`, `scratch` | 6 |
| `art`, `adaptive resonance`, `clustering` | 8 |
| `hopfield`, `hebbian`, `memory`, `bipolar`, `recall` | 10 |
| `tensorflow`, `keras`, `logistic`, `logistic regression`, `tf` | 11 |
| `cnn`, `convolutional`, `pytorch`, `mnist` | 12, 13 |
| `handwritten`, `character`, `detection` | 13 |

---

## Error Handling

```python
# Invalid number
p.get_practical(0)   # ValueError: Assignment number must be between 1 and 13
p.get_practical(14)  # ValueError: Assignment number must be between 1 and 13

# No keyword match
p.get_practical_by_string("transformer")
# ValueError: No assignments found matching 'transformer'.
# Try keywords like: activation, perceptron, xor, hopfield, art, cnn, mnist, tensorflow, pytorch.
```

---

## All 13 Assignments

| # | Title |
|---|-------|
| 1 | Plot activation functions (Sigmoid, ReLU, Tanh) using a Neuron class |
| 2 | Generate ANDNOT function using McCulloch-Pitts neural net |
| 3 | Perceptron Neural Network to recognise even and odd numbers (ASCII 0-9) |
| 4 | Perceptron learning law with decision regions (graphical) |
| 5 | ANN training process using Forward Propagation and Back Propagation |
| 6 | Neural network from scratch for multi-class classification (Iris, ReLU) |
| 7 | Back Propagation Network for XOR with Binary Input and Output |
| 8 | ART (Adaptive Resonance Theory) neural network |
| 9 | Back Propagation Feedforward neural network (XOR) |
| 10 | Hopfield Network storing 4 vectors |
| 11 | Train a Neural Network with TensorFlow + evaluate logistic regression |
| 12 | PyTorch implementation of CNN on MNIST |
| 13 | MNIST Handwritten Character Detection using PyTorch |
