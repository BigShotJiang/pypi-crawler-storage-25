"""Diagnostic package."""

