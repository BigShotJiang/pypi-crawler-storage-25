"""Search index package."""

