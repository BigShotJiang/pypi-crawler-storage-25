"""Engine-core compatibility entrypoints with safe optional imports."""

from kogwistar.engine_core.engine import GraphKnowledgeEngine
from kogwistar.engine_core.engine_sqlite import EngineSQLite, IndexJobRow
from kogwistar.engine_core.indexing import IndexingSubsystem
from kogwistar.engine_core.lifecycle import LifecycleSubsystem
from kogwistar.engine_core.subsystems import (
    AdjudicateSubsystem,
    EmbedSubsystem,
    ExtractSubsystem,
    IngestSubsystem,
    PersistSubsystem,
    ReadSubsystem,
    RollbackSubsystem,
    WriteSubsystem,
)
from kogwistar.engine_core.storage_backend import (
    NoopUnitOfWork,
    StorageBackend,
    UnitOfWork,
)
from kogwistar.engine_core.types import (
    EngineType,
    ExtractionSchemaMode,
    OffsetMismatchPolicy,
    OffsetRepairScorer,
    ResolvedExtractionSchemaMode,
)

__all__ = [
    "GraphKnowledgeEngine",
    "EnginePostgresConfig",
    "build_postgres_backend",
    "build_async_postgres_backend",
    "EnginePostgresMetaStore",
    "IndexJob",
    "EngineSQLite",
    "IndexJobRow",
    "IndexingSubsystem",
    "LifecycleSubsystem",
    "PgVectorBackend",
    "PgVectorConfig",
    "PostgresUnitOfWork",
    "AsyncPostgresUnitOfWork",
    "ChromaBackend",
    "NoopUnitOfWork",
    "StorageBackend",
    "UnitOfWork",
    "EngineType",
    "ExtractionSchemaMode",
    "ResolvedExtractionSchemaMode",
    "OffsetMismatchPolicy",
    "OffsetRepairScorer",
    "ReadSubsystem",
    "WriteSubsystem",
    "ExtractSubsystem",
    "PersistSubsystem",
    "RollbackSubsystem",
    "AdjudicateSubsystem",
    "IngestSubsystem",
    "EmbedSubsystem",
    "InMemoryBackend",
    "build_in_memory_backend",
]


def __getattr__(name: str):
    if name == "ChromaBackend":
        from kogwistar.engine_core.chroma_backend import ChromaBackend

        return ChromaBackend

    if name in {"InMemoryBackend", "build_in_memory_backend"}:
        from kogwistar.engine_core.in_memory_backend import (
            InMemoryBackend,
            build_in_memory_backend,
        )
        return {
            "InMemoryBackend": InMemoryBackend,
            "build_in_memory_backend": build_in_memory_backend,
        }[name]

    if name in {"EnginePostgresConfig", "build_postgres_backend", "build_async_postgres_backend"}:
        try:
            from kogwistar.engine_core.engine_postgres import (
                EnginePostgresConfig,
                build_postgres_backend,
                build_async_postgres_backend,
            )
        except Exception as e:  # pragma: no cover - optional dependency path
            raise RuntimeError(
                "Postgres backend support requires optional dependencies. "
                "Install with: pip install 'kogwistar[pgvector]'"
            ) from e
        return {
            "EnginePostgresConfig": EnginePostgresConfig,
            "build_postgres_backend": build_postgres_backend,
            "build_async_postgres_backend": build_async_postgres_backend,
        }[name]

    if name in {"EnginePostgresMetaStore", "IndexJob"}:
        try:
            from kogwistar.engine_core.engine_postgres_meta import (
                EnginePostgresMetaStore,
                IndexJob,
            )
        except Exception as e:  # pragma: no cover - optional dependency path
            raise RuntimeError(
                "Postgres meta store requires optional dependencies. "
                "Install with: pip install 'kogwistar[pgvector]'"
            ) from e
        return {
            "EnginePostgresMetaStore": EnginePostgresMetaStore,
            "IndexJob": IndexJob,
        }[name]

    if name in {"PgVectorBackend", "PgVectorConfig", "PostgresUnitOfWork", "AsyncPostgresUnitOfWork"}:
        try:
            from kogwistar.engine_core.postgres_backend import (
                PgVectorBackend,
                PgVectorConfig,
                PostgresUnitOfWork,
                AsyncPostgresUnitOfWork,
            )
        except Exception as e:  # pragma: no cover - optional dependency path
            raise RuntimeError(
                "PgVector backend requires optional dependencies. "
                "Install with: pip install 'kogwistar[pgvector]'"
            ) from e
        return {
            "PgVectorBackend": PgVectorBackend,
            "PgVectorConfig": PgVectorConfig,
            "PostgresUnitOfWork": PostgresUnitOfWork,
            "AsyncPostgresUnitOfWork": AsyncPostgresUnitOfWork,
        }[name]

    raise AttributeError(name)
