"""Graph navigation agent package."""

