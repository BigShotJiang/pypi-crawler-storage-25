from __future__ import annotations
from os import PathLike
import warnings

import copy
import time
import json
import uuid
import queue
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple, cast
from concurrent.futures import ThreadPoolExecutor
import pathlib
import logging
from contextlib import contextmanager, nullcontext

from kogwistar.id_provider import stable_id
from kogwistar.utils.log import bind_log_context
from kogwistar.runtime.models import StateUpdate
from kogwistar.engine_core.models import MentionVerification
from kogwistar.runtime.models import (
    RunFailure,
    WorkflowCancelledNode,
    WorkflowCheckpointNode,
    WorkflowCompletedNode,
    WorkflowFailedNode,
    WorkflowEdge,
    WorkflowDesignArtifact,
    WorkflowNode,
    WorkflowInvocationRequest,
    WorkflowRunNode,
    WorkflowRuntimeEdge,
    WorkflowState,
    WorkflowStepExecNode,
)

from .design import validate_workflow_design, Predicate
from .serialize import try_serialize_with_ref

RESERVED_ROOT_KEYS = {
    "_deps",
    "_rt_join",
}

RESERVED_PREFIXES = ("_", "__")


def validate_initial_state(initial_state: WorkflowState):
    """Validate user-provided initial workflow state.

    Workflow state is user-land *except* for a small set of underscore-prefixed
    keys that are reserved for runtime/DI plumbing.

    Allowed underscore keys:
      - _deps    : injected dependencies (non-serializable; must not be checkpointed)
      - _rt_join : runtime-owned join/barrier bookkeeping (checkpoint/resume)

    All other keys starting with '_' are reserved and will be rejected.

    Note: when underscore keys are present, we emit a RuntimeWarning to make the
    use of advanced/internal features explicit (helps debugging).
    """
    allowed_underscore = {"_deps", "_rt_join"}

    for key in initial_state:
        if key in allowed_underscore:
            warnings.warn(
                f"Using advanced underscore state key '{key}'. This key is reserved for runtime/DI plumbing.",
                RuntimeWarning,
                stacklevel=2,
            )
            continue

        # _deps and _rt_join are the only allowed reserved runtime keys.

        if key.startswith(RESERVED_PREFIXES):
            raise ValueError(
                f"Keys starting with '_' or '__' are reserved. Invalid key: '{key}'"
            )


# ------------------------------------------------------------------
# Join/barrier support (capability tracking via MAY-reach bitsets)
# ------------------------------------------------------------------


def _tarjan_scc(n: int, succ: list[list[int]]) -> tuple[list[int], list[list[int]]]:
    """
    Tarjan SCC.
    Returns:
      comp_of[v] -> component id
      comps -> list of components (each is list of vertices)
    """
    index = 0
    stack: list[int] = []
    onstack = [False] * n
    idxs = [-1] * n
    low = [0] * n
    comp_of = [-1] * n
    comps: list[list[int]] = []

    def strongconnect(v: int) -> None:
        nonlocal index
        idxs[v] = index
        low[v] = index
        index += 1
        stack.append(v)
        onstack[v] = True

        for w in succ[v]:
            if idxs[w] == -1:
                strongconnect(w)
                low[v] = low[v] if low[v] < low[w] else low[w]
            elif onstack[w]:
                low[v] = low[v] if low[v] < idxs[w] else idxs[w]

        if low[v] == idxs[v]:
            comp_id = len(comps)
            comp: list[int] = []
            while True:
                w = stack.pop()
                onstack[w] = False
                comp_of[w] = comp_id
                comp.append(w)
                if w == v:
                    break
            comps.append(comp)

    for v in range(n):
        if idxs[v] == -1:
            strongconnect(v)

    return comp_of, comps


def _compute_may_reach_join_bitsets(
    *,
    node_ids: list[str],
    adj: dict[str, list["WorkflowEdge"]],
    join_ids: list[str],
) -> dict[str, int]:
    """
    Over-approximate: for every node, compute the set of join/barrier nodes it MAY reach,
    ignoring predicates (static topology only).

    Output is a dict node_id -> bitset (int) where bit i means MAY reach join_ids[i].
    """
    n = len(node_ids)
    id_to_i = {nid: i for i, nid in enumerate(node_ids)}
    succ: list[list[int]] = [[] for _ in range(n)]
    for src, edges in adj.items():
        si = id_to_i.get(src)
        if si is None:
            continue
        for e in edges:
            for dst in getattr(e, "target_ids", []) or []:
                di = id_to_i.get(str(dst))
                if di is not None:
                    succ[si].append(di)

    comp_of, comps = _tarjan_scc(n, succ)
    c = len(comps)

    # component join mask
    join_pos = {jid: p for p, jid in enumerate(join_ids)}
    comp_join_mask = [0] * c
    for v_nid in node_ids:
        p = join_pos.get(v_nid)
        if p is None:
            continue
        v = id_to_i[v_nid]
        comp_join_mask[comp_of[v]] |= 1 << p

    # condensation DAG
    comp_succ: list[set[int]] = [set() for _ in range(c)]
    indeg = [0] * c
    for v in range(n):
        cv = comp_of[v]
        for w in succ[v]:
            cw = comp_of[w]
            if cv != cw and cw not in comp_succ[cv]:
                comp_succ[cv].add(cw)
                indeg[cw] += 1

    # topo order (Kahn)
    q = [i for i in range(c) if indeg[i] == 0]
    topo: list[int] = []
    while q:
        x = q.pop()
        topo.append(x)
        for y in comp_succ[x]:
            indeg[y] -= 1
            if indeg[y] == 0:
                q.append(y)

    # dp in reverse topo: may_reach[comp] = comp_join | OR succ
    may = comp_join_mask[:]
    for x in reversed(topo):
        m = may[x]
        for y in comp_succ[x]:
            m |= may[y]
        may[x] = m
    out: dict[str, int] = {}
    for nid in node_ids:
        out[nid] = may[comp_of[id_to_i[nid]]]
    return out


def _iter_bits(mask: int):
    """Yield bit positions (0-based) for an int bitset."""
    # 2's complement tricks to get the first set least significant bit in binary representation
    while mask:
        lsb = mask & -mask
        yield (lsb.bit_length() - 1)
        mask ^= lsb


RunID = uuid.UUID | str
Json = Any
State = Dict[str, Json]
# Result = Json
from typing import TypeAlias, Any
from .contract import WorkflowEdgeInfo


from kogwistar.engine_core.models import Grounding, Span

from .models import StepRunResult

StepFn: TypeAlias = Callable[["StepContext"], StepRunResult]

from dataclasses import field
from typing import Dict, Mapping
from types import MappingProxyType
import threading


@dataclass
class RunResult:
    run_id: str
    final_state: WorkflowState
    mq: queue.Queue[Dict[str, Json]]
    status: str = "succeeded"


class _StateWriteTxn:
    def __init__(self, ctx: "StepContext"):
        self._ctx = ctx

    def __enter__(self) -> WorkflowState:
        self._ctx._state_lock.acquire()
        # optional:
        # self._ctx.publish({"type": "state_write_start", "op": self._ctx.op})
        return self._ctx._state

    def __exit__(self, exc_type, exc, tb) -> None:
        # optional:
        # self._ctx.publish({"type": "state_write_end", "op": self._ctx.op, "ok": exc is None})
        self._ctx._state_lock.release()


from dataclasses import dataclass, InitVar
from typing import Dict

from .telemetry import (
    TraceContext,
    SQLiteEventSink,
    EventEmitter,
    bind_logger,
    BoundLoggerAdapter,
)
from kogwistar.cdc.sqlite_sink import _get_shared_sqlite_sink


@dataclass
class RouteDecision:
    """Structured routing outcome used for trace emission.

    evaluated: list of (edge_id_with_predicate, ok) entries for every predicate/base evaluation attempted.
    selected:  list of (edge_id, to_node_id, reason) entries for chosen edges.
    """

    evaluated: List[Tuple[str, bool]]
    selected: List[Tuple[str, str, str]]


@dataclass
class StepContext:
    # --- execution identity ---
    run_id: str
    workflow_id: str
    workflow_node_id: str
    op: str
    token_id: str
    attempt: int
    step_seq: int
    cache_dir: str | PathLike | None

    # --- optional provenance (may be None for non-conversational workloads) ---
    conversation_id: str | None = None
    turn_node_id: str | None = None

    # --- runtime capabilities ---
    message_queue: "queue.Queue[Dict[str, Json]]" = field(
        repr=False, default_factory=queue.Queue
    )
    events: EventEmitter | None = field(repr=False, default=None)

    # Accept `state=` in __init__ but don't store it as a field
    state: InitVar["WorkflowState"] = None  # type: ignore[assignment]

    # real storage
    _state: "WorkflowState" = field(init=False, repr=False)
    _state_lock: threading.RLock = field(
        default_factory=threading.RLock, init=False, repr=False
    )
    log: BoundLoggerAdapter = field(init=False, repr=False)
    
    def __post_init__(self, state: "WorkflowState") -> None:
        self._state = state
        # bind a correlated logger for resolver-level details
        self.log = bind_logger(logging.getLogger("workflow.resolver"), self.trace_ctx)

    @property
    def state_view(self) -> Mapping[str, Json]:
        return MappingProxyType(self._state)

    @property
    def state_write(self) -> "_StateWriteTxn":
        return _StateWriteTxn(self)

    def publish(self, msg: Dict[str, Json]) -> None:
        self.message_queue.put(msg)

    def drain(self, max_items: int = 200) -> List[Dict[str, Json]]:
        raise Exception(
            "current design does not allow mq drained in context, but only by orchestrator"
        )

    @property
    def trace_ctx(self) -> TraceContext:
        # generic trace context; conversation_id/turn_node_id may be None
        return TraceContext(
            run_id=self.run_id,
            token_id=self.token_id,
            step_seq=self.step_seq,
            node_id=self.workflow_node_id,
            attempt=self.attempt,
            conversation_id=self.conversation_id,
            turn_node_id=self.turn_node_id,
        )

    # Back-compat alias: older code used conv_trace_ctx
    @property
    def conv_trace_ctx(self) -> TraceContext:
        return self.trace_ctx


def _now_ms() -> int:
    return int(time.time() * 1000)


def _make_trace_span(*, conversation_id: str, excerpt: str, doc_id: str) -> Any:
    # We avoid importing models here to keep the runtime module lightweight.
    # The orchestrator will pass in a ready Span via a hook, OR we can create a minimal span-like dict.
    # In your repo, you already have Span model and Grounding/MentionVerification.
    return {
        "collection_page_url": f"conversation/{conversation_id}",
        "document_page_url": f"conversation/{conversation_id}",
        "doc_id": doc_id,
        "insertion_method": "workflow_trace",
        "page_number": 1,
        "start_char": 0,
        "end_char": len(excerpt),
        "excerpt": excerpt,
        "context_before": "",
        "context_after": "",
        "chunk_id": None,
        "source_cluster_id": None,
        "verification": {
            "method": "human",
            "is_verified": True,
            "score": 1.0,
            "notes": "workflow trace",
        },
    }


def _make_runtime_edge(
    *,
    edge_id: str,
    relation: str,
    label: str,
    summary: str,
    doc_id: str,
    conversation_id: str,
    source_ids: list[str],
    target_ids: list[str],
    mentions: list[Grounding],
    run_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> WorkflowRuntimeEdge:
    edge_metadata = {
        "entity_type": "conversation_edge",
        "relation": relation,
        "conversation_id": conversation_id,
    }
    if run_id is not None:
        edge_metadata["run_id"] = run_id
    if metadata:
        edge_metadata.update(metadata)
    return WorkflowRuntimeEdge(
        id=edge_id,
        source_ids=source_ids,
        target_ids=target_ids,
        relation=relation,
        label=label,
        type="relationship",
        summary=summary,
        doc_id=doc_id,
        mentions=mentions,
        domain_id=None,
        canonical_entity_id=None,
        properties={},
        embedding=None,
        metadata=edge_metadata,
        source_edge_ids=[],
        target_edge_ids=[],
    )


from threading import Lock


class WorkflowRuntime:
    """
    Core engine for executing graph-based **workflow designs**.

    This runtime:
    1.  Reads the workflow design (nodes/edges) from the `workflow_engine`.
    2.  Executes steps using the provided `step_resolver`.
    3.  Manages state transitions, branching, and join/barrier logic.
    4.  Persists execution traces (`WorkflowRunNode`, `WorkflowStepExecNode`) and checkpoints
        to the `conversation_engine` (or whichever engine is designated for traces).

    It is the backend execution engine used by high-level orchestrators like `ConversationOrchestrator`.
    """

    def __init__(
        self,
        *,
        workflow_engine: Any,
        conversation_engine: Any,
        step_resolver: Callable[[str], StepFn],
        predicate_registry: Dict[str, Predicate],
        checkpoint_every_n_steps: int = 1,
        max_workers: int = 4,
        transaction_mode: str | None = None,  # "step" | "run" | "none" (default auto)
        # Quick-fix knobs for nested runs / resource sharing
        trace: bool = True,
        events: EventEmitter | None = None,
        sink: SQLiteEventSink | None = None,
        cancel_requested: Callable[[str], bool] | None = None,
        fast_trace_persistence: bool | None = None,
    ) -> None:
        from kogwistar.engine_core.engine import GraphKnowledgeEngine

        self.workflow_engine: GraphKnowledgeEngine = workflow_engine
        self.conversation_engine: GraphKnowledgeEngine = conversation_engine
        self.step_resolver: Callable[[str], Callable[..., StepRunResult]] = (
            step_resolver
        )
        self.predicate_registry = predicate_registry
        self.checkpoint_every_n_steps = max(1, int(checkpoint_every_n_steps))
        self.max_workers = max_workers
        self.cancel_requested = cancel_requested
        if fast_trace_persistence is None:
            self.fast_trace_persistence = (
                str(getattr(conversation_engine, "backend_kind", "")).lower() == "memory"
            )
        else:
            self.fast_trace_persistence = bool(fast_trace_persistence)
        # Transaction policy: default to per-step transactions when conversation_engine is Postgres-backed.
        if transaction_mode is None:
            try:
                from kogwistar.engine_core.postgres_backend import (
                    PgVectorBackend,
                )

                self.transaction_mode = (
                    "step"
                    if isinstance(
                        getattr(conversation_engine, "backend", None), PgVectorBackend
                    )
                    else "none"
                )
            except Exception:
                self.transaction_mode = "none"
        else:
            self.transaction_mode = str(transaction_mode)
        self.state_lock: dict[RunID, Lock] = {}  # look up of run specific state lock

        # --------------------------------------------------------------
        # Trace plumbing (quick-fix for nested runtimes)
        # --------------------------------------------------------------
        # If an EventEmitter is provided, reuse it (prevents duplicate writers).
        if events is not None:
            self.emitter = events
            self.sink = getattr(events, "sink", None)
        else:
            if sink is not None:
                self.sink = sink
            elif not trace:
                self.sink = None
            else:
                self.sink = None
                if getattr(workflow_engine, "persist_directory", None) is not None:
                    db_path = str(
                        pathlib.Path(workflow_engine.persist_directory)
                        / "wf_trace.sqlite"
                    )
                    # Share a single sink per db_path in this process to reduce SQLite contention.
                    self.sink = _get_shared_sqlite_sink(db_path, drop_when_full=True)
            self.emitter = EventEmitter(
                sink=self.sink, logger=logging.getLogger("workflow.trace")
            )

    @contextmanager
    def _trace_write_mode(self):
        eng = self.conversation_engine
        if not self.fast_trace_persistence:
            yield
            return
        prev_idx = getattr(eng, "_phase1_enable_index_jobs", False)
        eng._phase1_enable_index_jobs = False
        try:
            yield
        finally:
            eng._phase1_enable_index_jobs = prev_idx

    def _maybe_step_uow(self):
        """Open a UoW transaction only when transaction_mode=='step'.

        This keeps callsites clean:
            with self._maybe_step_uow():
                ...
        """
        if self.transaction_mode == "step":
            return self.conversation_engine.uow()
        return nullcontext()

    def _close_sandbox_run(self, run_id: str) -> None:
        close_run = getattr(self.step_resolver, "close_sandbox_run", None)
        if callable(close_run):
            try:
                close_run(str(run_id))
            except Exception:
                logging.getLogger("workflow.runtime").exception(
                    "Failed to clean up sandbox resources for run %s",
                    run_id,
                )

    def _should_step_uow(self, op: str, state: WorkflowState) -> bool:
        """Best-effort guard to avoid holding a step UoW across nested workflow execution.

        Quick fix: if the current op is marked as a "nested op" by the resolver
        (MappingStepResolver.nested_ops), we skip the outer step UoW so the nested
        workflow can perform its own per-step UoWs without deadlocking/contending.

        Fallback: if resolver doesn't expose nested_ops, keep the old heuristic for
        `answer` calling `agent.answer_workflow_v2`.
        """
        if self.transaction_mode != "step":
            return False
        try:
            nested_ops = getattr(self.step_resolver, "nested_ops", None)
            if isinstance(nested_ops, set) and str(op) in nested_ops:
                return False

            if str(op) == "answer":
                deps = state.get("_deps") if isinstance(state, dict) else None
                if isinstance(deps, dict):
                    agent = deps.get("agent")
                    if agent is not None and hasattr(agent, "answer_workflow_v2"):
                        return False
        except Exception:
            return True
        return True

    def _persist_workflow_design_artifact(
        self, design: WorkflowDesignArtifact
    ) -> None:
        """Persist a workflow design artifact into the workflow engine.

        The engine's write path is intentionally idempotent-friendly, so we rely on
        stable node/edge identifiers instead of introducing a separate design store.
        """

        for node in design.nodes:
            self.workflow_engine.write.add_node(node)
        for edge in design.edges:
            self.workflow_engine.write.add_edge(edge)

    def _child_workflow_initial_state(
        self,
        *,
        parent_state: WorkflowState,
        invocation: WorkflowInvocationRequest,
    ) -> WorkflowState:
        child_state: WorkflowState = dict(parent_state) # type: ignore
        child_state.pop("_rt_join", None)
        if invocation.initial_state:
            child_state.update(copy.deepcopy(invocation.initial_state)) # type: ignore

        deps = dict(child_state.get("_deps") or parent_state.get("_deps") or {}) # type: ignore
        deps["workflow_runtime"] = self # type: ignore
        child_state["_deps"] = deps # type: ignore
        return child_state

    def _run_workflow_invocation(
        self,
        *,
        invocation: WorkflowInvocationRequest,
        parent_state: WorkflowState,
        conversation_id: str,
        turn_node_id: str,
        parent_run_id: str,
        cache_dir: str | PathLike | None = None,
    ) -> RunResult:
        if invocation.workflow_design is not None:
            if str(invocation.workflow_design.workflow_id) != str(
                invocation.workflow_id
            ):
                raise ValueError(
                    "workflow_design.workflow_id must match workflow_id on the invocation"
                )
            self._persist_workflow_design_artifact(invocation.workflow_design)

        child_state = self._child_workflow_initial_state(
            parent_state=parent_state, invocation=invocation
        )
        child_run_id = invocation.run_id or str(
            stable_id(
                "workflow.child_run",
                parent_run_id,
                invocation.workflow_id,
                invocation.result_state_key or "",
                invocation.turn_node_id or turn_node_id,
            )
        )
        return self.run(
            workflow_id=invocation.workflow_id,
            conversation_id=invocation.conversation_id or conversation_id,
            turn_node_id=invocation.turn_node_id or turn_node_id,
            initial_state=child_state,
            run_id=child_run_id,
            cache_dir=cache_dir,
        )

    def _apply_workflow_invocation_result(
        self,
        *,
        state: WorkflowState,
        invocation: WorkflowInvocationRequest,
        child_result: RunResult,
    ) -> None:
        result_key = invocation.result_state_key or f"workflow_result::{invocation.workflow_id}"
        child_state = dict(child_result.final_state)
        child_state.pop("_deps", None)
        child_state.pop("_rt_join", None)
        state[result_key] = copy.deepcopy(child_state)
        state[f"{result_key}__run_id"] = str(child_result.run_id)
        state[f"{result_key}__status"] = str(child_result.status)
        state[f"{result_key}__workflow_id"] = str(invocation.workflow_id)

    def run_subworkflow(
        self,
        *,
        workflow_id: str,
        parent_state: WorkflowState,
        conversation_id: str,
        turn_node_id: str,
        parent_run_id: str,
        result_state_key: str | None = None,
        workflow_design: WorkflowDesignArtifact | None = None,
        initial_state: dict[str, Any] | None = None,
        run_id: str | None = None,
        cache_dir: str | PathLike | None = None,
    ) -> RunResult:
        """Public helper for explicit nested workflow execution."""

        invocation = WorkflowInvocationRequest(
            workflow_id=workflow_id,
            initial_state=dict(initial_state or {}),
            result_state_key=result_state_key,
            workflow_design=workflow_design,
            run_id=run_id,
        )
        return self._run_workflow_invocation(
            invocation=invocation,
            parent_state=parent_state,
            conversation_id=conversation_id,
            turn_node_id=turn_node_id,
            parent_run_id=parent_run_id,
            cache_dir=cache_dir,
        )

    def apply_state_update(
        self,
        mute_state: WorkflowState,
        state_update: list[tuple[str, dict[str, Any]]] | list[StateUpdate],
        update: dict | None = None,
    ):
        # inplace update state
        if update and state_update:
            raise Exception("Either update or state_update can be used")

        for update_item in state_update:  # CR style state api
            update_item: tuple[str, dict[str, Any]] | StateUpdate
            if update_item[0] == "a":  # append
                append_dict: dict = update_item[1]
                for k, v in append_dict.items():
                    mute_state.setdefault(k, []).append(v)
            elif update_item[0] == "u":  # update by overwrite
                update_dict: dict = update_item[1]
                for k, v in update_dict.items():
                    mute_state[k] = v
            elif update_item[0] == "e":  # update by extending list
                update_dict: dict = update_item[1]
                for k, v in update_dict.items():
                    mute_state.setdefault(k, []).extend(v)
        if update:  # legacy api
            state_schema = getattr(self.step_resolver, "_state_schema", None)
            if state_schema is None:
                state_schema = {}  # will make everything default to just update
            for k, v in update.items():
                if op := state_schema.get(k):
                    pass
                else:
                    op = "u"
                if op == "a":
                    mute_state.setdefault(k, []).extend(v)
                else:  # u
                    mute_state[k] = v

    def resume_run(
        self,
        *,
        run_id: str,
        suspended_node_id: str,
        suspended_token_id: str,
        client_result: StepRunResult,
        workflow_id: str,
        conversation_id: str,
        turn_node_id: str,
        cache_dir = None
    ) -> RunResult:
        """
        Resumes a suspended workflow run using the results of an externally executed task
        (e.g. from a client-side sandbox).

        This assumes that:
        1. A checkpoint exists for the suspended state.
        2. The suspended step was saved in _rt_join_snapshot as pending with mask logic intact.
        """
        # Load the latest checkpoint for the run to reconstruct initial_state
        ckpts = self.conversation_engine.read.get_nodes(
            where={
                "$and": [
                    {"entity_type": "workflow_checkpoint"},
                    {"run_id": str(run_id)},
                ]
            },
            # limit=1,
            # we want the most recent
        )
        # Checkpoints might not come perfectly ordered, so we sort them
        if not ckpts:
            raise ValueError(f"Cannot resume run {run_id}: no checkpoints found.")

        latest_ckpt = max(
            ckpts, key=lambda c: int(getattr(c, "metadata", {}).get("step_seq", -1))
        )
        initial_state_raw = getattr(latest_ckpt, "metadata", {}).get("state_json", {})
        initial_state: WorkflowState
        if isinstance(initial_state_raw, str):
            # TO-DO add validation
            initial_state = json.loads(initial_state_raw) 
        elif isinstance(initial_state_raw, dict):
            initial_state = dict(initial_state_raw) # type: ignore
        else:
            raise ValueError(
                f"Cannot resume run {run_id}: checkpoint state_json is not a dict/json string."
            )

        # Apply the client's state update directly to the initial state for all resumable result types.
        self.apply_state_update(
            mute_state=initial_state,
            state_update=client_result.state_update,
            update=getattr(client_result, "update", None),
        )

        # Start the runtime again
        # The runtime will pick up the `pending` tokens from `_rt_join` stored in `initial_state`
        # Because the token was parked at `suspended_node_id`, it will try to re-execute it.
        # But wait! We don't want to re-execute the suspended node. We want to route *from* it.

        # To fix this, we manually route from the suspended node and update the `_rt_join`
        # pending state before calling run().
        start, nodes, adj = validate_workflow_design(
            workflow_engine=self.workflow_engine,
            workflow_id=workflow_id,
            predicate_registry=self.predicate_registry,
            resolver=self.step_resolver,
        )

        node_ids_list = list(nodes.keys())
        join_node_ids = []
        for _nid, _wn in nodes.items():
            _md = getattr(_wn, "metadata", None) or {}
            if bool(_md.get("wf_join", False)) or str(getattr(_wn, "op", "")) == "join":
                join_node_ids.append(str(_nid))

        _may_reach_join = (
            _compute_may_reach_join_bitsets(
                node_ids=node_ids_list, adj=adj, join_ids=join_node_ids
            )
            if join_node_ids
            else {nid: 0 for nid in node_ids_list}
        )

        wn = nodes[suspended_node_id]
        edges = adj.get(suspended_node_id, [])
        step_seq_current = (
            int(getattr(latest_ckpt, "metadata", {}).get("step_seq", 0)) + 1
        )
        next_nodes: list[str] = []
        route_decision = RouteDecision(evaluated=[], selected=[])
        client_status = str(getattr(client_result, "status", "success"))
        if client_status != "suspended":
            next_nodes, route_decision = self._route_next(
                edges, initial_state, client_result, wn.fanout, nodes
            )
        rt_join = initial_state.get("_rt_join", {})
        pending = rt_join.get("pending", [])
        suspended = rt_join.get("suspended", [])

        new_pending = []
        new_suspended = []
        token_found = False
        mask_to_distribute = 0
        parent_token_id = None
        resumed_exec_node = None

        previous_exec_node_id = f"wf_step|{run_id}|{step_seq_current - 1}"
        previous_exec_nodes = self.conversation_engine.read.get_nodes(
            ids=[previous_exec_node_id],
            limit=1,
        )
        if previous_exec_nodes:
            previous_exec_node = previous_exec_nodes[0]
        else:
            fallback_exec_nodes = self.conversation_engine.read.get_nodes(
                ids=[f"wf_run|{run_id}"],
                limit=1,
            )
            previous_exec_node = fallback_exec_nodes[0] if fallback_exec_nodes else None

        def _extract(items, keep):
            nonlocal token_found, mask_to_distribute, parent_token_id
            for item in items:
                norm = None
                if isinstance(item, (list, tuple)):
                    if len(item) == 4:
                        norm = (
                            str(item[0]),
                            int(item[1]),
                            str(item[2]),
                            (str(item[3]) if item[3] is not None else None),
                        )
                    elif len(item) == 3:
                        norm = (str(item[0]), int(item[1]), str(item[2]), None)
                if norm is None:
                    keep.append(item)
                    continue
                nid, tok_mask, tok_id, tok_parent = norm
                if (
                    (not token_found)
                    and nid == str(suspended_node_id)
                    and tok_id == str(suspended_token_id)
                ):
                    token_found = True
                    mask_to_distribute = int(tok_mask)
                    parent_token_id = tok_parent
                else:
                    keep.append(norm)

        _extract(suspended, new_suspended)
        _extract(pending, new_pending)

        if not token_found:
            raise ValueError(
                f"Token {suspended_token_id} for node {suspended_node_id} not found in suspended runtime state."
            )
        token_id = suspended_token_id
        node_id = suspended_node_id
        # Trace routing decision (includes rejections) at orchestration choke point
        try:
            tc = TraceContext(
                run_id=str(run_id),
                token_id=str(token_id),
                step_seq=int(step_seq_current),
                node_id=str(node_id),
                attempt=1,
                conversation_id=str(conversation_id),
                turn_node_id=str(turn_node_id),
            )
            self.emitter.emit(
                type="routing_decision",
                ctx=tc,
                payload={
                    "evaluated": [
                        (a, bool(b))
                        for a, b in getattr(route_decision, "evaluated", [])
                    ],
                    "selected": [
                        (e, t, r) for e, t, r in getattr(route_decision, "selected", [])
                    ],
                    "next_nodes": [str(x) for x in (next_nodes or [])],
                },
            )
            # Also emit per-evaluation/per-selection events for telemetry consumers
            for pred_name, ok in getattr(route_decision, "evaluated", []):
                try:
                    self.emitter.predicate_evaluated(
                        tc, predicate=str(pred_name), value=bool(ok)
                    )
                except Exception:
                    pass
            for edge_id, to_node_id, reason in getattr(route_decision, "selected", []):
                try:
                    self.emitter.edge_selected(
                        tc,
                        edge_id=str(edge_id),
                        to_node_id=str(to_node_id),
                        reason=str(reason),
                    )
                except Exception:
                    pass

            # Tracing must never break execution
        except Exception:
            pass
        # Modify the parked suspended tokens in state["_rt_join"]["suspended"] first.
        # Older checkpoints may still have the token in pending, so we accept both for compatibility.
        # Add next tokens
        _join_pos = {jid: i for i, jid in enumerate(join_node_ids)}
        jo = rt_join.get("join_outstanding", [0 for _ in join_node_ids])

        def _inc(m: int):
            for bi in _iter_bits(m):
                jo[bi] += 1

        def _dec(m: int):
            for bi in _iter_bits(m):
                jo[bi] = max(0, jo[bi] - 1)

        first = True

        if client_status == "suspended":
            new_suspended.append(
                (
                    str(suspended_node_id),
                    int(mask_to_distribute),
                    str(suspended_token_id),
                    parent_token_id,
                )
            )
        elif not next_nodes:
            _dec(mask_to_distribute)
        else:
            for i_fanout, nxt in enumerate(next_nodes):
                nxt = str(nxt)
                nxt_mask = int(_may_reach_join.get(nxt, 0))

                if first:
                    t = (nxt, nxt_mask, suspended_token_id, parent_token_id)
                    leaving = mask_to_distribute & ~nxt_mask
                    if leaving:
                        _dec(leaving)
                    gained = nxt_mask & ~mask_to_distribute
                    if gained:
                        _inc(gained)
                    new_pending.append(t)
                    first = False
                else:
                    child_token_id = stable_id(
                        "token_id",
                        f"{suspended_token_id}/{step_seq_current}:{i_fanout}:{nxt}",
                    ).hex
                    t = (nxt, nxt_mask, child_token_id, suspended_token_id)
                    _inc(nxt_mask)
                    new_pending.append(t)

        rt_join["pending"] = new_pending
        rt_join["suspended"] = new_suspended
        rt_join["join_outstanding"] = jo
        initial_state["_rt_join"] = rt_join

        # Log the step exec for the external execution so it's recorded
        resumed_exec_node = self._persist_step_exec(
            conversation_id=conversation_id,
            workflow_id=workflow_id,
            run_id=run_id,
            step_seq=step_seq_current,
            workflow_node_id=suspended_node_id,
            op="client_sandbox_resume",
            status=(
                "suspended"
                if client_status == "suspended"
                else "failure"
                if client_status == "failure"
                else "ok"
            ),
            duration_ms=0,
            result=client_result,
            state=initial_state,
            token_id=suspended_token_id,
            parent_token_id=parent_token_id,
            join_mask=mask_to_distribute,
            last_exec_node=previous_exec_node,
        )
        if (step_seq_current % self.checkpoint_every_n_steps) == 0:
            self._persist_checkpoint(
                conversation_id=conversation_id,
                workflow_id=workflow_id,
                run_id=run_id,
                step_seq=step_seq_current,
                state=initial_state,
                last_exec_node=resumed_exec_node,
            )
            try:
                tc_ck = TraceContext(
                    run_id=str(run_id),
                    token_id=str(suspended_token_id),
                    step_seq=int(step_seq_current),
                    node_id=str(suspended_node_id),
                    attempt=1,
                    conversation_id=str(conversation_id),
                    turn_node_id=str(turn_node_id),
                )
                self.emitter.emit(
                    type="checkpoint_saved",
                    ctx=tc_ck,
                    payload={"step_seq": int(step_seq_current)},
                )
            except Exception:
                pass

        if client_status == "suspended":
            if hasattr(client_result, "resume_payload"):
                try:
                    self.emitter.emit(
                        type="workflow_step_suspended",
                        ctx=TraceContext(
                            run_id=str(run_id),
                            token_id=str(suspended_token_id),
                            step_seq=int(step_seq_current),
                            node_id=str(suspended_node_id),
                            attempt=1,
                            conversation_id=str(conversation_id),
                            turn_node_id=str(turn_node_id),
                        ),
                        payload=getattr(client_result, "resume_payload"),
                    )
                except Exception:
                    pass
            return RunResult(
                final_state=initial_state,
                run_id=run_id,
                mq=queue.Queue(),
                status="suspended",
            )

        if new_pending:
            return self.run(
                workflow_id=workflow_id,
                conversation_id=conversation_id,
                turn_node_id=turn_node_id,
                initial_state=initial_state,
                run_id=run_id,
                cache_dir=cache_dir,
                _resume_step_seq=int(step_seq_current) + 1,
                _resume_last_exec_node=resumed_exec_node,
            )

        if new_suspended:
            return RunResult(
                final_state=initial_state,
                run_id=run_id,
                mq=queue.Queue(),
                status="suspended",
            )

        if client_status == "failure":
            try:
                self._persist_failed_terminal(
                    conversation_id=str(conversation_id),
                    workflow_id=str(workflow_id),
                    run_id=str(run_id),
                    accepted_step_seq=int(step_seq_current),
                    errors=list(getattr(client_result, "errors", []) or []),
                    last_processed_node_id=str(suspended_node_id),
                )
                tc_done = TraceContext(
                    run_id=str(run_id),
                    token_id=str(suspended_token_id),
                    step_seq=int(step_seq_current),
                    node_id=str(suspended_node_id),
                    attempt=1,
                    conversation_id=str(conversation_id),
                    turn_node_id=str(turn_node_id),
                )
                self.emitter.emit(
                    type="workflow_run_failed",
                    ctx=tc_done,
                    payload={"workflow_id": str(workflow_id)},
                )
            except Exception:
                pass
            return RunResult(
                final_state=initial_state,
                run_id=run_id,
                mq=queue.Queue(),
                status="failure",
            )

        self._persist_completed_terminal(
            conversation_id=str(conversation_id),
            workflow_id=str(workflow_id),
            run_id=str(run_id),
            accepted_step_seq=int(step_seq_current),
            last_processed_node_id=str(suspended_node_id),
        )
        try:
            tc_done = TraceContext(
                run_id=str(run_id),
                token_id=str(suspended_token_id),
                step_seq=int(step_seq_current),
                node_id=str(suspended_node_id),
                attempt=1,
                conversation_id=str(conversation_id),
                turn_node_id=str(turn_node_id),
            )
            self.emitter.emit(
                type="workflow_run_completed",
                ctx=tc_done,
                payload={"workflow_id": str(workflow_id)},
            )
        except Exception:
            pass
        return RunResult(
            final_state=initial_state,
            run_id=run_id,
            mq=queue.Queue(),
            status="succeeded",
        )

    def run(
        self,
        *,
        workflow_id: str,
        conversation_id: str,
        turn_node_id: str,  # parent run may trigger another run in a node
        initial_state: WorkflowState,
        run_id: Optional[str] = None,
        cache_dir = None,
        _resume_step_seq: int | None = None,
        _resume_last_exec_node: WorkflowStepExecNode | WorkflowRunNode | None = None,
    ) -> RunResult:
        """
        Returns (final_state, run_id).

        Design lives in workflow_engine.
        Traces/checkpoints live in conversation_engine.
        """
        with bind_log_context(
            conversation_id=conversation_id, workflow_run_id=f"{workflow_id}--{run_id}"
        ):
            # repair fields auto set by default schema
            state_schema = getattr(self.step_resolver, "_state_schema", None)
            if state_schema and isinstance(state_schema, dict):
                for k, v in state_schema.items():
                    if v == "u":
                        initial_state[k] = None
                    if v == "a":
                        initial_state[k] = []

            validate_initial_state(initial_state)

            run_id = run_id or f"run|{uuid.uuid4()}"
            self.state_lock[str(run_id)] = Lock()

            # an interworker, orchestrator message channel
            mq: queue.Queue[Dict[str, Json]] = queue.Queue(maxsize=10000)

            start, nodes, adj = validate_workflow_design(
                workflow_engine=self.workflow_engine,
                workflow_id=workflow_id,
                predicate_registry=self.predicate_registry,
                resolver=self.step_resolver,
            )

            # ----------------------------
            # Precompute MAY-reach join/barrier sets (ignoring predicates)
            # ----------------------------
            node_ids_list = list(nodes.keys())
            join_node_ids: list[str] = []
            _join_is_merge = {}
            for _nid, _wn in nodes.items():
                _md = getattr(_wn, "metadata", None) or {}
                if (
                    bool(_md.get("wf_join", False))
                    or str(getattr(_wn, "op", "")) == "join"
                ):
                    join_node_ids.append(str(_nid))
                    _join_is_merge[str(_nid)] = bool(
                        _md.get("wf_join_is_merge")
                        if _md.get("wf_join_is_merge") is not None
                        else True
                    )
            _may_reach_join = (
                _compute_may_reach_join_bitsets(
                    node_ids=node_ids_list, adj=adj, join_ids=join_node_ids
                )
                if join_node_ids
                else {nid: 0 for nid in node_ids_list}
            )
            _join_pos = {jid: i for i, jid in enumerate(join_node_ids)}
            _join_outstanding: list[int] = [
                0 for _ in join_node_ids
            ]  # tokens BEFORE each join
            _join_waiters: dict[str, list[tuple[int, str, str | None]]] = {
                jid: [] for jid in join_node_ids
            }  # store per-token mask at join

            def _inc(mask: int) -> None:
                for bi in _iter_bits(mask):
                    _join_outstanding[bi] += 1

            def _dec(mask: int) -> None:
                for bi in _iter_bits(mask):
                    _join_outstanding[bi] -= 1
                    if _join_outstanding[bi] < 0:
                        # defensive: never go negative
                        _join_outstanding[bi] = 0

            def _mask_without_join(mask: int, join_id: str) -> int:
                bi = _join_pos.get(join_id)
                if bi is None:
                    return mask
                return mask & ~(1 << bi)

            def _bit_for_join(join_id: str) -> int:
                bi = _join_pos.get(join_id)
                return (1 << bi) if bi is not None else 0

            def _normalize_join_waiter(
                item: Any,
            ) -> tuple[int, str, str | None] | None:
                if not isinstance(item, (list, tuple)):
                    return None
                if len(item) >= 3:
                    return (
                        int(item[0]),
                        str(item[1]),
                        (str(item[2]) if item[2] is not None else None),
                    )
                if len(item) == 1:
                    return (int(item[0]), uuid.uuid4().hex, None)
                return None

            def _rt_join_get() -> dict:
                return cast(dict, state.get("_rt_join", {}))

            def _rt_join_set(payload: dict) -> None:
                # Stored in workflow state so checkpoints can resume joins.
                state["_rt_join"] = payload

            def _normalize_rt_token(
                item: Any,
            ) -> tuple[str, int, str, str | None] | None:
                if not isinstance(item, (list, tuple)):
                    return None
                if len(item) == 4:
                    return (
                        str(item[0]),
                        int(item[1]),
                        str(item[2]),
                        (str(item[3]) if item[3] is not None else None),
                    )
                if len(item) == 3:
                    # backward-compat: snapshots without parent_token_id
                    return (str(item[0]), int(item[1]), str(item[2]), None)
                if len(item) == 2:
                    # backward-compat: older snapshots without token_id/parent_token_id
                    return (str(item[0]), int(item[1]), uuid.uuid4().hex, None)
                return None

            def _rt_join_snapshot(
                pending: list[tuple[str, int, str, str | None]],
                *,
                suspended: list[tuple[str, int, str, str | None]] | None = None,
            ) -> dict:
                # Persist inflight as pending-on-resume by including them in pending list upstream.
                # Suspended tokens must be kept separately: they are parked at the suspended node
                # and must NOT be re-scheduled automatically on resume.
                return {
                    "join_node_ids": join_node_ids,
                    "join_outstanding": list(_join_outstanding),
                    "join_waiters": {
                        jid: [
                            (
                                int(mask),
                                str(token_id),
                                (
                                    str(parent_token_id)
                                    if parent_token_id is not None
                                    else None
                                ),
                            )
                            for mask, token_id, parent_token_id in waiters
                        ]
                        for jid, waiters in _join_waiters.items()
                    },
                    "pending": [
                        (
                            nid,
                            int(mask),
                            str(token_id),
                            (
                                str(parent_token_id)
                                if parent_token_id is not None
                                else None
                            ),
                        )
                        for nid, mask, token_id, parent_token_id in pending
                    ],
                    "suspended": [
                        (
                            nid,
                            int(mask),
                            str(token_id),
                            (
                                str(parent_token_id)
                                if parent_token_id is not None
                                else None
                            ),
                        )
                        for nid, mask, token_id, parent_token_id in (suspended or [])
                    ],
                }

            def _rt_join_restore() -> list[tuple[str, int, str, str | None]] | None:
                payload = _rt_join_get()
                if not payload:
                    return None
                if payload.get("join_node_ids") != join_node_ids:
                    # Design changed; discard stale join runtime.
                    return None
                jo = payload.get("join_outstanding")
                jw = payload.get("join_waiters")
                pend = payload.get("pending")
                if (
                    not isinstance(jo, list)
                    or not isinstance(jw, dict)
                    or not isinstance(pend, list)
                ):
                    return None
                # restore counters/waiters
                for i in range(min(len(_join_outstanding), len(jo))):
                    try:
                        _join_outstanding[i] = int(jo[i])
                    except Exception:
                        _join_outstanding[i] = 0
                for jid in join_node_ids:
                    items = jw.get(jid, [])
                    if isinstance(items, list):
                        normalized: list[tuple[int, str, str | None]] = []
                        for item in items:
                            norm = _normalize_join_waiter(item)
                            if norm is not None:
                                normalized.append(norm)
                        _join_waiters[jid] = normalized
                # pending tokens only; suspended tokens are restored by resume_run
                out: list[tuple[str, int, str, str | None]] = []
                for item in pend:
                    norm = _normalize_rt_token(item)
                    if norm is not None:
                        out.append(norm)
                return out

            # start, nodes, adj = load_workflow_design(workflow_engine=self.workflow_engine, workflow_id=workflow_id)

            state: WorkflowState = initial_state
            step_seq = int(_resume_step_seq) if _resume_step_seq is not None else 0

            # Persist workflow_run node in conversation_engine
            wf_run_root_node = self._persist_workflow_run(
                conversation_id=conversation_id,
                workflow_id=workflow_id,
                run_id=run_id,
                turn_node_id=turn_node_id,
                status="running",
            )
            # trace: workflow run started
            try:
                tc_run = TraceContext(
                    run_id=str(run_id),
                    token_id=str(run_id),  # root token id is run_id for now
                    step_seq=0,
                    node_id=str(start_id) if "start_id" in locals() else "start", # type: ignore  # noqa: F821
                    attempt=1,
                    conversation_id=str(conversation_id)
                    if conversation_id is not None
                    else None,
                    turn_node_id=str(turn_node_id)
                    if turn_node_id is not None
                    else None,
                )
                self.emitter.emit(
                    type="workflow_run_started",
                    ctx=tc_run,
                    payload={"workflow_id": str(workflow_id)},
                )
            except Exception:
                pass
            # state_mutex_lock: threading.Lock = threading.Lock()
            scheduled_q: queue.Queue[Tuple[str, int, str, str | None]] = (
                queue.Queue()
            )  # (node_id, mask, token_id, parent_token_id)
            pending_tokens: set[tuple[str, int, str, str | None]] = set()
            inflight_tokens: set[tuple[str, int, str, str | None]] = set()
            suspended_tokens: dict[str, tuple[str, int, str, str | None]] = {}
            done_q: queue.Queue[
                Tuple[str, StepRunResult, int, str, str | None, str, int]
            ] = queue.Queue()  # (node_id, result, duration_ms, token_id, parent_token_id, status, mask)
            cancel_pending = False
            cancel_info: dict[str, Any] | None = None
            run_suspended = False
            run_failed = False

            graveyard: queue.Queue[
                Tuple[str, StepRunResult, int, str, str | None, str, int]
            ] = queue.Queue()

            def _persist_rt_join_runtime() -> None:
                # Persist both pending + inflight as pending-on-resume (idempotent).
                # Suspended tokens are stored separately so they are parked, not re-scheduled.
                combined = sorted(pending_tokens.union(inflight_tokens))
                suspended = sorted(suspended_tokens.values())
                _rt_join_set(_rt_join_snapshot(combined, suspended=suspended))

            def _enter_failed() -> bool:
                nonlocal run_failed
                if run_failed:
                    return False
                run_failed = True

                while True:
                    try:
                        nid, mask, tok, parent_tok = scheduled_q.get_nowait()
                    except queue.Empty:
                        break
                    pending_tokens.discard((str(nid), int(mask), str(tok), parent_tok))
                    _dec(int(mask))

                for jid in join_node_ids:
                    waiters = list(_join_waiters.get(jid, []))
                    if not waiters:
                        continue
                    _join_waiters[jid] = []
                    for wm, _tok, _parent in waiters:
                        _dec(int(wm))

                _persist_rt_join_runtime()
                return True

            def _cancel_requested() -> bool:
                nonlocal cancel_info
                if bool(self.cancel_requested and self.cancel_requested(str(run_id))):
                    if cancel_info is None:
                        cancel_info = {
                            "source": "callback",
                            "node_id": None,
                            "seq": None,
                            "watermark": None,
                        }
                    return True
                graph_cancel = self._find_eligible_cancel_request(
                    conversation_id=str(conversation_id),
                    run_id=str(run_id),
                )
                if graph_cancel is not None:
                    graph_cancel["source"] = "graph"
                    cancel_info = graph_cancel
                    return True
                return False

            def _enter_cancelling(
                reason_node_id: str = "run", token_id: str | None = None
            ) -> bool:
                nonlocal cancel_pending
                if cancel_pending or not _cancel_requested():
                    return cancel_pending
                cancel_pending = True
                while True:
                    try:
                        nid, mask, tok, parent_tok = scheduled_q.get_nowait()
                        pending_tokens.discard(
                            (str(nid), int(mask), str(tok), parent_tok)
                        )
                    except queue.Empty:
                        break
                _persist_rt_join_runtime()
                try:
                    tc_cancel = TraceContext(
                        run_id=str(run_id),
                        token_id=str(token_id or run_id),
                        step_seq=int(step_seq),
                        node_id=str(reason_node_id),
                        attempt=1,
                        conversation_id=str(conversation_id)
                        if conversation_id is not None
                        else None,
                        turn_node_id=str(turn_node_id)
                        if turn_node_id is not None
                        else None,
                    )
                    self.emitter.emit(
                        type="workflow_run_cancelling",
                        ctx=tc_cancel,
                        payload={"workflow_id": str(workflow_id)},
                    )
                except Exception:
                    pass
                return True

            start_id = start.safe_get_id()

            # Resume-safe join runtime: if a checkpoint restored pending tokens + join counters,
            # seed the scheduler from that payload. Otherwise start from the workflow start node.
            restored = _rt_join_restore()
            if restored:
                for nid, mask, token_id, parent_token_id in restored:
                    t = (str(nid), int(mask), str(token_id), parent_token_id)
                    pending_tokens.add(t)
                    scheduled_q.put(t)
                _persist_rt_join_runtime()
            else:
                start_mask = int(_may_reach_join.get(start_id, 0))
                _inc(start_mask)
                t = (
                    str(start_id),
                    int(start_mask),
                    run_id,  # uuid.uuid4().hex, # token_id = run-id
                    None,
                )
                pending_tokens.add(t)
                scheduled_q.put(t)
                _persist_rt_join_runtime()

            def worker(
                node_id: str,
                state: WorkflowState,
                token_id: str,
                parent_token_id: str | None,
                step_seq: int,
                mask: int,
                cache_dir : str | PathLike | None = None
            ) -> None:

                t = threading.current_thread()
                old_name = t.name
                ctx = None
                try:
                    t.name = (
                        f"rt-wf-{workflow_id}-wf-{run_id}-step-{step_seq}-{node_id}"
                    )
                    wn: WorkflowNode
                    wn = nodes[node_id]
                    op = nodes[node_id].op
                    t0 = _now_ms()
                    status = "ok"
                    with bind_log_context(step_id=f"{step_seq}-{node_id}", op=op):
                        try:
                            ctx = StepContext(
                                run_id=str(run_id),
                                workflow_id=str(workflow_id),
                                workflow_node_id=str(node_id),
                                op=str(op),
                                token_id=str(token_id),
                                attempt=1,
                                step_seq=int(step_seq),
                                conversation_id=str(conversation_id)
                                if conversation_id is not None
                                else None,
                                turn_node_id=str(turn_node_id)
                                if turn_node_id is not None
                                else None,
                                state=state,
                                message_queue=mq,
                                events=self.emitter,
                                cache_dir=cache_dir,
                            )
                            # step attempt start
                            self.emitter.step_started(ctx.trace_ctx)

                            if _cancel_requested():
                                status = "cancelled"
                                res = RunFailure(
                                    conversation_node_id=None,
                                    status="failure",
                                    errors=["Run cancelled"],
                                    state_update=[],
                                )
                            else:
                                fn: Callable[..., StepRunResult] = self.step_resolver(
                                    op
                                )

                                # Transaction boundary (best-effort): resolver is expected to call
                                # engine methods; when backed by Postgres this ensures those writes
                                # are committed or rolled back atomically for this step.
                                with (
                                    self.conversation_engine.uow()
                                    if self._should_step_uow(op, state)
                                    else __import__("contextlib").nullcontext()
                                ):
                                    res = fn(ctx)
                                if getattr(res, "status", None) == "suspended":
                                    status = "suspended"
                                elif getattr(res, "status", None) == "failure":
                                    status = "failure"
                                else:
                                    status = "ok"
                                if status == "ok":
                                    invocations = list(
                                        getattr(res, "workflow_invocations", []) or []
                                    )
                                    for invocation in invocations:
                                        child_result = self._run_workflow_invocation(
                                            invocation=invocation,
                                            parent_state=state,
                                            conversation_id=str(conversation_id),
                                            turn_node_id=str(turn_node_id),
                                            parent_run_id=str(run_id),
                                            cache_dir=cache_dir,
                                        )
                                        if child_result.status != "succeeded":
                                            status = "failure"
                                            res = RunFailure(
                                                conversation_node_id=None,
                                                status="failure",
                                                errors=[
                                                    "Nested workflow "
                                                    f"{invocation.workflow_id!r} "
                                                    f"returned status {child_result.status!r}"
                                                ],
                                                state_update=[],
                                            )
                                            break
                                        run_state_lock = self.state_lock[str(run_id)]
                                        with run_state_lock:
                                            self._apply_workflow_invocation_result(
                                                state=state,
                                                invocation=invocation,
                                                child_result=child_result,
                                            )

                        except Exception as e:
                            status = "error"
                            import traceback

                            res = RunFailure(
                                conversation_node_id=None,
                                status="failure",
                                errors=[str(e) + "\n" + traceback.format_exc()],
                                state_update=[],
                            )
                        try:
                            mq.put_nowait(res.model_dump())
                        except queue.Full as _e:
                            raise
                        t1 = _now_ms()

                        # step attempt complete (best-effort; never break worker)
                        try:
                            if ctx is None:
                                raise ValueError('ctx is None')
                            self.emitter.step_completed(
                                ctx.trace_ctx,
                                status=str(status),
                                duration_ms=max(0, t1 - t0),
                            )
                        except Exception:
                            status = "status_report_error"
                        if status in ["error", "status_report_error"]:
                            err_message = f"error on {node_id}, {res}"
                            # to do, emit fail, then raise
                            if getattr(wn, "fail_actiion", "raise") == "raise":
                                raise Exception(err_message)

                        done_q.put(
                            (
                                node_id,
                                res,
                                max(0, t1 - t0),
                                token_id,
                                parent_token_id,
                                status,
                                mask,
                            )
                        )
                except Exception as _e:
                    raise
                finally:
                    t.name = old_name

            inflight: Dict[tuple[str, int, str], Any] = {}
            last_exec_node = (
                _resume_last_exec_node
                if _resume_last_exec_node is not None
                else wf_run_root_node
            )
            with ThreadPoolExecutor(
                max_workers=self.max_workers, thread_name_prefix=f"rt-wf-{workflow_id}"
            ) as pool:
                while True:
                    _enter_cancelling()
                    if (
                        cancel_pending
                        and not inflight
                        and scheduled_q.empty()
                        and done_q.empty()
                    ):
                        self._persist_cancelled_terminal(
                            conversation_id=str(conversation_id),
                            workflow_id=str(workflow_id),
                            run_id=str(run_id),
                            accepted_step_seq=max(-1, int(step_seq) - 1),
                            cancel_info=cancel_info,
                            last_processed_node_id=(
                                str(last_exec_node.safe_get_id())
                                if last_exec_node is not None
                                else None
                            ),
                        )
                        # self._update_workflow_run_status(conversation_id, run_id, "cancelled")
                        try:
                            tc_done = TraceContext(
                                run_id=str(run_id),
                                token_id=str(run_id),
                                step_seq=int(step_seq),
                                node_id="run",
                                attempt=1,
                                conversation_id=str(conversation_id)
                                if conversation_id is not None
                                else None,
                                turn_node_id=str(turn_node_id)
                                if turn_node_id is not None
                                else None,
                            )
                            self.emitter.emit(
                                type="workflow_run_cancelled",
                                ctx=tc_done,
                                payload={"workflow_id": str(workflow_id)},
                            )
                        except Exception:
                            pass
                        self._close_sandbox_run(run_id)
                        self.state_lock.pop(run_id, None)
                        return RunResult(
                            final_state=state, run_id=run_id, mq=mq, status="cancelled"
                        )
                    if (
                        not cancel_pending
                        and not inflight
                        and not pending_tokens
                        and scheduled_q.empty()
                        and done_q.empty()
                    ):
                        if run_failed:
                            self._persist_failed_terminal(
                                conversation_id=str(conversation_id),
                                workflow_id=str(workflow_id),
                                run_id=str(run_id),
                                accepted_step_seq=max(-1, int(step_seq) - 1),
                                errors=list(
                                    getattr(run_result, "errors", []) or []
                                ),
                                last_processed_node_id=(
                                    str(last_exec_node.safe_get_id())
                                    if last_exec_node is not None
                                    else None
                                ),
                            )
                            try:
                                tc_done = TraceContext(
                                    run_id=str(run_id),
                                    token_id=str(run_id),
                                    step_seq=int(step_seq),
                                    node_id="run",
                                    attempt=1,
                                    conversation_id=str(conversation_id)
                                    if conversation_id is not None
                                    else None,
                                    turn_node_id=str(turn_node_id)
                                    if turn_node_id is not None
                                    else None,
                                )
                                self.emitter.emit(
                                    type="workflow_run_failed",
                                    ctx=tc_done,
                                    payload={"workflow_id": str(workflow_id)},
                                )
                            except Exception:
                                pass
                            self._close_sandbox_run(run_id)
                            self.state_lock.pop(run_id, None)
                            return RunResult(
                                final_state=state,
                                run_id=run_id,
                                mq=mq,
                                status="failure",
                            )
                        if run_suspended:
                            # suspended
                            # self._update_workflow_run_status(conversation_id, run_id, "suspended")
                            # trace: workflow run suspended
                            try:
                                tc_done = TraceContext(
                                    run_id=str(run_id),
                                    token_id=str(run_id),
                                    step_seq=int(step_seq),
                                    node_id="run",
                                    attempt=1,
                                    conversation_id=str(conversation_id)
                                    if conversation_id is not None
                                    else None,
                                    turn_node_id=str(turn_node_id)
                                    if turn_node_id is not None
                                    else None,
                                )
                                self.emitter.emit(
                                    type="workflow_run_suspended",
                                    ctx=tc_done,
                                    payload={"workflow_id": str(workflow_id)},
                                )
                            except Exception:
                                pass
                            self._close_sandbox_run(run_id)
                            self.state_lock.pop(run_id, None)
                            return RunResult(
                                final_state=state,
                                run_id=run_id,
                                mq=mq,
                                status="suspended",
                            )
                        else:
                            # done
                            # self._update_workflow_run_status(conversation_id, run_id, "succeeded")
                            self._persist_completed_terminal(
                                conversation_id=str(conversation_id),
                                workflow_id=str(workflow_id),
                                run_id=str(run_id),
                                accepted_step_seq=max(-1, int(step_seq) - 1),
                                last_processed_node_id=(
                                    str(last_exec_node.safe_get_id())
                                    if last_exec_node is not None
                                    else None
                                ),
                            )
                            # trace: workflow run completed
                            try:
                                tc_done = TraceContext(
                                    run_id=str(run_id),
                                    token_id=str(run_id),
                                    step_seq=int(step_seq),
                                    node_id="run",
                                    attempt=1,
                                    conversation_id=str(conversation_id)
                                    if conversation_id is not None
                                    else None,
                                    turn_node_id=str(turn_node_id)
                                    if turn_node_id is not None
                                    else None,
                                )
                                self.emitter.emit(
                                    type="workflow_run_completed",
                                    ctx=tc_done,
                                    payload={"workflow_id": str(workflow_id)},
                                )
                            except Exception:
                                pass
                            self._close_sandbox_run(run_id)
                            self.state_lock.pop(run_id, None)
                            return RunResult(
                                final_state=state,
                                run_id=run_id,
                                mq=mq,
                                status="succeeded",
                            )
                    # schedule while capacity
                    while (not cancel_pending) and len(inflight) < self.max_workers:
                        try:
                            nid, mask, token_id, parent_token_id = (
                                scheduled_q.get_nowait()
                            )
                            pending_tokens.discard(
                                (str(nid), int(mask), str(token_id), parent_token_id)
                            )
                            _persist_rt_join_runtime()
                        except queue.Empty:
                            break

                        # If this is a join/barrier node, it doesn't execute immediately.
                        if nid in _join_waiters:
                            join_idx = _join_pos.get(nid)
                            join_bit = _bit_for_join(nid)
                            was_before_join = bool(mask & join_bit)
                            if was_before_join:
                                # token reached the join -> no longer "before" this join
                                _dec(join_bit)
                                mask = _mask_without_join(mask, nid)
                            # trace: token arrived at join
                            try:
                                join_idx = _join_pos.get(nid)
                                outstanding = (
                                    int(_join_outstanding[join_idx])
                                    if join_idx is not None
                                    else 0
                                )
                                tcj = TraceContext(
                                    run_id=str(run_id),
                                    token_id=str(token_id),
                                    step_seq=int(step_seq),
                                    node_id=str(nid),
                                    attempt=1,
                                    conversation_id=str(conversation_id)
                                    if conversation_id is not None
                                    else None,
                                    turn_node_id=str(turn_node_id)
                                    if turn_node_id is not None
                                    else None,
                                )
                                self.emitter.join_event(
                                    tcj,
                                    join_node_id=str(nid),
                                    kind="arrived",
                                    outstanding=outstanding,
                                )
                            except Exception:
                                pass

                            _join_waiters[nid].append((mask, token_id, parent_token_id))
                            # trace: token waiting at join
                            try:
                                join_idx = _join_pos.get(nid)
                                outstanding = (
                                    int(_join_outstanding[join_idx])
                                    if join_idx is not None
                                    else 0
                                )
                                tcj = TraceContext(
                                    run_id=str(run_id),
                                    token_id=str(token_id),
                                    step_seq=int(step_seq),
                                    node_id=str(nid),
                                    attempt=1,
                                    conversation_id=str(conversation_id)
                                    if conversation_id is not None
                                    else None,
                                    turn_node_id=str(turn_node_id)
                                    if turn_node_id is not None
                                    else None,
                                )
                                self.emitter.join_event(
                                    tcj,
                                    join_node_id=str(nid),
                                    kind="waiting",
                                    outstanding=outstanding,
                                )
                            except Exception:
                                pass

                            if _join_is_merge[nid]:
                                if join_idx is None or _join_outstanding[join_idx] != 0:
                                    _persist_rt_join_runtime()
                                    continue
                                waiters = list(_join_waiters.get(nid, []))
                                if not waiters:
                                    _persist_rt_join_runtime()
                                    continue
                                try:
                                    tcj = TraceContext(
                                        run_id=str(run_id),
                                        token_id=str(waiters[0][1]),
                                        step_seq=int(step_seq),
                                        node_id=str(nid),
                                        attempt=1,
                                        conversation_id=str(conversation_id)
                                        if conversation_id is not None
                                        else None,
                                        turn_node_id=str(turn_node_id)
                                        if turn_node_id is not None
                                        else None,
                                    )
                                    self.emitter.join_event(
                                        tcj,
                                        join_node_id=str(nid),
                                        kind="released",
                                        outstanding=0,
                                    )
                                except Exception:
                                    pass
                                _join_waiters[nid] = []
                                merged_mask = int(waiters[0][0])
                                token_id = str(waiters[0][1])
                                parent_token_id = waiters[0][2]
                                for wm, _tok, _parent in waiters:
                                    _dec(int(wm))
                                for wm, _tok, _parent in waiters[1:]:
                                    merged_mask &= int(wm)
                                _inc(int(merged_mask))
                                mask = int(merged_mask)
                            _persist_rt_join_runtime()

                        inflight_tokens.add(
                            (str(nid), int(mask), str(token_id), parent_token_id)
                        )
                        _persist_rt_join_runtime()
                        import contextvars

                        ctx = contextvars.copy_context()
                        inflight[(nid, mask, str(token_id))] = pool.submit(
                            ctx.run,
                            worker,
                            nid,
                            state,
                            token_id,
                            parent_token_id,
                            step_seq,
                            mask,
                            cache_dir=cache_dir,
                        )

                    try:
                        done_task = done_q.get(timeout=0.05)
                    except queue.Empty:
                        continue
                    (
                        node_id,
                        run_result,
                        dur_ms,
                        token_id,
                        parent_token_id,
                        status,
                        mask,
                    ) = done_task
                    graveyard.put_nowait(done_task)
                    run_state_lock: Lock = self.state_lock[str(run_id)]
                    with self._maybe_step_uow():
                        with run_state_lock:
                            self.apply_state_update(
                                mute_state=state,
                                state_update=run_result.state_update,
                                update=getattr(run_result, "update", None),
                            )

                    inflight.pop((node_id, mask, str(token_id)), None)
                    inflight_tokens.discard(
                        (str(node_id), int(mask), str(token_id), parent_token_id)
                    )
                    _persist_rt_join_runtime()

                    wn = nodes[node_id]

                    # If suspended, mark the run as suspended and persist step
                    if status == "suspended":
                        run_suspended = True
                        suspended_tokens[str(token_id)] = (
                            str(node_id),
                            int(mask),
                            str(token_id),
                            parent_token_id,
                        )
                        # Do not enqueue next tokens for this node
                    else:
                        suspended_tokens.pop(str(token_id), None)

                    # persist step exec trace node (same transaction as state update when possible)
                    with self._maybe_step_uow():
                        last_exec_node = self._persist_step_exec(
                            conversation_id=conversation_id,
                            workflow_id=workflow_id,
                            run_id=run_id,
                            step_seq=step_seq,
                            workflow_node_id=node_id,
                            op=wn.op,
                            status=status,
                            duration_ms=dur_ms,
                            result=run_result,
                            state=state,
                            token_id=str(token_id),
                            parent_token_id=(
                                str(parent_token_id)
                                if parent_token_id is not None
                                else None
                            ),
                            join_mask=int(mask),
                            last_exec_node=last_exec_node,
                        )

                    # single-writer state apply:
                    # default behavior: store under result.<op> and allow ops to also write into state
                    # state[f"result.{wn.op}"] = result result only visible

                    # NOTE: checkpoint must be persisted after routing/enqueueing next tokens so that
                    # the state snapshot contains a correct _rt_join frontier (pending/inflight) for resume.
                    step_seq_current = step_seq
                    step_seq += 1

                    def _checkpoint_current_step() -> None:
                        if (step_seq_current % self.checkpoint_every_n_steps) == 0:
                            with self._maybe_step_uow():
                                self._persist_checkpoint(
                                    conversation_id=conversation_id,
                                    workflow_id=workflow_id,
                                    run_id=run_id,
                                    step_seq=step_seq_current,
                                    state=state,
                                    last_exec_node=last_exec_node,
                                )
                            try:
                                tc_ck = TraceContext(
                                    run_id=str(run_id),
                                    token_id=str(token_id),
                                    step_seq=int(step_seq_current),
                                    node_id=str(node_id),
                                    attempt=1,
                                    conversation_id=str(conversation_id),
                                    turn_node_id=str(turn_node_id),
                                )
                                self.emitter.emit(
                                    type="checkpoint_saved",
                                    ctx=tc_ck,
                                    payload={"step_seq": int(step_seq_current)},
                                )
                            except Exception:
                                pass

                    if status == "suspended":
                        # When suspended, the token is parked here pending external resume.
                        # We DO NOT decrement the join obligations because the token still exists
                        # and will eventually reach downstream joins once resumed.
                        _persist_rt_join_runtime()
                        _checkpoint_current_step()

                        # Emit specific suspension payload for client ingestion
                        if hasattr(run_result, "resume_payload"):
                            try:
                                self.emitter.emit(
                                    type="workflow_step_suspended",
                                    ctx=TraceContext(
                                        run_id=str(run_id),
                                        token_id=str(token_id),
                                        step_seq=int(step_seq_current),
                                        node_id=str(node_id),
                                        attempt=1,
                                        conversation_id=str(conversation_id),
                                        turn_node_id=str(turn_node_id),
                                    ),
                                    payload=getattr(run_result, "resume_payload"),
                                )
                            except Exception:
                                pass
                        continue

                    if _enter_cancelling(
                        reason_node_id=str(node_id), token_id=str(token_id)
                    ):
                        # The current token completed after a cancel request was accepted.
                        # Stop it here so no downstream work is scheduled during cancellation.
                        _dec(mask)
                        _persist_rt_join_runtime()
                        _checkpoint_current_step()
                        continue

                    # route
                    if wn.terminal or len(adj.get(node_id, [])) == 0:
                        # token ends here -> it will never reach any remaining joins
                        if status == "failure":
                            _enter_failed()
                        _dec(mask)
                        _persist_rt_join_runtime()
                        _checkpoint_current_step()
                        _enter_cancelling(
                            reason_node_id=str(node_id), token_id=str(token_id)
                        )
                        continue

                    edges = adj.get(node_id, [])
                    next_nodes, route_decision = self._route_next(
                        edges, state, run_result, wn.fanout, nodes
                    )

                    # Trace routing decision (includes rejections) at orchestration choke point
                    try:
                        tc = TraceContext(
                            run_id=str(run_id),
                            token_id=str(token_id),
                            step_seq=int(step_seq_current),
                            node_id=str(node_id),
                            attempt=1,
                            conversation_id=str(conversation_id),
                            turn_node_id=str(turn_node_id),
                        )
                        self.emitter.emit(
                            type="routing_decision",
                            ctx=tc,
                            payload={
                                "evaluated": [
                                    (a, bool(b))
                                    for a, b in getattr(route_decision, "evaluated", [])
                                ],
                                "selected": [
                                    (e, t, r)
                                    for e, t, r in getattr(
                                        route_decision, "selected", []
                                    )
                                ],
                                "next_nodes": [str(x) for x in (next_nodes or [])],
                            },
                        )
                        # Also emit per-evaluation/per-selection events for telemetry consumers
                        for pred_name, ok in getattr(route_decision, "evaluated", []):
                            try:
                                self.emitter.predicate_evaluated(
                                    tc, predicate=str(pred_name), value=bool(ok)
                                )
                            except Exception:
                                pass
                        for edge_id, to_node_id, reason in getattr(
                            route_decision, "selected", []
                        ):
                            try:
                                self.emitter.edge_selected(
                                    tc,
                                    edge_id=str(edge_id),
                                    to_node_id=str(to_node_id),
                                    reason=str(reason),
                                )
                            except Exception:
                                pass

                        # Tracing must never break execution
                    except Exception:
                        pass

                    if status == "failure":
                        handled_failure = any(
                            reason in {"predicate", "explicit"}
                            for _edge_id, _to_node_id, reason in getattr(
                                route_decision, "selected", []
                            )
                        )
                        if not handled_failure:
                            next_nodes = []

                    if run_failed:
                        _dec(mask)
                        _persist_rt_join_runtime()
                        _checkpoint_current_step()
                        continue

                    if not next_nodes:
                        if status == "failure":
                            _enter_failed()
                        _dec(mask)
                        _persist_rt_join_runtime()

                        if (step_seq_current % self.checkpoint_every_n_steps) == 0:
                            with self._maybe_step_uow():
                                self._persist_checkpoint(
                                    conversation_id=conversation_id,
                                    workflow_id=workflow_id,
                                    run_id=run_id,
                                    step_seq=step_seq_current,
                                    state=state,
                                    last_exec_node=last_exec_node,
                                )
                            try:
                                tc_ck = TraceContext(
                                    run_id=str(run_id),
                                    token_id=str(token_id),
                                    step_seq=int(step_seq_current),
                                    node_id=str(node_id),
                                    attempt=1,
                                    conversation_id=str(conversation_id),
                                    turn_node_id=str(turn_node_id),
                                )

                                self.emitter.emit(
                                    type="checkpoint_saved",
                                    ctx=tc_ck,
                                    payload={"step_seq": int(step_seq_current)},
                                )

                            except Exception:
                                pass
                        _enter_cancelling(
                            reason_node_id=str(node_id), token_id=str(token_id)
                        )
                        continue

                    # continuation token
                    first = True
                    for i_fanout, nxt in enumerate(next_nodes):
                        nxt = str(nxt)
                        nxt_mask = int(_may_reach_join.get(nxt, 0))

                        if first:
                            # continuation keeps token_id
                            t = (
                                str(nxt),
                                int(nxt_mask),
                                str(token_id),
                                parent_token_id,
                            )

                            leaving = mask & ~nxt_mask
                            if leaving:
                                _dec(leaving)
                                _persist_rt_join_runtime()

                            gained = nxt_mask & ~mask
                            if gained:
                                _inc(gained)
                                _persist_rt_join_runtime()

                            pending_tokens.add(t)
                            scheduled_q.put(t)
                            _persist_rt_join_runtime()
                            first = False
                        else:
                            # fanout child gets a NEW token_id
                            child_token_id = stable_id(
                                "token_id",
                                f"{token_id}/{step_seq_current}:{i_fanout}:{nxt}",
                            ).hex  # uuid.uuid4().hex
                            t = (str(nxt), int(nxt_mask), child_token_id, str(token_id))

                            try:
                                mq.put_nowait(
                                    {
                                        "type": "token.spawn",
                                        "parent_token_id": str(token_id),
                                        "child_token_id": child_token_id,
                                        "from_node_id": node_id,
                                        "to_node_id": str(nxt),
                                    }
                                )
                            except queue.Full:
                                pass
                            # trace token spawn
                            try:
                                tc_spawn = TraceContext(
                                    run_id=str(run_id),
                                    token_id=str(token_id),
                                    step_seq=int(step_seq_current),
                                    node_id=str(node_id),
                                    attempt=1,
                                    conversation_id=str(conversation_id)
                                    if conversation_id is not None
                                    else None,
                                    turn_node_id=str(turn_node_id)
                                    if turn_node_id is not None
                                    else None,
                                )
                                self.emitter.emit(
                                    type="token_spawned",
                                    ctx=tc_spawn,
                                    payload={
                                        "parent_token_id": str(token_id),
                                        "child_token_id": str(child_token_id),
                                        "to_node_id": str(nxt),
                                    },
                                )
                            except Exception:
                                pass

                            # fanout creates a new token (new outstanding obligations)
                            _inc(nxt_mask)

                            pending_tokens.add(t)
                            scheduled_q.put(t)
                            _persist_rt_join_runtime()

                    _checkpoint_current_step()
                    _enter_cancelling(
                        reason_node_id=str(node_id), token_id=str(token_id)
                    )
            raise Exception("unreacheable")

    def _route_next(
        self,
        edges: List[WorkflowEdge],
        state: WorkflowState,
        last_result: StepRunResult,
        fanout: bool,
        nodes: Optional[dict[str, WorkflowNode]] = None,
    ) -> tuple[List[str], RouteDecision]:
        """
        Waterfall routing:

          1) Evaluate explicit edge predicates (e.predicate != None) in order.
             - Record *all* predicate evaluations (true/false) into RouteDecision.evaluated.
             - Select the first matching edge unless fanout/multiplicity allows multiple.

          2) If no predicate edges match, evaluate unconditional edges (e.predicate == None)
             using BasePredicate (node-level "next_step_names" decision).

          3) If still nothing matches, pick any is_default edge.

        Returns:
          (next_node_ids, route_decision)

        NOTE: This function is pure with respect to tracing; the caller is responsible
        for emitting RouteDecision into the trace sink.
        """
        matched: List[tuple[WorkflowEdge, str]] = []
        decision = RouteDecision(evaluated=[], selected=[])

        def _edge_id(e: WorkflowEdge) -> str:
            return str(
                getattr(e, "id", None)
                or getattr(e, "edge_id", None)
                or f"{getattr(e, 'predicate', None)}->{(getattr(e, 'target_ids', None) or [''])[0]}"
            )

        def _first_target(e: WorkflowEdge) -> Optional[str]:
            tids = getattr(e, "target_ids", None) or []
            if not tids:
                return None
            return str(tids[0])

        def _stop_on_first(e: WorkflowEdge) -> bool:
            # stop if not fanout and edge multiplicity is not 'many'
            return (not fanout) and (getattr(e, "multiplicity", "one") != "many")

        def _target_aliases(target_id: str) -> set[str]:
            aliases = {str(target_id), str(target_id).split("|")[-1]}
            if nodes is not None:
                target_node = nodes.get(str(target_id))
                if target_node is not None:
                    label = getattr(target_node, "label", None)
                    if label:
                        aliases.add(str(label))
                    op = getattr(target_node, "op", None)
                    if op:
                        aliases.add(str(op))
            return aliases

        explicit_next = [
            str(x) for x in (getattr(last_result, "next_step_names", []) or [])
        ]
        if explicit_next:
            explicit_matches: list[str] = []
            for alias in explicit_next:
                matched_target = None
                for e in edges:
                    tgt = _first_target(e)
                    if tgt is None:
                        continue
                    if alias in _target_aliases(tgt):
                        matched_target = tgt
                        decision.selected.append((_edge_id(e), tgt, "explicit"))
                        break
                decision.evaluated.append(
                    (f"_route_next:{alias}", matched_target is not None)
                )
                if matched_target is not None:
                    explicit_matches.append(str(matched_target))
            if explicit_matches:
                return explicit_matches, decision

        failure_only = getattr(last_result, "status", None) == "failure"

        # (1) explicit predicates
        for e in edges:
            e: WorkflowEdge
            if getattr(e, "predicate", None) is None:
                continue
            tgt = _first_target(e)
            if tgt is None:
                continue
            pred_name = str(getattr(e, "predicate", ""))
            pred = self.predicate_registry.get(pred_name)
            if pred is None:
                # record missing predicate as rejection (False)
                decision.evaluated.append((f"{_edge_id(e)}:{pred_name}", False))
                continue

            workflow_info = WorkflowEdgeInfo.from_workflow_edge(e)
            try:
                ok = bool(pred(workflow_info, state, last_result))
            except Exception:
                ok = False

            decision.evaluated.append((f"{_edge_id(e)}:{pred_name}", ok))
            if ok:
                matched.append((e, tgt))
                decision.selected.append((_edge_id(e), tgt, "predicate"))

        def get_edge_priority(edge: tuple[WorkflowEdge, str]):
            return edge[0].priority

        matched.sort(key=get_edge_priority, reverse=True)

        candidates = []
        for e, next_node_id in matched:
            if _stop_on_first(e):
                if not candidates:
                    candidates.append(next_node_id)
                return candidates, decision
            elif fanout:
                candidates.append(next_node_id)
            else:
                # default unknown just add and return
                if not candidates:
                    candidates.append(next_node_id)
                return candidates, decision

        # Failure routing only considers explicit `_route_next` targets or
        # predicates that inspect the failed result. If neither matched, the
        # failure is unmatched and the token should terminate as failure.
        if failure_only:
            return [], decision

        # (2) unconditional edges (node-level decision)
        from typing import cast
        from .contract import BasePredicate

        node_decider = cast(Predicate, BasePredicate())
        for e in edges:
            if getattr(e, "predicate", None) is not None:
                continue  # skip as it is processed in earlier loo
            tgt = _first_target(e)
            if tgt is None:
                continue

            workflow_info = WorkflowEdgeInfo.from_workflow_edge(e)
            try:
                ok = bool(node_decider(workflow_info, state, last_result))
            except Exception:
                ok = False

            # Record unconditional evaluations too (use a synthetic name)
            decision.evaluated.append((f"{_edge_id(e)}:<base>", ok))
            if ok:
                matched.append((e, tgt))
                decision.selected.append((_edge_id(e), tgt, "base"))
                if _stop_on_first(e):
                    return [i[1] for i in matched[0:1]], decision

        if matched:
            return ([i[1] for i in (matched if fanout else matched[0:1])]), decision

        # (3) default edge
        for e in edges:
            if bool(getattr(e, "is_default", False)):
                tids = [str(x) for x in (getattr(e, "target_ids", None) or [])]
                if not tids:
                    continue
                picked = tids if fanout else tids[0:1]
                # record default selection once
                decision.selected.append((_edge_id(e), picked[0], "default"))
                return picked, decision

        return [], decision

    # --------------------
    # Persistence helpers (conversation_engine)
    # --------------------

    def _safe_get_conversation_nodes(
        self, *, where: dict, limit: int = 1000
    ) -> list[Any]:
        try:
            return self.conversation_engine.read.get_nodes(where=where, limit=limit)
        except Exception as exc:
            msg = str(exc)
            if "Nothing found on disk" in msg or "hnsw segment reader" in msg:
                return []
            raise

    def _find_eligible_cancel_request(
        self,
        *,
        conversation_id: str,
        run_id: str,
    ) -> dict[str, Any] | None:
        cancelled_nodes = self._safe_get_conversation_nodes(
            where={"$and": [{"entity_type": "workflow_cancelled"}, {"run_id": run_id}]},
            limit=1,
        )
        if cancelled_nodes:
            return None

        req_nodes = self._safe_get_conversation_nodes(
            where={
                "$and": [
                    {"entity_type": "workflow_cancel_request"},
                    {"run_id": run_id},
                    {"conversation_id": conversation_id},
                ]
            },
            limit=10_000,
        )
        if not req_nodes:
            return None

        try:
            watermark = int(
                self.conversation_engine.meta_sqlite.current_user_seq(conversation_id)
            )
        except Exception:
            watermark = None

        req_best: dict[str, Any] | None = None
        for node in req_nodes:
            md = getattr(node, "metadata", {}) or {}
            try:
                seq = int(md.get("seq", -1))
            except Exception:
                seq = -1
            if seq < 0:
                continue
            if watermark is not None and seq > watermark:
                continue
            if req_best is None or seq < int(req_best["seq"]):
                req_best = {
                    "node_id": str(getattr(node, "id", "") or ""),
                    "seq": seq,
                    "watermark": watermark,
                }
        return req_best

    def _conversation_backend(self) -> Any | None:
        return getattr(self.conversation_engine, "backend", None)

    def _conversation_node_exists(self, node_id: str) -> bool:
        backend = self._conversation_backend()
        if backend is not None:
            existing = backend.node_get(ids=[node_id], include=[])
            return bool(existing.get("ids"))

        try:
            nodes = self.conversation_engine.read.get_nodes()
        except TypeError:
            nodes = self.conversation_engine.read.get_nodes(where=None, limit=10_000)
        except Exception:
            nodes = getattr(self.conversation_engine, "nodes", [])
        return any(
            str(getattr(node, "id", "") or "") == node_id for node in (nodes or [])
        )

    def _conversation_edge_exists(self, edge_id: str) -> bool:
        backend = self._conversation_backend()
        if backend is not None:
            existing = backend.edge_get(ids=[edge_id], include=[])
            return bool(existing.get("ids"))

        try:
            edges = self.conversation_engine.read.get_edges()
        except TypeError:
            edges = self.conversation_engine.read.get_edges(where=None, limit=10_000)
        except Exception:
            edges = getattr(self.conversation_engine, "edges", [])
        return any(
            str(getattr(edge, "id", "") or "") == edge_id for edge in (edges or [])
        )

    def _persist_cancelled_terminal(
        self,
        *,
        conversation_id: str,
        workflow_id: str,
        run_id: str,
        accepted_step_seq: int,
        cancel_info: dict[str, Any] | None,
        last_processed_node_id: str | None = None,
    ) -> str:
        node_id = f"wf_cancelled|{run_id}"
        if self._conversation_node_exists(node_id):
            return node_id

        req_node_id = None if not cancel_info else str(cancel_info.get("node_id") or "")
        req_seq = None if not cancel_info else cancel_info.get("seq")
        watermark = None if not cancel_info else cancel_info.get("watermark")
        excerpt = (
            f"workflow cancelled run_id={run_id} accepted_step_seq={accepted_step_seq}"
        )
        span = Span(
            **_make_trace_span(
                conversation_id=conversation_id,
                excerpt=excerpt,
                doc_id=f"conv:{conversation_id}",
            )
        )
        node = WorkflowCancelledNode(
            id=node_id,
            label="Workflow cancelled",
            type="entity",
            doc_id=node_id,
            summary=excerpt,
            mentions=[Grounding(spans=[span])],
            properties={"entity_type": "workflow_cancelled"},
            metadata={
                "entity_type": "workflow_cancelled",
                "workflow_id": workflow_id,
                "run_id": run_id,
                "conversation_id": conversation_id,
                "accepted_step_seq": int(accepted_step_seq),
                "cancel_request_node_id": req_node_id or None,
                "cancel_request_seq": req_seq,
                "accepted_watermark": watermark,
                "last_processed_node_id": (
                    str(last_processed_node_id) if last_processed_node_id else None
                ),
                "level_from_root": 0,
            },
            level_from_root=0,
            domain_id=None,
            canonical_entity_id=None,
            embedding=None,
        )
        with self._trace_write_mode():
            self.conversation_engine.write.add_node(node)

            run_node_id = f"wf_run|{run_id}"
            if self._conversation_node_exists(run_node_id):
                edge_id = str(stable_id("workflow.edge", "cancelled", run_node_id, node_id))
                if not self._conversation_edge_exists(edge_id):
                    edge = _make_runtime_edge(
                        edge_id=edge_id,
                        relation="wf_cancelled",
                        label="wf_cancelled",
                        summary="workflow cancelled",
                        doc_id=f"wf_cancelled|{run_id}",
                        conversation_id=conversation_id,
                        source_ids=[run_node_id],
                        target_ids=[node_id],
                        mentions=[Grounding(spans=[Span.from_dummy_for_conversation()])],
                        run_id=run_id,
                    )
                    self.conversation_engine.write.add_edge(edge)

            if req_node_id:
                req_edge_id = str(
                    stable_id("workflow.edge", "cancel_reconciled", req_node_id, node_id)
                )
                if not self._conversation_edge_exists(req_edge_id):
                    req_edge = _make_runtime_edge(
                        edge_id=req_edge_id,
                        relation="wf_cancel_reconciled",
                        label="wf_cancel_reconciled",
                        summary="cancel request reconciled",
                        doc_id=f"wf_cancelled|{run_id}",
                        conversation_id=conversation_id,
                        source_ids=[req_node_id],
                        target_ids=[node_id],
                        mentions=[Grounding(spans=[Span.from_dummy_for_conversation()])],
                        run_id=run_id,
                    )
                    self.conversation_engine.write.add_edge(req_edge)

            if last_processed_node_id:
                cancelled_at_edge_id = str(
                    stable_id(
                        "workflow.edge",
                        "cancelled_at",
                        node_id,
                        str(last_processed_node_id),
                    )
                )
                if not self._conversation_edge_exists(cancelled_at_edge_id):
                    cancelled_at_edge = _make_runtime_edge(
                        edge_id=cancelled_at_edge_id,
                        relation="wf_cancelled_at",
                        label="wf_cancelled_at",
                        summary="workflow cancelled at node",
                        doc_id=f"wf_cancelled|{run_id}",
                        conversation_id=conversation_id,
                        source_ids=[node_id],
                        target_ids=[str(last_processed_node_id)],
                        mentions=[Grounding(spans=[Span.from_dummy_for_conversation()])],
                        run_id=run_id,
                    )
                    self.conversation_engine.write.add_edge(cancelled_at_edge)
        return node_id

    def _persist_completed_terminal(
        self,
        *,
        conversation_id: str,
        workflow_id: str,
        run_id: str,
        accepted_step_seq: int,
        last_processed_node_id: str | None = None,
    ) -> str:
        node_id = f"wf_completed|{run_id}"
        if self._conversation_node_exists(node_id):
            return node_id

        excerpt = (
            f"workflow completed run_id={run_id} accepted_step_seq={accepted_step_seq}"
        )
        span = Span(
            **_make_trace_span(
                conversation_id=conversation_id,
                excerpt=excerpt,
                doc_id=f"conv:{conversation_id}",
            )
        )
        node = WorkflowCompletedNode(
            id=node_id,
            label="Workflow completed",
            type="entity",
            doc_id=node_id,
            summary=excerpt,
            mentions=[Grounding(spans=[span])],
            properties={"entity_type": "workflow_completed"},
            metadata={
                "entity_type": "workflow_completed",
                "workflow_id": workflow_id,
                "run_id": run_id,
                "conversation_id": conversation_id,
                "accepted_step_seq": int(accepted_step_seq),
                "last_processed_node_id": (
                    str(last_processed_node_id) if last_processed_node_id else None
                ),
                "level_from_root": 0,
            },
            level_from_root=0,
            domain_id=None,
            canonical_entity_id=None,
            embedding=None,
        )
        with self._trace_write_mode():
            self.conversation_engine.write.add_node(node)

            run_node_id = f"wf_run|{run_id}"
            if self._conversation_node_exists(run_node_id):
                edge_id = str(stable_id("workflow.edge", "completed", run_node_id, node_id))
                if not self._conversation_edge_exists(edge_id):
                    edge = _make_runtime_edge(
                        edge_id=edge_id,
                        relation="wf_completed",
                        label="wf_completed",
                        summary="workflow completed",
                        doc_id=f"wf_completed|{run_id}",
                        conversation_id=conversation_id,
                        source_ids=[run_node_id],
                        target_ids=[node_id],
                        mentions=[Grounding(spans=[Span.from_dummy_for_conversation()])],
                        run_id=run_id,
                    )
                    self.conversation_engine.write.add_edge(edge)
        return node_id

    def _persist_failed_terminal(
        self,
        *,
        conversation_id: str,
        workflow_id: str,
        run_id: str,
        accepted_step_seq: int,
        errors: list[str] | None,
        last_processed_node_id: str | None = None,
    ) -> str:
        node_id = f"wf_failed|{run_id}"
        if self._conversation_node_exists(node_id):
            return node_id

        safe_errors = [str(err) for err in (errors or [])]
        excerpt = f"workflow failed run_id={run_id} accepted_step_seq={accepted_step_seq}"
        if safe_errors:
            excerpt += f" errors={len(safe_errors)}"
        span = Span(
            **_make_trace_span(
                conversation_id=conversation_id,
                excerpt=excerpt,
                doc_id=f"conv:{conversation_id}",
            )
        )
        node = WorkflowFailedNode(
            id=node_id,
            label="Workflow failed",
            type="entity",
            doc_id=node_id,
            summary=excerpt,
            mentions=[Grounding(spans=[span])],
            properties={"entity_type": "workflow_failed"},
            metadata={
                "entity_type": "workflow_failed",
                "workflow_id": workflow_id,
                "run_id": run_id,
                "conversation_id": conversation_id,
                "accepted_step_seq": int(accepted_step_seq),
                "errors": safe_errors,
                "last_processed_node_id": (
                    str(last_processed_node_id) if last_processed_node_id else None
                ),
                "level_from_root": 0,
            },
            level_from_root=0,
            domain_id=None,
            canonical_entity_id=None,
            embedding=None,
        )
        with self._trace_write_mode():
            self.conversation_engine.write.add_node(node)

            run_node_id = f"wf_run|{run_id}"
            if self._conversation_node_exists(run_node_id):
                edge_id = str(stable_id("workflow.edge", "failed", run_node_id, node_id))
                if not self._conversation_edge_exists(edge_id):
                    edge = _make_runtime_edge(
                        edge_id=edge_id,
                        relation="wf_failed",
                        label="wf_failed",
                        summary="workflow failed",
                        doc_id=f"wf_failed|{run_id}",
                        conversation_id=conversation_id,
                        source_ids=[run_node_id],
                        target_ids=[node_id],
                        mentions=[Grounding(spans=[Span.from_dummy_for_conversation()])],
                        run_id=run_id,
                    )
                    self.conversation_engine.write.add_edge(edge)

            if last_processed_node_id:
                failed_at_edge_id = str(
                    stable_id(
                        "workflow.edge",
                        "failed_at",
                        node_id,
                        str(last_processed_node_id),
                    )
                )
                if not self._conversation_edge_exists(failed_at_edge_id):
                    failed_at_edge = _make_runtime_edge(
                        edge_id=failed_at_edge_id,
                        relation="wf_failed_at",
                        label="wf_failed_at",
                        summary="workflow failed at node",
                        doc_id=f"wf_failed|{run_id}",
                        conversation_id=conversation_id,
                        source_ids=[node_id],
                        target_ids=[str(last_processed_node_id)],
                        mentions=[Grounding(spans=[Span.from_dummy_for_conversation()])],
                        run_id=run_id,
                    )
                    self.conversation_engine.write.add_edge(failed_at_edge)
        return node_id

    def _persist_workflow_run(
        self,
        conversation_id: str,
        workflow_id: str,
        run_id: str,
        turn_node_id: str,
        status: str,
    ) -> WorkflowRunNode: 
        # current engine always persist on edit, no batch persist mode needed
        from kogwistar.engine_core.models import (
            Grounding,
            Span,
        )  # adjust import path to your package layout

        excerpt = f"workflow_run {workflow_id} {run_id} status={status}"
        span = Span(
            **_make_trace_span(
                conversation_id=conversation_id,
                excerpt=excerpt,
                doc_id=f"conv:{conversation_id}",
            )
        )
        n = WorkflowRunNode(
            id=f"wf_run|{run_id}",
            label=f"Workflow run {workflow_id}",
            type="entity",
            doc_id=f"wf_run|{run_id}",
            summary=excerpt,
            mentions=[Grounding(spans=[span])],
            properties={},
            metadata={
                "entity_type": "workflow_run",
                "workflow_id": workflow_id,
                "workflow_version": "v1",
                "run_id": run_id,
                "conversation_id": conversation_id,
                "turn_node_id": turn_node_id,
                "status": status,
                "level_from_root": 0,
            },
            level_from_root=0,
            domain_id=None,
            canonical_entity_id=None,
            embedding=None,
        )
        with self._trace_write_mode():
            self.conversation_engine.write.add_node(n)
        return n

    # def _update_workflow_run_status(self, conversation_id: str, run_id: str, status: str) -> None:
    #     node_id = f"wf_run|{run_id}"
    #     got = self.conversation_engine.get_nodes(ids=[node_id], limit=1)
    #     if not got:
    #         return
    #     node = got[0]
    #     node.metadata = dict(getattr(node, "metadata", {}) or {})
    #     node.metadata["status"] = status
    #     node.summary = f"workflow_run {node.metadata.get('workflow_id', '')} {run_id} status={status}"
    #     try:
    #         props = dict(getattr(node, "properties", {}) or {})
    #         props["status"] = status
    #         node.properties = props
    #     except Exception:
    #         pass
    #     self.conversation_engine.write.add_node(node)

    def _persist_step_exec(
        self,
        conversation_id: str,
        workflow_id: str,
        run_id: str,
        step_seq: int,
        workflow_node_id: str,
        op: str,
        status: str,
        duration_ms: int,
        result: StepRunResult,
        state: WorkflowState,
        token_id: str | None = None,
        parent_token_id: str | None = None,
        join_mask: int | None = None,
        last_exec_node: Optional[WorkflowStepExecNode | WorkflowRunNode] = None,
    ) -> WorkflowStepExecNode:
        # from kogwistar.models import WorkflowStepExecNode, Grounding, Span  # adjust import path

        result_json = try_serialize_with_ref(result)

        excerpt = (
            f"{dict(step=step_seq, op=op, status=status, duration_ms=duration_ms)}"
        )
        span = Span(
            **_make_trace_span(
                conversation_id=conversation_id,
                excerpt=excerpt,
                doc_id=f"conv:{conversation_id}",
            )
        )

        n = WorkflowStepExecNode(
            id=f"wf_step|{run_id}|{step_seq}",
            label=f"WF step {step_seq}: {op}",
            type="entity",
            doc_id=f"wf_step|{run_id}|{step_seq}",
            summary=excerpt,
            mentions=[Grounding(spans=[span])],
            properties={},
            level_from_root=0,
            domain_id=None,
            canonical_entity_id=None,
            embedding=None,
            metadata={
                "entity_type": "workflow_step_exec",
                "run_id": run_id,
                "workflow_id": workflow_id,
                "workflow_node_id": workflow_node_id,
                "step_seq": step_seq,
                "op": op,
                "status": status,
                "duration_ms": duration_ms,
                "result_json": result_json,
                "token_id": token_id,
                "parent_token_id": parent_token_id,
                "join_mask": join_mask,
                "conversation_id": conversation_id,
                "char_distance_from_last_summary": 0,
                "turn_distance_from_last_summary": 0,
                # "tail_turn_index": state["prev_turn_meta_summary"]["tail_turn_index"]
            },
        )
        with self._trace_write_mode():
            self.conversation_engine.write.add_node(n)
            if result.conversation_node_id:
                self_span = Span(
                    collection_page_url=f"conversation/{conversation_id}",
                    document_page_url=f"conversation/{conversation_id}#{n.id}",
                    doc_id=f"conv:{conversation_id}",
                    insertion_method="step_exec",
                    page_number=1,
                    start_char=0,
                    end_char=len(n.summary),
                    excerpt=n.summary,
                    context_before="",
                    context_after="",
                    chunk_id=None,
                    source_cluster_id=None,
                    verification=MentionVerification(
                        method="system",
                        is_verified=True,
                        score=1.0,
                        notes="step run result",
                    ),
                )
            # eid = f"wf_interstep_edge|{run_id}|{step_seq}|{result.conversation_node_id}"
            # e = ConversationEdge(id = eid, type = 'relationship', summary = f"results during {result.conversation_node_id}",
            #                      domain_id=None, label='run_result',
            #                      properties={},
            #                      mentions=[Grounding(spans=[self_span])], canonical_entity_id=None,
            #                      source_ids=[n.safe_get_id()], target_ids=[result.conversation_node_id],
            #                      relation="run_result", source_edge_ids = [], target_edge_ids = [], embedding = None,
            #                      doc_id = f"wf_step|{run_id}|{step_seq}",
            #                      metadata={"relation":"run_result",
            #                                "source_id":[n.id],
            #                                "target_id":result.conversation_node_id,
            #                                "char_distance_from_last_summary": 0,
            #                                "turn_distance_from_last_summary": 0,
            #
            #                                },
            #                      )
            # self.conversation_engine.write.add_edge(e)
            if last_exec_node:
                content = f"{last_exec_node.safe_get_id()} next is {n.safe_get_id()}"
                self_span = Span(
                    collection_page_url=f"conversation/{conversation_id}",
                    document_page_url=f"conversation/{conversation_id}#{n.id}",
                    doc_id=f"conv:{conversation_id}",
                    insertion_method="step_exec",
                    page_number=1,
                    start_char=0,
                    end_char=len(content),
                    excerpt=content,
                    context_before="",
                    context_after="",
                    chunk_id=None,
                    source_cluster_id=None,
                    verification=MentionVerification(
                        method="system",
                        is_verified=True,
                        score=1.0,
                        notes="step run execution",
                    ),
                )
                eid = f"wf_next_step_exec|{run_id}|{step_seq}|last::{last_exec_node.safe_get_id()}|to::{n.safe_get_id()}"
                e = _make_runtime_edge(
                    edge_id=eid,
                    relation="wf_next_step_exec",
                    label=f"wf_next_step_exec {step_seq=}",
                    summary=f"wf_next_step_exec {step_seq=}",
                    doc_id=f"wf_next_step_exec|{run_id}|{step_seq}",
                    conversation_id=conversation_id,
                    source_ids=[last_exec_node.safe_get_id()],
                    target_ids=[n.safe_get_id()],
                    mentions=[Grounding(spans=[self_span])],
                    run_id=run_id,
                    metadata={
                        "source_id": [last_exec_node.safe_get_id()],
                        "target_id": [n.safe_get_id()],
                        "char_distance_from_last_summary": 0,
                        "turn_distance_from_last_summary": 0,
                    },
                )
                self.conversation_engine.write.add_edge(e)
            if result.conversation_node_id:
                content = f"{n.safe_get_id()} created {result.conversation_node_id} durign execution"
                self_span = Span(
                    collection_page_url=f"conversation/{conversation_id}",
                    document_page_url=f"conversation/{conversation_id}#{n.id}",
                    doc_id=f"conv:{conversation_id}",
                    insertion_method="step_exec",
                    page_number=1,
                    start_char=0,
                    end_char=len(content),
                    excerpt=content,
                    context_before="",
                    context_after="",
                    chunk_id=None,
                    source_cluster_id=None,
                    verification=MentionVerification(
                        method="system",
                        is_verified=True,
                        score=1.0,
                        notes="step execution created node",
                    ),
                )
                eid = f"conv:{conversation_id}|wfexe:{n.safe_get_id()}|created:{result.conversation_node_id}"
                e = _make_runtime_edge(
                    edge_id=eid,
                    relation="created_child",
                    label=f"created node during {step_seq=}",
                    summary=f"created node during {step_seq=}",
                    doc_id=f"wf_next_step_exec|{run_id}|{step_seq}",
                    conversation_id=conversation_id,
                    source_ids=[n.safe_get_id()],
                    target_ids=[result.conversation_node_id],
                    mentions=[Grounding(spans=[self_span])],
                    run_id=run_id,
                    metadata={
                        "source_id": [n.safe_get_id()],
                        "target_id": [result.conversation_node_id],
                        "char_distance_from_last_summary": 0,
                        "turn_distance_from_last_summary": 0,
                    },
                )

                self.conversation_engine.write.add_edge(e)
        return n

    def _persist_checkpoint(
        self,
        conversation_id: str,
        workflow_id: str,
        run_id: str,
        step_seq: int,
        state: WorkflowState,
        last_exec_node: Optional[WorkflowStepExecNode | WorkflowRunNode] = None,
    ) -> None:
        from kogwistar.engine_core.models import (
            Grounding,
            Span,
        )  # adjust import path

        state_copy = {k: v for k, v in state.items() if k != "_deps"}
        state_json = try_serialize_with_ref(state_copy)
        excerpt = f"checkpoint step_seq={step_seq}"
        span = Span(
            **_make_trace_span(
                conversation_id=conversation_id,
                excerpt=excerpt,
                doc_id=f"conv:{conversation_id}",
            )
        )

        n = WorkflowCheckpointNode(
            id=f"wf_ckpt|{run_id}|{step_seq}",
            label=f"WF checkpoint {step_seq}",
            type="entity",
            doc_id=f"wf_ckpt|{run_id}|{step_seq}",
            summary=excerpt,
            mentions=[Grounding(spans=[span])],
            properties={},
            metadata={
                "entity_type": "workflow_checkpoint",
                "run_id": run_id,
                "workflow_id": workflow_id,
                "step_seq": step_seq,
                "state_json": state_json,
                "level_from_root": 0,
                "conversation_id": conversation_id,
            },
            domain_id=None,
            canonical_entity_id=None,
            embedding=None,
            level_from_root=0,
        )
        with self._trace_write_mode():
            self.conversation_engine.write.add_node(n)

            if last_exec_node:
                self_span = Span(
                    collection_page_url=f"conversation/{conversation_id}",
                    document_page_url=f"conversation/{conversation_id}#{n.id}",
                    doc_id=f"conv:{conversation_id}",
                    insertion_method="persist_checkpoint",
                    page_number=1,
                    start_char=0,
                    end_char=len(n.summary),
                    excerpt=n.summary,
                    context_before="",
                    context_after="",
                    chunk_id=None,
                    source_cluster_id=None,
                    verification=MentionVerification(
                        method="system",
                        is_verified=True,
                        score=1.0,
                        notes="persist_checkpoint",
                    ),
                )
                eid = f"persist_checkpoint|{run_id}|{step_seq}|last::{last_exec_node.safe_get_id()}|to::{n.safe_get_id()}"
                e = _make_runtime_edge(
                    edge_id=eid,
                    relation="persist_checkpoint during",
                    label=f"persist_checkpoint during {step_seq=}",
                    summary=f"persist_checkpoint during {step_seq=}",
                    doc_id=f"wf_next_step_exec|{run_id}|{step_seq}",
                    conversation_id=conversation_id,
                    source_ids=[n.safe_get_id()],
                    target_ids=[last_exec_node.safe_get_id()],
                    mentions=[Grounding(spans=[self_span])],
                    run_id=run_id,
                    metadata={
                        "source_id": [last_exec_node.safe_get_id()],
                        "target_id": [n.safe_get_id()],
                        "char_distance_from_last_summary": 0,
                        "turn_distance_from_last_summary": 0,
                    },
                )
                self.conversation_engine.write.add_edge(e)
