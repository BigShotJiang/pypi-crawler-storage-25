from __future__ import annotations

from tutorial_ladder import main


if __name__ == "__main__":
    main()
