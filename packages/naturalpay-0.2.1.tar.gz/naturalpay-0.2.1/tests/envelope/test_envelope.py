from typing import Any

import pytest

from naturalpay._internal._envelope import wrap_if_needed, is_already_enveloped


@pytest.mark.parametrize(
    "body,expected",
    [
        ({"data": {"attributes": {"x": 1}}}, True),
        ({"data": {"attributes": {}}}, True),
        ({"x": 1}, False),
        ({"data": "string"}, False),
        ({"data": {"id": "x"}}, False),
        ([], False),
        (None, False),
        ("", False),
        ({}, False),
    ],
)
def test_is_already_enveloped(body: object, expected: bool) -> None:
    assert is_already_enveloped(body) is expected


class TestWrapIfNeeded:
    def test_wraps_plain_dict_when_json_request(self) -> None:
        assert wrap_if_needed({"amount": 100}, is_json_request=True) == {
            "data": {"attributes": {"amount": 100}}
        }

    def test_no_list_canary_wraps_without_knowing_any_path(self) -> None:
        # The whole point: the adapter does not consult a path/method list.
        # Any plain dict body with a JSON request wraps.
        assert wrap_if_needed({"futureField": True}, is_json_request=True) == {
            "data": {"attributes": {"futureField": True}}
        }

    def test_passes_through_when_not_json_request(self) -> None:
        body = {"amount": 100}
        # Multipart/form-data path: the call site sets is_json_request=False
        # because options.files is not None (or content_type is non-JSON).
        # The adapter must not wrap; downstream multipart serialization
        # expects raw fields.
        assert wrap_if_needed(body, is_json_request=False) is body

    def test_passes_through_none(self) -> None:
        # No empty-attributes wrap — null/undefined means "no body."
        assert wrap_if_needed(None, is_json_request=True) is None

    def test_passes_through_bytes(self) -> None:
        raw = b'{"x": 1}'
        assert wrap_if_needed(raw, is_json_request=True) is raw

    def test_passes_through_bytearray(self) -> None:
        raw = bytearray(b'{"x": 1}')
        assert wrap_if_needed(raw, is_json_request=True) is raw

    def test_passes_through_list(self) -> None:
        arr: Any = [1, 2, 3]
        assert wrap_if_needed(arr, is_json_request=True) is arr

    def test_passes_through_string(self) -> None:
        s: Any = '{"x": 1}'
        assert wrap_if_needed(s, is_json_request=True) is s

    def test_does_not_double_wrap_already_enveloped(self) -> None:
        enveloped: Any = {"data": {"attributes": {"amount": 1}}}
        assert wrap_if_needed(enveloped, is_json_request=True) is enveloped

    def test_benign_top_level_data_field_is_still_wrapped(self) -> None:
        # data exists but no attributes sibling — not an envelope, so wrap.
        assert wrap_if_needed({"data": "string-value"}, is_json_request=True) == {
            "data": {"attributes": {"data": "string-value"}}
        }

    def test_wraps_empty_dict(self) -> None:
        # An empty body for an envelope endpoint serializes as
        # {"data": {"attributes": {}}} — consistent with the wire contract.
        assert wrap_if_needed({}, is_json_request=True) == {"data": {"attributes": {}}}
