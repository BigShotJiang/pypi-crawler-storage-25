# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import (
    DelegationGetAgentDelegationResponse,
    DelegationListAgentDelegationsResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestDelegations:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_agent_delegation(self, client: Natural) -> None:
        delegation = client.delegations.get_agent_delegation(
            agent_delegation_id="adl_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(DelegationGetAgentDelegationResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_agent_delegation_with_all_params(self, client: Natural) -> None:
        delegation = client.delegations.get_agent_delegation(
            agent_delegation_id="adl_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(DelegationGetAgentDelegationResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get_agent_delegation(self, client: Natural) -> None:
        response = client.delegations.with_raw_response.get_agent_delegation(
            agent_delegation_id="adl_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        delegation = response.parse()
        assert_matches_type(DelegationGetAgentDelegationResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get_agent_delegation(self, client: Natural) -> None:
        with client.delegations.with_streaming_response.get_agent_delegation(
            agent_delegation_id="adl_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            delegation = response.parse()
            assert_matches_type(DelegationGetAgentDelegationResponse, delegation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_get_agent_delegation(self, client: Natural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_delegation_id` but received ''"):
            client.delegations.with_raw_response.get_agent_delegation(
                agent_delegation_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_agent_delegations(self, client: Natural) -> None:
        delegation = client.delegations.list_agent_delegations()
        assert_matches_type(DelegationListAgentDelegationsResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_agent_delegations_with_all_params(self, client: Natural) -> None:
        delegation = client.delegations.list_agent_delegations(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            cursor="cursor",
            delegatee_party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            delegation_id="dlg_ecc2efdd09bd231a9ad9bd2aada37aa7",
            delegator_party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            include_revoked=True,
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(DelegationListAgentDelegationsResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_agent_delegations(self, client: Natural) -> None:
        response = client.delegations.with_raw_response.list_agent_delegations()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        delegation = response.parse()
        assert_matches_type(DelegationListAgentDelegationsResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_agent_delegations(self, client: Natural) -> None:
        with client.delegations.with_streaming_response.list_agent_delegations() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            delegation = response.parse()
            assert_matches_type(DelegationListAgentDelegationsResponse, delegation, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncDelegations:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_agent_delegation(self, async_client: AsyncNatural) -> None:
        delegation = await async_client.delegations.get_agent_delegation(
            agent_delegation_id="adl_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(DelegationGetAgentDelegationResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_agent_delegation_with_all_params(self, async_client: AsyncNatural) -> None:
        delegation = await async_client.delegations.get_agent_delegation(
            agent_delegation_id="adl_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(DelegationGetAgentDelegationResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get_agent_delegation(self, async_client: AsyncNatural) -> None:
        response = await async_client.delegations.with_raw_response.get_agent_delegation(
            agent_delegation_id="adl_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        delegation = await response.parse()
        assert_matches_type(DelegationGetAgentDelegationResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get_agent_delegation(self, async_client: AsyncNatural) -> None:
        async with async_client.delegations.with_streaming_response.get_agent_delegation(
            agent_delegation_id="adl_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            delegation = await response.parse()
            assert_matches_type(DelegationGetAgentDelegationResponse, delegation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_get_agent_delegation(self, async_client: AsyncNatural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_delegation_id` but received ''"):
            await async_client.delegations.with_raw_response.get_agent_delegation(
                agent_delegation_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_agent_delegations(self, async_client: AsyncNatural) -> None:
        delegation = await async_client.delegations.list_agent_delegations()
        assert_matches_type(DelegationListAgentDelegationsResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_agent_delegations_with_all_params(self, async_client: AsyncNatural) -> None:
        delegation = await async_client.delegations.list_agent_delegations(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            cursor="cursor",
            delegatee_party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            delegation_id="dlg_ecc2efdd09bd231a9ad9bd2aada37aa7",
            delegator_party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            include_revoked=True,
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(DelegationListAgentDelegationsResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_agent_delegations(self, async_client: AsyncNatural) -> None:
        response = await async_client.delegations.with_raw_response.list_agent_delegations()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        delegation = await response.parse()
        assert_matches_type(DelegationListAgentDelegationsResponse, delegation, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_agent_delegations(self, async_client: AsyncNatural) -> None:
        async with async_client.delegations.with_streaming_response.list_agent_delegations() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            delegation = await response.parse()
            assert_matches_type(DelegationListAgentDelegationsResponse, delegation, path=["response"])

        assert cast(Any, response.is_closed) is True
