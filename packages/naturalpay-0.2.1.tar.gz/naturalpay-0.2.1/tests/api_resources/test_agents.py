# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import (
    AgentGetResponse,
    AgentListResponse,
    AgentCreateResponse,
    AgentRemoveResponse,
    AgentUpdateResponse,
    AgentCreateInvitationsResponse,
    AgentListInvitationsForDeveloperResponse,
)
from naturalpay._utils import parse_datetime

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAgents:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Natural) -> None:
        agent = client.agents.create(
            name="x",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(AgentCreateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Natural) -> None:
        agent = client.agents.create(
            name="x",
            idempotency_key="Idempotency-Key",
            description="description",
            limits={"per_transaction": 1},
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentCreateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Natural) -> None:
        response = client.agents.with_raw_response.create(
            name="x",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentCreateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Natural) -> None:
        with client.agents.with_streaming_response.create(
            name="x",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentCreateResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Natural) -> None:
        agent = client.agents.update(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(AgentUpdateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Natural) -> None:
        agent = client.agents.update(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            description="description",
            limits={"per_transaction": 1},
            name="name",
            status="ACTIVE",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentUpdateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Natural) -> None:
        response = client.agents.with_raw_response.update(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentUpdateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Natural) -> None:
        with client.agents.with_streaming_response.update(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentUpdateResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Natural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.update(
                agent_id="",
                idempotency_key="Idempotency-Key",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Natural) -> None:
        agent = client.agents.list()
        assert_matches_type(AgentListResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Natural) -> None:
        agent = client.agents.list(
            cursor="cursor",
            limit=1,
            status="ACTIVE",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentListResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Natural) -> None:
        response = client.agents.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentListResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Natural) -> None:
        with client.agents.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentListResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_invitations(self, client: Natural) -> None:
        agent = client.agents.create_invitations(
            agents=[
                {
                    "agent_id": "agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
                    "permissions": ["string"],
                }
            ],
            customer_email="dev@stainless.com",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(AgentCreateInvitationsResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_invitations_with_all_params(self, client: Natural) -> None:
        agent = client.agents.create_invitations(
            agents=[
                {
                    "agent_id": "agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
                    "permissions": ["string"],
                    "limits": {"per_transaction": 1},
                }
            ],
            customer_email="dev@stainless.com",
            idempotency_key="Idempotency-Key",
            expires_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentCreateInvitationsResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create_invitations(self, client: Natural) -> None:
        response = client.agents.with_raw_response.create_invitations(
            agents=[
                {
                    "agent_id": "agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
                    "permissions": ["string"],
                }
            ],
            customer_email="dev@stainless.com",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentCreateInvitationsResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create_invitations(self, client: Natural) -> None:
        with client.agents.with_streaming_response.create_invitations(
            agents=[
                {
                    "agent_id": "agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
                    "permissions": ["string"],
                }
            ],
            customer_email="dev@stainless.com",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentCreateInvitationsResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get(self, client: Natural) -> None:
        agent = client.agents.get(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_with_all_params(self, client: Natural) -> None:
        agent = client.agents.get(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get(self, client: Natural) -> None:
        response = client.agents.with_raw_response.get(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get(self, client: Natural) -> None:
        with client.agents.with_streaming_response.get(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentGetResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_get(self, client: Natural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.get(
                agent_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_invitations_for_developer(self, client: Natural) -> None:
        agent = client.agents.list_invitations_for_developer()
        assert_matches_type(AgentListInvitationsForDeveloperResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_invitations_for_developer_with_all_params(self, client: Natural) -> None:
        agent = client.agents.list_invitations_for_developer(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            cursor="cursor",
            customer_email="dev@stainless.com",
            limit=1,
            status=["PENDING"],
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentListInvitationsForDeveloperResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_invitations_for_developer(self, client: Natural) -> None:
        response = client.agents.with_raw_response.list_invitations_for_developer()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentListInvitationsForDeveloperResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_invitations_for_developer(self, client: Natural) -> None:
        with client.agents.with_streaming_response.list_invitations_for_developer() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentListInvitationsForDeveloperResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_remove(self, client: Natural) -> None:
        agent = client.agents.remove(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(AgentRemoveResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_remove_with_all_params(self, client: Natural) -> None:
        agent = client.agents.remove(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentRemoveResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_remove(self, client: Natural) -> None:
        response = client.agents.with_raw_response.remove(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentRemoveResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_remove(self, client: Natural) -> None:
        with client.agents.with_streaming_response.remove(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentRemoveResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_remove(self, client: Natural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.with_raw_response.remove(
                agent_id="",
                idempotency_key="Idempotency-Key",
            )


class TestAsyncAgents:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.create(
            name="x",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(AgentCreateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.create(
            name="x",
            idempotency_key="Idempotency-Key",
            description="description",
            limits={"per_transaction": 1},
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentCreateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncNatural) -> None:
        response = await async_client.agents.with_raw_response.create(
            name="x",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentCreateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncNatural) -> None:
        async with async_client.agents.with_streaming_response.create(
            name="x",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentCreateResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.update(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(AgentUpdateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.update(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            description="description",
            limits={"per_transaction": 1},
            name="name",
            status="ACTIVE",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentUpdateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncNatural) -> None:
        response = await async_client.agents.with_raw_response.update(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentUpdateResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncNatural) -> None:
        async with async_client.agents.with_streaming_response.update(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentUpdateResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncNatural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.update(
                agent_id="",
                idempotency_key="Idempotency-Key",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.list()
        assert_matches_type(AgentListResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.list(
            cursor="cursor",
            limit=1,
            status="ACTIVE",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentListResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNatural) -> None:
        response = await async_client.agents.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentListResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNatural) -> None:
        async with async_client.agents.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentListResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_invitations(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.create_invitations(
            agents=[
                {
                    "agent_id": "agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
                    "permissions": ["string"],
                }
            ],
            customer_email="dev@stainless.com",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(AgentCreateInvitationsResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_invitations_with_all_params(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.create_invitations(
            agents=[
                {
                    "agent_id": "agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
                    "permissions": ["string"],
                    "limits": {"per_transaction": 1},
                }
            ],
            customer_email="dev@stainless.com",
            idempotency_key="Idempotency-Key",
            expires_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentCreateInvitationsResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create_invitations(self, async_client: AsyncNatural) -> None:
        response = await async_client.agents.with_raw_response.create_invitations(
            agents=[
                {
                    "agent_id": "agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
                    "permissions": ["string"],
                }
            ],
            customer_email="dev@stainless.com",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentCreateInvitationsResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create_invitations(self, async_client: AsyncNatural) -> None:
        async with async_client.agents.with_streaming_response.create_invitations(
            agents=[
                {
                    "agent_id": "agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
                    "permissions": ["string"],
                }
            ],
            customer_email="dev@stainless.com",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentCreateInvitationsResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.get(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_with_all_params(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.get(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get(self, async_client: AsyncNatural) -> None:
        response = await async_client.agents.with_raw_response.get(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get(self, async_client: AsyncNatural) -> None:
        async with async_client.agents.with_streaming_response.get(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentGetResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_get(self, async_client: AsyncNatural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.get(
                agent_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_invitations_for_developer(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.list_invitations_for_developer()
        assert_matches_type(AgentListInvitationsForDeveloperResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_invitations_for_developer_with_all_params(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.list_invitations_for_developer(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            cursor="cursor",
            customer_email="dev@stainless.com",
            limit=1,
            status=["PENDING"],
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentListInvitationsForDeveloperResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_invitations_for_developer(self, async_client: AsyncNatural) -> None:
        response = await async_client.agents.with_raw_response.list_invitations_for_developer()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentListInvitationsForDeveloperResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_invitations_for_developer(self, async_client: AsyncNatural) -> None:
        async with async_client.agents.with_streaming_response.list_invitations_for_developer() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentListInvitationsForDeveloperResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_remove(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.remove(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(AgentRemoveResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_remove_with_all_params(self, async_client: AsyncNatural) -> None:
        agent = await async_client.agents.remove(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(AgentRemoveResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_remove(self, async_client: AsyncNatural) -> None:
        response = await async_client.agents.with_raw_response.remove(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentRemoveResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_remove(self, async_client: AsyncNatural) -> None:
        async with async_client.agents.with_streaming_response.remove(
            agent_id="agt_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentRemoveResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_remove(self, async_client: AsyncNatural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.with_raw_response.remove(
                agent_id="",
                idempotency_key="Idempotency-Key",
            )
