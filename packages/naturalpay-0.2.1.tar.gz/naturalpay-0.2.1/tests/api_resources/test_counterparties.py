# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import CounterpartyListResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestCounterparties:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Natural) -> None:
        counterparty = client.counterparties.list()
        assert_matches_type(CounterpartyListResponse, counterparty, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Natural) -> None:
        counterparty = client.counterparties.list(
            cursor="cursor",
            direction="sent",
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(CounterpartyListResponse, counterparty, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Natural) -> None:
        response = client.counterparties.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        counterparty = response.parse()
        assert_matches_type(CounterpartyListResponse, counterparty, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Natural) -> None:
        with client.counterparties.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            counterparty = response.parse()
            assert_matches_type(CounterpartyListResponse, counterparty, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncCounterparties:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNatural) -> None:
        counterparty = await async_client.counterparties.list()
        assert_matches_type(CounterpartyListResponse, counterparty, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncNatural) -> None:
        counterparty = await async_client.counterparties.list(
            cursor="cursor",
            direction="sent",
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(CounterpartyListResponse, counterparty, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNatural) -> None:
        response = await async_client.counterparties.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        counterparty = await response.parse()
        assert_matches_type(CounterpartyListResponse, counterparty, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNatural) -> None:
        async with async_client.counterparties.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            counterparty = await response.parse()
            assert_matches_type(CounterpartyListResponse, counterparty, path=["response"])

        assert cast(Any, response.is_closed) is True
