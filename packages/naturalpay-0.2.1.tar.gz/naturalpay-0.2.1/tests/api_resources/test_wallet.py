# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import (
    WalletGetBalanceResponse,
    WalletInitiateDepositResponse,
    WalletInitiateWithdrawalResponse,
    WalletGetDepositInstructionsResponse,
    WalletListPaymentInstrumentsResponse,
    WalletRemovePaymentInstrumentResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestWallet:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_balance(self, client: Natural) -> None:
        wallet = client.wallet.get_balance()
        assert_matches_type(WalletGetBalanceResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_balance_with_all_params(self, client: Natural) -> None:
        wallet = client.wallet.get_balance(
            party_id="partyId",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletGetBalanceResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get_balance(self, client: Natural) -> None:
        response = client.wallet.with_raw_response.get_balance()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = response.parse()
        assert_matches_type(WalletGetBalanceResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get_balance(self, client: Natural) -> None:
        with client.wallet.with_streaming_response.get_balance() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = response.parse()
            assert_matches_type(WalletGetBalanceResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_deposit_instructions(self, client: Natural) -> None:
        wallet = client.wallet.get_deposit_instructions()
        assert_matches_type(WalletGetDepositInstructionsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_deposit_instructions_with_all_params(self, client: Natural) -> None:
        wallet = client.wallet.get_deposit_instructions(
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletGetDepositInstructionsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get_deposit_instructions(self, client: Natural) -> None:
        response = client.wallet.with_raw_response.get_deposit_instructions()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = response.parse()
        assert_matches_type(WalletGetDepositInstructionsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get_deposit_instructions(self, client: Natural) -> None:
        with client.wallet.with_streaming_response.get_deposit_instructions() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = response.parse()
            assert_matches_type(WalletGetDepositInstructionsResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_initiate_deposit(self, client: Natural) -> None:
        wallet = client.wallet.initiate_deposit(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(WalletInitiateDepositResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_initiate_deposit_with_all_params(self, client: Natural) -> None:
        wallet = client.wallet.initiate_deposit(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="currency",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletInitiateDepositResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_initiate_deposit(self, client: Natural) -> None:
        response = client.wallet.with_raw_response.initiate_deposit(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = response.parse()
        assert_matches_type(WalletInitiateDepositResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_initiate_deposit(self, client: Natural) -> None:
        with client.wallet.with_streaming_response.initiate_deposit(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = response.parse()
            assert_matches_type(WalletInitiateDepositResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_initiate_withdrawal(self, client: Natural) -> None:
        wallet = client.wallet.initiate_withdrawal(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(WalletInitiateWithdrawalResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_initiate_withdrawal_with_all_params(self, client: Natural) -> None:
        wallet = client.wallet.initiate_withdrawal(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="currency",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletInitiateWithdrawalResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_initiate_withdrawal(self, client: Natural) -> None:
        response = client.wallet.with_raw_response.initiate_withdrawal(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = response.parse()
        assert_matches_type(WalletInitiateWithdrawalResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_initiate_withdrawal(self, client: Natural) -> None:
        with client.wallet.with_streaming_response.initiate_withdrawal(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = response.parse()
            assert_matches_type(WalletInitiateWithdrawalResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_payment_instruments(self, client: Natural) -> None:
        wallet = client.wallet.list_payment_instruments()
        assert_matches_type(WalletListPaymentInstrumentsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_payment_instruments_with_all_params(self, client: Natural) -> None:
        wallet = client.wallet.list_payment_instruments(
            cursor="cursor",
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletListPaymentInstrumentsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_payment_instruments(self, client: Natural) -> None:
        response = client.wallet.with_raw_response.list_payment_instruments()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = response.parse()
        assert_matches_type(WalletListPaymentInstrumentsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_payment_instruments(self, client: Natural) -> None:
        with client.wallet.with_streaming_response.list_payment_instruments() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = response.parse()
            assert_matches_type(WalletListPaymentInstrumentsResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_remove_payment_instrument(self, client: Natural) -> None:
        wallet = client.wallet.remove_payment_instrument(
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(WalletRemovePaymentInstrumentResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_remove_payment_instrument_with_all_params(self, client: Natural) -> None:
        wallet = client.wallet.remove_payment_instrument(
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletRemovePaymentInstrumentResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_remove_payment_instrument(self, client: Natural) -> None:
        response = client.wallet.with_raw_response.remove_payment_instrument(
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = response.parse()
        assert_matches_type(WalletRemovePaymentInstrumentResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_remove_payment_instrument(self, client: Natural) -> None:
        with client.wallet.with_streaming_response.remove_payment_instrument(
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = response.parse()
            assert_matches_type(WalletRemovePaymentInstrumentResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_remove_payment_instrument(self, client: Natural) -> None:
        with pytest.raises(
            ValueError, match=r"Expected a non-empty value for `external_funding_source_id` but received ''"
        ):
            client.wallet.with_raw_response.remove_payment_instrument(
                external_funding_source_id="",
            )


class TestAsyncWallet:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_balance(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.get_balance()
        assert_matches_type(WalletGetBalanceResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_balance_with_all_params(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.get_balance(
            party_id="partyId",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletGetBalanceResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get_balance(self, async_client: AsyncNatural) -> None:
        response = await async_client.wallet.with_raw_response.get_balance()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = await response.parse()
        assert_matches_type(WalletGetBalanceResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get_balance(self, async_client: AsyncNatural) -> None:
        async with async_client.wallet.with_streaming_response.get_balance() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = await response.parse()
            assert_matches_type(WalletGetBalanceResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_deposit_instructions(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.get_deposit_instructions()
        assert_matches_type(WalletGetDepositInstructionsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_deposit_instructions_with_all_params(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.get_deposit_instructions(
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletGetDepositInstructionsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get_deposit_instructions(self, async_client: AsyncNatural) -> None:
        response = await async_client.wallet.with_raw_response.get_deposit_instructions()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = await response.parse()
        assert_matches_type(WalletGetDepositInstructionsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get_deposit_instructions(self, async_client: AsyncNatural) -> None:
        async with async_client.wallet.with_streaming_response.get_deposit_instructions() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = await response.parse()
            assert_matches_type(WalletGetDepositInstructionsResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_initiate_deposit(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.initiate_deposit(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(WalletInitiateDepositResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_initiate_deposit_with_all_params(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.initiate_deposit(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="currency",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletInitiateDepositResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_initiate_deposit(self, async_client: AsyncNatural) -> None:
        response = await async_client.wallet.with_raw_response.initiate_deposit(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = await response.parse()
        assert_matches_type(WalletInitiateDepositResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_initiate_deposit(self, async_client: AsyncNatural) -> None:
        async with async_client.wallet.with_streaming_response.initiate_deposit(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = await response.parse()
            assert_matches_type(WalletInitiateDepositResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_initiate_withdrawal(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.initiate_withdrawal(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(WalletInitiateWithdrawalResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_initiate_withdrawal_with_all_params(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.initiate_withdrawal(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="currency",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletInitiateWithdrawalResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_initiate_withdrawal(self, async_client: AsyncNatural) -> None:
        response = await async_client.wallet.with_raw_response.initiate_withdrawal(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = await response.parse()
        assert_matches_type(WalletInitiateWithdrawalResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_initiate_withdrawal(self, async_client: AsyncNatural) -> None:
        async with async_client.wallet.with_streaming_response.initiate_withdrawal(
            amount=1,
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = await response.parse()
            assert_matches_type(WalletInitiateWithdrawalResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_payment_instruments(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.list_payment_instruments()
        assert_matches_type(WalletListPaymentInstrumentsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_payment_instruments_with_all_params(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.list_payment_instruments(
            cursor="cursor",
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletListPaymentInstrumentsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_payment_instruments(self, async_client: AsyncNatural) -> None:
        response = await async_client.wallet.with_raw_response.list_payment_instruments()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = await response.parse()
        assert_matches_type(WalletListPaymentInstrumentsResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_payment_instruments(self, async_client: AsyncNatural) -> None:
        async with async_client.wallet.with_streaming_response.list_payment_instruments() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = await response.parse()
            assert_matches_type(WalletListPaymentInstrumentsResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_remove_payment_instrument(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.remove_payment_instrument(
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(WalletRemovePaymentInstrumentResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_remove_payment_instrument_with_all_params(self, async_client: AsyncNatural) -> None:
        wallet = await async_client.wallet.remove_payment_instrument(
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(WalletRemovePaymentInstrumentResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_remove_payment_instrument(self, async_client: AsyncNatural) -> None:
        response = await async_client.wallet.with_raw_response.remove_payment_instrument(
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wallet = await response.parse()
        assert_matches_type(WalletRemovePaymentInstrumentResponse, wallet, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_remove_payment_instrument(self, async_client: AsyncNatural) -> None:
        async with async_client.wallet.with_streaming_response.remove_payment_instrument(
            external_funding_source_id="efs_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wallet = await response.parse()
            assert_matches_type(WalletRemovePaymentInstrumentResponse, wallet, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_remove_payment_instrument(self, async_client: AsyncNatural) -> None:
        with pytest.raises(
            ValueError, match=r"Expected a non-empty value for `external_funding_source_id` but received ''"
        ):
            await async_client.wallet.with_raw_response.remove_payment_instrument(
                external_funding_source_id="",
            )
