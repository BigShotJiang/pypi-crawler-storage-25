# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import (
    PartyGetResponse,
    PartyUpdateResponse,
    PartyListMembersResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestParties:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Natural) -> None:
        party = client.parties.update()
        assert_matches_type(PartyUpdateResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Natural) -> None:
        party = client.parties.update(
            display_name="x",
            persona="INDIVIDUAL",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PartyUpdateResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Natural) -> None:
        response = client.parties.with_raw_response.update()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        party = response.parse()
        assert_matches_type(PartyUpdateResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Natural) -> None:
        with client.parties.with_streaming_response.update() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            party = response.parse()
            assert_matches_type(PartyUpdateResponse, party, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get(self, client: Natural) -> None:
        party = client.parties.get()
        assert_matches_type(PartyGetResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_with_all_params(self, client: Natural) -> None:
        party = client.parties.get(
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PartyGetResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get(self, client: Natural) -> None:
        response = client.parties.with_raw_response.get()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        party = response.parse()
        assert_matches_type(PartyGetResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get(self, client: Natural) -> None:
        with client.parties.with_streaming_response.get() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            party = response.parse()
            assert_matches_type(PartyGetResponse, party, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_members(self, client: Natural) -> None:
        party = client.parties.list_members()
        assert_matches_type(PartyListMembersResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_members_with_all_params(self, client: Natural) -> None:
        party = client.parties.list_members(
            cursor="cursor",
            include_invitations=True,
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PartyListMembersResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_members(self, client: Natural) -> None:
        response = client.parties.with_raw_response.list_members()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        party = response.parse()
        assert_matches_type(PartyListMembersResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_members(self, client: Natural) -> None:
        with client.parties.with_streaming_response.list_members() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            party = response.parse()
            assert_matches_type(PartyListMembersResponse, party, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncParties:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncNatural) -> None:
        party = await async_client.parties.update()
        assert_matches_type(PartyUpdateResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncNatural) -> None:
        party = await async_client.parties.update(
            display_name="x",
            persona="INDIVIDUAL",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PartyUpdateResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncNatural) -> None:
        response = await async_client.parties.with_raw_response.update()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        party = await response.parse()
        assert_matches_type(PartyUpdateResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncNatural) -> None:
        async with async_client.parties.with_streaming_response.update() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            party = await response.parse()
            assert_matches_type(PartyUpdateResponse, party, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get(self, async_client: AsyncNatural) -> None:
        party = await async_client.parties.get()
        assert_matches_type(PartyGetResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_with_all_params(self, async_client: AsyncNatural) -> None:
        party = await async_client.parties.get(
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PartyGetResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get(self, async_client: AsyncNatural) -> None:
        response = await async_client.parties.with_raw_response.get()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        party = await response.parse()
        assert_matches_type(PartyGetResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get(self, async_client: AsyncNatural) -> None:
        async with async_client.parties.with_streaming_response.get() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            party = await response.parse()
            assert_matches_type(PartyGetResponse, party, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_members(self, async_client: AsyncNatural) -> None:
        party = await async_client.parties.list_members()
        assert_matches_type(PartyListMembersResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_members_with_all_params(self, async_client: AsyncNatural) -> None:
        party = await async_client.parties.list_members(
            cursor="cursor",
            include_invitations=True,
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PartyListMembersResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_members(self, async_client: AsyncNatural) -> None:
        response = await async_client.parties.with_raw_response.list_members()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        party = await response.parse()
        assert_matches_type(PartyListMembersResponse, party, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_members(self, async_client: AsyncNatural) -> None:
        async with async_client.parties.with_streaming_response.list_members() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            party = await response.parse()
            assert_matches_type(PartyListMembersResponse, party, path=["response"])

        assert cast(Any, response.is_closed) is True
