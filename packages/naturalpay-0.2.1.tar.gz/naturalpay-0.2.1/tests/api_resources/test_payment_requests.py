# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import (
    PaymentRequestGetResponse,
    PaymentRequestListResponse,
    PaymentRequestCreateResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPaymentRequests:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Natural) -> None:
        payment_request = client.payment_requests.create(
            amount=1,
            payer={
                "kind": "email",
                "value": "dev@stainless.com",
            },
            wallet_id="wal_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(PaymentRequestCreateResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Natural) -> None:
        payment_request = client.payment_requests.create(
            amount=1,
            payer={
                "kind": "email",
                "value": "dev@stainless.com",
            },
            wallet_id="wal_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="USD",
            customer_party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            description="description",
            payer_name="payerName",
            send_link={"channel": "EMAIL"},
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PaymentRequestCreateResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Natural) -> None:
        response = client.payment_requests.with_raw_response.create(
            amount=1,
            payer={
                "kind": "email",
                "value": "dev@stainless.com",
            },
            wallet_id="wal_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment_request = response.parse()
        assert_matches_type(PaymentRequestCreateResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Natural) -> None:
        with client.payment_requests.with_streaming_response.create(
            amount=1,
            payer={
                "kind": "email",
                "value": "dev@stainless.com",
            },
            wallet_id="wal_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment_request = response.parse()
            assert_matches_type(PaymentRequestCreateResponse, payment_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Natural) -> None:
        payment_request = client.payment_requests.list()
        assert_matches_type(PaymentRequestListResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Natural) -> None:
        payment_request = client.payment_requests.list(
            cursor="cursor",
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PaymentRequestListResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Natural) -> None:
        response = client.payment_requests.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment_request = response.parse()
        assert_matches_type(PaymentRequestListResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Natural) -> None:
        with client.payment_requests.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment_request = response.parse()
            assert_matches_type(PaymentRequestListResponse, payment_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get(self, client: Natural) -> None:
        payment_request = client.payment_requests.get(
            payment_request_id="prq_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(PaymentRequestGetResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_with_all_params(self, client: Natural) -> None:
        payment_request = client.payment_requests.get(
            payment_request_id="prq_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PaymentRequestGetResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get(self, client: Natural) -> None:
        response = client.payment_requests.with_raw_response.get(
            payment_request_id="prq_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment_request = response.parse()
        assert_matches_type(PaymentRequestGetResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get(self, client: Natural) -> None:
        with client.payment_requests.with_streaming_response.get(
            payment_request_id="prq_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment_request = response.parse()
            assert_matches_type(PaymentRequestGetResponse, payment_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_get(self, client: Natural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payment_request_id` but received ''"):
            client.payment_requests.with_raw_response.get(
                payment_request_id="",
            )


class TestAsyncPaymentRequests:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncNatural) -> None:
        payment_request = await async_client.payment_requests.create(
            amount=1,
            payer={
                "kind": "email",
                "value": "dev@stainless.com",
            },
            wallet_id="wal_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(PaymentRequestCreateResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncNatural) -> None:
        payment_request = await async_client.payment_requests.create(
            amount=1,
            payer={
                "kind": "email",
                "value": "dev@stainless.com",
            },
            wallet_id="wal_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="USD",
            customer_party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            description="description",
            payer_name="payerName",
            send_link={"channel": "EMAIL"},
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PaymentRequestCreateResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncNatural) -> None:
        response = await async_client.payment_requests.with_raw_response.create(
            amount=1,
            payer={
                "kind": "email",
                "value": "dev@stainless.com",
            },
            wallet_id="wal_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment_request = await response.parse()
        assert_matches_type(PaymentRequestCreateResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncNatural) -> None:
        async with async_client.payment_requests.with_streaming_response.create(
            amount=1,
            payer={
                "kind": "email",
                "value": "dev@stainless.com",
            },
            wallet_id="wal_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment_request = await response.parse()
            assert_matches_type(PaymentRequestCreateResponse, payment_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNatural) -> None:
        payment_request = await async_client.payment_requests.list()
        assert_matches_type(PaymentRequestListResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncNatural) -> None:
        payment_request = await async_client.payment_requests.list(
            cursor="cursor",
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PaymentRequestListResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNatural) -> None:
        response = await async_client.payment_requests.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment_request = await response.parse()
        assert_matches_type(PaymentRequestListResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNatural) -> None:
        async with async_client.payment_requests.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment_request = await response.parse()
            assert_matches_type(PaymentRequestListResponse, payment_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get(self, async_client: AsyncNatural) -> None:
        payment_request = await async_client.payment_requests.get(
            payment_request_id="prq_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(PaymentRequestGetResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_with_all_params(self, async_client: AsyncNatural) -> None:
        payment_request = await async_client.payment_requests.get(
            payment_request_id="prq_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PaymentRequestGetResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get(self, async_client: AsyncNatural) -> None:
        response = await async_client.payment_requests.with_raw_response.get(
            payment_request_id="prq_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment_request = await response.parse()
        assert_matches_type(PaymentRequestGetResponse, payment_request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get(self, async_client: AsyncNatural) -> None:
        async with async_client.payment_requests.with_streaming_response.get(
            payment_request_id="prq_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment_request = await response.parse()
            assert_matches_type(PaymentRequestGetResponse, payment_request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_get(self, async_client: AsyncNatural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payment_request_id` but received ''"):
            await async_client.payment_requests.with_raw_response.get(
                payment_request_id="",
            )
