# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import PaymentCreateResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPayments:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Natural) -> None:
        payment = client.payments.create(
            amount=1,
            counterparty="counterparty",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Natural) -> None:
        payment = client.payments.create(
            amount=1,
            counterparty="counterparty",
            idempotency_key="Idempotency-Key",
            currency="USD",
            customer_party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Natural) -> None:
        response = client.payments.with_raw_response.create(
            amount=1,
            counterparty="counterparty",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Natural) -> None:
        with client.payments.with_streaming_response.create(
            amount=1,
            counterparty="counterparty",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentCreateResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncPayments:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncNatural) -> None:
        payment = await async_client.payments.create(
            amount=1,
            counterparty="counterparty",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncNatural) -> None:
        payment = await async_client.payments.create(
            amount=1,
            counterparty="counterparty",
            idempotency_key="Idempotency-Key",
            currency="USD",
            customer_party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncNatural) -> None:
        response = await async_client.payments.with_raw_response.create(
            amount=1,
            counterparty="counterparty",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncNatural) -> None:
        async with async_client.payments.with_streaming_response.create(
            amount=1,
            counterparty="counterparty",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentCreateResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True
