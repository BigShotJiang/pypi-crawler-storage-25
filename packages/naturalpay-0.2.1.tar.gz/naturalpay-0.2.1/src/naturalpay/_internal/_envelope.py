from __future__ import annotations

from typing import Any, cast

from .._types import Body


def is_already_enveloped(body: object) -> bool:
    if not isinstance(body, dict):
        return False
    body_dict = cast("dict[str, object]", body)
    data = body_dict.get("data")
    if not isinstance(data, dict):
        return False
    return "attributes" in cast("dict[str, object]", data)


def wrap_if_needed(body: Body | None, *, is_json_request: bool) -> Body | None:
    if not is_json_request:
        return body
    if body is None:
        return body
    if isinstance(body, (bytes, bytearray)):
        return body
    if not isinstance(body, dict):
        return body
    body_dict = cast("dict[str, Any]", body)
    if is_already_enveloped(body_dict):
        return body_dict
    return {"data": {"attributes": body_dict}}
