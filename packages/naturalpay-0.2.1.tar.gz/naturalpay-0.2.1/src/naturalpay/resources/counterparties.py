# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import counterparty_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.counterparty_list_response import CounterpartyListResponse

__all__ = ["CounterpartiesResource", "AsyncCounterpartiesResource"]


class CounterpartiesResource(SyncAPIResource):
    """Counterparty management"""

    @cached_property
    def with_raw_response(self) -> CounterpartiesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return CounterpartiesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CounterpartiesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return CounterpartiesResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        direction: Literal["sent", "received"] | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CounterpartyListResponse:
        """Returns one row per counterparty with sent and received aggregates.

        Either side
        may be null when there are no payments in that direction. Pass direction=sent or
        direction=received to scope the list (and its pagination) to one side.

        Args:
          cursor: Cursor for pagination

          direction: Optional filter. When set, only counterparties with activity in that direction
              are returned, and pagination is scoped to that subset. Omit to return every
              counterparty.

          limit: Maximum number of results

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/counterparties",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "direction": direction,
                        "limit": limit,
                    },
                    counterparty_list_params.CounterpartyListParams,
                ),
            ),
            cast_to=CounterpartyListResponse,
        )


class AsyncCounterpartiesResource(AsyncAPIResource):
    """Counterparty management"""

    @cached_property
    def with_raw_response(self) -> AsyncCounterpartiesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncCounterpartiesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCounterpartiesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncCounterpartiesResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        direction: Literal["sent", "received"] | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CounterpartyListResponse:
        """Returns one row per counterparty with sent and received aggregates.

        Either side
        may be null when there are no payments in that direction. Pass direction=sent or
        direction=received to scope the list (and its pagination) to one side.

        Args:
          cursor: Cursor for pagination

          direction: Optional filter. When set, only counterparties with activity in that direction
              are returned, and pagination is scoped to that subset. Omit to return every
              counterparty.

          limit: Maximum number of results

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/counterparties",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "direction": direction,
                        "limit": limit,
                    },
                    counterparty_list_params.CounterpartyListParams,
                ),
            ),
            cast_to=CounterpartyListResponse,
        )


class CounterpartiesResourceWithRawResponse:
    def __init__(self, counterparties: CounterpartiesResource) -> None:
        self._counterparties = counterparties

        self.list = to_raw_response_wrapper(
            counterparties.list,
        )


class AsyncCounterpartiesResourceWithRawResponse:
    def __init__(self, counterparties: AsyncCounterpartiesResource) -> None:
        self._counterparties = counterparties

        self.list = async_to_raw_response_wrapper(
            counterparties.list,
        )


class CounterpartiesResourceWithStreamingResponse:
    def __init__(self, counterparties: CounterpartiesResource) -> None:
        self._counterparties = counterparties

        self.list = to_streamed_response_wrapper(
            counterparties.list,
        )


class AsyncCounterpartiesResourceWithStreamingResponse:
    def __init__(self, counterparties: AsyncCounterpartiesResource) -> None:
        self._counterparties = counterparties

        self.list = async_to_streamed_response_wrapper(
            counterparties.list,
        )
