# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal

import httpx

from ..types import party_update_params, party_list_members_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.party_get_response import PartyGetResponse
from ..types.party_update_response import PartyUpdateResponse
from ..types.party_list_members_response import PartyListMembersResponse

__all__ = ["PartiesResource", "AsyncPartiesResource"]


class PartiesResource(SyncAPIResource):
    """Party and organization management"""

    @cached_property
    def with_raw_response(self) -> PartiesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return PartiesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PartiesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return PartiesResourceWithStreamingResponse(self)

    def update(
        self,
        *,
        display_name: Optional[str] | Omit = omit,
        persona: Literal["INDIVIDUAL", "DEVELOPER"] | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PartyUpdateResponse:
        """
        Update the authenticated caller's party details.

        Args:
          display_name: Updated display name. Pass null to clear; empty string is rejected (use null to
              clear instead).

          persona: Updated party persona: INDIVIDUAL or DEVELOPER. Clearing persona to null is not
              supported.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._put(
            "/parties/me",
            body=maybe_transform(
                {
                    "display_name": display_name,
                    "persona": persona,
                },
                party_update_params.PartyUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PartyUpdateResponse,
        )

    def get(
        self,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PartyGetResponse:
        """
        Retrieve the authenticated caller's party details.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/parties/me",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PartyGetResponse,
        )

    def list_members(
        self,
        *,
        cursor: str | Omit = omit,
        include_invitations: bool | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PartyListMembersResponse:
        """
        List members and pending invitations.

        Args:
          cursor: Cursor for pagination

          include_invitations: Include pending invitations alongside active members. Defaults to false.

          limit: Max items per page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/parties/me/members",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "include_invitations": include_invitations,
                        "limit": limit,
                    },
                    party_list_members_params.PartyListMembersParams,
                ),
            ),
            cast_to=PartyListMembersResponse,
        )


class AsyncPartiesResource(AsyncAPIResource):
    """Party and organization management"""

    @cached_property
    def with_raw_response(self) -> AsyncPartiesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncPartiesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPartiesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncPartiesResourceWithStreamingResponse(self)

    async def update(
        self,
        *,
        display_name: Optional[str] | Omit = omit,
        persona: Literal["INDIVIDUAL", "DEVELOPER"] | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PartyUpdateResponse:
        """
        Update the authenticated caller's party details.

        Args:
          display_name: Updated display name. Pass null to clear; empty string is rejected (use null to
              clear instead).

          persona: Updated party persona: INDIVIDUAL or DEVELOPER. Clearing persona to null is not
              supported.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._put(
            "/parties/me",
            body=await async_maybe_transform(
                {
                    "display_name": display_name,
                    "persona": persona,
                },
                party_update_params.PartyUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PartyUpdateResponse,
        )

    async def get(
        self,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PartyGetResponse:
        """
        Retrieve the authenticated caller's party details.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/parties/me",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PartyGetResponse,
        )

    async def list_members(
        self,
        *,
        cursor: str | Omit = omit,
        include_invitations: bool | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PartyListMembersResponse:
        """
        List members and pending invitations.

        Args:
          cursor: Cursor for pagination

          include_invitations: Include pending invitations alongside active members. Defaults to false.

          limit: Max items per page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/parties/me/members",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "include_invitations": include_invitations,
                        "limit": limit,
                    },
                    party_list_members_params.PartyListMembersParams,
                ),
            ),
            cast_to=PartyListMembersResponse,
        )


class PartiesResourceWithRawResponse:
    def __init__(self, parties: PartiesResource) -> None:
        self._parties = parties

        self.update = to_raw_response_wrapper(
            parties.update,
        )
        self.get = to_raw_response_wrapper(
            parties.get,
        )
        self.list_members = to_raw_response_wrapper(
            parties.list_members,
        )


class AsyncPartiesResourceWithRawResponse:
    def __init__(self, parties: AsyncPartiesResource) -> None:
        self._parties = parties

        self.update = async_to_raw_response_wrapper(
            parties.update,
        )
        self.get = async_to_raw_response_wrapper(
            parties.get,
        )
        self.list_members = async_to_raw_response_wrapper(
            parties.list_members,
        )


class PartiesResourceWithStreamingResponse:
    def __init__(self, parties: PartiesResource) -> None:
        self._parties = parties

        self.update = to_streamed_response_wrapper(
            parties.update,
        )
        self.get = to_streamed_response_wrapper(
            parties.get,
        )
        self.list_members = to_streamed_response_wrapper(
            parties.list_members,
        )


class AsyncPartiesResourceWithStreamingResponse:
    def __init__(self, parties: AsyncPartiesResource) -> None:
        self._parties = parties

        self.update = async_to_streamed_response_wrapper(
            parties.update,
        )
        self.get = async_to_streamed_response_wrapper(
            parties.get,
        )
        self.list_members = async_to_streamed_response_wrapper(
            parties.list_members,
        )
