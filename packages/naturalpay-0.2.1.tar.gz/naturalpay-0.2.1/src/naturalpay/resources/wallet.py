# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import (
    wallet_get_balance_params,
    wallet_initiate_deposit_params,
    wallet_initiate_withdrawal_params,
    wallet_list_payment_instruments_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.wallet_get_balance_response import WalletGetBalanceResponse
from ..types.wallet_initiate_deposit_response import WalletInitiateDepositResponse
from ..types.wallet_initiate_withdrawal_response import WalletInitiateWithdrawalResponse
from ..types.wallet_get_deposit_instructions_response import WalletGetDepositInstructionsResponse
from ..types.wallet_list_payment_instruments_response import WalletListPaymentInstrumentsResponse
from ..types.wallet_remove_payment_instrument_response import WalletRemovePaymentInstrumentResponse

__all__ = ["WalletResource", "AsyncWalletResource"]


class WalletResource(SyncAPIResource):
    """Wallet balance, deposits, withdrawals, and external funding sources"""

    @cached_property
    def with_raw_response(self) -> WalletResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return WalletResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WalletResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return WalletResourceWithStreamingResponse(self)

    def get_balance(
        self,
        *,
        party_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletGetBalanceResponse:
        """
        Get spendable and total wallet ledger balance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/wallet/balance",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"party_id": party_id}, wallet_get_balance_params.WalletGetBalanceParams),
            ),
            cast_to=WalletGetBalanceResponse,
        )

    def get_deposit_instructions(
        self,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletGetDepositInstructionsResponse:
        """
        Get account and routing numbers for ACH deposits.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/wallet/deposit-instructions",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletGetDepositInstructionsResponse,
        )

    def initiate_deposit(
        self,
        *,
        amount: int,
        external_funding_source_id: str,
        idempotency_key: str,
        currency: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletInitiateDepositResponse:
        """
        Initiate a wallet deposit.

        Args:
          amount: Amount in cents

          external_funding_source_id: External funding source ID (efs\\__\\**)

          currency: Currency code

          description: Deposit description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/wallet/deposit",
            body=maybe_transform(
                {
                    "amount": amount,
                    "external_funding_source_id": external_funding_source_id,
                    "currency": currency,
                    "description": description,
                },
                wallet_initiate_deposit_params.WalletInitiateDepositParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletInitiateDepositResponse,
        )

    def initiate_withdrawal(
        self,
        *,
        amount: int,
        external_funding_source_id: str,
        idempotency_key: str,
        currency: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletInitiateWithdrawalResponse:
        """
        Initiate a wallet withdrawal.

        Args:
          amount: Amount in cents

          external_funding_source_id: External funding source ID (efs\\__\\**)

          currency: Currency code

          description: Withdrawal description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/wallet/withdraw",
            body=maybe_transform(
                {
                    "amount": amount,
                    "external_funding_source_id": external_funding_source_id,
                    "currency": currency,
                    "description": description,
                },
                wallet_initiate_withdrawal_params.WalletInitiateWithdrawalParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletInitiateWithdrawalResponse,
        )

    def list_payment_instruments(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletListPaymentInstrumentsResponse:
        """
        List linked external funding sources with cursor pagination.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/wallet/external-funding-sources",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    wallet_list_payment_instruments_params.WalletListPaymentInstrumentsParams,
                ),
            ),
            cast_to=WalletListPaymentInstrumentsResponse,
        )

    def remove_payment_instrument(
        self,
        external_funding_source_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletRemovePaymentInstrumentResponse:
        """
        Remove (unlink) a bank account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not external_funding_source_id:
            raise ValueError(
                f"Expected a non-empty value for `external_funding_source_id` but received {external_funding_source_id!r}"
            )
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._delete(
            path_template(
                "/wallet/external-funding-sources/{external_funding_source_id}",
                external_funding_source_id=external_funding_source_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletRemovePaymentInstrumentResponse,
        )


class AsyncWalletResource(AsyncAPIResource):
    """Wallet balance, deposits, withdrawals, and external funding sources"""

    @cached_property
    def with_raw_response(self) -> AsyncWalletResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncWalletResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWalletResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncWalletResourceWithStreamingResponse(self)

    async def get_balance(
        self,
        *,
        party_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletGetBalanceResponse:
        """
        Get spendable and total wallet ledger balance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/wallet/balance",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"party_id": party_id}, wallet_get_balance_params.WalletGetBalanceParams
                ),
            ),
            cast_to=WalletGetBalanceResponse,
        )

    async def get_deposit_instructions(
        self,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletGetDepositInstructionsResponse:
        """
        Get account and routing numbers for ACH deposits.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/wallet/deposit-instructions",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletGetDepositInstructionsResponse,
        )

    async def initiate_deposit(
        self,
        *,
        amount: int,
        external_funding_source_id: str,
        idempotency_key: str,
        currency: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletInitiateDepositResponse:
        """
        Initiate a wallet deposit.

        Args:
          amount: Amount in cents

          external_funding_source_id: External funding source ID (efs\\__\\**)

          currency: Currency code

          description: Deposit description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/wallet/deposit",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "external_funding_source_id": external_funding_source_id,
                    "currency": currency,
                    "description": description,
                },
                wallet_initiate_deposit_params.WalletInitiateDepositParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletInitiateDepositResponse,
        )

    async def initiate_withdrawal(
        self,
        *,
        amount: int,
        external_funding_source_id: str,
        idempotency_key: str,
        currency: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletInitiateWithdrawalResponse:
        """
        Initiate a wallet withdrawal.

        Args:
          amount: Amount in cents

          external_funding_source_id: External funding source ID (efs\\__\\**)

          currency: Currency code

          description: Withdrawal description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/wallet/withdraw",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "external_funding_source_id": external_funding_source_id,
                    "currency": currency,
                    "description": description,
                },
                wallet_initiate_withdrawal_params.WalletInitiateWithdrawalParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletInitiateWithdrawalResponse,
        )

    async def list_payment_instruments(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletListPaymentInstrumentsResponse:
        """
        List linked external funding sources with cursor pagination.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/wallet/external-funding-sources",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    wallet_list_payment_instruments_params.WalletListPaymentInstrumentsParams,
                ),
            ),
            cast_to=WalletListPaymentInstrumentsResponse,
        )

    async def remove_payment_instrument(
        self,
        external_funding_source_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletRemovePaymentInstrumentResponse:
        """
        Remove (unlink) a bank account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not external_funding_source_id:
            raise ValueError(
                f"Expected a non-empty value for `external_funding_source_id` but received {external_funding_source_id!r}"
            )
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._delete(
            path_template(
                "/wallet/external-funding-sources/{external_funding_source_id}",
                external_funding_source_id=external_funding_source_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletRemovePaymentInstrumentResponse,
        )


class WalletResourceWithRawResponse:
    def __init__(self, wallet: WalletResource) -> None:
        self._wallet = wallet

        self.get_balance = to_raw_response_wrapper(
            wallet.get_balance,
        )
        self.get_deposit_instructions = to_raw_response_wrapper(
            wallet.get_deposit_instructions,
        )
        self.initiate_deposit = to_raw_response_wrapper(
            wallet.initiate_deposit,
        )
        self.initiate_withdrawal = to_raw_response_wrapper(
            wallet.initiate_withdrawal,
        )
        self.list_payment_instruments = to_raw_response_wrapper(
            wallet.list_payment_instruments,
        )
        self.remove_payment_instrument = to_raw_response_wrapper(
            wallet.remove_payment_instrument,
        )


class AsyncWalletResourceWithRawResponse:
    def __init__(self, wallet: AsyncWalletResource) -> None:
        self._wallet = wallet

        self.get_balance = async_to_raw_response_wrapper(
            wallet.get_balance,
        )
        self.get_deposit_instructions = async_to_raw_response_wrapper(
            wallet.get_deposit_instructions,
        )
        self.initiate_deposit = async_to_raw_response_wrapper(
            wallet.initiate_deposit,
        )
        self.initiate_withdrawal = async_to_raw_response_wrapper(
            wallet.initiate_withdrawal,
        )
        self.list_payment_instruments = async_to_raw_response_wrapper(
            wallet.list_payment_instruments,
        )
        self.remove_payment_instrument = async_to_raw_response_wrapper(
            wallet.remove_payment_instrument,
        )


class WalletResourceWithStreamingResponse:
    def __init__(self, wallet: WalletResource) -> None:
        self._wallet = wallet

        self.get_balance = to_streamed_response_wrapper(
            wallet.get_balance,
        )
        self.get_deposit_instructions = to_streamed_response_wrapper(
            wallet.get_deposit_instructions,
        )
        self.initiate_deposit = to_streamed_response_wrapper(
            wallet.initiate_deposit,
        )
        self.initiate_withdrawal = to_streamed_response_wrapper(
            wallet.initiate_withdrawal,
        )
        self.list_payment_instruments = to_streamed_response_wrapper(
            wallet.list_payment_instruments,
        )
        self.remove_payment_instrument = to_streamed_response_wrapper(
            wallet.remove_payment_instrument,
        )


class AsyncWalletResourceWithStreamingResponse:
    def __init__(self, wallet: AsyncWalletResource) -> None:
        self._wallet = wallet

        self.get_balance = async_to_streamed_response_wrapper(
            wallet.get_balance,
        )
        self.get_deposit_instructions = async_to_streamed_response_wrapper(
            wallet.get_deposit_instructions,
        )
        self.initiate_deposit = async_to_streamed_response_wrapper(
            wallet.initiate_deposit,
        )
        self.initiate_withdrawal = async_to_streamed_response_wrapper(
            wallet.initiate_withdrawal,
        )
        self.list_payment_instruments = async_to_streamed_response_wrapper(
            wallet.list_payment_instruments,
        )
        self.remove_payment_instrument = async_to_streamed_response_wrapper(
            wallet.remove_payment_instrument,
        )
