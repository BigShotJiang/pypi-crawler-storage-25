# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import payment_create_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.payment_create_response import PaymentCreateResponse

__all__ = ["PaymentsResource", "AsyncPaymentsResource"]


class PaymentsResource(SyncAPIResource):
    """Payment and transaction operations"""

    @cached_property
    def with_raw_response(self) -> PaymentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return PaymentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PaymentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return PaymentsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        amount: int,
        counterparty: str,
        idempotency_key: str,
        currency: Literal["USD"] | Omit = omit,
        customer_party_id: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentCreateResponse:
        """
        Create a payment with delegation validation and limit enforcement.

        Args:
          amount: Amount in cents

          counterparty: Recipient: party ID (pty\\__\\**), email, or phone

          currency: Currency code

          customer_party_id: Sender party ID (pty\\__\\**). Omit to send from your own wallet; provide for
              delegated payments on behalf of a customer.

          description: Payment description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/payments",
            body=maybe_transform(
                {
                    "amount": amount,
                    "counterparty": counterparty,
                    "currency": currency,
                    "customer_party_id": customer_party_id,
                    "description": description,
                },
                payment_create_params.PaymentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentCreateResponse,
        )


class AsyncPaymentsResource(AsyncAPIResource):
    """Payment and transaction operations"""

    @cached_property
    def with_raw_response(self) -> AsyncPaymentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncPaymentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPaymentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncPaymentsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        amount: int,
        counterparty: str,
        idempotency_key: str,
        currency: Literal["USD"] | Omit = omit,
        customer_party_id: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentCreateResponse:
        """
        Create a payment with delegation validation and limit enforcement.

        Args:
          amount: Amount in cents

          counterparty: Recipient: party ID (pty\\__\\**), email, or phone

          currency: Currency code

          customer_party_id: Sender party ID (pty\\__\\**). Omit to send from your own wallet; provide for
              delegated payments on behalf of a customer.

          description: Payment description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/payments",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "counterparty": counterparty,
                    "currency": currency,
                    "customer_party_id": customer_party_id,
                    "description": description,
                },
                payment_create_params.PaymentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentCreateResponse,
        )


class PaymentsResourceWithRawResponse:
    def __init__(self, payments: PaymentsResource) -> None:
        self._payments = payments

        self.create = to_raw_response_wrapper(
            payments.create,
        )


class AsyncPaymentsResourceWithRawResponse:
    def __init__(self, payments: AsyncPaymentsResource) -> None:
        self._payments = payments

        self.create = async_to_raw_response_wrapper(
            payments.create,
        )


class PaymentsResourceWithStreamingResponse:
    def __init__(self, payments: PaymentsResource) -> None:
        self._payments = payments

        self.create = to_streamed_response_wrapper(
            payments.create,
        )


class AsyncPaymentsResourceWithStreamingResponse:
    def __init__(self, payments: AsyncPaymentsResource) -> None:
        self._payments = payments

        self.create = async_to_streamed_response_wrapper(
            payments.create,
        )
