# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union

import httpx

from ..types import delegation_list_agent_delegations_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.delegation_get_agent_delegation_response import DelegationGetAgentDelegationResponse
from ..types.delegation_list_agent_delegations_response import DelegationListAgentDelegationsResponse

__all__ = ["DelegationsResource", "AsyncDelegationsResource"]


class DelegationsResource(SyncAPIResource):
    """Agent delegation management"""

    @cached_property
    def with_raw_response(self) -> DelegationsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return DelegationsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DelegationsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return DelegationsResourceWithStreamingResponse(self)

    def get_agent_delegation(
        self,
        agent_delegation_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DelegationGetAgentDelegationResponse:
        """
        Get agent delegation

        Args:
          agent_delegation_id: Agent delegation handle (adl_xxx)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_delegation_id:
            raise ValueError(
                f"Expected a non-empty value for `agent_delegation_id` but received {agent_delegation_id!r}"
            )
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            path_template("/agent-delegations/{agent_delegation_id}", agent_delegation_id=agent_delegation_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DelegationGetAgentDelegationResponse,
        )

    def list_agent_delegations(
        self,
        *,
        agent_id: str | Omit = omit,
        cursor: str | Omit = omit,
        delegatee_party_id: str | Omit = omit,
        delegation_id: str | Omit = omit,
        delegator_party_id: str | Omit = omit,
        include_revoked: Union[bool, str] | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DelegationListAgentDelegationsResponse:
        """
        List agent delegations

        Args:
          agent_id: Filter by agent (agt_xxx)

          cursor: Cursor for pagination

          delegatee_party_id: Filter to delegations where caller is the delegated party (developer)

          delegation_id: Filter by parent delegation (dlg_xxx)

          delegator_party_id: Filter to delegations where caller is the delegating party (customer)

          include_revoked: Include revoked delegations

          limit: Max items per page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/agent-delegations",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "agent_id": agent_id,
                        "cursor": cursor,
                        "delegatee_party_id": delegatee_party_id,
                        "delegation_id": delegation_id,
                        "delegator_party_id": delegator_party_id,
                        "include_revoked": include_revoked,
                        "limit": limit,
                    },
                    delegation_list_agent_delegations_params.DelegationListAgentDelegationsParams,
                ),
            ),
            cast_to=DelegationListAgentDelegationsResponse,
        )


class AsyncDelegationsResource(AsyncAPIResource):
    """Agent delegation management"""

    @cached_property
    def with_raw_response(self) -> AsyncDelegationsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncDelegationsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDelegationsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncDelegationsResourceWithStreamingResponse(self)

    async def get_agent_delegation(
        self,
        agent_delegation_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DelegationGetAgentDelegationResponse:
        """
        Get agent delegation

        Args:
          agent_delegation_id: Agent delegation handle (adl_xxx)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not agent_delegation_id:
            raise ValueError(
                f"Expected a non-empty value for `agent_delegation_id` but received {agent_delegation_id!r}"
            )
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            path_template("/agent-delegations/{agent_delegation_id}", agent_delegation_id=agent_delegation_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DelegationGetAgentDelegationResponse,
        )

    async def list_agent_delegations(
        self,
        *,
        agent_id: str | Omit = omit,
        cursor: str | Omit = omit,
        delegatee_party_id: str | Omit = omit,
        delegation_id: str | Omit = omit,
        delegator_party_id: str | Omit = omit,
        include_revoked: Union[bool, str] | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DelegationListAgentDelegationsResponse:
        """
        List agent delegations

        Args:
          agent_id: Filter by agent (agt_xxx)

          cursor: Cursor for pagination

          delegatee_party_id: Filter to delegations where caller is the delegated party (developer)

          delegation_id: Filter by parent delegation (dlg_xxx)

          delegator_party_id: Filter to delegations where caller is the delegating party (customer)

          include_revoked: Include revoked delegations

          limit: Max items per page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/agent-delegations",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "agent_id": agent_id,
                        "cursor": cursor,
                        "delegatee_party_id": delegatee_party_id,
                        "delegation_id": delegation_id,
                        "delegator_party_id": delegator_party_id,
                        "include_revoked": include_revoked,
                        "limit": limit,
                    },
                    delegation_list_agent_delegations_params.DelegationListAgentDelegationsParams,
                ),
            ),
            cast_to=DelegationListAgentDelegationsResponse,
        )


class DelegationsResourceWithRawResponse:
    def __init__(self, delegations: DelegationsResource) -> None:
        self._delegations = delegations

        self.get_agent_delegation = to_raw_response_wrapper(
            delegations.get_agent_delegation,
        )
        self.list_agent_delegations = to_raw_response_wrapper(
            delegations.list_agent_delegations,
        )


class AsyncDelegationsResourceWithRawResponse:
    def __init__(self, delegations: AsyncDelegationsResource) -> None:
        self._delegations = delegations

        self.get_agent_delegation = async_to_raw_response_wrapper(
            delegations.get_agent_delegation,
        )
        self.list_agent_delegations = async_to_raw_response_wrapper(
            delegations.list_agent_delegations,
        )


class DelegationsResourceWithStreamingResponse:
    def __init__(self, delegations: DelegationsResource) -> None:
        self._delegations = delegations

        self.get_agent_delegation = to_streamed_response_wrapper(
            delegations.get_agent_delegation,
        )
        self.list_agent_delegations = to_streamed_response_wrapper(
            delegations.list_agent_delegations,
        )


class AsyncDelegationsResourceWithStreamingResponse:
    def __init__(self, delegations: AsyncDelegationsResource) -> None:
        self._delegations = delegations

        self.get_agent_delegation = async_to_streamed_response_wrapper(
            delegations.get_agent_delegation,
        )
        self.list_agent_delegations = async_to_streamed_response_wrapper(
            delegations.list_agent_delegations,
        )
