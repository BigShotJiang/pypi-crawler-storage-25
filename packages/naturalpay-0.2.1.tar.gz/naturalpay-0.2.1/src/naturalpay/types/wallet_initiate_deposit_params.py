# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["WalletInitiateDepositParams"]


class WalletInitiateDepositParams(TypedDict, total=False):
    amount: Required[int]
    """Amount in cents"""

    external_funding_source_id: Required[Annotated[str, PropertyInfo(alias="externalFundingSourceId")]]
    """External funding source ID (efs\\__\\**)"""

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    currency: str
    """Currency code"""

    description: str
    """Deposit description"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
