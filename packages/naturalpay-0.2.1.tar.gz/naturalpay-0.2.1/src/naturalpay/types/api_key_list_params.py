# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["APIKeyListParams"]


class APIKeyListParams(TypedDict, total=False):
    cursor: str
    """Cursor for pagination"""

    limit: int
    """Max items per page"""

    status: Literal["ACTIVE", "REVOKED"]
    """Filter by status (ACTIVE or REVOKED)"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
