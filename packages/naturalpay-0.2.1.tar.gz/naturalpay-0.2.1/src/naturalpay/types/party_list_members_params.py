# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PartyListMembersParams"]


class PartyListMembersParams(TypedDict, total=False):
    cursor: str
    """Cursor for pagination"""

    include_invitations: Annotated[bool, PropertyInfo(alias="includeInvitations")]
    """Include pending invitations alongside active members. Defaults to false."""

    limit: int
    """Max items per page"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
