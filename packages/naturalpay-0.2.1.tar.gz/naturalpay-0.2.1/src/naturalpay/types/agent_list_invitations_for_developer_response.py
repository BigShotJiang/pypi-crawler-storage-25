# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "AgentListInvitationsForDeveloperResponse",
    "Data",
    "DataAttributes",
    "DataAttributesLimits",
    "DataRelationships",
    "DataRelationshipsAgent",
    "DataRelationshipsAgentData",
    "DataRelationshipsAgentDelegation",
    "DataRelationshipsAgentDelegationData",
    "DataRelationshipsCustomerParty",
    "DataRelationshipsCustomerPartyData",
    "DataRelationshipsDeveloperParty",
    "DataRelationshipsDeveloperPartyData",
    "Meta",
    "MetaPagination",
]


class DataAttributesLimits(BaseModel):
    """Per-agent transaction limits"""

    per_transaction: Optional[int] = FieldInfo(alias="perTransaction", default=None)
    """Per-transaction cap, integer cents (USD)."""


class DataAttributes(BaseModel):
    """Resource attributes"""

    accepted_at: Optional[str] = FieldInfo(alias="acceptedAt", default=None)
    """When this invitation was accepted"""

    agent_name: str = FieldInfo(alias="agentName")
    """Display name of the agent being delegated"""

    cancel_reason: Optional[Literal["AGENT_RETIRED", "DEVELOPER_RETIRED"]] = FieldInfo(
        alias="cancelReason", default=None
    )
    """Why the invitation was cancelled"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this invitation was created"""

    declined_at: Optional[str] = FieldInfo(alias="declinedAt", default=None)
    """When this invitation was declined"""

    developer_name: str = FieldInfo(alias="developerName")
    """Display name of the developer party"""

    effective_status: Literal["PENDING", "ACCEPTED", "DECLINED", "EXPIRED", "CANCELLED"] = FieldInfo(
        alias="effectiveStatus"
    )
    """Status after applying expiry and cancel-reason overlays"""

    email: str
    """Customer email the invitation was sent to"""

    expires_at: str = FieldInfo(alias="expiresAt")
    """When this invitation expires"""

    limits: Optional[DataAttributesLimits] = None
    """Per-agent transaction limits"""

    permissions: List[str]
    """Permissions the agent will hold on accept"""

    status: Literal["PENDING", "ACCEPTED", "DECLINED", "EXPIRED", "CANCELLED"]
    """Raw persisted status"""

    updated_at: str = FieldInfo(alias="updatedAt")
    """When this invitation was last updated"""


class DataRelationshipsAgentData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsAgent(BaseModel):
    """Agent being delegated"""

    data: DataRelationshipsAgentData
    """Related resource identifier"""


class DataRelationshipsAgentDelegationData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsAgentDelegation(BaseModel):
    """
    Resulting agent delegation once accepted; currently null on public create/list responses
    """

    data: Optional[DataRelationshipsAgentDelegationData] = None
    """Related resource identifier"""


class DataRelationshipsCustomerPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsCustomerParty(BaseModel):
    """Customer party the invitation was accepted on (null until accept)"""

    data: Optional[DataRelationshipsCustomerPartyData] = None
    """Related resource identifier"""


class DataRelationshipsDeveloperPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsDeveloperParty(BaseModel):
    """Developer party that issued the invitation"""

    data: DataRelationshipsDeveloperPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Related resource identifiers"""

    agent: DataRelationshipsAgent
    """Agent being delegated"""

    agent_delegation: DataRelationshipsAgentDelegation = FieldInfo(alias="agentDelegation")
    """
    Resulting agent delegation once accepted; currently null on public create/list
    responses
    """

    customer_party: DataRelationshipsCustomerParty = FieldInfo(alias="customerParty")
    """Customer party the invitation was accepted on (null until accept)"""

    developer_party: DataRelationshipsDeveloperParty = FieldInfo(alias="developerParty")
    """Developer party that issued the invitation"""


class Data(BaseModel):
    id: str
    """Invitation ID (adi\\__\\**)"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Related resource identifiers"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class AgentListInvitationsForDeveloperResponse(BaseModel):
    data: List[Data]

    meta: Meta
