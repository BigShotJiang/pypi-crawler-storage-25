# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "AgentUpdateResponse",
    "Data",
    "DataAttributes",
    "DataAttributesLimits",
    "DataAttributesObservability",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
]


class DataAttributesLimits(BaseModel):
    """Per-transaction spend cap for actions this agent initiates on its owner's party.

    null = no limit. Stored as Policy(scope=Agent(id)) in the policy service.
    """

    per_transaction: Optional[int] = FieldInfo(alias="perTransaction", default=None)
    """Positive per-transaction limit in cents. null means no per-payment limit."""


class DataAttributesObservability(BaseModel):
    """Observability stats (null when unavailable)"""

    error_count: float = FieldInfo(alias="errorCount")
    """Errors in last 24h"""

    last_active_at: Optional[str] = FieldInfo(alias="lastActiveAt", default=None)
    """Last activity timestamp"""

    request_count: float = FieldInfo(alias="requestCount")
    """Requests in last 24h"""


class DataAttributes(BaseModel):
    """Resource attributes"""

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)
    """When this agent was created"""

    created_by: Optional[str] = FieldInfo(alias="createdBy", default=None)
    """User who created this agent (usr\\__\\**)"""

    description: Optional[str] = None
    """Agent description"""

    limits: Optional[DataAttributesLimits] = None
    """Per-transaction spend cap for actions this agent initiates on its owner's party.

    null = no limit. Stored as Policy(scope=Agent(id)) in the policy service.
    """

    name: str
    """Agent display name"""

    observability: Optional[DataAttributesObservability] = None
    """Observability stats (null when unavailable)"""

    status: Literal["ACTIVE", "REVOKED"]
    """Agent status"""

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)
    """When this agent was last updated"""

    updated_by: Optional[str] = FieldInfo(alias="updatedBy", default=None)
    """User who last updated this agent (usr\\__\\**)"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the agent"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the agent"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class AgentUpdateResponse(BaseModel):
    data: Data
