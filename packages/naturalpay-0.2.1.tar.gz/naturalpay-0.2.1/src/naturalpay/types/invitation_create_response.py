# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["InvitationCreateResponse", "Data", "DataAttributes", "Meta", "MetaFailed"]


class DataAttributes(BaseModel):
    """Resource attributes"""

    accepted_at: Optional[str] = FieldInfo(alias="acceptedAt", default=None)
    """When this invitation was accepted"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this invitation was created"""

    email: str
    """Invitee email address"""

    expires_at: str = FieldInfo(alias="expiresAt")
    """When this invitation expires"""

    role: Literal["OWNER", "ADMIN", "MEMBER", "VIEWER"]
    """Role assigned on acceptance"""

    status: Literal["PENDING", "ACCEPTED", "REVOKED"]
    """Invitation status"""


class Data(BaseModel):
    id: str
    """Invitation ID (inv_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class MetaFailed(BaseModel):
    """Failed invitation result"""

    email: str
    """Email address that was invited"""

    error: str
    """Error message for failed invitation"""


class Meta(BaseModel):
    """Batch invitation metadata"""

    failed: List[MetaFailed]
    """Failed invitation attempts with error details"""


class InvitationCreateResponse(BaseModel):
    data: List[Data]
    """Successfully created invitation resources"""

    meta: Meta
    """Batch invitation metadata"""
