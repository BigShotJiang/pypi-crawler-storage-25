# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["InvitationCreateParams", "Invitation"]


class InvitationCreateParams(TypedDict, total=False):
    invitations: Required[Iterable[Invitation]]
    """List of invitations to create (max 100)"""

    expires_in_days: Annotated[int, PropertyInfo(alias="expiresInDays")]
    """Days until invitation expires (1-30)"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]


class Invitation(TypedDict, total=False):
    """Single invitation in batch request"""

    email: Required[str]
    """Email address to invite"""

    role: Required[Literal["OWNER", "ADMIN", "MEMBER", "VIEWER"]]
    """Role to assign on acceptance"""
