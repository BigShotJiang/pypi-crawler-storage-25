# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "PaymentCreateResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsCounterparty",
    "DataRelationshipsCounterpartyData",
    "DataRelationshipsCustomerParty",
    "DataRelationshipsCustomerPartyData",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    amount: int
    """Amount in cents"""

    claim_link: Optional[str] = FieldInfo(alias="claimLink", default=None)
    """Claim link for unclaimed payments"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this payment was created"""

    currency: str
    """Currency code"""

    description: Optional[str] = None
    """Payment description"""

    status: Literal["PROCESSING", "PENDING_CLAIM", "IN_REVIEW", "COMPLETED", "FAILED", "CANCELLED"]
    """Payment status"""

    updated_at: str = FieldInfo(alias="updatedAt")
    """When this payment was last updated"""


class DataRelationshipsCounterpartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsCounterparty(BaseModel):
    """Party receiving the payment"""

    data: Optional[DataRelationshipsCounterpartyData] = None
    """Related resource identifier"""


class DataRelationshipsCustomerPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsCustomerParty(BaseModel):
    """Party that made the payment"""

    data: DataRelationshipsCustomerPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    counterparty: DataRelationshipsCounterparty
    """Party receiving the payment"""

    customer_party: DataRelationshipsCustomerParty = FieldInfo(alias="customerParty")
    """Party that made the payment"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str


class PaymentCreateResponse(BaseModel):
    data: Data
