# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PartyListMembersResponse", "Data", "DataAttributes", "Meta", "MetaPagination"]


class DataAttributes(BaseModel):
    """Resource attributes"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the membership was created"""

    email: Optional[str] = None
    """Email address of the user"""

    first_name: Optional[str] = FieldInfo(alias="firstName", default=None)
    """First name of the user"""

    invitation_id: Optional[str] = FieldInfo(alias="invitationId", default=None)
    """Invitation ID (only for type='invitation')"""

    invited_by: Optional[str] = FieldInfo(alias="invitedBy", default=None)
    """User ID who sent the invitation"""

    last_name: Optional[str] = FieldInfo(alias="lastName", default=None)
    """Last name of the user"""

    party_id: str = FieldInfo(alias="partyId")
    """ID of the party this membership belongs to"""

    role: Literal["OWNER", "ADMIN", "MEMBER", "VIEWER"]
    """User's role in the party (OWNER, ADMIN, MEMBER)"""

    status: Literal["ACTIVE", "REVOKED", "DELETED"]
    """Membership status"""

    type: Literal["member", "invitation"]
    """Whether this is an active member or pending invitation"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """When the membership was last updated"""


class Data(BaseModel):
    id: str
    """
    Member id: a user id (usr_xxx), or an invitation id (inv_xxx) for pending
    invitations
    """

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class PartyListMembersResponse(BaseModel):
    data: List[Data]

    meta: Meta
