# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["WalletGetDepositInstructionsResponse", "Data", "DataAttributes"]


class DataAttributes(BaseModel):
    """Resource attributes"""

    account_number: str = FieldInfo(alias="accountNumber")
    """Account number for ACH deposits"""

    bank_name: str = FieldInfo(alias="bankName")
    """Name of the receiving bank"""

    routing_number: str = FieldInfo(alias="routingNumber")
    """Bank routing number for ACH deposits"""


class Data(BaseModel):
    id: str
    """Resource ID (the wallet handle)"""

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class WalletGetDepositInstructionsResponse(BaseModel):
    data: Data
