# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "DelegationListAgentDelegationsResponse",
    "Data",
    "DataAttributes",
    "DataAttributesLimits",
    "DataRelationships",
    "DataRelationshipsAgent",
    "DataRelationshipsAgentData",
    "DataRelationshipsDelegation",
    "DataRelationshipsDelegationData",
    "DataRelationshipsDelegateeParty",
    "DataRelationshipsDelegateePartyData",
    "DataRelationshipsDelegatorParty",
    "DataRelationshipsDelegatorPartyData",
    "Meta",
    "MetaPagination",
]


class DataAttributesLimits(BaseModel):
    """Transaction limits in cents"""

    per_transaction: Optional[int] = FieldInfo(alias="perTransaction", default=None)
    """Positive per-transaction limit in cents. null means no per-payment limit."""


class DataAttributes(BaseModel):
    """Resource attributes"""

    agent_name: Optional[str] = FieldInfo(alias="agentName", default=None)
    """Agent display name"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When this delegation was created"""

    created_by: Optional[str] = FieldInfo(alias="createdBy", default=None)
    """User who created this delegation (usr\\__\\**)"""

    delegatee_party_name: Optional[str] = FieldInfo(alias="delegateePartyName", default=None)
    """Developer party name"""

    delegator_party_name: Optional[str] = FieldInfo(alias="delegatorPartyName", default=None)
    """Customer party name"""

    expires_at: Optional[datetime] = FieldInfo(alias="expiresAt", default=None)
    """Expiration timestamp"""

    limits: Optional[DataAttributesLimits] = None
    """Transaction limits in cents"""

    permissions: List[str]
    """Granted permissions. Use `status` to derive Active vs Revoked."""

    status: Literal["ACTIVE", "REVOKED"]
    """Authoritative active/revoked flag (revoke keeps permissions for audit)"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """When this delegation was last updated"""


class DataRelationshipsAgentData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsAgent(BaseModel):
    """Agent granted access"""

    data: DataRelationshipsAgentData
    """Related resource identifier"""


class DataRelationshipsDelegationData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsDelegation(BaseModel):
    """Parent party delegation"""

    data: DataRelationshipsDelegationData
    """Related resource identifier"""


class DataRelationshipsDelegateePartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsDelegateeParty(BaseModel):
    """Developer party receiving access"""

    data: Optional[DataRelationshipsDelegateePartyData] = None
    """Related resource identifier"""


class DataRelationshipsDelegatorPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsDelegatorParty(BaseModel):
    """Customer party granting access"""

    data: Optional[DataRelationshipsDelegatorPartyData] = None
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    agent: DataRelationshipsAgent
    """Agent granted access"""

    delegation: DataRelationshipsDelegation
    """Parent party delegation"""

    delegatee_party: Optional[DataRelationshipsDelegateeParty] = FieldInfo(alias="delegateeParty", default=None)
    """Developer party receiving access"""

    delegator_party: Optional[DataRelationshipsDelegatorParty] = FieldInfo(alias="delegatorParty", default=None)
    """Customer party granting access"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class DelegationListAgentDelegationsResponse(BaseModel):
    data: List[Data]

    meta: Meta
