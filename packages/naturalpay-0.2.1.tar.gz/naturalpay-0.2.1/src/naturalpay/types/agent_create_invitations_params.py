# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["AgentCreateInvitationsParams", "Agent", "AgentLimits"]


class AgentCreateInvitationsParams(TypedDict, total=False):
    agents: Required[Iterable[Agent]]
    """Per-agent delegation requests (1-50)"""

    customer_email: Required[Annotated[str, PropertyInfo(alias="customerEmail")]]
    """Email address of the customer to invite"""

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    expires_at: Annotated[Union[str, datetime], PropertyInfo(alias="expiresAt", format="iso8601")]
    """Optional explicit expiry timestamp; server defaults to 7 days"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]


class AgentLimits(TypedDict, total=False):
    per_transaction: Annotated[Optional[int], PropertyInfo(alias="perTransaction")]
    """Per-transaction cap, integer cents (USD)."""


class Agent(TypedDict, total=False):
    agent_id: Required[Annotated[str, PropertyInfo(alias="agentId")]]

    permissions: Required[SequenceNotStr[str]]

    limits: AgentLimits
