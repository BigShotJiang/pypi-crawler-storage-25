# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["InvitationListParams"]


class InvitationListParams(TypedDict, total=False):
    email: str
    """Filter by email"""

    party_id: Annotated[str, PropertyInfo(alias="partyId")]
    """Filter by party"""

    status: Literal["PENDING", "ACCEPTED", "REVOKED"]
    """Filter by status"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
