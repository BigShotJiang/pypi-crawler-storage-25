# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentRequestListParams"]


class PaymentRequestListParams(TypedDict, total=False):
    cursor: str
    """Pagination cursor returned by the previous response"""

    limit: int
    """Results per page (1-100)"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
