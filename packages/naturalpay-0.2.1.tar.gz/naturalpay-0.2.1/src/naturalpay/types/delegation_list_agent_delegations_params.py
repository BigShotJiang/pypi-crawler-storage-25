# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["DelegationListAgentDelegationsParams"]


class DelegationListAgentDelegationsParams(TypedDict, total=False):
    agent_id: Annotated[str, PropertyInfo(alias="agentId")]
    """Filter by agent (agt_xxx)"""

    cursor: str
    """Cursor for pagination"""

    delegatee_party_id: Annotated[str, PropertyInfo(alias="delegateePartyId")]
    """Filter to delegations where caller is the delegated party (developer)"""

    delegation_id: Annotated[str, PropertyInfo(alias="delegationId")]
    """Filter by parent delegation (dlg_xxx)"""

    delegator_party_id: Annotated[str, PropertyInfo(alias="delegatorPartyId")]
    """Filter to delegations where caller is the delegating party (customer)"""

    include_revoked: Annotated[Union[bool, str], PropertyInfo(alias="includeRevoked")]
    """Include revoked delegations"""

    limit: int
    """Max items per page"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
