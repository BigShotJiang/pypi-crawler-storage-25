# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["WalletInitiateWithdrawalResponse", "Data", "DataAttributes"]


class DataAttributes(BaseModel):
    """Resource attributes"""

    amount: float
    """Amount in cents"""

    currency: str
    """Currency code"""

    error: Optional[str] = None
    """Error message if failed"""

    error_details: Optional[str] = FieldInfo(alias="errorDetails", default=None)
    """Detailed error information"""

    estimated_settlement: Optional[str] = FieldInfo(alias="estimatedSettlement", default=None)
    """Estimated settlement time"""

    instruction_id: Optional[str] = FieldInfo(alias="instructionId", default=None)
    """Payment instruction ID"""

    mfa_challenge_id: Optional[str] = FieldInfo(alias="mfaChallengeId", default=None)
    """MFA challenge ID"""

    mfa_expires_at: Optional[str] = FieldInfo(alias="mfaExpiresAt", default=None)
    """MFA challenge expiration"""

    mfa_required: bool = FieldInfo(alias="mfaRequired")
    """Whether MFA is required"""

    status: Literal["PROCESSING", "IN_REVIEW", "COMPLETED", "FAILED", "RETURNED"]
    """Operation status"""


class Data(BaseModel):
    id: str
    """Transaction handle (txn_xxx).

    Empty when the operation failed before a transaction was created.
    """

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class WalletInitiateWithdrawalResponse(BaseModel):
    data: Data
