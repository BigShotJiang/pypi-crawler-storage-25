# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PartyUpdateParams"]


class PartyUpdateParams(TypedDict, total=False):
    display_name: Annotated[Optional[str], PropertyInfo(alias="displayName")]
    """Updated display name.

    Pass null to clear; empty string is rejected (use null to clear instead).
    """

    persona: Literal["INDIVIDUAL", "DEVELOPER"]
    """Updated party persona: INDIVIDUAL or DEVELOPER.

    Clearing persona to null is not supported.
    """

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
