# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PaymentRequestListResponse", "Data", "DataAttributes", "Meta", "MetaPagination"]


class DataAttributes(BaseModel):
    """Resource attributes"""

    amount: int
    """Amount in minor units (cents for USD)"""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp when the payment request was created"""

    currency: str
    """Currency code"""

    description: Optional[str] = None
    """Free-form description provided at creation"""

    payer_email: Optional[str] = FieldInfo(alias="payerEmail", default=None)
    """Email of the payer if addressed by email"""

    payer_identifier: str = FieldInfo(alias="payerIdentifier")
    """The identifier value used to address the payer"""

    payer_identifier_type: Literal["email", "phone", "party_id"] = FieldInfo(alias="payerIdentifierType")
    """Which identifier type was used to address the payer"""

    payer_name: Optional[str] = FieldInfo(alias="payerName", default=None)
    """Display name of the payer"""

    payer_party_id: Optional[str] = FieldInfo(alias="payerPartyId", default=None)
    """Natural party ID (pty\\__\\**) of the payer if addressed by party"""

    payer_phone: Optional[str] = FieldInfo(alias="payerPhone", default=None)
    """Phone of the payer in E.164 format if addressed by phone"""

    payment_link_url: str = FieldInfo(alias="paymentLinkUrl")
    """URL the payer visits to complete payment"""

    requester_email: Optional[str] = FieldInfo(alias="requesterEmail", default=None)
    """Email of the requester party"""

    requester_name: Optional[str] = FieldInfo(alias="requesterName", default=None)
    """Display name of the requester party"""

    status: Literal["OPEN", "PROCESSING", "COMPLETED", "CANCELLED", "DECLINED", "EXPIRED"]
    """Current status of the payment request"""

    transaction_id: Optional[str] = FieldInfo(alias="transactionId", default=None)
    """
    ID of the transaction created by the most recent payment attempt, or null if no
    attempt yet
    """

    updated_at: str = FieldInfo(alias="updatedAt")
    """ISO 8601 timestamp when the payment request was last updated"""


class Data(BaseModel):
    id: str
    """Resource ID (prq\\__\\**)"""

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class PaymentRequestListResponse(BaseModel):
    data: List[Data]

    meta: Meta
