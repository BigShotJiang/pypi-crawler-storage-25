# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "TransactionListResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsDestinationParty",
    "DataRelationshipsDestinationPartyData",
    "DataRelationshipsDestinationWallet",
    "DataRelationshipsDestinationWalletData",
    "DataRelationshipsSourceParty",
    "DataRelationshipsSourcePartyData",
    "DataRelationshipsSourceWallet",
    "DataRelationshipsSourceWalletData",
    "Meta",
    "MetaPagination",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    agent_id: Optional[str] = FieldInfo(alias="agentId", default=None)
    """Agent that initiated this transaction. Null when initiated by a human user."""

    amount: int
    """Amount in cents"""

    category: Literal["sent", "received", "deposit", "withdrawal"]
    """Classification from the authenticated party's perspective.

    Derived from transactionType + direction: "sent"/"received" for wallet-to-wallet
    payments (OUTBOUND/INBOUND), "deposit"/"withdrawal" for external transfers
    (INBOUND/OUTBOUND).
    """

    created_at: str = FieldInfo(alias="createdAt")
    """When this transaction was created"""

    currency: str
    """Currency code"""

    customer_name: Optional[str] = FieldInfo(alias="customerName", default=None)
    """Customer name if delegated"""

    description: Optional[str] = None
    """Payment description"""

    direction: Literal["INBOUND", "OUTBOUND"]
    """Direction: INBOUND | OUTBOUND"""

    dispute_id: Optional[str] = FieldInfo(alias="disputeId", default=None)
    """Active dispute ID when a dispute has been filed for this transaction"""

    escalation_id: Optional[str] = FieldInfo(alias="escalationId", default=None)
    """Pending escalation ID when this transaction requires approval"""

    initiator_name: Optional[str] = FieldInfo(alias="initiatorName", default=None)
    """Display name of the user or agent that initiated this transaction"""

    is_delegated: bool = FieldInfo(alias="isDelegated")
    """True if this is a delegated customer payment"""

    recipient_name: Optional[str] = FieldInfo(alias="recipientName", default=None)
    """Recipient display name"""

    sender_name: Optional[str] = FieldInfo(alias="senderName", default=None)
    """Sender display name"""

    status: str
    """Transaction status"""

    transaction_type: Literal["payment", "transfer"] = FieldInfo(alias="transactionType")
    """Transaction type: payment | transfer"""

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """When this transaction was last updated"""


class DataRelationshipsDestinationPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsDestinationParty(BaseModel):
    """Destination party"""

    data: Optional[DataRelationshipsDestinationPartyData] = None
    """Related resource identifier"""


class DataRelationshipsDestinationWalletData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsDestinationWallet(BaseModel):
    """Destination wallet"""

    data: Optional[DataRelationshipsDestinationWalletData] = None
    """Related resource identifier"""


class DataRelationshipsSourcePartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsSourceParty(BaseModel):
    """Source party"""

    data: Optional[DataRelationshipsSourcePartyData] = None
    """Related resource identifier"""


class DataRelationshipsSourceWalletData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsSourceWallet(BaseModel):
    """Source wallet"""

    data: Optional[DataRelationshipsSourceWalletData] = None
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    destination_party: DataRelationshipsDestinationParty = FieldInfo(alias="destinationParty")
    """Destination party"""

    destination_wallet: DataRelationshipsDestinationWallet = FieldInfo(alias="destinationWallet")
    """Destination wallet"""

    source_party: DataRelationshipsSourceParty = FieldInfo(alias="sourceParty")
    """Source party"""

    source_wallet: DataRelationshipsSourceWallet = FieldInfo(alias="sourceWallet")
    """Source wallet"""


class Data(BaseModel):
    id: str
    """Transaction handle (txn_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class TransactionListResponse(BaseModel):
    data: List[Data]

    meta: Meta
