# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["AgentCreateParams", "Limits"]


class AgentCreateParams(TypedDict, total=False):
    name: Required[str]
    """Agent display name"""

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    description: str
    """Agent description"""

    limits: Limits
    """Optional per-transaction limit for the agent"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]


class Limits(TypedDict, total=False):
    """Optional per-transaction limit for the agent"""

    per_transaction: Annotated[Optional[int], PropertyInfo(alias="perTransaction")]
    """Positive per-transaction limit in cents. null means no per-payment limit."""
