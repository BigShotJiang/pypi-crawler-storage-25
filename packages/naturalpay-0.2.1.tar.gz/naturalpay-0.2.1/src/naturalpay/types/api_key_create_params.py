# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["APIKeyCreateParams"]


class APIKeyCreateParams(TypedDict, total=False):
    name: Required[str]
    """Human-readable name for the key"""

    scopes: List[
        Literal[
            "party.read",
            "party.update",
            "invite.read",
            "invite.create",
            "invite.update",
            "invite.delete",
            "membership.create",
            "membership.read",
            "membership.update",
            "membership.delete",
            "payments.create",
            "payments.read",
            "wallets.read",
            "wallets.create",
            "wallets.update",
            "wallets.delete",
            "wallets.fund",
            "wallets.withdraw",
            "delegations.read",
            "delegations.create",
            "delegations.update",
            "delegations.delete",
            "api_keys.read",
            "api_keys.create",
            "api_keys.delete",
            "agents.read",
            "agents.create",
            "agents.update",
            "agents.delete",
            "disputes.read",
            "disputes.create",
        ]
    ]
    """Permission scopes for the API key. Defaults to all scopes if omitted."""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
