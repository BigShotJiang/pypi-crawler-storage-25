# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentCreateParams"]


class PaymentCreateParams(TypedDict, total=False):
    amount: Required[int]
    """Amount in cents"""

    counterparty: Required[str]
    """Recipient: party ID (pty\\__\\**), email, or phone"""

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    currency: Literal["USD"]
    """Currency code"""

    customer_party_id: Annotated[str, PropertyInfo(alias="customerPartyId")]
    """Sender party ID (pty\\__\\**).

    Omit to send from your own wallet; provide for delegated payments on behalf of a
    customer.
    """

    description: str
    """Payment description"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
