# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "WalletGetBalanceResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    available_amount_minor: int = FieldInfo(alias="availableAmountMinor")
    """Amount currently available to spend or withdraw (cents)"""

    currency: Literal["USD"]
    """Currency code"""

    total_amount_minor: int = FieldInfo(alias="totalAmountMinor")
    """Total wallet ledger balance (cents)"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the wallet"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the wallet"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class WalletGetBalanceResponse(BaseModel):
    data: Data
