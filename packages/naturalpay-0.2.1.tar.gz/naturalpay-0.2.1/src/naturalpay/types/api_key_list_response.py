# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "APIKeyListResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
    "Meta",
    "MetaPagination",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    api_key_prefix: str = FieldInfo(alias="apiKeyPrefix")
    """Non-secret prefix of the API key, e.g.

    `sk_ntl_live_abc123`. The middle segment encodes the environment; the final
    segment is random.
    """

    created_at: datetime = FieldInfo(alias="createdAt")
    """When this key was created"""

    created_by: Optional[str] = FieldInfo(alias="createdBy", default=None)
    """User who created this key (usr\\__\\**)"""

    environment: Literal["sandbox", "prod"]
    """Environment"""

    last_used_at: Optional[datetime] = FieldInfo(alias="lastUsedAt", default=None)
    """When this key was last used"""

    name: str
    """Human-readable name"""

    revoked_at: Optional[datetime] = FieldInfo(alias="revokedAt", default=None)
    """When this key was revoked"""

    revoked_by: Optional[str] = FieldInfo(alias="revokedBy", default=None)
    """User who revoked this key (usr\\__\\**)"""

    scopes: List[str]
    """Authorized scopes"""

    status: Literal["ACTIVE", "REVOKED"]
    """Status (ACTIVE or REVOKED)"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the API key"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the API key"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class APIKeyListResponse(BaseModel):
    data: List[Data]

    meta: Meta
