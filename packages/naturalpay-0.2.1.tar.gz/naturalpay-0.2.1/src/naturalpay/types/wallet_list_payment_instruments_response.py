# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "WalletListPaymentInstrumentsResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
    "Meta",
    "MetaPagination",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    account_name: Optional[str] = FieldInfo(alias="accountName", default=None)
    """Account display name"""

    account_type: Optional[Literal["checking", "savings", "unknown"]] = FieldInfo(alias="accountType", default=None)
    """Account type (checking, savings)"""

    bank_name: Optional[str] = FieldInfo(alias="bankName", default=None)
    """Bank institution name"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the funding source was linked"""

    last_four: str = FieldInfo(alias="lastFour")
    """Last 4 digits of account"""

    status: Literal["new", "active", "disabled", "deleted", "unknown"]
    """Status (new, active, disabled)"""

    verification_state: Optional[str] = FieldInfo(alias="verificationState", default=None)
    """Verification state"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the funding source"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the funding source"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class WalletListPaymentInstrumentsResponse(BaseModel):
    data: List[Data]

    meta: Meta
