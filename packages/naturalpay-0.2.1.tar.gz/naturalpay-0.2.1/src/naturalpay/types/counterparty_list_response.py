# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "CounterpartyListResponse",
    "Data",
    "DataAttributes",
    "DataAttributesReceived",
    "DataAttributesSent",
    "Meta",
    "MetaPagination",
]


class DataAttributesReceived(BaseModel):
    """Aggregates for payments you received from this counterparty. Null if none."""

    first_at: datetime = FieldInfo(alias="firstAt")
    """Timestamp of first payment in this direction"""

    total_amount_minor: float = FieldInfo(alias="totalAmountMinor")
    """Total amount in this direction, minor units (cents)"""

    transaction_count: float = FieldInfo(alias="transactionCount")
    """Number of payments in this direction"""


class DataAttributesSent(BaseModel):
    """Aggregates for payments you sent to this counterparty. Null if none."""

    first_at: datetime = FieldInfo(alias="firstAt")
    """Timestamp of first payment in this direction"""

    total_amount_minor: float = FieldInfo(alias="totalAmountMinor")
    """Total amount in this direction, minor units (cents)"""

    transaction_count: float = FieldInfo(alias="transactionCount")
    """Number of payments in this direction"""


class DataAttributes(BaseModel):
    """Counterparty attributes"""

    party_email: Optional[str] = FieldInfo(alias="partyEmail", default=None)
    """Counterparty primary email"""

    party_id: Optional[str] = FieldInfo(alias="partyId", default=None)
    """Party ID (pty_xxx) - null for unclaimed payments"""

    party_name: Optional[str] = FieldInfo(alias="partyName", default=None)
    """Counterparty display name"""

    party_status: Optional[Literal["PROVISIONAL", "ACTIVE", "SUSPENDED", "INACTIVE"]] = FieldInfo(
        alias="partyStatus", default=None
    )
    """Counterparty party status"""

    received: Optional[DataAttributesReceived] = None
    """Aggregates for payments you received from this counterparty. Null if none."""

    sent: Optional[DataAttributesSent] = None
    """Aggregates for payments you sent to this counterparty. Null if none."""


class Data(BaseModel):
    id: str
    """Counterparty ID: a party id (pty_xxx), or unknown_xxx for unclaimed payments"""

    attributes: DataAttributes
    """Counterparty attributes"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class CounterpartyListResponse(BaseModel):
    data: List[Data]

    meta: Meta
