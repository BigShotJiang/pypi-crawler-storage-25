# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["InvitationListResponse", "Data", "DataAttributes", "Meta", "MetaPagination"]


class DataAttributes(BaseModel):
    """Resource attributes"""

    accepted_at: Optional[str] = FieldInfo(alias="acceptedAt", default=None)
    """When this invitation was accepted"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this invitation was created"""

    email: str
    """Invitee email address"""

    expires_at: str = FieldInfo(alias="expiresAt")
    """When this invitation expires"""

    role: Literal["OWNER", "ADMIN", "MEMBER", "VIEWER"]
    """Role assigned on acceptance"""

    status: Literal["PENDING", "ACCEPTED", "REVOKED"]
    """Invitation status"""


class Data(BaseModel):
    id: str
    """Invitation ID (inv_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class InvitationListResponse(BaseModel):
    data: List[Data]

    meta: Meta
