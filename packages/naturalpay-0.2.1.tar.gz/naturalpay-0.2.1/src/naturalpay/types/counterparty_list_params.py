# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["CounterpartyListParams"]


class CounterpartyListParams(TypedDict, total=False):
    cursor: str
    """Cursor for pagination"""

    direction: Literal["sent", "received"]
    """Optional filter.

    When set, only counterparties with activity in that direction are returned, and
    pagination is scoped to that subset. Omit to return every counterparty.
    """

    limit: int
    """Maximum number of results"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
