# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PartyGetResponse", "Data", "DataAttributes"]


class DataAttributes(BaseModel):
    """Party attributes"""

    address_city: Optional[str] = FieldInfo(alias="addressCity", default=None)
    """City"""

    address_country: Optional[str] = FieldInfo(alias="addressCountry", default=None)
    """Country code (e.g., US)"""

    address_line1: Optional[str] = FieldInfo(alias="addressLine1", default=None)
    """Street address line 1"""

    address_postal_code: Optional[str] = FieldInfo(alias="addressPostalCode", default=None)
    """Postal or ZIP code"""

    address_state: Optional[str] = FieldInfo(alias="addressState", default=None)
    """State or province"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the party was created"""

    created_by: Optional[str] = FieldInfo(alias="createdBy", default=None)
    """User who created this party (usr\\__\\**)"""

    display_name: Optional[str] = FieldInfo(alias="displayName", default=None)
    """Display name for the party"""

    email: Optional[str] = None
    """Party's primary contact email"""

    first_name: Optional[str] = FieldInfo(alias="firstName", default=None)
    """Legal first name for PERSON parties"""

    last_name: Optional[str] = FieldInfo(alias="lastName", default=None)
    """Legal last name for PERSON parties"""

    legal_name: Optional[str] = FieldInfo(alias="legalName", default=None)
    """Legal business name for ORG parties"""

    party_type: Literal["PERSON", "ORG"] = FieldInfo(alias="partyType")
    """Party type: individual or organization"""

    persona: Optional[Literal["INDIVIDUAL", "DEVELOPER"]] = None
    """Party persona: INDIVIDUAL, DEVELOPER, or null during upstream rollout"""

    primary_phone: Optional[str] = FieldInfo(alias="primaryPhone", default=None)
    """Party's primary phone number"""

    status: Literal["PROVISIONAL", "ACTIVE", "SUSPENDED", "INACTIVE"]
    """Party status (e.g., ACTIVE, SUSPENDED)"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """When the party was last updated"""


class Data(BaseModel):
    id: str
    """Unique party identifier"""

    attributes: DataAttributes
    """Party attributes"""

    type: str
    """Resource type"""


class PartyGetResponse(BaseModel):
    data: Data
