# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "CustomerListInvitationsResponse",
    "Data",
    "DataAttributes",
    "DataAttributesAgentInvitation",
    "DataAttributesAgentInvitationAgent",
    "DataAttributesParty",
    "Meta",
    "MetaPagination",
]


class DataAttributesAgentInvitationAgent(BaseModel):
    """Agent the invitation targets"""

    id: str
    """Agent handle (agt_xxx)"""

    name: Optional[str] = None
    """Agent display name"""


class DataAttributesAgentInvitation(BaseModel):
    agent: DataAttributesAgentInvitationAgent
    """Agent the invitation targets"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the agent invitation was created"""

    expires_at: Optional[datetime] = FieldInfo(alias="expiresAt", default=None)
    """When the agent invitation expires (null if it does not expire)"""

    invitation_id: str = FieldInfo(alias="invitationId")
    """Agent delegation invitation handle (adi_xxx)"""

    permissions: List[str]
    """Permissions the invitation requests"""


class DataAttributesParty(BaseModel):
    """Party info (null until the recipient creates an account)"""

    id: str
    """Party handle (pty_xxx)"""

    email: Optional[str] = None
    """Primary email"""

    name: str
    """Display name, falling back to legal name when display name is unset"""


class DataAttributes(BaseModel):
    """Resource attributes"""

    agent_invitations: List[DataAttributesAgentInvitation] = FieldInfo(alias="agentInvitations")
    """Pending agent delegation invitations sent to this recipient"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the earliest agent invitation was created"""

    email: str
    """Recipient email — the grouping key"""

    party: Optional[DataAttributesParty] = None
    """Party info (null until the recipient creates an account)"""

    status: str
    """Status (always PENDING)"""

    wallet_access: Literal["granted", "denied", "noWallet"] = FieldInfo(alias="walletAccess")
    """Always 'denied' for pending customers"""

    wallet_available_minor: Optional[int] = FieldInfo(alias="walletAvailableMinor", default=None)
    """Always null for pending customers"""


class Data(BaseModel):
    """
    A pending customer invitation (type='customerInvitation', id=recipient email) — a grouping of agent invitations sent to one recipient.
    """

    id: str
    """Recipient email — the grouping key for the pending invitation.

    Stays the id even after the recipient creates an account.
    """

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class CustomerListInvitationsResponse(BaseModel):
    data: List[Data]

    meta: Meta
