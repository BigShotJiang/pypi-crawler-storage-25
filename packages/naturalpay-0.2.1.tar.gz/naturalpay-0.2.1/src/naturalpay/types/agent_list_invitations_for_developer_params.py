# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["AgentListInvitationsForDeveloperParams"]


class AgentListInvitationsForDeveloperParams(TypedDict, total=False):
    agent_id: Annotated[str, PropertyInfo(alias="agentId")]

    cursor: str

    customer_email: Annotated[str, PropertyInfo(alias="customerEmail")]

    limit: int

    status: List[Literal["PENDING", "ACCEPTED", "DECLINED", "EXPIRED", "CANCELLED"]]

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
