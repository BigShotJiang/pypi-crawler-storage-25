# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["CustomerListResponse", "Data", "DataAttributes", "DataAttributesParty", "Meta", "MetaPagination"]


class DataAttributesParty(BaseModel):
    """Party info"""

    id: str
    """Party handle (pty_xxx)"""

    email: Optional[str] = None
    """Primary email"""

    name: str
    """Display name, falling back to legal name when display name is unset"""


class DataAttributes(BaseModel):
    """Resource attributes"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the delegation was created"""

    email: Optional[str] = None
    """Customer email, if known"""

    party: DataAttributesParty
    """Party info"""

    permissions: List[str]
    """Granted permissions"""

    status: str
    """Status (ACTIVE, etc.)"""

    wallet_access: Literal["granted", "denied", "noWallet"] = FieldInfo(alias="walletAccess")
    """
    Why walletAvailableMinor may be null: "granted" balance is fresh; "denied"
    caller lacks wallets.read; "noWallet" party has not provisioned a wallet.
    """

    wallet_available_minor: Optional[int] = FieldInfo(alias="walletAvailableMinor", default=None)
    """Available wallet balance in cents.

    Null when access is denied or no wallet exists — see walletAccess.
    """


class Data(BaseModel):
    """Customer resource for an active customer (type='customer', id=pty_xxx)."""

    id: str
    """Customer party handle (pty_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class CustomerListResponse(BaseModel):
    data: List[Data]

    meta: Meta
