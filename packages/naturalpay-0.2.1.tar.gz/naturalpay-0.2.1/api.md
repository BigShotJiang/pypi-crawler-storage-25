# Agents

Types:

```python
from naturalpay.types import (
    AgentCreateResponse,
    AgentUpdateResponse,
    AgentListResponse,
    AgentCreateInvitationsResponse,
    AgentGetResponse,
    AgentListInvitationsForDeveloperResponse,
    AgentRemoveResponse,
)
```

Methods:

- <code title="post /agents">client.agents.<a href="./src/naturalpay/resources/agents.py">create</a>(\*\*<a href="src/naturalpay/types/agent_create_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_create_response.py">AgentCreateResponse</a></code>
- <code title="put /agents/{agentId}">client.agents.<a href="./src/naturalpay/resources/agents.py">update</a>(agent_id, \*\*<a href="src/naturalpay/types/agent_update_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_update_response.py">AgentUpdateResponse</a></code>
- <code title="get /agents">client.agents.<a href="./src/naturalpay/resources/agents.py">list</a>(\*\*<a href="src/naturalpay/types/agent_list_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_list_response.py">AgentListResponse</a></code>
- <code title="post /agents/invitations">client.agents.<a href="./src/naturalpay/resources/agents.py">create_invitations</a>(\*\*<a href="src/naturalpay/types/agent_create_invitations_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_create_invitations_response.py">AgentCreateInvitationsResponse</a></code>
- <code title="get /agents/{agentId}">client.agents.<a href="./src/naturalpay/resources/agents.py">get</a>(agent_id) -> <a href="./src/naturalpay/types/agent_get_response.py">AgentGetResponse</a></code>
- <code title="get /agents/invitations">client.agents.<a href="./src/naturalpay/resources/agents.py">list_invitations_for_developer</a>(\*\*<a href="src/naturalpay/types/agent_list_invitations_for_developer_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_list_invitations_for_developer_response.py">AgentListInvitationsForDeveloperResponse</a></code>
- <code title="delete /agents/{agentId}">client.agents.<a href="./src/naturalpay/resources/agents.py">remove</a>(agent_id) -> <a href="./src/naturalpay/types/agent_remove_response.py">AgentRemoveResponse</a></code>

# APIKeys

Types:

```python
from naturalpay.types import (
    APIKeyCreateResponse,
    APIKeyListResponse,
    APIKeyGetResponse,
    APIKeyRevokeResponse,
)
```

Methods:

- <code title="post /api-keys">client.api_keys.<a href="./src/naturalpay/resources/api_keys.py">create</a>(\*\*<a href="src/naturalpay/types/api_key_create_params.py">params</a>) -> <a href="./src/naturalpay/types/api_key_create_response.py">APIKeyCreateResponse</a></code>
- <code title="get /api-keys">client.api_keys.<a href="./src/naturalpay/resources/api_keys.py">list</a>(\*\*<a href="src/naturalpay/types/api_key_list_params.py">params</a>) -> <a href="./src/naturalpay/types/api_key_list_response.py">APIKeyListResponse</a></code>
- <code title="get /api-keys/{keyId}">client.api_keys.<a href="./src/naturalpay/resources/api_keys.py">get</a>(key_id) -> <a href="./src/naturalpay/types/api_key_get_response.py">APIKeyGetResponse</a></code>
- <code title="put /api-keys/{keyId}/revoke">client.api_keys.<a href="./src/naturalpay/resources/api_keys.py">revoke</a>(key_id) -> <a href="./src/naturalpay/types/api_key_revoke_response.py">APIKeyRevokeResponse</a></code>

# Counterparties

Types:

```python
from naturalpay.types import CounterpartyListResponse
```

Methods:

- <code title="get /counterparties">client.counterparties.<a href="./src/naturalpay/resources/counterparties.py">list</a>(\*\*<a href="src/naturalpay/types/counterparty_list_params.py">params</a>) -> <a href="./src/naturalpay/types/counterparty_list_response.py">CounterpartyListResponse</a></code>

# Customers

Types:

```python
from naturalpay.types import CustomerListResponse, CustomerListInvitationsResponse
```

Methods:

- <code title="get /customers">client.customers.<a href="./src/naturalpay/resources/customers.py">list</a>(\*\*<a href="src/naturalpay/types/customer_list_params.py">params</a>) -> <a href="./src/naturalpay/types/customer_list_response.py">CustomerListResponse</a></code>
- <code title="get /customers/invitations">client.customers.<a href="./src/naturalpay/resources/customers.py">list_invitations</a>(\*\*<a href="src/naturalpay/types/customer_list_invitations_params.py">params</a>) -> <a href="./src/naturalpay/types/customer_list_invitations_response.py">CustomerListInvitationsResponse</a></code>

# Delegations

Types:

```python
from naturalpay.types import (
    DelegationGetAgentDelegationResponse,
    DelegationListAgentDelegationsResponse,
)
```

Methods:

- <code title="get /agent-delegations/{agentDelegationId}">client.delegations.<a href="./src/naturalpay/resources/delegations.py">get_agent_delegation</a>(agent_delegation_id) -> <a href="./src/naturalpay/types/delegation_get_agent_delegation_response.py">DelegationGetAgentDelegationResponse</a></code>
- <code title="get /agent-delegations">client.delegations.<a href="./src/naturalpay/resources/delegations.py">list_agent_delegations</a>(\*\*<a href="src/naturalpay/types/delegation_list_agent_delegations_params.py">params</a>) -> <a href="./src/naturalpay/types/delegation_list_agent_delegations_response.py">DelegationListAgentDelegationsResponse</a></code>

# Invitations

Types:

```python
from naturalpay.types import (
    InvitationCreateResponse,
    InvitationListResponse,
    InvitationRevokeResponse,
)
```

Methods:

- <code title="post /party-invitations">client.invitations.<a href="./src/naturalpay/resources/invitations.py">create</a>(\*\*<a href="src/naturalpay/types/invitation_create_params.py">params</a>) -> <a href="./src/naturalpay/types/invitation_create_response.py">InvitationCreateResponse</a></code>
- <code title="get /party-invitations">client.invitations.<a href="./src/naturalpay/resources/invitations.py">list</a>(\*\*<a href="src/naturalpay/types/invitation_list_params.py">params</a>) -> <a href="./src/naturalpay/types/invitation_list_response.py">InvitationListResponse</a></code>
- <code title="post /party-invitations/{invitationId}/revoke">client.invitations.<a href="./src/naturalpay/resources/invitations.py">revoke</a>(invitation_id) -> <a href="./src/naturalpay/types/invitation_revoke_response.py">InvitationRevokeResponse</a></code>

# Parties

Types:

```python
from naturalpay.types import PartyUpdateResponse, PartyGetResponse, PartyListMembersResponse
```

Methods:

- <code title="put /parties/me">client.parties.<a href="./src/naturalpay/resources/parties.py">update</a>(\*\*<a href="src/naturalpay/types/party_update_params.py">params</a>) -> <a href="./src/naturalpay/types/party_update_response.py">PartyUpdateResponse</a></code>
- <code title="get /parties/me">client.parties.<a href="./src/naturalpay/resources/parties.py">get</a>() -> <a href="./src/naturalpay/types/party_get_response.py">PartyGetResponse</a></code>
- <code title="get /parties/me/members">client.parties.<a href="./src/naturalpay/resources/parties.py">list_members</a>(\*\*<a href="src/naturalpay/types/party_list_members_params.py">params</a>) -> <a href="./src/naturalpay/types/party_list_members_response.py">PartyListMembersResponse</a></code>

# PaymentRequests

Types:

```python
from naturalpay.types import (
    PaymentRequestCreateResponse,
    PaymentRequestListResponse,
    PaymentRequestGetResponse,
)
```

Methods:

- <code title="post /payment-requests">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">create</a>(\*\*<a href="src/naturalpay/types/payment_request_create_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_request_create_response.py">PaymentRequestCreateResponse</a></code>
- <code title="get /payment-requests">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">list</a>(\*\*<a href="src/naturalpay/types/payment_request_list_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_request_list_response.py">PaymentRequestListResponse</a></code>
- <code title="get /payment-requests/{paymentRequestId}">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">get</a>(payment_request_id) -> <a href="./src/naturalpay/types/payment_request_get_response.py">PaymentRequestGetResponse</a></code>

# Payments

Types:

```python
from naturalpay.types import PaymentCreateResponse
```

Methods:

- <code title="post /payments">client.payments.<a href="./src/naturalpay/resources/payments.py">create</a>(\*\*<a href="src/naturalpay/types/payment_create_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_create_response.py">PaymentCreateResponse</a></code>

# Transactions

Types:

```python
from naturalpay.types import TransactionListResponse, TransactionGetResponse
```

Methods:

- <code title="get /transactions">client.transactions.<a href="./src/naturalpay/resources/transactions.py">list</a>(\*\*<a href="src/naturalpay/types/transaction_list_params.py">params</a>) -> <a href="./src/naturalpay/types/transaction_list_response.py">TransactionListResponse</a></code>
- <code title="get /transactions/{transactionId}">client.transactions.<a href="./src/naturalpay/resources/transactions.py">get</a>(transaction_id, \*\*<a href="src/naturalpay/types/transaction_get_params.py">params</a>) -> <a href="./src/naturalpay/types/transaction_get_response.py">TransactionGetResponse</a></code>

# Wallet

Types:

```python
from naturalpay.types import (
    WalletGetBalanceResponse,
    WalletGetDepositInstructionsResponse,
    WalletInitiateDepositResponse,
    WalletInitiateWithdrawalResponse,
    WalletListPaymentInstrumentsResponse,
    WalletRemovePaymentInstrumentResponse,
)
```

Methods:

- <code title="get /wallet/balance">client.wallet.<a href="./src/naturalpay/resources/wallet.py">get_balance</a>(\*\*<a href="src/naturalpay/types/wallet_get_balance_params.py">params</a>) -> <a href="./src/naturalpay/types/wallet_get_balance_response.py">WalletGetBalanceResponse</a></code>
- <code title="get /wallet/deposit-instructions">client.wallet.<a href="./src/naturalpay/resources/wallet.py">get_deposit_instructions</a>() -> <a href="./src/naturalpay/types/wallet_get_deposit_instructions_response.py">WalletGetDepositInstructionsResponse</a></code>
- <code title="post /wallet/deposit">client.wallet.<a href="./src/naturalpay/resources/wallet.py">initiate_deposit</a>(\*\*<a href="src/naturalpay/types/wallet_initiate_deposit_params.py">params</a>) -> <a href="./src/naturalpay/types/wallet_initiate_deposit_response.py">WalletInitiateDepositResponse</a></code>
- <code title="post /wallet/withdraw">client.wallet.<a href="./src/naturalpay/resources/wallet.py">initiate_withdrawal</a>(\*\*<a href="src/naturalpay/types/wallet_initiate_withdrawal_params.py">params</a>) -> <a href="./src/naturalpay/types/wallet_initiate_withdrawal_response.py">WalletInitiateWithdrawalResponse</a></code>
- <code title="get /wallet/external-funding-sources">client.wallet.<a href="./src/naturalpay/resources/wallet.py">list_payment_instruments</a>(\*\*<a href="src/naturalpay/types/wallet_list_payment_instruments_params.py">params</a>) -> <a href="./src/naturalpay/types/wallet_list_payment_instruments_response.py">WalletListPaymentInstrumentsResponse</a></code>
- <code title="delete /wallet/external-funding-sources/{externalFundingSourceId}">client.wallet.<a href="./src/naturalpay/resources/wallet.py">remove_payment_instrument</a>(external_funding_source_id) -> <a href="./src/naturalpay/types/wallet_remove_payment_instrument_response.py">WalletRemovePaymentInstrumentResponse</a></code>
