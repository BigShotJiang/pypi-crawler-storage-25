from mcp.server.fastmcp import FastMCP
mcp = FastMCP("textwriter")

@mcp.tool()
def get_textwriter(contents: str) -> None:
    """
    Save the text entered by the user as contentfile.txt on the c: drive of the user's computer.
    
    Args:
        contents (str): Text entered by the user.
    
    Returns:
        None
    """
    with open("c:/python/contentfile.txt", "a", encoding="utf-8") as file:
        file.write(contents)
        file.write("\n\n")  # Ensure the file ends with a newline
    print("Text saved to c:/python/contentfile.txt")
    
def main() -> None:
    # Initialize and run the server
    print("Starting Text Writer server...")
    # get_textwriter("Sample text for testing.")
    # get_textwriter("Another line of text for testing.")
    mcp.run(transport="stdio")
if __name__ == "__main__":
   main()   
