from __future__ import annotations

import json
import http.client
import os
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, Tuple

REINSTALL_HINT = 'Try reinstalling: curl -s "https://code.deepline.com/api/v2/cli/install" | bash'
_HTTP_DEBUG_T0 = time.time()

# Statuses that indicate infrastructure-level failures worth reporting
_REPORTABLE_STATUSES = frozenset({413, 502, 503, 504})


@dataclass(frozen=True)
class HttpResponse:
    status: int
    body: str
    headers: Dict[str, str]

    def as_tuple(self) -> Tuple[int, str]:
        return self.status, self.body


def _network_runtime_error(message: str) -> RuntimeError:
    return RuntimeError(f"{message}\n{REINSTALL_HINT}")


def is_network_runtime_error(exc: BaseException) -> bool:
    return isinstance(exc, RuntimeError) and REINSTALL_HINT in str(exc)


def _normalize_response_headers(items: list[tuple[str, str]]) -> Dict[str, str]:
    return {str(key): str(value) for key, value in items}


def _http_debug_enabled() -> bool:
    raw = str(os.environ.get("DEEPLINE_DEBUG_HTTP", "")).strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    node_env = str(os.environ.get("NODE_ENV", "")).strip().lower()
    deepline_env = str(os.environ.get("DEEPLINE_ENV", "")).strip().lower()
    return node_env == "development" or deepline_env in {"dev", "development"}


def _http_debug(message: str) -> None:
    if not _http_debug_enabled():
        return
    now = time.time()
    ts = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(now))
    frac = int((now % 1) * 1000)
    elapsed_ms = int((now - _HTTP_DEBUG_T0) * 1000)
    print(f"[deepline:http] {ts}.{frac:03d} +{elapsed_ms}ms {message}", file=sys.stderr, flush=True)


def build_tool_get_url(base_url: str, tool_id: str) -> str:
    encoded_tool_id = urllib.parse.quote(str(tool_id or "").strip(), safe="")
    return f"{base_url}/api/v2/integrations/{encoded_tool_id}/get"


def build_tool_execute_url(base_url: str, tool_id: str) -> str:
    encoded_tool_id = urllib.parse.quote(str(tool_id or "").strip(), safe="")
    return f"{base_url}/api/v2/integrations/{encoded_tool_id}/execute"


def _build_cli_user_agent() -> str:
    version = str(os.environ.get("DEEPLINE_CLI_VERSION", "") or "").strip()
    if version:
        return f"deepline-python-cli/{version}"
    return "deepline-python-cli"


def _rewrite_localhost_subdomain_url(url: str) -> tuple[str, str | None]:
    parsed = urllib.parse.urlparse(url)
    host = (parsed.hostname or "").strip().lower()
    if not host.endswith(".localhost"):
        return url, None

    original_netloc = parsed.netloc
    connect_host = "127.0.0.1"
    if parsed.port is not None:
        replacement_netloc = f"{connect_host}:{parsed.port}"
    else:
        replacement_netloc = connect_host

    rewritten = urllib.parse.urlunparse(
        (
            parsed.scheme,
            replacement_netloc,
            parsed.path,
            parsed.params,
            parsed.query,
            parsed.fragment,
        )
    )
    return rewritten, original_netloc


def _http_request_with_headers(
    method: str,
    url: str,
    token: str | None,
    payload: Dict[str, Any] | None = None,
    timeout: int = 60,
    connect_timeout: int | None = None,
    extra_headers: Dict[str, str] | None = None,
) -> HttpResponse:
    started = time.time()
    request_url, host_override = _rewrite_localhost_subdomain_url(url)
    parsed_url = urllib.parse.urlparse(request_url)
    debug_host = parsed_url.hostname or ""
    debug_path = parsed_url.path or "/"
    if parsed_url.query:
        debug_path = f"{debug_path}?{parsed_url.query}"
    _http_debug(
        f"request start method={method} host={debug_host} path={debug_path} "
        f"timeout={timeout} connect_timeout={connect_timeout if connect_timeout is not None else 'none'}"
    )
    headers = {
        "User-Agent": _build_cli_user_agent(),
        "Accept": "application/json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if isinstance(extra_headers, dict):
        for key, value in extra_headers.items():
            if not isinstance(key, str) or not key.strip():
                continue
            headers[key] = str(value)
    if host_override:
        headers["Host"] = host_override

    data = None
    if payload is not None:
        data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"

    if connect_timeout is not None:
        parsed = urllib.parse.urlparse(request_url)
        scheme = (parsed.scheme or "https").lower()
        host = parsed.hostname
        if not host:
            raise _network_runtime_error(f"Failed to reach API: invalid URL {url!r}")
        path = parsed.path or "/"
        if parsed.query:
            path = f"{path}?{parsed.query}"
        port = parsed.port
        conn_cls = http.client.HTTPSConnection if scheme == "https" else http.client.HTTPConnection
        if port is not None:
            conn = conn_cls(host, port, timeout=connect_timeout)
        else:
            conn = conn_cls(host, timeout=connect_timeout)
        try:
            conn.request(method, path, body=data, headers=headers)
            if conn.sock is not None:
                conn.sock.settimeout(timeout)
            response = conn.getresponse()
            body = response.read().decode("utf-8", errors="replace")
            response_headers = _normalize_response_headers(list(response.getheaders()))
            _http_debug(
                f"request done method={method} host={host} path={path} "
                f"status={int(response.status)} elapsed_ms={int((time.time() - started) * 1000)}"
            )
            return HttpResponse(status=int(response.status), body=body, headers=response_headers)
        except socket.timeout as exc:
            _http_debug(
                f"request timeout method={method} host={host} path={path} "
                f"elapsed_ms={int((time.time() - started) * 1000)} error={exc}"
            )
            raise _network_runtime_error(f"Failed to reach API: timeout ({exc})") from exc
        except OSError as exc:
            _http_debug(
                f"request os-error method={method} host={host} path={path} "
                f"elapsed_ms={int((time.time() - started) * 1000)} error={exc}"
            )
            raise _network_runtime_error(f"Failed to reach API: {exc}") from exc
        finally:
            try:
                conn.close()
            except Exception:
                pass

    req = urllib.request.Request(request_url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            body = response.read().decode("utf-8", errors="replace")
            response_headers = _normalize_response_headers(list(response.headers.items()))
            _http_debug(
                f"request done method={method} host={debug_host} path={debug_path} "
                f"status={int(response.status)} elapsed_ms={int((time.time() - started) * 1000)}"
            )
            return HttpResponse(status=int(response.status), body=body, headers=response_headers)
    except urllib.error.HTTPError as exc:
        _http_debug(
            f"request http-error method={method} host={debug_host} path={debug_path} "
            f"status={int(exc.code)} elapsed_ms={int((time.time() - started) * 1000)}"
        )
        body = exc.read().decode("utf-8", errors="replace") if exc.fp else ""
        response_headers = _normalize_response_headers(list(exc.headers.items()))
        return HttpResponse(status=int(exc.code), body=body, headers=response_headers)
    except (TimeoutError, socket.timeout) as exc:
        _http_debug(
            f"request timeout method={method} host={debug_host} path={debug_path} "
            f"elapsed_ms={int((time.time() - started) * 1000)} error={exc}"
        )
        raise _network_runtime_error(f"Failed to reach API: timeout ({exc})") from exc
    except urllib.error.URLError as exc:
        _http_debug(
            f"request url-error method={method} host={debug_host} path={debug_path} "
            f"elapsed_ms={int((time.time() - started) * 1000)} error={exc}"
        )
        raise _network_runtime_error(f"Failed to reach API: {exc}") from exc
    except OSError as exc:
        _http_debug(
            f"request os-error method={method} host={debug_host} path={debug_path} "
            f"elapsed_ms={int((time.time() - started) * 1000)} error={exc}"
        )
        raise _network_runtime_error(f"Failed to reach API: {exc}") from exc


def http_request(
    method: str,
    url: str,
    token: str | None,
    payload: Dict[str, Any] | None = None,
    timeout: int = 60,
    connect_timeout: int | None = None,
    extra_headers: Dict[str, str] | None = None,
) -> Tuple[int, str]:
    response = _http_request_with_headers(
        method,
        url,
        token,
        payload,
        timeout,
        connect_timeout,
        extra_headers,
    )
    return response.as_tuple()


def http_request_with_headers(
    method: str,
    url: str,
    token: str | None,
    payload: Dict[str, Any] | None = None,
    timeout: int = 20,
    connect_timeout: int | None = None,
    extra_headers: Dict[str, str] | None = None,
) -> HttpResponse:
    return _http_request_with_headers(
        method,
        url,
        token,
        payload,
        timeout,
        connect_timeout,
        extra_headers,
    )


def report_failure(
    base_url: str,
    token: str | None,
    command: str,
    run_id: str | None = None,
    error_status: int | None = None,
    error_body: str | None = None,
    payload_size_bytes: int | None = None,
    exit_code: int | None = None,
    duration_ms: int | None = None,
    error_class: str | None = None,
    stack_trace: str | None = None,
    subcommand: str | None = None,
    log_source: str | None = None,
    log_tail: str | None = None,
    failure_kind: str | None = None,
    failure_code: str | None = None,
    failure_stage: str | None = None,
    context: Dict[str, Any] | None = None,
) -> None:
    """Best-effort error beacon — fire and forget, never raises."""
    try:
        cli_version = os.environ.get("DEEPLINE_CLI_VERSION", "")
        beacon: Dict[str, Any] = {"command": command}
        if context and context.get("session_id"):
            beacon["session_id"] = context.get("session_id")
        else:
            try:
                from deepline_core.commands.session import _resolve_cli_session_id

                session_id = str(_resolve_cli_session_id() or "").strip()
                if session_id:
                    beacon["session_id"] = session_id
            except Exception:
                pass
        if run_id:
            beacon["run_id"] = str(run_id)[:200]
        if error_status is not None:
            beacon["error_status"] = error_status
        if error_body:
            beacon["error_body"] = error_body[:4000]
        if payload_size_bytes is not None:
            beacon["payload_size_bytes"] = payload_size_bytes
        if exit_code is not None:
            beacon["exit_code"] = exit_code
        if duration_ms is not None:
            beacon["duration_ms"] = duration_ms
        if error_class:
            beacon["error_class"] = error_class[:200]
        if stack_trace:
            beacon["stack_trace"] = stack_trace[:4000]
        if subcommand:
            beacon["subcommand"] = subcommand[:200]
        if log_source:
            beacon["log_source"] = log_source[:200]
        if log_tail:
            beacon["log_tail"] = log_tail[:4000]
        if failure_kind:
            beacon["failure_kind"] = failure_kind[:100]
        if failure_code:
            beacon["failure_code"] = failure_code[:200]
        if failure_stage:
            beacon["failure_stage"] = failure_stage[:200]
        if cli_version:
            beacon["cli_version"] = cli_version
        if context:
            beacon["context"] = context
        http_request("POST", f"{base_url}/api/v2/cli/report-failure", token, beacon, timeout=10)
    except Exception:
        pass  # fire and forget


def should_report_failure(status: int) -> bool:
    """Return True if the HTTP status warrants an error beacon."""
    return status in _REPORTABLE_STATUSES
