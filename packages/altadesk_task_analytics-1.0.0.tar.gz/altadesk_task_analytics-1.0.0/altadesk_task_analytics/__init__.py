from .task_analytics import TaskAnalytics

__version__ = "1.0.0"
__author__ = "X23219505"
