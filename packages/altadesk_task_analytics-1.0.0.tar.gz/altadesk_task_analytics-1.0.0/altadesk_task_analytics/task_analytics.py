from datetime import datetime, timezone, date
from typing import List, Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

# Priority weights used for score calculation
PRIORITY_WEIGHT = {"high": 3, "medium": 2, "low": 1}
URGENCY_THRESHOLD_DAYS = 3


class TaskAnalytics:
    
    def __init__(self, tasks: List[Dict[str, Any]]):
        if not isinstance(tasks, list):
            raise TypeError("tasks must be a list of dicts")
        self._tasks = tasks
        self._today = date.today()

    def get_priority_score(self, task_id: str) -> Optional[float]:
        # Combines priority weight with urgency multiplier
        task = self._find_task(task_id)
        if task is None:
            return None
        base = PRIORITY_WEIGHT.get(task.get("priority", "low"), 1)
        urgency = self._urgency_multiplier(task.get("deadline", ""))
        return round(base * urgency, 2)

    def get_sorted_tasks(self) -> List[Dict[str, Any]]:
        # Returns tasks sorted by highest priority score first
        def sort_key(task):
            base    = PRIORITY_WEIGHT.get(task.get("priority", "low"), 1)
            urgency = self._urgency_multiplier(task.get("deadline", ""))
            return base * urgency
        return sorted(self._tasks, key=sort_key, reverse=True)

    def get_overdue_tasks(self) -> List[Dict[str, Any]]:
        # Returns tasks past their deadline that are not done
        overdue = []
        for task in self._tasks:
            if task.get("status") == "done":
                continue
            days = self._days_remaining(task.get("deadline", ""))
            if days is not None and days < 0:
                overdue.append(task)
        return overdue

    def get_upcoming_tasks(self, within_days: int = 7) -> List[Dict[str, Any]]:
        # Returns tasks due within the specified number of days
        upcoming = []
        for task in self._tasks:
            if task.get("status") == "done":
                continue
            days = self._days_remaining(task.get("deadline", ""))
            if days is not None and 0 <= days <= within_days:
                upcoming.append({**task, "_days_remaining": days})
        upcoming.sort(key=lambda t: t["_days_remaining"])
        return upcoming

    def generate_report(self) -> Dict[str, Any]:
        # Generates a full analytics summary for the dashboard
        total = len(self._tasks)

        by_status = {"todo": 0, "in_progress": 0, "done": 0}
        for task in self._tasks:
            status = task.get("status", "todo")
            by_status[status] = by_status.get(status, 0) + 1

        by_priority = {"high": 0, "medium": 0, "low": 0}
        for task in self._tasks:
            p = task.get("priority", "low")
            by_priority[p] = by_priority.get(p, 0) + 1

        overdue    = self.get_overdue_tasks()
        done_count = by_status.get("done", 0)
        completion_rate = round((done_count / total * 100), 1) if total else 0.0

        scores = [self.get_priority_score(t["task_id"]) for t in self._tasks
                  if self.get_priority_score(t["task_id"]) is not None]
        avg_score = round(sum(scores) / len(scores), 2) if scores else 0.0

        return {
            "total":              total,
            "by_status":          by_status,
            "by_priority":        by_priority,
            "overdue_count":      len(overdue),
            "completion_rate":    completion_rate,
            "avg_priority_score": avg_score,
            "upcoming_7days":     self.get_upcoming_tasks(within_days=7),
            "generated_at":       datetime.now(timezone.utc).isoformat(),
        }

    @staticmethod
    def is_urgent(task: Dict[str, Any]) -> bool:
        if task.get("status") == "done":
            return False
        days = TaskAnalytics._days_remaining_static(task.get("deadline", ""))
        if days is None:
            return False
        return days <= URGENCY_THRESHOLD_DAYS

    @classmethod
    def from_raw_scan(cls, scan_response: Dict) -> "TaskAnalytics":
        items = scan_response.get("Items", [])
        return cls(items)

    def _find_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        for task in self._tasks:
            if task.get("task_id") == task_id:
                return task
        return None

    def _days_remaining(self, deadline_str: str) -> Optional[int]:
        return TaskAnalytics._days_remaining_static(deadline_str)

    @staticmethod
    def _days_remaining_static(deadline_str: str) -> Optional[int]:
        if not deadline_str:
            return None
        try:
            deadline_date = date.fromisoformat(deadline_str[:10])
            return (deadline_date - date.today()).days
        except ValueError:
            return None

    def _urgency_multiplier(self, deadline_str: str) -> float:
        # Multiplier increases as deadline approaches
        days = self._days_remaining(deadline_str)
        if days is None: return 1.0
        if days < 0:     return 3.0
        if days <= 3:    return 2.5
        if days <= 7:    return 2.0
        if days <= 14:   return 1.5
        return 1.0