# AltaDesk Task Analytics

A custom Python library for task prioritisation, deadline tracking and analytics.

## Installation

pip install altadesk-task-analytics

## Usage

from altadesk_task_analytics import TaskAnalytics

analytics = TaskAnalytics(tasks)
report = analytics.generate_report()
