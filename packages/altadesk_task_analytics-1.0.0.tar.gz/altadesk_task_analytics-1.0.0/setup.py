from setuptools import setup, find_packages

setup(
    name="altadesk-task-analytics",
    version="1.0.0",
    author="X23219505",
    author_email="x23219505@student.ncirl.ie",
    description="A task analytics library for AltaDesk cloud task management system",
    long_description="A custom Python library that provides task prioritisation, deadline tracking and analytics calculations for the AltaDesk cloud-based task management system.",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
