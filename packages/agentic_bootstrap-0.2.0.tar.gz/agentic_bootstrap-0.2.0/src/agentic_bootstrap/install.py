"""Minimal install flow for the agentic-bootstrap CLI.

This slice implements four responsibilities:

1. Clone (or fast-forward) ``<remote_url>`` at ``<remote_ref>`` into
   ``<target>/.agentic/remote/``.
2. Symlink the six known shared overlay surfaces from the clone into the
   consumer repo, preserving any pre-existing real local directory at the
   same path (overlay precedence: local wins per surface).
3. When ``mcp_servers`` is provided, configure the three consumer-tool
   surfaces — ``.mcp.json`` (Claude Code), ``.vscode/mcp.json`` (VS Code),
   and ``.codex/config.toml`` (Codex CLI) — by deep-merging or
   tomlkit-replacing only the managed entries while preserving everything
   else the user had configured.
4. When ``<target>`` is a git repo, point ``core.hooksPath`` at the
   materialized ``scripts/hooks`` symlink so git picks up shared hooks.
5. Write ``<target>/.agentic-overlay.json`` describing the resolved remote,
   the materialized surfaces, and the configs that were touched.

The ``doctor`` / ``repair`` / ``update`` / ``status`` subcommands land in
follow-on slices of E17-10 and are deliberately out of scope here.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Mapping

import tomlkit

OVERLAY_MANIFEST_NAME = ".agentic-overlay.json"
SCHEMA_VERSION = 1
CLONE_SUBDIR = (".agentic", "remote")

# In the agentic-protocol-monorepo, the shared agentic-system surfaces live
# under packages/agentic-system/ rather than at the clone root. We probe this
# subdirectory first when resolving a surface in the clone, and fall back to
# the clone root for legacy/hoisted overlay layouts (and for the
# fake_remote_with_surfaces fixture used elsewhere in the test suite).
AGENTIC_SYSTEM_SUBDIR = "packages/agentic-system"

# Shared overlay surfaces materialized as symlinks into ``.agentic/remote``.
# Plan 0002 step 1 (3/3): per-agent surfaces (.claude/skills, .claude/commands,
# .github/prompts, .codex/skills) are no longer canonical in the overlay
# clone — they are generated artifacts produced by
# generate_agent_workflows.py during install. Only the truly shared
# surfaces remain symlinked here.
SHARED_SURFACES: tuple[str, ...] = (
    ".github/hooks",
    "scripts/hooks",
    "docs/agentic/contracts",
)

# Per-agent surfaces written by the generator into the target as real
# directories (not symlinks). Bootstrap ensures these exist as real
# dirs before the generator runs; pre-existing symlinks pointing into
# .agentic/remote/ (left over from the legacy overlay model) are
# replaced. Recorded in the manifest with ``source: "generated"``.
GENERATED_SURFACES: tuple[str, ...] = (
    ".claude/commands",
    ".claude/skills",
    ".github/prompts",
    ".codex/skills",
)

# Path to the generator script inside the cloned overlay.
GENERATOR_SCRIPT = "scripts/generate_agent_workflows.py"
GENERATOR_MANIFEST = "config/agent-workflows/portable_commands.json"
GENERATOR_SKILLS_SOURCE = "skills"

# Built-in managed-server map (Plan 0002 step 2a). The two MCP servers
# the agentic-protocol-monorepo ships, both runnable via ``uvx``. Used
# when callers pass ``mcp_servers="default"`` or, in the CLI, when
# ``--mcp-servers`` is omitted and ``--no-mcp-servers`` is not set.
# Operators wanting a custom managed map keep providing a JSON file via
# ``--mcp-servers <path>``.
DEFAULT_MCP_SERVERS: dict[str, dict[str, Any]] = {
    "agent-handoff-mcp": {
        "command": "uvx",
        "args": ["mcp-agent-handoff"],
    },
    "agent-orchestrator-mcp": {
        "command": "uvx",
        "args": ["mcp-agent-orchestrator"],
    },
}


class BootstrapManifestValidationError(RuntimeError):
    """Raised when the install manifest fails the cross-repo wire-shape contract."""


class RemoteUrlMismatchError(RuntimeError):
    """Raised when an existing ``.agentic/remote`` clone tracks a different
    ``origin`` URL than the one passed to ``install``.

    Silently rewriting the manifest while leaving the on-disk clone pointed at
    the old origin would make ``.agentic-overlay.json`` lie about provenance
    (E17-10-BR13-H-01). Operators get an actionable error instead.
    """


def _git(*args: str, cwd: Path | None = None) -> str:
    """Run ``git`` with the given args, returning stripped stdout."""
    cmd = ["git"]
    if cwd is not None:
        cmd.extend(["-C", str(cwd)])
    cmd.extend(args)
    result = subprocess.run(
        cmd,
        check=True,
        capture_output=True,
        text=True,
        timeout=120,
    )
    return result.stdout.strip()


def _resolve_ref_to_sha(clone: Path, remote_ref: str) -> str:
    """Resolve ``remote_ref`` against the just-fetched clone, preferring the
    fresh remote-tracking branch over any stale local ref.

    Resolution order:

    1. ``refs/remotes/origin/<ref>`` — picks up freshly fetched branch tips
       (E17-10-BR13-M-01: avoids the stale local-branch trap that
       ``git checkout --detach <branch>`` falls into after ``fetch``).
    2. ``refs/tags/<ref>`` — tag refs.
    3. ``<ref>`` raw — last-resort for SHAs and exotic refspecs.
    """
    candidates = (
        f"refs/remotes/origin/{remote_ref}",
        f"refs/tags/{remote_ref}",
        remote_ref,
    )
    for candidate in candidates:
        try:
            return _git("rev-parse", "--verify", f"{candidate}^{{commit}}", cwd=clone)
        except subprocess.CalledProcessError:
            continue
    raise RuntimeError(
        f"could not resolve remote_ref {remote_ref!r} in {clone} "
        "(tried remote-tracking branch, tag, and raw ref)"
    )


def _resolve_in_clone(clone: Path, relpath: str) -> Path:
    """Resolve a surface/asset path against the clone.

    Probes ``<clone>/packages/agentic-system/<relpath>`` first (the
    agentic-protocol-monorepo layout) and falls back to ``<clone>/<relpath>``
    for legacy hoisted overlays. Returns the nested path when neither exists
    so callers can use ``.exists()`` as the discriminator.
    """
    nested = clone / AGENTIC_SYSTEM_SUBDIR / relpath
    if nested.exists():
        return nested
    root = clone / relpath
    if root.exists():
        return root
    return nested


def _materialize_surfaces(target: Path, clone: Path) -> list[dict[str, str]]:
    """Symlink each known shared surface from ``clone`` into ``target``.

    Per-surface behavior:

    - Surface absent in the clone: skip silently. Not recorded in the manifest.
    - Surface absent in target: create the parent directory if needed, then
      ``symlink`` ``target/<surface> -> ../...../.agentic/remote/<surface>``
      using a relative target. Recorded as ``source='shared'``.
    - Target already a symlink into our clone: leave it; recorded as
      ``source='shared'`` (idempotent rerun path).
    - Target already a symlink pointing elsewhere (foreign symlink): leave it
      untouched; recorded as ``source='local'`` so overlay precedence is
      honored.
    - Target already a real file or directory: leave it untouched; recorded as
      ``source='local'``.
    """
    materialized: list[dict[str, str]] = []
    clone_resolved = clone.resolve()

    for surface in SHARED_SURFACES:
        remote_path = _resolve_in_clone(clone, surface)
        target_path = target / surface

        if not remote_path.exists():
            continue

        if target_path.is_symlink():
            try:
                resolved = target_path.resolve(strict=False)
            except OSError:
                resolved = None
            points_into_clone = (
                resolved is not None
                and (
                    resolved == remote_path.resolve()
                    or str(resolved).startswith(str(clone_resolved) + os.sep)
                )
            )
            if points_into_clone:
                materialized.append({"path": surface, "source": "shared"})
                continue
            # Foreign symlink — local content takes precedence.
            materialized.append({"path": surface, "source": "local"})
            continue

        if target_path.exists():
            materialized.append({"path": surface, "source": "local"})
            continue

        target_path.parent.mkdir(parents=True, exist_ok=True)
        rel = os.path.relpath(remote_path, target_path.parent)
        target_path.symlink_to(rel, target_is_directory=True)
        materialized.append({"path": surface, "source": "shared"})

    return materialized


def _prepare_generated_surfaces(target: Path, clone: Path) -> list[dict[str, str]]:
    """Ensure each per-agent generated surface exists as a real directory.

    Pre-existing symlinks pointing into the clone (left over from the
    pre-Plan-0002 overlay model where these surfaces were shared
    symlinks) are replaced with empty directories so the generator can
    write into them. Pre-existing real local content is preserved —
    the operator may have intentionally placed local overrides there;
    the generator's per-file write logic will only replace the files
    it owns.
    """
    materialized: list[dict[str, str]] = []
    clone_resolved = clone.resolve()

    for surface in GENERATED_SURFACES:
        target_path = target / surface

        if target_path.is_symlink():
            try:
                resolved = target_path.resolve(strict=False)
            except OSError:
                resolved = None
            points_into_clone = (
                resolved is not None
                and str(resolved).startswith(str(clone_resolved) + os.sep)
            )
            broken = resolved is not None and not target_path.exists()
            if points_into_clone or broken:
                # Legacy overlay symlink, or a dangling symlink whose
                # target is gone — replace with a real directory so the
                # generator can write into it. (A dangling symlink also
                # blocks the mkdir below, since lexists() is True.)
                target_path.unlink()
                target_path.mkdir(parents=True, exist_ok=True)
            # Foreign live symlinks are left alone (operator chose them);
            # the generator will write through them into wherever they point.

        elif not target_path.exists():
            target_path.mkdir(parents=True, exist_ok=True)

        materialized.append({"path": surface, "source": "generated"})

    return materialized


def _run_generator(target: Path, clone: Path) -> None:
    """Invoke the agent-workflow generator against the target.

    Uses the generator + manifest + skills source from the overlay
    clone. Writes per-agent surfaces into the target via the
    generator's ``--target`` convenience flag.
    """
    generator_script = _resolve_in_clone(clone, GENERATOR_SCRIPT)
    manifest_path = _resolve_in_clone(clone, GENERATOR_MANIFEST)
    skills_source = _resolve_in_clone(clone, GENERATOR_SKILLS_SOURCE)

    if not generator_script.is_file():
        # Older overlays don't ship the generator (Plan 0002 introduced it).
        # That's acceptable when bootstrapping from a legacy ref; emit
        # nothing rather than fail.
        return

    cmd = [
        sys.executable,
        str(generator_script),
        "--manifest",
        str(manifest_path),
        "--skills-source-root",
        str(skills_source),
        "--target",
        str(target),
    ]
    subprocess.run(cmd, check=True, cwd=str(clone), timeout=120)


def install(
    *,
    target: Path,
    remote_url: str,
    remote_ref: str,
    mcp_servers: Mapping[str, Mapping[str, Any]] | str | None = None,
    enforce_required_surfaces: bool = False,
) -> dict[str, object]:
    """Clone the shared agentic-system remote, materialize overlay surfaces,
    write consumer-tool configs, and write the overlay manifest.

    Args:
        target: Consumer repository root. Must already exist.
        remote_url: Git URL for the shared agentic-system remote.
        remote_ref: Tag, branch, or SHA to check out (e.g. ``"v0.1.0"``).
        mcp_servers: Mapping of ``<server_name> -> {command, args, env}`` to
            register in ``.mcp.json``, ``.vscode/mcp.json``, and
            ``.codex/config.toml``. Pass the sentinel string ``"default"``
            to use :data:`DEFAULT_MCP_SERVERS` (the two MCP servers shipped
            by this monorepo). When ``None``, the three file-writers are
            skipped. ``core.hooksPath`` is set independently whenever the
            target is a git repo.

    Returns:
        The manifest dict that was written to ``<target>/.agentic-overlay.json``.

    Raises:
        FileNotFoundError: ``target`` does not exist.
        FileExistsError: ``<target>/.agentic/remote`` exists but is not a git clone.
        RemoteUrlMismatchError: existing clone tracks a different ``origin`` URL.
        subprocess.CalledProcessError: ``git`` command failed.
    """
    target = Path(target).resolve()
    if not target.is_dir():
        raise FileNotFoundError(f"target directory does not exist: {target}")

    if isinstance(mcp_servers, str):
        if mcp_servers != "default":
            raise ValueError(
                f"mcp_servers={mcp_servers!r} is not a recognized sentinel; "
                "pass a mapping, the literal 'default', or None."
            )
        mcp_servers = DEFAULT_MCP_SERVERS

    clone = target.joinpath(*CLONE_SUBDIR)

    if (clone / ".git").exists():
        existing_origin = _git("remote", "get-url", "origin", cwd=clone)
        if existing_origin != remote_url:
            raise RemoteUrlMismatchError(
                f"{clone} already tracks origin {existing_origin!r}, "
                f"but install was called with remote_url={remote_url!r}. "
                "Move or remove .agentic/remote (or pass the original URL) to "
                "switch overlays."
            )
        _git("fetch", "--tags", "--prune", "--force", "origin", cwd=clone)
    else:
        clone.parent.mkdir(parents=True, exist_ok=True)
        if clone.exists():
            raise FileExistsError(
                f"{clone} exists but is not a git clone. "
                "Move or remove it before re-running install."
            )
        _git("clone", "--branch", remote_ref, remote_url, str(clone))

    sha = _resolve_ref_to_sha(clone, remote_ref)
    if len(sha) != 40:
        raise RuntimeError(f"unexpected sha shape from git rev-parse: {sha!r}")

    _git("checkout", "--detach", sha, cwd=clone)

    surfaces = _materialize_surfaces(target, clone)
    surfaces.extend(_prepare_generated_surfaces(target, clone))
    _run_generator(target, clone)
    configs = _write_configs(target, mcp_servers)

    manifest: dict[str, object] = {
        "schema_version": SCHEMA_VERSION,
        "remote_url": remote_url,
        "remote_ref": remote_ref,
        "remote_sha": sha,
        "surfaces": surfaces,
        "configs": configs,
    }

    # Wire-shape validation: refuse to write a manifest that does not
    # validate against agentic_protocol.BootstrapManifest. This is the
    # install-time schema check called for in founding plan 0001.
    # When agentic-protocol is not installed (partial migrations), we
    # warn but still write — the manifest contract is best-effort
    # until the protocol is mandatory.
    try:
        from agentic_protocol import BootstrapManifest  # type: ignore[import-not-found]

        BootstrapManifest.model_validate(manifest)
    except ImportError:
        pass
    except Exception as exc:  # noqa: BLE001
        raise BootstrapManifestValidationError(
            f"refusing to write {OVERLAY_MANIFEST_NAME}: agentic_protocol.BootstrapManifest "
            f"validation failed: {exc}"
        ) from exc

    # Required-surfaces refusal: founding plan 0001 calls for bootstrap
    # to refuse install when required hooks are missing, so consumers
    # cannot end up with a half-installed harness. We require the
    # scripts/hooks surface to be materialized; without it, target-side
    # guardrails (worktree drift, rationale guard, etc.) silently no-op.
    materialized_paths = {entry["path"] for entry in surfaces if isinstance(entry, dict)}
    if enforce_required_surfaces and "scripts/hooks" not in materialized_paths:
        raise BootstrapManifestValidationError(
            "refusing to declare install successful: required surface 'scripts/hooks' "
            "was not materialized. Bootstrap-installed hooks are part of the harness "
            "contract; without them, target-side guardrails do not run. "
            "Set enforce_required_surfaces=False to bypass for non-standard remotes."
        )

    manifest_path = target / OVERLAY_MANIFEST_NAME
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

    return manifest


# ---------------------------------------------------------------------------
# Config writers
# ---------------------------------------------------------------------------


HOOKS_PATH_VALUE = "scripts/hooks"


def _deep_merge(dst: dict[str, Any], src: Mapping[str, Any]) -> dict[str, Any]:
    """Recursively merge ``src`` into ``dst`` and return ``dst``.

    Dict-into-dict merges recurse. Any non-dict value in ``src`` (including
    lists) replaces the corresponding key in ``dst`` outright — list-concat
    semantics would silently grow user config across reruns.
    """
    for key, value in src.items():
        existing = dst.get(key)
        if isinstance(existing, dict) and isinstance(value, Mapping):
            _deep_merge(existing, value)
        elif isinstance(value, Mapping):
            new_dict: dict[str, Any] = {}
            _deep_merge(new_dict, value)
            dst[key] = new_dict
        else:
            dst[key] = value
    return dst


def _write_configs(
    target: Path, mcp_servers: Mapping[str, Mapping[str, Any]] | None
) -> list[dict[str, str]]:
    """Run the four post-install config writers and return per-surface entries
    suitable for ``manifest['configs']``.

    The three file-writers run only when ``mcp_servers`` is provided. The git
    ``core.hooksPath`` writer runs whenever the target looks like a git repo.
    """
    entries: list[dict[str, str]] = []

    if mcp_servers:
        entries.append(_write_mcp_json(target, mcp_servers))
        entries.append(_write_vscode_mcp_json(target, mcp_servers))
        entries.append(_write_codex_config(target, mcp_servers))

    hooks_entry = _set_git_hooks_path(target)
    if hooks_entry is not None:
        entries.append(hooks_entry)

    return entries


def _write_mcp_json(
    target: Path, mcp_servers: Mapping[str, Mapping[str, Any]]
) -> dict[str, str]:
    """Deep-merge managed servers into ``<target>/.mcp.json`` under
    ``mcpServers``. Preserves all other keys and other servers."""
    path = target / ".mcp.json"
    existed = path.exists()
    doc: dict[str, Any] = json.loads(path.read_text()) if existed else {}
    incoming = {"mcpServers": {name: dict(spec) for name, spec in mcp_servers.items()}}
    _deep_merge(doc, incoming)
    path.write_text(json.dumps(doc, indent=2) + "\n")
    return {"path": ".mcp.json", "action": "merged" if existed else "created"}


def _write_vscode_mcp_json(
    target: Path, mcp_servers: Mapping[str, Mapping[str, Any]]
) -> dict[str, str]:
    """Deep-merge managed servers into ``<target>/.vscode/mcp.json`` under
    ``servers``. Creates the ``.vscode`` directory if absent."""
    path = target / ".vscode" / "mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    existed = path.exists()
    doc: dict[str, Any] = json.loads(path.read_text()) if existed else {}
    incoming = {"servers": {name: dict(spec) for name, spec in mcp_servers.items()}}
    _deep_merge(doc, incoming)
    path.write_text(json.dumps(doc, indent=2) + "\n")
    return {"path": ".vscode/mcp.json", "action": "merged" if existed else "created"}


def _write_codex_config(
    target: Path, mcp_servers: Mapping[str, Mapping[str, Any]]
) -> dict[str, str]:
    """Replace the ``[mcp_servers.<name>]`` tables in
    ``<target>/.codex/config.toml`` for each managed server, leaving every
    other root key, table, and comment untouched (tomlkit round-trip)."""
    path = target / ".codex" / "config.toml"
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.exists():
        doc = tomlkit.parse(path.read_text())
        action = "merged"
    else:
        doc = tomlkit.document()
        action = "created"

    if "mcp_servers" not in doc:
        doc["mcp_servers"] = tomlkit.table(is_super_table=True)
    servers_table = doc["mcp_servers"]

    for name, spec in mcp_servers.items():
        new_table = tomlkit.table()
        for spec_key, spec_value in spec.items():
            new_table[spec_key] = spec_value
        servers_table[name] = new_table

    path.write_text(tomlkit.dumps(doc))
    return {"path": ".codex/config.toml", "action": action}


def _set_git_hooks_path(target: Path) -> dict[str, str] | None:
    """If ``target`` is a git repo, set ``core.hooksPath`` to the materialized
    ``scripts/hooks`` symlink and return a manifest entry. Otherwise return
    ``None`` (silent skip)."""
    if not (target / ".git").exists():
        return None
    _git("config", "core.hooksPath", HOOKS_PATH_VALUE, cwd=target)
    return {"path": "core.hooksPath", "action": "set"}


