"""agentic-bootstrap: hoist the shared agentic-system surface into consumer repos."""

from agentic_bootstrap.install import install

__all__ = ["install"]
__version__ = "0.2.0.dev0"
