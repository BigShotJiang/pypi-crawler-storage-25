"""Console entrypoint for ``agentic-bootstrap``."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Mapping

from agentic_bootstrap.install import DEFAULT_MCP_SERVERS, install
from agentic_bootstrap.subcommands import doctor, repair, status, update


def _resolve_mcp_servers(
    raw: str | None,
    *,
    no_servers: bool = False,
    default_when_unset: bool = False,
) -> Mapping[str, Mapping[str, Any]] | None:
    """Resolve the ``--mcp-servers`` argument into a server map (or None).

    - ``no_servers=True``: explicit opt-out → ``None`` (no config files written).
    - ``raw is None``: behavior depends on ``default_when_unset``. ``install``
      passes ``True`` so an unset flag falls back to :data:`DEFAULT_MCP_SERVERS`
      (Plan 0002 step 2a — single-command, no-hand-edits install). ``doctor`` /
      ``update`` / ``repair`` pass ``False`` so an unset flag means
      "don't check / refresh configs at all".
    - ``raw == "default"``: use :data:`DEFAULT_MCP_SERVERS`.
    - ``raw`` is a path: load JSON. Accepts ``{"mcpServers": {...}}`` or a
      flat mapping.
    """
    if no_servers:
        return None
    if raw is None:
        return DEFAULT_MCP_SERVERS if default_when_unset else None
    if raw == "default":
        return DEFAULT_MCP_SERVERS
    doc = json.loads(Path(raw).read_text())
    if isinstance(doc, dict) and "mcpServers" in doc:
        return doc["mcpServers"]
    return doc


DEFAULT_REMOTE_URL = "git@github.com:darce/agentic-protocol-monorepo.git"
DEFAULT_REMOTE_REF = "main"


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentic-bootstrap",
        description=(
            "Hoist the shared agentic-system surface into a consumer repo. "
            "Future subcommands: doctor, repair, update."
        ),
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_install = sub.add_parser(
        "install",
        help="Clone the shared agentic-system remote and write the overlay manifest.",
    )
    p_install.add_argument(
        "--target",
        type=Path,
        required=True,
        help="Consumer repository root. Must already exist.",
    )
    p_install.add_argument(
        "--remote-url",
        default=DEFAULT_REMOTE_URL,
        help=f"Git URL for the shared agentic-system remote (default: {DEFAULT_REMOTE_URL}).",
    )
    p_install.add_argument(
        "--remote-ref",
        default=DEFAULT_REMOTE_REF,
        help=f"Tag or branch to check out (default: {DEFAULT_REMOTE_REF}).",
    )
    p_install.add_argument(
        "--mcp-servers",
        default=None,
        help=(
            "Either the literal 'default' (or omit the flag) to register the "
            "monorepo's two managed MCP servers (mcp-agent-handoff, "
            "mcp-agent-orchestrator) via uvx, or a path to a JSON file "
            "carrying a custom mapping. Accepts {\"mcpServers\": {...}} or a "
            "flat mapping. Writes .mcp.json / .vscode/mcp.json / "
            ".codex/config.toml. Use --no-mcp-servers to opt out entirely."
        ),
    )
    p_install.add_argument(
        "--no-mcp-servers",
        action="store_true",
        help=(
            "Opt out of writing .mcp.json / .vscode/mcp.json / "
            ".codex/config.toml. Use when bootstrapping a target that manages "
            "MCP servers separately."
        ),
    )
    p_install.add_argument(
        "--no-enforce-required-surfaces",
        action="store_true",
        help=(
            "Skip the required-surfaces refusal (currently scripts/hooks). "
            "Use only when bootstrapping from a non-standard remote that "
            "intentionally does not ship the harness hooks; the default is "
            "to refuse install in that case so target-side guardrails cannot "
            "silently no-op."
        ),
    )

    p_status = sub.add_parser(
        "status",
        help="Print a summary of the installed overlay manifest.",
    )
    p_status.add_argument(
        "--target",
        type=Path,
        required=True,
        help="Consumer repository root that was previously installed.",
    )

    p_doctor = sub.add_parser(
        "doctor",
        help="Check the installed overlay for drift. Exit 1 when findings exist.",
    )
    p_doctor.add_argument(
        "--target",
        type=Path,
        required=True,
        help="Consumer repository root that was previously installed.",
    )
    p_doctor.add_argument(
        "--mcp-servers",
        default=None,
        help=(
            "Either 'default' for the monorepo's managed-server map, or a "
            "path to a JSON file. When set, config drift is checked."
        ),
    )

    p_update = sub.add_parser(
        "update",
        help="Re-run install at a new remote ref against an existing overlay.",
    )
    p_update.add_argument(
        "--target",
        type=Path,
        required=True,
        help="Consumer repository root that was previously installed.",
    )
    p_update.add_argument(
        "--remote-ref",
        required=True,
        help="New git ref (tag/branch/sha) to update the overlay to.",
    )
    p_update.add_argument(
        "--remote-url",
        default=None,
        help="Override remote URL. Defaults to the value in the existing manifest.",
    )
    p_update.add_argument(
        "--mcp-servers",
        default=None,
        help=(
            "Either 'default' for the monorepo's managed-server map, or a "
            "path to a JSON file. When set, configs are refreshed."
        ),
    )

    p_repair = sub.add_parser(
        "repair",
        help="Restore drifted overlay surfaces flagged by `doctor`.",
    )
    p_repair.add_argument(
        "--target",
        type=Path,
        required=True,
        help="Consumer repository root that was previously installed.",
    )
    p_repair.add_argument(
        "--force-dirty",
        action="store_true",
        help=(
            "Replace surfaces that contain real local content. "
            "Without this flag, dirty surfaces are skipped (rg-017)."
        ),
    )
    p_repair.add_argument(
        "--mcp-servers",
        default=None,
        help=(
            "Either 'default' for the monorepo's managed-server map, or a "
            "path to a JSON file. When set, config drift is also repaired."
        ),
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "install":
        manifest = install(
            target=args.target,
            remote_url=args.remote_url,
            remote_ref=args.remote_ref,
            mcp_servers=_resolve_mcp_servers(
                args.mcp_servers,
                no_servers=args.no_mcp_servers,
                default_when_unset=True,
            ),
            enforce_required_surfaces=not args.no_enforce_required_surfaces,
        )
        print(
            f"installed agentic-system overlay: "
            f"{args.remote_url}@{manifest['remote_sha']} -> {args.target}",
            file=sys.stdout,
        )
        return 0

    if args.command == "status":
        try:
            summary = status(target=args.target)
        except FileNotFoundError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        sys.stdout.write(summary)
        return 0

    if args.command == "doctor":
        try:
            findings = doctor(
                target=args.target,
                mcp_servers=_resolve_mcp_servers(args.mcp_servers),
            )
        except FileNotFoundError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        if not findings:
            print("doctor: no drift detected.", file=sys.stdout)
            return 0
        for f in findings:
            print(f"{f['kind']}: {f['path']}", file=sys.stdout)
        return 1

    if args.command == "update":
        try:
            manifest = update(
                target=args.target,
                remote_ref=args.remote_ref,
                remote_url=args.remote_url,
                mcp_servers=_resolve_mcp_servers(args.mcp_servers),
            )
        except FileNotFoundError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        print(
            f"update: refreshed overlay at {manifest['remote_ref']} "
            f"(sha={manifest['remote_sha'][:12]}).",
            file=sys.stdout,
        )
        return 0

    if args.command == "repair":
        try:
            report = repair(
                target=args.target,
                force_dirty=args.force_dirty,
                mcp_servers=_resolve_mcp_servers(args.mcp_servers),
            )
        except FileNotFoundError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        for f in report["repaired"]:
            print(f"repaired {f['kind']}: {f['path']}", file=sys.stdout)
        for f in report["skipped"]:
            print(
                f"skipped {f['kind']}: {f['path']} "
                "(re-run with --force-dirty to overwrite)",
                file=sys.stdout,
            )
        if not report["repaired"] and not report["skipped"]:
            print("repair: no drift detected.", file=sys.stdout)
        return 0

    # argparse with required=True prevents this branch from being reachable.
    parser.error(f"unknown command: {args.command!r}")
    return 2  # pragma: no cover


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
