"""Allow ``python -m agentic_bootstrap``."""

from agentic_bootstrap.cli import main

raise SystemExit(main())
