"""Post-install subcommands: status / doctor / update / repair.

Each subcommand is a small library function with a clear contract:

- ``status(target)`` returns a human-readable summary of the overlay manifest.
- ``doctor(target, mcp_servers=None)`` returns a list of drift findings.
- ``update(target, remote_ref, ...)`` (future slice) re-runs install at a new ref.
- ``repair(target, ..., force_dirty)`` (future slice) rewrites drifted overlays.

The CLI in ``agentic_bootstrap.cli`` is a thin argparse wrapper over these.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Mapping

from agentic_bootstrap.install import (
    CLONE_SUBDIR,
    GENERATED_SURFACES,
    GENERATOR_MANIFEST,
    GENERATOR_SCRIPT,
    GENERATOR_SKILLS_SOURCE,
    OVERLAY_MANIFEST_NAME,
    SHARED_SURFACES,
)


def _load_manifest(target: Path) -> dict[str, object]:
    manifest_path = target / OVERLAY_MANIFEST_NAME
    if not manifest_path.is_file():
        raise FileNotFoundError(
            f"{manifest_path} not found. Run `agentic-bootstrap install --target "
            f"{target}` first."
        )
    return json.loads(manifest_path.read_text())


def status(*, target: Path) -> str:
    """Return a multi-line human-readable summary of the overlay manifest at
    ``<target>/.agentic-overlay.json``.

    Raises ``FileNotFoundError`` when the manifest is absent.
    """
    target = Path(target).resolve()
    manifest = _load_manifest(target)

    surfaces = manifest.get("surfaces", []) or []
    configs = manifest.get("configs", []) or []
    shared = sum(1 for s in surfaces if s.get("source") == "shared")
    local = sum(1 for s in surfaces if s.get("source") == "local")
    generated = sum(1 for s in surfaces if s.get("source") == "generated")

    lines = [
        f"agentic-bootstrap overlay at {target}",
        f"  remote_url:  {manifest.get('remote_url')}",
        f"  remote_ref:  {manifest.get('remote_ref')}",
        f"  remote_sha:  {manifest.get('remote_sha')}",
        f"  surfaces:    {len(surfaces)} ({shared} shared, {local} local, {generated} generated)",
        f"  configs:     {len(configs)}",
    ]
    for entry in configs:
        lines.append(f"    - {entry.get('path')} ({entry.get('action')})")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


Finding = dict[str, str]


def doctor(
    *,
    target: Path,
    mcp_servers: Mapping[str, Mapping[str, Any]] | None = None,
) -> list[Finding]:
    """Return a list of drift findings for the overlay at ``target``.

    Each finding is a dict with at least ``kind`` and ``path``. Recognized
    kinds:

    - ``missing_manifest`` — ``.agentic-overlay.json`` is gone.
    - ``missing_clone`` — ``.agentic/remote/.git`` is gone.
    - ``surface_drift`` — a surface recorded as ``shared`` in the manifest is
      no longer a symlink resolving into the clone.
    - ``generated_drift`` — a surface recorded as ``generated`` differs from
      what ``scripts/generate_agent_workflows.py`` would write today. Detected
      by re-running the generator in ``--check`` mode against the target.
    - ``config_drift`` — a managed MCP server in ``mcp_servers`` is no longer
      present (or no longer matches) in ``.mcp.json`` / ``.vscode/mcp.json``.
      Only checked when ``mcp_servers`` is provided.

    Returns an empty list when everything is clean.
    """
    target = Path(target).resolve()
    findings: list[Finding] = []

    manifest_path = target / OVERLAY_MANIFEST_NAME
    if not manifest_path.is_file():
        findings.append(
            {"kind": "missing_manifest", "path": OVERLAY_MANIFEST_NAME}
        )
        return findings

    manifest = json.loads(manifest_path.read_text())
    clone = target.joinpath(*CLONE_SUBDIR)
    clone_resolved = clone.resolve(strict=False)

    if not (clone / ".git").exists():
        findings.append(
            {"kind": "missing_clone", "path": "/".join(CLONE_SUBDIR)}
        )

    surfaces = manifest.get("surfaces") or []
    for entry in surfaces:
        if entry.get("source") != "shared":
            continue
        surface = entry.get("path", "")
        link = target / surface
        if not link.is_symlink():
            findings.append({"kind": "surface_drift", "path": surface})
            continue
        try:
            resolved = link.resolve(strict=False)
        except OSError:
            findings.append({"kind": "surface_drift", "path": surface})
            continue
        in_clone = (
            resolved == (clone / surface).resolve(strict=False)
            or str(resolved).startswith(str(clone_resolved) + os.sep)
        )
        if not in_clone:
            findings.append({"kind": "surface_drift", "path": surface})

    findings.extend(_doctor_generated_surfaces(target, clone, manifest))

    if mcp_servers:
        for entry in manifest.get("configs") or []:
            path = entry.get("path", "")
            if path == ".mcp.json":
                _check_json_servers(
                    target / path, "mcpServers", mcp_servers, path, findings
                )
            elif path == ".vscode/mcp.json":
                _check_json_servers(
                    target / path, "servers", mcp_servers, path, findings
                )

    return findings


def _doctor_generated_surfaces(
    target: Path, clone: Path, manifest: dict[str, object]
) -> list[Finding]:
    """Detect drift in per-agent generated surfaces.

    Runs ``scripts/generate_agent_workflows.py --check --target <target>``
    against the target. Each ``drift detected: <path>`` line in the
    generator's stderr is mapped back to the manifest's ``generated``
    surface that owns it; one ``generated_drift`` finding per affected
    surface (deduplicated). Silent when no generated surfaces are recorded
    (legacy manifests) or the generator script is missing from the clone
    (older overlay refs that pre-date Plan 0002).
    """
    import subprocess
    import sys

    surfaces = manifest.get("surfaces") or []
    generated_surfaces = [
        str(entry.get("path", ""))
        for entry in surfaces
        if entry.get("source") == "generated" and entry.get("path")
    ]
    if not generated_surfaces:
        return []

    from agentic_bootstrap.install import _resolve_in_clone

    generator_script = _resolve_in_clone(clone, GENERATOR_SCRIPT)
    manifest_path = _resolve_in_clone(clone, GENERATOR_MANIFEST)
    skills_source = _resolve_in_clone(clone, GENERATOR_SKILLS_SOURCE)
    if not generator_script.is_file() or not manifest_path.is_file():
        return []

    try:
        proc = subprocess.run(
            [
                sys.executable,
                str(generator_script),
                "--manifest",
                str(manifest_path),
                "--skills-source-root",
                str(skills_source),
                "--target",
                str(target),
                "--check",
            ],
            cwd=str(clone),
            capture_output=True,
            text=True,
            timeout=120,
        )
    except (OSError, subprocess.TimeoutExpired):
        # Generator unavailable / hung — surface as a single coarse finding
        # rather than crashing doctor.
        return [
            {"kind": "generated_drift", "path": surface}
            for surface in generated_surfaces
        ]

    if proc.returncode == 0:
        return []

    # Parse "drift detected: <abs path>" lines and map each back to the
    # manifest surface whose target-relative path it sits under.
    drifted: set[str] = set()
    for line in (proc.stderr or "").splitlines():
        line = line.strip()
        if not line.startswith("drift detected:"):
            continue
        drifted_path = line.split(":", 1)[1].strip()
        try:
            rel = Path(drifted_path).resolve().relative_to(target)
        except (ValueError, OSError):
            continue
        rel_str = str(rel)
        for surface in generated_surfaces:
            if rel_str == surface or rel_str.startswith(surface.rstrip("/") + "/"):
                drifted.add(surface)
                break

    if not drifted:
        # Generator reported failure but we couldn't map any path. Flag
        # all generated surfaces coarsely so the operator knows there's
        # work to do.
        drifted.update(generated_surfaces)

    return [{"kind": "generated_drift", "path": surface} for surface in sorted(drifted)]


def _check_json_servers(
    file_path: Path,
    top_key: str,
    expected: Mapping[str, Mapping[str, Any]],
    rel_path: str,
    findings: list[Finding],
) -> None:
    if not file_path.is_file():
        findings.append({"kind": "config_drift", "path": rel_path})
        return
    try:
        doc = json.loads(file_path.read_text())
    except json.JSONDecodeError:
        findings.append({"kind": "config_drift", "path": rel_path})
        return
    actual = doc.get(top_key) or {}
    for name, spec in expected.items():
        current = actual.get(name)
        if current != dict(spec):
            findings.append({"kind": "config_drift", "path": rel_path})
            return


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


def update(
    *,
    target: Path,
    remote_ref: str,
    remote_url: str | None = None,
    mcp_servers: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, object]:
    """Re-run ``install`` against ``target`` at a new ``remote_ref``.

    ``remote_url`` defaults to whatever the current manifest already records,
    so callers don't need to repeat it. ``mcp_servers`` is forwarded so config
    surfaces are also refreshed when supplied.
    """
    from agentic_bootstrap.install import install

    target = Path(target).resolve()
    manifest = _load_manifest(target)
    if remote_url is None:
        remote_url = str(manifest["remote_url"])

    return install(
        target=target,
        remote_url=remote_url,
        remote_ref=remote_ref,
        mcp_servers=mcp_servers,
    )


# ---------------------------------------------------------------------------
# repair
# ---------------------------------------------------------------------------


def repair(
    *,
    target: Path,
    force_dirty: bool = False,
    mcp_servers: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, list[Finding]]:
    """Restore drifted overlay surfaces flagged by :func:`doctor`.

    For each surface flagged as ``surface_drift``:

    - If the path no longer exists or is a broken/foreign symlink, the
      canonical symlink into the clone is recreated.
    - If the path has been replaced by a real directory or file, the surface
      is **skipped** unless ``force_dirty=True`` (per regression guard rg-017
      "never silently force-remove dirty content"). With ``force_dirty=True``
      the dirty content is removed and the symlink reinstated.

    Config drift (``.mcp.json`` / ``.vscode/mcp.json``) is repaired by
    re-running the install-time writers when ``mcp_servers`` is supplied.

    Returns a report dict ``{"repaired": [...], "skipped": [...]}`` whose
    entries reuse the :func:`doctor` finding shape.
    """
    from agentic_bootstrap.install import (
        _run_generator,
        _set_git_hooks_path,
        _write_codex_config,
        _write_mcp_json,
        _write_vscode_mcp_json,
    )
    import shutil

    target = Path(target).resolve()
    findings = doctor(target=target, mcp_servers=mcp_servers)
    repaired: list[Finding] = []
    skipped: list[Finding] = []

    if not findings:
        return {"repaired": repaired, "skipped": skipped}

    clone = target.joinpath(*CLONE_SUBDIR)

    for finding in findings:
        kind = finding["kind"]
        path = finding["path"]

        if kind == "surface_drift":
            from agentic_bootstrap.install import _resolve_in_clone

            link = target / path
            remote_path = _resolve_in_clone(clone, path)
            if not remote_path.exists():
                skipped.append(finding)
                continue

            if link.is_symlink() or not link.exists():
                # Broken/foreign symlink or missing entirely: safe to replace.
                if link.is_symlink():
                    link.unlink()
            elif link.is_dir() and any(link.iterdir()):
                if not force_dirty:
                    skipped.append(finding)
                    continue
                shutil.rmtree(link)
            elif link.is_dir():
                link.rmdir()
            else:
                if not force_dirty:
                    skipped.append(finding)
                    continue
                link.unlink()

            link.parent.mkdir(parents=True, exist_ok=True)
            rel = os.path.relpath(remote_path, link.parent)
            link.symlink_to(rel, target_is_directory=True)
            repaired.append(finding)
            continue

        if kind == "generated_drift":
            # Re-run the generator once for the whole batch — it rewrites
            # every per-agent surface from the canonical source. Collapse
            # subsequent generated_drift findings into the same repair op.
            if any(f["kind"] == "generated_drift" for f in repaired):
                repaired.append(finding)
                continue
            try:
                _run_generator(target, clone)
            except Exception:
                skipped.append(finding)
                continue
            repaired.append(finding)
            continue

        if kind == "config_drift" and mcp_servers:
            if path == ".mcp.json":
                _write_mcp_json(target, mcp_servers)
                repaired.append(finding)
            elif path == ".vscode/mcp.json":
                _write_vscode_mcp_json(target, mcp_servers)
                repaired.append(finding)
            else:
                skipped.append(finding)
            continue

        # missing_clone / missing_manifest are out of scope here — caller
        # should run install/update instead. Surface as skipped.
        skipped.append(finding)

    # Refresh git hooks path defensively when we touched anything.
    if repaired and (target / ".git").exists():
        try:
            _set_git_hooks_path(target)
        except Exception:
            pass

    return {"repaired": repaired, "skipped": skipped}
