# agentic-bootstrap

Pip-installable CLI that hoists the shared agentic-system surface
(typed protocol, two MCP servers, hooks, skills, generated agent
workflows) into consumer repositories. Lives inside
[`darce/agentic-protocol-monorepo`](https://github.com/darce/agentic-protocol-monorepo).

Consumers run `agentic-bootstrap install --target <path>` once; it
clones the monorepo, materializes the overlay, and registers both
managed MCP servers (`mcp-agent-handoff`, `mcp-agent-orchestrator`)
across `.mcp.json`, `.vscode/mcp.json`, and `.codex/config.toml`. No
hand-edits required.

## Install

### From PyPI (recommended)

```bash
uvx --from agentic-bootstrap agentic-bootstrap install --target /path/to/your/repo
# or, persistent:
uv tool install agentic-bootstrap
```

### From the monorepo source tree (development)

```bash
cd packages/agentic-bootstrap
python -m pip install -e ".[dev]"
```

### Direct from git (private-repo phase, before PyPI release)

```bash
uvx --from "git+ssh://git@github.com/darce/agentic-protocol-monorepo@v0.1.0#subdirectory=packages/agentic-bootstrap" \
    agentic-bootstrap install \
    --target /path/to/your/repo
```

## Subcommands

```
agentic-bootstrap install --target <path> [--remote-ref <tag>] [--mcp-servers <default|path>] [--no-mcp-servers]
agentic-bootstrap update  --target <path> --remote-ref <tag>
agentic-bootstrap status  --target <path>
agentic-bootstrap doctor  --target <path> [--mcp-servers <default|path>]
agentic-bootstrap repair  --target <path> [--force-dirty] [--mcp-servers <default|path>]
```

| Subcommand | Purpose |
| ---------- | ------- |
| `install`  | Clone the monorepo, materialize SHARED + GENERATED surfaces, write the three MCP-config files, set `core.hooksPath`, write the overlay manifest. |
| `update`   | Re-run install at a new `--remote-ref`; refresh GENERATED surfaces and (optionally) configs. |
| `status`   | Print a summary of the installed overlay manifest. |
| `doctor`   | Detect drift in SHARED, GENERATED, and config surfaces. Exit `1` when drift exists. |
| `repair`   | Restore drifted surfaces flagged by `doctor`. |

See [`docs/CONSUMER.md`](https://github.com/darce/agentic-protocol-monorepo/blob/main/docs/CONSUMER.md)
for the consumer-facing walkthrough (upgrade, drift handling, skill
overrides, the `current_task_auto_regen` migration note).

## Surfaces written by `install`

| Surface                              | Source     | Layer       |
| ------------------------------------ | ---------- | ----------- |
| `scripts/hooks/`                     | shared     | symlink     |
| `.github/hooks/`                     | shared     | symlink     |
| `mk/`                                | shared     | symlink     |
| `.claude/skills/`                    | generated  | real dir    |
| `.claude/commands/`                  | generated  | real dir    |
| `.github/prompts/`                   | generated  | real dir    |
| `.codex/skills/`                     | generated  | real dir    |
| `.mcp.json`                          | generated  | real file   |
| `.vscode/mcp.json`                   | generated  | real file   |
| `.codex/config.toml`                 | generated  | real file   |
| `core.hooksPath` git config          | generated  | git config  |
| `.agentic/remote/`                   | bootstrap  | git clone   |
| `.agentic/overlay.json`              | bootstrap  | manifest    |

## Defaults

- `--remote-url` defaults to `git@github.com:darce/agentic-protocol-monorepo.git`.
- `--remote-ref` defaults to `main` (override with a release tag like `v0.1.0`).
- `--mcp-servers` defaults to the built-in managed map registering
  `mcp-agent-handoff` and `mcp-agent-orchestrator` via `uvx`. Pass a
  JSON file path to override; pass `--no-mcp-servers` to skip the
  three config writers entirely.

## Development

Tests live under `tests/`. From the monorepo root:

```bash
cd packages/agentic-bootstrap
PYTHONPATH=.:src:../agentic-protocol/src pytest tests -q
```
