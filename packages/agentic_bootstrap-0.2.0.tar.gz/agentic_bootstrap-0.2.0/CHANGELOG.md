# Changelog — agentic-bootstrap

## 0.2.0 — 2026-04-26

- Resolve shared overlay surfaces and the agent-workflow generator under
  `packages/agentic-system/` (the agentic-protocol-monorepo layout) with
  fallback to the clone root for legacy hoisted overlays. Fixes
  `BootstrapManifestValidationError: required surface 'scripts/hooks' was
  not materialized` against monorepo refs at or after Plan 0002 step 1.
- Rehearsal fixture (`fake_remote_with_generator`) now mirrors the real
  monorepo layout so this regression cannot return silently.

### Note on previously published refs

The monorepo `v0.1.0` tag pre-dates this fix. Consumers using
`uvx --from "...@v0.1.0..." agentic-bootstrap install ...` will hit the
required-surface error. Pin to `v0.1.1` or later.
