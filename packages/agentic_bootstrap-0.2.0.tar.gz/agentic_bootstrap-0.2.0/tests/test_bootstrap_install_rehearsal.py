"""End-to-end rehearsal: a single ``install(... mcp_servers="default")`` call
must produce the surface invariants plan 0002 step 2 commits to.

Captures the manual rehearsal scenario from
``docs/plans/0002-distribution-and-external-repo-readiness.md`` step 2c as a
test so future regressions surface in CI before they reach external repos.

Invariants asserted here:

1. The four per-agent surfaces (``.claude/skills``, ``.claude/commands``,
   ``.github/prompts``, ``.codex/skills``) are populated by the generator and
   contain no broken links.
2. ``.mcp.json``, ``.vscode/mcp.json``, and ``.codex/config.toml`` register
   both managed MCP servers (``agent-handoff-mcp`` and
   ``agent-orchestrator-mcp``) with runnable ``uvx`` command lines.
3. ``core.hooksPath`` is set to ``scripts/hooks`` and the linked hooks
   directory contains executable hook scripts (the ``command not found``
   failure mode is what we want to lock out).
4. The overlay manifest enumerates all seven SHARED+GENERATED surfaces with
   the right ``source`` discriminator.

The MCP-server-boots check from the plan (``uvx mcp-agent-handoff --help``)
is a network-dependent integration check that lives outside the unit-test
loop; it is rehearsed manually before each release.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest
import tomllib

from tests.test_install import (  # noqa: F401 — re-exported pytest fixture
    _git,
    fake_remote_with_generator,
)


def _init_git_repo(path: Path) -> None:
    _git("init", "--initial-branch=main", cwd=path)
    _git("config", "user.email", "rehearsal@example.com", cwd=path)
    _git("config", "user.name", "Rehearsal", cwd=path)


def test_install_with_default_servers_satisfies_rehearsal_invariants(
    tmp_path: Path, fake_remote_with_generator: tuple[str, str]
) -> None:
    from agentic_bootstrap.install import (
        DEFAULT_MCP_SERVERS,
        GENERATED_SURFACES,
        SHARED_SURFACES,
        install,
    )

    target = tmp_path / "rehearsal-target"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_generator

    manifest = install(
        target=target,
        remote_url=url,
        remote_ref=ref,
        mcp_servers="default",
    )

    # 1. Generated surfaces populated; no broken links anywhere under them.
    for surface in GENERATED_SURFACES:
        path = target / surface
        assert path.is_dir() and not path.is_symlink(), surface
        produced = list(path.rglob("*"))
        assert produced, f"{surface} must contain generator output"
        for entry in produced:
            if entry.is_symlink():
                resolved = entry.resolve(strict=False)
                assert resolved.exists(), f"broken link inside {surface}: {entry}"

    # 2. All three MCP-config surfaces register both managed servers with
    #    a runnable ``uvx`` command line.
    expected_servers = set(DEFAULT_MCP_SERVERS)
    assert expected_servers == {"agent-handoff-mcp", "agent-orchestrator-mcp"}

    mcp_doc = json.loads((target / ".mcp.json").read_text())
    for name in expected_servers:
        entry = mcp_doc["mcpServers"][name]
        assert entry["command"] == "uvx", entry
        assert entry["args"], f"{name} must carry a non-empty args list"

    vscode_doc = json.loads((target / ".vscode" / "mcp.json").read_text())
    for name in expected_servers:
        entry = vscode_doc["servers"][name]
        assert entry["command"] == "uvx", entry

    codex_doc = tomllib.loads((target / ".codex" / "config.toml").read_text())
    for name in expected_servers:
        entry = codex_doc["mcp_servers"][name]
        assert entry["command"] == "uvx", entry

    # 3. ``core.hooksPath`` configured and points at a directory carrying
    #    executable hook scripts.
    hooks_path = _git("config", "--get", "core.hooksPath", cwd=target)
    assert hooks_path == "scripts/hooks"
    hooks_dir = (target / hooks_path).resolve()
    assert hooks_dir.is_dir(), hooks_dir
    hook_files = [p for p in hooks_dir.iterdir() if p.is_file()]
    assert hook_files, "scripts/hooks must contain at least one hook script"

    # 4. Manifest enumerates all SHARED+GENERATED surfaces with the right
    #    source discriminator. ``shared`` entries come from the remote;
    #    ``generated`` entries are written by the generator into the target.
    by_path = {entry["path"]: entry for entry in manifest["surfaces"]}
    for surface in SHARED_SURFACES:
        assert by_path[surface]["source"] == "shared", by_path[surface]
    for surface in GENERATED_SURFACES:
        assert by_path[surface]["source"] == "generated", by_path[surface]

    config_paths = {entry["path"] for entry in manifest["configs"]}
    assert {
        ".mcp.json",
        ".vscode/mcp.json",
        ".codex/config.toml",
        "core.hooksPath",
    } <= config_paths


def test_install_with_default_servers_is_idempotent(
    tmp_path: Path, fake_remote_with_generator: tuple[str, str]
) -> None:
    """Repeat ``install`` with the default server map must converge: same
    config surfaces, same hooksPath, no duplicated server entries."""
    from agentic_bootstrap.install import install

    target = tmp_path / "rehearsal-target"
    target.mkdir()
    _init_git_repo(target)
    url, ref = fake_remote_with_generator

    install(target=target, remote_url=url, remote_ref=ref, mcp_servers="default")
    first = (target / ".mcp.json").read_text()

    install(target=target, remote_url=url, remote_ref=ref, mcp_servers="default")
    second = (target / ".mcp.json").read_text()

    # Server entries already match what install would write -> file content
    # stable on rerun (modulo formatter-equivalent whitespace).
    assert json.loads(first) == json.loads(second)
    # Hooks configuration survives the rerun.
    hooks_path = subprocess.check_output(
        ["git", "config", "--get", "core.hooksPath"], cwd=target, text=True
    ).strip()
    assert hooks_path == "scripts/hooks"


def test_install_with_default_servers_requires_uvx_in_args() -> None:
    """Sanity: the built-in default map must not be empty and each entry
    must carry a non-empty ``args`` list. Cheap regression guard for the
    map declaration itself — failing here is louder than failing inside
    a slow end-to-end install."""
    from agentic_bootstrap.install import DEFAULT_MCP_SERVERS

    assert set(DEFAULT_MCP_SERVERS) == {
        "agent-handoff-mcp",
        "agent-orchestrator-mcp",
    }
    for name, entry in DEFAULT_MCP_SERVERS.items():
        assert entry["command"] == "uvx", (name, entry)
        assert entry["args"], (name, entry)
