# Epics — `01-Planning/epics/`

This directory holds **per-epic narrative files** (markdown). Epics are the upper tier of the v1.0 hierarchy:

```
PRD → Epic (here) → Story → Task
```

## When to create an epic

Create an Epic when a single product requirement is large enough to span **multiple PRs** and **multiple stories**. Smaller features should be authored as standalone Stories without an Epic parent.

## Authoring flow

1. `sdlc epic new <slug>` — scaffolds `01-Planning/epics/<slug>.md` from `templates/07-Epic.md`
2. Edit the markdown — fill in Goal, Stories list, Requirements, Technical Decisions, UX, Cross-Story Dependencies
3. `sdlc epic bootstrap <slug>` — invokes the SM agent to draft each child story file from the Stories list
4. `sdlc epic sync <slug>` — re-parses your edits into `automation/epics/<slug>.yaml` (engine state)

## Source of truth

- Markdown here is the **narrative source of truth** (rich content, GitHub-PR-friendly)
- `automation/epics/<slug>.yaml` is the **state source of truth** (engine-maintained, auto-derived)

Epic status is auto-derived from its child stories — there is no manual gate.
