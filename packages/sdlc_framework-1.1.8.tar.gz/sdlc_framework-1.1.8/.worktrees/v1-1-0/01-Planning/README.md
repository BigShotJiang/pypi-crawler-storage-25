# Phase 1 — Planning & Requirements

> **Mục tiêu**: Biến idea thô thành tài liệu rõ ràng để team (gồm cả AI agents) hiểu *làm gì* và *tại sao*.

## Deliverables của Phase này

| # | File | Mục đích | Owner |
|---|------|---------|-------|
| 1 | `templates/01-PRD.md` | Product Requirements Document | PM |
| 2 | `templates/02-User-Stories.md` | User stories + acceptance criteria | PM/BA |
| 3 | `templates/03-Requirements-Spec.md` | Functional + non-functional requirements | BA |
| 4 | `templates/04-Stakeholder-Map.md` | RACI + comms plan | PM |
| 5 | `templates/05-Risk-Register.md` | Risk identification & mitigation | PM |

## Quy trình đề xuất

```
Idea → Discovery → PRD draft → Stakeholder review → Sign-off → Phase 2
```

## Definition of Done — Phase 1

- [ ] PRD đã được approve bởi product sponsor
- [ ] User stories có acceptance criteria rõ ràng (Given/When/Then)
- [ ] Non-functional requirements định lượng được (vd: p95 < 200ms)
- [ ] Stakeholder map xác định rõ RACI
- [ ] Top-5 risks có mitigation plan
- [ ] Tất cả AI tools đọc được context từ `ai-tools/` folder

## AI Assist trong Phase này

Khi viết PRD/User Stories, dùng prompts trong `../ai-tools/shared-prompts/planning-prompts.md`. Ví dụ:

```
Use template at 01-Planning/templates/01-PRD.md.
Context: <paste meeting notes>
Task: Generate first PRD draft. Flag anything ambiguous as <NEEDS-CLARIFICATION>.
```

## Epic / Story authoring (v1.0)

Two new subdirectories live alongside the existing PRD / requirements /
user-stories / risks artifacts:

- **`epics/<slug>.md`** — Epic narrative files. Each Epic decomposes
  into 2+ Stories. Templated by `sdlc epic new <slug>`. See
  `epics/README.md` for the authoring flow.
- **`stories/<slug>.md`** — Story narrative files with Given/When/Then
  acceptance criteria. Optionally belong to an Epic via `epic:`
  frontmatter; orphan stories are also allowed. Templated by
  `sdlc story new <slug> [--epic <epic-slug>]`. See `stories/README.md`.

Engine syncs these markdown files into `automation/epics/<slug>.yaml`
and `automation/stories/<slug>.yaml` via `sdlc epic sync` /
`sdlc story sync`. Source-of-truth split: humans write narrative,
engine writes state. The dashboard "Hierarchy" view renders the
combined tree.
