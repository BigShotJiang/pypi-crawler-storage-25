# Phase 3 — Development & Code Review

> **Mục tiêu**: Code chất lượng cao, an toàn, có thể bảo trì — bất kể human hay AI viết.

## Deliverables

| # | File | Owner |
|---|------|-------|
| 1 | `standards/coding-standards.md` | Eng Lead |
| 2 | `standards/git-workflow.md` | Eng Lead |
| 3 | `standards/error-handling.md` | Backend Lead |
| 4 | `standards/security-checklist.md` | Security |
| 5 | `templates/PR-Template.md` | Eng Lead |
| 6 | `templates/Code-Review-Checklist.md` | Eng Lead |
| 7 | `templates/Definition-of-Done.md` | Team |

## Definition of Done — Phase 3 (per PR)

- [ ] Tests written (unit + integration) — coverage delta ≥ 0%
- [ ] Lint + format clean
- [ ] Security scan (Semgrep / CodeQL) clean
- [ ] No secrets / no PII in logs
- [ ] Docs updated (README, OpenAPI, ADR if needed)
- [ ] Reviewed by ≥ 1 human (security-sensitive: ≥ 2)
- [ ] AI-generated code annotated and reviewed line-by-line
- [ ] Backwards-compatible OR migration plan documented
- [ ] Feature flag wraps risky paths
- [ ] Observability: logs, metrics, traces in place

## AI-Assisted Development Policy

1. **Always disclose**: PR description must say which AI tool generated which parts.
2. **Never trust blindly**: Treat AI output as a junior dev's first draft.
3. **Security-sensitive code** (auth, crypto, payments, IAM) requires human-only review.
4. **License hygiene**: Reject snippets that look copy-pasted from copyleft sources.
5. **Test first**: Ask AI to write tests *before* impl when possible.

See `../ai-tools/` for tool-specific configs (Claude, Copilot, Cursor, Codex, Aider).

## Review stage = 3 reviewers parallel (v1.0)

Phase 3 task `review` stage now dispatches **three reviewers in parallel**
by default:

1. `code-reviewer` — quality, style, performance, contract fidelity
2. `security-reviewer` — security, secrets, auth, OWASP-class issues
3. `edge-case-reviewer` — boundary conditions, race conditions, off-by-one

Each writes a verdict file at `automation/reviews/<task>-<reviewer>-<ts>.md`.
The consolidator aggregates: any **BLOCK** halts and creates a
clarification entry; **PASS_WITH_NOTES** advances with notes; all
**PASS** advances cleanly.

**Tier-based pack size cap:** tier 1 = full pack, tier 2 = cap at 2,
tier 3 = cap at 1.

**Bypass with `--no-review`** — opt out for trivial work (docs-only,
typo fixes). The engine refuses bypass on sensitive paths
(`src/auth/**`, `src/payment/**`, etc.). Force override via
`--force-skip-review --reason="..."` writes a git-tracked audit yaml.
See [GUIDELINE.md §G.4](../GUIDELINE.md) for the full policy.
