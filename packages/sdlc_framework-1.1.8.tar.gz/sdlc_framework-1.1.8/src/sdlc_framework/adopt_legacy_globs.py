# src/sdlc_framework/adopt_legacy_globs.py
"""Detect existing source + tests; extend project.yaml legacy_code_globs.

Spec §12: existing source code is grandfathered out of TDD enforcement
via `legacy_code_globs`. Adopt sets defaults based on detected layout.
"""
from __future__ import annotations

from pathlib import Path

import yaml

from sdlc_framework.adopt_manifest import AdoptManifest


def detect_legacy_globs(target: Path) -> list[str]:
    """Return the set of legacy_code_globs entries appropriate for `target`.

    Order: `src/**` first if present; then `tests/**` or `test/**` (whichever
    directory exists). Returns [] if no `src/` is found (greenfield without
    code — nothing to grandfather).
    """
    out: list[str] = []
    if (target / "src").is_dir():
        out.append("src/**")
    if (target / "tests").is_dir():
        out.append("tests/**")
    elif (target / "test").is_dir():
        out.append("test/**")
    return out


def apply_legacy_globs(target: Path, manifest: AdoptManifest) -> list[str]:
    """Update `target/project.yaml` so `legacy_code_globs` includes detected entries.

    - If project.yaml does not exist, creates it with just the detected entries.
    - If it exists, appends new entries while preserving order + dedup.
    - If detection returns [], does nothing.
    - Records a single `yaml-add` action on the manifest covering the new
      values added (empty added_values means no manifest entry).

    Returns the final list of legacy_code_globs.
    """
    detected = detect_legacy_globs(target)
    if not detected:
        return []

    py = target / "project.yaml"
    if py.exists():
        try:
            data = yaml.safe_load(py.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            data = {}
        if not isinstance(data, dict):
            data = {}
    else:
        data = {}

    current = data.get("legacy_code_globs") or []
    if not isinstance(current, list):
        current = []
    final = list(current)
    added: list[str] = []
    for entry in detected:
        if entry not in final:
            final.append(entry)
            added.append(entry)

    if added or not py.exists():
        data["legacy_code_globs"] = final
        py.write_text(
            yaml.safe_dump(data, sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )

    if added:
        manifest.record_yaml_add(
            "project.yaml", key="legacy_code_globs", added_values=added,
        )
    return final
