# src/sdlc_framework/render_commands.py
"""Slash-command manifest + per-tool render targets.

Spec §11 — the engine's `sdlc <cmd>` CLI is tool-agnostic Python; tool-side
wraps each command as a slash command for ergonomics. This module emits:

  - .claude/commands/sdlc-<name>.md          (one file per command)
  - .copilot/skills/sdlc-<name>/SKILL.md     (skill subdir per command)
  - .cursor/rules/sdlc-commands.mdc          (single rule listing all commands)
"""
from __future__ import annotations

from pathlib import Path

import yaml


# Curated subset of `sdlc <cmd>` operations exposed as slash commands.
# Keep this list short and focused on commands the user invokes interactively.
COMMAND_MANIFEST: list[dict] = [
    # --- Auto-generated stubs for all 3 tools (parity for hierarchy / verify / scan / next) ---
    {"name": "epic-new",    "description": "Scaffold a new epic.",
     "sdlc_command": "epic new",    "args": "<slug> [--title \"...\"]"},
    {"name": "story-new",   "description": "Scaffold a new story under an epic.",
     "sdlc_command": "story new",   "args": "<slug> [--epic <epic>] [--title \"...\"]"},
    {"name": "ticket-new",  "description": "Create a non-feature work item (bug/chore/hotfix/support).",
     "sdlc_command": "ticket new",  "args": "<slug> --kind=<bug|chore|hotfix|support>"},
    {"name": "tasks-new",   "description": "Add a Phase 3 task definition.",
     "sdlc_command": "tasks new",   "args": "<id>"},
    {"name": "verify",      "description": "Mark a Phase 1/2/4 artifact as verified.",
     "sdlc_command": "verify",      "args": "<item-id>"},
    {"name": "scan",        "description": "Run the SDLC engine and refresh state.json.",
     "sdlc_command": "scan",        "args": "[--print]"},
    {"name": "next",        "description": "Print a paste-ready prompt for the next pending DoD item.",
     "sdlc_command": "next",        "args": ""},
    {"name": "audit-list",  "description": "List forced-skip-review audit entries.",
     "sdlc_command": "audit list",  "args": ""},
    # --- Hand-written on Claude side (`.claude/commands/<name>.md`); auto-generated stubs for Copilot/Cursor parity ---
    # `claude_handwritten: True` means `_render_claude` skips this entry (file is owned by humans, not the renderer).
    {"name": "adopt",       "description": "Retrofit SDLC framework on an existing running project (auto-detect existing PRDs, designs, code, runbooks).",
     "sdlc_command": "adopt",       "args": "[--auto] [--dry-run]", "claude_handwritten": True},
    {"name": "auto",        "description": "Autopilot — auto-run through pending DoD items, dispatching the right subagent until a STOP condition.",
     "sdlc_command": "auto",        "args": "", "claude_handwritten": True},
    {"name": "auto-mad",    "description": "MAD MODE autopilot — auto-signs phase gates and auto-verifies artifacts. NOT for production.",
     "sdlc_command": "auto-mad",    "args": "", "claude_handwritten": True},
    {"name": "dashboard",   "description": "Open the SDLC dashboard in a browser.",
     "sdlc_command": "dashboard",   "args": "", "claude_handwritten": True},
    {"name": "dispatch",    "description": "Show the engine's full dispatch decision (primary agent, parallel agents, blocked_by).",
     "sdlc_command": "dispatch",    "args": "", "claude_handwritten": True},
    {"name": "init",        "description": "Scaffold an SDLC project (auto-detects stack from package.json / pyproject.toml / go.mod).",
     "sdlc_command": "init",        "args": "[--stack=<node|python|go>] [--ai-tools=<tool>]", "claude_handwritten": True},
    {"name": "replan",      "description": "Mark downstream DoD items dirty after a major change (requirements, UI/UX, tech stack, scale).",
     "sdlc_command": "replan",      "args": "[--scope=requirements|ui-ux|tech-stack|scale-nfr|custom] [--reason=...] [--clear]", "claude_handwritten": True},
    {"name": "resume",      "description": "Show \"where am I?\" — current phase, last activity, and the next action to take.",
     "sdlc_command": "resume",      "args": "", "claude_handwritten": True},
    {"name": "start",       "description": "Save the project idea, invoke pm-agent to draft the PRD, then auto-chain into autopilot through Phase 1.",
     "sdlc_command": "start",       "args": "<your idea>", "claude_handwritten": True},
    {"name": "tasks",       "description": "Manage Phase 3 task definitions (bootstrap from user stories, list, create, remove).",
     "sdlc_command": "tasks",       "args": "<bootstrap | list | new <id> | rm <id>>", "claude_handwritten": True},
]


def render_commands_for(tool: str) -> dict[str, str]:
    """Return a mapping of {relative_path: file_content} for the target tool."""
    tool = tool.lower()
    if tool == "claude":
        return _render_claude()
    if tool == "copilot":
        return _render_copilot()
    if tool == "cursor":
        return _render_cursor()
    raise ValueError(f"unsupported tool: {tool!r}")


def write_commands_for_tool(repo: Path, tool: str) -> list[Path]:
    """Render and write to disk under `repo`. Returns the list of paths written."""
    files = render_commands_for(tool)
    out: list[Path] = []
    for rel, content in files.items():
        target = repo / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        out.append(target)
    return out


def check_commands_for_tool(repo: Path, tool: str) -> tuple[bool, list[str]]:
    """Compare expected files to disk; return (matches, drift_messages)."""
    files = render_commands_for(tool)
    drift: list[str] = []
    for rel, expected in files.items():
        target = repo / rel
        if not target.exists():
            drift.append(f"missing: {rel}")
            continue
        actual = target.read_text(encoding="utf-8")
        if actual != expected:
            drift.append(f"drift: {rel}")
    return (not drift, drift)


# --- per-tool implementations ---------------------------------------------


def _frontmatter(d: dict) -> str:
    body = yaml.safe_dump(d, sort_keys=False, allow_unicode=True, default_flow_style=False).rstrip()
    return f"---\n{body}\n---\n"


def _render_claude() -> dict[str, str]:
    out: dict[str, str] = {}
    for cmd in COMMAND_MANIFEST:
        if cmd.get("claude_handwritten"):
            # File at .claude/commands/sdlc-<name>.md is hand-maintained; do not auto-generate.
            # Copilot + Cursor still get auto-generated stubs from this manifest entry.
            continue
        rel = f".claude/commands/sdlc-{cmd['name']}.md"
        fm = {"name": f"sdlc-{cmd['name']}", "description": cmd["description"]}
        body = (
            f"# /{cmd['name']}\n\n"
            f"Run `sdlc {cmd['sdlc_command']} {cmd['args']}`.\n\n"
            f"{cmd['description']}\n"
        )
        out[rel] = _frontmatter(fm) + body
    return out


def _render_copilot() -> dict[str, str]:
    out: dict[str, str] = {}
    for cmd in COMMAND_MANIFEST:
        rel = f".copilot/skills/sdlc-{cmd['name']}/SKILL.md"
        fm = {
            "name": f"sdlc-{cmd['name']}",
            "description": cmd["description"],
            "model": "sonnet",
        }
        body = (
            f"# sdlc-{cmd['name']}\n\n"
            f"Wraps `sdlc {cmd['sdlc_command']} {cmd['args']}`.\n\n"
            f"{cmd['description']}\n"
        )
        out[rel] = _frontmatter(fm) + body
    return out


def _render_cursor() -> dict[str, str]:
    rel = ".cursor/rules/sdlc-commands.mdc"
    lines = ["---", "description: SDLC framework slash commands.", "---", ""]
    lines.append("# SDLC commands\n")
    for cmd in COMMAND_MANIFEST:
        lines.append(
            f"- **/{cmd['name']}** — {cmd['description']} "
            f"(runs `sdlc {cmd['sdlc_command']} {cmd['args']}`)"
        )
    return {rel: "\n".join(lines) + "\n"}
