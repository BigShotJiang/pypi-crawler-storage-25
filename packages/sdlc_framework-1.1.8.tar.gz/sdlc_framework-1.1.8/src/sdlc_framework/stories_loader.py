"""Load Story yaml files from automation/stories/ and derive Story status.

Story state machine (v1.1.0):

    draft -> ready -> in-progress -> done -> deployed (terminal)
                          ^             |
                          +-- rollback -+  (engine-level: PR closed unmerged)

State-by-state contract:
- draft:        no child tasks reference this story yet AND yaml has no
                declared `state`/`status` of `ready` or `in-progress`.
- ready:        yaml `state: ready` (engine wrote on `complete-draft`)
                OR >=1 child task exists, none past `pending`.
- in-progress:  yaml `state: in-progress` (engine wrote it on
                `sdlc story activate`) OR a child task is past `pending`
                AND state.phase3.active_story_id == this slug.
- done:         yaml `state: done` (engine wrote it after `gh pr create`
                succeeded for the story branch).
- deployed:     yaml `state: deployed` (engine wrote it after
                `gh pr view --json merged=true` confirmed merge).

Note: Legacy yamls written before v1.1.0 used `status:`. Reads fall back
to `status` when `state` is absent so old files keep working until they
are touched again (next write upgrades them to `state`).

This loader is read-only: it never auto-flips `committed`-tasks to
`done`. That transition requires a side-effecting `gh pr create` call
and lives in the engine layer.
"""
from __future__ import annotations

import os
from pathlib import Path

import yaml

VALID_STORY_STATUSES = (
    "draft",
    "ready",
    "in-progress",
    "done",
    "deployed",
)


class StorySchemaError(ValueError):
    """Raised when a story yaml violates required schema."""


def load_stories(target: Path) -> list[dict]:
    """Load all automation/stories/*.yaml. Files missing `slug` are skipped."""
    sdir = target / "automation" / "stories"
    if not sdir.exists():
        return []
    out: list[dict] = []
    for f in sorted(sdir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict) or not data.get("slug"):
            continue
        out.append(data)
    return out


def _child_task_stages(target: Path, story_slug: str) -> list[str]:
    """Return list of stages for tasks whose story_id matches.

    Production path: delegates to ``tasks_loader.detect_stage`` which
    inspects the real filesystem (code/test globs, PR existence, merge
    status) to compute each child task's current stage.

    Test convenience: when ``SDLC_TEST_STAGE_OVERRIDE=1``, reads the
    ``stage_override`` field directly from task yaml. Reserved for unit
    tests that need specific stage scenarios without filesystem setup.
    This MUST NOT be set in production: a user or agent who wrote
    ``stage_override: done`` to a task yaml could otherwise fake Story
    state.
    """
    # Import locally to avoid a circular import at module load time
    # (tasks_loader → stories_loader is allowed; the reverse only via
    # function-local import).
    from sdlc_framework.tasks_loader import detect_stage

    tdir = target / "automation" / "tasks"
    if not tdir.exists():
        return []
    test_mode = os.environ.get("SDLC_TEST_STAGE_OVERRIDE") == "1"
    out: list[str] = []
    for f in sorted(tdir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if data.get("story_id") != story_slug:
            continue
        if test_mode:
            out.append(data.get("stage_override", "pending"))
        else:
            # Production: compute the real stage from filesystem + PR
            # state. ``is_active=True`` keeps this from collapsing every
            # task to ``pending`` based on the serial-lock check (which
            # is engine-level, not derive-level).
            stage = detect_stage(data, target, is_active=True)
            out.append(stage)
    return out


def derive_story_status(target: Path, story_slug: str) -> str:
    """Compute story status from yaml + child task stages.

    Engine-written terminal states (`done`, `deployed`) are trusted as
    long as they appear in yaml — only the engine writes them and the
    transitions are gated by side-effecting `gh` calls.

    Auto-derive layer (this function):
      - 0 child tasks reference the story -> `draft`
      - >=1 task, all at `pending` -> `ready`
      - any task past `pending` -> `in-progress`

    The loader does NOT auto-flip from all-tasks-`committed` to `done`.
    That transition requires `gh pr create` and lives in the engine.
    """
    spath = target / "automation" / "stories" / f"{story_slug}.yaml"
    if not spath.exists():
        return "draft"
    try:
        data = yaml.safe_load(spath.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return "draft"

    declared = data.get("state") or data.get("status")
    # Draft is a manual short-circuit: only `sdlc story complete-draft`
    # advances draft -> ready. Stray child task yamls (leftovers from a
    # previous attempt, scaffolds, etc.) must NOT pull a draft story
    # forward — the PM is still authoring.
    if declared == "draft":
        return "draft"
    if declared in ("done", "deployed"):
        return declared

    stages = _child_task_stages(target, story_slug)

    if not stages:
        if declared in ("in-progress", "ready"):
            return declared
        return "draft"

    if any(s != "pending" for s in stages):
        return "in-progress"

    if declared == "in-progress":
        return "in-progress"

    return "ready"
