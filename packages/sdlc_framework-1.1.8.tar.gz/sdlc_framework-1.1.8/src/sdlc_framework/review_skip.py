# src/sdlc_framework/review_skip.py
"""Review-skip orchestration: validate flag combinations, apply safety net,
write audit on force, return a structured decision the caller acts on.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from sdlc_framework.audit_log import write_forced_skip
from sdlc_framework.sensitive_paths import (
    detect_phase12,
    detect_phase3,
    load_sensitive_config,
)


@dataclass
class SkipDecision:
    """Outcome of `apply_review_skip_policy`.

    Caller pattern:

        d = apply_review_skip_policy(...)
        if d.refused:
            print(d.refusal_message, file=sys.stderr)
            return 1
        # else: write artifact yaml with d.review / d.skip_reason / d.skip_at
    """
    review: bool = True
    refused: bool = False
    forced: bool = False
    refusal_message: str = ""
    sensitive_match: list[str] = field(default_factory=list)
    skip_reason: str | None = None
    skip_at: str | None = None
    audit_path: Path | None = None


def apply_review_skip_policy(
    *,
    target: Path,
    artifact_id: str,
    artifact_type: str,
    title: str,
    body: str,
    globs: Iterable[str],
    no_review: bool,
    force_skip: bool,
    reason: str | None,
    ci_mode: bool | None = None,
) -> SkipDecision:
    """Decide skip outcome based on flags + artifact context."""
    import datetime as _dt

    # Default — no flags set: review stays true.
    if not no_review and not force_skip:
        return SkipDecision()

    # Force implies skip.
    skip_requested = no_review or force_skip

    # Detect sensitive matches.
    config = load_sensitive_config(target)
    sensitive_globs = detect_phase3(list(globs), config) if globs else []
    sensitive_topics = detect_phase12(f"{title}\n{body or ''}", config)
    sensitive_match = sensitive_globs + sensitive_topics

    # CI mode requires --reason whenever skip is requested.
    if ci_mode is None:
        ci_mode = _is_ci_mode()

    # If --force-skip-review was passed, --reason is mandatory in CI mode.
    if force_skip and ci_mode and not (reason or "").strip():
        return SkipDecision(
            refused=True,
            refusal_message=(
                "ERROR: --force-skip-review requires --reason=\"...\" in CI mode "
                f"(detected via CI env var). Artifact: {artifact_id}."
            ),
            sensitive_match=sensitive_match,
        )

    # --no-review without force on sensitive area → refuse.
    if no_review and not force_skip and sensitive_match:
        msg = _format_refusal(artifact_id, sensitive_match)
        return SkipDecision(
            refused=True,
            refusal_message=msg,
            sensitive_match=sensitive_match,
        )

    # Force path → write audit.
    if force_skip:
        if not skip_requested:
            # Defensive (force without explicit no_review still implies skip).
            skip_requested = True
        eff_reason = (reason or "").strip() or "(no reason given)"
        audit = write_forced_skip(
            target=target,
            artifact_id=artifact_id,
            artifact_type=artifact_type,
            reason=eff_reason,
            sensitive_match=sensitive_match,
        )
        now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        return SkipDecision(
            review=False,
            forced=True,
            sensitive_match=sensitive_match,
            skip_reason=eff_reason,
            skip_at=now,
            audit_path=audit,
        )

    # Plain --no-review on safe artifact → record but no audit.
    eff_reason = (reason or "").strip() or "unset"
    now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return SkipDecision(
        review=False,
        sensitive_match=sensitive_match,
        skip_reason=eff_reason,
        skip_at=now,
    )


# --- helpers ------------------------------------------------------------


def _is_ci_mode() -> bool:
    """CI mode = explicit CI env var OR non-tty stdin (no humans available)."""
    if os.environ.get("CI", "").strip().lower() in ("1", "true", "yes"):
        return True
    return not sys.stdin.isatty()


def _format_refusal(artifact_id: str, sensitive_match: list[str]) -> str:
    """Format the spec-mandated refusal message."""
    detected = sensitive_match[0] if sensitive_match else "(unknown)"
    return (
        f"ERROR: --no-review refused — artifact {artifact_id!r} touches "
        f"sensitive area: {detected}\n"
        f"       Detected via: {', '.join(sensitive_match)}\n"
        f"       To force, use: --force-skip-review --reason=\"<explicit justification>\"\n"
        f"       This will be logged to automation/audit/forced-skip-<id>.yaml"
    )


def collect_reason_interactive(prompt: str = "Reason for skipping review: ") -> str:
    """Helper for CLI commands: ask the user for a reason at the terminal.

    Returns the entered string or empty if user aborts. Caller must NOT call
    this in CI mode (use `_is_ci_mode()` first).
    """
    try:
        return input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        return ""
