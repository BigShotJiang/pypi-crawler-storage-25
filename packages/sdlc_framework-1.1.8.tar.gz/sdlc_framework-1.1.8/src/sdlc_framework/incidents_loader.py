"""Load Incident yaml files from automation/incidents/ and derive Incident status.

Incident state machine (v1.1.0):

    open -> restored -> closed (terminal)
              ^            |
              +-- (manual)-+   `sdlc incident close` requires tier-1 postmortem.

State-by-state contract:
- ``open``:      no fix ticket linked, OR linked fix ticket has not yet
                 reached ``status: done``.
- ``restored``:  ``fix_ticket_id`` references a kanban ticket whose
                 ``status: done``. MTTR computed in minutes from
                 ``opened_at`` to ``restored_at`` (or now when absent).
- ``closed``:    yaml ``status: closed`` is respected verbatim (manual
                 close). Postmortem gate enforced by the CLI, not here.

The loader is read-only: it never mutates the yaml. Side-effecting
transitions (auto-set ``restored_at`` when fix ticket reaches done,
etc.) live in ``incident_sync.py`` and are called by the engine scan
loop.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import yaml

VALID_INCIDENT_STATUSES = ("open", "restored", "closed")
VALID_SEVERITIES = ("critical", "high", "medium", "low")
REQUIRED_FIELDS = ("id", "title", "severity", "opened_at")


class IncidentSchemaError(ValueError):
    """Raised when an incident yaml is missing or malformed."""


def load_incidents(target: Path) -> list[dict]:
    """Load all ``automation/incidents/*.yaml``.

    Files missing required fields, or malformed yaml, are silently
    skipped — the same defensive policy used by ``stories_loader`` and
    ``epics_loader``. Returns the list sorted by filename for stable
    ordering across scan runs.
    """
    idir = target / "automation" / "incidents"
    if not idir.exists():
        return []

    out: list[dict] = []
    for f in sorted(idir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict):
            continue
        if not all(data.get(k) for k in REQUIRED_FIELDS):
            continue
        out.append(data)
    return out


def _parse_iso(ts: str) -> datetime:
    """Parse an ISO-8601 timestamp, treating bare strings as UTC.

    Accepts ``2026-05-04T11:00:00Z`` and ``2026-05-04T11:00:00+00:00``.
    """
    s = ts.rstrip("Z")
    parsed = datetime.fromisoformat(s)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def derive_incident_status(target: Path, incident_id: str) -> tuple[str, int | None]:
    """Return ``(status, mttr_min)`` for one incident.

    ``status`` is one of :data:`VALID_INCIDENT_STATUSES`.
    ``mttr_min`` is the integer minutes from ``opened_at`` to
    ``restored_at`` (or now). Returns ``None`` when the incident has
    not yet been restored.

    Raises :class:`IncidentSchemaError` when the incident yaml does
    not exist or is unreadable. The caller (engine scan loop) is
    expected to filter known incident ids via :func:`load_incidents`
    before calling this helper.
    """
    ipath = target / "automation" / "incidents" / f"{incident_id}.yaml"
    if not ipath.exists():
        raise IncidentSchemaError(f"incident not found: {incident_id}")

    try:
        data = yaml.safe_load(ipath.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise IncidentSchemaError(f"malformed yaml for {incident_id}: {exc}") from exc

    # Manual-close wins.
    if data.get("status") == "closed":
        return "closed", data.get("mttr_min")

    fix_id = data.get("fix_ticket_id")
    if not fix_id:
        return "open", None

    tpath = target / "automation" / "tickets" / f"{fix_id}.yaml"
    if not tpath.exists():
        # Dangling link — defensive default. Caller may surface a warning.
        return "open", None

    try:
        tdata = yaml.safe_load(tpath.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return "open", None

    if tdata.get("status") != "done":
        return "open", None

    # Fix ticket reached done → derive restored + MTTR.
    opened_raw = data.get("opened_at")
    if not opened_raw:
        # Should never happen — load_incidents enforced REQUIRED_FIELDS —
        # but be defensive when called directly.
        return "restored", None
    try:
        opened = _parse_iso(opened_raw)
    except ValueError as exc:
        raise IncidentSchemaError(
            f"malformed opened_at on {incident_id}: {opened_raw!r}"
        ) from exc

    restored_raw = data.get("restored_at")
    if restored_raw:
        try:
            restored = _parse_iso(restored_raw)
        except ValueError as exc:
            raise IncidentSchemaError(
                f"malformed restored_at on {incident_id}: {restored_raw!r}"
            ) from exc
    else:
        restored = datetime.now(timezone.utc)

    # Clamp negative MTTR to 0 — a clock-skew or operator-edited
    # restored_at < opened_at would otherwise yield a nonsensical
    # negative number on the dashboard.
    mttr = max(0, int((restored - opened).total_seconds() // 60))
    return "restored", mttr
