"""Story-tier PR management — Phase 7 of the v1.1.0 engine.

Responsibilities:
- ``maybe_create_pr``:  detect when all child tasks of a story have reached
  ``committed`` stage; run ``gh pr create``; stamp story.yaml with pr_url
  and state=done + state_transition.
- ``check_and_mark_deployed``:  scan all ``done`` stories; call
  ``gh pr view --json closed,merged``; mark state=deployed when merged=True.

Both functions are best-effort: ``gh`` errors (missing binary, network,
timeout, non-zero exit) are swallowed so engine scan stays green.

Mad-mode (Task 7.3):  ``maybe_create_pr(mad_mode=True)`` additionally calls
``gh pr merge --auto --squash`` immediately after a successful create.

Integration point (engine.py scan):
  After ``group_done_pairs`` is computed, call ``maybe_create_pr`` for each
  fully-committed group.  Call ``check_and_mark_deployed`` once per scan to
  advance stories from done→deployed when their PR has been merged.
"""
from __future__ import annotations

import datetime as dt
import json
import subprocess
from pathlib import Path

import yaml

from sdlc_framework.stories_loader import VALID_STORY_STATUSES


# ── internal helpers ──────────────────────────────────────────────────────────

def _utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _load_story(target: Path, slug: str) -> dict | None:
    """Load story yaml. Returns None if missing or unparseable."""
    spath = target / "automation" / "stories" / f"{slug}.yaml"
    if not spath.exists():
        return None
    try:
        return yaml.safe_load(spath.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return None


def _save_story(target: Path, slug: str, data: dict) -> None:
    spath = target / "automation" / "stories" / f"{slug}.yaml"
    spath.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


def _transition(data: dict, to: str, at: str) -> None:
    """Append a state_transition entry and update state in-place (idempotent).

    Raises:
        ValueError: if ``to`` is not a recognised story state.
    """
    if to not in VALID_STORY_STATUSES:
        raise ValueError(f"invalid story state: {to!r}")
    log: list[dict] = data.setdefault("state_transitions", [])
    if log and log[-1].get("to") == to:
        return  # already the most-recent transition
    log.append({"to": to, "at": at})
    data["state"] = to


def _child_tasks_for_story(target: Path, slug: str) -> list[dict]:
    """Return all task yamls whose story_id == slug."""
    tdir = target / "automation" / "tasks"
    if not tdir.exists():
        return []
    out: list[dict] = []
    for f in sorted(tdir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if data.get("story_id") == slug:
            out.append(data)
    return out


def _all_committed(tasks: list[dict]) -> bool:
    """Return True only when every task has a committed_at timestamp."""
    return bool(tasks) and all(t.get("committed_at") for t in tasks)


def _resolve_branch(story_slug: str, tasks: list[dict]) -> str:
    """Determine the shared PR branch for a story.

    Resolution order (mirrors tasks_loader._resolve_feature_branches):
      1. First explicit ``pr_branch`` declared on any sibling (file-sort order).
      2. ``feature/<story_slug>`` as deterministic fallback.
    """
    for t in tasks:
        if t.get("pr_branch"):
            return t["pr_branch"]
    return f"feature/{story_slug}"


def _build_pr_body(slug: str, story_data: dict, tasks: list[dict]) -> str:
    """Compose a PR body with story context and task list."""
    title = story_data.get("title", slug)
    lines = [
        f"## {title}",
        "",
        f"Closes story `{slug}`.",
        "",
        "### Tasks included",
    ]
    for t in tasks:
        tid = t.get("id", "?")
        label = t.get("label", tid)
        lines.append(f"- `{tid}` — {label}")
    lines += [
        "",
        "---",
        "<!-- sdlc:ai-disclosure -->",
        "This PR was opened automatically by the SDLC engine (v1.1.0).",
    ]
    return "\n".join(lines)


# ── public API ────────────────────────────────────────────────────────────────

def maybe_create_pr(
    target: Path,
    story_slug: str,
    *,
    mad_mode: bool = False,
    base_branch: str = "main",
) -> str | None:
    """Open a PR for a story when all its child tasks have reached ``committed``.

    Preconditions (all must hold; returns None otherwise):
      - story yaml exists
      - story ``state == "in-progress"``
      - story has no ``pr_url`` yet
      - story has ≥1 child task
      - all child tasks have ``committed_at`` set

    On success:
      - runs ``gh pr create --base <base_branch> --head <branch> --title ... --body ...``
      - stamps story.yaml: ``pr_url``, ``state=done``, state_transition entry

    Mad-mode (opt-in):
      - additionally runs ``gh pr merge <url> --auto --squash`` after create;
        merge failures are silently ignored (best-effort).

    Args:
        target: project root path.
        story_slug: slug of the story to open a PR for.
        mad_mode: if True, also schedules auto-merge after create.
        base_branch: target branch for the PR (default ``"main"``).

    Returns the PR URL string on success, None when ineligible or on gh error.
    """
    # ── pre-condition checks ──────────────────────────────────────────────────
    data = _load_story(target, story_slug)
    if data is None:
        return None

    # Idempotent: already has a PR URL
    existing_url: str | None = data.get("pr_url")
    if existing_url:
        return existing_url

    # Only create PRs for stories that are actively being developed
    if data.get("state") != "in-progress":
        return None

    tasks = _child_tasks_for_story(target, story_slug)
    if not _all_committed(tasks):
        return None

    # ── gh pr create ─────────────────────────────────────────────────────────
    branch = _resolve_branch(story_slug, tasks)
    title = data.get("title", story_slug)
    body = _build_pr_body(story_slug, data, tasks)

    try:
        proc = subprocess.run(
            [
                "gh", "pr", "create",
                "--base", base_branch,
                "--head", branch,
                "--title", title,
                "--body", body,
            ],
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None

    if proc.returncode != 0 or not proc.stdout.strip():
        return None

    pr_url = proc.stdout.strip()
    now = _utcnow()

    # ── update story yaml (single write) ─────────────────────────────────────
    data["pr_url"] = pr_url
    _transition(data, "done", now)
    _save_story(target, story_slug, data)

    # ── mad-mode: auto-merge (best-effort) ───────────────────────────────────
    if mad_mode:
        try:
            subprocess.run(
                ["gh", "pr", "merge", pr_url, "--auto", "--squash"],
                capture_output=True,
                text=True,
                check=False,
                timeout=30,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            pass  # merge is best-effort; never block

    return pr_url


def check_and_mark_deployed(target: Path) -> list[str]:
    """Scan all ``done`` stories; mark ``deployed`` when their PR is merged.

    Calls ``gh pr view <pr_url> --json closed,merged`` for each eligible
    story.  gh failures (timeout, missing binary, non-zero exit) are silently
    skipped — deployed detection is best-effort, never blocks scan.

    Returns the list of slugs that were transitioned to ``deployed`` this call.
    """
    sdir = target / "automation" / "stories"
    if not sdir.exists():
        return []

    deployed: list[str] = []
    now = _utcnow()

    for spath in sorted(sdir.glob("*.yaml")):
        try:
            data = yaml.safe_load(spath.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue

        # Only check stories that are in the 'done' state
        if data.get("state") != "done":
            continue

        pr_url: str | None = data.get("pr_url")
        if not pr_url:
            continue  # no PR to check

        slug = data.get("slug") or spath.stem

        try:
            proc = subprocess.run(
                ["gh", "pr", "view", pr_url, "--json", "closed,merged"],
                capture_output=True,
                text=True,
                check=False,
                timeout=10,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            continue

        if proc.returncode != 0 or not proc.stdout:
            continue

        try:
            payload = json.loads(proc.stdout)
        except ValueError:
            continue

        if payload.get("merged"):
            _transition(data, "deployed", now)
            spath.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
            deployed.append(slug)

    return deployed


def reconcile_done_stories(target: Path) -> dict[str, list[str]]:
    """Single-pass reconciliation for all ``done`` stories.

    Replaces the two-call pattern previously used in :func:`engine.scan`
    (``rollback_done_stories_on_pr_closed_unmerged`` + ``check_and_mark_deployed``),
    eliminating the double ``gh pr view`` call per story per scan.

    Logic per story (requires ``state == "done"`` and a ``pr_url``):

    - ``merged == True``                 → advance to ``deployed``
    - ``closed == True, merged == False`` → roll back to ``in-progress``
    - anything else (open, gh error)     → no change

    All ``gh`` failures (timeout, missing binary, non-zero exit) are silently
    skipped — reconciliation is best-effort and never blocks scan.

    Returns:
        ``{"deployed": [<slug>, ...], "rolled_back": [<slug>, ...]}``
    """
    from sdlc_framework.story_sync import append_state_transition

    sdir = target / "automation" / "stories"
    if not sdir.exists():
        return {"deployed": [], "rolled_back": []}

    deployed: list[str] = []
    rolled_back: list[str] = []
    now = _utcnow()

    for spath in sorted(sdir.glob("*.yaml")):
        try:
            data = yaml.safe_load(spath.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue

        if data.get("state") != "done":
            continue

        pr_url: str | None = data.get("pr_url")
        if not pr_url:
            continue

        slug = data.get("slug") or spath.stem

        # ── single gh call per story ──────────────────────────────────────────
        try:
            proc = subprocess.run(
                ["gh", "pr", "view", pr_url, "--json", "closed,merged"],
                capture_output=True,
                text=True,
                check=False,
                timeout=10,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            continue

        if proc.returncode != 0 or not proc.stdout:
            continue

        try:
            payload = json.loads(proc.stdout)
        except ValueError:
            continue

        if payload.get("merged"):
            # Advance done → deployed
            _transition(data, "deployed", now)
            spath.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
            deployed.append(slug)
        elif payload.get("closed") and not payload.get("merged"):
            # PR closed without merge → roll back to in-progress
            try:
                append_state_transition(target, slug, to="in-progress", at=now)
                rolled_back.append(slug)
            except Exception:  # noqa: BLE001
                pass

    return {"deployed": deployed, "rolled_back": rolled_back}
