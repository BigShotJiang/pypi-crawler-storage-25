"""Load Epic yaml files from automation/epics/ and derive Epic status (v1.1.0).

Epic state machine (auto-derive only):
    ready → in-progress → done

- ready: all child stories in {draft, ready} (or no children)
- in-progress: any child past ready (in-progress, done, deployed) and
  NOT all deployed
- done: ALL child stories at `deployed` (terminal)

v1.1.0 architecture:
- Child membership is determined by directory glob over
  `automation/stories/*.yaml` filtered by each story's `epic_id`
  field — NOT by the legacy `epic.story_ids` list (which can drift).
- Each story's persisted `state` field is read directly. The loader
  does NOT call `derive_story_status` — terminal transitions are
  written by the engine after PR merge.
- Missing or corrupt child yamls are silently skipped (no `unknown`
  sentinel). They cannot be authoritative about state.

Epic yaml itself has NO `state` field — the engine derives it on every
scan from the live filesystem state of the children.
"""
from __future__ import annotations

from pathlib import Path

import yaml


class EpicSchemaError(ValueError):
    """Raised when an epic yaml violates required schema."""


REQUIRED_FIELDS = ("slug",)

VALID_EPIC_STATUSES: tuple[str, ...] = ("ready", "in-progress", "done")


def load_epics(target: Path) -> list[dict]:
    """Load all automation/epics/*.yaml. Returns dicts with at least `slug`.

    Files missing the `slug` field are silently skipped (matches tasks_loader behavior).
    """
    epics_dir = target / "automation" / "epics"
    if not epics_dir.exists():
        return []
    out: list[dict] = []
    for f in sorted(epics_dir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict) or not data.get("slug"):
            continue
        out.append(data)
    return out


def derive_epic_status(target: Path, epic_slug: str) -> str:
    """Compute Epic status (v1.1.0) from child stories' persisted `state`.

    Returns one of `VALID_EPIC_STATUSES`. Defaults to ``"ready"`` when
    no child story's ``epic_id`` matches.
    """
    sdir = target / "automation" / "stories"
    if not sdir.exists():
        return "ready"

    children_states: list[str] = []
    for f in sorted(sdir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict) or data.get("epic_id") != epic_slug:
            continue
        children_states.append(data.get("state", "draft"))

    if not children_states:
        return "ready"
    if all(s == "deployed" for s in children_states):
        return "done"
    if any(s in ("in-progress", "done", "deployed") for s in children_states):
        return "in-progress"
    return "ready"
