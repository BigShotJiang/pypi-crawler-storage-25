# src/sdlc_framework/adopt_git_state.py
"""Git-working-tree + CI-mode detection helpers for `sdlc adopt`.

Spec §12: adopt detects uncommitted changes; warns and offers to skip
working-tree touches. In CI, auto-skip with message.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def working_tree_dirty(target: Path) -> bool:
    """Return True iff the git working tree at `target` has uncommitted/untracked changes.

    Returns False outside a git repo (caller should also check `.git/` exists
    if they want to gate behavior on "is this a git repo at all").
    """
    try:
        r = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=target, capture_output=True, text=True, timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    if r.returncode != 0:
        return False
    return bool(r.stdout.strip())


def is_ci_mode() -> bool:
    """True when running non-interactively (CI env var or non-tty stdin)."""
    if os.environ.get("CI", "").strip().lower() in ("1", "true", "yes"):
        return True
    return not sys.stdin.isatty()
