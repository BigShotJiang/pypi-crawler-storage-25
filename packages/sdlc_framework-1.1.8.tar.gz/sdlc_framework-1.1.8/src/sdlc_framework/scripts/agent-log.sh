#!/usr/bin/env bash
# agent-log.sh — append a structured JSON entry to automation/agent-runs.jsonl.
#
# Usage:
#   scripts/agent-log.sh start <agent> <item_id> [--tool=<tool>]
#   scripts/agent-log.sh done  <agent> <item_id> --summary="<text>" [--tool=<tool>]
#   scripts/agent-log.sh fail  <agent> <item_id> --summary="<error>" [--tool=<tool>]
#
# Behaviour:
#   - Append one JSONL entry. Schema: ts, agent, status, item_id, tool, duration_s, summary.
#   - For `start`, write a temp file under automation/.run-state/ recording the start epoch.
#   - For `done`/`fail`, read that temp file (if present) to compute duration_s, then delete it.
#   - The log file grows unbounded; the engine dashboard display is capped separately.
#   - Always exits 0 in production paths (log is observability; do not fail the agent).
#   - Exits 2 only for clear misuse: missing positional, unknown subcommand.
#
# Repo root is auto-detected (scripts/agent-log.sh is two levels deep). Override with
#   SDLC_LOG_ROOT=<path>     for tests.
# Tool can be set via:
#   --tool=<x>               flag (highest priority)
#   $SDLC_TOOL               env var (fallback)

set -u

CMD="${1:-}"; shift || true
AGENT="${1:-}"; shift || true
ITEM_ID="${1:-}"; shift || true

if [ -z "$CMD" ] || [ -z "$AGENT" ] || [ -z "$ITEM_ID" ]; then
  echo "usage: $0 start|done|fail <agent> <item_id> [--summary=...] [--tool=...]" >&2
  exit 2
fi

case "$CMD" in
  start|done|fail) ;;
  *) echo "unknown subcommand: $CMD" >&2; exit 2 ;;
esac

TOOL="${SDLC_TOOL:-}"
SUMMARY=""
for arg in "$@"; do
  case "$arg" in
    --tool=*)    TOOL="${arg#--tool=}" ;;
    --summary=*) SUMMARY="${arg#--summary=}" ;;
    *) ;; # ignore unknown
  esac
done

# Repo root
ROOT="${SDLC_LOG_ROOT:-}"
if [ -z "$ROOT" ]; then
  ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fi
LOG="$ROOT/automation/agent-runs.jsonl"
RUN_STATE_DIR="$ROOT/automation/.run-state"

warn() { echo "[agent-log] WARN: $*" >&2; }

# Ensure dirs exist; fail-soft on permission error.
mkdir -p "$RUN_STATE_DIR" 2>/dev/null || { warn "cannot create $RUN_STATE_DIR"; exit 0; }
mkdir -p "$(dirname "$LOG")" 2>/dev/null || { warn "cannot create log dir"; exit 0; }

NOW_EPOCH="$(date -u +%s)"
NOW_ISO="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

DURATION="null"
START_FILE="$RUN_STATE_DIR/${AGENT}-${ITEM_ID}.start"

if [ "$CMD" = "start" ]; then
  echo "$NOW_EPOCH" > "$START_FILE" 2>/dev/null || warn "cannot write $START_FILE"
else
  if [ -f "$START_FILE" ]; then
    START_EPOCH="$(cat "$START_FILE" 2>/dev/null || echo "")"
    if [ -n "$START_EPOCH" ]; then
      DURATION=$(( NOW_EPOCH - START_EPOCH ))
      if [ "$DURATION" -lt 0 ]; then DURATION="null"; fi
    fi
    rm -f "$START_FILE" 2>/dev/null || true
  fi
fi

# JSON-escape function for strings: handles \, ", control chars.
# Pass the raw value via env var to avoid the trailing newline that bash
# herestrings (`<<<`) inject before stdin.
json_escape() {
  AGENT_LOG_RAW="$1" python3 -c '
import json, os, sys
sys.stdout.write(json.dumps(os.environ.get("AGENT_LOG_RAW", "")))
'
}

AGENT_J="$(json_escape "$AGENT")"
ITEM_J="$(json_escape "$ITEM_ID")"
STATUS_J="$(json_escape "$CMD")"
if [ -n "$TOOL" ]; then TOOL_J="$(json_escape "$TOOL")"; else TOOL_J="null"; fi
if [ -n "$SUMMARY" ]; then SUMMARY_J="$(json_escape "$SUMMARY")"; else SUMMARY_J="null"; fi

LINE="{\"ts\":\"$NOW_ISO\",\"agent\":$AGENT_J,\"status\":$STATUS_J,\"item_id\":$ITEM_J,\"tool\":$TOOL_J,\"duration_s\":$DURATION,\"summary\":$SUMMARY_J}"

# Append (atomic for short writes on POSIX local FS).
printf '%s\n' "$LINE" >> "$LOG" 2>/dev/null || { warn "cannot append to $LOG"; exit 0; }

exit 0
