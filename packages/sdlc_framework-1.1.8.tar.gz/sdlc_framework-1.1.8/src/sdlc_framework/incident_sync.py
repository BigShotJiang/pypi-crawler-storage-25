"""Side-effecting helpers for the Incident entity.

`incidents_loader` is read-only: it loads yaml + derives status. This
module owns the writes — creating an incident yaml, scaffolding (or
linking) a kanban hotfix ticket, and (Phase 5) auto-stamping
`restored_at` when a linked ticket reaches `done`.

Conventions:
- Incidents live at ``automation/incidents/<INC-id>.yaml``.
- Hotfix tickets live at ``automation/tickets/<inc-id-hotfix>.yaml``.
  Auto-derived id: ``inc-{INCID-lowercased}-hotfix``.
- All timestamps are UTC ISO-8601 with trailing ``Z``.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import yaml


class IncidentSyncError(Exception):
    """Raised when an incident write cannot complete."""


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def hotfix_ticket_id(incident_id: str) -> str:
    """Derive the auto-created kanban ticket slug for an incident.

    ``INC-42`` -> ``inc-42-hotfix``. The id is lowercased so it survives
    case-sensitive filesystems and remains a valid yaml filename.
    """
    return f"{incident_id.lower()}-hotfix"


def write_incident(
    target: Path,
    incident_id: str,
    *,
    title: str,
    severity: str,
    description: str,
    root_cause: str | None = None,
    fix_ticket_id: str | None = None,
    extra: dict | None = None,
) -> Path:
    """Create ``automation/incidents/<id>.yaml``.

    Refuses to overwrite an existing incident — the caller (CLI) checks
    for duplicates first and reports a clear error to the user.
    """
    idir = target / "automation" / "incidents"
    idir.mkdir(parents=True, exist_ok=True)
    path = idir / f"{incident_id}.yaml"
    if path.exists():
        raise IncidentSyncError(f"incident already exists: {path}")

    body: dict = {
        "id": incident_id,
        "title": title,
        "severity": severity,
        "opened_at": _utc_now_iso(),
        "status": "open",
        "description": description,
    }
    if root_cause:
        body["root_cause"] = root_cause
    if fix_ticket_id:
        body["fix_ticket_id"] = fix_ticket_id
    if extra:
        body.update(extra)

    path.write_text(yaml.safe_dump(body, sort_keys=False), encoding="utf-8")
    return path


def create_hotfix_ticket(
    target: Path,
    incident_id: str,
    *,
    title: str,
    severity: str,
    description: str,
    ticket_id: str | None = None,
) -> Path:
    """Auto-create ``automation/tickets/<inc-id-hotfix>.yaml``.

    The ticket is back-linked to the incident via ``incident_id`` so the
    engine can cross-reference both directions during scan.
    """
    tdir = target / "automation" / "tickets"
    tdir.mkdir(parents=True, exist_ok=True)
    tid = ticket_id or hotfix_ticket_id(incident_id)
    path = tdir / f"{tid}.yaml"
    if path.exists():
        raise IncidentSyncError(f"hotfix ticket already exists: {path}")

    body = {
        "id": tid,
        "kind": "hotfix",
        "incident_id": incident_id,
        "title": f"Hotfix: {title}",
        "priority": severity,
        "status": "todo",
        "created_at": _utc_now_iso(),
        "description": description,
    }
    path.write_text(yaml.safe_dump(body, sort_keys=False), encoding="utf-8")
    return path


def close_incident(
    target: Path,
    incident_id: str,
    *,
    closed_at: str,
    restored_at: str,
    mttr_min: int | None,
    summary: str | None = None,
) -> Path:
    """Mark the incident yaml as closed (terminal state).

    Preserves every existing field and merges in:
    - ``status: closed``
    - ``closed_at``     (UTC ISO-8601 with trailing Z)
    - ``restored_at``   (frozen from derive_incident_status if not already set)
    - ``mttr_min``      (when known)
    - ``close_summary`` (optional ``-m`` annotation)

    Refuses to operate on a missing file (returns IncidentSyncError so the
    CLI can surface a clean message instead of a stack trace).
    """
    ipath = target / "automation" / "incidents" / f"{incident_id}.yaml"
    if not ipath.exists():
        raise IncidentSyncError(f"incident not found: {incident_id}")
    try:
        data = yaml.safe_load(ipath.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise IncidentSyncError(f"malformed incident yaml: {exc}") from exc
    if not isinstance(data, dict):
        raise IncidentSyncError(f"incident yaml is not a mapping: {ipath}")

    # Refuse to re-close. The CLI guards this too, but future callers
    # (Phase 5 sync hooks) need the helper itself to be safe — otherwise
    # a re-close would silently overwrite the original closed_at and
    # corrupt the audit trail.
    if data.get("status") == "closed":
        raise IncidentSyncError(
            f"incident already closed at {data.get('closed_at')}: {incident_id}"
        )

    data["status"] = "closed"
    data["closed_at"] = closed_at
    # Only freeze restored_at if not already pinned (e.g. operator wrote it
    # by hand). Same idempotent merge for mttr_min.
    data.setdefault("restored_at", restored_at)
    if mttr_min is not None:
        data.setdefault("mttr_min", mttr_min)
    if summary:
        data["close_summary"] = summary

    ipath.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return ipath


def auto_restore_on_ticket_done(target: Path) -> list[str]:
    """Stamp ``restored_at`` on every incident whose fix ticket reached ``done``.

    Walks ``automation/incidents/*.yaml`` and, for each incident that:

    1. is not already ``status: closed`` (terminal), AND
    2. has a ``fix_ticket_id`` linked, AND
    3. that fix ticket exists with ``status: done``, AND
    4. does not already have ``restored_at`` on its yaml,

    writes ``restored_at`` (UTC ISO-8601 with trailing ``Z``) onto the
    incident yaml. Returns the list of incident ids that were touched
    so the caller (engine scan loop) can log / notify.

    Idempotent by design: condition (4) prevents re-stamping. An
    operator-written ``restored_at`` is honoured verbatim — never
    overwritten.

    Defensive: malformed yaml, missing tickets, and dangling
    ``fix_ticket_id`` references are silently skipped (same policy as
    ``incidents_loader``). The engine must stay green even when one
    incident's data is broken.
    """
    idir = target / "automation" / "incidents"
    if not idir.exists():
        return []

    touched: list[str] = []
    now = _utc_now_iso()

    for ipath in sorted(idir.glob("*.yaml")):
        try:
            data = yaml.safe_load(ipath.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict):
            continue

        # Already closed → terminal, never re-stamp.
        if data.get("status") == "closed":
            continue
        # Operator already pinned restored_at → leave alone.
        if data.get("restored_at"):
            continue

        fix_id = data.get("fix_ticket_id")
        if not fix_id:
            continue

        tpath = target / "automation" / "tickets" / f"{fix_id}.yaml"
        if not tpath.exists():
            continue
        try:
            tdata = yaml.safe_load(tpath.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(tdata, dict):
            continue
        if tdata.get("status") != "done":
            continue

        # All gates passed — stamp.
        data["restored_at"] = now
        ipath.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
        touched.append(data.get("id") or ipath.stem)

    return touched


def link_existing_ticket(
    target: Path,
    incident_id: str,
    ticket_id: str,
) -> Path:
    """Backlink an existing kanban ticket to the new incident.

    Mutates ``automation/tickets/<ticket_id>.yaml`` to add
    ``incident_id``. All other fields are preserved verbatim — this is
    a one-key merge, never a rewrite.
    """
    tpath = target / "automation" / "tickets" / f"{ticket_id}.yaml"
    if not tpath.exists():
        raise IncidentSyncError(f"ticket not found: {tpath}")
    try:
        data = yaml.safe_load(tpath.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise IncidentSyncError(f"malformed ticket yaml: {exc}") from exc
    if not isinstance(data, dict):
        raise IncidentSyncError(f"ticket yaml is not a mapping: {tpath}")
    data["incident_id"] = incident_id
    tpath.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return tpath
