---
name: sdlc-verify
description: Mark a Phase 1/2/4 artifact as verified.
---
# /verify

Run `sdlc verify <item-id>`.

Mark a Phase 1/2/4 artifact as verified.
