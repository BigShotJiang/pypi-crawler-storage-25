---
name: sdlc-scan
description: Run the SDLC engine and refresh state.json.
---
# /scan

Run `sdlc scan [--print]`.

Run the SDLC engine and refresh state.json.
