---
name: sdlc-story-new
description: Scaffold a new story under an epic.
---
# /story-new

Run `sdlc story new <slug> [--epic <epic>] [--title "..."]`.

Scaffold a new story under an epic.
