---
name: sdlc-next
description: Print a paste-ready prompt for the next pending DoD item.
---
# /next

Run `sdlc next `.

Print a paste-ready prompt for the next pending DoD item.
