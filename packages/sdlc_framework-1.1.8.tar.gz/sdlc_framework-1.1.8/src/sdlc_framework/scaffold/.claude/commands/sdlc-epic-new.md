---
name: sdlc-epic-new
description: Scaffold a new epic.
---
# /epic-new

Run `sdlc epic new <slug> [--title "..."]`.

Scaffold a new epic.
