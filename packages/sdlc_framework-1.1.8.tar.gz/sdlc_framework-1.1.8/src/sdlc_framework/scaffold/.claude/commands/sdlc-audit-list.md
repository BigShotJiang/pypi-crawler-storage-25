---
name: sdlc-audit-list
description: List forced-skip-review audit entries.
---
# /audit-list

Run `sdlc audit list `.

List forced-skip-review audit entries.
