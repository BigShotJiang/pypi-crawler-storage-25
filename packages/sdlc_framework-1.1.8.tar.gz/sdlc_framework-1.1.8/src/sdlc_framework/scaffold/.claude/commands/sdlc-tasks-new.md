---
name: sdlc-tasks-new
description: Add a Phase 3 task definition.
---
# /tasks-new

Run `sdlc tasks new <id>`.

Add a Phase 3 task definition.
