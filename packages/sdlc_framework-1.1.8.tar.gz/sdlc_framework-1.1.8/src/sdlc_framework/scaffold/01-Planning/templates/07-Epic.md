---
slug: {{epic-slug}}
title: {{Epic Title}}
goal: {{One-sentence goal}}
review: true
review_skipped_by: null
review_skip_reason: null
review_skip_at: null
created_at: {{YYYY-MM-DD}}
---

# Epic: {{Epic Title}}

## Goal
{{One paragraph: what this epic achieves and why it matters.}}

## Stories
- {{story-slug-1}}
- {{story-slug-2}}
- {{story-slug-3}}

## Requirements & Constraints
{{Functional and non-functional requirements relevant to this epic. Quantify where possible (p95, RTO, etc.).}}

## Technical Decisions
{{Architecture decisions, constraints, patterns, data models, and conventions. Reference ADRs by ID where applicable.}}

## UX & Interaction Patterns
{{Optional. Relevant UX flows, interaction patterns, design constraints.}}

## Cross-Story Dependencies
{{Optional. Dependencies between stories in this epic or with other epics/systems.}}
