---
slug: {{story-slug}}
title: {{Story Title}}
epic: {{epic-slug-or-omit-if-orphan}}
review: true
review_skipped_by: null
review_skip_reason: null
review_skip_at: null
depends_on: []
created_at: {{YYYY-MM-DD}}
---

# Story: {{Story Title}}

## User Story
As a {{actor}}
I want to {{capability}}
So that {{value}}

## Acceptance Criteria (Given/When/Then)
- Given {{precondition}}, When {{action}}, Then {{expected outcome}}
- Given {{precondition}}, When {{action}}, Then {{expected outcome}}

## Dev Notes
{{Technical context for developer-agent: relevant files, patterns, gotchas, links to ADRs.}}

## Suggested Tasks
- {{task-id-1}}: {{brief description}}
- {{task-id-2}}: {{brief description}}
