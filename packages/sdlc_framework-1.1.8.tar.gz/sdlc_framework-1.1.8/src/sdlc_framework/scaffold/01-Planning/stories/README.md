# Stories — `01-Planning/stories/`

This directory holds **per-story files** (markdown). Stories are the middle tier of the v1.0 hierarchy:

```
PRD → Epic (optional) → Story (here) → Task
```

A Story may belong to a parent Epic, or be **orphan** (standalone, no Epic). Both shapes are first-class.

## Authoring flow

1. `sdlc story new <slug>` — scaffolds `01-Planning/stories/<slug>.md` from `templates/08-Story.md`
2. Edit the markdown — fill in As-a/I-want/So-that, at least 2 Given/When/Then acceptance criteria, dev notes, suggested tasks
3. `sdlc story complete-draft <slug>` — gate: marks the story as `ready` for task bootstrap
4. `sdlc tasks bootstrap <story-slug>` — generates Phase 3 task yaml stubs from the suggested-tasks list

## Story state machine (v1.1.0)

```
draft → ready → in-progress → done → deployed (terminal)
       ↑           ↑          ↑          ↑
   manual gate   activate    PR open    PR merged
   (complete-    (sdlc story  (sdlc      (engine
    draft)        activate)   gh-pr)     auto)
```

- `draft → ready` is a manual gate (`complete-draft`).
- `ready → in-progress` requires `sdlc story activate <slug>` (acquires the
  Phase 3 serial lock; only one story may be in-progress at a time).
- `in-progress → done` happens when the story's umbrella PR is opened.
- `done → deployed` happens when the engine confirms PR merge.
- `done → in-progress` rollback fires automatically when the engine
  detects a closed-but-unmerged PR.

## Replaces the old monolith

In v0.x the framework used a single `01-Planning/02-User-Stories.md` file. v1.0 splits this into per-story `.md` files for cleaner authoring, review, and dashboard rendering.

The legacy monolith file is kept for backward template reference but is no longer the primary authoring surface.
