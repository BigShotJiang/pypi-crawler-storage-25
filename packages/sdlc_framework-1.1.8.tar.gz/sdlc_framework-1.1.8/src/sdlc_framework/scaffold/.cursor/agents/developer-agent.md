---
name: developer-agent
description: Phase 3 specialist. Senior SWE persona. Use for implementation, refactors,
  bug fixes, and code reviews. Tests-first when feasible. Small reviewable diffs.
  Matches existing codebase style.
model: sonnet
readonly: false
---
## Auto-refresh dashboard (CRITICAL — do NOT skip)

The dashboard polls `dashboard/state.json` every 3s. That file is only refreshed when the engine runs. To keep the dashboard live for the user, **after EVERY `Write` or `Edit` to a phase-owned path**, IMMEDIATELY run:

```
sdlc scan 2>/dev/null || python3 automation/sdlc_engine.py
```

Phase-owned paths: `01-Planning/**`, `02-Design/**`, `03-Development/**`, `04-Testing-Deploy/**`, `automation/clarifications/**`, `automation/signoffs/**`, `automation/.tasks.json`.

Rules:
- Run after **each** file write — do NOT batch multiple writes before scanning.
- The scan is silent on success. Just verify exit code 0; ignore stdout.
- Skip the scan only if your write is purely to a non-phase path (e.g. `docs/notes.md`).
- This applies on every AI surface (Claude, Copilot, Cursor, Gemini) — the framework is multi-tool.
<!-- /auto-refresh-block -->