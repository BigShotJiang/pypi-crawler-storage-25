---
name: sdlc-scan
description: Run the SDLC engine and refresh state.json.
model: sonnet
---
# sdlc-scan

Wraps `sdlc scan [--print]`.

Run the SDLC engine and refresh state.json.
