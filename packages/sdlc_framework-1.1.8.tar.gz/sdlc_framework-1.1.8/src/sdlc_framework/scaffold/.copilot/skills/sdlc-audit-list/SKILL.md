---
name: sdlc-audit-list
description: List forced-skip-review audit entries.
model: sonnet
---
# sdlc-audit-list

Wraps `sdlc audit list `.

List forced-skip-review audit entries.
