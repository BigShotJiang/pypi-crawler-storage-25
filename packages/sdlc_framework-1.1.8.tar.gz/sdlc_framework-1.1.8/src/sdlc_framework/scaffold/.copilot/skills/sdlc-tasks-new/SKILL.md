---
name: sdlc-tasks-new
description: Add a Phase 3 task definition.
model: sonnet
---
# sdlc-tasks-new

Wraps `sdlc tasks new <id>`.

Add a Phase 3 task definition.
