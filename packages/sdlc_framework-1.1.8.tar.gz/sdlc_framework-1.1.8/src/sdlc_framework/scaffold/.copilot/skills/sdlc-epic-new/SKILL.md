---
name: sdlc-epic-new
description: Scaffold a new epic.
model: sonnet
---
# sdlc-epic-new

Wraps `sdlc epic new <slug> [--title "..."]`.

Scaffold a new epic.
