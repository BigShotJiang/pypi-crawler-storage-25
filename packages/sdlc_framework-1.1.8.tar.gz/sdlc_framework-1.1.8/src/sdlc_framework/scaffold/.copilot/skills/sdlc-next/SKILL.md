---
name: sdlc-next
description: Print a paste-ready prompt for the next pending DoD item.
model: sonnet
---
# sdlc-next

Wraps `sdlc next `.

Print a paste-ready prompt for the next pending DoD item.
