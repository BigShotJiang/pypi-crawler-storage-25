---
name: sdlc-ticket-new
description: Create a non-feature work item (bug/chore/hotfix/support).
model: sonnet
---
# sdlc-ticket-new

Wraps `sdlc ticket new <slug> --kind=<bug|chore|hotfix|support>`.

Create a non-feature work item (bug/chore/hotfix/support).
