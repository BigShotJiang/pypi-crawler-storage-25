---
name: sdlc-story-new
description: Scaffold a new story under an epic.
model: sonnet
---
# sdlc-story-new

Wraps `sdlc story new <slug> [--epic <epic>] [--title "..."]`.

Scaffold a new story under an epic.
