# SDLC Agent Loop — How AI Drives the SDLC Autonomously

> Đây là **runbook duy nhất** cho mọi AI tool (Claude / Codex / Cursor / Aider / Copilot Chat) khi chạy ở chế độ agent / autonomous trong repo này.
>
> Các tool config (`CLAUDE.md`, `AGENTS.md`, `.cursorrules`...) đều phải point về file này.

> 💡 **Agent roster**: từ Phase 2 trở đi, đừng dùng "1 prompt cho tất cả". Hệ thống có 9 specialist agents trong `agents/` — orchestrator gọi đúng người cho đúng việc. Xem `agents/README.md` để biết ai làm gì. Để biết next agent: `python3 scripts/sdlc-dispatch.py`.

---

## Mục tiêu của agent loop

Đẩy SDLC tự động qua 4 phases:
**Planning → Design → Development → Testing/Deploy**

— với sự can thiệp của user **chỉ khi gặp 1 trong 4 trường hợp**:

1. 🔍 **Ambiguity / không đủ thông tin** — không thể tự suy luận
2. ⚔️ **Conflict** — 2 nguồn yêu cầu mâu thuẫn nhau
3. 🚪 **Gate** — cần human approve (PRD signoff, design review, prod deploy)
4. 🛑 **High-risk action** — auth / crypto / payment / data deletion

Mọi trường hợp khác: **agent tự quyết, tự làm, tự verify**.

---

## Loop (mỗi turn agent chạy như sau)

```
┌──────────────────────────────────────────────────────────────┐
│ 1. Read state                                                │
│    - automation/state.json   (tiến độ hiện tại)              │
│    - automation/rules.json   (DoD criteria)                  │
│    - automation/clarifications/*.md  (questions chờ user)    │
│    - automation/signoffs/*.yaml      (gates đã approve)      │
│                                                              │
│ 2. Choose next action                                        │
│    - Tìm phase nhỏ nhất chưa 100%                            │
│    - Trong phase đó, tìm item đầu tiên `done: false`        │
│    - Nếu item.gate set và signoff chưa có → STOP, ask user  │
│    - Nếu item phụ thuộc upstream chưa xong → STOP            │
│                                                              │
│ 3. Plan the work                                             │
│    - Đọc rules.json → biết check nào cần pass                │
│    - Đọc template tương ứng (01-Planning/templates/...)     │
│    - Đọc context: prior phase outputs + AI configs          │
│    - Output 1-paragraph plan                                 │
│                                                              │
│ 4. Detect blockers BEFORE acting                             │
│    - Có ambiguity? → tạo clarification, STOP                │
│    - Có conflict với existing artifact? → tạo clarif, STOP  │
│    - High-risk file/action? → STOP, ask user                │
│                                                              │
│ 5. Execute (small steps)                                    │
│    - Chỉ touch files cần thiết                              │
│    - Match style của neighbor files                          │
│    - Không thêm dependency mới mà không hỏi                 │
│                                                              │
│ 6. Verify                                                    │
│    - Chạy: python3 automation/sdlc_engine.py                │
│    - Item vừa làm phải `done: true` trong state.json        │
│    - Nếu không → debug, lặp lại bước 5                      │
│                                                              │
│ 7. Commit (Conventional Commits + AI trailer)               │
│    - feat(<phase>): <subject>                               │
│    - body explains what+why                                  │
│    - Co-authored-by: <agent>                                 │
│                                                              │
│ 8. Loop back to 1 — until tất cả phases 100% hoặc gặp gate  │
└──────────────────────────────────────────────────────────────┘
```

---

## Khi nào STOP và hỏi user

### Trường hợp 1 — Ambiguity / missing info
Khi prompt / artifact hiện có không đủ để tự quyết, **không được đoán**. Tạo file:

```
automation/clarifications/<NNN>-<short-slug>.md
```

Format:
```markdown
# <Câu hỏi ngắn>

**Phase**: 1
**DoD item**: prd-exists
**Created by**: <agent name>
**Created at**: 2026-04-30T10:00:00Z

## Why I'm asking
<1 paragraph: ambiguity nằm ở đâu, tại sao không tự suy luận được>

## Options I considered
- **Option A**: ...
  - Pro: ...
  - Con: ...
- **Option B**: ...
- **Option C** (recommended): ...

## What I need from user
- Một câu trả lời cụ thể, hoặc
- Thêm context (link tài liệu / số liệu / decision)

## Will resume by
Sau khi user reply trong file này (thêm `STATUS: resolved` ở trên cùng) hoặc tạo file mới `signoffs/<gate>.yaml`.
```

Agent **không** tiếp tục item này cho đến khi clarification được resolve.

### Trường hợp 2 — Conflict
Ví dụ: PRD nói latency < 200ms nhưng Architecture đề xuất kiến trúc chỉ đạt < 500ms.

Tạo `clarifications/<NNN>-conflict-<slug>.md` với cả 2 nguồn quote nguyên văn + 2 options resolve.

### Trường hợp 3 — Gate
Item có field `gate` (xem rules.json). Agent **không bao giờ** tự tạo signoff. Phải:
1. Tạo evidence package: tóm tắt artifacts, link diff, ảnh hưởng, rollback plan.
2. Output message: "Gate `<id>` đang chờ approval. Evidence: ...". Stop.
3. User tạo `automation/signoffs/<gate-id>.yaml` với `approved: true` để tiếp tục.

### Trường hợp 4 — High-risk action
Tự động STOP khi sắp:
- Edit code trong path chứa: `auth`, `crypto`, `payment`, `migrations` (nếu DB), `iam`, `secrets`
- Xoá file > 100 dòng hoặc > 5 file 1 lúc
- `git push --force`, `rm -rf`, `DROP TABLE`, `DELETE FROM ... WHERE 1=1`
- Thêm dependency mới
- Thay đổi `.github/workflows/`

→ Output message: "High-risk action detected: <mô tả>. Need user approval to proceed."

---

## Hard rules

| Rule | Why |
|---|---|
| Never edit `automation/state.json` directly | Chỉ engine được sinh ra. Agent ghi vào nó là tampering. |
| Never edit `automation/signoffs/` | Đó là decision của user, agent không tự ký. |
| Never edit prior signed artifacts mà không tạo ADR | Truy vết quyết định. |
| Never bypass gate by creating signoff yourself | Gate exists for human-in-the-loop. |
| Always commit per logical step | Để revert được. |
| Always run `sdlc_engine.py --print` sau mỗi commit | Để trạng thái đồng bộ. |

---

## Cách AI đọc state ở mỗi turn

```bash
# 1. Refresh
python3 automation/sdlc_engine.py

# 2. Read
cat automation/state.json
```

Trong state, tìm:
- `phases[].items[]` với `done: false` → việc tiếp theo
- `gates[]` với `approved: false` → đang block phase đó
- `clarifications[]` → questions đang chờ — không tiếp tục item liên quan

---

## Example agent turn (Claude in agent mode)

```
[Agent]
Reading automation/state.json...
Current state: Phase 1 = 50% (3/6). Next pending: "user-stories-with-ac".

DoD rule wants: file matching 01-Planning/**/*User-Stor*.md containing
Given/When/Then.

Reading 01-Planning/templates/02-User-Stories.md (template).
Reading 01-Planning/templates/01-PRD.md (filled, source of stories).

Plan: derive 5 user stories from PRD §7 (Functional Requirements).
Will write to 01-Planning/User-Stories.md (NOT overwriting template).

No ambiguity detected. Proceeding.

[writing 01-Planning/User-Stories.md]
[running: python3 automation/sdlc_engine.py --print]
[verify] item user-stories-with-ac → done: true ✓

[git commit]
feat(planning): derive 5 user stories from PRD

Generated from FR-001..FR-005. Each story has Given/When/Then ACs.
Refs PROJ-PLN-001.

Co-authored-by: Claude <noreply@anthropic.com>
```

---

## Example STOP turn (clarification needed)

```
[Agent]
Reading state... Next pending: "nfr-quantified".
Rule wants: requirements file containing one of [p95, p99, rps, %, uptime, SLO].

Reading 01-Planning/templates/03-Requirements-Spec.md... template still has
{{...}} placeholders. PRD has no concrete numbers either.

Cannot infer SLO numbers without sponsor input.

[creating automation/clarifications/001-nfr-targets.md]

# Cần SLO targets cụ thể cho NFR

**Phase**: 1   **Item**: nfr-quantified

## Why I'm asking
PRD chỉ nói "high performance" mà không có số. Tôi không thể tự đặt SLO.

## Options
- A: Inherit từ team default — p95 < 300ms, 99.9% uptime
- B: Tighter — p95 < 150ms, 99.95% (tăng infra cost ~2x)
- C: Looser — p95 < 500ms, 99.5% (rẻ, suitable cho non-critical)

## Recommend
A — phù hợp cho hầu hết user-facing API.

[STOP — waiting for user reply]
```

User reply by editing the clarification file (`STATUS: resolved` + chosen option), then agent resumes.

---

## Cho từng AI tool — point họ tới file này

### Claude (`ai-tools/claude/CLAUDE.md`)
> Trong "How Claude should work", đã có. Đảm bảo line: "When in agent mode, follow `automation/AGENT-LOOP.md` strictly."

### Cursor (`.cursorrules`)
> Add: "If asked to drive SDLC: read and follow `automation/AGENT-LOOP.md`."

### Codex (`AGENTS.md`)
> Add: "Autonomous mode: follow `automation/AGENT-LOOP.md`. Never bypass STOP triggers."

### Aider (`.aider.conf.yml`)
> Add `automation/AGENT-LOOP.md` to the `read:` list.

---

## Failure modes & how to recover

| Symptom | Likely cause | Action |
|---|---|---|
| Item won't flip to `done` after edit | Rule pattern mismatch | Read rule in `rules.json`, check exact glob/regex |
| Engine errors out | rules.json malformed JSON | `python3 -c "import json; json.load(open('automation/rules.json'))"` |
| Agent loops on same item | Missing clarification or gate | Manual: create clarification or signoff |
| Dashboard stale | `state.json` not regenerated | `python3 automation/sdlc_engine.py` |

## Phase 3 contract — serial lock (added in 0.15.0)

Only ONE Phase 3 group (one `story_id` or one ungrouped task) is "active" at a time. Inactive tasks always show `stage: pending` regardless of filesystem state — this is by design.

Source of truth: `automation/state.json` → `phase3.active_story_id`.

If your assigned task id is not the active one:
- STOP. Do not write code or tests for it.
- Run `sdlc auto-step` — it will route you to the active task or surface a stop reason.
- If you believe the wrong task is active, write a clarification — DO NOT edit state.json.

If you observe two tasks both at `write-code` simultaneously, the state machine is corrupted. STOP and write a clarification with the file listing of both tasks.

### Filesystem-is-contract (spec §11)

The v1.0 engine never holds in-memory state across actions. Every state
transition is mediated by a file on disk:

- **State** — `automation/state.json` (engine-generated; never user-edited)
- **Epics / Stories / Tasks** — yaml under `automation/{epics,stories,tasks}/`
- **Reviews** — `automation/reviews/<artifact>-<reviewer>-<ts>.md` (one
  file per reviewer; consolidator reads all + writes summary)
- **Audit** — `automation/audit/forced-skip-<id>.yaml` (only when force-skip)
- **Adopt manifest** — `automation/.adopt-manifest.json` (created by
  `sdlc adopt`, consumed by `sdlc adopt --rollback`)

This makes parallel-vs-sequential dispatch produce identical end-states.
The orchestrator agent dispatches reviewers via the engine's
`invoke-parallel` action; on Cursor (no native parallel), the
orchestrator emits sequential prompts that produce the same review files.

### `invoke-parallel` action contract

When the engine dispatches a multi-reviewer pack, it returns an action
JSON shaped like:

```json
{
  "action": "invoke-parallel",
  "agents": [
    {
      "name": "code-reviewer",
      "brief_path": "automation/.briefs/code-reviewer-<artifact>.md",
      "output_path": "automation/reviews/<artifact>-code-reviewer-<ts>.md"
    },
    {
      "name": "security-reviewer",
      "brief_path": "automation/.briefs/security-reviewer-<artifact>.md",
      "output_path": "automation/reviews/<artifact>-security-reviewer-<ts>.md"
    },
    {
      "name": "edge-case-reviewer",
      "brief_path": "automation/.briefs/edge-case-reviewer-<artifact>.md",
      "output_path": "automation/reviews/<artifact>-edge-case-reviewer-<ts>.md"
    }
  ],
  "consolidate_after": "automation/reviews/<artifact>-summary.md"
}
```

The action JSON is **identical regardless of `SDLC_TOOL`**. Tool-side
orchestrator turns it into:

- **Claude Code** — single message with multiple `Task` tool_use blocks
  (true parallel)
- **Copilot CLI** — `copilot-sdk` JSON-RPC concurrent sessions (or
  sequential fallback)
- **Cursor** — three sequential `/agent` prompts (autopilot or user
  advances)

All three end with the same set of review files on disk and the
consolidator runnable.

### `--no-review` flag (spec §8)

Project owners may skip the review pack on a per-artifact basis with
`--no-review` on `sdlc story new`, `sdlc epic new`, `sdlc tasks new`,
`sdlc ticket new`, or `sdlc verify`. The engine refuses bypass on artifacts
that touch sensitive paths (`src/auth/**`, `src/payment/**`, `src/crypto/**`,
`src/secrets/**`, `migrations/**`, `infra/iam/**`) or sensitive topics
(`auth`, `crypto`, `payment`, `secrets`, `migrations`, `webhooks`). The
escape hatch is `--force-skip-review --reason="..."`, which writes a
git-tracked audit yaml under `automation/audit/forced-skip-<id>.yaml`.

In CI mode (CI=true or non-tty stdin), `--reason` is mandatory whenever
`--force-skip-review` is used. Inspection: `sdlc audit list`.

### Dashboard hierarchy + kanban (spec §9)

`state.json` exposes a flat `tasks[]` array (PR 7). Each entry has
`id`, `label`, `story_id`, `epic_id`, `kind`, `stage`, `priority`,
`review`. The dashboard's hierarchy view groups them under
`epics[]`/`stories[]`; kanban view filters to `kind != feature OR
story_id == null`. Filter chips and expand state are client-only
(localStorage key `sdlc.expand`).

### Multi-tool parity (spec §11)

The engine is tool-agnostic: `auto-step` / `auto-mad-step` / `next` JSON
output is identical regardless of which AI runtime is active. Tool-specific
divergence is confined to:

- **Frontmatter format** of rendered agents — see `sdlc render-agents`
- **Orchestrator dispatch** — Claude uses parallel `Task` calls; Copilot
  uses `copilot-sdk` JSON-RPC (or sequential fallback); Cursor uses 3
  sequential `/agent` prompts. All three end with the same review files
  on disk and the same consolidator verdict.

Active tool resolved via `SDLC_TOOL` env var (claude / copilot / cursor)
or filesystem markers (`.claude/`, `.cursor/`, `.copilot/`). Default:
`claude`.

### Adopt manifest (spec §12)

`sdlc adopt` writes `automation/.adopt-manifest.json` recording every
action it took (`mkdir`, `write`, `symlink`, `yaml-add`). `sdlc adopt
--rollback` replays in reverse to undo those actions. Files modified by
the user post-adopt are detected (via sha256) and left intact. The
manifest is committed to git so rollback works on fresh clones.
