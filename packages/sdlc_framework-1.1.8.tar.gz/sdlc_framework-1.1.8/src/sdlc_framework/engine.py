#!/usr/bin/env python3
"""
SDLC Auto-Detection Engine.

Reads automation/rules.json, scans the repo, evaluates each DoD check,
and writes automation/state.json + dashboard/state.json (the dashboard reads it).

Zero external deps. Run:
    python3 automation/sdlc_engine.py
or watch mode:
    python3 automation/sdlc_engine.py --watch

Exit codes:
    0  scan succeeded
    1  scan error (config / IO)
"""

from __future__ import annotations
import argparse
import datetime as dt
import glob as globlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

from sdlc_framework.project_loader import load_project, DEFAULTS as PROJECT_DEFAULTS
from sdlc_framework.schema_versions import (
    LEGACY_STATE_SCHEMA_VERSIONS,
    STATE_SCHEMA_VERSION,
)

# Default ROOT is the cwd at module-load time; override via set_root().
ROOT = Path(os.environ.get("SDLC_LOG_ROOT") or os.getcwd()).resolve()
RULES_PATH = ROOT / "automation" / "rules.json"
STATE_PATH = ROOT / "automation" / "state.json"
DASHBOARD_STATE = ROOT / "dashboard" / "state.json"
CLARIFICATIONS_DIR = ROOT / "automation" / "clarifications"
SIGNOFFS_DIR = ROOT / "automation" / "signoffs"

PROJECT_CLARIFICATION_FILE = "000-project-yaml.md"

AGENT_RUNS_PATH = ROOT / "automation" / "agent-runs.jsonl"
AGENT_RUNS_DASHBOARD_LIMIT = 20
AGENT_RUNS_REQUIRED_FIELDS = ("ts", "agent", "status", "item_id")
NOTIFY_SCRIPT = ROOT / "scripts" / "notify.sh"
REPLAN_PATH = ROOT / "automation" / ".replan.json"


def load_replan() -> dict:
    """Read automation/.replan.json. Returns {} when absent/invalid.

    Schema: {"dirty_items": ["item-id-1", ...], "reason": "...", "ts": "..."}
    """
    if not REPLAN_PATH.exists():
        return {}
    try:
        return json.loads(REPLAN_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_replan(data: dict) -> None:
    REPLAN_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPLAN_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def clear_replan() -> None:
    if REPLAN_PATH.exists():
        REPLAN_PATH.unlink()


def set_root(path: Path | str) -> None:
    """Re-anchor all path constants to a new root.

    Backward-compat shim. New code should construct a
    :class:`sdlc_framework.project.Project` and call ``project.activate()``
    instead — ``Project`` carries the path map cleanly and is testable
    without touching globals. ``set_root`` now delegates to ``Project``
    under the hood and additionally updates the legacy globals that have
    no Project equivalent (``CLARIFICATIONS_DIR``, ``AGENT_RUNS_PATH``,
    etc.) so older callers keep working.
    """
    from sdlc_framework.project import Project
    global ROOT, RULES_PATH, STATE_PATH, DASHBOARD_STATE
    global CLARIFICATIONS_DIR, SIGNOFFS_DIR, AGENT_RUNS_PATH, NOTIFY_SCRIPT, REPLAN_PATH
    proj = Project.from_path(path)
    proj.activate()  # sets ROOT, RULES_PATH, STATE_PATH, DASHBOARD_STATE, CURRENT_PROJECT_CTX
    # Update remaining legacy globals not yet on Project. Move these
    # onto Project incrementally as call sites get migrated.
    CLARIFICATIONS_DIR = proj.clarifications_dir
    SIGNOFFS_DIR = proj.signoffs_dir
    AGENT_RUNS_PATH = ROOT / "automation" / "agent-runs.jsonl"
    NOTIFY_SCRIPT = ROOT / "scripts" / "notify.sh"
    REPLAN_PATH = ROOT / "automation" / ".replan.json"
    # PR 6 — refuse to operate when project.yaml strictly narrows the baseline.
    from sdlc_framework.sensitive_paths import validate_baseline
    validate_baseline(path)


def current_project() -> "Project":
    """Return the currently active :class:`Project`.

    Falls back to constructing one from ``ROOT`` if no project has been
    explicitly activated yet — matches the legacy "globals are the truth"
    behavior so callers never get ``None``.
    """
    from sdlc_framework.project import Project
    if CURRENT_PROJECT_CTX is None:
        return Project.from_path(ROOT)
    return CURRENT_PROJECT_CTX


# ---------------------------------------------------------------------------
# Module-level slots managed by Project.activate / set_root.
# CURRENT_PROJECT_CTX holds the live Project context (new abstraction).
# _ACTIVE_PROJECT is a project.yaml config dict (legacy, separate concern).
# Keep the names distinct.
# ---------------------------------------------------------------------------

CURRENT_PROJECT_CTX = None  # type: ignore[assignment]

_ACTIVE_PROJECT: dict | None = None


def _set_active_project(project: dict) -> None:
    global _ACTIVE_PROJECT
    _ACTIVE_PROJECT = project

# Files / globs we never scan
IGNORE_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build", ".next"}

PLACEHOLDER_RE = re.compile(r"\{\{[A-Z_][A-Z0-9_]*\}\}")


# ---------- helpers ----------

def _glob(pattern: str) -> list[Path]:
    """Recursive glob from repo root, ignoring noisy dirs."""
    pattern = pattern.lstrip("/")
    # support brace expansion for extensions {js,ts}
    patterns = _expand_braces(pattern)
    out: list[Path] = []
    for pat in patterns:
        for p in globlib.glob(str(ROOT / pat), recursive=True):
            path = Path(p)
            if any(part in IGNORE_DIRS for part in path.parts):
                continue
            if path.is_file():
                out.append(path)
    # dedupe
    return list({p.resolve() for p in out})


def _expand_braces(pattern: str) -> list[str]:
    """Tiny brace expander: a/{x,y}/b -> [a/x/b, a/y/b]. Single-level only."""
    m = re.search(r"\{([^{}]+)\}", pattern)
    if not m:
        return [pattern]
    parts = m.group(1).split(",")
    pre, post = pattern[: m.start()], pattern[m.end() :]
    out = []
    for p in parts:
        out.extend(_expand_braces(pre + p + post))
    return out


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""


ISSUE_URL_RE = re.compile(r"^issue_url:\s*(\S+)", re.MULTILINE)


def _extract_issue_url(text: str) -> str | None:
    m = ISSUE_URL_RE.search(text)
    return m.group(1) if m else None


# ---------- check evaluators ----------

def check_file_exists(rule: dict) -> tuple[bool, str]:
    p = ROOT / rule["path"]
    return (p.exists(), f"{rule['path']} {'exists' if p.exists() else 'missing'}")


def check_file_glob_min_count(rule: dict) -> tuple[bool, str]:
    matches = _glob(rule["glob"])
    n = len(matches)
    ok = n >= rule.get("min", 1)
    return (ok, f"{rule['glob']}: found {n} (need ≥ {rule.get('min', 1)})")


def check_file_contains_all(rule: dict) -> tuple[bool, str]:
    matches = _glob(rule["glob"])
    if not matches:
        return (False, f"{rule['glob']}: no files")
    patterns = rule["patterns"]
    missing_per_file: list[str] = []
    any_pass = False
    for f in matches:
        text = _read(f)
        miss = [p for p in patterns if p not in text]
        if not miss:
            any_pass = True
            break
        else:
            missing_per_file.append(f"{f.name}: missing {miss}")
    if any_pass:
        return (True, "patterns matched in ≥ 1 file")
    return (False, "; ".join(missing_per_file)[:200])


def check_file_contains_any(rule: dict) -> tuple[bool, str]:
    matches = _glob(rule["glob"])
    patterns = rule["patterns"]
    for f in matches:
        text = _read(f)
        if any(p in text for p in patterns):
            return (True, f"{f.name} matches one of {patterns}")
    if rule.get("optional_evidence"):
        return (True, f"optional — no {rule['glob']}, skipped")
    return (False, f"none of {patterns} found in {rule['glob']}")


def check_no_unfilled_template(rule: dict) -> tuple[bool, str]:
    matches = _glob(rule["glob"])
    if not matches:
        return (False, f"{rule['glob']}: no files")
    max_p = rule.get("max_placeholders", 5)
    for f in matches:
        n = len(PLACEHOLDER_RE.findall(_read(f)))
        if n <= max_p:
            return (True, f"{f.name}: {n} placeholders (≤ {max_p})")
    return (False, f"all files have > {max_p} placeholders ({{}}-style)")


def check_tdd_pairing(rule: dict) -> tuple[bool, str]:
    """Verify TDD coverage: count test files vs source files for the given globs.

    Fields:
        code_glob:   glob matching production source files
        test_glob:   glob matching test files
        min_ratio:   tests / src minimum (default 1.0 — i.e. 1:1)
        allow_empty: if true, pass when no source files exist (vacuous). Default true.

    The rule does NOT verify that tests were written before code (would require
    git-history parsing). It enforces that for every src file there is at least
    one test file, which is a strong proxy for TDD discipline.
    """
    code_glob = rule.get("code_glob", "")
    test_glob = rule.get("test_glob", "")
    if not code_glob or not test_glob:
        return (False, "tdd_pairing: missing code_glob or test_glob")
    min_ratio = float(rule.get("min_ratio", 1.0))
    allow_empty = bool(rule.get("allow_empty", True))

    src_all = _glob(code_glob)
    test_files = _glob(test_glob)
    test_set = {p.resolve() for p in test_files}
    # Exclude any file that also matches the test glob — common when code_glob is
    # broad like `src/**/*.ts` which would catch `src/foo.test.ts` too.
    src_files = [p for p in src_all if p.resolve() not in test_set]
    n_src = len(src_files)
    n_test = len(test_files)

    if n_src == 0:
        if allow_empty:
            return (True, f"tdd: no source files yet ({code_glob}); vacuous pass")
        return (False, f"tdd: no source files match {code_glob}")

    required = max(1, int(n_src * min_ratio))
    if n_test >= required:
        return (True, f"tdd: {n_test} test(s) ≥ {required} required ({n_src} src × {min_ratio:.2f})")
    return (False, f"tdd: {n_test} test(s) < {required} required ({n_src} src × {min_ratio:.2f}) — write tests first")


def check_regex_min_count(rule: dict) -> tuple[bool, str]:
    matches = _glob(rule["glob"])
    if not matches:
        return (False, f"{rule['glob']}: no files")
    pat = re.compile(rule["pattern"], re.MULTILINE)
    for f in matches:
        n = len(pat.findall(_read(f)))
        if n >= rule.get("min", 1):
            return (True, f"{f.name}: {n} matches")
    return (False, f"none of {rule['glob']} has ≥ {rule.get('min', 1)} matches of /{rule['pattern']}/")


def check_signoff(rule: dict) -> tuple[bool, str]:
    sid = rule["id"]
    f = SIGNOFFS_DIR / f"{sid}.yaml"
    if not f.exists():
        f2 = SIGNOFFS_DIR / f"{sid}.json"
        if f2.exists():
            try:
                data = json.loads(_read(f2))
                ok = bool(data.get("approved"))
                return (ok, f"signoffs/{sid}.json approved={ok}")
            except Exception as e:
                return (False, f"signoffs/{sid}.json invalid: {e}")
        return (False, f"signoff '{sid}' not yet recorded — see automation/signoffs/")
    txt = _read(f).lower()
    ok = "approved: true" in txt or "approved=true" in txt
    return (ok, f"signoffs/{sid}.yaml approved={ok}")


def check_state_field(rule: dict) -> tuple[bool, str]:
    """Read prior state.json field set by external tools (e.g. CI publish)."""
    if not STATE_PATH.exists():
        return (rule.get("optional", False), "no prior state")
    try:
        data = json.loads(_read(STATE_PATH))
        v = data.get("external", {}).get(rule["field"])
        ok = v == rule.get("equals")
        if rule.get("optional") and v is None:
            return (True, f"{rule['field']} unset (optional)")
        return (ok, f"{rule['field']}={v} (need={rule.get('equals')})")
    except Exception:
        return (rule.get("optional", False), "state.json unreadable")


TIER_OWNER_REQUIREMENTS: dict[int, list[str]] = {
    1: ["sponsor", "eng_lead", "security", "sre"],
    2: ["sponsor", "eng_lead", "sre"],
    3: ["sponsor", "eng_lead"],
}


VERIFY_MARKER_RE = re.compile(
    r"<!--\s*sdlc:verified-by:\s*(\S+)\s+(\S+)\s*-->", re.IGNORECASE
)


def check_verified(rule: dict) -> tuple[bool, str]:
    """Scan files matching `glob` for an `<!-- sdlc:verified-by: <name> <ts> -->`
    marker. Pass when ≥ 1 file contains it.

    The marker is written by `sdlc verify <item-id>` or by hand. For retrofits
    via `sdlc adopt`, the marker uses `imported-from-existing` as the name.
    """
    matches = _glob(rule["glob"])
    if not matches:
        return (False, f"verify: no files match {rule['glob']}")
    for f in matches:
        m = VERIFY_MARKER_RE.search(_read(f))
        if m:
            return (True, f"verified-by: {m.group(1)} at {m.group(2)}")
    return (False, f"verify: no `sdlc:verified-by` marker in {rule['glob']} — run `sdlc verify <item-id>`")


def check_owners_required(rule: dict) -> tuple[bool, str]:
    """Verify that project.yaml.owners contains the keys required by tier.

    The engine injects the loaded project into a module-level cache via
    `_set_active_project()` at the start of `scan()`.
    """
    project = _ACTIVE_PROJECT or PROJECT_DEFAULTS
    tier = project.get("tier", 2)
    required = TIER_OWNER_REQUIREMENTS.get(tier, [])
    owners = project.get("owners") or {}
    missing = [k for k in required if not owners.get(k)]
    if not missing:
        return (True, f"tier {tier}: all required owners present ({', '.join(required)})")
    return (False, f"tier {tier}: missing owner(s): {', '.join(missing)}")


CHECKERS = {
    "file_exists": check_file_exists,
    "file_glob_min_count": check_file_glob_min_count,
    "file_contains_all": check_file_contains_all,
    "file_contains_any": check_file_contains_any,
    "no_unfilled_template": check_no_unfilled_template,
    "regex_min_count": check_regex_min_count,
    "signoff": check_signoff,
    "state_field": check_state_field,
    "owners_required": check_owners_required,
    "tdd_pairing": check_tdd_pairing,
    "verified": check_verified,
}


def _checks_for_tier(item: dict, tier: int) -> list[dict]:
    """Pick the right check list for the item given the project tier.

    If the item has `rules_by_tier`, return the list keyed by str(tier),
    falling back to `checks` if the tier key is missing. Otherwise return
    `checks` unchanged. The `applies_to_tiers` field, when present, may
    short-circuit the item to "passes vacuously" for excluded tiers (the
    rule does not apply at this tier).
    """
    applies = item.get("applies_to_tiers")
    if applies is not None and tier not in applies:
        return []  # vacuous pass: item does not apply at this tier
    by_tier = item.get("rules_by_tier")
    if by_tier:
        return by_tier.get(str(tier), item.get("checks", []))
    return item.get("checks", [])


def evaluate_item(item: dict, tier: int = 2) -> dict:
    """Run all checks for a single DoD item. Item passes when all checks pass."""
    checks = _checks_for_tier(item, tier)
    results = []
    all_pass = True
    if not checks:
        # Item does not apply at this tier — vacuous pass.
        return {
            "id": item["id"],
            "label": item["label"],
            "done": True,
            "gate": item.get("gate"),
            "checks": [{"rule": {"type": "tier_skip"}, "ok": True,
                        "msg": f"tier {tier} — rule does not apply"}],
        }
    for rule in checks:
        if rule.get("type") == "any_of_above":
            continue
        fn = CHECKERS.get(rule["type"])
        if fn is None:
            results.append({"rule": rule, "ok": False, "msg": f"unknown check type {rule['type']}"})
            all_pass = False
            continue
        ok, msg = fn(rule)
        if not ok and rule.get("optional_evidence"):
            ok = True
            msg = f"optional — {msg}"
        results.append({"rule": rule, "ok": ok, "msg": msg})
        if not ok:
            all_pass = False
    any_of = next((r for r in checks if r.get("type") == "any_of_above"), None)
    if any_of:
        passing = sum(1 for r in results if r["ok"] and not r["msg"].startswith("optional"))
        all_pass = passing >= any_of.get("min", 1)

    # Compute drafted vs verified split: drafted = all non-`verified` checks pass;
    # verified = the `verified` check (if present) passes. An item is `done` only
    # when both are true.
    has_verify = any(r.get("type") == "verified" for r in checks)
    if has_verify:
        non_verify_results = [r for r in results if r["rule"].get("type") != "verified"]
        verify_result = next((r for r in results if r["rule"].get("type") == "verified"), None)
        drafted = all(r["ok"] for r in non_verify_results) if non_verify_results else True
        verified = bool(verify_result and verify_result["ok"])
    else:
        drafted = all_pass
        verified = all_pass

    return {
        "id": item["id"],
        "label": item["label"],
        "done": all_pass,
        "drafted": drafted,
        "verified": verified,
        "gate": item.get("gate"),
        "agent": item.get("agent"),       # per-item subagent override (Section 4 of spec)
        "subtrack": item.get("subtrack"), # for Phase 2/3 sub-tracks
        "checks": results,
    }


def load_agent_runs() -> list[dict]:
    """Read the latest entries from automation/agent-runs.jsonl.

    Returns up to AGENT_RUNS_DASHBOARD_LIMIT entries sorted desc by `ts`.
    Corrupt JSON lines and entries missing required fields are skipped with
    a stderr warning. A missing log file returns an empty list.
    """
    if not AGENT_RUNS_PATH.exists():
        return []
    try:
        text = AGENT_RUNS_PATH.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        print(f"[engine] agent-runs.jsonl unreadable: {exc}", file=sys.stderr)
        return []
    out: list[dict] = []
    # Read more than we keep, then sort/cap. Reading all lines is fine for a 50-line file.
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            print(f"[engine] skipping corrupt agent-runs line: {line[:60]}", file=sys.stderr)
            continue
        if not isinstance(entry, dict) or not all(
            isinstance(entry.get(f), str) for f in AGENT_RUNS_REQUIRED_FIELDS
        ):
            print(f"[engine] skipping agent-runs entry missing required field(s)", file=sys.stderr)
            continue
        out.append(entry)
    out.sort(key=lambda e: e["ts"], reverse=True)
    return out[:AGENT_RUNS_DASHBOARD_LIMIT]


def _compute_dora() -> dict:
    """Compute DORA + SDLC effectiveness metrics from the current project root.

    Returns an empty dict on import/computation error so the rest of the scan
    is never blocked by a DORA failure.
    """
    try:
        from sdlc_framework.dora import compute
        return compute(ROOT)
    except Exception as exc:  # noqa: BLE001
        print(f"[engine] dora compute failed: {exc}", file=sys.stderr)
        return {}


def load_clarifications() -> list[dict]:
    out = []
    if not CLARIFICATIONS_DIR.exists():
        return out
    for f in sorted(CLARIFICATIONS_DIR.glob("*.md")):
        text = _read(f)
        # parse frontmatter-ish: --- key: value --- or just first H1 + paragraphs
        title = ""
        m = re.search(r"^#\s+(.+)$", text, re.MULTILINE)
        if m:
            title = m.group(1).strip()
        # status: open if "STATUS: resolved" not present
        resolved = bool(re.search(r"STATUS:\s*resolved", text, re.IGNORECASE))
        if resolved:
            continue
        out.append({
            "file": str(f.relative_to(ROOT)),
            "title": title or f.stem,
            "preview": (text[:400] + "...") if len(text) > 400 else text,
            "issue_url": _extract_issue_url(text),
        })
    return out


def load_project_block() -> tuple[dict, list[str]]:
    """Load project.yaml; on errors, write/refresh a clarification file."""
    project_path = ROOT / "project.yaml"
    project, errors = load_project(project_path)
    clarif_path = CLARIFICATIONS_DIR / PROJECT_CLARIFICATION_FILE
    if errors:
        CLARIFICATIONS_DIR.mkdir(parents=True, exist_ok=True)
        body = (
            "# project.yaml has validation errors\n\n"
            "STATUS: open\n\n"
            "The engine fell back to defaults for invalid fields. Fix and re-run scan.\n\n"
            "## Errors\n\n"
            + "\n".join(f"- {e}" for e in errors)
            + "\n"
        )
        clarif_path.write_text(body, encoding="utf-8")
    elif clarif_path.exists():
        # auto-resolve: prior errors fixed
        clarif_path.unlink()
    return project, errors


def load_signoffs(rules: dict) -> list[dict]:
    """Status of every gate defined in rules."""
    out = []
    for g in rules.get("gates", []):
        ok, msg = check_signoff({"id": g["id"]})
        signoff_path = SIGNOFFS_DIR / f"{g['id']}.yaml"
        issue_url: str | None = None
        if signoff_path.exists():
            issue_url = _extract_issue_url(_read(signoff_path))
        out.append({
            "id": g["id"],
            "label": g["label"],
            "phase": g.get("phase"),
            "approved": ok,
            "instruction": g.get("instruction", ""),
            "approvers_required": g.get("approvers_required", []),
            "msg": msg,
            "issue_url": issue_url,
        })
    return out


def git_info() -> dict:
    def run(cmd: list[str]) -> str:
        try:
            return subprocess.check_output(cmd, cwd=ROOT, stderr=subprocess.DEVNULL).decode().strip()
        except Exception:
            return ""
    return {
        "branch": run(["git", "rev-parse", "--abbrev-ref", "HEAD"]),
        "head": run(["git", "rev-parse", "--short", "HEAD"]),
        "last_commit": run(["git", "log", "-1", "--pretty=%s"]),
        "last_commit_at": run(["git", "log", "-1", "--pretty=%cI"]),
    }


PHASE_AGENT_MAP = {
    1: "pm-agent",
    2: "architect-agent",
    3: "developer-agent",
    4: "qa-engineer",
    5: "sre-agent",
}
HIGH_RISK_KEYWORDS = ["auth", "crypto", "payment", "secrets", "iam", "/migrations/"]
PARALLEL_AGENT_MAP: dict[str, list[str]] = {
    "api-contract": ["security-reviewer"],
    "database-schema": ["security-reviewer"],
    "system-architecture": ["test-author"],
    "security-threat-model": ["test-author"],
    "tdd-coverage-active": ["doc-keeper"],
    "ci-pipeline-configured": ["doc-keeper"],
}


def _empty_blocked_by() -> dict:
    return {"phase": None, "gate": None, "clarification": None, "high_risk_item": None}


def _phase_blocker(phase: dict, gates: list[dict]) -> dict | None:
    """Return a blocked_by dict if this phase has a hard blocker, else None.

    A hard blocker is: pending gate item, or item with high-risk keyword in its
    label. (Open clarifications are global and handled separately.)
    """
    for it in phase.get("items", []):
        if it.get("done"):
            continue
        if it.get("gate"):
            return {
                "phase": phase["id"],
                "gate": it["gate"],
                "clarification": None,
                "high_risk_item": None,
                "_item": it,  # internal hand-off
            }
        if any(p in it["label"].lower() for p in HIGH_RISK_KEYWORDS):
            return {
                "phase": phase["id"],
                "gate": None,
                "clarification": None,
                "high_risk_item": it["id"],
                "_item": it,
            }
    return None


def find_next_pending(state: dict) -> dict:
    """Single source of truth for "what's next?" across the framework.

    Used by:
    - ``compute_dispatch`` (drives ``sdlc dispatch``)
    - ``_next_pending`` in cli (drives ``sdlc next`` and ``sdlc resume``)
    - ``compute_next_step`` in commands.dispatch (drives ``sdlc auto-step``
      / ``sdlc auto-mad-step``)

    Before this helper existed, those three call sites diverged: only
    ``compute_next_step`` correctly handled "Phase 3 setup all done but
    no tasks bootstrapped". The other two iterated items, found nothing
    undone in Phase 3, and silently fell through to Phase 4 — the bug
    report dated 2026-05-02.

    Returns a dict with one of these ``kind`` values:
      - ``"clarification"``     — open clarification blocks all work;
                                  attaches ``"first"`` (the blocking entry).
      - ``"phase3_tasks_empty"``— Phase 3 setup is 100% but
                                  ``tasks_total == 0``; attaches ``phase_id: 3``.
      - ``"item"``              — normal pending item; attaches
                                  ``phase_id``, ``phase`` (full dict), ``item``.
      - ``"all_done"``          — every phase is complete.
    """
    if state.get("clarifications"):
        return {"kind": "clarification", "first": state["clarifications"][0]}

    for ph in state.get("phases") or []:
        if ph.get("complete"):
            continue
        # Phase 3 with all setup green but no bootstrapped tasks is a
        # hard stop, not a continue. ``ph.get("complete")`` is False
        # here because the engine sets ``complete=False`` whenever
        # ``tasks_total == 0`` (see scan()), and ``ph["items"]`` only
        # contains the all-done setup items — so a naive walk would
        # exit this phase with no candidate and silently advance.
        # Require ``setup_total > 0`` so test fixtures or malformed rules
        # that omit setup_*/tasks_* fields fall through to the normal
        # item walk instead of being mis-classified as "stuck".
        if (ph.get("id") == 3
                and ph.get("tasks_total", 0) == 0
                and ph.get("setup_total", 0) > 0
                and ph.get("setup_done", 0) == ph.get("setup_total", 0)):
            return {"kind": "phase3_tasks_empty", "phase_id": 3}
        for it in ph.get("items") or []:
            if not it.get("done"):
                return {"kind": "item",
                        "phase_id": ph["id"],
                        "phase": ph,
                        "item": it}
    return {"kind": "all_done"}


def compute_dispatch(
    phases_out: list[dict],
    gates: list[dict],
    clarifications: list[dict],
    project: dict | None = None,
) -> dict:
    """Decide next dispatch action. Backward-compatible: callers without
    `project` get prior dispatcher behaviour minus phase_target preference.
    """
    # 1) Open clarifications block everything globally.
    if clarifications:
        return {
            "action": "ask_user",
            "agent": "user (resolve clarification)",
            "reason": f"{len(clarifications)} open clarification(s)",
            "parallel_agents": [],
            "blocked_by": {
                "phase": None,
                "gate": None,
                "clarification": len(clarifications),
                "high_risk_item": None,
            },
        }

    # 2) Pass 1: walk phases in numeric order; first hard blocker wins.
    for ph in phases_out:
        if ph.get("complete"):
            continue
        blocker = _phase_blocker(ph, gates)
        if blocker is None:
            continue
        it = blocker.pop("_item", None) or {}
        if blocker["gate"]:
            gid = blocker["gate"]
            gate = next((g for g in gates if g["id"] == gid), None)
            return {
                "action": "stop_for_gate",
                "agent": "user (sign gate)",
                "reason": f"gate {gid} (blocking phase {ph['id']})",
                "gate": gate,
                "phase": ph["id"],
                "item_label": it.get("label"),
                "parallel_agents": [],
                "blocked_by": blocker,
            }
        # high-risk
        return {
            "action": "stop_for_user",
            "agent": "user + security-reviewer",
            "reason": f"high-risk path (blocking phase {ph['id']})",
            "phase": ph["id"],
            "item_label": it.get("label"),
            "parallel_agents": [],
            "blocked_by": blocker,
        }

    # 3) Pass 2: Phase 3 setup-done-but-no-tasks is a user-action stop.
    # This used to silently fall through to the "phase pending but no
    # items remaining" defensive `done` branch below, which made
    # `sdlc dispatch` report "all phases complete" while Phase 3 still
    # needed `sdlc tasks bootstrap`. Delegate to find_next_pending so
    # this matches `sdlc auto-step` and `sdlc next` exactly.
    pending_kind = find_next_pending(
        {"phases": phases_out, "clarifications": []})
    if pending_kind["kind"] == "phase3_tasks_empty":
        return {
            "action": "stop_for_user",
            "agent": "user (bootstrap Phase 3 tasks)",
            "reason": (
                "Phase 3 has no tasks. Draft "
                "01-Planning/02-User-Stories.md then run "
                "`sdlc tasks bootstrap` to seed task yamls."
            ),
            "phase": 3,
            "parallel_agents": [],
            "blocked_by": {
                "phase": 3,
                "gate": None,
                "clarification": None,
                "high_risk_item": None,
            },
        }

    # 4) Pass 3: no blockers. Pick phase_target if pending and present, else first pending.
    pending = [p for p in phases_out if not p.get("complete")]
    if not pending:
        return {
            "action": "done",
            "agent": None,
            "reason": "All phases complete",
            "parallel_agents": [],
            "blocked_by": None,
        }

    target = (project or {}).get("phase_target")
    chosen = next((p for p in pending if p["id"] == target), pending[0])

    next_item = next((i for i in chosen["items"] if not i.get("done")), None)
    if next_item is None:
        # Shouldn't happen because chosen is in pending; defensive.
        return {
            "action": "done",
            "agent": None,
            "reason": "phase pending but no items remaining",
            "parallel_agents": [],
            "blocked_by": None,
        }

    parallel = list(PARALLEL_AGENT_MAP.get(next_item["id"], []))
    # Resolution order: stage-specific subagent (for Phase 3 tasks) > item.agent override > phase default.
    resolved_agent = (
        next_item.get("next_subagent")    # Phase 3 task stage agent (Task 4)
        or next_item.get("agent")          # per-item override (this task)
        or PHASE_AGENT_MAP.get(chosen["id"], "orchestrator")
    )
    return {
        "action": "invoke",
        "agent": resolved_agent,
        "reason": next_item["label"],
        "phase": chosen["id"],
        "item_id": next_item["id"],
        "item_label": next_item["label"],
        "parallel_agents": parallel,
        "blocked_by": None,
    }


def _apply_replan(items_out: list[dict], replan: dict) -> list[dict]:
    """Force `done: false` (and add a check entry) for items in replan.dirty_items."""
    dirty = set(replan.get("dirty_items") or [])
    if not dirty:
        return items_out
    reason = replan.get("reason") or "marked dirty by sdlc replan"
    out = []
    for it in items_out:
        if it["id"] in dirty:
            new_it = dict(it)
            new_it["done"] = False
            new_it["dirty"] = True
            new_it["dirty_reason"] = reason
            new_it["checks"] = list(it.get("checks") or []) + [{
                "rule": {"type": "replan_dirty"},
                "ok": False,
                "msg": f"dirty (replan): {reason}",
            }]
            out.append(new_it)
        else:
            out.append(it)
    return out


def scan(rules: dict) -> dict:
    project, _project_errors = load_project_block()
    _set_active_project(project)
    agent_runs = load_agent_runs()
    replan = load_replan()

    # Phase 7: single-pass reconciliation for all `done` stories.
    # Replaces the old two-call pattern (rollback helper + check_and_mark_deployed)
    # with one `gh pr view` call per story per scan.  Best-effort — gh failures
    # (missing, offline, timeout) are swallowed inside the helper.
    try:
        from sdlc_framework.story_pr import reconcile_done_stories
        reconcile_done_stories(ROOT)
    except Exception:                                  # noqa: BLE001
        # Engine MUST stay green even if reconciliation misbehaves on a single
        # malformed story yaml — story-level integrity is downstream of scan.
        pass

    # Group user-defined custom_items from project.yaml by phase id.
    custom_by_phase: dict[int, list[dict]] = {}
    for ci in (project.get("custom_items") or []):
        custom_by_phase.setdefault(ci.get("phase", 3), []).append(ci)

    phases_out = []
    total_done, total_all = 0, 0
    for ph in rules["phases"]:
        # Phase items = framework rule items + user-declared custom items for this phase.
        phase_items = list(ph["items"]) + custom_by_phase.get(ph["id"], [])
        items_out = [evaluate_item(it, tier=project.get("tier", 2)) for it in phase_items]
        items_out = _apply_replan(items_out, replan)
        done = sum(1 for it in items_out if it["done"])
        total = len(items_out)
        total_done += done
        total_all += total
        phases_out.append({
            "id": ph["id"],
            "name": ph["name"],
            "emoji": ph.get("emoji", ""),
            "tagline": ph.get("tagline", ""),
            "color": ph.get("color", {"a": "#7c3aed", "b": "#3b82f6"}),
            "done": done,
            "total": total,
            "pct": round(done / total * 100) if total else 0,
            "complete": done == total,
            "items": items_out,
        })
    # Inject Phase 3 Tasks sub-track items from automation/tasks/*.yaml.
    # Phase 3 progress is computed from TASKS only (setup is "readiness", not progress):
    # - setup_done / setup_total — informational (always shown as "infrastructure ready")
    # - tasks_done / tasks_total — the actual development progress metric
    # - phase.pct = tasks_pct when tasks exist, else 0 (with "no tasks yet" hint)
    # - phase.complete = setup all done AND tasks all done AND tasks count > 0
    from sdlc_framework.tasks_loader import (
        load_tasks, evaluate_task_as_item, _pr_status_batch,
        _resolve_feature_branches, resolve_active_group, detect_stage,
    )
    tasks_data = load_tasks(ROOT)
    # Resolve story_id → shared branch so multiple tasks for one user
    # requirement collapse into a single PR. Tasks without story_id
    # keep their per-task pr_branch via the legacy path.
    feature_branches = _resolve_feature_branches(tasks_data)
    effective_branch_for: dict[str, str] = {}
    for t in tasks_data:
        fid = t.get("story_id")
        effective_branch_for[t["id"]] = (
            feature_branches.get(fid) if fid else None
        ) or t.get("pr_branch") or ""
    # Single batched `gh pr list` for ALL effective branches — replaces N
    # per-task `gh pr view` calls. Caps total scan-time gh cost at one
    # subprocess regardless of task count. Empty cache (gh missing /
    # offline) makes every task default to 'none' status, which is the
    # same legacy fallback behavior.
    branches = list({b for b in effective_branch_for.values() if b})
    pr_cache = _pr_status_batch(branches, ROOT) if branches else {}

    # ── Phase 3 serial lock ──
    # Read previous state to preserve / promote `phase3.active_story_id`.
    prev_state: dict = {}
    if STATE_PATH.exists():
        try:
            prev_state = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            prev_state = {}
    _refuse_legacy_state(prev_state, STATE_PATH)
    prev_state = migrate_state_to_v3(prev_state)

    seen_groups: list[str] = []
    group_tasks: dict[str, list[dict]] = {}
    for t in tasks_data:
        gid = t.get("story_id") or t["id"]
        if gid not in group_tasks:
            seen_groups.append(gid)
            group_tasks[gid] = []
        group_tasks[gid].append(t)

    def _group_done(gid: str) -> bool:
        for t in group_tasks[gid]:
            br = effective_branch_for[t["id"]] or None
            stage = detect_stage(
                t, ROOT, pr_cache=pr_cache, override_branch=br, is_active=True,
            )
            if stage != "committed":
                return False
        return True

    group_done_pairs = [(gid, _group_done(gid)) for gid in seen_groups]

    # Phase 7 Task 7.1+7.3: auto-create PR when all tasks in a story group
    # have reached `committed`.  Best-effort — gh errors are swallowed.
    # Mad-mode (SDLC_MAD_MODE=1) also calls `gh pr merge --auto --squash`
    # immediately after the create (Task 7.3).
    try:
        from sdlc_framework.story_pr import maybe_create_pr as _maybe_create_pr
        _mad = os.environ.get("SDLC_MAD_MODE") == "1"
        for _gid, _done in group_done_pairs:
            if _done:
                _maybe_create_pr(ROOT, _gid, mad_mode=_mad)
    except Exception:                                  # noqa: BLE001
        pass

    active_gid = resolve_active_group(prev_state, tasks_data, group_done_pairs)

    task_items = [
        evaluate_task_as_item(
            t, ROOT, pr_cache=pr_cache,
            override_branch=effective_branch_for[t["id"]] or None,
            is_active=((t.get("story_id") or t["id"]) == active_gid),
        )
        for t in tasks_data
    ]
    for ph in phases_out:
        if ph["id"] == 3:
            setup_items = list(ph["items"])  # original framework setup items
            setup_done = sum(1 for it in setup_items if it["done"])
            setup_total = len(setup_items)

            ph["items"].extend(task_items)
            tasks_done = sum(1 for t in task_items if t["done"])
            tasks_total = len(task_items)

            # Expose split metrics for dashboard.
            ph["setup_done"] = setup_done
            ph["setup_total"] = setup_total
            ph["setup_pct"] = round(setup_done / setup_total * 100) if setup_total else 0
            ph["tasks_done"] = tasks_done
            ph["tasks_total"] = tasks_total
            ph["tasks_pct"] = round(tasks_done / tasks_total * 100) if tasks_total else 0

            # Aggregate counts for back-compat (state.json consumers).
            ph["done"] = setup_done + tasks_done
            ph["total"] = setup_total + tasks_total

            # Phase 3 PROGRESS METRIC = tasks_pct (the real work).
            # Setup is treated as a readiness check, not as progress contribution.
            # When 0 tasks exist, phase 3 is 0% (with empty-state hint via tasks_total=0).
            ph["pct"] = ph["tasks_pct"] if tasks_total > 0 else 0

            # Phase 3 is complete only when both setup and tasks are 100%, AND tasks exist.
            ph["complete"] = (setup_done == setup_total
                              and tasks_total > 0
                              and tasks_done == tasks_total)

            # Hint surfaced to the dashboard for the empty-state CTA.
            if tasks_total == 0:
                ph["tasks_empty_hint"] = "No tasks yet. Run `sdlc tasks bootstrap` to create tasks from user stories, or `sdlc tasks new <id>` to add a feature manually."
            break
    # Recompute totals to reflect injected tasks.
    total_done = sum(p["done"] for p in phases_out)
    total_all = sum(p["total"] for p in phases_out)
    overall = round(total_done / total_all * 100) if total_all else 0
    gates = load_signoffs(rules)
    clarif = load_clarifications()

    # Surface installed addon assets per (phase, subtrack) so the dispatcher
    # brief and dashboard can render "external assets available" without
    # re-reading the lockfile. Pure read — no side effects on lockfile.
    try:
        from sdlc_framework.addons import (
            lockfile as addons_lockfile,
            loader as addons_loader,
            registry as addons_registry,
        )
        addons_lock = addons_lockfile.read(ROOT)
        addon_recipes = addons_loader.load_all(ROOT)
        phase_registry = addons_registry.build_phase_registry(
            addons_lock, addon_recipes,
        )
    except Exception:                              # noqa: BLE001
        # Engine MUST stay green even if addons module misbehaves —
        # external_assets is advisory, not load-bearing.
        phase_registry = {}

    for ph in phases_out:
        phase_id = ph.get("id")
        ph_subtracks: dict[str, dict] = {}
        for (p, sub), entries in phase_registry.items():
            if p == phase_id:
                ph_subtracks.setdefault(sub, {"external_assets": []})
                ph_subtracks[sub]["external_assets"].extend(
                    e.as_dict() for e in entries
                )
        if ph_subtracks:
            ph["subtracks"] = ph_subtracks

    # Hierarchy view: epics + stories with live-derived status.
    # Surfaces the epic→story tree on `state.json` so dashboards and
    # downstream agents can render the hierarchy without re-walking
    # automation/epics/*.yaml + automation/stories/*.yaml. Status is
    # derived from filesystem state (yaml + tasks), so it always
    # reflects current reality even if the yaml fields are stale.
    from sdlc_framework.epics_loader import derive_epic_status, load_epics
    from sdlc_framework.stories_loader import derive_story_status, load_stories

    epics_view = [
        {
            "slug": e["slug"],
            "title": e.get("title", e["slug"]),
            "status": derive_epic_status(ROOT, e["slug"]),
            "story_ids": e.get("story_ids", []),
        }
        for e in load_epics(ROOT)
    ]
    stories_view = [
        {
            "slug": s["slug"],
            "title": s.get("title", s["slug"]),
            "epic_id": s.get("epic_id"),
            "status": derive_story_status(ROOT, s["slug"]),
        }
        for s in load_stories(ROOT)
    ]

    # Hierarchy view companion: flat tasks[] for dashboard tree + kanban
    # rendering. Status is computed via detect_stage (already imported above)
    # so it always reflects current filesystem state.
    from sdlc_framework.tasks_loader import derive_epic_id

    tasks_view = []
    for t in load_tasks(ROOT):
        story_id = t.get("story_id")
        tasks_view.append({
            "id": t["id"],
            "label": t.get("label", t["id"]),
            "story_id": story_id,
            "epic_id": derive_epic_id(ROOT, story_id),
            "kind": t.get("kind", "feature"),
            "stage": detect_stage(t, ROOT),
            "priority": t.get("priority", "medium"),
            "review": bool(t.get("review", True)),
        })

    # Incidents view: surfaces every yaml under automation/incidents/ with
    # its derived status (open / restored / closed) so the dashboard
    # incident kanban can render without re-walking the linked fix tickets.
    # Order is filename-sorted (stable across scans).
    from sdlc_framework.incidents_loader import (
        IncidentSchemaError,
        derive_incident_status,
        load_incidents,
    )
    from sdlc_framework.incident_sync import auto_restore_on_ticket_done

    # Phase 5 Task 5.2: stamp restored_at on incidents whose fix ticket
    # reached done. Run before deriving the view so freshly-stamped
    # restored_at flows into mttr_min and the dashboard.
    auto_restore_on_ticket_done(ROOT)

    incidents_view = []
    for inc in load_incidents(ROOT):
        try:
            status, mttr_min = derive_incident_status(ROOT, inc["id"])
        except IncidentSchemaError:
            # Defensive: malformed individual file shouldn't blank the array.
            continue
        incidents_view.append({
            "id": inc["id"],
            "title": inc.get("title", inc["id"]),
            "severity": inc.get("severity"),
            "status": status,
            "opened_at": inc.get("opened_at"),
            "restored_at": inc.get("restored_at"),
            "closed_at": inc.get("closed_at"),
            "fix_ticket_id": inc.get("fix_ticket_id"),
            "mttr_min": mttr_min,
        })

    return {
        "generated_at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "git": git_info(),
        "project": project,
        "agent_runs": agent_runs,
        "overall_pct": overall,
        "total_done": total_done,
        "total_all": total_all,
        "phases_done": sum(1 for p in phases_out if p["complete"]),
        "phases": phases_out,
        "epics": epics_view,
        "stories": stories_view,
        "tasks": tasks_view,
        "incidents": incidents_view,
        "dora": _compute_dora(),
        "phase3": prev_state.get("phase3", {"active_story_id": None, "lock_acquired_at": None}),
        "gates": gates,
        "clarifications": clarif,
        "next_dispatch": compute_dispatch(phases_out, gates, clarif, project=project),
        "replan": replan if replan else None,
        "agents": [
            {"name": "orchestrator", "role": "Dispatcher", "type": "meta"},
            {"name": "pm-agent", "role": "Phase 1 — PM/BA", "type": "phase"},
            {"name": "architect-agent", "role": "Phase 2 — Staff Eng", "type": "phase"},
            {"name": "developer-agent", "role": "Phase 3 — Senior SWE", "type": "phase"},
            {"name": "sre-agent", "role": "Phase 4 — SRE/DevOps", "type": "phase"},
            {"name": "security-reviewer", "role": "AppSec review", "type": "cross"},
            {"name": "test-author", "role": "SDET", "type": "cross"},
            {"name": "doc-keeper", "role": "Tech writer", "type": "cross"},
            {"name": "clarification-triager", "role": "Ambiguity resolver", "type": "cross"},
        ],
        "external": {},
    }


def _atomic_write_text(path: Path, content: str) -> None:
    """Write `content` to `path` atomically.

    Strategy: write to a sibling `*.tmp` file then `os.replace` it onto the
    target. On POSIX `os.replace` is atomic — readers see either the full
    old content or the full new content, never a torn/partial file. Prevents
    dashboards or sub-agents from reading half-written JSON when concurrent
    writers race (--watch loop, manual `sdlc scan`, `sdlc auto-step`).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)


def _refuse_legacy_state(state: dict, state_path: Path) -> None:
    """Hard-cutover: refuse to scan if state.json uses a legacy schema_version."""
    sv = state.get("schema_version")
    if sv in LEGACY_STATE_SCHEMA_VERSIONS:
        msg = (
            f"\n[sdlc] ERROR: state.json schema_version={sv} is legacy.\n"
            f"This is v1.0 canonical. State files require schema_version: {STATE_SCHEMA_VERSION}.\n"
            f"Project file: {state_path}\n"
            f"Fix: rm automation/state.json && sdlc scan\n"
            f"  (state.json is regenerated on every scan; deleting it is non-destructive.)\n"
        )
        print(msg, file=sys.stderr)
        sys.exit(2)


def migrate_state_to_v3(state: dict) -> dict:
    """Idempotent v2→v3 migration. Adds phase3 block if missing.

    Returns a new dict — does not mutate the caller's state.
    """
    sv = state.get("schema_version", STATE_SCHEMA_VERSION)
    if sv >= STATE_SCHEMA_VERSION and "phase3" in state:
        return state
    new_state = dict(state)
    # Only bump the version when migrating up. Preserve user-set higher
    # versions (defensive — back-compat with an existing test).
    if sv < STATE_SCHEMA_VERSION:
        new_state["schema_version"] = STATE_SCHEMA_VERSION
    if "phase3" not in new_state:
        new_state["phase3"] = {
            "active_story_id": None,
            "lock_acquired_at": None,
        }
    return new_state


def write_state(state: dict) -> None:
    # Stamp a schema version so future engines can detect old state files
    # and refuse / migrate. Cheap to add now; expensive to retrofit later.
    # Copy first so we never mutate the caller's dict (callers reuse
    # `state` across multiple operations during a scan).
    state_to_write = migrate_state_to_v3(
        state if "schema_version" in state else {**state, "schema_version": STATE_SCHEMA_VERSION}
    )
    payload = json.dumps(state_to_write, indent=2, ensure_ascii=False)
    _atomic_write_text(STATE_PATH, payload)
    _atomic_write_text(DASHBOARD_STATE, payload)
    # Project memory bundle: small markdown summary that sub-agents read
    # instead of full upstream artifacts when they only need orientation.
    # Failures here must NOT break state.json writing — bundle is a nice-to-have.
    try:
        from sdlc_framework import context_bundle
        context_bundle.write_bundle_files(state, ROOT)
    except Exception as e:  # noqa: BLE001
        # Best-effort: log to stderr but do not raise.
        import sys
        print(f"[sdlc] context bundle write failed: {e}", file=sys.stderr)


def _pending_ids(state: dict) -> set[tuple[str, str]]:
    """Return the set of (kind, id) tuples that should fire notifications.

    - Each open clarification → ("clarification", file_basename or title)
    - Each not-yet-approved gate → ("gate", gate_id)

    Empty/missing IDs are filtered out so the diff is robust to malformed state.
    """
    out: set[tuple[str, str]] = set()
    for c in state.get("clarifications", []):
        out.add(("clarification", c.get("file") or c.get("title") or ""))
    for g in state.get("gates", []):
        if not g.get("approved"):
            out.add(("gate", g.get("id", "")))
    return {p for p in out if p[1]}


def _build_notification(state: dict, kind: str, ident: str) -> tuple[str, str] | None:
    """Resolve a (kind, id) into a (title, body) pair using the current state.

    Returns None when the id no longer exists in state (race-safe).
    """
    if kind == "clarification":
        for c in state.get("clarifications", []):
            if (c.get("file") or c.get("title")) == ident:
                title = f"🔍 Clarification: {c.get('title') or ident}"
                body = (c.get("preview") or "needs human input").splitlines()[0][:200]
                return (title, body)
    elif kind == "gate":
        for g in state.get("gates", []):
            if g.get("id") == ident:
                title = f"🔒 Gate pending: {g.get('label') or ident}"
                approvers = ", ".join(g.get("approvers_required") or [])
                body = (g.get("instruction") or f"approvers required: {approvers}")[:200]
                return (title, body)
    return None


def _fire_notification(kind: str, ident: str, title: str, body: str) -> None:
    """Invoke scripts/notify.sh fire-and-forget. Never blocks the watch loop."""
    if not NOTIFY_SCRIPT.exists():
        return
    try:
        subprocess.Popen(
            ["bash", str(NOTIFY_SCRIPT), kind, ident, title, body],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as exc:
        print(f"[engine] notify spawn failed: {exc}", file=sys.stderr)


def watch(rules: dict, interval: float = 3.0) -> None:
    print(f"[sdlc-engine] watch mode (every {interval}s). Ctrl-C to stop.")
    last_sig = None
    previous_pending: set[tuple[str, str]] | None = None
    while True:
        try:
            state = scan(rules)
            current_pending = _pending_ids(state)
            if previous_pending is not None:
                new_items = current_pending - previous_pending
                for kind, ident in sorted(new_items):
                    payload = _build_notification(state, kind, ident)
                    if payload is None:
                        continue
                    title, body = payload
                    _fire_notification(kind, ident, title, body)
            previous_pending = current_pending

            sig = (state["overall_pct"], state["total_done"], len(state["clarifications"]))
            if sig != last_sig:
                write_state(state)
                print(f"[{state['generated_at']}] overall={state['overall_pct']}% "
                      f"done={state['total_done']}/{state['total_all']} "
                      f"clarif={len(state['clarifications'])}")
                last_sig = sig
            time.sleep(interval)
        except KeyboardInterrupt:
            print("\n[sdlc-engine] stopped.")
            return
        except Exception as e:
            print(f"[sdlc-engine] error: {e}")
            time.sleep(interval)


def rollback_done_stories_on_pr_closed_unmerged(target: Path) -> list[str]:
    """Roll back stories from `done` to `in-progress` when their PR was
    closed without being merged.

    Detection: a story whose `state == "done"` and whose linked PR
    (`pr_url`) returns `closed: true` AND `merged: false` from
    `gh pr view --json closed,merged`.

    Stories in `done` without a `pr_url` are skipped entirely (no `gh`
    call) — that combination is unusual and engine should not pretend
    to know the PR state.

    Returns the list of slugs that were rolled back this scan.
    """
    import yaml as _yaml

    from sdlc_framework.story_sync import append_state_transition

    sdir = target / "automation" / "stories"
    if not sdir.exists():
        return []

    rolled_back: list[str] = []
    now = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    for spath in sorted(sdir.glob("*.yaml")):
        try:
            data = _yaml.safe_load(spath.read_text(encoding="utf-8")) or {}
        except _yaml.YAMLError:
            continue
        if data.get("state") != "done":
            continue
        pr_url = data.get("pr_url")
        if not pr_url:
            continue

        try:
            proc = subprocess.run(
                ["gh", "pr", "view", pr_url, "--json", "closed,merged"],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            # `gh` missing, network hung, or local tooling unavailable —
            # rollback is best-effort, never blocks `sdlc scan`.
            continue
        if proc.returncode != 0 or not proc.stdout:
            continue
        try:
            payload = json.loads(proc.stdout)
        except json.JSONDecodeError:
            continue
        if payload.get("closed") and not payload.get("merged"):
            slug = data.get("slug") or spath.stem
            append_state_transition(target, slug, to="in-progress", at=now)
            rolled_back.append(slug)

    return rolled_back


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--watch", action="store_true", help="re-scan on interval")
    p.add_argument("--interval", type=float, default=3.0)
    p.add_argument("--print", action="store_true", help="print summary to stdout")
    args = p.parse_args()

    if not RULES_PATH.exists():
        print(f"ERR: rules file missing: {RULES_PATH}", file=sys.stderr)
        return 1
    rules = json.loads(_read(RULES_PATH))

    if args.watch:
        watch(rules, args.interval)
        return 0

    state = scan(rules)
    write_state(state)
    if args.print:
        print(f"Overall: {state['overall_pct']}%  ({state['total_done']}/{state['total_all']})")
        for ph in state["phases"]:
            print(f"  Phase {ph['id']} {ph['name']}: {ph['pct']}%  ({ph['done']}/{ph['total']})")
            for it in ph["items"]:
                mark = "✓" if it["done"] else "·"
                print(f"     {mark} {it['label']}")
        if state["clarifications"]:
            print("\nClarifications:")
            for c in state["clarifications"]:
                print(f"  ? {c['title']}  ({c['file']})")
        if any(not g["approved"] for g in state["gates"]):
            print("\nPending gates:")
            for g in state["gates"]:
                if not g["approved"]:
                    print(f"  ! {g['label']}  ({g['id']})")
    print(f"wrote {STATE_PATH}")
    print(f"wrote {DASHBOARD_STATE}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
