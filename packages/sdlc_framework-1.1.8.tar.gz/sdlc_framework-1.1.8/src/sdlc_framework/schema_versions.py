"""Canonical schema version constants for v1.0 framework cutover.

The framework refuses to operate on state files that use legacy
schema versions. This module is the single source of truth.
"""
from __future__ import annotations

# state.json top-level schema_version
STATE_SCHEMA_VERSION: int = 3

# automation/rules.json schema_version
RULES_SCHEMA_VERSION: int = 4

# pyproject.toml [project].version semantic version
FRAMEWORK_VERSION: str = "1.0.0"

# state.json schema_version values that are legacy and refused at startup
LEGACY_STATE_SCHEMA_VERSIONS: tuple[int, ...] = (1, 2)
