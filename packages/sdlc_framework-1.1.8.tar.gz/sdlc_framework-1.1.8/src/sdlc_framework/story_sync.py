"""Sync 01-Planning/stories/<slug>.md → automation/stories/<slug>.yaml.

Story state machine fields (status, task_ids, verified_by, gates) are
engine-managed and preserved across sync — only md-narrative fields
(slug, title, epic_id, depends_on, last_md_mtime) are overwritten.
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml


class StorySyncError(Exception):
    """Raised when sync cannot complete."""


# Engine-owned fields preserved across `sdlc story sync` re-runs. When the
# sync regenerates `automation/stories/<slug>.yaml` from the markdown, these
# keys carry over from the prior yaml (if present) so engine-managed state
# isn't clobbered by a re-sync.
#
# Status of each producer (audit F-D3-006 follow-up):
#   state                — written below (default `draft`); v1.1.0 field name.
#                          Set by `complete-draft`, `story activate`, engine
#                          rollback, and `append_state_transition`.
#   state_transitions    — append-only log written by `append_state_transition`.
#                          MUST survive resync or the audit trail is wiped.
#   task_ids             — populated by `sdlc tasks bootstrap` once it links
#                          generated tasks back to the parent story
#   draft_completed_at   — set by `sdlc story complete-draft`
#   pr_url               — set by engine when the story's umbrella PR opens
#   verified_by/_at      — set by `sdlc verify <story>`
#   review_status        — set by review-pack consolidator
#   review_pack_run_at   — set by review-pack runner
#   review_skipped       — set by `--no-review` / `--force-skip-review`
#
# Legacy `status` field from pre-v1.1.0 yamls is migrated below to `state`.
_ENGINE_FIELDS = (
    "state",
    "state_transitions",
    "task_ids",
    "draft_completed_at",
    "pr_url",
    "verified_by", "verified_at",
    "review_status", "review_pack_run_at", "review_skipped",
)


def _normalize(text: str) -> str:
    """Strip BOM and normalize CRLF→LF before parsing."""
    if text.startswith("﻿"):
        text = text[1:]
    return text.replace("\r\n", "\n")


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---\n"):
        raise StorySyncError("missing or malformed frontmatter")
    end_match = re.search(r"\n---\n", text[4:])
    if end_match is None:
        raise StorySyncError("missing closing `---` in frontmatter")
    fm_text = text[4 : 4 + end_match.start()]
    body = text[4 + end_match.end() :]
    # Pre-yaml-parse `{{...}}` detection — PyYAML reads `{{x}}` as a flow
    # mapping and emits a confusing "found unhashable key" error. Replace
    # with a clear "fill placeholders" message. F-D3-002 in audit.
    if "{{" in fm_text:
        raise StorySyncError(
            "frontmatter still has `{{...}}` placeholders — "
            "fill `slug:`, `title:`, `epic:`, `created_at:` etc. before sync"
        )
    try:
        fm = yaml.safe_load(fm_text) or {}
    except yaml.YAMLError as e:
        raise StorySyncError(f"frontmatter yaml error: {e}") from e
    if not isinstance(fm, dict):
        raise StorySyncError("frontmatter must be a yaml mapping")
    return fm, body


def sync_story(target: Path, slug: str) -> Path:
    md_path = target / "01-Planning" / "stories" / f"{slug}.md"
    if not md_path.exists():
        raise StorySyncError(f"story markdown not found: {md_path}")

    text = _normalize(md_path.read_text(encoding="utf-8"))
    fm, _body = _parse_frontmatter(text)

    md_mtime = md_path.stat().st_mtime

    yaml_path = target / "automation" / "stories" / f"{slug}.yaml"
    yaml_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if yaml_path.exists():
        try:
            existing = yaml.safe_load(yaml_path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            existing = {}

    # Migrate legacy `status` → `state` if present on existing yaml.
    declared_state = existing.get("state") or existing.get("status", "draft")

    new_data = {
        "slug": slug,
        "title": fm.get("title", slug),
        "epic_id": fm.get("epic"),  # frontmatter `epic` → yaml `epic_id`
        "depends_on": fm.get("depends_on", []),
        "created_at": fm.get("created_at"),
        "last_md_mtime": md_mtime,
        "state": declared_state,
    }
    for k in _ENGINE_FIELDS:
        if k in existing:
            new_data[k] = existing[k]
    # Force `state` to the migrated value (covers case where existing has
    # only `status`, not `state` — the loop above would skip it).
    new_data["state"] = declared_state

    yaml_path.write_text(yaml.safe_dump(new_data, sort_keys=False), encoding="utf-8")
    return yaml_path


def append_state_transition(target: Path, slug: str, *, to: str, at: str) -> None:
    """Append a state transition entry to story.yaml. Idempotent: if the
    most-recent transition's `to` matches the new one, do nothing.

    Args:
        target: project root.
        slug: story slug.
        to: destination state (must be in VALID_STORY_STATUSES).
        at: ISO 8601 UTC timestamp.
    """
    from sdlc_framework.stories_loader import VALID_STORY_STATUSES

    if to not in VALID_STORY_STATUSES:
        raise ValueError(f"invalid state: {to!r}")
    spath = target / "automation" / "stories" / f"{slug}.yaml"
    if not spath.exists():
        raise FileNotFoundError(spath)
    data = yaml.safe_load(spath.read_text(encoding="utf-8")) or {}
    log = data.setdefault("state_transitions", [])
    if log and log[-1].get("to") == to:
        return
    log.append({"to": to, "at": at})
    data["state"] = to
    spath.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
