# src/sdlc_framework/render_agents.py
"""Canonical agent file parser + per-tool renderers.

Spec §11 — multi-tool parity render pipeline. Canonical agents live at
`automation/agents/<name>.md` with extended YAML frontmatter:

    ---
    name: <slug>
    description: <one-line description>
    tools: Read, Write, Edit, Glob, Grep, Bash
    model: sonnet           # optional; default unset (tools without model)
    readonly: false         # optional; default false
    ---
    <body markdown>

Body MAY contain `<!-- if-tool: claude -->...<!-- end-if-tool -->` blocks
that the per-tool renderer keeps or strips based on the target tool.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml


# Slug pattern for agent names — guards against path traversal in write_render
# (which derives target paths from `spec.name`). Must start with alphanumeric;
# subsequent chars allow hyphen/underscore. No path separators, no leading dot.
_SLUG_RE = re.compile(r"[a-z0-9][a-z0-9_-]*")


@dataclass
class AgentSpec:
    name: str
    description: str
    tools: list[str] = field(default_factory=list)
    model: str | None = None
    readonly: bool = False
    body: str = ""


def parse_agent(path: Path) -> AgentSpec:
    """Parse a canonical agent .md file. Raises ValueError on malformed input."""
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n") and not text.startswith("---\r\n"):
        raise ValueError(f"{path}: missing frontmatter (file must start with '---')")

    # Find the closing '---' line.
    end_idx = text.find("\n---\n", 4)
    if end_idx < 0:
        end_idx = text.find("\n---\r\n", 4)
    if end_idx < 0:
        raise ValueError(f"{path}: unterminated frontmatter (no closing '---')")
    fm_text = text[4:end_idx]
    body = text[end_idx + len("\n---\n"):].lstrip("\n")

    try:
        fm = yaml.safe_load(fm_text) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"{path}: yaml error in frontmatter: {e}") from e

    if not isinstance(fm, dict):
        raise ValueError(f"{path}: frontmatter must be a mapping")

    name = fm.get("name")
    description = fm.get("description")
    if not name or not isinstance(name, str):
        raise ValueError(f"{path}: frontmatter missing 'name' (string)")
    if not _SLUG_RE.fullmatch(name.strip()):
        raise ValueError(
            f"{path}: 'name' must be a slug matching {_SLUG_RE.pattern!r}; "
            f"got {name!r} (path-traversal-safe)"
        )
    if not description or not isinstance(description, str):
        raise ValueError(f"{path}: frontmatter missing 'description' (string)")

    raw_tools = fm.get("tools")
    if isinstance(raw_tools, str):
        tools = [t.strip() for t in raw_tools.split(",") if t.strip()]
    elif isinstance(raw_tools, list):
        tools = [str(t).strip() for t in raw_tools if str(t).strip()]
    else:
        tools = []

    model = fm.get("model")
    if model is not None and not isinstance(model, str):
        raise ValueError(f"{path}: 'model' must be a string if present")

    readonly = bool(fm.get("readonly", False))

    return AgentSpec(
        name=name.strip(),
        description=description.strip(),
        tools=tools,
        model=model.strip() if isinstance(model, str) else None,
        readonly=readonly,
        body=body,
    )


_IF_TOOL_RE = re.compile(
    r"<!--\s*if-tool:\s*([a-zA-Z0-9_-]+)\s*-->\s*\n?"   # opening marker
    r"(.*?)"                                             # block body (non-greedy)
    r"\n?\s*<!--\s*end-if-tool\s*-->",                  # closing marker
    flags=re.DOTALL,
)


def filter_body_for_tool(body: str, tool: str) -> str:
    """Keep only `<!-- if-tool: <tool> -->...<!-- end-if-tool -->` blocks
    matching the target. Strip markers in kept blocks; drop entire block
    (markers + content) when tool doesn't match. Pass-through if no markers.

    Defensive on unterminated markers — they're stripped from the output.
    """
    def _replace(m: re.Match) -> str:
        block_tool = m.group(1).strip().lower()
        content = m.group(2)
        if block_tool == tool.lower():
            # Keep content, drop the markers.
            return content.rstrip("\n")
        return ""

    out = _IF_TOOL_RE.sub(_replace, body)

    # Defensive: drop any orphaned markers (unterminated opens or stray ends).
    out = re.sub(r"<!--\s*if-tool:[^>]*-->\s*\n?", "", out)
    out = re.sub(r"<!--\s*end-if-tool\s*-->\s*\n?", "", out)
    return out


_DEFAULT_MODEL = "sonnet"


def render_for_claude(spec: AgentSpec) -> str:
    """Emit `.claude/agents/<name>.md` content (Claude frontmatter)."""
    body = filter_body_for_tool(spec.body, "claude")
    fm = {
        "name": spec.name,
        "description": spec.description,
        "tools": ", ".join(spec.tools),
    }
    return _format_frontmatter(fm) + body


def render_for_copilot(spec: AgentSpec) -> str:
    """Emit `.copilot/agents/<name>.agent.md` content (Copilot frontmatter)."""
    body = filter_body_for_tool(spec.body, "copilot")
    fm = {
        "name": spec.name,
        "description": spec.description,
        "model": spec.model or _DEFAULT_MODEL,
        "tools": list(spec.tools),
    }
    return _format_frontmatter(fm) + body


def render_for_cursor(spec: AgentSpec) -> str:
    """Emit `.cursor/agents/<name>.md` content (Cursor frontmatter)."""
    body = filter_body_for_tool(spec.body, "cursor")
    fm = {
        "name": spec.name,
        "description": spec.description,
        "model": spec.model or _DEFAULT_MODEL,
        "readonly": bool(spec.readonly),
    }
    return _format_frontmatter(fm) + body


def _format_frontmatter(fm: dict) -> str:
    """Emit '---\\n<yaml>\\n---\\n' with stable key ordering as inserted."""
    body = yaml.safe_dump(fm, sort_keys=False, allow_unicode=True, default_flow_style=False).rstrip()
    return f"---\n{body}\n---\n"


# Path mapping per tool.
_TOOL_PATHS: dict[str, callable] = {
    "claude":  lambda repo, name: repo / ".claude" / "agents" / f"{name}.md",
    "copilot": lambda repo, name: repo / ".copilot" / "agents" / f"{name}.agent.md",
    "cursor":  lambda repo, name: repo / ".cursor" / "agents" / f"{name}.md",
}

_TOOL_RENDERERS = {
    "claude":  render_for_claude,
    "copilot": render_for_copilot,
    "cursor":  render_for_cursor,
}

SUPPORTED_TOOLS: tuple[str, ...] = ("claude", "copilot", "cursor")


def _expected_output(spec: AgentSpec, tool: str) -> str:
    if tool not in _TOOL_RENDERERS:
        raise ValueError(f"unsupported tool: {tool!r}; expected one of {SUPPORTED_TOOLS}")
    return _TOOL_RENDERERS[tool](spec)


def write_render(repo: Path, spec: AgentSpec, tool: str) -> Path:
    """Render `spec` for `tool` and write to the conventional path under `repo`. Returns the path."""
    out = _expected_output(spec, tool)
    target = _TOOL_PATHS[tool](repo, spec.name)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(out, encoding="utf-8")
    return target


def check_render(repo: Path, spec: AgentSpec, tool: str) -> tuple[bool, str]:
    """Compare expected render to disk. Returns (matches, diff_summary).

    `matches` is True iff the file exists and equals the expected output.
    """
    expected = _expected_output(spec, tool)
    target = _TOOL_PATHS[tool](repo, spec.name)
    if not target.exists():
        return False, f"missing: {target.relative_to(repo)}"
    actual = target.read_text(encoding="utf-8")
    if actual == expected:
        return True, ""
    return False, f"drift: {target.relative_to(repo)}"



_TOOL_ALIASES: dict[str, str] = {
    "claude": "claude",
    "claude-code": "claude",
    "copilot": "copilot",
    "github-copilot": "copilot",
    "cursor": "cursor",
}


def detect_active_tool(repo: Path | None = None) -> str:
    """Resolve the active tool. Priority:

    1. ``SDLC_TOOL`` env var (must alias to one of SUPPORTED_TOOLS)
    2. Filesystem markers under ``repo`` if provided (`.claude/`, `.cursor/`, `.copilot/`)
    3. Default ``"claude"``

    Raises ValueError if SDLC_TOOL is set to an unknown value.
    """
    raw = os.environ.get("SDLC_TOOL", "").strip().lower()
    if raw:
        if raw not in _TOOL_ALIASES:
            raise ValueError(
                f"SDLC_TOOL={raw!r} is not a supported tool. "
                f"Expected one of: {sorted(set(_TOOL_ALIASES))}"
            )
        return _TOOL_ALIASES[raw]

    if repo is not None:
        if (repo / ".claude").is_dir():
            return "claude"
        if (repo / ".cursor").is_dir():
            return "cursor"
        if (repo / ".copilot").is_dir():
            return "copilot"

    return "claude"


def render_all_agents(
    repo: Path,
    tool: str | None = None,
    check: bool = False,
) -> tuple[list[Path], list[str]]:
    """Render every canonical agent under `repo / 'automation' / 'agents'`.

    Args:
        repo: project root (the dir containing `automation/`).
        tool: one of SUPPORTED_TOOLS, or None to render all three.
        check: if True, compute expected output and diff against disk;
            DO NOT write. Return list of drift descriptions.

    Returns:
        (written_paths_or_empty, drift_messages)
        - In write mode, written_paths is the list of files written
            and drift_messages is empty.
        - In check mode, written_paths is empty and drift_messages
            lists every file whose on-disk content does not match
            the expected render.
    """
    agents_dir = repo / "automation" / "agents"
    if not agents_dir.is_dir():
        raise FileNotFoundError(f"canonical agents dir missing: {agents_dir}")
    tools = (tool,) if tool else SUPPORTED_TOOLS
    written: list[Path] = []
    drift: list[str] = []
    for src in sorted(agents_dir.glob("*.md")):
        spec = parse_agent(src)
        for t in tools:
            if check:
                ok, msg = check_render(repo, spec, t)
                if not ok:
                    drift.append(f"{spec.name} ({t}): {msg}")
            else:
                written.append(write_render(repo, spec, t))
    return written, drift
