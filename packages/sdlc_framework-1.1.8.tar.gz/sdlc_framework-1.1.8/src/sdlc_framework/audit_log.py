# src/sdlc_framework/audit_log.py
"""Forced-skip audit log writer.

Writes `automation/audit/forced-skip-<id>.yaml` files whenever the user
escapes the sensitive-path safety net via `--force-skip-review`. Files are
git-tracked (NOT gitignored) so the audit trail is visible in PR diffs.
"""
from __future__ import annotations

import datetime as _dt
import os
import subprocess
from pathlib import Path

import yaml


def write_forced_skip(
    target: Path,
    *,
    artifact_id: str,
    artifact_type: str,
    reason: str,
    sensitive_match: list[str],
) -> Path:
    """Write the audit yaml; return the path."""
    audit_dir = target / "automation" / "audit"
    audit_dir.mkdir(parents=True, exist_ok=True)

    base = f"forced-skip-{artifact_id}"
    out = audit_dir / f"{base}.yaml"
    if out.exists():
        # Preserve history; never clobber.
        n = 2
        while True:
            candidate = audit_dir / f"{base}-{n}.yaml"
            if not candidate.exists():
                out = candidate
                break
            n += 1

    payload = {
        "artifact_id": artifact_id,
        "artifact_type": artifact_type,
        "forced_by": _git_user(target),
        "forced_at": _now_iso(),
        "reason": reason,
        "sensitive_match": list(sensitive_match),
        "git_sha": _git_sha(target),
        "git_user": _git_user(target),
    }
    out.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    return out


def _now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _git_sha(target: Path) -> str:
    try:
        r = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=target,
            capture_output=True,
            text=True,
            timeout=2,
        )
        if r.returncode == 0:
            return r.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    return "unknown"


def _git_user(target: Path) -> str:
    try:
        r = subprocess.run(
            ["git", "config", "user.name"],
            cwd=target,
            capture_output=True,
            text=True,
            timeout=2,
        )
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    return os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"
