"""Sync 01-Planning/epics/<slug>.md → automation/epics/<slug>.yaml.

Markdown is the narrative source-of-truth; yaml mirrors only the fields
the engine needs (slug, title, story_ids, last_md_mtime). Engine-managed
fields (verified_by, review_status, etc.) are preserved across sync.
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml


class EpicSyncError(Exception):
    """Raised when sync cannot complete (missing md, malformed frontmatter)."""


_ENGINE_FIELDS = (
    "verified_by", "verified_at",
    "review_status", "review_pack_run_at", "review_skipped",
)


def _normalize(text: str) -> str:
    """Strip BOM and normalize CRLF→LF before parsing."""
    if text.startswith("﻿"):
        text = text[1:]
    return text.replace("\r\n", "\n")


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    """Split YAML frontmatter (between --- delimiters at start of file) from body."""
    if not text.startswith("---\n"):
        raise EpicSyncError("missing or malformed frontmatter (must begin with `---`)")
    end_match = re.search(r"\n---\n", text[4:])
    if end_match is None:
        raise EpicSyncError("missing or malformed frontmatter (no closing `---`)")
    fm_text = text[4 : 4 + end_match.start()]
    body = text[4 + end_match.end() :]
    # Pre-yaml-parse `{{...}}` detection — PyYAML reads `{{x}}` as a flow
    # mapping and emits a confusing "found unhashable key" error. F-D3-002.
    if "{{" in fm_text:
        raise EpicSyncError(
            "frontmatter still has `{{...}}` placeholders — "
            "fill `slug:`, `title:`, `created_at:` etc. before sync"
        )
    try:
        fm = yaml.safe_load(fm_text) or {}
    except yaml.YAMLError as e:
        raise EpicSyncError(f"frontmatter yaml error: {e}") from e
    if not isinstance(fm, dict):
        raise EpicSyncError("frontmatter must be a yaml mapping")
    return fm, body


_STORIES_HEADING = re.compile(r"^## Stories\s*$", re.MULTILINE)
# Allow `- slug` or `- slug: description` or `- slug   # comment`:
_BULLET = re.compile(r"^- ([\w./-]+)[ \t]*(?:[:#].*)?$", re.MULTILINE)


def _extract_story_ids(body: str) -> list[str]:
    """Pull the bulleted list under '## Stories' heading.

    Emits a stderr warning when the '## Stories' heading exists but no
    bullets parse out — typically caused by a typo in bullet syntax. Returns
    an empty list either way (consistent with draft-epic behavior).
    """
    import sys
    m = _STORIES_HEADING.search(body)
    if not m:
        return []
    section = body[m.end() :]
    next_heading = re.search(r"^## ", section, re.MULTILINE)
    if next_heading:
        section = section[: next_heading.start()]
    slugs = [b.group(1) for b in _BULLET.finditer(section)]
    if not slugs:
        print(
            "[sdlc epic sync] warning: '## Stories' heading found but no slug bullets parsed. "
            "Expected format: `- slug-name` (optionally with `: description` or `# comment`).",
            file=sys.stderr,
        )
    return slugs


def sync_epic(target: Path, slug: str) -> Path:
    """Parse `01-Planning/epics/<slug>.md` and write `automation/epics/<slug>.yaml`.

    Returns the path to the written yaml.
    """
    md_path = target / "01-Planning" / "epics" / f"{slug}.md"
    if not md_path.exists():
        raise EpicSyncError(f"epic markdown not found: {md_path}")

    text = _normalize(md_path.read_text(encoding="utf-8"))
    fm, body = _parse_frontmatter(text)

    story_ids = _extract_story_ids(body)
    md_mtime = md_path.stat().st_mtime

    yaml_path = target / "automation" / "epics" / f"{slug}.yaml"
    yaml_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if yaml_path.exists():
        try:
            existing = yaml.safe_load(yaml_path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            existing = {}

    new_data = {
        "slug": slug,
        "title": fm.get("title", slug),
        "story_ids": story_ids,
        "created_at": fm.get("created_at"),
        "last_md_mtime": md_mtime,
    }
    for k in _ENGINE_FIELDS:
        if k in existing:
            new_data[k] = existing[k]

    yaml_path.write_text(yaml.safe_dump(new_data, sort_keys=False), encoding="utf-8")
    return yaml_path
