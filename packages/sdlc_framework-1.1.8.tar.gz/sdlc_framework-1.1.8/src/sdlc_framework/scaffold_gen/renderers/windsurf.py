"""Windsurf renderer — .windsurf/workflows/ + .windsurfrules warning."""
from __future__ import annotations

import re
from pathlib import Path

from .. import core, manifest
from .. import _frontmatter as fm
from .._write import safe_write

TOOL = "windsurf"

WARNING_BLOCK = """
<!-- scaffold-gen:tier2-warning:start -->
## SDLC Tier 2 — fresh-context-per-subagent NOT supported

Phase 3 stages execute inside the same Cascade session. Each `sdlc-*`
workflow re-reads `agents/<role>.md` per stage; discipline is by-prompt.
For strict TDD isolation, use Claude Code, Cursor, or GitHub Copilot.
<!-- scaffold-gen:tier2-warning:end -->
"""

ROLE_SWITCH_PREAMBLE = """\
> **ROLE SWITCH (Tier 2):** Re-read `agents/<role>.md` per stage and adopt
> the role fresh. Do not retain context across stages.

"""


def render(*, scaffold_root: Path, out_root: Path) -> list[Path]:
    written: list[Path] = []
    wf_dir = out_root / ".windsurf" / "workflows"
    wf_dir.mkdir(parents=True, exist_ok=True)

    for name in manifest.commands_for_tool(TOOL):
        meta, body = core.load_canonical_command(name, scaffold_root=scaffold_root)
        out_meta = {"description": meta.get("description", "")}
        rewritten = re.sub(
            r"Use the (\S+) subagent",
            r"Adopt the **\1** role (read `agents/<role>.md`)",
            body,
        )
        out_body = ROLE_SWITCH_PREAMBLE + rewritten
        text = fm.emit_with_marker(
            meta=out_meta, body=out_body,
            canonical_rel=f".claude/commands/{name}.md",
        )
        path = wf_dir / f"{name}.md"
        if safe_write(path, text):
            written.append(path)

    rules = out_root / ".windsurfrules"
    existing = rules.read_text(encoding="utf-8") if rules.exists() else ""
    if "scaffold-gen:tier2-warning:start" not in existing:
        rules.write_text(existing + WARNING_BLOCK, encoding="utf-8")
        written.append(rules)
    return written
