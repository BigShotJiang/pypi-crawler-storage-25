"""Canonical loader + generated-marker detection + render dispatcher."""
from __future__ import annotations

from importlib import import_module
from pathlib import Path

from . import _frontmatter as fm

GENERATED_MARKER = "<!-- generated-from:"

_RENDERER_MODULES = {
    "cursor": "sdlc_framework.scaffold_gen.renderers.cursor",
    "copilot": "sdlc_framework.scaffold_gen.renderers.copilot",
    "cline": "sdlc_framework.scaffold_gen.renderers.cline",
    "windsurf": "sdlc_framework.scaffold_gen.renderers.windsurf",
    "continue": "sdlc_framework.scaffold_gen.renderers.continue_",
}


def load_canonical_command(name: str, *, scaffold_root: Path) -> tuple[dict, str]:
    path = scaffold_root / ".claude" / "commands" / f"{name}.md"
    return fm.parse(path.read_text(encoding="utf-8"))


def load_canonical_agent(name: str, *, scaffold_root: Path) -> tuple[dict, str]:
    path = scaffold_root / "agents" / f"{name}.md"
    return fm.parse(path.read_text(encoding="utf-8"))


def is_generated(text: str) -> bool:
    return GENERATED_MARKER in text


def render_for_tool(tool: str, *, scaffold_root: Path, out_root: Path) -> list[Path]:
    # `claude` is the canonical surface — `.claude/` files are the source
    # that other tool renderers consume FROM. There's nothing to "render
    # to claude" because the scaffold copy already produced `.claude/agents/`
    # and `.claude/commands/`. Treat as a no-op rather than emitting the
    # misleading "unknown tool: claude" warning. F-D2-006 in audit.
    if tool == "claude":
        return []
    if tool not in _RENDERER_MODULES:
        raise ValueError(f"unknown tool: {tool}")
    mod = import_module(_RENDERER_MODULES[tool])
    return mod.render(scaffold_root=scaffold_root, out_root=out_root)


def render_all(*, tools: list[str], scaffold_root: Path, out_root: Path) -> dict[str, list[Path]]:
    return {
        t: render_for_tool(t, scaffold_root=scaffold_root, out_root=out_root)
        for t in tools
    }
