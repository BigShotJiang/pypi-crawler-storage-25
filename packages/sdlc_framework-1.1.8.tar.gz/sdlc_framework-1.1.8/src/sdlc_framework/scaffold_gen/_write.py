"""Idempotent write — refuses to overwrite user-edited files."""
from __future__ import annotations

from pathlib import Path

from . import core


def safe_write(path: Path, content: str) -> bool:
    """Write only if file is missing or carries the generated marker.

    Returns True if written, False if skipped (user-edited).
    """
    if path.exists() and not core.is_generated(path.read_text(encoding="utf-8")):
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True
