# src/sdlc_framework/adopt_scaffold.py
"""Scaffold the PR8-introduced hierarchy dirs during `sdlc adopt`.

Idempotent: only records new manifest actions when something actually
changes on disk. README + .gitignore content is fixed (no template
variables) so a re-run produces no diff.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from sdlc_framework.adopt_manifest import AdoptManifest


HIERARCHY_DIRS: tuple[str, ...] = (
    "01-Planning/epics",
    "01-Planning/stories",
    "automation/epics",
    "automation/stories",
    "automation/.epic-context",
    "automation/reviews",
    "automation/audit",
)


_EPIC_README = """\
# Epics

Epic narrative files (`<slug>.md`) live here. Each Epic is a coherent slice
of product work that decomposes into one or more Stories.

## Authoring flow

1. `sdlc epic new <slug>` — scaffold the markdown skeleton.
2. Fill in the Goal, Stories list, Requirements & Constraints sections.
3. `sdlc epic sync <slug>` — parse the markdown into `automation/epics/<slug>.yaml`
   so the engine + dashboard pick up status.

See spec §3 (`docs/superpowers/specs/2026-05-03-epic-story-task-hierarchy-and-multi-reviewer-design.md`)
for the full Epic→Story→Task contract.
"""

_STORY_README = """\
# Stories

Story narrative files (`<slug>.md`) live here. Each Story is a single user
need with Given/When/Then acceptance criteria. Stories may belong to an Epic
(via `epic:` frontmatter) or stand alone (orphan stories).

## Authoring flow

1. `sdlc story new <slug> [--epic <epic-slug>]` — scaffold the skeleton.
2. Fill in the As-a/I-want/So-that block + G/W/T criteria.
3. `sdlc story complete-draft <slug>` — gate `draft → ready`.
4. `sdlc tasks bootstrap` — derive Phase 3 tasks from acceptance criteria.

See spec §3 for the Story state machine.
"""

_EPIC_CONTEXT_GITIGNORE = "*\n!.gitignore\n"


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _ensure_dir(target: Path, rel: str, manifest: AdoptManifest) -> bool:
    p = target / rel
    if p.is_dir():
        return False
    p.mkdir(parents=True, exist_ok=True)
    manifest.record_mkdir(rel)
    return True


def _ensure_file(
    target: Path, rel: str, content: str, manifest: AdoptManifest,
) -> bool:
    p = target / rel
    digest = _sha256(content)
    if p.is_file():
        existing = p.read_text(encoding="utf-8")
        if _sha256(existing) == digest:
            return False
        # Don't overwrite user-modified content; leave as-is.
        return False
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    manifest.record_write(rel, sha256=digest)
    return True


def scaffold_hierarchy_dirs(target: Path, manifest: AdoptManifest) -> None:
    """Create the 7 hierarchy dirs + READMEs + epic-context .gitignore.

    Records every newly-created path on the manifest. Idempotent — re-runs
    produce no new manifest entries.
    """
    for rel in HIERARCHY_DIRS:
        _ensure_dir(target, rel, manifest)

    _ensure_file(
        target, "01-Planning/epics/README.md", _EPIC_README, manifest,
    )
    _ensure_file(
        target, "01-Planning/stories/README.md", _STORY_README, manifest,
    )
    _ensure_file(
        target, "automation/.epic-context/.gitignore",
        _EPIC_CONTEXT_GITIGNORE, manifest,
    )
