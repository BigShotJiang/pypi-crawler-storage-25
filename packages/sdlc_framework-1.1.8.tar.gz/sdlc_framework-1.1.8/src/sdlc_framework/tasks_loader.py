"""Read automation/tasks/*.yaml task files and compute current stage per task.

Inject as Phase 3 Tasks sub-track items into engine state.
"""
from __future__ import annotations

import datetime as _dt
import json as _json
import subprocess
from pathlib import Path

import yaml


def _utcnow_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def resolve_active_group(
    state: dict,
    tasks: list[dict],  # noqa: ARG001 — kept for future extension
    group_done_pairs: list[tuple[str, bool]],
) -> str | None:
    """Pick or promote the active story_id (or task.id) for Phase 3.

    ``group_done_pairs`` is a list of ``(group_id, all_tasks_done)`` in
    the order groups should be considered for promotion (yaml file-name
    order is the engine convention).

    Mutates ``state["phase3"]`` in place. Returns the active group id,
    or None when all groups are done.
    """
    state.setdefault("phase3", {"active_story_id": None, "lock_acquired_at": None})
    p3 = state["phase3"]
    current = p3.get("active_story_id")
    by_id = {gid: done for gid, done in group_done_pairs}
    if current and current in by_id and not by_id[current]:
        return current
    for gid, done in group_done_pairs:
        if not done:
            p3["active_story_id"] = gid
            p3["lock_acquired_at"] = _utcnow_iso()
            return gid
    p3["active_story_id"] = None
    p3["lock_acquired_at"] = None
    return None

# v1.1.0: terminal stage renamed ``done → committed``; ``await-merge`` removed.
# PR detection moves to the **story tier** — the per-story consolidator owns the
# branch + PR + merge for all sibling tasks. Filesystem evidence plateaus at
# ``review``; only an explicit ``committed_at`` marker on the task yaml flips
# it to ``committed``. As a tuple to signal the enum is closed.
VALID_STAGES = ("pending", "write-tests", "write-code", "review", "committed")
VALID_KINDS = ("feature", "bug", "chore", "hotfix", "support")


def validate_task_kind(kind: str) -> None:
    """Raise ValueError if kind is not one of VALID_KINDS."""
    if kind not in VALID_KINDS:
        raise ValueError(
            f"invalid kind: {kind!r}; must be one of {VALID_KINDS}"
        )


def derive_epic_id(target: Path, story_id: str | None) -> str | None:
    """Resolve epic_id by looking up the story yaml.

    Returns None if story_id is empty, story file missing, or story has no parent epic.
    """
    if not story_id:
        return None
    story_path = target / "automation" / "stories" / f"{story_id}.yaml"
    if not story_path.exists():
        return None
    try:
        data = yaml.safe_load(story_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return None
    return data.get("epic_id") or None
# Stage labels reflect the *current activity* (what is happening NOW), not
# the deliverable already produced. ``pending`` means the task is queued
# behind the **story-tier** serial lock — not currently being worked on.
# The active ladder is ``write-tests → write-code → review → committed``;
# each label names the activity in flight (or, for ``committed``, the
# terminal state stamped by the story-tier consolidator post-merge). This
# was reshaped in v1.1.0 when PR detection moved to the story tier; pre-
# v1.1.0 had two extra stages ``await-merge`` and ``done`` driven by
# ``gh pr`` queries that the task tier no longer makes.
HIGH_RISK_HINTS = ["auth", "crypto", "payment", "secrets", "iam", "migration"]


def load_tasks(target: Path) -> list[dict]:
    """Load all automation/tasks/*.yaml. Returns task dicts (passes through unchanged)."""
    import sys
    tasks_dir = target / "automation" / "tasks"
    if not tasks_dir.exists():
        return []
    out: list[dict] = []
    for f in sorted(tasks_dir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict) or not data.get("id"):
            continue
        kind = data.get("kind", "feature")
        try:
            validate_task_kind(kind)
        except ValueError as e:
            print(f"[sdlc tasks] skipping {f.name}: {e}", file=sys.stderr)
            continue
        out.append(data)
    return out


def _glob_paths(target: Path, pattern: str) -> set[Path]:
    """Return resolved files matching glob from target root, handling brace expansion."""
    from sdlc_framework import engine
    saved = engine.ROOT
    try:
        engine.ROOT = target
        return {p.resolve() for p in engine._glob(pattern)}
    finally:
        engine.ROOT = saved


def _glob_count(target: Path, pattern: str) -> int:
    """Count files matching glob from target root, handling brace expansion."""
    return len(_glob_paths(target, pattern))


def _pr_status_batch(branches: list[str], target: Path) -> dict[str, str]:
    """Return ``{branch: status}`` for every input branch in ONE `gh` call.

    Status is ``'open'``, ``'merged'``, or ``'none'``. Performs one
    ``gh pr list --json --state all --limit N`` instead of N separate
    ``gh pr view`` calls. Falls back to ``{}`` (caller treats as 'none')
    when ``gh`` is missing, unauthenticated, offline, or times out.

    This is the perf hot path during ``sdlc scan`` — N tasks used to
    mean N × up-to-5s subprocess calls and N × API quota burn.
    """
    out: dict[str, str] = {}
    branches = [b for b in branches if b]
    if not branches:
        return out
    # Cap at 200 — sane upper bound; exceeding this means a project has
    # accumulated too many task PRs and should archive some anyway.
    limit = max(200, len(branches) * 2)
    try:
        result = subprocess.run(
            ["gh", "pr", "list",
             "--state", "all",
             "--limit", str(limit),
             "--json", "headRefName,state"],
            capture_output=True, text=True, timeout=10, cwd=str(target),
        )
        if result.returncode != 0:
            return out
        data = _json.loads(result.stdout or "[]")
    except Exception:
        return out
    wanted = set(branches)
    # Track per-branch best status — prefer 'merged' over 'open' over 'none'
    # in case the same head branch has multiple PR records (rare but possible
    # after re-opening / closing).
    rank = {"merged": 2, "open": 1, "none": 0}
    for entry in data:
        head = entry.get("headRefName") or ""
        if head not in wanted:
            continue
        state = (entry.get("state") or "").upper()
        if state == "MERGED":
            status = "merged"
        elif state in ("OPEN", "DRAFT"):
            status = "open"
        else:
            continue
        if rank[status] > rank.get(out.get(head, "none"), 0):
            out[head] = status
    return out


def _pr_status(branch: str, target: Path) -> str:
    """Single-branch status query (legacy / fallback path).

    Prefer ``_pr_status_batch`` from a scan loop; this exists for callers
    that have only one branch on hand or for back-compat with older code.
    """
    if not branch:
        return "none"
    return _pr_status_batch([branch], target).get(branch, "none")


def _resolve_feature_branches(tasks: list[dict]) -> dict[str, str]:
    """Map ``story_id`` → canonical PR branch shared by all siblings.

    Task yamls may opt in to story grouping by declaring
    ``story_id: <slug>``. All tasks sharing a story_id then share
    one PR (instead of N PRs for one user requirement). The branch is
    resolved as:

      1. The first explicit ``pr_branch`` declared on any sibling
         (file-sort order — ``load_tasks`` returns sorted yamls).
      2. ``feature/<story_id>`` as a deterministic fallback.

    Tasks without ``story_id`` are not represented in the returned
    map; they retain their per-task ``pr_branch`` via the legacy path.
    """
    explicit: dict[str, str] = {}
    seen: set[str] = set()
    for t in tasks:
        fid = t.get("story_id")
        if not fid:
            continue
        seen.add(fid)
        if fid not in explicit and t.get("pr_branch"):
            explicit[fid] = t["pr_branch"]
    return {fid: explicit.get(fid, f"feature/{fid}") for fid in seen}


def detect_stage(
    task: dict,
    target: Path,
    pr_cache: dict[str, str] | None = None,  # noqa: ARG001 — vestigial, kept for caller compat
    override_branch: str | None = None,  # noqa: ARG001 — vestigial, kept for caller compat
    *,
    is_active: bool = True,
) -> str:
    """Determine the task's current stage from filesystem + ``committed_at``.

    v1.1.0: PR detection moved to the **story tier** (the per-story
    consolidator owns the branch + shared PR + merge for sibling tasks).
    Task-tier stage detection no longer queries ``gh pr``. ``pr_cache``
    and ``override_branch`` parameters are kept in the signature so
    callers in :func:`evaluate_task_as_item` and the engine don't break,
    but they are no longer consulted.

    Stage ladder (v1.1.0):
      ``pending → write-tests → write-code → review → committed``

    The terminal ``committed`` stage is set by an explicit
    ``committed_at`` timestamp on the task yaml — written by the
    story-tier consolidator after the shared PR merges. Filesystem
    evidence alone plateaus at ``review``.

    ``is_active=False`` short-circuits non-committed tasks to ``pending``
    so the story-tier serial lock doesn't let inactive groups drift.
    Already-``committed`` tasks are terminal and never regress.
    """
    # Terminal stage — explicit consolidator marker. Overrides serial-lock
    # so a completed task doesn't regress to ``pending`` when its group
    # rotates out of the active slot.
    if task.get("committed_at"):
        return "committed"

    # Inactive group (story-tier serial lock) → queued, not being worked on.
    if not is_active:
        return "pending"

    code_glob = task.get("code_glob") or ""
    test_glob = task.get("test_glob") or ""
    # Bootstrapped globs are typically nested: code_glob `*.{ts,...}` is a
    # superset of test_glob `*.{test,spec}.{ts,...}`. Counting raw matches
    # would double-count test files as production code, falsely advancing
    # the stage to ``review`` while developer-agent has not written a
    # single production file. Exclude test paths from the code count so
    # ``n_code`` only reflects real production source.
    test_paths = _glob_paths(target, test_glob) if test_glob else set()
    code_paths = _glob_paths(target, code_glob) if code_glob else set()
    n_test = len(test_paths)
    n_code = len(code_paths - test_paths)

    # No deliverables yet on an active task = test-author is in the
    # write-tests activity right now.
    if n_code == 0 and n_test == 0:
        return "write-tests"
    # Code without any matching test → backfill tests first; the activity
    # is still write-tests until the test suite catches up.
    if n_test == 0 and n_code > 0:
        return "write-tests"
    # Tests exist, no code yet → developer-agent is writing code now.
    if n_test > 0 and n_code == 0:
        return "write-code"
    # Both code and tests exist. Do NOT compare counts: one test file
    # legitimately covers many implementation files, so n_test < n_code
    # does not mean "TDD violation". TDD discipline is enforced by
    # *requiring* n_test > 0 before leaving write-tests, which is already
    # guaranteed at this point.
    # Both files exist, no committed_at yet → code-reviewer is reviewing
    # locally. Stage parks here until the story-tier consolidator stamps
    # ``committed_at`` post-merge.
    return "review"


def stage_to_subagent(task: dict, stage: str) -> str | None:
    """Map current activity stage to the subagent performing it.

    Each stage labels the activity in flight; the agent returned here is
    the one DOING that activity. ``pending`` (inactive group) and
    ``committed`` (terminal) return None. Legacy ``await-merge``/``done``
    stages also return None defensively so a stale state.json from a
    pre-v1.1.0 install does not raise — autopilot just sees "no agent"
    and advances on the next scan.
    """
    label = (task.get("label") or "") + " " + (task.get("id") or "")
    is_sensitive = any(h in label.lower() for h in HIGH_RISK_HINTS)
    return {
        "pending": None,                 # inactive group, queued behind story-tier serial lock
        "write-tests": "test-author",
        "write-code": "developer-agent",
        "review": "security-reviewer" if is_sensitive else "code-reviewer",
        "committed": None,               # terminal — consolidator stamped committed_at
    }.get(stage)


def evaluate_task_as_item(
    task: dict,
    target: Path,
    pr_cache: dict[str, str] | None = None,
    override_branch: str | None = None,
    *,
    is_active: bool = True,
) -> dict:
    """Convert a task dict into a Phase-3-compatible item dict for state.json.

    ``pr_cache`` is forwarded to :func:`detect_stage`; pass one once per
    scan to avoid a ``gh`` subprocess per task.

    ``override_branch`` lets the engine plug in a feature-shared branch
    (see ``_resolve_feature_branches``); the resolved branch becomes
    both the PR-detection target AND what ``state.json`` shows for
    ``pr_branch`` so the dashboard renders the effective branch.
    """
    stage = detect_stage(task, target, pr_cache=pr_cache,
                         override_branch=override_branch,
                         is_active=is_active)
    effective_branch = override_branch or task.get("pr_branch")
    return {
        "id": task["id"],
        "label": task.get("label") or task["id"],
        "subtrack": "tasks",
        "done": stage == "committed",
        # ``drafted`` = "real evidence exists". A bare ``write-tests`` stage
        # has no committed deliverable yet (test-author is still working);
        # everything from ``write-code`` onwards is a checkpoint with a
        # tangible artifact (tests at minimum).
        "drafted": stage in ("write-code", "review", "committed"),
        "verified": stage == "committed",
        "stage": stage,
        "stages": list(VALID_STAGES),
        "next_subagent": stage_to_subagent(task, stage),
        "priority": task.get("priority") or "medium",
        "code_glob": task.get("code_glob"),
        "test_glob": task.get("test_glob"),
        "pr_branch": effective_branch,
        "story_id": task.get("story_id"),
        "story": task.get("story"),
        "kind": task.get("kind", "feature"),
        "epic_id": derive_epic_id(target, task.get("story_id")),
        "checks": [{
            "rule": {"type": "task_stage"},
            "ok": stage == "committed",
            "msg": f"current stage: {stage}",
        }],
    }
