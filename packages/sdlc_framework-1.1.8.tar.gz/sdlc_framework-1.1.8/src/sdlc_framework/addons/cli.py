"""``sdlc addons <subcmd>`` — list / info / install / remove / sync.

This module exposes :func:`cmd_addons` as the dispatch entry point. The
top-level ``cli.py`` registers it under the ``addons`` subcommand.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import asset_indexer
from . import collisions as collisions_mod
from . import lockfile as lockfile_mod
from . import loader
from . import tool_detect
from .fetcher import FetchError, fetch, remove_fetched
from .injector import (
    content_hash,
    detect_drift,
    inject_snippet,
    remove_snippet,
)
from .lockfile import (
    AddonEntry,
    AssetRecord,
    FetchEntry,
    SnippetEntry,
    upsert_addon,
)
from .schema import (
    AgentInstruction,
    AppliesTo,
    DocSnippet,
    Recipe,
    RemoteFetch,
    SchemaError,
)


# ---------------------------------------------------------------------------
# Top-level dispatch
# ---------------------------------------------------------------------------

def cmd_addons(argv: list[str], project_root: Path | None = None) -> int:
    """Dispatch to the ``addons`` subcommand. Returns process exit code."""
    parser = argparse.ArgumentParser(prog="sdlc addons")
    sub = parser.add_subparsers(dest="action", required=True)
    p_list = sub.add_parser("list", help="list available + installed add-ons")
    p_list.add_argument("--installed", action="store_true")
    p_list.add_argument("--phase", type=int, choices=[1, 2, 3, 4, 5])
    p_list.add_argument("--all-tools", action="store_true",
                        help="include tool-gated add-ons even if your "
                             "selected tools don't match")
    p_info = sub.add_parser("info", help="show recipe details")
    p_info.add_argument("id")
    p_install = sub.add_parser("install", help="install one or more add-ons")
    p_install.add_argument("ids", help="comma-separated add-on ids")
    p_install.add_argument("--yes", action="store_true",
                           help="skip interactive confirmation")
    p_install.add_argument("--offline", action="store_true",
                           help="skip remote-fetch entries (snippets only)")
    p_install.add_argument("--force", action="store_true",
                           help="overwrite user files that conflict with addon "
                                "writes (default: skip them)")
    p_remove = sub.add_parser("remove", help="uninstall an add-on")
    p_remove.add_argument("id")
    p_remove.add_argument(
        "--yes", action="store_true",
        help="Skip the destructive-remove confirmation prompt. Without --yes "
             "the command lists files about to be deleted and asks before "
             "proceeding (F-D5-006 in audit — addon files were previously "
             "deleted unconditionally even when the user had edited them).",
    )
    p_sync = sub.add_parser("sync", help="apply addons.lock to filesystem")
    p_sync.add_argument("--yes", action="store_true")
    p_sync.add_argument("--offline", action="store_true")

    args = parser.parse_args(argv)
    root = project_root or Path.cwd()

    try:
        if args.action == "list":
            return _cmd_list(
                root,
                installed_only=args.installed,
                phase=args.phase,
                all_tools=args.all_tools,
            )
        if args.action == "info":
            return _cmd_info(root, args.id)
        if args.action == "install":
            ids = [x.strip() for x in args.ids.split(",") if x.strip()]
            return _cmd_install(
                root, ids,
                yes=args.yes, offline=args.offline, force=args.force,
            )
        if args.action == "remove":
            return _cmd_remove(root, args.id, yes=args.yes)
        if args.action == "sync":
            return _cmd_sync(root, yes=args.yes, offline=args.offline)
    except SchemaError as e:
        print(f"[sdlc addons] schema error: {e}", file=sys.stderr)
        return 2
    except FetchError as e:
        print(f"[sdlc addons] fetch error: {e}", file=sys.stderr)
        return 4

    parser.print_help()
    return 2


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

def _cmd_list(
    root: Path, *, installed_only: bool, phase: int | None, all_tools: bool,
) -> int:
    recipes = loader.load_all(root)
    lock = lockfile_mod.read(root)
    selected = tool_detect.resolve(root)

    rows: list[tuple[str, str, str, str, str, str]] = []
    for rid in sorted(recipes):
        r = recipes[rid]
        if phase is not None and not _matches_phase(r, phase):
            continue
        if (
            not all_tools
            and not tool_detect.recipe_matches_tools(r.requires_ai_tool, selected)
        ):
            continue
        installed = rid in lock.addons
        if installed_only and not installed:
            continue
        track = ", ".join(_slot_label(a) for a in r.applies_to)
        status = "installed" if installed else "available"
        version = lock.addons[rid].version if installed else "—"
        tools = ",".join(r.requires_ai_tool) if r.requires_ai_tool else "any"
        rows.append((rid, _phase_repr(r), track, tools, status, version))

    if not rows:
        print("No add-ons match the filter.")
        return 0

    headers = ("ID", "PHASE", "TRACK", "TOOLS", "STATUS", "VERSION")
    widths = [max(len(headers[i]), max(len(r[i]) for r in rows)) for i in range(6)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    print(fmt.format(*headers))
    for r in rows:
        print(fmt.format(*r))
    if not all_tools and selected:
        print(
            f"\n(filtered by detected tools: {sorted(selected)} — "
            "use --all-tools to see all)"
        )
    return 0


def _matches_phase(r: Recipe, phase: int) -> bool:
    return any(a.phase == phase for a in r.applies_to)


def _phase_repr(r: Recipe) -> str:
    phases = sorted({a.phase for a in r.applies_to if a.phase is not None})
    if not phases:
        return "cross"
    return ",".join(str(p) for p in phases)


def _slot_label(a: AppliesTo) -> str:
    if a.phase is None:
        return "cross"
    return f"{a.phase}/{a.subtrack}"


# ---------------------------------------------------------------------------
# info
# ---------------------------------------------------------------------------

def _cmd_info(root: Path, addon_id: str) -> int:
    r = loader.load_recipe(root, addon_id)
    print(f"{r.name}  ({r.id})")
    print(f"Phase    : {_phase_repr(r)}")
    print(f"Track    : {', '.join(_slot_label(a) for a in r.applies_to)}")
    print(f"License  : {r.license}")
    print(f"Homepage : {r.homepage}")
    print(f"Description: {r.description}")
    print()
    print("Will inject:")
    for inj in r.injects:
        if isinstance(inj, DocSnippet):
            print(f"  • doc-snippet  → {inj.target}  (section: {inj.section_id})")
        elif isinstance(inj, AgentInstruction):
            print(f"  • agent-instr  → {inj.target}  (section: {inj.section_id})")
        elif isinstance(inj, RemoteFetch):
            print(f"  • remote-fetch ← {inj.from_url}  @ {inj.pin}")
            for s in inj.select:
                print(f"      {s.from_pat}  →  {s.to}")
    return 0


# ---------------------------------------------------------------------------
# install
# ---------------------------------------------------------------------------

def _cmd_install(
    root: Path, ids: list[str], *, yes: bool, offline: bool, force: bool = False,
) -> int:
    if not ids:
        print("[sdlc addons] no ids provided", file=sys.stderr)
        return 2
    recipes = loader.load_all(root)
    missing = [rid for rid in ids if rid not in recipes]
    if missing:
        print(f"[sdlc addons] unknown add-ons: {missing}", file=sys.stderr)
        return 2

    fetch_recipes = [
        recipes[rid] for rid in ids
        if any(isinstance(i, RemoteFetch) for i in recipes[rid].injects)
    ]
    if fetch_recipes and not offline and not yes:
        print("[sdlc addons] the following add-ons will fetch remote content:")
        for r in fetch_recipes:
            for inj in r.injects:
                if isinstance(inj, RemoteFetch):
                    print(f"  • {r.id}: {inj.from_url} @ {inj.pin}")
                    print(f"      license: {r.license}    homepage: {r.homepage}")
        if not _confirm():
            print("[sdlc addons] aborted.")
            return 0

    lock = lockfile_mod.read(root)
    rc = 0
    for rid in ids:
        result = _install_one(
            root, recipes[rid], lock, offline=offline, yes=yes, force=force,
        )
        if result != 0:
            rc = result
        lock = lockfile_mod.read(root)   # re-read after each install
    return rc


def _install_one(
    root: Path, recipe: Recipe, lock, *, offline: bool,
    yes: bool = False, force: bool = False,
) -> int:
    """Install one recipe. Returns process exit code (0 = success, 5 = blocked)."""
    print(f"[sdlc addons] installing {recipe.id}…")
    snippets: list[SnippetEntry] = []
    fetched: FetchEntry | None = None
    resolved_sha = "—"
    version = "—"

    # ── Pre-flight collision check (Type 1, Type 2) ──
    # Snippet planned writes are knowable from the recipe alone; remote-fetch
    # planned files require a temp clone first, handled per-inject below.
    planned_snippets = [
        (inj.target, inj.section_id)
        for inj in recipe.injects
        if isinstance(inj, (DocSnippet, AgentInstruction))
    ]
    reserved = collisions_mod.framework_reserved_paths()
    owners = collisions_mod.installed_path_owners(lock)
    snip_report = collisions_mod.check_collisions(
        recipe.id,
        planned_files=[],
        planned_snippets=planned_snippets,
        reserved=reserved,
        owners=owners,
        project_root=root,
    )
    if snip_report.has_blocking:
        print(collisions_mod.render_collision_report(snip_report), file=sys.stderr)
        return 5

    # Track the snippets we've successfully injected so far so that, if a
    # later step (typically a remote-fetch) fails, we can roll the on-disk
    # markers back to keep install transactional. Without this, a network
    # blip during fetch leaves orphaned markers + an empty lockfile entry,
    # and ``sdlc addons remove`` refuses ("not installed"). F-D5-001 in audit.
    injected_snippets: list[tuple[str, str]] = []  # (target, section_id) pairs

    try:
        for inj in recipe.injects:
            if isinstance(inj, (DocSnippet, AgentInstruction)):
                result = inject_snippet(root, recipe.id, inj)
                print(f"    {result.action}: {inj.target}#{inj.section_id}")
                snippets.append(SnippetEntry(
                    target=inj.target,
                    section_id=inj.section_id,
                    content_hash=result.content_hash,
                ))
                injected_snippets.append((inj.target, inj.section_id))
            elif isinstance(inj, RemoteFetch):
                if offline:
                    print(f"    skipped (offline): fetch {inj.from_url}")
                    continue
                # Snapshot which destination dir paths exist BEFORE fetch so
                # we can distinguish "user file existed already" from "we just
                # wrote this file" — the latter must NOT trip Type 3.
                pre_fetch_existing = _snapshot_existing(root, inj)
                res = fetch(root, inj)
                resolved_sha = res.resolved_sha
                version = inj.pin
                # Filter "files we wrote" against pre-fetch existing → only
                # files that already existed are user-file conflicts.
                actually_existed = [f for f in res.files if f in pre_fetch_existing]
                fetch_report = collisions_mod.check_collisions(
                    recipe.id,
                    planned_files=list(res.files),
                    planned_snippets=[],
                    reserved=reserved,
                    owners=owners,
                    project_root=root,
                )
                # Override user_files with only paths that actually pre-existed.
                from dataclasses import replace
                fetch_report = replace(fetch_report, user_files=actually_existed)
                if fetch_report.has_blocking:
                    _rollback_fetched(root, res.files, res.to)
                    _rollback_snippets(root, recipe.id, injected_snippets)
                    print(collisions_mod.render_collision_report(fetch_report), file=sys.stderr)
                    return 5
                if fetch_report.has_warnings:
                    if not _resolve_user_file_conflicts(
                        fetch_report.user_files, yes=yes, force=force,
                    ):
                        _rollback_fetched(root, res.files, res.to)
                        _rollback_snippets(root, recipe.id, injected_snippets)
                        print(f"    aborted: {len(fetch_report.user_files)} user file conflicts")
                        return 0
                print(f"    fetched {len(res.files)} files → {res.to}")
                indexed_assets = asset_indexer.index_fetched(root, list(res.files))
                asset_records = [
                    AssetRecord(
                        path=a.path, kind=a.kind, name=a.name, description=a.description,
                    )
                    for a in indexed_assets
                ]
                fetched = FetchEntry(
                    to=res.to, files=list(res.files), assets=asset_records,
                )
    except FetchError:
        # Remote fetch raised (network, pin mismatch, missing path…). Reverse
        # any snippets we've already injected and re-raise so the caller's
        # generic FetchError handler at cmd_addons level prints the message.
        _rollback_snippets(root, recipe.id, injected_snippets)
        raise

    if version == "—":
        # Snippet-only addon — record sdlc version as the "version" stamp.
        from sdlc_framework import __version__ as sdlc_v
        version = f"snippet-only@{sdlc_v}"
        resolved_sha = "snippet-only"

    from sdlc_framework import __version__ as sdlc_v
    entry = AddonEntry(
        version=version,
        resolved_sha=resolved_sha,
        installed_at=lockfile_mod.utc_now_iso(),
        sdlc_version=sdlc_v,
        snippets=snippets,
        fetched=fetched,
    )
    lockfile_mod.write(root, upsert_addon(lock, recipe.id, entry))
    return 0


def _snapshot_existing(root: Path, inj: RemoteFetch) -> set[str]:
    """Snapshot project-relative paths that exist under any of inj.select.to dirs
    BEFORE fetch runs. Used to distinguish pre-existing user files from files
    the fetch is about to create."""
    out: set[str] = set()
    for entry in inj.select:
        dest_dir = root / entry.to
        if not dest_dir.exists():
            continue
        for p in dest_dir.rglob("*"):
            if p.is_file():
                try:
                    out.add(str(p.relative_to(root)))
                except ValueError:
                    pass
    return out


def _rollback_snippets(
    root: Path, addon_id: str, injected: list[tuple[str, str]],
) -> None:
    """Reverse snippet injections so an aborted install leaves no orphans.

    Symmetric to ``_rollback_fetched`` for the snippet path. Best-effort:
    failures during rollback are swallowed (the install path itself already
    raised, and double-failing during cleanup makes for a worse error).
    """
    for target, section_id in injected:
        try:
            remove_snippet(root, addon_id, target, section_id)
        except Exception:
            # Don't mask the original install error with a rollback error.
            pass


def _rollback_fetched(root: Path, files, to: str) -> None:
    """Remove files we just wrote when post-clone collision check fails."""
    for f in files:
        try:
            (root / f).unlink()
        except OSError:
            pass
    # Try to remove now-empty parent dirs up to project root
    to_dir = root / to
    cur = to_dir.resolve() if to_dir.exists() else None
    if cur is None:
        return
    stop = root.resolve()
    while cur != stop and cur.exists() and cur.is_dir():
        try:
            cur.rmdir()
        except OSError:
            return
        cur = cur.parent


def _resolve_user_file_conflicts(
    user_files: list[str], *, yes: bool, force: bool,
) -> bool:
    """Decide what to do about Type 3 conflicts. Returns True to proceed."""
    print(
        f"[sdlc addons] {len(user_files)} user file(s) would be overwritten:",
        file=sys.stderr,
    )
    for f in user_files[:10]:
        print(f"  {f}", file=sys.stderr)
    if len(user_files) > 10:
        print(f"  ...and {len(user_files) - 10} more", file=sys.stderr)
    if yes and force:
        print("  → --yes --force: proceeding with overwrite", file=sys.stderr)
        return True
    if yes:
        print("  → --yes (no --force): leaving user files alone, aborting addon",
              file=sys.stderr)
        return False
    # Interactive
    if not sys.stdin.isatty():
        return False
    try:
        ans = input("  Proceed? [o]verwrite / [s]kip+abort / [a]bort: ").strip().lower()
    except (EOFError, OSError):
        return False
    return ans.startswith("o")


# ---------------------------------------------------------------------------
# remove
# ---------------------------------------------------------------------------

def _cmd_remove(root: Path, addon_id: str, *, yes: bool = False) -> int:
    lock = lockfile_mod.read(root)
    if addon_id not in lock.addons:
        print(f"[sdlc addons] {addon_id} is not installed", file=sys.stderr)
        return 2
    entry = lock.addons[addon_id]

    # F-D5-006: list files about to be deleted and confirm before proceeding,
    # unless --yes was given. Without this prompt, a user who edited any of
    # the fetched files (e.g. customised the imported design tokens) lost
    # their changes without warning. The fetcher writes addon-owned files
    # but the user cannot easily distinguish "addon file" from "my file"
    # after a few weeks of work.
    fetched_count = len(entry.fetched.files) if entry.fetched else 0
    snippet_count = len(entry.snippets)
    print(f"[sdlc addons] remove {addon_id} will:")
    print(f"    - remove {snippet_count} doc-snippet block(s) (idempotent)")
    if entry.fetched is not None:
        print(f"    - DELETE {fetched_count} file(s) under {entry.fetched.to}")
        # Show up to 5 sample files so user can spot one they care about.
        sample = list(entry.fetched.files)[:5]
        for f in sample:
            print(f"        {f}")
        if fetched_count > len(sample):
            print(f"        … and {fetched_count - len(sample)} more")
        if not yes:
            print(
                "[sdlc addons] WARNING: any local edits to those files will "
                "be lost. Pass --yes to skip this prompt."
            )
            try:
                resp = input("[sdlc addons] Proceed with delete? [y/N] ").strip().lower()
            except EOFError:
                resp = ""
            if resp not in ("y", "yes"):
                print("[sdlc addons] aborted; lockfile + files preserved.")
                return 0

    print(f"[sdlc addons] removing {addon_id}…")

    for s in entry.snippets:
        result = remove_snippet(root, addon_id, s.target, s.section_id)
        status = "removed" if result.found else "already absent"
        print(f"    snippet {status}: {s.target}#{s.section_id}")

    if entry.fetched is not None:
        summary = remove_fetched(
            root, list(entry.fetched.files), to=entry.fetched.to,
        )
        print(f"    fetched files: deleted={len(summary['deleted'])}, "
              f"kept={len(summary['kept'])}")

    lockfile_mod.write(root, lockfile_mod.remove_addon(lock, addon_id))
    return 0


# ---------------------------------------------------------------------------
# sync — re-apply lockfile to filesystem (e.g. after fresh clone)
# ---------------------------------------------------------------------------

def _cmd_sync(root: Path, *, yes: bool, offline: bool) -> int:
    lock = lockfile_mod.read(root)
    if not lock.addons:
        print("[sdlc addons] addons.lock is empty — nothing to sync.")
        return 0
    recipes = loader.load_all(root)
    rc = 0
    for rid, entry in lock.addons.items():
        if rid not in recipes:
            print(f"[sdlc addons] sync: recipe for {rid} not available; "
                  "leaving as-is", file=sys.stderr)
            continue
        recipe = recipes[rid]
        # Re-inject snippets if they're missing or drifted (drift → skip)
        for inj in recipe.injects:
            if isinstance(inj, (DocSnippet, AgentInstruction)):
                expected = content_hash(inj.content)
                state = detect_drift(root, rid, inj.target, inj.section_id, expected)
                if state == "missing":
                    inject_snippet(root, rid, inj)
                    print(f"    sync: re-installed snippet {inj.target}#{inj.section_id}")
            elif isinstance(inj, RemoteFetch):
                if offline:
                    print(f"    sync: skipped fetch (offline): {inj.from_url}")
                    continue
                # Re-fetch only if files are missing
                if entry.fetched is None or not all(
                    (root / f).exists() for f in entry.fetched.files
                ):
                    if not yes and not _confirm(
                        f"re-fetch {inj.from_url} @ {inj.pin}?",
                    ):
                        print(f"    sync: skipped fetch by user request")
                        continue
                    fetch(root, inj)
                    print(f"    sync: re-fetched {inj.from_url}")
    return rc


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _confirm(prompt: str = "Proceed?") -> bool:
    """Yes/no prompt. Default ``no`` if input is empty or non-tty."""
    if not sys.stdin.isatty():
        return False
    try:
        ans = input(f"{prompt} [y/N] ").strip().lower()
    except EOFError:
        return False
    return ans in ("y", "yes")
