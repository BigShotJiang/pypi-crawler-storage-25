"""AI-tool detection for the addon system.

The user picks AI tools during ``sdlc setup``. We persist that choice to
``automation/.ai-tools`` (committed to git) so post-setup commands like
``sdlc addons list`` and the in-setup picker can filter recipes by the
tools the project actually uses.

Detection precedence:

  1. Explicit list passed by caller (e.g. ``--ai-tools=claude,cursor``)
  2. ``automation/.ai-tools`` written by ``sdlc setup``
  3. Filesystem fallback — presence of ``.<tool>/`` dirs at project root

Filesystem fallback exists so existing projects (set up before this
version) still benefit from tool-gated addons without re-running setup.
"""
from __future__ import annotations

import json
from pathlib import Path

# Set of supported tool slugs. Matches the directories that ``sdlc setup``
# scaffolds — keep in sync with ``scaffold/ai-tools/`` and the per-tool
# ``.<tool>/`` markers checked below.
SUPPORTED_TOOLS: tuple[str, ...] = (
    "aider",
    "claude-code",
    "cline",
    "codex",
    "continue",
    "cursor",
    "copilot",
    "windsurf",
)

# Filesystem markers used as the last-resort detection path. Keep slugs
# aligned with ``cli._TOOL_ARTIFACTS`` so persisted selections round-trip.
TOOL_MARKERS: dict[str, tuple[str, ...]] = {
    "aider":       (".aider.conf.yml",),
    "claude-code": (".claude",),
    "cline":       (".clinerules", ".cline"),
    "codex":       (".codex", "AGENTS.md"),
    "continue":    (".continuerules", ".continue"),
    "cursor":      (".cursor", ".cursorrules"),
    "copilot":     (".github/copilot-instructions.md",),
    "windsurf":    (".windsurfrules", ".windsurf"),
}

AI_TOOLS_FILE = Path("automation") / ".ai-tools"


def write_selected(project_root: Path, tools: list[str]) -> None:
    """Persist the user's tool selection. Called by ``sdlc setup`` after step 2."""
    valid = [t for t in tools if t in SUPPORTED_TOOLS]
    path = project_root / AI_TOOLS_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"version": 1, "tools": valid}, indent=2) + "\n",
        encoding="utf-8",
    )


def read_selected(project_root: Path) -> set[str] | None:
    """Return the persisted tool selection, or ``None`` if no file exists."""
    path = project_root / AI_TOOLS_FILE
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    tools = data.get("tools")
    if not isinstance(tools, list):
        return None
    return {t for t in tools if isinstance(t, str)}


def detect_from_filesystem(project_root: Path) -> set[str]:
    """Best-effort: which tool surfaces exist as files/dirs in the project."""
    found: set[str] = set()
    for tool, markers in TOOL_MARKERS.items():
        for m in markers:
            if (project_root / m).exists():
                found.add(tool)
                break
    return found


def resolve(project_root: Path, *, override: list[str] | None = None) -> set[str]:
    """Resolve effective AI tool set per the precedence above."""
    if override:
        return {t for t in override if t in SUPPORTED_TOOLS}
    persisted = read_selected(project_root)
    if persisted is not None:
        return persisted
    return detect_from_filesystem(project_root)


def recipe_matches_tools(
    requires_ai_tool: tuple[str, ...] | list[str],
    selected: set[str],
) -> bool:
    """Tool-agnostic recipes always match; otherwise require ≥1 overlap."""
    req = tuple(requires_ai_tool)
    if not req:
        return True
    return any(t in selected for t in req)
