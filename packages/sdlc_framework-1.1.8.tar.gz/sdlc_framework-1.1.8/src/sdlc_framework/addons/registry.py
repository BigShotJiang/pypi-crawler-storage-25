"""Build the per-(phase, subtrack) external assets map from a lockfile.

Pure module — input is the parsed :class:`Lockfile` and the recipe map
from :mod:`addons.loader`, output is a frozen dict keyed by slot tuples.

Consumers:
  * :mod:`engine` merges the map into ``state.json`` so dashboards and
    dispatchers can render assets without re-reading the lockfile.
  * :mod:`addons.brief` reads the map (via state) to render the
    advisory section in the agent brief.

Orphan handling: an addon present in the lockfile whose recipe is no
longer available (recipe deleted, source uninstalled, etc.) is skipped
silently — registry MUST NOT crash on orphan entries because lockfiles
outlive recipes.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .lockfile import Lockfile
from .schema import AppliesTo, Recipe


SlotKey = tuple[int | None, str]


@dataclass(frozen=True)
class AssetEntry:
    addon_id: str
    kind: str               # skill | command | agent | rule | other
    name: str
    description: str
    path: str
    requires_ai_tool: tuple[str, ...]   # propagated for downstream tool filter

    def as_dict(self) -> dict:
        return {
            "addon_id": self.addon_id,
            "kind": self.kind,
            "name": self.name,
            "description": self.description,
            "path": self.path,
            "requires_ai_tool": list(self.requires_ai_tool),
        }


def build_phase_registry(
    lock: Lockfile,
    recipes: dict[str, Recipe],
) -> dict[SlotKey, list[AssetEntry]]:
    """Return ``{(phase, subtrack): [AssetEntry, ...]}`` for installed addons.

    Snippets are intentionally excluded — they're inline edits in
    scaffold files the agent already reads as part of normal docs.
    Only fetched assets surface as registry entries.

    Within each slot, entries are sorted by ``(kind, name)`` so the
    output is deterministic across scans (clean diffs in state.json).
    """
    out: dict[SlotKey, list[AssetEntry]] = {}
    for addon_id, lock_entry in lock.addons.items():
        recipe = recipes.get(addon_id)
        if recipe is None:
            continue                             # orphan — see module docstring
        if lock_entry.fetched is None or not lock_entry.fetched.assets:
            continue
        for slot in recipe.applies_to:
            key = _slot_key(slot)
            bucket = out.setdefault(key, [])
            for asset in lock_entry.fetched.assets:
                if asset.kind == "other":
                    continue                     # excluded from brief surfacing
                bucket.append(AssetEntry(
                    addon_id=addon_id,
                    kind=asset.kind,
                    name=asset.name,
                    description=asset.description,
                    path=asset.path,
                    requires_ai_tool=tuple(recipe.requires_ai_tool),
                ))
    for key in out:
        out[key] = sorted(out[key], key=lambda e: (_kind_order(e.kind), e.name))
    return out


def assets_for_phase(
    registry: dict[SlotKey, list[AssetEntry]], phase: int | None,
) -> list[AssetEntry]:
    """Flatten all subtracks of a single phase. Used by dashboard/brief
    when the consumer cares about phase-level totals."""
    out: list[AssetEntry] = []
    for (p, _sub), entries in registry.items():
        if p == phase:
            out.extend(entries)
    return out


def assets_for_slot(
    registry: dict[SlotKey, list[AssetEntry]],
    phase: int | None,
    subtrack: str,
) -> list[AssetEntry]:
    return list(registry.get((phase, subtrack), []))


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

# Display order for kinds in the brief / dashboard. Skills first because
# they're usually the most actionable; rules last because they're
# background reference.
KIND_DISPLAY_ORDER: tuple[str, ...] = ("skill", "command", "agent", "rule")


def _kind_order(kind: str) -> int:
    if kind in KIND_DISPLAY_ORDER:
        return KIND_DISPLAY_ORDER.index(kind)
    return len(KIND_DISPLAY_ORDER)


def _slot_key(slot: AppliesTo) -> SlotKey:
    return (slot.phase, slot.subtrack)
