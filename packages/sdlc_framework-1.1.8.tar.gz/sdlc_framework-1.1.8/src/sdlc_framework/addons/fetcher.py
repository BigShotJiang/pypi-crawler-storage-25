"""Remote-fetch executor — shallow clone + sparse-checkout, pin-verified.

All git invocations are routed through ``_run_git`` so tests can monkeypatch
a single seam. The fetcher never writes into the project tree directly; it
populates a temp clone, then ``inject_files`` copies the whitelisted subset
into ``project_root / select.to``.

Pin verification: tags are resolved to SHA via ``git rev-parse``; the
result MUST match the resolved-from-clone HEAD. If they disagree, the
upstream tag was force-pushed → abort, do NOT touch the project tree.
"""
from __future__ import annotations

import fnmatch
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

import yaml

from .schema import RemoteFetch, SelectEntry


@dataclass(frozen=True)
class FetchResult:
    resolved_sha: str            # actual commit SHA installed
    to: str                      # destination dir relative to project root
    files: tuple[str, ...]       # exhaustive list of files written, relative to ``to``


class FetchError(RuntimeError):
    """Fetch operation failed (network, pin mismatch, missing path, etc.)."""


def fetch(project_root: Path, inject: RemoteFetch) -> FetchResult:
    """Execute a remote-fetch inject. Returns paths written.

    Side effects:
      * Creates files under ``project_root / select.to`` for each select entry.
      * Leaves no temp dirs behind (always cleans up).
      * Does NOT touch ``addons.lock`` — caller is responsible for recording.
    """
    with tempfile.TemporaryDirectory(prefix="sdlc-addon-") as td:
        clone_dir = Path(td) / "clone"
        resolved = _clone_at_pin(inject.from_url, inject.pin, clone_dir)
        files = _copy_select(clone_dir, project_root, inject.select)

    # Determine the canonical "to" for the lockfile entry: when a recipe has
    # a single select with one shared parent dir, prefer that; otherwise
    # use the parent of the first select.to.
    to_root = inject.select[0].to
    return FetchResult(
        resolved_sha=resolved,
        to=to_root,
        files=tuple(files),
    )




# ---------------------------------------------------------------------------
# Internals — clone + verify
# ---------------------------------------------------------------------------

def _clone_at_pin(from_url: str, pin: str, dest: Path) -> str:
    """Clone ``from_url`` at ``pin`` into ``dest``. Return the resolved SHA.

    Tag pins use ``--branch`` to fetch only that ref (already shallow).
    SHA pins use a partial clone (``--filter=blob:none --no-checkout``) so
    only commit + tree objects are fetched up front; the subsequent
    ``checkout <sha>`` lazy-fetches just the blobs reachable from that
    commit. For repos with binary assets, this typically beats the older
    full-history clone by 5-30× (was F-D5-002 in audit, addressed jointly
    with F-D5-001 — see ``_install_one`` rollback symmetry).

    After clone, ``HEAD`` is verified against the expected SHA. For tag
    pins, the expected SHA comes from ``git ls-remote`` on the upstream
    so that a force-pushed tag is caught.
    """
    is_sha = _is_sha(pin)
    dest.mkdir(parents=True, exist_ok=True)

    # Shallow clone the relevant ref
    if is_sha:
        # Partial clone: fetch metadata only, defer blob download until checkout.
        rc, _, err = _run_git([
            "clone", "--quiet", "--filter=blob:none", "--no-checkout",
            from_url, str(dest),
        ])
        if rc != 0:
            raise FetchError(f"git clone failed: {err.strip()}")
        rc, _, err = _run_git(
            ["-C", str(dest), "checkout", "--quiet", pin],
        )
        if rc != 0:
            raise FetchError(f"git checkout {pin}: {err.strip()}")
    else:
        rc, _, err = _run_git([
            "clone", "--quiet", "--depth=1",
            "--branch", pin, from_url, str(dest),
        ])
        if rc != 0:
            raise FetchError(f"git clone --branch={pin}: {err.strip()}")

    rc, head, err = _run_git(["-C", str(dest), "rev-parse", "HEAD"])
    if rc != 0:
        raise FetchError(f"git rev-parse HEAD: {err.strip()}")
    head_sha = head.strip()

    if is_sha:
        if head_sha.lower() != pin.lower():
            raise FetchError(
                f"pin mismatch: expected {pin}, got {head_sha} "
                "(upstream may have rewritten history)"
            )
    else:
        # Resolve tag → SHA via ls-remote and compare. This catches a
        # force-pushed tag where local clone fetched the new SHA.
        rc, lsr, err = _run_git([
            "ls-remote", "--tags", from_url, f"refs/tags/{pin}",
        ])
        if rc != 0:
            raise FetchError(f"git ls-remote: {err.strip()}")
        # ``ls-remote`` may print the dereferenced commit (refs/tags/X^{}) for
        # annotated tags. Prefer that line; fall back to the lightweight one.
        upstream_sha = _parse_lsremote(lsr.strip(), pin)
        if upstream_sha is None:
            raise FetchError(f"upstream has no tag {pin!r}")
        if head_sha != upstream_sha:
            raise FetchError(
                f"pin mismatch for tag {pin}: clone HEAD {head_sha} "
                f"!= upstream {upstream_sha} (force-pushed tag?)"
            )

    return head_sha


def _is_sha(pin: str) -> bool:
    """40-char lowercase hex == SHA pin."""
    return len(pin) == 40 and all(c in "0123456789abcdef" for c in pin)


def _parse_lsremote(out: str, tag: str) -> str | None:
    """Pick the dereferenced commit SHA from ``ls-remote --tags`` output.

    Format per line: ``<sha>\\trefs/tags/<tag>[^{}]``. Annotated tags emit
    two rows; we prefer the ``^{}`` row because it's the actual commit.
    """
    deref: str | None = None
    light: str | None = None
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) != 2:
            continue
        sha, ref = parts[0], parts[1]
        if ref == f"refs/tags/{tag}^{{}}":
            deref = sha
        elif ref == f"refs/tags/{tag}":
            light = sha
    return deref or light


# ---------------------------------------------------------------------------
# Internals — file selection
# ---------------------------------------------------------------------------

def _copy_select(
    clone: Path, project_root: Path, select: tuple[SelectEntry, ...],
) -> list[str]:
    """Copy whitelisted files from ``clone`` into project paths.

    Honors per-entry ``rename_pattern`` (template basename rewrite) and
    ``inject_frontmatter`` (replace YAML front-matter on the destination).
    Returns project-relative destination paths.
    """
    written: list[str] = []
    seen_dest: set[Path] = set()
    for entry in select:
        matched = _match(clone, entry.from_pat)
        if not matched:
            raise FetchError(
                f"select entry from={entry.from_pat!r} matched zero files in clone"
            )
        for src in matched:
            rel = src.relative_to(clone)
            stripped = _strip_glob_prefix(rel, entry.from_pat)
            if entry.rename_pattern:
                # Rename collapses the matched file to a single basename
                # under entry.to (no nested path preserved). Recipe author
                # is responsible for ensuring rename results are unique
                # across all matched files.
                new_basename = _apply_rename_pattern(entry.rename_pattern, src)
                dest = project_root / entry.to / new_basename
            else:
                dest = project_root / entry.to / stripped
            if dest in seen_dest:
                raise FetchError(
                    f"select would write the same destination twice: {dest}"
                )
            seen_dest.add(dest)
            dest.parent.mkdir(parents=True, exist_ok=True)
            if entry.inject_frontmatter is not None:
                _copy_with_frontmatter(src, dest, entry.inject_frontmatter)
            else:
                shutil.copy2(src, dest)
            written.append(dest.relative_to(project_root).as_posix())
    return sorted(written)


_FRONT_MATTER_RE = re.compile(r"\A---\s*\n.*?\n---\s*\n", re.DOTALL)


def _copy_with_frontmatter(src: Path, dest: Path, fm: dict) -> None:
    """Copy ``src`` to ``dest`` replacing any leading YAML front-matter
    with the rendered ``fm`` mapping. Falls back to a verbatim copy when
    the source isn't readable as text (binary)."""
    try:
        text = src.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        # Non-text source — recipe asked for frontmatter inject but file
        # isn't markdown. Fail loudly so the recipe author sees the bad
        # combination.
        raise FetchError(
            f"inject_frontmatter requested for binary file: {src}"
        )
    body = _FRONT_MATTER_RE.sub("", text, count=1)
    rendered = yaml.safe_dump(fm, sort_keys=False, default_flow_style=False)
    new_text = "---\n" + rendered + "---\n" + body
    dest.write_text(new_text, encoding="utf-8")


def _apply_rename_pattern(pattern: str, src: Path) -> str:
    """Substitute ``{stem}``, ``{name}``, ``{parent}`` from the matched source."""
    return (
        pattern
        .replace("{stem}", src.stem)
        .replace("{name}", src.name)
        .replace("{parent}", src.parent.name)
    )


def _match(root: Path, pattern: str) -> list[Path]:
    """Return absolute paths under ``root`` matching the POSIX glob pattern.

    Supports ``**`` for recursive match. Brace expansion (e.g. ``{a,b}``) is
    NOT supported in MVP; recipe authors split into multiple select entries.

    **Python version note:** ``Path.glob("dir/**")`` matched directories
    only on Python 3.12 and earlier; from 3.13 it matches files too. To
    keep recipe patterns identical across runtimes, we transparently
    append ``/*`` when the user wrote a trailing ``/**`` so the matcher
    finds files on every supported Python.
    """
    glob_pattern = pattern
    if glob_pattern.endswith("/**"):
        glob_pattern = glob_pattern + "/*"
    elif glob_pattern == "**":
        glob_pattern = "**/*"

    matches: list[Path] = []
    for p in root.glob(glob_pattern):
        if p.is_file():
            matches.append(p)
    # Skip files inside .git
    return [m for m in matches if ".git" not in m.parts]


def _strip_glob_prefix(rel: Path, pattern: str) -> Path:
    """For a directory glob like ``tokens/**``, drop ``tokens/`` from rel.

    For a literal-file glob like ``primitives/Button.tsx``, return only the
    file's basename so recipe authors don't have to repeat parents.
    """
    parts = list(rel.parts)
    pat = pattern.rstrip("/")
    if pat.endswith("/**"):
        prefix = pat[:-3].strip("/")
        head = prefix.split("/")
        if parts[: len(head)] == head:
            return Path(*parts[len(head):])
    if "**" not in pattern and "*" not in pattern and "?" not in pattern:
        # Literal path → flatten to basename
        return Path(rel.name)
    return rel


# ---------------------------------------------------------------------------
# git seam (mocked in tests)
# ---------------------------------------------------------------------------

def _run_git(args: list[str], *, timeout: float = 60.0) -> tuple[int, str, str]:
    """Single point of subprocess invocation. Tests monkeypatch this.

    Returns ``(returncode, stdout, stderr)``. Never raises on non-zero exit;
    callers translate to ``FetchError`` with context.
    """
    proc = subprocess.run(
        ["git", *args],
        capture_output=True, text=True, timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


# ---------------------------------------------------------------------------
# Removal helper — reverses fetch using lockfile data
# ---------------------------------------------------------------------------

def remove_fetched(
    project_root: Path,
    files: list[str],
    to: str,
) -> dict[str, list[str]]:
    """Delete files this addon installed. Returns ``{deleted, kept}``.

    Files modified by the user since install (would need a content hash to
    detect) are conservatively deleted in MVP — the fetched payload is
    treated as addon-owned. Future enhancement: track per-file SHA.

    The ``to`` directory is removed if it ends up empty.
    """
    deleted: list[str] = []
    kept: list[str] = []
    for rel in files:
        path = project_root / rel
        if not path.exists():
            kept.append(rel)
            continue
        try:
            path.unlink()
            deleted.append(rel)
        except OSError:
            kept.append(rel)
    # Clean up empty parent directories up to (but not including) project root
    to_dir = project_root / to
    _remove_empty_dirs(to_dir, stop_at=project_root)
    return {"deleted": deleted, "kept": kept}


def _remove_empty_dirs(start: Path, *, stop_at: Path) -> None:
    cur = start.resolve() if start.exists() else None
    if cur is None:
        return
    stop = stop_at.resolve()
    while cur != stop and cur.exists() and cur.is_dir():
        try:
            cur.rmdir()
        except OSError:
            return
        cur = cur.parent
