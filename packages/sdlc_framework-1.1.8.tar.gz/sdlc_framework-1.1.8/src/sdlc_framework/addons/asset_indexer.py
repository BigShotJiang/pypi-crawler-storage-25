"""Extract metadata (name, description, kind) from a fetched asset file.

Pure function — input is a project-relative path + the project root,
output is an :class:`AssetMetadata` dataclass. No side effects beyond
reading the file. Called once per fetched markdown file at install time
and stored in the lockfile so the engine can surface assets per-phase
without re-reading files on every scan.

Fallback chain (per spec §4.2):

    1. YAML front-matter ``name:`` + ``description:``
    2. First H1 line + first non-blank paragraph
    3. Filename stem + "(no description available)"

Description is normalized: collapsed whitespace, single line,
≤ ``DESCRIPTION_MAX`` chars.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

DESCRIPTION_MAX = 160
READ_BUDGET_BYTES = 4096
NO_DESCRIPTION = "(no description available)"

# Folder-style skill convention: index ONE representative file per dir
SKILL_INDEX_FILES = ("SKILL.md", "index.md", "README.md")


@dataclass(frozen=True)
class AssetMetadata:
    path: str               # project-relative path of the indexed file
    kind: str               # skill | command | agent | rule | other
    name: str
    description: str        # ≤ DESCRIPTION_MAX chars, single line


def index_asset(project_root: Path, path: str) -> AssetMetadata:
    """Index a single fetched file. Returns metadata derived per the
    fallback chain. Never raises — unreadable / non-text files fall back
    to filename + ``other`` kind."""
    abs_path = project_root / path
    kind = _detect_kind(path)
    name = Path(path).stem
    description = NO_DESCRIPTION

    if abs_path.suffix.lower() == ".md" and abs_path.exists():
        try:
            text = abs_path.read_text(encoding="utf-8", errors="replace")[:READ_BUDGET_BYTES]
        except OSError:
            text = ""
        fm_name, fm_desc = _parse_front_matter(text)
        if fm_name:
            name = fm_name
        if fm_desc:
            description = _normalize_description(fm_desc)
        elif text:
            h1, para = _parse_h1_and_paragraph(text)
            if h1 and not fm_name:
                # Slugify H1 → name only when no explicit front-matter name
                name = _slugify(h1) or name
            if para:
                description = _normalize_description(para)

    return AssetMetadata(path=path, kind=kind, name=name, description=description)


def index_fetched(project_root: Path, files: list[str]) -> list[AssetMetadata]:
    """Index the relevant subset of ``files`` for the lockfile.

    Folder-style skills: when several files belong to the same skill
    folder, only ONE representative file (per :data:`SKILL_INDEX_FILES`)
    is indexed. Other files are silently skipped — they're still tracked
    in ``fetched.files[]`` for removal but don't appear as assets.
    """
    by_skill_folder: dict[str, str] = {}   # skill folder → chosen index file
    plain_files: list[str] = []

    for f in files:
        kind = _detect_kind(f)
        if kind == "skill" and _is_under_skill_folder(f):
            folder = _skill_folder(f)
            current = by_skill_folder.get(folder)
            if current is None or _skill_index_priority(f) < _skill_index_priority(current):
                by_skill_folder[folder] = f
        else:
            plain_files.append(f)

    chosen = sorted(set(plain_files) | set(by_skill_folder.values()))
    return [index_asset(project_root, f) for f in chosen]


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

KIND_PATH_HINTS: tuple[tuple[str, str], ...] = (
    # Order matters — first hit wins. Most-specific BEFORE less-specific so
    # that ``.github/instructions/<addon>/rules/x.md`` resolves to ``rule``
    # (not ``skill`` via the parent ``/instructions/`` segment).
    ("/commands/", "command"),
    ("/prompts/", "command"),
    ("/agents/", "agent"),
    ("/rules/", "rule"),
    ("/skills/", "skill"),
    ("/instructions/", "skill"),
)


def _detect_kind(path: str) -> str:
    p = "/" + path.replace("\\", "/").lstrip("/")
    for hint, kind in KIND_PATH_HINTS:
        if hint in p:
            return kind
    return "other"


_FRONT_MATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
# Recipes use simple key: value lines. We DO NOT pull in PyYAML here to
# stay dependency-free at the indexer layer (PyYAML is loaded lazily in
# loader.py); this regex covers 99% of real-world skill front-matter.
_FRONT_KV_RE = re.compile(r"^([a-zA-Z_][\w-]*):\s*(.*)$", re.MULTILINE)


def _parse_front_matter(text: str) -> tuple[str | None, str | None]:
    m = _FRONT_MATTER_RE.match(text)
    if not m:
        return (None, None)
    body = m.group(1)
    name: str | None = None
    desc: str | None = None
    for kv in _FRONT_KV_RE.finditer(body):
        key, value = kv.group(1), kv.group(2).strip()
        if key == "name" and value:
            name = _strip_quotes(value)
        elif key == "description" and value:
            desc = _strip_quotes(value)
    return (name, desc)


def _strip_quotes(s: str) -> str:
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ("'", '"'):
        return s[1:-1]
    return s


_H1_RE = re.compile(r"^# +(.+?)\s*$", re.MULTILINE)


def _parse_h1_and_paragraph(text: str) -> tuple[str | None, str | None]:
    """Return ``(h1_title, first_paragraph_after_h1)``.

    First paragraph is the first non-blank, non-heading run of lines
    immediately after the H1 (skipping blank lines).
    """
    m = _H1_RE.search(text)
    if not m:
        return (None, None)
    h1 = m.group(1).strip()
    rest = text[m.end():]
    # Skip leading blank lines
    paragraph_lines: list[str] = []
    started = False
    for line in rest.splitlines():
        s = line.strip()
        if not started and not s:
            continue
        if not started and s.startswith("#"):
            return (h1, None)              # next heading, no body
        started = True
        if not s:
            break                          # paragraph end
        paragraph_lines.append(s)
    paragraph = " ".join(paragraph_lines) if paragraph_lines else None
    return (h1, paragraph)


def _normalize_description(s: str) -> str:
    s = " ".join(s.split())                # collapse whitespace + newlines
    if len(s) > DESCRIPTION_MAX:
        # Cut at the last word boundary <= DESCRIPTION_MAX-1, append ellipsis
        cut = s.rfind(" ", 0, DESCRIPTION_MAX - 1)
        if cut == -1:
            cut = DESCRIPTION_MAX - 1
        s = s[:cut].rstrip() + "…"
    return s


_SLUGIFY_RE = re.compile(r"[^a-z0-9-]+")


def _slugify(s: str) -> str:
    s = s.lower().strip()
    s = s.replace(" ", "-")
    s = _SLUGIFY_RE.sub("-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s


def _is_under_skill_folder(path: str) -> bool:
    p = path.replace("\\", "/")
    return "/skills/" in ("/" + p) and Path(p).suffix.lower() == ".md"


def _skill_folder(path: str) -> str:
    """Resolve the *skill* folder for a path inside any ``skills/`` tree.

    A skill is the directory immediately under ``skills/``. Files nested
    deeper (e.g. ``.claude/skills/tdd-workflow/examples/sample.md``) all
    belong to the same skill ``.claude/skills/tdd-workflow``, not their
    direct parent. Returning the direct parent would split one logical
    skill into multiple lockfile entries.
    """
    parts = path.replace("\\", "/").split("/")
    try:
        idx = parts.index("skills")
    except ValueError:
        return str(Path(path).parent)
    return "/".join(parts[: idx + 2]) if idx + 1 < len(parts) else str(Path(path).parent)


def _skill_index_priority(path: str) -> int:
    """Lower number = higher priority. Files not in SKILL_INDEX_FILES
    fall back to alphabetical (large priority offset)."""
    name = Path(path).name
    if name in SKILL_INDEX_FILES:
        return SKILL_INDEX_FILES.index(name)
    return 100 + ord(name[0]) if name else 999
