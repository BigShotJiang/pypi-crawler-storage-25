"""Render the "External assets available" advisory section for agent briefs.

Pure function — input is the engine's state dict + project root, output
is an extended brief context string. Called by the dispatcher (`sdlc next`,
`sdlc auto-step`, `sdlc auto-mad-step`) after the framework's own
``brief_context`` is built.

Three-tier hierarchy (per spec §6.3):

  Tier 1 — active subtrack: full entry (name + description + path + source)
  Tier 2 — same phase, other subtracks: name + path only
  Tier 3 — other phases: count summary only

Total budget for the appended section ≤ ``MAX_BYTES`` (default 1024).
Truncate Tier 1 first; Tier 2 / Tier 3 always render as count summaries
when there's no room for full entries.

Defer-to-framework hint is hard-coded — recipes cannot override this
because framework stage mandates (test-author writes tests, etc.) are
the contract of the SDLC state machine.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import tool_detect

MAX_BYTES = 1024
DEFER_HINT = (
    "Use them when their description matches the current task. "
    "Defer to framework agents (above) for SDLC flow decisions."
)


@dataclass(frozen=True)
class _AssetView:
    addon_id: str
    kind: str
    name: str
    description: str
    path: str
    requires_ai_tool: tuple[str, ...]


def append_external_section(
    brief_context: str,
    state: dict,
    project_root: Path,
    *,
    max_bytes: int = MAX_BYTES,
) -> str:
    """Append the external-assets advisory; return extended brief_context.

    When the project has no installed addons OR no assets match the
    selected tools, returns ``brief_context`` unchanged.
    """
    section = _render_section(state, project_root, max_bytes=max_bytes)
    if not section:
        return brief_context
    sep = "" if brief_context.endswith("\n\n") else (
        "\n" if brief_context.endswith("\n") else "\n\n"
    )
    return brief_context + sep + section


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _render_section(state: dict, project_root: Path, *, max_bytes: int) -> str:
    selected_tools = tool_detect.resolve(project_root)
    by_slot = _collect_assets_by_slot(state, selected_tools)
    if not by_slot:
        return ""

    active_phase, active_subtrack = _resolve_active_slot(state)
    active_assets = by_slot.get((active_phase, active_subtrack), [])

    same_phase_other_subtracks: dict[str, list[_AssetView]] = {}
    other_phases_count: dict[int, int] = {}
    for (phase, subtrack), assets in by_slot.items():
        if phase == active_phase and subtrack != active_subtrack:
            same_phase_other_subtracks[subtrack] = assets
        elif phase != active_phase and phase is not None:
            other_phases_count[phase] = other_phases_count.get(phase, 0) + len(assets)

    if not active_assets and not same_phase_other_subtracks and not other_phases_count:
        return ""

    header = _render_header(active_phase, active_subtrack)
    tier3 = _render_tier3(other_phases_count, same_phase_other_subtracks)
    # Reserve space for header + tier3 footer; rest goes to Tier 1, then Tier 2
    fixed_budget = len(header.encode("utf-8")) + len(tier3.encode("utf-8"))
    remaining = max(0, max_bytes - fixed_budget)
    tier1 = _render_tier1(active_assets, budget=int(remaining * 0.78))
    tier2_budget = remaining - len(tier1.encode("utf-8"))
    tier2 = _render_tier2(same_phase_other_subtracks, budget=tier2_budget)

    parts = [header, tier1, tier2, tier3]
    return "\n".join(p for p in parts if p)


def _collect_assets_by_slot(
    state: dict, selected_tools: set[str],
) -> dict[tuple[int | None, str], list[_AssetView]]:
    """Walk state.phases[].subtracks[*].external_assets[] → views by slot."""
    out: dict[tuple[int | None, str], list[_AssetView]] = {}
    for phase in state.get("phases", []):
        phase_id = phase.get("id")
        subtracks = phase.get("subtracks", {}) or {}
        for subtrack_name, subtrack_data in subtracks.items():
            assets = (subtrack_data or {}).get("external_assets", []) or []
            views: list[_AssetView] = []
            for a in assets:
                req = tuple(a.get("requires_ai_tool") or ())
                if not tool_detect.recipe_matches_tools(req, selected_tools):
                    continue
                views.append(_AssetView(
                    addon_id=a.get("addon_id", ""),
                    kind=a.get("kind", "other"),
                    name=a.get("name", ""),
                    description=a.get("description", ""),
                    path=a.get("path", ""),
                    requires_ai_tool=req,
                ))
            if views:
                out[(phase_id, subtrack_name)] = views
    return out


def _resolve_active_slot(state: dict) -> tuple[int | None, str]:
    """Best-effort: derive (phase, subtrack) the dispatcher is about to invoke for."""
    p3 = state.get("phase3", {}) or {}
    if "active_subtrack" in p3:
        return (3, str(p3["active_subtrack"]))
    # Fallback — first phase that's not yet complete
    for phase in state.get("phases", []):
        if not phase.get("complete", False):
            return (phase.get("id"), _first_subtrack(phase))
    return (None, "")


def _first_subtrack(phase: dict) -> str:
    subtracks = phase.get("subtracks", {}) or {}
    if isinstance(subtracks, dict) and subtracks:
        return next(iter(subtracks))
    return ""


def _render_header(phase: int | None, subtrack: str) -> str:
    label = (
        f"Phase {phase} · {subtrack}" if phase is not None and subtrack
        else "current phase"
    )
    return (
        f"## External assets available\n\n"
        f"These community-curated assets are installed for your current subtrack ({label}). "
        f"{DEFER_HINT}\n"
    )


def _render_tier1(assets: list[_AssetView], *, budget: int) -> str:
    if not assets or budget <= 0:
        return ""
    grouped = _group_by_kind(assets)
    lines: list[str] = []
    rendered_count = 0
    overflow = 0
    for kind in ("skill", "command", "agent", "rule"):
        bucket = grouped.get(kind, [])
        if not bucket:
            continue
        kind_header = f"\n**{_kind_display(kind)}**"
        bucket_lines: list[str] = [kind_header]
        for a in bucket:
            entry = f"- `{a.name}` — {a.description}\n  → `{a.path}` (from {a.addon_id})"
            tentative = "\n".join(lines + bucket_lines + [entry])
            if len(tentative.encode("utf-8")) > budget:
                overflow += len(bucket) - bucket.index(a)
                break
            bucket_lines.append(entry)
            rendered_count += 1
        # Only commit kind header when at least 1 entry survived budget check
        if len(bucket_lines) > 1:
            lines.extend(bucket_lines)
        if overflow:
            break
    if overflow:
        lines.append(f"\n_…and {overflow} more — see addons.lock_")
    return "\n".join(lines).lstrip("\n")


def _render_tier2(
    other_subtracks: dict[str, list[_AssetView]], *, budget: int,
) -> str:
    if not other_subtracks or budget <= 0:
        return ""
    items: list[str] = []
    for subtrack in sorted(other_subtracks):
        names = ", ".join(a.name for a in other_subtracks[subtrack][:5])
        suffix = "" if len(other_subtracks[subtrack]) <= 5 else f", +{len(other_subtracks[subtrack]) - 5} more"
        items.append(f"  - `{subtrack}`: {names}{suffix}")
    block = "\n_Same phase, other subtracks:_\n" + "\n".join(items)
    if len(block.encode("utf-8")) > budget:
        # Fall back to count-only when full names don't fit
        counts = ", ".join(
            f"`{s}` ({len(a)} assets)" for s, a in sorted(other_subtracks.items())
        )
        block = f"\n_Same phase, other subtracks: {counts}_"
    return block


def _render_tier3(
    other_phases_count: dict[int, int],
    same_phase_other: dict[str, list[_AssetView]] | None = None,
) -> str:
    if not other_phases_count:
        return ""
    parts = [f"Phase {p}: {n} asset{'s' if n != 1 else ''}"
             for p, n in sorted(other_phases_count.items())]
    return f"\n_Other phases: {'; '.join(parts)} — see addons.lock_"


def _group_by_kind(assets: list[_AssetView]) -> dict[str, list[_AssetView]]:
    out: dict[str, list[_AssetView]] = {}
    for a in assets:
        out.setdefault(a.kind, []).append(a)
    for kind in out:
        out[kind] = sorted(out[kind], key=lambda x: x.name)
    return out


_KIND_DISPLAY = {
    "skill": "Skills",
    "command": "Commands",
    "agent": "Agents",
    "rule": "Rules",
}


def _kind_display(kind: str) -> str:
    return _KIND_DISPLAY.get(kind, kind.title())
