"""``automation/addons.lock`` — read/write/diff.

Contract: committed to git as the team-shared "what add-ons are installed"
record. Every install/remove/upgrade rewrites this file atomically. Schema
mirrors the install operation 1:1 — no inferred state.
"""
from __future__ import annotations

import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml


LOCKFILE_PATH = Path("automation") / "addons.lock"
LOCKFILE_SCHEMA_VERSION = 1


@dataclass
class SnippetEntry:
    target: str
    section_id: str
    content_hash: str


@dataclass
class AssetRecord:
    """One indexed asset's metadata. Mirrors :class:`AssetMetadata` but
    lives in the lockfile module to keep that module dependency-light."""
    path: str
    kind: str
    name: str
    description: str


@dataclass
class FetchEntry:
    to: str
    files: list[str]
    # Indexed assets — populated at install time via asset_indexer. Optional
    # for backward compat: lockfiles written by 0.18.x have no assets field
    # and the engine treats missing/empty as "no assets to surface".
    assets: list[AssetRecord] = field(default_factory=list)


@dataclass
class AddonEntry:
    """One installed add-on. Multiple ``snippets`` and one optional ``fetched``."""
    version: str
    resolved_sha: str
    installed_at: str
    sdlc_version: str
    snippets: list[SnippetEntry] = field(default_factory=list)
    fetched: FetchEntry | None = None


@dataclass
class Lockfile:
    schema_version: int
    addons: dict[str, AddonEntry]


def empty() -> Lockfile:
    return Lockfile(schema_version=LOCKFILE_SCHEMA_VERSION, addons={})


def utc_now_iso() -> str:
    """ISO-8601 UTC string suitable for lockfile timestamps. Seconds resolution."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

def read(project_root: Path) -> Lockfile:
    """Read ``addons.lock`` from a project. Missing file → empty lockfile."""
    path = project_root / LOCKFILE_PATH
    if not path.exists():
        return empty()
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return _from_dict(raw)


def _from_dict(raw: dict[str, Any]) -> Lockfile:
    sv = raw.get("schema_version")
    if sv != LOCKFILE_SCHEMA_VERSION:
        raise ValueError(
            f"addons.lock schema_version {sv!r} unsupported "
            f"(this build expects {LOCKFILE_SCHEMA_VERSION})"
        )
    addons_raw = raw.get("addons") or {}
    if not isinstance(addons_raw, dict):
        raise ValueError("addons.lock: addons field must be a mapping")
    addons: dict[str, AddonEntry] = {}
    for aid, entry in addons_raw.items():
        if not isinstance(entry, dict):
            raise ValueError(f"addons.lock: addon {aid!r} entry must be a mapping")
        snippets = [
            SnippetEntry(
                target=s["target"],
                section_id=s["section_id"],
                content_hash=s["content_hash"],
            )
            for s in entry.get("snippets") or []
        ]
        fetched: FetchEntry | None = None
        f = entry.get("fetched")
        if f:
            assets_raw = f.get("assets") or []
            assets = [
                AssetRecord(
                    path=a["path"],
                    kind=a.get("kind", "other"),
                    name=a.get("name", ""),
                    description=a.get("description", ""),
                )
                for a in assets_raw if isinstance(a, dict)
            ]
            fetched = FetchEntry(
                to=f["to"],
                files=list(f.get("files") or []),
                assets=assets,
            )
        addons[aid] = AddonEntry(
            version=entry["version"],
            resolved_sha=entry["resolved_sha"],
            installed_at=entry["installed_at"],
            sdlc_version=entry["sdlc_version"],
            snippets=snippets,
            fetched=fetched,
        )
    return Lockfile(schema_version=sv, addons=addons)


# ---------------------------------------------------------------------------
# Write (atomic)
# ---------------------------------------------------------------------------

def write(project_root: Path, lock: Lockfile) -> None:
    """Atomically replace ``addons.lock`` with the serialized lock state.

    Atomicity: write to ``addons.lock.tmp`` then ``os.replace``. Either the
    old file or the new file is observable, never a partial write.
    """
    path = project_root / LOCKFILE_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".lock.tmp")
    tmp.write_text(_to_yaml(lock), encoding="utf-8")
    os.replace(tmp, path)


def _to_yaml(lock: Lockfile) -> str:
    payload: dict[str, Any] = {"schema_version": lock.schema_version, "addons": {}}
    for aid in sorted(lock.addons.keys()):
        e = lock.addons[aid]
        addon: dict[str, Any] = {
            "version": e.version,
            "resolved_sha": e.resolved_sha,
            "installed_at": e.installed_at,
            "sdlc_version": e.sdlc_version,
        }
        if e.snippets:
            addon["snippets"] = [asdict(s) for s in e.snippets]
        if e.fetched is not None:
            fetched_payload: dict[str, Any] = {
                "to": e.fetched.to,
                "files": list(e.fetched.files),
            }
            if e.fetched.assets:
                fetched_payload["assets"] = [
                    {
                        "path": a.path,
                        "kind": a.kind,
                        "name": a.name,
                        "description": a.description,
                    }
                    for a in e.fetched.assets
                ]
            addon["fetched"] = fetched_payload
        payload["addons"][aid] = addon
    return yaml.safe_dump(payload, sort_keys=False, default_flow_style=False)


# ---------------------------------------------------------------------------
# Mutators (return new Lockfile — Lockfile.addons is the only mutable seam)
# ---------------------------------------------------------------------------

def upsert_addon(lock: Lockfile, addon_id: str, entry: AddonEntry) -> Lockfile:
    new_addons = dict(lock.addons)
    new_addons[addon_id] = entry
    return Lockfile(schema_version=lock.schema_version, addons=new_addons)


def remove_addon(lock: Lockfile, addon_id: str) -> Lockfile:
    new_addons = {k: v for k, v in lock.addons.items() if k != addon_id}
    return Lockfile(schema_version=lock.schema_version, addons=new_addons)
