"""Compile epic context from narrative + state files into a markdown digest.

Pure-Python, deterministic, no LLM. The output digest is suitable for
prepending to developer-agent's brief so the agent receives epic-level
cross-story context before writing code.

Source slices:
- `01-Planning/epics/<slug>.md` — Goal / Requirements / Technical Decisions
  / UX / Cross-Story Dependencies sections
- `automation/stories/<sid>.yaml` for each story_id listed in epic.md —
  live status (auto-derived in PR 2)

Out of scope (deferred):
- ADR slicing by epic tag
- PRD FR/NFR slices by epic tag
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml


class EpicContextError(Exception):
    """Raised when the compiler cannot complete (missing epic, malformed frontmatter)."""


def _normalize(text: str) -> str:
    """Strip BOM and normalize CRLF→LF before parsing (matches epic_sync)."""
    if text.startswith("﻿"):
        text = text[1:]
    return text.replace("\r\n", "\n")


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    """Split YAML frontmatter from body. Mirrors epic_sync._parse_frontmatter."""
    if not text.startswith("---\n"):
        raise EpicContextError("missing or malformed frontmatter")
    end_match = re.search(r"\n---\n", text[4:])
    if end_match is None:
        raise EpicContextError("missing closing `---` in frontmatter")
    fm_text = text[4 : 4 + end_match.start()]
    body = text[4 + end_match.end() :]
    try:
        fm = yaml.safe_load(fm_text) or {}
    except yaml.YAMLError as e:
        raise EpicContextError(f"frontmatter yaml error: {e}") from e
    if not isinstance(fm, dict):
        raise EpicContextError("frontmatter must be a yaml mapping")
    return fm, body


_HEADING = re.compile(r"^## ([^\n]+)\s*$", re.MULTILINE)


def _extract_section(body: str, heading: str) -> str | None:
    """Return text under a `## <heading>` block (until next ## or EOF), or None."""
    pattern = re.compile(rf"^## {re.escape(heading)}\s*$", re.MULTILINE)
    m = pattern.search(body)
    if m is None:
        return None
    section = body[m.end():]
    next_h = _HEADING.search(section)
    if next_h:
        section = section[: next_h.start()]
    return section.strip("\n")


_BULLET = re.compile(r"^- ([\w./-]+)[ \t]*(?:[:#].*)?$", re.MULTILINE)


def _extract_story_ids(body: str) -> list[str]:
    section = _extract_section(body, "Stories")
    if section is None:
        return []
    return [m.group(1) for m in _BULLET.finditer(section)]


def _read_story_status(target: Path, story_slug: str) -> str:
    """Read persisted state from automation/stories/<slug>.yaml.

    v1.1.0: reads ``state`` (was ``status``); default ``"draft"`` (was
    ``"unknown"`` sentinel — removed). Missing/corrupt files default to
    the initial state in the v1.1.0 story machine.
    """
    p = target / "automation" / "stories" / f"{story_slug}.yaml"
    if not p.exists():
        return "draft"
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return "draft"
    return str(data.get("state", "draft"))


def compile_epic_context(target: Path, epic_slug: str) -> str:
    """Compile a markdown digest for `epic_slug`.

    Returns the digest as a string. Pure function — does not write to disk.
    Cache + filesystem write are handled by `compile_to_cache` (Task 2).
    """
    epic_md = target / "01-Planning" / "epics" / f"{epic_slug}.md"
    if not epic_md.exists():
        raise EpicContextError(f"epic markdown not found: {epic_md}")

    text = _normalize(epic_md.read_text(encoding="utf-8"))
    fm, body = _parse_frontmatter(text)

    title = fm.get("title", epic_slug)
    story_ids = _extract_story_ids(body)
    goal = _extract_section(body, "Goal") or ""
    reqs = _extract_section(body, "Requirements & Constraints")
    tech = _extract_section(body, "Technical Decisions")
    ux = _extract_section(body, "UX & Interaction Patterns")
    deps = _extract_section(body, "Cross-Story Dependencies")

    out_lines: list[str] = []
    out_lines.append(f"# Epic Context: {title}")
    out_lines.append("")
    out_lines.append(
        "> Auto-compiled from epic + sibling stories. "
        f"Regenerate with `sdlc epic compile {epic_slug}`."
    )
    out_lines.append("")

    if goal.strip():
        out_lines.append("## Goal")
        out_lines.append(goal.strip())
        out_lines.append("")

    out_lines.append("## Stories in this epic (live status)")
    if not story_ids:
        out_lines.append("(no stories listed)")
    for sid in story_ids:
        status = _read_story_status(target, sid)
        out_lines.append(f"- `{sid}` — status: **{status}**")
    out_lines.append("")

    if reqs:
        out_lines.append("## Requirements & Constraints")
        out_lines.append(reqs.strip())
        out_lines.append("")

    if tech:
        out_lines.append("## Technical Decisions")
        out_lines.append(tech.strip())
        out_lines.append("")

    if ux:
        out_lines.append("## UX & Interaction Patterns")
        out_lines.append(ux.strip())
        out_lines.append("")

    if deps:
        out_lines.append("## Cross-Story Dependencies")
        out_lines.append(deps.strip())
        out_lines.append("")

    return "\n".join(out_lines)


def cache_path_for(target: Path, epic_slug: str) -> Path:
    """Return the canonical cache path for an epic's compiled context."""
    return target / "automation" / ".epic-context" / f"{epic_slug}.md"


def _source_mtimes(target: Path, epic_slug: str) -> list[float]:
    """Return mtimes of every source file the compiler reads for `epic_slug`.

    Cache is fresh iff cache mtime >= max(source mtimes).
    """
    mtimes: list[float] = []
    epic_md = target / "01-Planning" / "epics" / f"{epic_slug}.md"
    if epic_md.exists():
        mtimes.append(epic_md.stat().st_mtime)

    try:
        text = _normalize(epic_md.read_text(encoding="utf-8"))
        _, body = _parse_frontmatter(text)
        for sid in _extract_story_ids(body):
            sp = target / "automation" / "stories" / f"{sid}.yaml"
            if sp.exists():
                mtimes.append(sp.stat().st_mtime)
    except (EpicContextError, OSError):
        return []
    return mtimes


def is_cache_fresh(target: Path, epic_slug: str) -> bool:
    """True when cache exists and its mtime >= all source mtimes."""
    cache = cache_path_for(target, epic_slug)
    if not cache.exists():
        return False
    cache_mtime = cache.stat().st_mtime
    source_mtimes = _source_mtimes(target, epic_slug)
    if not source_mtimes:
        return False
    return cache_mtime >= max(source_mtimes)


def compile_to_cache(target: Path, epic_slug: str) -> Path:
    """Compile the epic context and write it to the cache. Returns cache path.

    Always writes (force-recompile semantics). Callers can check
    `is_cache_fresh` first if they want to avoid redundant work.
    """
    digest = compile_epic_context(target, epic_slug)
    cache = cache_path_for(target, epic_slug)
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(digest, encoding="utf-8")
    return cache
