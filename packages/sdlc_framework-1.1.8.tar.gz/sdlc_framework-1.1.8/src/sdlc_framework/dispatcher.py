"""
SDLC Dispatcher.

Two entry points:

  - ``compute_dispatch`` (CLI-facing) — reads automation/state.json and
    prints which agent to invoke next, plus a ready-to-paste brief for
    that agent.
  - ``pick_next`` (library-only, Phase 6) — pure function that walks
    the v1.1.0 4-tier priority order (incident → active-story task →
    kanban → phase-1/2/4) and returns a target dict. Does not print or
    touch the filesystem; ``commands/dispatch.cmd_next`` wires it up
    when ``--story-only`` or ``--kanban-only`` is passed.

Usage:
    sdlc dispatch            # human-readable
    sdlc dispatch --json     # machine-readable
    sdlc dispatch --brief    # also writes brief file under agents/_briefs/
"""

from __future__ import annotations
import argparse
import datetime as dt
import json
import sys
from pathlib import Path

from sdlc_framework.schema_versions import (
    LEGACY_STATE_SCHEMA_VERSIONS,
    STATE_SCHEMA_VERSION,
)


def _root() -> Path:
    return Path.cwd()


def _state_path() -> Path:
    return _root() / "automation" / "state.json"


def _briefs_dir() -> Path:
    return _root() / "agents" / "_briefs"


# Canonical PHASE_AGENT lives in `engine.PHASE_AGENT_MAP` (5-phase, includes
# qa-engineer for Phase 4). Re-export here so existing callers don't have to
# import engine directly. F-D4-002 in audit consolidated these duplicates.
from .engine import PHASE_AGENT_MAP as PHASE_AGENT  # noqa: E402


# ---------------------------------------------------------------------
# v1.1.0 priority-aware picker (Phase 6).
#
# `compute_dispatch` (in engine.py) drives the phase-walking strategy
# used by `sdlc dispatch`. `pick_next` is the v1.1.0 entry point:
# instead of walking phases in numeric order, it answers "what should I
# work on right now?" against the four-tier model:
#
#   1. Open incident → its fix-ticket (severity desc — critical first).
#      A live incident is more urgent than any feature work.
#   2. Active story's next-stage task. Only one story is in flight at a
#      time (Phase 3 serial lock); pick its earliest unfinished task,
#      walking the TDD ladder.
#   3. Other kanban tickets — chores, bugs, hotfixes that aren't yet
#      tied to a live incident. Sorted by priority desc, alphabetical
#      by id within ties so the order is deterministic across scans.
#   4. Phase 1/2/4 pending DoD items. Phase 3 is excluded here — its
#      work is reachable via the active-story tier above. Pulling Phase
#      3 DoD items into this fallback would be a redundant hand-off.
#
# Returns None when every queue is empty — caller treats that as
# "all caught up" and prints a celebratory message.
# ---------------------------------------------------------------------

# Severity ordering for level 1 (incidents). Lower rank = higher
# urgency. critical < high < medium < low. Sentinel 99 is "unknown
# severity" so malformed yaml sorts last among open incidents rather
# than crashing the picker.
_SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

# Priority ordering for level 3 (plain kanban). Note: kanban tickets
# only have `priority`, never `severity` — the two scales are kept
# separate to prevent the cross-contamination bug that the Phase 5
# `_cmd_ticket_list` review surfaced (a kanban `priority: critical`
# would otherwise outrank real severity-critical incidents). Default
# `medium` matches `_PRIORITY_RANK` in commands/ticket_cmd.py.
_KANBAN_PRIORITY_ORDER = {"high": 0, "medium": 1, "low": 2}

# TDD ladder for level 2 (active story). Earlier stages dispatch first
# so the fresh-context subagents always pick up at the rung where work
# is actually blocked: pending tasks need test-author to enter the
# ladder; write-tests means tests are being written and we wait;
# write-code means tests exist and we want developer-agent to write
# code; review means both files exist and we want code-reviewer.
_TASK_STAGE_ORDER = ("pending", "write-tests", "write-code", "review")

# Stage → subagent mapping is the canonical one in
# ``tasks_loader.stage_to_subagent``: write-tests=test-author,
# write-code=developer-agent, review=code-reviewer (or
# security-reviewer for sensitive tasks: auth/crypto/payment/secrets/
# migrations). Don't re-declare a local table here — duplicating the
# mapping is exactly the regression-vector that Phase 5's review
# (audit F-D4-002) consolidated. ``pending`` returns None from that
# helper (queued behind the serial lock); ``pick_next`` walks past
# pending in the stage order and only "lands" on stages with an
# in-flight agent, so a None never escapes.


def pick_next(
    state: dict,
    *,
    skip: set[str] | None = None,
) -> dict | None:
    """Return the next dispatch target for v1.1.0, or None.

    The returned dict shape varies by ``kind`` so callers can route to
    the right CLI prompt:

      - ``{"kind": "ticket", "id", "agent", "reason"?}``
      - ``{"kind": "task",   "id", "agent", "stage"}``
      - ``{"kind": "phase_item", "id", "phase", "agent"}``

    Returns ``None`` when every priority level is empty.

    Tolerant of missing state keys — synthetic test fixtures and older
    snapshots that pre-date Phase 4/5 (no ``incidents`` / ``tickets``
    arrays) still walk through cleanly.

    ``skip`` (Phase 6 Task 6.2): an optional set of tier names to bypass.
    Recognised values:

      - ``"story"``  — skip level 2 (active-story task tier), used by
        ``sdlc next --kanban-only`` so a noisy kanban backlog can be
        drained without the active story stealing the slot.
      - ``"kanban"`` — skip level 3 (plain kanban tier), used by
        ``sdlc next --story-only`` so the active story stays in focus
        even when chore tickets are queued.

    Levels 1 (incidents) and 4 (Phase 1/2/4 phase items) are NEVER
    skipped: the flags are scoped filters on the optional tiers, not
    safety overrides. A live critical incident must always surface
    regardless of the user's filtering preference.
    """
    skip = skip or set()

    # Level 1: open incidents → their fix-tickets (severity desc).
    open_incidents = [
        i for i in state.get("incidents", []) if i.get("status") == "open"
    ]
    open_incidents.sort(
        key=lambda i: _SEVERITY_ORDER.get(i.get("severity"), 99)
    )
    tickets = state.get("tickets", [])
    for inc in open_incidents:
        ticket_id = inc.get("fix_ticket_id")
        if not ticket_id:
            continue
        # Skip if the ticket doesn't exist (dangling ref) or is no
        # longer actionable (already done/closed). The level-1 promise
        # is "open incident has live fix-ticket"; if the ticket isn't
        # live, fall through to lower levels.
        ticket = next(
            (t for t in tickets
             if t.get("id") == ticket_id
             and t.get("status") in ("todo", "in-progress")),
            None,
        )
        if ticket is None:
            continue
        return {
            "kind": "ticket",
            "id": ticket_id,
            "agent": "developer-agent",
            "reason": (
                f"hotfix for {inc['id']} "
                f"(severity: {inc.get('severity', 'unknown')})"
            ),
        }

    # Level 2: active story's next-stage task. Only one story is in
    # flight at a time (Phase 3 serial lock); walk its tasks in TDD
    # stage order and return the first one that matches.
    if "story" not in skip:
        from sdlc_framework.tasks_loader import stage_to_subagent
        asid = (state.get("phase3") or {}).get("active_story_id")
        if asid:
            story_tasks = [
                t for t in state.get("tasks", []) if t.get("story_id") == asid
            ]
            for stage in _TASK_STAGE_ORDER:
                t = next(
                    (t for t in story_tasks if t.get("stage") == stage), None
                )
                if t is None:
                    continue
                # Defensive: if the canonical helper returns None for
                # this stage (only ``pending`` and ``committed`` do —
                # plus legacy ``await-merge`` / ``done`` from pre-v1.1.0
                # snapshots), there's no agent to dispatch. Skip and
                # try the next stage rather than raising.
                agent = stage_to_subagent(t, stage)
                if agent is None:
                    continue
                return {
                    "kind": "task",
                    "id": t["id"],
                    "agent": agent,
                    "stage": stage,
                }

    # Level 3: other kanban tickets — non-incident-linked, still open.
    # Excluding incident-linked tickets here is important: if the
    # incident is open, level 1 already routed it; if the incident is
    # closed, the ticket should have been done too (see
    # `auto_restore_on_ticket_done` in incident_sync.py — Phase 5).
    # Either way, level 3 is for plain kanban only.
    if "kanban" not in skip:
        open_kanban = [
            t for t in tickets
            if t.get("status") in ("todo", "in-progress")
            and not t.get("incident_id")
        ]
        open_kanban.sort(
            key=lambda t: (
                _KANBAN_PRIORITY_ORDER.get(t.get("priority", "medium"), 9),
                str(t.get("id", "")),
            )
        )
        if open_kanban:
            return {
                "kind": "ticket",
                "id": open_kanban[0]["id"],
                "agent": "developer-agent",
            }

    # Level 4: Phase 1/2/4 pending DoD items. Phase 3 is excluded —
    # its work is reachable via level 2 (active story); pulling Phase
    # 3 here would route around the serial lock.
    for ph in state.get("phases", []):
        if ph.get("id") == 3:
            continue
        for item in ph.get("items", []):
            if not item.get("done"):
                return {
                    "kind": "phase_item",
                    "id": item["id"],
                    "phase": ph["id"],
                    "agent": item.get("agent")
                    or PHASE_AGENT.get(ph["id"], "orchestrator"),
                }

    return None


def load_state() -> dict:
    p = _state_path()
    if not p.exists():
        print("ERROR: automation/state.json not found. Run: sdlc scan", file=sys.stderr)
        sys.exit(1)
    data = json.loads(p.read_text(encoding="utf-8"))
    sv = data.get("schema_version")
    if sv in LEGACY_STATE_SCHEMA_VERSIONS:
        msg = (
            f"\n[sdlc] ERROR: state.json schema_version={sv} is legacy.\n"
            f"This is v1.0 canonical. State files require schema_version: {STATE_SCHEMA_VERSION}.\n"
            f"Project file: {p}\n"
            f"Fix: rm automation/state.json && sdlc scan\n"
            f"  (state.json is regenerated on every scan; deleting it is non-destructive.)\n"
        )
        print(msg, file=sys.stderr)
        sys.exit(2)
    return data


def _maybe_compile_epic_context(item: dict, phase: int) -> str:
    """Return compiled Epic Context for the active task, or empty string.

    Only fires for Phase 3 items that carry a non-null `epic_id`. Failures
    are swallowed — the brief still emits without the block, and the user
    can run `sdlc epic compile <slug>` manually to surface the underlying
    error.
    """
    if phase != 3:
        return ""
    epic_id = item.get("epic_id")
    if not epic_id:
        return ""
    try:
        from sdlc_framework.epic_context_compiler import compile_to_cache
        cache = compile_to_cache(Path.cwd(), epic_id)
        return cache.read_text(encoding="utf-8")
    except Exception:
        return ""


def build_brief(decision: dict, state: dict) -> str:
    if decision["action"] != "invoke":
        return ""
    ph = decision["phase"]
    item_id = decision["item_id"]
    item_label = decision["item_label"]

    # Find the full item dict in state for the failing-check messages
    item_full: dict = {}
    for p in state.get("phases", []):
        if p.get("id") == ph:
            for it in p.get("items", []):
                if it.get("id") == item_id:
                    item_full = it
                    break
            break

    fail_msgs = [c["msg"] for c in item_full.get("checks", []) if not c["ok"]]
    # Per-phase input hints. Phase 5 (deploy/monitor) added per F-D4-003 —
    # was previously a 4-phase map that referenced legacy `agents/phase-N`
    # paths and didn't include the Phase 5 SRE deploy track.
    inputs_by_phase = {
        1: ["01-Planning/templates/", "(any filled artifacts in 01-Planning/)"],
        2: ["01-Planning/01-PRD.md (if exists)", "01-Planning/03-Requirements-Spec.md", "02-Design/templates/"],
        3: ["02-Design/", "03-Development/standards/", "(neighbor files in src/)"],
        4: ["02-Design/01-Architecture.md", "04-Testing-Deploy/templates/"],
        5: ["04-Testing-Deploy/", "automation/signoffs/", "(observability dashboards if linked in project.yaml)"],
    }
    parallel = decision.get("parallel_agents") or []
    parallel_line = (
        f"\n## Parallel cross-agents (suggested)\n" + "\n".join(f"- `{a}`" for a in parallel) + "\n"
        if parallel else ""
    )
    base_brief = f"""# Agent Brief — {decision['agent']} / {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}

## Context
- Phase: {ph}
- Pending DoD item: `{item_id}` — {item_label}
- Why blocked: {'; '.join(fail_msgs) if fail_msgs else '(no failure msg)'}
- State snapshot: `automation/state.json` (overall {state['overall_pct']}%)

## Task
Satisfy DoD item `{item_id}` per rule in `automation/rules.json`. Specifically:
**{item_label}**.
{parallel_line}
## Inputs to read first
{chr(10).join(f"- `{p}`" for p in inputs_by_phase.get(ph, []))}
- `automation/rules.json` → block matching this item id
- `automation/agents/{PHASE_AGENT.get(ph, 'orchestrator')}.md` (your full spec)

## Hard constraints
- Don't leave `{{{{...}}}}` placeholders.
- Don't edit anything outside the deliverable for this item.
- Stop if you hit any AGENT-LOOP STOP trigger (ambiguity / conflict / gate / high-risk).

## Done criteria
- Deliverable file written (NOT into `templates/`).
- Run: `sdlc scan --print` → item flips `done: true`.
- Conventional Commit message ready.

## Hand-off
- Notify orchestrator with: files_changed, evidence (1-line per file), verified=yes/no, open_questions, next_agent.
"""

    epic_context = _maybe_compile_epic_context(item_full, ph)
    if epic_context:
        return epic_context + "\n---\n\n" + base_brief
    return base_brief


def fmt_human(decision: dict, state: dict) -> str:
    out = []
    out.append("=" * 60)
    out.append(f"SDLC Dispatch — {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}")
    out.append(f"Overall: {state['overall_pct']}%  ({state['total_done']}/{state['total_all']})")
    out.append("=" * 60)
    out.append(f"Action:  {decision['action'].upper()}")
    out.append(f"Reason:  {decision['reason']}")
    out.append(f"Agent:   {decision['agent']}")

    parallel = decision.get("parallel_agents") or []
    if parallel:
        out.append(f"Parallel: {', '.join(parallel)}")

    blocked = decision.get("blocked_by")
    if blocked:
        bits = []
        if blocked.get("phase") is not None: bits.append(f"phase {blocked['phase']}")
        if blocked.get("gate"): bits.append(f"gate {blocked['gate']}")
        if blocked.get("clarification"): bits.append(f"{blocked['clarification']} clarif")
        if blocked.get("high_risk_item"): bits.append(f"high-risk {blocked['high_risk_item']}")
        out.append(f"Blocked: {', '.join(bits)}")

    if decision["action"] == "invoke":
        item_id = decision.get("item_id")
        out.append("")
        out.append(f"Item:    {item_id} — {decision.get('item_label')}")
        # Find full item for check msgs
        for p in state.get("phases", []):
            if p.get("id") == decision.get("phase"):
                for it in p.get("items", []):
                    if it.get("id") == item_id:
                        out.append("Why fail:")
                        for c in it.get("checks", []):
                            mark = "✓" if c["ok"] else "✗"
                            out.append(f"  {mark} {c['msg']}")
                        break
        out.append("")
        out.append("Invocation hints:")
        out.append(f"  Claude Code:   /agents → pick {decision['agent']}, paste brief below")
        out.append(f"                 OR ask Claude: 'use the {decision['agent']} subagent to ...'")
        out.append(f"  Cursor:        @ paste content of agents/{decision['agent']}.md as system, then send brief")
        out.append(f"  Codex CLI:     codex --instructions agents/{decision['agent']}.md")
        out.append(f"  Aider:         /load agents/{decision['agent']}.md && /paste brief")
    elif decision["action"] == "stop_for_gate":
        g = decision.get("gate") or {}
        out.append("")
        out.append(f"Gate id:      {g.get('id')}")
        out.append(f"Approvers:    {', '.join(g.get('approvers_required', []))}")
        out.append(f"Instruction:  {g.get('instruction')}")
    elif decision["action"] == "ask_user":
        clarifs = state.get("clarifications") or []
        if clarifs:
            out.append("")
            out.append("Open clarifications:")
            for c in clarifs:
                out.append(f"  ? {c.get('title','?')}  ({c.get('file','?')})")
    elif decision["action"] == "done":
        out.append("\n🎉  All phases complete. Nothing to dispatch.")
    return "\n".join(out)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="sdlc dispatch")
    p.add_argument("--json", action="store_true")
    p.add_argument("--brief", action="store_true", help="also save brief to agents/_briefs/")
    args = p.parse_args(argv)

    state = load_state()
    decision = state.get("next_dispatch") or {
        "action": "done", "agent": None, "reason": "no next_dispatch",
        "parallel_agents": [], "blocked_by": None,
    }

    if args.json:
        print(json.dumps(decision, indent=2, ensure_ascii=False))
        return 0

    print(fmt_human(decision, state))

    if args.brief and decision["action"] == "invoke":
        briefs = _briefs_dir()
        briefs.mkdir(parents=True, exist_ok=True)
        ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
        brief_path = briefs / f"{ts}-{decision['agent']}-{decision['item_id']}.md"
        brief_path.write_text(build_brief(decision, state), encoding="utf-8")
        print(f"\nBrief saved: {brief_path.relative_to(_root())}")
    elif decision["action"] == "invoke":
        print("\n--- BRIEF (paste to specialist) ---\n")
        print(build_brief(decision, state))

    return 0
