# src/sdlc_framework/dora.py
"""Compute DORA + SDLC effectiveness metrics from story state_transitions and incidents.

DORA metrics (3 time windows: 7d / 30d / 90d):
  - DF   Deployment Frequency      — deployed transitions per day
  - LT   Lead Time for Changes     — median time from in-progress → deployed (minutes)
  - CFR  Change Failure Rate       — (incidents in window / deployments in window) * 100
  - MTTR Mean Time to Restore      — mean mttr_min of closed/restored incidents in window

SDLC effectiveness (same windows):
  - stories_per_week       — deployed stories per calendar week
  - cycle_time_median_min  — median in-progress → deployed (alias for LT, per-window)

DORA tier classification (2023 State of DevOps thresholds):
  Elite / High / Medium / Low for each metric; overall = worst of four.
"""
from __future__ import annotations

import datetime as _dt
from pathlib import Path
from statistics import median
from typing import Any

import yaml

# ---------------------------------------------------------------------------
# Time window helpers
# ---------------------------------------------------------------------------

_WINDOWS: dict[str, int] = {"7d": 7, "30d": 30, "90d": 90}


def _parse_iso(ts: str) -> _dt.datetime:
    """Parse ISO 8601 string (Z suffix or +HH:MM offset) to UTC-aware datetime.

    Handles three input forms:
      - "2026-05-04T10:00:00Z"       → strips Z, treats naive result as UTC
      - "2026-05-04T10:00:00"        → naive, treated as UTC
      - "2026-05-04T10:00:00+07:00"  → offset-aware, converted to UTC
    """
    s = ts.rstrip("Z")
    dt = _dt.datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_dt.timezone.utc)
    return dt.astimezone(_dt.timezone.utc)


def _in_window(ts: str, now: _dt.datetime, days: int) -> bool:
    try:
        dt = _parse_iso(ts)
    except (ValueError, AttributeError):
        return False
    return (now - dt).total_seconds() <= days * 86400


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------

def _load_stories(target: Path) -> list[dict]:
    sdir = target / "automation" / "stories"
    if not sdir.exists():
        return []
    out: list[dict] = []
    for f in sorted(sdir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        out.append(data)
    return out


def _load_incidents(target: Path) -> list[dict]:
    idir = target / "automation" / "incidents"
    if not idir.exists():
        return []
    out: list[dict] = []
    for f in sorted(idir.glob("*.yaml")):
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        if data.get("id") and data.get("opened_at"):
            out.append(data)
    return out


# ---------------------------------------------------------------------------
# Metric helpers
# ---------------------------------------------------------------------------

def _deployment_timestamps(stories: list[dict]) -> list[str]:
    """Return ISO timestamps for every 'deployed' state transition across all stories."""
    ts_list: list[str] = []
    for story in stories:
        for t in story.get("state_transitions", []):
            if t.get("to") == "deployed" and t.get("at"):
                ts_list.append(t["at"])
    return ts_list


def _lead_times_min(stories: list[dict], now: _dt.datetime, days: int) -> list[int]:
    """Compute lead-time (in-progress → deployed) in minutes for stories
    whose 'deployed' transition falls within the given window."""
    lts: list[int] = []
    for story in stories:
        transitions = story.get("state_transitions", [])
        deployed_at: str | None = None
        in_progress_at: str | None = None
        for t in transitions:
            state = t.get("to")
            if state == "deployed":
                deployed_at = t.get("at")
            if state == "in-progress" and in_progress_at is None:
                in_progress_at = t.get("at")
        if not deployed_at or not in_progress_at:
            continue
        if not _in_window(deployed_at, now, days):
            continue
        try:
            d = _parse_iso(deployed_at)
            ip = _parse_iso(in_progress_at)
            minutes = int((d - ip).total_seconds() / 60)
            if minutes >= 0:
                lts.append(minutes)
        except (ValueError, AttributeError):
            continue
    return lts


def _incident_mttr_values(incidents: list[dict], now: _dt.datetime, days: int) -> list[int]:
    """Return mttr_min values for incidents opened within the window that have mttr set."""
    values: list[int] = []
    for inc in incidents:
        opened_at = inc.get("opened_at", "")
        if not _in_window(opened_at, now, days):
            continue
        mttr = inc.get("mttr_min")
        if isinstance(mttr, int) and mttr >= 0:
            values.append(mttr)
    return values


# ---------------------------------------------------------------------------
# DORA tier classification
# ---------------------------------------------------------------------------

# Thresholds based on 2023 DORA State of DevOps Report
def _df_tier(df_per_day: float) -> str:
    if df_per_day > 1.0:
        return "elite"   # on-demand / multiple per day
    if df_per_day >= 1 / 7:
        return "high"    # between once per week and once per day
    if df_per_day >= 1 / 30:
        return "medium"  # between once per month and once per week
    return "low"         # less than once per month


def _lt_tier(lt_min: int | None) -> str:
    if lt_min is None:
        return "low"
    if lt_min <= 60:
        return "elite"   # < 1 hour
    if lt_min <= 7 * 24 * 60:
        return "high"    # < 1 week
    if lt_min <= 30 * 24 * 60:
        return "medium"  # < 1 month
    return "low"


def _cfr_tier(cfr_pct: float) -> str:
    if cfr_pct <= 5.0:
        return "elite"
    if cfr_pct <= 10.0:
        return "high"
    if cfr_pct <= 15.0:
        return "medium"
    return "low"


def _mttr_tier(mttr_min: int | None) -> str:
    if mttr_min is None:
        return "high"    # no incidents → assume healthy
    if mttr_min <= 60:
        return "elite"   # < 1 hour
    if mttr_min <= 24 * 60:
        return "high"    # < 1 day
    if mttr_min <= 7 * 24 * 60:
        return "medium"  # < 1 week
    return "low"


_TIER_RANK = {"elite": 0, "high": 1, "medium": 2, "low": 3}


def _overall_tier(tiers: dict[str, str]) -> str:
    worst_rank = max(_TIER_RANK[v] for v in tiers.values())
    for tier, rank in _TIER_RANK.items():
        if rank == worst_rank:
            return tier
    return "low"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compute(target: Path, *, now_iso: str | None = None) -> dict[str, Any]:
    """Compute DORA + SDLC effectiveness metrics.

    Args:
        target: Project root directory.
        now_iso: ISO 8601 UTC timestamp to use as "now" (defaults to actual now).
                 Useful for deterministic tests.

    Returns:
        Dict with keys: df, lt, cfr, mttr, sdlc, tier.
        Each DORA key contains sub-keys for each time window.
    """
    if now_iso:
        now = _parse_iso(now_iso)
    else:
        now = _dt.datetime.now(_dt.timezone.utc)

    stories = _load_stories(target)
    incidents = _load_incidents(target)
    deploy_ts = _deployment_timestamps(stories)

    # --- Deployment Frequency ---
    df: dict[str, float] = {}
    for key, days in _WINDOWS.items():
        count = sum(1 for ts in deploy_ts if _in_window(ts, now, days))
        df[key] = round(count / days, 6)

    # --- Lead Time ---
    # Pre-compute once per window; reused by both LT and SDLC cycle_time_median_min
    lt_by_window: dict[str, list[int]] = {
        key: _lead_times_min(stories, now, days) for key, days in _WINDOWS.items()
    }
    lt: dict[str, int | None] = {}
    for key, lts in lt_by_window.items():
        lt[f"{key}_min"] = int(median(lts)) if lts else None

    # --- Change Failure Rate ---
    cfr: dict[str, float] = {}
    for key, days in _WINDOWS.items():
        deployments = sum(1 for ts in deploy_ts if _in_window(ts, now, days))
        inc_count = sum(
            1 for inc in incidents
            if _in_window(inc.get("opened_at", ""), now, days)
        )
        cfr[key] = round(inc_count / deployments * 100, 2) if deployments else 0.0

    # --- MTTR ---
    mttr: dict[str, int | None] = {}
    for key, days in _WINDOWS.items():
        values = _incident_mttr_values(incidents, now, days)
        mttr[f"{key}_min"] = int(sum(values) / len(values)) if values else None

    # --- SDLC Effectiveness ---
    sdlc: dict[str, dict[str, Any]] = {
        "stories_per_week": {},
        "cycle_time_median_min": {},
    }
    for key, days in _WINDOWS.items():
        weeks = days / 7
        count = sum(1 for ts in deploy_ts if _in_window(ts, now, days))
        sdlc["stories_per_week"][key] = round(count / weeks, 4)

        # Reuse cached lead times — no second pass through stories
        lts = lt_by_window[key]
        sdlc["cycle_time_median_min"][key] = int(median(lts)) if lts else None

    # --- Tier ---
    # Use 30d window as the representative window for tier classification
    df_tier = _df_tier(df["30d"])
    lt_tier = _lt_tier(lt["30d_min"])
    cfr_tier = _cfr_tier(cfr["30d"])
    mttr_tier = _mttr_tier(mttr["30d_min"])
    tier_map = {"df": df_tier, "lt": lt_tier, "cfr": cfr_tier, "mttr": mttr_tier}
    tier_map["overall"] = _overall_tier(tier_map)

    return {
        "df": df,
        "lt": lt,
        "cfr": cfr,
        "mttr": mttr,
        "sdlc": sdlc,
        "tier": tier_map,
    }
