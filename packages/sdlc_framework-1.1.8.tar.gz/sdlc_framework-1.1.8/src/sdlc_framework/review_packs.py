"""Review pack registry — maps artifact types to reviewer agent lists.

Default packs ship with the framework. Projects can override per-pack
in their `project.yaml` under the `review_packs:` section. Tier-based
size cap reduces the pack size for tier 2 / tier 3 projects (lower-criticality)
to control reviewer cost.
"""
from __future__ import annotations

from pathlib import Path

import yaml


class PackError(Exception):
    """Raised on malformed pack registry."""


DEFAULT_REVIEW_PACKS: dict[str, dict[str, list[str]]] = {
    "phase1": {
        "prd": ["pm-agent", "business-reviewer", "security-reviewer"],
        "user-stories": ["sm-agent", "architect-agent", "qa-engineer"],
        "requirements": ["pm-agent", "architect-agent"],
        "risks": ["security-reviewer", "sre-agent"],
        "stakeholder-map": ["pm-agent"],
    },
    "phase2": {
        "architecture": ["architect-agent", "security-reviewer", "sre-agent"],
        "api-spec": ["architect-agent", "security-reviewer"],
        "db-schema": ["architect-agent", "security-reviewer"],
        "ui-ux-spec": ["ux-designer", "accessibility-reviewer"],
        "adr": ["architect-agent"],
        "threat-model": ["security-reviewer", "architect-agent"],
    },
    "phase3": {
        "code-review": ["code-reviewer", "security-reviewer", "edge-case-reviewer"],
    },
}


_TIER_CAPS: dict[int, int | None] = {
    1: None,  # Tier 1 critical — use full pack
    2: 2,     # Tier 2 default — cap at 2
    3: 1,     # Tier 3 experiment — cap at 1
}


def apply_tier_cap(pack: list[str], tier: int) -> list[str]:
    """Return at most `_TIER_CAPS[tier]` reviewers from the pack.

    Drops from the right (later reviewers in the list are dropped first).
    Unknown tiers return the full pack defensively.
    """
    cap = _TIER_CAPS.get(tier)
    if cap is None:
        return list(pack)
    return list(pack[:cap])


def _read_project_overrides(target: Path) -> dict[str, dict[str, list[str]]]:
    """Read `review_packs:` section from project.yaml, return empty dict if absent."""
    p = target / "project.yaml"
    if not p.exists():
        return {}
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return {}
    overrides = data.get("review_packs", {})
    if not isinstance(overrides, dict):
        return {}
    return overrides


def get_review_pack(target: Path, phase: int, artifact: str) -> list[str]:
    """Return the reviewer pack for `phase` + `artifact`.

    Resolution order:
    1. project.yaml override (`review_packs.phase{phase}.{artifact}`)
    2. DEFAULT_REVIEW_PACKS
    3. Empty list (unknown artifact)
    """
    phase_key = f"phase{phase}"
    overrides = _read_project_overrides(target)
    if phase_key in overrides and artifact in overrides[phase_key]:
        return list(overrides[phase_key][artifact])
    if phase_key in DEFAULT_REVIEW_PACKS and artifact in DEFAULT_REVIEW_PACKS[phase_key]:
        return list(DEFAULT_REVIEW_PACKS[phase_key][artifact])
    return []
