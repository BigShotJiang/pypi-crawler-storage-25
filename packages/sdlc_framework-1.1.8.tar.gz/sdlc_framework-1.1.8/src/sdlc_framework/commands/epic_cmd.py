"""sdlc epic <subcommand> dispatcher."""
from __future__ import annotations

import sys
from pathlib import Path

from sdlc_framework.epic_sync import EpicSyncError, sync_epic


def cmd_epic(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc epic <new|sync|list|bootstrap|compile> ...", file=sys.stderr)
        return 2
    sub = argv[0]
    rest = argv[1:]
    if sub == "new":
        return _cmd_epic_new(rest)
    if sub == "sync":
        return _cmd_epic_sync(rest)
    if sub == "list":
        return _cmd_epic_list(rest)
    if sub == "bootstrap":
        return _cmd_epic_bootstrap(rest)
    if sub == "compile":
        return _cmd_epic_compile(rest)
    print(f"sdlc epic: unknown subcommand {sub!r}", file=sys.stderr)
    print("usage: sdlc epic <new|sync|list|bootstrap|compile> ...", file=sys.stderr)
    return 2


def _cmd_epic_new(argv: list[str]) -> int:
    """Scaffold 01-Planning/epics/<slug>.md from template."""
    import argparse
    import datetime as _dt
    import sys

    from sdlc_framework.review_skip import apply_review_skip_policy
    from sdlc_framework.commands.story_cmd import (
        _git_user_name, _set_frontmatter_field,
    )

    parser = argparse.ArgumentParser(prog="sdlc epic new")
    parser.add_argument("slug")
    parser.add_argument("--title", default=None)
    parser.add_argument("--no-review", dest="no_review", action="store_true")
    parser.add_argument("--force-skip-review", dest="force_skip", action="store_true")
    parser.add_argument("--reason", default=None)
    args = parser.parse_args(argv)

    target = Path.cwd()
    template = target / "01-Planning" / "templates" / "07-Epic.md"
    if not template.is_file():
        print(
            f"[sdlc epic new] template not found: {template}\n"
            f"hint: run `sdlc init` to scaffold templates.",
            file=sys.stderr,
        )
        return 1
    out_path = target / "01-Planning" / "epics" / f"{args.slug}.md"
    if out_path.exists():
        print(f"[sdlc epic new] already exists: {out_path}", file=sys.stderr)
        return 1

    decision = apply_review_skip_policy(
        target=target,
        artifact_id=args.slug,
        artifact_type="epic",
        title=args.title or args.slug,
        body="",
        globs=[],
        no_review=args.no_review,
        force_skip=args.force_skip,
        reason=args.reason,
    )
    if decision.refused:
        print(decision.refusal_message, file=sys.stderr)
        return 1

    body = template.read_text(encoding="utf-8")
    body = body.replace("{{epic-slug}}", args.slug)
    body = body.replace("{{YYYY-MM-DD}}", _dt.date.today().isoformat())
    if args.title is not None:
        body = body.replace("{{Epic Title}}", args.title)

    if not decision.review:
        body = _set_frontmatter_field(body, "review", "false")
        body = _set_frontmatter_field(body, "review_skipped_by", _git_user_name())
        body = _set_frontmatter_field(body, "review_skip_reason", decision.skip_reason or "unset")
        body = _set_frontmatter_field(body, "review_skip_at", decision.skip_at or "")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(body, encoding="utf-8")
    print(f"[sdlc epic new] wrote {out_path.relative_to(target)}")
    if decision.forced and decision.audit_path:
        print(f"[sdlc epic new] forced skip audit: {decision.audit_path.relative_to(target)}")
    if args.title is None:
        print("hint: edit the file to fill in {{Epic Title}}, {{One-sentence goal}}, and the Stories list.")
    print(f"next: `sdlc epic sync {args.slug}` after you've filled in the Stories list.")
    return 0


def _cmd_epic_sync(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc epic sync <slug>", file=sys.stderr)
        return 2
    slug = argv[0]
    try:
        path = sync_epic(Path.cwd(), slug)
    except EpicSyncError as e:
        print(f"[sdlc epic sync] {e}", file=sys.stderr)
        return 1
    print(f"[sdlc epic sync] wrote {path.relative_to(Path.cwd())}")
    return 0


def _cmd_epic_list(argv: list[str]) -> int:  # noqa: ARG001
    from sdlc_framework.epics_loader import derive_epic_status, load_epics
    target = Path.cwd()
    epics = load_epics(target)
    if not epics:
        print("(no epics)")
        return 0
    rows = []
    for e in sorted(epics, key=lambda x: x["slug"]):
        status = derive_epic_status(target, e["slug"])
        title = e.get("title", e["slug"])
        rows.append((e["slug"], status, title))
    slug_w = max(len(r[0]) for r in rows)
    status_w = max(len(r[1]) for r in rows)
    print(f"{'SLUG':<{slug_w}}  {'STATUS':<{status_w}}  TITLE")
    print(f"{'-' * slug_w}  {'-' * status_w}  {'-' * 30}")
    for slug, status, title in rows:
        print(f"{slug:<{slug_w}}  {status:<{status_w}}  {title}")
    return 0


def _cmd_epic_bootstrap(argv: list[str]) -> int:
    """Read epic.md, emit a brief listing child stories that need to be drafted.

    Does NOT spawn sm-agent. The output is a structured prompt that an
    autopilot loop or a human passing it to Claude/Cursor/Copilot will
    hand to sm-agent for actual drafting.
    """
    if not argv:
        print("usage: sdlc epic bootstrap <slug>", file=sys.stderr)
        return 2
    slug = argv[0]
    target = Path.cwd()
    md = target / "01-Planning" / "epics" / f"{slug}.md"
    if not md.is_file():
        print(f"[sdlc epic bootstrap] epic not found: {md}", file=sys.stderr)
        return 1
    text = md.read_text(encoding="utf-8")
    # Reuse epic_sync's parser (already handles CRLF/BOM):
    from sdlc_framework.epic_sync import _normalize, _extract_story_ids
    body = _normalize(text)
    story_ids = _extract_story_ids(body)
    if not story_ids:
        print(
            f"[sdlc epic bootstrap] epic {slug!r} has no Stories list to bootstrap.\n"
            f"hint: edit {md.relative_to(target)} and add bullets under '## Stories'.",
            file=sys.stderr,
        )
        return 1
    stories_dir = target / "01-Planning" / "stories"
    to_draft: list[str] = []
    skipped: list[str] = []
    for sid in story_ids:
        if (stories_dir / f"{sid}.md").exists():
            skipped.append(sid)
        else:
            to_draft.append(sid)
    print("# sm-agent brief — sdlc epic bootstrap")
    print()
    print(f"Parent epic: `{slug}` ({md.relative_to(target)})")
    print()
    print("## Stories to draft")
    if to_draft:
        for sid in to_draft:
            print(f"- {sid}")
    else:
        print("(none — all child stories already exist)")
    print()
    if skipped:
        print("## Skipped (already exist — sm-agent will NOT overwrite)")
        for sid in skipped:
            print(f"- {sid} ({stories_dir.relative_to(target) / (sid + '.md')})")
        print()
    print("## Action")
    print(
        f"For each slug in 'Stories to draft', invoke sm-agent with the parent "
        f"epic context from {md.relative_to(target)} and have it write "
        f"`01-Planning/stories/<slug>.md`. Then run `sdlc story sync <slug>` "
        f"per file to populate yaml state."
    )
    return 0


def _cmd_epic_compile(argv: list[str]) -> int:
    """Force-recompile epic context cache."""
    from sdlc_framework.epic_context_compiler import (
        EpicContextError,
        compile_to_cache,
    )
    if not argv:
        print("usage: sdlc epic compile <slug>", file=sys.stderr)
        return 2
    slug = argv[0]
    target = Path.cwd()
    try:
        path = compile_to_cache(target, slug)
    except EpicContextError as e:
        print(f"[sdlc epic compile] {e}", file=sys.stderr)
        return 1
    print(f"[sdlc epic compile] wrote {path.relative_to(target)}")
    return 0
