"""sdlc review <subcommand> dispatcher."""
from __future__ import annotations

import re
import sys
from pathlib import Path


def cmd_review(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc review <run|consolidate|status> ...", file=sys.stderr)
        return 2
    sub = argv[0]
    rest = argv[1:]
    if sub == "run":
        return _cmd_review_run(rest)
    if sub == "consolidate":
        return _cmd_review_consolidate(rest)
    if sub == "status":
        return _cmd_review_status(rest)
    print(f"sdlc review: unknown subcommand {sub!r}", file=sys.stderr)
    print("usage: sdlc review <run|consolidate|status> ...", file=sys.stderr)
    return 2


def _read_project_tier(target: Path) -> int:
    """Read tier from project.yaml; default to 2 (matches scaffold default).

    Tier 1 = critical (full pack), 2 = standard (cap=2), 3 = experiment (cap=1).
    """
    import yaml
    p = target / "project.yaml"
    if not p.exists():
        return 2
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return 2
    return int(data.get("tier", 2))


def _cmd_review_run(argv: list[str]) -> int:
    """Emit a brief per reviewer in the pack — caller dispatches them."""
    if not argv:
        print(
            "usage: sdlc review run <artifact-id> --phase=<n> --artifact-type=<type>",
            file=sys.stderr,
        )
        return 2
    artifact_id = argv[0]
    phase = None
    artifact_type = None
    for a in argv[1:]:
        if a.startswith("--phase="):
            phase = int(a.split("=", 1)[1])
        elif a.startswith("--artifact-type="):
            artifact_type = a.split("=", 1)[1]
    if phase is None or artifact_type is None:
        print("usage: sdlc review run <artifact-id> --phase=<n> --artifact-type=<type>", file=sys.stderr)
        return 2

    from sdlc_framework.review_packs import apply_tier_cap, get_review_pack

    target = Path.cwd()
    pack = get_review_pack(target, phase=phase, artifact=artifact_type)
    if not pack:
        print(
            f"[sdlc review run] no review pack for phase {phase} / {artifact_type!r}",
            file=sys.stderr,
        )
        return 1
    tier = _read_project_tier(target)
    pack = apply_tier_cap(pack, tier=tier)

    print(f"# Review pack — {artifact_id}")
    print()
    print(f"Phase {phase} / artifact-type: `{artifact_type}` / tier {tier}")
    print(f"Reviewers ({len(pack)}):")
    for r in pack:
        print(f"- {r}")
    print()
    print("## Action")
    print()
    print("For each reviewer above, invoke them with the brief shown below ")
    print(f"and have them write `automation/reviews/{artifact_id}-<reviewer>-<ts>.md`.")
    print()
    print(f"After all reviewers complete, run: `sdlc review consolidate {artifact_id}`")
    print()
    print("## Per-reviewer briefs")
    print()
    for r in pack:
        print(f"### {r}")
        print()
        print(f"Read artifact `{artifact_id}` (path depends on phase + type). ")
        print(f"Apply the {r} persona's checklist and write findings to ")
        print(f"`automation/reviews/{artifact_id}-{r}-<unix-ts>.md` with frontmatter:")
        print("```yaml")
        print(f"reviewer: {r}")
        print(f"artifact: {artifact_id}")
        print("verdict: PASS | PASS_WITH_NOTES | BLOCK")
        print("critical: <int>")
        print("high: <int>")
        print("medium: <int>")
        print("low: <int>")
        print("```")
        print()
    return 0


def _cmd_review_consolidate(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc review consolidate <artifact-id>", file=sys.stderr)
        return 2
    artifact_id = argv[0]
    target = Path.cwd()
    from sdlc_framework.review_consolidator import (
        consolidate, ConsolidatorError, VERDICT_BLOCK,
    )
    try:
        result = consolidate(target, artifact_id)
    except ConsolidatorError as e:
        print(f"[sdlc review consolidate] {e}", file=sys.stderr)
        return 1
    print(f"[sdlc review consolidate] verdict: {result['verdict']}")
    print(f"  reviewers: {len(result['reviewers'])} ({', '.join(result['reviewers'])})")
    print(f"  totals: critical={result['totals']['critical']} "
          f"high={result['totals']['high']} medium={result['totals']['medium']} "
          f"low={result['totals']['low']}")
    print(f"  summary: {result['summary_path'].relative_to(target)}")
    if result["verdict"] == VERDICT_BLOCK:
        return 1
    return 0


def _cmd_review_status(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc review status <artifact-id>", file=sys.stderr)
        return 2
    artifact_id = argv[0]
    target = Path.cwd()
    rdir = target / "automation" / "reviews"
    if not rdir.exists():
        print(f"[sdlc review status] no review summary yet for {artifact_id!r}")
        return 0
    summaries = sorted(rdir.glob(f"{artifact_id}-summary-*.md"))
    if not summaries:
        print(f"[sdlc review status] no review summary yet for {artifact_id!r}")
        return 0
    latest = summaries[-1]
    text = latest.read_text(encoding="utf-8")
    m = re.search(r"^verdict:\s*(\w+)", text, re.MULTILINE)
    verdict = m.group(1) if m else "?"
    print(f"[sdlc review status] {artifact_id}: {verdict}")
    print(f"  summary: {latest.relative_to(target)}")
    return 0
