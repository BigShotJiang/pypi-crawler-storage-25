# src/sdlc_framework/commands/ticket_cmd.py
"""``sdlc ticket`` — non-feature work + Kanban lifecycle (Phase 5).

Two surfaces in one command:

1. **Legacy non-feature task creation** (carried over from Phase 4).
   ``sdlc ticket new <slug> --kind=<bug|chore|hotfix|support>`` writes a
   yaml under ``automation/tasks/`` so the task goes through the
   strict-TDD ladder defined by the task tier.

2. **Kanban tickets** (Phase 5, parallel to the story/task pipeline).
   Tickets live under ``automation/tickets/<slug>.yaml`` with a 3-state
   machine ``todo → in-progress → done``. There is *no* serial lock
   here — many tickets can be in-progress at once. The same directory
   already hosts incident hotfix tickets (see ``incident_sync``);
   ``ticket list`` therefore sorts them together.

Subcommands:

- ``new``   — creates a non-feature task (default) or a kanban ticket
              (when ``--strict`` is supplied: ``strict: true``,
              ``status: todo``, written to ``automation/tickets/``).
- ``pick``  — ``todo → in-progress`` on a kanban ticket. Idempotent on
              already-in-progress; refuses ``done`` tickets.
- ``done``  — ``in-progress|todo → done`` on a kanban ticket. Stamps
              ``done_at`` (UTC). Idempotent on already-done.
- ``list``  — table view sorted by:
                1. Incident-linked tickets (severity desc)
                2. ``priority`` field (high → medium → low)
                3. Alphabetical fallback for ties.

The kanban writes are intentionally simple — no schema validation
beyond "yaml maps to a dict". The loader (``stories_loader``-style
defensive policy) handles malformed entries downstream.
"""
from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml


_USAGE = "usage: sdlc ticket <new|pick|done|list> ..."

# Severity rank for incident-linked tickets (lower = floats higher).
_SEVERITY_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3}
# Priority rank for plain kanban tickets.
_PRIORITY_RANK = {"high": 0, "medium": 1, "low": 2}


def cmd_ticket(argv: list[str]) -> int:
    """Dispatch ``sdlc ticket <sub> ...``.

    Returns 2 on usage errors (no args / unknown sub) — matches the
    convention used by ``cmd_story`` / ``cmd_incident``.
    """
    if not argv:
        print(_USAGE, file=sys.stderr)
        return 2
    sub, rest = argv[0], argv[1:]
    if sub == "new":
        return _cmd_ticket_new(rest)
    if sub == "pick":
        return _cmd_ticket_pick(rest)
    if sub == "done":
        return _cmd_ticket_done(rest)
    if sub == "list":
        return _cmd_ticket_list(rest)
    print(f"sdlc ticket: unknown subcommand {sub!r}", file=sys.stderr)
    print(_USAGE, file=sys.stderr)
    return 2


# ---------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _ticket_path(target: Path, ticket_id: str) -> Path:
    return target / "automation" / "tickets" / f"{ticket_id}.yaml"


def _read_ticket(path: Path) -> dict | None:
    """Load a ticket yaml; return None on missing / malformed.

    Defensive: caller guards on existence first to surface a clean
    error message; this helper is the I/O leaf.
    """
    if not path.exists():
        return None
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return None
    if not isinstance(data, dict):
        return None
    return data


def _write_ticket(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


def _read_incident_severity(target: Path, incident_id: str) -> str | None:
    """Best-effort lookup of an incident's ``severity``.

    Used by ``ticket list`` to rank incident-linked tickets. Returns
    None when the incident yaml is missing or malformed — the caller
    falls back to plain priority ranking.
    """
    p = target / "automation" / "incidents" / f"{incident_id}.yaml"
    if not p.exists():
        return None
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return None
    if not isinstance(data, dict):
        return None
    return data.get("severity")


# ---------------------------------------------------------------------
# new (delegates → tasks, OR writes kanban ticket on --strict)
# ---------------------------------------------------------------------


def _cmd_ticket_new(argv: list[str]) -> int:
    """Create a non-feature task (default) or a kanban ticket (``--strict``).

    Without ``--strict`` we delegate to ``sdlc tasks new``: the engine
    needs the resulting yaml to live under ``automation/tasks/`` so the
    strict-TDD ladder applies.

    With ``--strict`` we write directly to
    ``automation/tickets/<slug>.yaml`` with ``strict: true``. The
    downstream tickets loader (Phase 6 dispatcher) reads that flag and
    treats the entry like a task for routing decisions, while keeping
    the simpler 3-state machine for the lifecycle CLI.
    """
    parser = argparse.ArgumentParser(prog="sdlc ticket new")
    parser.add_argument("slug")
    parser.add_argument(
        "--kind", required=True,
        choices=["bug", "chore", "hotfix", "support"],
        help="Ticket kind (must be non-feature; use `sdlc tasks new` for features).",
    )
    parser.add_argument("--label", default=None)
    parser.add_argument("--code-glob", default=None)
    parser.add_argument("--test-glob", default=None)
    parser.add_argument("--pr-branch", default=None)
    parser.add_argument("--priority", default="medium")
    parser.add_argument("--no-review", dest="no_review", action="store_true")
    parser.add_argument("--force-skip-review", dest="force_skip", action="store_true")
    parser.add_argument("--reason", default=None)
    parser.add_argument(
        "--strict", action="store_true",
        help="Write a strict kanban ticket under automation/tickets/ "
             "instead of delegating to `sdlc tasks new`.",
    )
    args = parser.parse_args(argv)

    if args.strict:
        return _write_strict_kanban_ticket(args)

    # Legacy path: delegate to `sdlc tasks new`.
    delegated = [args.slug, "--kind", args.kind, "--priority", args.priority]
    if args.label is not None:
        delegated += ["--label", args.label]
    if args.code_glob is not None:
        delegated += ["--code-glob", args.code_glob]
    if args.test_glob is not None:
        delegated += ["--test-glob", args.test_glob]
    if args.pr_branch is not None:
        delegated += ["--pr-branch", args.pr_branch]
    if args.no_review:
        delegated.append("--no-review")
    if args.force_skip:
        delegated.append("--force-skip-review")
    if args.reason is not None:
        delegated += ["--reason", args.reason]

    from sdlc_framework.commands.tasks import cmd_tasks
    return cmd_tasks(["new", *delegated])


def _write_strict_kanban_ticket(args: argparse.Namespace) -> int:
    """Write ``automation/tickets/<slug>.yaml`` for a strict kanban ticket.

    The yaml carries enough fields that the dispatcher (Phase 6) and
    incident loader can both reason about it without re-parsing every
    sibling artifact.
    """
    target = Path.cwd()
    path = _ticket_path(target, args.slug)
    if path.exists():
        print(
            f"[sdlc ticket new] ticket already exists: "
            f"{path.relative_to(target)}",
            file=sys.stderr,
        )
        return 1

    body: dict = {
        "id": args.slug,
        "kind": args.kind,
        "status": "todo",
        "strict": True,
        "priority": args.priority,
        "created_at": _utc_now_iso(),
    }
    if args.label:
        body["label"] = args.label
    if args.code_glob:
        body["code_glob"] = args.code_glob
    if args.test_glob:
        body["test_glob"] = args.test_glob
    if args.pr_branch:
        body["pr_branch"] = args.pr_branch

    _write_ticket(path, body)
    print(f"[sdlc ticket new] wrote {path.relative_to(target)}")
    return 0


# ---------------------------------------------------------------------
# pick: todo → in-progress
# ---------------------------------------------------------------------


def _cmd_ticket_pick(argv: list[str]) -> int:
    """``sdlc ticket pick <slug>`` — transition ``todo → in-progress``.

    Idempotent on already-in-progress (returns 0). Refuses to operate
    on a ``done`` ticket — that would silently regress audit history.
    """
    parser = argparse.ArgumentParser(prog="sdlc ticket pick")
    parser.add_argument("slug")
    args = parser.parse_args(argv)

    target = Path.cwd()
    path = _ticket_path(target, args.slug)
    data = _read_ticket(path)
    if data is None:
        print(
            f"[sdlc ticket pick] ticket not found: {args.slug}",
            file=sys.stderr,
        )
        return 1

    status = data.get("status")
    if status == "in-progress":
        print(f"[sdlc ticket pick] {args.slug} already in-progress")
        return 0
    if status == "done":
        print(
            f"[sdlc ticket pick] {args.slug} is done; cannot re-pick.",
            file=sys.stderr,
        )
        return 1

    data["status"] = "in-progress"
    _write_ticket(path, data)
    print(f"[sdlc ticket pick] {args.slug}: todo → in-progress")
    return 0


# ---------------------------------------------------------------------
# done: in-progress|todo → done
# ---------------------------------------------------------------------


def _cmd_ticket_done(argv: list[str]) -> int:
    """``sdlc ticket done <slug>`` — transition to ``done`` and stamp ``done_at``.

    Accepts the ``todo → done`` shortcut for small fixes that don't
    benefit from a separate ``pick`` step. Idempotent on already-done:
    preserves the original ``done_at`` so the audit trail never
    silently shifts.
    """
    parser = argparse.ArgumentParser(prog="sdlc ticket done")
    parser.add_argument("slug")
    args = parser.parse_args(argv)

    target = Path.cwd()
    path = _ticket_path(target, args.slug)
    data = _read_ticket(path)
    if data is None:
        print(
            f"[sdlc ticket done] ticket not found: {args.slug}",
            file=sys.stderr,
        )
        return 1

    if data.get("status") == "done":
        # Idempotent — keep existing done_at intact.
        print(f"[sdlc ticket done] {args.slug} already done")
        return 0

    data["status"] = "done"
    data.setdefault("done_at", _utc_now_iso())
    _write_ticket(path, data)
    print(f"[sdlc ticket done] {args.slug} → done")
    return 0


# ---------------------------------------------------------------------
# list: priority sort (incident severity → priority → alphabetical)
# ---------------------------------------------------------------------


def _cmd_ticket_list(argv: list[str]) -> int:
    """``sdlc ticket list`` — print all kanban tickets in priority order.

    Sort key (lower → printed first):
        (incident_rank, priority_rank, id)

    where ``incident_rank`` is the severity of the linked incident
    (``critical=0``…``low=3``) for incident-tickets, and ``99`` for
    plain kanban so they always sort below incident-linked work.
    """
    # No flags yet — keep argparse for consistency + future --status filter.
    parser = argparse.ArgumentParser(prog="sdlc ticket list")
    parser.parse_args(argv)

    target = Path.cwd()
    tdir = target / "automation" / "tickets"
    if not tdir.exists():
        print("[sdlc ticket list] no tickets found.")
        return 0

    rows: list[dict] = []
    for f in sorted(tdir.glob("*.yaml")):
        data = _read_ticket(f)
        if data is None or not data.get("id"):
            continue
        rows.append(data)

    if not rows:
        print("[sdlc ticket list] no tickets found.")
        return 0

    def _sort_key(t: dict) -> tuple[int, int, str]:
        inc_id = t.get("incident_id")
        if inc_id:
            sev = _read_incident_severity(target, inc_id)
            if sev is not None:
                # Resolvable severity: incident-tickets sort 0..3 (critical→low).
                inc_rank = _SEVERITY_RANK.get(sev, 4)
            else:
                # Incident yaml missing or severity field absent — fall back
                # to the ticket's own priority hint, but look it up in
                # _PRIORITY_RANK (NOT _SEVERITY_RANK), otherwise a kanban
                # ``priority: critical`` would silently outrank real
                # severity-critical incidents because the two maps share
                # ``high``/``medium``/``low`` keys with different ranks.
                # Offset by 10 so we still sort below resolvable-severity
                # incidents but above plain kanban (which gets 99).
                prio_rank_fallback = _PRIORITY_RANK.get(t.get("priority"), 9)
                inc_rank = 10 + prio_rank_fallback
        else:
            inc_rank = 99
        prio_rank = _PRIORITY_RANK.get(t.get("priority"), 9)
        return (inc_rank, prio_rank, str(t.get("id", "")))

    rows.sort(key=_sort_key)

    # Width-aware table — keep parity with `sdlc incident list`.
    id_w = max(len("ID"), max(len(str(r.get("id", ""))) for r in rows))
    st_w = max(len("STATUS"), max(len(str(r.get("status", "-"))) for r in rows))
    prio_w = max(len("PRIO"), max(len(str(r.get("priority", "-"))) for r in rows))
    print(f"{'ID':<{id_w}}  {'STATUS':<{st_w}}  {'PRIO':<{prio_w}}  INC")
    for r in rows:
        inc = r.get("incident_id") or "-"
        print(
            f"{str(r.get('id', '')):<{id_w}}  "
            f"{str(r.get('status', '-')):<{st_w}}  "
            f"{str(r.get('priority', '-')):<{prio_w}}  "
            f"{inc}"
        )
    return 0
