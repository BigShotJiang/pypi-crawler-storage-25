"""sdlc incident <subcommand> dispatcher.

Phase 4 of v1.1.0 introduces the Incident entity. This module owns the
CLI surface; all yaml writes are delegated to ``incident_sync``. Loader
+ status derivation live in ``incidents_loader`` (read-only).

Subcommands:
- ``open``   — create incident yaml; auto-create or link a kanban hotfix ticket.
- ``close``  — terminal transition; tier-1 enforces postmortem gate.
- ``edit``   — open incident yaml in ``$EDITOR`` / ``$VISUAL`` for in-place edits.
- ``list``   — table view, filterable by ``--state`` / ``--severity``.
- ``show``   — single-incident detail with linked ticket status + derived MTTR.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from datetime import datetime, timezone

from sdlc_framework.incident_sync import (
    IncidentSyncError,
    close_incident,
    create_hotfix_ticket,
    hotfix_ticket_id,
    link_existing_ticket,
    write_incident,
)
from sdlc_framework.incidents_loader import (
    IncidentSchemaError,
    VALID_SEVERITIES,
    derive_incident_status,
    load_incidents,
)


_USAGE = "usage: sdlc incident <open|close|edit|list|show> ..."


def cmd_incident(argv: list[str]) -> int:
    """Dispatch ``sdlc incident <sub> ...``.

    Returns 2 on usage errors (no args / unknown subcommand) — same
    convention as ``cmd_story`` / ``cmd_ticket``.
    """
    if not argv:
        print(_USAGE, file=sys.stderr)
        return 2
    sub, rest = argv[0], argv[1:]
    if sub == "open":
        return _cmd_incident_open(rest)
    if sub == "close":
        return _cmd_incident_close(rest)
    if sub == "edit":
        return _cmd_incident_edit(rest)
    if sub == "list":
        return _cmd_incident_list(rest)
    if sub == "show":
        return _cmd_incident_show(rest)
    print(f"sdlc incident: unknown subcommand {sub!r}", file=sys.stderr)
    print(_USAGE, file=sys.stderr)
    return 2


# ---------------------------------------------------------------------
# open
# ---------------------------------------------------------------------


def _cmd_incident_open(argv: list[str]) -> int:
    """``sdlc incident open <id> -s <sev> -t <title> [-m <msg>] ...``.

    Flow:
    1. Parse + validate args (argparse rejects bogus severities).
    2. Refuse duplicate incident id (don't overwrite existing yaml).
    3. Resolve description from -m / --stdin / $EDITOR (fail with hint
       when nothing is supplied).
    4. Resolve ``fix_ticket_id``:
       - ``--no-ticket``         → no link.
       - ``--link-ticket=<id>``  → reuse existing ticket; back-link to incident.
       - default                  → auto-create ``inc-<id>-hotfix`` ticket.
    5. Write the incident yaml.
    """
    parser = argparse.ArgumentParser(prog="sdlc incident open")
    parser.add_argument("incident_id", help="e.g. INC-42")
    parser.add_argument(
        "-s", "--severity", required=True, choices=list(VALID_SEVERITIES),
        help="critical | high | medium | low",
    )
    parser.add_argument("-t", "--title", required=True)
    parser.add_argument("-m", "--message", default=None,
                        help="Incident description body (one-shot).")
    parser.add_argument("--root-cause", dest="root_cause", default=None,
                        help="Root cause if already known at open time (rare).")
    parser.add_argument("--stdin", action="store_true",
                        help="Read description from stdin instead of -m.")

    ticket_group = parser.add_mutually_exclusive_group()
    ticket_group.add_argument(
        "--no-ticket", dest="no_ticket", action="store_true",
        help="Skip auto-creating the kanban hotfix ticket.",
    )
    ticket_group.add_argument(
        "--link-ticket", dest="link_ticket", default=None,
        help="Reuse an existing kanban ticket id instead of auto-creating one.",
    )

    args = parser.parse_args(argv)
    target = Path.cwd()

    # Refuse duplicate id BEFORE resolving description / mutating tickets.
    inc_path = target / "automation" / "incidents" / f"{args.incident_id}.yaml"
    if inc_path.exists():
        print(
            f"[sdlc incident open] incident already exists: "
            f"{inc_path.relative_to(target)}",
            file=sys.stderr,
        )
        return 1

    # Resolve description.
    description = _resolve_description(args)
    if description is None:
        return 1  # _resolve_description already printed the hint

    # Resolve fix_ticket_id and (maybe) write/back-link the ticket.
    try:
        fix_ticket_id = _resolve_fix_ticket(target, args, description)
    except IncidentSyncError as exc:
        print(f"[sdlc incident open] {exc}", file=sys.stderr)
        return 1

    # Write the incident yaml last — at this point the ticket either
    # exists or was deliberately skipped.
    try:
        write_incident(
            target,
            args.incident_id,
            title=args.title,
            severity=args.severity,
            description=description,
            root_cause=args.root_cause,
            fix_ticket_id=fix_ticket_id,
        )
    except IncidentSyncError as exc:
        print(f"[sdlc incident open] {exc}", file=sys.stderr)
        return 1

    print(f"[sdlc incident open] wrote {inc_path.relative_to(target)}")
    if fix_ticket_id:
        tkt_rel = (
            target / "automation" / "tickets" / f"{fix_ticket_id}.yaml"
        ).relative_to(target)
        print(f"[sdlc incident open] linked fix ticket: {tkt_rel}")
    return 0


# ---------------------------------------------------------------------
# close
# ---------------------------------------------------------------------


def _cmd_incident_close(argv: list[str]) -> int:
    """``sdlc incident close <id> [-m <summary>]``.

    Gate:
    - Incident must derive to ``restored`` (linked fix ticket reached done).
      Open or already-closed incidents are refused.
    - When ``project.tier == 1``, a postmortem file at
      ``04-Testing-Deploy/postmortems/<id>.md`` must exist before close.
      Tier 2/3 (or no project.yaml) skip the postmortem check.

    Writes the terminal yaml fields (``status: closed``, ``closed_at``,
    ``restored_at``, ``mttr_min``, optional ``close_summary``) via
    ``incident_sync.close_incident``.
    """
    parser = argparse.ArgumentParser(prog="sdlc incident close")
    parser.add_argument("incident_id")
    parser.add_argument("-m", "--message", default=None,
                        help="Short summary of the close (RCA link, action items, etc.).")
    args = parser.parse_args(argv)

    target = Path.cwd()
    inc_path = target / "automation" / "incidents" / f"{args.incident_id}.yaml"
    if not inc_path.exists():
        print(
            f"[sdlc incident close] incident not found: "
            f"{args.incident_id}",
            file=sys.stderr,
        )
        return 1

    # State validation — derive status from disk truth.
    try:
        status, mttr_min = derive_incident_status(target, args.incident_id)
    except IncidentSchemaError as exc:
        print(f"[sdlc incident close] {exc}", file=sys.stderr)
        return 1

    if status == "closed":
        print(
            f"[sdlc incident close] {args.incident_id} is already closed.",
            file=sys.stderr,
        )
        return 1
    if status != "restored":
        print(
            f"[sdlc incident close] {args.incident_id} is still '{status}'. "
            f"Mark the fix ticket 'done' before closing the incident.",
            file=sys.stderr,
        )
        return 1

    # Tier-1 postmortem gate.
    tier = _project_tier(target)
    if tier == 1:
        pm_path = (
            target / "04-Testing-Deploy" / "postmortems" / f"{args.incident_id}.md"
        )
        if not pm_path.exists():
            print(
                f"[sdlc incident close] tier-1 project requires postmortem at "
                f"{pm_path.relative_to(target)} before close.\n"
                f"hint: write the postmortem first, then re-run.",
                file=sys.stderr,
            )
            return 1

    # Compute timestamps. We freeze restored_at against the original
    # opened_at + derived MTTR so the closed yaml stays internally
    # consistent regardless of when the operator gets around to closing.
    closed_at = _utc_now_iso()
    restored_at = _restored_at_for(target, args.incident_id, mttr_min)

    try:
        close_incident(
            target,
            args.incident_id,
            closed_at=closed_at,
            restored_at=restored_at,
            mttr_min=mttr_min,
            summary=args.message,
        )
    except IncidentSyncError as exc:
        print(f"[sdlc incident close] {exc}", file=sys.stderr)
        return 1

    print(f"[sdlc incident close] closed {args.incident_id} (mttr={mttr_min}m)")
    return 0


# ---------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------


def _project_tier(target: Path) -> int:
    """Return the project tier (default 2 when project.yaml absent / invalid).

    Defers to ``project_loader.load_project`` so we share the same parser
    + validation as the engine.
    """
    from sdlc_framework.project_loader import load_project
    project, _errors = load_project(target / "project.yaml")
    return int(project.get("tier", 2))


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _restored_at_for(target: Path, incident_id: str, mttr_min: int | None) -> str:
    """Pick the canonical restored_at timestamp for closing.

    1. Honour an existing ``restored_at`` on the yaml (operator wrote it).
    2. Else derive from ``opened_at + mttr_min`` so the recorded interval
       matches what the dashboard already showed.
    3. Else fall back to "now" — the worst-case path; caller has already
       verified status == 'restored' so MTTR is normally available.
    """
    import yaml as _yaml
    inc = (
        target / "automation" / "incidents" / f"{incident_id}.yaml"
    ).read_text(encoding="utf-8")
    data = _yaml.safe_load(inc) or {}
    existing = data.get("restored_at")
    if existing:
        return existing
    opened = data.get("opened_at")
    if opened and mttr_min is not None:
        from sdlc_framework.incidents_loader import _parse_iso
        from datetime import timedelta
        restored = _parse_iso(opened) + timedelta(minutes=mttr_min)
        return restored.strftime("%Y-%m-%dT%H:%M:%SZ")
    return _utc_now_iso()


# ---------------------------------------------------------------------
# open helpers
# ---------------------------------------------------------------------


def _resolve_description(args: argparse.Namespace) -> str | None:
    """Return the incident description, or None on failure (already printed).

    Resolution order:
    1. ``-m/--message``       (explicit one-shot)
    2. ``--stdin``            (sys.stdin.read())
    3. ``$EDITOR`` / ``$VISUAL`` (open a tempfile, return its content)

    Empty / whitespace-only result is treated as failure with a hint.
    """
    if args.message is not None:
        return args.message
    if args.stdin:
        body = sys.stdin.read()
        if not body.strip():
            print(
                "[sdlc incident open] --stdin given but stdin was empty.",
                file=sys.stderr,
            )
            return None
        return body

    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")
    if not editor:
        print(
            "[sdlc incident open] no description supplied. "
            "Pass -m \"...\", --stdin, or set $EDITOR.",
            file=sys.stderr,
        )
        return None

    body = _read_from_editor(editor)
    if body is None or not body.strip():
        print(
            "[sdlc incident open] editor closed without a description.",
            file=sys.stderr,
        )
        return None
    return body


def _read_from_editor(editor: str) -> str | None:
    """Open ``editor`` on a tempfile and return its final content."""
    with tempfile.NamedTemporaryFile(
        mode="w+", suffix=".md", delete=False, encoding="utf-8",
    ) as tf:
        tmp_path = Path(tf.name)
        tf.write("# Describe the incident below. Lines starting with # are kept.\n")
    try:
        subprocess.run([editor, str(tmp_path)], check=False)  # noqa: S603
        return tmp_path.read_text(encoding="utf-8")
    finally:
        try:
            tmp_path.unlink()
        except OSError:
            pass


def _resolve_fix_ticket(
    target: Path,
    args: argparse.Namespace,
    description: str,
) -> str | None:
    """Create / link / skip the fix ticket; return its id (or None)."""
    if args.no_ticket:
        return None

    if args.link_ticket:
        # link_existing_ticket raises IncidentSyncError if the ticket
        # is missing or malformed — propagated to the caller.
        link_existing_ticket(target, args.incident_id, args.link_ticket)
        return args.link_ticket

    # Default: auto-create the hotfix ticket.
    tid = hotfix_ticket_id(args.incident_id)
    create_hotfix_ticket(
        target,
        args.incident_id,
        title=args.title,
        severity=args.severity,
        description=description,
        ticket_id=tid,
    )
    return tid


# ---------------------------------------------------------------------
# edit
# ---------------------------------------------------------------------


def _cmd_incident_edit(argv: list[str]) -> int:
    """``sdlc incident edit <id>`` — open the incident yaml in ``$EDITOR``.

    The yaml is intentionally not re-validated after the editor exits:
    the loader's defensive policy (skip malformed entries) gives the
    operator room to fix mistakes incrementally without the CLI
    blocking each save.
    """
    parser = argparse.ArgumentParser(prog="sdlc incident edit")
    parser.add_argument("incident_id")
    args = parser.parse_args(argv)

    target = Path.cwd()
    inc_path = target / "automation" / "incidents" / f"{args.incident_id}.yaml"
    if not inc_path.exists():
        print(
            f"[sdlc incident edit] incident not found: {args.incident_id}",
            file=sys.stderr,
        )
        return 1

    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")
    if not editor:
        print(
            "[sdlc incident edit] no $EDITOR or $VISUAL set; cannot open the yaml.",
            file=sys.stderr,
        )
        return 1

    result = subprocess.run([editor, str(inc_path)], check=False)  # noqa: S603
    return 0 if result.returncode == 0 else result.returncode


# ---------------------------------------------------------------------
# list
# ---------------------------------------------------------------------


def _cmd_incident_list(argv: list[str]) -> int:
    """``sdlc incident list [--state=<s>] [--severity=<s>]`` — table view.

    ``state`` is the *derived* status (per ``derive_incident_status``),
    not the raw yaml field. ``severity`` is the literal yaml field.
    Filters compose with AND. Stable order = filename order from
    ``load_incidents``.
    """
    from sdlc_framework.incidents_loader import VALID_INCIDENT_STATUSES

    parser = argparse.ArgumentParser(prog="sdlc incident list")
    parser.add_argument("--state", choices=list(VALID_INCIDENT_STATUSES), default=None)
    parser.add_argument("--severity", choices=list(VALID_SEVERITIES), default=None)
    args = parser.parse_args(argv)

    target = Path.cwd()
    incidents = load_incidents(target)
    if not incidents:
        print("[sdlc incident list] no incidents found.")
        return 0

    rows: list[tuple[str, str, str, str, int | None]] = []
    for inc in incidents:
        if args.severity and inc.get("severity") != args.severity:
            continue
        try:
            status, mttr_min = derive_incident_status(target, inc["id"])
        except IncidentSchemaError:
            # Malformed yaml — skip rather than crash the whole listing.
            continue
        if args.state and status != args.state:
            continue
        rows.append((
            inc["id"],
            inc.get("severity", "-"),
            status,
            inc.get("title", "-"),
            mttr_min,
        ))

    if not rows:
        print("[sdlc incident list] no incidents match the given filters.")
        return 0

    # Width-aware table; minimal — operators read this in a terminal.
    id_w = max(len("ID"), max(len(r[0]) for r in rows))
    sev_w = max(len("SEV"), max(len(r[1]) for r in rows))
    st_w = max(len("STATUS"), max(len(r[2]) for r in rows))
    print(f"{'ID':<{id_w}}  {'SEV':<{sev_w}}  {'STATUS':<{st_w}}  MTTR  TITLE")
    for inc_id, sev, status, title, mttr in rows:
        mttr_str = f"{mttr}m" if mttr is not None else "-"
        print(f"{inc_id:<{id_w}}  {sev:<{sev_w}}  {status:<{st_w}}  {mttr_str:>4}  {title}")
    return 0


# ---------------------------------------------------------------------
# show
# ---------------------------------------------------------------------


def _cmd_incident_show(argv: list[str]) -> int:
    """``sdlc incident show <id>`` — full detail for one incident.

    Output shape:
        id: INC-1
        title: ...
        severity: ...
        status (derived): open
        opened_at: 2026-...
        fix_ticket: <id> [status: <ticket-status>]
        mttr_min: <int>     (when known)
        description: |
          ...

    Designed to be skim-readable rather than machine-parseable; the
    yaml on disk is the source of truth for tooling.
    """
    parser = argparse.ArgumentParser(prog="sdlc incident show")
    parser.add_argument("incident_id")
    args = parser.parse_args(argv)

    target = Path.cwd()
    inc_path = target / "automation" / "incidents" / f"{args.incident_id}.yaml"
    if not inc_path.exists():
        print(
            f"[sdlc incident show] incident not found: {args.incident_id}",
            file=sys.stderr,
        )
        return 1

    import yaml as _yaml
    try:
        data = _yaml.safe_load(inc_path.read_text(encoding="utf-8")) or {}
    except _yaml.YAMLError as exc:
        print(f"[sdlc incident show] malformed yaml: {exc}", file=sys.stderr)
        return 1
    if not isinstance(data, dict):
        print(f"[sdlc incident show] yaml is not a mapping: {inc_path}", file=sys.stderr)
        return 1

    # Derived status + MTTR — best-effort; do not let a derivation
    # error wipe out the rest of the output.
    derived_status: str | None = None
    derived_mttr: int | None = None
    try:
        derived_status, derived_mttr = derive_incident_status(target, args.incident_id)
    except IncidentSchemaError:
        derived_status = None

    # Linked fix ticket status (if any).
    fix_id = data.get("fix_ticket_id")
    fix_status: str | None = None
    if fix_id:
        tpath = target / "automation" / "tickets" / f"{fix_id}.yaml"
        if tpath.exists():
            try:
                tdata = _yaml.safe_load(tpath.read_text(encoding="utf-8")) or {}
                if isinstance(tdata, dict):
                    fix_status = tdata.get("status")
            except _yaml.YAMLError:
                fix_status = None

    print(f"id: {data.get('id', args.incident_id)}")
    print(f"title: {data.get('title', '-')}")
    print(f"severity: {data.get('severity', '-')}")
    if derived_status:
        print(f"status (derived): {derived_status}")
    elif data.get("status"):
        print(f"status: {data['status']}")
    print(f"opened_at: {data.get('opened_at', '-')}")
    if data.get("restored_at"):
        print(f"restored_at: {data['restored_at']}")
    if data.get("closed_at"):
        print(f"closed_at: {data['closed_at']}")
    if fix_id:
        suffix = f" [status: {fix_status}]" if fix_status else " [status: unknown]"
        print(f"fix_ticket: {fix_id}{suffix}")
    # Prefer yaml mttr_min when present (closed); else derived.
    mttr_to_show = data.get("mttr_min", derived_mttr)
    if mttr_to_show is not None:
        print(f"mttr_min: {mttr_to_show}")
    if data.get("root_cause"):
        print(f"root_cause: {data['root_cause']}")
    if data.get("description"):
        print("description: |")
        for line in str(data["description"]).rstrip().splitlines():
            print(f"  {line}")
    if data.get("close_summary"):
        print(f"close_summary: {data['close_summary']}")
    return 0
