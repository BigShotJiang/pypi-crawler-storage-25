"""Phase 3 lock helpers: ``cmd_force_merge`` (CLI) + state I/O internals.

v1.1.0: ``cmd_activate`` / ``cmd_active`` / ``cmd_unlock`` were removed —
manual lock control moved to the story tier (``sdlc story activate`` /
``sdlc story deactivate``) so there's a single canonical place to flip
the in-progress story. The internal helpers ``_load_state`` /
``_save_state`` / ``_resolve_group_id`` are kept because
``cmd_force_merge`` still uses them, and because engine code reads the
same ``phase3.active_story_id`` field via ``tasks_loader.resolve_active_group``.

Subagents should NEVER edit state.json directly; use ``sdlc`` commands.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from sdlc_framework.schema_versions import (
    LEGACY_STATE_SCHEMA_VERSIONS,
    STATE_SCHEMA_VERSION,
)
from sdlc_framework.tasks_loader import _utcnow_iso, load_tasks


def _state_path(target: Path) -> Path:
    return target / "automation" / "state.json"


def _refuse_legacy(state: dict, p: Path) -> None:
    """Refuse to mutate state.json that carries a legacy schema_version.

    Mirrors engine._refuse_legacy_state — keeps tasks-lock subcommands from
    creating hybrid v0+v1 state.json that engine.scan would later refuse,
    leaving the user wondering how the file got corrupted.
    """
    sv = state.get("schema_version")
    if sv in LEGACY_STATE_SCHEMA_VERSIONS:
        msg = (
            f"\n[sdlc] ERROR: state.json schema_version={sv} is legacy.\n"
            f"This is v1.0 canonical. State files require schema_version: {STATE_SCHEMA_VERSION}.\n"
            f"Project file: {p}\n"
            f"Fix: rm automation/state.json && sdlc scan\n"
            f"  (state.json is regenerated on every scan; deleting it is non-destructive.)\n"
        )
        print(msg, file=sys.stderr)
        sys.exit(2)


def _load_state(target: Path) -> dict:
    p = _state_path(target)
    if not p.exists():
        return {
            "schema_version": STATE_SCHEMA_VERSION,
            "phase3": {"active_story_id": None, "lock_acquired_at": None},
        }
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        data = {}
    _refuse_legacy(data, p)
    data.setdefault("schema_version", STATE_SCHEMA_VERSION)
    data.setdefault("phase3", {"active_story_id": None, "lock_acquired_at": None})
    return data


def _save_state(target: Path, state: dict) -> None:
    p = _state_path(target)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _resolve_group_id(target: Path, ident: str) -> str | None:
    """Map a task id or story_id to a group id (story_id or task.id)."""
    for t in load_tasks(target):
        if t.get("id") == ident:
            return t.get("story_id") or t["id"]
        if t.get("story_id") == ident:
            return ident
    return None


def cmd_force_merge(argv: list[str]) -> int:
    if "--i-accept-the-risk" not in argv:
        print(
            "[sdlc tasks force-merge] refusing without explicit "
            "`--i-accept-the-risk` flag (this bypasses code-reviewer verdict)",
            file=sys.stderr,
        )
        return 2
    ident = next((a for a in argv if not a.startswith("--")), None)
    if ident is None:
        print(
            "usage: sdlc tasks force-merge <task-id> --i-accept-the-risk",
            file=sys.stderr,
        )
        return 2
    from sdlc_framework import gh_ops
    target = Path.cwd()
    gid = _resolve_group_id(target, ident)
    branch = f"feature/{gid or ident}"
    ok, err = gh_ops.squash_merge(
        pr_ref=branch,
        subject=f"chore: force-merge {ident} via sdlc tasks force-merge",
        target=target,
    )
    if not ok:
        print(f"[sdlc tasks force-merge] failed: {err}", file=sys.stderr)
        return 1
    state = _load_state(target)
    state["phase3"]["active_story_id"] = None
    state["phase3"]["lock_acquired_at"] = None
    _save_state(target, state)
    print(f"[sdlc tasks force-merge] merged {branch}")
    return 0
