"""sdlc story <subcommand> dispatcher."""
from __future__ import annotations

import sys
from pathlib import Path

import yaml

from sdlc_framework.story_sync import StorySyncError, sync_story


def cmd_story(argv: list[str]) -> int:
    if not argv:
        print(
            "usage: sdlc story <new|sync|complete-draft|list|refine|activate|deactivate> ...",
            file=sys.stderr,
        )
        return 2
    sub = argv[0]
    rest = argv[1:]
    if sub == "new":
        return _cmd_story_new(rest)
    if sub == "sync":
        return _cmd_story_sync(rest)
    if sub == "complete-draft":
        return _cmd_story_complete_draft(rest)
    if sub == "list":
        return _cmd_story_list(rest)
    if sub == "refine":
        return _cmd_story_refine(rest)
    if sub == "activate":
        return _cmd_story_activate(rest)
    if sub == "deactivate":
        return _cmd_story_deactivate(rest)
    print(f"sdlc story: unknown subcommand {sub!r}", file=sys.stderr)
    print(
        "usage: sdlc story <new|sync|complete-draft|list|refine|activate|deactivate> ...",
        file=sys.stderr,
    )
    return 2


def _cmd_story_new(argv: list[str]) -> int:
    """Scaffold 01-Planning/stories/<slug>.md from template."""
    import argparse
    import datetime as _dt

    from sdlc_framework.review_skip import apply_review_skip_policy

    parser = argparse.ArgumentParser(prog="sdlc story new")
    parser.add_argument("slug")
    parser.add_argument("--epic", default=None)
    parser.add_argument("--title", default=None)
    parser.add_argument("--no-review", dest="no_review", action="store_true")
    parser.add_argument(
        "--force-skip-review", dest="force_skip", action="store_true",
        help="Bypass sensitive-path safety net; writes audit yaml.",
    )
    parser.add_argument("--reason", default=None,
                        help="Justification for --no-review (required in CI mode).")
    args = parser.parse_args(argv)

    target = Path.cwd()
    template = target / "01-Planning" / "templates" / "08-Story.md"
    if not template.is_file():
        print(
            f"[sdlc story new] template not found: {template}\n"
            f"hint: run `sdlc init` to scaffold templates.",
            file=sys.stderr,
        )
        return 1
    out_path = target / "01-Planning" / "stories" / f"{args.slug}.md"
    if out_path.exists():
        print(f"[sdlc story new] already exists: {out_path}", file=sys.stderr)
        return 1

    decision = apply_review_skip_policy(
        target=target,
        artifact_id=args.slug,
        artifact_type="story",
        title=args.title or args.slug,
        body="",
        globs=[],
        no_review=args.no_review,
        force_skip=args.force_skip,
        reason=args.reason,
    )
    if decision.refused:
        print(decision.refusal_message, file=sys.stderr)
        return 1

    body = template.read_text(encoding="utf-8")
    body = body.replace("{{story-slug}}", args.slug)
    body = body.replace("{{YYYY-MM-DD}}", _dt.date.today().isoformat())
    if args.title is not None:
        body = body.replace("{{Story Title}}", args.title)
    if args.epic is not None:
        body = body.replace("{{epic-slug-or-omit-if-orphan}}", args.epic)
    else:
        lines = body.splitlines(keepends=True)
        body = "".join(l for l in lines if "{{epic-slug-or-omit-if-orphan}}" not in l)

    if not decision.review:
        body = _set_frontmatter_field(body, "review", "false")
        body = _set_frontmatter_field(body, "review_skipped_by", _git_user_name())
        body = _set_frontmatter_field(body, "review_skip_reason", decision.skip_reason or "unset")
        body = _set_frontmatter_field(body, "review_skip_at", decision.skip_at or "")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(body, encoding="utf-8")
    print(f"[sdlc story new] wrote {out_path.relative_to(target)}")
    if decision.forced and decision.audit_path:
        print(f"[sdlc story new] forced skip audit: {decision.audit_path.relative_to(target)}")
    if args.title is None:
        print("hint: edit the file to fill in {{Story Title}} + the As-a/I-want/So-that block + G/W/T acceptance criteria.")
    print(f"next: `sdlc story sync {args.slug}` once the body is filled in.")
    return 0


def _git_user_name() -> str:
    import subprocess
    try:
        r = subprocess.run(["git", "config", "user.name"], capture_output=True, text=True, timeout=2)
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    import os
    return os.environ.get("USER") or "unknown"


def _set_frontmatter_field(text: str, key: str, value: str) -> str:
    """Replace `key: <anything>` in the YAML frontmatter (top of file)."""
    import re as _re
    if not text.startswith("---\n"):
        return text
    end = text.find("\n---\n", 4)
    if end < 0:
        return text
    fm = text[4:end]
    pattern = _re.compile(rf"^{_re.escape(key)}:.*$", _re.MULTILINE)
    if pattern.search(fm):
        new_fm = pattern.sub(f"{key}: {value}", fm)
    else:
        new_fm = fm.rstrip() + f"\n{key}: {value}"
    return "---\n" + new_fm + "\n---\n" + text[end + len("\n---\n"):]


def _cmd_story_sync(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc story sync <slug>", file=sys.stderr)
        return 2
    slug = argv[0]
    try:
        path = sync_story(Path.cwd(), slug)
    except StorySyncError as e:
        print(f"[sdlc story sync] {e}", file=sys.stderr)
        return 1
    print(f"[sdlc story sync] wrote {path.relative_to(Path.cwd())}")
    return 0


def _cmd_story_complete_draft(argv: list[str]) -> int:
    """Manual gate: advance Story from draft -> ready."""
    if not argv:
        print("usage: sdlc story complete-draft <slug>", file=sys.stderr)
        return 2
    slug = argv[0]
    yaml_path = Path.cwd() / "automation" / "stories" / f"{slug}.yaml"
    if not yaml_path.exists():
        print(f"[sdlc story complete-draft] story not found: {yaml_path}", file=sys.stderr)
        print("hint: run `sdlc story sync` first to create the yaml from md.", file=sys.stderr)
        return 1
    try:
        data = yaml.safe_load(yaml_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        print(f"[sdlc story complete-draft] yaml parse error: {e}", file=sys.stderr)
        return 1
    declared = data.get("state") or data.get("status", "draft")
    if declared != "draft":
        print(
            f"[sdlc story complete-draft] story is not in draft (state={declared!r})",
            file=sys.stderr,
        )
        return 1
    data["state"] = "ready"
    data.pop("status", None)
    yaml_path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    print(f"[sdlc story complete-draft] {slug}: draft -> ready")
    return 0


def _cmd_story_list(argv: list[str]) -> int:
    from sdlc_framework.stories_loader import derive_story_status, load_stories
    epic_filter = None
    status_filter = None
    i = 0
    while i < len(argv):
        if argv[i] == "--epic" and i + 1 < len(argv):
            epic_filter = argv[i + 1]
            i += 2
        elif argv[i] == "--status" and i + 1 < len(argv):
            status_filter = argv[i + 1]
            i += 2
        else:
            i += 1
    target = Path.cwd()
    stories = load_stories(target)
    rows = []
    for s in sorted(stories, key=lambda x: x["slug"]):
        if epic_filter is not None and s.get("epic_id") != epic_filter:
            continue
        status = derive_story_status(target, s["slug"])
        if status_filter is not None and status != status_filter:
            continue
        epic_id = s.get("epic_id") or "-"
        title = s.get("title", s["slug"])
        rows.append((s["slug"], status, epic_id, title))
    if not rows:
        print("(no stories)")
        return 0
    slug_w = max(len(r[0]) for r in rows)
    status_w = max(len(r[1]) for r in rows)
    epic_w = max(len(r[2]) for r in rows)
    print(f"{'SLUG':<{slug_w}}  {'STATUS':<{status_w}}  {'EPIC':<{epic_w}}  TITLE")
    print(f"{'-' * slug_w}  {'-' * status_w}  {'-' * epic_w}  {'-' * 30}")
    for slug, status, epic_id, title in rows:
        print(f"{slug:<{slug_w}}  {status:<{status_w}}  {epic_id:<{epic_w}}  {title}")
    return 0


def _cmd_story_activate(argv: list[str]) -> int:
    """`sdlc story activate <slug>` — validate deps + acquire serial lock."""
    import argparse
    import datetime as _dt
    import json

    from sdlc_framework.commands.tasks_lock import _refuse_legacy
    from sdlc_framework.story_sync import append_state_transition

    parser = argparse.ArgumentParser(prog="sdlc story activate")
    parser.add_argument("slug")
    args = parser.parse_args(argv)
    target = Path.cwd()

    spath = target / "automation" / "stories" / f"{args.slug}.yaml"
    if not spath.exists():
        print(f"error: story not found: {args.slug}", file=sys.stderr)
        return 1
    data = yaml.safe_load(spath.read_text(encoding="utf-8")) or {}
    state = data.get("state") or data.get("status", "draft")
    if state == "draft":
        print(
            f"error: story '{args.slug}' is draft (0 tasks). Add tasks first.",
            file=sys.stderr,
        )
        return 1

    deps = data.get("depends_on") or []
    # Cycle detection uses an ancestor-path tuple (per traversal branch) so
    # diamond DAGs (two paths converging on one node) don't false-trigger.
    # `visited` is a separate set used purely for enqueue-dedup so we don't
    # re-walk the same subtree.
    visited: set[str] = set()
    queue: list[tuple[str, tuple[str, ...]]] = [(d, (args.slug,)) for d in deps]
    unmet: list[str] = []
    while queue:
        d, path = queue.pop(0)
        if d in path:
            chain = " -> ".join(path) + f" -> {d}"
            print(f"error: dependency cycle detected: {chain}", file=sys.stderr)
            return 1
        if d in visited:
            continue
        visited.add(d)
        dpath = target / "automation" / "stories" / f"{d}.yaml"
        if not dpath.exists():
            print(
                f"error: depends_on references missing story: {d}", file=sys.stderr
            )
            return 1
        ddata = yaml.safe_load(dpath.read_text(encoding="utf-8")) or {}
        dstate = ddata.get("state") or ddata.get("status", "draft")
        if dstate != "deployed":
            unmet.append(f"  - {d} (state: {dstate})")
        next_path = path + (d,)
        for nd in (ddata.get("depends_on") or []):
            queue.append((nd, next_path))
    if unmet:
        print(
            f"error: cannot activate '{args.slug}' — unmet dependencies (need 'deployed'):\n"
            + "\n".join(unmet)
            + f"\nResolve by deploying the deps, or remove with `sdlc story edit {args.slug} --remove-dep=<id>`.",
            file=sys.stderr,
        )
        return 1

    sjson = target / "automation" / "state.json"
    sj = json.loads(sjson.read_text(encoding="utf-8")) if sjson.exists() else {}
    # Refuse legacy schema_version BEFORE any mutation/setdefault — otherwise
    # we'd merge v1.1 fields into a v0/v1 dict and write back a hybrid file
    # that the next `sdlc scan` would refuse with no useful explanation.
    # See test_story_legacy_state_refusal.py for the regression class.
    _refuse_legacy(sj, sjson)
    p3 = sj.setdefault("phase3", {})
    if p3.get("active_story_id"):
        print(
            f"error: another story is in-progress: {p3['active_story_id']}. "
            f"Run `sdlc story deactivate` first.",
            file=sys.stderr,
        )
        return 1

    now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    append_state_transition(target, args.slug, to="in-progress", at=now)
    p3["active_story_id"] = args.slug
    p3["lock_acquired_at"] = now
    sjson.parent.mkdir(parents=True, exist_ok=True)
    sjson.write_text(json.dumps(sj, indent=2), encoding="utf-8")
    print(f"activated: {args.slug} (state.phase3.active_story_id = {args.slug})")
    return 0


def _cmd_story_deactivate(argv: list[str]) -> int:
    """`sdlc story deactivate <slug>` — release serial lock + rollback to ready.

    Releases the Phase 3 serial lock held by ``slug`` and appends a
    ``ready`` transition to the story's state log (idempotent — won't
    duplicate if the most-recent transition is already ``ready``).
    """
    import argparse
    import datetime as _dt
    import json

    from sdlc_framework.commands.tasks_lock import _refuse_legacy
    from sdlc_framework.story_sync import append_state_transition

    parser = argparse.ArgumentParser(prog="sdlc story deactivate")
    parser.add_argument("slug")
    args = parser.parse_args(argv)
    target = Path.cwd()

    spath = target / "automation" / "stories" / f"{args.slug}.yaml"
    if not spath.exists():
        print(f"error: story not found: {args.slug}", file=sys.stderr)
        return 1

    sjson = target / "automation" / "state.json"
    sj = json.loads(sjson.read_text(encoding="utf-8")) if sjson.exists() else {}
    # Refuse legacy schema_version BEFORE any mutation/setdefault. See
    # _cmd_story_activate above + test_story_legacy_state_refusal.py.
    _refuse_legacy(sj, sjson)
    p3 = sj.setdefault("phase3", {})
    active = p3.get("active_story_id")
    if not active:
        print(
            "error: no active story (phase3.active_story_id is null)",
            file=sys.stderr,
        )
        return 1
    if active != args.slug:
        print(
            f"error: cannot deactivate '{args.slug}' — active story is '{active}'. "
            f"Run `sdlc story deactivate {active}` instead.",
            file=sys.stderr,
        )
        return 1

    now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    append_state_transition(target, args.slug, to="ready", at=now)
    p3["active_story_id"] = None
    p3.pop("lock_acquired_at", None)
    sjson.parent.mkdir(parents=True, exist_ok=True)
    sjson.write_text(json.dumps(sj, indent=2), encoding="utf-8")
    print(f"deactivated: {args.slug} (lock released, rolled back to ready)")
    return 0


def _cmd_story_refine(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc story refine <slug>", file=sys.stderr)
        return 2
    slug = argv[0]
    target = Path.cwd()
    md = target / "01-Planning" / "stories" / f"{slug}.md"
    if not md.is_file():
        print(f"[sdlc story refine] story not found: {md}", file=sys.stderr)
        return 1
    print("# sm-agent brief — sdlc story refine")
    print()
    print(f"Target story: `{slug}` ({md.relative_to(target)})")
    print()
    print("## Action")
    print(
        f"Read {md.relative_to(target)} and ask the user what to refine "
        f"(acceptance criteria, dev notes, suggested tasks, scope). Edit the "
        f"body inline; preserve frontmatter unless the user explicitly asks to "
        f"switch the parent epic. After editing, run `sdlc story sync {slug}`."
    )
    return 0
