# src/sdlc_framework/commands/audit_cmd.py
"""sdlc audit — inspect forced-skip audit yaml files."""
from __future__ import annotations

import sys
from pathlib import Path

import yaml


def cmd_audit(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc audit <list|show> ...", file=sys.stderr)
        return 2
    sub = argv[0]
    rest = argv[1:]
    if sub == "list":
        return _cmd_audit_list(rest)
    if sub == "show":
        return _cmd_audit_show(rest)
    print(f"sdlc audit: unknown subcommand {sub!r}", file=sys.stderr)
    return 2


def _cmd_audit_list(argv: list[str]) -> int:  # noqa: ARG001
    target = Path.cwd()
    audit_dir = target / "automation" / "audit"
    if not audit_dir.exists():
        print("(no audit log)")
        return 0
    files = sorted(audit_dir.glob("forced-skip-*.yaml"))
    if not files:
        print("(no forced-skip entries)")
        return 0
    rows: list[tuple[str, str, str, str, str]] = []
    for f in files:
        try:
            data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        rows.append((
            str(data.get("artifact_id", "")),
            str(data.get("artifact_type", "")),
            str(data.get("forced_by", "")),
            str(data.get("forced_at", "")),
            str(data.get("reason", ""))[:60],
        ))
    if not rows:
        print("(no readable audit entries)")
        return 0
    w_id = max(len(r[0]) for r in rows)
    w_type = max(len(r[1]) for r in rows)
    w_who = max(len(r[2]) for r in rows)
    w_when = max(len(r[3]) for r in rows)
    print(f"{'ARTIFACT':<{w_id}}  {'TYPE':<{w_type}}  {'BY':<{w_who}}  {'AT':<{w_when}}  REASON")
    print(f"{'-'*w_id}  {'-'*w_type}  {'-'*w_who}  {'-'*w_when}  {'-'*30}")
    for aid, atype, who, when, reason in rows:
        print(f"{aid:<{w_id}}  {atype:<{w_type}}  {who:<{w_who}}  {when:<{w_when}}  {reason}")
    return 0


def _cmd_audit_show(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc audit show <artifact-id>", file=sys.stderr)
        return 2
    artifact_id = argv[0]
    target = Path.cwd()
    audit_dir = target / "automation" / "audit"
    matches = list(audit_dir.glob(f"forced-skip-{artifact_id}*.yaml"))
    if not matches:
        print(f"[sdlc audit] audit entry not found for {artifact_id!r}", file=sys.stderr)
        return 1
    for f in matches:
        print(f"# {f.relative_to(target)}")
        print(f.read_text(encoding="utf-8"))
    return 0
