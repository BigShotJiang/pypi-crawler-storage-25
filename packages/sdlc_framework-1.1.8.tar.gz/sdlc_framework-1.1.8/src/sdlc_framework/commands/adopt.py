"""Retrofit SDLC framework on an existing project (`sdlc adopt`).

Detects existing assets (PRD, design docs, tests, CI workflows, runbooks,
SLO docs, etc.), lets the user claim them as evidence — auto-verifying
with the ``imported-from-existing`` marker — and configures
``legacy_code_globs`` so existing code is grandfathered out of TDD
enforcement. Idempotent.

Extracted from cli.py during the I2 phase 2 split.
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path


def scan_existing_assets(target: Path) -> dict:
    """Inventory existing project assets that map to SDLC phases."""
    found: dict[str, list[Path]] = {
        "prd": [],
        "requirements": [],
        "user_stories": [],
        "architecture": [],
        "api_spec": [],
        "db_schema": [],
        "ui_spec": [],
        "threat_model": [],
        "test_plan": [],
        "runbook": [],
        "slo": [],
        "incident_response": [],
        "ci_workflow": [],
        "src_files": [],
        "test_files": [],
    }
    for p in target.rglob("*.md"):
        if any(part in {".git", "node_modules", ".venv", "venv", "__pycache__",
                        "01-Planning", "02-Design", "04-Testing-Deploy"}
               for part in p.parts):
            continue
        name_lower = p.name.lower()
        if "prd" in name_lower or "product-req" in name_lower:
            found["prd"].append(p)
        if "requirement" in name_lower:
            found["requirements"].append(p)
        if "user-stor" in name_lower or "user_stor" in name_lower or "stories" in name_lower:
            found["user_stories"].append(p)
        if "architecture" in name_lower or name_lower in ("design.md", "system-design.md"):
            found["architecture"].append(p)
        if "api" in name_lower and ("spec" in name_lower or name_lower.endswith("-api.md")):
            found["api_spec"].append(p)
        if "schema" in name_lower or "database" in name_lower or "db" in name_lower.split(".")[0].split("-"):
            found["db_schema"].append(p)
        if "ui" in name_lower.split(".")[0].split("-") or "ux" in name_lower.split(".")[0].split("-"):
            found["ui_spec"].append(p)
        if "threat" in name_lower:
            found["threat_model"].append(p)
        if "test-plan" in name_lower or "testplan" in name_lower:
            found["test_plan"].append(p)
        if "runbook" in name_lower:
            found["runbook"].append(p)
        if "slo" in name_lower or "sli" in name_lower:
            found["slo"].append(p)
        if "incident" in name_lower:
            found["incident_response"].append(p)
    # OpenAPI specs
    for ext in ("yaml", "yml", "json"):
        for p in target.rglob(f"openapi.{ext}"):
            found["api_spec"].append(p)
    # CI workflows
    workflows_dir = target / ".github" / "workflows"
    if workflows_dir.exists():
        found["ci_workflow"] = list(workflows_dir.glob("*.yml")) + list(workflows_dir.glob("*.yaml"))
    # Source + test counts (rough)
    src_dir = target / "src"
    if src_dir.exists():
        for ext in ("ts", "tsx", "js", "jsx", "py", "go"):
            found["src_files"].extend(src_dir.rglob(f"*.{ext}"))
    for pattern in ("**/*.test.*", "**/*.spec.*", "**/test_*.py", "**/*_test.go"):
        for p in target.rglob(pattern):
            if any(part in {".git", "node_modules", ".venv", "venv"} for part in p.parts):
                continue
            found["test_files"].append(p)
    return found


def _link_or_copy(src: Path, dst: Path) -> str:
    """Symlink dst → src using a relative path; fall back to copy on Windows.

    Returns "symlink" or "copy" indicating which strategy was used.
    """
    dst.parent.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        shutil.copy2(src, dst)
        return "copy"
    rel_target = os.path.relpath(src, start=dst.parent)
    try:
        dst.symlink_to(rel_target)
        return "symlink"
    except OSError:
        shutil.copy2(src, dst)
        return "copy"


def _cmd_init(argv: list[str]) -> int:
    """Thin re-export — delegates to cli._cmd_init."""
    from sdlc_framework.cli import _cmd_init as _real_init
    return _real_init(argv)


def _cmd_verify(argv: list[str]) -> int:
    """Thin re-export — delegates to cli._cmd_verify."""
    from sdlc_framework.cli import _cmd_verify as _real_verify
    return _real_verify(argv)


def _dry_run_plan(target: Path, found: dict, dirty: bool) -> list[str]:
    """Return a list of human-readable lines describing what adopt would do."""
    from sdlc_framework.adopt_legacy_globs import detect_legacy_globs
    lines: list[str] = []
    if dirty:
        lines.append("⚠  working tree dirty — will skip touching source files")
    lines.append("✚  scaffold hierarchy dirs (01-Planning/epics, stories, "
                 "automation/{epics,stories,.epic-context,reviews,audit})")
    det = detect_legacy_globs(target)
    if det:
        lines.append(f"✚  set project.yaml legacy_code_globs ← {det}")
    if found["prd"]:
        lines.append(f"⤷  symlink {len(found['prd'])} PRD file(s) → 01-Planning/01-PRD.md + auto-verify")
    if found["architecture"]:
        lines.append(f"⤷  symlink {len(found['architecture'])} architecture file(s) "
                     "→ 02-Design/01-Architecture.md + auto-verify")
    if found["runbook"]:
        lines.append(f"⤷  symlink {len(found['runbook'])} runbook(s) "
                     "→ 04-Testing-Deploy/03-Deployment-Runbook.md + auto-verify")
    if found["slo"]:
        lines.append(f"⤷  symlink {len(found['slo'])} SLO doc(s) "
                     "→ 04-Testing-Deploy/04-Monitoring-SLO.md + auto-verify")
    if found["test_plan"]:
        lines.append(f"⤷  symlink {len(found['test_plan'])} test plan(s) "
                     "→ 04-Testing-Deploy/01-Test-Plan.md + auto-verify")
    return lines


def cmd_adopt(argv: list[str]) -> int:
    """Adopt SDLC framework on an existing running project.

    Detects existing assets, lets user claim them as evidence (auto-verifies
    with imported-from-existing marker), and configures legacy_code_globs.
    Idempotent.
    """
    # Ensure emoji in summary lines prints correctly on Windows consoles that
    # default to a narrow encoding (e.g. cp1252).
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(prog="sdlc adopt")
    parser.add_argument("--auto", action="store_true",
                        help="Non-interactive: accept all detected assets, mark all phases approved.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print plan, write nothing.")
    parser.add_argument("--rollback", action="store_true",
                        help="Undo a previous adopt run (reads automation/.adopt-manifest.json).")
    args = parser.parse_args(argv)

    if args.rollback:
        from sdlc_framework.adopt_manifest import (
            load_manifest, rollback as _rollback, delete_manifest, manifest_path,
        )
        target = Path.cwd()
        if not manifest_path(target).is_file():
            print("[sdlc adopt --rollback] no adopt manifest found.", file=__import__("sys").stderr)
            print("[sdlc adopt --rollback] nothing to roll back.", file=__import__("sys").stderr)
            return 1
        manifest = load_manifest(target)
        summary = _rollback(target, manifest)
        for line in summary:
            print(f"  {line}")
        delete_manifest(target)
        print(f"[sdlc adopt --rollback] reversed {len(manifest.actions)} action(s); "
              "manifest deleted.")
        return 0

    target = Path.cwd()

    print("[sdlc adopt] scanning your project for existing assets...")
    print()
    found = scan_existing_assets(target)

    # PR 9 — adopt enhancements: manifest + scaffold + legacy globs.
    from sdlc_framework.adopt_manifest import (
        load_manifest, save_manifest, AdoptManifest,
    )
    from sdlc_framework.adopt_scaffold import scaffold_hierarchy_dirs
    from sdlc_framework.adopt_legacy_globs import apply_legacy_globs
    from sdlc_framework.adopt_git_state import working_tree_dirty, is_ci_mode

    manifest = AdoptManifest()
    dirty = working_tree_dirty(target)
    if dirty:
        if is_ci_mode():
            print("[sdlc adopt] working tree dirty (CI mode auto-skip working-tree touches).",
                  file=sys.stderr)
        else:
            print("[sdlc adopt] WARNING: working tree has uncommitted changes.")
            print("[sdlc adopt] adopt will scaffold dirs/yaml only, NOT modify any source files.")

    summary = []
    if found["prd"]:
        summary.append(f"  📋 {len(found['prd'])} PRD-like file(s): " + ", ".join(p.name for p in found["prd"][:3]))
    if found["requirements"]:
        summary.append(f"  📋 {len(found['requirements'])} requirements file(s): " + ", ".join(p.name for p in found["requirements"][:3]))
    if found["user_stories"]:
        summary.append(f"  📋 {len(found['user_stories'])} user-story file(s)")
    if found["architecture"]:
        summary.append(f"  📐 {len(found['architecture'])} architecture file(s)")
    if found["api_spec"]:
        summary.append(f"  📐 {len(found['api_spec'])} API spec file(s)")
    if found["test_plan"]:
        summary.append(f"  🧪 {len(found['test_plan'])} test plan(s)")
    if found["runbook"]:
        summary.append(f"  🚀 {len(found['runbook'])} runbook(s)")
    if found["slo"]:
        summary.append(f"  📊 {len(found['slo'])} SLO doc(s)")
    if found["ci_workflow"]:
        summary.append(f"  ⚙️  {len(found['ci_workflow'])} CI workflow(s)")
    if found["src_files"]:
        ratio = len(found["test_files"]) / max(1, len(found["src_files"]))
        summary.append(f"  💻 {len(found['src_files'])} source files, {len(found['test_files'])} tests (TDD ratio {ratio:.2f})")

    if not summary:
        print("[sdlc adopt] no existing SDLC-like assets detected.")
        print("[sdlc adopt] If this is a brand-new project, run `sdlc setup` instead.")
        return 0

    print("Found:")
    for s in summary:
        print(s)
    print()

    if args.dry_run:
        plan = _dry_run_plan(target, found, dirty)
        print("[sdlc adopt] --dry-run plan:")
        for line in plan:
            print(f"  {line}")
        if not plan:
            print("  (nothing to do — already adopted)")
        print("[sdlc adopt] --dry-run — no files written.")
        return 0

    # Ensure scaffold is in place (idempotent — sdlc init won't overwrite).
    if not (target / "automation" / "rules.json").exists():
        print("[sdlc adopt] scaffolding base SDLC structure first (delegates to `sdlc init`)...")
        _cmd_init([])
        print()

    # Scaffold hierarchy dirs (idempotent — no-op on re-run).
    scaffold_hierarchy_dirs(target, manifest)

    # Extend legacy_code_globs in project.yaml.
    apply_legacy_globs(target, manifest)

    auto = args.auto

    # Per-phase prompts.
    def ask(prompt: str, default_yes: bool = True) -> bool:
        if auto:
            return True
        try:
            choice = input(f"{prompt} [{'Y/n' if default_yes else 'y/N'}] ").strip().lower()
        except EOFError:
            return default_yes
        if not choice:
            return default_yes
        return choice in ("y", "yes")

    # Phase 1.
    p1_assets = found["prd"] + found["requirements"] + found["user_stories"]
    if p1_assets and ask("Phase 1 — claim these planning artifacts as drafted+verified?"):
        for p in found["prd"]:
            dst = target / "01-Planning" / "01-PRD.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["prd-drafted", "--auto"])
            break  # one file is enough
        for p in found["requirements"]:
            dst = target / "01-Planning" / "03-Requirements-Spec.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["nfr-targets", "--auto"])
            break
        for p in found["user_stories"]:
            dst = target / "01-Planning" / "02-User-Stories.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["user-stories", "--auto"])
            break

    # Phase 2.
    p2_assets = found["architecture"] + found["api_spec"] + found["db_schema"]
    if p2_assets and ask("Phase 2 — claim these design artifacts as drafted+verified?"):
        for p in found["architecture"]:
            dst = target / "02-Design" / "01-Architecture.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["system-architecture", "--auto"])
            break
        for p in found["api_spec"]:
            dst = target / "02-Design" / "02-API-Spec.md"
            if not dst.exists() and p.suffix == ".md":
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["api-contract", "--auto"])
            break

    # Phase 3 — legacy code policy.
    if found["src_files"]:
        print()
        print("Phase 3 — you have existing code. How should the framework treat it?")
        print("  a) Mark all existing src/ as legacy (no TDD enforcement); new code goes through tasks")
        print("  b) Skip — manage tasks manually")
        if not auto:
            try:
                choice = input("> ").strip().lower()
            except EOFError:
                choice = "a"
        else:
            choice = "a"
        if choice in ("a", ""):
            # legacy_code_globs already applied via apply_legacy_globs() above.
            print("  [ok] legacy_code_globs configured in project.yaml (via adopt enhancements)")

    # Phase 4.
    if found["test_plan"] and ask("Phase 4 — claim test plan as drafted+verified?"):
        for p in found["test_plan"]:
            dst = target / "04-Testing-Deploy" / "01-Test-Plan.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["test-plan-published", "--auto"])
            break

    # Phase 5.
    p5_assets = found["runbook"] + found["slo"] + found["incident_response"] + found["ci_workflow"]
    if p5_assets and ask("Phase 5 — claim deploy/monitor artifacts as drafted+verified?"):
        for p in found["runbook"]:
            dst = target / "04-Testing-Deploy" / "03-Deployment-Runbook.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["deployment-runbook-ready", "--auto"])
            break
        for p in found["slo"]:
            dst = target / "04-Testing-Deploy" / "04-Monitoring-SLO.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["slo-targets-defined", "--auto"])
            break
        for p in found["incident_response"]:
            dst = target / "04-Testing-Deploy" / "05-Incident-Response.md"
            if not dst.exists():
                kind = _link_or_copy(p, dst)
                print(f"  [{kind}] {dst.relative_to(target)} ← {p.relative_to(target)}")
            _cmd_verify(["incident-response-ready", "--auto"])
            break

    # Render slash command surfaces for any AI tool already present.
    from sdlc_framework.commands.upgrade import detect_tool_surfaces
    tools = detect_tool_surfaces(target)
    if tools:
        from sdlc_framework.scaffold_gen import core as scaffold_gen
        from importlib import resources
        pkg_files = resources.files("sdlc_framework").joinpath("scaffold")
        with resources.as_file(pkg_files) as real_root:
            for t in tools:
                try:
                    written = scaffold_gen.render_for_tool(
                        t, scaffold_root=real_root, out_root=target,
                    )
                    print(f"  scaffold-gen [{t}]: rendered {len(written)} file(s)")
                except ValueError as e:
                    print(f"  scaffold-gen [{t}]: {e}")

    save_manifest(target, manifest)

    print()
    print("[sdlc adopt] done.")
    print("[sdlc adopt] run `sdlc resume` to see your starting point.")
    print("[sdlc adopt] run `sdlc next` to begin work on the next pending item.")
    return 0


