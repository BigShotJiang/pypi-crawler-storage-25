# src/sdlc_framework/commands/render_cmd.py
"""sdlc render-agents / render-commands CLI dispatchers."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def cmd_render_agents(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="sdlc render-agents")
    parser.add_argument(
        "--tool",
        choices=["claude", "copilot", "cursor"],
        default=None,
        help="Single tool to render (default: render all 3)",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="CI mode: compute expected output and diff against disk; exit 1 if drift",
    )
    args = parser.parse_args(argv)

    from sdlc_framework.render_agents import render_all_agents

    repo = Path.cwd()
    try:
        written, drift = render_all_agents(repo, tool=args.tool, check=args.check)
    except FileNotFoundError as e:
        print(f"[sdlc render-agents] {e}", file=sys.stderr)
        print("[sdlc render-agents] hint: canonical agents must live at automation/agents/*.md",
              file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"[sdlc render-agents] {e}", file=sys.stderr)
        return 2

    if args.check:
        if drift:
            print("[sdlc render-agents] --check failed; drift detected:", file=sys.stderr)
            for d in drift:
                print(f"   · {d}", file=sys.stderr)
            print("[sdlc render-agents] run `sdlc render-agents` to regenerate.",
                  file=sys.stderr)
            return 1
        print("[sdlc render-agents] --check ok; all renders match canonical")
        return 0

    print(f"[sdlc render-agents] wrote {len(written)} file(s)")
    return 0


def cmd_render_commands(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="sdlc render-commands")
    parser.add_argument(
        "--tool",
        choices=["claude", "copilot", "cursor"],
        default=None,
        help="Single tool to render (default: render all 3)",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="CI mode: compute expected output and diff against disk; exit 1 if drift",
    )
    args = parser.parse_args(argv)

    from sdlc_framework.render_commands import (
        check_commands_for_tool,
        write_commands_for_tool,
    )

    repo = Path.cwd()
    tools = (args.tool,) if args.tool else ("claude", "copilot", "cursor")

    if args.check:
        all_drift: list[str] = []
        for t in tools:
            ok, drift = check_commands_for_tool(repo, t)
            if not ok:
                all_drift.extend(drift)
        if all_drift:
            print("[sdlc render-commands] --check failed; drift detected:", file=sys.stderr)
            for d in all_drift:
                print(f"   · {d}", file=sys.stderr)
            print("[sdlc render-commands] run `sdlc render-commands` to regenerate.",
                  file=sys.stderr)
            return 1
        print("[sdlc render-commands] --check ok; all renders match canonical")
        return 0

    total_written = 0
    for t in tools:
        total_written += len(write_commands_for_tool(repo, t))
    print(f"[sdlc render-commands] wrote {total_written} file(s)")
    return 0
