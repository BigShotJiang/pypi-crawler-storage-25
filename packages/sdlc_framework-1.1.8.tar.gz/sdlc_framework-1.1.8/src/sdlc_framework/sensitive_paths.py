# src/sdlc_framework/sensitive_paths.py
"""Sensitive path/topic baseline + extend-only validator + detection helpers.

Spec reference: §8 ("--no-review single bypass flag + safety net").

Defaults are baked in; user `project.yaml` may extend (add) but not narrow
(remove). To intentionally replace defaults, the user must set
`sensitive_paths_strict_replace: true` (and similarly for topics) — this is
detected by `validate_baseline` and refused unless the replacement still
contains every baseline keyword.
"""
from __future__ import annotations

import fnmatch
import re
from pathlib import Path
from typing import Iterable

import yaml


BASELINE_PATHS: tuple[str, ...] = (
    "src/auth/**",
    "src/payment/**",
    "src/crypto/**",
    "src/secrets/**",
    "migrations/**",
    "infra/iam/**",
)


BASELINE_TOPICS: tuple[str, ...] = (
    "auth",
    "crypto",
    "payment",
    "secrets",
    "migrations",
    "webhooks",
)


class BaselineError(Exception):
    """Raised when project.yaml removes baseline keywords."""


def load_sensitive_config(target: Path) -> dict[str, list[str]]:
    """Return merged config: baseline ∪ user additions.

    Always includes baseline. Order: baseline first, then user additions
    (deduplicated, preserving insertion order).
    """
    user_paths: list[str] = []
    user_topics: list[str] = []
    p = target / "project.yaml"
    if p.exists():
        try:
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            data = {}
        if isinstance(data, dict):
            user_paths = list(data.get("sensitive_paths", []) or [])
            user_topics = list(data.get("sensitive_topics", []) or [])

    paths = list(BASELINE_PATHS)
    for entry in user_paths:
        if entry not in paths:
            paths.append(entry)
    topics = list(BASELINE_TOPICS)
    for entry in user_topics:
        if entry not in topics:
            topics.append(entry)
    return {"paths": paths, "topics": topics}


def validate_baseline(target: Path) -> None:
    """Refuse to start when user explicitly replaces and narrows the baseline.

    Default behavior is extend-only — even if a user lists `sensitive_paths`
    in project.yaml, baseline is still merged in by `load_sensitive_config`.
    The only way to actually narrow is to set
    `sensitive_paths_strict_replace: true` (or topics equivalent), which
    signals the user wants their list to *be* the full list. We then check
    they haven't dropped any baseline value.
    """
    p = target / "project.yaml"
    if not p.exists():
        return
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return
    if not isinstance(data, dict):
        return

    if data.get("sensitive_paths_strict_replace") is True:
        user_paths = set(data.get("sensitive_paths", []) or [])
        missing = set(BASELINE_PATHS) - user_paths
        if missing:
            raise BaselineError(
                "project.yaml `sensitive_paths_strict_replace: true` is set "
                f"but baseline paths are missing: {sorted(missing)}. "
                "The baseline is mandatory — re-add the missing entries or "
                "remove `sensitive_paths_strict_replace`."
            )
    if data.get("sensitive_topics_strict_replace") is True:
        user_topics = set(data.get("sensitive_topics", []) or [])
        missing = set(BASELINE_TOPICS) - user_topics
        if missing:
            raise BaselineError(
                "project.yaml `sensitive_topics_strict_replace: true` is set "
                f"but baseline topics are missing: {sorted(missing)}. "
                "The baseline is mandatory — re-add the missing entries or "
                "remove `sensitive_topics_strict_replace`."
            )


def detect_phase3(globs: Iterable[str], config: dict[str, list[str]]) -> list[str]:
    """Return the list of sensitive_paths matched by any glob in `globs`.

    Used for Phase 3 task creation: caller passes `code_glob` and `test_glob`.
    """
    matches: list[str] = []
    for sensitive_glob in config["paths"]:
        for user_glob in globs:
            if not user_glob:
                continue
            if _glob_overlaps(user_glob, sensitive_glob):
                if sensitive_glob not in matches:
                    matches.append(sensitive_glob)
    return matches


def detect_phase12(text: str, config: dict[str, list[str]]) -> list[str]:
    """Return the list of sensitive_topics keywords found in `text`.

    Used for Phase 1/2 artifact creation/verification: caller passes the
    title + body. Match is case-insensitive whole-word.
    """
    if not text:
        return []
    lowered = text.lower()
    matches: list[str] = []
    for kw in config["topics"]:
        if _whole_word_match(lowered, kw.lower()):
            matches.append(kw)
    return matches


# --- helpers -------------------------------------------------------------


def _glob_overlaps(user_glob: str, sensitive_glob: str) -> bool:
    """Return True when the user glob targets files inside the sensitive glob.

    Matching is conservative: we treat both as fnmatch patterns and check
    whether either pattern matches a representative path of the other.
    """
    if user_glob == sensitive_glob:
        return True
    user_clean = user_glob.replace("**", "*")
    sens_clean = sensitive_glob.replace("**", "*")
    # Use the directory prefix of the sensitive glob (everything before the
    # first wildcard) as the comparison anchor.
    anchor = sensitive_glob.split("*", 1)[0].rstrip("/")
    if anchor:
        if user_glob == anchor or user_glob.startswith(anchor + "/"):
            return True
    if fnmatch.fnmatch(user_clean, sens_clean) or fnmatch.fnmatch(sens_clean, user_clean):
        return True
    return False


def _whole_word_match(haystack: str, needle: str) -> bool:
    """Case-insensitive whole-word substring match."""
    pattern = r"(?<![A-Za-z0-9_])" + re.escape(needle) + r"(?![A-Za-z0-9_])"
    return bool(re.search(pattern, haystack))
