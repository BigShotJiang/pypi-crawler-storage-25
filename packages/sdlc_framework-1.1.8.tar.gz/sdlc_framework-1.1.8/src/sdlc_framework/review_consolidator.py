"""Aggregate review files into a consolidated verdict + summary.

Reviewers write `automation/reviews/<artifact>-<reviewer>-<ts>.md` files
with frontmatter `verdict: PASS | PASS_WITH_NOTES | BLOCK` and severity
counts. The consolidator:

1. Reads all review files for `<artifact>` (latest per reviewer if duplicates)
2. Aggregates verdicts:
   - ANY BLOCK -> VERDICT_BLOCK + writes clarification with STATUS: open
   - NO BLOCK + ANY PASS_WITH_NOTES -> VERDICT_PASS_WITH_NOTES
   - ALL PASS -> VERDICT_PASS
3. Writes `automation/reviews/<artifact>-summary-<ts>.md` with merged findings
4. Returns dict with verdict + counts for the engine
"""
from __future__ import annotations

import datetime as _dt
import re
from pathlib import Path

import yaml

VERDICT_PASS = "PASS"
VERDICT_PASS_WITH_NOTES = "PASS_WITH_NOTES"
VERDICT_BLOCK = "BLOCK"


class ConsolidatorError(Exception):
    """Raised when no review files exist or files are malformed."""


# Match `<prefix>-<ts>.md` where ts is the trailing digit run before `.md`.
# The prefix is `<artifact>-<reviewer>` (reviewer may contain hyphens).
_REVIEW_TS_PATTERN = re.compile(r"^(.+)-(\d+)\.md$")


def _parse_review_file(path: Path) -> dict:
    """Parse a review file's frontmatter; return dict with reviewer/verdict/counts."""
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        raise ConsolidatorError(f"malformed review file (no frontmatter): {path}")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ConsolidatorError(f"malformed frontmatter in: {path}")
    fm_text = text[4:end]
    try:
        fm = yaml.safe_load(fm_text) or {}
    except yaml.YAMLError as e:
        raise ConsolidatorError(f"yaml error in {path}: {e}") from e
    body = text[end + 5:]
    m = _REVIEW_TS_PATTERN.match(path.name)
    return {
        "path": path,
        "reviewer": fm.get("reviewer", "unknown"),
        "artifact": fm.get("artifact", ""),
        "verdict": fm.get("verdict", VERDICT_PASS),
        "critical": int(fm.get("critical", 0)),
        "high": int(fm.get("high", 0)),
        "medium": int(fm.get("medium", 0)),
        "low": int(fm.get("low", 0)),
        "ts": int(m.group(2)) if m else 0,
        "body": body,
    }


def _list_reviews_for(target: Path, artifact: str) -> list[dict]:
    """Find all review files for `artifact`. Latest per reviewer wins.

    Files follow `<artifact>-<reviewer>-<ts>.md`. The reviewer may contain
    hyphens (e.g. `code-reviewer`), so we cannot split safely from the
    filename alone. We glob `<artifact>-*-<digits>.md` and trust the
    frontmatter `artifact:` field when present; otherwise fall back to a
    filename prefix check.

    IMPORTANT: skip summary files (named `<artifact>-summary-<ts>.md`).
    """
    rdir = target / "automation" / "reviews"
    if not rdir.exists():
        return []
    found_by_reviewer: dict[str, dict] = {}
    for p in rdir.iterdir():
        if not p.is_file() or not p.name.endswith(".md"):
            continue
        m = _REVIEW_TS_PATTERN.match(p.name)
        if not m:
            continue
        prefix = m.group(1)  # artifact + "-" + reviewer
        # Skip summary files for this artifact
        if prefix == f"{artifact}-summary":
            continue
        # Filename must start with `<artifact>-` (cheap pre-filter)
        if not prefix.startswith(f"{artifact}-"):
            continue
        try:
            review = _parse_review_file(p)
        except ConsolidatorError:
            continue
        # Trust frontmatter artifact when present; else accept filename-prefix match.
        fm_artifact = review.get("artifact") or ""
        if fm_artifact and fm_artifact != artifact:
            continue
        # Defensive: skip if reviewer field literally == "summary"
        if review["reviewer"] == "summary":
            continue
        reviewer = review["reviewer"]
        if reviewer not in found_by_reviewer or review["ts"] > found_by_reviewer[reviewer]["ts"]:
            found_by_reviewer[reviewer] = review
    return list(found_by_reviewer.values())


def _utcnow_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _utcnow_ts() -> int:
    return int(_dt.datetime.now(_dt.timezone.utc).timestamp())


def consolidate(target: Path, artifact: str) -> dict:
    """Aggregate reviews for `artifact`. Writes summary + (on BLOCK) clarification.

    Returns: {"verdict": str, "block_count": int, "totals": {...}, "summary_path": Path, "reviewers": [...]}
    """
    reviews = _list_reviews_for(target, artifact)
    if not reviews:
        raise ConsolidatorError(f"no review files found for artifact: {artifact}")

    block_count = sum(1 for r in reviews if r["verdict"] == VERDICT_BLOCK)
    notes_count = sum(1 for r in reviews if r["verdict"] == VERDICT_PASS_WITH_NOTES)

    if block_count > 0:
        verdict = VERDICT_BLOCK
    elif notes_count > 0:
        verdict = VERDICT_PASS_WITH_NOTES
    else:
        verdict = VERDICT_PASS

    totals = {
        "critical": sum(r["critical"] for r in reviews),
        "high": sum(r["high"] for r in reviews),
        "medium": sum(r["medium"] for r in reviews),
        "low": sum(r["low"] for r in reviews),
    }

    rdir = target / "automation" / "reviews"
    rdir.mkdir(parents=True, exist_ok=True)
    ts = _utcnow_ts()
    summary_path = rdir / f"{artifact}-summary-{ts}.md"
    summary_lines = [
        "---",
        f"artifact: {artifact}",
        f"verdict: {verdict}",
        f"reviewers: {len(reviews)}",
        f"block_count: {block_count}",
        f"critical: {totals['critical']}",
        f"high: {totals['high']}",
        f"medium: {totals['medium']}",
        f"low: {totals['low']}",
        f"consolidated_at: {_utcnow_iso()}",
        "---",
        "",
        f"# Consolidated Review: {artifact}",
        "",
        f"**Verdict: {verdict}**",
        "",
        "## Per-reviewer findings",
        "",
    ]
    for r in sorted(reviews, key=lambda x: x["reviewer"]):
        summary_lines.append(f"### {r['reviewer']} - {r['verdict']}")
        summary_lines.append(
            f"critical: {r['critical']}, high: {r['high']}, "
            f"medium: {r['medium']}, low: {r['low']}"
        )
        summary_lines.append(f"_See {r['path'].name}_")
        summary_lines.append("")
    summary_path.write_text("\n".join(summary_lines), encoding="utf-8")

    if verdict == VERDICT_BLOCK:
        cdir = target / "automation" / "clarifications"
        cdir.mkdir(parents=True, exist_ok=True)
        existing = [f for f in cdir.glob("*.md") if f.name[:3].isdigit()]
        next_n = max((int(f.name[:3]) for f in existing), default=0) + 1
        clar_path = cdir / f"{next_n:03d}-{artifact}-review.md"
        clar_lines = [
            f"# Review pack BLOCKED: {artifact}",
            "",
            "STATUS: open",
            "",
            "**Phase**: review consolidation",
            f"**Artifact**: `{artifact}`",
            f"**Created at**: {_utcnow_iso()}",
            "",
            "## Why blocked",
            "",
            f"At least one reviewer returned BLOCK. Total: {block_count} block(s) "
            f"across {len(reviews)} reviewer(s).",
            "",
            "## Reviewer summary",
            "",
        ]
        for r in sorted(reviews, key=lambda x: x["reviewer"]):
            clar_lines.append(
                f"- **{r['reviewer']}**: {r['verdict']} "
                f"(critical={r['critical']}, high={r['high']})"
            )
        clar_lines.extend([
            "",
            "## What I need from user",
            "",
            "Resolve the BLOCK findings (see per-reviewer files in "
            f"`automation/reviews/{artifact}-*.md`). Once addressed, "
            "either re-run review pack or mark this clarification "
            "`STATUS: resolved` if the BLOCKs are deemed acceptable.",
            "",
            "## Will resume by",
            f"User changes STATUS to `resolved` or re-runs `sdlc review run {artifact}`.",
            "",
        ])
        clar_path.write_text("\n".join(clar_lines), encoding="utf-8")

    return {
        "verdict": verdict,
        "block_count": block_count,
        "totals": totals,
        "summary_path": summary_path,
        "reviewers": [r["reviewer"] for r in reviews],
    }
