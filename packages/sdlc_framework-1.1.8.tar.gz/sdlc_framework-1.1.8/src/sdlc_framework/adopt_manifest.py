# src/sdlc_framework/adopt_manifest.py
"""Adopt action manifest — records what `sdlc adopt` did so `--rollback` can undo it.

Stored at `automation/.adopt-manifest.json` (committed to git so rollback
works on fresh clones).
"""
from __future__ import annotations

import datetime as _dt
import hashlib as _hashlib
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path

import yaml as _yaml

MANIFEST_REL = "automation/.adopt-manifest.json"
MANIFEST_SCHEMA_VERSION = 1


@dataclass
class ManifestAction:
    kind: str  # "mkdir" | "write" | "symlink" | "yaml-add"
    path: str
    target: str | None = None
    sha256: str | None = None
    added_values: list[str] | None = None


@dataclass
class AdoptManifest:
    actions: list[ManifestAction] = field(default_factory=list)

    def record_mkdir(self, path: str) -> None:
        self.actions.append(ManifestAction(kind="mkdir", path=path))

    def record_write(self, path: str, *, sha256: str) -> None:
        self.actions.append(ManifestAction(kind="write", path=path, sha256=sha256))

    def record_symlink(self, path: str, *, target: str) -> None:
        self.actions.append(ManifestAction(kind="symlink", path=path, target=target))

    def record_yaml_add(
        self, path: str, *, key: str, added_values: list[str],
    ) -> None:
        self.actions.append(ManifestAction(
            kind="yaml-add",
            path=path,
            target=key,
            added_values=list(added_values),
        ))


def manifest_path(target: Path) -> Path:
    return target / MANIFEST_REL


def load_manifest(target: Path) -> AdoptManifest:
    p = manifest_path(target)
    if not p.exists():
        return AdoptManifest()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return AdoptManifest()
    actions = [ManifestAction(**a) for a in data.get("actions", [])]
    return AdoptManifest(actions=actions)


def save_manifest(target: Path, manifest: AdoptManifest) -> Path:
    p = manifest_path(target)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "saved_at": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "actions": [_action_to_dict(a) for a in manifest.actions],
    }
    p.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return p


def _action_to_dict(a: ManifestAction) -> dict:
    """Drop None fields so the json stays compact + readable."""
    d = asdict(a)
    return {k: v for k, v in d.items() if v is not None}


def rollback(target: Path, manifest: AdoptManifest) -> list[str]:
    """Undo every action in `manifest` in reverse order.

    Returns a list of human-readable summary lines describing what was
    undone. Refuses to remove files whose sha256 no longer matches the
    recorded value (user-modified files are left intact and reported).
    """
    summary: list[str] = []
    target_resolved = target.resolve()
    for a in reversed(manifest.actions):
        p = target / a.path
        # Defense-in-depth: refuse to touch paths that escape the target dir.
        # Manifest is normally repo-generated, but a malicious PR could inject
        # `../../etc/passwd` with a forged sha256 that happens to match.
        try:
            p_resolved = p.resolve()
        except (OSError, RuntimeError):
            summary.append(f"skip   {a.path} (resolve failed)")
            continue
        if not str(p_resolved).startswith(str(target_resolved) + os.sep) \
                and p_resolved != target_resolved:
            summary.append(f"skip   {a.path} (escapes target dir)")
            continue
        if a.kind == "mkdir":
            try:
                if p.is_dir() and not any(p.iterdir()):
                    p.rmdir()
                    summary.append(f"rmdir  {a.path}")
                else:
                    summary.append(f"keep   {a.path} (not empty)")
            except OSError:
                summary.append(f"keep   {a.path} (rmdir failed)")
        elif a.kind == "write":
            if not p.is_file():
                summary.append(f"miss   {a.path} (already gone)")
                continue
            text = p.read_text(encoding="utf-8", errors="replace")
            digest = _hashlib.sha256(text.encode("utf-8")).hexdigest()
            if digest == a.sha256:
                p.unlink()
                summary.append(f"rm     {a.path}")
            else:
                summary.append(f"keep   {a.path} (modified by user)")
        elif a.kind == "symlink":
            if p.is_symlink():
                p.unlink()
                summary.append(f"unlink {a.path}")
            else:
                summary.append(f"keep   {a.path} (no longer a symlink)")
        elif a.kind == "yaml-add":
            if not p.is_file():
                summary.append(f"miss   {a.path}")
                continue
            try:
                data = _yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            except _yaml.YAMLError:
                summary.append(f"keep   {a.path} (yaml parse error)")
                continue
            if not isinstance(data, dict) or a.target not in data:
                summary.append(f"keep   {a.path} (key missing)")
                continue
            current = data.get(a.target) or []
            if not isinstance(current, list):
                summary.append(f"keep   {a.path}:{a.target} (not a list)")
                continue
            new = [v for v in current if v not in (a.added_values or [])]
            if new == current:
                summary.append(f"keep   {a.path}:{a.target} (values not present)")
                continue
            if new:
                data[a.target] = new
            else:
                del data[a.target]
            p.write_text(
                _yaml.safe_dump(data, sort_keys=False, allow_unicode=True),
                encoding="utf-8",
            )
            summary.append(
                f"yaml   {a.path}:{a.target} -= {a.added_values}"
            )
    return summary


def delete_manifest(target: Path) -> None:
    """Remove the manifest file itself after rollback."""
    p = manifest_path(target)
    if p.is_file():
        p.unlink()
