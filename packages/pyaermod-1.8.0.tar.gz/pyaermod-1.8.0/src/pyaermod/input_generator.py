"""
PyAERMOD Input File Generator

Generates AERMOD-compatible input files from Python objects.
Based on AERMOD version 24142 keyword specifications.

.. note::

   As of v1.6.0 the dataclasses that used to live in this single file
   have been split into focused submodules:

   * :mod:`pyaermod.pathways` -- enums, chemistry options, Control / Met /
     Output / Event pathways
   * :mod:`pyaermod.sources` -- deposition helpers, building-downwash
     helpers, all source dataclasses, SourcePathway
   * :mod:`pyaermod.receptors` -- CartesianGrid, PolarGrid,
     DiscreteReceptor, ReceptorPathway

   This module re-exports every public name so that existing imports
   (``from pyaermod.input_generator import X``) continue to work
   unchanged.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

# ---- Re-export everything from the new submodules --------------------------
from .pathways import (  # noqa: F401  -- re-exports
    ChemistryMethod,
    ChemistryOptions,
    ControlPathway,
    EventPathway,
    EventPeriod,
    MeteorologyPathway,
    OutputPathway,
    OzoneData,
    PollutantType,
    SourceType,
    TerrainType,
)
from .receptors import (  # noqa: F401  -- re-exports
    CartesianGrid,
    DiscreteReceptor,
    PolarGrid,
    ReceptorPathway,
)
from .sources import (  # noqa: F401  -- re-exports
    AreaCircSource,
    AreaPolySource,
    AreaSource,
    BackgroundConcentration,
    BackgroundSector,
    BuoyLineSegment,
    BuoyLineSource,
    DepositionMethod,
    GasDepositionParams,
    LineSource,
    OpenPitSource,
    ParticleDepositionParams,
    PointSource,
    RLineExtSource,
    RLineSource,
    SourceGroupDefinition,
    SourcePathway,
    StreetCanyon,
    VolumeSource,
    _building_downwash_lines,
    _deposition_to_aermod_lines,
    _format_building_keyword,
    _set_building_from_bpip,
)

# ============================================================================
# MAIN PROJECT CLASS
# ============================================================================

@dataclass
class AERMODProject:
    """
    Complete AERMOD project

    Combines all pathways into a single input file.
    """
    control: ControlPathway
    sources: SourcePathway
    receptors: ReceptorPathway
    meteorology: MeteorologyPathway
    output: OutputPathway
    events: Optional[EventPathway] = None

    def to_aermod_input(self,
                        validate: Optional[bool] = None,
                        check_files: bool = False) -> str:
        """
        Generate complete AERMOD input file.

        Parameters
        ----------
        validate : bool, optional
            If True, run the configuration validator before generating
            output. Raises ValueError on validation errors (warnings
            are allowed). If False, skip validation entirely.

            If None (the v1.x default), behave like False but emit a
            DeprecationWarning. Starting in pyaermod 2.0 the default
            will flip to True so callers who don't specify get
            structurally-invalid projects caught at write time. Pass
            ``validate=True`` or ``validate=False`` explicitly to silence
            the warning.
        check_files : bool
            If True (and validate is True), also verify that meteorology
            files exist on disk.
        """
        if validate is None:
            import warnings
            warnings.warn(
                "AERMODProject.to_aermod_input() is being called without "
                "specifying `validate=`. In pyaermod 2.0 the default flips "
                "from False to True (validate before write); pass "
                "validate=True to opt in early or validate=False to keep "
                "the current silent behavior and silence this warning.",
                DeprecationWarning,
                stacklevel=2,
            )
            validate = False  # preserve v1.x default behavior

        if validate:
            from pyaermod.validator import Validator
            result = Validator.validate(self, check_files=check_files)
            if not result.is_valid:
                raise ValueError(str(result))

        # Pass chemistry options to SO pathway for OLMGROUP emission
        chemistry = getattr(self.control, "chemistry", None)

        sections = [
            self.control.to_aermod_input(),
            "",
            self.sources.to_aermod_input(chemistry=chemistry),
            "",
            self.receptors.to_aermod_input(),
            "",
            self.meteorology.to_aermod_input(),
            "",
            self.output.to_aermod_input()
        ]
        return "\n".join(sections)

    def write(self, filename: Union[str, Path],
              event_filename: Optional[Union[str, Path]] = None,
              validate: Optional[bool] = None,
              check_files: bool = False):
        """Write input file to disk.

        Parameters
        ----------
        filename : str or Path
            Path for the main AERMOD input file.
        event_filename : str or Path, optional
            Path for the event file. Required if events are defined.
        validate : bool, optional
            Forwarded to :meth:`to_aermod_input`. Same semantics —
            if None, defaults to False with a DeprecationWarning;
            pyaermod 2.0 will flip to True.
        check_files : bool
            Forwarded to :meth:`to_aermod_input`.
        """
        output_path = Path(filename)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # write() called without specifying `validate` is the most
        # common path; pass through so the deprecation warning surfaces
        # at the user's call site rather than inside our writer.
        with open(output_path, 'w') as f:
            f.write(self.to_aermod_input(validate=validate,
                                         check_files=check_files))

        if self.events and event_filename:
            event_path = Path(event_filename)
            with open(event_path, 'w') as f:
                f.write(self.events.to_aermod_input())

        return output_path


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

def create_example_project() -> AERMODProject:
    """Create an example AERMOD project"""

    # Control pathway
    control = ControlPathway(
        title_one="Example AERMOD Project",
        title_two="Generated by pyaermod",
        pollutant_id=PollutantType.PM25,
        averaging_periods=["ANNUAL", "24", "1"],
        terrain_type=TerrainType.FLAT
    )

    # Sources
    sources = SourcePathway()

    stack1 = PointSource(
        source_id="STACK1",
        x_coord=500.0,
        y_coord=500.0,
        base_elevation=10.0,
        stack_height=50.0,
        stack_temp=400.0,  # Kelvin
        exit_velocity=15.0,  # m/s
        stack_diameter=2.0,  # m
        emission_rate=1.5,  # g/s
        source_groups=["ALL"]
    )
    sources.add_source(stack1)

    # Receptors - Cartesian grid
    receptors = ReceptorPathway()

    grid = CartesianGrid.from_bounds(
        x_min=0.0,
        x_max=2000.0,
        y_min=0.0,
        y_max=2000.0,
        spacing=100.0
    )
    receptors.add_cartesian_grid(grid)

    # Meteorology
    meteorology = MeteorologyPathway(
        surface_file="example.sfc",
        profile_file="example.pfl",
        start_year=2023,
        start_month=1,
        start_day=1,
        end_year=2023,
        end_month=12,
        end_day=31
    )

    # Output
    output = OutputPathway(
        receptor_table=True,
        receptor_table_rank=10,
        max_table=True,
        summary_file="example.sum"
    )

    return AERMODProject(
        control=control,
        sources=sources,
        receptors=receptors,
        meteorology=meteorology,
        output=output
    )


if __name__ == "__main__":
    # Create example project
    project = create_example_project()

    # Print to console
    print(project.to_aermod_input())

    # Or write to file
    # project.write("example.inp")
