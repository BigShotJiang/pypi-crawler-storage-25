import sys
from .main import recursive_copy_with_progress

def main():
    if len(sys.argv) < 4:
        print('Usage: python -m path2success recursive_copy_with_progress SOURCE_PATH DESTINATION_PATH\n')
        sys.exit(1)

    COMMAND = sys.argv[1]

    if COMMAND == 'recursive_copy_with_progress':
        SOURCE_PATH = sys.argv[2]
        DESTINATION_PATH = sys.argv[3]
        recursive_copy_with_progress(SOURCE_PATH, DESTINATION_PATH)
    else:
        print(f'Unknown command: {COMMAND}')
        sys.exit(1)

if __name__ == '__main__':
    main()