"""
NetGreener CLI entry point.

Commands:
  netgreener login             ; authenticate and persist token
  netgreener logout            ; clear stored credentials
  netgreener run <script> <dir>; run a script with full analysis and reporting
  netgreener analyze <dir>     ; analyze code without running (upload patterns/features)
  netgreener estimate [dir]    ; estimate KPIs pre-run using LLM (Phase 7)
  netgreener status            ; show current login status
  netgreener config            ; show/set API server URL
  netgreener features metadata ; register / view Parquet path for a project (API v1)
  netgreener features inputs   ; CRUD featurecollectioninput rows
  netgreener features definitions; CRUD featuredefinition rows
"""

import getpass
import json
import os
import platform
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import click

import threading

from .api_client import NetGreenerClient, APIError
from .config import (
    DASHBOARD_URL,
    SUPPORTED_LLM_PROVIDERS,
    clear_credentials,
    clear_user_llm_config,
    get_api_url,
    get_byok_llm_config_error,
    get_merged_llm_profile,
    load_credentials,
    save_api_url,
    save_credentials,
    save_user_llm_config,
    user_byok_llm_ready,
)
from .constants import CO2_KG_PER_KWH
from .reporter import console, print_error, print_info, print_login_success, print_run_report

# Library domains that indicate an AI/data project requiring a data path for full CNN feature extraction
_ML_DATA_DOMAINS = {"deep_learning", "machine_learning", "computer_vision", "nlp"}


def _collect_cicd_context() -> dict:
    """Detect CI/CD platform from environment variables and return metadata dict."""
    env = os.environ
    if env.get("GITHUB_ACTIONS"):
        return {
            "ci_platform": "github_actions",
            "ci_branch": env.get("GITHUB_REF_NAME"),
            "ci_commit": env.get("GITHUB_SHA"),
            "ci_pipeline_id": env.get("GITHUB_RUN_ID"),
            "ci_pr": env.get("GITHUB_PR_NUMBER"),
            "ci_actor": env.get("GITHUB_ACTOR"),
            "ci_repo": env.get("GITHUB_REPOSITORY"),
        }
    if env.get("TF_BUILD"):  # Azure DevOps
        return {
            "ci_platform": "azure_devops",
            "ci_branch": env.get("BUILD_SOURCEBRANCH"),
            "ci_commit": env.get("BUILD_SOURCEVERSION"),
            "ci_pipeline_id": env.get("BUILD_BUILDID"),
            "ci_pr": env.get("SYSTEM_PULLREQUEST_PULLREQUESTID"),
            "ci_actor": env.get("BUILD_REQUESTEDFOR"),
            "ci_repo": env.get("BUILD_REPOSITORY_NAME"),
        }
    if env.get("GITLAB_CI"):
        return {
            "ci_platform": "gitlab_ci",
            "ci_branch": env.get("CI_COMMIT_BRANCH"),
            "ci_commit": env.get("CI_COMMIT_SHA"),
            "ci_pipeline_id": env.get("CI_PIPELINE_ID"),
            "ci_pr": env.get("CI_MERGE_REQUEST_IID"),
            "ci_actor": env.get("CI_COMMIT_AUTHOR"),
            "ci_repo": env.get("CI_PROJECT_NAME"),
        }
    if env.get("JENKINS_URL"):
        return {
            "ci_platform": "jenkins",
            "ci_branch": env.get("GIT_BRANCH"),
            "ci_commit": env.get("GIT_COMMIT"),
            "ci_pipeline_id": env.get("BUILD_ID"),
            "ci_pr": None,
            "ci_actor": env.get("BUILD_USER"),
            "ci_repo": env.get("JOB_NAME"),
        }
    if env.get("CIRCLECI"):
        return {
            "ci_platform": "circleci",
            "ci_branch": env.get("CIRCLE_BRANCH"),
            "ci_commit": env.get("CIRCLE_SHA1"),
            "ci_pipeline_id": env.get("CIRCLE_WORKFLOW_ID"),
            "ci_pr": env.get("CIRCLE_PULL_REQUEST"),
            "ci_actor": env.get("CIRCLE_USERNAME"),
            "ci_repo": env.get("CIRCLE_PROJECT_REPONAME"),
        }
    return {}


def _file_features_from_project_summary(
    project_summary: dict[str, Any],
    project_path: Path,
    script_path: Path,
) -> dict[str, Any]:
    """Return per-file features for SCRIPT from analyze_project() cache if present."""
    per_file = project_summary.get("per_file", []) if project_summary else []
    if not isinstance(per_file, list):
        return {}
    try:
        rel = str(script_path.relative_to(project_path))
        rel_candidates = {rel, rel.replace("\\", "/")}
    except ValueError:
        # script is outside the project directory; no per-file features available
        return {}
    for entry in per_file:
        if not isinstance(entry, dict):
            continue
        rel_path = str(entry.get("rel_path", ""))
        if rel_path in rel_candidates:
            feats = entry.get("features", {})
            return feats if isinstance(feats, dict) else {}
    return {}


def _llm_credentials_available() -> bool:
    """True if LLM calls can be attempted (dual BYOK, or logged-in server path, or OPENAI_API_KEY)."""
    if get_byok_llm_config_error():
        return False
    if user_byok_llm_ready():
        return True
    if os.environ.get("OPENAI_API_KEY", "").strip():
        return True
    return bool(load_credentials())


def _require_valid_byok_or_exit() -> None:
    err = get_byok_llm_config_error()
    if err:
        print_error(err)
        raise SystemExit(1)


def _print_quality_summary(
    findings: list[dict[str, Any]], semantic_dangers: dict[str, Any]
) -> None:
    """Print compact findings + semantic/security snapshot for CLI users."""
    total = len(findings)
    security_hits = sum(1 for f in findings if f.get("issue_type") == "hardcoded_secret")
    present_dangers = 0
    if isinstance(semantic_dangers, dict):
        dangers = semantic_dangers.get("dangers", [])
        if isinstance(dangers, list):
            present_dangers = sum(
                1 for d in dangers if isinstance(d, dict) and d.get("present") is True
            )

    console.print("\n[bold]Quality Snapshot[/]")
    console.print(f"  findings                   : [cyan]{total}[/]")
    console.print(f"  semantic dangers (present) : [cyan]{present_dangers}[/]")
    console.print(f"  security (hardcoded secret): [cyan]{security_hits}[/]")

    if findings:
        top = Counter(str(f.get("issue_type", "unknown")) for f in findings).most_common(4)
        top_str = ", ".join(f"{name} x{count}" for name, count in top)
        console.print(f"  top findings               : [dim]{top_str}[/]")


@click.group()
def main() -> None:
    """NetGreener; measure energy, carbon, and code quality of your ML runs."""


# ---------------------------------------------------------------------------
# login / logout / status
# ---------------------------------------------------------------------------


@main.command()
@click.option("--email", prompt="Email", help="Your NetGreener account email.")
@click.option(
    "--password",
    default=None,
    help="Your password (prompted if omitted).",
)
@click.option("--api-url", default=None, help="Override API server URL.")
def login(email: str, password: str | None, api_url: str | None) -> None:
    """Authenticate and store credentials locally."""
    if api_url:
        save_api_url(api_url)

    if password is None:
        password = getpass.getpass("Password: ")

    client = NetGreenerClient()
    try:
        data = client.login(email, password)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)

    save_credentials(data["access_token"], data["user"])
    print_login_success(data["user"])


@main.command()
def logout() -> None:
    """Clear stored credentials."""
    clear_credentials()
    print_info("Logged out.")


@main.command()
def status() -> None:
    """Show current login status."""
    creds = load_credentials()
    if not creds:
        print_info(f"Not logged in.  API: {get_api_url()}")
        return
    user = creds.get("user", {})
    print_login_success(user)
    print_info(f"API: {get_api_url()}")


# ---------------------------------------------------------------------------
# config
# ---------------------------------------------------------------------------


@main.command("config")
@click.argument("api_url", required=False)
def config_cmd(api_url: str | None) -> None:
    """Show or set the API server URL.

    \b
    Examples:
      netgreener config
      netgreener config https://netgreener.example.com
    """
    if api_url:
        save_api_url(api_url)
        print_info(f"API URL set to: {api_url}")
    else:
        print_info(f"API URL: {get_api_url()}")


# ---------------------------------------------------------------------------
# llm-config; set / show / clear user LLM credentials
# ---------------------------------------------------------------------------


@main.command("llm-config")
@click.option(
    "--profile",
    "profile",
    type=click.Choice(["large", "mini"]),
    default="large",
    show_default=True,
    help="Which BYOK profile to set (large = heavy NLP; mini = lighter semantic analysis).",
)
@click.option(
    "--provider",
    default=None,
    type=click.Choice(list(SUPPORTED_LLM_PROVIDERS), case_sensitive=False),
    help="LLM provider (azure_openai | openai | anthropic | ollama | custom).",
)
@click.option("--key", default=None, help="API key (not required for ollama).")
@click.option(
    "--endpoint",
    default=None,
    help="Base URL / Azure endpoint (e.g. https://my-resource.openai.azure.com/ or http://localhost:11434).",
)
@click.option(
    "--model",
    default=None,
    help="Model or deployment name (e.g. gpt-4o, claude-3-5-sonnet-20241022).",
)
@click.option(
    "--clear", "do_clear", is_flag=True, default=False, help="Remove stored LLM credentials."
)
@click.option(
    "--clear-profile",
    "clear_profile",
    type=click.Choice(["large", "mini"]),
    default=None,
    help="With --clear, remove only this profile (default: clear both).",
)
def llm_config_cmd(
    profile: str,
    provider: str | None,
    key: str | None,
    endpoint: str | None,
    model: str | None,
    do_clear: bool,
    clear_profile: str | None,
) -> None:
    """Set, show, or clear user LLM credentials (BYOK: both large + mini required).

    \b
    Bring-your-own-key: if you set any field for custom LLMs, you must configure
    **both** profiles (large and mini). Env vars:
      Large: NETGREENER_LLM_PROVIDER, NETGREENER_LLM_KEY, NETGREENER_LLM_ENDPOINT, NETGREENER_LLM_MODEL
      Mini:  NETGREENER_LLM_MINI_PROVIDER, NETGREENER_LLM_MINI_KEY, NETGREENER_LLM_MINI_ENDPOINT, NETGREENER_LLM_MINI_MODEL

    \b
    Examples:
      netgreener llm-config --profile large --provider openai --key sk-xxx --model gpt-4o
      netgreener llm-config --profile mini --provider openai --key sk-xxx --model gpt-4o-mini
      netgreener llm-config --clear
      netgreener llm-config
    """
    if do_clear:
        if clear_profile:
            clear_user_llm_config(clear_profile)  # type: ignore[arg-type]
            print_info(f"LLM profile [cyan]{clear_profile}[/] cleared from config file.")
        else:
            clear_user_llm_config(None)
            print_info("All LLM credentials cleared from config file.")
        return

    if provider or key or endpoint or model:
        if not provider:
            raise click.UsageError("--provider is required when setting LLM credentials.")
        if not model:
            raise click.UsageError("--model is required when setting LLM credentials.")
        save_user_llm_config(
            profile=profile,  # type: ignore[arg-type]
            provider=provider,
            key=key or "",
            endpoint=endpoint or "",
            model=model,
        )
        print_info(
            f"LLM profile [cyan]{profile}[/] saved: provider=[cyan]{provider}[/], model=[cyan]{model}[/]."
        )
        return

    # Show current config
    err = get_byok_llm_config_error()
    if err:
        console.print(f"[yellow]{err}[/]")

    def _print_prof(title: str, p: dict[str, str]) -> None:
        console.print(f"[bold]{title}[/] (config.json / env):")
        console.print(f"  provider : [cyan]{p['provider'] or '(not set)'}[/]")
        console.print(f"  model    : [cyan]{p['model'] or '(not set)'}[/]")
        console.print(f"  endpoint : [cyan]{p['endpoint'] or '(not set)'}[/]")
        console.print(
            f"  key      : [dim]{'(set)' if (p.get('key') or '').strip() else '(not set)'}[/]"
        )

    large_m = get_merged_llm_profile("large")
    mini_m = get_merged_llm_profile("mini")
    _print_prof("Large LLM", large_m)
    console.print()
    _print_prof("Mini LLM", mini_m)

    if not err and user_byok_llm_ready():
        print_info("BYOK: both profiles complete.")
    elif not err:
        print_info("No BYOK fields set; using server default for LLM (requires login).")


# ---------------------------------------------------------------------------
# features; project feature metadata (Parquet path registration)
# ---------------------------------------------------------------------------


@main.group("features")
def features_cli() -> None:
    """Feature registry helpers (subset of /api/v1/features)."""


@features_cli.group("metadata")
def feature_metadata_cli() -> None:
    """Register or inspect on-disk feature Parquet path per project.

    Writes require API role developer or admin. Reads require project access.
    """


@feature_metadata_cli.command("get")
@click.argument("project_id", type=int)
def feature_metadata_get(project_id: int) -> None:
    """GET feature metadata row for PROJECT_ID (404 if none)."""
    try:
        client = NetGreenerClient.from_credentials()
        data = client.get_project_feature_metadata(project_id)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_metadata_cli.command("register")
@click.argument("project_id", type=int)
@click.option(
    "--parquet-path",
    required=True,
    help="Path or URI to the Parquet (or other) artifact.",
)
@click.option(
    "--feature-version",
    type=int,
    default=None,
    help="Feature schema version (default 1 on server).",
)
def feature_metadata_register(
    project_id: int, parquet_path: str, feature_version: int | None
) -> None:
    """POST a new metadata row (409 if one already exists; use update)."""
    payload: dict[str, Any] = {"parquet_path": parquet_path}
    if feature_version is not None:
        payload["feature_version"] = feature_version
    try:
        client = NetGreenerClient.from_credentials()
        data = client.post_project_feature_metadata(project_id, payload)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_metadata_cli.command("update")
@click.argument("project_id", type=int)
@click.option("--parquet-path", default=None, help="New path or URI.")
@click.option("--feature-version", type=int, default=None, help="New feature schema version.")
def feature_metadata_update(
    project_id: int,
    parquet_path: str | None,
    feature_version: int | None,
) -> None:
    """PUT changes to an existing row (at least one of --parquet-path / --feature-version)."""
    if parquet_path is None and feature_version is None:
        raise click.UsageError("Provide at least one of --parquet-path or --feature-version")
    payload: dict[str, Any] = {}
    if parquet_path is not None:
        payload["parquet_path"] = parquet_path
    if feature_version is not None:
        payload["feature_version"] = feature_version
    try:
        client = NetGreenerClient.from_credentials()
        data = client.put_project_feature_metadata(project_id, payload)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_metadata_cli.command("delete")
@click.argument("project_id", type=int)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
def feature_metadata_delete(project_id: int, yes: bool) -> None:
    """DELETE the metadata row for PROJECT_ID."""
    if not yes:
        click.confirm(
            f"Delete feature metadata for project_id={project_id}?",
            abort=True,
        )
    try:
        client = NetGreenerClient.from_credentials()
        data = client.delete_project_feature_metadata(project_id)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


# ---------------------------------------------------------------------------
# features inputs; feature collection input CRUD
# ---------------------------------------------------------------------------


@features_cli.group("inputs")
def feature_inputs_cli() -> None:
    """CRUD for /features/inputs and /features/project/{project_id}/inputs."""


@feature_inputs_cli.command("list")
@click.option("--project-id", type=int, default=None, help="Filter by project_id.")
@click.option("--feature-name", default=None, help="Filter by feature_name.")
@click.option("--entered-by-user-id", type=int, default=None, help="Filter by entered_by_user_id.")
def feature_inputs_list(
    project_id: int | None,
    feature_name: str | None,
    entered_by_user_id: int | None,
) -> None:
    """List feature collection inputs with optional filters."""
    try:
        client = NetGreenerClient.from_credentials()
        data = client.get_feature_collection_inputs(
            project_id=project_id,
            feature_name=feature_name,
            entered_by_user_id=entered_by_user_id,
        )
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_inputs_cli.command("list-project")
@click.argument("project_id", type=int)
def feature_inputs_list_project(project_id: int) -> None:
    """List feature inputs for one project via /features/project/{project_id}/inputs."""
    try:
        client = NetGreenerClient.from_credentials()
        data = client.list_project_feature_collection_inputs(project_id)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_inputs_cli.command("get")
@click.argument("input_id", type=int)
def feature_inputs_get(input_id: int) -> None:
    """Get one feature collection input by input_id."""
    try:
        client = NetGreenerClient.from_credentials()
        data = client.get_feature_collection_input(input_id)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_inputs_cli.command("create")
@click.argument("project_id", type=int)
@click.option("--feature-name", required=True, help="Feature definition name.")
@click.option("--value", required=True, help="Feature value as text/JSON string.")
@click.option("--input-timestamp", default=None, help="Optional ISO-8601 timestamp.")
@click.option("--entered-by-user-id", type=int, default=None, help="Optional explicit user id.")
def feature_inputs_create(
    project_id: int,
    feature_name: str,
    value: str,
    input_timestamp: str | None,
    entered_by_user_id: int | None,
) -> None:
    """Create a feature collection input row."""
    payload: dict[str, Any] = {
        "project_id": project_id,
        "feature_name": feature_name,
        "value": value,
    }
    if input_timestamp is not None:
        payload["input_timestamp"] = input_timestamp
    if entered_by_user_id is not None:
        payload["entered_by_user_id"] = entered_by_user_id
    try:
        client = NetGreenerClient.from_credentials()
        data = client.post_feature_collection_input(payload)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_inputs_cli.command("update")
@click.argument("input_id", type=int)
@click.option("--value", default=None, help="New value.")
@click.option("--input-timestamp", default=None, help="Optional ISO-8601 timestamp.")
def feature_inputs_update(
    input_id: int,
    value: str | None,
    input_timestamp: str | None,
) -> None:
    """Update feature input fields."""
    if value is None and input_timestamp is None:
        raise click.UsageError("Provide at least one of --value or --input-timestamp")
    payload: dict[str, Any] = {}
    if value is not None:
        payload["value"] = value
    if input_timestamp is not None:
        payload["input_timestamp"] = input_timestamp
    try:
        client = NetGreenerClient.from_credentials()
        data = client.update_feature_collection_input(input_id, payload)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_inputs_cli.command("delete")
@click.argument("input_id", type=int)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
def feature_inputs_delete(input_id: int, yes: bool) -> None:
    """Delete one feature collection input."""
    if not yes:
        click.confirm(f"Delete feature input input_id={input_id}?", abort=True)
    try:
        client = NetGreenerClient.from_credentials()
        data = client.delete_feature_collection_input(input_id)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


# ---------------------------------------------------------------------------
# features definitions; feature definition CRUD
# ---------------------------------------------------------------------------


@features_cli.group("definitions")
def feature_definitions_cli() -> None:
    """CRUD for /features/definitions."""


@feature_definitions_cli.command("list")
@click.option("--data-type", default=None, help="Filter by data_type (int|float|boolean|string).")
@click.option("--source-type", default=None, help="Filter by source_type (code|data|run_session).")
def feature_definitions_list(data_type: str | None, source_type: str | None) -> None:
    """List feature definitions with optional filters."""
    try:
        client = NetGreenerClient.from_credentials()
        data = client.list_feature_definitions(data_type=data_type, source_type=source_type)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_definitions_cli.command("get")
@click.argument("feature_name")
def feature_definitions_get(feature_name: str) -> None:
    """Get one feature definition by feature_name."""
    try:
        client = NetGreenerClient.from_credentials()
        data = client.get_feature_definition(feature_name)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_definitions_cli.command("create")
@click.argument("feature_name")
@click.option("--description", default=None, help="Optional definition description.")
@click.option("--data-type", default=None, help="int|float|boolean|string")
@click.option("--min-value", type=float, default=None, help="Optional numeric min bound.")
@click.option("--max-value", type=float, default=None, help="Optional numeric max bound.")
@click.option("--source-type", default=None, help="code|data|run_session")
def feature_definitions_create(
    feature_name: str,
    description: str | None,
    data_type: str | None,
    min_value: float | None,
    max_value: float | None,
    source_type: str | None,
) -> None:
    """Create a feature definition."""
    payload: dict[str, Any] = {"feature_name": feature_name}
    if description is not None:
        payload["description"] = description
    if data_type is not None:
        payload["data_type"] = data_type
    if min_value is not None:
        payload["min_value"] = min_value
    if max_value is not None:
        payload["max_value"] = max_value
    if source_type is not None:
        payload["source_type"] = source_type
    try:
        client = NetGreenerClient.from_credentials()
        data = client.post_feature_definition(payload)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_definitions_cli.command("update")
@click.argument("feature_name")
@click.option("--description", default=None, help="New description.")
@click.option("--data-type", default=None, help="int|float|boolean|string")
@click.option("--min-value", type=float, default=None, help="New min bound.")
@click.option("--max-value", type=float, default=None, help="New max bound.")
@click.option("--source-type", default=None, help="code|data|run_session")
def feature_definitions_update(
    feature_name: str,
    description: str | None,
    data_type: str | None,
    min_value: float | None,
    max_value: float | None,
    source_type: str | None,
) -> None:
    """Update fields on a feature definition."""
    if (
        description is None
        and data_type is None
        and min_value is None
        and max_value is None
        and source_type is None
    ):
        raise click.UsageError(
            "Provide at least one of --description, --data-type, --min-value, --max-value, --source-type"
        )
    payload: dict[str, Any] = {}
    if description is not None:
        payload["description"] = description
    if data_type is not None:
        payload["data_type"] = data_type
    if min_value is not None:
        payload["min_value"] = min_value
    if max_value is not None:
        payload["max_value"] = max_value
    if source_type is not None:
        payload["source_type"] = source_type
    try:
        client = NetGreenerClient.from_credentials()
        data = client.update_feature_definition(feature_name, payload)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


@feature_definitions_cli.command("delete")
@click.argument("feature_name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
def feature_definitions_delete(feature_name: str, yes: bool) -> None:
    """Delete one feature definition (fails if inputs still reference it)."""
    if not yes:
        click.confirm(f"Delete feature definition '{feature_name}'?", abort=True)
    try:
        client = NetGreenerClient.from_credentials()
        data = client.delete_feature_definition(feature_name)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)
    console.print(json.dumps(data, indent=2, default=str))


# ---------------------------------------------------------------------------
# estimate
# ---------------------------------------------------------------------------

_KPI_META: dict[str, tuple[str, str]] = {
    "energy_kwh": ("Energy", "kWh"),
    "carbon_kg": ("Carbon", "kg CO2"),
    "cpu_percent_hours": ("CPU", "CPU·h"),
    "ram_gb_hours": ("RAM", "GB·h"),
    "process_gpu_hours": ("GPU", "GPU·h"),
    "duration_minutes": ("Duration est.", "min"),
}


def _print_estimate_report(result: dict[str, Any]) -> None:
    from rich.table import Table
    from rich import box
    from rich.panel import Panel

    estimates = result.get("estimates", {})
    table = Table(box=box.SIMPLE, show_header=True, header_style="bold")
    table.add_column("KPI", style="bold cyan")
    table.add_column("Unit")
    table.add_column("Point", justify="right")
    table.add_column("Low", justify="right", style="dim")
    table.add_column("High", justify="right", style="dim")

    def _fmt(v: Any) -> str:
        if isinstance(v, float):
            return f"{v:.4g}"
        return str(v) if v is not None else "—"

    for key, (label, unit) in _KPI_META.items():
        band = estimates.get(key)
        if not band:
            continue
        table.add_row(
            label, unit, _fmt(band.get("point")), _fmt(band.get("low")), _fmt(band.get("high"))
        )

    confidence = result.get("confidence", "—")
    model = result.get("model", "stub")
    mode = result.get("estimate_mode", result.get("prompt_version", "llm"))
    conf_color = {"high": "green", "medium": "yellow", "low": "red"}.get(str(confidence), "white")

    console.print()
    console.print(Panel(table, title="[bold blue]KPI Estimate[/]", expand=False))
    console.print(
        f"Confidence: [{conf_color}]{confidence}[/]  |  Model: [dim]{model}[/]  |  Mode: [dim]{mode}[/]"
    )
    disclaimer = result.get("disclaimer", "")
    if disclaimer:
        console.print(f"[dim]{disclaimer}[/]")
    for bullet in result.get("reasoning_bullets", []):
        console.print(f"  • {bullet}")
    console.print()


@main.command("estimate")
@click.argument("project_dir", default=None, required=False, type=click.Path(file_okay=False))
@click.option(
    "--project-id",
    type=int,
    default=None,
    help="Project ID. If given alone, server resolves features from DB.",
)
@click.option(
    "--features-json",
    default=None,
    type=click.Path(exists=True, dir_okay=False),
    help="JSON file containing feature_values (alternative to local extraction).",
)
@click.option(
    "--persist-run-id", type=int, default=None, help="Persist estimate into this run session."
)
@click.option("--no-llm", is_flag=True, default=False, help="Use stub fallback instead of LLM.")
@click.option("--output-json", is_flag=True, default=False, help="Print raw JSON response.")
def estimate_cmd(
    project_dir: str | None,
    project_id: int | None,
    features_json: str | None,
    persist_run_id: int | None,
    no_llm: bool,
    output_json: bool,
) -> None:
    """Estimate KPIs (energy, carbon, CPU, RAM, GPU) before running a script.

    \b
    Uses the NetGreener LLM estimation API (Phase 7).

    \b
    Examples:
      netgreener estimate .
      netgreener estimate --project-id 42
      netgreener estimate . --project-id 42 --no-llm
      netgreener estimate --features-json feats.json --output-json
    """
    creds = load_credentials()
    if not creds:
        print_error("Not logged in. Run: netgreener login")
        raise SystemExit(1)

    client = NetGreenerClient.from_credentials()
    payload: dict[str, Any] = {"use_llm": not no_llm}
    if project_id is not None:
        payload["project_id"] = project_id
    if persist_run_id is not None:
        payload["persist_run_id"] = persist_run_id

    server_side_only = project_id is not None and not project_dir and not features_json

    if features_json:
        with open(features_json) as fh:
            payload["feature_values"] = json.load(fh)
        print_info(f"Loaded features from {features_json}.")
    elif project_dir:
        from .analyzer import analyze_project

        project_path = Path(project_dir).resolve()
        print_info(f"Analyzing {project_path} for features ...")
        summary = analyze_project(str(project_path))
        for err in (summary.get("errors") or [])[:3]:
            console.print(f"  [dim yellow]warn:[/] {err}")
        payload["feature_values"] = {
            k: v for k, v in summary.items() if k not in ("errors", "patterns", "per_file")
        }
    elif not server_side_only:
        print_error(
            "Provide a PROJECT_DIR, --features-json, or --project-id (for server-side resolution)."
        )
        raise SystemExit(1)

    try:
        if server_side_only:
            result = client.estimate_project(project_id, payload)  # type: ignore[arg-type]
        else:
            result = client.estimate_run(payload)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)

    if output_json:
        console.print(json.dumps(result, indent=2, default=str))
        return

    _print_estimate_report(result)


# ---------------------------------------------------------------------------
# analyze
# ---------------------------------------------------------------------------


@main.command("analyze")
@click.argument("project_dir", default=".", type=click.Path(file_okay=False))
@click.option("--project-name", default=None, help="Project name (defaults to directory name).")
@click.option(
    "--no-upload", is_flag=True, default=False, help="Analyze locally only, skip API upload."
)
@click.option(
    "--no-llm",
    is_flag=True,
    default=False,
    help="Skip GPT extraction (NLP/CNN-style features + semantic dangers). Default is to run them when credentials exist.",
)
@click.option(
    "--with-nlp",
    is_flag=True,
    default=False,
    hidden=True,
    help="Deprecated: GPT runs by default when credentials exist.",
)
@click.option(
    "--entry",
    default=None,
    type=click.Path(exists=True, dir_okay=False),
    help="Entry script for GPT analysis (defaults to first .py file found).",
)
@click.option(
    "--data-path",
    default=None,
    help="Path or URI to training/inference data (local dir, Azure Blob, S3, GCS). Required for full CNN/data feature extraction.",
)
def analyze_cmd(
    project_dir: str,
    project_name: str | None,
    no_upload: bool,
    no_llm: bool,
    with_nlp: bool,
    entry: str | None,
    data_path: str | None,
) -> None:
    """Analyze all Python files in PROJECT_DIR and upload code patterns.

    \b
    Use this when you want code quality data in the dashboard without running a script.

    \b
    Examples:
      netgreener analyze
      netgreener analyze C:\\users\\project1
      netgreener analyze . --no-llm
      netgreener analyze . --no-upload
    """
    from .analyzer import analyze_project

    if with_nlp:
        print_info(
            "Note: --with-nlp is deprecated; GPT analysis runs by default. Use --no-llm to skip."
        )

    _require_valid_byok_or_exit()

    project_path = Path(project_dir).resolve()
    p_name = project_name or project_path.name

    ctx_script_path = ""
    if entry:
        ctx_script_path = str(Path(entry).resolve())
    else:
        _pys = list(project_path.rglob("*.py"))
        if _pys:
            ctx_script_path = str(_pys[0])

    print_info(f"Analyzing project: {project_path} ...")
    project_summary = analyze_project(str(project_path))

    if project_summary.get("errors"):
        for err in project_summary["errors"][:5]:
            console.print(f"  [dim yellow]warn:[/] {err}")

    file_count = project_summary.get("file_count", 0)
    total_loc = project_summary.get("total_lines_of_code", 0)
    avg_cc = project_summary.get("avg_cyclomatic_complexity", 0)
    avg_mi = project_summary.get("avg_maintainability_index", 0)
    domains = ", ".join(project_summary.get("library_domains", [])) or "none detected"

    console.print(f"\n[bold]Analysis complete[/]; {file_count} files, {total_loc} lines")
    console.print(f"  avg cyclomatic complexity : [cyan]{avg_cc}[/]")
    console.print(f"  avg maintainability index : [cyan]{avg_mi}[/]")
    console.print(f"  library domains           : [cyan]{domains}[/]")

    detected_domains = set(project_summary.get("library_domains", []))
    if detected_domains & _ML_DATA_DOMAINS and not data_path:
        print_info(
            "[yellow]Warning:[/] AI/data project detected; provide [bold]--data-path[/] "
            "(local dir, Azure Blob, S3, GCS) for full CNN/data feature extraction."
        )

    # GPT analysis (default): NLP feature questionnaire (includes CNN/ConvNet items) + semantic dangers
    nlp_features: dict = {}
    semantic_dangers: dict = {}
    patterns_for_summary: list[dict[str, Any]] = []
    if not no_llm and _llm_credentials_available():
        script_path_str = entry
        if not script_path_str:
            py_files = list(project_path.rglob("*.py"))
            if py_files:
                script_path_str = str(py_files[0])
        if script_path_str:
            script_path_obj = Path(script_path_str).resolve()
            from .nlp_analyzer import run_combined_llm_analysis

            file_features = _file_features_from_project_summary(
                project_summary, project_path, script_path_obj
            )
            ast_findings: list[dict[str, Any]] = []

            print_info(
                f"GPT analysis: {script_path_obj.name}; NLP + semantic (30–60 s, please wait)…"
            )
            with console.status(
                f"[bold]GPT analysis:[/] {script_path_obj.name}; NLP + semantic (30–60 s) …",
                spinner="dots",
            ):
                try:
                    combined = run_combined_llm_analysis(
                        script_path=str(script_path_obj),
                        language="python",
                        ast_findings=ast_findings,
                        file_features=file_features or None,
                        project_context_summaries=[
                            (
                                "NetGreener analyze summary: "
                                f"file_count={project_summary.get('file_count', 0)}, "
                                f"avg_cc={project_summary.get('avg_cyclomatic_complexity', 0)}, "
                                f"avg_mi={project_summary.get('avg_maintainability_index', 0)}"
                            )
                        ],
                    )
                except KeyboardInterrupt:
                    print_error("GPT analysis interrupted; skipping NLP/semantic.")
                    combined = {"nlp_features": {}, "semantic_dangers": {}, "errors": []}
                except Exception as e:
                    print_error(f"GPT analysis error: {e}")
                    combined = {"nlp_features": {}, "semantic_dangers": {}, "errors": []}
            nlp_features = combined.get("nlp_features", {}) or {}
            semantic_dangers = combined.get("semantic_dangers", {}) or {}
            for err in combined.get("errors", []):
                print_error(err)
            if nlp_features:
                print_info(f"NLP analysis complete ({len(nlp_features)} features).")
            if semantic_dangers:
                print_info("Semantic danger analysis complete.")
        else:
            print_error("No .py files found for GPT analysis.")
    elif not no_llm:
        print_info(
            "Skipping GPT (NLP + semantic): run: netgreener login, or set both BYOK profiles "
            "(NETGREENER_LLM_* and NETGREENER_LLM_MINI_*), or OPENAI_API_KEY for legacy checks."
        )

    _print_quality_summary(patterns_for_summary, semantic_dangers)

    if no_upload:
        return

    creds = load_credentials()
    if not creds:
        print_info("Not logged in; skipping upload. Run: netgreener login")
        return

    try:
        client = NetGreenerClient.from_credentials()
        project = client.get_or_create_project(p_name, str(project_path))
        project_id = project["project_id"]

        findings = client.analyze_project_files(project_id, project_summary.get("per_file", []))
        if findings:
            client.post_findings_batch(findings)
            console.print(f"  [green]✓[/] Uploaded {len(findings)} finding(s).")
            patterns_for_summary = findings
        else:
            console.print("  [dim]No findings detected.[/]")

        if project_summary:
            features_payload = {
                k: v
                for k, v in project_summary.items()
                if k not in ("errors", "patterns", "per_file")
            }
            if nlp_features:
                features_payload["nlp_features"] = nlp_features
            if semantic_dangers:
                features_payload["semantic_dangers"] = semantic_dangers
            if data_path:
                features_payload["data_path"] = data_path
                from .dataset_features import extract_dataset_features

                ds_features = extract_dataset_features(data_path)
                if "error" not in ds_features:
                    features_payload["dataset_features"] = ds_features
                else:
                    console.print(f"  [dim]dataset features skipped: {ds_features['error']}[/]")
            from .run_context import build_run_context_v0

            features_payload["run_context"] = build_run_context_v0(
                client="netgreener_cli_analyze",
                script_path=ctx_script_path,
                project_dir=str(project_path),
                no_llm=no_llm,
            )
            client.post_surrogate_training(
                {
                    "project_id": project_id,
                    "split_type": "train",
                    "features": features_payload,
                }
            )
            console.print("  [green]✓[/] Features uploaded to surrogate training data.")

        print_info(f"Done. View at {DASHBOARD_URL}/projects/{project_id}")

    except APIError as e:
        print_error(f"Upload failed: {e}")
    except Exception as e:
        print_error(f"Upload error: {e}")


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------


@main.command()
@click.argument("script", type=click.Path(exists=True, dir_okay=False))
@click.argument("project_dir", default=".", type=click.Path(file_okay=False))
@click.option("--project-name", default=None, help="Project name (defaults to directory name).")
@click.option(
    "--no-upload", is_flag=True, default=False, help="Analyze locally only, skip API upload."
)
@click.option("--no-analyze", is_flag=True, default=False, help="Skip code analysis, run only.")
@click.option(
    "--no-llm",
    is_flag=True,
    default=False,
    help="Skip GPT extraction after the run (NLP/CNN-style features + semantic dangers). Default is to run when credentials exist.",
)
@click.option(
    "--with-nlp",
    is_flag=True,
    default=False,
    hidden=True,
    help="Deprecated: GPT runs by default when credentials exist.",
)
@click.option(
    "--dataset-source",
    default=None,
    type=click.Choice(
        ["disk", "blob", "s3", "database", "network", "memory", "mixed"], case_sensitive=False
    ),
    help="Where the training/inference data comes from (e.g. disk, blob, s3, database).",
)
@click.option(
    "--data-path",
    default=None,
    help="Path or URI to training/inference data (local dir, Azure Blob, S3, GCS). Required for full CNN/data feature extraction.",
)
def run(
    script: str,
    project_dir: str,
    project_name: str | None,
    no_upload: bool,
    no_analyze: bool,
    no_llm: bool,
    with_nlp: bool,
    dataset_source: str | None,
    data_path: str | None,
) -> None:
    """Run SCRIPT inside PROJECT_DIR with energy and code analysis.

    \b
    Examples:
      netgreener run train.py .
      netgreener run train.py C:\\users\\project1
      netgreener run train.py . --no-upload
      netgreener run train.py . --no-llm
    """
    from .analyzer import analyze_project
    from .executor import RunResult, run_script
    from ._metrics_server import MetricsServer

    if with_nlp:
        print_info(
            "Note: --with-nlp is deprecated; GPT analysis runs by default. Use --no-llm to skip."
        )

    _require_valid_byok_or_exit()

    script_path = Path(script).resolve()
    project_path = Path(project_dir).resolve()
    p_name = project_name or project_path.name

    if not no_upload and not load_credentials():
        print_error("Not logged in. Run: netgreener login")
        raise SystemExit(1)

    # --- Code analysis in background so script output starts immediately ---
    project_summary: dict = {}
    analysis_thread: threading.Thread | None = None
    if not no_analyze:
        print_info(f"Analyzing project: {project_path} ...")

        def _run_analysis() -> None:
            project_summary.update(analyze_project(str(project_path)))

        analysis_thread = threading.Thread(target=_run_analysis, daemon=True)
        analysis_thread.start()

    # --- Start metrics callback server ---
    received_accuracy: dict = {}

    def _on_metrics(payload: dict) -> None:
        received_accuracy.update(payload)

    metrics_server = MetricsServer(on_metrics=_on_metrics)
    metrics_server.start()

    # --- Execute script ---
    import time as _time

    print_info(f"Running: {script_path.name}\n")
    run_start_time = _time.time()
    result = run_script(
        script_path=str(script_path),
        project_dir=str(project_path),
        metrics_port=metrics_server.port,
    )
    metrics_server.drain()
    metrics_server.stop()

    if received_accuracy:
        result.accuracy_metrics = received_accuracy
    else:
        from .accuracy_extractor import auto_extract

        extracted = auto_extract(result.stdout_tail, str(project_path), run_start_time)
        if extracted:
            print_info(
                f"Auto-detected metrics: {', '.join(f'{k}={v}' for k, v in extracted.items())}"
            )
            result.accuracy_metrics = extracted

    if result.interrupted:
        print_error("Run interrupted by user (Ctrl+C); uploading partial metrics.")

    if analysis_thread is not None:
        console.print("[dim]  waiting for code analysis …[/]")
        analysis_thread.join(timeout=30)
        if analysis_thread.is_alive():
            console.print("[yellow]  code analysis timed out after 30s; skipping.[/]")
        else:
            console.print("  [green]✓[/] code analysis done.")
            if project_summary.get("errors"):
                for err in project_summary["errors"][:5]:
                    console.print(f"  [dim yellow]warn:[/] {err}")

    # --- Print report ---
    print_run_report(result, project_summary, script_path.name)

    # --- GPT analysis (default, post-run): NLP questionnaire + semantic dangers ---
    nlp_features: dict = {}
    semantic_dangers: dict = {}
    patterns_for_summary: list[dict[str, Any]] = []
    if not no_llm and _llm_credentials_available():
        from .nlp_analyzer import run_combined_llm_analysis

        file_features = _file_features_from_project_summary(
            project_summary, project_path, script_path
        )
        ast_findings: list[dict[str, Any]] = []

        print_info(f"GPT analysis: {script_path.name}; NLP + semantic (30–60 s, please wait)…")
        with console.status(
            f"[bold]GPT analysis:[/] {script_path.name}; NLP + semantic (30–60 s) …",
            spinner="dots",
        ):
            try:
                combined = run_combined_llm_analysis(
                    script_path=str(script_path),
                    language="python",
                    ast_findings=ast_findings,
                    file_features=file_features or None,
                    project_context_summaries=[
                        (
                            "NetGreener run summary: "
                            f"duration_seconds={result.duration_seconds}, "
                            f"energy_kwh={result.energy_kwh:.6f}, "
                            f"avg_cc={project_summary.get('avg_cyclomatic_complexity', 0)}"
                        )
                    ],
                )
            except KeyboardInterrupt:
                print_error("GPT analysis interrupted; skipping NLP/semantic.")
                combined = {"nlp_features": {}, "semantic_dangers": {}, "errors": []}
            except Exception as e:
                print_error(f"GPT analysis error: {e}")
                combined = {"nlp_features": {}, "semantic_dangers": {}, "errors": []}
        nlp_features = combined.get("nlp_features", {}) or {}
        semantic_dangers = combined.get("semantic_dangers", {}) or {}
        for err in combined.get("errors", []):
            print_error(err)
        if nlp_features:
            print_info(f"NLP analysis complete ({len(nlp_features)} features).")
        if semantic_dangers:
            print_info("Semantic danger analysis complete.")
    elif not no_llm:
        print_info(
            "Skipping GPT (NLP + semantic): run: netgreener login, or set both BYOK profiles "
            "(NETGREENER_LLM_* and NETGREENER_LLM_MINI_*), or OPENAI_API_KEY for legacy checks."
        )
    _print_quality_summary(patterns_for_summary, semantic_dangers)

    detected_domains = set(project_summary.get("library_domains", []))
    if detected_domains & _ML_DATA_DOMAINS and not data_path:
        print_info(
            "[yellow]Warning:[/] AI/data project detected; provide [bold]--data-path[/] "
            "(local dir, Azure Blob, S3, GCS) for full CNN/data feature extraction."
        )

    # --- Upload to API ---
    if not no_upload:
        _upload_results(
            result,
            project_summary,
            p_name,
            str(project_path),
            str(script_path),
            nlp_features,
            semantic_dangers,
            no_llm=no_llm,
            dataset_source=dataset_source,
            data_path=data_path,
        )

    raise SystemExit(130 if result.interrupted else result.exit_code)


def _upload_results(
    result: "RunResult",
    project_summary: dict,
    project_name: str,
    project_dir: str,
    script_path: str = "",
    nlp_features: dict | None = None,
    semantic_dangers: dict | None = None,
    *,
    no_llm: bool = False,
    dataset_source: str | None = None,
    data_path: str | None = None,
) -> None:
    """POST run session, accuracy, environmental impact, code patterns, and surrogate training data."""
    from .executor import RunResult

    creds = load_credentials()
    if not creds:
        print_info("Not logged in; skipping upload. Run: netgreener login")
        return

    console.print("\n[bold]Uploading to NetGreener …[/]")
    try:
        client = NetGreenerClient.from_credentials()

        console.print("  [dim]resolving project …[/]", end="\r")
        project = client.get_or_create_project(project_name, project_dir)
        project_id = project["project_id"]
        console.print(f"  [green]✓[/] project [cyan]#{project_id}[/] ({project_name})        ")

        # Fetch findings from server-side pattern detection
        if project_summary and not project_summary.get("errors"):
            per_file = project_summary.get("per_file", [])
            api_findings = client.analyze_project_files(project_id, per_file) if per_file else []
            project_summary = {**project_summary, "patterns": api_findings}

        carbon_kg = result.energy_kwh * CO2_KG_PER_KWH

        end_time = datetime.now(timezone.utc)
        duration_s = float(result.duration_seconds)
        start_time = end_time - timedelta(seconds=duration_s)

        run_payload: dict = {
            "project_id": project_id,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "server_name": platform.node() or None,
            "energy_kwh": result.energy_kwh,
            "cpu_percent_hours": result.cpu_percent_avg * result.duration_seconds / 3600,
            "ram_gb_hours": result.ram_gb_avg * result.duration_seconds / 3600,
            "process_gpu_hours": result.gpu_utilization_avg / 100 * result.duration_seconds / 3600,
        }
        if result.accuracy_metrics:
            run_payload.update(result.accuracy_metrics)

        from .run_context import build_run_context_v0

        run_context = build_run_context_v0(
            client="netgreener_cli_run",
            script_path=script_path,
            project_dir=project_dir,
            no_llm=no_llm,
            hardware_snapshot=result.hardware_snapshot or None,
        )
        if dataset_source:
            run_context["dataset_source"] = dataset_source

        meta: dict = {"run_context": run_context}
        if result.interrupted:
            meta["is_interrupted"] = True
        cicd = _collect_cicd_context()
        if cicd:
            meta["cicd"] = cicd
        if project_summary:
            meta.update(
                {
                    "file_count": project_summary.get("file_count"),
                    "total_lines_of_code": project_summary.get("total_lines_of_code"),
                    "avg_cyclomatic_complexity": project_summary.get("avg_cyclomatic_complexity"),
                    "avg_maintainability_index": project_summary.get("avg_maintainability_index"),
                    "avg_halstead_volume": project_summary.get("avg_halstead_volume"),
                    "library_domains": project_summary.get("library_domains", []),
                }
            )
        run_payload["session_metadata"] = meta

        console.print("  [dim]saving run session …[/]", end="\r")
        run_session = client.create_run_session(run_payload)
        run_id = run_session.get("run_id") or run_session.get("id")
        console.print(f"  [green]✓[/] run session [cyan]#{run_id}[/]                  ")

        # Update accuracy separately if reported (uses the dedicated endpoint)
        if result.accuracy_metrics and run_id:
            console.print("  [dim]saving accuracy metrics …[/]", end="\r")
            client.update_run_accuracy(run_id, result.accuracy_metrics)
            console.print("  [green]✓[/] accuracy metrics               ")

        # Environmental impact record
        console.print("  [dim]saving environmental impact …[/]", end="\r")
        client.post_environmental_impact(
            {
                "project_id": project_id,
                "run_id": run_id,
                "carbon_kg": round(carbon_kg, 6),
                "energy_kwh": result.energy_kwh,
            }
        )
        console.print("  [green]✓[/] environmental impact               ")

        # Findings → powers supervisor code_quality_score
        patterns = project_summary.get("patterns", []) if project_summary else []
        if patterns:
            console.print(f"  [dim]uploading {len(patterns)} finding(s) …[/]", end="\r")
            client.post_findings_batch(patterns)
            console.print(f"  [green]✓[/] {len(patterns)} finding(s)               ")

        # Surrogate training data; code features + run labels for surrogate model
        if project_summary:
            features_payload = {
                k: v
                for k, v in project_summary.items()
                if k not in ("errors", "patterns", "per_file")
            }
            if nlp_features:
                features_payload["nlp_features"] = nlp_features
            if semantic_dangers:
                features_payload["semantic_dangers"] = semantic_dangers
            if data_path:
                features_payload["data_path"] = data_path
                from .dataset_features import extract_dataset_features

                ds_features = extract_dataset_features(data_path)
                if "error" not in ds_features:
                    features_payload["dataset_features"] = ds_features
                else:
                    console.print(f"  [dim]dataset features skipped: {ds_features['error']}[/]")
            features_payload["run_context"] = run_context
            surrogate_payload: dict = {
                "project_id": project_id,
                "split_type": "train",
                "features": features_payload,
                "label_energy_kwh": result.energy_kwh,
                "label_carbon_kg": round(carbon_kg, 6),
            }
            if result.accuracy_metrics:
                surrogate_payload["label_model_accuracy"] = result.accuracy_metrics.get(
                    "model_accuracy"
                )
                surrogate_payload["label_f1_score"] = result.accuracy_metrics.get("f1_score")
            console.print("  [dim]uploading surrogate training data …[/]", end="\r")
            client.post_surrogate_training(surrogate_payload)
            console.print("  [green]✓[/] surrogate training data               ")

        print_info(
            f"Done; run [cyan]#{run_id}[/] saved. View at {DASHBOARD_URL}/projects/{project_id}/runs/{run_id}"
        )

    except APIError as e:
        print_error(f"Upload failed: {e}")
    except Exception as e:
        print_error(f"Upload error: {e}")
