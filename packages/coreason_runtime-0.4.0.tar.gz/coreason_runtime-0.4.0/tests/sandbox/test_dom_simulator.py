# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for DOM Simulation execution."""

from unittest.mock import AsyncMock, patch

import pytest

from coreason_runtime.sandbox.dom_simulator import (
    BrowserIntentPayload,
    BrowserStateDict,
    DocumentLayoutDict,
    execute_browser_intent_activity,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.mark.asyncio
async def test_dom_simulator_schema_failures() -> None:
    """Test strict schema enforcement intercepting payload violations."""
    payload = BrowserIntentPayload()
    with pytest.raises(ManifestConformanceError) as exc_info:
        await execute_browser_intent_activity(payload)
    assert "DOM Layout Security Violation" in str(exc_info.value)


@pytest.mark.asyncio
async def test_dom_simulator_restricted_domain_rejection() -> None:
    """Test interception of isolated restricted domains dynamically."""
    payload = BrowserIntentPayload(
        browser_state=BrowserStateDict(navigation_depth=1),
        document_layout=DocumentLayoutDict(source_uri="https://restricted.internal.network/admin"),
    )
    with pytest.raises(ManifestConformanceError) as exc_info:
        await execute_browser_intent_activity(payload)
    assert "Target URI breaches restricted DOM enclave topologies" in str(exc_info.value)


@pytest.mark.asyncio
async def test_dom_simulator_mocked_success() -> None:
    """Test a totally valid spatial traversal bypassing live playwright instance."""

    # Mock playwright async context
    mock_page = AsyncMock()
    mock_page.goto.return_value = None
    mock_page.content.return_value = "<html><body>Mocked HTML Output</body></html>"

    mock_context = AsyncMock()
    mock_context.new_page.return_value = mock_page

    mock_browser = AsyncMock()
    mock_browser.new_context.return_value = mock_context
    mock_browser.close.return_value = None

    # Mock exactly what async_playwright() async context manager provides
    mock_p_engine = AsyncMock()
    mock_p_engine.chromium.launch.return_value = mock_browser

    mock_async_playwright_cm = AsyncMock()
    mock_async_playwright_cm.__aenter__.return_value = mock_p_engine
    mock_async_playwright_cm.__aexit__.return_value = None

    payload = BrowserIntentPayload(
        browser_state=BrowserStateDict(navigation_depth=1),
        document_layout=DocumentLayoutDict(source_uri="about:blank"),
    )

    with patch("coreason_runtime.sandbox.dom_simulator.async_playwright", return_value=mock_async_playwright_cm):
        result = await execute_browser_intent_activity(payload)

    assert result["execution_status"] == "SUCCESS"
    assert result["rendered_html"] == "<html><body>Mocked HTML Output</body></html>"


@pytest.mark.asyncio
async def test_dom_simulator_connection_failure() -> None:
    """Test exception intercept bouncing back as ManifestConformanceError."""

    mock_page = AsyncMock()
    mock_page.goto.side_effect = Exception("Offline Mock Browser Collapse")

    mock_context = AsyncMock()
    mock_context.new_page.return_value = mock_page

    mock_browser = AsyncMock()
    mock_browser.new_context.return_value = mock_context
    mock_browser.close.return_value = None

    mock_p_engine = AsyncMock()
    mock_p_engine.chromium.launch.return_value = mock_browser

    mock_async_playwright_cm = AsyncMock()
    mock_async_playwright_cm.__aenter__.return_value = mock_p_engine
    mock_async_playwright_cm.__aexit__.return_value = None

    payload = BrowserIntentPayload(
        browser_state=BrowserStateDict(navigation_depth=1),
        document_layout=DocumentLayoutDict(source_uri="https://test.net/"),
    )

    with patch("coreason_runtime.sandbox.dom_simulator.async_playwright", return_value=mock_async_playwright_cm):
        with pytest.raises(ManifestConformanceError) as exc_info:
            await execute_browser_intent_activity(payload)

    assert "DOM Topological Access Denied" in str(exc_info.value)
    assert mock_browser.close.call_count == 1
