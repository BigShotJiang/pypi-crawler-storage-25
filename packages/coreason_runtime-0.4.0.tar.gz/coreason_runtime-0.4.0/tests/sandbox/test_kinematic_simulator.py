# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for Kinematic Simulation Engine."""

import asyncio

import coreason_manifest.spec.ontology as o
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from pydantic import BaseModel, ConfigDict


class MockSpatialKinematics(BaseModel):
    target_coordinate: list[float]
    model_config = ConfigDict(extra="ignore")


class MockObserverPhysics(BaseModel):
    optical_center_x: float
    model_config = ConfigDict(extra="ignore")


class MockBoundingVolumeHierarchy(BaseModel):
    collision_radius: float
    model_config = ConfigDict(extra="ignore")


class MockHollowPlaneBridge(BaseModel):
    model_config = ConfigDict(extra="ignore")


class MockNDimensionalTensorManifest(BaseModel):
    model_config = ConfigDict(extra="ignore")


import coreason_runtime.sandbox.kinematic_simulator as k

k.SpatialKinematics = MockSpatialKinematics
k.ObserverPhysics = MockObserverPhysics
k.BoundingVolumeHierarchy = MockBoundingVolumeHierarchy
o.HollowPlaneBridge = MockHollowPlaneBridge  # type: ignore
o.NDimensionalTensorManifest = MockNDimensionalTensorManifest  # type: ignore

from coreason_runtime.sandbox.kinematic_simulator import (
    BoundingVolumeDict,
    KinematicsDict,
    ObserverDict,
    SpatialBoundsPayload,
    verify_spatial_bounds_activity,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.mark.asyncio
async def test_kinematic_simulator_schema_failures() -> None:
    """Test rigorous schema conformance enforcement."""
    payload = SpatialBoundsPayload()
    with pytest.raises(ManifestConformanceError) as exc_info:
        await verify_spatial_bounds_activity(payload)
    assert "Kinematic Simulator Boundary Violation" in str(exc_info.value)


@pytest.mark.asyncio
async def test_kinematic_simulator_success() -> None:
    """Test a totally valid spatial traversal."""
    payload = SpatialBoundsPayload(
        kinematics=KinematicsDict(target_coordinate=[0.5, 0.5, 0.0]),
        observer=ObserverDict(optical_center_x=0.0),
        bounding_volume=BoundingVolumeDict(collision_radius=2.0),
    )
    result = await verify_spatial_bounds_activity(payload)
    assert result["kinematic_clearance"] is True


@settings(max_examples=50)
@given(
    target_x=st.floats(min_value=10.0, max_value=100.0),
    target_y=st.floats(min_value=10.0, max_value=100.0),
    radius=st.floats(min_value=0.1, max_value=5.0),
)
def test_kinematic_simulator_out_of_bounds(target_x: float, target_y: float, radius: float) -> None:
    """Rigorous property tests bombarding boundary physics."""

    async def run_test() -> None:
        payload = SpatialBoundsPayload(
            kinematics=KinematicsDict(target_coordinate=[target_x, target_y, 0.0]),
            observer=ObserverDict(optical_center_x=0.0),
            bounding_volume=BoundingVolumeDict(collision_radius=radius),
        )
        with pytest.raises(ManifestConformanceError) as exc_info:
            await verify_spatial_bounds_activity(payload)
        assert "Trajectory exceeds bounding physics" in str(exc_info.value)

    asyncio.run(run_test())
