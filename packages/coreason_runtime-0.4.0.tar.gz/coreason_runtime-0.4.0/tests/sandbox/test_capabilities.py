# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from coreason_manifest import MCPClientIntent

from coreason_runtime.sandbox.capabilities import build_extism_manifest


def test_build_extism_manifest_default_posture() -> None:
    intent = MCPClientIntent.model_construct(jsonrpc="2.0", method="mcp.ui.emit_intent", id="123", params=None)
    manifest = build_extism_manifest(intent)

    assert manifest["allowed_hosts"] == []
    assert manifest["allowed_paths"] == {}


def test_build_extism_manifest_with_params() -> None:
    intent = MCPClientIntent.model_construct(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        id="123",
        params={
            "allowed_hosts": ["api.example.com", "api.github.com"],
            "allowed_paths": {"/opt/coreason/foo": "/data"},
        },
    )
    manifest = build_extism_manifest(intent)

    assert manifest["allowed_hosts"] == ["api.example.com", "api.github.com"]
    assert manifest["allowed_paths"] == {"/opt/coreason/foo": "/data"}


def test_build_extism_manifest_with_invalid_params() -> None:
    intent = MCPClientIntent.model_construct(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        id="123",
        params={
            "allowed_hosts": "api.example.com",  # Should be list
            "allowed_paths": ["/opt/coreason/foo"],  # Should be dict
        },
    )
    manifest = build_extism_manifest(intent)

    # Should safely fallback to empty due to type checks
    assert manifest["allowed_hosts"] == []
    assert manifest["allowed_paths"] == {}


def test_topological_enforcer_validate_kinetic_separation() -> None:
    from unittest.mock import MagicMock

    import pytest
    from coreason_manifest import CognitiveActionSpaceManifest
    from temporalio.exceptions import ApplicationError

    from coreason_runtime.sandbox.topology import TopologicalEnforcer

    manifest = CognitiveActionSpaceManifest.model_construct(
        entry_point_cid="toolA", kinetic_separation=MagicMock(mutually_exclusive_clusters=[["toolB", "toolC"]])
    )
    enforcer = TopologicalEnforcer(manifest)

    # Valid
    enforcer.validate_kinetic_separation("toolB", ["toolA"])

    # Invalid (B and C in same trace)
    with pytest.raises(ApplicationError, match="Bipartite violation"):
        enforcer.validate_kinetic_separation("toolC", ["toolA", "toolB"])


def test_topological_enforcer_validate_mdp_transition() -> None:
    from unittest.mock import MagicMock

    import pytest
    from coreason_manifest import CognitiveActionSpaceManifest
    from temporalio.exceptions import ApplicationError

    from coreason_runtime.sandbox.topology import TopologicalEnforcer

    manifest = CognitiveActionSpaceManifest.model_construct(
        entry_point_cid="toolA",
        capabilities={"toolA": {}, "toolB": {}},
        transition_matrix={
            "toolA": [MagicMock(target_node_cid="toolB", compute_weight_magnitude=10.0, discount_factor=1.0)]
        },
    )
    enforcer = TopologicalEnforcer(manifest)

    # Test Missing Capability
    with pytest.raises(ApplicationError, match="Capability violation"):
        enforcer.validate_mdp_transition("toolC", [], 100.0)

    # Test Genesis
    with pytest.raises(ApplicationError, match="Genesis violation"):
        enforcer.validate_mdp_transition("toolB", [], 100.0)
    assert enforcer.validate_mdp_transition("toolA", [], 100.0) == 100.0

    # Test Edge Traversal Happy Path
    assert enforcer.validate_mdp_transition("toolB", ["toolA"], 100.0) == 90.0

    # Test Ghost Path
    with pytest.raises(ApplicationError, match="Ghost Path violation"):
        enforcer.validate_mdp_transition("toolA", ["toolB"], 100.0)

    # Test Thermodynamic Exhaustion
    with pytest.raises(ApplicationError, match="Thermodynamic exhaustion"):
        enforcer.validate_mdp_transition("toolB", ["toolA"], 5.0)

    # Test without discount factor
    manifest.transition_matrix["toolA"] = [MagicMock(target_node_cid="toolB", compute_weight_magnitude=5.0)]
    enforcer = TopologicalEnforcer(manifest)
    assert enforcer.validate_mdp_transition("toolB", ["toolA"], 100.0) == 95.0


def test_build_extism_manifest_missing_capabilities() -> None:
    # 74-85 in capabilities.py
    intent = MCPClientIntent.model_construct(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        id="123",
        params={
            "allowed_hosts": ["missing_capabilities_test"],
        },
    )
    manifest = build_extism_manifest(intent)
    assert "missing_capabilities_test" in manifest["allowed_hosts"]
