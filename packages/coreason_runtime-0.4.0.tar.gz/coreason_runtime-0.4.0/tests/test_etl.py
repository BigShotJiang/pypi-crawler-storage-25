# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from pathlib import Path

import polars as pl
import pytest

from coreason_runtime.etl.transform import process_medallion_pipeline


@pytest.fixture
def mock_bronze_data(tmp_path: Path) -> Path:
    """Creates a mock bronze parquet file with duplicate entries."""
    # Temporarily override the data directory path for the test
    # by using monkeypatch in the test, but first we create the data.

    bronze_dir = tmp_path / "data" / "bronze" / "telemetry" / "raw_events"
    bronze_dir.mkdir(parents=True, exist_ok=True)

    # Create mock data with duplicates to test deduplication and aggregation
    data = {
        "node_cid": ["node-1", "node-1", "node-2", "node-1"],
        "event_type": ["start", "start", "start", "stop"],
        "timestamp": ["2026-01-01T10:00:00Z", "2026-01-01T10:00:00Z", "2026-01-01T10:01:00Z", "2026-01-01T10:05:00Z"],
        "workflow_id": ["wf-123", "wf-123", "wf-123", "wf-123"],
    }

    df = pl.DataFrame(data)
    df.write_parquet(bronze_dir / "mock.parquet")

    # Also create an event with a null workflow_id to test drop_nulls
    data_null = {
        "node_cid": ["node-null"],
        "event_type": ["start"],
        "timestamp": ["2026-01-01T10:00:00Z"],
        "workflow_id": [None],
    }
    df_null = pl.DataFrame(data_null)
    df_null.write_parquet(bronze_dir / "mock_null.parquet")

    return tmp_path


def test_process_medallion_pipeline(mock_bronze_data: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from typing import Any

    # Patch Path to use our tmp_path
    original_path = Path

    class MockPath:
        def __new__(cls, *args: Any, **kwargs: Any) -> Any:
            if str(args[0]).startswith("data"):
                return original_path(mock_bronze_data / str(args[0]))
            return original_path(*args, **kwargs)

    monkeypatch.setattr("coreason_runtime.etl.transform.Path", MockPath)

    result = process_medallion_pipeline()

    assert result["status"] == "success"
    # silver should have 3 rows: node-1 start (deduplicated), node-2 start, node-1 stop.
    # null workflow_id row is dropped.
    assert result["silver_rows"] == "3"

    # gold should have 1 row: grouped by wf-123
    assert result["gold_rows"] == "1"

    # Verify files were created
    silver_path = mock_bronze_data / "data" / "silver" / "events.parquet"
    gold_path = mock_bronze_data / "data" / "gold" / "metrics.parquet"
    assert silver_path.exists()
    assert gold_path.exists()

    df_silver = pl.read_parquet(silver_path)
    assert len(df_silver) == 3

    df_gold = pl.read_parquet(gold_path)
    assert len(df_gold) == 1
    assert df_gold["total_events"][0] == 3
    assert df_gold["unique_nodes_activated"][0] == 2


def test_process_medallion_pipeline_no_data(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from typing import Any

    # Test skipping when no bronze data exists
    original_path = Path

    class MockPath:
        def __new__(cls, *args: Any, **kwargs: Any) -> Any:
            if str(args[0]).startswith("data"):
                return original_path(tmp_path / str(args[0]))
            return original_path(*args, **kwargs)

    monkeypatch.setattr("coreason_runtime.etl.transform.Path", MockPath)

    result = process_medallion_pipeline()
    assert result["status"] == "skipped"
    assert result["reason"] == "no_bronze_data"


@pytest.mark.asyncio
async def test_bronze_ingestion_loop() -> None:
    import asyncio
    import json

    from coreason_runtime.telemetry.broker import _active_clients
    from coreason_runtime.telemetry.subscriber import bronze_ingestion_loop

    # We need to test the while loop and the CancelledError handling
    # Create a task and inject data into its queue
    task = asyncio.create_task(bronze_ingestion_loop(batch_size=2))

    # Wait for subscriber_queue to be appended
    await asyncio.sleep(0.1)

    assert len(_active_clients) >= 1
    queue = _active_clients[-1]

    # Put an invalid JSON event
    await queue.put("invalid_json")

    # Put valid JSON events
    await queue.put(json.dumps({"test": 1}))
    await queue.put(json.dumps({"test": 2}))

    # Wait for flush
    await asyncio.sleep(0.5)

    # Cancel to hit the CancelledError block
    await queue.put(json.dumps({"test": 3}))  # Put one more to have a non-empty buffer on cancel
    task.cancel()

    import contextlib

    with contextlib.suppress(asyncio.CancelledError):
        await task
