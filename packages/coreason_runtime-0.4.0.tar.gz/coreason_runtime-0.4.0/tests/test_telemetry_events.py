# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from coreason_runtime.telemetry.events import (
    NodeStartedEvent,
    StateTransitionedEvent,
    TelemetryEvent,
    TokenStreamChunk,
    ToolExecutionUpdate,
)


def test_node_started_event() -> None:
    event = NodeStartedEvent(
        event_type="NodeStartedEvent",
        node_cid="node_123",
        agent_name="AgentSmith",
        timestamp="2026-01-01T12:00:00Z",
    )
    assert event.event_type == "NodeStartedEvent"
    assert event.node_cid == "node_123"
    assert event.agent_name == "AgentSmith"
    assert event.timestamp == "2026-01-01T12:00:00Z"

    # Check default event_type assignment
    event2 = NodeStartedEvent(
        node_cid="node_123",
        agent_name="AgentSmith",
        timestamp="2026-01-01T12:00:00Z",
    )
    assert event2.event_type == "NodeStartedEvent"


def test_token_stream_chunk() -> None:
    event = TokenStreamChunk(
        event_type="TokenStreamChunk",
        node_cid="node_123",
        agent_name="Agent47",
        text_chunk="Hello, ",
    )
    assert event.event_type == "TokenStreamChunk"
    assert event.node_cid == "node_123"
    assert event.agent_name == "Agent47"
    assert event.text_chunk == "Hello, "

    # Check default event_type
    event2 = TokenStreamChunk(node_cid="node_123", agent_name="Agent47", text_chunk="world!")
    assert event2.event_type == "TokenStreamChunk"


def test_tool_execution_update() -> None:
    event = ToolExecutionUpdate(
        event_type="ToolExecutionUpdate",
        status="started",
        tool_name="get_weather",
        duration_ms=0.0,
    )
    assert event.event_type == "ToolExecutionUpdate"
    assert event.status == "started"
    assert event.tool_name == "get_weather"
    assert event.duration_ms == 0.0

    # Check default event_type
    event2 = ToolExecutionUpdate(status="finished", tool_name="get_weather", duration_ms=150.5)
    assert event2.event_type == "ToolExecutionUpdate"


def test_state_transitioned_event() -> None:
    payload = {"result": "success", "steps": 5}
    event = StateTransitionedEvent(
        event_type="StateTransitionedEvent",
        workflow_id="wf_abc",
        payload=payload,
    )
    assert event.event_type == "StateTransitionedEvent"
    assert event.workflow_id == "wf_abc"
    assert event.payload == payload

    # Check default event_type
    event2 = StateTransitionedEvent(workflow_id="wf_xyz", payload={})
    assert event2.event_type == "StateTransitionedEvent"


def test_telemetry_event_base() -> None:
    event = TelemetryEvent(event_type="GenericEvent")
    assert event.event_type == "GenericEvent"
