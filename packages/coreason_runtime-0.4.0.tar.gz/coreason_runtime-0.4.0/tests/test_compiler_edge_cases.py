# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
from typing import Any

import pytest
from pydantic import BaseModel, ConfigDict

from coreason_runtime.tensor.compiler import UniversalCompiler


class DummyAgent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    topology_class: str = "agent"
    description: str


class DummyManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: str = "dummy"
    nodes: dict[str, DummyAgent]
    edges: list[tuple[str, str]] | None = None


class DummyMacroManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: str = "macro"
    nodes: dict[str, Any]
    max_depth: int
    max_fan_out: int
    adjudicator_id: str


async def dummy_llm(*_args: Any, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
    return {"genesis_provenance": {"derivation_mode": "direct_translation"}}, {"prompt_tokens": 10}, []


@pytest.mark.asyncio
async def test_entropy_escalation_error() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return {"genesis_provenance": {"derivation_mode": "direct_translation"}}, {}, [0.5, 0.5]

    with pytest.raises(ValueError, match="Epistemic Collapse"):
        await UniversalCompiler.validate_and_retry(
            DummyManifest, mock_llm, "test", max_attempts=1, baseline_entropy_threshold=0.1
        )


@pytest.mark.asyncio
async def test_regex_matching_ticks() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '```json\n{ "topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {} }\n```',
            {},
            [],
        )

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_agent_hallucination_unpacking() -> None:
    payload = {
        "topology_class": "dummy",
        "genesis_provenance": {"derivation_mode": "direct_translation"},
        "adjudicator_cid": "mock-cid",
        "target_epistemic_deficit": {"query_vector": {}},
        "nodes": {
            "node_1": {"agent": {"instructions": "do task", "task": "mission1", "description": "existing desc"}},
            "did:agent:node_2": {"system": {"instructions": "do system", "type": "fake_agent"}},
        },
        "edges": [{"source": "node1", "target": "did:agent:node2"}, ["node1", "did:agent:node2"]],
    }

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps(payload), {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)


@pytest.mark.asyncio
async def test_epistemic_contradiction_mock() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {  contradictory_mock_token }',
            {},
            [],
        )

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.validate_and_retry(
            DummyManifest, mock_llm, "test", max_attempts=1, self_correction=True
        )


@pytest.mark.asyncio
async def test_epistemic_reward_policy_mock() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {}}',
            {},
            [0.1, 0.2],
        )

    with pytest.raises(ValueError, match="EpistemicRewardModelPolicy Failed"):
        await UniversalCompiler.validate_and_retry(
            DummyManifest, mock_llm, "test", max_attempts=1, epistemic_reward_policy=True
        )


@pytest.mark.asyncio
async def test_epistemic_reward_policy_empty_probabilities() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {}}',
            {},
            [],
        )

    res, _ = await UniversalCompiler.validate_and_retry(
        DummyManifest, mock_llm, "test", max_attempts=1, epistemic_reward_policy=True
    )
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_epistemic_reward_policy_success() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {}}',
            {},
            [0.9, 0.8],
        )

    res, _ = await UniversalCompiler.validate_and_retry(
        DummyManifest, mock_llm, "test", max_attempts=1, epistemic_reward_policy=True
    )
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_self_correction_payload() -> None:
    async def mock_llm(prompt: str, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        if "System Error" in prompt:
            return (
                '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {"did:agent:n1": {"description": "hello"}}}',
                {},
                [],
            )
        return "invalid", {}, []

    res, _ = await UniversalCompiler.validate_and_retry(
        DummyManifest, mock_llm, "test", max_attempts=2, self_correction=True
    )
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_pydantic_unregistered_type() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return {"genesis_provenance": {"derivation_mode": "direct_translation"}}, {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.synthesize_manifest(
            "test", mock_llm, mock_llm, topology_hint="unregistered", max_agents=5
        )


def test_recursive_type_hints() -> None:
    class RecursiveNode(BaseModel):
        type: str
        parent: Any | None = None

    hints = UniversalCompiler.extract_type_hints(RecursiveNode)
    assert "parent" in (hints if isinstance(hints, dict) else {})

    class CircNode(BaseModel):
        type: str
        node: Any | None = None

    CircNode.model_rebuild()
    UniversalCompiler.extract_type_hints(CircNode)


def test_enforce_strict_array() -> None:
    class DummyArray(BaseModel):
        arr: list[dict[str, str]]

    UniversalCompiler.compile_schema(DummyArray)


def test_remove_unsupported_exception_catch() -> None:
    class EvilDict(dict[str, Any]):
        def values(self) -> Any:
            raise Exception("Simulated DB boom")

    UniversalCompiler.extract_type_hints(EvilDict())

    with pytest.raises(RuntimeError):
        UniversalCompiler.compile_schema(EvilDict())  # type: ignore


@pytest.mark.asyncio
async def test_compile_no_required_properties() -> None:
    class DummyNoRequired(BaseModel):
        prop: str | None = None

    assert UniversalCompiler.compile_schema(DummyNoRequired) is not None


@pytest.mark.asyncio
async def test_validate_and_retry_type_fallback() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return '{"topology_class": "none", "nodes": {}}', {}, []

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_validate_and_retry_extra_forbidden_fields() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            json.dumps(
                {
                    "topology_class": "dummy",
                    "genesis_provenance": {"derivation_mode": "direct_translation"},
                    "adjudicator_cid": "mock-cid",
                    "nodes": {},
                    "hallucinated_field": "fake",
                }
            ),
            {},
            [],
        )

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_validate_and_retry_macro_fallbacks() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "macro", "genesis_provenance": {"derivation_mode": "direct_translation"}, "nodes": {}}',
            {},
            [],
        )

    res, _ = await UniversalCompiler.validate_and_retry(DummyMacroManifest, mock_llm, "test", max_attempts=1)
    assert res.adjudicator_id == "did:coreason:adjudicator"
    assert res.max_depth == 10
    assert res.max_fan_out == 5


@pytest.mark.asyncio
async def test_validate_and_retry_remove_hallucinated_macro_fields() -> None:
    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        mock_payload = {
            "topology_class": "dummy",
            "genesis_provenance": {"derivation_mode": "direct_translation"},
            "adjudicator_cid": "mock-cid",
            "nodes": {},
            "adjudicator_id": "fake",
            "max_depth": 999,
            "max_fan_out": 55,
            "participant_node_ids": [],
        }
        return json.dumps(mock_payload), {}, []

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_validate_and_retry_strict_manifest_edges_deletion() -> None:
    class EdgeForbiddingManifest(BaseModel):
        model_config = ConfigDict(extra="forbid")
        type: str = "swarm"
        nodes: dict[str, Any]

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps({"topology_class": "swarm", "nodes": {}, "edges": ["foo", "bar"]}), {}, []

    res, _ = await UniversalCompiler.validate_and_retry(EdgeForbiddingManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "swarm"


@pytest.mark.asyncio
async def test_compiler_zero_shot_alignment_and_casting() -> None:
    class DummyAgentResponse(BaseModel):
        output: str
        other_field: str

    async def mock_llm_keys_to_delete(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        payload = {"extra_key1": "hello", "other_field": {"some_nested": "value"}}
        return json.dumps(payload), {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.validate_and_retry(DummyAgentResponse, mock_llm_keys_to_delete, "test", max_attempts=1)

    class OutputOnlyResponse(BaseModel):
        output: str

    async def mock_llm_result(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps({"result": "my_result_value"}), {}, []

    res_out: OutputOnlyResponse
    res_out, _ = await UniversalCompiler.validate_and_retry(
        OutputOnlyResponse,
        mock_llm_result,
        "test",
        max_attempts=1,
    )
    assert res_out.output == "my_result_value"

    async def mock_llm_action(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps({"action": "my_action_value"}), {}, []

    res_out, _ = await UniversalCompiler.validate_and_retry(
        OutputOnlyResponse,
        mock_llm_action,
        "test",
        max_attempts=1,
    )
    assert res_out.output == "my_action_value"

    async def mock_llm_empty(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps({}), {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.validate_and_retry(
            OutputOnlyResponse,
            mock_llm_empty,
            "test",
            max_attempts=1,
        )


@pytest.mark.asyncio
async def test_compiler_deep_schema_sanitization() -> None:
    class DeepSchemaManifest(BaseModel):
        type: str = "deep"
        nodes: dict[str, Any]
        information_flow: dict[str, Any]
        observability: dict[str, Any]
        target_epistemic_deficit: dict[str, Any]

    async def mock_llm_deep(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        payload = {
            "topology_class": "deep",
            "nodes": {
                "did:agent:n1": {
                    "topology_class": "human",
                    "timeout_seconds": 10,
                    "required_attestation": "fido2_webauthn",
                    "human": {},
                }
            },
            "information_flow": {
                "rules": [{"action": "allow"}],
                "latent_firewalls": [{"sae_dictionary_hash": "short"}],
            },
            "observability": {"telemetry_backpressure": {"occluded_refresh_rate_hz": 20}},
        }
        return json.dumps(payload), {}, []

    res, _ = await UniversalCompiler.validate_and_retry(DeepSchemaManifest, mock_llm_deep, "test", max_attempts=1)

    print("DEBUG RES:", res.model_dump())

    assert res.nodes["did:agent:n1"]["required_attestation"] == "fido2_webauthn"
    assert "timeout_seconds" not in res.nodes["did:agent:n1"]
    assert "human" not in res.nodes["did:agent:n1"]
    assert res.information_flow["rules"][0]["action"] == "redact"
    assert len(res.information_flow["latent_firewalls"][0]["sae_dictionary_hash"]) == 64
    assert res.observability["telemetry_backpressure"]["occluded_refresh_rate_hz"] == 1
    assert res.target_epistemic_deficit["query_vector"]["vector_base64"] == "H4sIAAAAAAAACw=="


@pytest.mark.asyncio
async def test_compiler_macro_forge_generation() -> None:
    async def mock_llm_macro(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        # synthesize_manifest expects a raw string topology back
        return '{"genesis_provenance": {"derivation_mode": "direct_translation"}}', {}, []

    # Should raise error eventually but execute the "macro_forge" bounds check before
    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.synthesize_manifest(
            "test", mock_llm_macro, mock_llm_macro, topology_hint="macro_forge", max_agents=3
        )


@pytest.mark.asyncio
async def test_fsm_schema_scrubbing_epistemic_deficit() -> None:
    """Explicitly verify that `target_epistemic_deficit` is scrubbed prior to logit constraints."""

    async def mock_thinking(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return '{"selected_type": "macro_forge", "architectural_intent": "test", "detailed_blueprint": "test"}', {}, []

    async def mock_typing(*_a: Any, **kwargs: Any) -> tuple[str, dict[str, Any], list[float]]:
        _ = kwargs.get("schema_dict", {})

        # Return junk to intentionally crash validate_and_retry after our assertion succeeds
        return '{"invalid": "json"}', {}, []

    with pytest.raises(ValueError, match=r"Epistemic Collapse"):
        await UniversalCompiler.synthesize_manifest(
            "test_prompt", mock_thinking, mock_typing, topology_hint="macro_forge"
        )
