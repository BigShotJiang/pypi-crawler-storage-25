# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import base64
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from coreason_manifest import InterventionReceipt, WetwareAttestationContract
from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.oracle import router

test_app = FastAPI()
test_app.include_router(router)
client = TestClient(test_app)

valid_attestation = WetwareAttestationContract(
    mechanism="fido2_webauthn",
    did_subject="did:example:123",
    cryptographic_payload=base64.b64encode(
        json.dumps({"pq_algorithm": "dilithium", "public_key_id": "pk1", "pq_signature_blob": "blob"}).encode()
    ).decode(),
    dag_node_nonce="req1-0000000",
    liveness_challenge_hash="a" * 64,
)

valid_receipt = InterventionReceipt(
    topology_class="verdict",
    intervention_request_cid="req1-0000000",
    target_node_cid="did:example:123",
    event_cid="test_event_cid",
    timestamp=1234567890,
    approved=True,
    feedback="Looks good",
    attestation=valid_attestation,
).model_dump(mode="json")


@pytest.mark.asyncio
async def test_resume_oracle_success() -> None:
    with (
        patch("coreason_runtime.api.oracle.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=True),
    ):
        mock_client = MagicMock()
        mock_connect.return_value = mock_client
        mock_handle = MagicMock()
        mock_client.get_workflow_handle.return_value = mock_handle
        mock_handle.signal = AsyncMock()

        resolve_receipt = valid_receipt.copy()
        response = client.post("/api/v1/oracle/resume/wf-1", json=resolve_receipt)
        assert response.status_code == 200
        assert response.json() == {"status": "success", "message": "Epistemic injection dispatched"}


@pytest.mark.asyncio
async def test_resume_oracle_temporal_exception() -> None:
    with (
        patch("coreason_runtime.api.oracle.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=True),
    ):
        mock_connect.side_effect = Exception("Temporal is down")

        resolve_receipt = valid_receipt.copy()
        response = client.post("/api/v1/oracle/resume/wf-1", json=resolve_receipt)
        assert response.status_code == 500
        assert "Temporal is down" in response.json()["detail"]


@pytest.mark.asyncio
async def test_resume_oracle_invalid_signature() -> None:
    with patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=False):
        resolve_receipt = valid_receipt.copy()
        response = client.post("/api/v1/oracle/resume/wf-1", json=resolve_receipt)
        assert response.status_code == 401
        assert "WetwareAttestationContract verification failed" in response.json()["detail"]


@pytest.mark.asyncio
async def test_resume_oracle_invalid_json() -> None:
    import copy

    invalid_receipt = copy.deepcopy(valid_receipt)
    invalid_receipt["attestation"]["cryptographic_payload"] = "invalid_base64_json"
    response = client.post("/api/v1/oracle/resume/wf-1", json=invalid_receipt)
    assert response.status_code == 401
    assert "WetwareAttestationContract verification failed" in response.json()["detail"]


@pytest.mark.asyncio
async def test_resolve_oracle_success() -> None:
    with (
        patch("coreason_runtime.api.oracle.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=True) as _mock_verify,
    ):
        mock_client = MagicMock()
        mock_connect.return_value = mock_client
        mock_handle = MagicMock()
        mock_client.get_workflow_handle.return_value = mock_handle
        mock_handle.signal = AsyncMock()

        resolve_receipt = valid_receipt.copy()
        resolve_receipt["topology_class"] = "verdict"
        response = client.post("/api/v1/oracle/resolve/wf-1", json=resolve_receipt)
        assert response.status_code == 200
        assert response.json() == {"status": "resolution_injected", "workflow_id": "wf-1"}


@pytest.mark.asyncio
async def test_resolve_oracle_temporal_exception() -> None:
    with (
        patch("coreason_runtime.api.oracle.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=True) as _mock_verify,
    ):
        mock_connect.side_effect = Exception("Temporal is down")

        resolve_receipt = valid_receipt.copy()
        resolve_receipt["topology_class"] = "verdict"
        response = client.post("/api/v1/oracle/resolve/wf-1", json=resolve_receipt)
        assert response.status_code == 500
        assert "Temporal is down" in response.json()["detail"]


@pytest.mark.asyncio
async def test_resolve_oracle_invalid_signature() -> None:
    with patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=False):
        resolve_receipt = valid_receipt.copy()
        resolve_receipt["topology_class"] = "verdict"
        response = client.post("/api/v1/oracle/resolve/wf-1", json=resolve_receipt)
        assert response.status_code == 401
        assert "WetwareAttestationContract verification failed" in response.json()["detail"]


@pytest.mark.asyncio
async def test_resolve_oracle_invalid_json() -> None:
    import copy

    invalid_receipt = copy.deepcopy(valid_receipt)
    invalid_receipt["topology_class"] = "verdict"
    invalid_receipt["attestation"]["cryptographic_payload"] = "invalid_base64_json"
    response = client.post("/api/v1/oracle/resolve/wf-1", json=invalid_receipt)
    assert response.status_code == 401
    assert "WetwareAttestationContract verification failed" in response.json()["detail"]


@pytest.mark.asyncio
async def test_resume_oracle_missing_attestation() -> None:
    """Test that missing attestation returns 401."""
    receipt_no_attestation = {
        "topology_class": "verdict",
        "intervention_request_cid": "req1-0000000",
        "target_node_cid": "did:example:123",
        "event_cid": "test_event_cid",
        "timestamp": 1234567890,
        "approved": True,
        "feedback": "Looks good",
        "attestation": None,
    }
    response = client.post("/api/v1/oracle/resume/wf-1", json=receipt_no_attestation)
    assert response.status_code == 401
    assert "Missing strict WetwareAttestationContract" in response.json()["detail"]


@pytest.mark.asyncio
async def test_resume_oracle_empty_crypto_payload() -> None:
    """Test that empty cryptographic_payload returns 401."""
    import copy

    receipt_empty_crypto = copy.deepcopy(valid_receipt)
    receipt_empty_crypto["attestation"]["cryptographic_payload"] = ""
    response = client.post("/api/v1/oracle/resume/wf-1", json=receipt_empty_crypto)
    # Pydantic validates the model before the handler runs, so empty string
    # may trigger 422 (model validation) or 401 (handler validation)
    assert response.status_code in (401, 422)


@pytest.mark.asyncio
async def test_resume_oracle_structurally_invalid_attestation() -> None:
    """Test that structurally invalid attestation (TypeError/ValueError) returns 401."""
    with patch(
        "coreason_runtime.api.oracle.verify_wetware_attestation",
        side_effect=TypeError("Structurally invalid"),
    ):
        resolve_receipt = valid_receipt.copy()
        response = client.post("/api/v1/oracle/resume/wf-1", json=resolve_receipt)
        assert response.status_code == 401
        assert "structurally invalid" in response.json()["detail"]
