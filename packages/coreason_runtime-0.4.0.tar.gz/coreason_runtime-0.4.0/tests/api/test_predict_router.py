# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.predict_router import predict_router

test_app = FastAPI()
test_app.include_router(predict_router)
client = TestClient(test_app)

import typing


@pytest.fixture(autouse=True)
def mock_discovery_and_mcp_global() -> typing.Generator[None]:
    with (
        patch("coreason_runtime.sandbox.mcp.mcp_client_manager.MCPClientManager") as mock_mcp,
        patch("coreason_runtime.sandbox.discovery.DiscoveryIndexer") as mock_indexer,
    ):
        mock_mcp.return_value.profiles = {}
        mock_indexer.return_value.search_capabilities.return_value = []
        mock_indexer.return_value.sync_remote_mcp = AsyncMock()
        yield


VALID_JSON_TOPOLOGY = """{
  "manifest_version": "1.0.0",
  "tenant_id": "default-tenant",
  "session_id": "s1",
  "genesis_provenance": {
    "derivation_mode": "direct_translation", "extracted_by": "did:coreason:local-dev-user",
    "source_event_cid": "local-dev-session-001"
  },
  "topology": {
    "topology_class": "dag",
    "nodes": {
      "did:coreason:grammar-agent-1": {
        "topology_class": "agent",
        "description": "Corrects grammar."
      }
    },
    "edges": [],
    "max_depth": 10,
    "max_fan_out": 5
  }
}"""

VALID_YAML_TOPOLOGY = """manifest_version: 1.0.0
tenant_id: default-tenant
session_id: s1
genesis_provenance:
  extracted_by: did:coreason:local-dev-user
  source_event_cid: local-dev-session-001
topology:
  type: dag
  nodes:
    did:coreason:grammar-agent-1:
      type: agent
      description: Corrects grammar.
  edges: []
  max_depth: 10
  max_fan_out: 5
"""

MOCK_LLM_NODE = {
    "new_node": {
        "node_cid": "did:coreason:summarizer-agent-1",
        "topology_class": "agent",
        "description": "Summarizes the corrected text.",
    }
}


@pytest.mark.asyncio
async def test_synthesize_success_json() -> None:
    """Happy path: valid JSON topology → new node merged → JSON response."""
    import json

    mock_response = (json.dumps(MOCK_LLM_NODE), {"prompt_tokens": 100, "completion_tokens": 50}, [0.95, 0.05])

    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "Add a summarizer"},
        )

    assert response.status_code == 200
    result = response.json()
    nodes = result["topology"]["nodes"]
    assert "did:coreason:summarizer-agent-1" in nodes
    assert nodes["did:coreason:summarizer-agent-1"]["topology_class"] == "agent"
    # Original node must still be present
    assert "did:coreason:grammar-agent-1" in nodes


@pytest.mark.asyncio
async def test_synthesize_success_yaml() -> None:
    """Happy path: valid YAML topology → new node merged → YAML response."""
    import json

    mock_response = (json.dumps(MOCK_LLM_NODE), {"prompt_tokens": 100, "completion_tokens": 50}, [0.95, 0.05])

    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_YAML_TOPOLOGY, "user_prompt": ""},
        )

    assert response.status_code == 200
    import yaml

    result = yaml.safe_load(response.text)
    nodes = result["topology"]["nodes"]
    assert "did:coreason:summarizer-agent-1" in nodes
    assert "did:coreason:grammar-agent-1" in nodes


@pytest.mark.asyncio
async def test_synthesize_llm_error() -> None:
    """Cloud Oracle raises an exception → 503 returned."""
    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
        side_effect=RuntimeError("LLM unreachable"),
    ):
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": ""},
        )

    assert response.status_code == 503
    assert "Synthesis engine failure" in response.json()["detail"]


@pytest.mark.asyncio
async def test_synthesize_bad_llm_json() -> None:
    """LLM returns valid JSON but invalid schema → 503 returned."""
    import json

    # Valid JSON but missing 'new_node' key and invalid ontology
    mock_response: tuple[str, dict[str, int], list[float]] = (json.dumps({"wrong_key": "oops"}), {}, [])

    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": ""},
        )

    assert response.status_code == 503
    assert "hallucinated invalid ontology" in response.json()["detail"]


@pytest.mark.asyncio
async def test_synthesize_invalid_topology() -> None:
    """Invalid topology string → 422 returned without calling LLM."""
    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
    ) as mock_gen:
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": "{this is not json or yaml:::}", "user_prompt": ""},
        )
        mock_gen.assert_not_called()

    assert response.status_code == 422
    assert "Failed to parse topology" in response.json()["detail"]


@pytest.mark.asyncio
async def test_synthesize_invalid_did_fallback() -> None:
    """LLM returns a non-DID node_id → router generates a safe fallback DID."""
    import json

    bad_node = {
        "new_node": {
            "node_cid": "NOT_A_DID",  # invalid
            "topology_class": "agent",
            "description": "Bad node.",
        }
    }
    mock_response: tuple[str, dict[str, int], list[float]] = (json.dumps(bad_node), {}, [])

    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": ""},
        )

    assert response.status_code == 200
    result = response.json()
    nodes = result["topology"]["nodes"]
    # A fallback DID should have been created
    generated_ids = [nid for nid in nodes if nid.startswith("did:coreason:synthesized-agent-")]
    assert len(generated_ids) == 1


@pytest.mark.asyncio
async def test_synthesize_next_agent_markdown_output() -> None:
    """Test that markdown and conversational text are safely ignored."""

    markdown_response = """Here is your agent:
```json
{
  "new_node": {
    "node_cid": "did:coreason:md-agent-1",
    "topology_class": "agent",
    "description": "I was extracted from markdown"
  }
}
```
Hope this helps!"""

    mock_response = (markdown_response, {"prompt_tokens": 10}, None)

    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "Use markdown"},
        )

    assert response.status_code == 200
    data = response.json()
    assert "did:coreason:md-agent-1" in data["topology"]["nodes"]
    assert data["topology"]["nodes"]["did:coreason:md-agent-1"]["description"] == "I was extracted from markdown"


@pytest.mark.asyncio
async def test_synthesize_next_agent_pure_markdown_output() -> None:
    """Test that pure markdown codeblocks are safely extracted."""
    from unittest.mock import AsyncMock, patch

    markdown_response = (
        "```json\n"
        "{\n"
        '  "new_node": {\n'
        '    "node_cid": "did:coreason:md-agent-pure",\n'
        '    "topology_class": "agent",\n'
        '    "description": "Pure markdown"\n'
        "  }\n"
        "}\n"
        "```"
    )

    mock_response: tuple[str, dict[str, int], list[float]] = (markdown_response, {"prompt_tokens": 10}, [])

    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "Use pure markdown"},
        )

    assert response.status_code == 200
    import yaml

    data = yaml.safe_load(response.text)
    assert "did:coreason:md-agent-pure" in data["topology"]["nodes"]
    assert data["topology"]["nodes"]["did:coreason:md-agent-pure"]["description"] == "Pure markdown"


@pytest.mark.asyncio
async def test_synthesize_manifest_success() -> None:
    """Happy path: user prompt → manifest synthesis → Temporal dispatch → 200."""
    from unittest.mock import MagicMock

    from coreason_manifest import DAGTopologyManifest, WorkflowManifest

    mock_manifest = WorkflowManifest.model_construct(
        manifest_version="1.0.0",
        tenant_cid="test-tenant",
        session_cid="test-session",
        genesis_provenance={},
        topology=DAGTopologyManifest.model_construct(
            topology_class="dag",
            type="dag",
            max_depth=10,
            max_fan_out=5,
            nodes={
                "did:coreason:agent-1": {"topology_class": "agent", "description": "Agent 1."},
                "did:coreason:agent-2": {"topology_class": "agent", "description": "Agent 2."},
            },
            edges=[("did:coreason:agent-1", "did:coreason:agent-2")],
        ),
    )
    mock_usage = {"prompt_tokens": 100, "completion_tokens": 200}

    with (
        patch(
            "coreason_runtime.tensor.router.tensor_router.TensorRouter.synthesize_hybrid_workflow",
            new_callable=AsyncMock,
            return_value=(mock_manifest, mock_usage),
        ),
        patch(
            "temporalio.client.Client.connect",
            new_callable=AsyncMock,
        ) as mock_temporal_connect,
        patch(
            "coreason_runtime.sandbox.discovery.DiscoveryIndexer.sync_remote_mcp",
            new_callable=AsyncMock,
        ),
        patch("coreason_runtime.sandbox.mcp.mcp_client_manager.MCPClientManager"),
    ):
        mock_client = MagicMock()
        mock_exec_future = AsyncMock(return_value={"status": "success"})
        mock_client.start_workflow = mock_exec_future
        mock_temporal_connect.return_value = mock_client

        response = client.post(
            "/api/v1/predict/synthesize",
            json={"user_prompt": "Build a web scraper and analyze the data"},
        )

    assert response.status_code == 200
    data = response.json()
    assert data["manifest_type"] == "dag"
    assert data["node_count"] == 2
    assert "workflow_id" in data
    assert data["workflow_id"].startswith("synthesis-")


@pytest.mark.asyncio
async def test_synthesize_manifest_llm_error() -> None:
    """LLM synthesis fails → 503 returned."""
    with (
        patch(
            "coreason_runtime.tensor.router.tensor_router.TensorRouter.synthesize_hybrid_workflow",
            new_callable=AsyncMock,
            side_effect=ValueError("LLM failed to produce valid manifest"),
        ),
        patch("coreason_runtime.sandbox.mcp.mcp_client_manager.MCPClientManager"),
    ):
        response = client.post(
            "/api/v1/predict/synthesize",
            json={"user_prompt": "Do something impossible"},
        )

    assert response.status_code == 503
    assert "Manifest synthesis engine failure" in response.json()["detail"]


@pytest.mark.asyncio
async def test_synthesize_scratch_macro_forge_fallback() -> None:
    """Test semantic deficit triggering macro_forge workflow."""
    from unittest.mock import MagicMock

    from coreason_manifest import DAGTopologyManifest, WorkflowManifest

    mock_forge_manifest = WorkflowManifest.model_construct(
        manifest_version="1.0.0",
        tenant_cid="test-tenant",
        session_cid="test-session",
        genesis_provenance={},
        topology=DAGTopologyManifest.model_construct(
            topology_class="macro_forge",
            type="macro_forge",
            max_depth=10,
            max_fan_out=5,
            nodes={
                "did:coreason:generator-agent-1": {
                    "topology_class": "agent",
                    "type": "agent",
                    "description": "Generates code.",
                    "domain_extensions": {},
                },
                "did:coreason:verifier-system-1": {
                    "topology_class": "system",
                    "type": "system",
                    "description": "Verifies code.",
                    "domain_extensions": {},
                },
            },
            edges=[("did:coreason:generator-agent-1", "did:coreason:verifier-system-1")],
        ),
    )

    mock_manifest = WorkflowManifest.model_construct(
        manifest_version="1.0.0",
        tenant_cid="test-tenant",
        session_cid="test-session",
        genesis_provenance={},
        topology=DAGTopologyManifest.model_construct(
            topology_class="dag",
            type="dag",
            nodes={"did:coreason:agent-1": {"topology_class": "agent", "description": "Final agent."}},
            edges=[],
        ),
    )

    with (
        patch("coreason_runtime.sandbox.mcp.mcp_client_manager.MCPClientManager") as mock_mcp_client_manager,
        patch(
            "coreason_runtime.sandbox.discovery.DiscoveryIndexer.search_capabilities",
            side_effect=[
                [],
                [
                    {
                        "distance": 0.5,
                        "name": "newly_forged_tool",
                        "capability_id": "test_cid",
                        "description": "Test tool",
                    }
                ],
            ],
        ),
        patch("coreason_runtime.sandbox.discovery.DiscoveryIndexer.sync_local_wasm", return_value=None),
        patch("coreason_runtime.sandbox.discovery.DiscoveryIndexer.sync_remote_mcp", new_callable=AsyncMock),
        patch(
            "coreason_runtime.tensor.router.tensor_router.TensorRouter.synthesize_hybrid_workflow",
            new_callable=AsyncMock,
            side_effect=[(mock_forge_manifest, {"prompt_tokens": 10}), (mock_manifest, {"prompt_tokens": 20})],
        ),
        patch("temporalio.client.Client.connect", new_callable=AsyncMock) as mock_temporal_connect,
    ):
        mock_mcp_client_manager.return_value.profiles = {"server-1": {}}
        mock_client = MagicMock()
        mock_start_future = AsyncMock(return_value=MagicMock())
        mock_client.start_workflow = mock_start_future
        mock_client.execute_workflow = AsyncMock(return_value={"status": "success"})
        mock_temporal_connect.return_value = mock_client

        response = client.post(
            "/api/v1/predict/synthesize",
            json={"user_prompt": "Build an isolated custom tool that doesn't exist yet"},
        )

    assert response.status_code == 200
    data = response.json()
    assert data["manifest_type"] == "dag"
    assert data["node_count"] == 1


@pytest.mark.asyncio
async def test_synthesize_expansion_discovery_paths() -> None:
    import json

    # 1. Test error in sync_local_wasm (line 137-138)
    with patch(
        "coreason_runtime.api.predict_router.CloudOracleClient.generate",
        new_callable=AsyncMock,
        return_value=(json.dumps(MOCK_LLM_NODE), {}, []),
    ):
        with patch(
            "coreason_runtime.sandbox.discovery.DiscoveryIndexer.sync_local_wasm",
            side_effect=RuntimeError("Test fallback"),
        ):
            response = client.post(
                "/api/v1/predict/topology",
                json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "do it"},
            )
            assert response.status_code == 200

    # 2. Test successful tool hit (lines 135-136) and mcp manager loops (lines 126)
    with (
        patch(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            new_callable=AsyncMock,
            return_value=(json.dumps(MOCK_LLM_NODE), {}, []),
        ),
        patch("coreason_runtime.sandbox.mcp.mcp_client_manager.MCPClientManager") as mock_mcp_client_manager,
        patch(
            "coreason_runtime.sandbox.discovery.DiscoveryIndexer.search_capabilities",
            return_value=[{"distance": 0.5, "name": "discovered_tool"}],
        ),
        patch("coreason_runtime.sandbox.discovery.DiscoveryIndexer.sync_local_wasm", return_value=None),
        patch("coreason_runtime.sandbox.discovery.DiscoveryIndexer.sync_remote_mcp", new_callable=AsyncMock),
    ):
        mock_mcp_client_manager.return_value.profiles = {"server-1": {}}
        response = client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "do it with tool"},
        )
        assert response.status_code == 200
