# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import patch

from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.schema import router


def setup_test_app() -> FastAPI:
    app = FastAPI()
    app.include_router(router)
    return app


client = TestClient(setup_test_app())


def test_get_topology_schema_dag() -> None:
    response = client.get("/api/v1/schema/topology/dag")
    assert response.status_code == 200
    data = response.json()
    assert "$ref" in data
    assert "DAGTopologyManifest" in data["$ref"]
    assert "$defs" in data


def test_get_topology_schema_swarm() -> None:
    response = client.get("/api/v1/schema/topology/swarm")
    assert response.status_code == 200
    data = response.json()
    assert "$ref" in data
    assert "SwarmTopologyManifest" in data["$ref"]
    assert "$defs" in data


def test_get_topology_schema_workflow() -> None:
    response = client.get("/api/v1/schema/topology/workflow")
    assert response.status_code == 200
    data = response.json()
    # WorkflowManifest is a root-object schema, not a $ref
    assert data.get("title") == "WorkflowManifest"
    # Must contain definitions for all top-level fields that were causing VSCode errors
    assert "$defs" in data
    props = data.get("properties", {})
    assert "manifest_version" in props, "manifest_version must be in WorkflowManifest schema"
    assert "tenant_cid" in props, "tenant_cid must be in WorkflowManifest schema"
    assert "session_cid" in props, "session_cid must be in WorkflowManifest schema"
    assert "genesis_provenance" in props, "genesis_provenance must be in WorkflowManifest schema"
    assert "topology" in props, "topology must be in WorkflowManifest schema"


def test_get_topology_schema_invalid() -> None:
    response = client.get("/api/v1/schema/topology/invalid_topology")
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data
    assert "Unknown topology or schema model: invalid_topology" in data["detail"]


def test_get_receipt_schema() -> None:
    response = client.get("/api/v1/schema/receipt")
    assert response.status_code == 200
    data = response.json()
    assert "title" in data
    assert data["title"] == "ExecutionNodeReceipt"
    assert "$defs" in data


@patch("coreason_runtime.api.schema.router.Path")
def test_get_capabilities_schema_with_tools(mock_path) -> None:  # type: ignore[no-untyped-def]
    mock_instance = mock_path.return_value
    mock_instance.exists.return_value = True
    mock_instance.is_dir.return_value = True

    class MockFile:
        def __init__(self, stem: str) -> None:
            self.stem = stem

    mock_instance.glob.return_value = [MockFile("tool_a"), MockFile("tool_b")]

    response = client.get("/api/v1/schema/capabilities")
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "ExecutableCapabilities"
    assert "tool_a" in data["enum"]
    assert "tool_b" in data["enum"]


@patch("coreason_runtime.api.schema.router.Path")
def test_get_capabilities_schema_no_tools(mock_path) -> None:  # type: ignore[no-untyped-def]
    mock_instance = mock_path.return_value
    mock_instance.exists.return_value = False

    response = client.get("/api/v1/schema/capabilities")
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "ExecutableCapabilities"
    assert data["enum"] == ["no_tools_available"]
