# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import time
from unittest.mock import MagicMock

import pandas as pd
import pytest

from coreason_runtime.memory.latent import LatentMemoryManager


@pytest.fixture
def mock_medallion_engine():
    """Build structurally sound engine boundaries natively avoiding database limits securely."""

    class MockEngine:
        def __init__(self):
            self.db = MagicMock()
            self.mock_table = MagicMock()
            self.db.open_table.return_value = self.mock_table

            self.deleted_conditions = []

            def mock_delete(condition):
                self.deleted_conditions.append(condition)

            self.mock_table.delete.side_effect = mock_delete

    return MockEngine()


@pytest.mark.asyncio
async def test_epistemic_pruning_retains_active_memory(mock_medallion_engine):
    """Prove that exactly robust active vectors safely survive decay algorithms gracefully."""
    manager = LatentMemoryManager(mock_medallion_engine)

    now = time.time()

    # Mathematical setup:
    # Vec 1: New (0 age), frequency 1 -> utility 1
    # Vec 2: Old (100 age), frequency 1 -> utility ~0.000045 (decay=0.1) -> Pruned
    # Vec 3: Old (10 age), frequency 50 -> utility 50 * exp(-1) = 18.39 -> Kept
    mock_df = pd.DataFrame(
        {
            "intent_hash": ["active_new", "stale_forget", "active_frequent"],
            "timestamp": [now, now - 100, now - 10],
            "access_frequency": [1, 1, 50],
        }
    )

    mock_medallion_engine.mock_table.to_pandas.return_value = mock_df

    decay_rate = 0.1
    utility_threshold = 0.5

    pruned = await manager.prune_stale_vectors(decay_rate=decay_rate, threshold=utility_threshold, protected_cids=[])

    assert pruned == 1
    assert len(mock_medallion_engine.deleted_conditions) == 1
    assert "stale_forget" in mock_medallion_engine.deleted_conditions[0]
    assert "active_new" not in mock_medallion_engine.deleted_conditions[0]
    assert "active_frequent" not in mock_medallion_engine.deleted_conditions[0]


@pytest.mark.asyncio
async def test_epistemic_pruning_empty_database(mock_medallion_engine):
    """Prove exact handling bounds correctly handle structurally unbounded null topologies."""
    manager = LatentMemoryManager(mock_medallion_engine)

    mock_df = pd.DataFrame(columns=["intent_hash", "timestamp", "access_frequency"])
    mock_medallion_engine.mock_table.to_pandas.return_value = mock_df

    pruned = await manager.prune_stale_vectors(decay_rate=0.1, threshold=0.5, protected_cids=[])

    assert pruned == 0
    assert len(mock_medallion_engine.deleted_conditions) == 0
