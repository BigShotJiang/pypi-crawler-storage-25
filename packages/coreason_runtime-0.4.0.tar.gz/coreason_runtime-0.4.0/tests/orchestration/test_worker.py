# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, patch

import pytest

from coreason_runtime.orchestration.worker import start_worker


@pytest.mark.asyncio
async def test_start_worker_main(monkeypatch: pytest.MonkeyPatch):
    with (
        patch("coreason_runtime.orchestration.worker.Worker") as mock_worker_cls,
        patch("coreason_runtime.orchestration.worker.Client.connect", new_callable=AsyncMock),
    ):
        mock_worker_inst = AsyncMock()
        mock_worker_cls.return_value = mock_worker_inst

        monkeypatch.setenv("PLUGINS_DIR", "/tmp/plugins")
        monkeypatch.setenv("LANCEDB_URI", "/tmp/lancedb")

        await start_worker("localhost:7233")
        mock_worker_cls.assert_called()
        mock_worker_inst.run.assert_called_once()
