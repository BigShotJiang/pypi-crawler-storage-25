# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import pytest
from coreason_manifest.spec.ontology import IdeationPhaseProfile
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

from coreason_runtime.orchestration.workflows.stochastic_execution_workflow import (
    StochasticExecutionWorkflow,
    evaluate_transition_probability_activity,
)


@pytest.fixture
def mock_manifest_payload() -> dict:
    """Provides a structurally sound StochasticTopologyManifest payload dict."""
    return {
        "topology_cid": "stoch_topo_1",
        "phase": IdeationPhaseProfile.STOCHASTIC_DIFFUSION,
        "stochastic_graph": [
            {
                "node_cid": "branch_A",
                "agent_role": "generator",
                "stochastic_tensor": "test logic 1",
                "epistemic_entropy": 0.5,
            },
            {
                "node_cid": "branch_B",
                "agent_role": "critic",
                "stochastic_tensor": "test logic 2",
                "epistemic_entropy": 0.2,
            },
        ],
        "superposition": {
            "superposition_cid": "sup_1",
            "wave_collapse_function": "highest_confidence",
            "competing_manifolds": {
                "branch_A": 0.8,
                "branch_B": 0.2,
            },
        },
    }


@pytest.mark.asyncio
async def test_markov_blanket_enforcer_rejects_illegal_caller(mock_manifest_payload: dict):
    """Ensure direct injection into an isolated Markov state throws a ManifestConformanceError."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="markov-queue",
            workflows=[StochasticExecutionWorkflow],
            activities=[evaluate_transition_probability_activity],
        ):
            # caller_cid "evil_hacker" maliciously bypasses the listed sensory edges ["valid_node_1"]
            valid_edges = ["valid_node_1", "valid_node_2"]
            caller_cid = "evil_hacker"

            from temporalio.client import WorkflowFailureError

            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    StochasticExecutionWorkflow.run,
                    args=[mock_manifest_payload, caller_cid, valid_edges],
                    id="markov-test-workflow",
                    task_queue="markov-queue",
                )

            assert "Markov Blanket Subversion" in str(exc_info.value.cause)


@pytest.mark.asyncio
async def test_stochastic_execution_workflow_valid_sensory_edge(mock_manifest_payload: dict):
    """Ensure that valid sensory edge calls perform stochastic branch evaluation flawlessly natively."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="stochastic-queue",
            workflows=[StochasticExecutionWorkflow],
            activities=[evaluate_transition_probability_activity],
        ):
            valid_edges = ["trusted_sensory_node"]
            caller_cid = "trusted_sensory_node"

            result = await env.client.execute_workflow(
                StochasticExecutionWorkflow.run,
                args=[mock_manifest_payload, caller_cid, valid_edges],
                id="stochastic-test-workflow",
                task_queue="stochastic-queue",
            )

            assert result["status"] == "stochastic_execution_completed"
            assert result["traversed_branch"] in ["branch_A", "branch_B"]
