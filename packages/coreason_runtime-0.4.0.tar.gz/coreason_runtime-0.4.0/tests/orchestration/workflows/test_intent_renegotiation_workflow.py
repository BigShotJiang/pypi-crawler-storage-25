# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for Intent Renegotiation workflow."""

from typing import Any

import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.intent_renegotiation_workflow import (
    IntentRenegotiationExecutionWorkflow,
    parse_rejection_parameters_activity,
    synthesize_compromise_intent_activity,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.mark.asyncio
async def test_intent_renegotiation_workflow_success() -> None:
    """Test mathematically constrained renegotiation convergence."""
    payload = {
        "rejection": {
            "event_cid": "evt_1",
            "prior_event_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            "timestamp": 1712966400.0,
            "topology_class": "epistemic_rejection",
            "receipt_cid": "rec_1",
            "failed_projection_cid": "proj_1",
            "violated_algebraic_constraint": "X > 5",
            "kl_divergence_to_validity": 0.5,
            "stochastic_mutation_gradient": "grad_1",
        },
        "intent": {
            "jsonrpc": "2.0",
            "method": "do_something",
            "params": {"test": True},
            "id": "1",
        },
    }
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="intent-renegotiation-queue",
            workflows=[IntentRenegotiationExecutionWorkflow],
            activities=[parse_rejection_parameters_activity, synthesize_compromise_intent_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                IntentRenegotiationExecutionWorkflow.run,
                payload,
                id="test-val-wf-2",
                task_queue="intent-renegotiation-queue",
            )
            assert result["new_intent"]["params"] == {"adjusted": True}


@pytest.mark.asyncio
async def test_intent_renegotiation_failures() -> None:
    """Test rigorous schema conformance enforcement."""
    payload_bad_eval: dict[str, Any] = {"rejection": {}}
    with pytest.raises(ManifestConformanceError) as exc_info:
        await parse_rejection_parameters_activity(payload_bad_eval)
    assert "Invalid EpistemicRejectionReceipt" in str(exc_info.value)

    payload_bad_update: dict[str, Any] = {"intent": {}}
    with pytest.raises(ManifestConformanceError) as exc_info:
        await synthesize_compromise_intent_activity(payload_bad_update)
    assert "Invalid BoundedJSONRPCIntent" in str(exc_info.value)
