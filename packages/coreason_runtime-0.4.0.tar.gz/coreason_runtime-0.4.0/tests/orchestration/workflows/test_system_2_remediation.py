# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import pytest
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

from coreason_runtime.orchestration.workflows.system_2_remediation_workflow import (
    System2RemediationWorkflow,
    execute_node_regeneration_activity,
)


@pytest.fixture
def remediable_payload() -> dict:
    """Structurally compliant System2RemediationIntent simulating a fixable gradient."""
    return {
        "topology_class": "system_2_remediation",
        "fault_cid": "fault-100",
        "target_node_cid": "node_generator_1",
        "violation_receipts": [
            {
                "failing_pointer": "/step_2/parameters/0",
                "violation_category": "type_error",
                "diagnostic_message": "Expected string, got int",
            }
        ],
        "ast_gradient": {"loss_vector_magnitude": 0.5, "topological_distance": 1.2},
    }


@pytest.fixture
def unrecoverable_payload() -> dict:
    """Structurally compliant payload causing persistent failure bounds."""
    return {
        "topology_class": "system_2_remediation",
        "fault_cid": "fault-101",
        "target_node_cid": "node_generator_1",
        "violation_receipts": [
            {
                "failing_pointer": "/step_1",
                "violation_category": "missing_key",
                "diagnostic_message": "Key 'data' not found",
            }
        ],
        "ast_gradient": {"loss_vector_magnitude": 0.95, "topological_distance": 9.9},
    }


@pytest.mark.asyncio
async def test_system_2_remediation_success(remediable_payload: dict):
    """Ensure the workflow triggers remediation targeting exact RFC pointers and recovers."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="remediation-queue",
            workflows=[System2RemediationWorkflow],
            activities=[execute_node_regeneration_activity],
        ):
            result = await env.client.execute_workflow(
                System2RemediationWorkflow.run,
                args=[remediable_payload],
                id="test-remediation-1",
                task_queue="remediation-queue",
            )
            assert result["status"] == "remediation_successful"
            assert result["attempts"] == 1


@pytest.mark.asyncio
async def test_system_2_remediation_exhaustion(unrecoverable_payload: dict):
    """Proves the workflow executes bounded recursive retries but ultimately halts causing SystemFaultEvent."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="remediation-queue",
            workflows=[System2RemediationWorkflow],
            activities=[execute_node_regeneration_activity],
        ):
            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    System2RemediationWorkflow.run,
                    args=[unrecoverable_payload],
                    id="test-remediation-2",
                    task_queue="remediation-queue",
                )

            assert "SystemFaultEvent" in str(exc_info.value.cause)
            assert "after 3 attempts" in str(exc_info.value.cause)
