# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""AGENT INSTRUCTION: Counterfactual Integration Testing for Speculative workflows and Defeasible Cascades."""

import asyncio
import contextlib
import tempfile
import uuid
from typing import Any

import hypothesis.strategies as st
import pytest
from coreason_manifest.spec.ontology import DefeasibleCascadeEvent
from hypothesis import given, settings
from temporalio import workflow
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.orchestration.workflows.speculative_execution_workflow import SpeculativeExecutionWorkflow


# Dummy child workflow to bypass actual DAG complexity in unit tests
@workflow.defn(name="DAGExecutionWorkflow")
class DummyDAGExecutionWorkflow:
    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        await asyncio.sleep(0.5)  # Simulate execution time to allow signals to hit
        return {"status": "success", "mock_dag": True}


@pytest.mark.asyncio
async def test_speculative_workflow_rollback() -> None:
    """Verify that a RollbackIntent correctly halts the SpeculativeExecutionWorkflow and unwinds."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="speculative-test-queue",
            workflows=[SpeculativeExecutionWorkflow, DummyDAGExecutionWorkflow],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            # Construct a Speculative Execution payload
            test_workflow_id = f"test-spec-{uuid.uuid4()}"
            rollback_anchors = ["checkpoint_A1", "checkpoint_B2"]
            payload = {
                "execution_cid": test_workflow_id,
                "orchestrator_directive": "run",
                "topology_class": "macro_speculative",
                "payload": {
                    "speculative_cid": "spec_branch_1",
                    "commit_probability": 0.5,
                    "rollback_pointers": rollback_anchors,
                },
            }

            # Start workflow mapped asynchronously
            handle = await env.client.start_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id=test_workflow_id,
                task_queue="speculative-test-queue",
            )

            # Let it spin up the shadow DAG
            await asyncio.sleep(0.1)

            # Signal a rollback intent causing branch falsification
            rollback_intent = {
                "intent_hash": "falsified_hash_001",
                "reason": "Foundational fact physically contradicted.",
            }
            await handle.signal(SpeculativeExecutionWorkflow.receive_rollback_intent, rollback_intent)

            # Await conclusion
            result = await handle.result()

            # Verify causal rollback correctly yielded
            assert result["status"] == "rolled_back"
            assert result["falsified_subgraph"] == "spec_branch_1"
            assert result["rewind_anchors"] == rollback_anchors
            assert result["rollback_intent"] == rollback_intent


# Hypothesis strategy to generate randomized causal chains mapping circular loops securely.
def generate_causal_chain():
    return st.lists(
        st.tuples(
            st.text(alphabet="ABCDEF", min_size=1, max_size=1),  # parent
            st.text(alphabet="ABCDEF", min_size=1, max_size=1),  # child
        ),
        min_size=2,
        max_size=10,
    )


@pytest.mark.asyncio
@given(chain_links=generate_causal_chain())
@settings(max_examples=10, deadline=None)  # Deadline disabled for async testing geometries
async def test_defeasible_cascade_ablation_logic(chain_links: list[tuple[str, str]]) -> None:
    """AGENT INSTRUCTION: Mathematically prove the graph ablation engine safely trims Epistemic Contagion using networkx paths."""
    # Build a simulated history out of randomized tuples avoiding internal paradox checks manually.
    history_records = []
    nodes_seen = set()
    for parent, child in chain_links:
        if child not in nodes_seen:
            history_records.append({"event_cid": child, "causal_attributions": [parent]})
            nodes_seen.add(child)
        if parent not in nodes_seen:
            history_records.append({"event_cid": parent, "causal_attributions": []})
            nodes_seen.add(parent)

    # Pick a random root to falsify
    if not chain_links:
        return

    root_falsified = chain_links[0][0]

    ledger_payload = {
        "ledger_cid": "ledger_test_1",
        "workflow_id": "wf_test_1",
        "history": history_records,
        "retracted_nodes": [],
        "active_cascades": [],
        "root_entropy": 0.0,
    }

    cascade_payload = {
        "cascade_cid": "cascade_event_x",
        "root_falsified_event_cid": root_falsified,
        "propagated_decay_factor": 0.5,
        "quarantined_event_cids": [root_falsified],
        "cross_boundary_quarantine_issued": False,
    }

    import networkx as nx

    with tempfile.TemporaryDirectory() as tmpdir:
        # Spin up actual DB natively bounded to safe logic limits
        activities = KineticActivities(
            sglang_url="http://mock", memory_path=tmpdir, plugins_dir="/tmp", telemetry_url="http://mock_telemetry"
        )

        # We invoke the activity explicitly to calculate paths natively
        result = await activities.execute_defeasible_cascade_compute_activity(
            cascade_intent_payload=cascade_payload, ledger_snapshot_payload=ledger_payload
        )

        # Verify logical execution successfully handled
        assert result["status"] == "success"

        retracted = result["retracted_nodes"]
        # In a real graph, verifying exact blast radius natively via a different algorithm protects against errors:
        graph = nx.DiGraph()
        for link in chain_links:
            graph.add_edge(link[0], link[1])

        expected_retracted = set()
        if root_falsified in graph:
            with contextlib.suppress(nx.NetworkXError):
                expected_retracted = nx.descendants(graph, root_falsified)

        # Ensure exact semantic match
        assert set(retracted) == expected_retracted

        # Assure correct storage limits
        await activities.ledger.bootstrap()
        await activities.ledger.commit_retracted_nodes("wf_test_1", retracted)
        await activities.ledger.commit_cascade_event(
            "wf_test_1", DefeasibleCascadeEvent.model_validate(cascade_payload)
        )

        # Validation mapping against persistent bindings
        state = await activities.ledger.fetch_epistemic_ledger_state("wf_test_1")
        assert set(state.retracted_nodes) == expected_retracted
