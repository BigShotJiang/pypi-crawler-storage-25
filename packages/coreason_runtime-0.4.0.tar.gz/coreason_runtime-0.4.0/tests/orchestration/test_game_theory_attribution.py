# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

from coreason_runtime.orchestration.activities import (
    execute_collective_intelligence_activity,
    execute_market_settlement_io_activity,
    execute_shapley_attribution_compute_activity,
)
from coreason_runtime.orchestration.workflows.value_attribution_workflow import ValueAttributionWorkflow


@pytest.mark.asyncio
async def test_shapley_solver_efficiency():
    """AGENT INSTRUCTION: Verify the Efficiency, Symmetry, and Dummy axioms mathematically aligning marginal utility mapping limits."""
    # N=4 Exact Configuration
    agents = ["did:coreason:agent-1", "did:coreason:agent-2", "did:coreason:agent-3", "did:coreason:agent-4"]
    outcome_magnitude = 100.0

    receipts = await execute_shapley_attribution_compute_activity(
        outcome_magnitude=outcome_magnitude, agent_cids=agents, characteristic_values=None
    )

    total = sum(r["causal_attribution_score"] for r in receipts)
    assert abs(total - 1.0) < 0.001

    # Validate Symmetry Constraints natively mathematically bounds
    assert receipts[0]["causal_attribution_score"] == receipts[1]["causal_attribution_score"]
    assert receipts[0]["normalized_contribution_percentage"] == 0.25


@pytest.mark.asyncio
async def test_shapley_solver_monte_carlo():
    """AGENT INSTRUCTION: Assert the Monte Carlo algorithm computes properly within boundaries seamlessly mapping efficiency for scale."""
    # N=12 Monte Carlo Scale Configuration
    agents = [f"did:coreason:agent-{i}" for i in range(12)]
    outcome_magnitude = 500.0

    receipts = await execute_shapley_attribution_compute_activity(
        outcome_magnitude=outcome_magnitude, agent_cids=agents, characteristic_values=None
    )

    # Efficiency Axiom verification mapping correctly bounds exactly precisely securely
    total = sum(r["causal_attribution_score"] for r in receipts)
    assert abs(total - 1.0) < 0.001


@pytest.mark.asyncio
async def test_market_settlement_logic():
    """AGENT INSTRUCTION: Verify Brier Scores effectively distribute outcome distributions securely mapping prediction bounds cleanly."""

    auction_payload = {
        "market_cid": "test_auction_1",
        "resolution_oracle_condition_cid": "win",
        "lmsr_b_parameter": "10.0",
        "current_market_probabilities": {"target_win": "0.5", "target_lose": "0.5"},
        "order_book": [
            {
                "agent_cid": "did:coreason:agent-a",
                "target_hypothesis_cid": "target_win",
                "staked_magnitude": 100,
                "implied_probability": 0.9,
            },
            {
                "agent_cid": "did:coreason:agent-a",
                "target_hypothesis_cid": "target_lose",
                "staked_magnitude": 100,
                "implied_probability": 0.1,
            },
            {
                "agent_cid": "did:coreason:agent-b",
                "target_hypothesis_cid": "target_win",
                "staked_magnitude": 100,
                "implied_probability": 0.4,
            },
        ],
    }

    res = await execute_market_settlement_io_activity(
        auction_payload=auction_payload, winning_hypothesis_cid="target_win"
    )

    assert res["settlement_status"] == "cleared"
    assert res["brier_scores"]["did:coreason:agent-a"] < res["brier_scores"]["did:coreason:agent-b"]
    assert res["payout_distribution"]["did:coreason:agent-a"] > res["payout_distribution"]["did:coreason:agent-b"]


@pytest.mark.asyncio
async def test_value_attribution_workflow_end_to_end():
    """AGENT INSTRUCTION: Assert end-to-end ValueAttribution workflow strictly commits structurally accurate macro causality nodes."""

    @activity.defn(name="StoreEpistemicStateIOActivity")
    async def mocked_store(_payload: dict[str, Any]) -> dict[str, str]:  # pragma: no cover
        return {"status": "success", "event_cid": "mocked"}

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="test-value-q",
            workflows=[ValueAttributionWorkflow],
            activities=[
                execute_shapley_attribution_compute_activity,
                execute_collective_intelligence_activity,
                mocked_store,
            ],
        ):
            payload = {
                "target_outcome_event_cid": "test_target_cid",
                "agent_cids": ["did:test:agent-x", "did:test:agent-y", "did:test:agent-z"],
                "outcome_magnitude": 300.0,
            }

            result = await env.client.execute_workflow(
                "ValueAttributionWorkflow",
                payload,
                id="test-value-wf-1",
                task_queue="test-value-q",
            )

            assert result["status"] == "success"
            assert "causal_exp_test_target_cid" in result["event_cid"]
