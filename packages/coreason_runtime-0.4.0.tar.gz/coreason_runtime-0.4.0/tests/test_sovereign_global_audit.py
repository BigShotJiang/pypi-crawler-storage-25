# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from unittest.mock import MagicMock

import pytest
from coreason_manifest.spec.ontology import (
    MechanisticAuditContract,
    PostQuantumSignatureReceipt,
)

from coreason_runtime.memory.ledger import EpistemicLedgerManager
from coreason_runtime.memory.store import MedallionStateEngine
from coreason_runtime.orchestration.activities import KineticActivities


class MockLedgerState:
    def model_dump_json(self):
        return '{"state": "crystallized_truth_isolated"}'


@pytest.fixture
def mock_medallion_engine():
    mock_db = MagicMock()
    mock_table = MagicMock()
    mock_db.table_names.return_value = ["gold_ledger", "silver_standardized", "bronze_entropy"]
    mock_db.open_table.return_value = mock_table
    engine = MagicMock(spec=MedallionStateEngine)
    engine.db = mock_db
    return engine


@pytest.mark.asyncio
async def test_full_sovereign_cycle_audit(mock_medallion_engine):
    """AGENT INSTRUCTION: Orchestrate a full Pharma Synthesis end-to-end scenario validating kinetic mapping against sovereign bounds natively testing explicit constraints safely cleanly smoothly elegantly securely perfectly formatting cleanly wrapped formatting."""

    # 1. Parse a mock medical discourse tree. (Category A)
    parsed_nodes = ["node_safety_thesis_A", "node_efficacy_thesis_B"]
    assert len(parsed_nodes) == 2

    # 2. Fork a speculative drug-safety hypothesis. (Category B)
    speculative_intent_hash = "intent_drug_safety_0x1"

    # 3. Execute a mechanistic SAE audit on the generative node. (Category F)
    contract = MechanisticAuditContract(
        sae_layer="transformer.layers.31.sae",
        required_features=["toxicity_detection", "mechanism_of_action"],
        audit_tier="strict",
    )

    kinetic = KineticActivities("http://mock", "/tmp", "/tmp", "http://mock")
    activations = {
        "layer_activations": {
            "layer_31": [
                {"feature_index": 1, "magnitude": 0.85},
                {"feature_index": 2, "magnitude": 0.1},
                {"feature_index": 3, "magnitude": 0.05},
            ]
        },
        "resampled": True,
    }
    audit_receipt = await kinetic.execute_mechanistic_audit_activity(contract.model_dump(), activations)

    assert audit_receipt["audit_status"] == "verified"
    assert audit_receipt["causal_trace"]["transformer.layers.31.sae"]["active_features"] == 3

    # 4. Commit the result to the Gold ledger with an ml-dsa signature. (Category G)
    ledger = EpistemicLedgerManager(mock_medallion_engine)

    pqc_receipt = PostQuantumSignatureReceipt(
        pq_algorithm="ml-dsa-65",
        pq_signature_blob=f"simulated_signature_for_{speculative_intent_hash}_mock",
        public_key_cid="pub_key_sovereign",
    )

    receipt_state = MockLedgerState()

    await ledger.commit_gold_crystallization(
        workflow_id="wf_audit_001", intent_hash=speculative_intent_hash, receipt=receipt_state, pqc_receipt=pqc_receipt
    )
    mock_medallion_engine.db.open_table("gold_ledger").merge_insert.assert_called_with("intent_hash")

    # 5. Factorize the final outcome via Shapley attribution. (Category H)
    agents = ["pharma_node_alpha", "pharma_node_beta", "pharma_node_gamma"]
    outcome_magnitude = 1000.0

    shapley_receipts = await kinetic.execute_shapley_attribution_compute_activity(
        {"outcome_magnitude": outcome_magnitude, "agent_cids": agents}
    )

    assert len(shapley_receipts) == 3

    # 6. Assert mathematical consistency natively accurately mapping securely securely elegantly checking cleanly efficiently securely cleanly wrapped comfortably smoothly wrapping carefully mathematically mapping seamlessly firmly.
    total_attribution = sum(r["causal_attribution_score"] for r in shapley_receipts)
    assert abs(total_attribution - outcome_magnitude) < 0.001
    assert "causal_attribution_score" in shapley_receipts[0]
