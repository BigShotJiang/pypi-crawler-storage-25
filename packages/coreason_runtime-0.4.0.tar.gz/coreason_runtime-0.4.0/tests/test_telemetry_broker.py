# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
import contextlib

import pytest
from fastapi.testclient import TestClient

from coreason_runtime.telemetry.broker import _active_clients, app
from coreason_runtime.telemetry.events import NodeStartedEvent

client = TestClient(app)


def test_telemetry_broker_push_success() -> None:
    # Test valid event push
    event = NodeStartedEvent(
        event_type="NodeStartedEvent",
        node_cid="node_1",
        agent_name="TestAgent",
        timestamp="2026-01-01T00:00:00Z",
    )

    response = client.post("/api/v1/telemetry/push", json=event.model_dump())
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_telemetry_broker_push_invalid() -> None:
    # Test invalid event push without event_type
    response = client.post("/api/v1/telemetry/push", json={"random": "data"})
    assert response.status_code == 200
    assert response.json()["status"] == "error"


@pytest.mark.asyncio
async def test_telemetry_broker_stream() -> None:
    from httpx import ASGITransport, AsyncClient

    # Empty active clients
    _active_clients.clear()

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:

        async def stream_consumer() -> None:
            # Use httpx streaming API instead of task cancellation to properly close the stream connection.
            async with ac.stream("GET", "/api/v1/telemetry/stream") as stream_response:
                # Wait for stream to be connected and queue appended
                async for line in stream_response.aiter_lines():
                    if line:
                        break

        consumer_task = asyncio.create_task(stream_consumer())

        for _ in range(50):
            if len(_active_clients) > 0:
                break
            await asyncio.sleep(0.01)

        assert len(_active_clients) == 1

        # Now push an event
        push_response = await ac.post(
            "/api/v1/telemetry/push",
            json={
                "event_type": "NodeStartedEvent",
                "node_cid": "test",
                "agent_name": "agent",
                "timestamp": "now",
            },
        )
        assert push_response.status_code == 200

        consumer_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await consumer_task

        assert len(_active_clients) == 0


def test_telemetry_broker_startup_shutdown() -> None:
    # TestClient doesn't close streams automatically properly inside context sometimes
    # Using a fast GET /api/v1/telemetry/push to just test context startup shutdown
    import unittest.mock

    # We must patch the import in subscriber.py since the lifespan directly imports it
    # But because lifespan executes within the FastAPI scope, patching it within subscriber is more robust
    with (
        unittest.mock.patch(
            "coreason_runtime.telemetry.subscriber.bronze_ingestion_loop", new_callable=unittest.mock.AsyncMock
        ),
        TestClient(app) as test_client,
    ):
        response = test_client.post("/api/v1/telemetry/push", json={"event_type": "Fake"})
        assert response.status_code == 200
