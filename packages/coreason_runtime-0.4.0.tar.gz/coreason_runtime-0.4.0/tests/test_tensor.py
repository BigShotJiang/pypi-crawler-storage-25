# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pydantic
import pytest

from coreason_runtime.tensor.client import CloudOracleClient, SGLangKineticClient
from coreason_runtime.tensor.compiler import UniversalCompiler
from coreason_runtime.tensor.router import BudgetExceededError, EpistemicYieldError, TensorRouter


class DummyModel(pydantic.BaseModel):
    name: str
    age: int


def test_universal_compiler_compile() -> None:
    schema = UniversalCompiler.compile_schema(DummyModel)
    assert isinstance(schema, dict)


@pytest.mark.asyncio
async def test_universal_compiler_validate_and_retry_success() -> None:
    async def mock_llm_callable(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice", "age": 30}', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    result, usage = await UniversalCompiler.validate_and_retry(DummyModel, mock_llm_callable, "prompt")
    assert result.name == "Alice"
    assert result.age == 30
    assert usage["prompt_tokens"] == 10
    assert usage["completion_tokens"] == 5


@pytest.mark.asyncio
async def test_universal_compiler_validate_and_retry_failure() -> None:
    async def mock_llm_callable(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice"}', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    with pytest.raises(ValueError, match="Epistemic Collapse"):
        await UniversalCompiler.validate_and_retry(DummyModel, mock_llm_callable, "prompt", max_attempts=3)


@pytest.mark.asyncio
async def test_universal_compiler_json_decode_error() -> None:
    async def mock_llm_callable(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    with pytest.raises(ValueError, match="Epistemic Collapse"):
        await UniversalCompiler.validate_and_retry(DummyModel, mock_llm_callable, "prompt", max_attempts=3)


@pytest.mark.asyncio
async def test_sglang_kinetic_client() -> None:
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {
        "text": '{"result": "success"}',
        "meta_info": {"prompt_tokens": 10, "completion_tokens": 20},
    }

    client = SGLangKineticClient("http://sglang")
    client.client = AsyncMock()
    client.client.post = AsyncMock(return_value=mock_response)

    result, usage, probs = await client.generate("prompt", {"type": "object"}, constrained_decoding=True)
    assert result == '{"result": "success"}'
    assert usage["prompt_tokens"] == 10
    assert usage["completion_tokens"] == 20
    assert usage["total_tokens"] == 30
    assert probs == pytest.approx([1.0, 0.0])

    # Verify correct API call was made
    call_args = client.client.post.call_args
    assert "generate" in call_args[0][0]
    request_body = call_args[1]["json"]
    assert request_body["text"] == "prompt"
    assert "sampling_params" in request_body
    assert "temperature" in request_body["sampling_params"]
    assert "max_new_tokens" in request_body["sampling_params"]
    assert "json_schema" in request_body["sampling_params"]


@pytest.mark.asyncio
async def test_cloud_oracle_client() -> None:
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {
        "choices": [{"message": {"content": '{"request_cid": "test-123"}'}}],
        "usage": {"prompt_tokens": 50, "completion_tokens": 25},
    }

    client = CloudOracleClient(api_key="test-key", base_url="https://api.test.com/v1", model="test-model")
    client.client = AsyncMock()
    client.client.post = AsyncMock(return_value=mock_response)

    result, usage, probs = await client.generate("prompt", {"type": "object"}, constrained_decoding=True)
    assert result == '{"request_cid": "test-123"}'
    assert usage["prompt_tokens"] == 50
    assert usage["completion_tokens"] == 25
    assert probs == pytest.approx([1.0, 0.0])

    call_args = client.client.post.call_args
    assert "chat/completions" in call_args[0][0]
    request_body = call_args[1]["json"]
    assert request_body["model"] == "test-model"
    assert request_body["response_format"] == {
        "type": "json_schema",
        "json_schema": {
            "name": "agent_response_schema",
            "schema": {"type": "object"},
            "strict": True,
        },
    }
    assert len(request_body["messages"]) == 2
    assert request_body["messages"][0]["role"] == "system"
    assert request_body["messages"][1]["role"] == "user"


@pytest.mark.asyncio
async def test_cloud_oracle_client_system_prompt() -> None:
    client = CloudOracleClient(api_key="test-key", base_url="https://api.test.com/v1", model="test-model")
    system_prompt = client._build_system_prompt()
    assert "JSON Schema execution bounds" in system_prompt
    assert "deterministic execution engine" in system_prompt


@pytest.mark.asyncio
async def test_cloud_oracle_client_env_defaults() -> None:
    with patch.dict(
        "os.environ",
        {
            "CLOUD_ORACLE_API_KEY": "env-key",
            "CLOUD_ORACLE_BASE_URL": "https://env.api.com/v1",
            "CLOUD_ORACLE_MODEL": "env-model",
        },
    ):
        client = CloudOracleClient()
        assert client.api_key == "env-key"
        assert client.base_url == "https://env.api.com/v1"
        assert client.model == "env-model"


@pytest.mark.asyncio
async def test_tensor_router_success() -> None:
    router = TensorRouter("http://sglang")

    with patch.object(UniversalCompiler, "validate_and_retry", new_callable=AsyncMock) as mock_validate:
        mock_validate.return_value = (DummyModel(name="Alice", age=30), {"prompt_tokens": 10, "completion_tokens": 5})
        result, _usage, _cost, _acc_tokens, _sig = await router.route_inference("wf_1", "prompt", DummyModel)
        assert result.name == "Alice"
        assert result.age == 30
        assert router.budgets["wf_1"] == 15  # 10 + 5


@pytest.mark.asyncio
async def test_tensor_router_cascade() -> None:
    router = TensorRouter("http://sglang")

    async def mock_validate(
        _schema_class: type[Any], llm_callable: Any, _prompt: str, _max_attempts: int = 3, **_kwargs: Any
    ) -> tuple[Any, dict[str, int]]:
        if getattr(llm_callable, "__name__", "") == "_call_kinetic":
            raise ValueError("Kinetic Error")
        return DummyModel(name="Bob", age=40), {"prompt_tokens": 20, "completion_tokens": 10}

    with patch.object(UniversalCompiler, "validate_and_retry", side_effect=mock_validate):
        result, _usage, _cost, _acc_tokens, _sig = await router.route_inference("wf_1", "prompt", DummyModel)
        assert result.name == "Bob"
        assert result.age == 40
        assert router.budgets["wf_1"] == 30  # 20 + 10


@pytest.mark.asyncio
async def test_tensor_router_epistemic_yield() -> None:
    router = TensorRouter("http://sglang")

    async def mock_validate(
        _schema_class: type[Any], _llm_callable: Any, _prompt: str, _max_attempts: int = 3, **_kwargs: Any
    ) -> tuple[Any, dict[str, int]]:
        raise ValueError("Oracle Error")

    with (
        patch.object(UniversalCompiler, "validate_and_retry", side_effect=mock_validate),
        pytest.raises(EpistemicYieldError, match="Autonomic Cascade Failed"),
    ):
        await router.route_inference("wf_1", "prompt", DummyModel)


@pytest.mark.asyncio
async def test_tensor_router_oracle_yield() -> None:
    router = TensorRouter("http://sglang")

    async def mock_validate(
        _schema_class: type[Any], llm_callable: Any, _prompt: str, _max_attempts: int = 3, **_kwargs: Any
    ) -> tuple[Any, dict[str, int]]:
        if getattr(llm_callable, "__name__", "") == "_call_kinetic":
            raise ValueError("Kinetic Error")
        raise ValueError("Oracle Yield Error")

    with (
        patch.object(UniversalCompiler, "validate_and_retry", side_effect=mock_validate),
        pytest.raises(EpistemicYieldError, match="Autonomic Cascade Failed"),
    ):
        await router.route_inference("wf_1", "prompt", DummyModel)


@pytest.mark.asyncio
async def test_tensor_router_budget_exceeded() -> None:
    router = TensorRouter("http://sglang")

    with patch.object(UniversalCompiler, "validate_and_retry", new_callable=AsyncMock) as mock_validate:
        # Exceed budget raises BudgetExceededError in _deduct_budget, which is caught
        # and re-raised as EpistemicYieldError in the cascade
        mock_validate.return_value = (
            DummyModel(name="Alice", age=30),
            {"prompt_tokens": 0, "completion_tokens": 500_000},
        )
        with pytest.raises(EpistemicYieldError, match=r"Autonomic Cascade Failed\. Manual Oracle required\."):
            await router.route_inference("wf_1", "prompt", DummyModel)


def test_budget_exceeded_error_direct() -> None:
    router = TensorRouter("http://sglang")
    with pytest.raises(BudgetExceededError, match="exceeded thermodynamic budget"):
        router._deduct_budget("wf_1", {"prompt_tokens": 0, "completion_tokens": 500_000}, router.MAX_TOKENS)


@pytest.mark.asyncio
async def test_compiler_unreachable() -> None:
    # Test the unreachable block when max_attempts is <= 0
    async def mock_llm_callable(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice", "age": 30}', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    with pytest.raises(ValueError, match="Unreachable"):
        await UniversalCompiler.validate_and_retry(DummyModel, mock_llm_callable, "prompt", max_attempts=0)


@pytest.mark.asyncio
async def test_tensor_router_clients_success() -> None:
    router = TensorRouter("http://sglang")

    # Override clients to track usage correctly
    async def mock_kinetic_generate(*_args: Any, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice", "age": 30}', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    router.kinetic_client.generate = AsyncMock(side_effect=mock_kinetic_generate)  # type: ignore[method-assign]

    result, _usage, _cost, _acc_tokens, _sig = await router.route_inference("wf_1", "prompt", DummyModel)
    assert result.name == "Alice"
    assert result.age == 30

    async def mock_oracle_generate(*_args: Any, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Bob", "age": 40}', {"prompt_tokens": 20, "completion_tokens": 10}, [0.9, 0.1]

    router.kinetic_client.generate = AsyncMock(side_effect=Exception("Kinetic fail"))  # type: ignore[method-assign]
    router.oracle_client.generate = AsyncMock(side_effect=mock_oracle_generate)  # type: ignore[method-assign]

    result2, _usage2, _cost2, _acc_tokens2, _sig2 = await router.route_inference("wf_2", "prompt", DummyModel)
    assert result2.name == "Bob"
    assert result2.age == 40


@pytest.mark.asyncio
async def test_tensor_router_cascade_oracle_success() -> None:
    router = TensorRouter("http://sglang")

    async def mock_validate(
        _schema_class: type[Any], llm_callable: Any, _prompt: str, _max_attempts: int = 3, **_kwargs: Any
    ) -> tuple[Any, dict[str, int]]:
        if getattr(llm_callable, "__name__", "") == "_call_kinetic":
            raise ValueError("Kinetic Error")
        return DummyModel(name="Bob", age=40), {"prompt_tokens": 20, "completion_tokens": 10}

    with patch.object(UniversalCompiler, "validate_and_retry", side_effect=mock_validate):
        result, _usage, _cost, _acc_tokens, _sig = await router.route_inference("wf_1", "prompt", DummyModel)
        assert result.name == "Bob"
        assert result.age == 40
        assert router.budgets["wf_1"] == 30  # 20 + 10


@pytest.mark.asyncio
async def test_tensor_router_budget_exceeded_in_oracle() -> None:
    router = TensorRouter("http://sglang")

    async def mock_validate(
        _schema_class: type[Any], llm_callable: Any, _prompt: str, _max_attempts: int = 3, **_kwargs: Any
    ) -> tuple[Any, dict[str, int]]:
        if getattr(llm_callable, "__name__", "") == "_call_kinetic":
            raise ValueError("Kinetic Error")
        return DummyModel(name="Alice", age=30), {"prompt_tokens": 0, "completion_tokens": 500_000}

    with (
        patch.object(UniversalCompiler, "validate_and_retry", side_effect=mock_validate),
        pytest.raises(EpistemicYieldError, match=r"Autonomic Cascade Failed\. Manual Oracle required\."),
    ):
        await router.route_inference("wf_1", "prompt", DummyModel)


@pytest.mark.asyncio
async def test_tensor_router_cognitive_policies() -> None:
    router = TensorRouter("http://sglang")

    mock_profile = MagicMock()
    mock_profile.compute_frontier = None
    mock_profile.baseline_cognitive_state = None
    mock_profile.logit_steganography = None
    mock_profile.peft_adapters = None
    mock_profile.latent_firewalls = None
    mock_profile.prm_policy = MagicMock()
    mock_profile.analogical_policy = MagicMock()
    mock_profile.symbolic_handoff_policy = None
    mock_profile.audit_policy = MagicMock()
    mock_profile.anchoring_policy = None
    mock_profile.grpo_reward_policy = None
    mock_profile.reflex_policy = MagicMock()
    mock_profile.escalation_policy = None
    mock_profile.correction_policy = None

    with patch.object(UniversalCompiler, "validate_and_retry", new_callable=AsyncMock) as mock_validate:
        mock_validate.return_value = (DummyModel(name="Alice", age=30), {"prompt_tokens": 10, "completion_tokens": 5})

        await router.route_inference("wf_1", "prompt", DummyModel, agent_profile=mock_profile)

        call_kwargs = mock_validate.call_args[1]
        assert call_kwargs.get("top_p", 1.0) == 1.0
        assert call_kwargs["analogical_mapping"] is True
        assert call_kwargs["audit_logging"] is True


@pytest.mark.asyncio
async def test_tensor_router_symbolic_handoff() -> None:
    router = TensorRouter("http://sglang")

    mock_profile = MagicMock()
    mock_profile.compute_frontier = None
    mock_profile.symbolic_handoff_policy = MagicMock()

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.text = '{"name": "SolverBot", "age": 99}'

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_response

        result, usage, cost, _acc_tokens, _sig = await router.route_inference(
            "wf_1", "prompt", DummyModel, agent_profile=mock_profile
        )

        assert result.name == "SolverBot"
        assert result.age == 99
        assert usage == {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        assert cost == 0.0
        mock_post.assert_awaited_once()


@pytest.mark.asyncio
async def test_tensor_router_symbolic_handoff_failure() -> None:
    router = TensorRouter("http://sglang")

    mock_profile = MagicMock()
    mock_profile.compute_frontier = None
    mock_profile.symbolic_handoff_policy = MagicMock()

    with (
        patch("httpx.AsyncClient.post", side_effect=Exception("Solver crash")),
        pytest.raises(EpistemicYieldError, match=r"Symbolic Handoff Failed\. Total Collapse\."),
    ):
        await router.route_inference("wf_1", "prompt", DummyModel, agent_profile=mock_profile)


@pytest.mark.asyncio
async def test_synthesize_manifest_two_phase_dag() -> None:
    """Verify the two-phase synthesis pipeline: Phase 1 selects 'dag',
    Phase 2 generates a DAGTopologyManifest."""
    from coreason_manifest import DAGTopologyManifest

    from coreason_runtime.tensor.compiler import TopologySelectionResult

    mock_selection = TopologySelectionResult(
        selected_type="dag",
        architectural_intent="Sequential pipeline for web scraping and analysis.",
        detailed_blueprint="{}",
    )
    mock_manifest = DAGTopologyManifest.model_validate(
        {
            "topology_class": "dag",
            "max_depth": 10,
            "max_fan_out": 5,
            "nodes": {
                "did:coreason:scraper-agent-1": {"topology_class": "agent", "description": "Scrapes web content."},
                "did:coreason:analyzer-agent-1": {"topology_class": "agent", "description": "Analyzes scraped data."},
            },
            "edges": [("did:coreason:scraper-agent-1", "did:coreason:analyzer-agent-1")],
        }
    )

    phase1_usage = {"prompt_tokens": 20, "completion_tokens": 10}
    phase2_usage = {"prompt_tokens": 50, "completion_tokens": 100}

    async def mock_llm(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return (
            {"genesis_provenance": {"derivation_mode": "direct_translation"}},
            {},
            [],
        )  # pragma: no cover — never called

    with patch.object(
        UniversalCompiler,
        "validate_and_retry",
        new_callable=AsyncMock,
        side_effect=[
            (mock_selection, phase1_usage),  # Phase 1
            (mock_manifest, phase2_usage),  # Phase 2
        ],
    ) as mock_retry:
        manifest, usage = await UniversalCompiler.synthesize_manifest(
            user_prompt="Build a web scraper and analyze the data",
            thinking_callable=mock_llm,
            typing_callable=mock_llm,
        )

    # Two FSM calls: Phase 1 (selection) and Phase 2 (generation)
    assert mock_retry.call_count == 2

    # Phase 1: topology selection against TopologySelectionResult
    phase1_call = mock_retry.call_args_list[0]
    assert phase1_call.kwargs["schema_class"] == TopologySelectionResult
    assert "Topology Selector" in phase1_call.kwargs["prompt"]

    # Phase 2: manifest generation against DAGTopologyManifest
    phase2_call = mock_retry.call_args_list[1]
    from coreason_manifest import WorkflowManifest

    assert issubclass(phase2_call.kwargs["schema_class"], WorkflowManifest)
    assert phase2_call.kwargs["schema_class"].model_fields["topology"].annotation == DAGTopologyManifest
    assert "'dag'" in phase2_call.kwargs["prompt"]
    assert "Build a web scraper" in phase2_call.kwargs["prompt"]

    # Result validation
    assert manifest.topology_class == "dag"
    assert len(manifest.nodes) == 2
    assert usage["prompt_tokens"] == 70  # 20 + 50
    assert usage["completion_tokens"] == 110  # 10 + 100


@pytest.mark.asyncio
async def test_synthesize_manifest_two_phase_swarm() -> None:
    """Verify that Phase 1 can select a non-DAG topology (swarm)."""
    from coreason_manifest import SwarmTopologyManifest

    from coreason_runtime.tensor.compiler import TopologySelectionResult

    mock_selection = TopologySelectionResult(
        selected_type="swarm",
        architectural_intent="Decentralized multi-agent exploration for research.",
        detailed_blueprint="{}",
    )
    mock_manifest = SwarmTopologyManifest.model_validate(
        {
            "topology_class": "swarm",
            "spawning_threshold": 3,
            "max_concurrent_agents": 10,
            "nodes": {
                "did:coreason:explorer-1": {"topology_class": "agent", "description": "Explores topic A."},
                "did:coreason:explorer-2": {"topology_class": "agent", "description": "Explores topic B."},
                "did:coreason:synthesizer": {"topology_class": "agent", "description": "Synthesizes findings."},
            },
        }
    )

    async def mock_llm(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return {"genesis_provenance": {"derivation_mode": "direct_translation"}}, {}, []  # pragma: no cover

    with patch.object(
        UniversalCompiler,
        "validate_and_retry",
        new_callable=AsyncMock,
        side_effect=[
            (mock_selection, {"prompt_tokens": 15, "completion_tokens": 8}),
            (mock_manifest, {"prompt_tokens": 40, "completion_tokens": 90}),
        ],
    ) as mock_retry:
        manifest, usage = await UniversalCompiler.synthesize_manifest(
            user_prompt="Research quantum computing breakthroughs collaboratively",
            thinking_callable=mock_llm,
            typing_callable=mock_llm,
        )

    assert mock_retry.call_count == 2
    phase2_call = mock_retry.call_args_list[1]
    from coreason_manifest import WorkflowManifest

    assert issubclass(phase2_call.kwargs["schema_class"], WorkflowManifest)
    assert phase2_call.kwargs["schema_class"].model_fields["topology"].annotation == SwarmTopologyManifest

    assert manifest.topology_class == "swarm"
    assert len(manifest.nodes) == 3
    assert usage["prompt_tokens"] == 55


@pytest.mark.asyncio
async def test_tensor_router_peft_adapters_dispatch() -> None:
    router = TensorRouter("http://sglang")

    mock_profile = MagicMock()
    mock_profile.compute_frontier = None
    mock_profile.peft_adapters = [MagicMock()]
    mock_profile.peft_adapters[0].model_dump.return_value = {"adapter_cid": "foo", "vram_footprint_bytes": 1024}
    mock_profile.symbolic_handoff_policy = None

    with patch.object(UniversalCompiler, "validate_and_retry", new_callable=AsyncMock) as mock_validate:
        mock_validate.return_value = (DummyModel(name="Alice", age=30), {"prompt_tokens": 10, "completion_tokens": 5})

        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
            mock_post.return_value = mock_response

            await router.route_inference("wf_1", "prompt", DummyModel, agent_profile=mock_profile)

            mock_post.assert_awaited_once()
            call_args = mock_post.call_args
            assert "mount" in call_args[0][0]
            assert "adapter_config" in call_args[1]["json"]


@pytest.mark.asyncio
async def test_synthesize_hybrid_workflow() -> None:
    """Verifies that the TensorRouter properly orchestrates Tier 2 Thinking with Tier 0 Typing via UniversalCompiler."""
    router = TensorRouter("http://sglang")

    # Mock the internal clients
    router.oracle_client.generate = AsyncMock(return_value=("{}", {"prompt_tokens": 15, "completion_tokens": 30}, []))  # type: ignore[method-assign]

    router._outlines_client = MagicMock()
    router._outlines_client.generate = AsyncMock(
        return_value=("{}", {"prompt_tokens": 50, "completion_tokens": 100}, [])
    )

    from coreason_runtime.tensor.compiler import TopologySelectionResult

    mock_selection = TopologySelectionResult(selected_type="dag", architectural_intent="test", detailed_blueprint="{}")
    mock_manifest = MagicMock()
    mock_manifest.topology_class = "dag"

    with patch.object(UniversalCompiler, "validate_and_retry", new_callable=AsyncMock) as mock_validate:
        mock_validate.side_effect = [
            (mock_selection, {"prompt_tokens": 10, "completion_tokens": 20}),
            (mock_manifest, {"prompt_tokens": 30, "completion_tokens": 40}),
        ]

        result, usage = await router.synthesize_hybrid_workflow("Create a macro forge task", topology_hint=None)

        assert result.topology_class == "dag"
        assert usage["prompt_tokens"] == 40  # 10 + 30
        assert usage["completion_tokens"] == 60  # 20 + 40

        # Extract the logical closure targets passed into the Compiler limits
        call_args1 = mock_validate.call_args_list[0]
        call_args2 = mock_validate.call_args_list[1]
        thinking_callable = call_args1.kwargs.get("llm_callable") or call_args1.args[1]
        typing_callable = call_args2.kwargs.get("llm_callable") or call_args2.args[1]

        # Execute explicitly mathematically bypassing validation schemas
        await thinking_callable("test prompt")
        router.oracle_client.generate.assert_awaited()

        await typing_callable("test prompt")
        router._outlines_client.generate.assert_awaited()
