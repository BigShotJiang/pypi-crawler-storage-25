# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import hashlib
from typing import Any

from coreason_runtime.utils.security import generate_canonical_hash


def test_generate_canonical_hash_ordering():
    """Verify lexicographical key sorting for canonical hashing."""
    dict1 = {"b": 2, "a": 1}
    dict2 = {"a": 1, "b": 2}

    assert generate_canonical_hash(dict1) == generate_canonical_hash(dict2)


def test_generate_canonical_hash_floats():
    """Verify float normalization rules for canonical hashing."""
    dict1 = {"v": 1.0}
    dict2 = {"v": 1}

    assert generate_canonical_hash(dict1) == generate_canonical_hash(dict2)

    dict3 = {"v": 100000000000000000000.0}
    dict4 = {"v": 1e20}

    assert generate_canonical_hash(dict3) == generate_canonical_hash(dict4)


def test_generate_canonical_hash_whitespace():
    """Verify elimination of whitespace between structural characters."""
    dict1 = {"a": [1, 2, 3], "b": {"c": 4, "d": 5}}

    # Hand-calculate expected canonical JSON
    expected_str = '{"a":[1,2,3],"b":{"c":4,"d":5}}'
    expected_hash = hashlib.sha256(expected_str.encode("utf-8")).hexdigest()

    assert generate_canonical_hash(dict1) == expected_hash


def test_generate_canonical_hash_complex():
    """Test complex dictionary structures to ensure all rules apply recursively."""
    payload: dict[str, Any] = {"user_id": "123456", "nested": {"z": 1.5e-5, "a": "text", "c": [True, False, None, 0.0]}}

    # Expected canonicalization:
    # "0.0" -> "0"
    # "1.5e-5" -> "1.5E-5"
    # Keys get sorted
    expected_str = '{"nested":{"a":"text","c":[true,false,null,0],"z":1.5E-5},"user_id":"123456"}'
    expected_hash = hashlib.sha256(expected_str.encode("utf-8")).hexdigest()

    assert generate_canonical_hash(payload) == expected_hash
