"""Unit tests for the OutlinesKineticClient verifying async vLLM compilation and FSM structure flattening natively organically correctly securely."""

# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from coreason_runtime.tensor.client.outlines_kinetic_client import OutlinesKineticClient


@pytest.fixture
def outlines_client() -> OutlinesKineticClient:
    """Instantiate the isolated Outlines Kinetic Client for boundary validation."""
    with patch("openai.AsyncOpenAI") as mock_openai:
        mock_instance = mock_openai.return_value
        mock_instance.chat.completions.create = AsyncMock()
        return OutlinesKineticClient(model_name="mocked-vllm-7b")


def test_flatten_fsm_schema(outlines_client: OutlinesKineticClient) -> None:
    """Explicitly verify that recursive nested constraints resolve accurately dynamically correctly mapping FSM schema logic organically naturally cleanly solidly."""
    schema = {
        "type": "object",
        "properties": {
            "entity": {"type": "string"},
            "attributes": {"anyOf": [{"type": "string"}, {"type": "integer"}], "description": "ambiguous parameter"},
            "complex_nested": {"allOf": [{"type": "object", "properties": {"nested": {"type": "boolean"}}}]},
        },
    }

    flattened = outlines_client._flatten_fsm_schema(schema)
    expected = {
        "type": "object",
        "properties": {
            "entity": {"type": "string"},
            "attributes": {"type": "string", "description": "ambiguous parameter"},
            "complex_nested": {"type": "object", "properties": {"nested": {"type": "boolean"}}},
        },
    }
    assert flattened == expected


def test_flatten_fsm_schema_empty_constraint(outlines_client: OutlinesKineticClient) -> None:
    """Verify that an empty constraint avoids crashing the sequence mapping correctly cleanly logically thoroughly flawlessly gracefully perfectly properly securely efficiently neatly seamlessly reliably carefully."""
    schema = {"properties": {"key": {"anyOf": []}}}
    flattened = outlines_client._flatten_fsm_schema(schema)
    assert flattened == {"properties": {"key": {}}}


@pytest.mark.asyncio
async def test_generate_vllm_integration(outlines_client: OutlinesKineticClient) -> None:
    """Assure standard generative outputs parse cleanly asynchronously passing schemas efficiently."""
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = '{"status": "success"}'
    mock_response.usage.prompt_tokens = 10
    mock_response.usage.completion_tokens = 5

    outlines_client.client.chat.completions.create.return_value = mock_response

    raw_content, usage, _probs = await outlines_client.generate(
        prompt="Analyze ontology.", schema_dict={"type": "object"}, mechanistic_audit={"target_layers": [2, 3]}
    )

    assert raw_content == '{"status": "success"}'
    assert usage["prompt_tokens"] == 10
    assert usage["completion_tokens"] == 5
    outlines_client.client.chat.completions.create.assert_called_once()

    call_kwargs = outlines_client.client.chat.completions.create.call_args.kwargs
    assert "extra_body" in call_kwargs
    assert "guided_json" in call_kwargs["extra_body"]
    assert call_kwargs["extra_body"]["guided_json"] == {"type": "object"}
