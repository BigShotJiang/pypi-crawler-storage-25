# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import base64
from collections.abc import AsyncIterator
from typing import Any

import numpy as np
import pytest
import pytest_asyncio
from coreason_manifest.spec.ontology import ExecutionNodeReceipt, LatentProjectionIntent, VectorEmbeddingState

from coreason_runtime.memory.latent import LatentMemoryManager
from coreason_runtime.memory.ledger import EpistemicLedgerManager
from coreason_runtime.memory.store import MedallionStateEngine


@pytest_asyncio.fixture
async def temp_medallion_engine(tmp_path: Any) -> AsyncIterator[MedallionStateEngine]:
    store_path = str(tmp_path / "test_lancedb")
    engine = MedallionStateEngine(db_path=store_path)
    # The ledger and latent managers handle bootstrapping now
    yield engine
    # Cleanup done automatically by tmp_path fixture


@pytest.mark.asyncio
async def test_epistemic_ledger(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = EpistemicLedgerManager(temp_medallion_engine)
    await manager.bootstrap()

    receipt = ExecutionNodeReceipt(
        request_cid="req_123",
        inputs={"query": "test query"},
        outputs={"result": "test result"},
        parent_hashes=["hash1", "hash2"],
        node_hash="a" * 64,
    )

    intent_hash = "intent_" + "a" * 57

    await manager.crystallize_gold_state("wf_1", intent_hash, receipt)

    # Check isolation and idempotency
    await manager.crystallize_gold_state("wf_1", intent_hash, receipt)

    # Commit bronze entropy
    await manager.commit_bronze_entropy("wf_1", "bronze_hash_1", {"error": "test"}, "trace test")

    table = temp_medallion_engine.db.open_table(manager.gold_table_name)
    df = table.to_pandas()
    assert len(df) == 1

    table = temp_medallion_engine.db.open_table(manager.bronze_table_name)
    df = table.to_pandas()
    assert len(df) == 1


@pytest.mark.asyncio
async def test_execute_rollback_updates_status(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = EpistemicLedgerManager(temp_medallion_engine)
    await manager.bootstrap()

    receipt = ExecutionNodeReceipt(
        request_cid="req_123",
        inputs={"query": "test query"},
        outputs={"result": "test result"},
        parent_hashes=["hash1", "hash2"],
        node_hash="a" * 64,
    )
    intent_hash = "intent_123"
    await manager.crystallize_gold_state("wf_1", intent_hash, receipt)

    table = temp_medallion_engine.db.open_table(manager.gold_table_name)
    assert len(table.to_pandas()) == 1

    class MockRollbackIntent:
        def __init__(self):
            self.target_event_cid = "req_123"
            self.invalidated_node_cids = [intent_hash]
            self.request_cid = "rollback_req"

    await manager.execute_rollback("wf_1", MockRollbackIntent())

    table = temp_medallion_engine.db.open_table(manager.gold_table_name)
    df = table.to_pandas()
    assert len(df) == 1
    assert df.iloc[0]["status"] == "quarantined"


@pytest.mark.asyncio
async def test_ledger_crystallize_gold_error(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = EpistemicLedgerManager(temp_medallion_engine)
    await manager.bootstrap()

    receipt = ExecutionNodeReceipt(
        request_cid="req_123",
        inputs={"query": "test query"},
        outputs={"result": "test result"},
        parent_hashes=["hash1", "hash2"],
        node_hash="a" * 64,
    )

    with pytest.raises(ValueError, match="Gold Cache Rejection: Missing Merkle Root"):
        await manager.crystallize_gold_state("wf_1", "", receipt)


@pytest.mark.asyncio
async def test_latent_memory(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32)
    vector_b64 = base64.b64encode(vector.tobytes()).decode("utf-8")

    intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64=vector_b64, dimensionality=1536, foundation_matrix_name="test-model"
        ),
        top_k_candidates=5,
        min_isometry_score=0.5,
    )

    intent_hash = "intent_" + "a" * 57

    await manager.upsert_projection(intent_hash, intent, vector.tolist())

    table = temp_medallion_engine.db.open_table(manager.table_name)
    df = table.to_pandas()
    assert len(df) == 1


@pytest.mark.asyncio
async def test_latent_memory_compaction_error(
    temp_medallion_engine: MedallionStateEngine, monkeypatch: pytest.MonkeyPatch
) -> None:
    manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()

    def mock_open_table(_name: str) -> Any:
        raise ValueError("Simulated DB Error")

    monkeypatch.setattr(manager.db, "open_table", mock_open_table)

    # Should safely swallow error and log
    await manager.optimize_and_compact()


@pytest.mark.asyncio
async def test_fetch_memoized_state(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = EpistemicLedgerManager(temp_medallion_engine)
    latent_manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()
    await latent_manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32).tolist()
    intent_hash = "intent_semantic_match_123"

    intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64="dummy", dimensionality=1536, foundation_matrix_name="test"
        ),
        top_k_candidates=5,
        min_isometry_score=0.5,
    )
    await latent_manager.upsert_projection(intent_hash, intent, vector)

    receipt = ExecutionNodeReceipt(
        request_cid="req_semantic_123",
        inputs={"query": "test query semantic"},
        outputs={"result": "test result semantic"},
        parent_hashes=["hash1"],
        node_hash="b" * 64,
    )

    class MockPQC:
        pq_algorithm = "Ed25519"
        pq_signature_blob = "valid_mock_signature"
        public_key_id = "MOCK"

    await manager.crystallize_gold_state("wf_test", intent_hash, receipt, pqc_receipt=MockPQC())

    result = await manager.fetch_memoized_state_io_activity(vector, threshold=0.05)
    assert result is not None
    assert result["outputs"]["result"] == "test result semantic"

    far_vector = np.zeros(1536, dtype=np.float32)
    far_vector[0] = 1.0
    missed_result = await manager.fetch_memoized_state_io_activity(far_vector.tolist(), threshold=0.05)
    assert missed_result is None


@pytest.mark.asyncio
async def test_fetch_memoized_state_invalid_signature_rejected(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = EpistemicLedgerManager(temp_medallion_engine)
    latent_manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()
    await latent_manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32).tolist()
    intent_hash = "intent_semantic_match_124"

    intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64="dummy", dimensionality=1536, foundation_matrix_name="test"
        ),
        top_k_candidates=5,
        min_isometry_score=0.5,
    )
    await latent_manager.upsert_projection(intent_hash, intent, vector)

    receipt = ExecutionNodeReceipt(
        request_cid="req_semantic_124",
        inputs={"query": "test query semantic 2"},
        outputs={"result": "test result 2"},
        parent_hashes=["hash2"],
        node_hash="c" * 64,
    )

    class MockInvalidPQC:
        pq_algorithm = "Ed25519"
        pq_signature_blob = "invalid_forged_blob_without_bypass"
        public_key_id = "MOCK"

    await manager.crystallize_gold_state("wf_test", intent_hash, receipt, pqc_receipt=MockInvalidPQC())

    result = await manager.fetch_memoized_state_io_activity(vector, threshold=0.05)
    assert result is None


@pytest.mark.asyncio
async def test_fetch_memoized_state_missing_tables(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = EpistemicLedgerManager(temp_medallion_engine)
    vector = np.zeros(1536, dtype=np.float32).tolist()
    result = await manager.fetch_memoized_state_io_activity(vector)
    assert result is None


@pytest.mark.asyncio
async def test_fetch_memoized_state_empty_table(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = EpistemicLedgerManager(temp_medallion_engine)
    latent_manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()
    await latent_manager.bootstrap()

    # Tables exist, but are completely empty
    vector = np.random.rand(1536).astype(np.float32).tolist()

    result = await manager.fetch_memoized_state_io_activity(vector, threshold=0.05)
    assert result is None


@pytest.mark.asyncio
async def test_fetch_memoized_state_missing_gold(temp_medallion_engine: MedallionStateEngine) -> None:
    manager = EpistemicLedgerManager(temp_medallion_engine)
    latent_manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()
    await latent_manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32).tolist()
    intent_hash = "intent_orphan_123"

    intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64="dummy", dimensionality=1536, foundation_matrix_name="test"
        ),
        top_k_candidates=5,
        min_isometry_score=0.5,
    )
    await latent_manager.upsert_projection(intent_hash, intent, vector)

    result = await manager.fetch_memoized_state_io_activity(vector, threshold=0.05)
    assert result is None


@pytest.mark.asyncio
async def test_fetch_action_space_manifest_missing_table(temp_medallion_engine: MedallionStateEngine) -> None:
    """Test that fetch_action_space_manifest raises ValueError when action_spaces table is missing."""
    manager = EpistemicLedgerManager(temp_medallion_engine)
    await manager.bootstrap()

    result = await manager.fetch_action_space_manifest("test-space-id")
    assert result is None
