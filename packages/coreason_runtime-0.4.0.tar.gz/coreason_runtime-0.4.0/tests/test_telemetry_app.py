# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import sys
from unittest.mock import MagicMock, patch

# Pre-mock streamlit before importing app
mock_st = MagicMock()
sys.modules["streamlit"] = mock_st


def test_telemetry_app_successful_connection() -> None:
    # We mock requests to return a mock response with a valid event stream
    mock_response = MagicMock()
    mock_response.status_code = 200

    import json

    event1 = json.dumps({"event_type": "NodeStartedEvent", "agent_name": "AI", "node_cid": "1"})
    event2 = json.dumps({"event_type": "TokenStreamChunk", "text_chunk": "He", "node_cid": "1"})
    event3 = json.dumps({"event_type": "TokenStreamChunk", "text_chunk": "llo", "node_cid": "1"})

    mock_response.iter_lines.return_value = [
        b"data: " + event1.encode("utf-8"),
        b"data: " + event2.encode("utf-8"),
        b"data: " + event3.encode("utf-8"),
        b"data: invalid data not json",
        b"invalid data not json at all",
        b"",
    ]

    with patch("requests.get", return_value=mock_response):
        import importlib

        import coreason_runtime.telemetry.app

        importlib.reload(coreason_runtime.telemetry.app)
        coreason_runtime.telemetry.app.render_app()

        # Verify the streamlit functions were called
        mock_st.set_page_config.assert_called_with(page_title="CoReason Telemetry", layout="wide")
        mock_st.title.assert_called_with("CoReason Execution Telemetry")
        mock_st.sidebar.title.assert_called_with("Execution Graph")
        mock_st.header.assert_called_with("Agent Chat")


def test_telemetry_app_connection_failure() -> None:
    import requests

    with patch("requests.get") as mock_get:
        mock_get.side_effect = requests.exceptions.ConnectionError("Broker down")

        import importlib

        import coreason_runtime.telemetry.app

        importlib.reload(coreason_runtime.telemetry.app)
        coreason_runtime.telemetry.app.render_app()

        mock_st.error.assert_called_with("Connection error: Broker down")


def test_telemetry_app_non_200_status() -> None:
    mock_response = MagicMock()
    mock_response.status_code = 404

    with patch("requests.get", return_value=mock_response):
        import importlib

        import coreason_runtime.telemetry.app

        importlib.reload(coreason_runtime.telemetry.app)
        coreason_runtime.telemetry.app.render_app()

        mock_st.error.assert_called_with("Failed to connect to broker: 404")
