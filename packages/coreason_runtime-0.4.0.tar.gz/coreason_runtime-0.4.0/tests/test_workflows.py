# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import dataclasses
from typing import Any
from unittest.mock import MagicMock, mock_open, patch

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker
from temporalio.worker.workflow_sandbox import SandboxRestrictions

from coreason_runtime.orchestration.engine import CoreasonRuntime
from coreason_runtime.orchestration.worker import TASK_QUEUE, start_worker
from coreason_runtime.orchestration.workflows import DAGExecutionWorkflow, SwarmExecutionWorkflow

invalid_members = dict(SandboxRestrictions.default.invalid_module_members.children)
invalid_members.pop("datetime", None)
invalid_members.pop("uuid", None)
invalid_members.pop("pathlib", None)
invalid_members.pop("glob", None)
invalid_members.pop("pathlib", None)
new_matcher = dataclasses.replace(SandboxRestrictions.default.invalid_module_members, children=invalid_members)
PydanticSafeRestrictions = dataclasses.replace(
    SandboxRestrictions.default, invalid_module_members=new_matcher
).with_passthrough_modules(
    "pydantic",
    "pydantic_core",
    "coreason_manifest",
    "coreason_manifest.spec.events",
    "coreason_runtime.telemetry.events",
    "polars",
    "dlt",
    "pyarrow",
)


@pytest.fixture
def dag_manifest() -> dict[str, Any]:
    return {
        "topology_class": "dag",
        "max_depth": 10,
        "max_fan_out": 5,
        "nodes": {
            "did:test:node-1-agent": {
                "topology_class": "agent",
                "description": "A helpful assistant node.",
            },
            "did:test:node-2-agent": {
                "topology_class": "agent",
                "description": "A summarization node.",
            },
        },
    }


@pytest.fixture
def swarm_manifest() -> dict[str, Any]:
    return {
        "topology_class": "swarm",
        "nodes": {
            "did:test:agent-1-swarm": {
                "topology_class": "agent",
                "description": "A helpful swarm agent.",
            }
        },
    }


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def mock_execute_tensor_inference(
    workflow_id: str, payload: dict[str, Any], schema_type_name: str
) -> dict[str, Any]:
    _ = workflow_id
    _ = schema_type_name
    return {
        "node_cid": payload.get("node_id", "mock-node"),
        "status": "success",
        "intent_hash": "mock-hash-123",
        "success": True,
        "result": {"output": "Mocked tensor inference result"},
    }


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state(
    workflow_id: str,
    intent_hash: str,
    success: bool,
    payload: dict[str, Any],
    latent_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    _ = workflow_id
    _ = intent_hash
    _ = success
    _ = payload
    _ = latent_payload
    return {"status": "success", "vector_id": "mock-123"}


@activity.defn(name="BroadcastStateEchoIOActivity")
async def mock_broadcast_state_echo(workflow_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    _ = workflow_id
    _ = payload
    return {"status": "echoed"}


@activity.defn(name="ExecuteMCPToolIOActivity")
async def mock_execute_mcp_tool(tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    _ = tool_name
    _ = payload
    return {
        "node_cid": "mock-node",
        "status": "success",
        "intent_hash": "mock-mcp-hash-123",
        "success": True,
        "result": {"output": "Mocked tool execution result"},
    }


@activity.defn(name="EmitResumedEventIOActivity")
async def mock_emit_resumed_event_activity(workflow_id: str, node_id: str) -> dict[str, Any]:
    _ = workflow_id
    _ = node_id
    return {"status": "resumed"}


@activity.defn(name="RequestOracleInterventionIOActivity")
async def mock_request_oracle_intervention(workflow_id: str, node_id: str, context: dict[str, Any]) -> dict[str, Any]:
    _ = workflow_id
    _ = node_id
    _ = context
    return {"status": "oracle_requested", "node_cid": node_id}


@activity.defn(name="AnnounceTaskIOActivity")
async def mock_announce_task(payload: dict[str, Any]) -> dict[str, Any]:
    return payload


@activity.defn(name="ExecuteResolveAuctionComputeActivity")
async def mock_execute_resolve_auction(state_payload: dict[str, Any], policy_payload: dict[str, Any]) -> dict[str, Any]:  # noqa: ARG001
    # Return a mocked TaskAwardReceipt
    return {
        "task_id": "task_id",
        "awarded_syndicate": {"agent_1": 100},
        "cleared_price_magnitude": 100,
        "escrow": {
            "escrow_locked_magnitude": 100,
            "release_condition_metric": "test",
            "refund_target_node_id": "agent_1",
        },
    }


@activity.defn(name="ExecuteMarketContractComputeActivity")
async def mock_execute_market_contract(payload: dict[str, Any], success: bool) -> dict[str, Any]:  # noqa: ARG001
    return {"status": "success", "penalty_amount": 0}


@activity.defn(name="ExecuteSettlePredictionMarketComputeActivity")
async def mock_execute_settle_prediction_market(payload: dict[str, Any]) -> dict[str, Any]:
    return payload


@pytest.mark.asyncio
async def test_dag_workflow(dag_manifest: dict[str, Any]) -> None:
    from temporalio.worker.workflow_sandbox import SandboxedWorkflowRunner

    async with (
        await WorkflowEnvironment.start_time_skipping() as env,
        Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DAGExecutionWorkflow],
            activities=[
                mock_execute_tensor_inference,
                mock_store_epistemic_state,
                mock_broadcast_state_echo,
                mock_execute_mcp_tool,
                mock_emit_resumed_event_activity,
                mock_request_oracle_intervention,
                mock_announce_task,
                mock_execute_resolve_auction,
                mock_execute_market_contract,
                mock_execute_settle_prediction_market,
            ],
            workflow_runner=SandboxedWorkflowRunner(
                restrictions=SandboxRestrictions.default.with_passthrough_all_modules()
            ),
        ),
    ):
        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
            payload=dag_manifest,
        ).model_dump(mode="json")

        handle = await env.client.start_workflow(
            DAGExecutionWorkflow.run,
            envelope,
            id="test-dag-workflow-id",
            task_queue=TASK_QUEUE,
        )

        # test state before delta
        state_before = await handle.query("get_current_state")
        assert "test" not in state_before

        # test query without initialization
        test_workflow = DAGExecutionWorkflow()
        assert test_workflow.get_current_state() == {}

        # test signal without current_state_payload
        import asyncio

        with (
            patch("temporalio.workflow.logger.info"),
            patch("temporalio.workflow.execute_activity") as mock_execute,
            patch("temporalio.workflow.info") as mock_info,
        ):
            mock_info.return_value.workflow_id = "test_wf_id"
            # Mocking these allow us to call apply_state_delta directly without loop error
            mock_f: asyncio.Future[Any] = asyncio.Future()
            mock_f.set_result(None)
            mock_execute.return_value = mock_f
            import uuid6
            from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

            trace_id = str(uuid6.uuid7())
            test_envelope = ExecutionEnvelopeState[dict[str, Any]](
                trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
                state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
                payload={"test_direct": "data"},
            )

            test_workflow._current_state_envelope = test_envelope
            await test_workflow.apply_state_delta({"test_direct": "data"})
            env_dag = test_workflow._current_state_envelope
            assert env_dag is not None
            assert env_dag.state_vector.mutable_matrix == {"test_direct": "data"}

        # Mathematical proof that state mutates mid-flight
        await handle.signal("apply_state_delta", {"test": "dag_delta_data"})

        # we also send a second signal
        await handle.signal("apply_state_delta", {"test2": "dag_delta_data2"})

        import contextlib

        # allow enough time to run and get state
        with contextlib.suppress(Exception):
            result = await handle.result()

        state = await handle.query("get_current_state")
        assert state["state_vector"]["mutable_matrix"].get("test") == "dag_delta_data", "State mutation failed"
        assert state["state_vector"]["mutable_matrix"].get("test2") == "dag_delta_data2", "Second state mutation failed"
        assert result["status"] == "success"


@pytest.mark.asyncio
async def test_swarm_workflow(swarm_manifest: dict[str, Any]) -> None:
    from temporalio.worker.workflow_sandbox import SandboxedWorkflowRunner

    async with (
        await WorkflowEnvironment.start_time_skipping() as env,
        Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[SwarmExecutionWorkflow],
            activities=[
                mock_execute_tensor_inference,
                mock_store_epistemic_state,
                mock_broadcast_state_echo,
                mock_execute_mcp_tool,
                mock_emit_resumed_event_activity,
                mock_request_oracle_intervention,
                mock_announce_task,
                mock_execute_resolve_auction,
                mock_execute_market_contract,
                mock_execute_settle_prediction_market,
            ],
            workflow_runner=SandboxedWorkflowRunner(
                restrictions=SandboxRestrictions.default.with_passthrough_all_modules()
            ),
        ),
    ):
        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        state_vector = StateVectorProfile(immutable_matrix={}, mutable_matrix={"compute_budget": 1000}, is_delta=False)
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=state_vector,
            payload=swarm_manifest,
        ).model_dump(mode="json")

        handle = await env.client.start_workflow(
            SwarmExecutionWorkflow.run,
            envelope,
            id="test-swarm-workflow-id",
            task_queue=TASK_QUEUE,
        )

        # test state before delta
        state_before = await handle.query("get_current_state")
        assert "test" not in state_before

        # test query without initialization
        test_workflow = SwarmExecutionWorkflow()
        assert test_workflow.get_current_state() == {}

        # test signal without current_state_payload
        import asyncio

        with (
            patch("temporalio.workflow.logger.info"),
            patch("temporalio.workflow.execute_activity") as mock_execute,
            patch("temporalio.workflow.info") as mock_info,
        ):
            mock_info.return_value.workflow_id = "test_wf_id"
            mock_f: asyncio.Future[Any] = asyncio.Future()
            mock_f.set_result(None)
            mock_execute.return_value = mock_f
            import uuid6
            from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

            trace_id = str(uuid6.uuid7())
            test_envelope = ExecutionEnvelopeState[dict[str, Any]](
                trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
                state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
                payload={"test_direct": "data"},
            )

            test_workflow._current_state_envelope = test_envelope
            await test_workflow.apply_state_delta({"test_direct": "data"})
            env_swarm = test_workflow._current_state_envelope
            assert env_swarm is not None
            assert env_swarm.state_vector.mutable_matrix == {"test_direct": "data"}

        # Mathematical proof that state mutates mid-flight
        await handle.signal("apply_state_delta", {"test": "swarm_delta_data"})

        # we also send a second signal
        await handle.signal("apply_state_delta", {"test2": "swarm_delta_data2"})

        import contextlib

        # allow enough time to run
        with contextlib.suppress(Exception):
            result = await handle.result()

        state = await handle.query("get_current_state")
        assert state["state_vector"]["mutable_matrix"].get("test") == "swarm_delta_data", "State mutation failed"
        assert state["state_vector"]["mutable_matrix"].get("test2") == "swarm_delta_data2"
        assert result["status"] == "success"
        assert result["iterations"] == 3
        assert len(result["results"]) == 3


@pytest.mark.asyncio
async def test_swarm_oracle_escalation(swarm_manifest: dict[str, Any]) -> None:
    # Use a real Temporal instance to test timeouts to prevent asyncio deadlocks
    # Wait conditions on local testing environment often deadlock on fast forward
    import asyncio

    test_workflow = SwarmExecutionWorkflow()

    with (
        patch("temporalio.workflow.now") as mock_now,
        patch("temporalio.workflow.logger.info"),
        patch("temporalio.workflow.execute_activity") as mock_execute,
        patch("temporalio.workflow.info") as mock_info,
        patch("temporalio.workflow.wait_condition") as mock_wait,
        patch("temporalio.workflow.sleep") as mock_sleep,
        patch("coreason_manifest.SwarmTopologyManifest.model_validate") as mock_validate,
    ):
        from datetime import datetime

        mock_now.return_value = datetime.now()
        mock_info.return_value.workflow_id = "test_wf_id"

        def mock_execute_side_effect(activity: str, args: Any = None, **_kwargs: Any) -> dict[str, Any]:
            if activity == "ExecuteResolveAuctionComputeActivity":
                return {
                    "task_id": "task_id",
                    "awarded_syndicate": {"agent_1": 100},
                    "cleared_price_magnitude": 100,
                    "escrow": {
                        "escrow_locked_magnitude": 100,
                        "release_condition_metric": "test",
                        "refund_target_node_id": "agent_1",
                    },
                }
            if activity == "ExecuteTensorInferenceComputeActivity":
                return {
                    "status": "epistemic_yield",
                    "node_cid": "mock-node",
                    "intent_hash": "mock-oracle-hash",
                    "success": True,
                }
            if activity == "RequestOracleInterventionIOActivity":
                return {"status": "oracle_requested", "node_cid": args[1] if args else "mock-node"}
            if activity == "EmitResumedEventIOActivity":
                return {"status": "resumed"}
            if activity == "ExecuteMCPToolIOActivity":
                return {
                    "node_cid": "mock-node",
                    "status": "success",
                    "intent_hash": "mock-mcp-hash-123",
                    "success": True,
                    "result": {"output": "Mocked tool execution result"},
                    "outputs": {"observation": "success_obs"},
                }
            if activity == "StoreEpistemicStateIOActivity":
                return {"status": "success", "vector_id": "mock-123"}
            if activity == "ExecuteMarketContractComputeActivity":
                return {"status": "success", "penalty_amount": 0}
            if activity == "ExecuteSettlePredictionMarketComputeActivity":
                return args[0] if args else {}
            return {}

        mock_execute.side_effect = mock_execute_side_effect

        # mock the manifest
        mock_manifest = MagicMock()
        mock_node = MagicMock()
        mock_node.requires_oracle = True
        mock_node.model_dump.return_value = {}
        mock_manifest.nodes = {"did:test:agent-1-swarm": mock_node}
        mock_manifest.model_dump.return_value = swarm_manifest
        mock_validate.return_value = mock_manifest

        mock_sleep_f: asyncio.Future[Any] = asyncio.Future()
        mock_sleep_f.set_result(None)
        mock_sleep.return_value = mock_sleep_f.result()

        # for wait condition, simulate that it resolves after setting the signal
        # we do this by actually running a future that gets resolved
        mock_wait_f: asyncio.Future[Any] = asyncio.Future()
        mock_wait_f.set_result(None)

        from collections.abc import Callable

        async def mock_wait_impl(condition_func: Callable[[], bool], timeout: Any = None) -> Any:
            _ = timeout
            # immediately simulate a signal firing to test state
            # For phase C, we use receive_oracle_override which takes a corrected intent
            # In Temporal, an async test interacts directly with the signal method as a function
            # But the test instantiates test_workflow. The signal might need to be called explicitly
            test_workflow.receive_oracle_override(
                {
                    "jsonrpc": "2.0",
                    "method": "mcp.ui.emit_intent",
                    "params": {"name": "test_tool", "arguments": {"human_decision": "proceed"}},
                    "id": "123",
                }
            )
            # verify condition is true now
            assert condition_func() is True
            return await mock_wait_f

        mock_wait.side_effect = mock_wait_impl

        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        state_vector = StateVectorProfile(immutable_matrix={}, mutable_matrix={"compute_budget": 1000}, is_delta=False)
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=state_vector,
            payload=swarm_manifest,
        ).model_dump(mode="json")

        result = await test_workflow.run(envelope)

        assert result["status"] == "success"
        # We loop back/continue without standard inference in the first round due to oracle injection
        assert result["iterations"] == 3


@pytest.mark.asyncio
async def test_swarm_oracle_escalation_timeout(swarm_manifest: dict[str, Any]) -> None:
    import asyncio

    test_workflow = SwarmExecutionWorkflow()

    with (
        patch("temporalio.workflow.now") as mock_now,
        patch("temporalio.workflow.logger.info"),
        patch("temporalio.workflow.logger.warning"),
        patch("temporalio.workflow.logger.error"),
        patch("temporalio.workflow.execute_activity") as mock_execute,
        patch("temporalio.workflow.info") as mock_info,
        patch("temporalio.workflow.wait_condition") as mock_wait,
        patch("temporalio.workflow.sleep") as mock_sleep,
        patch("temporalio.workflow.unsafe.sandbox_unrestricted") as mock_sandbox_unrestricted,
        patch("coreason_manifest.SwarmTopologyManifest.model_validate") as mock_validate,
    ):
        mock_sandbox_unrestricted.return_value.__enter__.return_value = None
        from datetime import datetime

        mock_now.return_value = datetime.now()
        mock_info.return_value.workflow_id = "test_wf_id"

        def mock_execute_side_effect(activity: str, args: Any = None, **_kwargs: Any) -> dict[str, Any]:
            if activity == "ExecuteResolveAuctionComputeActivity":
                return {
                    "task_id": "task_id",
                    "awarded_syndicate": {"agent_1": 100},
                    "cleared_price_magnitude": 100,
                    "escrow": {
                        "escrow_locked_magnitude": 100,
                        "release_condition_metric": "test",
                        "refund_target_node_id": "agent_1",
                    },
                }
            if activity == "ExecuteTensorInferenceComputeActivity":
                return {
                    "status": "epistemic_yield",
                    "node_cid": "mock-node",
                    "intent_hash": "mock-oracle-hash",
                    "success": True,
                }
            if activity == "RequestOracleInterventionIOActivity":
                return {"status": "oracle_requested", "node_cid": args[1] if args else "mock-node"}
            if activity == "EmitResumedEventIOActivity":
                return {"status": "resumed"}
            if activity == "StoreEpistemicStateIOActivity":
                return {"status": "success", "vector_id": "mock-123"}
            if activity == "ExecuteMarketContractComputeActivity":
                return {"status": "success", "penalty_amount": 0}
            if activity == "ExecuteSettlePredictionMarketComputeActivity":
                return args[0] if args else {}
            return {}

        mock_execute.side_effect = mock_execute_side_effect

        mock_sleep_f: asyncio.Future[Any] = asyncio.Future()
        mock_sleep_f.set_result(None)
        mock_sleep.return_value = mock_sleep_f.result()

        # mock the manifest
        mock_manifest = MagicMock()
        mock_node = MagicMock()
        mock_node.requires_oracle = True
        mock_node.model_dump.return_value = {}
        mock_manifest.nodes = {"did:test:agent-1-swarm": mock_node}
        mock_manifest.model_dump.return_value = swarm_manifest
        mock_validate.return_value = mock_manifest

        from collections.abc import Callable

        # force timeout
        async def mock_wait_impl(condition_func: Callable[[], bool], timeout: Any = None) -> Any:
            _ = condition_func
            _ = timeout
            raise TimeoutError()

        mock_wait.side_effect = mock_wait_impl

        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        state_vector = StateVectorProfile(immutable_matrix={}, mutable_matrix={"compute_budget": 1000}, is_delta=False)
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=state_vector,
            payload=swarm_manifest,
        ).model_dump(mode="json")

        result = await test_workflow.run(envelope)

        # Because the wait_condition timed out and handled gracefully, the execution continues
        assert result["status"] == "success"
        assert result["iterations"] == 3  # it runs up to the default spawning_threshold


@pytest.mark.asyncio
async def test_worker_start() -> None:
    with (
        patch("coreason_runtime.orchestration.worker.Client.connect") as mock_connect,
        patch("coreason_runtime.orchestration.activities.MedallionStateEngine.__init__", return_value=None),
        patch("lancedb.connect"),
    ):
        mock_client = MagicMock()
        mock_connect.return_value = mock_client

        with patch("coreason_runtime.orchestration.worker.Worker") as mock_worker_class:
            mock_worker = MagicMock()
            # mock async run
            mock_worker.run = MagicMock()
            import asyncio

            f: asyncio.Future[Any] = asyncio.Future()
            f.set_result(None)
            mock_worker.run.return_value = f
            mock_worker_class.return_value = mock_worker

            await start_worker("localhost:7233", memory_path="/tmp/lancedb_test")

            mock_connect.assert_called_once_with("localhost:7233")
            mock_worker_class.assert_called_once()
            mock_worker.run.assert_called_once()


@pytest.mark.asyncio
async def test_engine_connect_execute() -> None:
    engine = CoreasonRuntime()
    with patch("coreason_runtime.orchestration.engine.Client.connect") as mock_connect:
        mock_client = MagicMock()
        mock_connect.return_value = mock_client

        await engine.connect()
        assert engine._client is mock_client

    # Test execute
    import json

    mock_manifest_data = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        },
        "topology": {"topology_class": "dag", "max_depth": 10, "max_fan_out": 5, "nodes": {}, "edges": []},
    }
    with patch("builtins.open", mock_open(read_data=json.dumps(mock_manifest_data))):
        # mock execute_workflow
        import asyncio

        f: asyncio.Future[Any] = asyncio.Future()
        f.set_result({"status": "success", "results": []})
        mock_client.execute_workflow.return_value = f

        result = await engine.execute("dummy_path.json")
        assert result == {"status": "success", "results": []}
        mock_client.execute_workflow.assert_called_once()

    # test execute without client connected initially
    engine2 = CoreasonRuntime()
    with patch("coreason_runtime.orchestration.engine.Client.connect") as mock_connect2:
        mock_connect2.return_value = mock_client
        with patch("builtins.open", mock_open(read_data=json.dumps(mock_manifest_data))):
            result = await engine2.execute("dummy_path_noclient.json")
            assert result == {"status": "success", "results": []}
            mock_connect2.assert_called_once()

    # Test swarm
    if isinstance(mock_manifest_data["topology"], dict):
        mock_manifest_data["topology"]["topology_class"] = "swarm"
        if "max_depth" in mock_manifest_data["topology"]:
            del mock_manifest_data["topology"]["max_depth"]
        if "max_fan_out" in mock_manifest_data["topology"]:
            del mock_manifest_data["topology"]["max_fan_out"]
        if "edges" in mock_manifest_data["topology"]:
            del mock_manifest_data["topology"]["edges"]
    with patch("builtins.open", mock_open(read_data=json.dumps(mock_manifest_data))):
        f2: asyncio.Future[Any] = asyncio.Future()
        f2.set_result({"status": "success", "iterations": 1, "results": []})
        mock_client.execute_workflow.return_value = f2

        result = await engine.execute("dummy_path2.json")
        assert result.get("status") == "success"

    # Test unknown
    if isinstance(mock_manifest_data["topology"], dict):
        mock_manifest_data["topology"]["topology_class"] = "unknown"
    with (
        patch("builtins.open", mock_open(read_data=json.dumps(mock_manifest_data))),
        pytest.raises(ValueError, match="Invalid WorkflowManifest format"),
    ):
        await engine.execute("dummy_path3.json")

    # Test no type
    if isinstance(mock_manifest_data["topology"], dict) and "topology_class" in mock_manifest_data["topology"]:
        del mock_manifest_data["topology"]["topology_class"]
    with (
        patch("builtins.open", mock_open(read_data=json.dumps(mock_manifest_data))),
        pytest.raises(ValueError, match="Invalid WorkflowManifest format"),
    ):
        await engine.execute("dummy_path5.json")

    # Test read error
    with patch("builtins.open", side_effect=Exception("Read error")), pytest.raises(Exception, match="Read error"):
        await engine.execute("dummy_path4.json")


@pytest.mark.asyncio
async def test_broadcast_state_echo() -> None:
    from coreason_runtime.orchestration.activities import KineticActivities

    with (
        patch("coreason_runtime.orchestration.activities.TensorRouter"),
        patch("coreason_runtime.orchestration.activities.MedallionStateEngine"),
        patch("coreason_runtime.orchestration.activities.EpistemicLedgerManager"),
        patch("coreason_runtime.orchestration.activities.LatentMemoryManager"),
        patch("coreason_runtime.orchestration.activities.WasmSandboxExecutor"),
        patch("coreason_runtime.orchestration.activities.TelemetryEmitter") as mock_telemetry,
    ):
        ka = KineticActivities("http://sglang", "test/lancedb", "test/plugins", "http://telemetry")

        async def mock_emit(*args: Any, **kwargs: Any) -> None:
            pass

        mock_telemetry.return_value.emit = mock_emit

        res = await ka.broadcast_state_echo_io_activity("wf_1", {"test": "data"})
        assert res["status"] == "echoed"

        # test error
        import httpx

        async def mock_emit_error(*_args: Any, **_kwargs: Any) -> None:
            raise httpx.ConnectError("test")

        mock_telemetry.return_value.emit = mock_emit_error
        res_err = await ka.broadcast_state_echo_io_activity("wf_1", {"test": "data"})
        assert res_err["status"] == "echoed"


@pytest.mark.asyncio
async def test_activities() -> None:
    from coreason_runtime.orchestration.activities import KineticActivities

    with (
        patch("coreason_runtime.orchestration.activities.TensorRouter"),
        patch("coreason_runtime.orchestration.activities.MedallionStateEngine"),
        patch("coreason_runtime.orchestration.activities.EpistemicLedgerManager"),
        patch("coreason_runtime.orchestration.activities.LatentMemoryManager"),
        patch("coreason_runtime.orchestration.activities.WasmSandboxExecutor") as mock_sandbox,
        patch("coreason_runtime.orchestration.activities.TelemetryEmitter") as mock_telemetry,
        patch("coreason_runtime.orchestration.activities.MCPClientIntent.model_validate") as mock_mcp_intent,
    ):
        mock_mcp_intent.return_value = "mock_intent"
        ka = KineticActivities("http://sglang", "test/lancedb", "test/plugins", "http://telemetry")

        # test execute_mcp_tool_io_activity
        import asyncio

        from coreason_runtime.api.schema import SandboxReceipt

        f: asyncio.Future[Any] = asyncio.Future()
        f.set_result(SandboxReceipt.model_validate({"intent_hash": "test", "success": True}))
        mock_sandbox.return_value.execute_tool.return_value = f

        async def mock_emit(*args: Any, **kwargs: Any) -> None:
            pass

        mock_telemetry.return_value.emit = mock_emit

        # test execute_tensor_inference_compute_activity

        from coreason_manifest.spec.ontology import ExecutionNodeReceipt

        mock_tensor_f: asyncio.Future[Any] = asyncio.Future()
        mock_tensor_f.set_result(
            (ExecutionNodeReceipt(request_cid="test", inputs={}, outputs={}), {"prompt_tokens": 10}, 0.5)
        )

        import unittest.mock

        ka.tensor_router.route_inference = unittest.mock.AsyncMock(return_value=mock_tensor_f.result())  # type: ignore[method-assign]

        res = await ka.execute_tensor_inference_compute_activity("wf_1", {"node_cid": "test"}, "ExecutionNodeReceipt")
        assert isinstance(res, dict)
        assert res.get("cost") == 0.5
        assert res.get("usage") == {"prompt_tokens": 10}

        # Test schema fallback for AgentResponse
        res_ar = await ka.execute_tensor_inference_compute_activity("wf_1", {"node_cid": "test"}, "AgentResponse")
        assert res_ar.get("cost") == 0.5

        # Test schema fallback for DomainExtensions
        res_de = await ka.execute_tensor_inference_compute_activity(
            "wf_1",
            {"node_profile": {"node_cid": "test", "domain_extensions": {"CustomSchema": {"field": "description"}}}},
            "CustomSchema",
        )
        assert res_de.get("cost") == 0.5

        # Test schema fallback failure
        import pytest

        with pytest.raises(ValueError, match="Schema 'UnknownSchema' not found"):
            await ka.execute_tensor_inference_compute_activity("wf_1", {"node_cid": "test"}, "UnknownSchema")

        with patch("coreason_runtime.orchestration.activities.MCPClientIntent.model_validate") as mock_val:
            dummy_intent = MagicMock()
            dummy_intent.params = {"name": "test_tool", "arguments": {}}
            dummy_intent.model_dump_json.return_value = "{}"
            mock_val.return_value = dummy_intent

            res_mcp = await ka.execute_mcp_tool_io_activity(
                "test_tool",
                {
                    "jsonrpc": "2.0",
                    "method": "mcp.ui.emit_intent",
                    "holographic_projection": "test",
                    "params": {"name": "test_tool", "arguments": {}},
                },
            )
        assert "receipt" in res_mcp
        assert "system_state" in res_mcp

        # Test BudgetExceededError handling in execute_tensor_inference_compute_activity
        from coreason_runtime.tensor.router import BudgetExceededError

        ka.tensor_router.route_inference = unittest.mock.AsyncMock(side_effect=BudgetExceededError("test"))  # type: ignore[method-assign]
        res = await ka.execute_tensor_inference_compute_activity("wf_1", {"node_cid": "test"}, "ExecutionNodeReceipt")
        assert res["status"] == "epistemic_yield"
        assert res["reason"] == "budget_exceeded"

        # Test EpistemicYieldError handling in execute_tensor_inference_compute_activity
        from coreason_runtime.tensor.router import EpistemicYieldError

        ka.tensor_router.route_inference = unittest.mock.AsyncMock(side_effect=EpistemicYieldError("test"))  # type: ignore[method-assign]
        res = await ka.execute_tensor_inference_compute_activity("wf_1", {"node_cid": "test"}, "ExecutionNodeReceipt")
        assert res["status"] == "epistemic_yield"
        assert res["reason"] == "oracle_required"

        # Test general Exception handling in execute_tensor_inference_compute_activity
        ka.tensor_router.route_inference = unittest.mock.AsyncMock(side_effect=Exception("test panic"))  # type: ignore[method-assign]
        res = await ka.execute_tensor_inference_compute_activity("wf_1", {"node_cid": "test"}, "ExecutionNodeReceipt")
        assert res["status"] == "epistemic_yield"
        assert res["reason"] == "execution_panic"

        # test store_epistemic_state_io_activity
        ka.ledger.crystallize_gold_state = unittest.mock.AsyncMock(return_value=None)  # type: ignore[method-assign]
        ka.ledger.commit_bronze_entropy = unittest.mock.AsyncMock(return_value=None)  # type: ignore[method-assign]
        ka.latent.upsert_projection = unittest.mock.AsyncMock(return_value=None)  # type: ignore[method-assign]

        res = await ka.store_epistemic_state_io_activity(
            "wf_1", "hash_gold", True, {"request_cid": "test", "inputs": {}, "outputs": {}}
        )
        assert res["status"] == "gold_crystallized"

        # test crystallization failure
        res_fail = await ka.store_epistemic_state_io_activity("wf_1", "hash_gold", True, {"invalid_field": "test"})
        assert res_fail["status"] == "crystallization_failed"

        # test fail condition
        res_fail = await ka.store_epistemic_state_io_activity("wf_1", "hash_bronze", False, {"error": "test fail"})
        assert res_fail["status"] == "bronze_committed"

        import base64
        import struct

        ka._generate_dense_vector = unittest.mock.AsyncMock(return_value=[0.1])  # type: ignore[method-assign]

        encoded_vector = base64.b64encode(struct.pack(f"{1}f", 0.1)).decode("utf-8")
        res = await ka.store_epistemic_state_io_activity(
            "wf_1",
            "hash_latent",
            True,
            {"request_cid": "test", "inputs": {}, "outputs": {}},
            {
                "synthetic_target_vector": {
                    "foundation_matrix_name": "test",
                    "dimensionality": 1,
                    "vector_base64": encoded_vector,
                },
                "top_k_candidates": 10,
                "min_isometry_score": 0.5,
            },
        )
        assert res["status"] == "gold_crystallized"

        # Mock Extism Sandbox tool correctly for coverage
        import base64
        import struct

        mock_sandbox_f: asyncio.Future[Any] = asyncio.Future()
        from coreason_manifest.spec.ontology import ExecutionNodeReceipt

        mock_sandbox_f.set_result(ExecutionNodeReceipt(request_cid="test", inputs={}, outputs={}))

        with patch(
            "coreason_runtime.orchestration.activities.WasmSandboxExecutor.execute_tool",
            new_callable=unittest.mock.AsyncMock,
        ) as mock_exec:
            mock_exec.return_value = mock_sandbox_f.result()

            with patch("coreason_runtime.orchestration.activities.MCPClientIntent.model_validate") as mock_val:
                # Force passing validation to reach code

                # create a dummy intent object
                dummy_intent = MagicMock()
                dummy_intent.params = {"message": "hello"}
                dummy_intent.model_dump_json.return_value = "{}"
                mock_val.return_value = dummy_intent

                res = await ka.execute_mcp_tool_io_activity(
                    "test-tool",
                    {"jsonrpc": "2.0", "method": "mcp.ui.emit_intent", "params": {"message": "hello"}, "id": "123"},
                )
                assert isinstance(res, dict)

        # test request_oracle_intervention_io_activity
        res = await ka.request_oracle_intervention_io_activity("wf_1", "node_1", {"some": "context"})
        assert res["status"] == "oracle_requested"


@pytest.mark.asyncio
async def test_dag_workflow_state_direct() -> None:
    test_workflow = DAGExecutionWorkflow()
    with patch("temporalio.workflow.logger.info"):
        test_workflow.receive_oracle_override({"test": "data"})
        assert test_workflow._pending_oracle_override == {"test": "data"}


@pytest.mark.asyncio
async def test_swarm_workflow_inject_oracle_resolution() -> None:
    test_workflow = SwarmExecutionWorkflow()
    with patch("temporalio.workflow.logger.info"):
        await test_workflow.inject_oracle_resolution({"human_decision": "proceed"})
        assert test_workflow._current_oracle_resolution == {"human_decision": "proceed"}


# =====================================================
# Tests for Macro & Advanced Topology Workflows
# =====================================================


@pytest.fixture
def council_manifest() -> dict[str, Any]:
    return {
        "topology_class": "council",
        "adjudicator_cid": "did:test:adjudicator",
        "consensus_policy": {
            "strategy": "majority",
        },
        "nodes": {
            "did:test:member-1": {
                "topology_class": "agent",
                "description": "Council member 1.",
            },
            "did:test:member-2": {
                "topology_class": "agent",
                "description": "Council member 2.",
            },
            "did:test:adjudicator": {
                "topology_class": "agent",
                "description": "Council adjudicator.",
            },
        },
    }


@pytest.fixture
def digital_twin_manifest() -> dict[str, Any]:
    return {
        "topology_class": "digital_twin",
        "target_topology_cid": "did:test:target-topology-001",
        "convergence_sla": {
            "max_monte_carlo_rollouts": 3,
            "variance_tolerance": 0.5,
        },
        "enforce_no_side_effects": True,
        "nodes": {
            "did:test:twin-node-1": {
                "topology_class": "agent",
                "description": "Digital twin simulation node.",
            },
        },
    }


@pytest.fixture
def evolutionary_manifest() -> dict[str, Any]:
    return {
        "topology_class": "evolutionary",
        "generations": 1,
        "population_size": 2,
        "mutation": {
            "mutation_rate": 0.1,
            "temperature_shift_variance": 0.05,
        },
        "crossover": {"blending_factor": 0.5, "strategy_profile": "single_point"},
        "fitness_objectives": [
            {
                "target_metric": "accuracy",
                "direction": "maximize",
            },
        ],
        "nodes": {
            "did:test:evo-agent-1": {
                "topology_class": "agent",
                "description": "Evolutionary agent.",
            },
        },
    }


@pytest.fixture
def smpc_manifest() -> dict[str, Any]:
    return {
        "topology_class": "smpc",
        "smpc_protocol": "secret_sharing",
        "joint_function_uri": "sha256:abc123def456",
        "participant_node_cids": ["did:test:participant-1", "did:test:participant-2"],
        "nodes": {
            "did:test:participant-1": {
                "topology_class": "agent",
                "description": "SMPC participant 1.",
            },
            "did:test:participant-2": {
                "topology_class": "agent",
                "description": "SMPC participant 2.",
            },
        },
    }


@pytest.mark.asyncio
async def test_council_workflow(council_manifest: dict[str, Any]) -> None:
    """Test the CouncilExecutionWorkflow with majority consensus."""
    import asyncio

    from coreason_runtime.orchestration.workflows import CouncilExecutionWorkflow

    test_workflow = CouncilExecutionWorkflow()

    with (
        patch("temporalio.workflow.now") as mock_now,
        patch("temporalio.workflow.logger.info"),
        patch("temporalio.workflow.logger.warning"),
        patch("temporalio.workflow.execute_activity") as mock_execute,
        patch("temporalio.workflow.info") as mock_info,
        patch("temporalio.workflow.sleep") as mock_sleep,
    ):
        from datetime import datetime

        mock_now.return_value = datetime.now()
        mock_info.return_value.workflow_id = "test_council_wf"

        mock_f: asyncio.Future[Any] = asyncio.Future()
        mock_f.set_result(
            {
                "status": "success",
                "intent_hash": "mock-council-hash",
                "success": True,
                "result": {"output": "Council member output"},
            }
        )
        mock_execute.return_value = mock_f.result()

        mock_sleep_f: asyncio.Future[Any] = asyncio.Future()
        mock_sleep_f.set_result(None)
        mock_sleep.return_value = mock_sleep_f.result()

        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
            payload=council_manifest,
        ).model_dump(mode="json")

        result = await test_workflow.run(envelope)

        assert result["status"] == "success"
        assert result["consensus_detail"] == "majority"
        assert len(result["results"]) == 3  # 2 members + 1 adjudicator
        # Verify member results
        member_results = [r for r in result["results"] if r["type"] == "council_member"]
        assert len(member_results) == 2
        # Verify adjudicator result
        adj_results = [r for r in result["results"] if r["type"] == "adjudicator"]
        assert len(adj_results) == 1
        assert adj_results[0]["node_cid"] == "did:test:adjudicator"


@pytest.mark.asyncio
async def test_digital_twin_workflow(digital_twin_manifest: dict[str, Any]) -> None:
    """Test the DigitalTwinExecutionWorkflow with Monte Carlo convergence."""
    import asyncio

    from coreason_runtime.orchestration.workflows import DigitalTwinExecutionWorkflow

    test_workflow = DigitalTwinExecutionWorkflow()

    with (
        patch("temporalio.workflow.now") as mock_now,
        patch("temporalio.workflow.logger.info"),
        patch("temporalio.workflow.execute_activity") as mock_execute,
        patch("temporalio.workflow.info") as mock_info,
        patch("temporalio.workflow.sleep") as mock_sleep,
    ):
        from datetime import datetime

        mock_now.return_value = datetime.now()
        mock_info.return_value.workflow_id = "test_twin_wf"

        mock_f: asyncio.Future[Any] = asyncio.Future()
        mock_f.set_result(
            {
                "status": "success",
                "intent_hash": "mock-twin-hash",
                "success": True,
                "result": {"output": "Twin simulation result"},
            }
        )
        mock_execute.return_value = mock_f.result()

        mock_sleep_f: asyncio.Future[Any] = asyncio.Future()
        mock_sleep_f.set_result(None)
        mock_sleep.return_value = mock_sleep_f.result()

        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
            payload=digital_twin_manifest,
        ).model_dump(mode="json")

        result = await test_workflow.run(envelope)

        assert result["status"] == "success"
        # Rollouts completed should be <= max_monte_carlo_rollouts (3)
        assert result["rollouts_completed"] <= 3
        assert len(result["results"]) > 0
        # Since all rollouts return success=True (identical), variance should be 0 → converge early
        assert result["converged"] is True


@pytest.mark.asyncio
async def test_evolutionary_workflow(evolutionary_manifest: dict[str, Any]) -> None:
    """Test the EvolutionaryExecutionWorkflow with fitness evaluation."""
    import asyncio

    from coreason_runtime.orchestration.workflows import EvolutionaryExecutionWorkflow

    test_workflow = EvolutionaryExecutionWorkflow()

    with (
        patch("temporalio.workflow.now") as mock_now,
        patch("temporalio.workflow.logger.info"),
        patch("temporalio.workflow.execute_activity") as mock_execute,
        patch("temporalio.workflow.info") as mock_info,
        patch("temporalio.workflow.sleep") as mock_sleep,
    ):
        from datetime import datetime

        mock_now.return_value = datetime.now()
        mock_info.return_value.workflow_id = "test_evo_wf"

        mock_f: asyncio.Future[Any] = asyncio.Future()
        mock_f.set_result(
            {
                "status": "success",
                "intent_hash": "mock-evo-hash",
                "success": True,
                "result": {"output": "Evolved agent output"},
            }
        )
        mock_execute.return_value = mock_f.result()

        mock_sleep_f: asyncio.Future[Any] = asyncio.Future()
        mock_sleep_f.set_result(None)
        mock_sleep.return_value = mock_sleep_f.result()

        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
            payload=evolutionary_manifest,
        ).model_dump(mode="json")

        result = await test_workflow.run(envelope)

        assert result["status"] == "success"
        assert result["generations_completed"] == 1
        assert len(result["results"]) == 1
        gen_result = result["results"][0]
        assert gen_result["generation"] == 0
        assert gen_result["population_evaluated"] == 2


@pytest.mark.asyncio
async def test_smpc_workflow(smpc_manifest: dict[str, Any]) -> None:
    """Test the SMPCExecutionWorkflow with share generation and aggregation."""
    import asyncio

    from coreason_runtime.orchestration.workflows import SMPCExecutionWorkflow

    test_workflow = SMPCExecutionWorkflow()

    with (
        patch("temporalio.workflow.now") as mock_now,
        patch("temporalio.workflow.logger.info"),
        patch("temporalio.workflow.execute_activity") as mock_execute,
        patch("temporalio.workflow.info") as mock_info,
        patch("temporalio.workflow.sleep") as mock_sleep,
    ):
        from datetime import datetime

        mock_now.return_value = datetime.now()
        mock_info.return_value.workflow_id = "test_smpc_wf"

        mock_f: asyncio.Future[Any] = asyncio.Future()
        mock_f.set_result(
            {
                "status": "success",
                "intent_hash": "mock-smpc-hash",
                "success": True,
                "result": {"output": "SMPC share result"},
            }
        )
        mock_execute.return_value = mock_f.result()

        mock_sleep_f: asyncio.Future[Any] = asyncio.Future()
        mock_sleep_f.set_result(None)
        mock_sleep.return_value = mock_sleep_f.result()

        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
            payload=smpc_manifest,
        ).model_dump(mode="json")

        result = await test_workflow.run(envelope)

        assert result["status"] == "success"
        assert result["smpc_protocol"] == "secret_sharing"
        assert result["participants"] == 2
        # 2 share results + 1 aggregation
        assert len(result["results"]) == 3
        share_results = [r for r in result["results"] if r.get("type") == "share"]
        assert len(share_results) == 2
        agg_results = [r for r in result["results"] if r.get("type") == "aggregation"]
        assert len(agg_results) == 1


@pytest.mark.asyncio
async def test_consensus_federation_workflow() -> None:
    """Test ConsensusFederationExecutionWorkflow delegates to CouncilExecutionWorkflow."""
    import asyncio

    from coreason_runtime.orchestration.workflows import ConsensusFederationExecutionWorkflow

    test_workflow = ConsensusFederationExecutionWorkflow()

    with (
        patch("temporalio.workflow.now") as mock_now,
        patch("temporalio.workflow.logger.info"),
        patch("temporalio.workflow.execute_child_workflow") as mock_child,
        patch("temporalio.workflow.info") as mock_info,
    ):
        from datetime import datetime

        mock_now.return_value = datetime.now()
        mock_info.return_value.workflow_id = "test_federation_wf"

        # Mock the child workflow result
        mock_child_result: asyncio.Future[Any] = asyncio.Future()
        mock_child_result.set_result(
            {
                "status": "success",
                "consensus_detail": "pbft_quorum_met",
                "results": [{"type": "council_member"}, {"type": "adjudicator"}],
            }
        )
        mock_child.return_value = mock_child_result.result()

        # ConsensusFederationTopologyManifest requires participant_cids (min 3)
        # and adjudicator_cid isolated from participants
        federation_manifest: dict[str, Any] = {
            "topology_class": "macro_federation",
            "participant_cids": ["did:test:p1", "did:test:p2", "did:test:p3"],
            "adjudicator_cid": "did:test:sequencer",
            "quorum_rules": {
                "max_tolerable_faults": 0,
                "min_quorum_size": 3,
                "state_validation_metric": "ledger_hash",
                "byzantine_action": "quarantine",
            },
        }

        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
            payload=federation_manifest,
        ).model_dump(mode="json")

        result = await test_workflow.run(envelope)

        assert result["status"] == "success"
        # Verify that execute_child_workflow was called with CouncilExecutionWorkflow
        mock_child.assert_called_once()
        call_args = mock_child.call_args
        assert call_args[0][0] == "CouncilExecutionWorkflow"


@pytest.mark.asyncio
async def test_swarm_workflow_edge_cases() -> None:
    manifest = {
        "topology_class": "swarm",
        "nodes": {
            "did:test:agent-1": {
                "topology_class": "agent",
                "description": "Agent 1",
            },
            "did:test:agent-2": {
                "topology_class": "agent",
                "description": "Agent 2",
                "domain_extensions": {"dependencies": ["did:test:agent-1"]},
            },
        },
    }

    from temporalio.worker.workflow_sandbox import SandboxedWorkflowRunner

    async with (
        await WorkflowEnvironment.start_time_skipping() as env,
        Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[SwarmExecutionWorkflow],
            activities=[
                mock_execute_tensor_inference,
                mock_store_epistemic_state,
                mock_broadcast_state_echo,
                mock_execute_mcp_tool,
                mock_emit_resumed_event_activity,
                mock_request_oracle_intervention,
                mock_announce_task,
                mock_execute_resolve_auction,
                mock_execute_market_contract,
                mock_execute_settle_prediction_market,
            ],
            workflow_runner=SandboxedWorkflowRunner(
                restrictions=SandboxRestrictions.default.with_passthrough_all_modules()
            ),
        ),
    ):
        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        # Tests the max budget cap logic (> 1_000_000_000)
        state_vector = StateVectorProfile(
            immutable_matrix={},
            mutable_matrix={"compute_budget": 2_000_000_000},
            is_delta=False,
        )
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=state_vector,
            payload=manifest,
        ).model_dump(mode="json")

        handle = await env.client.start_workflow(
            SwarmExecutionWorkflow.run,
            envelope,
            id="test-swarm-edge-cases",
            task_queue=TASK_QUEUE,
        )

        import contextlib

        with contextlib.suppress(Exception):
            result = await handle.result()

        assert result["status"] == "success"


@pytest.mark.asyncio
async def test_dag_workflow_mechanistic_firewall_rollback(dag_manifest: dict[str, Any]) -> None:
    test_workflow = DAGExecutionWorkflow()

    with (
        patch("temporalio.workflow.now"),
        patch("temporalio.workflow.logger.info"),
        patch("temporalio.workflow.execute_activity") as mock_execute,
        patch("temporalio.workflow.info") as mock_info,
    ):
        mock_info.return_value.workflow_id = "test_wf_id"

        called_activities = []

        def mock_execute_side_effect(activity: str, _args: Any = None, **_kwargs: Any) -> dict[str, Any] | None:
            called_activities.append(activity)
            if activity == "ExecuteTensorInferenceComputeActivity":
                return {
                    "status": "epistemic_yield",
                    "error": "mechanistic_firewall_trip: hallucinatory vector bounds violated natively",
                    "node_cid": "mock-node-cid",
                }
            if activity in ("ApplyDefeasibleCascadeActivity", "ExecuteRollbackActivity"):
                return None
            return {"status": "success"}

        mock_execute.side_effect = mock_execute_side_effect

        import uuid6
        from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

        trace_id = str(uuid6.uuid7())
        envelope = ExecutionEnvelopeState[dict[str, Any]](
            trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
            state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}, is_delta=False),
            payload=dag_manifest,
        ).model_dump(mode="json")

        test_workflow._current_state_envelope = None

        import contextlib

        with contextlib.suppress(Exception):
            await test_workflow.run(envelope)

        assert "ApplyDefeasibleCascadeActivity" in called_activities
        assert "ExecuteRollbackActivity" in called_activities
