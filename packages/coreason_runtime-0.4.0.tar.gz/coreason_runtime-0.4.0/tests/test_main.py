# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, MagicMock, patch

from typer.testing import CliRunner

from coreason_runtime.cli import app, start_api, start_node


@patch("coreason_runtime.cli.CoreasonRuntime.execute", new_callable=AsyncMock)
@patch("coreason_runtime.cli.CoreasonRuntime.connect", new_callable=AsyncMock)
def test_execute(mock_connect: AsyncMock, mock_execute: AsyncMock, tmp_path) -> None:
    manifest = tmp_path / "test_path.json"
    manifest.write_text("{}")
    runner = CliRunner()
    result = runner.invoke(app, ["execute", str(manifest)])
    assert result.exit_code == 0

    mock_connect.assert_called_once()
    mock_execute.assert_called_once_with(str(manifest), exogenous_perturbation_vector=None)


@patch("uvicorn.run")
@patch("coreason_runtime.telemetry.broker.app.include_router")
def test_start_api(mock_include_router: MagicMock, mock_run: MagicMock) -> None:
    from unittest.mock import call

    from coreason_runtime.api.oracle import router as oracle_router
    from coreason_runtime.api.predict_router import predict_router
    from coreason_runtime.api.sandbox_router import sandbox_router, state_router
    from coreason_runtime.api.schema import router as schema_router

    start_api(port=8080)

    mock_include_router.assert_has_calls(
        [call(state_router), call(schema_router), call(oracle_router), call(sandbox_router), call(predict_router)]
    )
    mock_run.assert_called_once()
    _, kwargs = mock_run.call_args
    assert kwargs.get("host") == "0.0.0.0"  # noqa: S104
    assert kwargs.get("port") == 8080


@patch("coreason_runtime.cli.asyncio.run")
@patch("coreason_runtime.cli.start_worker")
def test_start_node(mock_start: MagicMock, mock_run: MagicMock) -> None:
    start_node()
    mock_start.assert_called_once_with("localhost:7233")
    mock_run.assert_called_once()
