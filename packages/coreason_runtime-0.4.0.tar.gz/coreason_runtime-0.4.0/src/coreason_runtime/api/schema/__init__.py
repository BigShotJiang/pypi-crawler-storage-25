# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

# From Phase 2
from typing import Any

from pydantic import BaseModel

from .execute_payload import ExecutePayload
from .router import _generate_cached_schema, router
from .sandbox_logs import SandboxLogs
from .sandbox_receipt import SandboxReceipt

# From Phase 3
from .sandbox_telemetry import SandboxTelemetry


class TopologySynthesisRequest(BaseModel):
    topology: str | dict[str, Any] | None = None
    user_prompt: str | None = None
    topological_manifold_bias: str | None = None
    epistemic_boundary_state: str | None = None
    max_agents: int | None = 10
    tenant_cid: str | None = "default-tenant"


__all__ = [
    "ExecutePayload",
    "SandboxLogs",
    "SandboxReceipt",
    "SandboxTelemetry",
    "TopologySynthesisRequest",
    "_generate_cached_schema",
    "router",
]
