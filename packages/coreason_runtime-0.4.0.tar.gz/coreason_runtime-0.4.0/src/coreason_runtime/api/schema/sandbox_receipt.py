# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from pydantic import BaseModel

from .sandbox_logs import SandboxLogs
from .sandbox_telemetry import SandboxTelemetry


class SandboxReceipt(BaseModel):
    intent_hash: str
    success: bool
    output: str | dict[str, Any] | None = None
    telemetry: SandboxTelemetry | None = None
    logs: SandboxLogs | None = None
    error: str | None = None
