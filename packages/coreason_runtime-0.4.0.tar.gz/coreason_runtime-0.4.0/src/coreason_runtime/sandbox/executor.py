# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
import hashlib
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from coreason_runtime.api.schema import SandboxLogs, SandboxReceipt, SandboxTelemetry
from coreason_runtime.sandbox.capabilities import build_extism_manifest
from coreason_runtime.sandbox.io import serialize_intent
from coreason_runtime.utils.exceptions import ManifestConformanceError
from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_MEMORY_LATTICE_PAGES

if TYPE_CHECKING:
    from coreason_manifest import MCPClientIntent


class WasmSandboxExecutor:
    """
    SOTA 2026 Sandbox Executor.
    Mathematically bounded WebAssembly environment with Thermodynamic Extraction.
    """

    def __init__(self, plugins_dir: str | None = None):
        """
        Initialize the mathematically bounded executor.

        Args:
            plugins_dir: The strictly designated, secure directory containing compiled .wasm files.
        """
        from coreason_runtime.utils.settings import COREASON_PLUGINS_DIR

        self.plugins_dir = Path(plugins_dir or COREASON_PLUGINS_DIR).resolve()

    def _sync_execute(
        self, tool_name: str, wasm_path: Path, manifest: dict[str, Any], intent: MCPClientIntent
    ) -> tuple[int, int, str, str, Any]:
        """
        Synchronous wrapper around Extism plugin creation and execution via zero-trust enclave.
        Enforces Topological Memory Caging and Thermodynamic Extraction.
        """

        extism_manifest = manifest.copy()
        extism_manifest["memory"] = {"max_pages": COREASON_MEMORY_LATTICE_PAGES}
        extism_manifest["allowed_paths"] = {}

        from pathlib import Path

        from coreason_runtime.sandbox.wasm_enclave import ExtismWasmEnclave

        enclave = ExtismWasmEnclave()
        enclave.initialize_plugin(Path(wasm_path), extism_manifest)

        import asyncio

        start_exec = time.perf_counter_ns()
        enclave_receipt = asyncio.run(enclave.execute_intent(tool_name, intent))
        latency_ns = time.perf_counter_ns() - start_exec

        plugin_obj = enclave.plugin
        """Eradicate fallback laziness; retrieve exact WASM linear memory strictly from the Extism plugin instance."""
        memory_bytes = getattr(
            plugin_obj,
            "memory_length",
            extism_manifest.get("memory", {}).get("max_pages", COREASON_MEMORY_LATTICE_PAGES) * 65536,
        )

        return (latency_ns, memory_bytes, "", "", enclave_receipt)

    async def execute_tool(self, tool_name: str, intent: MCPClientIntent) -> SandboxReceipt:
        """
        Execute a WebAssembly tool securely inside the isolated memory lattice.

        AGENT INSTRUCTION: Enforces Deterministic Panic Absorption.
        Host OS noise is scrubbed from WebAssembly hardware traps to yield a clean,
        safe SandboxReceipt without crashing the Temporal worker.
        """
        serialized_intent = serialize_intent(intent)
        intent_hash = hashlib.sha256(serialized_intent).hexdigest()

        fallback_start_ns = time.perf_counter_ns()

        tool_filename = f"{tool_name}.wasm" if not tool_name.endswith(".wasm") else tool_name
        wasm_path = (self.plugins_dir / tool_filename).resolve()

        if not wasm_path.is_relative_to(self.plugins_dir):
            error_msg = f"Path traversal attack detected: {tool_name}"
            logger.error(error_msg)
            return SandboxReceipt(intent_hash=intent_hash, success=False, error=error_msg)

        if not wasm_path.exists():
            error_msg = f"WASM tool not found: {wasm_path}"
            logger.error(error_msg)
            return SandboxReceipt(intent_hash=intent_hash, success=False, error=error_msg)

        manifest = build_extism_manifest(intent)

        logger.info(f"Kinetic Execution: Igniting WASM capability '{tool_name}'...")

        try:
            latency_ns, memory_bytes, stdout_str, stderr_str, enclave_receipt = await asyncio.to_thread(
                self._sync_execute, tool_name, wasm_path, manifest, intent
            )

            logger.info(
                f"Capability '{tool_name}' completed. M_peak: {memory_bytes} bytes. Latency: {latency_ns / 1e6:.2f}ms"
            )

            parsed_output = enclave_receipt.model_dump(mode="json")
            return SandboxReceipt(
                intent_hash=intent_hash,
                success=True,
                output=parsed_output,
                telemetry=SandboxTelemetry(latency_ns=latency_ns, peak_memory_bytes=memory_bytes),
                logs=SandboxLogs(stdout=stdout_str, stderr=stderr_str),
            )

        except ManifestConformanceError as e:
            trap_latency_ns = time.perf_counter_ns() - fallback_start_ns
            error_trace = str(e)

            clean_error = error_trace.rsplit("\n", maxsplit=1)[-1] if "\n" in error_trace else error_trace

            logger.warning(f"Epistemic Yield: Capability '{tool_name}' trapped execution. Reason: {clean_error}")

            return SandboxReceipt(
                intent_hash=intent_hash,
                success=False,
                error=f"WASM Trap/Conformance Error: {clean_error}",
                telemetry=SandboxTelemetry(latency_ns=trap_latency_ns, peak_memory_bytes=65536),
                logs=SandboxLogs(stdout="", stderr=error_trace),
            )
        except Exception as e:
            logger.exception(f"Sandbox virtualization error for '{tool_name}': {e}")
            return SandboxReceipt(intent_hash=intent_hash, success=False, error=f"Internal Sandbox Error: {e!s}")
