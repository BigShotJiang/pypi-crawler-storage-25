# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from coreason_runtime.utils.logger import logger


class ManifoldProjector:
    """Zero-trust UI projector that compiles internal runtime geometries into declarative manifold profiles.

    Translates dense backend state (AST gradients, thermodynamic burns, topology graphs) into
    structured panel profiles that instruct visual clients (coreason-vscode) on rendering,
    without the runtime ever producing HTML/WebGL itself.
    """

    @staticmethod
    def compile_ast_gradient(receipt: Any) -> dict[str, Any]:
        """Compile an ASTGradientReceipt into a GrammarPanelProfile for frontend visualization.

        Maps the loss vector into a 2D line/point grammar chart representation.

        Args:
            receipt: An ASTGradientReceipt instance from coreason-manifest.

        Returns:
            A dict representing a GrammarPanelProfile.
        """
        loss_vector = getattr(receipt, "loss_vector", [])
        source_file = getattr(receipt, "source_file_cid", "unknown")
        fracture_line = getattr(receipt, "fracture_line", 0)
        severity = getattr(receipt, "severity", "warning")

        data_points = []
        for idx, loss_val in enumerate(loss_vector):
            data_points.append(
                {
                    "index": idx,
                    "loss": float(loss_val),
                    "annotation": f"token_{idx}",
                }
            )

        return {
            "panel_type": "grammar_panel",
            "source_file_cid": str(source_file),
            "fracture_line": int(fracture_line),
            "severity": str(severity),
            "chart_type": "line",
            "data_points": data_points,
            "title": f"AST Gradient — {source_file}:{fracture_line}",
            "description": f"Syntactic fracture detected at line {fracture_line}. "
            f"Loss vector contains {len(loss_vector)} gradient samples.",
        }

    @staticmethod
    def compile_burn_card(burn: Any, budget: int) -> dict[str, Any]:
        """Compile a TokenBurnReceipt into an InsightCardProfile for budget warnings.

        Generates a safe Markdown-formatted warning card without malicious URIs
        or unescaped HTML.

        Args:
            burn: A TokenBurnReceipt from coreason-manifest.
            budget: The total compute budget in tokens.

        Returns:
            A dict representing an InsightCardProfile.
        """
        input_tokens = int(getattr(burn, "input_tokens", 0))
        output_tokens = int(getattr(burn, "output_tokens", 0))
        burn_magnitude = int(getattr(burn, "burn_magnitude", 0))
        tool_cid = str(getattr(burn, "tool_invocation_cid", "unknown"))

        total_burn = input_tokens + output_tokens
        utilization_pct = (total_burn / budget * 100) if budget > 0 else 0.0

        if utilization_pct >= 90:
            severity = "critical"
            emoji = "🔴"
        elif utilization_pct >= 70:
            severity = "warning"
            emoji = "🟡"
        else:
            severity = "info"
            emoji = "🟢"

        # Safe Markdown — no raw HTML, no external URIs
        markdown_body = (
            f"## {emoji} Thermodynamic Burn Report\\n\\n"
            f"**Node:** `{tool_cid}`\\n\\n"
            f"| Metric | Value |\\n"
            f"|--------|-------|\\n"
            f"| Input Tokens | {input_tokens:,} |\\n"
            f"| Output Tokens | {output_tokens:,} |\\n"
            f"| Burn Magnitude | {burn_magnitude:,} |\\n"
            f"| Budget Utilization | {utilization_pct:.1f}% |\\n"
        )

        return {
            "panel_type": "insight_card",
            "severity": severity,
            "title": f"Token Burn — {tool_cid}",
            "markdown_body": markdown_body,
            "utilization_percentage": utilization_pct,
            "remaining_budget": max(0, budget - total_burn),
        }

    @staticmethod
    def package_into_mcp_intent(panels: list[dict[str, Any]]) -> dict[str, Any]:
        """Wrap compiled panel profiles into an MCPClientIntent for frontend delivery.

        Args:
            panels: A list of compiled panel profiles (GrammarPanelProfile, InsightCardProfile, etc.)

        Returns:
            A dict representing an MCPClientIntent with method 'mcp.ui.emit_intent'.
        """
        if not panels:
            logger.warning("ManifoldProjector: No panels to package into MCPClientIntent.")

        return {
            "method": "mcp.ui.emit_intent",
            "params": {
                "holographic_projection": panels,
                "panel_count": len(panels),
            },
        }
