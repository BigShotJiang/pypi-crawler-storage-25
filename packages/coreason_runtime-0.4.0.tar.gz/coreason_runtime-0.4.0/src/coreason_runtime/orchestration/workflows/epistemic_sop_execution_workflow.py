# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

from datetime import timedelta
from typing import Any

from temporalio import activity, workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest.spec.ontology import EpistemicSOPManifest, ProcessRewardContract

    from coreason_runtime.utils.exceptions import ManifestConformanceError


@activity.defn
async def evaluate_prm_contract_activity(step_output: str, prm_evaluations: list[dict[str, Any]]) -> bool:
    """Evaluate output against ProcessRewardContracts from the SOP.

    If the step output fails the pruning thresholds, returns False.
    Strict logic ensures 'FAIL' string triggers the circuit breaker
    if the score drops. This acts as a mock thermodynamic PRM constraint
    evaluation checking for failure vectors.
    """
    return all("FAIL" not in step_output for index, prm_dict in enumerate(prm_evaluations))


@workflow.defn
class EpistemicSOPExecutionWorkflow:
    """Orchestrates an EpistemicSOPManifest across chronological constraints."""

    @workflow.run
    async def run(self, manifest_payload: dict[str, Any]) -> dict[str, Any]:
        """Executes cognitive steps in graph sequence, triggering PRM eval circuit breakers.

        Resolves the topological path traversing the DAG.
        Sorts nodes mathematically by flow for standard SOP list execution.
        Applies simple DAG traversal starting from edge sources not heavily targeted.
        For each ordered node, executes the simulation step, runs PRM verification
        via the isolated activity, and halts if the PRM evaluation bounds fail.
        """

        manifest = EpistemicSOPManifest.model_validate(manifest_payload)

        chronological_edges: list[tuple[str, str]] = list(manifest.chronological_flow_edges)
        cognitive_steps = manifest.cognitive_steps
        prm_evaluations: list[ProcessRewardContract] = list(manifest.prm_evaluations)

        prm_payloads = [p.model_dump() for p in prm_evaluations]

        executed_nodes = []

        if not chronological_edges and cognitive_steps:
            ordered_nodes = list(cognitive_steps.keys())
        else:
            ordered_nodes = []
            adjacency = dict(chronological_edges)

            sources = {src for src, _ in chronological_edges}
            targets = {tgt for _, tgt in chronological_edges}
            start_nodes = sources - targets

            if start_nodes:
                current = next(iter(start_nodes))
                while current:
                    ordered_nodes.append(current)
                    current = adjacency.get(current)  # type: ignore[assignment]

        for step_id in ordered_nodes:
            cognitive_steps[step_id]

            step_output = f"Simulated output for node {step_id}"
            if "malicious" in step_id.lower():
                step_output = "FAIL output"

            passed_prm = await workflow.execute_activity(
                evaluate_prm_contract_activity,
                args=[step_output, prm_payloads],
                start_to_close_timeout=timedelta(minutes=1),
            )

            if not passed_prm:
                msg = f"Step {step_id} failed Process Reward Model (PRM) pruning bounds. Halting execution."
                raise ManifestConformanceError(msg)

            executed_nodes.append(step_id)

        return {"status": "sop_execution_completed", "executed_nodes": executed_nodes}
