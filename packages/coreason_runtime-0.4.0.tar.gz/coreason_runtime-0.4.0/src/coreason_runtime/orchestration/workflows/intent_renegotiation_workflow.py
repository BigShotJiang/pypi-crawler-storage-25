# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Intent renegotiation execution logic.

AGENT INSTRUCTION: This workflow acts as an automated broker fixing rejection boundaries mathematically.
"""

from datetime import timedelta
from typing import TypedDict

from coreason_manifest.spec.ontology import IntentClassificationReceipt
from loguru import logger
from temporalio import activity, workflow

from coreason_runtime.utils.exceptions import ManifestConformanceError


class RejectionReceiptDict(TypedDict, total=False):
    violated_algebraic_constraint: list[str]
    stochastic_mutation_gradient: float


class IntentDict(TypedDict, total=False):
    intent_hash: str


class RenegotiationPayload(TypedDict, total=False):
    rejection: RejectionReceiptDict
    intent: IntentDict
    violated_algebraic_constraint: list[str]
    stochastic_mutation_gradient: float


class RejectionParametersResult(TypedDict, total=False):
    violated_algebraic_constraint: list[str]
    stochastic_mutation_gradient: float


class IntentParamsDict(TypedDict, total=False):
    adjusted: bool


class RepackagedIntentDict(TypedDict, total=False):
    intent_hash: str
    params: IntentParamsDict


class CompromiseIntentResult(TypedDict, total=False):
    new_intent: RepackagedIntentDict


@activity.defn
async def parse_rejection_parameters_activity(payload: RenegotiationPayload) -> RejectionParametersResult:
    """Parse the cryptographic denial parameters.

    AGENT INSTRUCTION: Ensure the constraints are mathematically extracted.
    """
    logger.info("Parsing rejection boundaries mathematically constraints.")
    receipt = payload.get("rejection", {})
    if receipt.get("violated_algebraic_constraint") is None:
        msg = "Invalid EpistemicRejectionReceipt: missing algebraic constraints."
        raise ManifestConformanceError(msg)

    constraints = receipt.get("violated_algebraic_constraint", [])
    if constraints is None:
        constraints = []

    gradient = float(receipt.get("stochastic_mutation_gradient", 0.0))

    return RejectionParametersResult(
        violated_algebraic_constraint=constraints,
        stochastic_mutation_gradient=gradient,
    )


@activity.defn
async def synthesize_compromise_intent_activity(payload: RenegotiationPayload) -> CompromiseIntentResult:
    """Coordinate mathematically constrained renegotiation.

    AGENT INSTRUCTION: Use SGLang proxy to reform the intent dynamically.
    """
    logger.info("Synthesizing compromise topology intent boundary.")
    if not payload.get("intent"):
        msg = "Invalid BoundedJSONRPCIntent: missing explicit intent structure."
        raise ManifestConformanceError(msg)

    intent = payload.get("intent", {})
    intent_hash = intent.get("intent_hash", "")
    intent_data: RepackagedIntentDict = {"intent_hash": intent_hash, "params": {"adjusted": True}}

    return CompromiseIntentResult(new_intent=intent_data)


@workflow.defn
class IntentRenegotiationExecutionWorkflow:
    """Mathematical constrained renegotiation of intents."""

    def __init__(self) -> None:
        """Initialize IntentRenegotiationExecutionWorkflow."""

    @workflow.run
    async def run(self, payload: RenegotiationPayload) -> CompromiseIntentResult:
        """Execute boundary negotiation fallback protocol.

        Args:
            payload: Internal payload containing the unfulfilled intent and receipt payload.

        Returns:
            The newly synthesized and adjusted intent dict.
        """
        logger.info("Transition: execute syntactic boundary parsing protocol")
        parse_result = await workflow.execute_activity(
            parse_rejection_parameters_activity,
            payload,
            schedule_to_close_timeout=timedelta(seconds=60),
        )

        synth_payload = RenegotiationPayload(**payload)
        synth_payload.update(parse_result)  # type: ignore

        IntentClassificationReceipt(
            event_cid=workflow.info().run_id,
            timestamp=0.0,
            classified_intent="renegotiation",
            confidence_score=1.0,
            raw_input_string=str(payload.get("intent", {})),
        )

        logger.info("Transition: orchestrate compromise topology layout")
        return await workflow.execute_activity(
            synthesize_compromise_intent_activity,
            synth_payload,
            schedule_to_close_timeout=timedelta(seconds=120),
        )
