# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Literal

from pydantic import Field

from .telemetry_event import TelemetryEvent


class ToolExecutionUpdate(TelemetryEvent):
    """Emitted by the Extism sandbox during tool execution."""

    event_type: Literal["ToolExecutionUpdate"] = Field(
        "ToolExecutionUpdate", description="The type of the telemetry event."
    )
    status: Literal["started", "finished", "failed"] = Field(description="The current status of the tool execution.")
    tool_name: str = Field(description="The name of the tool being executed.")
    duration_ms: float = Field(description="The duration of the tool execution in milliseconds.")
