# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any, Literal

from pydantic import Field

from .telemetry_event import TelemetryEvent


class StateTransitionedEvent(TelemetryEvent):
    """Emitted when an agent completes its turn."""

    event_type: Literal["StateTransitionedEvent"] = Field(
        "StateTransitionedEvent", description="The type of the telemetry event."
    )
    workflow_id: str = Field(description="The unique identifier for the Temporal workflow.")
    payload: dict[str, Any] = Field(
        description="The generic payload containing the ExecutionNodeReceipt or other state data."
    )
