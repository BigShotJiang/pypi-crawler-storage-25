# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from coreason_manifest import TraceContextState
from pydantic import BaseModel, Field


class TelemetryEvent(BaseModel):
    """Base class for all telemetry.events."""

    event_type: str = Field(description="The type of the telemetry event.")
    trace_context: TraceContextState | None = Field(
        default=None, description="The cryptographic trace context for distributed causality."
    )
