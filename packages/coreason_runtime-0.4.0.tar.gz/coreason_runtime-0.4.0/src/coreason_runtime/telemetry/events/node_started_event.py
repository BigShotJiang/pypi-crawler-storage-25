# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Literal

from pydantic import Field

from .telemetry_event import TelemetryEvent


class NodeStartedEvent(TelemetryEvent):
    """Emitted when the DAG/Swarm moves to a new agent."""

    event_type: Literal["NodeStartedEvent"] = Field("NodeStartedEvent", description="The type of the telemetry event.")
    node_cid: str = Field(description="The unique identifier for the execution node.")
    agent_name: str = Field(description="The name of the agent assigned to this node.")
    timestamp: str = Field(description="The ISO 8601 timestamp of when the node started.")
