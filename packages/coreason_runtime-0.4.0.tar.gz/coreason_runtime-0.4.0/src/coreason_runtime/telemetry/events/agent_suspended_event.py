# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any, Literal

from pydantic import Field

from .telemetry_event import TelemetryEvent


class AgentSuspendedEvent(TelemetryEvent):
    """Emitted when an agent hits an uncertainty boundary and yields execution."""

    event_type: Literal["AgentSuspendedEvent"] = Field(
        "AgentSuspendedEvent", description="The type of the telemetry event."
    )
    workflow_id: str = Field(description="The routing key for Temporal resumption.")
    agent_name: str = Field(description="The name of the yielded agent.")
    suspension_reason: Literal["schema_violation", "oracle_required", "budget_exceeded", "execution_panic"] = Field(
        description="The strictly finite reason for suspension."
    )
    latent_state: dict[str, Any] = Field(description="The agent's memory ledger at the time of yielding.")
    failed_intent: dict[str, Any] | None = Field(
        default=None, description="The precise JSON payload the agent attempted to execute."
    )
