# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json

import requests
import streamlit as st

# Set up page config
st.set_page_config(page_title="CoReason Telemetry", layout="wide")

st.title("CoReason Execution Telemetry")

# Sidebar for the execution graph
st.sidebar.title("Execution Graph")
st.sidebar.write("TopologyManifest graph visualization placeholder.")

# Main column for Agent Chat
st.header("Agent Chat")

# Placeholder for text streaming
current_stream_placeholder = st.empty()


def render_app() -> None:
    global current_stream_placeholder
    # Attempt to connect to SSE stream
    try:
        # Use a tuple for timeout: (connect_timeout, read_timeout).
        # We set read_timeout to None because SSE is a continuous stream
        # that could be idle for long periods while an agent "thinks".
        response = requests.get("http://localhost:8000/api/v1/telemetry/stream", stream=True, timeout=(10, None))
        if response.status_code == 200:
            for line in response.iter_lines():
                if line:
                    decoded_line = line.decode("utf-8")
                    if decoded_line.startswith("data: "):
                        json_data = decoded_line[len("data: ") :]
                        try:
                            event_dict = json.loads(json_data)
                            event_type = event_dict.get("event_type")

                            if event_type == "NodeStartedEvent":
                                agent_name = event_dict.get("agent_name", "Unknown")
                                node_cid = event_dict.get("node_cid", "Unknown")
                                with st.chat_message(agent_name):
                                    st.write(f"**Agent {agent_name} started** (Node: {node_cid})")
                                    # Prepare the stream placeholder inside the chat block
                                    current_stream_placeholder = st.empty()

                            elif event_type == "TokenStreamChunk":
                                chunk = event_dict.get("text_chunk", "")
                                # A simple incremental UI update mechanism (typewriter effect)
                                # In an actual deployment, we'd accumulate the text in session_state,
                                # but here we follow simple reactive updating as per instructions.
                                # Assuming we accumulate inside session state:
                                node_cid = event_dict.get("node_cid")
                                state_key = f"stream_{node_cid}"
                                if state_key not in st.session_state:
                                    st.session_state[state_key] = ""

                                st.session_state[state_key] += chunk
                                current_stream_placeholder.write(st.session_state[state_key])

                        except json.JSONDecodeError:
                            pass
        else:
            st.error(f"Failed to connect to broker: {response.status_code}")
    except requests.exceptions.RequestException as e:
        st.error(f"Connection error: {e}")


if __name__ == "__main__":
    render_app()  # pragma: no cover
