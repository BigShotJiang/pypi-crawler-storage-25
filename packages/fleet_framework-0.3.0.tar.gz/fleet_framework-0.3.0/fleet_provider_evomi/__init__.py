from __future__ import annotations

import secrets
import string
from dataclasses import dataclass
from typing import Any, Literal, Optional

from fleet.core import ProxySession, register_provider, resolve_countries

_DEFAULT_PORTS = {"http": 1000, "socks5": 1002}


@dataclass
class EvomiConfig:
    username: str
    password: str
    host: str = "core-residential.evomi.com"
    scheme: Literal["http", "socks5"] = "http"
    port: Optional[int] = None  # defaults from scheme
    # str preset ("EU", "EU+US", ...), list of ISO codes, or comma-separated string.
    countries: Optional[str | list[str]] = None
    sticky_lifetime_minutes: int = 60  # evomi default


def _session_id(length: int = 10) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


@register_provider("evomi")
class EvomiProvider:
    def __init__(self, cfg: EvomiConfig) -> None:
        self._cfg = cfg

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "EvomiProvider":
        return cls(EvomiConfig(**cfg))

    async def acquire(
        self,
        *,
        slot_id: int,
        sticky: bool = True,
        country: Optional[str | list[str]] = None,
    ) -> ProxySession:
        c = self._cfg
        scheme = c.scheme
        port = c.port if c.port is not None else _DEFAULT_PORTS[scheme]

        # password carries the directives, joined with underscores.
        password_parts: list[str] = [c.password]
        cc = country if country is not None else c.countries
        codes = resolve_countries(cc)
        if codes:
            password_parts.append("country-" + ",".join(codes))
        sid: Optional[str] = None
        if sticky:
            sid = _session_id()
            password_parts.append("session-" + sid)
            if c.sticky_lifetime_minutes and c.sticky_lifetime_minutes != 60:
                password_parts.append("lifetime-" + str(c.sticky_lifetime_minutes))
        password = "_".join(password_parts)

        url = f"{scheme}://{c.username}:{password}@{c.host}:{port}"
        return ProxySession(
            url=url,
            metadata={
                "provider": "evomi",
                "scheme": scheme,
                "country": codes,
                "sticky": sticky,
                "session_id": sid,
                "lifetime_min": c.sticky_lifetime_minutes if sticky else None,
                "slot_id": slot_id,
            },
        )
