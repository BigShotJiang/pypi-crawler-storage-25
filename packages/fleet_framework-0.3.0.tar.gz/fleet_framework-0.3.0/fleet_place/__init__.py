"""fleet-place — abstract place / POI / listing automation contract.

Covers maps (Google / Apple), lodging (Booking / Airbnb / Hotels.com /
Expedia), real estate (Zillow / Redfin / Realtor), restaurants (Yelp /
OpenTable), travel POIs (TripAdvisor).
"""

from fleet_place.automation import PlaceAutomation, PlaceConfig
from fleet_place.contracts import (
    Address,
    GeoPoint,
    Place,
    PlaceHours,
    PlaceQuery,
    PlaceQueryKind,
    PlaceResult,
    PlaceReview,
    PlaceSource,
)

__all__ = [
    "Address",
    "GeoPoint",
    "Place",
    "PlaceAutomation",
    "PlaceConfig",
    "PlaceHours",
    "PlaceQuery",
    "PlaceQueryKind",
    "PlaceResult",
    "PlaceReview",
    "PlaceSource",
]
