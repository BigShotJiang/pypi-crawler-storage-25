from __future__ import annotations

from typing import ClassVar

from fleet.core.automation import BatchAutomation, Task
from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet_place.contracts import PlaceQuery, PlaceResult


class PlaceConfig(BaseConfig):
    """Default config for place plugins. Concrete plugins add provider-
    specific keys (API key, session cookie, region affinity)."""

    default_locale: str = "en-US"
    default_currency: str | None = None


class PlaceAutomation(BatchAutomation[PlaceConfig]):
    """Abstract base for one query in -> one PlaceResult out.

    The same shape covers Google Maps "find restaurants near me",
    Booking "hotels in Barcelona", Zillow "houses in 94043", and a
    point lookup ("place_id=XYZ details"). Concrete plugins override
    `run_one` and dispatch on `task.payload.kind` to support the
    `PlaceQueryKind` values they cover.
    """

    Config: ClassVar = PlaceConfig
    TaskPayload: ClassVar = PlaceQuery
    Output: ClassVar = PlaceResult

    async def run_one(self, task: Task, ctx: Context) -> None:
        raise NotImplementedError(
            f"{type(self).__name__}.run_one must be overridden — the "
            "abstract PlaceAutomation does not call any provider.",
        )
