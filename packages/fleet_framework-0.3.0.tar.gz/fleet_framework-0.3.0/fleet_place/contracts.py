from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, HttpUrl, model_validator


class PlaceSource(str, Enum):
    GOOGLE_MAPS = "google_maps"
    APPLE_MAPS = "apple_maps"
    BOOKING = "booking"
    AIRBNB = "airbnb"
    YELP = "yelp"
    TRIPADVISOR = "tripadvisor"
    ZILLOW = "zillow"
    REDFIN = "redfin"
    REALTOR = "realtor"
    HOTELS_COM = "hotels_com"
    EXPEDIA = "expedia"
    OPEN_TABLE = "open_table"


class GeoPoint(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lng: float = Field(ge=-180, le=180)


class Address(BaseModel):
    street: str | None = None
    city: str | None = None
    region: str | None = None
    country: str | None = None
    """ISO-3166-1 alpha-2 when known; otherwise the source's display name."""

    postal_code: str | None = None
    full: str | None = None
    """One-line formatted address as the source rendered it. Useful when
    structured fields are missing or unparseable."""


class PlaceHours(BaseModel):
    weekday: int = Field(ge=0, le=6)
    """0 = Monday, 6 = Sunday (ISO weekday minus 1)."""

    open_at: str | None = None
    """24h 'HH:MM' local to the place's timezone. None when closed all day."""

    close_at: str | None = None
    closed: bool = False
    """True overrides open_at/close_at. Useful for 'closed for renovation'."""


class PlaceReview(BaseModel):
    author: str | None = None
    rating: float = Field(ge=0.0, le=5.0)
    text: str | None = None
    posted_at: datetime | None = None
    url: HttpUrl | None = None
    response_text: str | None = None
    """Owner's reply, when present (Google Maps / Yelp / TripAdvisor all
    support this)."""


class Place(BaseModel):
    source: PlaceSource
    place_id: str
    """Stable identifier on the source. Plugins MUST populate this — the
    deduplication / pool-key strategy depends on it."""

    name: str
    categories: list[str] = Field(default_factory=list)
    address: Address = Field(default_factory=Address)
    geo: GeoPoint | None = None
    phone: str | None = None
    url: HttpUrl

    rating: float | None = Field(default=None, ge=0.0, le=5.0)
    review_count: int | None = Field(default=None, ge=0)
    price_level: int | None = Field(default=None, ge=1, le=4)
    """1-4 dollar-sign scale where 1 = cheap, 4 = expensive. Sources that
    publish currency-symbol counts (Yelp, OpenTable) map to this; sources
    that publish exact ranges (Booking) leave it None."""

    hours: list[PlaceHours] = Field(default_factory=list)
    photos: list[HttpUrl] = Field(default_factory=list)
    amenities: list[str] = Field(default_factory=list)
    """Free-form tags: 'wifi', 'parking', 'pool', 'pet_friendly'. The
    framework doesn't normalize these — concrete plugins decide."""

    reviews: list[PlaceReview] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class PlaceQueryKind(str, Enum):
    TEXT_SEARCH = "text_search"
    NEARBY = "nearby"
    DETAILS = "details"
    AVAILABILITY = "availability"
    """Source-specific availability lookup (e.g. Booking dates, Airbnb
    check-in/check-out). Most plugins won't implement this."""


class PlaceQuery(BaseModel):
    source: PlaceSource
    kind: PlaceQueryKind = PlaceQueryKind.TEXT_SEARCH
    query: str | None = None
    """Text-search query string. Required when kind=TEXT_SEARCH."""

    near: GeoPoint | None = None
    """Anchor for kind=NEARBY (radius_meters required)."""

    radius_meters: int | None = Field(default=None, ge=1, le=50_000)
    place_id: str | None = None
    """Required when kind=DETAILS or kind=AVAILABILITY."""

    check_in: datetime | None = None
    """Required when kind=AVAILABILITY (lodging sources)."""

    check_out: datetime | None = None
    guests: int | None = Field(default=None, ge=1)
    locale: str = "en-US"
    currency: str | None = None
    """ISO 4217 — needed by Booking/Airbnb to return prices in your
    currency rather than the listing's local."""

    page: int = Field(default=1, ge=1, le=100)
    limit: int = Field(default=20, ge=1, le=100)

    device: Literal["desktop", "mobile"] = "desktop"

    @model_validator(mode="after")
    def _kind_requires(self) -> "PlaceQuery":
        if self.kind == PlaceQueryKind.TEXT_SEARCH and not self.query:
            raise ValueError("kind=text_search requires `query`")
        if self.kind == PlaceQueryKind.NEARBY:
            if self.near is None or self.radius_meters is None:
                raise ValueError("kind=nearby requires `near` and `radius_meters`")
        if self.kind in (PlaceQueryKind.DETAILS, PlaceQueryKind.AVAILABILITY) and not self.place_id:
            raise ValueError(f"kind={self.kind.value} requires `place_id`")
        if self.kind == PlaceQueryKind.AVAILABILITY and (self.check_in is None or self.check_out is None):
            raise ValueError("kind=availability requires `check_in` and `check_out`")
        return self


class PlaceResult(BaseModel):
    """Output for a PlaceQuery. Always a list — text_search and nearby
    return many; details returns a list of length 1; availability
    returns a list of length 1 with availability-specific data in
    `raw`."""

    query: PlaceQuery
    places: list[Place] = Field(default_factory=list)
    next_page_token: str | None = None
    raw: dict[str, Any] = Field(default_factory=dict)
