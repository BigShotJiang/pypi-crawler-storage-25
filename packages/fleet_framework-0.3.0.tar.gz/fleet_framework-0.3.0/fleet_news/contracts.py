from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl


class NewsSourceKind(str, Enum):
    RSS = "rss"
    ATOM = "atom"
    JSON_FEED = "json_feed"
    GOOGLE_NEWS = "google_news"
    HACKER_NEWS = "hacker_news"
    REDDIT = "reddit"
    SITEMAP = "sitemap"
    """Some news sites publish a sitemap-news.xml; treat it like a feed."""


class NewsFeed(BaseModel):
    kind: NewsSourceKind
    url: HttpUrl
    label: str | None = None
    """Optional human label, e.g. 'NYT - Politics' or 'r/programming'."""

    categories: list[str] = Field(default_factory=list)
    """Tag this feed with one or more topics. The framework doesn't
    interpret these — they ride through to the emitted Article model so
    downstream consumers can route by category."""


class NewsArticle(BaseModel):
    feed_url: str
    """The feed URL that emitted this article — useful for dedup +
    per-source rate-limiting downstream."""

    article_id: str
    """Stable id within the feed. Plugins should use the entry's <guid>
    / <id> when present and fall back to the article URL otherwise.
    Used as the dedup key by feed pollers."""

    title: str
    author: str | None = None
    published_at: datetime
    fetched_at: datetime
    url: HttpUrl
    canonical_url: HttpUrl | None = None
    summary: str | None = None
    content_html: str | None = None
    content_text: str | None = None
    image_url: HttpUrl | None = None
    language: str | None = None
    """BCP 47 tag, e.g. 'en', 'tr-TR'."""

    categories: list[str] = Field(default_factory=list)
    """Inherits from NewsFeed.categories plus any per-entry tags."""

    raw: dict[str, Any] = Field(default_factory=dict)
