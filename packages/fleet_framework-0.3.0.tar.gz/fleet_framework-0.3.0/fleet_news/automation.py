from __future__ import annotations

from typing import ClassVar

from pydantic import Field

from fleet.core.automation import ContinuousAutomation
from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet_news.contracts import NewsArticle, NewsFeed


class NewsConfig(BaseConfig):
    """Watch a fixed list of feeds and emit articles as they appear.

    `feeds` is part of the config so an admin can add / remove sources
    via `PATCH /api/v1/automations/{type}/workers/{id}/config` and the
    reconcile loop will pick up the change. Plugins should react to the
    feed list changing without restarting the slot."""

    feeds: list[NewsFeed] = Field(default_factory=list)
    poll_interval_seconds: int = Field(default=300, ge=30, le=86400)
    dedup_window_seconds: int = Field(default=86_400, ge=60)
    """How long an article_id is remembered as "already seen" before the
    plugin will emit a re-publish as new. Default 24h."""


class NewsAutomation(ContinuousAutomation[NewsConfig]):
    """Abstract base for a one-slot-per-feed-set polling automation.

    Concrete plugins (`fleet-news-rss`, `fleet-news-google-news`, etc.)
    override `run_slot` to:
      1. For each feed in `ctx.config.feeds`, fetch on a schedule.
      2. Parse entries into `NewsArticle`.
      3. Deduplicate against an in-memory or pool-backed set of
         `article_id`s seen in the last `dedup_window_seconds`.
      4. `await ctx.emit(article)` for each fresh article.

    Designed as continuous because the natural unit of work is "watch a
    set of feeds forever", not "fetch one URL". For "scrape this one
    feed URL right now" use a BatchAutomation instead.
    """

    Config: ClassVar = NewsConfig
    Output: ClassVar = NewsArticle

    async def run_slot(self, ctx: Context) -> None:
        raise NotImplementedError(
            f"{type(self).__name__}.run_slot must be overridden — the "
            "abstract NewsAutomation does not poll any feed.",
        )
