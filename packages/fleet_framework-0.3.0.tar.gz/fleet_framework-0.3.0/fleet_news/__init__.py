"""fleet-news — abstract news / RSS firehose ContinuousAutomation contract.

ContinuousAutomation shape because the natural unit of work is "watch a
set of feeds forever and emit new articles". For "fetch this one feed
URL right now" use fleet-content instead.
"""

from fleet_news.automation import NewsAutomation, NewsConfig
from fleet_news.contracts import (
    NewsArticle,
    NewsFeed,
    NewsSourceKind,
)

__all__ = [
    "NewsArticle",
    "NewsAutomation",
    "NewsConfig",
    "NewsFeed",
    "NewsSourceKind",
]
