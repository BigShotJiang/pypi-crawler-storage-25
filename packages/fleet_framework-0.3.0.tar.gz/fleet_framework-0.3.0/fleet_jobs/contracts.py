from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, HttpUrl, model_validator


class JobSource(str, Enum):
    LINKEDIN = "linkedin"
    INDEED = "indeed"
    GREENHOUSE = "greenhouse"
    LEVER = "lever"
    GLASSDOOR = "glassdoor"
    WORKABLE = "workable"
    ZIPRECRUITER = "ziprecruiter"
    REMOTIVE = "remotive"
    WE_WORK_REMOTELY = "we_work_remotely"
    ASHBY = "ashby"
    SMARTRECRUITERS = "smartrecruiters"
    BAMBOOHR = "bamboohr"
    ANGEL_LIST = "angel_list"
    """A.k.a. Wellfound."""


class EmploymentType(str, Enum):
    FULL_TIME = "full_time"
    PART_TIME = "part_time"
    CONTRACT = "contract"
    INTERNSHIP = "internship"
    TEMPORARY = "temporary"
    VOLUNTEER = "volunteer"
    FREELANCE = "freelance"


class WorkArrangement(str, Enum):
    REMOTE = "remote"
    HYBRID = "hybrid"
    ON_SITE = "on_site"
    UNSPECIFIED = "unspecified"


class SalaryRange(BaseModel):
    min_amount: Decimal | None = None
    max_amount: Decimal | None = None
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    period: Literal["hour", "day", "week", "month", "year"] = "year"

    @model_validator(mode="after")
    def _ordered(self) -> "SalaryRange":
        if (self.min_amount is not None and self.max_amount is not None
                and self.min_amount > self.max_amount):
            raise ValueError("min_amount must be <= max_amount")
        return self


class GeoPoint(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lng: float = Field(ge=-180, le=180)


class JobListing(BaseModel):
    source: JobSource
    job_id: str
    """Stable on the source. LinkedIn job_id, Greenhouse opening_id,
    Lever postings.id, etc. Used as dedup key."""

    url: HttpUrl
    title: str
    company: str
    company_logo_url: HttpUrl | None = None
    location: str | None = None
    """Human-readable city/state/country string. Normalized geo
    (lat/lng) goes in `geo`."""

    geo: GeoPoint | None = None
    posted_at: datetime | None = None
    employment_type: EmploymentType | None = None
    work_arrangement: WorkArrangement = WorkArrangement.UNSPECIFIED
    seniority: str | None = None
    """Free-form. Plugins should normalize when the source publishes
    a fixed taxonomy (LinkedIn does), pass through otherwise."""

    description_html: str | None = None
    description_text: str | None = None
    """Plugins are encouraged to set BOTH when the source publishes
    HTML — consumers that want plain text get it without re-parsing,
    consumers that want HTML get it without losing the structure."""

    requirements: list[str] = Field(default_factory=list)
    benefits: list[str] = Field(default_factory=list)
    salary: SalaryRange | None = None
    apply_url: HttpUrl | None = None
    """If the source publishes a separate apply link (Greenhouse and
    Lever do), populate it. Otherwise leave None — `url` is the
    apply-from-listing path."""

    raw: dict[str, Any] = Field(default_factory=dict)


class JobQueryKind(str, Enum):
    SEARCH = "search"
    DETAILS = "details"
    COMPANY = "company"
    """List all open postings at one company (Greenhouse / Lever
    boards typically scope to one company)."""


class JobQuery(BaseModel):
    source: JobSource
    kind: JobQueryKind = JobQueryKind.SEARCH

    keywords: str | None = None
    location: str | None = None
    remote_only: bool = False
    employment_type: EmploymentType | None = None
    posted_within_days: int | None = Field(default=None, ge=1, le=365)
    job_id: str | None = None
    """Required for kind=DETAILS."""

    company: str | None = None
    """Required for kind=COMPANY (free-text slug or canonical name,
    depending on source)."""

    page: int = Field(default=1, ge=1, le=400)
    limit: int = Field(default=25, ge=1, le=100)

    @model_validator(mode="after")
    def _kind_requires(self) -> "JobQuery":
        if self.kind == JobQueryKind.DETAILS and not self.job_id:
            raise ValueError("kind=details requires `job_id`")
        if self.kind == JobQueryKind.COMPANY and not self.company:
            raise ValueError("kind=company requires `company`")
        return self


class JobResult(BaseModel):
    query: JobQuery
    listings: list[JobListing] = Field(default_factory=list)
    next_page_token: str | None = None
    raw: dict[str, Any] = Field(default_factory=dict)
