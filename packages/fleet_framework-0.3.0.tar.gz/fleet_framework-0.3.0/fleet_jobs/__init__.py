"""fleet-jobs — abstract job-listing automation contract for fleet."""

from fleet_jobs.automation import JobsAutomation, JobsConfig
from fleet_jobs.contracts import (
    EmploymentType,
    GeoPoint,
    JobListing,
    JobQuery,
    JobQueryKind,
    JobResult,
    JobSource,
    SalaryRange,
    WorkArrangement,
)

__all__ = [
    "EmploymentType",
    "GeoPoint",
    "JobListing",
    "JobQuery",
    "JobQueryKind",
    "JobResult",
    "JobSource",
    "JobsAutomation",
    "JobsConfig",
    "SalaryRange",
    "WorkArrangement",
]
