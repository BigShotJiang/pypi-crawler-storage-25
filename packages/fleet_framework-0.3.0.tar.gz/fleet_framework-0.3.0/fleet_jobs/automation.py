from __future__ import annotations

from typing import ClassVar

from fleet.core.automation import BatchAutomation, Task
from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet_jobs.contracts import JobQuery, JobResult


class JobsConfig(BaseConfig):
    default_country: str = "US"


class JobsAutomation(BatchAutomation[JobsConfig]):
    """Abstract base for "one query in, one listing page out" job
    automations.

    Concrete plugins (`fleet-jobs-linkedin`, `-indeed`, `-greenhouse`,
    `-lever`) override `run_one` and dispatch on `task.payload.kind`.
    `JobQueryKind.COMPANY` is the cheap path on ATS boards (Greenhouse /
    Lever publish all company postings under one URL); SEARCH is the
    aggregator path (LinkedIn / Indeed / Glassdoor).
    """

    Config: ClassVar = JobsConfig
    TaskPayload: ClassVar = JobQuery
    Output: ClassVar = JobResult

    async def run_one(self, task: Task, ctx: Context) -> None:
        raise NotImplementedError(
            f"{type(self).__name__}.run_one must be overridden — the "
            "abstract JobsAutomation does not call any job board.",
        )
