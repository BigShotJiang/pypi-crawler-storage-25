from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Literal, Optional

from fleet.core import ProxySession, register_provider, resolve_countries

_ROTATING_PORT = 823


@dataclass
class DataimpulseConfig:
    username: str
    password: str
    host: str = "gw.dataimpulse.com"
    scheme: Literal["http", "socks5"] = "http"
    countries: Optional[str | list[str]] = None
    # inclusive sticky-session port range. dataimpulse exposes 10000-19999.
    sticky_port_range: tuple[int, int] = (10000, 19999)
    # how the sticky port is chosen inside the range:
    #   "random" — random pick on every acquire (default; max IP diversity)
    #   "by_slot_id" — deterministic slot_id % span (same slot always gets same port)
    sticky_port_strategy: Literal["random", "by_slot_id"] = "random"
    # override the rotating port if your account uses a non-default one.
    rotating_port: int = _ROTATING_PORT


@register_provider("dataimpulse")
class DataimpulseProvider:
    def __init__(self, cfg: DataimpulseConfig) -> None:
        self._cfg = cfg

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "DataimpulseProvider":
        # accept list or tuple from JSON for sticky_port_range
        raw = dict(cfg)
        spr = raw.get("sticky_port_range")
        if spr is not None and isinstance(spr, list):
            raw["sticky_port_range"] = tuple(spr)
        return cls(DataimpulseConfig(**raw))

    async def acquire(
        self,
        *,
        slot_id: int,
        sticky: bool = True,
        country: Optional[str | list[str]] = None,
    ) -> ProxySession:
        c = self._cfg
        cc = country if country is not None else c.countries
        codes = resolve_countries(cc)

        # directives are appended to the username with double-underscore.
        # dataimpulse expects lowercase country codes (per their docs).
        username = c.username
        if codes:
            username = f"{username}__cr.{','.join(c.lower() for c in codes)}"

        if sticky:
            lo, hi = c.sticky_port_range
            if hi < lo:
                lo, hi = hi, lo
            if c.sticky_port_strategy == "by_slot_id":
                port = lo + (slot_id % (hi - lo + 1))
            else:
                port = random.randint(lo, hi)
        else:
            port = c.rotating_port

        url = f"{c.scheme}://{username}:{c.password}@{c.host}:{port}"
        return ProxySession(
            url=url,
            metadata={
                "provider": "dataimpulse",
                "scheme": c.scheme,
                "port": port,
                "country": codes,
                "sticky": sticky,
                "slot_id": slot_id,
            },
        )
