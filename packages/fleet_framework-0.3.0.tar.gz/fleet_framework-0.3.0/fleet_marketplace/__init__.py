"""fleet-marketplace — abstract product / marketplace automation contract.

Covers Amazon, eBay, Walmart, Shopify storefronts, AliExpress, Etsy,
Mercado Libre, Rakuten, Target, Best Buy, Home Depot. One contract
because the data shape is the same — title, price, offer, variants,
images, reviews — even though the per-source APIs / scrape paths are
all different.
"""

from fleet_marketplace.automation import MarketplaceAutomation, MarketplaceConfig
from fleet_marketplace.contracts import (
    MarketplaceSource,
    Money,
    Product,
    ProductOffer,
    ProductQuery,
    ProductQueryKind,
    ProductResult,
    ProductVariant,
)

__all__ = [
    "MarketplaceAutomation",
    "MarketplaceConfig",
    "MarketplaceSource",
    "Money",
    "Product",
    "ProductOffer",
    "ProductQuery",
    "ProductQueryKind",
    "ProductResult",
    "ProductVariant",
]
