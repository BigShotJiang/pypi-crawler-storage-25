from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl, model_validator


class MarketplaceSource(str, Enum):
    AMAZON = "amazon"
    EBAY = "ebay"
    WALMART = "walmart"
    SHOPIFY = "shopify"
    """Generic Shopify storefront — concrete plugins typically take the
    store domain as config."""

    ALIEXPRESS = "aliexpress"
    ETSY = "etsy"
    MERCADO_LIBRE = "mercado_libre"
    RAKUTEN = "rakuten"
    TARGET = "target"
    BEST_BUY = "best_buy"
    HOME_DEPOT = "home_depot"


class Money(BaseModel):
    """Decimal price + ISO-4217 currency. Always use Decimal to avoid
    floating-point error accumulating across pricing arithmetic.
    """

    amount: Decimal = Field(ge=0)
    currency: str = Field(min_length=3, max_length=3)


class ProductOffer(BaseModel):
    price: Money
    list_price: Money | None = None
    """Strikethrough / "was" price. None when not on sale."""

    discount_pct: float | None = Field(default=None, ge=0.0, le=100.0)
    in_stock: bool | None = None
    quantity_available: int | None = Field(default=None, ge=0)
    seller_id: str | None = None
    seller_name: str | None = None
    shipping_price: Money | None = None
    eligible_for_prime: bool | None = None
    """Amazon-specific; other sources leave None."""


class ProductVariant(BaseModel):
    variant_id: str
    name: str | None = None
    sku: str | None = None
    attributes: dict[str, str] = Field(default_factory=dict)
    """color / size / style / etc. Free-form; concrete plugins decide
    the key set."""

    offer: ProductOffer | None = None
    images: list[HttpUrl] = Field(default_factory=list)


class Product(BaseModel):
    source: MarketplaceSource
    product_id: str
    """Stable on the source. ASIN for Amazon, item_id for eBay, GTIN +
    seller_id for Walmart, etc."""

    title: str
    url: HttpUrl
    brand: str | None = None
    description: str | None = None
    bullet_points: list[str] = Field(default_factory=list)
    categories: list[str] = Field(default_factory=list)
    """Breadcrumb path, root first. ['Electronics', 'Computers',
    'Laptops']."""

    images: list[HttpUrl] = Field(default_factory=list)
    rating: float | None = Field(default=None, ge=0.0, le=5.0)
    review_count: int | None = Field(default=None, ge=0)
    base_offer: ProductOffer | None = None
    """The default (or only) offer. For multi-variant products the base
    offer is typically the cheapest / first-shown variant."""

    variants: list[ProductVariant] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class ProductQueryKind(str, Enum):
    DETAILS = "details"
    """Look up one product by URL or product_id."""

    SEARCH = "search"
    """Keyword + filters; returns a list of products from one results page."""

    SELLER = "seller"
    """List products from one seller's storefront."""

    CATEGORY = "category"
    """Walk one category page."""


class ProductQuery(BaseModel):
    source: MarketplaceSource
    kind: ProductQueryKind = ProductQueryKind.DETAILS

    url: HttpUrl | None = None
    """For kind=DETAILS, either url or product_id is required."""

    product_id: str | None = None
    query: str | None = None
    """Required for kind=SEARCH."""

    seller_id: str | None = None
    """Required for kind=SELLER."""

    category_id: str | None = None
    """Required for kind=CATEGORY."""

    country: str = "US"
    """ISO-3166-1 alpha-2. Many marketplaces serve different inventory +
    prices per country; this drives the geo routing."""

    currency: str | None = None
    page: int = Field(default=1, ge=1, le=400)
    limit: int = Field(default=20, ge=1, le=100)

    include_reviews: bool = False
    """When True, plugins should fetch and embed the first page of
    reviews in `raw['reviews']`. Off by default because it doubles
    per-product cost."""

    @model_validator(mode="after")
    def _kind_requires(self) -> "ProductQuery":
        k = self.kind
        if k == ProductQueryKind.DETAILS and not (self.url or self.product_id):
            raise ValueError("kind=details requires `url` or `product_id`")
        if k == ProductQueryKind.SEARCH and not self.query:
            raise ValueError("kind=search requires `query`")
        if k == ProductQueryKind.SELLER and not self.seller_id:
            raise ValueError("kind=seller requires `seller_id`")
        if k == ProductQueryKind.CATEGORY and not self.category_id:
            raise ValueError("kind=category requires `category_id`")
        return self


class ProductResult(BaseModel):
    query: ProductQuery
    products: list[Product] = Field(default_factory=list)
    next_page_token: str | None = None
    raw: dict[str, Any] = Field(default_factory=dict)
