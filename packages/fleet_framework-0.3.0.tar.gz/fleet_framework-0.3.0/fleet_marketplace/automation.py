from __future__ import annotations

from typing import ClassVar

from fleet.core.automation import BatchAutomation, Task
from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet_marketplace.contracts import ProductQuery, ProductResult


class MarketplaceConfig(BaseConfig):
    default_country: str = "US"
    default_currency: str | None = None
    include_reviews_by_default: bool = False


class MarketplaceAutomation(BatchAutomation[MarketplaceConfig]):
    """Abstract base for one ProductQuery in -> one ProductResult out.

    Concrete plugins (`fleet-marketplace-amazon`, `-ebay`, `-walmart`,
    `-shopify`) override `run_one` and dispatch on `task.payload.kind`.
    """

    Config: ClassVar = MarketplaceConfig
    TaskPayload: ClassVar = ProductQuery
    Output: ClassVar = ProductResult

    async def run_one(self, task: Task, ctx: Context) -> None:
        raise NotImplementedError(
            f"{type(self).__name__}.run_one must be overridden — the "
            "abstract MarketplaceAutomation does not call any marketplace.",
        )
