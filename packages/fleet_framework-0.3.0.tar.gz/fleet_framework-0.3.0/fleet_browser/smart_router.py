"""Smart per-flow proxy router for browser-based automation.

The problem this solves: residential proxy bandwidth costs $0.50-1.00/GB.
A vanilla Chromium load of a Google SERP through a residential proxy burns
5+ MB per query (Google's own ML model downloads, gstatic CDN assets, JS
bundles). Only the search-result document actually needs the residential
IP — Google's bot-wall scores the document fetch, not its subresources.

How it works: a local mitmproxy subprocess acts as Chromium's proxy. Per-flow
the addon decides:

  - HOST + PATH matches a "paid" rule → forward through the upstream
    residential proxy → captures the IP-reputation signal
  - Otherwise → flow.server_conn.via = None → forward direct → free, doesn't
    affect the SERP fetch
  - Matches a "block" rule → return 204 immediately

In our measurements: 1.31 MB → 0.17 MB paid per Google query. 87% reduction.

ChromiumWorker spins up a SmartRouter automatically when `BrowserConfig.proxy`
is set AND `smart_routing=True` (the default). Per-process subprocess. Stats
(paid/direct/blocked bytes + counts) are written to a temp file and read on
stop, so callers can attribute cost per task.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import signal
import socket
import subprocess
import tempfile
import textwrap
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SmartRule:
    """One routing rule. Fields are AND-ed when both are set.

    `host_match` is matched as a SUFFIX so `google.com` covers www.google.com,
    images.google.com, etc. Use a leading "." for exact subdomain ("google.com"
    matches "google.com" but ".google.com" matches "*.google.com" only).

    `path_prefix` is a literal prefix on the URL path. Empty = match any path.

    `action`:
      - "paid"   → forward through the upstream residential proxy
      - "direct" → forward direct, bypassing the upstream
      - "block"  → drop the request (returns 204; useful for trackers/ads)
    """

    host_match: str
    path_prefix: str = ""
    action: str = "paid"


DEFAULT_RULES: tuple[SmartRule, ...] = (
    # PATH-SCOPED BLOCKS — must come BEFORE the broad google.com paid rule
    # so the first-match-wins resolver picks them up. These are Google's own
    # telemetry beacons / measurement endpoints served from www.google.com:
    #   /gen_204  → fire-and-forget pixel beacons (page views, clicks, timing).
    #              Each call is ~100-500 B but a single SERP load fires 10-20+,
    #              adding up to 2-5 KB of paid wire bytes per query that the
    #              parser doesn't need. Returning 204 keeps Chrome happy.
    #   /log     → similar shape, used for some experiment metrics.
    #   /async/  → speculative-fetch endpoints for related-search / People-Also-
    #              Ask carousels. Optional UI; results don't depend on it.
    SmartRule(host_match="google.com", path_prefix="/gen_204", action="block"),
    SmartRule(host_match="google.com", path_prefix="/log", action="block"),
    SmartRule(host_match="google.com", path_prefix="/async/", action="block"),
    SmartRule(host_match="google.com", path_prefix="/client_204", action="block"),
    # All hosts in a search-engine's CDN family go through the SAME residential
    # IP with the SAME Chrome TLS fingerprint. Routing /search through curl_cffi
    # but letting gstatic / fonts.gstatic / ggpht / googleusercontent fetch
    # direct (Python-ssl JA3, our host IP) is what fires /sorry/ on a fresh
    # Evomi session in <1 s — Google correlates JA3 across the CDN family and
    # sees two "Chromes" from two IPs. Pin every Google-owned subresource host
    # to the same paid path.
    SmartRule(host_match="google.com", action="paid"),
    SmartRule(host_match="gstatic.com", action="paid"),
    SmartRule(host_match="googleusercontent.com", action="paid"),
    SmartRule(host_match="ggpht.com", action="paid"),
    SmartRule(host_match="googleapis.com", action="paid"),
    # Bing, Yahoo, DDG — same logic, scoped to their CDN families.
    SmartRule(host_match="bing.com", action="paid"),
    SmartRule(host_match="bing-com.akamaized.net", action="paid"),
    SmartRule(host_match="yahoo.com", action="paid"),
    SmartRule(host_match="yimg.com", action="paid"),
    SmartRule(host_match="duckduckgo.com", action="paid"),
    SmartRule(host_match="duckassist.duckduckgo.com", action="paid"),
    # Block known-noise endpoints — trackers / ML model downloads / safebrowsing
    # check-ins. Each one returning 204 keeps Chrome happy and saves bandwidth.
    SmartRule(host_match="googletagmanager.com", action="block"),
    SmartRule(host_match="googlesyndication.com", action="block"),
    SmartRule(host_match="googleadservices.com", action="block"),
    SmartRule(host_match="doubleclick.net", action="block"),
    SmartRule(host_match="google-analytics.com", action="block"),
    SmartRule(host_match="optimizationguide-pa.googleapis.com", action="block"),
    SmartRule(host_match="safebrowsing.googleapis.com", action="block"),
    SmartRule(host_match="clientservices.googleapis.com", action="block"),
    SmartRule(host_match="update.googleapis.com", action="block"),
)


@dataclass
class RouterStats:
    paid_bytes: int = 0
    paid_requests: int = 0
    direct_bytes: int = 0
    direct_requests: int = 0
    blocked_requests: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    cache_bytes_saved: int = 0


def _pick_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _is_port_open(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.15)
        try:
            s.connect((host, port))
            return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False


def _find_mitmdump() -> Optional[str]:
    """Locate the mitmdump binary. Returns None if not installed."""
    p = shutil.which("mitmdump")
    if p:
        return p
    # mitmproxy is often pip-installed under the venv's bin
    here = Path(__file__).resolve()
    for candidate in (
        here.parents[2] / ".venv" / "bin" / "mitmdump",
        Path.home() / ".local" / "bin" / "mitmdump",
    ):
        if candidate.exists() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


@dataclass
class SmartRouter:
    """Embedded mitmproxy subprocess that does per-flow upstream routing.

    Lifecycle: start() spawns mitmdump, blocks until its listen port is open;
    stop() sends SIGTERM and reads the stats file. Designed for one router
    per ChromiumWorker — cheap to spin up (~150ms cold start).
    """

    upstream_proxy: str
    """Upstream residential proxy URL with auth: http://user:pass@host:port."""

    rules: tuple[SmartRule, ...] = field(default_factory=lambda: DEFAULT_RULES)
    """Routing rules. First matching rule wins. Default for non-matches: direct."""

    default_action: str = "direct"
    """Action when no rule matches. "direct" = free, "paid" = everything paid."""

    listen_host: str = "127.0.0.1"
    listen_port: int = 0
    """0 = auto-pick free port."""

    impersonate: str = "chrome"
    """curl_cffi impersonation target for the PAID upstream call. This is
    what Google (or whoever) sees on the TLS handshake. "chrome" rolls
    forward to the latest. Without curl_cffi short-circuiting, mitmproxy's
    Python-ssl outbound would expose a non-Chrome JA3 → instant flagging."""

    cache_dir: Optional[str] = None
    """Directory for the content-addressable response cache. Hash-versioned
    URLs (e.g. Google's /xjs/_/js/k=…hash…) are stored here on first fetch
    and served from disk on subsequent requests — cuts ~80% of the paid
    bandwidth on a multi-query run. Defaults to ~/.cache/fleet-smart-router/.
    Set to "" (empty string) to disable caching entirely."""

    cache_url_patterns: tuple[str, ...] = (
        # Substring matches against the full URL. Each pattern names a path
        # shape whose response body is determined by the URL path (not query,
        # not cookies). Cache hit is safe — Google's deploy cycle naturally
        # invalidates entries because the URL hash changes.
        "/xjs/_/",             # Google's JS+CSS bundles (k=… hash in URL)
        "/og/_/",              # Google's OneGoogle JS+CSS
        "/images/branding/",   # Google logo/icon family
        "/images/icons/",      # UI icons (search/clear/voice)
        "/scaffolding/",       # versioned scaffold assets
        "/static/",            # generic Google CDN static path
        "/textinputassistant/",  # autocomplete-related static JS
        "/favicons",           # Google's favicon endpoint (versioned)
    )
    """URL substrings that mark a flow as cacheable. Match → first request
    fetches through Evomi and writes to cache_dir, subsequent requests serve
    from disk."""

    truncate_url_patterns: tuple[tuple[str, int], ...] = (
        # (URL substring, max decompressed body bytes). Streams the response
        # via curl_cffi and closes the connection once the body crosses the
        # cap — Evomi only charges for what crossed the wire before close.
        # Used for Google's /search response: the organic results live in the
        # first ~150 KB of decompressed HTML, but Google ships the full ~500 KB
        # document. Capping at 200 KB decompressed lets the parser still find
        # all 10 organic results while saving ~70 KB of wire bytes per query.
        ("/search?", 200_000),
    )
    """Per-URL streaming caps. The smart router opens a stream, reads up to
    `max_bytes` of (decompressed) body, then closes — Evomi stops billing."""

    _proc: Optional[subprocess.Popen] = field(default=None, repr=False, init=False)
    _stats_path: Optional[Path] = field(default=None, repr=False, init=False)
    _addon_path: Optional[Path] = field(default=None, repr=False, init=False)
    _families: dict = field(default_factory=dict, repr=False, init=False)
    _stats: RouterStats = field(default_factory=RouterStats, init=False)

    @property
    def proxy_url(self) -> str:
        return f"http://{self.listen_host}:{self.listen_port}"

    @property
    def stats(self) -> RouterStats:
        # Live read while the addon is running so callers can snapshot mid-
        # flow without waiting for stop(). After stop(), _stats_path is gone
        # and we return the snapshot captured during cleanup.
        if self._stats_path is not None and self._stats_path.exists():
            try:
                self._read_stats()
            except Exception:
                pass
        return self._stats

    def start(self, *, startup_timeout: float = 10.0) -> None:
        mitmdump = _find_mitmdump()
        if mitmdump is None:
            raise RuntimeError(
                "SmartRouter requires mitmproxy. "
                "Install with: pip install 'fleet-framework[browser]'"
            )
        if self.listen_port == 0:
            self.listen_port = _pick_free_port()

        # Strip auth from upstream URL and pass separately.
        from urllib.parse import urlparse
        u = urlparse(self.upstream_proxy)
        upstream_clean = f"{u.scheme}://{u.hostname}:{u.port or 80}"
        upstream_auth = f"{u.username}:{u.password}" if u.username else None

        # Persist stats to a tmp file the subprocess writes to.
        self._stats_path = Path(tempfile.mktemp(prefix="smart-router-stats-", suffix=".json"))
        # Resolve cache directory. Default: ~/.cache/fleet-smart-router (shared
        # across all router instances, so cache hits accumulate over time).
        if self.cache_dir is None:
            resolved_cache = Path.home() / ".cache" / "fleet-smart-router"
            resolved_cache.mkdir(parents=True, exist_ok=True)
            cache_dir_str = str(resolved_cache)
        elif self.cache_dir == "":
            cache_dir_str = ""
        else:
            Path(self.cache_dir).mkdir(parents=True, exist_ok=True)
            cache_dir_str = str(self.cache_dir)
        # Generate the addon script — embeds the rules so the subprocess has them.
        rules_repr = [asdict(r) for r in self.rules]
        self._addon_path = Path(tempfile.mktemp(prefix="smart-router-addon-", suffix=".py"))
        self._addon_path.write_text(_render_addon_script(
            rules_repr,
            self.default_action,
            str(self._stats_path),
            upstream_url=upstream_clean,
            upstream_auth=upstream_auth,
            impersonate=self.impersonate,
            cache_dir=cache_dir_str,
            cache_url_patterns=list(self.cache_url_patterns),
            truncate_url_patterns=[list(p) for p in self.truncate_url_patterns],
        ))

        cmd = [
            mitmdump,
            "-p", str(self.listen_port),
            "--mode", f"upstream:{upstream_clean}",
            "--set", "ssl_insecure=true",
            "-s", str(self._addon_path),
            "--quiet",
        ]
        if upstream_auth:
            cmd.extend(["--upstream-auth", upstream_auth])

        self._proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
        # Wait for the listen socket.
        deadline = time.monotonic() + startup_timeout
        while time.monotonic() < deadline:
            if _is_port_open(self.listen_host, self.listen_port):
                logger.info(
                    "smart-router @ %s, %d rules, upstream=%s",
                    self.proxy_url, len(self.rules), upstream_clean,
                )
                return
            if self._proc.poll() is not None:
                err = (self._proc.stderr.read() if self._proc.stderr else b"").decode(errors="replace")
                self._cleanup_files()
                raise RuntimeError(f"SmartRouter mitmdump exited early: {err[:400]}")
            time.sleep(0.1)
        self.stop()
        raise RuntimeError(f"SmartRouter failed to start within {startup_timeout}s")

    def stop(self) -> None:
        # Read stats BEFORE killing the process — the addon flushes on every
        # response, so the file is current up to the last completed flow.
        self._read_stats()
        if self._proc is not None:
            try:
                # Term the whole process group; mitmdump spawns helper threads.
                os.killpg(os.getpgid(self._proc.pid), signal.SIGTERM)
            except (ProcessLookupError, PermissionError, OSError):
                pass
            try:
                self._proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(os.getpgid(self._proc.pid), signal.SIGKILL)
                except (ProcessLookupError, OSError):
                    pass
                self._proc.wait(timeout=2)
            self._proc = None
        # Re-read stats one more time in case any flows finished between the
        # first read and the SIGTERM.
        self._read_stats()
        self._cleanup_files()
        logger.info(
            "smart-router stopped. paid=%d B / %d req, blocked=%d, "
            "cache=%d hit / %d miss / %d B saved",
            self._stats.paid_bytes, self._stats.paid_requests,
            self._stats.blocked_requests,
            self._stats.cache_hits, self._stats.cache_misses,
            self._stats.cache_bytes_saved,
        )

    def __enter__(self) -> "SmartRouter":
        self.start()
        return self

    def __exit__(self, *exc) -> None:
        self.stop()

    def _read_stats(self) -> None:
        if self._stats_path is None or not self._stats_path.exists():
            return
        try:
            data = json.loads(self._stats_path.read_text() or "{}")
            self._stats = RouterStats(
                paid_bytes=int(data.get("paid_bytes", 0)),
                paid_requests=int(data.get("paid_requests", 0)),
                direct_bytes=int(data.get("direct_bytes", 0)),
                direct_requests=int(data.get("direct_requests", 0)),
                blocked_requests=int(data.get("blocked_requests", 0)),
                cache_hits=int(data.get("cache_hits", 0)),
                cache_misses=int(data.get("cache_misses", 0)),
                cache_bytes_saved=int(data.get("cache_bytes_saved", 0)),
            )
        except (json.JSONDecodeError, ValueError, OSError):
            logger.debug("smart-router stats file unreadable", exc_info=True)
        fam_path = Path(str(self._stats_path) + ".families")
        if fam_path.exists():
            try:
                self._families = json.loads(fam_path.read_text() or "{}")
            except (json.JSONDecodeError, ValueError, OSError):
                logger.debug(
                    "smart-router families file unreadable", exc_info=True
                )

    @property
    def families(self) -> dict:
        """Per-URL-family paid bandwidth, refreshed from disk every call.
        Returns {family_key: {"bytes": int, "count": int}}. Empty before
        first traffic. Available between start() and stop(); after stop()
        returns whatever was captured at the last _read_stats() call."""
        if self._stats_path is not None and self._stats_path.exists():
            try:
                self._read_stats()
            except Exception:
                pass
        return self._families

    def _cleanup_files(self) -> None:
        for p in (self._stats_path, self._addon_path):
            if p is not None and p.exists():
                try:
                    p.unlink()
                except OSError:
                    pass
        # Side-files the addon writes next to stats_path; nuke them too so
        # /tmp doesn't accumulate stale telemetry across runs.
        if self._stats_path is not None:
            for suffix in (".families", ".errors"):
                side = Path(str(self._stats_path) + suffix)
                if side.exists():
                    try:
                        side.unlink()
                    except OSError:
                        pass


def _render_addon_script(
    rules: list[dict],
    default_action: str,
    stats_path: str,
    upstream_url: str,
    upstream_auth: Optional[str],
    impersonate: str,
    cache_dir: str = "",
    cache_url_patterns: Optional[list[str]] = None,
    truncate_url_patterns: Optional[list[list]] = None,
) -> str:
    """Generate the mitmproxy addon script. Embeds the rules as a literal so
    the subprocess has them at startup without a separate config file.

    Design: mitm terminates TLS for every flow (the browser trusts mitm's CA
    via Playwright's ignore_https_errors). For each request, the addon picks
    an action:
      - "paid": fetch upstream via curl_cffi(impersonate='chrome') through the
        residential proxy, substitute the response back into the flow. The
        target sees Chrome's real JA3/JA4/HTTP2 fingerprint regardless of
        what the actual browser engine is — this is what makes cloak's
        Chromium work behind a smart router (mitm's TLS passthrough closes
        cloak's clienthello, but full intercept-and-substitute is fine).
      - "direct": return 502 — direct flows are out of scope for this router.
        Callers wanting "direct" should bypass the router entirely.
      - "block": return 204 immediately."""
    return textwrap.dedent(f"""
        import hashlib
        import json
        import pickle
        import re
        from mitmproxy import http
        from pathlib import Path

        RULES = {json.dumps(rules)}
        DEFAULT_ACTION = {default_action!r}
        STATS_PATH = {stats_path!r}
        UPSTREAM_URL = {upstream_url!r}
        UPSTREAM_AUTH = {upstream_auth!r}
        IMPERSONATE = {impersonate!r}
        CACHE_DIR = {cache_dir!r}
        CACHE_URL_PATTERNS = {json.dumps(cache_url_patterns or [])}
        TRUNCATE_URL_PATTERNS = {json.dumps(truncate_url_patterns or [])}

        # URL-key normalisation rules: each (regex, replacement) collapses a
        # session-variant tail to its content-hash portion so two distinct
        # session URLs map to the same cache entry. The /xjs/ and /og/_/
        # families are the big bandwidth eaters — Google embeds per-session
        # active-module bitmaps + timestamps after the content hash, so
        # without normalisation every page caches a near-identical 1.4 MB JS
        # blob under a different key.
        _CACHE_KEY_RULES = [
            # Google /xjs/_/js/k=HASH/... and /og/_/js/k=HASH/...
            # Generalised: /<family>/_/<subtype>/k=<content-hash>/<session-tail>
            (re.compile(r'(/[a-z_]+/_/[a-z]+/k=[^/]+).*$'), r'\\1'),
        ]

        try:
            from curl_cffi.requests import Session as _CurlSession
            _CURL_OK = True
        except ImportError:
            _CURL_OK = False

        # Single persistent curl_cffi Session reused across every paid flow.
        # Each Session keeps its own connection pool — HTTP/2 multiplexing,
        # keep-alive, shared cookies — which is what real Chrome looks like to
        # Google's anti-bot. A Session-per-request opens a fresh TLS handshake
        # for every subresource, and the resulting flood of CONNECTs from one
        # Evomi IP is itself the bot signal that fires /sorry/.
        _SESSION = _CurlSession(impersonate=IMPERSONATE) if _CURL_OK else None

        _stats = {{
            "paid_bytes": 0, "paid_requests": 0,
            "direct_bytes": 0, "direct_requests": 0,
            "blocked_requests": 0,
            "cache_hits": 0, "cache_misses": 0,
            "cache_bytes_saved": 0,
        }}

        # Per-URL-family paid-bandwidth accounting. Key = (host, family) where
        # family is the URL path collapsed to its first 2 segments (so
        # /xjs/_/js/k=.../m=... collapses to "/xjs/_") so we can see at a
        # glance which families are eating budget on cold cache.
        _PER_FAMILY = {{}}  # family_str -> {{"bytes": int, "count": int}}

        def _url_family(host, path):
            # Take the first two path segments (after leading /) so deep
            # session-variant tails don't fragment the family stats.
            parts = [p for p in path.split("?", 1)[0].split("/") if p]
            head = "/".join(parts[:2]) if parts else "/"
            return host + "/" + head

        # In-memory cache of (status, content, headers_bytes) by URL hash.
        # Hot cache for the addon process; cold cache is disk under CACHE_DIR.
        _MEM_CACHE = {{}}
        _MEM_CACHE_MAX = 128  # LRU-ish bound

        def _is_cacheable(method, url):
            if method != "GET" or not CACHE_DIR or not CACHE_URL_PATTERNS:
                return False
            for pat in CACHE_URL_PATTERNS:
                if pat in url:
                    return True
            return False

        def _cache_key(url):
            # Drop query string — same content is served regardless of
            # session-state params (timestamp, sei, etc.).
            base = url.split("?", 1)[0]
            # Apply URL-shape collapsing rules (mostly for /xjs/).
            for pat, repl in _CACHE_KEY_RULES:
                base = pat.sub(repl, base)
            return base

        def _cache_path(url):
            key = _cache_key(url)
            h = hashlib.sha256(key.encode("utf-8")).hexdigest()
            return Path(CACHE_DIR) / h[:2] / (h + ".bin")

        def _cache_get(url):
            key = _cache_key(url)
            if key in _MEM_CACHE:
                return _MEM_CACHE[key]
            p = _cache_path(url)
            if not p.exists():
                return None
            try:
                with open(p, "rb") as f:
                    entry = pickle.load(f)
                if len(_MEM_CACHE) < _MEM_CACHE_MAX:
                    _MEM_CACHE[key] = entry
                return entry
            except (OSError, pickle.PickleError):
                return None

        def _cache_put(url, status, content, headers_bytes):
            key = _cache_key(url)
            entry = (status, content, headers_bytes)
            _MEM_CACHE[key] = entry
            if len(_MEM_CACHE) > _MEM_CACHE_MAX:
                _MEM_CACHE.pop(next(iter(_MEM_CACHE)), None)
            p = _cache_path(url)
            try:
                p.parent.mkdir(parents=True, exist_ok=True)
                with open(p, "wb") as f:
                    pickle.dump(entry, f)
            except OSError:
                pass

        def _host_matches(host, pattern):
            return host == pattern or host.endswith("." + pattern) or host.endswith(pattern)

        def _pick_action(host, path):
            for r in RULES:
                if not _host_matches(host, r["host_match"]):
                    continue
                if r["path_prefix"] and not path.startswith(r["path_prefix"]):
                    continue
                return r["action"]
            return DEFAULT_ACTION

        def _persist():
            try:
                Path(STATS_PATH).write_text(json.dumps(_stats))
            except OSError:
                pass
            try:
                Path(STATS_PATH + ".families").write_text(
                    json.dumps(_PER_FAMILY, sort_keys=True)
                )
            except OSError:
                pass

        def _account_paid(host, path, wire_bytes):
            fam = _url_family(host, path)
            slot = _PER_FAMILY.get(fam)
            if slot is None:
                slot = {{"bytes": 0, "count": 0}}
                _PER_FAMILY[fam] = slot
            slot["bytes"] += int(wire_bytes)
            slot["count"] += 1

        def _proxy_for_curl():
            scheme, _, rest = UPSTREAM_URL.partition("://")
            if not UPSTREAM_AUTH:
                return UPSTREAM_URL
            return f"{{scheme}}://{{UPSTREAM_AUTH}}@{{rest}}"

        # Headers from the real browser that we DO want forwarded — cookies,
        # locale, referer, anything that carries session/state. The rest
        # (sec-ch-ua, sec-fetch-*, accept-encoding, user-agent) is generated
        # by curl_cffi's chrome profile so the on-wire fingerprint is coherent.
        _FORWARD_HEADERS = (
            "cookie", "referer", "accept-language", "origin",
            "x-client-data", "x-goog-visitor-id", "authorization",
        )

        def _select_headers(src):
            out = {{}}
            for k, v in src.items():
                if k.lower() in _FORWARD_HEADERS:
                    out[k] = v
            return out

        # Hop-by-hop headers mitm will re-add when it serialises the
        # substituted response. Stripping them out avoids double-encoding.
        _HOP_HEADERS = frozenset({{
            "transfer-encoding", "connection", "keep-alive",
            "upgrade", "proxy-connection", "content-encoding",
        }})

        def _truncate_cap(url):
            for pat, cap in TRUNCATE_URL_PATTERNS:
                if pat in url:
                    return int(cap)
            return 0

        def _via_curl_cffi(flow):
            url = flow.request.pretty_url
            method = flow.request.method
            req_host = flow.request.pretty_host
            req_path = flow.request.path
            # Cache check: content-addressable static assets (e.g. Google's
            # /xjs/_/js/ bundles) are immutable per URL hash — serve from disk
            # cache when available, save the residential round-trip entirely.
            if _is_cacheable(method, url):
                entry = _cache_get(url)
                if entry is not None:
                    status, content, headers_bytes = entry
                    flow.response = http.Response.make(
                        status, content, headers_bytes,
                    )
                    _stats["cache_hits"] += 1
                    # Saved bytes ≈ what download_size would have been. We
                    # don't have that on a hit, so estimate from content size
                    # scaled down by typical text Brotli ratio (~0.25).
                    _stats["cache_bytes_saved"] += int(len(content or b"") * 0.25)
                    _persist()
                    return True
                _stats["cache_misses"] += 1

            # Stream-and-close path: for URLs we've capped, open a streaming
            # request, read up to `cap` bytes of decompressed body, close. Evomi
            # stops billing the moment we close the TCP stream — a 500 KB SERP
            # caps at ~200 KB decompressed (~50 KB wire) without losing the
            # organic results which live at the top of the document.
            cap = _truncate_cap(url)
            if cap and method == "GET":
                try:
                    rs = _SESSION.request(
                        method=method, url=url,
                        headers=_select_headers(flow.request.headers),
                        proxies={{"http": _proxy_for_curl(), "https": _proxy_for_curl()}},
                        allow_redirects=False,
                        timeout=30,
                        stream=True,
                    )
                    chunks = []
                    total = 0
                    truncated = False
                    for chunk in rs.iter_content(chunk_size=8192):
                        if not chunk:
                            continue
                        chunks.append(chunk)
                        total += len(chunk)
                        if total >= cap:
                            truncated = True
                            break
                    try:
                        rs.close()
                    except Exception:
                        pass
                    body = b"".join(chunks)
                    out_headers = []
                    for k, v in rs.headers.items():
                        lk = k.lower()
                        # curl_cffi already decompressed, so strip the encoding
                        # header AND content-length (we set our own).
                        if lk in _HOP_HEADERS or lk in ("content-encoding", "content-length"):
                            continue
                        kk = k.encode("latin-1", "ignore") if isinstance(k, str) else k
                        vv = v.encode("latin-1", "ignore") if isinstance(v, str) else v
                        out_headers.append((kk, vv))
                    out_headers.append((b"content-length", str(len(body)).encode()))
                    if truncated:
                        out_headers.append((b"x-smart-router-truncated", b"1"))
                    flow.response = http.Response.make(
                        rs.status_code, body, out_headers,
                    )
                    _stats["paid_requests"] += 1
                    wire = int(getattr(rs, "download_size", 0) or 0) + \
                           int(getattr(rs, "upload_size", 0) or 0) + \
                           int(getattr(rs, "header_size", 0) or 0) + \
                           int(getattr(rs, "request_size", 0) or 0)
                    # download_size on a closed stream reports bytes received
                    # before close — exactly what we want for paid_bytes.
                    if wire == 0:
                        wire = total
                    _stats["paid_bytes"] += wire
                    _account_paid(req_host, req_path, wire)
                    _persist()
                    return True
                except Exception as e:
                    try:
                        Path(STATS_PATH + ".errors").write_text(repr(e)[:300])
                    except OSError:
                        pass
                    # Fall through to non-streaming path on failure

            try:
                r = _SESSION.request(
                    method=method,
                    url=url,
                    headers=_select_headers(flow.request.headers),
                    data=flow.request.raw_content or None,
                    proxies={{"http": _proxy_for_curl(), "https": _proxy_for_curl()}},
                    allow_redirects=False,
                    timeout=30,
                )
                if r is None:
                    raise RuntimeError("curl_cffi returned None")
                out_headers = []
                for k, v in r.headers.items():
                    if k.lower() in _HOP_HEADERS:
                        continue
                    kk = k.encode("latin-1", "ignore") if isinstance(k, str) else k
                    vv = v.encode("latin-1", "ignore") if isinstance(v, str) else v
                    out_headers.append((kk, vv))
                flow.response = http.Response.make(
                    r.status_code, r.content, out_headers,
                )
                _stats["paid_requests"] += 1
                # True wire bytes: curl_cffi's download_size is the compressed
                # body Evomi actually delivered (br/gzip), upload_size is what
                # we sent. len(r.content) would overstate by 2-4× because Google
                # serves with Brotli. Fall back to decompressed length if curl
                # didn't populate the size fields.
                wire = int(getattr(r, "download_size", 0) or 0)
                wire += int(getattr(r, "upload_size", 0) or 0)
                wire += int(getattr(r, "header_size", 0) or 0)
                wire += int(getattr(r, "request_size", 0) or 0)
                if wire == 0:
                    wire = len(r.content or b"")
                _stats["paid_bytes"] += wire
                _account_paid(req_host, req_path, wire)
                # Cache 2xx responses for content-addressable URLs.
                if (
                    _is_cacheable(method, url)
                    and 200 <= r.status_code < 300
                    and r.content
                ):
                    _cache_put(url, r.status_code, r.content, out_headers)
                _persist()
                return True
            except Exception as e:
                try:
                    Path(STATS_PATH + ".errors").write_text(repr(e)[:300])
                except OSError:
                    pass
                flow.response = http.Response.make(
                    502, f"smart-router upstream error: {{e!r}}".encode(),
                    {{"x-smart-router": "upstream-error"}},
                )
                return False

        def request(flow):
            host = flow.request.pretty_host
            path = flow.request.path
            action = _pick_action(host, path)
            flow.metadata["smart_action"] = action
            if action == "block":
                _stats["blocked_requests"] += 1
                flow.response = http.Response.make(
                    204, b"", {{"x-smart-router": "blocked"}}
                )
                _persist()
                return
            if action == "paid":
                if not _CURL_OK:
                    flow.response = http.Response.make(
                        502, b"smart-router: curl_cffi not installed",
                        {{"x-smart-router": "no-curl"}},
                    )
                    return
                _via_curl_cffi(flow)
                return
            # action == "direct": let mitm forward via its native upstream stack,
            # but skip the residential upstream for this flow (saves bandwidth
            # AND saves Google from correlating a non-residential subresource
            # against the residential /search fetch — wait, no, we WANT all
            # google.com subresources to look like they came from the same
            # session as /search, but gstatic/fonts/etc. go to a different
            # CDN host so they're naturally separated). The trick: gstatic
            # doesn't fingerprint TLS, so mitm's Python-ssl JA3 is fine here.
            # Critically, do NOT 502 these — Chrome's failure to load gstatic
            # subresources is a huge bot signal that fires /sorry/ on the
            # next /search request.
            try:
                flow.server_conn.via = None
            except Exception:
                pass
    """).strip()


__all__ = [
    "DEFAULT_RULES",
    "RouterStats",
    "SmartRouter",
    "SmartRule",
]
