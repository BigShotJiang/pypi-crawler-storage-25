from __future__ import annotations

import json
import platform as _platform
import random
import re
from dataclasses import dataclass
from typing import Iterable

# uaforge is an optional dep — the PyPI package of the same name is unrelated.
# Install from source if you want FingerprintFactory:
#   pip install git+https://github.com/sarperavci/uaforge.git
try:
    from uaforge.core.generator import (
        ClientHintsGenerator,
        UserAgentGenerator,
        VersionExpander,
    )
    from uaforge.models.enums import BrowserFamily, DeviceType, OSType
    from uaforge.models.objects import UserAgentData
    _UAFORGE_AVAILABLE = True
except ImportError:
    _UAFORGE_AVAILABLE = False
    ClientHintsGenerator = UserAgentGenerator = VersionExpander = None  # type: ignore[assignment]
    UserAgentData = None  # type: ignore[assignment]

    class _MissingEnum:
        WINDOWS = "windows"
        MACOS = "macos"
        LINUX = "linux"
        CHROME_OS = "chrome_os"
        CHROME = "chrome"
        DESKTOP = "desktop"

    BrowserFamily = DeviceType = OSType = _MissingEnum  # type: ignore[assignment,misc]

# Realistic Windows desktop spreads. Sampled per fingerprint for diversity.
_HARDWARE_CONCURRENCY_CHOICES = (4, 6, 8)
_DEVICE_MEMORY_CHOICES = (4, 8, 8, 8, 16, 16, 32)

# Default language priority. Most farms target English-speaking sites; expose
# this as a constructor option if needed.
_DEFAULT_LANGUAGES = ("en-US", "en")


# UAForge returns ch_brands like:
#   "Not A Brand";v="99", "Chromium";v="145", "Google Chrome";v="145"
_BRAND_RE = re.compile(r'"([^"]+)";v="([^"]+)"')


def _parse_brands(s: str) -> list[tuple[str, str]]:
    return [(m.group(1), m.group(2)) for m in _BRAND_RE.finditer(s or "")]


def _pick(choices, rng: random.Random) -> int:
    if isinstance(choices, (tuple, list)):
        return rng.choice(choices) if choices else 0
    return choices


# UAForge's ch_platform → navigator.platform.
_PLATFORM_BY_OS = {
    OSType.WINDOWS: "Win32",
    OSType.MACOS: "MacIntel",
    OSType.LINUX: "Linux x86_64",
    OSType.CHROME_OS: "Linux x86_64",
}

# UAForge's ch_platform → CDP userAgentMetadata.platform (capitalization
# matters: CDP expects "Windows", "macOS", "Linux").
_CDP_PLATFORM_BY_OS = {
    OSType.WINDOWS: "Windows",
    OSType.MACOS: "macOS",
    OSType.LINUX: "Linux",
    OSType.CHROME_OS: "Chrome OS",
}


@dataclass(frozen=True)
class Fingerprint:

    user_agent: str
    brands: tuple[tuple[str, str], ...]
    """Low-entropy brand list, e.g. (('Chromium', '145'), ('Google Chrome', '145'))."""
    full_version_list: tuple[tuple[str, str], ...]
    """High-entropy brand list with full versions."""
    full_version: str
    """e.g. '145.0.7632.161'."""

    os_family: str  # "windows" | "macos" | "linux"
    cdp_platform: str  # "Windows" | "macOS" | "Linux"  (CDP capitalization)
    platform: str  # navigator.platform value
    platform_version: str  # e.g. "10.0.0"
    architecture: str  # "x86" | "arm"
    bitness: str  # "32" | "64"
    is_mobile: bool
    model: str
    device_type: str  # "desktop" | "mobile" | "tablet"
    browser_family: str  # "chrome" | "edge"

    languages: tuple[str, ...] = _DEFAULT_LANGUAGES
    hardware_concurrency: int = 8
    device_memory: int = 8

    def to_cdp_user_agent_metadata(self) -> dict:
        return {
            "brands": [{"brand": b, "version": v} for b, v in self.brands],
            "fullVersionList": [{"brand": b, "version": v} for b, v in self.full_version_list],
            "fullVersion": self.full_version,
            "platform": self.cdp_platform,
            "platformVersion": self.platform_version,
            "architecture": self.architecture,
            "bitness": self.bitness,
            "wow64": False,
            "model": self.model,
            "mobile": self.is_mobile,
        }

    def to_extra_http_headers(self) -> dict[str, str]:
        brand_str = ", ".join(f'"{b}";v="{v}"' for b, v in self.brands)
        full_brand_str = ", ".join(
            f'"{b}";v="{v}"' for b, v in self.full_version_list
        )
        return {
            "Sec-CH-UA": brand_str,
            "Sec-CH-UA-Mobile": "?1" if self.is_mobile else "?0",
            "Sec-CH-UA-Platform": f'"{self.cdp_platform}"',
            "Sec-CH-UA-Platform-Version": f'"{self.platform_version}"',
            "Sec-CH-UA-Full-Version-List": full_brand_str,
            "Sec-CH-UA-Full-Version": f'"{self.full_version}"',
            "Sec-CH-UA-Arch": f'"{self.architecture}"',
            "Sec-CH-UA-Bitness": f'"{self.bitness}"',
            "Sec-CH-UA-Model": f'"{self.model}"',
        }

    def navigator_overrides_js(self) -> str:
        languages = json.dumps(list(self.languages))
        return (
            "(function(){\n"
            "  const _d = Object.defineProperty;\n"
            "  const proto = Navigator.prototype;\n"
            f"  _d(proto, 'platform', {{get: () => {json.dumps(self.platform)}, configurable: true}});\n"
            f"  _d(proto, 'languages', {{get: () => Object.freeze({languages}), configurable: true}});\n"
            f"  _d(proto, 'language', {{get: () => {json.dumps(self.languages[0])}, configurable: true}});\n"
            f"  _d(proto, 'hardwareConcurrency', {{get: () => {self.hardware_concurrency}, configurable: true}});\n"
            f"  _d(proto, 'deviceMemory', {{get: () => {self.device_memory}, configurable: true}});\n"
            "})();"
        )



# Chrome only — Edge fingerprints are inconsistent in UAForge's corpus
# (mismatched UA / brand / Sec-CH-UA-Full-Version pairs).
_CHROMIUM_FAMILIES = {BrowserFamily.CHROME}


def _detect_host_os() -> str:
    p = _platform.system().lower()
    if p == "darwin":
        return "macos"
    if p == "windows":
        return "windows"
    return "linux"


class FingerprintFactory:

    def __init__(
        self,
        *,
        seed: int | None = None,
        min_chromium_version: int = 140,
        allowed_os: Iterable[str] | None = None,
    ) -> None:
        if not _UAFORGE_AVAILABLE:
            raise ImportError(
                "FingerprintFactory requires the 'uaforge' package "
                "(not the unrelated PyPI uaforge — the one at "
                "github.com/sarperavci/uaforge). Install with: "
                "pip install git+https://github.com/sarperavci/uaforge.git"
            )
        if allowed_os is None:
            # Default to Windows regardless of host. The host's actual OS
            # is irrelevant — what matters is which UA + client-hint corpus
            # the fleet's fingerprints are drawn from. Windows is the highest-
            # entropy population (~70% of real browsing traffic) and matches
            # the cloak engine's `--fingerprint-platform=windows` default.
            allowed_os = ("windows",)
        self._gen = UserAgentGenerator(seed=seed)
        self._rng = random.Random(seed)
        self._min_chromium = min_chromium_version

        os_lookup = {
            "windows": OSType.WINDOWS,
            "macos": OSType.MACOS,
            "linux": OSType.LINUX,
            "chrome_os": OSType.CHROME_OS,
        }
        # tuple (deterministic order) so seeded picks are reproducible.
        self._allowed_os = tuple(os_lookup[name] for name in allowed_os)

    def next(self) -> Fingerprint:
        os_type = self._rng.choice(self._allowed_os)
        candidate = self._pick_candidate()
        data = self._build_user_agent_data(candidate, os_type)
        return self._from_uaforge(data)

    def _pick_candidate(self):
        if not hasattr(self, "_chrome_desktop_candidates"):
            self._chrome_desktop_candidates = [
                c for c in self._gen.loader.candidates
                if c.family == BrowserFamily.CHROME
                and c.device_type == DeviceType.DESKTOP
                and self._gen._candidate_chromium_version(c) >= self._min_chromium
            ]
            if not self._chrome_desktop_candidates:
                raise RuntimeError(
                    f"UAForge has no Chrome desktop candidates >= chromium "
                    f"{self._min_chromium}"
                )
        return self._rng.choice(self._chrome_desktop_candidates)

    def _resolve_os_targeted(self, os_type: OSType) -> dict:
        os_key = os_type.value
        # Find platform_header from UAForge's own choices table for this OS.
        cache_key = ("chrome", "desktop_weights")
        cached = self._gen._os_choice_cache.get(cache_key, {})
        platform_header = next(
            (c["platform"] for c in cached.get("choices", []) if c["os"] == os_key),
            os_key.capitalize(),
        )

        templates = self._gen.loader.get_os_template(os_key)
        if not templates:
            raise RuntimeError(f"No OS templates for {os_key!r}")
        tpl = self._rng.choice(templates)
        ua_token = tpl["ua_token"]

        if "platform_version" in tpl:
            pv = tpl["platform_version"]
        elif os_key == "linux":
            pv = f"{self._rng.randint(5, 6)}.{self._rng.randint(4, 19)}.0"
        elif os_key == "macos":
            pv = f"{self._rng.randint(13, 14)}.{self._rng.randint(0, 6)}.0"
        else:
            pv = "10.0.0"

        return {
            "type": os_type,
            "platform_header": platform_header,
            "ua_token": ua_token,
            "platform_version": pv,
        }

    def _build_user_agent_data(self, candidate, os_type: OSType) -> UserAgentData:
        rand = self._rng
        loader = self._gen.loader
        os_data = self._resolve_os_targeted(os_type)
        platform = self._gen._map_os_to_platform(os_data["type"])

        full_version = VersionExpander.generate_full_version(
            candidate.family, candidate.version,
            rand=rand, platform=platform, loader=loader,
        )
        major_version = full_version.split(".", 1)[0]
        full_version_flattened = major_version + ".0.0.0"

        # UA string
        # Use the metadata template UAForge cached for this candidate.
        idx = loader.candidates.index(candidate)
        metadata = self._gen._ua_metadata[idx]
        ua_string = self._gen._build_ua_string(
            metadata["family"], metadata["device"],
            os_data["ua_token"], full_version_flattened,
            metadata["version"],
        )

        # Client Hints
        brands = ClientHintsGenerator.generate_brands(
            candidate.family, candidate.version, rand=rand,
        )
        full_version_list = ClientHintsGenerator.generate_full_version_list(
            candidate.family, full_version, rand=rand, loader=loader,
        )
        full_version_hint = ClientHintsGenerator.generate_full_version(
            candidate.family, full_version,
        )

        return UserAgentData(
            user_agent=ua_string,
            ch_brands=brands,
            ch_full_version_list=full_version_list,
            ch_mobile=ClientHintsGenerator.get_mobile_token(False),
            ch_platform=os_data["platform_header"],
            ch_platform_version=os_data["platform_version"],
            ch_model="",
            ch_arch="x86",
            ch_bitness="64",
            ch_full_version=full_version_hint,
            ch_form_factors=ClientHintsGenerator.generate_form_factors(
                DeviceType.DESKTOP, rand=rand,
            ),
            ch_wow64=ClientHintsGenerator.get_wow64_token(False),
            ch_prefers_color_scheme=ClientHintsGenerator.get_prefers_color_scheme(
                rand=rand,
            ),
            meta_os=os_data["type"],
            meta_browser=candidate.family,
            meta_device=DeviceType.DESKTOP,
        )

    def _from_uaforge(self, d: UserAgentData) -> Fingerprint:
        os_type = d.meta_os
        return Fingerprint(
            user_agent=d.user_agent,
            brands=tuple(_parse_brands(d.ch_brands)),
            full_version_list=tuple(_parse_brands(d.ch_full_version_list)),
            full_version=d.ch_full_version,
            os_family=os_type.value,
            cdp_platform=_CDP_PLATFORM_BY_OS[os_type],
            platform=_PLATFORM_BY_OS[os_type],
            platform_version=d.ch_platform_version,
            architecture=d.ch_arch,
            bitness=d.ch_bitness,
            is_mobile=(d.ch_mobile == "?1"),
            model=d.ch_model or "",
            device_type=d.meta_device.value,
            browser_family=d.meta_browser.value,
            languages=_DEFAULT_LANGUAGES,
            hardware_concurrency=_pick(_HARDWARE_CONCURRENCY_CHOICES, self._rng),
            device_memory=_pick(_DEVICE_MEMORY_CHOICES, self._rng),
        )
