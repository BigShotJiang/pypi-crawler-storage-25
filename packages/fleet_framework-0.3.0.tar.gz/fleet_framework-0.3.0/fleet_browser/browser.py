"""Async Chromium worker backed by cloakbrowser (Playwright + patched binary).

DrissionPage's CDP version handshake breaks on Chromium 144+ — the version
string parses to empty, page.html returns 0, and --load-extension is silently
ignored. The replacement uses cloakbrowser.launch_async (which wraps Playwright
and ships a patched Chromium 146) for the cloak engine, and falls back to
plain Playwright for the chrome engine when callers want a stock browser.

Worker.start() returns a Playwright Page. All callers are async-first.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional

from fleet_browser.cloak import cloak_available, resolve_engine
from fleet_browser.display import ensure_virtual_display
from fleet_browser.smart_router import DEFAULT_RULES, SmartRouter, SmartRule
from fleet_browser.stealth import Stealth

if TYPE_CHECKING:
    from playwright.async_api import Browser, BrowserContext, Page

logger = logging.getLogger(__name__)


@dataclass
class BrowserConfig:
    page_url: str
    """URL the worker will navigate to. Reserved for compatibility; callers
    drive navigation via the returned Page directly."""

    proxy: Optional[str] = None
    """Proxy URL: http://host:port or http://user:pass@host:port. Playwright
    parses out the credentials automatically — no auth extension needed."""

    proxy_bypass: tuple[str, ...] = ()
    """Hostnames that should NOT go through the proxy (semicolon-joined into
    Playwright's `bypass=`). localhost / 127.0.0.1 are always bypassed."""

    user_agent: Optional[str] = None
    """Override the UA string. `stealth.launch_user_agent()` wins if non-None."""

    stealth: Optional[Stealth] = None
    """Pluggable browser hardening (async hook — see fleet_browser.stealth)."""

    headless: bool = True
    """Run headless? Cloak's binary supports new-headless; for stock chrome,
    headed-via-Xvfb is recommended for max signal stability."""

    engine: str = "auto"
    """`"auto"` resolves to `"cloak"` when cloakbrowser is installed (it is, by
    default). `"chrome"` forces stock Playwright Chromium. `"cloak"` requires
    the cloakbrowser package — raises otherwise."""

    cloak_platform: str = "windows"
    cloak_timezone: Optional[str] = None
    cloak_webrtc_ip: Optional[str] = None
    cloak_fingerprint_seed: Optional[int] = None
    """Cloak knobs — forwarded to cloakbrowser.launch_async when engine=cloak."""

    extra_args: tuple[str, ...] = ()
    """Additional Chromium launch flags."""

    ignore_cert_errors: bool = False
    """--ignore-certificate-errors. Needed only when terminating TLS at a
    self-signed local proxy you don't have a CA cert for."""

    host_resolver_rules: Optional[str] = None
    """Chromium --host-resolver-rules. e.g. `MAP example.com 127.0.0.1`."""

    smart_routing: bool = True
    """When True AND `proxy` is set, spawn a local SmartRouter and point
    Chromium at THAT instead of the upstream — per-flow paid/direct/block.
    Auto-disables for engine=cloak (mitm passthrough can't tunnel cloak's
    modern TLS clienthello)."""

    smart_routing_rules: tuple[SmartRule, ...] = DEFAULT_RULES


class ChromiumWorker:
    """Async lifecycle wrapper around a Playwright Browser+Context+Page.

    Use either:
        worker = ChromiumWorker(cfg)
        page = await worker.start()
        ...
        await worker.stop()

    or `async with slot(...)` from fleet_browser.pool.
    """

    def __init__(self, config: BrowserConfig) -> None:
        self.config = config
        self._playwright = None
        self._browser: Optional["Browser"] = None
        self._context: Optional["BrowserContext"] = None
        self.page: Optional["Page"] = None
        self._smart_router: Optional[SmartRouter] = None

    @property
    def smart_router(self) -> Optional[SmartRouter]:
        return self._smart_router

    async def start(self) -> "Page":
        if self.page is not None:
            return self.page

        engine = resolve_engine(self.config.engine)
        if engine == "cloak" and not cloak_available():
            raise RuntimeError(
                "engine='cloak' requires cloakbrowser. "
                "Install with: pip install fleet-framework[browser]"
            )

        # Auto-start a managed Xvfb if no display is configured. Stays a no-op
        # when the caller has already exported DISPLAY=:N (e.g. CI sets up
        # Xvfb manually) — see fleet_browser.display.ensure_virtual_display.
        ensure_virtual_display()

        # Smart router: spin up mitm in front of the upstream. The new design
        # (curl_cffi outbound, full TLS intercept) is compatible with every
        # engine — the browser trusts mitm's self-signed cert via the
        # ignore_https_errors flag we set on the context below.
        effective_proxy = self.config.proxy
        if self.config.proxy and self.config.smart_routing:
            try:
                self._smart_router = SmartRouter(
                    upstream_proxy=self.config.proxy,
                    rules=self.config.smart_routing_rules,
                )
                self._smart_router.start()
                effective_proxy = self._smart_router.proxy_url
            except Exception:
                logger.exception(
                    "smart-router failed to start; falling back to upstream proxy"
                )
                self._smart_router = None

        proxy_settings = _build_proxy_settings(effective_proxy, self.config.proxy_bypass)
        # Browser must trust mitm's CA when smart_routing is on; otherwise
        # every CONNECT-then-TLS handshake errors with bad cert.
        ignore_https = self.config.ignore_cert_errors or self._smart_router is not None

        chromium_args = _build_chromium_args(self.config, engine)

        launch_ua = (
            self.config.stealth.launch_user_agent() if self.config.stealth
            else None
        ) or self.config.user_agent

        if engine == "cloak":
            from cloakbrowser import launch_async

            # cloakbrowser auto-applies the stealth args; we just pass extras.
            self._browser = await launch_async(
                headless=self.config.headless,
                proxy=proxy_settings,
                args=list(chromium_args) or None,
                stealth_args=True,
                timezone=self.config.cloak_timezone,
                # cloakbrowser handles --fingerprint=NNN seed internally; we
                # forward the optional override.
                **({"fingerprint_seed": self.config.cloak_fingerprint_seed}
                   if self.config.cloak_fingerprint_seed is not None else {}),
            )
            self._context = await self._browser.new_context(
                user_agent=launch_ua,
                ignore_https_errors=ignore_https,
            )
        else:
            from playwright.async_api import async_playwright

            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.config.headless,
                proxy=proxy_settings,
                args=list(chromium_args) or None,
            )
            self._context = await self._browser.new_context(
                user_agent=launch_ua,
                ignore_https_errors=ignore_https,
            )

        self.page = await self._context.new_page()
        if self.config.stealth is not None:
            try:
                await self.config.stealth.apply_post_launch(self.page)
            except Exception:
                logger.exception(
                    "[browser] stealth.apply_post_launch failed (name=%s)",
                    getattr(self.config.stealth, "name", "?"),
                )

        return self.page

    async def stop(self) -> None:
        if self._context is not None:
            try:
                await self._context.close()
            except Exception:
                logger.debug("context close failed", exc_info=True)
            self._context = None
        if self._browser is not None:
            try:
                await self._browser.close()
            except Exception:
                logger.debug("browser close failed", exc_info=True)
            self._browser = None
        if self._playwright is not None:
            try:
                await self._playwright.stop()
            except Exception:
                logger.debug("playwright stop failed", exc_info=True)
            self._playwright = None
        self.page = None
        if self._smart_router is not None:
            try:
                self._smart_router.stop()
            except Exception:
                logger.debug("smart-router stop failed", exc_info=True)

    # Back-compat shim — older callers ran `worker.start()` then
    # `await worker.stop_async()`. Both ends are async now, so this
    # just forwards to stop().
    async def stop_async(self) -> None:
        await self.stop()


def _build_proxy_settings(
    proxy_url: Optional[str], bypass: tuple[str, ...]
) -> Optional[dict]:
    if not proxy_url:
        return None
    from fleet_browser.proxy_extension import parse_proxy_url
    spec = parse_proxy_url(proxy_url)
    server = f"{spec.scheme}://{spec.host}:{spec.port}"
    bypass_list = ["localhost", "127.0.0.1", *bypass]
    out = {"server": server, "bypass": ",".join(bypass_list)}
    if spec.has_auth:
        out["username"] = spec.username or ""
        out["password"] = spec.password or ""
    return out


def _build_chromium_args(cfg: BrowserConfig, engine: str) -> tuple[str, ...]:
    args: list[str] = [
        "--disable-blink-features=AutomationControlled",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-default-apps",
        "--disable-dev-shm-usage",
        "--disable-popup-blocking",
        "--disable-infobars",
        "--mute-audio",
    ]
    if cfg.host_resolver_rules:
        args.append(f"--host-resolver-rules={cfg.host_resolver_rules}")
    if cfg.ignore_cert_errors:
        args.append("--ignore-certificate-errors")
        args.append("--allow-insecure-localhost")
    args.extend(cfg.extra_args)
    _ = engine  # reserved for engine-specific tweaks
    return tuple(args)


__all__ = [
    "BrowserConfig",
    "ChromiumWorker",
]
