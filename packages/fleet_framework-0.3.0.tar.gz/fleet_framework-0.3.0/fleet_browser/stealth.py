from __future__ import annotations

import logging
from typing import Any, Optional, Protocol, runtime_checkable

from fleet_browser.fingerprint import Fingerprint

logger = logging.getLogger(__name__)


@runtime_checkable
class Stealth(Protocol):
    """Pluggable browser hardening — anything that prepares a Chromium page
    against fingerprinting / anti-bot detection.

    Two hooks: `launch_user_agent()` returns the UA string to wire into
    Chromium *before* it launches (so pre-CDP requests look right); and
    `apply_post_launch(page)` runs once the Playwright Page exists, typically
    using a CDP session for setUserAgentOverride / setExtraHTTPHeaders, and
    page.add_init_script for navigator overrides.

    `apply_post_launch` is async because Playwright's API is async-only.
    Implementations must be safe to call once per browser launch.
    """

    name: str

    def launch_user_agent(self) -> Optional[str]: ...
    async def apply_post_launch(self, page: Any) -> None: ...


class NoOpStealth:
    """No-op stealth. Useful for tests and for environments where a stock
    Chromium fingerprint is acceptable."""

    name = "noop"

    def launch_user_agent(self) -> Optional[str]:
        return None

    async def apply_post_launch(self, page: Any) -> None:  # noqa: ARG002
        return None


class FingerprintStealth:
    """Default stealth: applies a uaforge-derived Windows-Chrome
    fingerprint via CDP (UA + UA-CH metadata + Accept-Language +
    navigator.* overrides)."""

    name = "fingerprint"

    def __init__(self, fingerprint: Fingerprint) -> None:
        self._fp = fingerprint

    @property
    def fingerprint(self) -> Fingerprint:
        return self._fp

    def launch_user_agent(self) -> Optional[str]:
        return self._fp.user_agent

    async def apply_post_launch(self, page: Any) -> None:
        fp = self._fp
        cdp = await page.context.new_cdp_session(page)
        try:
            await cdp.send(
                "Network.setUserAgentOverride",
                {
                    "userAgent": fp.user_agent,
                    "userAgentMetadata": fp.to_cdp_user_agent_metadata(),
                    "acceptLanguage": ",".join(
                        f"{lang};q=0.{9 - i}" if i else lang
                        for i, lang in enumerate(fp.languages)
                    ),
                    "platform": fp.platform,
                },
            )
            await cdp.send(
                "Network.setExtraHTTPHeaders",
                {"headers": fp.to_extra_http_headers()},
            )
        finally:
            await cdp.detach()
        # Init script runs before any document — works for every nav.
        await page.add_init_script(fp.navigator_overrides_js())
