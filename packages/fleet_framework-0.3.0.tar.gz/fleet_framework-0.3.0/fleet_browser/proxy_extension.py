"""Proxy URL parser + (legacy) auth-extension builder.

Since fleet_browser migrated to Playwright, authenticated proxies are handled
natively via Playwright's `proxy=` argument — no extension needed. The
MV3 extension builder below is retained for callers driving Chromium directly
without Playwright (rare); it WILL NOT work in Chromium 127+ without the
matching webRequestAuthProvider permission and a developer-mode-enabled
profile.
"""
from __future__ import annotations

import hashlib
import json
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, NamedTuple
from urllib.parse import urlparse


class ProxySpec(NamedTuple):
    scheme: str  # "http" | "https" | "socks5"
    host: str
    port: int
    username: str | None
    password: str | None

    @property
    def has_auth(self) -> bool:
        return bool(self.username and self.password)

    @property
    def chromium_proxy_server(self) -> str:
        return f"{self.scheme}://{self.host}:{self.port}"


def parse_proxy_url(url: str) -> ProxySpec:
    if "://" not in url:
        url = "http://" + url
    p = urlparse(url)
    if not p.hostname or not p.port:
        raise ValueError(f"proxy URL missing host or port: {url!r}")
    scheme = (p.scheme or "http").lower()
    if scheme not in ("http", "https", "socks5", "socks5h"):
        raise ValueError(f"unsupported proxy scheme: {scheme!r}")
    return ProxySpec(
        scheme=scheme,
        host=p.hostname,
        port=p.port,
        username=p.username,
        password=p.password,
    )


@dataclass
class ProxyAuthExtension:
    directory: Path
    proxy: ProxySpec


_MANIFEST_TEMPLATE = {
    "name": "Fleet Proxy Auth",
    "version": "1.1.0",
    "manifest_version": 3,
    "permissions": [
        "proxy",
        "webRequest",
        # MV3-only permission that re-allows blocking onAuthRequired
        # (the only chrome.webRequest event that still supports the
        # "blocking" extraInfoSpec in MV3 — Chrome 108+).
        "webRequestAuthProvider",
        "storage",
    ],
    "host_permissions": ["<all_urls>"],
    "background": {"service_worker": "background.js"},
    "minimum_chrome_version": "108",
}


_DEFAULT_BYPASS = ("localhost", "127.0.0.1", "<local>")


def _background_js(proxy: ProxySpec, bypass_hosts: tuple[str, ...]) -> str:
    single = {"scheme": proxy.scheme, "host": proxy.host, "port": proxy.port}
    creds = {"username": proxy.username or "", "password": proxy.password or ""}
    # Top-level listener registration is required in MV3 service workers —
    # the worker can shut down between events and listeners must be reachable
    # at re-spawn. chrome.webRequest.onAuthRequired keeps "blocking" support
    # in MV3 when the manifest declares webRequestAuthProvider.
    return (
        f'const PROXY_CONFIG = {{\n'
        f'  mode: "fixed_servers",\n'
        f'  rules: {{\n'
        f'    singleProxy: {json.dumps(single)},\n'
        f'    bypassList: {json.dumps(list(bypass_hosts))}\n'
        f'  }}\n'
        f'}};\n'
        f'const CREDENTIALS = {json.dumps(creds)};\n'
        f'\n'
        f'chrome.proxy.settings.set({{ value: PROXY_CONFIG, scope: "regular" }});\n'
        f'\n'
        f'chrome.webRequest.onAuthRequired.addListener(\n'
        f'  () => ({{ authCredentials: CREDENTIALS }}),\n'
        f'  {{ urls: ["<all_urls>"] }},\n'
        f'  ["blocking"]\n'
        f');\n'
    )


def build_proxy_auth_extension(
    proxy: ProxySpec,
    *,
    base_dir: Path | None = None,
    bypass_hosts: Iterable[str] = (),
) -> ProxyAuthExtension:
    if not proxy.has_auth:
        raise ValueError("build_proxy_auth_extension called without credentials")

    bypass = tuple(_DEFAULT_BYPASS) + tuple(
        h for h in bypass_hosts if h not in _DEFAULT_BYPASS
    )

    base = base_dir if base_dir is not None else Path(tempfile.gettempdir())
    # Include the manifest version in the cache key so a v2-cached directory
    # doesn't get reused for v3 (and vice versa) when callers move between
    # Chromium generations that support different manifests.
    mv = _MANIFEST_TEMPLATE["manifest_version"]
    creds_id = hashlib.sha256(
        f"mv{mv}|{proxy.username}:{proxy.password}@{proxy.host}:{proxy.port}|"
        f"bypass={','.join(bypass)}".encode()
    ).hexdigest()[:24]
    ext_dir = base / f"fleet-proxy-auth-{creds_id}"
    ext_dir.mkdir(parents=True, exist_ok=True)

    (ext_dir / "manifest.json").write_text(json.dumps(_MANIFEST_TEMPLATE, indent=2))
    (ext_dir / "background.js").write_text(_background_js(proxy, bypass))

    return ProxyAuthExtension(directory=ext_dir, proxy=proxy)
