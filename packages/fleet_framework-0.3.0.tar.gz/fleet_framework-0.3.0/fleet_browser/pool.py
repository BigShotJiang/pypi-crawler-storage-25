"""Async slot helper + pre-warmed BrowserPool for Playwright-backed sessions.

Two entry points:

* `slot()` — one-shot context manager. Spawns a fresh ChromiumWorker per call.
  Use when you don't run enough tasks to amortise the ~1.5-2 s cloak launch.

* `BrowserPool` — keeps N hot workers ready, lease via `pool.acquire()`. Use
  when launch overhead matters (high-throughput SERP, account-creation flows).
  `max_uses` controls fingerprint isolation: 1 = dispose + respawn after every
  task (fresh cloak fingerprint per task — recommended against Google's bot
  wall); higher values reuse the same Browser across many tasks (cookies are
  cleared between uses but the cloak fingerprint stays the same).
"""
from __future__ import annotations

import asyncio
import logging
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Awaitable, Callable, Optional

from fleet_browser.browser import BrowserConfig, ChromiumWorker
from fleet_browser.display import ensure_virtual_display
from fleet_browser.fingerprint import FingerprintFactory
from fleet_browser.stealth import FingerprintStealth, Stealth

logger = logging.getLogger(__name__)


@asynccontextmanager
async def slot(
    ctx: Any,
    *,
    page_url: str,
    fingerprint_factory: FingerprintFactory | None = None,
    use_fingerprint: bool = True,
    headless: bool = True,
    extra_args: tuple[str, ...] = (),
    host_resolver_rules: str | None = None,
    ignore_cert_errors: bool = False,
    proxy_bypass: tuple[str, ...] = (),
    engine: str = "auto",
    nav_timeout_seconds: float = 15.0,
    block_resource_types: tuple[str, ...] = (),
) -> AsyncIterator[Any]:
    """Spawn one Playwright Page, yield it, and tear it down cleanly.

    `engine` defaults to `"auto"` → `"cloak"` (cloakbrowser is bundled in the
    [browser] extra so it's available). Set `"chrome"` to use stock Playwright
    Chromium instead.

    `nav_timeout_seconds` caps the initial `page.goto(page_url)` so a slow
    proxy exit fails fast and the caller can retry+rotate instead of blocking
    on one hung IP. Default 15 s — a clean Evomi exit through cloak+router
    finishes a SERP load in 5-10 s.

    `block_resource_types` is a tuple of Playwright resource-type strings to
    abort at the browser level (no proxy traffic, no render-blocking wait).
    E.g. ("image", "font", "media", "stylesheet") — Google's organic results
    are in the server-rendered HTML, so blocking these costs nothing for SERP
    parsing while saving ~50 % of the residential bandwidth per page.

    The yielded object is a Playwright `Page`. Drive it with `page.goto(...)`,
    `await page.content()`, `await page.locator(...)`, etc.
    """
    ensure_virtual_display()
    stealth: Stealth | None = None
    if use_fingerprint:
        factory = fingerprint_factory or FingerprintFactory()
        stealth = FingerprintStealth(factory.next())

    cfg = BrowserConfig(
        page_url=page_url,
        proxy=getattr(ctx, "proxy_url", None),
        proxy_bypass=proxy_bypass,
        stealth=stealth,
        host_resolver_rules=host_resolver_rules,
        ignore_cert_errors=ignore_cert_errors,
        headless=headless,
        extra_args=extra_args,
        engine=engine,
    )
    worker = ChromiumWorker(cfg)
    page = await worker.start()
    if block_resource_types:
        blocked = frozenset(block_resource_types)
        async def _route(route):
            if route.request.resource_type in blocked:
                try:
                    await route.abort()
                except Exception:
                    pass
            else:
                try:
                    await route.continue_()
                except Exception:
                    pass
        await page.route("**/*", _route)
    try:
        await page.goto(
            page_url, wait_until="domcontentloaded",
            timeout=int(nav_timeout_seconds * 1000),
        )
        yield page
    finally:
        try:
            await worker.stop()
        except Exception:
            logger.exception("worker stop failed")


WorkerFactory = Callable[[], ChromiumWorker]
ResetFn = Callable[[Any], Awaitable[None]]


@dataclass
class _PoolEntry:
    worker: Any  # ChromiumWorker or a test stub
    page: Any
    uses: int = 0
    started_at: float = field(default_factory=time.monotonic)
    healthy: bool = True


async def _default_reset(page: Any) -> None:
    """Reset between uses: clear cookies + storage, navigate to about:blank.

    Cheap (one CDP call + one nav). Does NOT refresh the cloak fingerprint —
    that lives at Browser-launch level. Callers wanting fingerprint refresh
    should set `max_uses=1` so each task gets a fresh worker.
    """
    try:
        ctx = page.context
    except AttributeError:
        return
    try:
        await ctx.clear_cookies()
    except Exception:
        logger.debug("clear_cookies failed", exc_info=True)
    try:
        await ctx.clear_permissions()
    except Exception:
        logger.debug("clear_permissions failed", exc_info=True)
    try:
        await page.goto("about:blank", wait_until="domcontentloaded", timeout=5_000)
    except Exception:
        logger.debug("about:blank nav failed", exc_info=True)


def _default_worker_factory(
    config_template: BrowserConfig,
    fingerprint_factory: FingerprintFactory | None = None,
) -> WorkerFactory:
    """Build a worker factory that materialises BrowserConfig per call.

    Each call rotates a fresh FingerprintStealth so the cloak Browser launched
    by this worker gets its own seed. Caller provides the template with proxy
    / engine / headless / smart_routing flags; this factory just stamps a
    fingerprint on top.
    """
    factory = fingerprint_factory or FingerprintFactory()

    def _make() -> ChromiumWorker:
        cfg = BrowserConfig(
            page_url=config_template.page_url,
            proxy=config_template.proxy,
            proxy_bypass=config_template.proxy_bypass,
            user_agent=config_template.user_agent,
            stealth=FingerprintStealth(factory.next()),
            headless=config_template.headless,
            engine=config_template.engine,
            cloak_platform=config_template.cloak_platform,
            cloak_timezone=config_template.cloak_timezone,
            cloak_webrtc_ip=config_template.cloak_webrtc_ip,
            cloak_fingerprint_seed=config_template.cloak_fingerprint_seed,
            extra_args=config_template.extra_args,
            ignore_cert_errors=config_template.ignore_cert_errors,
            host_resolver_rules=config_template.host_resolver_rules,
            smart_routing=config_template.smart_routing,
            smart_routing_rules=config_template.smart_routing_rules,
        )
        return ChromiumWorker(cfg)

    return _make


class BrowserPool:
    """Pool of pre-warmed Chromium workers, leased per task.

    Lifecycle:
        pool = BrowserPool(size=4, worker_factory=...)
        await pool.start()                # pre-warms 4 workers in parallel
        async with pool.acquire() as page:
            await page.goto(...)
        ...
        await pool.stop()                 # disposes everything

    Each entry handles `max_uses` tasks before being recycled. Between tasks
    the page is reset (cookies + storage cleared, nav to about:blank). The
    janitor task periodically recycles entries past `max_age_seconds`.

    If the caller raises inside the `async with`, the entry is flagged
    unhealthy and disposed immediately; a replacement spawns so the next
    `acquire()` doesn't stall.

    Use `max_uses=1` to force a fresh cloak fingerprint per task (the cloak
    seed is set at Browser launch and can't be changed without restart).
    Use higher `max_uses` for cheap workloads where fingerprint reuse is OK.
    """

    def __init__(
        self,
        size: int,
        worker_factory: WorkerFactory,
        *,
        max_uses: int = 100,
        max_age_seconds: float = 3600.0,
        janitor_interval_seconds: float = 30.0,
        reset_fn: Optional[ResetFn] = None,
    ) -> None:
        if size <= 0:
            raise ValueError("pool size must be >= 1")
        self._size = size
        self._factory = worker_factory
        self._max_uses = max_uses
        self._max_age = max_age_seconds
        self._janitor_interval = janitor_interval_seconds
        self._reset_fn = reset_fn or _default_reset
        self._queue: asyncio.Queue[_PoolEntry] = asyncio.Queue(maxsize=size)
        self._entries: list[_PoolEntry] = []
        self._janitor: Optional[asyncio.Task[None]] = None
        self._closed = False

    @property
    def size(self) -> int:
        return self._size

    @property
    def stats(self) -> dict[str, Any]:
        now = time.monotonic()
        return {
            "size": self._size,
            "alive": sum(1 for e in self._entries if e.healthy),
            "idle": self._queue.qsize(),
            "total_uses": sum(e.uses for e in self._entries),
            "oldest_age_seconds": max(
                (now - e.started_at for e in self._entries), default=0.0,
            ),
        }

    async def start(self) -> None:
        """Pre-launch `size` workers in parallel and start the janitor."""
        if self._closed:
            raise RuntimeError("pool already closed")
        ensure_virtual_display()
        await asyncio.gather(*(self._spawn() for _ in range(self._size)))
        self._janitor = asyncio.create_task(
            self._janitor_loop(), name="browser-pool-janitor",
        )

    async def stop(self) -> None:
        """Cancel the janitor and dispose every worker. Idempotent."""
        if self._closed:
            return
        self._closed = True
        if self._janitor is not None:
            self._janitor.cancel()
            try:
                await self._janitor
            except (asyncio.CancelledError, Exception):
                pass
            self._janitor = None
        for entry in list(self._entries):
            await self._dispose(entry)
        self._entries.clear()
        # Drain the queue so future acquires fail loudly.
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break

    @asynccontextmanager
    async def acquire(self) -> AsyncIterator[Any]:
        """Lease one Page. On exit it's reset and returned to the pool.

        Caller exceptions flag the entry unhealthy → immediate dispose +
        respawn so the next acquire isn't stuck behind a broken worker.
        """
        if self._closed:
            raise RuntimeError("pool is closed")
        entry = await self._queue.get()
        try:
            yield entry.page
        except Exception:
            entry.healthy = False
            raise
        finally:
            entry.uses += 1
            if entry.healthy and not self._is_stale(entry):
                try:
                    await self._reset_fn(entry.page)
                except Exception:
                    logger.exception(
                        "browser-pool: reset_fn failed; marking unhealthy",
                    )
                    entry.healthy = False
            if entry.healthy and not self._is_stale(entry):
                await self._queue.put(entry)
            else:
                await self._dispose(entry)
                if not self._closed:
                    asyncio.create_task(self._spawn())

    def _is_stale(self, entry: _PoolEntry) -> bool:
        if entry.uses >= self._max_uses:
            return True
        if (time.monotonic() - entry.started_at) >= self._max_age:
            return True
        return False

    async def _spawn(self) -> None:
        worker = self._factory()
        try:
            page = await worker.start()
        except Exception:
            logger.exception("browser-pool: worker start failed")
            return
        entry = _PoolEntry(worker=worker, page=page)
        self._entries.append(entry)
        try:
            await self._queue.put(entry)
        except asyncio.QueueFull:
            await self._dispose(entry)

    async def _dispose(self, entry: _PoolEntry) -> None:
        if entry in self._entries:
            self._entries.remove(entry)
        try:
            await entry.worker.stop()
        except Exception:
            logger.exception("browser-pool: worker stop failed")

    async def _janitor_loop(self) -> None:
        while not self._closed:
            try:
                await asyncio.sleep(self._janitor_interval)
            except asyncio.CancelledError:
                return
            if self._closed:
                return
            # Recycle stale entries that are currently IDLE (in the queue).
            # Don't touch checked-out entries — acquire()'s finally clause
            # handles those.
            idle_drained: list[_PoolEntry] = []
            while not self._queue.empty():
                try:
                    e = self._queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
                if self._is_stale(e) or not e.healthy:
                    await self._dispose(e)
                    asyncio.create_task(self._spawn())
                else:
                    idle_drained.append(e)
            for e in idle_drained:
                await self._queue.put(e)


def make_browser_pool(
    size: int,
    *,
    config_template: BrowserConfig,
    max_uses: int = 100,
    max_age_seconds: float = 3600.0,
    janitor_interval_seconds: float = 30.0,
    fingerprint_factory: FingerprintFactory | None = None,
) -> BrowserPool:
    """Convenience constructor: build a BrowserPool from a BrowserConfig template.

    The template's `page_url`, `proxy`, `engine`, etc. are used as defaults for
    every spawned worker. A fresh FingerprintStealth is rotated per worker so
    every cloak Browser launches with its own seed.
    """
    factory = _default_worker_factory(config_template, fingerprint_factory)
    return BrowserPool(
        size=size,
        worker_factory=factory,
        max_uses=max_uses,
        max_age_seconds=max_age_seconds,
        janitor_interval_seconds=janitor_interval_seconds,
    )


__all__ = ["slot", "BrowserPool", "make_browser_pool", "WorkerFactory", "ResetFn"]
