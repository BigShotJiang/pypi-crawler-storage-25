"""Protocol for browser-driven anti-bot solvers.

Each anti-bot system (Cloudflare, DataDome, Akamai, ...) implements `Solver`
in its own package and registers via the `fleet.solvers` entry-point group.
A harvester or scraper can dispatch by calling `detect(page)` on each
registered solver in turn and using the first that matches.
"""

from __future__ import annotations

from typing import Any, Generic, Protocol, TypeVar, runtime_checkable

R = TypeVar("R", covariant=True)


@runtime_checkable
class Solver(Protocol, Generic[R]):
    """Protocol for an anti-bot solver bound to a browser page.

    `name` is a short stable identifier ("cloudflare", "datadome").
    `detect` returns True when the current page state matches this solver's
    target system. `solve` drives the page through the challenge and
    returns whatever result type the implementation defines.
    """

    name: str

    def detect(self, page: Any) -> bool: ...

    def solve(self, page: Any, target: str, timeout: float = 30.0) -> R: ...


def load_solver_entry_points() -> dict[str, type]:
    """Return solver classes registered under the `fleet.solvers` entry-point."""
    import importlib.metadata as _md
    try:
        eps = _md.entry_points(group="fleet.solvers")
    except TypeError:
        eps = _md.entry_points().get("fleet.solvers", [])  # type: ignore[assignment]
    except Exception:
        return {}
    out: dict[str, type] = {}
    for ep in eps:
        try:
            out[ep.name] = ep.load()
        except Exception:
            continue
    return out


__all__ = ["Solver", "load_solver_entry_points"]
