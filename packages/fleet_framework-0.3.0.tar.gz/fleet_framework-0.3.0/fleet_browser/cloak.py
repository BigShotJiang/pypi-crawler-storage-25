"""Cloak engine integration — uses the CloakBrowser patched Chromium binary.

CloakBrowser is a separately-licensed binary (free for own-business use,
OEM license required for browser-as-a-service distribution). See:
  https://github.com/CloakHQ/CloakBrowser

The wrapper Python package is MIT-licensed and pulled in via the optional
extra: `pip install fleet-framework[cloak]`. The binary is downloaded on
first use to ~/.cloakbrowser/ (override with CLOAKBROWSER_CACHE_DIR).

Combining cloak (source-level canvas/WebGL/audio/font/WebRTC patches) with
FingerprintStealth (CDP-level UA + Sec-CH-UA + navigator overrides) gives:
  - Deep, JS-undetectable spoofing of low-level signals (cloak)
  - Per-launch diversity of UA versions from the uaforge corpus (FingerprintStealth)

That diversity matters: cloak's binary patches use the latest Chrome only,
so without the CDP layer every harvest looks like the same Chrome version.
With CDP override on top, each launch picks a different version from uaforge
while keeping the renderer-level fingerprint coherent.
"""
from __future__ import annotations

import logging
import os
import random
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


_CLOAK_AVAILABLE: Optional[bool] = None


def cloak_available() -> bool:
    """Return True if the cloakbrowser wrapper package is importable.

    The binary may still need to be downloaded — that's `ensure_cloak_binary`'s
    job. This is just the cheap import probe.
    """
    global _CLOAK_AVAILABLE
    if _CLOAK_AVAILABLE is None:
        try:
            import cloakbrowser  # noqa: F401
            _CLOAK_AVAILABLE = True
        except ImportError:
            _CLOAK_AVAILABLE = False
    return _CLOAK_AVAILABLE


def resolve_engine(name: str) -> str:
    """Resolve `engine="auto"` to `"cloak"` if available, else `"chrome"`."""
    if name != "auto":
        return name
    return "cloak" if cloak_available() else "chrome"


def ensure_cloak_binary(cache_dir: Optional[str] = None) -> str:
    """Return path to the patched Chromium binary; download if missing.

    Delegates to cloakbrowser.download.ensure_binary. ~250-400 MB download
    on first use; cached at ~/.cloakbrowser/ (or `cache_dir`) thereafter.
    Cloakbrowser checks for updates hourly when launched.
    """
    if not cloak_available():
        raise RuntimeError(
            "engine='cloak' requires cloakbrowser. "
            "Install with: pip install fleet-framework[cloak]"
        )
    if cache_dir:
        os.environ.setdefault("CLOAKBROWSER_CACHE_DIR", str(Path(cache_dir).expanduser()))
    from cloakbrowser.download import ensure_binary
    path = ensure_binary()
    return str(path)


def cloak_stealth_args(
    *,
    platform: str = "windows",
    timezone: Optional[str] = None,
    webrtc_ip: Optional[str] = None,
    seed: Optional[int] = None,
) -> tuple[str, ...]:
    """Return Chromium command-line flags that activate cloak's source patches.

    The `seed` drives canvas/WebGL/audio noise variation per-launch. Pass a
    stable seed if you need reproducibility (e.g. testing). `platform` should
    match what FingerprintStealth's UA claims — keep them aligned (default
    'windows' matches uaforge's Windows corpus).
    """
    s = seed if seed is not None else random.randint(10000, 99999)
    args = [
        f"--fingerprint={s}",
        f"--fingerprint-platform={platform}",
    ]
    if timezone:
        args.append(f"--fingerprint-timezone={timezone}")
    if webrtc_ip:
        args.append(f"--fingerprint-webrtc-ip={webrtc_ip}")
    return tuple(args)


CLOAK_IGNORE_DEFAULT_ARGS: tuple[str, ...] = (
    "--enable-automation",
    "--enable-unsafe-swiftshader",
)
"""Default args Playwright/DrissionPage pass that leak automation signals.

`--enable-automation` exposes `navigator.webdriver=true`. `--enable-unsafe-
swiftshader` forces SwiftShader's distinctive WebGL renderer string. We pass
these to Chromium's launch options so DrissionPage stops setting them."""


__all__ = [
    "CLOAK_IGNORE_DEFAULT_ARGS",
    "cloak_available",
    "cloak_stealth_args",
    "ensure_cloak_binary",
    "resolve_engine",
]
