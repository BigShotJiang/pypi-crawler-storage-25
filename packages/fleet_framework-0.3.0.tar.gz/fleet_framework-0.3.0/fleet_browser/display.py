"""Auto-managed virtual display for headed-on-Xvfb browser runs.

Production deployments hide Chromium behind an X virtual framebuffer (Xvfb)
because stock headless leaves detectable fingerprint artifacts (HeadlessChrome
UA, missing GPU, etc.). Until now callers had to start `Xvfb :99 ...` by hand
and set `DISPLAY=:99`. This module wraps pyvirtualdisplay so a single Xvfb
spins up on first browser launch and shuts down on interpreter exit.

The display is **shared** across every ChromiumWorker / BrowserPool in the
process. We never start a second display; multiple browsers fan out onto
the same virtual framebuffer the same way they'd fan out onto a real monitor.

If the caller has already set `DISPLAY=:N` (N != 0) we leave it alone — they
brought their own Xvfb and we trust them.
"""
from __future__ import annotations

import atexit
import logging
import os
import threading
from typing import Optional

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_display = None  # pyvirtualdisplay.Display | None — lazy import
_managed_display_value: Optional[str] = None


def ensure_virtual_display(
    *,
    width: int = 1920,
    height: int = 1080,
    color_depth: int = 24,
) -> Optional[str]:
    """Start a pyvirtualdisplay-managed Xvfb if no display is configured.

    Idempotent — subsequent calls return the same DISPLAY value. Sets the
    ``DISPLAY`` environment variable so child processes (Chromium, mitmdump)
    inherit it.

    Returns the active DISPLAY value (e.g. ``":42"``) or None if no display
    could be set up (pyvirtualdisplay not installed AND no manual DISPLAY).
    """
    cur = os.environ.get("DISPLAY", "")
    if cur and cur != ":0":
        return cur

    global _display, _managed_display_value
    with _lock:
        if _display is not None:
            return _managed_display_value or os.environ.get("DISPLAY")
        try:
            from pyvirtualdisplay.display import Display
        except ImportError:
            logger.warning(
                "pyvirtualdisplay not installed; falling back to DISPLAY=%r. "
                "Install with `pip install fleet-framework[browser]`.",
                cur or "(unset)",
            )
            return cur or None
        try:
            _display = Display(
                visible=False, size=(width, height), color_depth=color_depth,
            )
            _display.start()
        except Exception:
            logger.exception("pyvirtualdisplay start failed; using DISPLAY=%r", cur)
            _display = None
            return cur or None
        _managed_display_value = os.environ.get("DISPLAY") or f":{_display.display}"
        # Defensive: pyvirtualdisplay sets DISPLAY for the parent process, but
        # some shells inherit DISPLAY at exec time. Re-export to be sure.
        os.environ["DISPLAY"] = _managed_display_value
        atexit.register(_shutdown)
        logger.info(
            "virtual display %s started (%dx%d@%dbit)",
            _managed_display_value, width, height, color_depth,
        )
        return _managed_display_value


def _shutdown() -> None:
    global _display
    if _display is None:
        return
    try:
        _display.stop()
    except Exception:
        logger.debug("virtual display stop failed", exc_info=True)
    _display = None


__all__ = ["ensure_virtual_display"]
