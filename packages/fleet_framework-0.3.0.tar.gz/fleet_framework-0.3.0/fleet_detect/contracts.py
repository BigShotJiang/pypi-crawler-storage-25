from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class AntiBotSystem(str, Enum):
    NONE = "none"
    CLOUDFLARE = "cloudflare"
    DATADOME = "datadome"
    AKAMAI = "akamai"
    PERIMETERX = "perimeterx"
    INCAPSULA = "incapsula"
    KASADA = "kasada"
    RECAPTCHA = "recaptcha"
    HCAPTCHA = "hcaptcha"
    TURNSTILE = "turnstile"
    AWS_WAF = "aws_waf"
    FASTLY_WAF = "fastly_waf"
    UNKNOWN_WAF = "unknown_waf"


class SignalKind(str, Enum):
    HEADER = "header"
    COOKIE = "cookie"
    BODY = "body"
    STATUS = "status"
    URL = "url"


class DetectionEvidence(BaseModel):
    system: AntiBotSystem
    signal: SignalKind
    confidence: float = Field(ge=0.0, le=1.0)
    detail: str


class DetectionResult(BaseModel):
    primary: AntiBotSystem = AntiBotSystem.NONE
    detected: list[DetectionEvidence] = Field(default_factory=list)
    page_status: int
    target_url: str

    @property
    def is_blocked(self) -> bool:
        """True when the response *looks* like a challenge / block page
        rather than the underlying content. False for `none` and for
        captcha widgets embedded on otherwise-normal pages.

        Rules:
          - HTTP 4xx/5xx with any detected system → blocked.
          - 2xx/3xx with only a low-confidence body widget (e.g. an
            embedded reCAPTCHA on a signup form) → not blocked, the
            session is fine.
          - 2xx/3xx with a very-high-confidence challenge body marker
            (CF "Attention Required!", DataDome captcha-delivery URL) →
            blocked.
        """
        if self.primary == AntiBotSystem.NONE:
            return False
        if self.page_status >= 400:
            return True
        return any(
            ev.signal == SignalKind.BODY and ev.confidence >= 0.9
            for ev in self.detected
        )
