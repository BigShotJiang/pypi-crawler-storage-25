from __future__ import annotations

from typing import Mapping

from fleet_detect.contracts import (
    AntiBotSystem,
    DetectionEvidence,
    DetectionResult,
    SignalKind,
)


def _lower_headers(h: Mapping[str, str]) -> dict[str, str]:
    return {k.lower(): v for k, v in h.items()}


# Signature tables. Add new entries with care — false positives are worse
# than missed detections because callers may route a healthy response to a
# solver and turn it into a stuck loop.

_HEADER_SIGS: list[tuple[AntiBotSystem, str, str, float, str]] = [
    # (system, header_name_lower, substring_lower, confidence, detail)
    (AntiBotSystem.CLOUDFLARE, "server", "cloudflare", 0.7, "Server: cloudflare"),
    (AntiBotSystem.CLOUDFLARE, "cf-ray", "", 0.9, "CF-Ray header present"),
    (AntiBotSystem.CLOUDFLARE, "cf-mitigated", "", 0.95, "CF-Mitigated header present"),
    (AntiBotSystem.DATADOME, "x-dd-b", "", 0.95, "X-DD-B header present"),
    (AntiBotSystem.DATADOME, "set-cookie", "datadome=", 0.95, "datadome cookie set"),
    (AntiBotSystem.AKAMAI, "set-cookie", "ak_bmsc=", 0.85, "ak_bmsc cookie set"),
    (AntiBotSystem.AKAMAI, "set-cookie", "bm_sv=", 0.85, "bm_sv cookie set"),
    (AntiBotSystem.AKAMAI, "set-cookie", "bm_sz=", 0.85, "bm_sz cookie set"),
    (AntiBotSystem.AKAMAI, "server", "akamaighost", 0.7, "Server: AkamaiGHost"),
    (AntiBotSystem.PERIMETERX, "set-cookie", "_px=", 0.85, "_px cookie set"),
    (AntiBotSystem.PERIMETERX, "set-cookie", "_pxhd=", 0.85, "_pxhd cookie set"),
    (AntiBotSystem.INCAPSULA, "set-cookie", "incap_ses_", 0.85, "incap_ses_ cookie set"),
    (AntiBotSystem.INCAPSULA, "set-cookie", "visid_incap_", 0.85, "visid_incap_ cookie set"),
    (AntiBotSystem.KASADA, "set-cookie", "kasada", 0.85, "kasada cookie set"),
    (AntiBotSystem.AWS_WAF, "x-amzn-waf-action", "", 0.9, "x-amzn-waf-action header present"),
    (AntiBotSystem.FASTLY_WAF, "x-fastly", "", 0.6, "x-fastly header present"),
]


_BODY_SIGS: list[tuple[AntiBotSystem, str, float, str]] = [
    (AntiBotSystem.CLOUDFLARE, "cf-browser-verification", 0.9, "CF JS-challenge marker"),
    (AntiBotSystem.CLOUDFLARE, "challenges.cloudflare.com", 0.85, "Turnstile widget URL"),
    (AntiBotSystem.CLOUDFLARE, "attention required! | cloudflare", 0.95, "CF block title"),
    (AntiBotSystem.TURNSTILE, "challenges.cloudflare.com/turnstile", 0.95, "Turnstile widget URL"),
    (AntiBotSystem.RECAPTCHA, "www.google.com/recaptcha/api.js", 0.95, "reCAPTCHA script"),
    (AntiBotSystem.RECAPTCHA, "g-recaptcha", 0.7, "g-recaptcha element class"),
    (AntiBotSystem.HCAPTCHA, "hcaptcha.com/1/api.js", 0.95, "hCaptcha script"),
    (AntiBotSystem.HCAPTCHA, "h-captcha", 0.7, "h-captcha element class"),
    (AntiBotSystem.DATADOME, "geo.captcha-delivery.com", 0.95, "DataDome captcha delivery URL"),
    (AntiBotSystem.PERIMETERX, "_pxonbeforeload", 0.8, "PerimeterX onbeforeload"),
    (AntiBotSystem.PERIMETERX, "px-captcha", 0.8, "PerimeterX captcha element"),
    (AntiBotSystem.KASADA, "kpsdk", 0.85, "Kasada KP-SDK reference"),
    (AntiBotSystem.AWS_WAF, "awswafcookie", 0.85, "AWS WAF cookie marker"),
]


# Status codes commonly issued by challenge / block flows.
_STATUS_SIGS: dict[int, tuple[AntiBotSystem, float, str]] = {
    403: (AntiBotSystem.UNKNOWN_WAF, 0.3, "HTTP 403 (could be WAF or app-level)"),
    429: (AntiBotSystem.UNKNOWN_WAF, 0.4, "HTTP 429 rate-limited"),
    503: (AntiBotSystem.UNKNOWN_WAF, 0.4, "HTTP 503 (CF/Akamai use this for challenges)"),
}


def detect_from_response(
    *,
    status: int,
    headers: Mapping[str, str],
    body: str,
    url: str,
) -> DetectionResult:
    """Classify which anti-bot system, if any, fronts this response.

    All four inputs are needed — header-only detection misses body-rendered
    captchas, body-only detection misses cookie-based WAFs that haven't
    challenged yet.
    """
    h = _lower_headers(headers)
    body_l = body.lower() if body else ""

    evidence: list[DetectionEvidence] = []

    for system, hname, substr, conf, detail in _HEADER_SIGS:
        v = h.get(hname)
        if v is None:
            continue
        if substr and substr.lower() not in v.lower():
            continue
        evidence.append(DetectionEvidence(
            system=system, signal=SignalKind.HEADER, confidence=conf, detail=detail,
        ))

    for system, substr, conf, detail in _BODY_SIGS:
        if substr in body_l:
            evidence.append(DetectionEvidence(
                system=system, signal=SignalKind.BODY, confidence=conf, detail=detail,
            ))

    if status in _STATUS_SIGS:
        sys_, conf, detail = _STATUS_SIGS[status]
        evidence.append(DetectionEvidence(
            system=sys_, signal=SignalKind.STATUS, confidence=conf, detail=detail,
        ))

    primary = _pick_primary(evidence)
    return DetectionResult(
        primary=primary,
        detected=evidence,
        page_status=status,
        target_url=url,
    )


def _pick_primary(evidence: list[DetectionEvidence]) -> AntiBotSystem:
    if not evidence:
        return AntiBotSystem.NONE
    # Weight by max confidence per system; prefer specific systems over
    # UNKNOWN_WAF when both fired.
    by_system: dict[AntiBotSystem, float] = {}
    for ev in evidence:
        by_system[ev.system] = max(by_system.get(ev.system, 0.0), ev.confidence)
    if AntiBotSystem.UNKNOWN_WAF in by_system and len(by_system) > 1:
        del by_system[AntiBotSystem.UNKNOWN_WAF]
    return max(by_system.items(), key=lambda kv: kv[1])[0]
