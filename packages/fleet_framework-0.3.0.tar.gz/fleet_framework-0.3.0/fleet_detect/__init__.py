"""fleet-detect — classify which anti-bot system, if any, fronts an HTTP
response.

Pass `status`, `headers`, `body`, and `url` from a real response (curl_cffi,
httpx, requests, fetch, anything) to `detect_from_response` and get back
a `DetectionResult` with the primary system + all triggered signals.

Signals are deliberately conservative — a single match doesn't override
the body-content evidence, and "none" is the default when nothing fires.
"""

from fleet_detect.contracts import (
    AntiBotSystem,
    DetectionEvidence,
    DetectionResult,
    SignalKind,
)
from fleet_detect.detect import detect_from_response

__all__ = [
    "AntiBotSystem",
    "DetectionEvidence",
    "DetectionResult",
    "SignalKind",
    "detect_from_response",
]
