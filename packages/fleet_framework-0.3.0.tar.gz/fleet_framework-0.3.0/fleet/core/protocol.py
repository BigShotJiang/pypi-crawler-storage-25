from __future__ import annotations

import json
from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, ValidationError

PROTOCOL_VERSION: int = 1

WorkerState = Literal["IDLE", "RUNNING", "ERROR", "DRAINING"]


class ProtocolError(Exception):
    pass


class _Frame(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Hardware(BaseModel):
    model_config = ConfigDict(extra="forbid")
    cores: int = Field(ge=1)
    ram_gb: int = Field(ge=0)
    hostname: str
    kernel: str


# worker -> master


class Register(_Frame):
    type: Literal["register"] = "register"
    worker_id: str
    automation_type: str
    protocol_version: int
    hardware: Hardware
    fleet_core_version: str = ""
    """Worker's installed fleet-core version. Master logs a mismatch warning
    when the major differs from its own. Empty for backwards compat with
    pre-0.1 workers."""


class State(_Frame):
    type: Literal["state"] = "state"
    state: WorkerState
    config_gen: int = Field(ge=0)
    ts: int = Field(ge=0)
    last_error: str | None = None


class SlotStats(_Frame):
    """Per-slot snapshot inside a Stats frame."""
    slot_id: int = Field(ge=0)
    age_seconds: float = Field(ge=0.0)
    cpu_pct: float = Field(ge=0.0, default=0.0)
    rss_mb: int = Field(ge=0, default=0)
    counters: dict[str, int] = Field(default_factory=dict)


class Stats(_Frame):
    type: Literal["stats"] = "stats"
    slots: int = Field(ge=0)
    cpu_pct: float = Field(ge=0.0)
    rss_mb: int = Field(ge=0)
    ts: int = Field(ge=0)
    metrics: dict[str, Any] = Field(default_factory=dict)
    per_slot: list[SlotStats] = Field(default_factory=list)


class Output(_Frame):
    # generic worker -> master output frame. payload is plugin-typed (validated server-side).
    type: Literal["output"] = "output"
    slot_id: int = Field(ge=0)
    ts: int = Field(ge=0)
    payload: dict[str, Any]


# master -> worker


class ConfigChanged(_Frame):
    type: Literal["config_changed"] = "config_changed"
    config_gen: int = Field(ge=0)


class TaskAssign(_Frame):
    # used by BatchAutomation. master pushes a single task to a worker slot.
    type: Literal["task_assign"] = "task_assign"
    task_id: str
    payload: dict[str, Any]


class Ping(_Frame):
    type: Literal["ping"] = "ping"
    id: str


class Drain(_Frame):
    """Master → worker: drain in-flight slots and exit cleanly.

    After receiving, the worker sets shutdown on every slot, waits for
    them to complete (no hard cancel), reports DRAINING, then exits.
    """
    type: Literal["drain"] = "drain"


Message = Annotated[
    Union[Register, State, Stats, Output, ConfigChanged, TaskAssign, Ping, Drain],
    Field(discriminator="type"),
]


_TYPE_REGISTRY: dict[str, type[BaseModel]] = {
    "register": Register,
    "state": State,
    "stats": Stats,
    "output": Output,
    "config_changed": ConfigChanged,
    "task_assign": TaskAssign,
    "ping": Ping,
    "drain": Drain,
}


def encode(msg: BaseModel) -> str:
    if not isinstance(msg, BaseModel):
        raise TypeError(f"encode() expected pydantic BaseModel, got {type(msg).__name__}")
    return msg.model_dump_json()


def decode(raw: str | bytes | bytearray) -> BaseModel:
    if not isinstance(raw, (str, bytes, bytearray)):
        raise ProtocolError(f"decode() expects str/bytes, got {type(raw).__name__}")
    try:
        data: Any = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ProtocolError(f"malformed JSON: {e}") from e
    if not isinstance(data, dict):
        raise ProtocolError(f"frame root must be object, got {type(data).__name__}")
    if "type" not in data:
        raise ProtocolError("frame missing required field 'type'")
    tag = data["type"]
    if not isinstance(tag, str):
        raise ProtocolError(f"frame 'type' must be string, got {type(tag).__name__}")
    cls = _TYPE_REGISTRY.get(tag)
    if cls is None:
        raise ProtocolError(f"unknown message type: {tag!r}")
    try:
        return cls.model_validate(data)
    except ValidationError as e:
        raise ProtocolError(f"validation failed for type={tag!r}: {e}") from e


__all__ = [
    "ConfigChanged",
    "Drain",
    "Hardware",
    "Message",
    "Output",
    "PROTOCOL_VERSION",
    "Ping",
    "ProtocolError",
    "Register",
    "State",
    "Stats",
    "TaskAssign",
    "WorkerState",
    "decode",
    "encode",
]
