from __future__ import annotations

import json
import logging
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, AsyncIterator, Generic, Optional, TypeVar

from pydantic import BaseModel, ValidationError

from fleet.core.backend import Backend, RawItem
from fleet.core.contract import Pool, Queue, Stream, validate_tag_filter

logger = logging.getLogger(__name__)

P = TypeVar("P", bound=BaseModel)
T = TypeVar("T", bound=BaseModel)



@dataclass
class PoolItem(Generic[P, T]):
    id: str
    payload: P
    tags: T
    expires_at: Optional[float]
    _handle: "PoolHandle[P, T]"

    async def release(self) -> None:
        await self._handle._backend.pool_release(self._handle._spec.name, self.id)

    async def evict(self) -> None:
        await self._handle._backend.pool_remove(self._handle._spec.name, self.id)

    async def mark_bad(self, reason: str) -> None:
        """Evict and log. Plugins can override later via a hook for stats."""
        logger.info("pool %s item %s marked bad: %s", self._handle._spec.name, self.id, reason)
        await self.evict()


class PoolFilter(Generic[P, T]):
    def __init__(self, handle: "PoolHandle[P, T]", conditions: dict[str, Any]) -> None:
        self._handle = handle
        self._conditions = conditions

    def where(self, **kwargs: Any) -> "PoolFilter[P, T]":
        # validate kwargs against tag schema; chainable.
        validated = validate_tag_filter(self._handle._spec.tags, **kwargs)
        return PoolFilter(self._handle, {**self._conditions, **validated})

    async def list(self) -> list[PoolItem[P, T]]:
        raws = await self._handle._backend.pool_list(self._handle._spec.name)
        out: list[PoolItem[P, T]] = []
        for r in raws:
            if r.in_use_until is not None:
                continue
            if not all(r.tags.get(k) == v for k, v in self._conditions.items()):
                continue
            item = self._handle._wrap(r)
            if item is not None:
                out.append(item)
        return out

    async def size(self) -> int:
        return len(await self.list())

    @asynccontextmanager
    async def claim(self, *, hold_seconds: int = 30) -> AsyncIterator[Optional[PoolItem[P, T]]]:
        raw = await self._handle._backend.pool_claim_any(
            self._handle._spec.name, self._conditions, hold_seconds,
        )
        if raw is None:
            yield None
            return
        item = self._handle._wrap(raw)
        if item is None:
            # decode failure — release the claim, treat as miss
            await self._handle._backend.pool_release(self._handle._spec.name, raw.id)
            yield None
            return
        try:
            yield item
        finally:
            # if the user evicted, the claim is gone too. release is idempotent.
            try:
                await self._handle._backend.pool_release(self._handle._spec.name, raw.id)
            except Exception:
                logger.debug("pool release failed", exc_info=True)


class PoolHandle(Generic[P, T]):
    def __init__(self, spec: Pool[P, T], backend: Backend) -> None:
        self._spec = spec
        self._backend = backend

    @property
    def name(self) -> str:
        return self._spec.name

    def where(self, **kwargs: Any) -> PoolFilter[P, T]:
        return PoolFilter(self, {}).where(**kwargs)

    async def put(
        self,
        *,
        payload: P,
        tags: T,
        ttl_seconds: Optional[int] = None,
        id: Optional[str] = None,
    ) -> str:
        # local pydantic validation (re-construct enforces type) plus tags type check.
        if not isinstance(payload, self._spec.payload):
            raise TypeError(
                f"pool {self._spec.name}: payload must be {self._spec.payload.__name__}, "
                f"got {type(payload).__name__}"
            )
        if not isinstance(tags, self._spec.tags):
            raise TypeError(
                f"pool {self._spec.name}: tags must be {self._spec.tags.__name__}, "
                f"got {type(tags).__name__}"
            )
        item_id = id or uuid.uuid4().hex
        await self._backend.pool_put(
            self._spec.name,
            item_id,
            payload.model_dump_json().encode("utf-8"),
            tags.model_dump(mode="json"),
            ttl_seconds,
        )
        return item_id

    async def list(self) -> list[PoolItem[P, T]]:
        return await PoolFilter(self, {}).list()

    async def size(self) -> int:
        return await PoolFilter(self, {}).size()

    def _wrap(self, raw: RawItem) -> Optional[PoolItem[P, T]]:
        try:
            payload = self._spec.payload.model_validate_json(raw.payload)
            tags = self._spec.tags.model_validate(raw.tags)
        except ValidationError:
            logger.warning("pool %s item %s failed schema validation; dropping", self._spec.name, raw.id)
            return None
        return PoolItem(
            id=raw.id,
            payload=payload,
            tags=tags,
            expires_at=raw.expires_at,
            _handle=self,
        )



class KV:
    def __init__(self, backend: Backend, namespace: str) -> None:
        self._backend = backend
        self._ns = namespace

    async def set(self, key: str, value: Any, *, ttl_seconds: Optional[int] = None) -> None:
        # value can be a pydantic model, dict, str, int, ..., serialized as json
        import json
        if hasattr(value, "model_dump_json"):
            blob = value.model_dump_json().encode("utf-8")
        else:
            blob = json.dumps(value).encode("utf-8")
        await self._backend.kv_set(self._ns, key, blob, ttl_seconds)

    async def get(self, key: str) -> Any:
        import json
        raw = await self._backend.kv_get(self._ns, key)
        if raw is None:
            return None
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return None

    async def get_as(self, key: str, model: type[BaseModel]) -> Optional[BaseModel]:
        raw = await self._backend.kv_get(self._ns, key)
        if raw is None:
            return None
        return model.model_validate_json(raw)

    async def delete(self, key: str) -> bool:
        return await self._backend.kv_del(self._ns, key)



class Lock:
    def __init__(self, backend: Backend, name: str, hold_seconds: int, wait_seconds: float) -> None:
        self._backend = backend
        self._name = name
        self._hold = hold_seconds
        self._wait = wait_seconds
        self._token: Optional[str] = None

    async def __aenter__(self) -> bool:
        self._token = await self._backend.lock_acquire(self._name, self._hold, self._wait)
        return self._token is not None

    async def __aexit__(self, *exc) -> None:
        if self._token is not None:
            try:
                await self._backend.lock_release(self._name, self._token)
            except Exception:
                logger.debug("lock release failed", exc_info=True)
            self._token = None



class Counter:
    def __init__(self, backend: Backend, name: str) -> None:
        self._backend = backend
        self._name = name

    async def incr(self, by: int = 1) -> int:
        return await self._backend.counter_incr(self._name, by)

    async def decr(self, by: int = 1) -> int:
        return await self._backend.counter_incr(self._name, -by)

    async def get(self) -> int:
        return await self._backend.counter_get(self._name)

    async def set(self, value: int) -> None:
        await self._backend.counter_set(self._name, value)

    async def reset(self) -> None:
        await self._backend.counter_del(self._name)



class QueueHandle(Generic[P]):
    def __init__(self, spec: Queue[P], backend: Backend) -> None:
        self._spec = spec
        self._backend = backend

    async def push(
        self,
        payload: P,
        *,
        task_id: Optional[str] = None,
        priority: int = 0,
        ttl_seconds: Optional[int] = None,
    ) -> str:
        if not isinstance(payload, self._spec.payload):
            raise TypeError(
                f"queue {self._spec.name}: payload must be {self._spec.payload.__name__}, "
                f"got {type(payload).__name__}"
            )
        import time
        tid = task_id or uuid.uuid4().hex
        envelope: dict[str, Any] = {
            "id": tid,
            "payload": payload.model_dump(mode="json"),
            "attempt": 0,
            "submitted_at": time.time(),
        }
        if ttl_seconds is not None:
            envelope["ttl_seconds"] = ttl_seconds
        body = json.dumps(envelope).encode("utf-8")
        await self._backend.queue_push(self._spec.name, body, priority=priority)
        return tid



class StreamReader(Generic[P]):
    def __init__(self, spec: Stream[P], backend: Backend) -> None:
        self._spec = spec
        self._backend = backend

    async def pop(self, n: int = 1) -> list[P]:
        raw_list = await self._backend.stream_pop(self._spec.name, n)
        out: list[P] = []
        for raw in raw_list:
            try:
                envelope = json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
                out.append(self._spec.payload.model_validate(envelope.get("payload", {})))
            except (json.JSONDecodeError, ValidationError):
                logger.warning("stream %s: bad item, dropping", self._spec.name)
                continue
        return out

    async def peek(self, n: int = 10) -> list[P]:
        raw_list = await self._backend.stream_peek(self._spec.name, n)
        out: list[P] = []
        for raw in raw_list:
            try:
                envelope = json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
                out.append(self._spec.payload.model_validate(envelope.get("payload", {})))
            except (json.JSONDecodeError, ValidationError):
                continue
        return out

    async def length(self) -> int:
        return await self._backend.stream_length(self._spec.name)


__all__ = [
    "Counter",
    "KV",
    "Lock",
    "PoolFilter",
    "PoolHandle",
    "PoolItem",
    "QueueHandle",
    "StreamReader",
]
