from __future__ import annotations

import importlib.metadata as md
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, ClassVar, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


@dataclass
class ProxySession:
    url: str
    metadata: dict[str, Any] = field(default_factory=dict)
    _release: Optional[Any] = None
    _report_bad: Optional[Any] = None

    async def release(self) -> None:
        if self._release is not None:
            await self._release(self)

    async def report_bad(self, reason: str) -> None:
        if self._report_bad is not None:
            await self._report_bad(self, reason)


@runtime_checkable
class ProxyProvider(Protocol):
    name: ClassVar[str]

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "ProxyProvider": ...

    async def acquire(
        self,
        *,
        slot_id: int,
        sticky: bool = True,
        country: Optional[str | list[str]] = None,
    ) -> ProxySession: ...


class ProxyHandle:
    # what ctx.proxy returns. wraps a provider and the slot's identity.
    def __init__(self, provider: Optional[ProxyProvider], slot_id: int) -> None:
        self._provider = provider
        self._slot_id = slot_id

    @property
    def provider(self) -> Optional[ProxyProvider]:
        return self._provider

    @asynccontextmanager
    async def session(
        self,
        *,
        sticky: bool = True,
        country: Optional[str | list[str]] = None,
    ) -> AsyncIterator[ProxySession]:
        if self._provider is None:
            yield ProxySession(url="")
            return
        sess = await self._provider.acquire(
            slot_id=self._slot_id, sticky=sticky, country=country
        )
        try:
            yield sess
        finally:
            try:
                await sess.release()
            except Exception:
                logger.debug("proxy session release failed", exc_info=True)


_REGISTRY: dict[str, type] = {}


def register_provider(name: str):
    def _wrap(cls):
        if not hasattr(cls, "from_config"):
            raise TypeError(f"{cls.__name__} must define classmethod from_config")
        cls.name = name
        if name in _REGISTRY and _REGISTRY[name] is not cls:
            raise ValueError(f"proxy provider '{name}' already registered")
        _REGISTRY[name] = cls
        return cls

    return _wrap


def get_provider_registry() -> dict[str, type]:
    return dict(_REGISTRY)


def load_provider_entry_points(group: str = "fleet.providers.proxy") -> dict[str, type]:
    try:
        eps = md.entry_points(group=group)
    except TypeError:
        eps = md.entry_points().get(group, [])  # type: ignore[assignment]
    for ep in eps:
        try:
            ep.load()
        except Exception:
            logger.exception("failed to load proxy provider entry-point %s", ep.name)
    return get_provider_registry()


def build_provider(name: str, cfg: dict[str, Any]) -> ProxyProvider:
    load_provider_entry_points()
    cls = _REGISTRY.get(name)
    if cls is None:
        known = ", ".join(sorted(_REGISTRY.keys())) or "(none installed)"
        raise ValueError(f"unknown proxy provider '{name}'. installed: {known}")
    return cls.from_config(cfg)



@register_provider("static")
class StaticProvider:
    # the original behavior: one URL, always the same.
    def __init__(self, url: Optional[str]) -> None:
        self._url = url

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "StaticProvider":
        return cls(url=cfg.get("url"))

    async def acquire(
        self,
        *,
        slot_id: int,
        sticky: bool = True,
        country: Optional[str | list[str]] = None,
    ) -> ProxySession:
        return ProxySession(url=self._url or "")



@register_provider("rotating-list")
class RotatingListProvider:
    def __init__(self, urls: list[str]) -> None:
        self._urls = urls
        self._next = 0

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "RotatingListProvider":
        urls = list(cfg.get("urls") or [])
        if not urls:
            raise ValueError("rotating-list provider requires non-empty 'urls' list")
        return cls(urls=urls)

    async def acquire(
        self,
        *,
        slot_id: int,
        sticky: bool = True,
        country: Optional[str | list[str]] = None,
    ) -> ProxySession:
        if sticky:
            # deterministic by slot_id so the same slot keeps the same URL.
            url = self._urls[slot_id % len(self._urls)]
        else:
            url = self._urls[self._next % len(self._urls)]
            self._next += 1
        return ProxySession(url=url, metadata={"sticky": sticky})
