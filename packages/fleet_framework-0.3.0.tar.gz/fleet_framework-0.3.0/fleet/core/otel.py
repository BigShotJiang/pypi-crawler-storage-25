"""Optional OpenTelemetry integration.

Importing this module never fails: if `opentelemetry-api` is not installed
or `OTEL_EXPORTER_OTLP_ENDPOINT` (or `FLEET_OTEL_ENABLED`) is not set, the
tracer falls back to no-op context managers so wrapping a hot path costs
roughly one Python function call.

Activation:

    pip install fleet-core[otel]
    export OTEL_EXPORTER_OTLP_ENDPOINT=http://collector:4318
    export OTEL_SERVICE_NAME=fleet-worker

Then spans appear in your collector for `slot.run_continuous`,
`slot.run_one`, `slot.reserve`, and `api.submit_task`. All spans set
`fleet.automation_type`, `fleet.worker_id`, `fleet.slot_id`, and (where
relevant) `fleet.task_id` attributes.
"""

from __future__ import annotations

import logging
import os
from contextlib import contextmanager, nullcontext
from typing import Any, Iterator

logger = logging.getLogger(__name__)

_tracer: Any = None
_disabled = False


def _build_tracer() -> Any:
    global _tracer, _disabled
    if _disabled:
        return None
    if _tracer is not None:
        return _tracer
    if not _otel_requested():
        _disabled = True
        return None
    try:
        from opentelemetry import trace
    except ImportError:
        logger.info("opentelemetry-api not installed; OTel hooks disabled")
        _disabled = True
        return None
    _tracer = trace.get_tracer("fleet-core")
    return _tracer


def _otel_requested() -> bool:
    if os.environ.get("FLEET_OTEL_ENABLED", "").lower() in ("1", "true", "yes"):
        return True
    return any(k.startswith("OTEL_EXPORTER_") for k in os.environ)


@contextmanager
def span(name: str, **attrs: Any) -> Iterator[Any]:
    """Start an OTel span if OTel is configured, otherwise a no-op.

    Attributes are passed in as kwargs and are added to the span. Any
    None-valued attributes are skipped (OTel rejects them)."""
    tracer = _build_tracer()
    if tracer is None:
        with nullcontext() as ctx:
            yield ctx
        return
    cleaned = {f"fleet.{k}": v for k, v in attrs.items() if v is not None}
    with tracer.start_as_current_span(name, attributes=cleaned) as s:
        yield s


def record_exception(exc: BaseException) -> None:
    """Attach an exception to the active span if one exists."""
    tracer = _build_tracer()
    if tracer is None:
        return
    try:
        from opentelemetry import trace
        current = trace.get_current_span()
        if current is not None:
            current.record_exception(exc)
    except Exception:
        return


def reset_for_tests() -> None:
    """Test helper. Clears cached tracer so monkeypatched env reloads."""
    global _tracer, _disabled
    _tracer = None
    _disabled = False


def is_active() -> bool:
    """True if OTel is wired and ready to emit spans."""
    return _build_tracer() is not None
