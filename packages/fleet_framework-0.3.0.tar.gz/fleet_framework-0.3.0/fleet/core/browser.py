"""Browser pool as a first-class core resource.

`BrowserNeeds` is the declarative side: an automation declares what kind of
browser-pool it needs at the class level, the same way it declares
`TaskPayload`, `Output`, and `Pools`. The worker bootstrap reads these
declarations, provisions one shared `BrowserResource` per unique need, and
injects it as `ctx.browser`.

Plugins should never `import fleet_browser` directly. They:

    class MyAutomation(BatchAutomation):
        Browser = BrowserNeeds(size=4, max_uses=1, engine="cloak")

        async def run_one(self, task, ctx):
            async with ctx.browser.acquire(proxy=ctx.proxy_url) as page:
                await page.goto(...)

`fleet_browser` stays an optional install — `BrowserResource.start()` only
imports it when an automation actually declares a `Browser` need.

Design notes:

* The Browser is pooled and pre-warmed at worker boot; SmartRouter is per-
  acquire because each task usually has its own proxy URL (residential
  sticky-session rotation). mitmdump can't be reconfigured mid-flight, so
  pooling it doesn't help — a fresh router per task is cheap (~150 ms).

* Each acquire creates a new Playwright BrowserContext so cookies / storage
  / page state from a previous task can't leak into the next. The cloak
  fingerprint stays at the Browser-launch level, so fingerprint refresh per
  task requires `max_uses=1` (dispose + respawn the Browser between uses).
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, AsyncIterator, Optional

if TYPE_CHECKING:
    from playwright.async_api import Page

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class BrowserNeeds:
    """Declarative browser-pool requirement attached to an automation class.

    The worker boots one ``BrowserResource`` per *unique* ``BrowserNeeds``
    across all loaded automations — automations that declare identical
    needs share a pool.

    Attributes
    ----------
    size : int
        Pool size — number of pre-warmed Browsers kept hot. Lease is
        instant while at least one slot is idle.

    max_uses : int
        How many acquires one Browser handles before being recycled.
        ``1`` = fresh cloak fingerprint per task (recommended against
        Google-class bot walls). Larger values reuse the Browser across
        many tasks, with cookies cleared between (cheaper but the cloak
        seed persists).

    max_age_seconds : float
        Hard recycling window. A Browser past this age is disposed even
        if its use count is below ``max_uses`` — defends against process
        memory leaks.

    engine : str
        Browser engine. ``"auto"`` resolves to ``"cloak"`` when
        cloakbrowser is installed, ``"chrome"`` is stock Playwright
        Chromium.

    headless : bool
        Run headless. Default ``False`` because headed-on-Xvfb beats
        headless for anti-bot fingerprint stability; the framework
        auto-starts a managed Xvfb so the deployment doesn't need to.

    smart_routing : bool
        When ``True`` and the caller passes ``proxy=...`` to ``acquire``,
        a per-task SmartRouter is spun up so paid flows go via curl_cffi
        with a real Chrome JA3. Set ``False`` to bypass the router and
        use the proxy directly (cheaper but loses CDN-family JA3 coherence).
    """

    size: int = 4
    max_uses: int = 1
    max_age_seconds: float = 3600.0
    engine: str = "auto"
    headless: bool = False
    smart_routing: bool = True

    def __post_init__(self) -> None:
        if self.size <= 0:
            raise ValueError("BrowserNeeds.size must be >= 1")
        if self.max_uses <= 0:
            raise ValueError("BrowserNeeds.max_uses must be >= 1")
        if self.max_age_seconds <= 0:
            raise ValueError("BrowserNeeds.max_age_seconds must be > 0")
        if self.engine not in ("auto", "cloak", "chrome"):
            raise ValueError(
                f"BrowserNeeds.engine must be one of auto/cloak/chrome, "
                f"got {self.engine!r}"
            )


@dataclass
class BrowserResource:
    """Process-wide handle wrapping a pre-warmed BrowserPool.

    Constructed by the worker bootstrap (one per unique BrowserNeeds),
    started before any slot runs, stopped on worker shutdown. Plugins
    access it via ``ctx.browser`` and call ``.acquire(proxy=...)`` per
    task.
    """

    needs: BrowserNeeds
    _pool: Any = field(default=None, init=False, repr=False)  # BrowserPool, lazy import
    _started: bool = field(default=False, init=False, repr=False)

    async def start(self) -> None:
        """Pre-warm the underlying BrowserPool.

        Imports fleet_browser lazily so the core stays importable in
        deployments that don't need browser automation.
        """
        if self._started:
            return
        try:
            from fleet_browser import BrowserConfig, make_browser_pool
        except ImportError as e:
            raise RuntimeError(
                "BrowserNeeds declared but fleet_browser is not installed. "
                "Install with: pip install fleet-framework[browser]"
            ) from e

        template = BrowserConfig(
            page_url="about:blank",
            proxy=None,  # Browser launches without proxy; per-acquire context sets it
            engine=self.needs.engine,
            headless=self.needs.headless,
            smart_routing=False,  # we manage SmartRouter per-acquire
        )
        self._pool = make_browser_pool(
            size=self.needs.size,
            config_template=template,
            max_uses=self.needs.max_uses,
            max_age_seconds=self.needs.max_age_seconds,
        )
        await self._pool.start()
        self._started = True
        logger.info(
            "browser-resource started: size=%d max_uses=%d engine=%s",
            self.needs.size, self.needs.max_uses, self.needs.engine,
        )

    async def stop(self) -> None:
        """Dispose every pooled Browser. Idempotent."""
        if not self._started:
            return
        try:
            await self._pool.stop()
        finally:
            self._started = False
            self._pool = None
            logger.info("browser-resource stopped")

    @asynccontextmanager
    async def acquire(
        self, *, proxy: Optional[str] = None,
    ) -> AsyncIterator["Page"]:
        """Lease a Page bound to this task's proxy.

        Implementation: leases a Browser from the pool, spins up a
        per-task SmartRouter (if ``smart_routing`` and a proxy was
        provided), creates a fresh BrowserContext pointed at the router,
        yields a new Page. On exit the context is closed and the router
        stopped; the Browser returns to the pool (or is disposed per
        ``max_uses``).
        """
        if not self._started:
            raise RuntimeError("BrowserResource not started")

        async with self._pool.acquire() as base_page:
            # base_page is the launch-time page from the pool entry; we don't
            # use it directly because it lives in a shared context. New
            # context per acquire = clean cookie/storage isolation.
            browser = base_page.context.browser
            if browser is None:
                raise RuntimeError("pooled page has no parent browser")

            router = None
            proxy_settings: Optional[dict] = None
            ignore_https = False
            if proxy and self.needs.smart_routing:
                from fleet_browser.smart_router import SmartRouter
                router = SmartRouter(upstream_proxy=proxy)
                router.start()
                proxy_settings = {"server": router.proxy_url}
                ignore_https = True  # browser must trust mitm's self-signed CA
            elif proxy:
                proxy_settings = _proxy_settings_from_url(proxy)

            new_ctx = await browser.new_context(
                proxy=proxy_settings,
                ignore_https_errors=ignore_https,
            )
            page = await new_ctx.new_page()
            # Expose the router on the page so callers can read stats /
            # families without having to thread it through.
            try:
                page._smart_router = router  # type: ignore[attr-defined]
            except Exception:
                pass
            try:
                yield page
            finally:
                try:
                    await new_ctx.close()
                except Exception:
                    logger.debug("context close failed", exc_info=True)
                if router is not None:
                    try:
                        router.stop()
                    except Exception:
                        logger.debug("router stop failed", exc_info=True)


def _proxy_settings_from_url(url: str) -> dict:
    """Convert ``http://user:pass@host:port`` into Playwright proxy settings."""
    from urllib.parse import urlparse
    u = urlparse(url)
    server = f"{u.scheme}://{u.hostname}:{u.port or 80}"
    out: dict[str, str] = {"server": server}
    if u.username:
        out["username"] = u.username
        out["password"] = u.password or ""
    return out


class BrowserRegistry:
    """Holds one BrowserResource per unique BrowserNeeds across all loaded
    automations. Built once at worker boot, queried by SlotRunner to attach
    the right resource to each Context."""

    def __init__(self) -> None:
        self._resources: dict[BrowserNeeds, BrowserResource] = {}
        self._started: bool = False

    def register(self, needs: BrowserNeeds) -> BrowserResource:
        """Return the shared resource for these needs, creating one if needed.
        Must be called before ``start_all``."""
        if needs in self._resources:
            return self._resources[needs]
        res = BrowserResource(needs=needs)
        self._resources[needs] = res
        return res

    async def start_all(self) -> None:
        """Pre-warm every registered resource in parallel."""
        if self._started:
            return
        if not self._resources:
            self._started = True
            return
        await asyncio.gather(*(r.start() for r in self._resources.values()))
        self._started = True

    async def stop_all(self) -> None:
        """Stop every resource. Idempotent."""
        if not self._started:
            return
        await asyncio.gather(
            *(r.stop() for r in self._resources.values()),
            return_exceptions=True,
        )
        self._started = False
        self._resources.clear()

    def __len__(self) -> int:
        return len(self._resources)


__all__ = [
    "BrowserNeeds",
    "BrowserRegistry",
    "BrowserResource",
]
