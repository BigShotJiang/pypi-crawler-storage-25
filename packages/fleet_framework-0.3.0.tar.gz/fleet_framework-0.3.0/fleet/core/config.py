from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class BaseConfig(BaseModel):
    # generic fields every automation has. plugin subclasses add domain knobs.
    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    slots: int = Field(default=0, ge=0, le=1024)
    recycle_seconds: int = Field(default=0, ge=0, le=86400)

    max_attempts: int = Field(default=3, ge=1, le=100)
    """Batch automations only: how many times a task is retried before the DLQ."""

    visibility_seconds: int = Field(default=300, ge=10, le=86400)
    """Batch automations only: reservation TTL on dequeued tasks. If the slot
    crashes mid-run_one, the master sweeper requeues after this window."""

    # simple-case proxy. wired into the built-in `static` provider when no
    # provider is named. mutually compatible with proxy_provider/_config.
    proxy_url: str | None = None

    # provider-based proxy. set both fields together. when set, takes
    # precedence over proxy_url.
    proxy_provider: str | None = None
    proxy_provider_config: dict[str, Any] | None = None

    @classmethod
    def restart_fields(cls) -> frozenset[str]:
        return frozenset({"proxy_url", "proxy_provider", "proxy_provider_config"})

    @classmethod
    def reboot_fields(cls) -> frozenset[str]:
        return frozenset()
