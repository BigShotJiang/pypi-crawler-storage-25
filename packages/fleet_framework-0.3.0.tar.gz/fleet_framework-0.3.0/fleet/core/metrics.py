from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from threading import Lock
from typing import Any


@dataclass
class _Counter:
    n: int = 0


@dataclass
class _Gauge:
    v: float = 0.0


@dataclass
class _Histogram:
    samples: deque = field(default_factory=lambda: deque(maxlen=512))


class SlotMetrics:
    # per-slot counters. dumped via WS Stats frames and surfaced on the dashboard.
    def __init__(self) -> None:
        self._lock = Lock()
        self._counters: dict[str, _Counter] = defaultdict(_Counter)
        self._gauges: dict[str, _Gauge] = defaultdict(_Gauge)
        self._hists: dict[str, _Histogram] = defaultdict(_Histogram)
        self._created_at = time.monotonic()

    def incr(self, name: str, by: int = 1) -> None:
        with self._lock:
            self._counters[name].n += by

    def set(self, name: str, value: float) -> None:
        with self._lock:
            self._gauges[name].v = value

    def observe(self, name: str, value: float) -> None:
        with self._lock:
            self._hists[name].samples.append(value)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            counters = {k: v.n for k, v in self._counters.items()}
            gauges = {k: v.v for k, v in self._gauges.items()}
            hists = {}
            for k, h in self._hists.items():
                if not h.samples:
                    continue
                s = sorted(h.samples)
                hists[k] = {
                    "n": len(s),
                    "p50": s[len(s) // 2],
                    "p95": s[int(len(s) * 0.95)],
                    "p99": s[int(len(s) * 0.99)],
                }
        return {"counters": counters, "gauges": gauges, "histograms": hists}
