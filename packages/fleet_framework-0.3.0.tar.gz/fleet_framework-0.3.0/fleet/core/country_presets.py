from __future__ import annotations

# ISO 3166-1 alpha-2. used by proxy providers to resolve string presets to
# concrete country lists. providers stringify the result however they need.

EU_27 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR",
    "DE", "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL",
    "PL", "PT", "RO", "SK", "SI", "ES", "SE",
]
EU_PLUS_GB = EU_27 + ["GB"]
NA = ["US", "CA"]
EU_US = EU_27 + ["US"]
LATAM = ["AR", "BR", "CL", "CO", "MX", "PE", "UY"]
APAC = ["AU", "JP", "KR", "SG", "HK", "TW", "NZ", "MY", "TH", "ID", "PH", "VN"]

_PRESETS: dict[str, list[str]] = {
    "EU": EU_27,
    "EU+UK": EU_PLUS_GB,
    "EU+GB": EU_PLUS_GB,
    "NA": NA,
    "EU+US": EU_US,
    "EU+NA": EU_27 + NA,
    "LATAM": LATAM,
    "APAC": APAC,
    "WORLDWIDE": [],
    "GLOBAL": [],
    "ANY": [],
}


def resolve_countries(spec: str | list[str] | None) -> list[str]:
    # returns uppercase ISO codes. empty list means "no restriction" (worldwide).
    if spec is None:
        return []
    if isinstance(spec, list):
        return [c.strip().upper() for c in spec if c and c.strip()]
    s = spec.strip()
    if not s:
        return []
    key = s.upper()
    if key in _PRESETS:
        return list(_PRESETS[key])
    if "," in s:
        return [p.strip().upper() for p in s.split(",") if p.strip()]
    return [key]


def known_presets() -> list[str]:
    return sorted(_PRESETS.keys())
