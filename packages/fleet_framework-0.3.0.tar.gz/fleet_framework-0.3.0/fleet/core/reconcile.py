from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from fleet.core.config import BaseConfig

# pure-functional diff between observed and desired config. no I/O.
# applied by fleet.worker.reconcile_loop.

ActionKind = Literal[
    "stop_all",
    "cold_start",
    "restart",
    "scale_up",
    "scale_down",
    "restart_pages",
    "noop",
]


@dataclass(frozen=True)
class Action:
    kind: ActionKind
    detail: dict[str, Any] = field(default_factory=dict, hash=False, compare=True)


_BASE_REBOOT = frozenset()  # populated per-config-class via BaseConfig.reboot_fields()
_BASE_RESTART = frozenset({"proxy_url"})


def _diff_fields(observed: BaseConfig, desired: BaseConfig, names: frozenset[str]) -> list[str]:
    return [f for f in names if getattr(observed, f) != getattr(desired, f)]


def diff(observed: BaseConfig, desired: BaseConfig) -> list[Action]:
    # rule 1: disabled wins.
    if not desired.enabled:
        return [Action(kind="stop_all", detail={})]

    # rule 2: cold start.
    if not observed.enabled:
        return [Action(kind="cold_start", detail={"desired": desired})]

    cls = type(desired)
    reboot_fields = _BASE_REBOOT | cls.reboot_fields()
    restart_fields = _BASE_RESTART | cls.restart_fields()

    # rule 3: reboot-class change → full cold restart of the worker (token server etc).
    reboot_changes = _diff_fields(observed, desired, reboot_fields)
    if reboot_changes:
        return [Action(kind="restart", detail={"desired": desired, "changed": reboot_changes})]

    # rule 4 / 5: scale by slot delta.
    delta = desired.slots - observed.slots
    if delta > 0:
        return [Action(kind="scale_up", detail={"delta": delta})]
    if delta < 0:
        return [Action(kind="scale_down", detail={"delta": -delta})]

    # rule 6: restart-class (page-level) change → recycle each slot.
    restart_changes = _diff_fields(observed, desired, restart_fields)
    if restart_changes:
        return [
            Action(kind="restart_pages", detail={"desired": desired, "changed": restart_changes})
        ]

    return [Action(kind="noop", detail={})]


def is_noop(plan: list[Action]) -> bool:
    return len(plan) == 1 and plan[0].kind == "noop"


__all__ = ["Action", "ActionKind", "diff", "is_noop"]
