from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from fleet.core.backend import Backend


@dataclass
class WorkerRec:
    worker_id: str
    automation_type: str
    hardware: dict[str, Any]
    config: dict[str, Any]
    config_gen: int
    state: str
    last_seen: float
    last_error: str | None
    stats: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "worker_id": self.worker_id,
            "automation_type": self.automation_type,
            "hardware": self.hardware,
            "config": self.config,
            "config_gen": self.config_gen,
            "state": self.state,
            "last_seen": self.last_seen,
            "last_error": self.last_error,
            "current_stats": self.stats,
        }


class Store:
    """Master-side facade over Backend that produces WorkerRec objects."""

    def __init__(self, backend: Backend) -> None:
        self._backend = backend

    async def upsert_register(
        self, automation_type: str, worker_id: str, hardware: dict[str, Any]
    ) -> None:
        await self._backend.worker_register(automation_type, worker_id, hardware)

    async def get_config(self, automation_type: str, worker_id: str) -> tuple[dict[str, Any], int]:
        return await self._backend.worker_get_config(automation_type, worker_id)

    async def patch_config(
        self, automation_type: str, worker_id: str, partial: dict[str, Any]
    ) -> tuple[dict[str, Any], int]:
        current, _ = await self._backend.worker_get_config(automation_type, worker_id)
        merged = {**current, **partial}
        return await self._backend.worker_set_config(automation_type, worker_id, merged)

    async def replace_config(
        self, automation_type: str, worker_id: str, full: dict[str, Any]
    ) -> tuple[dict[str, Any], int]:
        return await self._backend.worker_set_config(automation_type, worker_id, full)

    async def report_state(
        self,
        automation_type: str,
        worker_id: str,
        state: str,
        last_error: str | None,
    ) -> None:
        await self._backend.worker_set_state(
            automation_type, worker_id, state, last_error, last_seen=time.time()
        )

    async def report_stats(
        self, automation_type: str, worker_id: str, stats: dict[str, Any]
    ) -> None:
        await self._backend.worker_set_stats(automation_type, worker_id, stats)

    async def get_worker(self, automation_type: str, worker_id: str) -> WorkerRec | None:
        raw = await self._backend.worker_get(automation_type, worker_id)
        if raw is None:
            return None
        return WorkerRec(
            worker_id=worker_id,
            automation_type=automation_type,
            hardware=raw["hardware"],
            config=raw["config"],
            config_gen=raw["config_gen"],
            state=raw["state"],
            last_seen=raw["last_seen"],
            last_error=raw["last_error"],
            stats=raw["stats"],
        )

    async def list_workers(self, automation_type: str | None = None) -> list[WorkerRec]:
        pairs = await self._backend.worker_list(automation_type)
        out: list[WorkerRec] = []
        for at, wid in pairs:
            rec = await self.get_worker(at, wid)
            if rec is not None:
                out.append(rec)
        return out

    async def remove_worker(self, automation_type: str, worker_id: str) -> bool:
        return await self._backend.worker_remove(automation_type, worker_id)
