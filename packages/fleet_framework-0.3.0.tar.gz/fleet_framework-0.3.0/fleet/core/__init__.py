from fleet.core.automation import (
    BaseAutomation,
    BatchAutomation,
    ContinuousAutomation,
    Task,
    catalog_doc,
    get_registry,
    load_entry_points,
    register,
)
from fleet.core.backend import Backend, RedisBackend
from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet.core.contract import Pool, Queue, Stream
from fleet.core.country_presets import known_presets, resolve_countries
from fleet.core.primitives import (
    KV,
    Counter,
    Lock,
    PoolFilter,
    PoolHandle,
    PoolItem,
    QueueHandle,
    StreamReader,
)
from fleet.core.proxy import (
    ProxyHandle,
    ProxyProvider,
    ProxySession,
    build_provider,
    get_provider_registry,
    load_provider_entry_points,
    register_provider,
)

__all__ = [
    "Backend",
    "BaseAutomation",
    "BaseConfig",
    "BatchAutomation",
    "ContinuousAutomation",
    "Context",
    "Counter",
    "KV",
    "Lock",
    "Pool",
    "PoolFilter",
    "PoolHandle",
    "PoolItem",
    "ProxyHandle",
    "ProxyProvider",
    "ProxySession",
    "Queue",
    "QueueHandle",
    "RedisBackend",
    "Stream",
    "StreamReader",
    "Task",
    "build_provider",
    "catalog_doc",
    "get_provider_registry",
    "get_registry",
    "known_presets",
    "load_entry_points",
    "load_provider_entry_points",
    "register",
    "register_provider",
    "resolve_countries",
]
