from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, TypeAdapter

P = TypeVar("P", bound=BaseModel)
T = TypeVar("T", bound=BaseModel)


@dataclass(frozen=True)
class Pool(Generic[P, T]):
    name: str
    payload: type[P]
    tags: type[T]

    def __init__(self, name: str, *, payload: type[P], tags: type[T]) -> None:
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "payload", payload)
        object.__setattr__(self, "tags", tags)

    def json_schema(self) -> dict[str, Any]:
        return {
            "kind": "pool",
            "name": self.name,
            "payload": self.payload.model_json_schema(),
            "tags": self.tags.model_json_schema(),
        }


@dataclass(frozen=True)
class Queue(Generic[P]):
    """Task queue. `name` is the automation_type that consumes from it."""
    name: str
    payload: type[P]

    def __init__(self, name: str, *, payload: type[P]) -> None:
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "payload", payload)

    def json_schema(self) -> dict[str, Any]:
        return {
            "kind": "queue",
            "name": self.name,
            "payload": self.payload.model_json_schema(),
        }


@dataclass(frozen=True)
class Stream(Generic[P]):
    """Output stream. `name` is the automation_type that emits to it."""
    name: str
    payload: type[P]

    def __init__(self, name: str, *, payload: type[P]) -> None:
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "payload", payload)

    def json_schema(self) -> dict[str, Any]:
        return {
            "kind": "stream",
            "name": self.name,
            "payload": self.payload.model_json_schema(),
        }


def validate_tag_filter(tags_type: type[BaseModel], **kwargs: Any) -> dict[str, Any]:
    """Validate kwargs against a Tags model. TypeError on unknown field,
    ValueError on type mismatch. Returns coerced values."""
    fields = tags_type.model_fields
    out: dict[str, Any] = {}
    for k, v in kwargs.items():
        if k not in fields:
            known = ", ".join(sorted(fields.keys())) or "(none)"
            raise TypeError(
                f"unknown tag '{k}' for {tags_type.__name__}; known tags: {known}"
            )
        annotation = fields[k].annotation
        try:
            out[k] = TypeAdapter(annotation).validate_python(v)
        except Exception as e:
            raise ValueError(f"tag '{k}' value {v!r} invalid: {e}") from e
    return out


__all__ = ["Pool", "Queue", "Stream", "validate_tag_filter", "P", "T"]
