"""Logging setup: text or JSON, with contextvars threaded into every record.

Set `FLEET_LOG_FORMAT=json` to emit structured logs. Set `LOG_LEVEL` for the
threshold. Plugins call `bind_log_context(...)` to attach worker_id /
slot_id / automation_type / task_id to records emitted from their slot.
"""

from __future__ import annotations

import contextvars
import json
import logging
import os
from typing import Any

_context: contextvars.ContextVar[dict[str, Any]] = contextvars.ContextVar(
    "_fleet_log_context", default={}
)


def bind_log_context(**kwargs: Any) -> contextvars.Token:
    """Add fields to the current async context's log records.

    Returns a Token; pass it to reset_log_context to roll back.
    """
    merged = {**_context.get(), **kwargs}
    return _context.set(merged)


def reset_log_context(token: contextvars.Token) -> None:
    _context.reset(token)


class _ContextFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        ctx = _context.get()
        for k, v in ctx.items():
            if not hasattr(record, k):
                setattr(record, k, v)
        return True


_STANDARD_LOGRECORD_FIELDS = frozenset({
    "args", "asctime", "created", "exc_info", "exc_text", "filename",
    "funcName", "levelname", "levelno", "lineno", "message", "module",
    "msecs", "msg", "name", "pathname", "process", "processName",
    "relativeCreated", "stack_info", "thread", "threadName",
    "taskName",
})


class _JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        # record.created is seconds-since-epoch float; iso-format with ms precision.
        from datetime import datetime, timezone
        ts = datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(timespec="milliseconds")
        out: dict[str, Any] = {
            "ts": ts,
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info:
            out["exc"] = self.formatException(record.exc_info)
        for k, v in record.__dict__.items():
            if k in _STANDARD_LOGRECORD_FIELDS or k.startswith("_"):
                continue
            out[k] = v
        return json.dumps(out, default=str)


def configure_logging(
    level: str | None = None,
    fmt: str | None = None,
) -> None:
    """Idempotent log setup. Reads LOG_LEVEL and FLEET_LOG_FORMAT from env
    when args are None."""
    lvl = (level or os.environ.get("LOG_LEVEL", "INFO")).upper()
    chosen_fmt = (fmt or os.environ.get("FLEET_LOG_FORMAT", "text")).lower()

    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h)

    handler = logging.StreamHandler()
    if chosen_fmt == "json":
        handler.setFormatter(_JsonFormatter())
    else:
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)s %(name)s: %(message)s"
        ))
    handler.addFilter(_ContextFilter())
    root.addHandler(handler)
    root.setLevel(lvl)


__all__ = ["bind_log_context", "configure_logging", "reset_log_context"]
