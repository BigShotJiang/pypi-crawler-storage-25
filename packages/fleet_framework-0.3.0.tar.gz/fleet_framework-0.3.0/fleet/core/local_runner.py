"""Run an automation in-process without a master/worker/backend stack.

For CLI smoke-tests (`fleet run <type>`) and unit-style integration: spins
up an InMemoryBackend, stubs the event bus, validates payload/config
against the automation's declared schemas, and drives the right entry
point. Each `ctx.emit(...)` is forwarded to an emit callback (stdout by
default).

- BatchAutomation: drives `run_one` once per payload, returns when all done.
- ContinuousAutomation: drives `run_slot` for `duration_seconds` then signals
  shutdown and returns.

Not suitable for production — there's no DLQ, no retries, no observability.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from typing import Any, AsyncIterator, Awaitable, Callable, Optional

from pydantic import BaseModel, ValidationError

from fleet.core.automation import (
    BaseAutomation,
    BatchAutomation,
    ContinuousAutomation,
    Task,
)
from fleet.core.browser import BrowserRegistry
from fleet.core.context import Context
from fleet.core.memory_backend import InMemoryBackend
from fleet.core.metrics import SlotMetrics


class _StubEventBus:
    """No-op event bus for in-process runs. publish/subscribe go nowhere."""

    async def publish(self, topic: str, payload: dict[str, Any]) -> None:
        return None

    async def subscribe(self, topic: str) -> AsyncIterator[dict[str, Any]]:
        if False:
            yield  # type: ignore[unreachable]


def _coerce_payload(cls: type[BaseAutomation], raw: dict[str, Any]) -> BaseModel:
    if cls.TaskPayload is None:
        raise TypeError(
            f"{cls.automation_type}: automation has no TaskPayload schema; "
            "run_local() requires a BatchAutomation"
        )
    try:
        return cls.TaskPayload.model_validate(raw)
    except ValidationError as e:
        raise ValueError(
            f"payload does not match {cls.TaskPayload.__name__} schema: {e}"
        ) from e


async def _default_emit(payload: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(payload, default=str) + "\n")
    sys.stdout.flush()


def _build_context(
    cls: type[BaseAutomation],
    cfg: Any,
    emit_cb: Callable[[dict[str, Any]], Awaitable[None]],
    backend: InMemoryBackend,
    log: logging.Logger,
    worker_id: str,
    slot_id: int = 0,
    browser_registry: Optional[BrowserRegistry] = None,
) -> tuple[Context, asyncio.Event]:
    shutdown = asyncio.Event()
    browser_resource = None
    if browser_registry is not None and cls.Browser is not None:
        browser_resource = browser_registry.register(cls.Browser)
    ctx = Context(
        automation_type=cls.automation_type,
        worker_id=worker_id,
        slot_id=slot_id,
        config=cfg,
        shutdown=shutdown,
        logger=log,
        _emit_raw=emit_cb,
        _backend=backend,
        _events=_StubEventBus(),  # type: ignore[arg-type]
        _metrics=SlotMetrics(),
        _automation_cls=cls,
        browser=browser_resource,
    )
    return ctx, shutdown


async def run_local(
    cls: type[BaseAutomation],
    payloads: list[dict[str, Any]],
    *,
    config: Optional[dict[str, Any]] = None,
    emit: Optional[Callable[[dict[str, Any]], Awaitable[None]]] = None,
    worker_id: str = "local",
    concurrency: int = 1,
    timeout: Optional[float] = None,
    logger: Optional[logging.Logger] = None,
) -> dict[str, int]:
    """Drive `cls.run_one` for each payload in-process.

    Returns a `{ok, failed}` summary. Validation errors raise before any
    task runs; per-task runtime errors are logged and counted as `failed`.
    """
    if not issubclass(cls, BatchAutomation):
        raise TypeError(
            f"{cls.__name__} must be a BatchAutomation to run via run_local "
            f"(got {cls.__mro__[1].__name__})"
        )

    automation = cls()
    backend = InMemoryBackend()
    log = logger or logging.getLogger(cls.automation_type or cls.__name__)

    cfg = cls.Config.model_validate(config or {})

    tasks = [
        Task(id=f"local-{i}", payload=_coerce_payload(cls, p))
        for i, p in enumerate(payloads)
    ]

    emit_cb = emit or _default_emit

    # Provision the browser pool BEFORE building the context so ctx.browser
    # is ready by the time run_one() fires. Plugins that don't declare
    # Browser get a noop registry and ctx.browser stays None.
    browser_registry = BrowserRegistry()
    if cls.Browser is not None:
        browser_registry.register(cls.Browser)
    await browser_registry.start_all()

    ctx, _shutdown = _build_context(
        cls, cfg, emit_cb, backend, log, worker_id,
        browser_registry=browser_registry,
    )

    sem = asyncio.Semaphore(max(1, concurrency))
    ok = 0
    failed = 0

    async def _run_one(task: Task) -> None:
        nonlocal ok, failed
        async with sem:
            try:
                coro = automation.run_one(task, ctx)  # type: ignore[attr-defined]
                if timeout is not None:
                    await asyncio.wait_for(coro, timeout=timeout)
                else:
                    await coro
                ok += 1
            except asyncio.TimeoutError:
                failed += 1
                log.error("task %s timed out after %.1fs", task.id, timeout)
            except Exception as e:
                failed += 1
                log.exception("task %s failed: %s", task.id, e)

    try:
        await asyncio.gather(*(_run_one(t) for t in tasks))
    finally:
        try:
            await automation.cleanup(ctx)
        except Exception:
            log.exception("cleanup() raised")
        await browser_registry.stop_all()
        await backend.aclose()

    return {"ok": ok, "failed": failed}


async def run_local_continuous(
    cls: type[BaseAutomation],
    *,
    duration_seconds: float = 5.0,
    config: Optional[dict[str, Any]] = None,
    emit: Optional[Callable[[dict[str, Any]], Awaitable[None]]] = None,
    worker_id: str = "local",
    slots: int = 1,
    logger: Optional[logging.Logger] = None,
) -> dict[str, int]:
    """Drive `cls.run_slot` for `duration_seconds`, then signal shutdown.

    Spawns `slots` parallel slot coroutines so you can smoke-test
    cross-slot uniqueness (nonces, dedupe locks). Returns `{emits}` once
    all slots have stopped.
    """
    if not issubclass(cls, ContinuousAutomation):
        raise TypeError(
            f"{cls.__name__} must be a ContinuousAutomation to run via "
            f"run_local_continuous (got {cls.__mro__[1].__name__})"
        )

    automation = cls()
    backend = InMemoryBackend()
    log = logger or logging.getLogger(cls.automation_type or cls.__name__)
    cfg = cls.Config.model_validate(config or {})

    emit_count = 0

    async def _counting_emit(payload: dict[str, Any]) -> None:
        nonlocal emit_count
        emit_count += 1
        await (emit or _default_emit)(payload)

    browser_registry = BrowserRegistry()
    if cls.Browser is not None:
        browser_registry.register(cls.Browser)
    await browser_registry.start_all()

    contexts = [
        _build_context(
            cls, cfg, _counting_emit, backend, log, worker_id,
            slot_id=i, browser_registry=browser_registry,
        )
        for i in range(max(1, slots))
    ]

    async def _drive(ctx: Context, shutdown: asyncio.Event) -> None:
        try:
            await automation.run_slot(ctx)  # type: ignore[attr-defined]
        except asyncio.CancelledError:
            pass
        except Exception as e:
            log.exception("slot %d crashed: %s", ctx.slot_id, e)

    coros = [_drive(ctx, sd) for ctx, sd in contexts]
    tasks = [asyncio.create_task(c) for c in coros]

    try:
        await asyncio.sleep(duration_seconds)
    finally:
        for _ctx, sd in contexts:
            sd.set()
        # Give slots a brief grace period to notice shutdown.
        try:
            await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=True), timeout=2.0)
        except asyncio.TimeoutError:
            for t in tasks:
                if not t.done():
                    t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        try:
            await automation.cleanup(contexts[0][0])
        except Exception:
            log.exception("cleanup() raised")
        await browser_registry.stop_all()
        await backend.aclose()

    return {"emits": emit_count}


__all__ = ["run_local", "run_local_continuous"]
