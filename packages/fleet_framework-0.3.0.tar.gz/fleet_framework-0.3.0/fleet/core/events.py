from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from typing import Any

import redis.asyncio as aioredis

# lightweight pub/sub on redis. ephemeral — no persistence. for signals,
# not for work hand-off (use stream.py for that).


class EventBus:
    def __init__(self, r: aioredis.Redis) -> None:
        self._r = r

    async def publish(self, topic: str, payload: dict[str, Any]) -> None:
        await self._r.publish(f"event:{topic}", json.dumps(payload))

    async def subscribe(self, topic: str) -> AsyncIterator[dict[str, Any]]:
        # async generator that yields payloads forever. cancel the consumer
        # task to stop. consumer is responsible for handling backpressure.
        pubsub = self._r.pubsub()
        await pubsub.subscribe(f"event:{topic}")
        try:
            async for msg in pubsub.listen():
                if msg is None or msg.get("type") != "message":
                    continue
                data = msg.get("data")
                if data is None:
                    continue
                try:
                    yield json.loads(data)
                except (json.JSONDecodeError, TypeError):
                    continue
        finally:
            try:
                await pubsub.unsubscribe(f"event:{topic}")
                await pubsub.aclose()
            except Exception:
                pass


async def first(topic: str, bus: EventBus, *, timeout: float = 5.0) -> dict[str, Any] | None:
    # helper for tests / one-shot waits. returns None on timeout.
    async def _consume() -> dict[str, Any]:
        async for ev in bus.subscribe(topic):
            return ev
        raise RuntimeError("unreachable")

    try:
        return await asyncio.wait_for(_consume(), timeout=timeout)
    except asyncio.TimeoutError:
        return None
