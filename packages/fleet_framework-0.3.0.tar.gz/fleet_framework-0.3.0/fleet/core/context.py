from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Generic, Optional, TypeVar

from pydantic import BaseModel

if TYPE_CHECKING:
    from fleet.core.backend import Backend
    from fleet.core.browser import BrowserResource
    from fleet.core.config import BaseConfig
    from fleet.core.contract import Pool, Queue, Stream
    from fleet.core.events import EventBus
    from fleet.core.metrics import SlotMetrics
    from fleet.core.primitives import KV, Counter, Lock, PoolHandle, StreamReader
    from fleet.core.proxy import ProxyHandle

C = TypeVar("C", bound="BaseConfig")
P = TypeVar("P", bound=BaseModel)
T = TypeVar("T", bound=BaseModel)


@dataclass
class Context(Generic[C]):
    # passed into every slot/task callback. owns the lifecycle of one slot.
    automation_type: str
    worker_id: str
    slot_id: int
    config: C
    shutdown: asyncio.Event
    logger: logging.Logger
    _emit_raw: Any  # async (payload_dict) -> None — pushes onto own stream via master
    _backend: "Backend"
    _events: "EventBus"
    _metrics: "SlotMetrics"
    _automation_cls: Any = None  # type[BaseAutomation], set by SlotRunner
    _proxy: Optional["ProxyHandle"] = None
    proxy_url: Optional[str] = None
    browser: Optional["BrowserResource"] = None  # set when automation declares Browser
    extra: dict[str, Any] = field(default_factory=dict)

    # ---- proxy ----
    @property
    def proxy(self) -> "ProxyHandle":
        from fleet.core.proxy import ProxyHandle
        if self._proxy is None:
            self._proxy = ProxyHandle(provider=None, slot_id=self.slot_id)
        return self._proxy

    # ---- own output stream ----
    async def emit(self, payload: BaseModel) -> None:
        # the automation declared `Output = SomePydantic`. validate at the boundary.
        cls = self._automation_cls
        if cls is not None and cls.Output is not None and not isinstance(payload, cls.Output):
            raise TypeError(
                f"{self.automation_type}: emit() expected {cls.Output.__name__}, "
                f"got {type(payload).__name__}"
            )
        if hasattr(payload, "model_dump"):
            await self._emit_raw(payload.model_dump(mode="json"))
        else:
            raise TypeError("emit() requires a Pydantic model")

    # ---- read another automation's stream ----
    def stream(self, spec: "Stream[P]") -> "StreamReader[P]":
        from fleet.core.primitives import StreamReader
        return StreamReader(spec, self._backend)

    # ---- pools ----
    def pool(self, spec: "Pool[P, T]") -> "PoolHandle[P, T]":
        from fleet.core.primitives import PoolHandle
        return PoolHandle(spec, self._backend)

    # ---- submit task to another automation ----
    async def submit(self, spec: "Queue[P]", payload: P, *, task_id: Optional[str] = None) -> str:
        from fleet.core.primitives import QueueHandle
        return await QueueHandle(spec, self._backend).push(payload, task_id=task_id)

    # ---- kv ----
    def kv(self, namespace: str) -> "KV":
        from fleet.core.primitives import KV
        return KV(self._backend, namespace)

    # ---- lock ----
    def lock(self, name: str, *, hold_seconds: int = 30, wait_seconds: float = 5.0) -> "Lock":
        from fleet.core.primitives import Lock
        return Lock(self._backend, name, hold_seconds, wait_seconds)

    # ---- counter ----
    def counter(self, name: str) -> "Counter":
        from fleet.core.primitives import Counter
        return Counter(self._backend, name)

    # ---- event bus ----
    @property
    def events(self) -> "EventBus":
        return self._events

    # ---- metrics ----
    @property
    def metrics(self) -> "SlotMetrics":
        return self._metrics
