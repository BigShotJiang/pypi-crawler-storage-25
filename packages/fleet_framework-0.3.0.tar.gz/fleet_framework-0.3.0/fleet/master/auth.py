from __future__ import annotations

import json
import logging
import os
import secrets

from fastapi import Header, HTTPException

logger = logging.getLogger(__name__)


def _expected(env_name: str, fallback: str | None) -> str:
    val = os.environ.get(env_name) or fallback
    if not val:
        val = secrets.token_hex(16)
        os.environ[env_name] = val
        print(f"[fleet] generated {env_name}={val}")
    return val


def admin_token() -> str:
    return _expected("FLEET_ADMIN_TOKEN", None)


def worker_token() -> str:
    """Primary worker token. Kept for the WS-token check path that needs
    a single canonical value (it always falls back to the first accepted
    one). For request-time auth, use `worker_tokens()` which also accepts
    rotation peers from FLEET_WORKER_TOKENS."""
    return _expected("FLEET_WORKER_TOKEN", None)


def worker_tokens() -> tuple[str, ...]:
    """All currently-valid worker tokens. The primary token from
    FLEET_WORKER_TOKEN is always included; additional rotation tokens
    can be provided via FLEET_WORKER_TOKENS as a comma-separated string
    or a JSON list. During a rotation, set the new token first, roll
    workers across to it, then drop the old one."""
    primary = worker_token()
    extras: list[str] = []
    raw = os.environ.get("FLEET_WORKER_TOKENS")
    if raw:
        raw = raw.strip()
        if raw.startswith("["):
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, list):
                    extras = [t for t in parsed if isinstance(t, str) and t]
            except json.JSONDecodeError:
                logger.warning("FLEET_WORKER_TOKENS is not valid JSON; ignoring")
        else:
            extras = [t.strip() for t in raw.split(",") if t.strip()]
    seen: set[str] = set()
    out: list[str] = []
    for t in (primary, *extras):
        if t not in seen:
            seen.add(t)
            out.append(t)
    return tuple(out)


def _matches_any(token: str, candidates: tuple[str, ...]) -> bool:
    matched = False
    for c in candidates:
        if secrets.compare_digest(token, c):
            matched = True
    return matched


def _token_scopes() -> dict[str, set[str]]:
    """Parse FLEET_TOKEN_SCOPES as a JSON map of token -> list of automation types.

    The admin token implicitly has the wildcard scope `*`. Bad JSON is logged
    and ignored (the admin token still works).
    """
    raw = os.environ.get("FLEET_TOKEN_SCOPES")
    out: dict[str, set[str]] = {admin_token(): {"*"}}
    if not raw:
        return out
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("FLEET_TOKEN_SCOPES is not valid JSON; ignoring")
        return out
    if not isinstance(parsed, dict):
        logger.warning("FLEET_TOKEN_SCOPES must be a JSON object {token: [types]}")
        return out
    for tok, scopes in parsed.items():
        if not isinstance(tok, str) or not isinstance(scopes, list):
            continue
        out[tok] = {s for s in scopes if isinstance(s, str)}
    return out


def _bearer(authorization: str | None) -> str:
    if not authorization:
        raise HTTPException(401, "missing Authorization header")
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Authorization must be Bearer <token>")
    return authorization.split(" ", 1)[1].strip()


async def require_admin(authorization: str | None = Header(default=None)) -> None:
    token = _bearer(authorization)
    if not secrets.compare_digest(token, admin_token()):
        raise HTTPException(403, "invalid token")


async def require_worker(authorization: str | None = Header(default=None)) -> None:
    token = _bearer(authorization)
    if not _matches_any(token, worker_tokens()):
        raise HTTPException(403, "invalid token")


async def require_scope(
    automation_type: str,
    authorization: str | None = Header(default=None),
) -> None:
    token = _bearer(authorization)
    scopes_by_token = _token_scopes()
    # find the token by constant-time compare against each known one
    granted: set[str] | None = None
    for known, scopes in scopes_by_token.items():
        if secrets.compare_digest(token, known):
            granted = scopes
            break
    if granted is None:
        raise HTTPException(403, "invalid token")
    if "*" in granted or automation_type in granted:
        return
    raise HTTPException(403, f"token has no scope for '{automation_type}'")
