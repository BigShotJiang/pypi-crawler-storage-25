from fleet.master.app import create_app

__all__ = ["create_app"]
