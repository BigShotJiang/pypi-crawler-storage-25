"""Prometheus-compatible /metrics endpoint.

Hand-rolled text exposition format. No prometheus_client dependency.
Scraped state lives in Redis (or the in-memory backend); this module
just composes the lines on each scrape.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from fastapi import APIRouter, Response

from fleet.core.automation import get_registry
from fleet.core.backend import Backend
from fleet.core.store import Store

logger = logging.getLogger(__name__)


def _esc(label_value: str) -> str:
    return label_value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _line(name: str, value: float, **labels: str) -> str:
    if not labels:
        return f"{name} {value}"
    pairs = ",".join(f'{k}="{_esc(v)}"' for k, v in sorted(labels.items()))
    return f"{name}{{{pairs}}} {value}"


def make_metrics_router(store: Store, backend: Backend) -> APIRouter:
    router = APIRouter()

    @router.get("/metrics", include_in_schema=False)
    async def metrics() -> Response:
        lines: list[str] = []
        now = time.time()
        registry = get_registry()

        lines.append("# HELP fleet_master_up Master process liveness")
        lines.append("# TYPE fleet_master_up gauge")
        lines.append(_line("fleet_master_up", 1))

        lines.append("# HELP fleet_workers_total Worker count by automation type and state")
        lines.append("# TYPE fleet_workers_total gauge")
        lines.append("# HELP fleet_worker_last_seen_age_seconds Seconds since last_seen heartbeat")
        lines.append("# TYPE fleet_worker_last_seen_age_seconds gauge")
        lines.append("# HELP fleet_worker_slots Slot count last reported by the worker")
        lines.append("# TYPE fleet_worker_slots gauge")
        lines.append("# HELP fleet_worker_cpu_pct Last reported CPU percentage")
        lines.append("# TYPE fleet_worker_cpu_pct gauge")
        lines.append("# HELP fleet_worker_rss_mb Last reported RSS in megabytes")
        lines.append("# TYPE fleet_worker_rss_mb gauge")

        for at in registry:
            recs = await store.list_workers(at)
            by_state: dict[str, int] = {}
            for r in recs:
                by_state[r.state] = by_state.get(r.state, 0) + 1
                lines.append(_line(
                    "fleet_worker_last_seen_age_seconds",
                    max(0.0, now - r.last_seen),
                    automation_type=at, worker_id=r.worker_id,
                ))
                stats: dict[str, Any] = r.stats or {}
                if "slots" in stats:
                    lines.append(_line(
                        "fleet_worker_slots", float(stats["slots"]),
                        automation_type=at, worker_id=r.worker_id,
                    ))
                if "cpu_pct" in stats:
                    lines.append(_line(
                        "fleet_worker_cpu_pct", float(stats["cpu_pct"]),
                        automation_type=at, worker_id=r.worker_id,
                    ))
                if "rss_mb" in stats:
                    lines.append(_line(
                        "fleet_worker_rss_mb", float(stats["rss_mb"]),
                        automation_type=at, worker_id=r.worker_id,
                    ))
            for state, n in by_state.items():
                lines.append(_line(
                    "fleet_workers_total", n,
                    automation_type=at, state=state,
                ))

        lines.append("# HELP fleet_stream_length Output stream depth")
        lines.append("# TYPE fleet_stream_length gauge")
        lines.append("# HELP fleet_queue_size Queue pending count")
        lines.append("# TYPE fleet_queue_size gauge")
        lines.append("# HELP fleet_queue_dlq_length Dead-letter queue length")
        lines.append("# TYPE fleet_queue_dlq_length gauge")

        for at, cls in registry.items():
            try:
                lines.append(_line(
                    "fleet_stream_length",
                    float(await backend.stream_length(at)),
                    automation_type=at,
                ))
            except Exception:
                logger.debug("stream_length failed for %s", at, exc_info=True)
            if cls.TaskPayload is not None:
                try:
                    lines.append(_line(
                        "fleet_queue_size",
                        float(await backend.queue_size(at)),
                        automation_type=at,
                    ))
                    lines.append(_line(
                        "fleet_queue_dlq_length",
                        float(await backend.dlq_length(at)),
                        automation_type=at,
                    ))
                except Exception:
                    logger.debug("queue/dlq size failed for %s", at, exc_info=True)

        pool_names = set()
        for cls in registry.values():
            for ref in (cls.Pools or {}).values():
                pool_names.add(ref.name)
        if pool_names:
            lines.append("# HELP fleet_pool_size Pool item count")
            lines.append("# TYPE fleet_pool_size gauge")
            for name in sorted(pool_names):
                try:
                    lines.append(_line(
                        "fleet_pool_size",
                        float(await backend.pool_size(name)),
                        pool=name,
                    ))
                except Exception:
                    logger.debug("pool_size failed for %s", name, exc_info=True)

        body = "\n".join(lines) + "\n"
        return Response(content=body, media_type="text/plain; version=0.0.4; charset=utf-8")

    return router
