from __future__ import annotations

import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ValidationError

from fleet.core.automation import BaseAutomation, catalog_doc, get_registry
from fleet.core.backend import Backend
from fleet.core.otel import span
from fleet.core.protocol import ConfigChanged, Drain
from fleet.core.store import Store
from fleet.master.auth import require_admin, require_scope, require_worker
from fleet.master.broadcaster import Broadcaster
from fleet.master.ratelimit import RateLimiter, make_token_rate_limit

logger = logging.getLogger(__name__)


class PopRequest(BaseModel):
    n: int = 1


class SubmitRequest(BaseModel):
    payload: dict[str, Any]
    task_id: str | None = None
    max_attempts: int | None = None
    priority: int = 0
    """Higher = more urgent. >0 routes to the high-priority bucket;
    <0 to the low-priority bucket; 0 (default) to the normal bucket."""
    ttl_seconds: int | None = None
    """If set, the task is silently dropped on reserve when older than
    this many seconds. Useful for "act on now or never" events."""
    idempotency_key: str | None = None
    """If set, a second submission with the same (automation_type, key) within
    the idempotency window returns the original task_id without enqueueing."""


def _decode_envelopes(raw_list: list[bytes]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for raw in raw_list:
        try:
            out.append(json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw))
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
    return out


def make_api_router(
    store: Store, broadcaster: Broadcaster, backend: Backend
) -> APIRouter:
    router = APIRouter()
    registry: dict[str, type[BaseAutomation]] = get_registry()
    import os as _os
    submit_rps = float(_os.environ.get("FLEET_SUBMIT_RPS_PER_TOKEN", "0"))
    submit_limiter = RateLimiter(submit_rps)
    submit_rate_dep = make_token_rate_limit(submit_limiter)
    idempotency_ttl = int(_os.environ.get("FLEET_IDEMPOTENCY_TTL_SECONDS", "86400"))

    @router.get("/api/v1/automations", dependencies=[Depends(require_admin)])
    async def list_automations() -> list[dict[str, Any]]:
        return [
            {
                "type": name,
                "class": cls.__name__,
                "config_schema": cls.Config.model_json_schema(),
                "kind": cls.__mro__[1].__name__,
            }
            for name, cls in registry.items()
        ]

    @router.get(
        "/api/v1/automations/{automation_type}/workers",
        dependencies=[Depends(require_scope)],
    )
    async def list_workers(automation_type: str) -> list[dict[str, Any]]:
        _require_type(automation_type, registry)
        recs = await store.list_workers(automation_type)
        return [r.to_dict() for r in recs]

    @router.get(
        "/api/v1/automations/{automation_type}/workers/{worker_id}",
        dependencies=[Depends(require_scope)],
    )
    async def get_worker(automation_type: str, worker_id: str) -> dict[str, Any]:
        _require_type(automation_type, registry)
        rec = await store.get_worker(automation_type, worker_id)
        if rec is None:
            raise HTTPException(404, "worker not found")
        return rec.to_dict()

    @router.patch(
        "/api/v1/automations/{automation_type}/workers/{worker_id}/config",
        dependencies=[Depends(require_scope)],
    )
    async def patch_config(
        automation_type: str, worker_id: str, partial: dict[str, Any]
    ) -> dict[str, Any]:
        cls = _require_type(automation_type, registry)
        current, _ = await store.get_config(automation_type, worker_id)
        merged = {**current, **partial}
        try:
            cls.Config.model_validate(merged)
        except ValidationError as e:
            raise HTTPException(422, f"invalid config: {e}") from e
        cfg, gen = await store.replace_config(automation_type, worker_id, merged)
        await broadcaster.publish(
            automation_type,
            worker_id,
            ConfigChanged(config_gen=gen).model_dump(),
        )
        return {"config": cfg, "config_gen": gen}

    @router.get(
        "/api/v1/automations/{automation_type}/output/length",
        dependencies=[Depends(require_scope)],
    )
    async def stream_len(automation_type: str) -> dict[str, int]:
        _require_type(automation_type, registry)
        return {"length": await backend.stream_length(automation_type)}

    @router.get(
        "/api/v1/automations/{automation_type}/queue",
        dependencies=[Depends(require_scope)],
    )
    async def queue_inspect(automation_type: str, n: int = 20) -> dict[str, Any]:
        _require_type(automation_type, registry)
        items = _decode_envelopes(await backend.queue_peek(automation_type, n))
        length = await backend.queue_size(automation_type)
        return {"length": length, "items": items}

    @router.get(
        "/api/v1/pools/{pool_name}",
        dependencies=[Depends(require_admin)],
    )
    async def pool_inspect(pool_name: str, n: int = 20) -> dict[str, Any]:
        raws = await backend.pool_list(pool_name)
        size = await backend.pool_size(pool_name)
        items: list[dict[str, Any]] = []
        for raw in raws[:n]:
            try:
                payload = json.loads(raw.payload.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                payload = None
            items.append({
                "id": raw.id,
                "tags": raw.tags,
                "payload": payload,
                "expires_at": raw.expires_at,
                "in_use_until": raw.in_use_until,
            })
        return {"size": size, "items": items}

    @router.get(
        "/api/v1/automations/{automation_type}/output/peek",
        dependencies=[Depends(require_scope)],
    )
    async def stream_pk(automation_type: str, n: int = 10) -> list[dict[str, Any]]:
        _require_type(automation_type, registry)
        return _decode_envelopes(await backend.stream_peek(automation_type, n))

    @router.post(
        "/api/v1/automations/{automation_type}/output/pop",
        dependencies=[Depends(require_scope)],
    )
    async def stream_pp(automation_type: str, req: PopRequest) -> list[dict[str, Any]]:
        _require_type(automation_type, registry)
        return _decode_envelopes(await backend.stream_pop(automation_type, req.n))

    @router.get("/api/v1/catalog", dependencies=[Depends(require_admin)])
    async def get_catalog() -> dict[str, Any]:
        return {name: catalog_doc(cls) for name, cls in registry.items()}

    @router.get(
        "/api/v1/catalog/{automation_type}",
        dependencies=[Depends(require_scope)],
    )
    async def get_catalog_one(automation_type: str) -> dict[str, Any]:
        cls = _require_type(automation_type, registry)
        return catalog_doc(cls)

    @router.post(
        "/api/v1/automations/{automation_type}/tasks",
        dependencies=[Depends(require_scope), Depends(submit_rate_dep)],
    )
    async def submit_task(automation_type: str, req: SubmitRequest) -> dict[str, Any]:
        cls = _require_type(automation_type, registry)
        if cls.TaskPayload is None:
            raise HTTPException(
                400,
                f"automation '{automation_type}' did not declare TaskPayload; "
                "only BatchAutomations with a declared task schema accept submissions",
            )
        try:
            cls.TaskPayload.model_validate(req.payload)
        except ValidationError as e:
            raise HTTPException(422, f"invalid task payload: {e}") from e
        tid = req.task_id or uuid.uuid4().hex
        if req.idempotency_key:
            ns = f"idem:{automation_type}"
            claimed = await backend.kv_setnx(
                ns, req.idempotency_key, tid.encode("utf-8"), idempotency_ttl,
            )
            if not claimed:
                existing = await backend.kv_get(ns, req.idempotency_key)
                if existing is not None:
                    return {
                        "task_id": existing.decode("utf-8"),
                        "queued": False,
                        "duplicate": True,
                    }
        import time as _time
        envelope: dict[str, Any] = {
            "id": tid,
            "payload": req.payload,
            "attempt": 0,
            "submitted_at": _time.time(),
        }
        if req.max_attempts is not None:
            envelope["max_attempts"] = req.max_attempts
        if req.ttl_seconds is not None:
            envelope["ttl_seconds"] = req.ttl_seconds
        body = json.dumps(envelope).encode("utf-8")
        with span(
            "api.submit_task",
            automation_type=automation_type,
            task_id=tid,
            priority=req.priority,
        ):
            await backend.queue_push(automation_type, body, priority=req.priority)
        return {"task_id": tid, "queued": True, "priority": req.priority}

    @router.get(
        "/api/v1/automations/{automation_type}/dead",
        dependencies=[Depends(require_scope)],
    )
    async def dlq_peek(automation_type: str, n: int = 50) -> dict[str, Any]:
        _require_type(automation_type, registry)
        items = _decode_envelopes(await backend.dlq_peek(automation_type, n))
        length = await backend.dlq_length(automation_type)
        return {"length": length, "items": items}

    @router.post(
        "/api/v1/automations/{automation_type}/dead/replay",
        dependencies=[Depends(require_scope)],
    )
    async def dlq_replay(automation_type: str, req: PopRequest) -> dict[str, int]:
        _require_type(automation_type, registry)
        popped = await backend.dlq_pop(automation_type, req.n)
        for body in popped:
            try:
                env = json.loads(body.decode("utf-8") if isinstance(body, bytes) else body)
                env["attempt"] = 0  # reset attempts on replay
                body = json.dumps(env).encode("utf-8")
            except Exception:
                pass
            await backend.queue_push(automation_type, body)
        return {"replayed": len(popped)}

    @router.delete(
        "/api/v1/automations/{automation_type}/dead",
        dependencies=[Depends(require_scope)],
    )
    async def dlq_drain(automation_type: str) -> dict[str, int]:
        _require_type(automation_type, registry)
        return {"cleared": await backend.dlq_clear(automation_type)}

    @router.post(
        "/api/v1/automations/{automation_type}/workers/{worker_id}/drain",
        dependencies=[Depends(require_scope)],
    )
    async def drain_worker(automation_type: str, worker_id: str) -> dict[str, Any]:
        _require_type(automation_type, registry)
        rec = await store.get_worker(automation_type, worker_id)
        if rec is None:
            raise HTTPException(404, "worker not found")
        await broadcaster.publish(
            automation_type, worker_id, Drain().model_dump()
        )
        return {"worker_id": worker_id, "drain": "requested"}

    @router.delete(
        "/api/v1/automations/{automation_type}/workers/{worker_id}",
        dependencies=[Depends(require_scope)],
    )
    async def delete_worker(automation_type: str, worker_id: str) -> dict[str, Any]:
        _require_type(automation_type, registry)
        removed = await store.remove_worker(automation_type, worker_id)
        if not removed:
            raise HTTPException(404, "worker not found")
        return {"worker_id": worker_id, "removed": True}

    @router.get(
        "/api/v1/automations/{automation_type}/workers/{worker_id}/stats",
        dependencies=[Depends(require_scope)],
    )
    async def worker_stats_history(
        automation_type: str, worker_id: str, since: float = 0, limit: int = 240
    ) -> list[dict[str, Any]]:
        _require_type(automation_type, registry)
        return await backend.worker_stats_history(
            automation_type, worker_id, since=since, limit=limit,
        )

    @router.get(
        "/api/v1/automations/{automation_type}/workers/{worker_id}/config",
        dependencies=[Depends(require_worker)],
    )
    async def worker_poll(automation_type: str, worker_id: str) -> dict[str, Any]:
        _require_type(automation_type, registry)
        cfg, gen = await store.get_config(automation_type, worker_id)
        return {"config": cfg, "config_gen": gen}

    return router


def _require_type(automation_type: str, registry: dict[str, type[BaseAutomation]]) -> type[BaseAutomation]:
    cls = registry.get(automation_type)
    if cls is None:
        raise HTTPException(404, f"unknown automation type: {automation_type}")
    return cls
