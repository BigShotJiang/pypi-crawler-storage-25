from __future__ import annotations

import asyncio
import json
import logging
from collections import defaultdict
from typing import Any

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class Broadcaster:
    # in-memory worker_id -> set[WebSocket]. one WS per (automation_type, worker_id).
    # used to push ConfigChanged frames after a PATCH.
    def __init__(self) -> None:
        self._sockets: dict[tuple[str, str], set[WebSocket]] = defaultdict(set)
        self._lock = asyncio.Lock()

    async def attach(self, automation_type: str, worker_id: str, ws: WebSocket) -> None:
        async with self._lock:
            self._sockets[(automation_type, worker_id)].add(ws)

    async def detach(self, automation_type: str, worker_id: str, ws: WebSocket) -> None:
        async with self._lock:
            self._sockets.get((automation_type, worker_id), set()).discard(ws)

    async def publish(self, automation_type: str, worker_id: str, frame: dict[str, Any]) -> None:
        payload = json.dumps(frame)
        async with self._lock:
            socks = list(self._sockets.get((automation_type, worker_id), set()))
        for ws in socks:
            try:
                await ws.send_text(payload)
            except Exception:
                logger.debug("ws send failed for %s/%s", automation_type, worker_id)
