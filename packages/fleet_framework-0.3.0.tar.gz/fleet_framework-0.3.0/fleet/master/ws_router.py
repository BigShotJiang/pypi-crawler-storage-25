from __future__ import annotations

import json
import logging
import secrets
import time
import uuid
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from fleet.core.backend import Backend
from fleet.core.protocol import (
    PROTOCOL_VERSION,
    Output,
    Ping,
    ProtocolError,
    Register,
    State,
    Stats,
    decode,
    encode,
)
from fleet.core.store import Store
from fleet.master.auth import worker_tokens
from fleet.master.broadcaster import Broadcaster

logger = logging.getLogger(__name__)


STREAM_DEFAULT_MAX_LEN = 50_000
STREAM_DEFAULT_TTL_SECONDS = 3600


def make_ws_router(store: Store, broadcaster: Broadcaster, backend: Backend) -> APIRouter:
    router = APIRouter()

    @router.websocket("/api/v1/automations/{automation_type}/workers/{worker_id}/control")
    async def control(ws: WebSocket, automation_type: str, worker_id: str) -> None:
        if not _check_ws_token(ws):
            # 4401 = application-level "unauthorized" for WS.
            await ws.close(code=4401)
            return
        await ws.accept()
        await broadcaster.attach(automation_type, worker_id, ws)
        try:
            while True:
                raw = await ws.receive_text()
                try:
                    msg = decode(raw)
                except ProtocolError as e:
                    logger.warning("bad frame from %s/%s: %s", automation_type, worker_id, e)
                    continue
                await _handle(msg, store, backend, automation_type, worker_id, ws)
        except WebSocketDisconnect:
            pass
        finally:
            await broadcaster.detach(automation_type, worker_id, ws)

    return router


def _check_ws_token(ws: WebSocket) -> bool:
    candidates = worker_tokens()
    header = ws.headers.get("authorization") or ""
    if header.lower().startswith("bearer "):
        token = header.split(" ", 1)[1].strip()
        if _matches(token, candidates):
            return True
    qtoken = ws.query_params.get("token")
    if qtoken and _matches(qtoken, candidates):
        return True
    return False


def _matches(token: str, candidates: tuple[str, ...]) -> bool:
    matched = False
    for c in candidates:
        if secrets.compare_digest(token, c):
            matched = True
    return matched


async def _handle(
    msg: Any,
    store: Store,
    backend: Backend,
    automation_type: str,
    worker_id: str,
    ws: WebSocket,
) -> None:
    if isinstance(msg, Register):
        if msg.protocol_version != PROTOCOL_VERSION:
            await ws.close(code=4000, reason="protocol mismatch")
            return
        if msg.fleet_core_version:
            try:
                from importlib.metadata import version as _pkg_version
                master_v = _pkg_version("fleet-core")
            except Exception:
                master_v = ""
            if master_v and _major(master_v) != _major(msg.fleet_core_version):
                logger.warning(
                    "worker %s/%s reports fleet-core %s but master is on %s; "
                    "consider upgrading the worker",
                    automation_type, worker_id, msg.fleet_core_version, master_v,
                )
        await store.upsert_register(automation_type, worker_id, msg.hardware.model_dump())
    elif isinstance(msg, State):
        await store.report_state(automation_type, worker_id, msg.state, msg.last_error)
    elif isinstance(msg, Stats):
        frame = msg.model_dump()
        await store.report_stats(automation_type, worker_id, frame)
        await backend.worker_stats_push(
            automation_type, worker_id,
            ts=float(msg.ts), frame=frame,
        )
    elif isinstance(msg, Output):
        await _push_output(backend, automation_type, msg)
    elif isinstance(msg, Ping):
        await ws.send_text(encode(Ping(id=msg.id)))


async def _push_output(backend: Backend, automation_type: str, msg: Output) -> None:
    now = time.time()
    envelope = json.dumps({
        "id": uuid.uuid4().hex,
        "slot_id": msg.slot_id,
        "ts": now,
        "payload": msg.payload,
    }).encode("utf-8")
    await backend.stream_push(
        automation_type,
        envelope,
        score=now,
        max_len=STREAM_DEFAULT_MAX_LEN,
        ttl_seconds=STREAM_DEFAULT_TTL_SECONDS,
    )


def _major(version: str) -> str:
    return (version.split(".") or [""])[0]
