# dashboard templates + static + router lives here.
from fleet.master.dashboard.router import make_dashboard_router

__all__ = ["make_dashboard_router"]
