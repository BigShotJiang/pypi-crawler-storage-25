from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from fleet.core.automation import get_registry

_HERE = Path(__file__).parent


def make_dashboard_router() -> APIRouter:
    router = APIRouter()
    templates = Jinja2Templates(directory=str(_HERE / "templates"))

    @router.get("/", response_class=HTMLResponse)
    async def index(request: Request) -> HTMLResponse:
        reg = get_registry()
        automations = [
            {
                "type": name,
                "class": cls.__name__,
                "kind": cls.__mro__[1].__name__,
                "schema": cls.Config.model_json_schema(),
            }
            for name, cls in reg.items()
        ]
        return templates.TemplateResponse(
            request, "index.html", {"automations": automations}
        )

    router.mount("/static", StaticFiles(directory=str(_HERE / "static")), name="static")
    return router
