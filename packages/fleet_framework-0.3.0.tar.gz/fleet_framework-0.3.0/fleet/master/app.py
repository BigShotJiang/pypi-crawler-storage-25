from __future__ import annotations

import asyncio
import json
import logging
import os

from fastapi import FastAPI

from fleet.core.automation import catalog_doc, get_registry, load_entry_points
from fleet.core.backend import backend_from_url
from fleet.core.proxy import load_provider_entry_points
from fleet.core.store import Store
from fleet.master.api import make_api_router
from fleet.master.broadcaster import Broadcaster
from fleet.master.dashboard import make_dashboard_router
from fleet.master.metrics_route import make_metrics_router
from fleet.master.ws_router import make_ws_router

logger = logging.getLogger(__name__)


def create_app(backend_url: str | None = None) -> FastAPI:
    # Backwards-compatible: callers passing redis://... still work because
    # backend_from_url handles redis:// natively. New callers can pass
    # memory:// or any registered scheme.
    backend_url = (
        backend_url
        or os.environ.get("FLEET_BACKEND_URL")
        or os.environ.get("REDIS_URL", "redis://localhost:6379/0")
    )
    registry = load_entry_points()
    providers = load_provider_entry_points()
    logger.info("loaded automations: %s", list(registry.keys()))
    logger.info("loaded proxy providers: %s", list(providers.keys()))

    backend = backend_from_url(backend_url)
    store = Store(backend)
    broadcaster = Broadcaster()

    app = FastAPI(title="fleet")
    app.state.store = store
    app.state.backend = backend
    app.state.broadcaster = broadcaster

    # publish the catalog: schemas for every installed automation. dashboards
    # and operators read this; consumers don't need it for typing because they
    # import the same contract refs as the producer.
    @app.on_event("startup")
    async def _publish_catalog() -> None:
        for name, cls in get_registry().items():
            try:
                doc = json.dumps(catalog_doc(cls)).encode("utf-8")
                await backend.catalog_set(name, doc)
            except Exception:
                logger.exception("failed to publish catalog entry for %s", name)

    sweeper_task: "asyncio.Task | None" = None
    worker_ttl_seconds = int(os.environ.get("FLEET_WORKER_IDLE_TTL_SECONDS", "0"))

    @app.on_event("startup")
    async def _start_sweeper() -> None:
        nonlocal sweeper_task
        import time as _time

        async def _loop() -> None:
            while True:
                try:
                    for name in get_registry():
                        moved = await backend.queue_sweep_expired(name)
                        if moved:
                            logger.info("swept %d expired reservation(s) from %s", moved, name)
                    if worker_ttl_seconds > 0:
                        cutoff = _time.time() - worker_ttl_seconds
                        for at in get_registry():
                            for rec in await store.list_workers(at):
                                if rec.last_seen and rec.last_seen < cutoff:
                                    if await store.remove_worker(at, rec.worker_id):
                                        logger.info(
                                            "evicted idle worker %s/%s (last_seen %.0fs ago)",
                                            at, rec.worker_id, _time.time() - rec.last_seen,
                                        )
                except asyncio.CancelledError:
                    raise
                except Exception:
                    logger.exception("queue sweep failed")
                await asyncio.sleep(10)

        sweeper_task = asyncio.create_task(_loop(), name="queue-sweeper")

    @app.on_event("shutdown")
    async def _stop_sweeper() -> None:
        if sweeper_task is not None and not sweeper_task.done():
            sweeper_task.cancel()

    app.include_router(make_api_router(store, broadcaster, backend))
    app.include_router(make_ws_router(store, broadcaster, backend))
    app.include_router(make_metrics_router(store, backend))
    app.include_router(make_dashboard_router())

    @app.get("/healthz")
    async def healthz() -> dict[str, str]:
        return {"status": "ok"}

    return app
