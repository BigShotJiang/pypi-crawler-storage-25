"""Simple per-token sliding-window rate limiter.

Keeps a deque of request timestamps per token. On each call, drops
timestamps older than the window, then either appends + allows or
rejects. In-process state — fine for a single master; if you scale
horizontally, swap for a Redis-backed counter.
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from typing import Deque

from fastapi import Header, HTTPException


class RateLimiter:
    def __init__(self, requests_per_second: float, window_seconds: float = 1.0) -> None:
        self._rps = requests_per_second
        self._window = window_seconds
        self._timestamps: dict[str, Deque[float]] = {}
        self._lock = asyncio.Lock()

    async def check(self, token_key: str) -> None:
        if self._rps <= 0:
            return
        async with self._lock:
            now = time.monotonic()
            dq = self._timestamps.setdefault(token_key, deque())
            cutoff = now - self._window
            while dq and dq[0] < cutoff:
                dq.popleft()
            if len(dq) >= int(self._rps * self._window):
                raise HTTPException(429, "rate limit exceeded")
            dq.append(now)


def _bearer_or_empty(authorization: str | None) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        return ""
    return authorization.split(" ", 1)[1].strip()


def make_token_rate_limit(limiter: RateLimiter):
    """FastAPI dependency factory: rate-limits by bearer token."""

    async def dep(authorization: str | None = Header(default=None)) -> None:
        await limiter.check(_bearer_or_empty(authorization) or "anonymous")

    return dep


__all__ = ["RateLimiter", "make_token_rate_limit"]
