from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable

import websockets
from websockets.exceptions import ConnectionClosed

from fleet.core.protocol import (
    PROTOCOL_VERSION,
    Hardware,
    Output,
    Register,
    State,
    Stats,
    decode,
    encode,
)

logger = logging.getLogger(__name__)


class WSClient:
    # async WS client with auto-reconnect + buffered outbound queue.
    # outbound order is preserved across reconnects. inbound frames are
    # dispatched to on_frame.
    def __init__(
        self,
        url: str,
        worker_token: str,
        automation_type: str,
        worker_id: str,
        hardware: Hardware,
        on_frame: Callable[[Any], Awaitable[None]],
        *,
        max_buffer: int = 1024,
    ) -> None:
        self._url = url
        self._token = worker_token
        self._automation_type = automation_type
        self._worker_id = worker_id
        self._hardware = hardware
        self._on_frame = on_frame
        self._outbox: asyncio.Queue[str] = asyncio.Queue(maxsize=max_buffer)
        self._connected = asyncio.Event()
        self._stop = asyncio.Event()
        self._task: asyncio.Task | None = None

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._run(), name="ws-client")

    async def stop(self) -> None:
        self._stop.set()
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _run(self) -> None:
        backoff = 1.0
        while not self._stop.is_set():
            try:
                async with websockets.connect(
                    self._url,
                    additional_headers=[("Authorization", f"Bearer {self._token}")],
                    open_timeout=10,
                    ping_interval=20,
                    ping_timeout=10,
                ) as ws:
                    logger.info("ws connected %s", self._url)
                    backoff = 1.0
                    self._connected.set()
                    await self._send_register(ws)
                    await self._drain_outbox(ws)
                    reader = asyncio.create_task(self._read_loop(ws))
                    writer = asyncio.create_task(self._write_loop(ws))
                    done, pending = await asyncio.wait(
                        [reader, writer], return_when=asyncio.FIRST_COMPLETED
                    )
                    for t in pending:
                        t.cancel()
            except (ConnectionClosed, OSError, asyncio.TimeoutError) as e:
                logger.warning("ws disconnected: %s", e)
            finally:
                self._connected.clear()
            if self._stop.is_set():
                break
            await asyncio.sleep(min(backoff, 30))
            backoff *= 2

    async def _send_register(self, ws: Any) -> None:
        try:
            from importlib.metadata import version as _pkg_version
            core_version = _pkg_version("fleet-core")
        except Exception:
            core_version = ""
        msg = Register(
            worker_id=self._worker_id,
            automation_type=self._automation_type,
            protocol_version=PROTOCOL_VERSION,
            hardware=self._hardware,
            fleet_core_version=core_version,
        )
        await ws.send(encode(msg))

    async def _drain_outbox(self, ws: Any) -> None:
        # flush anything buffered while we were disconnected.
        while True:
            try:
                msg = self._outbox.get_nowait()
            except asyncio.QueueEmpty:
                return
            try:
                await ws.send(msg)
            except Exception:
                # put it back at the head — best-effort.
                try:
                    self._outbox.put_nowait(msg)
                except asyncio.QueueFull:
                    pass
                raise

    async def _read_loop(self, ws: Any) -> None:
        async for raw in ws:
            try:
                msg = decode(raw)
            except Exception:
                logger.exception("decode failed")
                continue
            try:
                await self._on_frame(msg)
            except Exception:
                logger.exception("on_frame failed")

    async def _write_loop(self, ws: Any) -> None:
        while True:
            msg = await self._outbox.get()
            await ws.send(msg)

    async def send_state(
        self, state: str, config_gen: int, ts: int, last_error: str | None = None
    ) -> None:
        await self._enqueue(State(state=state, config_gen=config_gen, ts=ts, last_error=last_error))

    async def send_stats(self, **kwargs: Any) -> None:
        await self._enqueue(Stats(**kwargs))

    async def send_output(self, slot_id: int, ts: int, payload: dict[str, Any]) -> None:
        await self._enqueue(Output(slot_id=slot_id, ts=ts, payload=payload))

    async def _enqueue(self, msg: Any) -> None:
        try:
            self._outbox.put_nowait(encode(msg))
        except asyncio.QueueFull:
            # drop the oldest to make room — outbox is bounded.
            try:
                self._outbox.get_nowait()
            except asyncio.QueueEmpty:
                pass
            self._outbox.put_nowait(encode(msg))
