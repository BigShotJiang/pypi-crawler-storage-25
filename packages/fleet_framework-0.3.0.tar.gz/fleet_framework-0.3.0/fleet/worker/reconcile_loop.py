from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from fleet.core.config import BaseConfig
from fleet.core.metrics import SlotMetrics
from fleet.core.reconcile import diff, is_noop

logger = logging.getLogger(__name__)


class _Slot:
    # one running automation unit. for ContinuousAutomation this hosts a
    # run_slot() task; for BatchAutomation it's a worker that pulls from the queue.
    def __init__(self, slot_id: int, task: asyncio.Task, started_at: float) -> None:
        self.slot_id = slot_id
        self.task = task
        self.started_at = started_at
        self.shutdown = asyncio.Event()
        self.metrics = SlotMetrics()


class ReconcileLoop:
    # async reconcile loop, generalized from the turnstile farm.
    # owns the lifecycle of slots: cold_start, restart, scale, heal, recycle.
    def __init__(
        self,
        slot_factory: Any,  # (slot_id, config, shutdown_event, metrics) -> asyncio.Task
        config_cls: type[BaseConfig],
    ) -> None:
        self._slot_factory = slot_factory
        self._config_cls = config_cls
        self._observed: BaseConfig = config_cls()
        self._slots: list[_Slot] = []
        self._current_gen: int = -1
        self._apply_lock = asyncio.Lock()
        self._recycle_task: asyncio.Task | None = None
        self._stopping = False
        self._draining = False

    @property
    def slot_count(self) -> int:
        return len(self._slots)

    @property
    def state(self) -> str:
        if self._draining:
            return "DRAINING"
        if self._stopping:
            return "IDLE"
        if self._observed.enabled and self._observed.slots > 0:
            return "RUNNING"
        return "IDLE"

    async def apply(self, desired: BaseConfig, gen: int) -> None:
        if self._draining:
            logger.info("apply gen=%d ignored: draining", gen)
            return
        if gen <= self._current_gen:
            logger.info("apply gen=%d superseded by gen=%d", gen, self._current_gen)
            return
        async with self._apply_lock:
            if gen <= self._current_gen:
                return
            plan = diff(self._observed, desired)
            logger.info("gen=%d plan=%s", gen, [a.kind for a in plan])
            if is_noop(plan):
                self._observed = desired
                self._current_gen = gen
                return
            for action in plan:
                await self._execute(action)
            self._observed = desired
            self._current_gen = gen
            self._ensure_recycle_task()

    async def _execute(self, action: Any) -> None:
        kind = action.kind
        if kind == "stop_all":
            await self._stop_all()
        elif kind == "cold_start":
            await self._cold_start(action.detail["desired"])
        elif kind == "restart":
            await self._stop_all()
            await self._cold_start(action.detail["desired"])
        elif kind == "scale_up":
            await self._scale(self._observed.slots + action.detail["delta"], action.detail.get("desired", self._observed))
        elif kind == "scale_down":
            await self._scale(self._observed.slots - action.detail["delta"], action.detail.get("desired", self._observed))
        elif kind == "restart_pages":
            await self._restart_pages(action.detail["desired"])

    async def _cold_start(self, desired: BaseConfig) -> None:
        self._observed = desired
        await self._spawn_n(desired.slots, desired)

    async def _stop_all(self) -> None:
        old = self._slots[:]
        self._slots.clear()
        for slot in old:
            slot.shutdown.set()
        for slot in old:
            try:
                await asyncio.wait_for(slot.task, timeout=15)
            except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                slot.task.cancel()

    async def _spawn_n(self, n: int, desired: BaseConfig) -> None:
        if n <= 0:
            return
        base = len(self._slots)
        new: list[_Slot] = []
        for i in range(n):
            slot_id = base + i
            metrics = SlotMetrics()
            shutdown = asyncio.Event()
            try:
                task = await self._slot_factory(slot_id, desired, shutdown, metrics)
            except Exception:
                logger.exception("slot factory failed for slot_id=%d", slot_id)
                continue
            slot = _Slot(slot_id, task, time.monotonic())
            slot.shutdown = shutdown
            slot.metrics = metrics
            new.append(slot)
        # stagger started_at so all-recycle-at-once doesn't happen on the first batch.
        recycle_seconds = max(0, desired.recycle_seconds)
        if base == 0 and recycle_seconds > 0 and len(new) > 1:
            now = time.monotonic()
            for i, s in enumerate(new):
                offset = (i * recycle_seconds) / len(new)
                s.started_at = now - offset
        self._slots.extend(new)

    async def _scale(self, target: int, desired: BaseConfig) -> None:
        delta = target - len(self._slots)
        if delta > 0:
            await self._spawn_n(delta, desired)
        elif delta < 0:
            # tear down the oldest first.
            to_remove = sorted(self._slots, key=lambda s: s.started_at)[: -delta]
            keep_ids = {id(s) for s in self._slots if s not in to_remove}
            for slot in to_remove:
                slot.shutdown.set()
            for slot in to_remove:
                try:
                    await asyncio.wait_for(slot.task, timeout=15)
                except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                    slot.task.cancel()
            self._slots = [s for s in self._slots if id(s) in keep_ids]

    async def _restart_pages(self, desired: BaseConfig) -> None:
        # cheap path is currently the same as a full restart of each slot.
        # plugins that want smarter restart (page.get instead of relaunch)
        # can override in future revisions.
        await self._stop_all()
        await self._cold_start(desired)

    def _ensure_recycle_task(self) -> None:
        if self._recycle_task is None or self._recycle_task.done():
            self._recycle_task = asyncio.create_task(self._recycle_loop(), name="recycle-loop")

    async def _recycle_loop(self) -> None:
        try:
            while not self._stopping:
                recycle_seconds = max(0, self._observed.recycle_seconds)
                tick = 30 if recycle_seconds <= 0 else max(1, min(30, recycle_seconds // 4))
                await asyncio.sleep(tick)
                await self._recycle_tick_once()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("recycle loop crashed")
            raise

    async def _recycle_tick_once(self) -> None:
        async with self._apply_lock:
            recycle_seconds = max(0, self._observed.recycle_seconds)
            # recycle oldest aged-out slot.
            if recycle_seconds > 0 and self._slots:
                now = time.monotonic()
                oldest = max(self._slots, key=lambda s: now - s.started_at, default=None)
                if oldest and (now - oldest.started_at) > recycle_seconds:
                    await self._recycle_slot(oldest)
            # heal: replenish dropped slots up to desired count.
            desired = self._observed
            if desired.enabled and desired.slots > 0 and len(self._slots) < desired.slots:
                missing = desired.slots - len(self._slots)
                logger.info("heal: have %d/%d, spawning %d", len(self._slots), desired.slots, missing)
                try:
                    await self._spawn_n(missing, desired)
                except Exception:
                    logger.exception("heal spawn failed; will retry")

    async def _recycle_slot(self, slot: _Slot) -> None:
        logger.info("recycling slot %d", slot.slot_id)
        slot.shutdown.set()
        try:
            await asyncio.wait_for(slot.task, timeout=15)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
            slot.task.cancel()
        if slot in self._slots:
            self._slots.remove(slot)
        # heal step (above) will respawn it next tick.

    async def stop(self) -> None:
        self._stopping = True
        if self._recycle_task is not None:
            self._recycle_task.cancel()
            try:
                await self._recycle_task
            except (asyncio.CancelledError, Exception):
                pass
        await self._stop_all()

    async def drain(self, max_wait_seconds: float = 600.0) -> None:
        """Signal every slot to wind down and wait without aggressive cancel.

        Unlike stop(), there is no 15s hard timeout. Slots see their
        shutdown event and complete the work they are currently holding,
        then exit. Reconcile.apply is a no-op while draining.
        """
        if self._draining:
            return
        self._draining = True
        if self._recycle_task is not None:
            self._recycle_task.cancel()
            try:
                await self._recycle_task
            except (asyncio.CancelledError, Exception):
                pass
        old = self._slots[:]
        self._slots.clear()
        for slot in old:
            slot.shutdown.set()
        for slot in old:
            try:
                await asyncio.wait_for(slot.task, timeout=max_wait_seconds)
            except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                logger.warning("slot %d did not drain within %.0fs, cancelling",
                               slot.slot_id, max_wait_seconds)
                slot.task.cancel()
        self._stopping = True
