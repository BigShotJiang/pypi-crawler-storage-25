from __future__ import annotations

import asyncio
import logging
import os
import platform
import socket
import time
from typing import Any

import httpx
import psutil

from fleet.core.automation import BaseAutomation, load_entry_points
from fleet.core.browser import BrowserRegistry
from fleet.core.protocol import ConfigChanged, Drain, Hardware
from fleet.worker.reconcile_loop import ReconcileLoop
from fleet.worker.slot_runner import SlotRunner
from fleet.worker.ws_client import WSClient

logger = logging.getLogger(__name__)


def _hardware() -> Hardware:
    return Hardware(
        cores=psutil.cpu_count(logical=True) or 1,
        ram_gb=int(round(psutil.virtual_memory().total / 1024 / 1024 / 1024)),
        hostname=socket.gethostname(),
        kernel=platform.release(),
    )


class Agent:
    # the worker top-level. owns ws client, reconcile loop, periodic poll, stats reporter.
    def __init__(
        self,
        automation_type: str,
        worker_id: str,
        master_url: str,
        worker_token: str,
        redis_url: str,
    ) -> None:
        registry = load_entry_points()
        if automation_type not in registry:
            raise SystemExit(f"automation '{automation_type}' not installed. available: {list(registry)}")
        self._auto: BaseAutomation = registry[automation_type]()
        self._auto.automation_type = automation_type
        self._cfg_cls = self._auto.Config
        self._worker_id = worker_id
        self._master_url = master_url.rstrip("/")
        self._worker_token = worker_token
        self._redis_url = redis_url

        # ws + reconcile
        self._ws: WSClient | None = None
        self._reconcile: ReconcileLoop | None = None
        self._slot_runner: SlotRunner | None = None
        self._stop = asyncio.Event()

        # Shared resources for plugins to consume via ctx. Browser pool is
        # the only one for now; future ones (HTTP session, cache, etc.) can
        # follow the same opt-in declaration pattern on BaseAutomation.
        self._browser_registry = BrowserRegistry()
        if self._auto.Browser is not None:
            self._browser_registry.register(self._auto.Browser)

    async def run(self) -> None:
        ws_url = (
            self._master_url.replace("http://", "ws://").replace("https://", "wss://")
            + f"/api/v1/automations/{self._auto.automation_type}/workers/{self._worker_id}/control"
        )
        # Pre-warm shared resources BEFORE accepting slot work.
        await self._browser_registry.start_all()

        self._slot_runner = SlotRunner(
            self._auto, self._worker_id, self._redis_url, self._on_output,
            browser_registry=self._browser_registry,
        )
        self._reconcile = ReconcileLoop(self._slot_runner.make_task, self._cfg_cls)

        self._ws = WSClient(
            url=ws_url,
            worker_token=self._worker_token,
            automation_type=self._auto.automation_type,
            worker_id=self._worker_id,
            hardware=_hardware(),
            on_frame=self._on_frame,
        )
        self._ws.start()

        # initial poll + periodic
        poll_task = asyncio.create_task(self._poll_loop(), name="poll")
        stats_task = asyncio.create_task(self._stats_loop(), name="stats")
        try:
            await self._stop.wait()
        finally:
            poll_task.cancel()
            stats_task.cancel()
            if self._reconcile is not None:
                await self._reconcile.stop()
            if self._ws is not None:
                await self._ws.stop()
            await self._browser_registry.stop_all()

    async def stop(self) -> None:
        self._stop.set()

    async def _on_frame(self, msg: Any) -> None:
        if isinstance(msg, ConfigChanged):
            await self._poll_once()
        elif isinstance(msg, Drain):
            logger.info("drain signal received; gracefully stopping slots")
            if self._reconcile is not None:
                await self._reconcile.drain()
            self._stop.set()

    async def _poll_loop(self) -> None:
        # gentle initial wait so ws has a chance to push.
        await asyncio.sleep(0.5)
        while not self._stop.is_set():
            try:
                await self._poll_once()
            except Exception:
                logger.exception("poll failed")
            await asyncio.sleep(30)

    async def _poll_once(self) -> None:
        if self._reconcile is None:
            return
        url = (
            f"{self._master_url}/api/v1/automations/{self._auto.automation_type}"
            f"/workers/{self._worker_id}/config"
        )
        async with httpx.AsyncClient(timeout=15) as h:
            r = await h.get(url, headers={"Authorization": f"Bearer {self._worker_token}"})
            r.raise_for_status()
            data = r.json()
        try:
            cfg = self._cfg_cls.model_validate(data["config"])
        except Exception:
            logger.exception("config validation failed: %s", data.get("config"))
            return
        await self._reconcile.apply(cfg, int(data["config_gen"]))

    async def _stats_loop(self) -> None:
        proc = psutil.Process(os.getpid())
        while not self._stop.is_set():
            await asyncio.sleep(15)
            if self._ws is None or self._reconcile is None:
                continue
            try:
                cpu = proc.cpu_percent(interval=None)
                rss = int(proc.memory_info().rss / 1024 / 1024)
                metrics: dict[str, Any] = {}
                per_slot: list[dict[str, Any]] = []
                now_mono = time.monotonic()
                for s in getattr(self._reconcile, "_slots", []):
                    snap = s.metrics.snapshot()
                    counters = snap.get("counters", {}) or {}
                    for k, v in counters.items():
                        metrics[f"counter.{k}"] = metrics.get(f"counter.{k}", 0) + v
                    per_slot.append({
                        "slot_id": s.slot_id,
                        "age_seconds": max(0.0, now_mono - s.started_at),
                        "counters": dict(counters),
                    })
                await self._ws.send_stats(
                    slots=self._reconcile.slot_count,
                    cpu_pct=cpu,
                    rss_mb=rss,
                    ts=int(time.time()),
                    metrics=metrics,
                    per_slot=per_slot,
                )
                await self._ws.send_state(
                    state=self._reconcile.state,
                    config_gen=max(self._reconcile._current_gen, 0),
                    ts=int(time.time()),
                )
            except Exception:
                logger.exception("stats emit failed")

    async def _on_output(self, slot_id: int, payload: dict[str, Any]) -> None:
        if self._ws is None:
            return
        await self._ws.send_output(slot_id=slot_id, ts=int(time.time()), payload=payload)
