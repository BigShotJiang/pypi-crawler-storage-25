from __future__ import annotations

from typing import ClassVar

from fleet.core.automation import BatchAutomation, Task
from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet_social.contracts import SocialQuery, SocialResult


class SocialConfig(BaseConfig):
    rate_limit_per_minute: int = 30
    """Default soft cap. Concrete plugins should respect this and the
    network's own rate limits — `429`s + DLQ are bad UX, throttle in
    advance."""


class SocialAutomation(BatchAutomation[SocialConfig]):
    """Abstract base for one SocialQuery in -> one SocialResult out.

    Concrete plugins are usually per-network (`fleet-social-tiktok`,
    `-instagram`, `-x`, `-youtube`, `-linkedin`, `-reddit`, `-pinterest`,
    `-bluesky`, `-threads`, `-mastodon`) and override `run_one` to
    dispatch on `task.payload.kind`.

    Convention: SocialResult's `posts` / `profile` / `profiles` slots
    are populated based on the kind:
      * PROFILE       -> result.profile is set
      * POSTS         -> result.posts is set, result.profile MAY be set
      * POST          -> result.posts has length 1
      * SEARCH        -> result.posts
      * FOLLOWERS /
        FOLLOWING     -> result.profiles
    """

    Config: ClassVar = SocialConfig
    TaskPayload: ClassVar = SocialQuery
    Output: ClassVar = SocialResult

    async def run_one(self, task: Task, ctx: Context) -> None:
        raise NotImplementedError(
            f"{type(self).__name__}.run_one must be overridden — the "
            "abstract SocialAutomation does not call any social network.",
        )
