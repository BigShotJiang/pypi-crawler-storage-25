"""fleet-social — abstract social-media profile / post automation contract.

Covers TikTok, Instagram, YouTube, X, LinkedIn, Reddit, Facebook,
Pinterest, Threads, Bluesky, Mastodon, Snapchat. One contract because
the shape of "profile + posts + engagement" is the same across all of
them — only the IDs and the anti-bot story differ.
"""

from fleet_social.automation import SocialAutomation, SocialConfig
from fleet_social.contracts import (
    MediaKind,
    SocialEngagement,
    SocialMediaAsset,
    SocialNetwork,
    SocialPost,
    SocialProfile,
    SocialQuery,
    SocialQueryKind,
    SocialResult,
)

__all__ = [
    "MediaKind",
    "SocialAutomation",
    "SocialConfig",
    "SocialEngagement",
    "SocialMediaAsset",
    "SocialNetwork",
    "SocialPost",
    "SocialProfile",
    "SocialQuery",
    "SocialQueryKind",
    "SocialResult",
]
