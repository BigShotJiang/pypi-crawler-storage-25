from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, HttpUrl, model_validator


class SocialNetwork(str, Enum):
    TIKTOK = "tiktok"
    INSTAGRAM = "instagram"
    YOUTUBE = "youtube"
    X = "x"
    """Formerly Twitter."""

    LINKEDIN = "linkedin"
    REDDIT = "reddit"
    FACEBOOK = "facebook"
    PINTEREST = "pinterest"
    THREADS = "threads"
    BLUESKY = "bluesky"
    MASTODON = "mastodon"
    SNAPCHAT = "snapchat"


class MediaKind(str, Enum):
    IMAGE = "image"
    VIDEO = "video"
    GIF = "gif"
    AUDIO = "audio"
    """Voice clips on X, audio-only posts."""


class SocialMediaAsset(BaseModel):
    kind: MediaKind
    url: HttpUrl
    width: int | None = Field(default=None, ge=1)
    height: int | None = Field(default=None, ge=1)
    duration_seconds: float | None = Field(default=None, ge=0)
    poster_url: HttpUrl | None = None
    """Thumbnail / poster image for video assets."""


class SocialEngagement(BaseModel):
    likes: int | None = Field(default=None, ge=0)
    comments: int | None = Field(default=None, ge=0)
    shares: int | None = Field(default=None, ge=0)
    """Re-shares / retweets / reposts."""

    views: int | None = Field(default=None, ge=0)
    saves: int | None = Field(default=None, ge=0)
    quotes: int | None = Field(default=None, ge=0)
    """Quote-tweets / quote-posts. Distinct from shares because they
    carry commentary."""


class SocialProfile(BaseModel):
    network: SocialNetwork
    profile_id: str
    """Canonical, stable ID. Use the network's numeric / string ID, not
    the handle — handles can change, IDs don't."""

    handle: str | None = None
    """Display @-handle. None for networks that hide it (Facebook's
    "vanity URL" is the closest equivalent)."""

    display_name: str | None = None
    bio: str | None = None
    avatar_url: HttpUrl | None = None
    cover_url: HttpUrl | None = None
    verified: bool | None = None
    follower_count: int | None = Field(default=None, ge=0)
    following_count: int | None = Field(default=None, ge=0)
    post_count: int | None = Field(default=None, ge=0)
    created_at: datetime | None = None
    url: HttpUrl
    location: str | None = None
    external_links: list[HttpUrl] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class SocialPost(BaseModel):
    network: SocialNetwork
    post_id: str
    """Canonical post id on the network."""

    url: HttpUrl
    author_profile_id: str
    author_handle: str | None = None
    posted_at: datetime
    text: str | None = None
    language: str | None = None
    media: list[SocialMediaAsset] = Field(default_factory=list)
    engagement: SocialEngagement = Field(default_factory=SocialEngagement)
    hashtags: list[str] = Field(default_factory=list)
    mentions: list[str] = Field(default_factory=list)
    reply_to_post_id: str | None = None
    """For threaded networks (X, Reddit, Bluesky, Threads). None for the
    root post or for non-threading networks."""

    repost_of_post_id: str | None = None
    """For shares with no additional text (true retweet). Quotes leave
    this None and put the quoted post's URL in `text` or `raw`."""

    raw: dict[str, Any] = Field(default_factory=dict)


class SocialQueryKind(str, Enum):
    PROFILE = "profile"
    POSTS = "posts"
    """List posts by a profile."""

    POST = "post"
    """Single post details."""

    SEARCH = "search"
    """Keyword / hashtag search. Returns posts."""

    FOLLOWERS = "followers"
    """List a profile's followers. Most networks heavily rate-limit this
    or expose only the first N — plugins should document their cap."""

    FOLLOWING = "following"


class SocialQuery(BaseModel):
    network: SocialNetwork
    kind: SocialQueryKind

    handle_or_profile_id: str | None = None
    post_url: HttpUrl | None = None
    """For kind=POST. Either post_url or post_id is required."""

    post_id: str | None = None
    query: str | None = None
    """Required for kind=SEARCH. Hashtag (with leading #) or keyword."""

    limit: int = Field(default=50, ge=1, le=1000)
    since: datetime | None = None
    """Plugins should only emit posts >= this timestamp when present.
    Useful for incremental crawls."""

    device: Literal["desktop", "mobile"] = "desktop"

    @model_validator(mode="after")
    def _kind_requires(self) -> "SocialQuery":
        k = self.kind
        if k in (SocialQueryKind.PROFILE, SocialQueryKind.POSTS,
                 SocialQueryKind.FOLLOWERS, SocialQueryKind.FOLLOWING):
            if not self.handle_or_profile_id:
                raise ValueError(f"kind={k.value} requires `handle_or_profile_id`")
        if k == SocialQueryKind.POST:
            if not (self.post_url or self.post_id):
                raise ValueError("kind=post requires `post_url` or `post_id`")
        if k == SocialQueryKind.SEARCH and not self.query:
            raise ValueError("kind=search requires `query`")
        return self


class SocialResult(BaseModel):
    query: SocialQuery
    profile: SocialProfile | None = None
    """Populated when kind=PROFILE or as a side-effect of POSTS (some
    networks return the author profile alongside the post list)."""

    posts: list[SocialPost] = Field(default_factory=list)
    profiles: list[SocialProfile] = Field(default_factory=list)
    """Populated when kind=FOLLOWERS / FOLLOWING."""

    next_page_token: str | None = None
    raw: dict[str, Any] = Field(default_factory=dict)
