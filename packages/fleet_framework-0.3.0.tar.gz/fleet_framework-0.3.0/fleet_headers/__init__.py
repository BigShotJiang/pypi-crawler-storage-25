"""fleet-headers — typed browser-header profiles for fleet plugins.

A `HeaderProfile` bundles the UA + Sec-CH-UA + Accept* values that need to
move together for an HTTP request to look like a real browser of a given
flavour. Plugins that hit anti-bot-protected endpoints over plain HTTP use
this to keep their headers consistent without re-deriving the table from
scratch.

The profile catalog is intentionally small — chrome / firefox / safari at
recent major versions, desktop only. Add new entries by registering with
`register_profile()` from your plugin code.
"""

from fleet_headers.profiles import (
    HeaderProfile,
    all_profiles,
    get_profile,
    headers_for,
    register_profile,
)

__all__ = [
    "HeaderProfile",
    "all_profiles",
    "get_profile",
    "headers_for",
    "register_profile",
]
