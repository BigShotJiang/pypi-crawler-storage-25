from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class HeaderProfile(BaseModel):
    """A bundle of headers that move together for one browser identity.

    `impersonate_target` is the matching `curl_cffi` impersonation tag — set
    it when this profile has a curl_cffi equivalent so callers can swap
    between requests-and-curl_cffi cleanly. None means "no curl_cffi target,
    use the headers as-is over httpx".
    """

    name: str = Field(min_length=1)
    user_agent: str
    sec_ch_ua: str
    sec_ch_ua_mobile: Literal["?0", "?1"] = "?0"
    sec_ch_ua_platform: str
    accept: str = (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,image/apng,*/*;q=0.8,"
        "application/signed-exchange;v=b3;q=0.7"
    )
    accept_language: str = "en-US,en;q=0.9"
    accept_encoding: str = "gzip, deflate, br, zstd"
    impersonate_target: str | None = None


_REGISTRY: dict[str, HeaderProfile] = {}


def register_profile(profile: HeaderProfile) -> None:
    _REGISTRY[profile.name] = profile


def get_profile(name: str) -> HeaderProfile:
    if name not in _REGISTRY:
        raise KeyError(f"unknown header profile: {name!r}. known: {sorted(_REGISTRY)}")
    return _REGISTRY[name]


def all_profiles() -> list[HeaderProfile]:
    return list(_REGISTRY.values())


def headers_for(
    profile: HeaderProfile,
    *,
    referer: str | None = None,
    fetch_mode: Literal["navigate", "cors", "no-cors", "same-origin"] = "navigate",
    fetch_site: Literal["none", "same-origin", "same-site", "cross-site"] = "none",
    fetch_dest: Literal["document", "empty", "image", "script", "style"] = "document",
) -> dict[str, str]:
    """Materialize the profile + Sec-Fetch-* headers into a request dict.

    Sec-Fetch-* defaults match a top-level navigation. Override per request
    when issuing same-origin XHR / fetch / image requests so the chain looks
    realistic to anti-bot systems that validate these.
    """
    out: dict[str, str] = {
        "User-Agent": profile.user_agent,
        "Sec-CH-UA": profile.sec_ch_ua,
        "Sec-CH-UA-Mobile": profile.sec_ch_ua_mobile,
        "Sec-CH-UA-Platform": profile.sec_ch_ua_platform,
        "Accept": profile.accept,
        "Accept-Language": profile.accept_language,
        "Accept-Encoding": profile.accept_encoding,
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Mode": fetch_mode,
        "Sec-Fetch-Site": fetch_site,
        "Sec-Fetch-Dest": fetch_dest,
    }
    if referer:
        out["Referer"] = referer
    return out


# Seed catalog. Conservative selection — adding a profile should be a
# deliberate decision in a plugin's startup, not a guess in this file.

register_profile(HeaderProfile(
    name="chrome_124_win",
    user_agent=(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    sec_ch_ua='"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
    sec_ch_ua_platform='"Windows"',
    impersonate_target="chrome124",
))

register_profile(HeaderProfile(
    name="chrome_124_mac",
    user_agent=(
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    sec_ch_ua='"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
    sec_ch_ua_platform='"macOS"',
    impersonate_target="chrome124",
))

register_profile(HeaderProfile(
    name="firefox_125_win",
    user_agent=(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) "
        "Gecko/20100101 Firefox/125.0"
    ),
    sec_ch_ua="",  # firefox doesn't send these
    sec_ch_ua_platform="",
    accept=(
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,*/*;q=0.8"
    ),
    impersonate_target=None,
))

register_profile(HeaderProfile(
    name="safari_17_mac",
    user_agent=(
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
        "(KHTML, like Gecko) Version/17.4 Safari/605.1.15"
    ),
    sec_ch_ua="",  # safari doesn't send these
    sec_ch_ua_platform="",
    accept_encoding="gzip, deflate, br",
    impersonate_target="safari17_0",
))
