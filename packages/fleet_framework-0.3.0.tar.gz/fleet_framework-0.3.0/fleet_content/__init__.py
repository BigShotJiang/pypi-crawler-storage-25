"""fleet-content — abstract URL -> extracted content automation contract.

Defines the Pydantic schemas (ContentRequest as TaskPayload,
ExtractedContent as Output) and an abstract BatchAutomation base for any
"give me one URL, get back cleaned text/markdown/screenshot/pdf" plugin.

Concrete plugins (fleet-content-readability, fleet-content-screenshot,
fleet-content-pdfgen) subclass `ContentAutomation`, register a name, and
implement `run_one` against whichever extraction engine they prefer.
"""

from fleet_content.automation import ContentAutomation
from fleet_content.contracts import (
    ContentRequest,
    ExtractedContent,
    ExtractMode,
)

__all__ = [
    "ContentAutomation",
    "ContentRequest",
    "ExtractedContent",
    "ExtractMode",
]
