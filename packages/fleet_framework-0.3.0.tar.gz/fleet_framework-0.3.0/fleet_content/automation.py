from __future__ import annotations

from typing import ClassVar

from fleet.core.automation import BatchAutomation, Task
from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet_content.contracts import ContentRequest, ExtractedContent


class ContentConfig(BaseConfig):
    """Default config for content-extraction plugins. Concrete plugins
    subclass and add their own fields (e.g. browser binary path, max
    concurrent renders, output bucket URL)."""

    pass


class ContentAutomation(BatchAutomation[ContentConfig]):
    """Abstract base for any URL -> extracted content batch automation.

    Concrete plugins subclass this, set `Config` (optionally to a tighter
    subtype), and override `run_one`. They MUST `@register("...")` to
    appear in the fleet registry — the abstract base intentionally does
    not register itself so multiple concrete plugins can coexist.

    Conventions:
      * On success, push the ExtractedContent into ctx.emit (so it lands
        in the output stream) AND/OR into a pool if downstream consumers
        will claim by tags.
      * On failure, raise — the slot runner will nack with exponential
        backoff and DLQ after `Config.max_attempts`.
    """

    Config: ClassVar = ContentConfig
    TaskPayload: ClassVar = ContentRequest
    Output: ClassVar = ExtractedContent

    async def run_one(self, task: Task, ctx: Context) -> None:
        raise NotImplementedError(
            f"{type(self).__name__}.run_one must be overridden — the "
            "abstract ContentAutomation does not perform extraction itself.",
        )
