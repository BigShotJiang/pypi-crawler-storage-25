from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl


class ExtractMode(str, Enum):
    READABILITY = "readability"
    """Newspaper-style article extraction: title + author + cleaned body."""

    DOM_TO_MARKDOWN = "dom_to_markdown"
    """Full page DOM rendered to markdown — preserves headings + tables +
    code blocks, drops scripts / nav / footer."""

    SCREENSHOT = "screenshot"
    """Render and return a PNG. `screenshot_url` in the result is a link
    or data URI depending on the plugin."""

    PDF = "pdf"
    """Render and return a PDF."""

    RAW_HTML = "raw_html"
    """Return the page HTML after JS execution. No cleaning."""


class ContentRequest(BaseModel):
    url: HttpUrl
    mode: ExtractMode = ExtractMode.READABILITY
    wait_for_selector: str | None = None
    """If the page is JS-rendered, the plugin will wait for this CSS
    selector before extracting. None = use the plugin's default heuristic
    (usually `domcontentloaded` + a short settle delay)."""

    timeout_seconds: int = Field(default=30, ge=1, le=600)
    render_js: bool = True
    """False means "fetch as HTML, no browser". Plugins that don't drive
    a browser ignore this field."""

    proxy_hint: str | None = None
    """Optional override for the worker's proxy. Concrete plugins decide
    whether to honour it; useful for "this one URL needs a residential
    IP" overrides."""

    user_agent: str | None = None
    """Override the User-Agent for this request. None = let the plugin
    decide (typically a fleet-headers profile)."""

    extra_headers: dict[str, str] = Field(default_factory=dict)


class ExtractedContent(BaseModel):
    request_url: str
    final_url: str
    """May differ from request_url due to redirects. Plugins should record
    the post-redirect URL so duplicate detection works."""

    status: int
    title: str | None = None
    author: str | None = None
    published_at: datetime | None = None
    lang: str | None = None
    """BCP 47 language tag, e.g. "en", "en-US", "tr"."""

    markdown: str | None = None
    text: str | None = None
    html: str | None = None
    screenshot_url: str | None = None
    pdf_url: str | None = None

    word_count: int | None = None
    image_urls: list[str] = Field(default_factory=list)
    fetched_at: datetime
    raw: dict[str, Any] = Field(default_factory=dict)
