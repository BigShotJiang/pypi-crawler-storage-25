"""Replay helpers: turn a HarvestResult into a pre-configured async HTTP client.

Cloudflare ties the clearance cookie to the (IP, UA, Sec-CH-UA-*) tuple
that earned it. Replaying with the wrong combination earns a fresh
challenge. These helpers wire result.cookies + result.headers into the
client so the downstream scraper sends byte-identical headers.
"""

from __future__ import annotations

from typing import Any, Optional
from urllib.parse import urlparse

from fleet_cloudflare.harvest import HarvestResult


def _cookie_domain(url: str) -> str:
    host = urlparse(url).hostname or ""
    return host.lstrip(".")


def replay_with_httpx(
    result: HarvestResult,
    target_url: str,
    *,
    proxy: Optional[str] = None,
    timeout: float = 30.0,
) -> Any:
    """Return an `httpx.AsyncClient` configured with the harvested cookie + headers.

    Apply `result.cookies` scoped to the target URL's host, set
    `result.headers` as defaults, and optionally route through a proxy
    (typically the same one the harvester used; CF binds clearance to
    the egress IP).
    """
    import httpx

    domain = _cookie_domain(target_url)
    cookies = httpx.Cookies()
    for name, value in (result.cookies or {}).items():
        cookies.set(name, value, domain=domain, path="/")
    return httpx.AsyncClient(
        headers={**(result.headers or {})},
        cookies=cookies,
        timeout=timeout,
        proxy=proxy,
        follow_redirects=True,
    )


def replay_with_curl_cffi(
    result: HarvestResult,
    target_url: str,
    *,
    proxy: Optional[str] = None,
    timeout: float = 30.0,
    impersonate: str = "chrome",
) -> Any:
    """Return a `curl_cffi.requests.AsyncSession` configured the same way.

    Requires `curl_cffi` installed by the caller. Useful when the target
    inspects TLS/JA3 — curl_cffi's `impersonate=` flag matches Chrome's
    fingerprint at the TLS layer, which a vanilla httpx client can't.
    """
    try:
        from curl_cffi.requests import AsyncSession
    except ImportError as e:
        raise RuntimeError(
            "replay_with_curl_cffi requires `pip install curl_cffi`"
        ) from e

    domain = _cookie_domain(target_url)
    sess = AsyncSession(impersonate=impersonate, timeout=timeout)
    sess.headers.update(result.headers or {})
    for name, value in (result.cookies or {}).items():
        sess.cookies.set(name, value, domain=domain, path="/")
    if proxy:
        sess.proxies = {"http": proxy, "https": proxy}
    return sess


__all__ = ["replay_with_curl_cffi", "replay_with_httpx"]
