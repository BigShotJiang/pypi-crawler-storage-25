"""Drive a Chromium page through a CF challenge, return cf_clearance."""

from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from fleet_cloudflare.bypasser import (
    CloudflareBypasser,
    install_shadow_tracker,
    is_challenge_page,
)

logger = logging.getLogger(__name__)


async def _extract_cookies(page: Any) -> list[dict[str, str]]:
    try:
        raw = await page.context.cookies()
    except Exception:
        return []
    out: list[dict[str, str]] = []
    for c in raw or []:
        name = c.get("name", "")
        value = c.get("value", "")
        if name:
            out.append({"name": name, "value": value})
    return out


def _has_clearance(cookies: list[dict[str, str]]) -> bool:
    return any(c["name"] == "cf_clearance" for c in cookies)


def _cookies_to_dict(cookies: list[dict[str, str]]) -> dict[str, str]:
    return {c["name"]: c["value"] for c in cookies}


_UA_OS_MAP: tuple[tuple[str, str], ...] = (
    ("Windows NT", "Windows"),
    ("Macintosh", "macOS"),
    ("Mac OS X", "macOS"),
    ("Android", "Android"),
    ("iPhone", "iOS"),
    ("iPad", "iOS"),
    ("Linux", "Linux"),
)


def headers_for_ua(user_agent: str) -> dict[str, str]:
    """Low-entropy client hints Chrome sends alongside this UA.

    Returned with the cookie so downstream HTTP clients can replay
    byte-identical headers without CF flagging a UA/CH mismatch.
    """
    if not user_agent:
        return {}
    m = re.search(r"Chrome/(\d+)", user_agent)
    major = m.group(1) if m else ""
    platform = next(
        (name for token, name in _UA_OS_MAP if token in user_agent), "Unknown"
    )
    mobile = "?1" if ("Mobile" in user_agent or "Android" in user_agent) else "?0"
    headers = {
        "user-agent": user_agent,
        "accept-language": "en-US,en;q=0.9",
        "sec-ch-ua-mobile": mobile,
        "sec-ch-ua-platform": f'"{platform}"',
    }
    if major:
        headers["sec-ch-ua"] = (
            f'"Chromium";v="{major}", '
            f'"Google Chrome";v="{major}", '
            f'"Not_A Brand";v="24"'
        )
    return headers


async def _user_agent(page: Any) -> str:
    try:
        return await page.evaluate("() => navigator.userAgent")
    except Exception:
        return ""


@dataclass
class HarvestResult:
    success: bool
    cookies: dict[str, str] = field(default_factory=dict)
    user_agent: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    error: Optional[str] = None
    message: Optional[str] = None
    time_taken_s: float = 0.0


async def harvest_clearance(
    page: Any,
    url: str,
    timeout: float = 30.0,
) -> HarvestResult:
    """Drive a browser through a CF challenge and return cf_clearance.

    Always returns a HarvestResult; never raises for user-input issues.
    Caller decides whether to retry on `success=False` failures.
    """
    start = time.monotonic()
    await install_shadow_tracker(page)

    try:
        await page.goto(url, timeout=int(timeout * 1000), wait_until="domcontentloaded")
    except Exception as e:
        msg = str(e).lower()
        code = (
            "PROXY_ERROR"
            if any(k in msg for k in ("proxy", "tunnel", "err_proxy"))
            else "BROWSER_ERROR"
        )
        return _failure(code, f"navigation failed: {e}", start)

    cookies = await _extract_cookies(page)
    if _has_clearance(cookies):
        return await _success(page, cookies, start)

    title_deadline = time.monotonic() + min(timeout, 10)
    while time.monotonic() < title_deadline:
        try:
            title = await page.title() or ""
        except Exception:
            title = ""
        if is_challenge_page(title):
            return await _run_bypasser(page, start, timeout)
        cookies = await _extract_cookies(page)
        if _has_clearance(cookies):
            return await _success(page, cookies, start)
        if title:
            break
        await asyncio.sleep(0.2)

    cookies = await _extract_cookies(page)
    if _has_clearance(cookies):
        return await _success(page, cookies, start)
    try:
        title_now = await page.title() or ""
    except Exception:
        title_now = ""
    if is_challenge_page(title_now):
        return await _run_bypasser(page, start, timeout)
    return _failure(
        "NO_CHALLENGE", "no CF challenge detected on this URL", start
    )


async def _run_bypasser(page: Any, start: float, timeout: float) -> HarvestResult:
    bypasser = CloudflareBypasser(page, click_delay=1.0, log=False)
    deadline = start + timeout
    while time.monotonic() < deadline:
        cookies = await _extract_cookies(page)
        if _has_clearance(cookies):
            return await _success(page, cookies, start)
        if await bypasser.is_bypassed():
            cookies = await _extract_cookies(page)
            if _has_clearance(cookies):
                return await _success(page, cookies, start)
            return _failure(
                "NO_CHALLENGE",
                "challenge page cleared but no cf_clearance cookie",
                start,
            )
        await bypasser.click_verification_button()
        await asyncio.sleep(bypasser.click_delay)
    return _failure(
        "TIMEOUT", f"challenge not solved within {timeout}s", start
    )


async def _success(
    page: Any, cookies: list[dict[str, str]], start: float
) -> HarvestResult:
    ua = await _user_agent(page)
    return HarvestResult(
        success=True,
        cookies=_cookies_to_dict(cookies),
        user_agent=ua,
        headers=headers_for_ua(ua),
        time_taken_s=time.monotonic() - start,
    )


def _failure(code: str, message: str, start: float) -> HarvestResult:
    return HarvestResult(
        success=False,
        error=code,
        message=message,
        time_taken_s=time.monotonic() - start,
    )


__all__ = [
    "HarvestResult",
    "harvest_clearance",
    "headers_for_ua",
]
