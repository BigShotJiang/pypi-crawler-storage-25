"""Solver-protocol wrapper around harvest_clearance.

Implements `fleet_browser.solver.Solver[HarvestResult]` so a dispatcher
can fan out across multiple anti-bot systems uniformly.
"""

from __future__ import annotations

from typing import Any

from fleet_cloudflare.bypasser import is_challenge_page
from fleet_cloudflare.harvest import HarvestResult, harvest_clearance


class CloudflareSolver:
    name = "cloudflare"

    def detect(self, page: Any) -> bool:
        try:
            return is_challenge_page(page.title or "")
        except Exception:
            return False

    def solve(self, page: Any, target: str, timeout: float = 30.0) -> HarvestResult:
        return harvest_clearance(page, target, timeout=timeout)


__all__ = ["CloudflareSolver"]
