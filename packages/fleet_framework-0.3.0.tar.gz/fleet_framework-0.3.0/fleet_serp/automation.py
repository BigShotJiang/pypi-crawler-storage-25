from __future__ import annotations

from typing import ClassVar

from fleet.core.automation import BatchAutomation, Task
from fleet.core.config import BaseConfig
from fleet.core.context import Context
from fleet_serp.contracts import SerpQuery, SerpResult


class SerpConfig(BaseConfig):
    """Default config for SERP plugins. Concrete plugins subclass to add
    engine-specific knobs (e.g. API key for paid engines, scroll page
    count for engines that infinite-scroll instead of paginate)."""

    default_locale: str = "en-US"
    default_country: str = "US"
    use_proxy: bool = True
    """Most plugins should leave this on — searching from a residential
    IP and a sensible UA together make a search look like a person's,
    which keeps friction scores low."""


class SerpAutomation(BatchAutomation[SerpConfig]):
    """Abstract base for "one query in, one result page out" plugins.

    A concrete plugin (`fleet-serp-google`, `fleet-serp-bing`, etc.)
    subclasses this and overrides `run_one`. Engines that paginate
    naturally can ignore `next_page_token`; engines that don't expose a
    page count and instead expose an opaque continuation token should
    populate it.

    The contract is symmetric per query: one task in -> one SerpResult
    out. Multi-page traversal is the caller's job — submit one task per
    page, possibly using the previous result's `next_page_token` as the
    next task's query.page or query.q seed.
    """

    Config: ClassVar = SerpConfig
    TaskPayload: ClassVar = SerpQuery
    Output: ClassVar = SerpResult

    async def run_one(self, task: Task, ctx: Context) -> None:
        raise NotImplementedError(
            f"{type(self).__name__}.run_one must be overridden — the "
            "abstract SerpAutomation does not call any search engine.",
        )
