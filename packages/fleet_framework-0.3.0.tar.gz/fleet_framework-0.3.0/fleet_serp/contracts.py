from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, HttpUrl


class SerpEngine(str, Enum):
    GOOGLE = "google"
    BING = "bing"
    DUCKDUCKGO = "duckduckgo"
    YANDEX = "yandex"
    BAIDU = "baidu"
    NAVER = "naver"
    BRAVE = "brave"
    KAGI = "kagi"
    ECOSIA = "ecosia"


class SerpVertical(str, Enum):
    WEB = "web"
    IMAGES = "images"
    NEWS = "news"
    VIDEOS = "videos"
    SHOPPING = "shopping"
    MAPS = "maps"


class SerpResultType(str, Enum):
    ORGANIC = "organic"
    AD = "ad"
    FEATURED_SNIPPET = "featured_snippet"
    KNOWLEDGE_PANEL = "knowledge_panel"
    PEOPLE_ALSO_ASK = "people_also_ask"
    RELATED_SEARCH = "related_search"
    NEWS = "news"
    IMAGE = "image"
    VIDEO = "video"
    SHOPPING = "shopping"
    LOCAL_PACK = "local_pack"
    TWEET = "tweet"


class Sitelink(BaseModel):
    title: str
    url: HttpUrl
    snippet: str | None = None


class SerpQuery(BaseModel):
    q: str = Field(min_length=1)
    engine: SerpEngine = SerpEngine.GOOGLE
    vertical: SerpVertical = SerpVertical.WEB
    locale: str = "en-US"
    """BCP47, e.g. 'en-US', 'tr-TR'. Plugins translate to engine-specific
    `hl`/`gl`/`mkt` params."""

    country: str = "US"
    """ISO-3166-1 alpha-2, e.g. 'US', 'GB', 'TR'."""

    device: Literal["desktop", "mobile"] = "desktop"
    page: int = Field(default=1, ge=1, le=100)
    num: int = Field(default=10, ge=1, le=100)
    safe: bool = True
    site_restrict: str | None = None
    """Restrict to one domain, e.g. 'wikipedia.org'. Engine equivalent of
    `site:wikipedia.org` operator."""

    time_range: Literal["any", "day", "week", "month", "year"] = "any"


class SerpResultRow(BaseModel):
    rank: int = Field(ge=1)
    """1-indexed position within the page. Ads and organic share one rank
    space — sort by rank to get the visual order on the page."""

    type: SerpResultType
    title: str
    url: HttpUrl
    displayed_url: str | None = None
    snippet: str | None = None
    favicon_url: HttpUrl | None = None
    sitelinks: list[Sitelink] = Field(default_factory=list)
    rich_attributes: dict[str, Any] = Field(default_factory=dict)
    """Type-specific extras: knowledge panel facts, video duration,
    news source name, etc. Concrete plugins populate this; consumers
    should treat it as best-effort."""


class SerpResult(BaseModel):
    query: SerpQuery
    engine_response_time_ms: int | None = None
    total_results_estimate: int | None = None
    rows: list[SerpResultRow] = Field(default_factory=list)
    next_page_token: str | None = None
    """Opaque token for the next page. None if the result is exhausted or
    if the engine does not expose a token (most do; use `query.page + 1`)."""

    raw: dict[str, Any] = Field(default_factory=dict)
