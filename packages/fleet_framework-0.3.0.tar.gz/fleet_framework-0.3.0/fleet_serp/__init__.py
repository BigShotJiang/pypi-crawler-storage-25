"""fleet-serp — abstract Search Engine Result Page automation contract.

Defines SerpQuery (TaskPayload) and SerpResult (Output) so any concrete
engine plugin (fleet-serp-google, fleet-serp-bing, fleet-serp-ddg, ...)
returns the same shape. Consumers can swap engines without changing the
downstream parsing code.
"""

from fleet_serp.automation import SerpAutomation, SerpConfig
from fleet_serp.contracts import (
    SerpEngine,
    SerpQuery,
    SerpResult,
    SerpResultRow,
    SerpResultType,
    SerpVertical,
    Sitelink,
)

__all__ = [
    "SerpAutomation",
    "SerpConfig",
    "SerpEngine",
    "SerpQuery",
    "SerpResult",
    "SerpResultRow",
    "SerpResultType",
    "SerpVertical",
    "Sitelink",
]
