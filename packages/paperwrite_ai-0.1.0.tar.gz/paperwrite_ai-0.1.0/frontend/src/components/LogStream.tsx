'use client';

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { Filter, Trash2, ArrowDown } from 'lucide-react';
import type { LogEntry } from '@/lib/types';

interface LogStreamProps {
  logs: LogEntry[];
  maxHeight?: string;
  onClear?: () => void;
}

const MAX_DISPLAYED_ENTRIES = 500;

const LEVEL_STYLES = {
  info: 'text-green-400',
  warning: 'text-yellow-400',
  error: 'text-red-400',
};

const LEVEL_BG = {
  info: '',
  warning: 'bg-amber-900/10',
  error: 'bg-red-900/10',
};

export default function LogStream({
  logs,
  maxHeight = '400px',
  onClear,
}: LogStreamProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [agentFilter, setAgentFilter] = useState<string>('all');
  const [levelFilter, setLevelFilter] = useState<string>('all');

  const agentTypes = useMemo(() => {
    const set = new Set(logs.map((l) => l.agent_id));
    return Array.from(set).sort();
  }, [logs]);

  const filteredLogs = useMemo(() => {
    const filtered = logs.filter((log) => {
      if (agentFilter !== 'all' && log.agent_id !== agentFilter) return false;
      if (levelFilter !== 'all' && log.level !== levelFilter) return false;
      return true;
    });
    // Limit to MAX_DISPLAYED_ENTRIES
    if (filtered.length > MAX_DISPLAYED_ENTRIES) {
      return filtered.slice(filtered.length - MAX_DISPLAYED_ENTRIES);
    }
    return filtered;
  }, [logs, agentFilter, levelFilter]);

  useEffect(() => {
    if (autoScroll && containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [filteredLogs, autoScroll]);

  function handleScroll() {
    if (!containerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = containerRef.current;
    const isAtBottom = scrollHeight - scrollTop - clientHeight < 40;
    setAutoScroll(isAtBottom);
  }

  function scrollToBottom() {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
      setAutoScroll(true);
    }
  }

  function formatTimestamp(ts: string): string {
    try {
      const d = new Date(ts);
      return d.toLocaleTimeString('en-US', { hour12: false });
    } catch {
      return ts;
    }
  }

  return (
    <div
      className="flex flex-col bg-slate-900 rounded-lg border border-slate-700 overflow-hidden font-mono"
      style={{ maxHeight }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-800 border-b border-slate-700 flex-shrink-0">
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-slate-400" />
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Logs
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Agent Filter */}
          <select
            value={agentFilter}
            onChange={(e) => setAgentFilter(e.target.value)}
            className="text-xs bg-slate-700 border border-slate-600 rounded px-2 py-1 text-slate-300 focus:outline-none focus:border-indigo-500"
          >
            <option value="all">All Agents</option>
            {agentTypes.map((agent) => (
              <option key={agent} value={agent}>
                {agent}
              </option>
            ))}
          </select>

          {/* Level Filter */}
          <select
            value={levelFilter}
            onChange={(e) => setLevelFilter(e.target.value)}
            className="text-xs bg-slate-700 border border-slate-600 rounded px-2 py-1 text-slate-300 focus:outline-none focus:border-indigo-500"
          >
            <option value="all">All Levels</option>
            <option value="info">Info</option>
            <option value="warning">Warning</option>
            <option value="error">Error</option>
          </select>

          {/* Clear */}
          {onClear && (
            <button
              onClick={onClear}
              className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-slate-300 transition-colors"
              title="Clear logs"
            >
              <Trash2 size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Log Entries */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto log-stream min-h-0 bg-slate-800"
      >
        {filteredLogs.length === 0 ? (
          <div className="flex items-center justify-center h-full text-sm text-slate-500">
            No log entries
          </div>
        ) : (
          filteredLogs.map((log, idx) => (
            <div
              key={idx}
              className={`log-entry level-${log.level} flex items-start gap-2 px-3 py-1 text-xs hover:bg-slate-800/50 ${LEVEL_BG[log.level]}`}
            >
              <span className="text-slate-500 flex-shrink-0">
                [{formatTimestamp(log.timestamp)}]
              </span>
              <span
                className={`font-semibold flex-shrink-0 uppercase ${LEVEL_STYLES[log.level]}`}
              >
                {log.level}
              </span>
              <span className="text-indigo-400 flex-shrink-0 truncate max-w-[140px]">
                [{log.agent_id}]
              </span>
              <span className="text-slate-300 break-all">{log.message}</span>
            </div>
          ))
        )}
      </div>

      {/* Scroll-to-bottom indicator */}
      {!autoScroll && (
        <button
          onClick={scrollToBottom}
          className="absolute bottom-14 right-4 p-2 bg-indigo-600 rounded-full shadow-lg hover:bg-indigo-500 transition-colors"
          title="Scroll to bottom"
        >
          <ArrowDown size={14} />
        </button>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between px-3 py-1 bg-slate-800 border-t border-slate-700 flex-shrink-0">
        <span className="text-xs text-slate-500">
          {filteredLogs.length} entries
          {filteredLogs.length !== logs.length &&
            ` (${logs.length} total)`}
        </span>
        {autoScroll && (
          <span className="text-xs text-indigo-400">Auto-scroll enabled</span>
        )}
      </div>
    </div>
  );
}
