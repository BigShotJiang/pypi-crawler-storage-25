'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Trash2,
  GripVertical,
  Eye,
  EyeOff,
  Loader2,
  AlertCircle,
  CheckCircle,
} from 'lucide-react';
import { projectsApi, type CreateProjectPayload } from '@/lib/api';
import type { Section, ApiKeys } from '@/lib/types';

const DEFAULT_SECTIONS: Section[] = [
  { title: 'Introduction' },
  { title: 'Background' },
  { title: 'Motivation' },
  { title: 'Overview' },
  { title: 'Method' },
  { title: 'Implementation' },
  { title: 'Evaluation' },
  { title: 'Discussion' },
  { title: 'Related Work' },
  { title: 'Conclusion' },
];

const TEMPLATES = [
  { value: 'ieee_conference', label: 'IEEE Conference' },
  { value: 'ieee_journal', label: 'IEEE Journal' },
  { value: 'acm_conference', label: 'ACM Conference' },
  { value: 'generic', label: 'Generic' },
];

const MODELS = [
  { value: 'gpt-4o', label: 'GPT-4o (OpenAI)' },
  { value: 'claude-3-opus', label: 'Claude 3 Opus (Anthropic)' },
  { value: 'gemini-pro', label: 'Gemini Pro (Google)' },
  { value: 'deepseek-chat', label: 'DeepSeek Chat' },
];

const STEPS = [
  { label: 'Topic & Abstract', number: 1 },
  { label: 'Outline', number: 2 },
  { label: 'Configuration', number: 3 },
  { label: 'API Keys', number: 4 },
];

export default function ProjectForm() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Step 1
  const [topic, setTopic] = useState('');
  const [abstractIdea, setAbstractIdea] = useState('');

  // Step 2
  const [sections, setSections] = useState<Section[]>(DEFAULT_SECTIONS);
  const [newSectionTitle, setNewSectionTitle] = useState('');

  // Step 3
  const [pageCount, setPageCount] = useState(12);
  const [template, setTemplate] = useState('ieee_conference');
  const [defaultModel, setDefaultModel] = useState('gpt-4o');

  // Step 4
  const [apiKeys, setApiKeys] = useState<ApiKeys>({
    openai: '',
    anthropic: '',
    google: '',
    deepseek: '',
    tavily: '',
  });
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});

  function addSection() {
    if (newSectionTitle.trim()) {
      setSections([...sections, { title: newSectionTitle.trim() }]);
      setNewSectionTitle('');
    }
  }

  function removeSection(idx: number) {
    setSections(sections.filter((_, i) => i !== idx));
  }

  function moveSection(idx: number, direction: 'up' | 'down') {
    const newIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (newIdx < 0 || newIdx >= sections.length) return;
    const newSections = [...sections];
    [newSections[idx], newSections[newIdx]] = [
      newSections[newIdx],
      newSections[idx],
    ];
    setSections(newSections);
  }

  function updateSectionTitle(idx: number, title: string) {
    const newSections = [...sections];
    newSections[idx] = { ...newSections[idx], title };
    setSections(newSections);
  }

  function toggleShowKey(key: string) {
    setShowKeys((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  function updateApiKey(key: keyof ApiKeys, value: string) {
    setApiKeys((prev) => ({ ...prev, [key]: value }));
  }

  function canProceed(): boolean {
    switch (step) {
      case 1:
        return topic.trim().length > 0;
      case 2:
        return sections.length > 0;
      case 3:
        return pageCount > 0;
      case 4:
        return (
          (apiKeys.openai?.trim() || '') !== '' ||
          (apiKeys.anthropic?.trim() || '') !== '' ||
          (apiKeys.google?.trim() || '') !== '' ||
          (apiKeys.deepseek?.trim() || '') !== ''
        );
      default:
        return false;
    }
  }

  async function handleSubmit() {
    if (!canProceed()) return;

    setSubmitting(true);
    setError(null);

    const cleanKeys: ApiKeys = {};
    if (apiKeys.openai?.trim()) cleanKeys.openai = apiKeys.openai.trim();
    if (apiKeys.anthropic?.trim()) cleanKeys.anthropic = apiKeys.anthropic.trim();
    if (apiKeys.google?.trim()) cleanKeys.google = apiKeys.google.trim();
    if (apiKeys.deepseek?.trim()) cleanKeys.deepseek = apiKeys.deepseek.trim();
    if (apiKeys.tavily?.trim()) cleanKeys.tavily = apiKeys.tavily.trim();

    const payload: CreateProjectPayload = {
      topic: topic.trim(),
      abstract_idea: abstractIdea.trim() || undefined,
      outline: sections,
      page_count: pageCount,
      template,
      config: {
        api_keys: cleanKeys,
        default_model: defaultModel,
      },
    };

    try {
      const response = await projectsApi.create(payload);
      const projectId = response.data.id;
      router.push(`/project/${projectId}`);
    } catch (err: any) {
      setError(
        err.response?.data?.detail ||
          err.message ||
          'Failed to create project'
      );
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Step Indicator */}
      <div className="flex items-center justify-center gap-0 mb-8">
        {STEPS.map((s, idx) => (
          <React.Fragment key={s.number}>
            <button
              onClick={() => {
                if (s.number < step) setStep(s.number);
              }}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                step === s.number
                  ? 'bg-indigo-600 text-white'
                  : step > s.number
                  ? 'bg-indigo-900/50 text-indigo-300 hover:bg-indigo-900/70 cursor-pointer'
                  : 'bg-slate-800 text-slate-500 cursor-default'
              }`}
            >
              <span
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step > s.number
                    ? 'bg-indigo-500 text-white'
                    : step === s.number
                    ? 'bg-white text-indigo-600'
                    : 'bg-slate-700 text-slate-400'
                }`}
              >
                {step > s.number ? (
                  <CheckCircle size={14} />
                ) : (
                  s.number
                )}
              </span>
              <span className="hidden sm:inline">{s.label}</span>
            </button>
            {idx < STEPS.length - 1 && (
              <div
                className={`w-8 h-0.5 ${
                  step > s.number ? 'bg-indigo-500' : 'bg-slate-700'
                }`}
              />
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-6 p-3 bg-red-900/30 border border-red-700 rounded-lg flex items-center gap-2">
          <AlertCircle size={16} className="text-red-400 flex-shrink-0" />
          <span className="text-sm text-red-300">{error}</span>
        </div>
      )}

      {/* Step Content */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
        {/* Step 1: Topic & Abstract */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-100 mb-1">
                Topic & Abstract
              </h2>
              <p className="text-sm text-slate-400">
                Describe your paper topic and provide an optional abstract idea.
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Paper Topic <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., Multi-Agent Systems for Automated Scientific Paper Writing"
                className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Abstract Idea
                <span className="text-slate-500 text-xs ml-2">(optional)</span>
              </label>
              <textarea
                value={abstractIdea}
                onChange={(e) => setAbstractIdea(e.target.value)}
                placeholder="Briefly describe the core idea, approach, and expected contributions..."
                rows={5}
                className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors resize-none"
              />
            </div>
          </div>
        )}

        {/* Step 2: Outline Editor */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-100 mb-1">
                Paper Outline
              </h2>
              <p className="text-sm text-slate-400">
                Organize the sections of your paper. Add, remove, or reorder as needed.
              </p>
            </div>

            <div className="space-y-2">
              {sections.map((section, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 group"
                >
                  <GripVertical
                    size={16}
                    className="text-slate-600 flex-shrink-0"
                  />
                  <span className="text-xs text-slate-500 w-6 text-right flex-shrink-0">
                    {idx + 1}.
                  </span>
                  <input
                    type="text"
                    value={section.title}
                    onChange={(e) => updateSectionTitle(idx, e.target.value)}
                    className="flex-1 px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => moveSection(idx, 'up')}
                      disabled={idx === 0}
                      className="p-1 text-slate-400 hover:text-slate-200 disabled:opacity-30"
                      title="Move up"
                    >
                      <ChevronLeft size={14} className="rotate-90" />
                    </button>
                    <button
                      onClick={() => moveSection(idx, 'down')}
                      disabled={idx === sections.length - 1}
                      className="p-1 text-slate-400 hover:text-slate-200 disabled:opacity-30"
                      title="Move down"
                    >
                      <ChevronRight size={14} className="rotate-90" />
                    </button>
                    <button
                      onClick={() => removeSection(idx)}
                      className="p-1 text-slate-400 hover:text-red-400"
                      title="Remove section"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newSectionTitle}
                onChange={(e) => setNewSectionTitle(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addSection()}
                placeholder="New section title..."
                className="flex-1 px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
              />
              <button
                onClick={addSection}
                disabled={!newSectionTitle.trim()}
                className="flex items-center gap-1 px-3 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg text-sm font-medium transition-colors"
              >
                <Plus size={14} />
                Add
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Configuration */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-100 mb-1">
                Configuration
              </h2>
              <p className="text-sm text-slate-400">
                Set the paper format and generation preferences.
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Page Count
              </label>
              <input
                type="number"
                value={pageCount}
                onChange={(e) =>
                  setPageCount(Math.max(1, parseInt(e.target.value) || 1))
                }
                min={1}
                max={100}
                className="w-32 px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Paper Template
              </label>
              <select
                value={template}
                onChange={(e) => setTemplate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
              >
                {TEMPLATES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Default Model
              </label>
              <select
                value={defaultModel}
                onChange={(e) => setDefaultModel(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
              >
                {MODELS.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* Step 4: API Keys */}
        {step === 4 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-100 mb-1">
                API Keys
              </h2>
              <p className="text-sm text-slate-400">
                Provide API keys for the AI models and services you want to use.
                At least one LLM API key is required.
              </p>
            </div>

            {(
              [
                {
                  key: 'openai' as const,
                  label: 'OpenAI',
                  placeholder: 'sk-...',
                },
                {
                  key: 'anthropic' as const,
                  label: 'Anthropic',
                  placeholder: 'sk-ant-...',
                },
                {
                  key: 'google' as const,
                  label: 'Google (Gemini)',
                  placeholder: 'AIza...',
                },
                {
                  key: 'deepseek' as const,
                  label: 'DeepSeek',
                  placeholder: 'sk-...',
                },
                {
                  key: 'tavily' as const,
                  label: 'Tavily (Search)',
                  placeholder: 'tvly-...',
                },
              ] as const
            ).map(({ key, label, placeholder }) => (
              <div key={key}>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  {label} API Key
                  {key !== 'tavily' && (
                    <span className="text-slate-500 text-xs ml-2">
                      (LLM provider)
                    </span>
                  )}
                </label>
                <div className="relative">
                  <input
                    type={showKeys[key] ? 'text' : 'password'}
                    value={apiKeys[key] || ''}
                    onChange={(e) => updateApiKey(key, e.target.value)}
                    placeholder={placeholder}
                    className="w-full px-3 py-2 pr-10 bg-slate-900 border border-slate-600 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors font-mono text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => toggleShowKey(key)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-300"
                  >
                    {showKeys[key] ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
            ))}

            {!canProceed() && (
              <div className="p-3 bg-amber-900/20 border border-amber-700/50 rounded-lg">
                <p className="text-sm text-amber-300 flex items-center gap-2">
                  <AlertCircle size={14} />
                  At least one LLM API key is required to proceed.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between mt-6">
        <button
          onClick={() => setStep((s) => Math.max(1, s - 1))}
          disabled={step === 1}
          className="flex items-center gap-1 px-4 py-2 rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
        >
          <ChevronLeft size={16} />
          Back
        </button>

        {step < 4 ? (
          <button
            onClick={() => setStep((s) => s + 1)}
            disabled={!canProceed()}
            className="flex items-center gap-1 px-6 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg text-sm font-medium transition-colors"
          >
            Next
            <ChevronRight size={16} />
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            disabled={!canProceed() || submitting}
            className="flex items-center gap-2 px-6 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg text-sm font-medium transition-colors"
          >
            {submitting ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                Creating...
              </>
            ) : (
              'Create Project'
            )}
          </button>
        )}
      </div>
    </div>
  );
}
