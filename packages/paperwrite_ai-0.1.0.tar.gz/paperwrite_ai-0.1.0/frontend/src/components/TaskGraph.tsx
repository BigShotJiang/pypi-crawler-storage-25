'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import type { TaskNode as TaskNodeType } from '@/lib/types';
import {
  FileText,
  Search,
  Cpu,
  FlaskConical,
  PenTool,
  CheckCircle,
  BarChart3,
  AlertCircle,
  Clock,
  Play,
  Loader2,
  XCircle,
} from 'lucide-react';

// Attempt to load ReactFlow - if not available we fall back to CSS grid view
let ReactFlowModule: any = null;
try {
  ReactFlowModule = require('reactflow');
  require('reactflow/dist/style.css');
} catch {
  // ReactFlow not available, will use CSS fallback
}

interface TaskGraphProps {
  tasks: TaskNodeType[];
}

// -------------------------------------------------------------------
// Status color mappings (shared between both views)
// -------------------------------------------------------------------

const STATUS_COLORS: Record<
  string,
  { bg: string; border: string; text: string; tailwind: string }
> = {
  pending: {
    bg: '#1e293b',
    border: '#475569',
    text: '#94a3b8',
    tailwind: 'bg-slate-800 border-slate-600 text-slate-400',
  },
  idle: {
    bg: '#1e293b',
    border: '#475569',
    text: '#94a3b8',
    tailwind: 'bg-slate-800 border-slate-600 text-slate-400',
  },
  running: {
    bg: '#312e81',
    border: '#6366f1',
    text: '#c7d2fe',
    tailwind: 'bg-indigo-900/50 border-indigo-500 text-indigo-200',
  },
  in_progress: {
    bg: '#312e81',
    border: '#6366f1',
    text: '#c7d2fe',
    tailwind: 'bg-indigo-900/50 border-indigo-500 text-indigo-200',
  },
  completed: {
    bg: '#14532d',
    border: '#22c55e',
    text: '#bbf7d0',
    tailwind: 'bg-emerald-900/50 border-emerald-500 text-emerald-200',
  },
  done: {
    bg: '#14532d',
    border: '#22c55e',
    text: '#bbf7d0',
    tailwind: 'bg-emerald-900/50 border-emerald-500 text-emerald-200',
  },
  failed: {
    bg: '#450a0a',
    border: '#ef4444',
    text: '#fecaca',
    tailwind: 'bg-red-900/50 border-red-500 text-red-200',
  },
  error: {
    bg: '#450a0a',
    border: '#ef4444',
    text: '#fecaca',
    tailwind: 'bg-red-900/50 border-red-500 text-red-200',
  },
};

function getStatusColor(status: string) {
  return STATUS_COLORS[status] || STATUS_COLORS.pending;
}

// -------------------------------------------------------------------
// Helper: get icon for agent/task type
// -------------------------------------------------------------------

function getTypeIcon(type: string): React.ReactNode {
  const lower = type.toLowerCase();
  if (lower.includes('research') || lower.includes('search'))
    return <Search size={14} />;
  if (lower.includes('method') || lower.includes('compute'))
    return <Cpu size={14} />;
  if (lower.includes('experiment') || lower.includes('test'))
    return <FlaskConical size={14} />;
  if (lower.includes('writ') || lower.includes('draft'))
    return <PenTool size={14} />;
  if (lower.includes('review') || lower.includes('check'))
    return <CheckCircle size={14} />;
  if (lower.includes('figure') || lower.includes('chart') || lower.includes('plot'))
    return <BarChart3 size={14} />;
  return <FileText size={14} />;
}

function getStatusIcon(status: string): React.ReactNode {
  const normalized = status.toLowerCase();
  if (normalized === 'pending' || normalized === 'idle')
    return <Clock size={12} className="text-slate-400" />;
  if (normalized === 'running' || normalized === 'in_progress')
    return <Loader2 size={12} className="text-indigo-400 animate-spin" />;
  if (normalized === 'completed' || normalized === 'done')
    return <CheckCircle size={12} className="text-emerald-400" />;
  if (normalized === 'failed' || normalized === 'error')
    return <XCircle size={12} className="text-red-400" />;
  return <Clock size={12} className="text-slate-400" />;
}

function getStatusBadgeClass(status: string): string {
  const normalized = status.toLowerCase();
  if (normalized === 'pending' || normalized === 'idle')
    return 'bg-slate-700 text-slate-400';
  if (normalized === 'running' || normalized === 'in_progress')
    return 'bg-indigo-900/60 text-indigo-300';
  if (normalized === 'completed' || normalized === 'done')
    return 'bg-emerald-900/60 text-emerald-300';
  if (normalized === 'failed' || normalized === 'error')
    return 'bg-red-900/60 text-red-300';
  return 'bg-slate-700 text-slate-400';
}

// -------------------------------------------------------------------
// CSS Fallback: column-based status grouping
// -------------------------------------------------------------------

interface StatusColumn {
  key: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  headerBg: string;
}

const STATUS_COLUMNS: StatusColumn[] = [
  {
    key: 'pending',
    label: 'Pending',
    icon: <Clock size={14} />,
    color: 'text-slate-400',
    headerBg: 'bg-slate-700/50',
  },
  {
    key: 'running',
    label: 'Running',
    icon: <Play size={14} />,
    color: 'text-indigo-400',
    headerBg: 'bg-indigo-900/30',
  },
  {
    key: 'completed',
    label: 'Completed',
    icon: <CheckCircle size={14} />,
    color: 'text-emerald-400',
    headerBg: 'bg-emerald-900/30',
  },
  {
    key: 'failed',
    label: 'Failed',
    icon: <AlertCircle size={14} />,
    color: 'text-red-400',
    headerBg: 'bg-red-900/30',
  },
];

function normalizeStatus(status: string): string {
  const s = status.toLowerCase();
  if (s === 'idle' || s === 'pending') return 'pending';
  if (s === 'running' || s === 'in_progress') return 'running';
  if (s === 'completed' || s === 'done') return 'completed';
  if (s === 'failed' || s === 'error') return 'failed';
  return 'pending';
}

function CSSTaskCard({ task }: { task: TaskNodeType }) {
  const colors = getStatusColor(task.status);

  return (
    <div
      className={`rounded-lg border p-3 transition-all duration-200 hover:brightness-110 ${colors.tailwind}`}
    >
      <div className="flex items-center gap-2 mb-1.5">
        <span className="flex-shrink-0 opacity-80">
          {getTypeIcon(task.agent_type || task.type)}
        </span>
        <span className="text-xs font-semibold truncate">
          {task.agent_type || task.type}
        </span>
        <span className="ml-auto flex-shrink-0">{getStatusIcon(task.status)}</span>
      </div>
      <p className="text-[11px] opacity-70 leading-tight line-clamp-2 mb-1.5">
        {task.description}
      </p>
      {task.progress !== undefined && task.progress > 0 && (
        <div className="w-full h-1 bg-slate-700 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full bg-indigo-400 transition-all"
            style={{ width: `${task.progress}%` }}
          />
        </div>
      )}
      {task.dependencies.length > 0 && (
        <div className="mt-1.5 text-[10px] opacity-50 truncate">
          Depends on: {task.dependencies.join(', ')}
        </div>
      )}
    </div>
  );
}

function CSSFallbackView({ tasks }: { tasks: TaskNodeType[] }) {
  const grouped = useMemo(() => {
    const groups: Record<string, TaskNodeType[]> = {
      pending: [],
      running: [],
      completed: [],
      failed: [],
    };
    tasks.forEach((task) => {
      const key = normalizeStatus(task.status);
      groups[key].push(task);
    });
    return groups;
  }, [tasks]);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 h-full">
      {STATUS_COLUMNS.map((col) => (
        <div
          key={col.key}
          className="flex flex-col bg-slate-900/50 rounded-lg border border-slate-700 overflow-hidden"
        >
          {/* Column Header */}
          <div
            className={`flex items-center gap-2 px-3 py-2 border-b border-slate-700 ${col.headerBg}`}
          >
            <span className={col.color}>{col.icon}</span>
            <span className={`text-xs font-semibold uppercase tracking-wider ${col.color}`}>
              {col.label}
            </span>
            <span className="ml-auto text-xs text-slate-500 font-mono">
              {grouped[col.key].length}
            </span>
          </div>

          {/* Column Tasks */}
          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {grouped[col.key].length === 0 ? (
              <div className="flex items-center justify-center h-20 text-xs text-slate-600">
                No tasks
              </div>
            ) : (
              grouped[col.key].map((task) => (
                <CSSTaskCard key={task.id} task={task} />
              ))
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

// -------------------------------------------------------------------
// ReactFlow-based view (when available)
// -------------------------------------------------------------------

function layoutNodes(
  tasks: TaskNodeType[],
  ReactFlow: any
): { nodes: any[]; edges: any[] } {
  if (tasks.length === 0) return { nodes: [], edges: [] };

  const { Position, MarkerType } = ReactFlow;
  const taskMap = new Map(tasks.map((t) => [t.id, t]));
  const levels = new Map<string, number>();

  function getLevel(id: string, visited: Set<string> = new Set()): number {
    if (levels.has(id)) return levels.get(id)!;
    if (visited.has(id)) return 0;
    visited.add(id);

    const task = taskMap.get(id);
    if (!task || !task.dependencies || task.dependencies.length === 0) {
      levels.set(id, 0);
      return 0;
    }

    const maxDepLevel = Math.max(
      ...task.dependencies
        .filter((d) => taskMap.has(d))
        .map((d) => getLevel(d, visited))
    );
    const level = maxDepLevel + 1;
    levels.set(id, level);
    return level;
  }

  tasks.forEach((t) => getLevel(t.id));

  const levelGroups = new Map<number, TaskNodeType[]>();
  tasks.forEach((t) => {
    const level = levels.get(t.id) || 0;
    if (!levelGroups.has(level)) levelGroups.set(level, []);
    levelGroups.get(level)!.push(t);
  });

  const NODE_WIDTH = 180;
  const NODE_HEIGHT = 60;
  const H_GAP = 60;
  const V_GAP = 100;

  const nodes: any[] = [];

  levelGroups.forEach((group, level) => {
    const totalWidth = group.length * NODE_WIDTH + (group.length - 1) * H_GAP;
    const startX = -totalWidth / 2;

    group.forEach((task, idx) => {
      const colors = getStatusColor(task.status);
      nodes.push({
        id: task.id,
        position: {
          x: startX + idx * (NODE_WIDTH + H_GAP),
          y: level * (NODE_HEIGHT + V_GAP),
        },
        data: {
          label: React.createElement(
            'div',
            { className: 'text-center' },
            React.createElement(
              'div',
              { className: 'text-xs font-semibold truncate' },
              task.agent_type || task.type
            ),
            React.createElement(
              'div',
              { className: 'text-[10px] opacity-70 truncate mt-0.5' },
              task.description
            ),
            task.progress !== undefined &&
              task.progress > 0 &&
              React.createElement(
                'div',
                { className: 'mt-1 w-full bg-slate-700 rounded-full h-1' },
                React.createElement('div', {
                  className: 'h-1 rounded-full bg-indigo-400',
                  style: { width: `${task.progress}%` },
                })
              )
          ),
        },
        sourcePosition: Position.Bottom,
        targetPosition: Position.Top,
        style: {
          background: colors.bg,
          border: `2px solid ${colors.border}`,
          color: colors.text,
          borderRadius: '8px',
          padding: '8px 12px',
          width: NODE_WIDTH,
          fontSize: '12px',
        },
      });
    });
  });

  const edges: any[] = [];
  tasks.forEach((task) => {
    if (task.dependencies) {
      task.dependencies.forEach((depId) => {
        if (taskMap.has(depId)) {
          edges.push({
            id: `${depId}-${task.id}`,
            source: depId,
            target: task.id,
            animated:
              task.status === 'running' || task.status === 'in_progress',
            style: { stroke: '#475569', strokeWidth: 1.5 },
            markerEnd: {
              type: MarkerType.ArrowClosed,
              color: '#475569',
              width: 15,
              height: 15,
            },
          });
        }
      });
    }
  });

  return { nodes, edges };
}

function ReactFlowView({ tasks }: { tasks: TaskNodeType[] }) {
  const RF = ReactFlowModule;
  const {
    default: ReactFlowComponent,
    Background,
    Controls,
    MiniMap,
    useNodesState,
    useEdgesState,
  } = RF;

  const { nodes: initialNodes, edges: initialEdges } = useMemo(
    () => layoutNodes(tasks, RF),
    [tasks]
  );

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  useEffect(() => {
    const { nodes: newNodes, edges: newEdges } = layoutNodes(tasks, RF);
    setNodes(newNodes);
    setEdges(newEdges);
  }, [tasks, setNodes, setEdges]);

  return (
    <div className="w-full h-full">
      <ReactFlowComponent
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        minZoom={0.3}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
      >
        <Background color="#334155" gap={20} size={1} />
        <Controls
          style={{
            background: '#1e293b',
            border: '1px solid #334155',
            borderRadius: '8px',
          }}
        />
        <MiniMap
          style={{
            background: '#0f172a',
            border: '1px solid #334155',
            borderRadius: '8px',
          }}
          nodeColor={() => '#6366f1'}
        />
      </ReactFlowComponent>
    </div>
  );
}

// -------------------------------------------------------------------
// Main TaskGraph component
// -------------------------------------------------------------------

export default function TaskGraph({ tasks }: TaskGraphProps) {
  const [viewMode, setViewMode] = useState<'graph' | 'columns'>(
    ReactFlowModule ? 'graph' : 'columns'
  );

  if (tasks.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500 text-sm">
        No tasks available. Start the pipeline to see the task graph.
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* View Toggle (only when ReactFlow is available) */}
      {ReactFlowModule && (
        <div className="flex items-center gap-2 mb-3 flex-shrink-0">
          <button
            onClick={() => setViewMode('graph')}
            className={`text-xs px-3 py-1 rounded-md transition-colors ${
              viewMode === 'graph'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            Graph View
          </button>
          <button
            onClick={() => setViewMode('columns')}
            className={`text-xs px-3 py-1 rounded-md transition-colors ${
              viewMode === 'columns'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            Column View
          </button>
          <span className="ml-auto text-xs text-slate-500">
            {tasks.length} task{tasks.length !== 1 ? 's' : ''}
          </span>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 min-h-0">
        {viewMode === 'graph' && ReactFlowModule ? (
          <ReactFlowView tasks={tasks} />
        ) : (
          <CSSFallbackView tasks={tasks} />
        )}
      </div>
    </div>
  );
}
