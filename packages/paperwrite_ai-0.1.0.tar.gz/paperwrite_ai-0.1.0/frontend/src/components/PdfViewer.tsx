'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import {
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  Download,
  Loader2,
  AlertCircle,
} from 'lucide-react';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

interface PdfViewerProps {
  url: string;
  onDownload?: () => void;
}

export default function PdfViewer({ url, onDownload }: PdfViewerProps) {
  const [numPages, setNumPages] = useState<number>(0);
  const [pageNumber, setPageNumber] = useState(1);
  const [scale, setScale] = useState(1.2);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
    setNumPages(numPages);
    setLoading(false);
    setError(null);
  }

  function onDocumentLoadError(err: Error) {
    setError(err.message || 'Failed to load PDF');
    setLoading(false);
  }

  function goToPrev() {
    setPageNumber((p) => Math.max(1, p - 1));
  }

  function goToNext() {
    setPageNumber((p) => Math.min(numPages, p + 1));
  }

  function zoomIn() {
    setScale((s) => Math.min(3, s + 0.2));
  }

  function zoomOut() {
    setScale((s) => Math.max(0.5, s - 0.2));
  }

  function handleDownload() {
    if (onDownload) {
      onDownload();
    } else {
      window.open(url, '_blank');
    }
  }

  useEffect(() => {
    setPageNumber(1);
    setLoading(true);
    setError(null);
  }, [url]);

  return (
    <div className="pdf-viewer-container flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700 flex-shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={goToPrev}
            disabled={pageNumber <= 1}
            className="p-1.5 rounded hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Previous page"
          >
            <ChevronLeft size={18} />
          </button>
          <span className="text-sm text-slate-300 min-w-[80px] text-center">
            {numPages > 0 ? `${pageNumber} / ${numPages}` : '--'}
          </span>
          <button
            onClick={goToNext}
            disabled={pageNumber >= numPages}
            className="p-1.5 rounded hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Next page"
          >
            <ChevronRight size={18} />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={zoomOut}
            className="p-1.5 rounded hover:bg-slate-700 transition-colors"
            title="Zoom out"
          >
            <ZoomOut size={18} />
          </button>
          <span className="text-sm text-slate-400 min-w-[50px] text-center">
            {Math.round(scale * 100)}%
          </span>
          <button
            onClick={zoomIn}
            className="p-1.5 rounded hover:bg-slate-700 transition-colors"
            title="Zoom in"
          >
            <ZoomIn size={18} />
          </button>
          <div className="w-px h-5 bg-slate-700 mx-1" />
          <button
            onClick={handleDownload}
            className="p-1.5 rounded hover:bg-slate-700 transition-colors"
            title="Download PDF"
          >
            <Download size={18} />
          </button>
        </div>
      </div>

      {/* PDF Content */}
      <div
        ref={containerRef}
        className="flex-1 overflow-auto flex justify-center bg-slate-950 p-4"
      >
        {error ? (
          <div className="flex flex-col items-center justify-center gap-3 text-slate-400">
            <AlertCircle size={48} className="text-red-400" />
            <p className="text-sm">Failed to load PDF</p>
            <p className="text-xs text-slate-500">{error}</p>
          </div>
        ) : (
          <Document
            file={url}
            onLoadSuccess={onDocumentLoadSuccess}
            onLoadError={onDocumentLoadError}
            loading={
              <div className="flex items-center gap-2 text-slate-400">
                <Loader2 size={20} className="animate-spin" />
                <span className="text-sm">Loading PDF...</span>
              </div>
            }
          >
            <Page
              pageNumber={pageNumber}
              scale={scale}
              loading={
                <div className="flex items-center gap-2 text-slate-400 py-8">
                  <Loader2 size={16} className="animate-spin" />
                  <span className="text-xs">Rendering page...</span>
                </div>
              }
            />
          </Document>
        )}
      </div>
    </div>
  );
}
