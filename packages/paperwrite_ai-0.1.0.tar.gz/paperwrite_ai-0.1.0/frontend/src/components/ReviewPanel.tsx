'use client';

import React from 'react';
import {
  Star,
  CheckCircle,
  XCircle,
  MessageSquare,
  AlertTriangle,
} from 'lucide-react';
import type { ReviewScore } from '@/lib/types';

interface ReviewData {
  passed: boolean;
  review_scores: ReviewScore[];
  feedback: string[];
  revision_priority: string[];
  passing_count: number;
  total_reviewers: number;
}

interface ReviewPanelProps {
  reviewData: ReviewData | null;
}

interface ScoreBarProps {
  label: string;
  value: number;
  max?: number;
}

function ScoreBar({ label, value, max = 10 }: ScoreBarProps) {
  const pct = (value / max) * 100;
  let color: string;
  if (value >= 4) {
    color = 'bg-emerald-500';
  } else if (value === 3) {
    color = 'bg-yellow-500';
  } else {
    color = 'bg-red-500';
  }

  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-slate-400 w-[130px] flex-shrink-0 truncate">
        {label}
      </span>
      <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${color}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="text-xs text-slate-300 w-[40px] text-right font-mono">
        {value.toFixed(1)}
      </span>
    </div>
  );
}

function ReviewCard({ review }: { review: ReviewScore }) {
  const overallPct = (review.overall / 10) * 100;
  const passed = review.overall >= 6;

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Star size={16} className="text-amber-400" />
          <span className="text-sm font-semibold text-slate-200">
            {review.reviewer_id}
          </span>
        </div>
        <span
          className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full ${
            passed
              ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-700'
              : 'bg-red-900/50 text-red-400 border border-red-700'
          }`}
        >
          {passed ? <CheckCircle size={12} /> : <XCircle size={12} />}
          {passed ? 'PASS' : 'FAIL'}
        </span>
      </div>

      {/* Overall Score */}
      <div className="flex items-center gap-2 mb-4 p-2 rounded bg-slate-900/50">
        <span className="text-sm text-slate-400">Overall</span>
        <div className="flex-1" />
        <span
          className={`text-2xl font-bold ${
            overallPct >= 70
              ? 'text-emerald-400'
              : overallPct >= 40
              ? 'text-amber-400'
              : 'text-red-400'
          }`}
        >
          {review.overall.toFixed(1)}
        </span>
        <span className="text-sm text-slate-500">/ 10</span>
      </div>

      {/* Criteria Scores */}
      <div className="space-y-2 mb-4">
        <ScoreBar label="Writing Quality" value={review.writing_quality} />
        <ScoreBar label="Method Logic" value={review.method_logic} />
        <ScoreBar label="Technical Feasibility" value={review.technical_feasibility} />
        <ScoreBar label="Reproducibility" value={review.reproducibility} />
      </div>

      {/* Per-reviewer Feedback */}
      {review.feedback && review.feedback.length > 0 && (
        <div className="border-t border-slate-700 pt-3">
          <div className="flex items-center gap-1.5 mb-2">
            <MessageSquare size={12} className="text-slate-400" />
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Feedback
            </span>
          </div>
          <ul className="space-y-1">
            {review.feedback.map((fb, idx) => (
              <li
                key={idx}
                className="text-xs text-slate-300 pl-3 border-l-2 border-slate-700 py-0.5"
              >
                {fb}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default function ReviewPanel({ reviewData }: ReviewPanelProps) {
  if (!reviewData) {
    return null;
  }

  const { passed, review_scores, feedback, revision_priority, passing_count, total_reviewers } =
    reviewData;

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">
          Peer Review Results
        </h3>
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-400">
            {passing_count} / {total_reviewers} passed
          </span>
          <span
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full ${
              passed
                ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-700'
                : 'bg-red-900/50 text-red-400 border border-red-700'
            }`}
          >
            {passed ? (
              <CheckCircle size={14} />
            ) : (
              <XCircle size={14} />
            )}
            {passed ? 'PASSED' : 'FAILED'}
          </span>
        </div>
      </div>

      {/* Reviewer Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {review_scores.map((review) => (
          <ReviewCard key={review.reviewer_id} review={review} />
        ))}
      </div>

      {/* Aggregated Feedback Section */}
      {feedback.length > 0 && (
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-4 mb-4">
          <div className="flex items-center gap-2 mb-3">
            <MessageSquare size={16} className="text-slate-400" />
            <h4 className="text-sm font-semibold text-slate-300">
              Aggregated Feedback
            </h4>
          </div>
          <ul className="space-y-2">
            {feedback.map((item, idx) => (
              <li
                key={idx}
                className="text-sm text-slate-300 pl-4 border-l-2 border-indigo-600 py-1"
              >
                {item}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Priority Areas */}
      {revision_priority.length > 0 && (
        <div className="bg-amber-900/20 rounded-lg border border-amber-800/50 p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle size={16} className="text-amber-400" />
            <h4 className="text-sm font-semibold text-amber-300">
              Revision Priority Areas
            </h4>
          </div>
          <ul className="space-y-1.5">
            {revision_priority.map((item, idx) => (
              <li
                key={idx}
                className="flex items-start gap-2 text-sm text-amber-200/80"
              >
                <span className="text-amber-400 font-bold flex-shrink-0 mt-0.5">
                  {idx + 1}.
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
