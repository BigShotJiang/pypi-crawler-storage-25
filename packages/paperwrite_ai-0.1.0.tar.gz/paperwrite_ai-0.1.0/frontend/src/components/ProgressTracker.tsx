'use client';

import React from 'react';
import {
  FileText,
  Search,
  Cpu,
  FlaskConical,
  PenTool,
  CheckCircle,
  BarChart3,
  Flag,
} from 'lucide-react';
import type { TaskNode } from '@/lib/types';

interface Stage {
  key: string;
  label: string;
  icon: React.ReactNode;
}

const STAGES: Stage[] = [
  { key: 'planning', label: 'Planning', icon: <FileText size={18} /> },
  { key: 'research', label: 'Research', icon: <Search size={18} /> },
  { key: 'method', label: 'Method', icon: <Cpu size={18} /> },
  { key: 'experiments', label: 'Experiments', icon: <FlaskConical size={18} /> },
  { key: 'writing', label: 'Writing', icon: <PenTool size={18} /> },
  { key: 'review', label: 'Review', icon: <CheckCircle size={18} /> },
  { key: 'figures', label: 'Figures', icon: <BarChart3 size={18} /> },
  { key: 'final', label: 'Final', icon: <Flag size={18} /> },
];

function getStageStatus(
  stageKey: string,
  tasks: TaskNode[]
): 'pending' | 'running' | 'completed' | 'failed' {
  const stageTasks = tasks.filter(
    (t) =>
      t.type?.toLowerCase().includes(stageKey) ||
      t.agent_type?.toLowerCase().includes(stageKey)
  );

  if (stageTasks.length === 0) return 'pending';
  if (stageTasks.some((t) => t.status === 'failed' || t.status === 'error'))
    return 'failed';
  if (stageTasks.every((t) => t.status === 'completed' || t.status === 'done'))
    return 'completed';
  if (
    stageTasks.some(
      (t) => t.status === 'running' || t.status === 'in_progress'
    )
  )
    return 'running';
  return 'pending';
}

const statusColors = {
  pending: 'bg-slate-700 text-slate-400 border-slate-600',
  running: 'bg-indigo-900/50 text-indigo-300 border-indigo-500 pulse-dot',
  completed: 'bg-emerald-900/50 text-emerald-300 border-emerald-500',
  failed: 'bg-red-900/50 text-red-300 border-red-500',
};

const connectorColors = {
  pending: 'bg-slate-700',
  running: 'progress-shimmer',
  completed: 'bg-emerald-500',
  failed: 'bg-red-500',
};

interface ProgressTrackerProps {
  tasks: TaskNode[];
  pipelineStatus?: string;
}

export default function ProgressTracker({
  tasks,
  pipelineStatus,
}: ProgressTrackerProps) {
  return (
    <div className="w-full">
      <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">
        Pipeline Progress
      </h3>

      {/* Desktop: horizontal layout */}
      <div className="hidden md:flex items-center justify-between gap-0">
        {STAGES.map((stage, idx) => {
          const status = getStageStatus(stage.key, tasks);
          return (
            <React.Fragment key={stage.key}>
              <div className="flex flex-col items-center gap-2 flex-shrink-0">
                <div
                  className={`w-10 h-10 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${statusColors[status]}`}
                >
                  {stage.icon}
                </div>
                <span className="text-xs text-slate-400 whitespace-nowrap">
                  {stage.label}
                </span>
              </div>
              {idx < STAGES.length - 1 && (
                <div
                  className={`flex-1 h-0.5 min-w-[20px] rounded-full transition-all duration-300 ${connectorColors[status]}`}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Mobile: vertical layout */}
      <div className="flex md:hidden flex-col gap-1">
        {STAGES.map((stage, idx) => {
          const status = getStageStatus(stage.key, tasks);
          return (
            <React.Fragment key={stage.key}>
              <div className="flex items-center gap-3">
                <div
                  className={`w-8 h-8 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all duration-300 ${statusColors[status]}`}
                >
                  {stage.icon}
                </div>
                <span className="text-sm text-slate-300">{stage.label}</span>
                <span
                  className={`ml-auto text-xs px-2 py-0.5 rounded-full ${
                    status === 'completed'
                      ? 'bg-emerald-900/50 text-emerald-400'
                      : status === 'running'
                      ? 'bg-indigo-900/50 text-indigo-400'
                      : status === 'failed'
                      ? 'bg-red-900/50 text-red-400'
                      : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  {status}
                </span>
              </div>
              {idx < STAGES.length - 1 && (
                <div className="ml-4 w-0.5 h-4 bg-slate-700 rounded-full" />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Overall progress bar */}
      {pipelineStatus === 'running' && (
        <div className="mt-4">
          <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
            <div className="h-full progress-shimmer rounded-full" />
          </div>
        </div>
      )}
    </div>
  );
}
