export interface Project {
  id: string;
  topic: string;
  outline: Section[];
  page_count: number;
  template: string;
  status: 'created' | 'running' | 'completed' | 'failed';
  config: ProjectConfig;
  created_at: string;
}

export interface Section {
  title: string;
  subsections?: string[];
}

export interface ProjectConfig {
  api_keys: ApiKeys;
  default_model: string;
}

export interface ApiKeys {
  openai?: string;
  anthropic?: string;
  google?: string;
  deepseek?: string;
  tavily?: string;
}

export interface AgentStatus {
  agent_id: string;
  agent_type: string;
  status: 'idle' | 'running' | 'completed' | 'error';
  current_task?: string;
}

export interface TaskNode {
  id: string;
  type: string;
  status: string;
  agent_type: string;
  description: string;
  dependencies: string[];
  progress?: number;
}

export interface ReviewScore {
  reviewer_id: string;
  writing_quality: number;
  method_logic: number;
  technical_feasibility: number;
  reproducibility: number;
  overall: number;
  feedback: string[];
}

export interface LogEntry {
  agent_id: string;
  level: 'info' | 'warning' | 'error';
  message: string;
  timestamp: string;
}

export interface WSMessage {
  type:
    | 'agent_status'
    | 'log'
    | 'task_update'
    | 'review_result'
    | 'compilation'
    | 'pipeline_started'
    | 'pipeline_completed'
    | 'pipeline_failed';
  project_id: string;
  agent_id?: string;
  data: any;
  timestamp: string;
}

export interface PipelineProgress {
  total: number;
  completed: number;
  running: number;
  failed: number;
  pending: number;
  progress_pct: number;
}
