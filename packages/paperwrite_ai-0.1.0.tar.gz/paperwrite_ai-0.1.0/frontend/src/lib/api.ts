import axios from 'axios';
import type { Project, Section, ApiKeys } from './types';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

export interface CreateProjectPayload {
  topic: string;
  outline?: string;
  page_count: number;
  template: string;
  config?: {
    openai_api_key?: string;
    anthropic_api_key?: string;
    google_api_key?: string;
    deepseek_api_key?: string;
    tavily_api_key?: string;
    default_model?: string;
  };
}

export const projectsApi = {
  create: (data: CreateProjectPayload) =>
    api.post<Project>('/api/projects', data),

  list: () => api.get<{ projects: Project[]; total: number }>('/api/projects'),

  get: (id: string) => api.get<Project>(`/api/projects/${id}`),

  start: (id: string) => api.post(`/api/projects/${id}/start`),

  delete: (id: string) => api.delete(`/api/projects/${id}`),

  getPdf: (id: string) => `${API_BASE}/api/projects/${id}/pdf`,

  getLatex: (id: string) =>
    api.get<{ latex: string }>(`/api/projects/${id}/latex`),

  compile: (id: string) => api.post(`/api/projects/${id}/compile`),

  getTaskGraph: (id: string) =>
    api.get<{ nodes: any[]; edges: any[] }>(`/api/projects/${id}/task-graph`),
};

export { API_BASE };
export default api;
