import { create } from 'zustand';
import type {
  Project,
  AgentStatus,
  TaskNode,
  ReviewScore,
  LogEntry,
  PipelineProgress,
} from './types';

interface ProjectStore {
  project: Project | null;
  agents: AgentStatus[];
  tasks: TaskNode[];
  reviews: ReviewScore[];
  logs: LogEntry[];
  progress: PipelineProgress;
  isConnected: boolean;

  setProject: (project: Project) => void;
  updateAgentStatus: (agent: AgentStatus) => void;
  updateTask: (task: TaskNode) => void;
  addReview: (review: ReviewScore) => void;
  addLog: (log: LogEntry) => void;
  setProgress: (progress: Partial<PipelineProgress>) => void;
  setConnected: (connected: boolean) => void;
  clearLogs: () => void;
  reset: () => void;
}

const initialProgress: PipelineProgress = {
  total: 0,
  completed: 0,
  running: 0,
  failed: 0,
  pending: 0,
  progress_pct: 0,
};

export const useProjectStore = create<ProjectStore>((set) => ({
  project: null,
  agents: [],
  tasks: [],
  reviews: [],
  logs: [],
  progress: initialProgress,
  isConnected: false,

  setProject: (project) => set({ project }),

  updateAgentStatus: (agent) =>
    set((state) => {
      const idx = state.agents.findIndex((a) => a.agent_id === agent.agent_id);
      const agents = [...state.agents];
      if (idx >= 0) {
        agents[idx] = agent;
      } else {
        agents.push(agent);
      }
      return { agents };
    }),

  updateTask: (task) =>
    set((state) => {
      const idx = state.tasks.findIndex((t) => t.id === task.id);
      const tasks = [...state.tasks];
      if (idx >= 0) {
        tasks[idx] = task;
      } else {
        tasks.push(task);
      }
      return { tasks };
    }),

  addReview: (review) =>
    set((state) => {
      const idx = state.reviews.findIndex(
        (r) => r.reviewer_id === review.reviewer_id
      );
      const reviews = [...state.reviews];
      if (idx >= 0) {
        reviews[idx] = review;
      } else {
        reviews.push(review);
      }
      return { reviews };
    }),

  addLog: (log) =>
    set((state) => {
      const logs = [...state.logs, log];
      if (logs.length > 500) {
        logs.splice(0, logs.length - 500);
      }
      return { logs };
    }),

  setProgress: (progress) =>
    set((state) => ({
      progress: { ...state.progress, ...progress },
    })),

  setConnected: (connected) => set({ isConnected: connected }),

  clearLogs: () => set({ logs: [] }),

  reset: () =>
    set({
      project: null,
      agents: [],
      tasks: [],
      reviews: [],
      logs: [],
      progress: initialProgress,
      isConnected: false,
    }),
}));
