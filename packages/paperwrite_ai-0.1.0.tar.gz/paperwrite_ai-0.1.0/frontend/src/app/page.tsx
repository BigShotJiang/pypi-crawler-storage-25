'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Plus, FileText } from 'lucide-react';
import { projectsApi } from '@/lib/api';
import type { Project } from '@/lib/types';

const STATUS_BADGE: Record<Project['status'], string> = {
  completed: 'bg-emerald-900/50 text-emerald-400 border border-emerald-700',
  running: 'bg-blue-900/50 text-blue-400 border border-blue-700',
  created: 'bg-slate-700 text-slate-300 border border-slate-600',
  failed: 'bg-red-900/50 text-red-400 border border-red-700',
};

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return iso;
  }
}

function SkeletonCard() {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-lg p-5 animate-pulse">
      <div className="h-5 bg-slate-700 rounded w-3/4 mb-3" />
      <div className="h-4 bg-slate-700 rounded w-1/2 mb-2" />
      <div className="h-4 bg-slate-700 rounded w-1/3" />
    </div>
  );
}

export default function HomePage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    projectsApi
      .list()
      .then((res) => {
        const data = res.data;
        setProjects(data.projects || data || []);
      })
      .catch((err) => {
        setError(err?.message || 'Failed to load projects');
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <div className="space-y-8">
      {/* Header & New Project Button */}
      <div className="flex flex-col items-center gap-4">
        <h1 className="text-3xl font-bold text-slate-100">Your Projects</h1>
        <Link
          href="/new"
          className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg transition-colors shadow-lg shadow-indigo-900/30"
        >
          <Plus size={20} />
          New Project
        </Link>
      </div>

      {/* Error State */}
      {error && (
        <div className="bg-red-900/20 border border-red-700 rounded-lg p-4 text-red-400 text-center">
          {error}
        </div>
      )}

      {/* Loading State */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && projects.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-slate-500">
          <FileText size={48} className="mb-4 text-slate-600" />
          <p className="text-lg">No projects yet. Create your first paper!</p>
        </div>
      )}

      {/* Project Grid */}
      {!loading && projects.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((project) => (
            <Link
              key={project.id}
              href={`/project/${project.id}`}
              className="group bg-slate-800 border border-slate-700 rounded-lg p-5 hover:border-indigo-500/50 hover:bg-slate-800/80 transition-all"
            >
              <div className="flex items-start justify-between mb-3">
                <h3 className="text-base font-semibold text-slate-100 group-hover:text-indigo-300 transition-colors line-clamp-2 flex-1 mr-2">
                  {project.topic}
                </h3>
                <span
                  className={`text-xs font-medium px-2 py-0.5 rounded-full whitespace-nowrap ${STATUS_BADGE[project.status]}`}
                >
                  {project.status}
                </span>
              </div>
              <div className="space-y-1 text-sm text-slate-400">
                <p>Template: {project.template}</p>
                <p>Created: {formatDate(project.created_at)}</p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
