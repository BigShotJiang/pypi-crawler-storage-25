'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  Check,
} from 'lucide-react';
import { projectsApi, CreateProjectPayload } from '@/lib/api';
import type { ApiKeys } from '@/lib/types';

interface SectionEntry {
  title: string;
  subsections: string;
}

const DEFAULT_SECTIONS: SectionEntry[] = [
  { title: 'Introduction', subsections: '' },
  { title: 'Background', subsections: '' },
  { title: 'Motivation', subsections: '' },
  { title: 'Overview', subsections: '' },
  { title: 'Method', subsections: '' },
  { title: 'Implementation', subsections: '' },
  { title: 'Evaluation', subsections: '' },
  { title: 'Discussion', subsections: '' },
  { title: 'Related Work', subsections: '' },
  { title: 'Conclusion', subsections: '' },
];

const TEMPLATES = [
  { value: 'ieee_conference', label: 'IEEE Conference' },
  { value: 'ieee_journal', label: 'IEEE Journal' },
  { value: 'acm_conference', label: 'ACM Conference' },
  { value: 'generic', label: 'Generic' },
];

const MODELS = [
  { value: 'gpt-4o', label: 'gpt-4o' },
  { value: 'claude-sonnet-4-20250514', label: 'claude-sonnet-4-20250514' },
  { value: 'gemini-pro', label: 'gemini-pro' },
  { value: 'deepseek-chat', label: 'deepseek-chat' },
];

const STEP_LABELS = ['Topic & Overview', 'Outline', 'Configuration', 'API Keys'];

export default function NewProjectPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Step 1: Topic & Overview
  const [topic, setTopic] = useState('');
  const [abstractIdea, setAbstractIdea] = useState('');

  // Step 2: Outline
  const [sections, setSections] = useState<SectionEntry[]>(DEFAULT_SECTIONS);

  // Step 3: Configuration
  const [pageCount, setPageCount] = useState(12);
  const [template, setTemplate] = useState('ieee_conference');
  const [defaultModel, setDefaultModel] = useState('gpt-4o');

  // Step 4: API Keys
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({
    openai: '',
    anthropic: '',
    google: '',
    deepseek: '',
    tavily: '',
  });
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});

  // --- Section helpers ---
  const addSection = () => {
    setSections([...sections, { title: '', subsections: '' }]);
  };

  const removeSection = (index: number) => {
    setSections(sections.filter((_, i) => i !== index));
  };

  const updateSection = (index: number, field: keyof SectionEntry, value: string) => {
    const updated = [...sections];
    updated[index] = { ...updated[index], [field]: value };
    setSections(updated);
  };

  const moveSection = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= sections.length) return;
    const updated = [...sections];
    [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]];
    setSections(updated);
  };

  // --- Validation ---
  const canProceed = (): boolean => {
    if (step === 0) return topic.trim().length > 0;
    if (step === 1) return sections.some((s) => s.title.trim().length > 0);
    if (step === 2) return pageCount >= 4 && pageCount <= 30;
    if (step === 3) {
      const { tavily, ...llmKeys } = apiKeys;
      return Object.values(llmKeys).some((k) => k.trim().length > 0);
    }
    return true;
  };

  // --- Submit ---
  const handleSubmit = async () => {
    setError(null);
    setSubmitting(true);

    try {
      const filteredKeys: ApiKeys = {};
      if (apiKeys.openai.trim()) filteredKeys.openai = apiKeys.openai.trim();
      if (apiKeys.anthropic.trim()) filteredKeys.anthropic = apiKeys.anthropic.trim();
      if (apiKeys.google.trim()) filteredKeys.google = apiKeys.google.trim();
      if (apiKeys.deepseek.trim()) filteredKeys.deepseek = apiKeys.deepseek.trim();
      if (apiKeys.tavily.trim()) filteredKeys.tavily = apiKeys.tavily.trim();

      const outline = sections
        .filter((s) => s.title.trim())
        .map((s) => ({
          title: s.title.trim(),
          subsections: s.subsections
            ? s.subsections
                .split(',')
                .map((sub) => sub.trim())
                .filter(Boolean)
            : undefined,
        }));

      const payload: CreateProjectPayload = {
        topic: topic.trim(),
        abstract_idea: abstractIdea.trim() || undefined,
        outline,
        page_count: pageCount,
        template,
        config: {
          api_keys: filteredKeys,
          default_model: defaultModel,
        },
      };

      const res = await projectsApi.create(payload);
      router.push(`/project/${res.data.id}`);
    } catch (err: any) {
      setError(err?.response?.data?.detail || err?.message || 'Failed to create project');
    } finally {
      setSubmitting(false);
    }
  };

  const toggleKeyVisibility = (key: string) => {
    setVisibleKeys((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-slate-100 mb-6">Create New Paper</h1>

      {/* Step Indicator */}
      <div className="flex items-center justify-center mb-8">
        {STEP_LABELS.map((label, idx) => (
          <div key={label} className="flex items-center">
            <div className="flex flex-col items-center">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-semibold border-2 transition-all ${
                  idx === step
                    ? 'bg-indigo-600 border-indigo-500 text-white'
                    : idx < step
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-slate-800 border-slate-600 text-slate-400'
                }`}
              >
                {idx < step ? <Check size={16} /> : idx + 1}
              </div>
              <span className="text-xs text-slate-400 mt-1 whitespace-nowrap">
                {label}
              </span>
            </div>
            {idx < STEP_LABELS.length - 1 && (
              <div
                className={`w-12 h-0.5 mx-2 mt-[-16px] ${
                  idx < step ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              />
            )}
          </div>
        ))}
      </div>

      {/* Step Content Card */}
      <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 transition-all">
        {/* Step 1: Topic & Overview */}
        {step === 0 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold text-slate-100">Topic & Overview</h2>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                Research Topic <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., LLM-Based Fuzzing for PLC Compilers"
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2.5 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                Abstract Idea (optional)
              </label>
              <textarea
                value={abstractIdea}
                onChange={(e) => setAbstractIdea(e.target.value)}
                rows={5}
                placeholder="Briefly describe the core idea, contributions, or hypothesis..."
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2.5 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors resize-y"
              />
            </div>
          </div>
        )}

        {/* Step 2: Outline */}
        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-slate-100">Paper Outline</h2>
            <p className="text-sm text-slate-400">
              Define the sections of your paper. Each section can have optional
              comma-separated subsections.
            </p>
            <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
              {sections.map((section, index) => (
                <div
                  key={index}
                  className="flex items-start gap-2 rounded-lg border border-slate-600 bg-slate-700/50 p-3"
                >
                  {/* Up/Down controls */}
                  <div className="flex flex-col gap-0.5 pt-1">
                    <button
                      onClick={() => moveSection(index, 'up')}
                      disabled={index === 0}
                      className="p-0.5 rounded text-slate-400 hover:text-slate-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    >
                      <ArrowUp size={14} />
                    </button>
                    <button
                      onClick={() => moveSection(index, 'down')}
                      disabled={index === sections.length - 1}
                      className="p-0.5 rounded text-slate-400 hover:text-slate-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    >
                      <ArrowDown size={14} />
                    </button>
                  </div>

                  {/* Inputs */}
                  <div className="flex-1 space-y-1.5">
                    <input
                      type="text"
                      value={section.title}
                      onChange={(e) => updateSection(index, 'title', e.target.value)}
                      placeholder="Section title"
                      className="w-full rounded border border-slate-500 bg-slate-600 px-3 py-1.5 text-sm text-slate-100 placeholder-slate-400 focus:border-indigo-500 focus:outline-none transition-colors"
                    />
                    <input
                      type="text"
                      value={section.subsections}
                      onChange={(e) => updateSection(index, 'subsections', e.target.value)}
                      placeholder="Subsections (comma-separated, optional)"
                      className="w-full rounded border border-slate-500 bg-slate-600 px-3 py-1.5 text-xs text-slate-300 placeholder-slate-500 focus:border-indigo-500 focus:outline-none transition-colors"
                    />
                  </div>

                  {/* Remove button */}
                  <button
                    onClick={() => removeSection(index)}
                    className="p-1.5 rounded text-slate-400 hover:text-red-400 hover:bg-red-900/20 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
            <button
              onClick={addSection}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-sm rounded-lg border border-dashed border-slate-600 text-slate-400 hover:border-indigo-500 hover:text-indigo-400 transition-colors"
            >
              <Plus size={14} />
              Add Section
            </button>
          </div>
        )}

        {/* Step 3: Configuration */}
        {step === 2 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold text-slate-100">Configuration</h2>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                Page Count
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min={4}
                  max={30}
                  value={pageCount}
                  onChange={(e) => setPageCount(Number(e.target.value))}
                  className="w-28 rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-slate-100 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
                <span className="text-sm text-slate-400">pages (4 - 30)</span>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                Template
              </label>
              <select
                value={template}
                onChange={(e) => setTemplate(e.target.value)}
                className="w-full max-w-xs rounded-lg border border-slate-600 bg-slate-700 px-4 py-2.5 text-slate-100 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
              >
                {TEMPLATES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                Default Model
              </label>
              <select
                value={defaultModel}
                onChange={(e) => setDefaultModel(e.target.value)}
                className="w-full max-w-xs rounded-lg border border-slate-600 bg-slate-700 px-4 py-2.5 text-slate-100 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
              >
                {MODELS.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* Step 4: API Keys */}
        {step === 3 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold text-slate-100">API Keys</h2>
            <p className="text-sm text-slate-400">
              Provide at least one LLM API key. Keys are sent securely and not stored
              on the server.
            </p>
            <div className="space-y-3">
              {[
                { key: 'openai', label: 'OpenAI' },
                { key: 'anthropic', label: 'Anthropic' },
                { key: 'google', label: 'Google (Gemini)' },
                { key: 'deepseek', label: 'DeepSeek' },
                { key: 'tavily', label: 'Tavily (Search)' },
              ].map(({ key, label }) => (
                <div key={key} className="flex items-center gap-3">
                  <label className="w-36 text-sm text-slate-300 flex-shrink-0">
                    {label}
                  </label>
                  <div className="relative flex-1">
                    <input
                      type={visibleKeys[key] ? 'text' : 'password'}
                      value={apiKeys[key]}
                      onChange={(e) =>
                        setApiKeys((prev) => ({ ...prev, [key]: e.target.value }))
                      }
                      placeholder={`Enter ${label} API key`}
                      className="w-full rounded-lg border border-slate-600 bg-slate-700 pl-4 pr-12 py-2 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => toggleKeyVisibility(key)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 transition-colors"
                    >
                      {visibleKeys[key] ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {apiKeys[key].trim() && (
                    <Check size={18} className="text-emerald-400 flex-shrink-0" />
                  )}
                </div>
              ))}
            </div>
            {step === 3 && !canProceed() && (
              <p className="text-sm text-amber-400">
                At least one LLM API key (OpenAI, Anthropic, Google, or DeepSeek) is
                required.
              </p>
            )}
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="mt-4 p-3 rounded-lg bg-red-900/20 border border-red-700 text-red-400 text-sm">
            {error}
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-6 pt-4 border-t border-slate-700">
          <button
            onClick={() => setStep((s) => Math.max(0, s - 1))}
            disabled={step === 0}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm rounded-lg border border-slate-600 text-slate-300 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft size={16} />
            Back
          </button>

          {step < 3 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              disabled={!canProceed()}
              className="inline-flex items-center gap-1.5 px-5 py-2 text-sm font-medium rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Next
              <ChevronRight size={16} />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!canProceed() || submitting}
              className="inline-flex items-center gap-1.5 px-6 py-2 text-sm font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              {submitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Creating...
                </>
              ) : (
                'Create Project'
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
