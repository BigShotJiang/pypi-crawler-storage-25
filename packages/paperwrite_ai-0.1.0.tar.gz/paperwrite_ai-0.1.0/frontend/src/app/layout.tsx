import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Link from 'next/link';
import '@/styles/globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

export const metadata: Metadata = {
  title: 'PaperWrite AI',
  description: 'Multi-Agent Paper Writing System',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="bg-slate-900 text-slate-100 min-h-screen flex flex-col font-[family-name:var(--font-inter)]">
        {/* Header */}
        <header className="sticky top-0 z-50 bg-slate-800/90 backdrop-blur border-b border-slate-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
            <Link
              href="/"
              className="font-bold text-xl text-slate-100 hover:text-indigo-400 transition-colors"
            >
              PaperWrite AI
            </Link>
            <nav className="flex items-center gap-6">
              <Link
                href="/"
                className="text-sm text-slate-300 hover:text-slate-100 transition-colors"
              >
                Home
              </Link>
              <Link
                href="/new"
                className="text-sm text-slate-300 hover:text-slate-100 transition-colors"
              >
                New Project
              </Link>
            </nav>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
          {children}
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-700 bg-slate-800/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-sm text-slate-500">
            Multi-Agent Paper Writing System
          </div>
        </footer>
      </body>
    </html>
  );
}
