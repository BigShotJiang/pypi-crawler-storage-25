'use client';

import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Play,
  FileText,
  Loader2,
  CheckCircle2,
  XCircle,
  Circle,
  ArrowLeft,
} from 'lucide-react';
import { projectsApi } from '@/lib/api';
import { useProjectStore } from '@/lib/store';
import { useWebSocket } from '@/hooks/useWebSocket';
import ProgressTracker from '@/components/ProgressTracker';
import LogStream from '@/components/LogStream';
import type { Project, WSMessage, AgentStatus, ReviewScore } from '@/lib/types';

const STATUS_BADGE: Record<Project['status'], string> = {
  completed: 'bg-emerald-900/50 text-emerald-400 border border-emerald-700',
  running: 'bg-blue-900/50 text-blue-400 border border-blue-700',
  created: 'bg-slate-700 text-slate-300 border border-slate-600',
  failed: 'bg-red-900/50 text-red-400 border border-red-700',
};

const AGENT_STATUS_ICON: Record<AgentStatus['status'], React.ReactNode> = {
  idle: <Circle size={16} className="text-slate-500" />,
  running: <Loader2 size={16} className="text-blue-400 animate-spin" />,
  completed: <CheckCircle2 size={16} className="text-emerald-400" />,
  error: <XCircle size={16} className="text-red-400" />,
};

export default function ProjectDashboardPage() {
  const params = useParams();
  const router = useRouter();
  const projectId = params.id as string;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);

  const {
    project,
    agents,
    tasks,
    reviews,
    logs,
    setProject,
    updateAgentStatus,
    updateTask,
    addReview,
    addLog,
    setProgress,
    setConnected,
    clearLogs,
    reset,
  } = useProjectStore();

  // Handle WebSocket messages
  const handleWSMessage = useCallback(
    (msg: WSMessage) => {
      switch (msg.type) {
        case 'agent_status':
          updateAgentStatus(msg.data as AgentStatus);
          break;
        case 'log':
          addLog(msg.data);
          break;
        case 'task_update':
          updateTask(msg.data);
          break;
        case 'review_result':
          addReview(msg.data as ReviewScore);
          break;
        case 'pipeline_started':
          if (project) {
            setProject({ ...project, status: 'running' });
          }
          break;
        case 'pipeline_completed':
          if (project) {
            setProject({ ...project, status: 'completed' });
          }
          break;
        case 'pipeline_failed':
          if (project) {
            setProject({ ...project, status: 'failed' });
          }
          break;
        case 'compilation':
          break;
      }
    },
    [project, setProject, updateAgentStatus, updateTask, addReview, addLog]
  );

  const { isConnected } = useWebSocket(projectId, handleWSMessage);

  // Fetch project on mount
  useEffect(() => {
    reset();
    projectsApi
      .get(projectId)
      .then((res) => {
        setProject(res.data);
      })
      .catch((err) => {
        setError(err?.response?.data?.detail || err?.message || 'Failed to load project');
      })
      .finally(() => {
        setLoading(false);
      });
  }, [projectId, setProject, reset]);

  // Sync connection state
  useEffect(() => {
    setConnected(isConnected);
  }, [isConnected, setConnected]);

  // Start pipeline
  const handleStart = async () => {
    setStarting(true);
    try {
      await projectsApi.start(projectId);
      if (project) {
        setProject({ ...project, status: 'running' });
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Failed to start pipeline');
    } finally {
      setStarting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 size={32} className="text-indigo-400 animate-spin" />
      </div>
    );
  }

  if (error && !project) {
    return (
      <div className="space-y-4">
        <div className="bg-red-900/20 border border-red-700 rounded-lg p-4 text-red-400">
          {error}
        </div>
        <button
          onClick={() => router.push('/')}
          className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-slate-200 transition-colors"
        >
          <ArrowLeft size={16} />
          Back to projects
        </button>
      </div>
    );
  }

  if (!project) return null;

  return (
    <div className="space-y-6">
      {/* Back link */}
      <Link
        href="/"
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200 transition-colors"
      >
        <ArrowLeft size={16} />
        All Projects
      </Link>

      {/* Project Header */}
      <div className="bg-slate-800 border border-slate-700 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div className="space-y-2">
            <h1 className="text-xl font-bold text-slate-100">{project.topic}</h1>
            <div className="flex items-center gap-3 text-sm text-slate-400">
              <span
                className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${STATUS_BADGE[project.status]}`}
              >
                {project.status}
              </span>
              <span>Template: {project.template}</span>
              <span>{project.page_count} pages</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {project.status === 'created' && (
              <button
                onClick={handleStart}
                disabled={starting}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 disabled:opacity-50 transition-colors"
              >
                {starting ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Play size={16} />
                )}
                Start Pipeline
              </button>
            )}
            {project.status === 'completed' && (
              <Link
                href={`/project/${projectId}/editor`}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-500 transition-colors"
              >
                <FileText size={16} />
                View PDF
              </Link>
            )}
          </div>
        </div>

        {/* Connection indicator */}
        <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
          <div
            className={`w-2 h-2 rounded-full ${
              isConnected ? 'bg-emerald-400' : 'bg-red-400'
            }`}
          />
          {isConnected ? 'Connected (live updates)' : 'Disconnected'}
        </div>
      </div>

      {/* Progress Tracker */}
      <div className="bg-slate-800 border border-slate-700 rounded-lg p-5">
        <ProgressTracker tasks={tasks} pipelineStatus={project.status} />
      </div>

      {/* Agent Status Grid */}
      {agents.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-3">
            Agents
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {agents.map((agent) => (
              <div
                key={agent.agent_id}
                className="bg-slate-800 border border-slate-700 rounded-lg p-4 flex items-start gap-3"
              >
                <div className="mt-0.5">
                  {AGENT_STATUS_ICON[agent.status]}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-medium text-slate-200 truncate">
                    {agent.agent_type}
                  </h3>
                  {agent.current_task && (
                    <p className="text-xs text-slate-400 mt-0.5 truncate">
                      {agent.current_task}
                    </p>
                  )}
                </div>
                <span
                  className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0 ${
                    agent.status === 'running'
                      ? 'bg-blue-900/50 text-blue-400'
                      : agent.status === 'completed'
                      ? 'bg-emerald-900/50 text-emerald-400'
                      : agent.status === 'error'
                      ? 'bg-red-900/50 text-red-400'
                      : 'bg-slate-700 text-slate-400'
                  }`}
                >
                  {agent.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Review Panel */}
      {reviews.length > 0 && (
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-5">
          <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">
            Review Results
          </h2>
          <div className="space-y-4">
            {reviews.map((review) => (
              <div
                key={review.reviewer_id}
                className="border border-slate-600 rounded-lg p-4 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium text-slate-200">
                    {review.reviewer_id}
                  </h3>
                  <span className="text-lg font-bold text-indigo-400">
                    {review.overall.toFixed(1)}/10
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <div className="bg-slate-700/50 rounded p-2">
                    <span className="text-slate-400 block">Writing</span>
                    <span className="text-slate-200 font-medium">
                      {review.writing_quality}/10
                    </span>
                  </div>
                  <div className="bg-slate-700/50 rounded p-2">
                    <span className="text-slate-400 block">Method</span>
                    <span className="text-slate-200 font-medium">
                      {review.method_logic}/10
                    </span>
                  </div>
                  <div className="bg-slate-700/50 rounded p-2">
                    <span className="text-slate-400 block">Technical</span>
                    <span className="text-slate-200 font-medium">
                      {review.technical_feasibility}/10
                    </span>
                  </div>
                  <div className="bg-slate-700/50 rounded p-2">
                    <span className="text-slate-400 block">Reproducibility</span>
                    <span className="text-slate-200 font-medium">
                      {review.reproducibility}/10
                    </span>
                  </div>
                </div>
                {review.feedback.length > 0 && (
                  <ul className="space-y-1">
                    {review.feedback.map((fb, idx) => (
                      <li
                        key={idx}
                        className="text-xs text-slate-400 pl-3 border-l-2 border-slate-600"
                      >
                        {fb}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Log Stream */}
      <div className="h-[300px] relative">
        <LogStream logs={logs} onClear={clearLogs} />
      </div>

      {/* Error banner */}
      {error && (
        <div className="bg-red-900/20 border border-red-700 rounded-lg p-3 text-sm text-red-400">
          {error}
        </div>
      )}
    </div>
  );
}
