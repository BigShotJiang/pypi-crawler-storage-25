'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft,
  Copy,
  Check,
  Download,
  RefreshCw,
  Loader2,
} from 'lucide-react';
import { projectsApi } from '@/lib/api';

export default function EditorPage() {
  const params = useParams();
  const projectId = params.id as string;

  const [latex, setLatex] = useState<string>('');
  const [loadingLatex, setLoadingLatex] = useState(true);
  const [compiling, setCompiling] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pdfUrl = projectsApi.getPdf(projectId);

  // Fetch LaTeX source
  useEffect(() => {
    setLoadingLatex(true);
    projectsApi
      .getLatex(projectId)
      .then((res) => {
        setLatex(res.data.latex);
      })
      .catch((err) => {
        setError(
          err?.response?.data?.detail || 'Failed to load LaTeX source'
        );
      })
      .finally(() => {
        setLoadingLatex(false);
      });
  }, [projectId]);

  // Copy to clipboard
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(latex);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback for older browsers
      const ta = document.createElement('textarea');
      ta.value = latex;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Recompile
  const handleRecompile = async () => {
    setCompiling(true);
    setError(null);
    try {
      await projectsApi.compile(projectId);
      // Force PDF iframe reload by appending timestamp
      const iframe = document.querySelector<HTMLIFrameElement>('#pdf-viewer');
      if (iframe) {
        iframe.src = `${pdfUrl}?t=${Date.now()}`;
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Compilation failed');
    } finally {
      setCompiling(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-10rem)]">
      {/* Toolbar */}
      <div className="flex items-center justify-between mb-4 flex-shrink-0">
        <Link
          href={`/project/${projectId}`}
          className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200 transition-colors"
        >
          <ArrowLeft size={16} />
          Back to Dashboard
        </Link>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRecompile}
            disabled={compiling}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border border-slate-600 text-slate-300 hover:bg-slate-700 disabled:opacity-50 transition-colors"
          >
            {compiling ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <RefreshCw size={14} />
            )}
            Recompile
          </button>
          <a
            href={pdfUrl}
            download
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 transition-colors"
          >
            <Download size={14} />
            Download PDF
          </a>
        </div>
      </div>

      {/* Error banner */}
      {error && (
        <div className="mb-3 p-3 rounded-lg bg-red-900/20 border border-red-700 text-red-400 text-sm flex-shrink-0">
          {error}
        </div>
      )}

      {/* Split Layout */}
      <div className="flex-1 flex gap-4 min-h-0">
        {/* Left Panel: LaTeX Source */}
        <div className="w-1/2 flex flex-col bg-slate-800 border border-slate-700 rounded-lg overflow-hidden">
          {/* Panel Header */}
          <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700 flex-shrink-0">
            <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">
              LaTeX Source
            </h2>
            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded border border-slate-600 text-slate-400 hover:text-slate-200 hover:border-slate-500 transition-colors"
            >
              {copied ? (
                <>
                  <Check size={12} className="text-emerald-400" />
                  Copied
                </>
              ) : (
                <>
                  <Copy size={12} />
                  Copy
                </>
              )}
            </button>
          </div>

          {/* Source Content */}
          <div className="flex-1 overflow-auto p-4">
            {loadingLatex ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 size={24} className="text-indigo-400 animate-spin" />
              </div>
            ) : (
              <pre className="latex-source text-slate-300 whitespace-pre-wrap break-words">
                {latex || '% No LaTeX source available yet.'}
              </pre>
            )}
          </div>
        </div>

        {/* Right Panel: PDF Preview */}
        <div className="w-1/2 flex flex-col bg-slate-800 border border-slate-700 rounded-lg overflow-hidden">
          {/* Panel Header */}
          <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700 flex-shrink-0">
            <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">
              PDF Preview
            </h2>
          </div>

          {/* PDF Viewer */}
          <div className="flex-1 min-h-0">
            <iframe
              id="pdf-viewer"
              src={pdfUrl}
              className="w-full h-full border-0 bg-white"
              title="PDF Preview"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
