"""TaskDistributionAgent: enriches an outline into a detailed per-section writing plan."""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.orchestrator.task_graph import Task
from paperwrite.memory.manager import MemoryManager
from paperwrite.tools.llm_client import LLMClient
from paperwrite.orchestrator.events import EventBus, Event, EventType

logger = logging.getLogger(__name__)

# Default word-count budget per page (approximate, double-column academic).
_WORDS_PER_PAGE = 650


class TaskDistributionAgent(BaseAgent):
    """Analyse the user's topic and outline, then produce an enriched writing plan.

    The plan contains per-section writing instructions (target word count,
    key points, assigned agent type, and dependency hints) together with a
    set of research queries for the KnowledgeSearchAgent.

    This agent does **not** build the DAG task graph itself; the
    PipelineController consumes the plan dict and translates it into
    :class:`Task` nodes.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        review_criteria: Optional[list[str]] = None,
        max_self_review_iterations: int = 3,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="task_distribution",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=review_criteria
            or [
                "Every outline section must appear in the plan.",
                "Word-count targets must sum close to the requested page count.",
                "Research queries must be specific and academically oriented.",
            ],
            max_self_review_iterations=max_self_review_iterations,
        )

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def execute(self, task: Task) -> dict[str, Any]:
        """Generate a detailed writing plan from the user's outline.

        Expected ``task.input_data`` keys:

        * ``topic``      -- paper topic (str)
        * ``outline``    -- section hierarchy (list[dict] or dict)
        * ``page_count`` -- target page count (int, default 12)
        * ``project_id`` -- project identifier (str, optional)

        Returns a dict with:

        * ``sections``           -- list of enriched section descriptors
        * ``research_queries``   -- list of search query strings
        * ``total_target_words`` -- aggregate word budget
        """
        project_id: str = task.input_data.get("project_id", "")
        topic: str = task.input_data.get("topic", "")
        outline: Any = task.input_data.get("outline", [])
        page_count: int = task.input_data.get("page_count", 12)

        if not topic:
            logger.error("TaskDistributionAgent received empty topic.")
            return {"error": "Topic is required."}

        await self.emit_log(project_id, "info", f"Planning paper on: {topic}")

        total_target_words = page_count * _WORDS_PER_PAGE
        outline_json = json.dumps(outline, ensure_ascii=False)

        # ----- Step 1: generate the enriched writing plan -----
        plan = await self._generate_plan(
            topic, outline_json, page_count, total_target_words
        )

        if not plan or "sections" not in plan:
            logger.warning("LLM returned invalid plan; attempting fallback.")
            plan = self._build_fallback_plan(outline, total_target_words)

        # ----- Step 2: generate targeted research queries -----
        research_queries = await self._generate_research_queries(
            topic, plan.get("sections", [])
        )
        plan["research_queries"] = research_queries
        plan["total_target_words"] = total_target_words

        # Persist plan in short-term memory for downstream agents.
        self.save_memory("writing_plan", plan, term="short")

        await self.emit_log(
            project_id,
            "info",
            f"Plan ready: {len(plan.get('sections', []))} sections, "
            f"{len(research_queries)} research queries.",
        )

        await self.event_bus.emit(
            Event(
                type=EventType.TASK_COMPLETED,
                project_id=project_id,
                agent_id=self.agent_id,
                data={
                    "task_id": task.id,
                    "sections_count": len(plan.get("sections", [])),
                    "queries_count": len(research_queries),
                },
            )
        )

        return plan

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _generate_plan(
        self,
        topic: str,
        outline_json: str,
        page_count: int,
        total_target_words: int,
    ) -> dict[str, Any]:
        """Call the LLM to produce the structured writing plan."""

        system_prompt = (
            "You are an expert academic paper planner. Given a paper topic, "
            "an outline, a target page count, and an approximate word budget, "
            "produce a detailed writing plan in JSON.\n\n"
            "The JSON must have a top-level key \"sections\" containing an "
            "array. Each element is an object with:\n"
            "  - \"name\": section title (string)\n"
            "  - \"target_words\": approximate word count for this section (int)\n"
            "  - \"key_points\": list of bullet-point strings the writer must cover\n"
            "  - \"writing_instructions\": specific prose-style guidance (string)\n"
            "  - \"figures_needed\": list of figure descriptions needed (list[str])\n"
            "  - \"tables_needed\": list of table descriptions needed (list[str])\n"
            "  - \"references_focus\": what references to emphasise (string)\n"
            "  - \"agent\": which agent type should write it -- one of "
            "\"writer\", \"method_construction\", \"experiment_construction\" (string)\n"
            "  - \"dependencies\": list of section names this section depends on "
            "(e.g., Results depends on Methods) (list[str])\n"
            "  - \"priority\": integer 1-10 where 10 is highest priority\n\n"
            "Also include a top-level key \"abstract_guidance\" with a brief "
            "description of what the abstract should cover.\n\n"
            "Respond ONLY with valid JSON. No markdown fences, no commentary."
        )

        user_prompt = (
            f"Topic: {topic}\n"
            f"Outline: {outline_json}\n"
            f"Target pages: {page_count}\n"
            f"Total word budget: {total_target_words}\n\n"
            "Generate the detailed writing plan."
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        try:
            plan: dict[str, Any] = await self.chat_json(messages)
            logger.info(
                "Plan generated with %d sections.",
                len(plan.get("sections", [])),
            )
            return plan
        except Exception:
            logger.exception("Failed to generate writing plan via LLM.")
            return {}

    async def _generate_research_queries(
        self,
        topic: str,
        sections: list[dict[str, Any]],
    ) -> list[str]:
        """Use the LLM to derive targeted academic search queries."""

        section_summary = "\n".join(
            f"- {s.get('name', 'Unnamed')}: {', '.join(s.get('key_points', []))}"
            for s in sections
        )

        system_prompt = (
            "You are a research librarian specialising in academic literature. "
            "Given a paper topic and a list of sections with key points, "
            "generate a set of specific, targeted web search queries that "
            "would find relevant academic papers, surveys, and technical "
            "references.\n\n"
            "Include queries for:\n"
            "  - Related work and surveys\n"
            "  - Key techniques and methods\n"
            "  - Evaluation benchmarks and datasets\n"
            "  - Recent advances in the area\n\n"
            "Respond ONLY with valid JSON: {\"queries\": [\"query1\", ...]}"
        )

        user_prompt = (
            f"Topic: {topic}\n\n"
            f"Sections and key points:\n{section_summary}\n\n"
            "Generate 8-15 targeted search queries."
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        try:
            result = await self.chat_json(messages)
            queries = result.get("queries", [])
            if not queries:
                logger.warning("LLM returned empty query list; using topic fallback.")
                return [topic]
            return queries
        except Exception:
            logger.exception("Failed to generate research queries.")
            return [topic, f"{topic} survey", f"{topic} related work"]

    # ------------------------------------------------------------------
    # Fallback
    # ------------------------------------------------------------------

    @staticmethod
    def _build_fallback_plan(
        outline: Any,
        total_target_words: int,
    ) -> dict[str, Any]:
        """Construct a minimal plan when the LLM call fails."""

        sections_raw: list[Any] = []
        if isinstance(outline, list):
            sections_raw = outline
        elif isinstance(outline, dict):
            sections_raw = outline.get("sections", [outline])

        section_count = max(len(sections_raw), 1)
        words_each = total_target_words // section_count

        sections: list[dict[str, Any]] = []
        for idx, item in enumerate(sections_raw):
            name = (
                item
                if isinstance(item, str)
                else item.get("title", item.get("name", f"Section {idx + 1}"))
            )
            sections.append(
                {
                    "name": name,
                    "target_words": words_each,
                    "key_points": [f"Cover main aspects of {name}"],
                    "writing_instructions": "Write a comprehensive academic section.",
                    "figures_needed": [],
                    "tables_needed": [],
                    "references_focus": "relevant literature",
                    "agent": "writer",
                    "dependencies": [],
                    "priority": 5,
                }
            )

        return {
            "sections": sections,
            "abstract_guidance": "Summarise the main contribution of this paper.",
        }
