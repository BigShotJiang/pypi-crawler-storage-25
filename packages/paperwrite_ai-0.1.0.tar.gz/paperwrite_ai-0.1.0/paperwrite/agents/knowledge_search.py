"""KnowledgeSearchAgent: performs web searches and indexes results into ChromaDB."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Optional

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.orchestrator.task_graph import Task
from paperwrite.memory.manager import MemoryManager
from paperwrite.tools.llm_client import LLMClient
from paperwrite.tools.web_search import WebSearchTool, SearchResult
from paperwrite.rag.indexer import DocumentIndexer
from paperwrite.orchestrator.events import EventBus, Event, EventType

logger = logging.getLogger(__name__)

# Sensible upper bound to avoid runaway API costs.
_MAX_QUERIES = 20
# Maximum number of concurrent search requests.
_SEARCH_CONCURRENCY = 5


class KnowledgeSearchAgent(BaseAgent):
    """Execute web searches for a paper topic and index results into ChromaDB.

    The agent generates targeted academic search queries (using the LLM),
    runs them through the :class:`WebSearchTool`, and persists the results
    via :class:`DocumentIndexer` so that downstream agents can retrieve
    relevant knowledge through RAG.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        web_search_tool: WebSearchTool,
        document_indexer: DocumentIndexer,
        review_criteria: Optional[list[str]] = None,
        max_self_review_iterations: int = 3,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="knowledge_search",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=review_criteria or [],
            max_self_review_iterations=max_self_review_iterations,
        )
        self.web_search = web_search_tool
        self.indexer = document_indexer

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def execute(self, task: Task) -> dict[str, Any]:
        """Run research for the paper and index gathered knowledge.

        Expected ``task.input_data`` keys:

        * ``topic``       -- paper topic (str)
        * ``outline``     -- section list / hierarchy (list | dict, optional)
        * ``project_id``  -- project identifier (str)
        * ``queries``     -- pre-generated queries from the planning step
                             (list[str], optional)

        Returns a dict with:

        * ``sources_count``      -- total unique search results obtained
        * ``chunks_indexed``     -- total chunks written to ChromaDB
        * ``queries``            -- the queries that were executed
        * ``knowledge_summary``  -- brief LLM-generated summary of findings
        * ``sources``            -- list of {title, url} for the top results
        """
        project_id: str = task.input_data.get("project_id", "")
        topic: str = task.input_data.get("topic", "")
        outline: Any = task.input_data.get("outline", [])

        if not topic:
            logger.error("KnowledgeSearchAgent received empty topic.")
            return {"error": "Topic is required."}

        await self.emit_log(project_id, "info", f"Starting research for: {topic}")

        # --- Determine search queries ---
        queries: list[str] = task.input_data.get("queries", [])
        if not queries:
            queries = await self._generate_search_queries(topic, outline)
        queries = queries[:_MAX_QUERIES]

        await self.emit_log(
            project_id, "info", f"Generated {len(queries)} search queries."
        )

        # --- Execute searches with bounded concurrency ---
        all_results: list[SearchResult] = await self._run_searches(
            queries, project_id
        )

        await self.emit_log(
            project_id,
            "info",
            f"Collected {len(all_results)} unique results from {len(queries)} queries.",
        )

        # --- Index into ChromaDB ---
        chunks_indexed = 0
        if all_results:
            try:
                chunks_indexed = self.indexer.index_search_results(
                    project_id,
                    [self._result_to_dict(r) for r in all_results],
                )
                logger.info(
                    "Indexed %d chunks for project %s.", chunks_indexed, project_id
                )
                await self.emit_log(
                    project_id,
                    "info",
                    f"Indexed {chunks_indexed} chunks into knowledge base.",
                )
            except Exception:
                logger.exception(
                    "Failed to index search results for project %s.", project_id
                )

        # --- Summarise the gathered knowledge ---
        knowledge_summary = await self._summarise_results(topic, all_results)

        # Persist result count in short-term memory.
        self.save_memory("search_results_count", len(all_results), term="short")

        # --- Emit completion event ---
        await self.event_bus.emit(
            Event(
                type=EventType.KNOWLEDGE_INDEXED,
                project_id=project_id,
                agent_id=self.agent_id,
                data={
                    "task_id": task.id,
                    "sources_count": len(all_results),
                    "chunks_indexed": chunks_indexed,
                    "queries_count": len(queries),
                },
            )
        )

        return {
            "type": "knowledge",
            "sources_count": len(all_results),
            "chunks_indexed": chunks_indexed,
            "queries": queries,
            "knowledge_summary": knowledge_summary,
            "sources": [
                {"title": r.title, "url": r.url} for r in all_results[:20]
            ],
        }

    # ------------------------------------------------------------------
    # Query generation
    # ------------------------------------------------------------------

    async def _generate_search_queries(
        self,
        topic: str,
        outline: Any,
    ) -> list[str]:
        """Use the LLM to produce targeted academic search queries."""

        outline_text = (
            json.dumps(outline, ensure_ascii=False)
            if outline
            else "standard academic paper"
        )

        system_prompt = (
            "You are a research librarian specialising in academic literature. "
            "Given a paper topic and an optional outline, generate a list of "
            "specific web search queries designed to find relevant academic "
            "papers, surveys, datasets, and technical references.\n\n"
            "Include queries for:\n"
            "  - Core topic background and related work\n"
            "  - Specific methods or algorithms mentioned\n"
            "  - Evaluation benchmarks and baselines\n"
            "  - Recent state-of-the-art advances\n\n"
            "Respond ONLY with valid JSON: {\"queries\": [\"query1\", ...]}"
        )

        user_prompt = (
            f"Topic: {topic}\n"
            f"Outline: {outline_text}\n\n"
            "Generate 8-15 targeted search queries."
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        try:
            result = await self.chat_json(messages)
            queries = result.get("queries", [])
            if not queries:
                logger.warning("LLM returned empty queries; falling back to topic.")
                return [topic, f"{topic} survey", f"{topic} state of the art"]
            return queries[:_MAX_QUERIES]
        except Exception:
            logger.exception("Query generation failed; using topic fallback.")
            return [
                topic,
                f"{topic} survey",
                f"{topic} related work",
                f"{topic} evaluation",
                f"{topic} benchmark",
            ]

    # ------------------------------------------------------------------
    # Search execution
    # ------------------------------------------------------------------

    async def _run_searches(
        self, queries: list[str], project_id: str
    ) -> list[SearchResult]:
        """Execute all queries with bounded concurrency and de-duplication."""

        semaphore = asyncio.Semaphore(_SEARCH_CONCURRENCY)
        all_results: list[SearchResult] = []
        seen_urls: set[str] = set()

        async def _search_one(query: str) -> list[SearchResult]:
            async with semaphore:
                try:
                    results = await self.web_search.search(query, max_results=5)
                    await self.emit_log(
                        project_id,
                        "info",
                        f"Query '{query}': found {len(results)} results.",
                    )
                    return results
                except Exception:
                    logger.exception("Search failed for query: %r", query)
                    await self.emit_log(
                        project_id, "warning", f"Search failed: {query}"
                    )
                    return []

        tasks = [_search_one(q) for q in queries]
        batch_results = await asyncio.gather(*tasks)

        for results in batch_results:
            for result in results:
                if result.url not in seen_urls:
                    seen_urls.add(result.url)
                    all_results.append(result)

        # Sort by relevance score descending.
        all_results.sort(key=lambda r: r.score, reverse=True)
        return all_results

    # ------------------------------------------------------------------
    # Summarisation
    # ------------------------------------------------------------------

    async def _summarise_results(
        self,
        topic: str,
        results: list[SearchResult],
    ) -> str:
        """Generate a concise summary of the gathered knowledge."""

        if not results:
            return f"No search results found for {topic}."

        # Feed the top results to the LLM for a digest.
        snippets = "\n\n".join(
            f"[{r.title}]({r.url})\n{r.content[:500]}"
            for r in results[:15]
        )

        messages = [
            {
                "role": "system",
                "content": (
                    "Summarise the following web search results into a concise "
                    "knowledge digest relevant to the paper topic. Highlight "
                    "key findings, methods, datasets, and gaps in existing "
                    "work. This summary will be used as context for writing "
                    "an academic paper. Keep the summary under 500 words."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Paper topic: {topic}\n\n"
                    f"Search results:\n{snippets}"
                ),
            },
        ]

        try:
            return await self.chat(messages)
        except Exception:
            logger.exception("Knowledge summarisation failed.")
            return f"Knowledge gathered from {len(results)} sources about {topic}."

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _result_to_dict(result: SearchResult) -> dict[str, Any]:
        """Convert a :class:`SearchResult` dataclass to a plain dict."""
        return {
            "title": result.title,
            "url": result.url,
            "content": result.content,
            "score": result.score,
        }
