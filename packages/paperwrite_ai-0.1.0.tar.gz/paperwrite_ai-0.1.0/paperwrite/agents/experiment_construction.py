"""ExperimentConstructionAgent: designs experimental evaluation with placeholders."""

from __future__ import annotations

import logging
from typing import Any, Optional

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.memory.manager import MemoryManager
from paperwrite.orchestrator.events import EventBus
from paperwrite.orchestrator.task_graph import Task
from paperwrite.tools.llm_client import LLMClient

logger = logging.getLogger(__name__)


class ExperimentConstructionAgent(BaseAgent):
    """Designs a comprehensive experimental evaluation plan for the paper.

    Takes the proposed method (from dependency outputs) and generates an
    experiment section with research questions, setup, datasets, metrics,
    baselines, and expected structure.  Uses ``[PLACEHOLDER]`` markers for
    actual data values and performance numbers that will be filled later.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        max_self_review_iterations: int = 3,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="experiment_construction",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=[
                "Reproducibility: experimental steps are detailed enough to replicate",
                "Metrics: evaluation metrics are clearly defined and appropriate",
                "Baselines: relevant baselines are identified for comparison",
                "Datasets: data sources and preprocessing are specified",
                "Statistical rigor: appropriate statistical methods mentioned",
            ],
            max_self_review_iterations=max_self_review_iterations,
        )

    async def execute(self, task: Task) -> dict[str, Any]:
        """Generate an experiment design based on the proposed method.

        Parameters
        ----------
        task:
            Must contain ``input_data["topic"]``.  Expects
            ``input_data["dependency_outputs"]`` to include at least one
            output with ``"type": "method"``.

        Returns
        -------
        dict
            Contains ``"content"`` (LaTeX experiment text) and
            ``"type": "experiment"``.
        """
        project_id = task.input_data.get("project_id", "")
        topic: str = task.input_data["topic"]
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        await self.emit_log(project_id, "info", f"Starting experiment design for: {topic}")

        # Extract the method description from upstream dependencies.
        method_context = self._extract_method_context(dep_outputs)

        if not method_context:
            await self.emit_log(
                project_id, "warning",
                "No method context found in dependencies; generating experiment from topic only",
            )

        # Build and send prompt.
        messages = self._build_generation_messages(topic, method_context)
        initial_output = await self.chat(messages)

        if not initial_output.strip():
            await self.emit_log(project_id, "warning", "LLM returned empty experiment output; retrying")
            initial_output = await self.chat(messages)

        # Self-review loop for quality assurance.
        result: TaskResult = await self.execute_with_self_review(task, initial_output)
        result.output["type"] = "experiment"

        await self.emit_log(
            project_id,
            "info",
            f"Experiment design complete after {result.iterations} iteration(s)"
            + (f" - WARNING: {result.warning}" if result.warning else ""),
        )

        return result.output

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_method_context(dep_outputs: dict[str, Any]) -> str:
        """Extract method content from dependency outputs.

        Searches for outputs tagged with ``"type": "method"`` first, then
        falls back to any output containing ``"content"``.
        """
        # Priority 1: explicitly typed method outputs.
        for dep_id, output in dep_outputs.items():
            if not isinstance(output, dict):
                continue
            if output.get("type") == "method":
                return output.get("content", "")

        # Priority 2: any content-bearing output (e.g., knowledge summaries).
        parts: list[str] = []
        for dep_id, output in dep_outputs.items():
            if not isinstance(output, dict):
                continue
            if "content" in output:
                parts.append(str(output["content"]))

        return "\n\n".join(parts)

    @staticmethod
    def _build_generation_messages(topic: str, method_context: str) -> list[dict[str, str]]:
        """Construct prompt messages for experiment design generation."""
        system_prompt = (
            "You are an expert in experimental design. Design a comprehensive "
            "evaluation for the proposed method. Include:\n"
            "- Research questions that the experiments address\n"
            "- Experimental setup (hardware, software, environment)\n"
            "- Datasets: sources, sizes, preprocessing steps\n"
            "- Evaluation metrics with formal definitions\n"
            "- Baselines and competing approaches\n"
            "- Expected experiment structure (ablation studies, parameter sensitivity)\n\n"
            "Use [PLACEHOLDER] markers for actual experimental results, data values, "
            "and performance numbers that will be filled in later.\n\n"
            "Output in LaTeX format suitable for an academic paper's experiments section. "
            "Use \\subsection{} for major components."
        )

        user_content = f"Topic: {topic}\n\n"
        if method_context:
            user_content += f"Proposed Method:\n{method_context}\n\n"
        else:
            user_content += "Proposed Method: (not yet available)\n\n"
        user_content += "Design the experiments."

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
