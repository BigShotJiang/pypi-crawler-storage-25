"""ReviewerAgent: multi-persona academic review with majority voting."""

from __future__ import annotations

import json
import logging
from typing import Any

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.memory.manager import MemoryManager
from paperwrite.orchestrator.events import EventBus
from paperwrite.orchestrator.task_graph import Task
from paperwrite.tools.llm_client import LLMClient

logger = logging.getLogger(__name__)


class ReviewerAgent(BaseAgent):
    """Simulates an academic peer review process with multiple independent reviewers.

    Three reviewer personas evaluate the paper independently.  The paper
    passes review if a strict majority (>50%, i.e., at least 2 out of 3)
    assign an overall score >= 4.

    Each reviewer focuses on a different aspect: writing quality, method
    logic, or feasibility/reproducibility.
    """

    REVIEWER_PERSONAS: list[dict[str, str]] = [
        {
            "id": "reviewer_A",
            "focus": "writing quality and clarity",
            "style": "strict on grammar, flow, and academic tone",
        },
        {
            "id": "reviewer_B",
            "focus": "method logic and technical depth",
            "style": "emphasizes soundness of approach and theoretical grounding",
        },
        {
            "id": "reviewer_C",
            "focus": "feasibility and reproducibility",
            "style": "focuses on whether results can be reproduced and method is practical",
        },
    ]

    REVIEW_CRITERIA: list[str] = [
        "writing_quality",
        "method_logic",
        "technical_feasibility",
        "reproducibility",
    ]

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="reviewer",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=[],  # Reviewer does not self-review; it *is* the review.
        )

    async def execute(self, task: Task) -> dict[str, Any]:
        """Run multi-persona review on the assembled paper content.

        Parameters
        ----------
        task:
            ``input_data["dependency_outputs"]`` should contain the paper
            sections produced by upstream agents.

        Returns
        -------
        dict
            Keys: ``passed``, ``review_scores``, ``feedback``,
            ``revision_priority``, ``passing_count``, ``total_reviewers``,
            ``type``.
        """
        project_id = task.input_data.get("project_id", "")
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        await self.emit_log(project_id, "info", "Starting multi-persona peer review")

        # Collect all paper content from dependencies.
        paper_content = self._collect_paper_content(dep_outputs)

        if not paper_content or paper_content == "No content available":
            await self.emit_log(project_id, "warning", "No paper content found for review")

        # Run 3 independent reviews.
        reviews: list[dict[str, Any]] = []
        for persona in self.REVIEWER_PERSONAS:
            await self.emit_log(
                project_id, "info", f"Running review: {persona['id']} ({persona['focus']})"
            )
            review = await self._run_single_review(persona, paper_content)
            reviews.append(review)
            logger.info(
                "Review %s: overall=%.1f", persona["id"], review.get("overall", 0)
            )

        # Voting: pass if >50% give overall >= 4.
        passing_count = sum(1 for r in reviews if r.get("overall", 0) >= 4)
        passed = passing_count > len(reviews) / 2

        # Aggregate feedback from all reviewers.
        all_feedback: list[str] = []
        for r in reviews:
            all_feedback.extend(r.get("feedback", []))

        # Determine priority areas for revision (lowest average scores first).
        priority_areas = self._determine_priorities(reviews)

        await self.emit_log(
            project_id,
            "info",
            f"Review complete: {passing_count}/{len(reviews)} passed (threshold: >50%). "
            f"Decision: {'ACCEPT' if passed else 'REVISE'}",
        )

        return {
            "passed": passed,
            "review_scores": reviews,
            "feedback": all_feedback,
            "revision_priority": priority_areas,
            "passing_count": passing_count,
            "total_reviewers": len(reviews),
            "type": "review",
        }

    # ------------------------------------------------------------------
    # Single reviewer execution
    # ------------------------------------------------------------------

    async def _run_single_review(
        self, persona: dict[str, str], paper_content: str
    ) -> dict[str, Any]:
        """Execute a single reviewer persona's evaluation.

        Returns a dict with per-criterion scores, overall score, feedback,
        strengths, and weaknesses.
        """
        response_schema = json.dumps(
            {
                "reviewer_id": persona["id"],
                "writing_quality": 0,
                "method_logic": 0,
                "technical_feasibility": 0,
                "reproducibility": 0,
                "overall": 0.0,
                "feedback": ["specific feedback items"],
                "strengths": ["strengths"],
                "weaknesses": ["weaknesses"],
            },
            indent=2,
        )

        system_prompt = (
            f"You are an academic paper reviewer with expertise in {persona['focus']}. "
            f"Your reviewing style: {persona['style']}.\n\n"
            "Score each criterion from 1-5 (1=poor, 5=excellent). "
            "Provide specific, actionable feedback.\n\n"
            f"Respond in JSON:\n{response_schema}"
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Review this paper:\n\n{paper_content}"},
        ]

        try:
            result = await self.chat_json(messages)
            result["reviewer_id"] = persona["id"]

            # Calculate overall as the mean of criterion scores.
            scores = [result.get(c, 3) for c in self.REVIEW_CRITERIA]
            result["overall"] = sum(scores) / len(scores) if scores else 3.0

            # Ensure feedback is a list.
            if not isinstance(result.get("feedback"), list):
                result["feedback"] = [str(result.get("feedback", ""))]

            return result

        except Exception as e:
            logger.error("Review by %s failed: %s", persona["id"], e)
            return {
                "reviewer_id": persona["id"],
                "overall": 3.0,
                "writing_quality": 3,
                "method_logic": 3,
                "technical_feasibility": 3,
                "reproducibility": 3,
                "feedback": [f"Review failed: {e}"],
                "strengths": [],
                "weaknesses": [],
                "error": True,
            }

    # ------------------------------------------------------------------
    # Content collection
    # ------------------------------------------------------------------

    @staticmethod
    def _collect_paper_content(dep_outputs: dict[str, Any]) -> str:
        """Assemble paper text from all dependency outputs.

        Handles both flat ``"content"`` fields and structured ``"sections"``
        dicts.
        """
        parts: list[str] = []

        for dep_id, output in dep_outputs.items():
            if not isinstance(output, dict):
                continue
            if "content" in output:
                parts.append(str(output["content"]))
            elif "sections" in output:
                sections = output["sections"]
                if isinstance(sections, dict):
                    for name, content in sections.items():
                        parts.append(f"% Section: {name}\n{content}")

        return "\n\n".join(parts) if parts else "No content available"

    # ------------------------------------------------------------------
    # Priority determination
    # ------------------------------------------------------------------

    def _determine_priorities(self, reviews: list[dict[str, Any]]) -> list[str]:
        """Rank review criteria by average score (ascending = most needing work).

        Criteria with the lowest average scores are returned first,
        indicating the highest priority for revision.
        """
        avg_scores: dict[str, float] = {}

        for criterion in self.REVIEW_CRITERIA:
            scores = [
                r.get(criterion, 3) for r in reviews if not r.get("error")
            ]
            avg_scores[criterion] = sum(scores) / len(scores) if scores else 3.0

        # Sort ascending: weakest criteria first.
        return sorted(avg_scores, key=lambda c: avg_scores[c])
