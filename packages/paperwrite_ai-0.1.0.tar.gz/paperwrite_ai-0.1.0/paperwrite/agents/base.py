"""Base agent class providing LLM access, memory, self-review, and event emission."""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional

from paperwrite.memory.manager import MemoryManager
from paperwrite.tools.llm_client import LLMClient
from paperwrite.orchestrator.events import EventBus, Event, EventType
from paperwrite.orchestrator.task_graph import Task

logger = logging.getLogger(__name__)


@dataclass
class ReviewResult:
    passes: bool
    score: float = 0.0
    issues: list[str] = field(default_factory=list)
    feedback: str = ""


@dataclass
class TaskResult:
    output: dict[str, Any]
    review_metadata: Optional[ReviewResult] = None
    iterations: int = 1
    warning: str = ""


class BaseAgent(ABC):
    """Abstract base class for all agents in the paper writing pipeline."""

    def __init__(
        self,
        agent_id: str,
        agent_type: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        review_criteria: Optional[list[str]] = None,
        max_self_review_iterations: int = 3,
    ):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.llm = llm_client
        self.event_bus = event_bus
        self.memory = memory_manager
        self.review_criteria = review_criteria or []
        self.max_self_review_iterations = max_self_review_iterations

    @abstractmethod
    async def execute(self, task: Task) -> dict[str, Any]:
        """Execute a task and return output dict. Must be implemented by subclasses."""
        pass

    async def chat(self, messages: list[dict], **kwargs) -> str:
        """Send messages to LLM and return response."""
        return await self.llm.chat(messages, **kwargs)

    async def chat_json(self, messages: list[dict], **kwargs) -> dict:
        """Send messages to LLM and return parsed JSON response."""
        return await self.llm.chat_with_json(messages, **kwargs)

    async def self_review(self, output: str, criteria: list[str] = None) -> ReviewResult:
        """Self-review the generated output against criteria.

        Returns ReviewResult with pass/fail status and feedback.
        """
        criteria = criteria or self.review_criteria
        if not criteria:
            return ReviewResult(passes=True, score=5.0)

        criteria_text = "\n".join(f"- {c}" for c in criteria)
        messages = [
            {
                "role": "system",
                "content": (
                    "You are a critical academic reviewer. Evaluate the following "
                    "output against the given criteria. Be strict and thorough.\n\n"
                    "Respond in JSON format:\n"
                    '{"passes": true/false, "score": 1-5, "issues": ["issue1", ...], '
                    '"feedback": "detailed feedback for improvement"}'
                ),
            },
            {
                "role": "user",
                "content": (
                    f"## Criteria\n{criteria_text}\n\n"
                    f"## Output to Review\n{output}"
                ),
            },
        ]

        try:
            result = await self.chat_json(messages)
            return ReviewResult(
                passes=result.get("passes", False),
                score=result.get("score", 0),
                issues=result.get("issues", []),
                feedback=result.get("feedback", ""),
            )
        except Exception as e:
            logger.warning(f"Self-review failed: {e}")
            return ReviewResult(passes=True, score=3.0, feedback="Self-review failed")

    async def revise(self, output: str, feedback: str) -> str:
        """Revise output based on review feedback."""
        messages = [
            {
                "role": "system",
                "content": (
                    "You are an expert academic writer. Revise the following content "
                    "based on the feedback provided. Maintain academic English quality. "
                    "Return only the revised content, no explanations."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"## Feedback\n{feedback}\n\n"
                    f"## Content to Revise\n{output}"
                ),
            },
        ]
        return await self.chat(messages)

    async def execute_with_self_review(
        self, task: Task, initial_output: str
    ) -> TaskResult:
        """Execute self-review loop on initial output.

        1. Review output against criteria
        2. If issues found, revise and re-review
        3. Repeat up to max_self_review_iterations
        """
        output = initial_output

        for iteration in range(self.max_self_review_iterations):
            review = await self.self_review(output)

            await self.event_bus.emit(Event(
                type=EventType.SELF_REVIEW_ITERATION,
                project_id=task.input_data.get("project_id", ""),
                agent_id=self.agent_id,
                data={
                    "iteration": iteration + 1,
                    "passes": review.passes,
                    "score": review.score,
                    "issues_count": len(review.issues),
                },
            ))

            if review.passes and review.score >= 4.0:
                return TaskResult(
                    output={"content": output},
                    review_metadata=review,
                    iterations=iteration + 1,
                )

            output = await self.revise(output, review.feedback)

        # Max iterations reached
        return TaskResult(
            output={"content": output},
            review_metadata=review,
            iterations=self.max_self_review_iterations,
            warning="Max self-review iterations reached",
        )

    async def emit_log(self, project_id: str, level: str, message: str) -> None:
        """Emit a log event."""
        await self.event_bus.emit_log(project_id, self.agent_id, level, message)

    def save_memory(self, key: str, value: Any, term: str = "short") -> None:
        """Save to memory."""
        self.memory.save(key, value, term)

    def recall_memory(self, query: str, term: str = "both") -> Any:
        """Recall from memory."""
        return self.memory.recall(query, term)
