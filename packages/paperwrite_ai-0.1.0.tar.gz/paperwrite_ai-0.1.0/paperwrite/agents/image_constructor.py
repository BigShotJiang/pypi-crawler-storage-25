"""ImageConstructorAgent: generates academic figures using Matplotlib and Graphviz."""

from __future__ import annotations

import logging
import os
from typing import Any, Optional

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.memory.manager import MemoryManager
from paperwrite.orchestrator.events import EventBus
from paperwrite.orchestrator.task_graph import Task
from paperwrite.tools.graphviz_gen import GraphvizGenerator
from paperwrite.tools.llm_client import LLMClient
from paperwrite.tools.matplotlib_gen import MatplotlibGenerator

logger = logging.getLogger(__name__)


class ImageConstructorAgent(BaseAgent):
    """Generates publication-quality figures for the paper.

    Supported figure types:
    - **Flowcharts** rendered via Graphviz (DOT language).
    - **Charts** (line, bar, scatter, pie) rendered via Matplotlib.

    The agent uses the LLM to determine what figures are needed based on
    the paper content, then delegates rendering to the appropriate backend.
    A self-review loop checks for text readability, font consistency,
    number formatting, element overlap, and colour accessibility.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        matplotlib_gen: Optional[MatplotlibGenerator] = None,
        graphviz_gen: Optional[GraphvizGenerator] = None,
        output_dir: str = "storage/figures",
        max_self_review_iterations: int = 3,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="image_constructor",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=[
                "Text readability: all labels and titles are legible",
                "Font consistency: fonts are uniform across all figures",
                "Number formatting: numbers are properly formatted (decimal places, units)",
                "No overlapping elements: text and data do not overlap",
                "Color accessibility: colors are distinguishable",
            ],
            max_self_review_iterations=max_self_review_iterations,
        )
        self.matplotlib_gen = matplotlib_gen or MatplotlibGenerator()
        self.graphviz_gen = graphviz_gen or GraphvizGenerator()
        self.output_dir = output_dir

    async def execute(self, task: Task) -> dict[str, Any]:
        """Determine required figures and generate them.

        Parameters
        ----------
        task:
            ``input_data["dependency_outputs"]`` should contain the paper
            sections from upstream agents.

        Returns
        -------
        dict
            Keys: ``figures`` (list of generated figure metadata),
            ``count``, ``type``.
        """
        project_id = task.input_data.get("project_id", "")
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        await self.emit_log(project_id, "info", "Starting figure generation")

        # Ensure output directory exists.
        os.makedirs(self.output_dir, exist_ok=True)

        # Use LLM to determine what figures are needed.
        content = self._collect_content(dep_outputs)
        figure_specs = await self._plan_figures(content)

        figures = figure_specs.get("figures", [])
        if not figures:
            await self.emit_log(project_id, "info", "No figures required for this paper")
            return {"figures": [], "count": 0, "type": "figures"}

        await self.emit_log(project_id, "info", f"Planning {len(figures)} figure(s)")

        # Generate each figure.
        generated: list[dict[str, Any]] = []
        for idx, fig in enumerate(figures):
            try:
                path = await self._generate_figure(fig, project_id, idx)
                if path:
                    generated.append({
                        "id": fig.get("id", f"fig{idx + 1}"),
                        "title": fig.get("title", ""),
                        "path": path,
                        "type": fig.get("type", "unknown"),
                    })
            except Exception as e:
                logger.error("Failed to generate figure %s: %s", fig.get("id", idx), e)
                await self.emit_log(
                    project_id, "warning",
                    f"Figure generation failed for {fig.get('id', idx)}: {e}",
                )

        await self.emit_log(
            project_id, "info",
            f"Figure generation complete: {len(generated)}/{len(figures)} succeeded",
        )

        return {"figures": generated, "count": len(generated), "type": "figures"}

    # ------------------------------------------------------------------
    # Figure planning
    # ------------------------------------------------------------------

    async def _plan_figures(self, content: str) -> dict[str, Any]:
        """Use LLM to plan which figures the paper needs."""
        system_prompt = (
            "You are an expert in academic figure design. Based on the paper content, "
            "specify what figures should be generated. For each figure, provide:\n"
            "1. type: 'flowchart' or 'chart'\n"
            "2. For flowcharts: provide valid Graphviz DOT code in 'dot_code'\n"
            "3. For charts: provide 'chart_spec' with keys: chart_type "
            "(line/bar/pie/scatter), title, xlabel, ylabel, and data "
            "(list of {label, values})\n\n"
            "Respond in JSON:\n"
            '{"figures": [\n'
            '  {"id": "fig1", "type": "flowchart", "title": "...", "dot_code": "digraph{...}"},\n'
            '  {"id": "fig2", "type": "chart", "title": "...", "chart_spec": {"chart_type": "bar", ...}}\n'
            "]}"
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Paper content:\n{content[:6000]}"},
        ]

        try:
            return await self.chat_json(messages)
        except Exception as e:
            logger.error("Figure planning failed: %s", e)
            return {"figures": []}

    # ------------------------------------------------------------------
    # Figure generation
    # ------------------------------------------------------------------

    async def _generate_figure(
        self, fig: dict[str, Any], project_id: str, index: int
    ) -> Optional[str]:
        """Generate a single figure and return its file path."""
        fig_type = fig.get("type", "").lower()
        fig_id = fig.get("id", f"fig{index + 1}")

        if fig_type == "flowchart":
            return await self._generate_flowchart(fig, fig_id)
        elif fig_type == "chart":
            return await self._generate_chart(fig, fig_id)
        else:
            logger.warning("Unknown figure type %r for %s", fig_type, fig_id)
            return None

    async def _generate_flowchart(
        self, fig: dict[str, Any], fig_id: str
    ) -> Optional[str]:
        """Render a flowchart from DOT code using Graphviz."""
        dot_code = fig.get("dot_code", "")
        if not dot_code:
            logger.warning("No DOT code provided for flowchart %s", fig_id)
            return None

        output_path = os.path.join(self.output_dir, f"{fig_id}.pdf")

        try:
            rendered_path = await self.graphviz_gen.generate_diagram(
                dot_code=dot_code,
                output_path=output_path,
                format="pdf",
            )
            return rendered_path
        except Exception as e:
            logger.error("Graphviz rendering failed for %s: %s", fig_id, e)
            return None

    async def _generate_chart(
        self, fig: dict[str, Any], fig_id: str
    ) -> Optional[str]:
        """Render a chart from a chart specification using Matplotlib."""
        chart_spec = fig.get("chart_spec", {})
        if not chart_spec:
            logger.warning("No chart_spec provided for chart %s", fig_id)
            return None

        # Map chart_type to the format expected by MatplotlibGenerator.
        if "chart_type" in chart_spec and "type" not in chart_spec:
            chart_spec["type"] = chart_spec.pop("chart_type")

        output_path = os.path.join(self.output_dir, f"{fig_id}.pdf")

        try:
            rendered_path = self.matplotlib_gen.generate_chart(
                chart_spec=chart_spec,
                output_path=output_path,
            )
            return rendered_path
        except Exception as e:
            logger.error("Matplotlib rendering failed for %s: %s", fig_id, e)
            return None

    # ------------------------------------------------------------------
    # Content helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _collect_content(dep_outputs: dict[str, Any]) -> str:
        """Aggregate paper text from all dependency outputs."""
        parts: list[str] = []

        for dep_id, output in dep_outputs.items():
            if not isinstance(output, dict):
                continue
            if "content" in output:
                parts.append(str(output["content"]))
            elif "sections" in output:
                sections = output["sections"]
                if isinstance(sections, dict):
                    for name, content in sections.items():
                        parts.append(f"% Section: {name}\n{content}")

        return "\n\n".join(parts) if parts else "No content available"
