"""TableConstructorAgent: generates LaTeX tables for the paper."""

from __future__ import annotations

import logging
from typing import Any

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.memory.manager import MemoryManager
from paperwrite.orchestrator.events import EventBus
from paperwrite.orchestrator.task_graph import Task
from paperwrite.tools.llm_client import LLMClient

logger = logging.getLogger(__name__)


class TableConstructorAgent(BaseAgent):
    """Generates publication-quality LaTeX tables based on paper content.

    The agent uses the LLM to determine what tables are needed and produces
    properly formatted LaTeX tabular environments with captions, labels, and
    ``[PLACEHOLDER]`` markers for actual data values.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        max_self_review_iterations: int = 3,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="table_constructor",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=[
                "LaTeX syntax: all table environments are syntactically valid",
                "Column alignment: appropriate alignment specifiers used",
                "Caption and label: every table has a descriptive caption and unique label",
                "Placeholder usage: [PLACEHOLDER] used for unavailable data values",
                "Formatting: numbers and text are consistently formatted",
            ],
            max_self_review_iterations=max_self_review_iterations,
        )

    async def execute(self, task: Task) -> dict[str, Any]:
        """Generate LaTeX tables based on paper content from dependencies.

        Parameters
        ----------
        task:
            ``input_data["dependency_outputs"]`` should contain paper
            sections from upstream agents (method, experiment, etc.).

        Returns
        -------
        dict
            Keys: ``tables`` (list of table dicts with id, caption, label,
            latex), ``count``, ``type``.
        """
        project_id = task.input_data.get("project_id", "")
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        await self.emit_log(project_id, "info", "Starting table generation")

        # Collect paper content from dependencies.
        context = self._collect_content(dep_outputs)

        if not context or context == "No content available":
            await self.emit_log(project_id, "warning", "No content available for table generation")
            return {"tables": [], "count": 0, "type": "tables"}

        # Use LLM to determine and generate needed tables.
        messages = self._build_generation_messages(context)

        try:
            result = await self.chat_json(messages)
        except Exception as e:
            logger.error("Table generation LLM call failed: %s", e)
            await self.emit_log(project_id, "error", f"Table generation failed: {e}")
            return {"tables": [], "count": 0, "type": "tables"}

        tables = result.get("tables", [])

        # Validate table entries.
        validated_tables = self._validate_tables(tables)

        await self.emit_log(
            project_id, "info",
            f"Table generation complete: {len(validated_tables)} table(s) generated",
        )

        return {
            "tables": validated_tables,
            "count": len(validated_tables),
            "type": "tables",
        }

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_generation_messages(context: str) -> list[dict[str, str]]:
        """Construct the prompt messages for table generation."""
        system_prompt = (
            "You are an expert in academic table formatting. Based on the paper "
            "content, generate LaTeX tables. Use [PLACEHOLDER] for actual data "
            "values that are not yet available.\n\n"
            "Requirements:\n"
            "- Use proper LaTeX table/tabular environments\n"
            "- Include \\caption{} and \\label{tab:...} for each table\n"
            "- Use appropriate column alignment (l, c, r)\n"
            "- Include \\hline or \\toprule/\\midrule/\\bottomrule for structure\n"
            "- Use consistent number formatting\n\n"
            "Respond in JSON:\n"
            '{"tables": [\n'
            '  {"id": "tab1", "caption": "...", "label": "tab:...", '
            '"latex": "\\\\begin{table}[h]\\n...\\n\\\\end{table}"}\n'
            "]}"
        )

        # Truncate context to avoid exceeding token limits.
        truncated_context = context[:8000]

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Paper content:\n{truncated_context}"},
        ]

    @staticmethod
    def _validate_tables(tables: list[Any]) -> list[dict[str, str]]:
        """Validate and normalize table entries from LLM output.

        Ensures each table has the required fields (id, caption, label, latex).
        Discards malformed entries.
        """
        validated: list[dict[str, str]] = []

        for idx, table in enumerate(tables):
            if not isinstance(table, dict):
                logger.warning("Skipping non-dict table entry at index %d", idx)
                continue

            # Ensure required fields with sensible defaults.
            entry: dict[str, str] = {
                "id": table.get("id", f"tab{idx + 1}"),
                "caption": table.get("caption", f"Table {idx + 1}"),
                "label": table.get("label", f"tab:table{idx + 1}"),
                "latex": table.get("latex", ""),
            }

            if not entry["latex"]:
                logger.warning(
                    "Table %s has empty LaTeX content; skipping", entry["id"]
                )
                continue

            validated.append(entry)

        return validated

    @staticmethod
    def _collect_content(dep_outputs: dict[str, Any]) -> str:
        """Aggregate paper text from all dependency outputs."""
        parts: list[str] = []

        for dep_id, output in dep_outputs.items():
            if not isinstance(output, dict):
                continue
            if "content" in output:
                parts.append(str(output["content"]))
            elif "sections" in output:
                sections = output["sections"]
                if isinstance(sections, dict):
                    for name, content in sections.items():
                        parts.append(f"% Section: {name}\n{content}")

        return "\n\n".join(parts) if parts else "No content available"
