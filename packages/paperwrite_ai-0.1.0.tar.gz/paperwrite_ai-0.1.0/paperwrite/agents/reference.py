"""ReferenceAgent: manages BibTeX references with verification."""

from __future__ import annotations

import logging
import re
from typing import Any, Optional

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.memory.manager import MemoryManager
from paperwrite.orchestrator.events import EventBus
from paperwrite.orchestrator.task_graph import Task
from paperwrite.tools.llm_client import LLMClient
from paperwrite.tools.web_search import WebSearchTool

logger = logging.getLogger(__name__)


class ReferenceAgent(BaseAgent):
    """Generates and manages BibTeX references for the paper.

    Extracts citation keys from the LaTeX content produced by upstream
    agents, generates properly formatted BibTeX entries, and applies a
    self-review loop to verify completeness and correctness.

    Optionally uses a web search tool to verify that generated references
    correspond to real publications.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        web_search_tool: Optional[WebSearchTool] = None,
        max_self_review_iterations: int = 3,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="reference",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=[
                "All cited references have valid entries",
                "BibTeX format is consistent",
                "No duplicate entries",
                "Each reference has minimum required fields (author, title, year)",
            ],
            max_self_review_iterations=max_self_review_iterations,
        )
        self.web_search = web_search_tool

    async def execute(self, task: Task) -> dict[str, Any]:
        """Generate BibTeX entries for all citations found in the paper.

        Parameters
        ----------
        task:
            ``input_data["dependency_outputs"]`` should contain the paper
            sections that include ``\\cite{...}`` commands.

        Returns
        -------
        dict
            Keys: ``content`` (raw BibTeX), ``citation_count``, ``type``.
        """
        project_id = task.input_data.get("project_id", "")
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        await self.emit_log(project_id, "info", "Starting reference generation")

        # Collect all paper content from dependencies.
        paper_content = self._collect_content(dep_outputs)

        # Extract citation keys from LaTeX \cite{...} commands.
        all_keys = self._extract_citation_keys(paper_content)

        if not all_keys:
            await self.emit_log(
                project_id, "info", "No citation keys found in paper content"
            )
            return {
                "content": "",
                "citation_count": 0,
                "type": "bibtex",
            }

        await self.emit_log(
            project_id, "info", f"Found {len(all_keys)} unique citation key(s)"
        )

        # Optionally verify references via web search.
        verification_context = ""
        if self.web_search:
            verification_context = await self._verify_references(all_keys, project_id)

        # Generate BibTeX entries using LLM.
        messages = self._build_generation_messages(
            all_keys, paper_content, verification_context
        )
        bibtex_output = await self.chat(messages)

        if not bibtex_output.strip():
            await self.emit_log(project_id, "warning", "LLM returned empty BibTeX; retrying")
            bibtex_output = await self.chat(messages)

        # Self-review: verify completeness and formatting.
        result: TaskResult = await self.execute_with_self_review(task, bibtex_output)
        result.output["type"] = "bibtex"
        result.output["citation_count"] = len(all_keys)
        result.output["citation_keys"] = sorted(all_keys)

        await self.emit_log(
            project_id,
            "info",
            f"Reference generation complete: {len(all_keys)} entries "
            f"after {result.iterations} iteration(s)"
            + (f" - WARNING: {result.warning}" if result.warning else ""),
        )

        return result.output

    # ------------------------------------------------------------------
    # Citation key extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_citation_keys(paper_content: str) -> set[str]:
        """Extract all unique citation keys from LaTeX \\cite{} commands.

        Handles multiple keys per \\cite command (comma-separated) and
        various cite command variants (\\cite, \\citep, \\citet, \\citeauthor).
        """
        # Match \cite{...}, \citep{...}, \citet{...}, \citeauthor{...}, etc.
        cite_pattern = r"\\cite[a-z]*\{([^}]+)\}"
        matches = re.findall(cite_pattern, paper_content)

        all_keys: set[str] = set()
        for key_group in matches:
            for key in key_group.split(","):
                stripped = key.strip()
                if stripped:
                    all_keys.add(stripped)

        return all_keys

    # ------------------------------------------------------------------
    # Reference verification (optional)
    # ------------------------------------------------------------------

    async def _verify_references(
        self, citation_keys: set[str], project_id: str
    ) -> str:
        """Attempt to verify citation keys via web search.

        Returns a text summary of verification results that can inform
        BibTeX generation.
        """
        if not self.web_search:
            return ""

        verification_results: list[str] = []

        # Only verify a subset to avoid excessive API calls.
        keys_to_verify = sorted(citation_keys)[:10]

        for key in keys_to_verify:
            try:
                results = await self.web_search.search_academic(
                    query=key.replace("_", " "),
                    max_results=2,
                )
                if results:
                    top = results[0]
                    verification_results.append(
                        f"- {key}: Found '{top.title}' (score={top.score:.2f})"
                    )
                else:
                    verification_results.append(f"- {key}: No results found")
            except Exception as e:
                logger.warning("Web search failed for key %s: %s", key, e)
                verification_results.append(f"- {key}: Search error")

        if verification_results:
            await self.emit_log(
                project_id, "info",
                f"Verified {len(verification_results)} reference(s) via web search",
            )

        return "\n".join(verification_results)

    # ------------------------------------------------------------------
    # Prompt construction
    # ------------------------------------------------------------------

    @staticmethod
    def _build_generation_messages(
        citation_keys: set[str],
        paper_content: str,
        verification_context: str,
    ) -> list[dict[str, str]]:
        """Construct the prompt messages for BibTeX generation."""
        system_prompt = (
            "Generate valid BibTeX entries for the following citation keys from an "
            "academic paper. Each entry must have:\n"
            "- A correct BibTeX type (@article, @inproceedings, @book, etc.)\n"
            "- author field with proper name formatting\n"
            "- title field\n"
            "- year field\n"
            "- Appropriate venue fields (journal, booktitle, publisher, etc.)\n\n"
            "Use realistic, properly formatted entries based on the paper context. "
            "If a citation key suggests a well-known paper, generate an accurate entry. "
            "Otherwise, generate a plausible entry consistent with the paper's topic.\n\n"
            "Output raw BibTeX entries only (no markdown fences, no explanations)."
        )

        user_content = f"Citation keys: {sorted(citation_keys)}\n\n"
        user_content += f"Paper topic context:\n{paper_content[:3000]}"

        if verification_context:
            user_content += f"\n\nWeb search verification results:\n{verification_context}"

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]

    # ------------------------------------------------------------------
    # Content collection
    # ------------------------------------------------------------------

    @staticmethod
    def _collect_content(dep_outputs: dict[str, Any]) -> str:
        """Aggregate paper text from all dependency outputs."""
        parts: list[str] = []

        for dep_id, output in dep_outputs.items():
            if not isinstance(output, dict):
                continue
            if "content" in output:
                parts.append(str(output["content"]))
            elif "sections" in output:
                sections = output["sections"]
                if isinstance(sections, dict):
                    for name, content in sections.items():
                        parts.append(content)

        return "\n\n".join(parts) if parts else ""
