"""WriterAgent: generates, revises, and compiles LaTeX paper content."""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.orchestrator.task_graph import Task, TaskType
from paperwrite.memory.manager import MemoryManager
from paperwrite.tools.llm_client import LLMClient
from paperwrite.rag.retriever import KnowledgeRetriever, RetrievedChunk
from paperwrite.orchestrator.events import EventBus, Event, EventType

logger = logging.getLogger(__name__)

# Maximum characters of RAG context injected into the prompt.
_MAX_RAG_CONTEXT_CHARS = 6000
# Maximum characters of dependency context per entry.
_MAX_DEP_CONTEXT_CHARS = 2000


class WriterAgent(BaseAgent):
    """Primary writing agent that produces and revises LaTeX content.

    Supports three task types dispatched via :pymethod:`execute`:

    * **WRITE_SECTION** -- draft a single paper section in LaTeX.
    * **REVISE** -- revise previously written sections using reviewer feedback.
    * **COMPILE** -- assemble all sections and BibTeX into a final document
      structure ready for the LaTeX compiler.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        knowledge_retriever: Optional[KnowledgeRetriever] = None,
        review_criteria: Optional[list[str]] = None,
        max_self_review_iterations: int = 3,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="writer",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=review_criteria
            or [
                "LaTeX syntax must be correct and compilable.",
                "Academic English must be concise and formal.",
                "All claims should reference supporting evidence.",
                "Section structure must follow standard conventions.",
            ],
            max_self_review_iterations=max_self_review_iterations,
        )
        self.retriever = knowledge_retriever

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def execute(self, task: Task) -> dict[str, Any]:
        """Dispatch to the handler matching the task type."""

        project_id = task.input_data.get("project_id", "")

        try:
            if task.type == TaskType.WRITE_SECTION:
                return await self._write_section(task)
            elif task.type == TaskType.REVISE:
                return await self._revise_paper(task)
            elif task.type == TaskType.COMPILE:
                return await self._compile(task)
            else:
                logger.warning(
                    "WriterAgent received unsupported task type: %s", task.type
                )
                return {"error": f"Unsupported task type: {task.type}"}
        except Exception:
            logger.exception(
                "WriterAgent failed on task %s (type=%s).", task.id, task.type
            )
            await self.emit_log(
                project_id,
                "error",
                f"Writer failed on task {task.id}: {task.type}",
            )
            raise

    # ------------------------------------------------------------------
    # WRITE_SECTION
    # ------------------------------------------------------------------

    async def _write_section(self, task: Task) -> dict[str, Any]:
        """Draft a single paper section in LaTeX.

        Expected ``task.input_data`` keys:

        * ``section``            -- dict with at least ``title`` (and
          optionally ``key_points``, ``target_words``, ``writing_instructions``)
        * ``topic``              -- overall paper topic (str)
        * ``project_id``         -- project identifier (str, optional)
        * ``dependency_outputs`` -- outputs from upstream tasks (dict, optional)
        """
        section: dict[str, Any] = task.input_data.get("section", {})
        topic: str = task.input_data.get("topic", "")
        project_id: str = task.input_data.get("project_id", "")
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        section_title = section.get("title", section.get("name", "Unnamed Section"))
        target_words = section.get("target_words", 800)
        key_points = section.get("key_points", [])
        writing_instructions = section.get("writing_instructions", "")

        await self.emit_log(project_id, "info", f"Writing section: {section_title}")

        # -- Gather context from dependency outputs --
        dep_context = self._collect_context(dep_outputs)

        # -- Retrieve relevant knowledge from RAG --
        rag_context = self._retrieve_rag_context(project_id, section_title)

        # -- Build key points block --
        key_points_text = ""
        if key_points:
            key_points_text = "Key points to cover:\n" + "\n".join(
                f"  - {pt}" for pt in key_points
            )

        # -- Build the LLM prompt --
        system_prompt = (
            "You are an expert academic writer producing content for a "
            "research paper. Write in concise, formal, idiomatic academic "
            "English.\n\n"
            "Output LaTeX content ONLY -- no preamble, no "
            "\\\\documentclass, no \\\\begin{document}. Use proper LaTeX "
            "formatting including \\\\cite{}, \\\\ref{}, \\\\label{}, "
            "itemize/enumerate, and mathematical notation where appropriate.\n\n"
            "Do not include placeholder citations; if a claim needs a "
            "reference and you do not have a concrete one, mark it with "
            "\\\\cite{TODO}."
        )

        user_prompt = (
            f"Paper topic: {topic}\n"
            f"Section: {section_title}\n"
            f"Target word count: {target_words}\n"
        )
        if writing_instructions:
            user_prompt += f"Writing instructions: {writing_instructions}\n"
        if key_points_text:
            user_prompt += f"\n{key_points_text}\n"
        if rag_context:
            user_prompt += f"\nRelevant research context:\n{rag_context}\n"
        if dep_context:
            user_prompt += f"\nContext from prior pipeline stages:\n{dep_context}\n"
        user_prompt += "\nWrite this section in LaTeX now."

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        content = await self.chat(messages)

        await self.emit_log(
            project_id,
            "info",
            f"Section '{section_title}' drafted ({len(content)} chars).",
        )

        return {
            "section_name": section_title,
            "content": content,
            "type": "latex_section",
        }

    # ------------------------------------------------------------------
    # REVISE
    # ------------------------------------------------------------------

    async def _revise_paper(self, task: Task) -> dict[str, Any]:
        """Revise sections based on reviewer feedback.

        Expected ``task.input_data`` keys:

        * ``dependency_outputs`` -- must contain at least one output with
          ``review_scores`` (from the reviewer) and one or more outputs
          with ``type == "latex_section"``
        * ``project_id``         -- project identifier (str, optional)
        """
        project_id: str = task.input_data.get("project_id", "")
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        # -- Locate review data --
        review_data: Optional[dict[str, Any]] = None
        for dep_id, output in dep_outputs.items():
            if "review_scores" in output:
                review_data = output
                break

        if review_data is None or review_data.get("passed", False):
            logger.info("No revision needed (review passed or absent).")
            return {"revised": False, "content": "no_revision_needed"}

        # -- Collect section content from earlier write tasks --
        sections: dict[str, str] = {}
        for dep_id, output in dep_outputs.items():
            if output.get("type") == "latex_section":
                name = output.get("section_name", dep_id)
                sections[name] = output.get("content", "")

        if not sections:
            logger.warning("Revise task found no sections to revise.")
            return {"revised": False, "content": "no_sections_found"}

        # -- Build feedback text --
        feedback_items: list[str] = review_data.get("feedback", [])
        if isinstance(feedback_items, str):
            feedback_items = [feedback_items]
        feedback_text = "\n".join(f"- {f}" for f in feedback_items)

        await self.emit_log(
            project_id,
            "info",
            f"Revising {len(sections)} section(s) based on {len(feedback_items)} feedback item(s).",
        )

        # -- Revise each section --
        revised_sections: dict[str, str] = {}
        for name, content in sections.items():
            try:
                revised = await self.revise(content, feedback_text)
                revised_sections[name] = revised
            except Exception:
                logger.exception("Revision failed for section: %s", name)
                revised_sections[name] = content  # keep original on failure

        return {
            "revised": True,
            "sections": revised_sections,
            "type": "revised_paper",
        }

    # ------------------------------------------------------------------
    # COMPILE
    # ------------------------------------------------------------------

    async def _compile(self, task: Task) -> dict[str, Any]:
        """Assemble all sections and BibTeX into a final document structure.

        The actual PDF compilation is handled by
        :class:`backend.tools.latex_compiler.LaTeXCompiler`; this method
        only gathers and orders the content.

        Expected ``task.input_data`` keys:

        * ``dependency_outputs`` -- outputs from write/revise/reference tasks
        * ``project_id``         -- project identifier (str)
        * ``template``           -- LaTeX template name (str, default ``"ieee_conference"``)
        * ``title``              -- paper title (str, optional)
        * ``authors``            -- author list (str, optional)
        """
        project_id: str = task.input_data.get("project_id", "")
        template: str = task.input_data.get("template", "ieee_conference")
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        await self.emit_log(project_id, "info", "Compiling final document.")

        sections_content: list[str] = []
        references_bib: str = ""

        for dep_id, output in dep_outputs.items():
            output_type = output.get("type", "")

            if output_type == "revised_paper":
                # Revised output may contain a dict of sections.
                for name, content in output.get("sections", {}).items():
                    sections_content.append(content)
            elif output_type == "latex_section":
                content = output.get("content", "")
                if content:
                    sections_content.append(content)
            elif output_type == "bibtex":
                references_bib = output.get("content", "")

        full_content = "\n\n".join(sections_content)

        await self.emit_log(
            project_id,
            "info",
            f"Compilation assembled: {len(sections_content)} section(s), "
            f"{len(full_content)} chars total.",
        )

        await self.event_bus.emit(
            Event(
                type=EventType.COMPILATION_REQUESTED,
                project_id=project_id,
                agent_id=self.agent_id,
                data={
                    "task_id": task.id,
                    "sections_count": len(sections_content),
                    "has_bibtex": bool(references_bib),
                },
            )
        )

        return {
            "latex_content": full_content,
            "bibtex_content": references_bib,
            "template": template,
            "project_id": project_id,
            "type": "compiled_paper",
        }

    # ------------------------------------------------------------------
    # Context helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _collect_context(dep_outputs: dict[str, Any]) -> str:
        """Merge dependency outputs into a single context string."""
        parts: list[str] = []
        for dep_id, output in dep_outputs.items():
            content = output.get("content")
            if content is not None:
                truncated = str(content)[:_MAX_DEP_CONTEXT_CHARS]
                parts.append(truncated)
        return "\n---\n".join(parts)

    def _retrieve_rag_context(
        self,
        project_id: str,
        section_title: str,
    ) -> str:
        """Fetch relevant chunks from the knowledge store."""
        if not self.retriever or not project_id:
            return ""

        try:
            chunks: list[RetrievedChunk] = self.retriever.retrieve_for_section(
                project_id,
                section_title,
            )
            if not chunks:
                return ""

            parts = [c.content for c in chunks]
            combined = "\n\n".join(parts)
            return combined[:_MAX_RAG_CONTEXT_CHARS]
        except Exception:
            logger.exception(
                "RAG retrieval failed for project %s, section '%s'.",
                project_id,
                section_title,
            )
            return ""
