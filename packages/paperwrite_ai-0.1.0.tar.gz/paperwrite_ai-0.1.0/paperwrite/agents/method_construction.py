"""MethodConstructionAgent: proposes a novel research method with self-review."""

from __future__ import annotations

import logging
from typing import Any, Optional

from paperwrite.agents.base import BaseAgent, TaskResult, ReviewResult
from paperwrite.memory.manager import MemoryManager
from paperwrite.orchestrator.events import EventBus
from paperwrite.orchestrator.task_graph import Task
from paperwrite.tools.llm_client import LLMClient

logger = logging.getLogger(__name__)


class MethodConstructionAgent(BaseAgent):
    """Constructs a research methodology section for an academic paper.

    The agent uses dependency outputs (e.g., knowledge summaries from prior
    research tasks) to propose a novel, technically sound method.  It applies
    a self-review loop to verify logical consistency, feasibility, novelty,
    and completeness before returning the final output.
    """

    def __init__(
        self,
        agent_id: str,
        llm_client: LLMClient,
        event_bus: EventBus,
        memory_manager: MemoryManager,
        max_self_review_iterations: int = 3,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            agent_type="method_construction",
            llm_client=llm_client,
            event_bus=event_bus,
            memory_manager=memory_manager,
            review_criteria=[
                "Logical consistency: no contradictions in the proposed method",
                "Technical soundness: the approach is feasible and well-grounded",
                "Novelty: clear articulation of what is new vs existing work",
                "Completeness: all key components of the method are described",
            ],
            max_self_review_iterations=max_self_review_iterations,
        )

    async def execute(self, task: Task) -> dict[str, Any]:
        """Generate a methodology section based on topic and research context.

        Parameters
        ----------
        task:
            Must contain ``input_data["topic"]``.  Optionally includes
            ``input_data["dependency_outputs"]`` with upstream knowledge.

        Returns
        -------
        dict
            Contains ``"content"`` (the LaTeX method text) and
            ``"type": "method"``.
        """
        project_id = task.input_data.get("project_id", "")
        topic: str = task.input_data["topic"]
        dep_outputs: dict[str, Any] = task.input_data.get("dependency_outputs", {})

        await self.emit_log(project_id, "info", f"Starting method construction for: {topic}")

        # Gather research knowledge from upstream dependencies.
        research_context = self._gather_research_context(dep_outputs)

        # Generate the initial method proposal.
        messages = self._build_generation_messages(topic, research_context)
        initial_output = await self.chat(messages)

        if not initial_output.strip():
            await self.emit_log(project_id, "warning", "LLM returned empty method output; retrying")
            initial_output = await self.chat(messages)

        # Self-review loop: iteratively refine until quality threshold is met.
        result: TaskResult = await self.execute_with_self_review(task, initial_output)
        result.output["type"] = "method"

        await self.emit_log(
            project_id,
            "info",
            f"Method construction complete after {result.iterations} iteration(s)"
            + (f" - WARNING: {result.warning}" if result.warning else ""),
        )

        return result.output

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _gather_research_context(dep_outputs: dict[str, Any]) -> str:
        """Extract research context from dependency outputs.

        Looks for ``knowledge_summary`` fields first, then falls back to
        generic ``content`` fields.
        """
        parts: list[str] = []

        for dep_id, output in dep_outputs.items():
            if not isinstance(output, dict):
                continue
            if "knowledge_summary" in output:
                parts.append(output["knowledge_summary"])
            elif "content" in output:
                parts.append(str(output["content"]))

        return "\n\n".join(parts) if parts else ""

    @staticmethod
    def _build_generation_messages(topic: str, research_context: str) -> list[dict[str, str]]:
        """Construct the prompt messages for method generation."""
        system_prompt = (
            "You are an expert researcher. Given the topic and background knowledge, "
            "propose a novel and technically sound method. Output in LaTeX format "
            "suitable for an academic paper's methodology section. Include subsections "
            "for each major component of the method.\n\n"
            "Requirements:\n"
            "- Use \\subsection{} for each major component\n"
            "- Include mathematical formulations where appropriate\n"
            "- Clearly state assumptions and constraints\n"
            "- Distinguish what is novel from what leverages existing work\n"
            "- Ensure the method is complete and self-contained"
        )

        user_content = f"Topic: {topic}\n\n"
        if research_context:
            user_content += f"Background Knowledge:\n{research_context}\n\n"
        else:
            user_content += "Background Knowledge: (none provided)\n\n"
        user_content += "Propose a method."

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
