"""Application configuration loaded from environment variables and .env file."""

from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central configuration for the Multi-Agent Paper Writing System.

    Values are loaded from a .env file (if present) and can be overridden by
    real environment variables.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- API keys (all optional; only required when the corresponding
    #     provider is actually used) ---
    OPENAI_API_KEY: Optional[str] = None
    ANTHROPIC_API_KEY: Optional[str] = None
    GOOGLE_API_KEY: Optional[str] = None
    DEEPSEEK_API_KEY: Optional[str] = None
    TAVILY_API_KEY: Optional[str] = None

    # --- Model defaults ---
    DEFAULT_MODEL: str = "gpt-4o"

    # --- Storage paths ---
    CHROMA_PERSIST_DIR: str = "./storage/chroma_db"
    SQLITE_DB_PATH: str = "./storage/paperwrite.db"
    STORAGE_DIR: str = "./storage"

    # --- Server ---
    HOST: str = "0.0.0.0"
    PORT: int = 8000


settings = Settings()
