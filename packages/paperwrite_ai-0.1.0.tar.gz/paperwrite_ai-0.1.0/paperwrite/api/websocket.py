"""WebSocket endpoint and connection manager for real-time updates."""

from __future__ import annotations

import json
from typing import Any, Dict, List

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter()


class ConnectionManager:
    """Manages per-project WebSocket connections and broadcasts."""

    def __init__(self) -> None:
        # project_id -> list of active WebSocket connections
        self._connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, project_id: str, websocket: WebSocket) -> None:
        """Accept and register a WebSocket connection for *project_id*."""
        await websocket.accept()
        self._connections.setdefault(project_id, []).append(websocket)

    def disconnect(self, project_id: str, websocket: WebSocket) -> None:
        """Remove a WebSocket connection from the project pool."""
        conns = self._connections.get(project_id, [])
        if websocket in conns:
            conns.remove(websocket)
        if not conns:
            self._connections.pop(project_id, None)

    async def broadcast(self, project_id: str, message: Dict[str, Any]) -> None:
        """Send a JSON message to every connection listening on *project_id*.

        Message should include a ``type`` key. Recognised types:
        - ``agent_status``  -- agent lifecycle updates
        - ``log``           -- streaming log lines
        - ``task_update``   -- task status transitions
        - ``review_result`` -- review scores / comments
        - ``compilation``   -- LaTeX compilation progress
        """
        dead: List[WebSocket] = []
        for ws in self._connections.get(project_id, []):
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(project_id, ws)

    async def send_personal(
        self, websocket: WebSocket, message: Dict[str, Any]
    ) -> None:
        """Send a JSON message to a single connection."""
        await websocket.send_json(message)

    def get_connection_count(self, project_id: str) -> int:
        """Return the number of active connections for a project."""
        return len(self._connections.get(project_id, []))


# Singleton used across the application
manager = ConnectionManager()


@router.websocket("/ws/{project_id}")
async def websocket_endpoint(websocket: WebSocket, project_id: str) -> None:
    """WebSocket endpoint that streams real-time updates for a project."""
    await manager.connect(project_id, websocket)
    try:
        while True:
            # Keep the connection alive; optionally handle client messages
            raw = await websocket.receive_text()
            try:
                data = json.loads(raw)
                # Echo acknowledgement
                await manager.send_personal(
                    websocket,
                    {"type": "ack", "received": data},
                )
            except json.JSONDecodeError:
                await manager.send_personal(
                    websocket,
                    {"type": "error", "detail": "Invalid JSON"},
                )
    except WebSocketDisconnect:
        manager.disconnect(project_id, websocket)
