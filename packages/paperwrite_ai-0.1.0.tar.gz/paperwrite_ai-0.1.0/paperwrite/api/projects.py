"""REST API router for project management."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, BackgroundTasks, HTTPException, status
from pydantic import BaseModel, Field

from paperwrite.database import get_db

router = APIRouter(prefix="/api/projects", tags=["projects"])


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------

class APIKeysConfig(BaseModel):
    """Optional per-project API key overrides."""
    openai_api_key: Optional[str] = None
    anthropic_api_key: Optional[str] = None
    google_api_key: Optional[str] = None
    deepseek_api_key: Optional[str] = None
    tavily_api_key: Optional[str] = None
    default_model: Optional[str] = None


class ProjectCreate(BaseModel):
    """Payload for creating a new project."""
    topic: str = Field(..., min_length=1, max_length=500)
    outline: Optional[str] = None
    page_count: int = Field(default=6, ge=1, le=100)
    template: str = Field(default="ieee_conference")
    config: Optional[APIKeysConfig] = None


class ProjectResponse(BaseModel):
    """Serialised project returned to the client."""
    id: str
    topic: str
    outline: Optional[str] = None
    page_count: int
    template: str
    config: Optional[Dict[str, Any]] = None
    status: str
    created_at: str
    updated_at: str


class ProjectListResponse(BaseModel):
    """Wrapper for a list of projects."""
    projects: List[ProjectResponse]
    total: int


# ---------------------------------------------------------------------------
# Background pipeline stub
# ---------------------------------------------------------------------------

async def _run_pipeline(project_id: str) -> None:
    """Placeholder that will be replaced by the orchestrator pipeline."""
    async with get_db() as db:
        await db.execute(
            "UPDATE projects SET status = ?, updated_at = ? WHERE id = ?",
            ("running", datetime.now(timezone.utc).isoformat(), project_id),
        )
        await db.commit()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post(
    "",
    response_model=ProjectResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_project(payload: ProjectCreate) -> ProjectResponse:
    """Create a new paper-writing project."""
    project_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    config_json = (
        payload.config.model_dump_json() if payload.config else None
    )

    async with get_db() as db:
        await db.execute(
            """
            INSERT INTO projects (id, topic, outline, page_count, template, config, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                project_id,
                payload.topic,
                payload.outline,
                payload.page_count,
                payload.template,
                config_json,
                "created",
                now,
                now,
            ),
        )
        await db.commit()

    return ProjectResponse(
        id=project_id,
        topic=payload.topic,
        outline=payload.outline,
        page_count=payload.page_count,
        template=payload.template,
        config=payload.config.model_dump() if payload.config else None,
        status="created",
        created_at=now,
        updated_at=now,
    )


@router.get("", response_model=ProjectListResponse)
async def list_projects() -> ProjectListResponse:
    """Return all projects ordered by creation date (newest first)."""
    async with get_db() as db:
        cursor = await db.execute(
            "SELECT * FROM projects ORDER BY created_at DESC"
        )
        rows = await cursor.fetchall()

    projects = [
        ProjectResponse(
            id=row["id"],
            topic=row["topic"],
            outline=row["outline"],
            page_count=row["page_count"],
            template=row["template"],
            config=json.loads(row["config"]) if row["config"] else None,
            status=row["status"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )
        for row in rows
    ]

    return ProjectListResponse(projects=projects, total=len(projects))


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: str) -> ProjectResponse:
    """Return a single project by its ID."""
    async with get_db() as db:
        cursor = await db.execute(
            "SELECT * FROM projects WHERE id = ?", (project_id,)
        )
        row = await cursor.fetchone()

    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project {project_id} not found",
        )

    return ProjectResponse(
        id=row["id"],
        topic=row["topic"],
        outline=row["outline"],
        page_count=row["page_count"],
        template=row["template"],
        config=json.loads(row["config"]) if row["config"] else None,
        status=row["status"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


@router.post("/{project_id}/start", response_model=Dict[str, str])
async def start_pipeline(
    project_id: str,
    background_tasks: BackgroundTasks,
) -> Dict[str, str]:
    """Start the multi-agent paper writing pipeline as a background task."""
    async with get_db() as db:
        cursor = await db.execute(
            "SELECT id, status FROM projects WHERE id = ?", (project_id,)
        )
        row = await cursor.fetchone()

    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project {project_id} not found",
        )

    if row["status"] == "running":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Pipeline is already running for this project",
        )

    background_tasks.add_task(_run_pipeline, project_id)

    return {"project_id": project_id, "status": "started"}


@router.delete(
    "/{project_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_project(project_id: str) -> None:
    """Delete a project and all associated data."""
    async with get_db() as db:
        cursor = await db.execute(
            "SELECT id FROM projects WHERE id = ?", (project_id,)
        )
        row = await cursor.fetchone()

        if row is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Project {project_id} not found",
            )

        await db.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        await db.commit()
