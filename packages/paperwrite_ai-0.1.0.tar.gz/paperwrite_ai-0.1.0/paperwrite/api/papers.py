"""REST API router for paper artifacts (PDF, LaTeX source, compilation)."""

from __future__ import annotations

import os
from typing import Any, Dict

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse
from pydantic import BaseModel

from paperwrite.config import settings
from paperwrite.database import get_db

router = APIRouter(prefix="/api/projects", tags=["papers"])


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------

class LatexResponse(BaseModel):
    """LaTeX source returned to the client."""
    project_id: str
    latex_source: str
    filename: str


class CompilationResult(BaseModel):
    """Result of a LaTeX compilation request."""
    project_id: str
    status: str
    message: str
    pdf_path: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _project_dir(project_id: str) -> str:
    """Return the on-disk storage directory for a given project."""
    return os.path.join(settings.STORAGE_DIR, "projects", project_id)


def _compiled_dir(project_id: str) -> str:
    """Return the compiled-output directory for a given project."""
    return os.path.join(settings.STORAGE_DIR, "compiled", project_id)


async def _assert_project_exists(project_id: str) -> None:
    """Raise 404 if the project does not exist in the database."""
    async with get_db() as db:
        cursor = await db.execute(
            "SELECT id FROM projects WHERE id = ?", (project_id,)
        )
        row = await cursor.fetchone()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project {project_id} not found",
        )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/{project_id}/pdf")
async def get_pdf(project_id: str) -> FileResponse:
    """Serve the compiled PDF for the project."""
    await _assert_project_exists(project_id)

    pdf_path = os.path.join(_compiled_dir(project_id), "paper.pdf")
    if not os.path.isfile(pdf_path):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="PDF has not been compiled yet. Trigger /compile first.",
        )

    return FileResponse(
        path=pdf_path,
        media_type="application/pdf",
        filename=f"paper_{project_id[:8]}.pdf",
    )


@router.get("/{project_id}/latex", response_model=LatexResponse)
async def get_latex(project_id: str) -> LatexResponse:
    """Return the LaTeX source for the project."""
    await _assert_project_exists(project_id)

    tex_path = os.path.join(_project_dir(project_id), "paper.tex")
    if not os.path.isfile(tex_path):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="LaTeX source not generated yet.",
        )

    with open(tex_path, "r", encoding="utf-8") as fh:
        source = fh.read()

    return LatexResponse(
        project_id=project_id,
        latex_source=source,
        filename="paper.tex",
    )


@router.post("/{project_id}/compile", response_model=CompilationResult)
async def compile_paper(project_id: str) -> CompilationResult:
    """Trigger LaTeX compilation for the project.

    The actual compilation logic (calling pdflatex / latexmk) will be
    implemented in a dedicated tools module. This endpoint validates
    pre-conditions and delegates to that tool.
    """
    await _assert_project_exists(project_id)

    tex_path = os.path.join(_project_dir(project_id), "paper.tex")
    if not os.path.isfile(tex_path):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No LaTeX source to compile. Run the pipeline first.",
        )

    # Ensure output directory exists
    compiled_dir = _compiled_dir(project_id)
    os.makedirs(compiled_dir, exist_ok=True)

    # TODO: invoke the actual LaTeX compiler tool here
    # For now, return a placeholder indicating the endpoint is wired up.
    return CompilationResult(
        project_id=project_id,
        status="pending",
        message="Compilation endpoint is ready. LaTeX compiler integration pending.",
        pdf_path=None,
    )
