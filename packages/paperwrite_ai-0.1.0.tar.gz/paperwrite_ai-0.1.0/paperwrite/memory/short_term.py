"""Short-term memory: per-agent conversation context stored as JSON files."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass
class Message:
    """A single message in the conversation context."""

    role: str
    content: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ShortTermMemory:
    """Sliding-window conversation memory persisted to JSON files.

    Storage layout:
        ``{storage_dir}/memory/{agent_id}/{session_id}.json``

    Each JSON file contains an array of :class:`Message` dicts.
    """

    def __init__(
        self,
        agent_id: str,
        session_id: str,
        storage_dir: str = "storage",
        max_messages: int = 100,
    ) -> None:
        self.agent_id = agent_id
        self.session_id = session_id
        self.max_messages = max_messages

        self._dir = Path(storage_dir) / "memory" / agent_id
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file = self._dir / f"{session_id}.json"

        self._messages: list[dict[str, Any]] = self._load()

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------

    def _load(self) -> list[dict[str, Any]]:
        if self._file.exists():
            try:
                with open(self._file, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                    if isinstance(data, list):
                        return data
            except (json.JSONDecodeError, OSError):
                pass
        return []

    def _save(self) -> None:
        with open(self._file, "w", encoding="utf-8") as fh:
            json.dump(self._messages, fh, indent=2, ensure_ascii=False)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_message(self, role: str, content: str) -> None:
        """Append a message and persist to disk.

        If the buffer exceeds ``max_messages`` the oldest entries are
        dropped (sliding window).
        """
        msg = Message(role=role, content=content)
        self._messages.append(asdict(msg))

        # Enforce sliding window.
        if len(self._messages) > self.max_messages:
            self._messages = self._messages[-self.max_messages :]

        self._save()

    def get_context(self, last_n: int = 10) -> list[dict[str, Any]]:
        """Return the most recent *last_n* messages."""
        return self._messages[-last_n:]

    def clear(self) -> None:
        """Remove all messages and delete the backing file."""
        self._messages = []
        if self._file.exists():
            os.remove(self._file)

    def get_summary(self) -> dict[str, Any]:
        """Return a lightweight summary of the current memory state."""
        return {
            "agent_id": self.agent_id,
            "session_id": self.session_id,
            "total_messages": len(self._messages),
            "roles": list({m["role"] for m in self._messages}),
            "first_timestamp": self._messages[0]["timestamp"] if self._messages else None,
            "last_timestamp": self._messages[-1]["timestamp"] if self._messages else None,
        }

    def __len__(self) -> int:
        return len(self._messages)

    def __repr__(self) -> str:
        return (
            f"ShortTermMemory(agent_id={self.agent_id!r}, "
            f"session_id={self.session_id!r}, messages={len(self._messages)})"
        )
