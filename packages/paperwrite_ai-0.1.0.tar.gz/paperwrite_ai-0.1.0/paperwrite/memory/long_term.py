"""Long-term memory: persistent knowledge stored in SQLite via aiosqlite."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

import aiosqlite


@dataclass
class MemoryRecord:
    """A single record in the long-term memory store."""

    id: int
    agent_id: str
    project_id: str
    key: str
    value: Any
    task_type: Optional[str] = None
    created_at: str = ""
    updated_at: str = ""


_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS long_term_memory (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id    TEXT    NOT NULL,
    project_id  TEXT    NOT NULL,
    key         TEXT    NOT NULL,
    value       TEXT    NOT NULL,
    task_type   TEXT,
    created_at  TEXT    NOT NULL,
    updated_at  TEXT    NOT NULL
);
"""

_CREATE_INDEX_SQL = [
    "CREATE INDEX IF NOT EXISTS idx_ltm_agent ON long_term_memory(agent_id);",
    "CREATE INDEX IF NOT EXISTS idx_ltm_project ON long_term_memory(project_id);",
    "CREATE INDEX IF NOT EXISTS idx_ltm_key ON long_term_memory(key);",
    "CREATE INDEX IF NOT EXISTS idx_ltm_task_type ON long_term_memory(task_type);",
]


class LongTermMemory:
    """Async-compatible persistent memory backed by SQLite.

    Values are stored as JSON-serialized text, allowing arbitrary
    Python objects that survive ``json.dumps`` / ``json.loads``.
    """

    def __init__(self, db_path: str = "storage/paperwrite.db") -> None:
        self.db_path = db_path
        self._initialised = False

    async def _ensure_schema(self, db: aiosqlite.Connection) -> None:
        if not self._initialised:
            await db.execute(_CREATE_TABLE_SQL)
            for idx_sql in _CREATE_INDEX_SQL:
                await db.execute(idx_sql)
            await db.commit()
            self._initialised = True

    async def _connect(self) -> aiosqlite.Connection:
        db = await aiosqlite.connect(self.db_path)
        db.row_factory = aiosqlite.Row
        await self._ensure_schema(db)
        return db

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def store(
        self,
        agent_id: str,
        project_id: str,
        key: str,
        value: Any,
        task_type: Optional[str] = None,
    ) -> int:
        """Persist a key-value pair and return its row id."""
        now = datetime.now(timezone.utc).isoformat()
        serialized = json.dumps(value, ensure_ascii=False)

        db = await self._connect()
        try:
            cursor = await db.execute(
                """
                INSERT INTO long_term_memory
                    (agent_id, project_id, key, value, task_type, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (agent_id, project_id, key, serialized, task_type, now, now),
            )
            await db.commit()
            return cursor.lastrowid  # type: ignore[return-value]
        finally:
            await db.close()

    async def recall(
        self,
        agent_id: str,
        query: str,
        limit: int = 5,
    ) -> list[MemoryRecord]:
        """Search for records whose key contains *query* (case-insensitive).

        Returns the most recent matches up to *limit*.
        """
        db = await self._connect()
        try:
            cursor = await db.execute(
                """
                SELECT id, agent_id, project_id, key, value,
                       task_type, created_at, updated_at
                FROM long_term_memory
                WHERE agent_id = ? AND key LIKE ?
                ORDER BY updated_at DESC
                LIMIT ?
                """,
                (agent_id, f"%{query}%", limit),
            )
            rows = await cursor.fetchall()
            return [self._row_to_record(r) for r in rows]
        finally:
            await db.close()

    async def get_history(
        self,
        agent_id: str,
        task_type: str,
        limit: int = 20,
    ) -> list[MemoryRecord]:
        """Return records for a given agent and task type."""
        db = await self._connect()
        try:
            cursor = await db.execute(
                """
                SELECT id, agent_id, project_id, key, value,
                       task_type, created_at, updated_at
                FROM long_term_memory
                WHERE agent_id = ? AND task_type = ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (agent_id, task_type, limit),
            )
            rows = await cursor.fetchall()
            return [self._row_to_record(r) for r in rows]
        finally:
            await db.close()

    async def update(self, record_id: int, value: Any) -> bool:
        """Update the value of an existing record.  Returns ``True`` on success."""
        now = datetime.now(timezone.utc).isoformat()
        serialized = json.dumps(value, ensure_ascii=False)

        db = await self._connect()
        try:
            cursor = await db.execute(
                """
                UPDATE long_term_memory
                SET value = ?, updated_at = ?
                WHERE id = ?
                """,
                (serialized, now, record_id),
            )
            await db.commit()
            return cursor.rowcount > 0
        finally:
            await db.close()

    async def delete(self, record_id: int) -> bool:
        """Delete a record by id.  Returns ``True`` if a row was removed."""
        db = await self._connect()
        try:
            cursor = await db.execute(
                "DELETE FROM long_term_memory WHERE id = ?",
                (record_id,),
            )
            await db.commit()
            return cursor.rowcount > 0
        finally:
            await db.close()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_record(row: aiosqlite.Row) -> MemoryRecord:
        return MemoryRecord(
            id=row["id"],
            agent_id=row["agent_id"],
            project_id=row["project_id"],
            key=row["key"],
            value=json.loads(row["value"]),
            task_type=row["task_type"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def __repr__(self) -> str:
        return f"LongTermMemory(db_path={self.db_path!r})"
