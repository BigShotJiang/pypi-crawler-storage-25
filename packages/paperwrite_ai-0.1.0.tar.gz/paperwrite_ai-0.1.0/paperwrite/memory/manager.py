"""MemoryManager: unified interface combining short-term and long-term memory."""

from __future__ import annotations

from typing import Any, Literal, Optional

from .long_term import LongTermMemory, MemoryRecord
from .short_term import ShortTermMemory


class MemoryManager:
    """Facade that unifies :class:`ShortTermMemory` and :class:`LongTermMemory`.

    Parameters
    ----------
    agent_id:
        Unique identifier for the owning agent.
    project_id:
        Current project scope.
    db_path:
        Path to the SQLite database used by long-term memory.
    storage_dir:
        Root directory for file-based short-term memory.
    session_id:
        Session identifier passed to ``ShortTermMemory``.  Defaults to
        ``"default"``.
    max_short_term:
        Maximum number of messages kept in the sliding window.
    """

    def __init__(
        self,
        agent_id: str,
        project_id: str,
        db_path: str = "storage/paperwrite.db",
        storage_dir: str = "storage",
        session_id: str = "default",
        max_short_term: int = 100,
    ) -> None:
        self.agent_id = agent_id
        self.project_id = project_id

        self.short_term = ShortTermMemory(
            agent_id=agent_id,
            session_id=session_id,
            storage_dir=storage_dir,
            max_messages=max_short_term,
        )
        self.long_term = LongTermMemory(db_path=db_path)

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------

    async def save(
        self,
        key: str,
        value: Any,
        term: Literal["short", "long"] = "short",
        task_type: Optional[str] = None,
    ) -> None:
        """Store a value in short-term or long-term memory.

        Parameters
        ----------
        key:
            Identifier for the datum (used as ``role`` in short-term, or
            as the ``key`` column in long-term).
        value:
            The content / payload to store.
        term:
            ``"short"`` writes to the JSON-file sliding window;
            ``"long"`` writes to SQLite.
        task_type:
            Optional task-type tag (long-term only).
        """
        if term == "short":
            content = value if isinstance(value, str) else str(value)
            self.short_term.add_message(role=key, content=content)
        else:
            await self.long_term.store(
                agent_id=self.agent_id,
                project_id=self.project_id,
                key=key,
                value=value,
                task_type=task_type,
            )

    # ------------------------------------------------------------------
    # Recall
    # ------------------------------------------------------------------

    async def recall(
        self,
        query: str,
        term: Literal["short", "long", "both"] = "both",
        limit: int = 5,
    ) -> dict[str, Any]:
        """Retrieve relevant memories.

        Returns a dict with keys ``"short_term"`` and/or ``"long_term"``
        depending on *term*.
        """
        results: dict[str, Any] = {}

        if term in ("short", "both"):
            # For short-term we return the latest context (simple approach).
            results["short_term"] = self.short_term.get_context(last_n=limit)

        if term in ("long", "both"):
            records: list[MemoryRecord] = await self.long_term.recall(
                agent_id=self.agent_id,
                query=query,
                limit=limit,
            )
            results["long_term"] = [
                {
                    "id": r.id,
                    "key": r.key,
                    "value": r.value,
                    "task_type": r.task_type,
                    "updated_at": r.updated_at,
                }
                for r in records
            ]

        return results

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def clear_short_term(self) -> None:
        """Wipe the short-term sliding window for this agent/session."""
        self.short_term.clear()

    async def get_agent_context(self, last_n: int = 10) -> dict[str, Any]:
        """Return a combined snapshot useful for constructing LLM prompts.

        Contains the recent short-term messages plus any long-term
        records tagged for this agent.
        """
        short = self.short_term.get_context(last_n=last_n)
        long_records = await self.long_term.recall(
            agent_id=self.agent_id,
            query="",
            limit=last_n,
        )

        return {
            "agent_id": self.agent_id,
            "project_id": self.project_id,
            "short_term": short,
            "long_term": [
                {
                    "id": r.id,
                    "key": r.key,
                    "value": r.value,
                    "task_type": r.task_type,
                    "updated_at": r.updated_at,
                }
                for r in long_records
            ],
            "summary": self.short_term.get_summary(),
        }

    def __repr__(self) -> str:
        return (
            f"MemoryManager(agent_id={self.agent_id!r}, "
            f"project_id={self.project_id!r})"
        )
