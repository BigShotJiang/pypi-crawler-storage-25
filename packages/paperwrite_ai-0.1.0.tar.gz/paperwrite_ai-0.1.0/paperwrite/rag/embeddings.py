"""Embedding model configuration for RAG pipeline."""

from langchain_community.embeddings import HuggingFaceEmbeddings


def get_embedding_function(model_name: str = "all-MiniLM-L6-v2"):
    """Get the embedding function for document indexing and retrieval.

    Uses sentence-transformers running locally for privacy and speed.
    Default model (all-MiniLM-L6-v2) is compact (~80MB) with good quality.
    """
    return HuggingFaceEmbeddings(
        model_name=model_name,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )
