"""Document indexer: chunks and stores documents in ChromaDB."""

import logging
from typing import Optional

import chromadb
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma

from .embeddings import get_embedding_function

logger = logging.getLogger(__name__)


class DocumentIndexer:
    """Indexes documents into ChromaDB for semantic retrieval."""

    def __init__(self, persist_dir: str = "./storage/chroma_db"):
        self.persist_dir = persist_dir
        self.embedding_fn = get_embedding_function()
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            separators=["\n\n", "\n", ". ", " ", ""],
        )
        self._client = chromadb.PersistentClient(path=persist_dir)

    def _get_collection(self, project_id: str) -> Chroma:
        """Get or create a ChromaDB collection for a project."""
        return Chroma(
            collection_name=f"project_{project_id}",
            embedding_function=self.embedding_fn,
            persist_directory=self.persist_dir,
        )

    def index_document(
        self,
        project_id: str,
        content: str,
        metadata: Optional[dict] = None,
        doc_id: Optional[str] = None,
    ) -> int:
        """Index a document into the project's collection.

        Args:
            project_id: Project identifier
            content: Document text content
            metadata: Optional metadata (source, type, url, title, etc.)
            doc_id: Optional unique document ID to prevent duplicates

        Returns:
            Number of chunks indexed
        """
        chunks = self.text_splitter.split_text(content)
        if not chunks:
            return 0

        collection = self._get_collection(project_id)
        metadatas = [metadata or {} for _ in chunks]
        ids = [f"{doc_id or 'doc'}_{i}" for i in range(len(chunks))]

        collection.add_texts(
            texts=chunks,
            metadatas=metadatas,
            ids=ids,
        )

        logger.info(
            f"Indexed {len(chunks)} chunks for project {project_id}"
        )
        return len(chunks)

    def index_search_results(
        self, project_id: str, results: list[dict]
    ) -> int:
        """Index web search results.

        Args:
            results: List of {title, url, content, score} dicts

        Returns:
            Total chunks indexed
        """
        total = 0
        for i, result in enumerate(results):
            metadata = {
                "source": "web_search",
                "title": result.get("title", ""),
                "url": result.get("url", ""),
                "search_score": result.get("score", 0),
            }
            count = self.index_document(
                project_id,
                result.get("content", ""),
                metadata=metadata,
                doc_id=f"search_{i}",
            )
            total += count
        return total

    def delete_collection(self, project_id: str) -> None:
        """Delete a project's entire collection."""
        try:
            self._client.delete_collection(f"project_{project_id}")
            logger.info(f"Deleted collection for project {project_id}")
        except Exception as e:
            logger.warning(f"Could not delete collection: {e}")
