"""Knowledge retriever: queries ChromaDB for relevant document chunks."""

import logging
from dataclasses import dataclass
from typing import Optional

from langchain_chroma import Chroma

from .embeddings import get_embedding_function

logger = logging.getLogger(__name__)


@dataclass
class RetrievedChunk:
    content: str
    metadata: dict
    relevance_score: float


class KnowledgeRetriever:
    """Retrieves relevant knowledge from ChromaDB collections."""

    def __init__(self, persist_dir: str = "./storage/chroma_db"):
        self.persist_dir = persist_dir
        self.embedding_fn = get_embedding_function()

    def _get_collection(self, project_id: str) -> Chroma:
        """Get a ChromaDB collection for a project."""
        return Chroma(
            collection_name=f"project_{project_id}",
            embedding_function=self.embedding_fn,
            persist_directory=self.persist_dir,
        )

    def retrieve(
        self,
        project_id: str,
        query: str,
        top_k: int = 5,
        source_filter: Optional[str] = None,
    ) -> list[RetrievedChunk]:
        """Retrieve relevant document chunks for a query.

        Args:
            project_id: Project identifier
            query: Natural language query
            top_k: Number of results to return
            source_filter: Optional filter by source type ("web_search", "paper", etc.)

        Returns:
            List of RetrievedChunk with content, metadata, and relevance score
        """
        collection = self._get_collection(project_id)

        filter_dict = None
        if source_filter:
            filter_dict = {"source": source_filter}

        try:
            results = collection.similarity_search_with_relevance_scores(
                query,
                k=top_k,
                filter=filter_dict,
            )
        except Exception as e:
            logger.warning(f"Retrieval failed for project {project_id}: {e}")
            return []

        chunks = []
        for doc, score in results:
            chunks.append(RetrievedChunk(
                content=doc.page_content,
                metadata=doc.metadata,
                relevance_score=score,
            ))

        return chunks

    def retrieve_for_section(
        self,
        project_id: str,
        section_title: str,
        section_context: str = "",
        top_k: int = 8,
    ) -> list[RetrievedChunk]:
        """Retrieve knowledge relevant to a specific paper section.

        Constructs a targeted query combining section title and context.
        """
        query = f"{section_title}: {section_context}" if section_context else section_title
        return self.retrieve(project_id, query, top_k=top_k)

    def get_all_sources(self, project_id: str) -> list[dict]:
        """Get all unique sources indexed for a project."""
        collection = self._get_collection(project_id)
        try:
            results = collection.get(include=["metadatas"])
            seen_urls = set()
            sources = []
            for meta in results.get("metadatas", []):
                url = meta.get("url", "")
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    sources.append({
                        "title": meta.get("title", ""),
                        "url": url,
                        "source": meta.get("source", ""),
                    })
            return sources
        except Exception:
            return []
