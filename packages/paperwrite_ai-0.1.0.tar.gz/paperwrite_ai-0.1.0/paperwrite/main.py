"""FastAPI application entry-point for the Multi-Agent Paper Writing System."""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator, Dict

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from paperwrite.api.papers import router as papers_router
from paperwrite.api.projects import router as projects_router
from paperwrite.api.websocket import router as ws_router
from paperwrite.config import settings
from paperwrite.database import init_db


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application startup / shutdown lifecycle."""
    # Startup
    await init_db()
    yield
    # Shutdown (cleanup if needed)


# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------

app = FastAPI(
    title="PaperWrite API",
    description="Backend API for the Multi-Agent Paper Writing System",
    version="0.1.0",
    lifespan=lifespan,
)

# -- CORS ------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -- Routers ---------------------------------------------------------------
app.include_router(projects_router)
app.include_router(papers_router)
app.include_router(ws_router)


# -- Health check ----------------------------------------------------------

@app.get("/api/health", tags=["health"])
async def health_check() -> Dict[str, str]:
    """Simple liveness probe."""
    return {"status": "ok", "service": "paperwrite-api"}


# ---------------------------------------------------------------------------
# Dev entry-point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=True,
    )
