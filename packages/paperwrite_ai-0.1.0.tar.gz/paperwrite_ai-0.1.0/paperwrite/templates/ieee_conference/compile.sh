#!/bin/bash
# Compile IEEE conference paper
# Usage: ./compile.sh <project_dir>
set -e
DIR="${1:-.}"
cd "$DIR"

echo "Running pdflatex (pass 1)..."
pdflatex -interaction=nonstopmode main.tex

echo "Running bibtex..."
bibtex main || true

echo "Running pdflatex (pass 2)..."
pdflatex -interaction=nonstopmode main.tex

echo "Running pdflatex (pass 3)..."
pdflatex -interaction=nonstopmode main.tex

echo "Compilation complete: main.pdf"

# Clean auxiliary files
rm -f main.aux main.bbl main.blg main.log main.out main.synctex.gz
