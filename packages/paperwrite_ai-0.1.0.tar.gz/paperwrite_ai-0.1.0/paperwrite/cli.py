"""CLI entry point for paperwrite-ai."""

import argparse
import os
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="paperwrite",
        description="PaperWrite AI - Multi-Agent Academic Paper Writing System",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- server ---
    server_parser = subparsers.add_parser("serve", help="Start the backend API server")
    server_parser.add_argument("--host", default="0.0.0.0", help="Host to bind (default: 0.0.0.0)")
    server_parser.add_argument("--port", type=int, default=8000, help="Port to bind (default: 8000)")
    server_parser.add_argument("--reload", action="store_true", help="Enable auto-reload for development")

    # --- init ---
    subparsers.add_parser("init", help="Initialize storage directories and database")

    # --- version ---
    subparsers.add_parser("version", help="Show version")

    args = parser.parse_args()

    if args.command == "serve":
        _run_server(args.host, args.port, args.reload)
    elif args.command == "init":
        _init_project()
    elif args.command == "version":
        print("paperwrite-ai 0.1.0")
    else:
        parser.print_help()


def _run_server(host: str, port: int, reload: bool):
    """Start the FastAPI backend server."""
    try:
        import uvicorn
    except ImportError:
        print("Error: uvicorn is not installed. Run: pip install paperwrite-ai")
        sys.exit(1)

    uvicorn.run(
        "paperwrite.main:app",
        host=host,
        port=port,
        reload=reload,
    )


def _init_project():
    """Initialize storage directories and database."""
    import asyncio

    dirs = [
        "storage/projects",
        "storage/memory",
        "storage/chroma_db",
        "storage/compiled",
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        print(f"  Created: {d}/")

    # Create .env from template if not exists
    if not os.path.exists(".env"):
        env_example = os.path.join(os.path.dirname(__file__), "..", ".env.example")
        if os.path.exists(env_example):
            import shutil
            shutil.copy2(env_example, ".env")
            print("  Created: .env (from .env.example)")
        else:
            print("  Skipped: .env (no .env.example found)")

    # Initialize database
    try:
        from paperwrite.database import init_db
        asyncio.run(init_db())
        print("  Initialized: SQLite database")
    except Exception as e:
        print(f"  Warning: Database init failed: {e}")

    print("\nInitialization complete. Edit .env with your API keys, then run:")
    print("  paperwrite serve")


if __name__ == "__main__":
    main()
