"""Async event bus for inter-agent communication."""

import asyncio
import json
import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Callable, Coroutine
from enum import Enum

logger = logging.getLogger(__name__)


class EventType(str, Enum):
    TASK_ASSIGNED = "task.assigned"
    TASK_STARTED = "task.started"
    TASK_COMPLETED = "task.completed"
    TASK_FAILED = "task.failed"
    KNOWLEDGE_INDEXED = "knowledge.indexed"
    REVIEW_REQUESTED = "review.requested"
    REVIEW_COMPLETED = "review.completed"
    REVISION_REQUESTED = "revision.requested"
    COMPILATION_REQUESTED = "compilation.requested"
    COMPILATION_COMPLETED = "compilation.completed"
    AGENT_STATUS = "agent.status"
    LOG = "log"
    PIPELINE_STARTED = "pipeline.started"
    PIPELINE_COMPLETED = "pipeline.completed"
    PIPELINE_FAILED = "pipeline.failed"
    SELF_REVIEW_ITERATION = "self_review.iteration"


@dataclass
class Event:
    type: EventType
    project_id: str
    agent_id: str = ""
    data: dict = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> dict:
        return {
            "type": self.type.value,
            "project_id": self.project_id,
            "agent_id": self.agent_id,
            "data": self.data,
            "timestamp": self.timestamp,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


# Type alias for event handler
EventHandler = Callable[[Event], Coroutine[Any, Any, None]]


class EventBus:
    """Async pub/sub event bus for agent coordination."""

    def __init__(self):
        self._subscribers: dict[str, list[EventHandler]] = {}
        self._global_subscribers: list[EventHandler] = []
        self._event_history: list[Event] = []
        self._max_history = 1000

    def subscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Subscribe to a specific event type."""
        key = event_type.value
        if key not in self._subscribers:
            self._subscribers[key] = []
        self._subscribers[key].append(handler)

    def subscribe_all(self, handler: EventHandler) -> None:
        """Subscribe to all events (used by WebSocket bridge)."""
        self._global_subscribers.append(handler)

    def unsubscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Unsubscribe from a specific event type."""
        key = event_type.value
        if key in self._subscribers:
            self._subscribers[key] = [
                h for h in self._subscribers[key] if h != handler
            ]

    def unsubscribe_all(self, handler: EventHandler) -> None:
        """Unsubscribe from all events."""
        self._global_subscribers = [
            h for h in self._global_subscribers if h != handler
        ]

    async def emit(self, event: Event) -> None:
        """Emit an event to all relevant subscribers."""
        self._event_history.append(event)
        if len(self._event_history) > self._max_history:
            self._event_history = self._event_history[-self._max_history:]

        key = event.type.value
        handlers = self._subscribers.get(key, []) + self._global_subscribers

        for handler in handlers:
            try:
                await handler(event)
            except Exception as e:
                logger.error(f"Event handler error for {key}: {e}")

    async def emit_log(
        self, project_id: str, agent_id: str, level: str, message: str
    ) -> None:
        """Convenience method to emit a log event."""
        await self.emit(Event(
            type=EventType.LOG,
            project_id=project_id,
            agent_id=agent_id,
            data={"level": level, "message": message},
        ))

    def get_history(
        self, project_id: str = None, event_type: EventType = None, limit: int = 50
    ) -> list[Event]:
        """Get event history with optional filters."""
        events = self._event_history
        if project_id:
            events = [e for e in events if e.project_id == project_id]
        if event_type:
            events = [e for e in events if e.type == event_type]
        return events[-limit:]

    def clear_history(self) -> None:
        """Clear event history."""
        self._event_history.clear()
