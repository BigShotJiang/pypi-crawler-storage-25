"""End-to-end pipeline controller: orchestrates the full paper generation workflow."""

import asyncio
import logging
from typing import Optional

from .task_graph import TaskGraph, Task, TaskType, TaskStatus, AgentType
from .dispatcher import Dispatcher
from .events import EventBus, Event, EventType

logger = logging.getLogger(__name__)


class PipelineController:
    """Controls the full paper generation pipeline from input to PDF."""

    def __init__(self, event_bus: EventBus, dispatcher: Dispatcher):
        self.event_bus = event_bus
        self.dispatcher = dispatcher
        self._task_graphs: dict[str, TaskGraph] = {}

    async def run(self, project_id: str, project_config: dict) -> dict:
        """Run the full pipeline for a project.

        Args:
            project_id: Unique project identifier
            project_config: {
                "topic": str,
                "outline": list of section dicts,
                "page_count": int,
                "template": str,
                "api_keys": dict,
                "model_config": dict (optional per-agent model assignments)
            }

        Returns:
            Pipeline result dict with status, pdf_path, etc.
        """
        task_graph = self._build_task_graph(project_id, project_config)
        self._task_graphs[project_id] = task_graph

        await self.event_bus.emit_log(
            project_id, "pipeline",
            "info", f"Pipeline started with {len(task_graph.tasks)} tasks"
        )

        try:
            await self.dispatcher.dispatch(task_graph)

            if task_graph.has_failed():
                return {
                    "status": "failed",
                    "progress": task_graph.get_progress(),
                    "error": "One or more tasks failed permanently",
                }

            return {
                "status": "completed",
                "progress": task_graph.get_progress(),
                "pdf_path": self._get_pdf_path(project_id, task_graph),
            }

        except Exception as e:
            logger.error(f"Pipeline error for {project_id}: {e}")
            return {"status": "error", "error": str(e)}

    def _build_task_graph(self, project_id: str, config: dict) -> TaskGraph:
        """Build the DAG of tasks based on project outline."""
        graph = TaskGraph(project_id)
        outline = config.get("outline", [])

        # Phase 1: Research / Knowledge gathering
        research_task = Task(
            type=TaskType.RESEARCH,
            agent_type=AgentType.KNOWLEDGE_SEARCH,
            priority=10,
            description="Search and gather related work and background knowledge",
            input_data={
                "topic": config["topic"],
                "outline": outline,
            },
        )
        graph.add_task(research_task)

        # Phase 2: Method construction
        method_task = Task(
            type=TaskType.CONSTRUCT_METHOD,
            agent_type=AgentType.METHOD_CONSTRUCTION,
            priority=9,
            description="Design and construct the proposed method",
            dependencies=[research_task.id],
            input_data={
                "topic": config["topic"],
                "outline": outline,
            },
        )
        graph.add_task(method_task)

        # Phase 2b: Experiment construction (parallel with method finalization)
        experiment_task = Task(
            type=TaskType.CONSTRUCT_EXPERIMENT,
            agent_type=AgentType.EXPERIMENT_CONSTRUCTION,
            priority=8,
            description="Design experiments and evaluation methodology",
            dependencies=[research_task.id, method_task.id],
            input_data={
                "topic": config["topic"],
                "outline": outline,
            },
        )
        graph.add_task(experiment_task)

        # Phase 3: Write sections
        write_task_ids = []
        for section in outline:
            section_name = section.get("title", section.get("name", ""))
            write_task = Task(
                type=TaskType.WRITE_SECTION,
                agent_type=AgentType.WRITER,
                priority=7,
                description=f"Write section: {section_name}",
                dependencies=[research_task.id, method_task.id, experiment_task.id],
                input_data={
                    "section": section,
                    "topic": config["topic"],
                    "page_count": config.get("page_count", 12),
                    "template": config.get("template", "ieee_conference"),
                },
            )
            graph.add_task(write_task)
            write_task_ids.append(write_task.id)

        # Phase 4: Generate figures
        figure_task = Task(
            type=TaskType.GENERATE_FIGURE,
            agent_type=AgentType.IMAGE_CONSTRUCTOR,
            priority=6,
            description="Generate all figures (flowcharts, data plots)",
            dependencies=[method_task.id, experiment_task.id],
            input_data={"topic": config["topic"]},
        )
        graph.add_task(figure_task)

        # Phase 4b: Generate tables
        table_task = Task(
            type=TaskType.GENERATE_TABLE,
            agent_type=AgentType.TABLE_CONSTRUCTOR,
            priority=6,
            description="Generate all tables",
            dependencies=[experiment_task.id],
            input_data={"topic": config["topic"]},
        )
        graph.add_task(table_task)

        # Phase 5: Review
        review_deps = write_task_ids + [figure_task.id, table_task.id]
        review_task = Task(
            type=TaskType.REVIEW,
            agent_type=AgentType.REVIEWER,
            priority=5,
            description="Multi-reviewer evaluation with voting",
            dependencies=review_deps,
            input_data={"max_revision_cycles": 3},
        )
        graph.add_task(review_task)

        # Phase 5b: Revision (after review)
        revise_task = Task(
            type=TaskType.REVISE,
            agent_type=AgentType.WRITER,
            priority=4,
            description="Revise paper based on reviewer feedback",
            dependencies=[review_task.id],
            input_data={},
        )
        graph.add_task(revise_task)

        # Phase 6: References
        ref_task = Task(
            type=TaskType.GENERATE_REFERENCES,
            agent_type=AgentType.REFERENCE,
            priority=3,
            description="Generate and verify bibliography",
            dependencies=[revise_task.id],
            input_data={},
        )
        graph.add_task(ref_task)

        # Phase 7: Final compilation
        compile_task = Task(
            type=TaskType.COMPILE,
            agent_type=AgentType.WRITER,
            priority=1,
            description="Final LaTeX compilation to PDF",
            dependencies=[revise_task.id, ref_task.id],
            input_data={
                "template": config.get("template", "ieee_conference"),
                "project_id": project_id,
            },
        )
        graph.add_task(compile_task)

        return graph

    def _get_pdf_path(self, project_id: str, task_graph: TaskGraph) -> Optional[str]:
        """Extract the PDF path from the compile task output."""
        for task in task_graph.tasks.values():
            if task.type == TaskType.COMPILE and task.output_data:
                return task.output_data.get("pdf_path")
        return None

    def get_task_graph(self, project_id: str) -> Optional[TaskGraph]:
        """Get the task graph for a project."""
        return self._task_graphs.get(project_id)

    def get_progress(self, project_id: str) -> dict:
        """Get pipeline progress for a project."""
        graph = self._task_graphs.get(project_id)
        if not graph:
            return {"status": "not_found"}
        return graph.get_progress()
