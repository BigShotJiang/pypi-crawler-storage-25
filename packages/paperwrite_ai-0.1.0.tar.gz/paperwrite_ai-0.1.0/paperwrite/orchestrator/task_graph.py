"""DAG-based task graph for managing pipeline execution order."""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from collections import deque


class TaskStatus(str, Enum):
    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"


class TaskType(str, Enum):
    PLAN = "plan"
    RESEARCH = "research"
    CONSTRUCT_METHOD = "construct_method"
    CONSTRUCT_EXPERIMENT = "construct_experiment"
    WRITE_SECTION = "write_section"
    GENERATE_FIGURE = "generate_figure"
    GENERATE_TABLE = "generate_table"
    REVIEW = "review"
    REVISE = "revise"
    GENERATE_REFERENCES = "generate_references"
    COMPILE = "compile"


class AgentType(str, Enum):
    TASK_DISTRIBUTION = "task_distribution"
    KNOWLEDGE_SEARCH = "knowledge_search"
    METHOD_CONSTRUCTION = "method_construction"
    EXPERIMENT_CONSTRUCTION = "experiment_construction"
    WRITER = "writer"
    REVIEWER = "reviewer"
    IMAGE_CONSTRUCTOR = "image_constructor"
    TABLE_CONSTRUCTOR = "table_constructor"
    REFERENCE = "reference"


@dataclass
class Task:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    type: TaskType = TaskType.PLAN
    agent_type: AgentType = AgentType.TASK_DISTRIBUTION
    status: TaskStatus = TaskStatus.PENDING
    priority: int = 5
    dependencies: list[str] = field(default_factory=list)
    input_data: dict[str, Any] = field(default_factory=dict)
    output_data: Optional[dict[str, Any]] = None
    retries: int = 0
    max_retries: int = 3
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type.value,
            "agent_type": self.agent_type.value,
            "status": self.status.value,
            "priority": self.priority,
            "dependencies": self.dependencies,
            "description": self.description,
            "retries": self.retries,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class TaskGraph:
    """DAG-based task graph managing execution order and dependencies."""

    def __init__(self, project_id: str):
        self.project_id = project_id
        self.tasks: dict[str, Task] = {}

    def add_task(self, task: Task) -> str:
        """Add a task to the graph. Returns task ID."""
        self.tasks[task.id] = task
        return task.id

    def add_dependency(self, task_id: str, depends_on: str) -> None:
        """Add a dependency: task_id depends on depends_on."""
        if task_id in self.tasks and depends_on in self.tasks:
            if depends_on not in self.tasks[task_id].dependencies:
                self.tasks[task_id].dependencies.append(depends_on)

    def get_ready_tasks(self) -> list[Task]:
        """Return tasks whose dependencies are all completed."""
        ready = []
        for task in self.tasks.values():
            if task.status != TaskStatus.PENDING:
                continue
            deps_met = all(
                self.tasks[dep_id].status == TaskStatus.COMPLETED
                for dep_id in task.dependencies
                if dep_id in self.tasks
            )
            if deps_met:
                ready.append(task)
        return sorted(ready, key=lambda t: t.priority, reverse=True)

    def mark_running(self, task_id: str) -> None:
        """Mark a task as running."""
        if task_id in self.tasks:
            self.tasks[task_id].status = TaskStatus.RUNNING
            self.tasks[task_id].started_at = datetime.utcnow()

    def mark_completed(self, task_id: str, output: dict = None) -> None:
        """Mark a task as completed with optional output."""
        if task_id in self.tasks:
            self.tasks[task_id].status = TaskStatus.COMPLETED
            self.tasks[task_id].completed_at = datetime.utcnow()
            self.tasks[task_id].output_data = output

    def mark_failed(self, task_id: str) -> None:
        """Mark a task as failed. Increment retry count."""
        if task_id in self.tasks:
            task = self.tasks[task_id]
            task.retries += 1
            if task.retries >= task.max_retries:
                task.status = TaskStatus.FAILED
            else:
                task.status = TaskStatus.PENDING

    def is_complete(self) -> bool:
        """Check if all tasks are completed or failed."""
        return all(
            t.status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED)
            for t in self.tasks.values()
        )

    def has_failed(self) -> bool:
        """Check if any task has permanently failed."""
        return any(t.status == TaskStatus.FAILED for t in self.tasks.values())

    def topological_order(self) -> list[str]:
        """Return task IDs in topological order (BFS-based)."""
        in_degree = {tid: 0 for tid in self.tasks}
        for task in self.tasks.values():
            for dep in task.dependencies:
                if dep in in_degree:
                    in_degree[task.id] = in_degree.get(task.id, 0) + 1

        queue = deque([tid for tid, deg in in_degree.items() if deg == 0])
        order = []

        while queue:
            tid = queue.popleft()
            order.append(tid)
            for task in self.tasks.values():
                if tid in task.dependencies:
                    in_degree[task.id] -= 1
                    if in_degree[task.id] == 0:
                        queue.append(task.id)

        return order

    def get_progress(self) -> dict:
        """Get pipeline progress summary."""
        total = len(self.tasks)
        completed = sum(1 for t in self.tasks.values() if t.status == TaskStatus.COMPLETED)
        running = sum(1 for t in self.tasks.values() if t.status == TaskStatus.RUNNING)
        failed = sum(1 for t in self.tasks.values() if t.status == TaskStatus.FAILED)
        pending = total - completed - running - failed

        return {
            "total": total,
            "completed": completed,
            "running": running,
            "failed": failed,
            "pending": pending,
            "progress_pct": (completed / total * 100) if total > 0 else 0,
        }

    def to_dict(self) -> dict:
        """Serialize the full graph."""
        return {
            "project_id": self.project_id,
            "tasks": {tid: t.to_dict() for tid, t in self.tasks.items()},
            "progress": self.get_progress(),
        }
