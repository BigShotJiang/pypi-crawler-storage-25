"""Task dispatcher: schedules and runs tasks from the task graph."""

import asyncio
import logging
from typing import Any

from .task_graph import TaskGraph, Task, TaskStatus, AgentType
from .events import EventBus, Event, EventType

logger = logging.getLogger(__name__)


class Dispatcher:
    """Dispatches ready tasks to appropriate agents for execution."""

    def __init__(self, event_bus: EventBus, max_concurrent: int = 5):
        self.event_bus = event_bus
        self.max_concurrent = max_concurrent
        self._agents: dict[str, Any] = {}
        self._running_tasks: set[str] = set()
        self._semaphore = asyncio.Semaphore(max_concurrent)

    def register_agent(self, agent_type: AgentType, agent: Any) -> None:
        """Register an agent instance for a given type."""
        self._agents[agent_type.value] = agent

    def get_agent(self, agent_type: AgentType) -> Any:
        """Get the registered agent for a type."""
        return self._agents.get(agent_type.value)

    async def dispatch(self, task_graph: TaskGraph) -> None:
        """Main dispatch loop: continuously execute ready tasks until graph is complete."""
        project_id = task_graph.project_id

        await self.event_bus.emit(Event(
            type=EventType.PIPELINE_STARTED,
            project_id=project_id,
            data={"total_tasks": len(task_graph.tasks)},
        ))

        while not task_graph.is_complete():
            ready_tasks = task_graph.get_ready_tasks()

            if not ready_tasks and not self._running_tasks:
                if task_graph.has_failed():
                    await self.event_bus.emit(Event(
                        type=EventType.PIPELINE_FAILED,
                        project_id=project_id,
                        data={"reason": "Tasks failed with no remaining work"},
                    ))
                    break
                await asyncio.sleep(0.5)
                continue

            launch_tasks = []
            for task in ready_tasks:
                if task.id not in self._running_tasks:
                    launch_tasks.append(task)

            if launch_tasks:
                coros = [self._execute_task(task, task_graph) for task in launch_tasks]
                await asyncio.gather(*coros, return_exceptions=True)
            else:
                await asyncio.sleep(0.5)

        if not task_graph.has_failed():
            await self.event_bus.emit(Event(
                type=EventType.PIPELINE_COMPLETED,
                project_id=project_id,
                data=task_graph.get_progress(),
            ))

    async def _execute_task(self, task: Task, task_graph: TaskGraph) -> None:
        """Execute a single task using the appropriate agent."""
        async with self._semaphore:
            task_graph.mark_running(task.id)
            self._running_tasks.add(task.id)

            await self.event_bus.emit(Event(
                type=EventType.TASK_STARTED,
                project_id=task_graph.project_id,
                agent_id=task.agent_type.value,
                data={"task_id": task.id, "task_type": task.type.value},
            ))

            agent = self.get_agent(task.agent_type)
            if not agent:
                logger.error(f"No agent registered for {task.agent_type.value}")
                task_graph.mark_failed(task.id)
                self._running_tasks.discard(task.id)
                return

            try:
                # Collect dependency outputs as context
                dep_outputs = {}
                for dep_id in task.dependencies:
                    dep_task = task_graph.tasks.get(dep_id)
                    if dep_task and dep_task.output_data:
                        dep_outputs[dep_id] = dep_task.output_data

                task.input_data["dependency_outputs"] = dep_outputs
                result = await agent.execute(task)

                task_graph.mark_completed(task.id, result)

                await self.event_bus.emit(Event(
                    type=EventType.TASK_COMPLETED,
                    project_id=task_graph.project_id,
                    agent_id=task.agent_type.value,
                    data={
                        "task_id": task.id,
                        "task_type": task.type.value,
                        "progress": task_graph.get_progress(),
                    },
                ))

            except Exception as e:
                logger.error(f"Task {task.id} failed: {e}")
                task_graph.mark_failed(task.id)

                await self.event_bus.emit(Event(
                    type=EventType.TASK_FAILED,
                    project_id=task_graph.project_id,
                    agent_id=task.agent_type.value,
                    data={
                        "task_id": task.id,
                        "error": str(e),
                        "retries": task.retries,
                    },
                ))

            finally:
                self._running_tasks.discard(task.id)
