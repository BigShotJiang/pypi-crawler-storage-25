"""Tool suite for the Multi-Agent Paper Writing System."""

from .graphviz_gen import GraphEdge, GraphNode, GraphvizGenerator
from .latex_compiler import CompilationResult, LaTeXCompiler
from .llm_client import LLMClient
from .matplotlib_gen import MatplotlibGenerator
from .web_search import SearchResult, WebSearchTool

__all__ = [
    "LLMClient",
    "WebSearchTool",
    "SearchResult",
    "LaTeXCompiler",
    "CompilationResult",
    "MatplotlibGenerator",
    "GraphvizGenerator",
    "GraphNode",
    "GraphEdge",
]
