"""Graphviz diagram generator: DOT rendering and flowchart helpers."""

from __future__ import annotations

import asyncio
import logging
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class GraphNode:
    """Node specification for flowchart generation."""

    id: str
    label: str
    shape: str = "box"
    style: str = "filled"
    fillcolor: str = "#e8f4fd"


@dataclass
class GraphEdge:
    """Edge specification for flowchart generation."""

    source: str
    target: str
    label: str = ""
    style: str = "solid"


class GraphvizGenerator:
    """Render Graphviz DOT source to image files.

    Requires the ``dot`` executable (from the graphviz system package)
    to be available on ``PATH``.
    """

    def __init__(self, timeout: int = 30) -> None:
        self.timeout = timeout

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def generate_diagram(
        self,
        dot_code: str,
        output_path: str,
        format: str = "pdf",
    ) -> str:
        """Render raw DOT source to an image file.

        Parameters
        ----------
        dot_code:
            Valid DOT language source.
        output_path:
            Destination path (extension may be overridden by *format*).
        format:
            Output format (``"pdf"``, ``"png"``, ``"svg"``, etc.).

        Returns
        -------
        str
            Absolute path to the rendered file.
        """
        self._validate_dot(dot_code)

        out = Path(output_path).resolve()
        # Ensure proper extension matches format.
        if out.suffix.lstrip(".") != format:
            out = out.with_suffix(f".{format}")
        out.parent.mkdir(parents=True, exist_ok=True)

        await self._render(dot_code, str(out), format)
        logger.info("Diagram rendered to %s", out)
        return str(out)

    async def generate_flowchart(
        self,
        nodes: list[dict | GraphNode],
        edges: list[dict | GraphEdge],
        output_path: str,
        format: str = "pdf",
        title: Optional[str] = None,
        rankdir: str = "TB",
    ) -> str:
        """Build a flowchart from node/edge lists and render it.

        Parameters
        ----------
        nodes:
            List of :class:`GraphNode` instances or dicts with the same
            keys (``id``, ``label``, ``shape``, ``style``, ``fillcolor``).
        edges:
            List of :class:`GraphEdge` instances or dicts with the same
            keys (``source``, ``target``, ``label``, ``style``).
        output_path:
            Destination file path.
        format:
            Output format.
        title:
            Optional graph title.
        rankdir:
            Layout direction (``"TB"``, ``"LR"``, ``"BT"``, ``"RL"``).

        Returns
        -------
        str
            Absolute path to the rendered file.
        """
        dot_code = self._build_flowchart_dot(nodes, edges, title, rankdir)
        return await self.generate_diagram(dot_code, output_path, format)

    # ------------------------------------------------------------------
    # DOT construction
    # ------------------------------------------------------------------

    @staticmethod
    def _build_flowchart_dot(
        nodes: list[dict | GraphNode],
        edges: list[dict | GraphEdge],
        title: Optional[str],
        rankdir: str,
    ) -> str:
        lines: list[str] = []
        lines.append("digraph G {")
        lines.append(f'    rankdir="{rankdir}";')
        lines.append('    node [fontname="Helvetica", fontsize=10];')
        lines.append('    edge [fontname="Helvetica", fontsize=9];')

        if title:
            lines.append(f'    labelloc="t";')
            lines.append(f'    label="{title}";')
            lines.append('    fontsize=14;')

        lines.append("")

        # Nodes
        for node in nodes:
            n = node if isinstance(node, GraphNode) else GraphNode(**node)
            attrs = (
                f'label="{n.label}", shape={n.shape}, '
                f'style="{n.style}", fillcolor="{n.fillcolor}"'
            )
            lines.append(f"    {n.id} [{attrs}];")

        lines.append("")

        # Edges
        for edge in edges:
            e = edge if isinstance(edge, GraphEdge) else GraphEdge(**edge)
            attrs_parts: list[str] = []
            if e.label:
                attrs_parts.append(f'label="{e.label}"')
            if e.style and e.style != "solid":
                attrs_parts.append(f'style="{e.style}"')
            attr_str = f" [{', '.join(attrs_parts)}]" if attrs_parts else ""
            lines.append(f"    {e.source} -> {e.target}{attr_str};")

        lines.append("}")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Validation & rendering
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_dot(dot_code: str) -> None:
        """Basic structural validation of DOT source."""
        stripped = dot_code.strip()
        if not stripped:
            raise ValueError("DOT source is empty")

        # Must start with a graph type keyword.
        first_word = stripped.split()[0].lower()
        if first_word not in ("graph", "digraph", "strict"):
            raise ValueError(
                f"DOT source does not start with a valid keyword "
                f"(got {first_word!r}; expected 'graph', 'digraph', or 'strict')"
            )

        # Balanced braces.
        open_count = stripped.count("{")
        close_count = stripped.count("}")
        if open_count != close_count:
            raise ValueError(
                f"Unbalanced braces in DOT source: "
                f"{open_count} opening vs {close_count} closing"
            )

    async def _render(self, dot_code: str, output_path: str, format: str) -> None:
        """Call the ``dot`` executable to produce the output file."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "dot",
                f"-T{format}",
                "-o",
                output_path,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(input=dot_code.encode("utf-8")),
                timeout=self.timeout,
            )

            if proc.returncode != 0:
                error_msg = stderr.decode("utf-8", errors="replace").strip()
                raise RuntimeError(
                    f"Graphviz 'dot' failed (rc={proc.returncode}): {error_msg}"
                )

        except FileNotFoundError:
            raise RuntimeError(
                "Graphviz 'dot' command not found. "
                "Install graphviz: sudo apt-get install graphviz"
            )
        except asyncio.TimeoutError:
            proc.kill()  # type: ignore[union-attr]
            raise RuntimeError(
                f"Graphviz rendering timed out after {self.timeout}s"
            )

    def __repr__(self) -> str:
        return f"GraphvizGenerator(timeout={self.timeout})"
