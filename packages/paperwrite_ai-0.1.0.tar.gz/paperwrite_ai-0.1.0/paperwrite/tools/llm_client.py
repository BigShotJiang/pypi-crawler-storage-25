"""LLM client wrapping litellm with retry logic and token-usage logging."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Optional

import litellm

logger = logging.getLogger(__name__)


class LLMClient:
    """Async wrapper around ``litellm.acompletion``.

    Parameters
    ----------
    default_model:
        The model identifier to use when none is passed to individual
        calls (e.g. ``"gpt-4o"``, ``"claude-3-opus-20240229"``).
    api_keys:
        A mapping of provider name to API key.  Keys are set on the
        ``litellm`` module at construction time so that all subsequent
        calls pick them up automatically.
    max_retries:
        Number of retry attempts on transient failures.
    """

    def __init__(
        self,
        default_model: str = "gpt-4o",
        api_keys: Optional[dict[str, str]] = None,
        max_retries: int = 3,
    ) -> None:
        self.default_model = default_model
        self.max_retries = max_retries

        # Propagate keys into litellm so every provider is configured.
        if api_keys:
            for provider, key in api_keys.items():
                attr = f"{provider}_api_key"
                if hasattr(litellm, attr):
                    setattr(litellm, attr, key)

        # Cumulative token counters for the lifetime of this client.
        self.total_prompt_tokens: int = 0
        self.total_completion_tokens: int = 0
        self.total_cost: float = 0.0

    # ------------------------------------------------------------------
    # Core chat
    # ------------------------------------------------------------------

    async def chat(
        self,
        messages: list[dict[str, str]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4000,
        **kwargs: Any,
    ) -> str:
        """Send a chat completion request and return the assistant text.

        Retries up to ``max_retries`` times with exponential back-off
        on transient errors.
        """
        resolved_model = model or self.default_model

        for attempt in range(1, self.max_retries + 1):
            try:
                response = await litellm.acompletion(
                    model=resolved_model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    **kwargs,
                )

                self._log_usage(response, resolved_model)

                content: str = response.choices[0].message.content or ""
                return content.strip()

            except Exception as exc:
                wait = 2 ** (attempt - 1)
                logger.warning(
                    "LLM call attempt %d/%d failed (%s: %s). "
                    "Retrying in %ds...",
                    attempt,
                    self.max_retries,
                    type(exc).__name__,
                    exc,
                    wait,
                )
                if attempt == self.max_retries:
                    raise
                await asyncio.sleep(wait)

        # Unreachable, but keeps type checkers happy.
        raise RuntimeError("All retry attempts exhausted")

    async def chat_with_json(
        self,
        messages: list[dict[str, str]],
        model: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 4000,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Chat completion that forces a JSON response.

        Uses ``response_format={"type": "json_object"}`` for models that
        support it.  The returned string is parsed and returned as a
        Python dict.
        """
        resolved_model = model or self.default_model

        # Ensure the system or user message contains the word "json" so
        # that providers that enforce that constraint do not reject the
        # request.
        _messages = list(messages)
        has_json_hint = any("json" in m.get("content", "").lower() for m in _messages)
        if not has_json_hint:
            _messages.insert(
                0,
                {
                    "role": "system",
                    "content": "Respond ONLY with valid JSON.",
                },
            )

        for attempt in range(1, self.max_retries + 1):
            try:
                response = await litellm.acompletion(
                    model=resolved_model,
                    messages=_messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    response_format={"type": "json_object"},
                    **kwargs,
                )

                self._log_usage(response, resolved_model)

                raw: str = response.choices[0].message.content or "{}"
                return json.loads(raw)

            except json.JSONDecodeError as exc:
                logger.warning(
                    "JSON parse failed on attempt %d/%d: %s",
                    attempt,
                    self.max_retries,
                    exc,
                )
                if attempt == self.max_retries:
                    raise
                await asyncio.sleep(2 ** (attempt - 1))

            except Exception as exc:
                wait = 2 ** (attempt - 1)
                logger.warning(
                    "LLM JSON call attempt %d/%d failed (%s: %s). "
                    "Retrying in %ds...",
                    attempt,
                    self.max_retries,
                    type(exc).__name__,
                    exc,
                    wait,
                )
                if attempt == self.max_retries:
                    raise
                await asyncio.sleep(wait)

        raise RuntimeError("All retry attempts exhausted")

    # ------------------------------------------------------------------
    # Usage tracking
    # ------------------------------------------------------------------

    def _log_usage(self, response: Any, model: str) -> None:
        usage = getattr(response, "usage", None)
        if usage is None:
            return

        prompt_tok = getattr(usage, "prompt_tokens", 0) or 0
        completion_tok = getattr(usage, "completion_tokens", 0) or 0
        self.total_prompt_tokens += prompt_tok
        self.total_completion_tokens += completion_tok

        # litellm exposes a cost helper; fall back to 0 on failure.
        try:
            cost = litellm.completion_cost(completion_response=response)
            self.total_cost += cost
        except Exception:
            cost = 0.0

        logger.info(
            "LLM usage [%s]: prompt=%d completion=%d cost=$%.6f",
            model,
            prompt_tok,
            completion_tok,
            cost,
        )

    def get_usage_summary(self) -> dict[str, Any]:
        """Return cumulative token and cost statistics."""
        return {
            "total_prompt_tokens": self.total_prompt_tokens,
            "total_completion_tokens": self.total_completion_tokens,
            "total_tokens": self.total_prompt_tokens + self.total_completion_tokens,
            "total_cost_usd": round(self.total_cost, 6),
        }

    def __repr__(self) -> str:
        return f"LLMClient(default_model={self.default_model!r})"
