"""Web search tool backed by the Tavily API."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

from tavily import TavilyClient

logger = logging.getLogger(__name__)


@dataclass
class SearchResult:
    """A single web search result."""

    title: str
    url: str
    content: str
    score: float


class WebSearchTool:
    """Async-compatible wrapper around the Tavily search API.

    Parameters
    ----------
    api_key:
        Tavily API key.  Falls back to the ``TAVILY_API_KEY``
        environment variable when not provided.
    """

    def __init__(self, api_key: Optional[str] = None) -> None:
        # TavilyClient reads TAVILY_API_KEY from env when *api_key* is None.
        self._client = TavilyClient(api_key=api_key) if api_key else TavilyClient()

    async def search(
        self,
        query: str,
        max_results: int = 5,
        search_depth: str = "basic",
    ) -> list[SearchResult]:
        """Execute a general web search.

        Parameters
        ----------
        query:
            The search query string.
        max_results:
            Maximum number of results to return.
        search_depth:
            Tavily search depth (``"basic"`` or ``"advanced"``).

        Returns
        -------
        list[SearchResult]
            Matching results sorted by relevance score (descending).
        """
        logger.info("Web search: %r (max_results=%d)", query, max_results)

        try:
            # Tavily's Python client is synchronous; call it from async
            # context without blocking the event loop by using the
            # synchronous API directly (acceptable for I/O-bound HTTP
            # calls that Tavily handles internally).  For a truly
            # non-blocking path you could wrap with asyncio.to_thread.
            import asyncio

            response = await asyncio.to_thread(
                self._client.search,
                query=query,
                max_results=max_results,
                search_depth=search_depth,
            )
        except Exception:
            logger.exception("Tavily search failed for query %r", query)
            raise

        results: list[SearchResult] = []
        for item in response.get("results", []):
            results.append(
                SearchResult(
                    title=item.get("title", ""),
                    url=item.get("url", ""),
                    content=item.get("content", ""),
                    score=float(item.get("score", 0.0)),
                )
            )

        results.sort(key=lambda r: r.score, reverse=True)
        logger.info("Web search returned %d results", len(results))
        return results

    async def search_academic(
        self,
        query: str,
        max_results: int = 5,
    ) -> list[SearchResult]:
        """Search specifically for academic papers.

        Appends ``"academic paper"`` to the query and uses advanced
        search depth for better relevance.
        """
        academic_query = f"{query} academic paper"
        return await self.search(
            query=academic_query,
            max_results=max_results,
            search_depth="advanced",
        )

    def __repr__(self) -> str:
        return "WebSearchTool()"
