"""Matplotlib chart generator with publication-quality defaults."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.use("Agg")  # Non-interactive backend for server environments.

logger = logging.getLogger(__name__)

# Publication-quality defaults.
_PUB_RC = {
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif", "serif"],
    "font.size": 11,
    "axes.labelsize": 12,
    "axes.titlesize": 13,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 10,
    "figure.figsize": (6.4, 4.0),
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "axes.grid": True,
    "grid.alpha": 0.3,
}

# A colour palette suitable for academic papers.
_COLORS = [
    "#2171b5",
    "#e6550d",
    "#31a354",
    "#756bb1",
    "#636363",
    "#d62728",
    "#17becf",
    "#bcbd22",
]


class MatplotlibGenerator:
    """Generate publication-quality charts from declarative specifications.

    Supported chart types: ``line``, ``bar``, ``scatter``, ``pie``.

    ``chart_spec`` schema::

        {
            "type": "line" | "bar" | "scatter" | "pie",
            "title": "Chart Title",
            "xlabel": "X axis label",
            "ylabel": "Y axis label",
            "data": [
                {"label": "Series A", "values": [1, 2, 3, ...]},
                ...
            ],
            "style": {                   # optional overrides
                "figsize": [8, 5],
                "dpi": 300,
                "colors": ["#aaa", ...],
                "grid": true
            }
        }
    """

    def generate_chart(
        self,
        chart_spec: dict[str, Any],
        output_path: str,
    ) -> str:
        """Render a chart to *output_path* and return the absolute path.

        Parameters
        ----------
        chart_spec:
            Declarative specification following the schema above.
        output_path:
            Destination file (extension determines format: ``.png``,
            ``.pdf``, ``.svg``, etc.).
        """
        chart_type: str = chart_spec.get("type", "line").lower()
        title: str = chart_spec.get("title", "")
        xlabel: str = chart_spec.get("xlabel", "")
        ylabel: str = chart_spec.get("ylabel", "")
        data: list[dict[str, Any]] = chart_spec.get("data", [])
        style: dict[str, Any] = chart_spec.get("style", {})

        if not data:
            raise ValueError("chart_spec.data must contain at least one series")

        # Merge publication defaults with user overrides.
        rc = {**_PUB_RC}
        if "figsize" in style:
            rc["figure.figsize"] = tuple(style["figsize"])
        if "dpi" in style:
            rc["figure.dpi"] = style["dpi"]
            rc["savefig.dpi"] = style["dpi"]
        if "grid" in style:
            rc["axes.grid"] = bool(style["grid"])

        colors = style.get("colors", _COLORS)

        with plt.rc_context(rc):
            fig, ax = plt.subplots()

            renderer = self._RENDERERS.get(chart_type)
            if renderer is None:
                raise ValueError(
                    f"Unsupported chart type {chart_type!r}. "
                    f"Choose from: {', '.join(self._RENDERERS)}"
                )
            renderer(self, ax, data, colors)

            if title:
                ax.set_title(title)
            if xlabel:
                ax.set_xlabel(xlabel)
            if ylabel:
                ax.set_ylabel(ylabel)

            # Ensure the parent directory exists.
            out = Path(output_path).resolve()
            out.parent.mkdir(parents=True, exist_ok=True)

            fig.savefig(str(out))
            plt.close(fig)

        logger.info("Chart saved to %s", out)
        return str(out)

    # ------------------------------------------------------------------
    # Per-type renderers
    # ------------------------------------------------------------------

    def _render_line(
        self,
        ax: plt.Axes,
        data: list[dict[str, Any]],
        colors: list[str],
    ) -> None:
        for idx, series in enumerate(data):
            values = series["values"]
            x = list(range(len(values)))
            ax.plot(
                x,
                values,
                label=series.get("label", f"Series {idx + 1}"),
                color=colors[idx % len(colors)],
                marker="o",
                markersize=4,
                linewidth=1.5,
            )
        if len(data) > 1:
            ax.legend()

    def _render_bar(
        self,
        ax: plt.Axes,
        data: list[dict[str, Any]],
        colors: list[str],
    ) -> None:
        n_series = len(data)
        n_points = max(len(s["values"]) for s in data)
        x = np.arange(n_points)
        width = 0.8 / n_series

        for idx, series in enumerate(data):
            values = series["values"]
            offset = (idx - n_series / 2 + 0.5) * width
            ax.bar(
                x + offset,
                values,
                width=width,
                label=series.get("label", f"Series {idx + 1}"),
                color=colors[idx % len(colors)],
            )
        if n_series > 1:
            ax.legend()

    def _render_scatter(
        self,
        ax: plt.Axes,
        data: list[dict[str, Any]],
        colors: list[str],
    ) -> None:
        for idx, series in enumerate(data):
            values = series["values"]
            # values can be [[x, y], ...] or just [y1, y2, ...].
            if values and isinstance(values[0], (list, tuple)):
                xs = [p[0] for p in values]
                ys = [p[1] for p in values]
            else:
                xs = list(range(len(values)))
                ys = values
            ax.scatter(
                xs,
                ys,
                label=series.get("label", f"Series {idx + 1}"),
                color=colors[idx % len(colors)],
                s=30,
                alpha=0.8,
            )
        if len(data) > 1:
            ax.legend()

    def _render_pie(
        self,
        ax: plt.Axes,
        data: list[dict[str, Any]],
        colors: list[str],
    ) -> None:
        # Pie uses the first series only.
        series = data[0]
        values = series["values"]
        labels = [s.get("label", f"Slice {i + 1}") for i, s in enumerate(data)] if len(data) > 1 else None

        # If multiple series provided, treat each series' first value as a slice.
        if len(data) > 1:
            values = [s["values"][0] if s["values"] else 0 for s in data]
            labels = [s.get("label", f"Slice {i + 1}") for i, s in enumerate(data)]
        else:
            labels = [f"Slice {i + 1}" for i in range(len(values))]

        used_colors = colors[: len(values)]
        ax.pie(
            values,
            labels=labels,
            colors=used_colors,
            autopct="%1.1f%%",
            startangle=90,
        )
        ax.set_aspect("equal")

    _RENDERERS = {
        "line": _render_line,
        "bar": _render_bar,
        "scatter": _render_scatter,
        "pie": _render_pie,
    }

    def __repr__(self) -> str:
        return "MatplotlibGenerator()"
