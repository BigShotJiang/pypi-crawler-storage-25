"""LaTeX compiler: full build cycle with async subprocess execution."""

from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Auxiliary extensions to clean up after a successful build.
_AUX_EXTENSIONS = (
    ".aux",
    ".bbl",
    ".blg",
    ".log",
    ".out",
    ".toc",
    ".lof",
    ".lot",
    ".fls",
    ".fdb_latexmk",
    ".synctex.gz",
    ".nav",
    ".snm",
    ".vrb",
)


@dataclass
class CompilationResult:
    """Outcome of a LaTeX build."""

    success: bool
    pdf_path: Optional[str] = None
    log: str = ""
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class LaTeXCompiler:
    """Compile a LaTeX project through the standard build cycle.

    Build order: ``pdflatex -> bibtex -> pdflatex -> pdflatex``.

    Parameters
    ----------
    timeout:
        Maximum wall-clock seconds allowed per subprocess step.
    clean_aux:
        Whether to remove auxiliary files after a successful build.
    """

    def __init__(
        self,
        timeout: int = 60,
        clean_aux: bool = True,
    ) -> None:
        self.timeout = timeout
        self.clean_aux = clean_aux

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def compile(
        self,
        project_dir: str,
        main_tex: str = "main.tex",
    ) -> CompilationResult:
        """Run the full LaTeX build cycle and return a :class:`CompilationResult`.

        Parameters
        ----------
        project_dir:
            Absolute or relative path to the directory containing the
            ``.tex`` source files.
        main_tex:
            Name of the root TeX file inside *project_dir*.
        """
        project = Path(project_dir).resolve()
        tex_file = project / main_tex

        if not tex_file.exists():
            return CompilationResult(
                success=False,
                log="",
                errors=[f"Source file not found: {tex_file}"],
            )

        stem = tex_file.stem  # e.g. "main"

        full_log_parts: list[str] = []
        all_errors: list[str] = []
        all_warnings: list[str] = []

        # -- Build cycle -----------------------------------------------
        steps = [
            (["pdflatex", "-interaction=nonstopmode", "-halt-on-error", main_tex], "pdflatex (1)"),
            (["bibtex", stem], "bibtex"),
            (["pdflatex", "-interaction=nonstopmode", "-halt-on-error", main_tex], "pdflatex (2)"),
            (["pdflatex", "-interaction=nonstopmode", "-halt-on-error", main_tex], "pdflatex (3)"),
        ]

        for cmd, label in steps:
            logger.info("Running %s in %s", label, project)
            ok, stdout, stderr = await self._run(cmd, cwd=str(project))

            combined_output = stdout + "\n" + stderr
            full_log_parts.append(f"=== {label} ===\n{combined_output}")

            step_errors = self._extract_errors(combined_output)
            step_warnings = self._extract_warnings(combined_output)
            all_errors.extend(step_errors)
            all_warnings.extend(step_warnings)

            # bibtex may "fail" when there is no .bib; that is non-fatal.
            if not ok and label != "bibtex":
                return CompilationResult(
                    success=False,
                    pdf_path=None,
                    log="\n".join(full_log_parts),
                    errors=all_errors or [f"{label} exited with an error"],
                    warnings=all_warnings,
                )

        # -- Post-build ------------------------------------------------
        pdf_path = project / f"{stem}.pdf"
        if not pdf_path.exists():
            return CompilationResult(
                success=False,
                pdf_path=None,
                log="\n".join(full_log_parts),
                errors=all_errors or ["PDF was not generated"],
                warnings=all_warnings,
            )

        if self.clean_aux:
            self._cleanup(project, stem)

        return CompilationResult(
            success=True,
            pdf_path=str(pdf_path),
            log="\n".join(full_log_parts),
            errors=all_errors,
            warnings=all_warnings,
        )

    # ------------------------------------------------------------------
    # Subprocess execution
    # ------------------------------------------------------------------

    async def _run(
        self,
        cmd: list[str],
        cwd: str,
    ) -> tuple[bool, str, str]:
        """Execute *cmd* asynchronously and return ``(success, stdout, stderr)``."""
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(),
                timeout=self.timeout,
            )
            stdout = stdout_bytes.decode("utf-8", errors="replace")
            stderr = stderr_bytes.decode("utf-8", errors="replace")
            return proc.returncode == 0, stdout, stderr

        except asyncio.TimeoutError:
            logger.error("Command %s timed out after %ds", cmd, self.timeout)
            proc.kill()  # type: ignore[union-attr]
            return False, "", f"Process timed out after {self.timeout}s"

        except FileNotFoundError:
            return False, "", f"Command not found: {cmd[0]}"

        except Exception as exc:
            return False, "", str(exc)

    # ------------------------------------------------------------------
    # Log parsing
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_errors(log_text: str) -> list[str]:
        errors: list[str] = []
        for line in log_text.splitlines():
            stripped = line.strip()
            if stripped.startswith("!") or "Fatal error" in stripped:
                errors.append(stripped)
        return errors

    @staticmethod
    def _extract_warnings(log_text: str) -> list[str]:
        warnings: list[str] = []
        for line in log_text.splitlines():
            stripped = line.strip()
            low = stripped.lower()
            if "warning" in low or "overfull" in low or "underfull" in low:
                warnings.append(stripped)
        return warnings

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    @staticmethod
    def _cleanup(project: Path, stem: str) -> None:
        for ext in _AUX_EXTENSIONS:
            aux_file = project / f"{stem}{ext}"
            if aux_file.exists():
                try:
                    os.remove(aux_file)
                except OSError:
                    pass

    def __repr__(self) -> str:
        return f"LaTeXCompiler(timeout={self.timeout})"
