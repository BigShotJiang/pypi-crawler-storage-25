import os
import subprocess
import sys
import time
from urllib.parse import quote

from .exceptions import AuthenticationError, MissingDependencyError, ScrapingError
from .schemas import LinkedInCredentials, LinkedInProfile


class LinkedInBot:
    def __init__(
        self,
        credentials: LinkedInCredentials,
        headless: bool = False,
        timeout_seconds: float = 30.0,
        preflight_check: bool = True,
    ):
        self.credentials = credentials
        self.headless = headless
        self.timeout_ms = int(max(timeout_seconds, 1) * 1000)
        self.preflight_check = preflight_check
        self.playwright = None
        self.browser = None
        self.page = None

    @classmethod
    def from_env(
        cls,
        email_var: str = "LINKEDIN_EMAIL",
        password_var: str = "LINKEDIN_PASSWORD",
        headless: bool = False,
        timeout_seconds: float = 30.0,
        preflight_check: bool = True,
    ) -> "LinkedInBot":
        email = os.getenv(email_var, "").strip()
        password = os.getenv(password_var, "").strip()
        if not email or not password:
            raise ValueError(
                f"Missing LinkedIn credentials. Set `{email_var}` and `{password_var}`."
            )
        return cls(
            credentials=LinkedInCredentials(email=email, password=password),
            headless=headless,
            timeout_seconds=timeout_seconds,
            preflight_check=preflight_check,
        )

    def __enter__(self) -> "LinkedInBot":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def login(self) -> None:
        if self.preflight_check:
            self._preflight_playwright_runtime()

        try:
            from playwright.sync_api import Error as PlaywrightError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise MissingDependencyError(
                "Playwright is not installed. Install with `pip install linkedin-autobot[automation]`."
            ) from exc

        self.playwright = sync_playwright().start()
        try:
            self.browser = self.playwright.chromium.launch(headless=self.headless)
        except PlaywrightError as exc:
            self.close()
            if self._is_browser_missing_error(exc):
                raise MissingDependencyError(
                    "Chromium browser is not installed for Playwright. "
                    "Run `python -m playwright install chromium`."
                ) from exc
            raise

        self.page = self.browser.new_page()
        self.page.goto("https://www.linkedin.com/login", wait_until="domcontentloaded")
        self.page.fill("input#username", self.credentials.email)
        self.page.fill("input#password", self.credentials.password)
        self.page.click("button[type='submit']")
        self.page.wait_for_load_state("domcontentloaded", timeout=self.timeout_ms)
        time.sleep(2)
        self._assert_logged_in()

    def visit_profile(self, profile_url: str) -> None:
        self._require_session()
        self.page.goto(profile_url, wait_until="domcontentloaded")
        time.sleep(1)

    def find_profile_url_by_name(self, name: str) -> str:
        self._require_session()
        search_url = f"https://www.linkedin.com/search/results/people/?keywords={quote(name)}"
        self.page.goto(search_url, wait_until="domcontentloaded")
        time.sleep(2)

        selectors = [
            "a[href*='/in/']",
            ".entity-result__title-text a",
            ".linked-area[href*='/in/']",
        ]

        for selector in selectors:
            try:
                locator = self.page.locator(selector).first
                href = locator.get_attribute("href")
                if href and "/in/" in href:
                    return href.split("?")[0]
            except Exception:
                continue

        raise ValueError(f"Could not find a LinkedIn profile for '{name}'.")

    def _safe_text(self, selector: str) -> str:
        try:
            locator = self.page.locator(selector).first
            if locator.count() == 0:
                return ""
            return " ".join(locator.inner_text().strip().split())
        except Exception:
            return ""

    def _first_text(self, selectors: list[str]) -> str:
        for selector in selectors:
            value = self._safe_text(selector)
            if value:
                return value
        return ""

    def collect_profile(self, profile_url: str) -> LinkedInProfile:
        self.visit_profile(profile_url)

        profile = LinkedInProfile(
            profile_url=profile_url,
            full_name=self._first_text(["h1"]),
            title=self._first_text(
                [
                    "div.text-body-medium.break-words",
                    ".pv-text-details__left-panel .text-body-medium",
                    ".text-body-medium",
                ]
            ),
            location=self._first_text(
                [
                    ".pv-text-details__left-panel .text-body-small.inline",
                    ".text-body-small.inline.t-black--light.break-words",
                    ".text-body-small.inline",
                ]
            ),
            about=self._first_text(
                [
                    "section.artdeco-card:has(#about) div.inline-show-more-text",
                    "section.artdeco-card:has(#about) .full-width[dir='ltr']",
                    "#about ~ div .inline-show-more-text",
                    "#about ~ *",
                ]
            ),
            experience=self._first_text(
                [
                    "section.artdeco-card:has(#experience) .pvs-list__outer-container",
                    "#experience ~ div .pvs-list__outer-container",
                    "#experience ~ *",
                ]
            ),
        )
        if not profile.full_name and not profile.title:
            raise ScrapingError(
                "Could not extract profile data. LinkedIn page structure may have changed."
            )
        return profile

    def collect_profile_by_name(self, name: str) -> LinkedInProfile:
        profile = self.collect_profile(self.find_profile_url_by_name(name))
        if not profile.full_name:
            profile.full_name = name
        return profile

    def send_connection_request(self, profile_url: str, message: str | None = None) -> bool:
        self.visit_profile(profile_url)
        try:
            self.page.click("button[aria-label^='Connect']")
            time.sleep(1)
            if message:
                self.page.click("button[aria-label='Add a note']")
                self.page.fill("textarea[name='message']", message)
            self.page.click("button[aria-label='Send now']")
            return True
        except Exception:
            return False

    def close(self) -> None:
        if self.page:
            try:
                self.page.close()
            except Exception:
                pass
        if self.browser:
            try:
                self.browser.close()
            except Exception:
                pass
        if self.playwright:
            try:
                self.playwright.stop()
            except Exception:
                pass
        self.page = None
        self.browser = None
        self.playwright = None

    def _require_session(self) -> None:
        if not self.page:
            raise RuntimeError("No active browser session. Call `login()` first.")

    def _assert_logged_in(self) -> None:
        current_url = (self.page.url or "").lower()
        if "/checkpoint/challenge" in current_url:
            raise AuthenticationError(
                "LinkedIn requested a security challenge. Complete it manually, then retry."
            )
        if "/login" in current_url:
            error_banner = self._first_text(
                [
                    "#error-for-password",
                    "#error-for-username",
                    ".alert.error",
                    ".form__label--error",
                ]
            )
            raise AuthenticationError(
                f"LinkedIn login failed. {error_banner}".strip()
            )

    @staticmethod
    def _is_browser_missing_error(exc: Exception) -> bool:
        message = str(exc).lower()
        return (
            "executable doesn't exist" in message
            or "browsertype.launch" in message and "executable" in message
        )

    @staticmethod
    def _preflight_playwright_runtime() -> None:
        check_code = (
            "from playwright.sync_api import sync_playwright; "
            "p=sync_playwright().start(); "
            "b=p.chromium.launch(headless=True); "
            "b.close(); p.stop()"
        )

        def _run_check() -> None:
            subprocess.run(
                [sys.executable, "-c", check_code],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=25,
            )

        try:
            _run_check()
        except subprocess.TimeoutExpired as exc:
            raise MissingDependencyError(
                "Playwright preflight check timed out. "
                "This environment may block browser processes. "
                "Try running terminal as Administrator or run hosted mode."
            ) from exc
        except subprocess.CalledProcessError as exc:
            details = (exc.stderr or exc.stdout or "").strip()
            if "executable doesn't exist" in details.lower():
                raise MissingDependencyError(
                    "Playwright is installed but Chromium is missing. "
                    "Run `python -m playwright install chromium`."
                ) from exc
            raise MissingDependencyError(
                "Playwright preflight check failed. "
                "Ensure browser runtime is available and permissions allow launching it. "
                "Install dependencies manually: "
                "`pip install \"linkedin-autobot[automation]\"` then "
                "`python -m playwright install chromium`. "
                f"Details: {details}"
            ) from exc
