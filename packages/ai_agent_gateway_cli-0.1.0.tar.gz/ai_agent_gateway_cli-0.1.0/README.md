# ai-agent-gateway-cli

Canonical Python dev CLI for the `ai-agent-gateway` HTTP/SSE protocol.

## Usage

```bash
python -m agent_gateway_cli login
python -m agent_gateway_cli chat "hello"
python -m agent_gateway_cli --config-namespace cashnerd login
python -m agent_gateway_cli --config-namespace cashnerd chat --session default "hello"
```

The default config namespace is `agent-gateway`, which writes:

- `~/.cache/agent-gateway/cli_config.json`
- `~/.cache/agent-gateway/sessions/<name>.json`

`--config-namespace cashnerd` writes under `~/.cache/cashnerd/` instead.

## Contract

The CLI sends `context.channel = "cli"` on every chat request. When `user_id`
is configured, it is sent as a top-level field on both `/api/chat/init` and
`/api/chat`. Tool approvals post `tool_call_id`, `nonce`, `approved`, and
`allow_tool_type`.

The default `BaseUrlPolicy` is intentionally strict: `http://127.0.0.1` only,
with no path, query, or fragment. Products that need a wider local policy can
inject `BaseUrlPolicy(allowed_schemes=..., allowed_hostnames=...)`.
