from __future__ import annotations

import io
import json
import logging
from pathlib import Path

import httpx
import pytest

from agent_gateway_cli.cli import main
from agent_gateway_cli.config import CLIConfig, save_config


class ChunkStream(httpx.SyncByteStream):
    def __init__(self, chunks: list[str]) -> None:
        self._chunks = [chunk.encode("utf-8") for chunk in chunks]

    def __iter__(self):
        yield from self._chunks


@pytest.fixture(autouse=True)
def clear_dev_chat_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GATEWAY_API_KEY", raising=False)
    monkeypatch.delenv("GATEWAY_USER_ID", raising=False)
    monkeypatch.delenv("GATEWAY_BASE_URL", raising=False)


def _write_config(tmp_path: Path) -> None:
    save_config(
        tmp_path / "agent-gateway" / "cli_config.json",
        CLIConfig(
            gateway_api_key="api-key-123",
            user_id="user-123",
            base_url="http://127.0.0.1:8000",
            config_namespace="agent-gateway",
        ),
    )


def _sse(event: dict[str, object]) -> str:
    return f"data: {json.dumps(event, sort_keys=True)}\n\n"


def test_mock_gateway_contract_round_trip(monkeypatch, tmp_path: Path, caplog) -> None:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    _write_config(tmp_path)
    caplog.set_level(logging.DEBUG, logger="dev.chat_cli")
    init_posts: list[dict[str, object]] = []
    chat_posts: list[dict[str, object]] = []
    approval_posts: list[dict[str, object]] = []

    stream_events = [
        {"type": "text_delta", "text": "Hello"},
        {"type": "thinking_delta", "text": "hidden thought"},
        {
            "type": "tool_call_start",
            "tool_call_id": "tool-1",
            "tool_name": "search",
            "tool_input": {"q": "agent"},
        },
        {
            "type": "tool_output_chunk",
            "tool_call_id": "tool-1",
            "stream": "stdout",
            "text": "chunk",
            "seq": 1,
        },
        {
            "type": "tool_approval_request",
            "tool_call_id": "tool-2",
            "nonce": "nonce-2",
            "tool_name": "write_file",
            "tool_input": {"path": "x"},
            "resolved_qualifier": "write_file",
            "reason": "file write requested",
            "allow_persistent_approval": False,
        },
        {
            "type": "interceptor_decision",
            "tool_call_id": "tool-1",
            "action": "warn",
            "code": "review",
            "message": "review tool output",
        },
        {"type": "stream_retry", "attempt": 2, "error": "temporary"},
        {"type": "compaction", "chars": 123},
        {"type": "heartbeat", "timestamp": 1},
        {
            "type": "turn_complete",
            "turn": 1,
            "usage": {
                "input_tokens": 10,
                "output_tokens": 20,
                "cache_read_input_tokens": 4,
                "cache_creation_input_tokens": 3,
            },
        },
        {
            "type": "interrupted",
            "reason": "recovered_on_attach",
            "runner_id": "runner-1",
            "role": "writer",
            "last_completed_seq": 42,
        },
        {
            "type": "tool_call_interrupted",
            "tool_call_id": "tool-3",
            "tool_name": "search",
            "tool_input": {"q": "stale"},
            "original_started_at": 1.0,
            "discovered_at": 2.0,
            "tool_risk": "safe",
            "runner_id": "runner-1",
            "role": "writer",
        },
        {
            "type": "task_registered",
            "task_id": "bg_0",
            "agent_name": "worker",
            "parent_session_id": "sess-1",
            "metadata": {},
            "started_at": 1.0,
        },
        {
            "type": "task_completed",
            "task_id": "bg_0",
            "final_state": "completed",
            "completed_at": 2.0,
            "result": {"response": "done"},
            "error": None,
        },
        {
            "type": "parent_message_sent",
            "task_id": "bg_0",
            "message_id": "msg-1",
            "sender": {"session_id": "sess-1", "user_id": "user-123"},
            "sent_at": 1.5,
            "message": "continue",
        },
        {
            "type": "headless_auto_deny",
            "tool_call_id": "tool-4",
            "tool_name": "write_file",
            "reason": "approval required",
            "source": "static",
        },
        {"type": "future_event", "value": 1},
        {
            "type": "tool_call_complete",
            "tool_call_id": "tool-1",
            "tool_name": "search",
            "result": {"summary": "done"},
            "error": None,
            "duration_ms": 9,
        },
        {
            "type": "stream_complete",
            "usage": {
                "input_tokens": 10,
                "output_tokens": 20,
                "cache_creation_input_tokens": 3,
                "cache_read_input_tokens": 4,
                "estimated_cost": 0.01,
            },
        },
    ]

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/chat/init":
            init_posts.append(json.loads(request.content.decode("utf-8")))
            return httpx.Response(
                200,
                json={"session_token": "tok-1", "session_id": "sess-1", "expires_at": 4102444800},
            )
        if request.url.path == "/api/chat":
            chat_posts.append(json.loads(request.content.decode("utf-8")))
            return httpx.Response(
                200,
                stream=ChunkStream([_sse(event) for event in stream_events]),
            )
        if request.url.path == "/api/chat/tool-approval":
            approval_posts.append(json.loads(request.content.decode("utf-8")))
            return httpx.Response(200, json={"status": "ok"})
        raise AssertionError(f"Unexpected path {request.url.path}")

    stdout = io.StringIO()
    stderr = io.StringIO()
    code = main(
        ["chat", "--model", "model-1", "hello"],
        stdout=stdout,
        stderr=stderr,
        input_fn=lambda: "n",
        transport=httpx.MockTransport(handler),
    )

    assert code == 0
    assert stderr.getvalue() == ""
    assert init_posts == [{"api_key": "api-key-123", "user_id": "user-123"}]
    assert chat_posts == [
        {
            "messages": [{"role": "user", "content": "hello"}],
            "context": {"channel": "cli"},
            "user_id": "user-123",
            "model": "model-1",
        }
    ]
    assert approval_posts == [
        {
            "tool_call_id": "tool-2",
            "nonce": "nonce-2",
            "approved": False,
            "allow_tool_type": False,
        }
    ]

    rendered = stdout.getvalue()
    assert "[text] Hello" in rendered
    assert "[tool_call_start] search  call_id=tool-1" in rendered
    assert "reason: file write requested" in rendered
    assert "approve all of this type" not in rendered
    assert "expires_in" not in rendered
    assert "[interceptor] warn: review tool output" in rendered
    assert "[retry] attempt=2 error=temporary" in rendered
    assert "[compaction] chars=123" in rendered
    assert "[tool_call_complete] search  call_id=tool-1" in rendered
    assert "usage: in=10 out=20 cache_read=4 cache_create=3 cost=$0.0100" in rendered
    assert "thinking_delta: hidden thought" in caplog.text
    assert "tool_output_chunk: call_id=tool-1" in caplog.text
    for event_type in (
        "turn_complete",
        "interrupted",
        "tool_call_interrupted",
        "task_registered",
        "task_completed",
        "parent_message_sent",
        "headless_auto_deny",
    ):
        assert f"SSE event {event_type}" in caplog.text
        assert f"Unknown SSE event: {{'type': '{event_type}'" not in caplog.text
    assert "Unknown SSE event" in caplog.text


@pytest.mark.parametrize(
    ("terminal_event", "expected_output"),
    [
        ({"type": "error", "error": "boom"}, "[error] boom"),
        ({"type": "stream_error", "error": "bad stream"}, "[stream_error] bad stream"),
        (
            {"type": "max_turns_reached", "turn_count": 3, "max_turns": 3},
            "[max_turns_reached] turn_count=3/max_turns=3",
        ),
        (
            {"type": "budget_exceeded", "total_cost": 2.0, "budget": 1.0},
            "[budget_exceeded] total_cost=$2.0 / budget=$1.0",
        ),
    ],
)
def test_terminal_events_stop_the_stream(
    monkeypatch,
    tmp_path: Path,
    terminal_event: dict[str, object],
    expected_output: str,
) -> None:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    _write_config(tmp_path)

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/chat/init":
            return httpx.Response(
                200,
                json={"session_token": "tok-1", "session_id": "sess-1", "expires_at": 4102444800},
            )
        if request.url.path == "/api/chat":
            return httpx.Response(
                200,
                stream=ChunkStream([_sse(terminal_event), _sse({"type": "text_delta", "text": "after"})]),
            )
        raise AssertionError(f"Unexpected path {request.url.path}")

    stdout = io.StringIO()
    code = main(
        ["chat", "hello"],
        stdout=stdout,
        stderr=io.StringIO(),
        transport=httpx.MockTransport(handler),
    )

    assert code == 0
    rendered = stdout.getvalue()
    assert expected_output in rendered
    assert "after" not in rendered
