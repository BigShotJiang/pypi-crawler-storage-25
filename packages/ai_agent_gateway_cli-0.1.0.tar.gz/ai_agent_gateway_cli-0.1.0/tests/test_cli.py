from __future__ import annotations

import io
import json
import stat
from pathlib import Path

import httpx
import pytest

from agent_gateway_cli.cli import main
from agent_gateway_cli.config import CLIConfig, save_config


class ChunkStream(httpx.SyncByteStream):
    def __init__(self, chunks: list[str]) -> None:
        self._chunks = [chunk.encode("utf-8") for chunk in chunks]

    def __iter__(self):
        yield from self._chunks


@pytest.fixture(autouse=True)
def clear_dev_chat_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GATEWAY_API_KEY", raising=False)
    monkeypatch.delenv("GATEWAY_USER_ID", raising=False)
    monkeypatch.delenv("GATEWAY_BASE_URL", raising=False)


def _write_config(tmp_path: Path, namespace: str = "agent-gateway") -> None:
    save_config(
        tmp_path / namespace / "cli_config.json",
        CLIConfig(
            gateway_api_key="api-key-123",
            user_id="user-123",
            base_url="http://127.0.0.1:8000",
            config_namespace=namespace,
        ),
    )


def test_login_verifies_init_and_saves_namespaced_config(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    requests: list[dict[str, object]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(
            {
                "path": request.url.path,
                "json": json.loads(request.content.decode("utf-8")),
            }
        )
        return httpx.Response(
            200,
            json={"session_token": "tok-1", "session_id": "sess-1", "expires_at": 4102444800},
        )

    answers = iter(["api-key-123", "user-uuid-123"])
    stdout = io.StringIO()
    stderr = io.StringIO()

    code = main(
        ["--config-namespace", "cashnerd", "login", "--base-url", "http://127.0.0.1:8002"],
        stdout=stdout,
        stderr=stderr,
        input_fn=lambda: next(answers),
        transport=httpx.MockTransport(handler),
    )

    assert code == 0
    assert stderr.getvalue() == ""
    config_path = tmp_path / "cashnerd" / "cli_config.json"
    saved = json.loads(config_path.read_text(encoding="utf-8"))
    assert saved == {
        "schema_version": 1,
        "gateway_api_key": "api-key-123",
        "user_id": "user-uuid-123",
        "base_url": "http://127.0.0.1:8002",
        "config_namespace": "cashnerd",
    }
    assert stat.S_IMODE(config_path.stat().st_mode) == 0o600
    assert requests == [
        {"path": "/api/chat/init", "json": {"api_key": "api-key-123", "user_id": "user-uuid-123"}}
    ]
    assert "[login] verified init session sess-1" in stdout.getvalue()


def test_chat_persists_named_session_and_sends_cli_context(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    _write_config(tmp_path, "cashnerd")
    chat_posts: list[dict[str, object]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/chat/init":
            return httpx.Response(
                200,
                json={"session_token": "tok-1", "session_id": "sess-1", "expires_at": 4102444800},
            )
        if request.url.path == "/api/chat":
            chat_posts.append(
                {
                    "authorization": request.headers.get("Authorization"),
                    "json": json.loads(request.content.decode("utf-8")),
                }
            )
            return httpx.Response(
                200,
                stream=ChunkStream(
                    [
                        'data: {"type":"text_delta","text":"Hello"}\n\n',
                        'data: {"type":"stream_complete","usage":{"input_tokens":"3","output_tokens":4,"cache_creation_input_tokens":1,"cache_read_input_tokens":2,"estimated_cost":"0.0123"}}\n\n',
                    ]
                ),
            )
        raise AssertionError(f"Unexpected path {request.url.path}")

    stdout = io.StringIO()
    stderr = io.StringIO()
    code = main(
        [
            "--config-namespace",
            "cashnerd",
            "chat",
            "--session",
            "work",
            "--skill",
            "onboarding",
            "--mode",
            "research",
            "--model",
            "model-1",
            "connect",
            "bank",
        ],
        stdout=stdout,
        stderr=stderr,
        transport=httpx.MockTransport(handler),
    )

    assert code == 0
    assert stderr.getvalue() == ""
    assert chat_posts == [
        {
            "authorization": "Bearer tok-1",
            "json": {
                "messages": [{"role": "user", "content": "connect bank"}],
                "context": {"channel": "cli", "skill": "onboarding", "mode": "research"},
                "user_id": "user-123",
                "model": "model-1",
            },
        }
    ]

    session_path = tmp_path / "cashnerd" / "sessions" / "work.json"
    saved = json.loads(session_path.read_text(encoding="utf-8"))
    assert saved["schema_version"] == 1
    assert saved["messages"] == [
        {"role": "user", "content": "connect bank"},
        {"role": "assistant", "content": "Hello"},
    ]
    assert stat.S_IMODE(session_path.stat().st_mode) == 0o600
    rendered = stdout.getvalue()
    assert "[text] Hello" in rendered
    assert "usage: in=3 out=4 cache_read=2 cache_create=1 cost=$0.0123" in rendered


def test_approval_reason_rendered_and_persistent_option_suppressed(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    _write_config(tmp_path)
    approval_posts: list[dict[str, object]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/chat/init":
            return httpx.Response(
                200,
                json={"session_token": "tok-1", "session_id": "sess-1", "expires_at": 4102444800},
            )
        if request.url.path == "/api/chat":
            return httpx.Response(
                200,
                stream=ChunkStream(
                    [
                        'data: {"type":"tool_approval_request","tool_name":"write_file","tool_call_id":"tool-1","nonce":"nonce-1","tool_input":{"path":"x"},"reason":"write requested","allow_persistent_approval":false}\n\n',
                        'data: {"type":"stream_complete","usage":{}}\n\n',
                    ]
                ),
            )
        if request.url.path == "/api/chat/tool-approval":
            approval_posts.append(
                {
                    "authorization": request.headers.get("Authorization"),
                    "json": json.loads(request.content.decode("utf-8")),
                }
            )
            return httpx.Response(200, json={"status": "ok"})
        raise AssertionError(f"Unexpected path {request.url.path}")

    stdout = io.StringIO()
    code = main(
        ["chat", "approve this"],
        stdout=stdout,
        stderr=io.StringIO(),
        input_fn=lambda: "Y",
        transport=httpx.MockTransport(handler),
    )

    assert code == 0
    rendered = stdout.getvalue()
    assert "reason: write requested" in rendered
    assert "approve all of this type" not in rendered
    assert approval_posts == [
        {
            "authorization": "Bearer tok-1",
            "json": {
                "tool_call_id": "tool-1",
                "nonce": "nonce-1",
                "approved": True,
                "allow_tool_type": False,
            },
        }
    ]


def test_approval_persistent_option_posts_allow_tool_type(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    _write_config(tmp_path)
    approval_posts: list[dict[str, object]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/chat/init":
            return httpx.Response(
                200,
                json={"session_token": "tok-1", "session_id": "sess-1", "expires_at": 4102444800},
            )
        if request.url.path == "/api/chat":
            return httpx.Response(
                200,
                stream=ChunkStream(
                    [
                        'data: {"type":"tool_approval_request","tool_name":"write_file","tool_call_id":"tool-1","nonce":"nonce-1","tool_input":{},"reason":"","allow_persistent_approval":true}\n\n',
                        'data: {"type":"stream_complete","usage":{}}\n\n',
                    ]
                ),
            )
        if request.url.path == "/api/chat/tool-approval":
            approval_posts.append(json.loads(request.content.decode("utf-8")))
            return httpx.Response(200, json={"status": "ok"})
        raise AssertionError(f"Unexpected path {request.url.path}")

    stdout = io.StringIO()
    code = main(
        ["chat", "approve this"],
        stdout=stdout,
        stderr=io.StringIO(),
        input_fn=lambda: "Y",
        transport=httpx.MockTransport(handler),
    )

    assert code == 0
    assert "approve all of this type" in stdout.getvalue()
    assert approval_posts == [
        {
            "tool_call_id": "tool-1",
            "nonce": "nonce-1",
            "approved": True,
            "allow_tool_type": True,
        }
    ]
