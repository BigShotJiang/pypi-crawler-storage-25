from __future__ import annotations

import json
import stat
from pathlib import Path

import pytest

from agent_gateway_cli.config import (
    BaseUrlPolicy,
    CLIConfig,
    config_path_for_namespace,
    load_saved_config,
    resolve_config,
    save_config,
    sessions_dir_for_namespace,
    validate_namespace,
)


def test_namespace_resolution_honors_xdg_cache_home(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))

    assert config_path_for_namespace("agent-gateway") == tmp_path / "agent-gateway" / "cli_config.json"
    assert config_path_for_namespace("cashnerd") == tmp_path / "cashnerd" / "cli_config.json"
    assert sessions_dir_for_namespace("cashnerd") == tmp_path / "cashnerd" / "sessions"


@pytest.mark.parametrize("namespace", ["", "../bad", "has.dot", "a" * 65])
def test_namespace_validation_rejects_pathlike_values(namespace: str) -> None:
    with pytest.raises(Exception, match="Invalid config namespace"):
        validate_namespace(namespace)


def test_save_and_load_config_schema_v1_with_mode_0600(tmp_path: Path) -> None:
    path = tmp_path / "agent-gateway" / "cli_config.json"
    config = CLIConfig(
        gateway_api_key="key",
        user_id="user-1",
        base_url="http://127.0.0.1:8000",
        config_namespace="agent-gateway",
    )

    save_config(path, config)

    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    saved = json.loads(path.read_text(encoding="utf-8"))
    assert saved == {
        "schema_version": 1,
        "gateway_api_key": "key",
        "user_id": "user-1",
        "base_url": "http://127.0.0.1:8000",
        "config_namespace": "agent-gateway",
    }
    assert load_saved_config(path) == config


def test_base_url_policy_default_allows_loopback_http_or_https() -> None:
    policy = BaseUrlPolicy()

    assert policy.validate(" http://127.0.0.1:8000/ ") == "http://127.0.0.1:8000"
    assert policy.validate("https://localhost:8000") == "https://localhost:8000"
    assert policy.validate("http://localhost:8000") == "http://localhost:8000"
    assert policy.validate("https://127.0.0.1:8000") == "https://127.0.0.1:8000"

    with pytest.raises(Exception, match="hostname"):
        policy.validate("http://example.com:8000")
    with pytest.raises(Exception, match="one of"):
        policy.validate("ftp://127.0.0.1:8000")
    with pytest.raises(Exception, match="path"):
        policy.validate("http://127.0.0.1:8000/api")


def test_base_url_policy_can_be_narrowed_by_injection() -> None:
    policy = BaseUrlPolicy(
        allowed_schemes=frozenset({"http"}),
        allowed_hostnames=frozenset({"127.0.0.1"}),
    )

    assert policy.validate("http://127.0.0.1:8000") == "http://127.0.0.1:8000"
    with pytest.raises(Exception, match="one of"):
        policy.validate("https://127.0.0.1:8000")
    with pytest.raises(Exception, match="hostname"):
        policy.validate("http://localhost:8000")


def test_resolve_config_uses_args_env_saved_then_default(monkeypatch, tmp_path: Path) -> None:
    path = tmp_path / "agent-gateway" / "cli_config.json"
    save_config(
        path,
        CLIConfig(
            gateway_api_key="saved-key",
            user_id="saved-user",
            base_url="http://127.0.0.1:8001",
            config_namespace="agent-gateway",
        ),
    )
    monkeypatch.setenv("GATEWAY_API_KEY", "env-key")
    monkeypatch.setenv("GATEWAY_USER_ID", "env-user")

    config = resolve_config(
        config_path=path,
        config_namespace="agent-gateway",
        base_url="http://127.0.0.1:8002",
        api_key=None,
        user_id=None,
    )

    assert config.gateway_api_key == "env-key"
    assert config.user_id == "env-user"
    assert config.base_url == "http://127.0.0.1:8002"
    assert config.config_namespace == "agent-gateway"
