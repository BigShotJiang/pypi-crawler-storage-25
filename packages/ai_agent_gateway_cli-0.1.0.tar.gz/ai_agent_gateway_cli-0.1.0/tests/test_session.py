from __future__ import annotations

import json
import os
import stat
from pathlib import Path

import pytest

from agent_gateway_cli.session import (
    SessionState,
    load_session,
    save_session,
    session_path_for_name,
    validate_session_name,
)


def test_session_path_uses_namespace_and_validates_name(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    assert session_path_for_name("work-1", config_namespace="cashnerd") == (
        tmp_path / "cashnerd" / "sessions" / "work-1.json"
    )

    with pytest.raises(Exception, match="Invalid session name"):
        validate_session_name("bad/name")


def test_load_missing_or_empty_file_returns_empty_session(tmp_path: Path) -> None:
    path = tmp_path / "default.json"
    missing = load_session(path, name="default", time_fn=lambda: 1000.0)
    assert missing.messages == []
    assert missing.created_at == 1000
    assert missing.updated_at == 1000

    path.write_text("", encoding="utf-8")
    empty = load_session(path, name="default", time_fn=lambda: 1001.0)
    assert empty.messages == []
    assert empty.created_at == 1001
    assert empty.updated_at == 1001
    assert path.exists()


def test_load_parse_failure_quarantines_and_returns_empty_session(tmp_path: Path) -> None:
    path = tmp_path / "broken.json"
    path.write_text("{not json", encoding="utf-8")

    state = load_session(path, name="broken", time_fn=lambda: 2000.0)

    assert state.messages == []
    assert not path.exists()
    quarantine = tmp_path / "broken.json.corrupt.2000.json"
    assert quarantine.read_text(encoding="utf-8") == "{not json"


def test_load_hank_v0_array_and_save_forward_promotes(tmp_path: Path) -> None:
    path = tmp_path / "chat_history.json"
    path.write_text(
        json.dumps(
            [
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "hi"},
            ]
        ),
        encoding="utf-8",
    )
    os.utime(path, (1234, 1234))

    state = load_session(path, time_fn=lambda: 3000.0)

    assert state.name == "chat_history"
    assert state.created_at == 1234
    assert state.updated_at == 1234
    assert state.messages == [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hi"},
    ]

    save_session(state, time_fn=lambda: 3001.0)
    saved = json.loads(path.read_text(encoding="utf-8"))
    assert saved == {
        "schema_version": 1,
        "name": "chat_history",
        "created_at": 1234,
        "updated_at": 3001,
        "messages": [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
        ],
    }


def test_load_cashnerd_v0_object_and_save_forward_promotes(tmp_path: Path) -> None:
    path = tmp_path / "default.json"
    path.write_text(
        json.dumps(
            {
                "name": "default",
                "created_at": 111,
                "updated_at": 112,
                "messages": [{"role": "user", "content": "legacy"}],
            }
        ),
        encoding="utf-8",
    )

    state = load_session(path, name="default", time_fn=lambda: 4000.0)

    assert state.name == "default"
    assert state.created_at == 111
    assert state.updated_at == 112
    assert state.messages == [{"role": "user", "content": "legacy"}]

    save_session(state, time_fn=lambda: 4001.0)
    saved = json.loads(path.read_text(encoding="utf-8"))
    assert saved["schema_version"] == 1
    assert saved["messages"] == [{"role": "user", "content": "legacy"}]


def test_load_v1_accepts_system_role(tmp_path: Path) -> None:
    path = tmp_path / "default.json"
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "name": "default",
                "created_at": 1,
                "updated_at": 2,
                "messages": [{"role": "system", "content": "be concise"}],
            }
        ),
        encoding="utf-8",
    )

    state = load_session(path, name="default", time_fn=lambda: 5000.0)

    assert state.messages == [{"role": "system", "content": "be concise"}]


@pytest.mark.parametrize("payload", [None, 42, "text", {"schema_version": 999, "messages": []}])
def test_load_primitive_or_unknown_version_quarantines(tmp_path: Path, payload: object) -> None:
    path = tmp_path / "bad.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    state = load_session(path, name="bad", time_fn=lambda: 6000.0)

    assert state.messages == []
    assert not path.exists()
    assert (tmp_path / "bad.json.corrupt.6000.json").exists()


def test_save_session_writes_schema_v1_atomically_and_mode_0600(tmp_path: Path) -> None:
    path = tmp_path / "sessions" / "default.json"
    state = SessionState(
        name="default",
        path=path,
        created_at=7000,
        updated_at=7000,
        messages=[{"role": "assistant", "content": "hello"}],
    )

    save_session(state, time_fn=lambda: 7001.0)

    saved = json.loads(path.read_text(encoding="utf-8"))
    assert saved == {
        "schema_version": 1,
        "name": "default",
        "created_at": 7000,
        "updated_at": 7001,
        "messages": [{"role": "assistant", "content": "hello"}],
    }
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
