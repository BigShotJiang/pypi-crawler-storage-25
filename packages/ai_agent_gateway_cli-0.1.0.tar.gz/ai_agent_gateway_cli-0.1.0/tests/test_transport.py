from __future__ import annotations

import json

import httpx

from agent_gateway_cli.config import CLIConfig
from agent_gateway_cli.transport import GatewayTransport


class ChunkStream(httpx.SyncByteStream):
    def __init__(self, chunks: list[str]) -> None:
        self._chunks = [chunk.encode("utf-8") for chunk in chunks]

    def __iter__(self):
        yield from self._chunks


def test_transport_sends_contract_wire_shape_for_init_chat_and_approval() -> None:
    requests: list[dict[str, object]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8")) if request.content else None
        requests.append(
            {
                "path": request.url.path,
                "authorization": request.headers.get("Authorization"),
                "json": payload,
            }
        )
        if request.url.path == "/api/chat/init":
            return httpx.Response(
                200,
                json={
                    "session_token": "tok-1",
                    "session_id": "sess-1",
                    "expires_at": 4102444800,
                    "model_catalog": {"default_model": "m1", "allowed_models": ["m1"], "display_names": {}},
                },
            )
        if request.url.path == "/api/chat":
            return httpx.Response(
                200,
                stream=ChunkStream(['data: {"type":"stream_complete","usage":{}}\n\n']),
            )
        if request.url.path == "/api/chat/tool-approval":
            return httpx.Response(200, json={"status": "ok"})
        raise AssertionError(f"Unexpected path {request.url.path}")

    config = CLIConfig(
        gateway_api_key="key-1",
        user_id="user-1",
        base_url="http://127.0.0.1:8000",
        config_namespace="agent-gateway",
    )

    with GatewayTransport(
        config=config,
        http_transport=httpx.MockTransport(handler),
        time_fn=lambda: 1000.0,
    ) as gateway:
        session = gateway.init_session()
        with gateway.stream_chat(
            session=session,
            messages=[{"role": "user", "content": "hello"}],
            context={"channel": "telegram", "skill": "onboarding"},
            model="m1",
        ) as response:
            assert response.status_code == 200
            list(response.iter_text())
        gateway.submit_approval(
            session=session,
            tool_call_id="tool-1",
            nonce="nonce-1",
            approved=True,
            allow_tool_type=True,
        )

    assert requests == [
        {
            "path": "/api/chat/init",
            "authorization": None,
            "json": {"api_key": "key-1", "user_id": "user-1"},
        },
        {
            "path": "/api/chat",
            "authorization": "Bearer tok-1",
            "json": {
                "messages": [{"role": "user", "content": "hello"}],
                "context": {"channel": "cli", "skill": "onboarding"},
                "user_id": "user-1",
                "model": "m1",
            },
        },
        {
            "path": "/api/chat/tool-approval",
            "authorization": "Bearer tok-1",
            "json": {
                "tool_call_id": "tool-1",
                "nonce": "nonce-1",
                "approved": True,
                "allow_tool_type": True,
            },
        },
    ]
