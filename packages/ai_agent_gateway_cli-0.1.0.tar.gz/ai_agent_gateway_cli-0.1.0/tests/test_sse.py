from __future__ import annotations

import logging

from agent_gateway_cli.sse import dispatch_event, parse_sse_events


def test_parse_sse_events_handles_chunks_and_multiline_data() -> None:
    events, remainder = parse_sse_events('data: {"type":"text_delta","text":"hi"}\n')
    assert events == []
    assert remainder == 'data: {"type":"text_delta","text":"hi"}\n'

    events, remainder = parse_sse_events(remainder + "\n")
    assert events == [{"type": "text_delta", "text": "hi"}]
    assert remainder == ""

    events, remainder = parse_sse_events('data: {"type":\ndata: "heartbeat"}\n\nleft')
    assert events == [{"type": "heartbeat"}]
    assert remainder == "left"


def test_parse_sse_events_ignores_malformed_payloads() -> None:
    events, remainder = parse_sse_events("data: {not json\n\ndata: []\n\n")
    assert events == []
    assert remainder == ""


def test_dispatch_event_maps_all_documented_sse_events() -> None:
    cases = [
        (
            {"type": "text_delta", "text": "hello"},
            "assistant_text_append",
            {"text": "hello"},
            False,
        ),
        (
            {"type": "thinking_delta", "text": "hmm"},
            "thinking_text_append",
            {"text": "hmm"},
            False,
        ),
        (
            {
                "type": "tool_call_start",
                "tool_call_id": "tool-1",
                "tool_name": "search",
                "tool_input": {"q": "x"},
            },
            "tool_start",
            {"tool_call_id": "tool-1", "tool_name": "search", "tool_input": {"q": "x"}},
            False,
        ),
        (
            {
                "type": "tool_call_complete",
                "tool_call_id": "tool-1",
                "tool_name": "search",
                "result": {"ok": True},
                "error": None,
                "duration_ms": 12,
            },
            "tool_complete",
            {
                "tool_call_id": "tool-1",
                "tool_name": "search",
                "result": {"ok": True},
                "error": None,
                "duration_ms": 12,
            },
            False,
        ),
        (
            {
                "type": "tool_output_chunk",
                "tool_call_id": "tool-1",
                "stream": "stderr",
                "text": "warn",
                "seq": 2,
            },
            "tool_chunk",
            {"tool_call_id": "tool-1", "stream": "stderr", "text": "warn", "seq": 2},
            False,
        ),
        (
            {
                "type": "tool_approval_request",
                "tool_call_id": "tool-1",
                "nonce": "nonce-1",
                "tool_name": "write_file",
                "tool_input": {"path": "x"},
                "resolved_qualifier": "write_file",
                "reason": "needs write access",
                "allow_persistent_approval": True,
            },
            "tool_approval_needed",
            {
                "tool_call_id": "tool-1",
                "nonce": "nonce-1",
                "tool_name": "write_file",
                "tool_input": {"path": "x"},
                "resolved_qualifier": "write_file",
                "reason": "needs write access",
                "allow_persistent_approval": True,
            },
            False,
        ),
        (
            {
                "type": "interceptor_decision",
                "tool_call_id": "tool-1",
                "action": "warn",
                "code": "review",
                "message": "check this",
            },
            "interceptor_warning",
            {
                "tool_call_id": "tool-1",
                "action": "warn",
                "code": "review",
                "message": "check this",
            },
            False,
        ),
        (
            {"type": "stream_retry", "attempt": 2, "error": "timeout"},
            "stream_retry_notice",
            {"attempt": 2, "error": "timeout"},
            False,
        ),
        (
            {"type": "compaction", "chars": 123},
            "compaction_notice",
            {"chars": 123},
            False,
        ),
        (
            {"type": "max_turns_reached", "turn_count": 10, "max_turns": 10},
            "terminal_max_turns",
            {"turn_count": 10, "max_turns": 10},
            True,
        ),
        (
            {"type": "budget_exceeded", "total_cost": 1.2, "budget": 1.0},
            "terminal_budget_exceeded",
            {"total_cost": 1.2, "budget": 1.0},
            True,
        ),
        (
            {"type": "stream_complete", "usage": {"input_tokens": 1}},
            "terminal_complete",
            {"usage": {"input_tokens": 1}},
            True,
        ),
        (
            {"type": "error", "error": "bad"},
            "terminal_error",
            {"error": "bad", "source": "error"},
            True,
        ),
        (
            {"type": "stream_error", "error": "bad stream"},
            "terminal_error",
            {"error": "bad stream", "source": "stream_error"},
            True,
        ),
    ]

    for wire_event, expected_name, expected_payload, expected_terminal in cases:
        normalized = dispatch_event(wire_event)
        assert normalized is not None
        assert normalized.name == expected_name
        assert normalized.payload == expected_payload
        assert normalized.terminal is expected_terminal


def test_dispatch_event_heartbeat_is_silent() -> None:
    assert dispatch_event({"type": "heartbeat", "timestamp": 123}) is None


def test_dispatch_event_new_sse_events_are_debug_only(caplog) -> None:
    caplog.set_level(logging.DEBUG, logger="dev.chat_cli")
    events = [
        {
            "type": "turn_complete",
            "turn": 1,
            "usage": {
                "input_tokens": 1,
                "output_tokens": 2,
                "cache_read_input_tokens": 0,
                "cache_creation_input_tokens": 0,
            },
        },
        {
            "type": "interrupted",
            "reason": "recovered_on_attach",
            "runner_id": "runner-1",
            "role": "writer",
            "last_completed_seq": 42,
        },
        {
            "type": "tool_call_interrupted",
            "tool_call_id": "tool-1",
            "tool_name": "search",
            "tool_input": {"q": "x"},
            "original_started_at": 1.0,
            "discovered_at": 2.0,
            "tool_risk": "safe",
            "runner_id": "runner-1",
            "role": "writer",
        },
        {
            "type": "task_registered",
            "task_id": "bg_0",
            "agent_name": "worker",
            "parent_session_id": "sess-1",
            "metadata": {},
            "started_at": 1.0,
        },
        {
            "type": "task_completed",
            "task_id": "bg_0",
            "final_state": "completed",
            "completed_at": 2.0,
            "result": {"response": "done"},
            "error": None,
        },
        {
            "type": "parent_message_sent",
            "task_id": "bg_0",
            "message_id": "msg-1",
            "sender": {"session_id": "sess-1", "user_id": "user-1"},
            "sent_at": 1.5,
            "message": "continue",
        },
        {
            "type": "headless_auto_deny",
            "tool_call_id": "tool-2",
            "tool_name": "write_file",
            "reason": "approval required",
            "source": "static",
        },
    ]

    for event in events:
        assert dispatch_event(event) is None

    assert "Unknown SSE event" not in caplog.text
    for event in events:
        assert f"SSE event {event['type']}" in caplog.text


def test_dispatch_event_unknown_logs_and_does_not_crash(caplog) -> None:
    caplog.set_level(logging.DEBUG, logger="dev.chat_cli")
    assert dispatch_event({"type": "future_event", "value": 1}) is None
    assert "Unknown SSE event" in caplog.text
