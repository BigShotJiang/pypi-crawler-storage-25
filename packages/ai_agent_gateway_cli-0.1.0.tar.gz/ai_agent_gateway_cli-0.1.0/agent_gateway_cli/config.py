from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


DEFAULT_NAMESPACE = "agent-gateway"
DEFAULT_BASE_URL = "http://127.0.0.1:8000"
CONFIG_SCHEMA_VERSION = 1
_NAMESPACE_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


class CLIError(RuntimeError):
    """Raised for expected CLI usage and transport errors."""


@dataclass(frozen=True, slots=True)
class BaseUrlPolicy:
    # Default policy allows http or https on the loopback addresses. http vs https
    # on localhost is not a meaningful security distinction for a dev-tool threat
    # model — both flow over the loopback interface and don't leave the machine.
    # Products that want stricter (e.g. http-only) policy can inject a tighter
    # BaseUrlPolicy via the constructor.
    allowed_schemes: frozenset[str] = frozenset({"http", "https"})
    allowed_hostnames: frozenset[str] = frozenset({"127.0.0.1", "localhost"})

    def validate(self, base_url: str) -> str:
        normalized = base_url.strip().rstrip("/")
        parsed = urlparse(normalized)
        if parsed.scheme not in self.allowed_schemes:
            allowed = ", ".join(sorted(self.allowed_schemes))
            raise CLIError(f"Base URL must use one of: {allowed}.")
        if parsed.hostname not in self.allowed_hostnames:
            allowed = ", ".join(sorted(self.allowed_hostnames))
            raise CLIError(f"Base URL hostname must be one of: {allowed}.")
        if parsed.path not in {"", "/"} or parsed.params or parsed.query or parsed.fragment:
            raise CLIError("Base URL must not include a path, query, or fragment.")
        return normalized


@dataclass(slots=True)
class CLIConfig:
    gateway_api_key: str
    user_id: str | None
    base_url: str
    config_namespace: str = DEFAULT_NAMESPACE
    schema_version: int = CONFIG_SCHEMA_VERSION

    def to_json_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "gateway_api_key": self.gateway_api_key,
            "user_id": self.user_id,
            "base_url": self.base_url,
            "config_namespace": self.config_namespace,
        }


def validate_namespace(namespace: str) -> str:
    cleaned = namespace.strip()
    if not _NAMESPACE_RE.fullmatch(cleaned):
        raise CLIError(
            "Invalid config namespace. Use 1-64 letters, numbers, underscores, or hyphens."
        )
    return cleaned


def cache_root() -> Path:
    override = os.getenv("XDG_CACHE_HOME", "").strip()
    if override:
        return Path(override).expanduser()
    return Path.home() / ".cache"


def config_path_for_namespace(namespace: str = DEFAULT_NAMESPACE) -> Path:
    return cache_root() / validate_namespace(namespace) / "cli_config.json"


def sessions_dir_for_namespace(namespace: str = DEFAULT_NAMESPACE) -> Path:
    return cache_root() / validate_namespace(namespace) / "sessions"


def pick_value(*values: str | None) -> str | None:
    for value in values:
        if value is None:
            continue
        stripped = value.strip()
        if stripped:
            return stripped
    return None


def load_saved_config(path: Path, *, base_url_policy: BaseUrlPolicy | None = None) -> CLIConfig | None:
    policy = base_url_policy or BaseUrlPolicy()
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise CLIError(f"Failed to read CLI config: {path}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise CLIError(f"Invalid CLI config file: {path}") from exc

    if not isinstance(payload, dict):
        raise CLIError(f"Invalid CLI config file: {path}")

    raw_schema_version = payload.get("schema_version")
    if raw_schema_version is not None and raw_schema_version != CONFIG_SCHEMA_VERSION:
        raise CLIError(f"Unsupported CLI config schema_version in {path}")

    try:
        gateway_api_key = str(payload["gateway_api_key"]).strip()
        raw_user_id = payload.get("user_id")
        user_id = str(raw_user_id).strip() if raw_user_id is not None else None
        if user_id == "":
            user_id = None
        base_url = policy.validate(str(payload["base_url"]))
        raw_namespace = payload.get("config_namespace")
        if raw_namespace is None:
            config_namespace = path.parent.name or "agent-gateway"
            config_namespace = validate_namespace(config_namespace)
        else:
            config_namespace = validate_namespace(str(raw_namespace))
    except (KeyError, TypeError, ValueError) as exc:
        raise CLIError(f"Invalid CLI config file: {path}") from exc

    if not gateway_api_key:
        raise CLIError(f"Invalid CLI config file: {path}")

    return CLIConfig(
        gateway_api_key=gateway_api_key,
        user_id=user_id,
        base_url=base_url,
        config_namespace=config_namespace,
    )


def save_config(path: Path, config: CLIConfig) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = config.to_json_dict()
    data = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(data)
    os.chmod(path, 0o600)


def resolve_config(
    *,
    config_path: Path,
    config_namespace: str,
    base_url: str | None,
    api_key: str | None,
    user_id: str | None,
    base_url_policy: BaseUrlPolicy | None = None,
    require_complete: bool = True,
) -> CLIConfig:
    policy = base_url_policy or BaseUrlPolicy()
    namespace = validate_namespace(config_namespace)
    saved = load_saved_config(config_path, base_url_policy=policy)
    resolved_base_url = policy.validate(
        pick_value(
            base_url,
            os.getenv("GATEWAY_BASE_URL"),
            saved.base_url if saved is not None else None,
            DEFAULT_BASE_URL,
        )
        or DEFAULT_BASE_URL
    )
    resolved_api_key = pick_value(
        api_key,
        os.getenv("GATEWAY_API_KEY"),
        saved.gateway_api_key if saved is not None else None,
    )
    resolved_user_id = pick_value(
        user_id,
        os.getenv("GATEWAY_USER_ID"),
        saved.user_id if saved is not None else None,
    )

    if require_complete and (not resolved_api_key or not resolved_user_id):
        raise CLIError(
            "Missing gateway credentials. Run `python -m agent_gateway_cli login` "
            "or set GATEWAY_API_KEY and GATEWAY_USER_ID."
        )

    return CLIConfig(
        gateway_api_key=resolved_api_key or "",
        user_id=resolved_user_id,
        base_url=resolved_base_url,
        config_namespace=namespace,
    )
