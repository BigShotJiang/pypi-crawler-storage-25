from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import json
import time
from typing import Any, Callable, Iterator

import httpx

from .config import CLIConfig, CLIError


@dataclass(frozen=True, slots=True)
class GatewaySession:
    token: str
    session_id: str
    expires_at: int
    model_catalog: dict[str, Any] | None = None


def extract_error_detail(response: httpx.Response) -> str:
    try:
        raw = response.read()
    except httpx.HTTPError:
        raw = b""

    text = raw.decode("utf-8", errors="replace").strip()
    if not text:
        return f"HTTP {response.status_code}"

    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return text

    if isinstance(payload, dict):
        detail = payload.get("detail") or payload.get("error") or payload.get("message")
        if detail:
            if isinstance(detail, str):
                return detail
            return json.dumps(detail, sort_keys=True, default=str)
        return json.dumps(payload, sort_keys=True, default=str)
    return str(payload)


class GatewayTransport:
    def __init__(
        self,
        *,
        config: CLIConfig,
        http_transport: httpx.BaseTransport | None = None,
        time_fn: Callable[[], float] = time.time,
    ) -> None:
        self._config = config
        self._time_fn = time_fn
        self._client = httpx.Client(
            timeout=None,
            follow_redirects=True,
            transport=http_transport,
            verify=False,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "GatewayTransport":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()

    def init_session(self) -> GatewaySession:
        payload: dict[str, Any] = {"api_key": self._config.gateway_api_key}
        if self._config.user_id:
            payload["user_id"] = self._config.user_id

        for attempt in range(2):
            try:
                response = self._client.post(
                    f"{self._config.base_url}/api/chat/init",
                    json=payload,
                    timeout=30.0,
                )
            except httpx.ConnectError as exc:
                raise CLIError(
                    f"Gateway not reachable at {self._config.base_url}. Start it locally and retry."
                ) from exc
            except httpx.HTTPError as exc:
                raise CLIError(f"Gateway init failed: {exc}") from exc

            if response.status_code >= 400:
                raise CLIError(
                    f"Gateway init failed ({response.status_code}): {extract_error_detail(response)}"
                )

            try:
                data = response.json()
            except json.JSONDecodeError as exc:
                raise CLIError("Gateway init returned invalid JSON.") from exc

            if not isinstance(data, dict):
                raise CLIError("Gateway init returned an invalid session payload.")

            token = str(data.get("session_token", "") or "").strip()
            session_id = str(data.get("session_id", "") or "").strip()
            expires_at = int(data.get("expires_at", 0) or 0)
            model_catalog = data.get("model_catalog")
            if not token or not session_id or expires_at <= 0:
                raise CLIError("Gateway init returned an invalid session payload.")
            if expires_at <= int(self._time_fn()):
                if attempt == 0:
                    continue
                raise CLIError("Gateway init returned an already-expired session.")

            return GatewaySession(
                token=token,
                session_id=session_id,
                expires_at=expires_at,
                model_catalog=model_catalog if isinstance(model_catalog, dict) else None,
            )

        raise CLIError("Gateway init failed to create a usable session.")

    @contextmanager
    def stream_chat(
        self,
        *,
        session: GatewaySession,
        messages: list[dict[str, str]],
        context: dict[str, Any],
        model: str | None = None,
    ) -> Iterator[httpx.Response]:
        payload: dict[str, Any] = {
            "messages": messages,
            "context": {**context, "channel": "cli"},
        }
        if self._config.user_id:
            payload["user_id"] = self._config.user_id
        if model:
            payload["model"] = model

        try:
            with self._client.stream(
                "POST",
                f"{self._config.base_url}/api/chat",
                headers={
                    "Accept": "text/event-stream",
                    "Authorization": f"Bearer {session.token}",
                    "Content-Type": "application/json",
                },
                json=payload,
            ) as response:
                yield response
        except httpx.ConnectError as exc:
            raise CLIError(
                f"Gateway not reachable at {self._config.base_url}. Start it locally and retry."
            ) from exc
        except httpx.HTTPError as exc:
            raise CLIError(f"Chat failed: {exc}") from exc

    def submit_approval(
        self,
        *,
        session: GatewaySession,
        tool_call_id: str,
        nonce: str,
        approved: bool,
        allow_tool_type: bool = False,
    ) -> None:
        try:
            response = self._client.post(
                f"{self._config.base_url}/api/chat/tool-approval",
                headers={
                    "Authorization": f"Bearer {session.token}",
                    "Content-Type": "application/json",
                },
                json={
                    "tool_call_id": tool_call_id,
                    "nonce": nonce,
                    "approved": approved,
                    "allow_tool_type": allow_tool_type,
                },
                timeout=30.0,
            )
        except httpx.ConnectError as exc:
            raise CLIError("[approval_error] gateway unreachable") from exc
        except httpx.HTTPError as exc:
            raise CLIError(f"[approval_error] {exc}") from exc

        if response.status_code >= 400:
            detail = extract_error_detail(response)
            raise CLIError(f"[approval_error] status={response.status_code} detail={detail}")
