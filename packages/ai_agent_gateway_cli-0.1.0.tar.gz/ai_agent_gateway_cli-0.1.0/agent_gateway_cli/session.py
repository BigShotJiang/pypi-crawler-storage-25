from __future__ import annotations

import json
import os
import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .config import CLIError, sessions_dir_for_namespace, validate_namespace


SESSION_SCHEMA_VERSION = 1
DEFAULT_SESSION = "default"
_SESSION_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_V1_ROLES = {"user", "assistant", "system"}
_CASHNERD_V0_ROLES = {"user", "assistant"}


@dataclass(slots=True)
class SessionState:
    name: str
    path: Path
    created_at: int
    updated_at: int
    messages: list[dict[str, str]]

    @classmethod
    def empty(
        cls,
        *,
        name: str,
        path: Path,
        time_fn: Callable[[], float] = time.time,
    ) -> "SessionState":
        now = int(time_fn())
        return cls(name=name, path=path, created_at=now, updated_at=now, messages=[])

    def to_json_dict(self, *, updated_at: int) -> dict[str, Any]:
        return {
            "schema_version": SESSION_SCHEMA_VERSION,
            "name": self.name,
            "created_at": self.created_at,
            "updated_at": updated_at,
            "messages": self.messages,
        }


def validate_session_name(name: str) -> str:
    if not _SESSION_NAME_RE.fullmatch(name):
        raise CLIError(
            "Invalid session name. Use 1-64 letters, numbers, underscores, or hyphens."
        )
    return name


def session_path_for_name(name: str, *, config_namespace: str) -> Path:
    return sessions_dir_for_namespace(validate_namespace(config_namespace)) / f"{validate_session_name(name)}.json"


def _session_name_from_path(path: Path, name: str | None) -> str:
    if name is not None:
        return validate_session_name(name)
    stem = path.stem
    if stem:
        return validate_session_name(stem)
    return DEFAULT_SESSION


def _coerce_int(value: Any, fallback: int) -> int:
    if isinstance(value, bool):
        return fallback
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return fallback


def _coerce_messages(value: Any, *, allowed_roles: set[str]) -> list[dict[str, str]] | None:
    if not isinstance(value, list):
        return None
    messages: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, dict):
            return None
        role = item.get("role")
        content = item.get("content")
        if not isinstance(role, str) or not isinstance(content, str):
            return None
        if role not in allowed_roles:
            return None
        messages.append({"role": role, "content": content})
    return messages


def _quarantine(path: Path, *, time_fn: Callable[[], float]) -> Path | None:
    if not path.exists():
        return None
    timestamp = int(time_fn())
    candidate = path.with_name(f"{path.name}.corrupt.{timestamp}.json")
    index = 1
    while candidate.exists():
        candidate = path.with_name(f"{path.name}.corrupt.{timestamp}.{index}.json")
        index += 1
    try:
        path.rename(candidate)
    except OSError as exc:
        raise CLIError(f"Failed to quarantine corrupted session file: {path}") from exc
    return candidate


def _empty_after_quarantine(
    path: Path,
    *,
    name: str,
    time_fn: Callable[[], float],
) -> SessionState:
    _quarantine(path, time_fn=time_fn)
    return SessionState.empty(name=name, path=path, time_fn=time_fn)


def load_session(
    path: Path,
    *,
    name: str | None = None,
    time_fn: Callable[[], float] = time.time,
) -> SessionState:
    resolved_name = _session_name_from_path(path, name)

    try:
        stat_result = path.stat()
    except FileNotFoundError:
        return SessionState.empty(name=resolved_name, path=path, time_fn=time_fn)
    except OSError as exc:
        raise CLIError(f"Failed to read session file: {path}") from exc

    if stat_result.st_size == 0:
        return SessionState.empty(name=resolved_name, path=path, time_fn=time_fn)

    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise CLIError(f"Failed to read session file: {path}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return _empty_after_quarantine(path, name=resolved_name, time_fn=time_fn)

    if isinstance(payload, list):
        messages = _coerce_messages(payload, allowed_roles=_V1_ROLES)
        if messages is None:
            return _empty_after_quarantine(path, name=resolved_name, time_fn=time_fn)
        mtime = int(stat_result.st_mtime)
        return SessionState(
            name=resolved_name,
            path=path,
            created_at=mtime,
            updated_at=mtime,
            messages=messages,
        )

    if isinstance(payload, dict) and "schema_version" not in payload:
        messages = _coerce_messages(payload.get("messages"), allowed_roles=_CASHNERD_V0_ROLES)
        if messages is None:
            return _empty_after_quarantine(path, name=resolved_name, time_fn=time_fn)
        now = int(time_fn())
        payload_name = payload.get("name")
        state_name = (
            validate_session_name(payload_name)
            if isinstance(payload_name, str) and _SESSION_NAME_RE.fullmatch(payload_name)
            else resolved_name
        )
        return SessionState(
            name=state_name,
            path=path,
            created_at=_coerce_int(payload.get("created_at"), now),
            updated_at=_coerce_int(payload.get("updated_at"), now),
            messages=messages,
        )

    if isinstance(payload, dict) and payload.get("schema_version") == SESSION_SCHEMA_VERSION:
        messages = _coerce_messages(payload.get("messages"), allowed_roles=_V1_ROLES)
        if messages is None:
            return _empty_after_quarantine(path, name=resolved_name, time_fn=time_fn)
        now = int(time_fn())
        payload_name = payload.get("name")
        state_name = (
            validate_session_name(payload_name)
            if isinstance(payload_name, str) and _SESSION_NAME_RE.fullmatch(payload_name)
            else resolved_name
        )
        return SessionState(
            name=state_name,
            path=path,
            created_at=_coerce_int(payload.get("created_at"), now),
            updated_at=_coerce_int(payload.get("updated_at"), now),
            messages=messages,
        )

    return _empty_after_quarantine(path, name=resolved_name, time_fn=time_fn)


def save_session(state: SessionState, *, time_fn: Callable[[], float] = time.time) -> None:
    state.path.parent.mkdir(parents=True, exist_ok=True)
    updated_at = int(time_fn())
    payload = state.to_json_dict(updated_at=updated_at)

    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            dir=state.path.parent,
            delete=False,
            prefix=f".{state.name}.",
            suffix=".tmp",
            encoding="utf-8",
        ) as temp_file:
            temp_path = Path(temp_file.name)
            json.dump(payload, temp_file, indent=2, sort_keys=True)
            temp_file.write("\n")
            temp_file.flush()
            os.fsync(temp_file.fileno())
        os.chmod(temp_path, 0o600)
        os.replace(temp_path, state.path)
        os.chmod(state.path, 0o600)
        state.updated_at = updated_at
    except Exception:
        if temp_path is not None:
            try:
                temp_path.unlink()
            except OSError:
                pass
        raise
