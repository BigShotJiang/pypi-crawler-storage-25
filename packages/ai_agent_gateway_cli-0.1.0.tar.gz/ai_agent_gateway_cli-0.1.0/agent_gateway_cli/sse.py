from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Callable


log = logging.getLogger("dev.chat_cli")


@dataclass(frozen=True, slots=True)
class NormalizedEvent:
    name: str
    payload: dict[str, Any]
    terminal: bool = False


def _parse_sse_event(raw_event: str) -> dict[str, Any] | None:
    data_lines: list[str] = []
    for line in raw_event.splitlines():
        if not line.startswith("data:"):
            continue
        payload = line[5:]
        if payload.startswith(" "):
            payload = payload[1:]
        data_lines.append(payload)

    if not data_lines:
        return None

    payload_text = "\n".join(data_lines).strip()
    if not payload_text:
        return None

    try:
        parsed = json.loads(payload_text)
    except json.JSONDecodeError:
        log.debug("Skipping malformed SSE payload: %s", payload_text[:200])
        return None
    if isinstance(parsed, dict):
        return parsed
    return None


def parse_sse_events(buffer: str) -> tuple[list[dict[str, Any]], str]:
    normalized = buffer.replace("\r\n", "\n").replace("\r", "\n")
    parts = normalized.split("\n\n")
    if len(parts) == 1:
        return [], normalized

    events: list[dict[str, Any]] = []
    for raw_event in parts[:-1]:
        parsed = _parse_sse_event(raw_event)
        if parsed is not None:
            events.append(parsed)
    return events, parts[-1]


def _string(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def _bool(value: Any) -> bool:
    return bool(value)


def _text_delta(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "assistant_text_append",
        {"text": _string(event.get("text"))},
    )


def _thinking_delta(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "thinking_text_append",
        {"text": _string(event.get("text", event.get("thinking_text")))},
    )


def _tool_call_start(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "tool_start",
        {
            "tool_call_id": _string(event.get("tool_call_id")),
            "tool_name": _string(event.get("tool_name"), "tool"),
            "tool_input": event.get("tool_input") if isinstance(event.get("tool_input"), dict) else {},
        },
    )


def _tool_output_chunk(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "tool_chunk",
        {
            "tool_call_id": _string(event.get("tool_call_id")),
            "stream": _string(event.get("stream"), "stdout"),
            "text": _string(event.get("text")),
            "seq": event.get("seq"),
        },
    )


def _tool_call_complete(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "tool_complete",
        {
            "tool_call_id": _string(event.get("tool_call_id")),
            "tool_name": _string(event.get("tool_name"), "tool"),
            "result": event.get("result"),
            "error": event.get("error"),
            "duration_ms": event.get("duration_ms"),
        },
    )


def _tool_approval_request(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "tool_approval_needed",
        {
            "tool_call_id": _string(event.get("tool_call_id")),
            "nonce": _string(event.get("nonce")),
            "tool_name": _string(event.get("tool_name"), "tool"),
            "tool_input": event.get("tool_input") if isinstance(event.get("tool_input"), dict) else {},
            "resolved_qualifier": event.get("resolved_qualifier"),
            "reason": _string(event.get("reason")),
            "allow_persistent_approval": _bool(event.get("allow_persistent_approval")),
        },
    )


def _interceptor_decision(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "interceptor_warning",
        {
            "tool_call_id": _string(event.get("tool_call_id")),
            "action": _string(event.get("action")),
            "code": _string(event.get("code")),
            "message": _string(event.get("message")),
        },
    )


def _stream_retry(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "stream_retry_notice",
        {
            "attempt": event.get("attempt"),
            "error": event.get("error"),
        },
    )


def _compaction(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "compaction_notice",
        {"chars": event.get("chars")},
    )


def _max_turns_reached(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "terminal_max_turns",
        {
            "turn_count": event.get("turn_count"),
            "max_turns": event.get("max_turns"),
        },
        terminal=True,
    )


def _budget_exceeded(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "terminal_budget_exceeded",
        {
            "total_cost": event.get("total_cost"),
            "budget": event.get("budget"),
        },
        terminal=True,
    )


def _stream_complete(event: dict[str, Any]) -> NormalizedEvent:
    usage = event.get("usage")
    return NormalizedEvent(
        "terminal_complete",
        {"usage": usage if isinstance(usage, dict) else {}},
        terminal=True,
    )


def _error(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "terminal_error",
        {
            "error": event.get("error", event.get("message")),
            "source": "error",
        },
        terminal=True,
    )


def _stream_error(event: dict[str, Any]) -> NormalizedEvent:
    return NormalizedEvent(
        "terminal_error",
        {
            "error": event.get("error", event.get("message")),
            "source": "stream_error",
        },
        terminal=True,
    )


def _debug_only(event: dict[str, Any]) -> None:
    log.debug("SSE event %s: %s", _string(event.get("type"), "unknown"), event)
    return None


_HANDLERS: dict[str, Callable[[dict[str, Any]], NormalizedEvent | None]] = {
    "text_delta": _text_delta,
    "thinking_delta": _thinking_delta,
    "tool_call_start": _tool_call_start,
    "tool_call_complete": _tool_call_complete,
    "tool_call_interrupted": _debug_only,
    "tool_output_chunk": _tool_output_chunk,
    "tool_approval_request": _tool_approval_request,
    "headless_auto_deny": _debug_only,
    "interceptor_decision": _interceptor_decision,
    "turn_complete": _debug_only,
    "interrupted": _debug_only,
    "stream_retry": _stream_retry,
    "compaction": _compaction,
    "max_turns_reached": _max_turns_reached,
    "budget_exceeded": _budget_exceeded,
    "task_registered": _debug_only,
    "task_completed": _debug_only,
    "parent_message_sent": _debug_only,
    "heartbeat": lambda event: None,
    "stream_complete": _stream_complete,
    "error": _error,
    "stream_error": _stream_error,
}


def dispatch_event(event: dict[str, Any]) -> NormalizedEvent | None:
    event_type = _string(event.get("type"))
    handler = _HANDLERS.get(event_type)
    if handler is None:
        log.debug("Unknown SSE event: %s", event)
        return None
    return handler(event)
