from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from typing import Any, Callable, TextIO

import httpx

from .config import (
    DEFAULT_BASE_URL,
    DEFAULT_NAMESPACE,
    BaseUrlPolicy,
    CLIConfig,
    CLIError,
    config_path_for_namespace,
    load_saved_config,
    pick_value,
    resolve_config,
    save_config,
    validate_namespace,
)
from .session import (
    DEFAULT_SESSION,
    load_session,
    save_session,
    session_path_for_name,
    validate_session_name,
)
from .sse import NormalizedEvent, dispatch_event, parse_sse_events
from .transport import GatewaySession, GatewayTransport, extract_error_detail


DIVIDER = "-" * 60
_TOOL_SUMMARY_MAX = 500
_TOOL_INPUT_MAX = 500
log = logging.getLogger("dev.chat_cli")


def _ensure_not_production() -> None:
    if os.getenv("APP_ENV", "").strip().lower() == "production":
        raise CLIError("Refusing to run dev chat CLI with APP_ENV=production.")


def _json_compact(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _json_pretty(value: Any) -> str:
    return json.dumps(value, sort_keys=True, indent=2, default=str)


def _event_error_message(raw_error: Any) -> str:
    if isinstance(raw_error, str) and raw_error.strip():
        return raw_error
    if isinstance(raw_error, dict):
        message = raw_error.get("message") or raw_error.get("error")
        if isinstance(message, str) and message.strip():
            return message
    try:
        return json.dumps(raw_error, sort_keys=True, default=str)
    except TypeError:
        return str(raw_error)


def _summarize_result(result: Any, max_len: int = 150) -> str:
    if result is None:
        return ""
    if isinstance(result, dict):
        summary = result.get("summary")
        if summary:
            rendered = json.dumps(summary, default=str, sort_keys=True)
            if rendered not in {"null", "{}", "\"\""}:
                return rendered[:max_len] + "..." if len(rendered) > max_len else rendered
    rendered = json.dumps(result, default=str, sort_keys=True)
    return rendered[:max_len] + "..." if len(rendered) > max_len else rendered


def _tool_error_message(error: Any) -> str | None:
    if isinstance(error, dict):
        return str(error.get("message", "unknown"))
    if error is None:
        return None
    return str(error)


def _format_args(tool_input: dict[str, Any], max_val_len: int = 30) -> str:
    if not tool_input:
        return ""

    parts: list[str] = []
    for key, value in tool_input.items():
        if value is None or value == "":
            continue
        if value is True:
            parts.append(key)
        elif value is False:
            parts.append(f"{key}=false")
        else:
            text = json.dumps(value, default=str)
            if len(text) > max_val_len:
                text = text[:max_val_len] + "..."
            parts.append(f"{key}={text}")
    return ", ".join(parts)


def _build_tool_summary(tool_calls: list[dict[str, Any]]) -> str:
    if not tool_calls:
        return ""

    parts: list[str] = []
    for tool_call in tool_calls:
        name = str(tool_call.get("tool_name", "?"))
        args = _format_args(tool_call.get("tool_input", {}))
        if tool_call.get("is_error"):
            error = str(tool_call.get("error_message") or "unknown error")
            parts.append(f"{name}({args}) -> ERROR: {error}")
            continue
        summary = str(tool_call.get("result_summary", ""))
        parts.append(f"{name}({args}) -> {summary}" if summary else f"{name}({args})")

    text = "[Tools: " + " | ".join(parts) + "]"
    if len(text) > _TOOL_SUMMARY_MAX:
        text = text[: _TOOL_SUMMARY_MAX - 4] + "...]"
    return text


def _truncate(text: str, max_len: int = _TOOL_INPUT_MAX) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


def _usage_int(usage: dict[str, Any], key: str) -> int:
    value = usage.get(key, 0)
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return 0


def _usage_float(usage: dict[str, Any], key: str) -> float:
    value = usage.get(key, 0.0)
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return 0.0


class DevChatCLI:
    """Small sync CLI for direct gateway chat debugging."""

    def __init__(
        self,
        *,
        stdout: TextIO,
        stderr: TextIO,
        input_fn: Callable[[], str],
        time_fn: Callable[[], float],
        transport: httpx.BaseTransport | None = None,
        base_url_policy: BaseUrlPolicy | None = None,
    ) -> None:
        self._stdout = stdout
        self._stderr = stderr
        self._input_fn = input_fn
        self._time_fn = time_fn
        self._transport = transport
        self._base_url_policy = base_url_policy or BaseUrlPolicy()
        self._colors = self._supports_color(stdout)
        self._open_stream: str | None = None

    def _supports_color(self, stream: TextIO) -> bool:
        return bool(getattr(stream, "isatty", lambda: False)()) and not os.getenv("NO_COLOR")

    def _style(self, text: str, code: str) -> str:
        if not self._colors:
            return text
        return f"\033[{code}m{text}\033[0m"

    def _write(self, text: str = "") -> None:
        self._stdout.write(text)
        self._stdout.flush()

    def _write_line(self, text: str = "") -> None:
        self._write(f"{text}\n")

    def _close_text_line(self) -> None:
        if self._open_stream is not None:
            self._write("\n")
            self._open_stream = None

    def _write_stream_delta(self, *, kind: str, prefix: str, text: str, style: str | None = None) -> None:
        if self._open_stream != kind:
            self._close_text_line()
            self._write(self._style(prefix, style) if style else prefix)
            self._open_stream = kind
        self._write(self._style(text, style) if style else text)

    def _prompt(self, prompt: str) -> str:
        self._write(prompt)
        try:
            return self._input_fn()
        except EOFError:
            return ""

    def _prompt_value(self, label: str, current: str | None = None) -> str:
        suffix = f" [{current}]" if current else ""
        entered = self._prompt(f"{label}{suffix}: ").strip()
        if entered:
            return entered
        return current or ""

    def login(
        self,
        *,
        base_url: str | None,
        api_key: str | None,
        user_id: str | None,
        config_namespace: str,
    ) -> int:
        _ensure_not_production()
        namespace = validate_namespace(config_namespace)
        config_path = config_path_for_namespace(namespace)
        saved = load_saved_config(config_path, base_url_policy=self._base_url_policy)
        resolved_base_url = self._base_url_policy.validate(
            pick_value(
                base_url,
                os.getenv("GATEWAY_BASE_URL"),
                saved.base_url if saved is not None else None,
                DEFAULT_BASE_URL,
            )
            or DEFAULT_BASE_URL
        )
        resolved_api_key = pick_value(api_key, os.getenv("GATEWAY_API_KEY"))
        if not resolved_api_key:
            resolved_api_key = self._prompt_value(
                "Gateway API key",
                saved.gateway_api_key if saved is not None else None,
            )
        resolved_user_id = pick_value(user_id, os.getenv("GATEWAY_USER_ID"))
        if not resolved_user_id:
            resolved_user_id = self._prompt_value(
                "Gateway user_id",
                saved.user_id if saved is not None else None,
            )
        if not resolved_api_key or not resolved_user_id:
            raise CLIError("Both gateway_api_key and user_id are required.")

        config = CLIConfig(
            gateway_api_key=resolved_api_key,
            user_id=resolved_user_id,
            base_url=resolved_base_url,
            config_namespace=namespace,
        )
        with GatewayTransport(
            config=config,
            http_transport=self._transport,
            time_fn=self._time_fn,
        ) as gateway:
            session = gateway.init_session()

        save_config(config_path, config)
        self._write_line(f"[login] verified init session {session.session_id}")
        self._write_line(f"[login] config saved to {config_path}")
        self._write_line(f"[login] base_url={config.base_url}")
        self._write_line(f"[login] user_id={config.user_id}")
        return 0

    def chat(
        self,
        *,
        message: str | None,
        skill: str | None,
        mode: str | None,
        model: str | None,
        raw: bool,
        new_history: bool,
        session_name: str,
        base_url: str | None,
        api_key: str | None,
        user_id: str | None,
        config_namespace: str,
    ) -> int:
        session_name = validate_session_name(session_name)
        _ensure_not_production()
        namespace = validate_namespace(config_namespace)
        state_path = session_path_for_name(session_name, config_namespace=namespace)
        state = load_session(state_path, name=session_name, time_fn=self._time_fn)
        if new_history:
            state.messages = []
            try:
                save_session(state, time_fn=self._time_fn)
            except Exception as exc:
                self._stderr.write(f"[session_warn] failed to persist: {exc}\n")
                self._stderr.flush()

        config = resolve_config(
            config_path=config_path_for_namespace(namespace),
            config_namespace=namespace,
            base_url=base_url,
            api_key=api_key,
            user_id=user_id,
            base_url_policy=self._base_url_policy,
            require_complete=True,
        )

        prompt_message = (message or "").strip()
        history: list[dict[str, str]] = [dict(item) for item in state.messages]

        with GatewayTransport(
            config=config,
            http_transport=self._transport,
            time_fn=self._time_fn,
        ) as gateway:
            session = gateway.init_session()

            while True:
                if not prompt_message:
                    prompt_message = self._prompt("You> ").strip()
                    if not prompt_message:
                        break

                session = self._run_chat_turn(
                    gateway=gateway,
                    session=session,
                    history=history,
                    message=prompt_message,
                    skill=skill,
                    mode=mode,
                    model=model,
                    raw=raw,
                )
                state.messages = [dict(item) for item in history]
                try:
                    save_session(state, time_fn=self._time_fn)
                except Exception as exc:
                    self._stderr.write(f"[session_warn] failed to persist: {exc}\n")
                    self._stderr.flush()
                prompt_message = ""
                if message is not None:
                    break

        return 0

    def _run_chat_turn(
        self,
        *,
        gateway: GatewayTransport,
        session: GatewaySession,
        history: list[dict[str, str]],
        message: str,
        skill: str | None,
        mode: str | None,
        model: str | None,
        raw: bool,
    ) -> GatewaySession:
        request_messages = [*history, {"role": "user", "content": message}]
        context: dict[str, Any] = {}
        if skill:
            context["skill"] = skill
        if mode:
            context["mode"] = mode
        started_at = self._time_fn()

        self._write_line(self._style(f"You> {message}", "2"))
        self._write_line(DIVIDER)

        assistant_parts: list[str] = []
        tool_inputs: dict[str, dict[str, Any]] = {}
        tool_calls: list[dict[str, Any]] = []
        terminal_status: str | None = None
        attempt = 0

        while attempt < 2:
            assistant_parts = []
            tool_inputs = {}
            tool_calls = []
            terminal_status = None
            buffer = ""

            with gateway.stream_chat(
                session=session,
                messages=request_messages,
                context=context,
                model=model,
            ) as response:
                if response.status_code == 401:
                    if attempt == 0:
                        session = gateway.init_session()
                        attempt += 1
                        continue
                    raise CLIError(
                        f"Chat failed after session refresh (401): {extract_error_detail(response)}"
                    )
                if response.status_code >= 400:
                    raise CLIError(
                        f"Chat failed ({response.status_code}): {extract_error_detail(response)}"
                    )

                for chunk in response.iter_text():
                    if not chunk:
                        continue
                    buffer += chunk
                    events, buffer = parse_sse_events(buffer)
                    terminal_status = self._handle_events(
                        gateway=gateway,
                        session=session,
                        events=events,
                        raw=raw,
                        started_at=started_at,
                        assistant_parts=assistant_parts,
                        tool_inputs=tool_inputs,
                        tool_calls=tool_calls,
                    )
                    if terminal_status is not None:
                        break

                if terminal_status is None and buffer:
                    events, _remainder = parse_sse_events(f"{buffer}\n\n")
                    terminal_status = self._handle_events(
                        gateway=gateway,
                        session=session,
                        events=events,
                        raw=raw,
                        started_at=started_at,
                        assistant_parts=assistant_parts,
                        tool_inputs=tool_inputs,
                        tool_calls=tool_calls,
                    )
            break

        self._close_text_line()
        if terminal_status is None:
            raise CLIError("Chat stream ended before a terminal event.")
        if terminal_status != "complete":
            return session

        assistant_text = "".join(assistant_parts).strip() or "No response generated."
        history.append({"role": "user", "content": message})
        history_text = assistant_text
        tool_summary = _build_tool_summary(tool_calls)
        if tool_summary:
            history_text = f"{assistant_text}\n\n{tool_summary}"
        history.append({"role": "assistant", "content": history_text})
        return session

    def _handle_events(
        self,
        *,
        gateway: GatewayTransport,
        session: GatewaySession,
        events: list[dict[str, Any]],
        raw: bool,
        started_at: float,
        assistant_parts: list[str],
        tool_inputs: dict[str, dict[str, Any]],
        tool_calls: list[dict[str, Any]],
    ) -> str | None:
        for event in events:
            if raw:
                self._close_text_line()
                self._write_line(f"[raw] {_json_compact(event)}")
            normalized = dispatch_event(event)
            if normalized is None:
                continue
            terminal_status = self._handle_normalized_event(
                gateway=gateway,
                session=session,
                normalized=normalized,
                started_at=started_at,
                assistant_parts=assistant_parts,
                tool_inputs=tool_inputs,
                tool_calls=tool_calls,
            )
            if terminal_status is not None:
                return terminal_status
        return None

    def _handle_normalized_event(
        self,
        *,
        gateway: GatewayTransport,
        session: GatewaySession,
        normalized: NormalizedEvent,
        started_at: float,
        assistant_parts: list[str],
        tool_inputs: dict[str, dict[str, Any]],
        tool_calls: list[dict[str, Any]],
    ) -> str | None:
        name = normalized.name
        payload = normalized.payload

        if name == "assistant_text_append":
            text = str(payload.get("text", "") or "")
            if text:
                assistant_parts.append(text)
                self._write_stream_delta(kind="text", prefix="[text] ", text=text)
            return None

        if name == "thinking_text_append":
            text = str(payload.get("text", "") or "")
            if text:
                log.debug("thinking_delta: %s", text)
            return None

        self._close_text_line()

        if name == "tool_start":
            tool_call_id = str(payload.get("tool_call_id", "") or "")
            raw_input = payload.get("tool_input")
            tool_input = raw_input if isinstance(raw_input, dict) else {}
            tool_inputs[tool_call_id] = tool_input
            suffix = f" input={_truncate(_json_compact(tool_input))}" if tool_call_id and tool_input else ""
            self._write_line(
                self._style(
                    f"[tool_call_start] {payload.get('tool_name', 'tool')}  "
                    f"call_id={tool_call_id}{suffix}",
                    "36",
                )
            )
            return None

        if name == "tool_chunk":
            log.debug(
                "tool_output_chunk: call_id=%s stream=%s seq=%s text=%s",
                payload.get("tool_call_id"),
                payload.get("stream"),
                payload.get("seq"),
                payload.get("text"),
            )
            return None

        if name == "tool_complete":
            tool_name = str(payload.get("tool_name", "tool"))
            tool_call_id = str(payload.get("tool_call_id", "") or "")
            result = payload.get("result")
            error = payload.get("error")
            tool_calls.append(
                {
                    "tool_name": tool_name,
                    "tool_input": tool_inputs.get(tool_call_id, {}),
                    "is_error": error is not None,
                    "result_summary": _summarize_result(result),
                    "error_message": _tool_error_message(error),
                }
            )
            try:
                result_bytes = (
                    len(json.dumps(result, default=str).encode("utf-8"))
                    if result is not None
                    else 0
                )
            except TypeError:
                result_bytes = len(str(result).encode("utf-8")) if result is not None else 0
            line = (
                f"[tool_call_complete] {tool_name}  "
                f"call_id={tool_call_id}  result_bytes={result_bytes}"
            )
            if error is not None:
                line = f"{line}  error={_event_error_message(error)}"
            self._write_line(self._style(line, "36"))
            return None

        if name == "tool_approval_needed":
            self._render_approval_request(gateway=gateway, session=session, payload=payload)
            return None

        if name == "interceptor_warning":
            action = str(payload.get("action", "") or "")
            message = str(payload.get("message", "") or payload.get("code", "") or "")
            style = "31" if action == "deny" else "33"
            self._write_line(self._style(f"[interceptor] {action}: {message}", style))
            return None

        if name == "stream_retry_notice":
            self._write_line(
                self._style(
                    f"[retry] attempt={payload.get('attempt', '?')} "
                    f"error={_event_error_message(payload.get('error'))}",
                    "33",
                )
            )
            return None

        if name == "compaction_notice":
            self._write_line(f"[compaction] chars={payload.get('chars', '?')}")
            return None

        if name == "terminal_max_turns":
            self._write_line(
                self._style(
                    f"[max_turns_reached] turn_count={payload.get('turn_count', '?')}/"
                    f"max_turns={payload.get('max_turns', '?')}",
                    "33",
                )
            )
            return "max_turns"

        if name == "terminal_budget_exceeded":
            self._write_line(
                self._style(
                    f"[budget_exceeded] total_cost=${payload.get('total_cost', '?')} / "
                    f"budget=${payload.get('budget', '?')}",
                    "33",
                )
            )
            return "budget_exceeded"

        if name == "terminal_complete":
            usage_raw = payload.get("usage")
            usage = usage_raw if isinstance(usage_raw, dict) else {}
            elapsed = self._time_fn() - started_at
            self._write_line(
                f"[done] {elapsed:.1f}s usage: "
                f"in={_usage_int(usage, 'input_tokens')} "
                f"out={_usage_int(usage, 'output_tokens')} "
                f"cache_read={_usage_int(usage, 'cache_read_input_tokens')} "
                f"cache_create={_usage_int(usage, 'cache_creation_input_tokens')} "
                f"cost=${_usage_float(usage, 'estimated_cost'):.4f}"
            )
            return "complete"

        if name == "terminal_error":
            self._write_line(
                self._style(
                    f"[{payload.get('source', 'error')}] "
                    f"{_event_error_message(payload.get('error'))}",
                    "31",
                )
            )
            return "error"

        return None

    def _render_approval_request(
        self,
        *,
        gateway: GatewayTransport,
        session: GatewaySession,
        payload: dict[str, Any],
    ) -> None:
        tool_name = str(payload.get("tool_name", "tool"))
        tool_call_id = str(payload.get("tool_call_id", "") or "")
        nonce = str(payload.get("nonce", "") or "")
        tool_input = payload.get("tool_input") if isinstance(payload.get("tool_input"), dict) else {}
        reason = str(payload.get("reason", "") or "").strip()
        allow_persistent = bool(payload.get("allow_persistent_approval"))

        self._write_line(
            self._style(
                f"[tool_approval_request] {tool_name}  call_id={tool_call_id}  nonce={nonce}",
                "1;33",
            )
        )
        if reason:
            self._write_line(f"  reason: {reason}")
        self._write_line(_json_pretty({"tool_input": tool_input}))
        prompt = (
            "  -> Allow? [y/Y(approve all of this type)/N]: "
            if allow_persistent
            else "  -> Allow? [y/N]: "
        )
        decision = self._prompt(prompt).strip()
        approved = decision in {"y", "Y"}
        allow_tool_type = allow_persistent and decision == "Y"
        gateway.submit_approval(
            session=session,
            tool_call_id=tool_call_id,
            nonce=nonce,
            approved=approved,
            allow_tool_type=allow_tool_type,
        )
        suffix = " allow_tool_type=true" if allow_tool_type else ""
        self._write_line(f"[approval_submitted] {'approved' if approved else 'denied'}{suffix}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m agent_gateway_cli",
        description="Gateway-direct dev chat CLI for local agent-gateway debugging.",
    )
    parser.add_argument(
        "--config-namespace",
        default=DEFAULT_NAMESPACE,
        help=(
            "Cache namespace for cli_config.json and sessions. "
            f"Defaults to {DEFAULT_NAMESPACE}."
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    def add_connection_args(target: argparse.ArgumentParser) -> None:
        target.add_argument(
            "--base-url",
            default=None,
            help=f"Gateway base URL. Defaults to saved config, env, or {DEFAULT_BASE_URL}.",
        )
        target.add_argument(
            "--api-key",
            default=None,
            help="Gateway API key override. Otherwise uses env or saved config.",
        )
        target.add_argument(
            "--user-id",
            default=None,
            help="Gateway user_id override.",
        )

    login_parser = subparsers.add_parser("login", help="Verify /api/chat/init and save CLI config.")
    add_connection_args(login_parser)

    chat_parser = subparsers.add_parser(
        "chat",
        help="Stream chat directly from the gateway using init -> bearer -> chat.",
    )
    add_connection_args(chat_parser)
    chat_parser.add_argument(
        "message",
        nargs="*",
        help="Message to send. If omitted, starts an interactive prompt.",
    )
    chat_parser.add_argument("--skill", help="Attach context.skill to every chat request.")
    chat_parser.add_argument("--mode", help="Attach context.mode to every chat request.")
    chat_parser.add_argument("--model", help="Top-level gateway model override.")
    chat_parser.add_argument(
        "--raw",
        action="store_true",
        help="Print raw parsed SSE events alongside rendered output.",
    )
    chat_parser.add_argument(
        "--session",
        default=DEFAULT_SESSION,
        help=(
            "Named session for persisted history. Default 'default'. Concurrent invocations "
            "on the same session race; last writer wins."
        ),
    )
    chat_parser.add_argument(
        "--new",
        action="store_true",
        help="Truncate this session's history before sending.",
    )
    return parser


def main(
    argv: list[str] | None = None,
    *,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
    input_fn: Callable[[], str] | None = None,
    time_fn: Callable[[], float] = time.time,
    transport: httpx.BaseTransport | None = None,
    base_url_policy: BaseUrlPolicy | None = None,
) -> int:
    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    input_fn = input_fn or (lambda: input())
    parser = build_parser()
    args = parser.parse_args(argv)

    cli = DevChatCLI(
        stdout=stdout,
        stderr=stderr,
        input_fn=input_fn,
        time_fn=time_fn,
        transport=transport,
        base_url_policy=base_url_policy,
    )

    try:
        if args.command == "login":
            return cli.login(
                base_url=args.base_url,
                api_key=args.api_key,
                user_id=args.user_id,
                config_namespace=args.config_namespace,
            )

        if args.command == "chat":
            message = " ".join(args.message).strip() if args.message else None
            return cli.chat(
                message=message,
                skill=args.skill,
                mode=args.mode,
                model=args.model,
                raw=bool(args.raw),
                new_history=bool(args.new),
                session_name=args.session,
                base_url=args.base_url,
                api_key=args.api_key,
                user_id=args.user_id,
                config_namespace=args.config_namespace,
            )
    except CLIError as exc:
        stderr.write(f"{exc}\n")
        stderr.flush()
        return 1

    parser.error(f"Unknown command: {args.command}")
    return 2
