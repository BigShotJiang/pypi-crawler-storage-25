#!/usr/bin/env python3
"""
Integration test for sun and moon properties.

This test verifies that:
1. sun and moon properties exist and work
2. The returned SkyCoord objects have obsgeoloc/obsgeovel set correctly
3. The celestial body positions and velocities match expected values
4. obsgeoloc/obsgeovel match the spacecraft GCRS position/velocity

Requirements:
    pip install astropy numpy

Build and install the Rust module first:
    maturin build --release
    pip install target/wheels/*.whl
"""

import sys
from typing import Any

import numpy as np
import pytest
from astropy.coordinates.sky_coordinate import SkyCoord  # type: ignore[import-untyped]

try:
    from astropy.coordinates import (  # type: ignore[import-untyped]
        GCRS,
        SkyCoord,
        get_body,
    )
    from astropy.time import Time  # type: ignore[import-untyped]

    ASTROPY_AVAILABLE = True
except ImportError:
    ASTROPY_AVAILABLE = False


from .conftest import TOLERANCE


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_sun_type(sun: Any) -> None:
    """Test that sun property returns SkyCoord."""
    assert isinstance(sun, SkyCoord), f"Expected SkyCoord, got {type(sun)}"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_sun_length(sun: Any, ephem: Any) -> None:
    """Test that sun has correct length."""
    expected_len: int = len(ephem.timestamp)
    assert len(sun) == expected_len, f"Expected {expected_len} coords, got {len(sun)}"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_sun_frame(sun: Any) -> None:
    """Test that sun is in GCRS frame."""
    assert isinstance(sun.frame, GCRS), f"Expected GCRS frame, got {type(sun.frame)}"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_sun_obsgeoloc_set(sun: Any) -> None:
    """Test that sun obsgeoloc is set."""
    assert sun.frame.obsgeoloc is not None, "obsgeoloc not set"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_sun_obsgeovel_set(sun: Any) -> None:
    """Test that sun obsgeovel is set."""
    assert sun.frame.obsgeovel is not None, "obsgeovel not set"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))  # 31 timestamps based on BEGIN, END, STEP_SIZE
def test_sun_obsgeoloc_match(sun: Any, ephem: Any, i: int) -> None:
    """Test that sun obsgeoloc matches spacecraft position at index i."""
    expected_pos = ephem.gcrs_pv.position[i]
    actual_pos = np.array(
        [
            sun.frame.obsgeoloc[i].x.to("km").value,
            sun.frame.obsgeoloc[i].y.to("km").value,
            sun.frame.obsgeoloc[i].z.to("km").value,
        ]
    )
    assert np.allclose(expected_pos, actual_pos, rtol=TOLERANCE), (
        f"obsgeoloc mismatch at index {i}"
    )


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))  # 31 timestamps based on BEGIN, END, STEP_SIZE
def test_sun_obsgeovel_match(sun: Any, ephem: Any, i: int) -> None:
    """Test that sun obsgeovel matches spacecraft velocity at index i."""
    expected_vel = ephem.gcrs_pv.velocity[i]
    actual_vel = np.array(
        [
            sun.frame.obsgeovel[i].x.to("km/s").value,
            sun.frame.obsgeovel[i].y.to("km/s").value,
            sun.frame.obsgeovel[i].z.to("km/s").value,
        ]
    )
    assert np.allclose(expected_vel, actual_vel, rtol=TOLERANCE), (
        f"obsgeovel mismatch at index {i}"
    )


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))  # 31 timestamps based on BEGIN, END, STEP_SIZE
def test_sun_position_match(sun: Any, ephem: Any, i: int) -> None:
    """Test that sun position matches expected at index i."""
    expected_sun_pos = ephem.sun_pv.position[i] - ephem.gcrs_pv.position[i]
    actual_sun_pos = sun[i].cartesian.xyz.to("km").value
    assert np.allclose(expected_sun_pos, actual_sun_pos, rtol=TOLERANCE), (
        f"Sun position mismatch at index {i}"
    )


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))  # 31 timestamps based on BEGIN, END, STEP_SIZE
def test_sun_velocity_match(sun: Any, ephem: Any, i: int) -> None:
    """Test that sun velocity matches expected at index i."""
    expected_sun_vel = ephem.sun_pv.velocity[i] - ephem.gcrs_pv.velocity[i]
    actual_sun_vel = sun[i].velocity.d_xyz.to("km/s").value
    assert np.allclose(expected_sun_vel, actual_sun_vel, rtol=TOLERANCE), (
        f"Sun velocity mismatch at index {i}"
    )


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_moon_type(moon: Any) -> None:
    """Test that moon property returns SkyCoord."""
    assert isinstance(moon, SkyCoord), f"Expected SkyCoord, got {type(moon)}"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_moon_length(moon: Any, ephem: Any) -> None:
    """Test that moon has correct length."""
    expected_len: int = len(ephem.timestamp)
    assert len(moon) == expected_len, f"Expected {expected_len} coords, got {len(moon)}"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_moon_frame(moon: Any) -> None:
    """Test that moon is in GCRS frame."""
    assert isinstance(moon.frame, GCRS), f"Expected GCRS frame, got {type(moon.frame)}"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_moon_obsgeoloc_set(moon: Any) -> None:
    """Test that moon obsgeoloc is set."""
    assert moon.frame.obsgeoloc is not None, "obsgeoloc not set"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
def test_moon_obsgeovel_set(moon: Any) -> None:
    """Test that moon obsgeovel is set."""
    assert moon.frame.obsgeovel is not None, "obsgeovel not set"


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))  # 31 timestamps based on BEGIN, END, STEP_SIZE
def test_moon_obsgeoloc_match(moon: Any, ephem: Any, i: int) -> None:
    """Test that moon obsgeoloc matches spacecraft position at index i."""
    expected_pos = ephem.gcrs_pv.position[i]
    actual_pos = np.array(
        [
            moon.frame.obsgeoloc[i].x.to("km").value,
            moon.frame.obsgeoloc[i].y.to("km").value,
            moon.frame.obsgeoloc[i].z.to("km").value,
        ]
    )
    assert np.allclose(expected_pos, actual_pos, rtol=TOLERANCE), (
        f"obsgeoloc mismatch at index {i}"
    )


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))  # 31 timestamps based on BEGIN, END, STEP_SIZE
def test_moon_obsgeovel_match(moon: Any, ephem: Any, i: int) -> None:
    """Test that moon obsgeovel matches spacecraft velocity at index i."""
    expected_vel = ephem.gcrs_pv.velocity[i]
    actual_vel = np.array(
        [
            moon.frame.obsgeovel[i].x.to("km/s").value,
            moon.frame.obsgeovel[i].y.to("km/s").value,
            moon.frame.obsgeovel[i].z.to("km/s").value,
        ]
    )
    assert np.allclose(expected_vel, actual_vel, rtol=TOLERANCE), (
        f"obsgeovel mismatch at index {i}"
    )


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))  # 31 timestamps based on BEGIN, END, STEP_SIZE
def test_moon_position_match(moon: Any, ephem: Any, i: int) -> None:
    """Test that moon position matches expected at index i."""
    expected_moon_pos = ephem.moon_pv.position[i] - ephem.gcrs_pv.position[i]
    actual_moon_pos = moon[i].cartesian.xyz.to("km").value
    assert np.allclose(expected_moon_pos, actual_moon_pos, rtol=TOLERANCE), (
        f"Moon position mismatch at index {i}"
    )


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))  # 31 timestamps based on BEGIN, END, STEP_SIZE
def test_moon_velocity_match(moon: Any, ephem: Any, i: int) -> None:
    """Test that moon velocity matches expected at index i."""
    expected_moon_vel = ephem.moon_pv.velocity[i] - ephem.gcrs_pv.velocity[i]
    actual_moon_vel = moon[i].velocity.d_xyz.to("km/s").value
    assert np.allclose(expected_moon_vel, actual_moon_vel, rtol=TOLERANCE), (
        f"Moon velocity mismatch at index {i}"
    )


# Find Moon position using astropy get_body and compare to ephemeris
# value_chain
@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))
def test_moon_ra_compare_to_astropy(moon: Any, ephem: Any, i: int) -> None:
    """Test that moon RA matches expected using astropy at index i."""
    expected_moon_pos = ephem.moon[i]
    actual_moon_pos: SkyCoord = get_body(
        "moon", Time(ephem.timestamp[i]), location=ephem.itrs.earth_location[i]
    )
    assert np.allclose(expected_moon_pos.ra.value, actual_moon_pos.ra.value, rtol=1e-3)


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))
def test_moon_dec_compare_to_astropy(moon: Any, ephem: Any, i: int) -> None:
    """Test that moon Dec matches expected using astropy at index i."""
    expected_moon_pos = ephem.moon[i]
    actual_moon_pos: SkyCoord = get_body(
        "moon", Time(ephem.timestamp[i]), location=ephem.itrs.earth_location[i]
    )
    assert np.allclose(
        expected_moon_pos.dec.value, actual_moon_pos.dec.value, rtol=1e-3
    )


# Find Sun position using astropy get_body and compare to ephemeris
@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))
def test_sun_ra_compare_to_astropy(sun: Any, ephem: Any, i: int) -> None:
    """Test that sun RA matches expected using astropy at index i."""
    expected_sun_pos = ephem.sun[i]
    actual_sun_pos: SkyCoord = get_body(
        "sun", Time(ephem.timestamp[i]), location=ephem.itrs.earth_location[i]
    )
    assert np.allclose(expected_sun_pos.ra.value, actual_sun_pos.ra.value, rtol=1e-4)


@pytest.mark.skipif(not ASTROPY_AVAILABLE, reason="astropy not available")
@pytest.mark.parametrize("i", range(31))
def test_sun_dec_compare_to_astropy(sun: Any, ephem: Any, i: int) -> None:
    """Test that sun Dec matches expected using astropy at index i."""
    expected_sun_pos = ephem.sun[i]
    actual_sun_pos: SkyCoord = get_body(
        "sun", Time(ephem.timestamp[i]), location=ephem.itrs.earth_location[i]
    )
    assert np.allclose(expected_sun_pos.dec.value, actual_sun_pos.dec.value, rtol=1e-3)


def main() -> int:
    """Run all tests."""
    print("\n" + "=" * 80)
    print("Sun and Moon gcrs_to_skycoord() Integration Tests")
    print("=" * 80)

    # Since the tests are now pytest-based, we can run them via pytest
    # For standalone execution, we can use pytest.main()
    import pytest

    return pytest.main([__file__, "-v"])


if __name__ == "__main__":
    sys.exit(main())
