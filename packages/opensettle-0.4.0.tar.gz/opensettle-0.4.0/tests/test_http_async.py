"""AsyncHttpClient — request shape, errors, retries (parity with sync)."""

from __future__ import annotations

from collections.abc import AsyncIterator

import httpx
import pytest
import respx

from helpers import envelope
from opensettle import (
    SDK_VERSION,
    APIError,
    AuthenticationError,
    ConflictError,
    InvalidRequestError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    SettlementError,
    StepUpRequiredError,
)
from opensettle._http_async import AsyncHttpClient


@pytest.fixture
async def client(
    key: str, workspace_id: str, base_url: str, no_async_sleep
) -> AsyncIterator[AsyncHttpClient]:
    c = AsyncHttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_async_sleep,
    )
    try:
        yield c
    finally:
        await c.aclose()


@pytest.fixture
def url(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/x"


async def test_async_auth_header(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str, key: str
) -> None:
    route = respx_mock.get(url).mock(return_value=httpx.Response(200, json={"ok": True}))
    await client.request("/x")
    assert route.calls.last.request.headers["authorization"] == f"Bearer {key}"


async def test_async_user_agent(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    route = respx_mock.get(url).mock(return_value=httpx.Response(200, json={"ok": True}))
    await client.request("/x")
    assert route.calls.last.request.headers["user-agent"] == f"opensettle-python/{SDK_VERSION}"


async def test_async_query_encoding(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    route = respx_mock.get(url).mock(return_value=httpx.Response(200, json={"ok": True}))
    await client.request("/x", query={"limit": 10, "cursor": None, "q": "hi there"})
    full = str(route.calls.last.request.url)
    assert "limit=10" in full
    assert "cursor" not in full
    assert ("q=hi+there" in full) or ("q=hi%20there" in full)


async def test_async_json_body(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    route = respx_mock.post(url).mock(return_value=httpx.Response(200, json={"ok": True}))
    await client.request("/x", method="POST", body={"email": "a@b.co"})
    assert route.calls.last.request.headers["content-type"] == "application/json"


async def test_async_idempotency_auto(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    route = respx_mock.post(url).mock(return_value=httpx.Response(200, json={"ok": True}))
    await client.request("/x", method="POST", body={}, idempotency_key=True)
    assert route.calls.last.request.headers.get("idempotency-key", "").startswith("os_")


async def test_async_returns_json(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(200, json={"id": "x"}))
    r = await client.request("/x")
    assert r == {"id": "x"}


async def test_async_returns_none_on_204(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.delete(url).mock(return_value=httpx.Response(204))
    assert await client.request("/x", method="DELETE") is None


@pytest.mark.parametrize(
    "status,code,cls",
    [
        (400, "invalid_request", InvalidRequestError),
        (401, "unauthorized", AuthenticationError),
        (401, "aal_required", StepUpRequiredError),
        (404, "not_found", NotFoundError),
        (409, "conflict", ConflictError),
        (422, "chain_reverted", SettlementError),
        (500, "internal_error", APIError),
    ],
)
async def test_async_error_mapping(
    client: AsyncHttpClient,
    respx_mock: respx.MockRouter,
    url: str,
    status: int,
    code: str,
    cls: type,
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(status, json=envelope(code)))
    with pytest.raises(cls):
        await client.request("/x")


async def test_async_429_retry_after(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_async_sleep,
    url: str,
) -> None:
    c = AsyncHttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_async_sleep,
        max_network_retries=0,
    )
    try:
        respx_mock.get(url).mock(
            return_value=httpx.Response(
                429, json=envelope("rate_limited"), headers={"retry-after": "5"}
            )
        )
        with pytest.raises(RateLimitError) as ei:
            await c.request("/x")
        assert ei.value.retry_after == 5.0
    finally:
        await c.aclose()


async def test_async_retries_5xx(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_async_sleep,
    url: str,
) -> None:
    c = AsyncHttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_async_sleep,
        max_network_retries=2,
    )
    try:
        route = respx_mock.get(url).mock(
            side_effect=[
                httpx.Response(500, json=envelope("internal_error")),
                httpx.Response(200, json={"ok": True}),
            ]
        )
        r = await c.request("/x")
        assert r == {"ok": True}
        assert route.call_count == 2
    finally:
        await c.aclose()


async def test_async_retries_network_error(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_async_sleep,
    url: str,
) -> None:
    c = AsyncHttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_async_sleep,
        max_network_retries=1,
    )
    try:
        respx_mock.get(url).mock(side_effect=httpx.ConnectError("nope"))
        with pytest.raises(NetworkError):
            await c.request("/x")
    finally:
        await c.aclose()


async def test_async_close_via_context_manager(
    key: str, workspace_id: str, base_url: str, no_async_sleep
) -> None:
    async with AsyncHttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_async_sleep,
    ) as c:
        assert c.base_url == base_url


async def test_async_url_workspace_prefix(client: AsyncHttpClient, workspace_id: str) -> None:
    assert (
        client.url("/customers")
        == f"https://api.example.com/v1/workspaces/{workspace_id}/customers"
    )


async def test_async_raw_url_no_prefix(client: AsyncHttpClient) -> None:
    assert client.raw_url("/v1/health") == "https://api.example.com/v1/health"


async def test_async_custom_header(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    route = respx_mock.get(url).mock(return_value=httpx.Response(200, json={"ok": True}))
    await client.request("/x", headers={"X-Trace": "abc"})
    assert route.calls.last.request.headers["x-trace"] == "abc"


async def test_async_returns_none_on_empty_body(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.post(url).mock(return_value=httpx.Response(201, content=b""))
    assert await client.request("/x", method="POST", body={}) is None


async def test_async_does_not_retry_400(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_async_sleep,
    url: str,
) -> None:
    c = AsyncHttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_async_sleep,
        max_network_retries=5,
    )
    try:
        route = respx_mock.get(url).mock(
            return_value=httpx.Response(400, json=envelope("invalid_request"))
        )
        with pytest.raises(InvalidRequestError):
            await c.request("/x")
        assert route.call_count == 1
    finally:
        await c.aclose()


async def test_async_idempotency_caller_supplied(
    client: AsyncHttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    route = respx_mock.post(url).mock(return_value=httpx.Response(200, json={"ok": True}))
    await client.request("/x", method="POST", body={}, idempotency_key="caller-key")
    assert route.calls.last.request.headers["idempotency-key"] == "caller-key"
