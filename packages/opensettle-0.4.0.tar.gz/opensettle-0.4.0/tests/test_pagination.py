"""Pagination iterator — sync + async."""

from __future__ import annotations

from typing import Any

from opensettle import aiterate, paginate


def test_paginate_single_page() -> None:
    def fetch(**_q: Any) -> dict[str, Any]:
        return {"data": [{"id": "a"}, {"id": "b"}], "nextCursor": None, "hasMore": False}

    out = list(paginate(fetch))
    assert out == [{"id": "a"}, {"id": "b"}]


def test_paginate_two_pages() -> None:
    pages = [
        {"data": [{"id": "a"}], "nextCursor": "cur_1", "hasMore": True},
        {"data": [{"id": "b"}], "nextCursor": None, "hasMore": False},
    ]
    i = iter(pages)

    def fetch(**q: Any) -> dict[str, Any]:
        return next(i)

    out = list(paginate(fetch))
    assert out == [{"id": "a"}, {"id": "b"}]


def test_paginate_passes_cursor_forward() -> None:
    seen_cursors: list[Any] = []
    pages = iter(
        [
            {"data": [{"id": "a"}], "nextCursor": "cur_x", "hasMore": True},
            {"data": [{"id": "b"}], "nextCursor": None, "hasMore": False},
        ]
    )

    def fetch(**q: Any) -> dict[str, Any]:
        seen_cursors.append(q.get("cursor"))
        return next(pages)

    list(paginate(fetch))
    assert seen_cursors == [None, "cur_x"]


def test_paginate_passes_initial_query_through() -> None:
    captured: list[dict[str, Any]] = []

    def fetch(**q: Any) -> dict[str, Any]:
        captured.append(dict(q))
        return {"data": [], "nextCursor": None, "hasMore": False}

    list(paginate(fetch, status="active", limit=10))
    assert captured == [{"status": "active", "limit": 10}]


def test_paginate_drops_none_filters() -> None:
    captured: list[dict[str, Any]] = []

    def fetch(**q: Any) -> dict[str, Any]:
        captured.append(dict(q))
        return {"data": [], "nextCursor": None, "hasMore": False}

    list(paginate(fetch, status=None, limit=None))
    assert captured == [{}]


def test_paginate_stops_on_has_more_false_even_with_cursor() -> None:
    def fetch(**_q: Any) -> dict[str, Any]:
        return {"data": [], "nextCursor": "ignored", "hasMore": False}

    out = list(paginate(fetch))
    assert out == []


def test_paginate_handles_empty_pages() -> None:
    pages = iter(
        [
            {"data": [], "nextCursor": "cur_1", "hasMore": True},
            {"data": [{"id": "z"}], "nextCursor": None, "hasMore": False},
        ]
    )

    def fetch(**_q: Any) -> dict[str, Any]:
        return next(pages)

    assert list(paginate(fetch)) == [{"id": "z"}]


async def test_aiterate_single_page() -> None:
    async def fetch(**_q: Any) -> dict[str, Any]:
        return {"data": [{"id": "a"}, {"id": "b"}], "nextCursor": None, "hasMore": False}

    out = [item async for item in aiterate(fetch)]
    assert out == [{"id": "a"}, {"id": "b"}]


async def test_aiterate_two_pages() -> None:
    pages = iter(
        [
            {"data": [{"id": "a"}], "nextCursor": "cur_1", "hasMore": True},
            {"data": [{"id": "b"}], "nextCursor": None, "hasMore": False},
        ]
    )

    async def fetch(**_q: Any) -> dict[str, Any]:
        return next(pages)

    out = [item async for item in aiterate(fetch)]
    assert out == [{"id": "a"}, {"id": "b"}]


async def test_aiterate_passes_cursor_forward() -> None:
    seen: list[Any] = []
    pages = iter(
        [
            {"data": [{"id": "a"}], "nextCursor": "cur_y", "hasMore": True},
            {"data": [], "nextCursor": None, "hasMore": False},
        ]
    )

    async def fetch(**q: Any) -> dict[str, Any]:
        seen.append(q.get("cursor"))
        return next(pages)

    _ = [x async for x in aiterate(fetch)]
    assert seen == [None, "cur_y"]
