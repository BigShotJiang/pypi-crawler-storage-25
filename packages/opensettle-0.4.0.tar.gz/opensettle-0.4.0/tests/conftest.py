"""Shared pytest fixtures.

Conventions used across the test suite:

- ``KEY`` is a test-mode key; we always use ``sk_test_…`` for fixtures
  so the env-assertion gate stays out of the way unless a test
  specifically exercises it.
- ``WS`` is a workspace ID that round-trips cleanly through
  ``urllib.parse.quote``.
- ``BASE_URL`` is non-canonical (``https://api.example.com``) so a
  bug that hard-codes the prod host would surface as a failed mock.
- ``no_sleep`` / ``no_async_sleep`` neuter the retry backoff so retry
  tests are instant and deterministic.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import pytest

KEY = "sk_test_abcdefghij12345"
WS = "ws_01HG"
BASE_URL = "https://api.example.com"


@pytest.fixture
def key() -> str:
    return KEY


@pytest.fixture
def workspace_id() -> str:
    return WS


@pytest.fixture
def base_url() -> str:
    return BASE_URL


@pytest.fixture
def no_sleep() -> Any:
    """Drop-in for ``time.sleep`` that records calls but never sleeps."""

    calls: list[float] = []

    def _sleep(seconds: float) -> None:
        calls.append(seconds)

    _sleep.calls = calls  # type: ignore[attr-defined]
    return _sleep


@pytest.fixture
def no_async_sleep() -> Any:
    """Drop-in for ``asyncio.sleep`` that records calls but never sleeps."""

    calls: list[float] = []

    async def _sleep(seconds: float) -> None:
        calls.append(seconds)

    _sleep.calls = calls  # type: ignore[attr-defined]
    return _sleep


@pytest.fixture
def respx_mock() -> Iterator[Any]:
    """Activate respx for one test, with assert_all_called disabled so
    individual tests can opt into stricter assertions when they want.
    """

    import respx

    with respx.mock(assert_all_called=False, assert_all_mocked=True) as router:
        yield router
