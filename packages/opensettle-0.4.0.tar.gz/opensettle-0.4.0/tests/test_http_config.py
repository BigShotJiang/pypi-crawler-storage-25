"""HttpClient + AsyncHttpClient — configuration validation matrix."""

from __future__ import annotations

import pytest

from opensettle._http import HttpClient
from opensettle._http_async import AsyncHttpClient
from opensettle._transport import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_NETWORK_RETRIES,
    DEFAULT_TIMEOUT_SECONDS,
    assert_api_key_environment,
)


@pytest.fixture
def kwargs(key: str, workspace_id: str, no_sleep) -> dict:
    return {
        "api_key": key,
        "workspace_id": workspace_id,
        "_sleep": no_sleep,
    }


def test_sync_requires_api_key(workspace_id: str) -> None:
    with pytest.raises(ValueError, match="api_key is required"):
        HttpClient(api_key="", workspace_id=workspace_id)


def test_sync_requires_workspace_id(key: str) -> None:
    with pytest.raises(ValueError, match="workspace_id is required"):
        HttpClient(api_key=key, workspace_id="")


def test_async_requires_api_key(workspace_id: str) -> None:
    with pytest.raises(ValueError, match="api_key is required"):
        AsyncHttpClient(api_key="", workspace_id=workspace_id)


def test_async_requires_workspace_id(key: str) -> None:
    with pytest.raises(ValueError, match="workspace_id is required"):
        AsyncHttpClient(api_key=key, workspace_id="")


def test_rejects_malformed_api_key_prefix(workspace_id: str) -> None:
    with pytest.raises(ValueError, match="sk_live_"):
        HttpClient(api_key="pk_live_xxx", workspace_id=workspace_id)


def test_rejects_completely_unprefixed_key(workspace_id: str) -> None:
    with pytest.raises(ValueError, match="sk_live_"):
        HttpClient(api_key="no_prefix_here", workspace_id=workspace_id)


def test_test_mode_true_refuses_live_key(workspace_id: str) -> None:
    with pytest.raises(ValueError, match="refusing to send live traffic"):
        HttpClient(
            api_key="sk_live_abc",
            workspace_id=workspace_id,
            test_mode=True,
        )


def test_test_mode_false_refuses_test_key(workspace_id: str) -> None:
    with pytest.raises(ValueError, match="refusing to send to test API"):
        HttpClient(
            api_key="sk_test_abc",
            workspace_id=workspace_id,
            test_mode=False,
        )


def test_test_mode_none_accepts_test_key(workspace_id: str) -> None:
    HttpClient(api_key="sk_test_xyz", workspace_id=workspace_id, test_mode=None)


def test_test_mode_none_accepts_live_key(workspace_id: str) -> None:
    HttpClient(api_key="sk_live_xyz", workspace_id=workspace_id, test_mode=None)


def test_test_mode_true_accepts_test_key(workspace_id: str) -> None:
    HttpClient(api_key="sk_test_xyz", workspace_id=workspace_id, test_mode=True)


def test_test_mode_false_accepts_live_key(workspace_id: str) -> None:
    HttpClient(api_key="sk_live_xyz", workspace_id=workspace_id, test_mode=False)


def test_base_url_default(kwargs: dict) -> None:
    c = HttpClient(**kwargs)
    assert c.base_url == DEFAULT_BASE_URL


def test_base_url_trailing_slash_trim(kwargs: dict) -> None:
    c = HttpClient(**kwargs, base_url="https://api.example.com/")
    assert c.base_url == "https://api.example.com"


def test_base_url_many_trailing_slashes_trim(kwargs: dict) -> None:
    c = HttpClient(**kwargs, base_url="https://api.example.com///")
    assert c.base_url == "https://api.example.com"


def test_timeout_default(kwargs: dict) -> None:
    c = HttpClient(**kwargs)
    assert c.timeout == DEFAULT_TIMEOUT_SECONDS


def test_timeout_override(kwargs: dict) -> None:
    c = HttpClient(**kwargs, timeout=5.0)
    assert c.timeout == 5.0


def test_max_network_retries_default(kwargs: dict) -> None:
    c = HttpClient(**kwargs)
    assert c.max_network_retries == DEFAULT_MAX_NETWORK_RETRIES


def test_max_network_retries_override(kwargs: dict) -> None:
    c = HttpClient(**kwargs, max_network_retries=7)
    assert c.max_network_retries == 7


@pytest.mark.parametrize(
    "key,test_mode,should_raise",
    [
        ("sk_live_abc", True, True),
        ("sk_test_abc", False, True),
        ("sk_live_abc", False, False),
        ("sk_test_abc", True, False),
        ("sk_live_abc", None, False),
        ("sk_test_abc", None, False),
    ],
)
def test_assert_api_key_environment_matrix(key: str, test_mode: bool, should_raise: bool) -> None:
    if should_raise:
        with pytest.raises(ValueError):
            assert_api_key_environment(key, test_mode)
    else:
        assert_api_key_environment(key, test_mode)
