"""Typed error hierarchy — construction, fields, ``from_envelope`` mapping."""

from __future__ import annotations

from opensettle import (
    APIError,
    AuthenticationError,
    ConflictError,
    ForbiddenError,
    InvalidRequestError,
    InvalidStateTransitionError,
    NetworkError,
    NotFoundError,
    OpenSettleError,
    RateLimitError,
    SettlementError,
    StepUpRequiredError,
)
from opensettle._errors import from_envelope


def test_openSettle_error_is_base_class() -> None:
    classes = [
        InvalidRequestError,
        InvalidStateTransitionError,
        AuthenticationError,
        ForbiddenError,
        NotFoundError,
        ConflictError,
        RateLimitError,
        SettlementError,
        StepUpRequiredError,
        APIError,
        NetworkError,
    ]
    for cls in classes:
        assert issubclass(cls, OpenSettleError), cls.__name__


def test_invalid_request_error_construction() -> None:
    e = InvalidRequestError(
        "bad email",
        code="invalid_request",
        status=400,
        request_id="req_1",
        param="email",
    )
    assert e.code == "invalid_request"
    assert e.status == 400
    assert e.request_id == "req_1"
    assert e.param == "email"
    assert str(e) == "bad email"


def test_authentication_error_construction() -> None:
    e = AuthenticationError(
        "bad key",
        code="unauthorized",
        status=401,
    )
    assert e.code == "unauthorized"
    assert e.status == 401
    assert e.request_id is None
    assert e.param is None


def test_rate_limit_error_default_retry_after() -> None:
    e = RateLimitError("slow", status=429)
    assert e.code == "rate_limited"
    assert e.retry_after is None


def test_rate_limit_error_with_retry_after() -> None:
    e = RateLimitError("slow", status=429, retry_after=12)
    assert e.retry_after == 12


def test_rate_limit_error_preserves_request_id() -> None:
    e = RateLimitError("slow", status=429, request_id="r_1")
    assert e.request_id == "r_1"


def test_settlement_error_chain_reverted() -> None:
    e = SettlementError("revert", code="chain_reverted", status=422)
    assert e.code == "chain_reverted"


def test_settlement_error_insufficient_confs() -> None:
    e = SettlementError("low", code="insufficient_confirmations", status=422)
    assert e.code == "insufficient_confirmations"


def test_settlement_error_signing_required() -> None:
    e = SettlementError("sign", code="signing_required", status=422)
    assert e.code == "signing_required"


def test_step_up_required_error() -> None:
    e = StepUpRequiredError("aal", code="aal_required", status=401)
    assert e.code == "aal_required"


def test_network_error_defaults() -> None:
    e = NetworkError("dns failed")
    assert e.code == "network_error"
    assert e.status == 0
    assert e.request_id is None
    assert e.param is None


def test_repr_includes_message_and_code() -> None:
    e = NotFoundError("nope", code="not_found", status=404)
    r = repr(e)
    assert "NotFoundError" in r
    assert "not_found" in r
    assert "nope" in r
    assert "404" in r


def test_from_envelope_invalid_request() -> None:
    e = from_envelope({"error": {"code": "invalid_request", "message": "x"}}, 400, None)
    assert isinstance(e, InvalidRequestError)
    assert e.status == 400


def test_from_envelope_invalid_state_transition() -> None:
    e = from_envelope({"error": {"code": "invalid_state_transition", "message": "x"}}, 409, None)
    assert isinstance(e, InvalidStateTransitionError)


def test_from_envelope_unauthorized() -> None:
    e = from_envelope({"error": {"code": "unauthorized"}}, 401, None)
    assert isinstance(e, AuthenticationError)


def test_from_envelope_forbidden() -> None:
    e = from_envelope({"error": {"code": "forbidden"}}, 403, None)
    assert isinstance(e, ForbiddenError)


def test_from_envelope_not_found() -> None:
    e = from_envelope({"error": {"code": "not_found"}}, 404, None)
    assert isinstance(e, NotFoundError)


def test_from_envelope_conflict() -> None:
    e = from_envelope({"error": {"code": "conflict"}}, 409, None)
    assert isinstance(e, ConflictError)


def test_from_envelope_rate_limited_includes_retry_after() -> None:
    e = from_envelope({"error": {"code": "rate_limited"}}, 429, 7.5)
    assert isinstance(e, RateLimitError)
    assert e.retry_after == 7.5


def test_from_envelope_chain_reverted() -> None:
    e = from_envelope({"error": {"code": "chain_reverted"}}, 422, None)
    assert isinstance(e, SettlementError)
    assert e.code == "chain_reverted"


def test_from_envelope_insufficient_confirmations() -> None:
    e = from_envelope({"error": {"code": "insufficient_confirmations"}}, 422, None)
    assert isinstance(e, SettlementError)
    assert e.code == "insufficient_confirmations"


def test_from_envelope_signing_required() -> None:
    e = from_envelope({"error": {"code": "signing_required"}}, 422, None)
    assert isinstance(e, SettlementError)
    assert e.code == "signing_required"


def test_from_envelope_aal_required() -> None:
    e = from_envelope({"error": {"code": "aal_required"}}, 401, None)
    assert isinstance(e, StepUpRequiredError)


def test_from_envelope_internal_error() -> None:
    e = from_envelope({"error": {"code": "internal_error"}}, 500, None)
    assert isinstance(e, APIError)
    assert e.code == "internal_error"


def test_from_envelope_unknown_code_falls_back() -> None:
    e = from_envelope({"error": {"code": "future_unknown_thing"}}, 599, None)
    assert isinstance(e, APIError)
    assert e.code == "internal_error"


def test_from_envelope_missing_error_key() -> None:
    e = from_envelope({}, 500, None)
    assert isinstance(e, APIError)


def test_from_envelope_none_envelope() -> None:
    e = from_envelope(None, 500, None)
    assert isinstance(e, APIError)


def test_from_envelope_param_propagated() -> None:
    e = from_envelope(
        {"error": {"code": "invalid_request", "message": "bad", "param": "email"}},
        400,
        None,
    )
    assert e.param == "email"


def test_from_envelope_request_id_propagated() -> None:
    e = from_envelope(
        {"error": {"code": "not_found", "message": "x", "request_id": "req_x"}},
        404,
        None,
    )
    assert e.request_id == "req_x"


def test_from_envelope_message_fallback_when_missing() -> None:
    e = from_envelope({"error": {"code": "invalid_request"}}, 400, None)
    assert "400" in str(e) or "Request failed" in str(e)
