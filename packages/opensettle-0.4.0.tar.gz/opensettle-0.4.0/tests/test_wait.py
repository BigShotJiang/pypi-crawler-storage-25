"""wait_for / wait_for_async polling helpers."""

from __future__ import annotations

import pytest

from opensettle import WaitTimeoutError, wait_for, wait_for_async


def test_returns_immediately_when_already_in_target_state() -> None:
    def retrieve(rid: str) -> dict[str, str]:
        return {"id": rid, "status": "confirmed"}

    result = wait_for(
        retrieve,
        "pay_1",
        until=lambda r: r["status"] == "confirmed",
        sleep=lambda _s: pytest.fail("should not sleep"),
    )
    assert result == {"id": "pay_1", "status": "confirmed"}


def test_polls_until_target_state() -> None:
    states = iter(["pending", "pending", "confirmed"])
    sleeps: list[float] = []

    def retrieve(rid: str) -> dict[str, str]:
        return {"id": rid, "status": next(states)}

    result = wait_for(
        retrieve,
        "pay_1",
        until=lambda r: r["status"] == "confirmed",
        interval=2.0,
        sleep=sleeps.append,
    )
    assert result["status"] == "confirmed"
    assert sleeps == [2.0, 2.0]


def test_times_out_when_predicate_never_matches() -> None:
    """Use injected clock to make this deterministic + instant."""

    clock = iter([0.0, 0.5, 1.5, 2.5, 3.5])

    def retrieve(rid: str) -> dict[str, str]:
        return {"id": rid, "status": "pending"}

    with pytest.raises(WaitTimeoutError) as ei:
        wait_for(
            retrieve,
            "pay_x",
            until=lambda r: r["status"] == "confirmed",
            timeout=2.0,
            interval=1.0,
            sleep=lambda _s: None,
            now=lambda: next(clock),
        )
    assert ei.value.last == {"id": "pay_x", "status": "pending"}


def test_custom_until_predicate_can_inspect_any_field() -> None:
    def retrieve(rid: str) -> dict[str, int]:
        return {"id": rid, "confirmations": 12}

    out = wait_for(
        retrieve,
        "pay_1",
        until=lambda r: r["confirmations"] >= 6,
        sleep=lambda _s: None,
    )
    assert out["confirmations"] == 12


async def test_async_returns_immediately_when_in_target_state() -> None:
    async def retrieve(rid: str) -> dict[str, str]:
        return {"id": rid, "status": "active"}

    async def no_sleep(_s: float) -> None:
        pytest.fail("should not sleep")

    result = await wait_for_async(
        retrieve,
        "sub_1",
        until=lambda r: r["status"] == "active",
        sleep=no_sleep,
    )
    assert result["status"] == "active"


async def test_async_polls_until_target_state() -> None:
    states = iter(["pending", "succeeded"])
    sleeps: list[float] = []

    async def retrieve(rid: str) -> dict[str, str]:
        return {"id": rid, "status": next(states)}

    async def fake_sleep(s: float) -> None:
        sleeps.append(s)

    result = await wait_for_async(
        retrieve,
        "co_1",
        until=lambda r: r["status"] == "succeeded",
        interval=1.5,
        sleep=fake_sleep,
    )
    assert result["status"] == "succeeded"
    assert sleeps == [1.5]


async def test_async_times_out() -> None:
    clock = iter([0.0, 0.5, 1.5, 2.5])

    async def retrieve(rid: str) -> dict[str, str]:
        return {"id": rid, "status": "pending"}

    async def fake_sleep(_s: float) -> None:
        return None

    with pytest.raises(WaitTimeoutError):
        await wait_for_async(
            retrieve,
            "co_x",
            until=lambda r: r["status"] == "succeeded",
            timeout=2.0,
            interval=1.0,
            sleep=fake_sleep,
            now=lambda: next(clock),
        )
