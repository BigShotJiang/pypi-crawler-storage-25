"""Test helpers — webhook signing, error-envelope builders, response makers."""

from __future__ import annotations

import hmac
import json
from hashlib import sha256
from typing import Any, Optional


def sign_webhook(secret: str, body: str, t: int) -> str:
    """Build a valid ``x-opensettle-signature`` header value for ``body`` at ``t``."""

    v1 = hmac.new(secret.encode("utf-8"), f"{t}.{body}".encode(), sha256).hexdigest()
    return f"t={t},v1={v1}"


def envelope(
    code: str,
    message: str = "fail",
    *,
    param: Optional[str] = None,
    request_id: str = "req_test",
) -> dict[str, Any]:
    err: dict[str, Any] = {"code": code, "message": message, "request_id": request_id}
    if param is not None:
        err["param"] = param
    return {"error": err}


def envelope_json(
    code: str,
    message: str = "fail",
    *,
    param: Optional[str] = None,
    request_id: str = "req_test",
) -> str:
    return json.dumps(envelope(code, message, param=param, request_id=request_id))
