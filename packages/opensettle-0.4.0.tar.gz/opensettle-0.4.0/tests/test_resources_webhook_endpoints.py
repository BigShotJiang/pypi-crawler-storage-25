"""Webhook-endpoints resource."""

from __future__ import annotations

import json
from collections.abc import Iterator

import httpx
import pytest
import respx

from opensettle import OpenSettle
from opensettle._http import HttpClient


@pytest.fixture
def os_client(key: str, workspace_id: str, base_url: str, no_sleep) -> Iterator[OpenSettle]:
    http = HttpClient(api_key=key, workspace_id=workspace_id, base_url=base_url, _sleep=no_sleep)
    client = OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url, http=http)
    try:
        yield client
    finally:
        client.close()


@pytest.fixture
def root(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/webhook_endpoints"


def test_list_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(return_value=httpx.Response(200, json={"data": []}))
    os_client.webhook_endpoints.list()
    assert str(route.calls.last.request.url) == root


def test_retrieve_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(f"{root}/we_1").mock(
        return_value=httpx.Response(200, json={"id": "we_1"})
    )
    os_client.webhook_endpoints.retrieve("we_1")
    assert "/we_1" in str(route.calls.last.request.url)


def test_create_url_and_method(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(
        return_value=httpx.Response(200, json={"endpoint": {"id": "we_1"}, "secret": "whsec_x"})
    )
    os_client.webhook_endpoints.create(url="https://merchant.com/h", events=["payment.confirmed"])
    assert route.calls.last.request.method == "POST"


def test_create_body(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(root).mock(
        return_value=httpx.Response(200, json={"endpoint": {"id": "we_1"}, "secret": "whsec_x"})
    )
    os_client.webhook_endpoints.create(
        url="https://merchant.com/h",
        events=["payment.confirmed", "invoice.paid"],
        description="primary webhook",
    )
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {
        "url": "https://merchant.com/h",
        "events": ["payment.confirmed", "invoice.paid"],
        "description": "primary webhook",
    }


def test_create_omits_description_when_none(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(
        return_value=httpx.Response(200, json={"endpoint": {"id": "we_1"}, "secret": "whsec_x"})
    )
    os_client.webhook_endpoints.create(url="https://merchant.com/h", events=["payment.confirmed"])
    body = json.loads(route.calls.last.request.content.decode())
    assert "description" not in body


def test_create_has_idempotency_key(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(
        return_value=httpx.Response(200, json={"endpoint": {"id": "we_1"}, "secret": "whsec_x"})
    )
    os_client.webhook_endpoints.create(url="https://merchant.com/h", events=["payment.confirmed"])
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_update_url_and_method(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.patch(f"{root}/we_1").mock(
        return_value=httpx.Response(200, json={"id": "we_1"})
    )
    os_client.webhook_endpoints.update("we_1", url="https://merchant.com/h2")
    assert route.calls.last.request.method == "PATCH"


def test_update_url_only(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.patch(f"{root}/we_1").mock(
        return_value=httpx.Response(200, json={"id": "we_1"})
    )
    os_client.webhook_endpoints.update("we_1", url="https://merchant.com/h2")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"url": "https://merchant.com/h2"}


def test_update_events(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.patch(f"{root}/we_1").mock(
        return_value=httpx.Response(200, json={"id": "we_1"})
    )
    os_client.webhook_endpoints.update("we_1", events=["invoice.paid"])
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"events": ["invoice.paid"]}


def test_update_status(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.patch(f"{root}/we_1").mock(
        return_value=httpx.Response(200, json={"id": "we_1"})
    )
    os_client.webhook_endpoints.update("we_1", status="disabled")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"status": "disabled"}


def test_update_combines_fields(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.patch(f"{root}/we_1").mock(
        return_value=httpx.Response(200, json={"id": "we_1"})
    )
    os_client.webhook_endpoints.update(
        "we_1",
        url="https://merchant.com/h2",
        events=["payment.confirmed"],
        status="enabled",
    )
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {
        "url": "https://merchant.com/h2",
        "events": ["payment.confirmed"],
        "status": "enabled",
    }


def test_delete(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.delete(f"{root}/we_1").mock(return_value=httpx.Response(204))
    assert os_client.webhook_endpoints.delete("we_1") is None
    assert route.calls.last.request.method == "DELETE"


def test_rotate_secret_default_body_empty(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/we_1/rotate").mock(
        return_value=httpx.Response(
            200,
            json={
                "secret": "whsec_new",
                "rotationGraceUntil": "2026-05-13T00:00:00Z",
            },
        )
    )
    os_client.webhook_endpoints.rotate_secret("we_1")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {}


def test_rotate_secret_with_grace(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/we_1/rotate").mock(
        return_value=httpx.Response(
            200,
            json={
                "secret": "whsec_new",
                "rotationGraceUntil": "2026-05-13T00:00:00Z",
            },
        )
    )
    os_client.webhook_endpoints.rotate_secret("we_1", grace_seconds=3600)
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"graceSeconds": 3600}


def test_rotate_secret_idempotency(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/we_1/rotate").mock(
        return_value=httpx.Response(200, json={"secret": "x", "rotationGraceUntil": "x"})
    )
    os_client.webhook_endpoints.rotate_secret("we_1")
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_rotate_secret_returns_new_secret(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.post(f"{root}/we_1/rotate").mock(
        return_value=httpx.Response(
            200,
            json={
                "secret": "whsec_brand_new",
                "rotationGraceUntil": "2026-06-01T00:00:00Z",
            },
        )
    )
    r = os_client.webhook_endpoints.rotate_secret("we_1")
    assert r["secret"] == "whsec_brand_new"


def test_test_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/we_1/test").mock(
        return_value=httpx.Response(200, json={"ok": True, "status": 200, "latencyMs": 42})
    )
    os_client.webhook_endpoints.test("we_1", event_type="payment.confirmed")
    assert "/we_1/test" in str(route.calls.last.request.url)


def test_test_body(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/we_1/test").mock(
        return_value=httpx.Response(200, json={"ok": True, "status": 200, "latencyMs": 42})
    )
    os_client.webhook_endpoints.test("we_1", event_type="invoice.paid")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"eventType": "invoice.paid"}


def test_test_returns_result(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.post(f"{root}/we_1/test").mock(
        return_value=httpx.Response(200, json={"ok": True, "status": 200, "latencyMs": 42})
    )
    r = os_client.webhook_endpoints.test("we_1", event_type="payment.confirmed")
    assert r["ok"] is True
    assert r["latencyMs"] == 42


def test_create_returns_secret(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.post(root).mock(
        return_value=httpx.Response(
            200,
            json={
                "endpoint": {
                    "id": "we_1",
                    "url": "https://merchant.com/h",
                    "events": ["payment.confirmed"],
                    "status": "enabled",
                },
                "secret": "whsec_supersecret",
            },
        )
    )
    r = os_client.webhook_endpoints.create(
        url="https://merchant.com/h", events=["payment.confirmed"]
    )
    assert r["secret"] == "whsec_supersecret"
    assert r["endpoint"]["status"] == "enabled"


def test_retrieve_id_escaped(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(f"{root}/we%2Fweird").mock(
        return_value=httpx.Response(200, json={"id": "ok"})
    )
    os_client.webhook_endpoints.retrieve("we/weird")
    assert "we%2Fweird" in str(route.calls.last.request.url)


def test_update_empty_body_when_no_args(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.patch(f"{root}/we_1").mock(
        return_value=httpx.Response(200, json={"id": "we_1"})
    )
    os_client.webhook_endpoints.update("we_1")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {}
