"""HttpClient — request shape: headers, URL, query, body, idempotency."""

from __future__ import annotations

import json
import re
from typing import Any

import httpx
import pytest
import respx

from opensettle import SDK_VERSION
from opensettle._http import HttpClient


@pytest.fixture
def client(key: str, workspace_id: str, base_url: str, no_sleep) -> HttpClient:
    return HttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_sleep,
    )


def _ok(payload: Any = None) -> httpx.Response:
    return httpx.Response(200, json=payload if payload is not None else {"ok": True})


def test_authorization_header_is_bearer(
    client: HttpClient, respx_mock: respx.MockRouter, key: str, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers")
    req = route.calls.last.request
    assert req.headers["authorization"] == f"Bearer {key}"


def test_accept_header_is_json(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers")
    assert route.calls.last.request.headers["accept"] == "application/json"


def test_user_agent_includes_sdk_version(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers")
    ua = route.calls.last.request.headers["user-agent"]
    assert ua == f"opensettle-python/{SDK_VERSION}"
    assert re.match(r"^opensettle-python/\d+\.\d+\.\d+", ua)


def test_url_includes_workspace_prefix(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers")
    assert (
        str(route.calls.last.request.url)
        == f"https://api.example.com/v1/workspaces/{workspace_id}/customers"
    )


def test_url_tolerates_path_without_leading_slash(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("customers")
    assert "v1/workspaces" in str(route.calls.last.request.url)


def test_raw_url_skips_workspace_prefix(client: HttpClient, respx_mock: respx.MockRouter) -> None:
    route = respx_mock.get("https://api.example.com/v1/health").mock(return_value=_ok())
    client.request_raw("/v1/health")
    assert str(route.calls.last.request.url) == "https://api.example.com/v1/health"


def test_query_encodes_int(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    respx_mock.get(
        f"https://api.example.com/v1/workspaces/{workspace_id}/customers",
        params={"limit": "10"},
    ).mock(return_value=_ok())
    client.request("/customers", query={"limit": 10})


def test_query_encodes_str_with_spaces(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", query={"q": "hi there"})
    url = str(route.calls.last.request.url)
    assert ("q=hi+there" in url) or ("q=hi%20there" in url)


def test_query_skips_none_values(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", query={"limit": 10, "cursor": None, "status": None})
    url = str(route.calls.last.request.url)
    assert "cursor" not in url
    assert "status" not in url
    assert "limit=10" in url


def test_query_encodes_boolean_true(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/products").mock(
        return_value=_ok()
    )
    client.request("/products", query={"active": True})
    assert "active=true" in str(route.calls.last.request.url)


def test_query_encodes_boolean_false(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/products").mock(
        return_value=_ok()
    )
    client.request("/products", query={"active": False})
    assert "active=false" in str(route.calls.last.request.url)


def test_empty_query_dict_makes_no_query_string(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", query={})
    assert "?" not in str(route.calls.last.request.url)


def test_all_none_query_makes_no_query_string(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", query={"limit": None, "cursor": None})
    assert "?" not in str(route.calls.last.request.url)


def test_json_body_sets_content_type(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.post(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", method="POST", body={"email": "a@b.co"})
    req = route.calls.last.request
    assert req.headers["content-type"] == "application/json"
    assert json.loads(req.content.decode("utf-8")) == {"email": "a@b.co"}


def test_no_body_means_no_content_type(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers")
    assert "content-type" not in route.calls.last.request.headers


def test_idempotency_key_true_auto_generates(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.post(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", method="POST", body={}, idempotency_key=True)
    key = route.calls.last.request.headers.get("idempotency-key")
    assert key
    assert key.startswith("os_")
    assert len(key) > 10


def test_idempotency_key_string_passed_through(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.post(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", method="POST", body={}, idempotency_key="my-key-123")
    assert route.calls.last.request.headers["idempotency-key"] == "my-key-123"


def test_idempotency_key_in_headers_wins(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.post(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request(
        "/customers",
        method="POST",
        body={},
        idempotency_key=True,
        headers={"idempotency-key": "caller-supplied"},
    )
    assert route.calls.last.request.headers["idempotency-key"] == "caller-supplied"


def test_idempotency_key_false_disables_injection(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.post(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", method="POST", body={}, idempotency_key=None)
    assert "idempotency-key" not in route.calls.last.request.headers


def test_path_segment_with_slash_is_encoded(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    # The slash inside the ID must be %2F so we don't address a different
    # resource by accident. The resource layer is responsible for quoting;
    # this test uses request_raw to confirm raw-path passthrough.
    route = respx_mock.get(
        "https://api.example.com/v1/workspaces/ws_01HG/customers/cus%2Fweird"
    ).mock(return_value=_ok())
    client.request("/customers/cus%2Fweird")
    assert "customers/cus%2Fweird" in str(route.calls.last.request.url)


def test_returns_parsed_json_on_2xx(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers/cus_1").mock(
        return_value=httpx.Response(200, json={"id": "cus_1"})
    )
    r = client.request("/customers/cus_1")
    assert r == {"id": "cus_1"}


def test_returns_none_on_204(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    respx_mock.delete(f"https://api.example.com/v1/workspaces/{workspace_id}/customers/cus_1").mock(
        return_value=httpx.Response(204)
    )
    r = client.request("/customers/cus_1", method="DELETE")
    assert r is None


def test_returns_none_on_empty_2xx_body(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    respx_mock.post(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=httpx.Response(201, content=b"")
    )
    r = client.request("/customers", method="POST", body={})
    assert r is None


def test_custom_header_overrides_default(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", headers={"X-Trace-Id": "abc-123"})
    assert route.calls.last.request.headers["x-trace-id"] == "abc-123"


def test_headers_are_case_insensitive_in_caller_input(
    client: HttpClient, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/customers").mock(
        return_value=_ok()
    )
    client.request("/customers", headers={"Idempotency-Key": "ABC"})
    assert route.calls.last.request.headers["idempotency-key"] == "ABC"
