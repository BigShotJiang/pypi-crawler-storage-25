"""Subscriptions resource."""

from __future__ import annotations

import json
from collections.abc import Iterator

import httpx
import pytest
import respx

from opensettle import OpenSettle
from opensettle._http import HttpClient


@pytest.fixture
def os_client(key: str, workspace_id: str, base_url: str, no_sleep) -> Iterator[OpenSettle]:
    http = HttpClient(api_key=key, workspace_id=workspace_id, base_url=base_url, _sleep=no_sleep)
    client = OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url, http=http)
    try:
        yield client
    finally:
        client.close()


@pytest.fixture
def root(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/subscriptions"


def test_list(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    assert os_client.subscriptions.list()["data"] == []


def test_list_with_status(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.subscriptions.list(status="active")
    assert "status=active" in str(route.calls.last.request.url)


def test_list_with_customer(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.subscriptions.list(customerId="cus_1")
    assert "customerId=cus_1" in str(route.calls.last.request.url)


def test_retrieve(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    respx_mock.get(f"{root}/sub_1").mock(return_value=httpx.Response(200, json={"id": "sub_1"}))
    assert os_client.subscriptions.retrieve("sub_1") == {"id": "sub_1"}


def test_create(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "sub_1"}))
    os_client.subscriptions.create(customerId="cus_1", priceId="price_1", autopay="manual")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {
        "customerId": "cus_1",
        "priceId": "price_1",
        "autopay": "manual",
    }


def test_create_idempotency(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "sub_1"}))
    os_client.subscriptions.create(customerId="cus_1", priceId="price_1")
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_pause_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/sub_1/pause").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.pause("sub_1")
    assert "/sub_1/pause" in str(route.calls.last.request.url)


def test_pause_method_is_post(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/sub_1/pause").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.pause("sub_1")
    assert route.calls.last.request.method == "POST"


def test_pause_does_not_send_idempotency(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/sub_1/pause").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.pause("sub_1")
    assert "idempotency-key" not in route.calls.last.request.headers


def test_resume_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/sub_1/resume").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.resume("sub_1")
    assert "/sub_1/resume" in str(route.calls.last.request.url)


def test_cancel_default_body_empty(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/sub_1/cancel").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.cancel("sub_1")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {}


def test_cancel_with_mode(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/sub_1/cancel").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.cancel("sub_1", mode="immediately")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"mode": "immediately"}


def test_cancel_with_at_period_end(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/sub_1/cancel").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.cancel("sub_1", mode="at_period_end")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"mode": "at_period_end"}


def test_cancel_with_reason(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/sub_1/cancel").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.cancel("sub_1", reason="customer asked")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"reason": "customer asked"}


def test_cancel_with_mode_and_reason(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/sub_1/cancel").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.cancel("sub_1", mode="immediately", reason="bad fit")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"mode": "immediately", "reason": "bad fit"}


def test_change_plan_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/sub_1/change_plan").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.change_plan("sub_1", priceId="price_2")
    assert "/sub_1/change_plan" in str(route.calls.last.request.url)


def test_change_plan_default_body(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/sub_1/change_plan").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.change_plan("sub_1", priceId="price_2")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"priceId": "price_2"}


def test_change_plan_with_proration(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/sub_1/change_plan").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.change_plan("sub_1", priceId="price_2", prorationMode="immediately")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"priceId": "price_2", "prorationMode": "immediately"}


def test_change_plan_idempotency(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/sub_1/change_plan").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    os_client.subscriptions.change_plan("sub_1", priceId="price_2")
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_create_with_metadata(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "sub_1"}))
    os_client.subscriptions.create(
        customerId="cus_1",
        priceId="price_1",
        metadata={"plan": "pro"},
    )
    body = json.loads(route.calls.last.request.content.decode())
    assert body["metadata"] == {"plan": "pro"}


def test_retrieve_id_escaped(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(f"{root}/sub%2Fweird").mock(
        return_value=httpx.Response(200, json={"id": "ok"})
    )
    os_client.subscriptions.retrieve("sub/weird")
    assert "sub%2Fweird" in str(route.calls.last.request.url)


def test_pause_id_escaped(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/sub%2Fweird/pause").mock(
        return_value=httpx.Response(200, json={"id": "ok"})
    )
    os_client.subscriptions.pause("sub/weird")
    assert "sub%2Fweird/pause" in str(route.calls.last.request.url)


def test_create_with_autopay_modes(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    for mode in ("allowance", "smart-wallet", "manual"):
        route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "sub_1"}))
        os_client.subscriptions.create(customerId="cus_1", priceId="price_1", autopay=mode)
        body = json.loads(route.calls.last.request.content.decode())
        assert body["autopay"] == mode


def test_list_passing_all_filters(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.subscriptions.list(cursor="cur", limit=10, customerId="cus_1", status="active")
    url = str(route.calls.last.request.url)
    assert "cursor=cur" in url
    assert "limit=10" in url
    assert "customerId=cus_1" in url
    assert "status=active" in url
