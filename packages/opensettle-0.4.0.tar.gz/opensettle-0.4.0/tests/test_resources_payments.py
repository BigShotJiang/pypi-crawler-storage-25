"""Payments resource."""

from __future__ import annotations

import json
from collections.abc import Iterator

import httpx
import pytest
import respx

from opensettle import OpenSettle
from opensettle._http import HttpClient


@pytest.fixture
def os_client(key: str, workspace_id: str, base_url: str, no_sleep) -> Iterator[OpenSettle]:
    http = HttpClient(api_key=key, workspace_id=workspace_id, base_url=base_url, _sleep=no_sleep)
    client = OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url, http=http)
    try:
        yield client
    finally:
        client.close()


@pytest.fixture
def root(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/payments"


def test_list(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    assert os_client.payments.list()["data"] == []


def test_list_with_customer(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.payments.list(customerId="cus_1")
    assert "customerId=cus_1" in str(route.calls.last.request.url)


def test_list_with_status(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.payments.list(status="confirmed")
    assert "status=confirmed" in str(route.calls.last.request.url)


def test_list_with_reorged_status(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.payments.list(status="reorged")
    assert "status=reorged" in str(route.calls.last.request.url)


def test_retrieve(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    respx_mock.get(f"{root}/pay_1").mock(return_value=httpx.Response(200, json={"id": "pay_1"}))
    assert os_client.payments.retrieve("pay_1") == {"id": "pay_1"}


def test_refund_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund").mock(
        return_value=httpx.Response(200, json={"refund_id": "ref_1"})
    )
    os_client.payments.refund("pay_1", amount_minor=100)
    assert "pay_1/refund" in str(route.calls.last.request.url)


def test_refund_is_post(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund").mock(
        return_value=httpx.Response(200, json={"refund_id": "ref_1"})
    )
    os_client.payments.refund("pay_1")
    assert route.calls.last.request.method == "POST"


def test_refund_has_idempotency(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund").mock(
        return_value=httpx.Response(200, json={"refund_id": "ref_1"})
    )
    os_client.payments.refund("pay_1", amount_minor=100)
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_refund_passes_amount_and_reason(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund").mock(
        return_value=httpx.Response(200, json={"refund_id": "ref_1"})
    )
    os_client.payments.refund("pay_1", amount_minor=500, reason="duplicate")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"amount_minor": 500, "reason": "duplicate"}


def test_refund_with_no_args(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund").mock(
        return_value=httpx.Response(200, json={"refund_id": "ref_1"})
    )
    os_client.payments.refund("pay_1")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {}


def test_refund_broadcast_url(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund/broadcast").mock(
        return_value=httpx.Response(200, json={"id": "pay_1"})
    )
    os_client.payments.refund_broadcast("pay_1", refundTxHash="0xdeadbeef")
    assert "/refund/broadcast" in str(route.calls.last.request.url)


def test_refund_broadcast_body(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund/broadcast").mock(
        return_value=httpx.Response(200, json={"id": "pay_1"})
    )
    os_client.payments.refund_broadcast("pay_1", refundTxHash="0xdeadbeef")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"refundTxHash": "0xdeadbeef"}


def test_refund_broadcast_idempotency(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund/broadcast").mock(
        return_value=httpx.Response(200, json={"id": "pay_1"})
    )
    os_client.payments.refund_broadcast("pay_1", refundTxHash="0xabc")
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_retrieve_id_escaped(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(f"{root}/pay%2Fweird").mock(
        return_value=httpx.Response(200, json={"id": "ok"})
    )
    os_client.payments.retrieve("pay/weird")
    assert "pay%2Fweird" in str(route.calls.last.request.url)


def test_list_all_filters(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.payments.list(cursor="cur_1", limit=50, customerId="cus_1", status="confirmed")
    url = str(route.calls.last.request.url)
    assert "cursor=cur_1" in url
    assert "limit=50" in url
    assert "customerId=cus_1" in url
    assert "status=confirmed" in url


def test_refund_with_amount_zero_is_explicit(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/pay_1/refund").mock(
        return_value=httpx.Response(200, json={"refund_id": "ref_1"})
    )
    os_client.payments.refund("pay_1", amount_minor=0)
    body = json.loads(route.calls.last.request.content.decode())
    assert body["amount_minor"] == 0
