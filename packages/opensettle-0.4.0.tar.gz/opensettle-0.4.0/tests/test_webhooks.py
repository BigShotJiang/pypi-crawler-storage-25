"""Signed-webhook verifier."""

from __future__ import annotations

import hmac
import json
from hashlib import sha256

import pytest

from helpers import sign_webhook
from opensettle import VerifiedWebhook, WebhookVerificationError, verify_webhook

SECRET = "whsec_test_0123456789abcdef"
NOW = 1_777_000_000


def _body(payload: dict) -> str:
    return json.dumps(payload, separators=(",", ":"))


@pytest.fixture
def body() -> str:
    return _body({"id": "evt_1", "type": "payment.confirmed"})


def test_valid_signature(body: str) -> None:
    r = verify_webhook(
        raw_body=body,
        signature_header=sign_webhook(SECRET, body, NOW),
        secret=SECRET,
        now=NOW,
    )
    assert isinstance(r, VerifiedWebhook)
    assert r.timestamp == NOW
    assert r.data["id"] == "evt_1"
    assert r.data["type"] == "payment.confirmed"


def test_valid_signature_bytes_body(body: str) -> None:
    body_bytes = body.encode("utf-8")
    r = verify_webhook(
        raw_body=body_bytes,
        signature_header=sign_webhook(SECRET, body, NOW),
        secret=SECRET,
        now=NOW,
    )
    assert r.timestamp == NOW


def test_unknown_kv_in_header_tolerated(body: str) -> None:
    v1 = hmac.new(SECRET.encode(), f"{NOW}.{body}".encode(), sha256).hexdigest()
    r = verify_webhook(
        raw_body=body,
        signature_header=f"t={NOW},v1={v1},v2=futurevalue",
        secret=SECRET,
        now=NOW,
    )
    assert r.timestamp == NOW


def test_header_with_whitespace_around_segments(body: str) -> None:
    v1 = hmac.new(SECRET.encode(), f"{NOW}.{body}".encode(), sha256).hexdigest()
    r = verify_webhook(
        raw_body=body,
        signature_header=f"  t={NOW}  ,  v1={v1}  ",
        secret=SECRET,
        now=NOW,
    )
    assert r.timestamp == NOW


def test_missing_header(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(raw_body=body, signature_header=None, secret=SECRET)
    assert ei.value.reason == "missing_header"


def test_empty_string_header(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(raw_body=body, signature_header="", secret=SECRET)
    assert ei.value.reason == "missing_header"


def test_malformed_header_missing_v1(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(raw_body=body, signature_header=f"t={NOW}", secret=SECRET, now=NOW)
    assert ei.value.reason == "malformed_header"


def test_malformed_header_missing_t(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(raw_body=body, signature_header="v1=ff", secret=SECRET, now=NOW)
    assert ei.value.reason == "malformed_header"


def test_malformed_header_non_integer_t(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header="t=abc,v1=deadbeef",
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "malformed_header"


def test_malformed_header_non_hex_v1(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=f"t={NOW},v1=ZZZZ",
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "malformed_header"


def test_malformed_header_empty_v1(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=f"t={NOW},v1=",
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "malformed_header"


def test_malformed_header_garbage(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header="totally bad",
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "malformed_header"


def test_stale_timestamp_in_past(body: str) -> None:
    old = NOW - 600
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=sign_webhook(SECRET, body, old),
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "stale_timestamp"


def test_stale_timestamp_in_future(body: str) -> None:
    future = NOW + 600
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=sign_webhook(SECRET, body, future),
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "stale_timestamp"


def test_custom_tolerance_allows_older_signature(body: str) -> None:
    old = NOW - 600
    r = verify_webhook(
        raw_body=body,
        signature_header=sign_webhook(SECRET, body, old),
        secret=SECRET,
        now=NOW,
        tolerance=3600,
    )
    assert r.timestamp == old


def test_tolerance_zero_disables_check(body: str) -> None:
    ancient = NOW - 86400 * 365
    r = verify_webhook(
        raw_body=body,
        signature_header=sign_webhook(SECRET, body, ancient),
        secret=SECRET,
        now=NOW,
        tolerance=0,
    )
    assert r.timestamp == ancient


def test_tampered_body_fails(body: str) -> None:
    tampered = body + "X"
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=tampered,
            signature_header=sign_webhook(SECRET, body, NOW),
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "signature_mismatch"


def test_wrong_secret_fails(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=sign_webhook(SECRET, body, NOW),
            secret="whsec_other",
            now=NOW,
        )
    assert ei.value.reason == "signature_mismatch"


def test_invalid_json_body_after_sig_passes() -> None:
    garbage = "not json {"
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=garbage,
            signature_header=sign_webhook(SECRET, garbage, NOW),
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "invalid_body"


def test_unicode_body_roundtrips() -> None:
    body = json.dumps({"name": "Ada 한국 ⚡ 🦄"}, ensure_ascii=False, separators=(",", ":"))
    r = verify_webhook(
        raw_body=body,
        signature_header=sign_webhook(SECRET, body, NOW),
        secret=SECRET,
        now=NOW,
    )
    assert r.data["name"] == "Ada 한국 ⚡ 🦄"


def test_large_body_verifies() -> None:
    payload = {"items": [f"row-{i}" for i in range(10_000)]}
    body = json.dumps(payload, separators=(",", ":"))
    r = verify_webhook(
        raw_body=body,
        signature_header=sign_webhook(SECRET, body, NOW),
        secret=SECRET,
        now=NOW,
    )
    assert len(r.data["items"]) == 10_000


def test_uppercase_hex_v1_passes_header_parse_but_byte_compare_fails(body: str) -> None:
    """Header parser tolerates uppercase hex (forward-compat with v2 schemes),
    but the byte-for-byte constant-time compare is lowercase-only — which
    matches the Node SDK's behavior exactly. Uppercase digests produced by
    a non-conforming signer therefore surface as signature_mismatch, not
    malformed_header."""

    v1 = hmac.new(SECRET.encode(), f"{NOW}.{body}".encode(), sha256).hexdigest().upper()
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=f"t={NOW},v1={v1}",
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "signature_mismatch"


def test_short_v1_fails_constant_time(body: str) -> None:
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=f"t={NOW},v1=deadbeef",
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "signature_mismatch"


def test_long_v1_fails(body: str) -> None:
    v1 = hmac.new(SECRET.encode(), f"{NOW}.{body}".encode(), sha256).hexdigest() + "00"
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=f"t={NOW},v1={v1}",
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "signature_mismatch"


def test_default_tolerance_300_seconds(body: str) -> None:
    """At exactly default tolerance (300s) the signature still verifies."""
    old = NOW - 300
    r = verify_webhook(
        raw_body=body,
        signature_header=sign_webhook(SECRET, body, old),
        secret=SECRET,
        now=NOW,
    )
    assert r.timestamp == old


def test_default_tolerance_301_seconds_rejected(body: str) -> None:
    old = NOW - 301
    with pytest.raises(WebhookVerificationError):
        verify_webhook(
            raw_body=body,
            signature_header=sign_webhook(SECRET, body, old),
            secret=SECRET,
            now=NOW,
        )


def test_now_defaults_to_current_time_when_unset(body: str) -> None:
    import time

    current = int(time.time())
    r = verify_webhook(
        raw_body=body,
        signature_header=sign_webhook(SECRET, body, current),
        secret=SECRET,
    )
    assert r.timestamp == current


def test_verification_error_reason_is_typed(body: str) -> None:
    try:
        verify_webhook(raw_body=body, signature_header=None, secret=SECRET)
    except WebhookVerificationError as e:
        assert e.reason == "missing_header"
        assert isinstance(str(e), str)
    else:
        raise AssertionError("expected WebhookVerificationError")


def test_verified_webhook_is_frozen() -> None:
    r = VerifiedWebhook(data={"x": 1}, timestamp=NOW)
    with pytest.raises(Exception):  # FrozenInstanceError on dataclass(frozen=True)
        r.timestamp = 0  # type: ignore[misc]


def test_zero_byte_body_with_valid_signature_yields_invalid_body() -> None:
    body = ""
    with pytest.raises(WebhookVerificationError) as ei:
        verify_webhook(
            raw_body=body,
            signature_header=sign_webhook(SECRET, body, NOW),
            secret=SECRET,
            now=NOW,
        )
    assert ei.value.reason == "invalid_body"
