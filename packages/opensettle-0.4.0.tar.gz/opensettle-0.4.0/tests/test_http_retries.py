"""HttpClient — retry policy."""

from __future__ import annotations

import httpx
import pytest
import respx

from helpers import envelope
from opensettle import (
    APIError,
    InvalidRequestError,
    NetworkError,
)
from opensettle._http import HttpClient
from opensettle._transport import backoff_seconds, parse_retry_after


@pytest.fixture
def url(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/x"


def _client(key: str, workspace_id: str, base_url: str, no_sleep, budget: int) -> HttpClient:
    return HttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        max_network_retries=budget,
        _sleep=no_sleep,
    )


def test_retries_500_up_to_budget(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    route = respx_mock.get(url).mock(
        return_value=httpx.Response(500, json=envelope("internal_error"))
    )
    client = _client(key, workspace_id, base_url, no_sleep, budget=2)
    with pytest.raises(APIError):
        client.request("/x")
    # initial + 2 retries = 3 total calls
    assert route.call_count == 3


def test_does_not_retry_4xx_user_errors(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    route = respx_mock.get(url).mock(
        return_value=httpx.Response(400, json=envelope("invalid_request"))
    )
    client = _client(key, workspace_id, base_url, no_sleep, budget=5)
    with pytest.raises(InvalidRequestError):
        client.request("/x")
    assert route.call_count == 1


@pytest.mark.parametrize("status", [400, 401, 403, 404, 405, 410, 422])
def test_4xx_codes_not_retried(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
    status: int,
) -> None:
    route = respx_mock.get(url).mock(
        return_value=httpx.Response(status, json=envelope("invalid_request"))
    )
    client = _client(key, workspace_id, base_url, no_sleep, budget=5)
    with pytest.raises(Exception):  # any OpenSettleError subclass
        client.request("/x")
    assert route.call_count == 1


@pytest.mark.parametrize("status", [408, 425, 429, 500, 502, 503, 504])
def test_retriable_status_codes_are_retried(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
    status: int,
) -> None:
    responses = [
        httpx.Response(status, json=envelope("internal_error")),
        httpx.Response(200, json={"ok": True}),
    ]
    route = respx_mock.get(url).mock(side_effect=responses)
    client = _client(key, workspace_id, base_url, no_sleep, budget=3)
    r = client.request("/x")
    assert r == {"ok": True}
    assert route.call_count == 2


def test_retries_network_error_then_succeeds(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    responses = [
        httpx.ConnectError("dns fail"),
        httpx.Response(200, json={"ok": True}),
    ]
    route = respx_mock.get(url).mock(side_effect=responses)
    client = _client(key, workspace_id, base_url, no_sleep, budget=2)
    r = client.request("/x")
    assert r == {"ok": True}
    assert route.call_count == 2


def test_raises_networkerror_after_budget_exhausted(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    route = respx_mock.get(url).mock(side_effect=httpx.ConnectError("nope"))
    client = _client(key, workspace_id, base_url, no_sleep, budget=1)
    with pytest.raises(NetworkError):
        client.request("/x")
    # initial + 1 retry
    assert route.call_count == 2


def test_429_honors_numeric_retry_after(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    responses = [
        httpx.Response(
            429,
            json=envelope("rate_limited"),
            headers={"retry-after": "0"},
        ),
        httpx.Response(200, json={"ok": True}),
    ]
    route = respx_mock.get(url).mock(side_effect=responses)
    client = _client(key, workspace_id, base_url, no_sleep, budget=2)
    r = client.request("/x")
    assert r == {"ok": True}
    assert route.call_count == 2
    # The recorded sleep should have honored the retry-after of 0.
    assert no_sleep.calls[0] == 0.0


def test_429_sleep_uses_retry_after_seconds(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    responses = [
        httpx.Response(
            429,
            json=envelope("rate_limited"),
            headers={"retry-after": "7"},
        ),
        httpx.Response(200, json={"ok": True}),
    ]
    respx_mock.get(url).mock(side_effect=responses)
    client = _client(key, workspace_id, base_url, no_sleep, budget=2)
    client.request("/x")
    assert no_sleep.calls == [7.0]


def test_budget_zero_disables_retry(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    route = respx_mock.get(url).mock(
        return_value=httpx.Response(500, json=envelope("internal_error"))
    )
    client = _client(key, workspace_id, base_url, no_sleep, budget=0)
    with pytest.raises(APIError):
        client.request("/x")
    assert route.call_count == 1


def test_per_request_budget_override(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    route = respx_mock.get(url).mock(
        return_value=httpx.Response(500, json=envelope("internal_error"))
    )
    client = _client(key, workspace_id, base_url, no_sleep, budget=5)
    with pytest.raises(APIError):
        client.request("/x", max_network_retries=0)
    assert route.call_count == 1


def test_backoff_schedule_is_capped() -> None:
    # 0.25, 0.5, 1, 2, 4, 4, 4, 4 …
    assert backoff_seconds(0) == 0.25
    assert backoff_seconds(1) == 0.5
    assert backoff_seconds(2) == 1.0
    assert backoff_seconds(3) == 2.0
    assert backoff_seconds(4) == 4.0
    assert backoff_seconds(5) == 4.0
    assert backoff_seconds(10) == 4.0


def test_backoff_records_increasing_waits(
    respx_mock: respx.MockRouter,
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    url: str,
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(500, json=envelope("internal_error")))
    client = _client(key, workspace_id, base_url, no_sleep, budget=3)
    with pytest.raises(APIError):
        client.request("/x")
    # 3 retries => 3 sleeps; values follow capped exponential.
    assert no_sleep.calls == [0.25, 0.5, 1.0]


def test_parse_retry_after_numeric() -> None:
    assert parse_retry_after("12") == 12.0
    assert parse_retry_after("0") == 0.0


def test_parse_retry_after_negative_returns_none() -> None:
    assert parse_retry_after("-5") is None


def test_parse_retry_after_invalid_returns_none() -> None:
    assert parse_retry_after("not a date") is None


def test_parse_retry_after_none_input() -> None:
    assert parse_retry_after(None) is None


def test_parse_retry_after_empty_string() -> None:
    assert parse_retry_after("") is None


def test_parse_retry_after_whitespace_handled() -> None:
    assert parse_retry_after("  12  ") == 12.0
