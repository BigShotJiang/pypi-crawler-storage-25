"""Customers resource."""

from __future__ import annotations

import json
from collections.abc import Iterator

import httpx
import pytest
import respx

from opensettle import OpenSettle


@pytest.fixture
def os_client(key: str, workspace_id: str, base_url: str, no_sleep) -> Iterator[OpenSettle]:
    from opensettle._http import HttpClient

    http = HttpClient(api_key=key, workspace_id=workspace_id, base_url=base_url, _sleep=no_sleep)
    client = OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url, http=http)
    try:
        yield client
    finally:
        client.close()


@pytest.fixture
def root(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/customers"


def test_list_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.customers.list()
    assert str(route.calls.last.request.url) == root


def test_list_method_is_get(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.customers.list()
    assert route.calls.last.request.method == "GET"


def test_list_passes_cursor(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.customers.list(cursor="cur_abc")
    assert "cursor=cur_abc" in str(route.calls.last.request.url)


def test_list_passes_limit(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.customers.list(limit=25)
    assert "limit=25" in str(route.calls.last.request.url)


def test_list_drops_none_args(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.customers.list()
    assert "?" not in str(route.calls.last.request.url)


def test_retrieve(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    respx_mock.get(f"{root}/cus_1").mock(return_value=httpx.Response(200, json={"id": "cus_1"}))
    r = os_client.customers.retrieve("cus_1")
    assert r == {"id": "cus_1"}


def test_retrieve_escapes_id(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(f"{root}/cus%2Fweird").mock(
        return_value=httpx.Response(200, json={"id": "ok"})
    )
    os_client.customers.retrieve("cus/weird")
    assert "cus%2Fweird" in str(route.calls.last.request.url)


def test_create_is_post(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "cus_1"}))
    os_client.customers.create(email="ada@example.com")
    assert route.calls.last.request.method == "POST"


def test_create_sends_body(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "cus_1"}))
    os_client.customers.create(email="ada@example.com", name="Ada")
    body = json.loads(route.calls.last.request.content.decode("utf-8"))
    assert body == {"email": "ada@example.com", "name": "Ada"}


def test_create_includes_idempotency_key(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "cus_1"}))
    os_client.customers.create(email="ada@example.com")
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_create_two_calls_yield_distinct_idempotency_keys(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "cus_1"}))
    os_client.customers.create(email="a@b.co")
    os_client.customers.create(email="c@d.co")
    keys = [c.request.headers["idempotency-key"] for c in route.calls]
    assert keys[0] != keys[1]


def test_update_is_patch(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.patch(f"{root}/cus_1").mock(
        return_value=httpx.Response(200, json={"id": "cus_1"})
    )
    os_client.customers.update("cus_1", name="Updated")
    assert route.calls.last.request.method == "PATCH"


def test_update_sends_body(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.patch(f"{root}/cus_1").mock(
        return_value=httpx.Response(200, json={"id": "cus_1"})
    )
    os_client.customers.update("cus_1", name="Updated")
    assert json.loads(route.calls.last.request.content.decode()) == {"name": "Updated"}


def test_delete_is_delete(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.delete(f"{root}/cus_1").mock(return_value=httpx.Response(204))
    os_client.customers.delete("cus_1")
    assert route.calls.last.request.method == "DELETE"


def test_delete_returns_none(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.delete(f"{root}/cus_1").mock(return_value=httpx.Response(204))
    assert os_client.customers.delete("cus_1") is None


def test_list_with_both_pagination_args(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.customers.list(cursor="cur_1", limit=10)
    url = str(route.calls.last.request.url)
    assert "cursor=cur_1" in url
    assert "limit=10" in url
