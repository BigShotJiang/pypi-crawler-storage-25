"""Checkouts resource."""

from __future__ import annotations

import json
from collections.abc import Iterator

import httpx
import pytest
import respx

from opensettle import OpenSettle
from opensettle._http import HttpClient


@pytest.fixture
def os_client(key: str, workspace_id: str, base_url: str, no_sleep) -> Iterator[OpenSettle]:
    http = HttpClient(api_key=key, workspace_id=workspace_id, base_url=base_url, _sleep=no_sleep)
    client = OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url, http=http)
    try:
        yield client
    finally:
        client.close()


@pytest.fixture
def root(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/checkouts"


def test_create_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "ch_1"}))
    os_client.checkouts.create(
        mode="payment",
        customer_id="cus_1",
        amount_minor=19_900,
        currency="USD",
        chain="base",
        token="USDC",
        success_url="https://merchant.com/ok",
    )
    assert str(route.calls.last.request.url) == root


def test_create_method_is_post(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "ch_1"}))
    os_client.checkouts.create(
        mode="payment",
        customer_id="cus_1",
        chain="base",
        token="USDC",
        success_url="https://merchant.com/ok",
    )
    assert route.calls.last.request.method == "POST"


def test_create_has_idempotency_key(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "ch_1"}))
    os_client.checkouts.create(
        mode="payment",
        customer_id="cus_1",
        success_url="https://merchant.com/ok",
        chain="base",
        token="USDC",
    )
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_create_sends_body(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "ch_1"}))
    os_client.checkouts.create(
        mode="subscription",
        customer_id="cus_1",
        price_id="price_pro",
        success_url="https://merchant.com/ok",
        cancel_url="https://merchant.com/cancel",
        chain="base",
        token="USDC",
        description="Pro plan",
    )
    body = json.loads(route.calls.last.request.content.decode())
    assert body["mode"] == "subscription"
    assert body["price_id"] == "price_pro"
    assert body["cancel_url"] == "https://merchant.com/cancel"


def test_retrieve_url(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.get(f"{root}/ch_1").mock(
        return_value=httpx.Response(200, json={"id": "ch_1"})
    )
    os_client.checkouts.retrieve("ch_1")
    assert "/checkouts/ch_1" in str(route.calls.last.request.url)


def test_retrieve_returns_full_object(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.get(f"{root}/ch_1").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "ch_1",
                "mode": "payment",
                "status": "open",
                "amount_minor": 19_900,
                "currency": "USD",
                "chain": "base",
                "token": "USDC",
            },
        )
    )
    r = os_client.checkouts.retrieve("ch_1")
    assert r["status"] == "open"
    assert r["chain"] == "base"


def test_retrieve_id_escaped(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(f"{root}/ch%2Fweird").mock(
        return_value=httpx.Response(200, json={"id": "ok"})
    )
    os_client.checkouts.retrieve("ch/weird")
    assert "ch%2Fweird" in str(route.calls.last.request.url)


def test_create_returns_response_json(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.post(root).mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "ch_1",
                "url": "https://checkout.opensettle.io/c/ch_1",
                "status": "open",
                "expires_at": "2026-05-13T00:00:00Z",
            },
        )
    )
    r = os_client.checkouts.create(
        mode="payment",
        customer_id="cus_1",
        amount_minor=100,
        currency="USD",
        chain="base",
        token="USDC",
        success_url="https://merchant.com/ok",
    )
    assert r["url"].startswith("https://checkout.opensettle.io/")
