"""Version pinning — SDK_VERSION must match pyproject.toml exactly."""

from __future__ import annotations

import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover
    import tomli as tomllib  # type: ignore[no-redef]

from opensettle import SDK_VERSION


def _project_version() -> str:
    pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
    with pyproject.open("rb") as fh:
        data = tomllib.load(fh)
    return str(data["project"]["version"])


def test_sdk_version_matches_pyproject() -> None:
    assert _project_version() == SDK_VERSION


def test_sdk_version_is_semver_ish() -> None:
    parts = SDK_VERSION.split(".")
    assert len(parts) >= 3
    for p in parts[:3]:
        assert p.isdigit(), f"non-numeric component in version: {SDK_VERSION!r}"
