"""Async resource parity tests.

For each sync resource method, assert the async sibling produces the
exact same HTTP call shape. This guards against drift between the two
client surfaces.
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator

import httpx
import pytest
import respx

from opensettle import AsyncOpenSettle
from opensettle._http_async import AsyncHttpClient


@pytest.fixture
async def aclient(
    key: str, workspace_id: str, base_url: str, no_async_sleep
) -> AsyncIterator[AsyncOpenSettle]:
    http = AsyncHttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_async_sleep,
    )
    c = AsyncOpenSettle(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        http=http,
    )
    try:
        yield c
    finally:
        await c.aclose()


def _ws_root(workspace_id: str, resource: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/{resource}"


# ---- Customers ----------------------------------------------------------


async def test_async_customers_list(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "customers")
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    await aclient.customers.list(limit=10)
    assert "limit=10" in str(route.calls.last.request.url)


async def test_async_customers_retrieve(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "customers")
    respx_mock.get(f"{root}/cus_1").mock(return_value=httpx.Response(200, json={"id": "cus_1"}))
    assert (await aclient.customers.retrieve("cus_1")) == {"id": "cus_1"}


async def test_async_customers_create(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "customers")
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "cus_1"}))
    await aclient.customers.create(email="ada@example.com")
    assert route.calls.last.request.method == "POST"
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


async def test_async_customers_update(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "customers")
    route = respx_mock.patch(f"{root}/cus_1").mock(
        return_value=httpx.Response(200, json={"id": "cus_1"})
    )
    await aclient.customers.update("cus_1", name="A")
    assert route.calls.last.request.method == "PATCH"


async def test_async_customers_delete(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "customers")
    route = respx_mock.delete(f"{root}/cus_1").mock(return_value=httpx.Response(204))
    assert (await aclient.customers.delete("cus_1")) is None
    assert route.calls.last.request.method == "DELETE"


# ---- Products -----------------------------------------------------------


async def test_async_products_list(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "products")
    route = respx_mock.get(root).mock(return_value=httpx.Response(200, json={"data": []}))
    await aclient.products.list(active=True)
    assert "active=true" in str(route.calls.last.request.url)


async def test_async_products_create(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "products")
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "prod_1"}))
    await aclient.products.create(name="Pro")
    assert json.loads(route.calls.last.request.content.decode()) == {"name": "Pro"}


async def test_async_products_update(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "products")
    route = respx_mock.patch(f"{root}/prod_1").mock(
        return_value=httpx.Response(200, json={"id": "prod_1"})
    )
    await aclient.products.update("prod_1", name="v2")
    assert route.calls.last.request.method == "PATCH"


async def test_async_products_create_price(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "products")
    route = respx_mock.post(f"{root}/prod_1/prices").mock(
        return_value=httpx.Response(200, json={"id": "price_1"})
    )
    await aclient.products.create_price("prod_1", amount_minor=100)
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


async def test_async_products_list_prices(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "products")
    respx_mock.get(f"{root}/prod_1/prices").mock(
        return_value=httpx.Response(200, json={"data": [{"id": "p1"}]})
    )
    r = await aclient.products.list_prices("prod_1")
    assert r["data"] == [{"id": "p1"}]


async def test_async_products_delete_price(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    route = respx_mock.delete(
        f"https://api.example.com/v1/workspaces/{workspace_id}/prices/price_1"
    ).mock(return_value=httpx.Response(204))
    assert (await aclient.products.delete_price("price_1")) is None
    assert route.calls.last.request.method == "DELETE"


# ---- Invoices -----------------------------------------------------------


async def test_async_invoices_list(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "invoices")
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    await aclient.invoices.list(customerId="cus_1", status="open")
    url = str(route.calls.last.request.url)
    assert "customerId=cus_1" in url
    assert "status=open" in url


async def test_async_invoices_create(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "invoices")
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "in_1"}))
    await aclient.invoices.create(
        customerId="cus_1",
        amount_minor=100,
        currency="USD",
        chain="base",
        token="USDC",
    )
    assert route.calls.last.request.method == "POST"
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


async def test_async_invoices_send(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "invoices")
    route = respx_mock.post(f"{root}/in_1/send").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    await aclient.invoices.send("in_1")
    assert "/in_1/send" in str(route.calls.last.request.url)


async def test_async_invoices_remind(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "invoices")
    route = respx_mock.post(f"{root}/in_1/reminder").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    await aclient.invoices.remind("in_1")
    assert "/in_1/reminder" in str(route.calls.last.request.url)


async def test_async_invoices_void(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "invoices")
    route = respx_mock.post(f"{root}/in_1/void").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    await aclient.invoices.void("in_1")
    assert "/in_1/void" in str(route.calls.last.request.url)


# ---- Payments -----------------------------------------------------------


async def test_async_payments_list(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "payments")
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    await aclient.payments.list(status="confirmed")
    assert "status=confirmed" in str(route.calls.last.request.url)


async def test_async_payments_retrieve(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "payments")
    respx_mock.get(f"{root}/pay_1").mock(return_value=httpx.Response(200, json={"id": "pay_1"}))
    assert (await aclient.payments.retrieve("pay_1")) == {"id": "pay_1"}


async def test_async_payments_refund(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "payments")
    route = respx_mock.post(f"{root}/pay_1/refund").mock(
        return_value=httpx.Response(200, json={"refund_id": "ref_1"})
    )
    await aclient.payments.refund("pay_1", amount_minor=100)
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"amount_minor": 100}


async def test_async_payments_refund_broadcast(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "payments")
    route = respx_mock.post(f"{root}/pay_1/refund/broadcast").mock(
        return_value=httpx.Response(200, json={"id": "pay_1"})
    )
    await aclient.payments.refund_broadcast("pay_1", refundTxHash="0xabc")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"refundTxHash": "0xabc"}


# ---- Subscriptions ------------------------------------------------------


async def test_async_subscriptions_list(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "subscriptions")
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    await aclient.subscriptions.list(status="active")
    assert "status=active" in str(route.calls.last.request.url)


async def test_async_subscriptions_create(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "subscriptions")
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "sub_1"}))
    await aclient.subscriptions.create(customerId="cus_1", priceId="price_1")
    assert route.calls.last.request.method == "POST"


async def test_async_subscriptions_pause(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "subscriptions")
    route = respx_mock.post(f"{root}/sub_1/pause").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    await aclient.subscriptions.pause("sub_1")
    assert "/sub_1/pause" in str(route.calls.last.request.url)


async def test_async_subscriptions_resume(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "subscriptions")
    route = respx_mock.post(f"{root}/sub_1/resume").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    await aclient.subscriptions.resume("sub_1")
    assert "/sub_1/resume" in str(route.calls.last.request.url)


async def test_async_subscriptions_cancel(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "subscriptions")
    route = respx_mock.post(f"{root}/sub_1/cancel").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    await aclient.subscriptions.cancel("sub_1", mode="at_period_end")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"mode": "at_period_end"}


async def test_async_subscriptions_change_plan(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "subscriptions")
    route = respx_mock.post(f"{root}/sub_1/change_plan").mock(
        return_value=httpx.Response(200, json={"id": "sub_1"})
    )
    await aclient.subscriptions.change_plan("sub_1", priceId="price_2")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"priceId": "price_2"}


# ---- Checkouts ----------------------------------------------------------


async def test_async_checkouts_create(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "checkouts")
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "ch_1"}))
    await aclient.checkouts.create(
        mode="payment",
        customerId="cus_1",
        amount_minor=100,
        currency="USD",
        chain="base",
        token="USDC",
        success_url="https://merchant.com/ok",
    )
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


async def test_async_checkouts_retrieve(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "checkouts")
    respx_mock.get(f"{root}/ch_1").mock(return_value=httpx.Response(200, json={"id": "ch_1"}))
    assert (await aclient.checkouts.retrieve("ch_1")) == {"id": "ch_1"}


# ---- Webhook endpoints --------------------------------------------------


async def test_async_webhook_endpoints_list(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "webhook_endpoints")
    respx_mock.get(root).mock(return_value=httpx.Response(200, json={"data": []}))
    r = await aclient.webhook_endpoints.list()
    assert r == {"data": []}


async def test_async_webhook_endpoints_create(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "webhook_endpoints")
    route = respx_mock.post(root).mock(
        return_value=httpx.Response(200, json={"endpoint": {"id": "we_1"}, "secret": "x"})
    )
    await aclient.webhook_endpoints.create(
        url="https://x.example.com/h", events=["payment.confirmed"]
    )
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


async def test_async_webhook_endpoints_update(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "webhook_endpoints")
    route = respx_mock.patch(f"{root}/we_1").mock(
        return_value=httpx.Response(200, json={"id": "we_1"})
    )
    await aclient.webhook_endpoints.update("we_1", url="https://x2.example.com/h")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"url": "https://x2.example.com/h"}


async def test_async_webhook_endpoints_rotate(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "webhook_endpoints")
    route = respx_mock.post(f"{root}/we_1/rotate").mock(
        return_value=httpx.Response(200, json={"secret": "whsec_new", "rotationGraceUntil": "x"})
    )
    await aclient.webhook_endpoints.rotate_secret("we_1", grace_seconds=60)
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"graceSeconds": 60}


async def test_async_webhook_endpoints_test(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "webhook_endpoints")
    route = respx_mock.post(f"{root}/we_1/test").mock(
        return_value=httpx.Response(200, json={"ok": True, "status": 200, "latencyMs": 10})
    )
    await aclient.webhook_endpoints.test("we_1", event_type="payment.confirmed")
    body = json.loads(route.calls.last.request.content.decode())
    assert body == {"eventType": "payment.confirmed"}


async def test_async_webhook_endpoints_delete(
    aclient: AsyncOpenSettle, respx_mock: respx.MockRouter, workspace_id: str
) -> None:
    root = _ws_root(workspace_id, "webhook_endpoints")
    respx_mock.delete(f"{root}/we_1").mock(return_value=httpx.Response(204))
    assert (await aclient.webhook_endpoints.delete("we_1")) is None
