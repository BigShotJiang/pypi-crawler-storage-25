"""HttpClient — error envelope mapping for every code in the taxonomy."""

from __future__ import annotations

import httpx
import pytest
import respx

from helpers import envelope
from opensettle import (
    APIError,
    AuthenticationError,
    ConflictError,
    ForbiddenError,
    InvalidRequestError,
    InvalidStateTransitionError,
    NetworkError,
    NotFoundError,
    OpenSettleError,
    RateLimitError,
    SettlementError,
    StepUpRequiredError,
)
from opensettle._http import HttpClient


@pytest.fixture
def client(key: str, workspace_id: str, base_url: str, no_sleep) -> HttpClient:
    return HttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        max_network_retries=0,
        _sleep=no_sleep,
    )


@pytest.fixture
def url(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/x"


@pytest.mark.parametrize(
    "status,code,expected_cls",
    [
        (400, "invalid_request", InvalidRequestError),
        (409, "invalid_state_transition", InvalidStateTransitionError),
        (401, "unauthorized", AuthenticationError),
        (403, "forbidden", ForbiddenError),
        (404, "not_found", NotFoundError),
        (409, "conflict", ConflictError),
        (429, "rate_limited", RateLimitError),
        (422, "chain_reverted", SettlementError),
        (422, "insufficient_confirmations", SettlementError),
        (422, "signing_required", SettlementError),
        (401, "aal_required", StepUpRequiredError),
        (500, "internal_error", APIError),
    ],
)
def test_error_code_maps_to_class(
    client: HttpClient,
    respx_mock: respx.MockRouter,
    url: str,
    status: int,
    code: str,
    expected_cls: type,
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(status, json=envelope(code)))
    with pytest.raises(expected_cls) as ei:
        client.request("/x")
    assert isinstance(ei.value, OpenSettleError)


def test_unknown_code_falls_back_to_apierror(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(500, json=envelope("future_unknown_code")))
    with pytest.raises(APIError) as ei:
        client.request("/x")
    # Forward-compat: unknown code surfaces as the catch-all and gets the
    # ``internal_error`` code label, not the raw server-side value.
    assert ei.value.code == "internal_error"


def test_error_preserves_request_id(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(
        return_value=httpx.Response(
            400, json=envelope("invalid_request", "bad", param="email", request_id="req_xyz")
        )
    )
    with pytest.raises(InvalidRequestError) as ei:
        client.request("/x")
    assert ei.value.request_id == "req_xyz"


def test_error_preserves_param(client: HttpClient, respx_mock: respx.MockRouter, url: str) -> None:
    respx_mock.get(url).mock(
        return_value=httpx.Response(
            400, json=envelope("invalid_request", "bad email", param="email")
        )
    )
    with pytest.raises(InvalidRequestError) as ei:
        client.request("/x")
    assert ei.value.param == "email"


def test_error_preserves_status(client: HttpClient, respx_mock: respx.MockRouter, url: str) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(422, json=envelope("chain_reverted")))
    with pytest.raises(SettlementError) as ei:
        client.request("/x")
    assert ei.value.status == 422


def test_rate_limit_error_carries_numeric_retry_after(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(
        return_value=httpx.Response(
            429,
            json=envelope("rate_limited"),
            headers={"retry-after": "12"},
        )
    )
    with pytest.raises(RateLimitError) as ei:
        client.request("/x")
    assert ei.value.retry_after == 12.0


def test_rate_limit_without_retry_after_header(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(429, json=envelope("rate_limited")))
    with pytest.raises(RateLimitError) as ei:
        client.request("/x")
    assert ei.value.retry_after is None


def test_malformed_envelope_falls_back_to_apierror(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(500, text="totally not json {{"))
    with pytest.raises(APIError):
        client.request("/x")


def test_empty_error_body(client: HttpClient, respx_mock: respx.MockRouter, url: str) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(500, text=""))
    with pytest.raises(APIError) as ei:
        client.request("/x")
    assert "500" in str(ei.value) or "Request failed" in str(ei.value)


def test_partial_envelope_missing_message(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(
        return_value=httpx.Response(400, json={"error": {"code": "invalid_request"}})
    )
    with pytest.raises(InvalidRequestError) as ei:
        client.request("/x")
    # Fallback message used.
    assert str(ei.value)


def test_envelope_with_no_error_key(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(500, json={"unrelated": 1}))
    with pytest.raises(APIError):
        client.request("/x")


def test_2xx_with_invalid_json_raises_apierror(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(200, text="garbage"))
    with pytest.raises(APIError) as ei:
        client.request("/x")
    assert "non-JSON body" in str(ei.value)


def test_oprensettle_error_is_base_class_for_every_typed_error(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(return_value=httpx.Response(400, json=envelope("invalid_request")))
    with pytest.raises(OpenSettleError):
        client.request("/x")


def test_request_id_passes_through_when_absent(
    client: HttpClient, respx_mock: respx.MockRouter, url: str
) -> None:
    respx_mock.get(url).mock(
        return_value=httpx.Response(
            400,
            json={"error": {"code": "invalid_request", "message": "x"}},
        )
    )
    with pytest.raises(InvalidRequestError) as ei:
        client.request("/x")
    assert ei.value.request_id is None


def test_network_error_class_has_zero_status() -> None:
    err = NetworkError("boom")
    assert err.status == 0
    assert err.code == "network_error"
