"""High-level OpenSettle client wiring."""

from __future__ import annotations

import httpx
import pytest
import respx

from opensettle import (
    AsyncOpenSettle,
    OpenSettle,
)
from opensettle._http import HttpClient
from opensettle.resources.checkouts import CheckoutsResource
from opensettle.resources.customers import CustomersResource
from opensettle.resources.invoices import InvoicesResource
from opensettle.resources.payments import PaymentsResource
from opensettle.resources.products import ProductsResource
from opensettle.resources.subscriptions import SubscriptionsResource
from opensettle.resources.webhook_endpoints import WebhookEndpointsResource


def _client(key: str, workspace_id: str, base_url: str, no_sleep) -> OpenSettle:
    http = HttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_sleep,
    )
    return OpenSettle(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        http=http,
    )


def test_resources_lazy_instantiated(key: str, workspace_id: str, base_url: str, no_sleep) -> None:
    os = _client(key, workspace_id, base_url, no_sleep)
    assert os._customers is None  # not yet touched
    _ = os.customers
    assert os._customers is not None
    # And the property is memoised — same object returned twice.
    assert os.customers is os._customers


@pytest.mark.parametrize(
    "attr,expected_cls",
    [
        ("customers", CustomersResource),
        ("products", ProductsResource),
        ("invoices", InvoicesResource),
        ("payments", PaymentsResource),
        ("subscriptions", SubscriptionsResource),
        ("checkouts", CheckoutsResource),
        ("webhook_endpoints", WebhookEndpointsResource),
    ],
)
def test_resource_types(
    key: str,
    workspace_id: str,
    base_url: str,
    no_sleep,
    attr: str,
    expected_cls: type,
) -> None:
    os = _client(key, workspace_id, base_url, no_sleep)
    resource = getattr(os, attr)
    assert isinstance(resource, expected_cls)


def test_context_manager_closes_http(key: str, workspace_id: str, base_url: str, no_sleep) -> None:
    # The OpenSettle context manager should close the underlying http client.
    # We can't easily inspect httpx internal state; just verify the call
    # site doesn't error.
    with OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url) as os:
        assert os.http.base_url == base_url


def test_customer_retrieve_url(
    key: str, workspace_id: str, base_url: str, no_sleep, respx_mock: respx.MockRouter
) -> None:
    route = respx_mock.get(
        f"https://api.example.com/v1/workspaces/{workspace_id}/customers/cus_1"
    ).mock(return_value=httpx.Response(200, json={"id": "cus_1"}))
    os = _client(key, workspace_id, base_url, no_sleep)
    r = os.customers.retrieve("cus_1")
    assert r == {"id": "cus_1"}
    assert "customers/cus_1" in str(route.calls.last.request.url)


def test_customer_id_with_reserved_chars_is_escaped(
    key: str, workspace_id: str, base_url: str, no_sleep, respx_mock: respx.MockRouter
) -> None:
    route = respx_mock.get(
        f"https://api.example.com/v1/workspaces/{workspace_id}/customers/cus%2Fweird%20id"
    ).mock(return_value=httpx.Response(200, json={"id": "ok"}))
    os = _client(key, workspace_id, base_url, no_sleep)
    os.customers.retrieve("cus/weird id")
    assert "cus%2Fweird%20id" in str(route.calls.last.request.url)


def test_payment_refund_has_idempotency_key(
    key: str, workspace_id: str, base_url: str, no_sleep, respx_mock: respx.MockRouter
) -> None:
    route = respx_mock.post(
        f"https://api.example.com/v1/workspaces/{workspace_id}/payments/pay_1/refund"
    ).mock(return_value=httpx.Response(200, json={"refund_id": "ref_1"}))
    os = _client(key, workspace_id, base_url, no_sleep)
    os.payments.refund("pay_1", amount_minor=100)
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_subscription_cancel_sends_mode(
    key: str, workspace_id: str, base_url: str, no_sleep, respx_mock: respx.MockRouter
) -> None:
    route = respx_mock.post(
        f"https://api.example.com/v1/workspaces/{workspace_id}/subscriptions/sub_1/cancel"
    ).mock(return_value=httpx.Response(200, json={"id": "sub_1"}))
    os = _client(key, workspace_id, base_url, no_sleep)
    os.subscriptions.cancel("sub_1", mode="at_period_end")
    import json as J

    body = J.loads(route.calls.last.request.content.decode("utf-8"))
    assert body == {"mode": "at_period_end"}


def test_invoice_list_passes_query(
    key: str, workspace_id: str, base_url: str, no_sleep, respx_mock: respx.MockRouter
) -> None:
    route = respx_mock.get(f"https://api.example.com/v1/workspaces/{workspace_id}/invoices").mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os = _client(key, workspace_id, base_url, no_sleep)
    os.invoices.list(customerId="cus_1", status="open", limit=5)
    url = httpx.URL(str(route.calls.last.request.url))
    assert url.params["limit"] == "5"
    assert url.params["customerId"] == "cus_1"
    assert url.params["status"] == "open"


def test_webhook_endpoint_create_returns_secret(
    key: str, workspace_id: str, base_url: str, no_sleep, respx_mock: respx.MockRouter
) -> None:
    respx_mock.post(f"https://api.example.com/v1/workspaces/{workspace_id}/webhook_endpoints").mock(
        return_value=httpx.Response(
            200,
            json={
                "endpoint": {"id": "we_1", "url": "https://x.example.com/h"},
                "secret": "whsec_xxx",
            },
        )
    )
    os = _client(key, workspace_id, base_url, no_sleep)
    r = os.webhook_endpoints.create(url="https://x.example.com/h", events=["payment.confirmed"])
    assert r["endpoint"]["id"] == "we_1"
    assert r["secret"] == "whsec_xxx"


def test_close_is_idempotent(key: str, workspace_id: str, base_url: str) -> None:
    os = OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url)
    os.close()
    # Closing a second time on a sync httpx.Client is a no-op.
    os.close()


def test_external_http_not_closed_by_client(
    key: str, workspace_id: str, base_url: str, no_sleep
) -> None:
    http = HttpClient(
        api_key=key,
        workspace_id=workspace_id,
        base_url=base_url,
        _sleep=no_sleep,
    )
    os = OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url, http=http)
    os.close()
    # Externally-owned HTTP client should NOT be closed by the wrapper.
    # If it had been, the underlying httpx.Client would be closed and
    # subsequent calls would raise; instead we can still use it.
    assert http._owns_client is True  # owns its own client
    http.close()  # explicit user close, no error


def test_resources_share_http_client(key: str, workspace_id: str, base_url: str, no_sleep) -> None:
    os = _client(key, workspace_id, base_url, no_sleep)
    # All resources receive the same underlying transport.
    assert os.customers._http is os.http
    assert os.products._http is os.http
    assert os.invoices._http is os.http
    assert os.payments._http is os.http
    assert os.subscriptions._http is os.http
    assert os.checkouts._http is os.http
    assert os.webhook_endpoints._http is os.http


def test_async_client_resources_lazy(key: str, workspace_id: str, base_url: str) -> None:
    os = AsyncOpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url)
    assert os._customers is None
    _ = os.customers
    assert os._customers is not None
