"""Invoices resource."""

from __future__ import annotations

import json
from collections.abc import Iterator

import httpx
import pytest
import respx

from opensettle import OpenSettle
from opensettle._http import HttpClient


@pytest.fixture
def os_client(key: str, workspace_id: str, base_url: str, no_sleep) -> Iterator[OpenSettle]:
    http = HttpClient(api_key=key, workspace_id=workspace_id, base_url=base_url, _sleep=no_sleep)
    client = OpenSettle(api_key=key, workspace_id=workspace_id, base_url=base_url, http=http)
    try:
        yield client
    finally:
        client.close()


@pytest.fixture
def root(workspace_id: str) -> str:
    return f"https://api.example.com/v1/workspaces/{workspace_id}/invoices"


def test_list(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    r = os_client.invoices.list()
    assert r["data"] == []


def test_list_with_customer_filter(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.invoices.list(customerId="cus_1")
    assert "customerId=cus_1" in str(route.calls.last.request.url)


def test_list_with_status_filter(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.invoices.list(status="open")
    assert "status=open" in str(route.calls.last.request.url)


def test_list_with_all_filters(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.invoices.list(cursor="cur_x", limit=20, customerId="cus_2", status="paid")
    url = str(route.calls.last.request.url)
    assert "cursor=cur_x" in url
    assert "limit=20" in url
    assert "customerId=cus_2" in url
    assert "status=paid" in url


def test_retrieve(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    respx_mock.get(f"{root}/in_1").mock(return_value=httpx.Response(200, json={"id": "in_1"}))
    assert os_client.invoices.retrieve("in_1") == {"id": "in_1"}


def test_create_is_post_with_idempotency(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "in_1"}))
    os_client.invoices.create(
        customerId="cus_1",
        amount_minor=19_900,
        currency="USD",
        chain="base",
        token="USDC",
    )
    assert route.calls.last.request.method == "POST"
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_create_sends_line_items(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "in_1"}))
    os_client.invoices.create(
        customerId="cus_1",
        amount_minor=19_900,
        currency="USD",
        chain="base",
        token="USDC",
        line_items=[{"description": "Pro plan", "quantity": 1, "unit_amount_minor": 19_900}],
    )
    body = json.loads(route.calls.last.request.content.decode())
    assert body["line_items"][0]["description"] == "Pro plan"


def test_send(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/in_1/send").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    os_client.invoices.send("in_1")
    assert route.calls.last.request.method == "POST"


def test_send_idempotency_key(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(f"{root}/in_1/send").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    os_client.invoices.send("in_1")
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_send_has_no_body(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/in_1/send").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    os_client.invoices.send("in_1")
    assert route.calls.last.request.content in (b"", None)


def test_remind(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/in_1/reminder").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    os_client.invoices.remind("in_1")
    assert route.calls.last.request.method == "POST"


def test_remind_idempotency(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/in_1/reminder").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    os_client.invoices.remind("in_1")
    assert route.calls.last.request.headers["idempotency-key"].startswith("os_")


def test_void(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/in_1/void").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    os_client.invoices.void("in_1")
    assert route.calls.last.request.method == "POST"


def test_void_does_not_send_idempotency(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    # void is destructive but a single-action endpoint; the Node SDK does
    # NOT auto-inject an idempotency key for void.
    route = respx_mock.post(f"{root}/in_1/void").mock(
        return_value=httpx.Response(200, json={"id": "in_1"})
    )
    os_client.invoices.void("in_1")
    assert "idempotency-key" not in route.calls.last.request.headers


def test_send_id_escaped(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(f"{root}/in%2Fweird/send").mock(
        return_value=httpx.Response(200, json={"id": "ok"})
    )
    os_client.invoices.send("in/weird")
    assert "in%2Fweird/send" in str(route.calls.last.request.url)


def test_retrieve_returns_full_invoice(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.get(f"{root}/in_1").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "in_1",
                "amount_minor": 19_900,
                "currency": "USD",
                "status": "open",
                "line_items": [{"description": "x", "quantity": 1, "unit_amount_minor": 19_900}],
            },
        )
    )
    r = os_client.invoices.retrieve("in_1")
    assert r["status"] == "open"
    assert len(r["line_items"]) == 1


def test_create_with_metadata(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "in_1"}))
    os_client.invoices.create(
        customerId="cus_1",
        amount_minor=100,
        currency="USD",
        chain="base",
        token="USDC",
        metadata={"po": "PO-42"},
    )
    body = json.loads(route.calls.last.request.content.decode())
    assert body["metadata"] == {"po": "PO-42"}


def test_create_with_due_at(os_client: OpenSettle, respx_mock: respx.MockRouter, root: str) -> None:
    route = respx_mock.post(root).mock(return_value=httpx.Response(200, json={"id": "in_1"}))
    os_client.invoices.create(
        customerId="cus_1",
        amount_minor=100,
        currency="USD",
        chain="base",
        token="USDC",
        due_at="2026-06-01T00:00:00Z",
    )
    body = json.loads(route.calls.last.request.content.decode())
    assert body["due_at"] == "2026-06-01T00:00:00Z"


def test_list_drops_none_filters(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    route = respx_mock.get(root).mock(
        return_value=httpx.Response(200, json={"data": [], "next_cursor": None})
    )
    os_client.invoices.list(customerId=None, status=None)
    assert "?" not in str(route.calls.last.request.url)


def test_send_returns_invoice(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.post(f"{root}/in_1/send").mock(
        return_value=httpx.Response(200, json={"id": "in_1", "status": "open"})
    )
    r = os_client.invoices.send("in_1")
    assert r == {"id": "in_1", "status": "open"}


def test_remind_returns_invoice(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.post(f"{root}/in_1/reminder").mock(
        return_value=httpx.Response(200, json={"id": "in_1", "status": "overdue"})
    )
    r = os_client.invoices.remind("in_1")
    assert r["status"] == "overdue"


def test_void_returns_invoice(
    os_client: OpenSettle, respx_mock: respx.MockRouter, root: str
) -> None:
    respx_mock.post(f"{root}/in_1/void").mock(
        return_value=httpx.Response(200, json={"id": "in_1", "status": "void"})
    )
    r = os_client.invoices.void("in_1")
    assert r["status"] == "void"
