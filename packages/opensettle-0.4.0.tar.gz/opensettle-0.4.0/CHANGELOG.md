# Changelog

## 0.4.0 — 2026-05-15

### Fixed

- **`Checkout` TypedDict now matches the API response shape.** The shape
  was drifted in several places:
  - Added `amountMinor`, `currency`, `description`, `hostedUrl` (server
    returns all of them; previously silently dropped from the overlay).
  - Removed `customerEmail` (the API never returns this on the response;
    it's only on `CreateCheckoutRequest`).
  - `customerId`, `chain`, `token` were typed as `Optional[...]` despite
    being required in the response.

### Breaking

- Code that reads `checkout["customerEmail"]` from a Checkout response
  will raise `KeyError` (the field was never set by the server, but the
  overlay's `total=False` masked the breakage). The email is available on
  the customer record: `os.customers.retrieve(checkout["customerId"])`.

## 0.3.0 — 2026-05-12

### Added

- **Pagination iterator** — `paginate(os.customers.list, ...)` yields
  every item across all pages, auto-following `nextCursor`. Sync via
  `paginate(...)`, async via `aiterate(...)`.
- **Polling helper** — `wait_for(os.payments.retrieve, "pay_…",
  until=lambda p: p["status"] == "confirmed", timeout=120,
  interval=2)`. Async: `wait_for_async(...)`. Raises
  `WaitTimeoutError` (importable from top level) on timeout, carrying
  the last-observed resource.

## 0.2.0 — 2026-05-12

**Breaking** — body fields and response keys are now camelCase, matching
the API's wire format. Resource method signatures and TypedDict
overlays have been corrected against the authoritative zod schemas in
`packages/shared/src/schemas/*`.

If you used 0.1.0, fix-up checklist:

- `customer_id=` kwargs → `customerId=`
- `amount_minor=` → `amountMinor` (or `amount` for prices — there is no
  `amount_minor` field; prices use `amount` in minor units)
- `success_url=` → `successUrl=`
- `tx_hash=` (refund-broadcast) → `refundTxHash=`
- Response keys: `result.get("created_at")` → `result.get("createdAt")`,
  same for every other field
- Webhook create/rotate returns `signingSecret`, not `secret`

### Fixed

- Response envelope unwrapping. The API returns
  `{"customer": {...}}` for singleton responses; the SDK now strips
  that wrapper transparently so `os.customers.create(...)["id"]` works.
  Multi-key envelopes (`refund` returns `{payment, unsignedTx}`,
  webhook create returns `{endpoint, signingSecret}`) are preserved.
- `Price` schema: removed hallucinated fields (`nickname`, `chain`,
  `token`, `intervalCount`, `amountMinor`). Real fields are `amount`,
  `currency`, `interval`, `metadata`.
- `Subscription` schema: `autopay` enum is
  `allowance | smart-wallet | manual` (was incorrectly
  `off | wallet_signature | merchant_pull`).
- `Invoice` create: `dueInDays` (not `dueAt`); `amountMinor` is
  server-computed from `lineItems`.
- `Customer` schema: added `wallet`, `country`, `activeSubscriptions`,
  `lifetimeValue`, `deletedAt`.
- `Checkout` schema: dropped `description` field that doesn't exist.
- All response-shape TypedDicts switched from snake_case to camelCase.

### Added

- `update_price()` on the products resource.
- `recipientAddress` field on refund request (per
  `InitiateRefundRequest`).
- `subscriptionId` filter on `payments.list()`.
- `q`, `status` filters on `customers.list()`.

## 0.1.0 — 2026-05-12

Initial release. **Do not use — significant schema drift from the
real API.** Upgrade to 0.2.0.
