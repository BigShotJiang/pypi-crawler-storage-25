"""Invoices resource.

Body kwargs and response keys are camelCase. Body shape per
``packages/shared/src/schemas/invoice.ts``: ``customerId``, ``chain``,
``token``, ``currency``, ``lineItems`` (with ``unitAmountMinor``),
``memo``, ``dueInDays`` (NOT ``dueAt`` — the server computes ``dueAt``
from this), ``subscriptionId``, ``metadata``. The server computes
``amountMinor`` from ``lineItems``.
"""

from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

from .._http import HttpClient
from .._http_async import AsyncHttpClient
from .._transport import unwrap


def _esc(s: str) -> str:
    return quote(s, safe="")


class InvoicesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        customerId: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Any:
        return self._http.request(
            "/invoices",
            query={
                "cursor": cursor,
                "limit": limit,
                "customerId": customerId,
                "status": status,
            },
        )

    def retrieve(self, invoice_id: str) -> Any:
        return unwrap(
            self._http.request(f"/invoices/{_esc(invoice_id)}"),
            "invoice",
        )

    def create(self, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                "/invoices",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "invoice",
        )

    def send(self, invoice_id: str) -> Any:
        return unwrap(
            self._http.request(
                f"/invoices/{_esc(invoice_id)}/send",
                method="POST",
                idempotency_key=True,
            ),
            "invoice",
        )

    def remind(self, invoice_id: str) -> Any:
        return unwrap(
            self._http.request(
                f"/invoices/{_esc(invoice_id)}/reminder",
                method="POST",
                idempotency_key=True,
            ),
            "invoice",
        )

    def void(self, invoice_id: str) -> Any:
        return unwrap(
            self._http.request(f"/invoices/{_esc(invoice_id)}/void", method="POST"),
            "invoice",
        )


class AsyncInvoicesResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        customerId: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Any:
        return await self._http.request(
            "/invoices",
            query={
                "cursor": cursor,
                "limit": limit,
                "customerId": customerId,
                "status": status,
            },
        )

    async def retrieve(self, invoice_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/invoices/{_esc(invoice_id)}"),
            "invoice",
        )

    async def create(self, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                "/invoices",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "invoice",
        )

    async def send(self, invoice_id: str) -> Any:
        return unwrap(
            await self._http.request(
                f"/invoices/{_esc(invoice_id)}/send",
                method="POST",
                idempotency_key=True,
            ),
            "invoice",
        )

    async def remind(self, invoice_id: str) -> Any:
        return unwrap(
            await self._http.request(
                f"/invoices/{_esc(invoice_id)}/reminder",
                method="POST",
                idempotency_key=True,
            ),
            "invoice",
        )

    async def void(self, invoice_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/invoices/{_esc(invoice_id)}/void", method="POST"),
            "invoice",
        )


__all__ = ["AsyncInvoicesResource", "InvoicesResource"]
