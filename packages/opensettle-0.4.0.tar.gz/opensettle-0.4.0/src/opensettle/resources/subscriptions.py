"""Subscriptions resource.

Per ``packages/shared/src/schemas/subscription.ts``:
  - Create body: ``customerId``, ``priceId``, ``chain``, ``token``,
    ``autopay`` (``allowance`` | ``smart-wallet`` | ``manual``),
    ``trialDays``, ``metadata``.
  - Cancel body: ``mode`` (``immediately`` | ``at_period_end``),
    ``reason``.
  - Change plan body: ``priceId``, ``prorationMode``.
"""

from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

try:  # pragma: no cover
    from typing import Literal
except ImportError:  # pragma: no cover
    from typing_extensions import Literal

from .._http import HttpClient
from .._http_async import AsyncHttpClient
from .._transport import unwrap

CancelMode = Literal["immediately", "at_period_end"]
ProrationMode = Literal["immediately", "at_period_end"]


def _esc(s: str) -> str:
    return quote(s, safe="")


class SubscriptionsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        customerId: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Any:
        return self._http.request(
            "/subscriptions",
            query={
                "cursor": cursor,
                "limit": limit,
                "customerId": customerId,
                "status": status,
            },
        )

    def retrieve(self, sub_id: str) -> Any:
        return unwrap(
            self._http.request(f"/subscriptions/{_esc(sub_id)}"),
            "subscription",
        )

    def create(self, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                "/subscriptions",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "subscription",
        )

    def pause(self, sub_id: str) -> Any:
        return unwrap(
            self._http.request(f"/subscriptions/{_esc(sub_id)}/pause", method="POST"),
            "subscription",
        )

    def resume(self, sub_id: str) -> Any:
        return unwrap(
            self._http.request(f"/subscriptions/{_esc(sub_id)}/resume", method="POST"),
            "subscription",
        )

    def cancel(
        self,
        sub_id: str,
        *,
        mode: Optional[CancelMode] = None,
        reason: Optional[str] = None,
    ) -> Any:
        body: dict[str, Any] = {}
        if mode is not None:
            body["mode"] = mode
        if reason is not None:
            body["reason"] = reason
        return unwrap(
            self._http.request(
                f"/subscriptions/{_esc(sub_id)}/cancel",
                method="POST",
                body=body,
            ),
            "subscription",
        )

    def change_plan(
        self,
        sub_id: str,
        *,
        priceId: str,
        prorationMode: Optional[ProrationMode] = None,
    ) -> Any:
        body: dict[str, Any] = {"priceId": priceId}
        if prorationMode is not None:
            body["prorationMode"] = prorationMode
        return unwrap(
            self._http.request(
                f"/subscriptions/{_esc(sub_id)}/change_plan",
                method="POST",
                body=body,
                idempotency_key=True,
            ),
            "subscription",
        )


class AsyncSubscriptionsResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        customerId: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Any:
        return await self._http.request(
            "/subscriptions",
            query={
                "cursor": cursor,
                "limit": limit,
                "customerId": customerId,
                "status": status,
            },
        )

    async def retrieve(self, sub_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/subscriptions/{_esc(sub_id)}"),
            "subscription",
        )

    async def create(self, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                "/subscriptions",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "subscription",
        )

    async def pause(self, sub_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/subscriptions/{_esc(sub_id)}/pause", method="POST"),
            "subscription",
        )

    async def resume(self, sub_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/subscriptions/{_esc(sub_id)}/resume", method="POST"),
            "subscription",
        )

    async def cancel(
        self,
        sub_id: str,
        *,
        mode: Optional[CancelMode] = None,
        reason: Optional[str] = None,
    ) -> Any:
        body: dict[str, Any] = {}
        if mode is not None:
            body["mode"] = mode
        if reason is not None:
            body["reason"] = reason
        return unwrap(
            await self._http.request(
                f"/subscriptions/{_esc(sub_id)}/cancel",
                method="POST",
                body=body,
            ),
            "subscription",
        )

    async def change_plan(
        self,
        sub_id: str,
        *,
        priceId: str,
        prorationMode: Optional[ProrationMode] = None,
    ) -> Any:
        body: dict[str, Any] = {"priceId": priceId}
        if prorationMode is not None:
            body["prorationMode"] = prorationMode
        return unwrap(
            await self._http.request(
                f"/subscriptions/{_esc(sub_id)}/change_plan",
                method="POST",
                body=body,
                idempotency_key=True,
            ),
            "subscription",
        )


__all__ = [
    "AsyncSubscriptionsResource",
    "CancelMode",
    "ProrationMode",
    "SubscriptionsResource",
]
