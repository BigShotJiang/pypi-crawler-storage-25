"""Products + nested Prices resource.

Body kwargs and response keys are camelCase to match the API exactly.
Price create accepts only ``amount``, ``currency``, ``interval``,
``metadata`` per the zod schema — no ``nickname``, ``chain``, or
``token`` (those are inferred at subscription time).
"""

from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

from .._http import HttpClient
from .._http_async import AsyncHttpClient
from .._transport import unwrap


def _esc(s: str) -> str:
    return quote(s, safe="")


class ProductsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        active: Optional[bool] = None,
    ) -> Any:
        return self._http.request(
            "/products",
            query={"cursor": cursor, "limit": limit, "active": active},
        )

    def retrieve(self, product_id: str) -> Any:
        return unwrap(
            self._http.request(f"/products/{_esc(product_id)}"),
            "product",
        )

    def create(self, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                "/products",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "product",
        )

    def update(self, product_id: str, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                f"/products/{_esc(product_id)}",
                method="PATCH",
                body=fields,
            ),
            "product",
        )

    def list_prices(self, product_id: str) -> Any:
        return self._http.request(f"/products/{_esc(product_id)}/prices")

    def create_price(self, product_id: str, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                f"/products/{_esc(product_id)}/prices",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "price",
        )

    def update_price(self, price_id: str, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                f"/prices/{_esc(price_id)}",
                method="PATCH",
                body=fields,
            ),
            "price",
        )

    def delete(self, product_id: str) -> Any:
        return self._http.request(f"/products/{_esc(product_id)}", method="DELETE")

    def delete_price(self, price_id: str) -> Any:
        return unwrap(
            self._http.request(f"/prices/{_esc(price_id)}", method="DELETE"),
            "price",
        )


class AsyncProductsResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        active: Optional[bool] = None,
    ) -> Any:
        return await self._http.request(
            "/products",
            query={"cursor": cursor, "limit": limit, "active": active},
        )

    async def retrieve(self, product_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/products/{_esc(product_id)}"),
            "product",
        )

    async def create(self, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                "/products",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "product",
        )

    async def update(self, product_id: str, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                f"/products/{_esc(product_id)}",
                method="PATCH",
                body=fields,
            ),
            "product",
        )

    async def list_prices(self, product_id: str) -> Any:
        return await self._http.request(f"/products/{_esc(product_id)}/prices")

    async def create_price(self, product_id: str, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                f"/products/{_esc(product_id)}/prices",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "price",
        )

    async def update_price(self, price_id: str, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                f"/prices/{_esc(price_id)}",
                method="PATCH",
                body=fields,
            ),
            "price",
        )

    async def delete(self, product_id: str) -> Any:
        return await self._http.request(f"/products/{_esc(product_id)}", method="DELETE")

    async def delete_price(self, price_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/prices/{_esc(price_id)}", method="DELETE"),
            "price",
        )


__all__ = ["AsyncProductsResource", "ProductsResource"]
