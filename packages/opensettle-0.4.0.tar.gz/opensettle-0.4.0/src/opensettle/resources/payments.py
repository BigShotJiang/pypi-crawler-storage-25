"""Payments resource.

Refund accepts ``amountMinor``, ``reason``, ``recipientAddress`` and
returns a multi-key envelope ``{payment, unsignedTx}`` — the SDK
returns it as-is (no unwrap) since the caller needs both halves.

``refund_broadcast`` accepts ``refundTxHash`` per
``RecordRefundBroadcastRequest``.
"""

from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

from .._http import HttpClient
from .._http_async import AsyncHttpClient
from .._transport import unwrap


def _esc(s: str) -> str:
    return quote(s, safe="")


class PaymentsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        customerId: Optional[str] = None,
        subscriptionId: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Any:
        return self._http.request(
            "/payments",
            query={
                "cursor": cursor,
                "limit": limit,
                "customerId": customerId,
                "subscriptionId": subscriptionId,
                "status": status,
            },
        )

    def retrieve(self, payment_id: str) -> Any:
        return unwrap(
            self._http.request(f"/payments/{_esc(payment_id)}"),
            "payment",
        )

    def refund(self, payment_id: str, **fields: Any) -> Any:
        """Initiate a refund.

        Returns ``{"payment": Payment, "unsignedTx": UnsignedRefundTx}`` —
        the caller signs ``unsignedTx`` with their wallet and broadcasts,
        then calls :meth:`refund_broadcast`.
        """

        # Multi-key envelope is preserved by `unwrap` (it only unwraps
        # single-key wrappers); calling it here is a no-op but consistent
        # with the rest of the SDK.
        return unwrap(
            self._http.request(
                f"/payments/{_esc(payment_id)}/refund",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "payment",
        )

    def refund_broadcast(self, payment_id: str, *, refundTxHash: str) -> Any:
        return unwrap(
            self._http.request(
                f"/payments/{_esc(payment_id)}/refund/broadcast",
                method="POST",
                body={"refundTxHash": refundTxHash},
                idempotency_key=True,
            ),
            "payment",
        )


class AsyncPaymentsResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        customerId: Optional[str] = None,
        subscriptionId: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Any:
        return await self._http.request(
            "/payments",
            query={
                "cursor": cursor,
                "limit": limit,
                "customerId": customerId,
                "subscriptionId": subscriptionId,
                "status": status,
            },
        )

    async def retrieve(self, payment_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/payments/{_esc(payment_id)}"),
            "payment",
        )

    async def refund(self, payment_id: str, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                f"/payments/{_esc(payment_id)}/refund",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "payment",
        )

    async def refund_broadcast(self, payment_id: str, *, refundTxHash: str) -> Any:
        return unwrap(
            await self._http.request(
                f"/payments/{_esc(payment_id)}/refund/broadcast",
                method="POST",
                body={"refundTxHash": refundTxHash},
                idempotency_key=True,
            ),
            "payment",
        )


__all__ = ["AsyncPaymentsResource", "PaymentsResource"]
