"""Customers resource.

Body kwargs and response keys are camelCase (``customerId``,
``createdAt``, etc.) — they match the API wire format exactly. Method
and positional-arg names stay snake_case per PEP 8.
"""

from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

from .._http import HttpClient
from .._http_async import AsyncHttpClient
from .._transport import unwrap


def _esc(s: str) -> str:
    return quote(s, safe="")


class CustomersResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        status: Optional[str] = None,
        q: Optional[str] = None,
    ) -> Any:
        return self._http.request(
            "/customers",
            query={"cursor": cursor, "limit": limit, "status": status, "q": q},
        )

    def retrieve(self, customer_id: str) -> Any:
        return unwrap(
            self._http.request(f"/customers/{_esc(customer_id)}"),
            "customer",
        )

    def create(self, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                "/customers",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "customer",
        )

    def update(self, customer_id: str, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                f"/customers/{_esc(customer_id)}",
                method="PATCH",
                body=fields,
            ),
            "customer",
        )

    def delete(self, customer_id: str) -> Any:
        return self._http.request(f"/customers/{_esc(customer_id)}", method="DELETE")


class AsyncCustomersResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        status: Optional[str] = None,
        q: Optional[str] = None,
    ) -> Any:
        return await self._http.request(
            "/customers",
            query={"cursor": cursor, "limit": limit, "status": status, "q": q},
        )

    async def retrieve(self, customer_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/customers/{_esc(customer_id)}"),
            "customer",
        )

    async def create(self, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                "/customers",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "customer",
        )

    async def update(self, customer_id: str, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                f"/customers/{_esc(customer_id)}",
                method="PATCH",
                body=fields,
            ),
            "customer",
        )

    async def delete(self, customer_id: str) -> Any:
        return await self._http.request(f"/customers/{_esc(customer_id)}", method="DELETE")


__all__ = ["AsyncCustomersResource", "CustomersResource"]
