"""Resource modules. Each module ships a sync ``Resource`` class and an
``AsyncResource`` mirror sharing identical URL/body/idempotency semantics.
"""
