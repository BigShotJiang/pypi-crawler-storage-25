"""Checkouts resource.

Per ``packages/shared/src/schemas/checkout.ts``:
  - Body: ``mode`` (``payment`` | ``subscription``), ``customerId``
    or ``customerEmail`` (+ optional ``customerName``), ``invoiceId``
    (when mode=payment) or ``priceId`` (when mode=subscription),
    ``successUrl``, ``cancelUrl``, ``chain``, ``token``,
    ``expiresInMinutes``, ``metadata``.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from .._http import HttpClient
from .._http_async import AsyncHttpClient
from .._transport import unwrap


def _esc(s: str) -> str:
    return quote(s, safe="")


class CheckoutsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, **fields: Any) -> Any:
        return unwrap(
            self._http.request(
                "/checkouts",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "checkout",
        )

    def retrieve(self, checkout_id: str) -> Any:
        return unwrap(
            self._http.request(f"/checkouts/{_esc(checkout_id)}"),
            "checkout",
        )


class AsyncCheckoutsResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, **fields: Any) -> Any:
        return unwrap(
            await self._http.request(
                "/checkouts",
                method="POST",
                body=fields,
                idempotency_key=True,
            ),
            "checkout",
        )

    async def retrieve(self, checkout_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/checkouts/{_esc(checkout_id)}"),
            "checkout",
        )


__all__ = ["AsyncCheckoutsResource", "CheckoutsResource"]
