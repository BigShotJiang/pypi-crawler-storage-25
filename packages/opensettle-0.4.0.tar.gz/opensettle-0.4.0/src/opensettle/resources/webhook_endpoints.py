"""Webhook-endpoints resource.

``create`` and ``rotate_secret`` return a multi-key envelope
``{endpoint, signingSecret}`` — the SDK passes it through unchanged.
``signingSecret`` is the field name the API uses; do not rename to
``secret``.
"""

from __future__ import annotations

from typing import Any, List, Optional
from urllib.parse import quote

try:  # pragma: no cover
    from typing import Literal
except ImportError:  # pragma: no cover
    from typing_extensions import Literal

from .._http import HttpClient
from .._http_async import AsyncHttpClient
from .._transport import unwrap

EndpointStatus = Literal["enabled", "disabled"]


def _esc(s: str) -> str:
    return quote(s, safe="")


class WebhookEndpointsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self) -> Any:
        return self._http.request("/webhook_endpoints")

    def retrieve(self, endpoint_id: str) -> Any:
        return unwrap(
            self._http.request(f"/webhook_endpoints/{_esc(endpoint_id)}"),
            "endpoint",
        )

    def create(
        self,
        *,
        url: str,
        events: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> Any:
        """Create an endpoint. Returns ``{endpoint, signingSecret}`` —
        ``signingSecret`` is shown exactly once."""

        body: dict[str, Any] = {"url": url}
        if events is not None:
            body["events"] = events
        if description is not None:
            body["description"] = description
        return self._http.request(
            "/webhook_endpoints",
            method="POST",
            body=body,
            idempotency_key=True,
        )

    def update(
        self,
        endpoint_id: str,
        *,
        url: Optional[str] = None,
        description: Optional[str] = None,
        events: Optional[List[str]] = None,
        status: Optional[EndpointStatus] = None,
    ) -> Any:
        body: dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if description is not None:
            body["description"] = description
        if events is not None:
            body["events"] = events
        if status is not None:
            body["status"] = status
        return unwrap(
            self._http.request(
                f"/webhook_endpoints/{_esc(endpoint_id)}",
                method="PATCH",
                body=body,
            ),
            "endpoint",
        )

    def delete(self, endpoint_id: str) -> Any:
        return self._http.request(f"/webhook_endpoints/{_esc(endpoint_id)}", method="DELETE")

    def rotate_secret(
        self,
        endpoint_id: str,
        *,
        grace_seconds: Optional[int] = None,
    ) -> Any:
        """Rotate the signing secret. Returns ``{endpoint, signingSecret}``."""

        body: dict[str, Any] = {}
        if grace_seconds is not None:
            body["graceSeconds"] = grace_seconds
        return self._http.request(
            f"/webhook_endpoints/{_esc(endpoint_id)}/rotate",
            method="POST",
            body=body,
            idempotency_key=True,
        )

    def test(self, endpoint_id: str, *, event_type: str) -> Any:
        return self._http.request(
            f"/webhook_endpoints/{_esc(endpoint_id)}/test",
            method="POST",
            body={"eventType": event_type},
        )


class AsyncWebhookEndpointsResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list(self) -> Any:
        return await self._http.request("/webhook_endpoints")

    async def retrieve(self, endpoint_id: str) -> Any:
        return unwrap(
            await self._http.request(f"/webhook_endpoints/{_esc(endpoint_id)}"),
            "endpoint",
        )

    async def create(
        self,
        *,
        url: str,
        events: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> Any:
        body: dict[str, Any] = {"url": url}
        if events is not None:
            body["events"] = events
        if description is not None:
            body["description"] = description
        return await self._http.request(
            "/webhook_endpoints",
            method="POST",
            body=body,
            idempotency_key=True,
        )

    async def update(
        self,
        endpoint_id: str,
        *,
        url: Optional[str] = None,
        description: Optional[str] = None,
        events: Optional[List[str]] = None,
        status: Optional[EndpointStatus] = None,
    ) -> Any:
        body: dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if description is not None:
            body["description"] = description
        if events is not None:
            body["events"] = events
        if status is not None:
            body["status"] = status
        return unwrap(
            await self._http.request(
                f"/webhook_endpoints/{_esc(endpoint_id)}",
                method="PATCH",
                body=body,
            ),
            "endpoint",
        )

    async def delete(self, endpoint_id: str) -> Any:
        return await self._http.request(f"/webhook_endpoints/{_esc(endpoint_id)}", method="DELETE")

    async def rotate_secret(
        self,
        endpoint_id: str,
        *,
        grace_seconds: Optional[int] = None,
    ) -> Any:
        body: dict[str, Any] = {}
        if grace_seconds is not None:
            body["graceSeconds"] = grace_seconds
        return await self._http.request(
            f"/webhook_endpoints/{_esc(endpoint_id)}/rotate",
            method="POST",
            body=body,
            idempotency_key=True,
        )

    async def test(self, endpoint_id: str, *, event_type: str) -> Any:
        return await self._http.request(
            f"/webhook_endpoints/{_esc(endpoint_id)}/test",
            method="POST",
            body={"eventType": event_type},
        )


__all__ = [
    "AsyncWebhookEndpointsResource",
    "EndpointStatus",
    "WebhookEndpointsResource",
]
