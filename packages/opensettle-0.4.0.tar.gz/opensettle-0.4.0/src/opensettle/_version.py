"""Single source of truth for the SDK version.

Pinned to ``pyproject.toml`` by ``tests/test_version.py`` — bump both in
the same commit.
"""

SDK_VERSION = "0.4.0"
