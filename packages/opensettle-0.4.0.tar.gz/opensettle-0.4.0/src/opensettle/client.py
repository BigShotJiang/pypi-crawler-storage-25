"""High-level ``OpenSettle`` and ``AsyncOpenSettle`` client classes.

Resources are lazy-instantiated on first access — no eager allocation
for resources you don't use.

  os = OpenSettle(
      api_key=os.environ["OPENSETTLE_KEY"],
      workspace_id=os.environ["OPENSETTLE_WORKSPACE"],
  )

  customer = os.customers.create(email="ada@example.com")
  invoice = os.invoices.create(
      customer_id=customer["id"],
      amount_minor=19_900,
      currency="USD",
      chain="base",
      token="USDC",
      line_items=[{"description": "Pro plan", "quantity": 1,
                   "unit_amount_minor": 19_900}],
  )
  os.invoices.send(invoice["id"])
"""

from __future__ import annotations

from typing import Optional

from typing_extensions import Self

from ._http import HttpClient
from ._http_async import AsyncHttpClient
from ._transport import DEFAULT_MAX_NETWORK_RETRIES, DEFAULT_TIMEOUT_SECONDS
from .resources.checkouts import AsyncCheckoutsResource, CheckoutsResource
from .resources.customers import AsyncCustomersResource, CustomersResource
from .resources.invoices import AsyncInvoicesResource, InvoicesResource
from .resources.payments import AsyncPaymentsResource, PaymentsResource
from .resources.products import AsyncProductsResource, ProductsResource
from .resources.subscriptions import (
    AsyncSubscriptionsResource,
    SubscriptionsResource,
)
from .resources.webhook_endpoints import (
    AsyncWebhookEndpointsResource,
    WebhookEndpointsResource,
)


class OpenSettle:
    """Server-side synchronous OpenSettle client."""

    http: HttpClient

    def __init__(
        self,
        *,
        api_key: str,
        workspace_id: str,
        base_url: Optional[str] = None,
        test_mode: Optional[bool] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_network_retries: int = DEFAULT_MAX_NETWORK_RETRIES,
        http: Optional[HttpClient] = None,
    ) -> None:
        if http is not None:
            self.http = http
            self._owns_http = False
        else:
            self.http = HttpClient(
                api_key=api_key,
                workspace_id=workspace_id,
                base_url=base_url,
                test_mode=test_mode,
                timeout=timeout,
                max_network_retries=max_network_retries,
            )
            self._owns_http = True

        self._customers: Optional[CustomersResource] = None
        self._products: Optional[ProductsResource] = None
        self._invoices: Optional[InvoicesResource] = None
        self._payments: Optional[PaymentsResource] = None
        self._subscriptions: Optional[SubscriptionsResource] = None
        self._checkouts: Optional[CheckoutsResource] = None
        self._webhook_endpoints: Optional[WebhookEndpointsResource] = None

    @property
    def customers(self) -> CustomersResource:
        if self._customers is None:
            self._customers = CustomersResource(self.http)
        return self._customers

    @property
    def products(self) -> ProductsResource:
        if self._products is None:
            self._products = ProductsResource(self.http)
        return self._products

    @property
    def invoices(self) -> InvoicesResource:
        if self._invoices is None:
            self._invoices = InvoicesResource(self.http)
        return self._invoices

    @property
    def payments(self) -> PaymentsResource:
        if self._payments is None:
            self._payments = PaymentsResource(self.http)
        return self._payments

    @property
    def subscriptions(self) -> SubscriptionsResource:
        if self._subscriptions is None:
            self._subscriptions = SubscriptionsResource(self.http)
        return self._subscriptions

    @property
    def checkouts(self) -> CheckoutsResource:
        if self._checkouts is None:
            self._checkouts = CheckoutsResource(self.http)
        return self._checkouts

    @property
    def webhook_endpoints(self) -> WebhookEndpointsResource:
        if self._webhook_endpoints is None:
            self._webhook_endpoints = WebhookEndpointsResource(self.http)
        return self._webhook_endpoints

    def close(self) -> None:
        if self._owns_http:
            self.http.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()


class AsyncOpenSettle:
    """Server-side asynchronous OpenSettle client."""

    http: AsyncHttpClient

    def __init__(
        self,
        *,
        api_key: str,
        workspace_id: str,
        base_url: Optional[str] = None,
        test_mode: Optional[bool] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_network_retries: int = DEFAULT_MAX_NETWORK_RETRIES,
        http: Optional[AsyncHttpClient] = None,
    ) -> None:
        if http is not None:
            self.http = http
            self._owns_http = False
        else:
            self.http = AsyncHttpClient(
                api_key=api_key,
                workspace_id=workspace_id,
                base_url=base_url,
                test_mode=test_mode,
                timeout=timeout,
                max_network_retries=max_network_retries,
            )
            self._owns_http = True

        self._customers: Optional[AsyncCustomersResource] = None
        self._products: Optional[AsyncProductsResource] = None
        self._invoices: Optional[AsyncInvoicesResource] = None
        self._payments: Optional[AsyncPaymentsResource] = None
        self._subscriptions: Optional[AsyncSubscriptionsResource] = None
        self._checkouts: Optional[AsyncCheckoutsResource] = None
        self._webhook_endpoints: Optional[AsyncWebhookEndpointsResource] = None

    @property
    def customers(self) -> AsyncCustomersResource:
        if self._customers is None:
            self._customers = AsyncCustomersResource(self.http)
        return self._customers

    @property
    def products(self) -> AsyncProductsResource:
        if self._products is None:
            self._products = AsyncProductsResource(self.http)
        return self._products

    @property
    def invoices(self) -> AsyncInvoicesResource:
        if self._invoices is None:
            self._invoices = AsyncInvoicesResource(self.http)
        return self._invoices

    @property
    def payments(self) -> AsyncPaymentsResource:
        if self._payments is None:
            self._payments = AsyncPaymentsResource(self.http)
        return self._payments

    @property
    def subscriptions(self) -> AsyncSubscriptionsResource:
        if self._subscriptions is None:
            self._subscriptions = AsyncSubscriptionsResource(self.http)
        return self._subscriptions

    @property
    def checkouts(self) -> AsyncCheckoutsResource:
        if self._checkouts is None:
            self._checkouts = AsyncCheckoutsResource(self.http)
        return self._checkouts

    @property
    def webhook_endpoints(self) -> AsyncWebhookEndpointsResource:
        if self._webhook_endpoints is None:
            self._webhook_endpoints = AsyncWebhookEndpointsResource(self.http)
        return self._webhook_endpoints

    async def aclose(self) -> None:
        if self._owns_http:
            await self.http.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()


__all__ = ["AsyncOpenSettle", "OpenSettle"]
