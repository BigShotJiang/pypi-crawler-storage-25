"""TypedDict overlays for API request and response shapes.

These match the zod schemas in ``packages/shared/src/schemas/*`` exactly.
All field names are camelCase to mirror the API's wire format — there
is no client-side translation. The API speaks camelCase; we speak
camelCase.

These types are static-only — there is no runtime validation. The API
already validates server-side; re-validating client-side is duplicated
effort and a source of false breakage on additive server changes.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

try:  # pragma: no cover - exercised on Python 3.9/3.10
    from typing import Literal, TypedDict
except ImportError:  # pragma: no cover
    from typing_extensions import Literal, TypedDict


# ---- Primitives ----------------------------------------------------------

ChainId = Literal[
    "base",
    "ethereum",
    "polygon",
    "arbitrum",
    "tron",
    "solana",
]
TokenSymbol = Literal["USDC", "USDT"]
CustomerStatus = Literal["active", "at_risk", "churned"]
PriceInterval = Literal["one_time", "week", "month", "year"]
InvoiceStatus = Literal["draft", "open", "paid", "past_due", "void"]
PaymentStatus = Literal[
    "pending",
    "confirmed",
    "failed",
    "refunded",
    "reorged",
]
SubscriptionStatus = Literal[
    "trialing",
    "active",
    "past_due",
    "paused",
    "canceled",
]
AutopayMode = Literal["allowance", "smart-wallet", "manual"]
CheckoutMode = Literal["payment", "subscription"]
CheckoutStatus = Literal["open", "pending", "succeeded", "failed", "expired"]
WebhookEndpointStatus = Literal["enabled", "disabled"]
ProrationMode = Literal["immediately", "at_period_end"]
CancelMode = Literal["immediately", "at_period_end"]


# ---- Pagination envelope ------------------------------------------------


class CursorPage(TypedDict, total=False):
    data: List[Any]
    nextCursor: Optional[str]
    hasMore: bool


# ---- Customer ------------------------------------------------------------


class Customer(TypedDict, total=False):
    id: str
    workspaceId: str
    email: str
    name: str
    wallet: Optional[str]
    country: Optional[str]
    status: CustomerStatus
    activeSubscriptions: int
    lifetimeValue: int
    metadata: Optional[Dict[str, Any]]
    createdAt: str
    deletedAt: Optional[str]


class CreateCustomerRequest(TypedDict, total=False):
    email: str
    name: str
    wallet: str
    country: str
    metadata: Dict[str, Any]


class UpdateCustomerRequest(TypedDict, total=False):
    name: str
    wallet: Optional[str]
    country: Optional[str]
    metadata: Optional[Dict[str, Any]]


class ListCustomersQuery(TypedDict, total=False):
    status: CustomerStatus
    q: str
    cursor: str
    limit: int


# ---- Product / Price -----------------------------------------------------


class Product(TypedDict, total=False):
    id: str
    workspaceId: str
    name: str
    description: Optional[str]
    active: bool
    metadata: Optional[Dict[str, Any]]
    createdAt: str


class Price(TypedDict, total=False):
    id: str
    workspaceId: str
    productId: str
    amount: int
    currency: str
    interval: PriceInterval
    active: bool
    metadata: Optional[Dict[str, Any]]
    createdAt: str


class CreateProductRequest(TypedDict, total=False):
    name: str
    description: str
    metadata: Dict[str, Any]


class UpdateProductRequest(TypedDict, total=False):
    name: str
    description: Optional[str]
    active: bool
    metadata: Optional[Dict[str, Any]]


class CreatePriceRequest(TypedDict, total=False):
    amount: int
    currency: str
    interval: PriceInterval
    metadata: Dict[str, Any]


class UpdatePriceRequest(TypedDict, total=False):
    active: bool
    metadata: Optional[Dict[str, Any]]


# ---- Invoice -------------------------------------------------------------


class LineItem(TypedDict, total=False):
    description: str
    quantity: int
    unitAmountMinor: int


class Invoice(TypedDict, total=False):
    id: str
    workspaceId: str
    number: str
    customerId: str
    subscriptionId: Optional[str]
    amountMinor: int
    currency: str
    chain: ChainId
    token: TokenSymbol
    status: InvoiceStatus
    lineItems: List[LineItem]
    memo: Optional[str]
    paymentId: Optional[str]
    hostedUrl: str
    issuedAt: Optional[str]
    dueAt: str
    paidAt: Optional[str]
    voidedAt: Optional[str]
    metadata: Optional[Dict[str, Any]]
    createdAt: str


class CreateInvoiceRequest(TypedDict, total=False):
    customerId: str
    chain: ChainId
    token: TokenSymbol
    currency: str
    lineItems: List[LineItem]
    memo: str
    dueInDays: int
    subscriptionId: str
    metadata: Dict[str, Any]


# ---- Payment -------------------------------------------------------------


class Payment(TypedDict, total=False):
    id: str
    workspaceId: str
    customerId: Optional[str]
    subscriptionId: Optional[str]
    invoiceId: Optional[str]
    walletId: Optional[str]
    amountMinor: int
    feeMinor: int
    netMinor: int
    currency: str
    token: TokenSymbol
    chain: ChainId
    status: PaymentStatus
    failureReason: Optional[str]
    description: Optional[str]
    txHash: Optional[str]
    blockNumber: Optional[int]
    confirmations: int
    refundTxHash: Optional[str]
    refundAmountMinor: Optional[int]
    refundBroadcastAt: Optional[str]
    refundedAt: Optional[str]
    refundReason: Optional[str]
    createdAt: str
    confirmedAt: Optional[str]


class InitiateRefundRequest(TypedDict, total=False):
    amountMinor: int
    reason: str
    recipientAddress: str


class UnsignedRefundTx(TypedDict, total=False):
    chain: ChainId
    token: TokenSymbol
    to: str
    amountMinor: int
    memo: str
    instructions: str
    evm: Dict[str, Any]


class InitiateRefundResponse(TypedDict, total=False):
    payment: Payment
    unsignedTx: UnsignedRefundTx


class AttachRefundTxRequest(TypedDict, total=False):
    refundTxHash: str


# ---- Subscription --------------------------------------------------------


class Subscription(TypedDict, total=False):
    id: str
    workspaceId: str
    customerId: str
    productId: str
    priceId: str
    amountMinor: int
    currency: str
    chain: ChainId
    token: TokenSymbol
    status: SubscriptionStatus
    autopay: AutopayMode
    allowanceTx: Optional[str]
    allowanceRemaining: Optional[int]
    trialEndsAt: Optional[str]
    startedAt: str
    currentPeriodEnd: str
    nextBillingDate: str
    canceledAt: Optional[str]
    cancelReason: Optional[str]
    pausedAt: Optional[str]
    mrrMinor: int
    metadata: Optional[Dict[str, Any]]
    createdAt: str


class CreateSubscriptionRequest(TypedDict, total=False):
    customerId: str
    priceId: str
    chain: ChainId
    token: TokenSymbol
    autopay: AutopayMode
    trialDays: int
    metadata: Dict[str, Any]


class ChangePlanRequest(TypedDict, total=False):
    priceId: str
    prorationMode: ProrationMode


class CancelSubscriptionRequest(TypedDict, total=False):
    reason: str
    mode: CancelMode


# ---- Checkout ------------------------------------------------------------


class Checkout(TypedDict, total=False):
    id: str
    workspaceId: str
    mode: CheckoutMode
    status: CheckoutStatus
    customerId: str
    invoiceId: Optional[str]
    priceId: Optional[str]
    amountMinor: int
    currency: str
    chain: ChainId
    token: TokenSymbol
    description: Optional[str]
    successUrl: str
    cancelUrl: Optional[str]
    expiresAt: str
    completedAt: Optional[str]
    metadata: Optional[Dict[str, Any]]
    createdAt: str
    hostedUrl: str


class CreateCheckoutRequest(TypedDict, total=False):
    mode: CheckoutMode
    customerId: str
    customerEmail: str
    customerName: str
    invoiceId: str
    priceId: str
    successUrl: str
    cancelUrl: str
    chain: ChainId
    token: TokenSymbol
    expiresInMinutes: int
    metadata: Dict[str, Any]


# ---- Webhook endpoint ----------------------------------------------------


class WebhookEndpoint(TypedDict, total=False):
    id: str
    workspaceId: str
    url: str
    description: Optional[str]
    events: List[str]
    status: WebhookEndpointStatus
    successRate: float
    rotationGraceUntil: Optional[str]
    createdAt: str


class CreateWebhookEndpointRequest(TypedDict, total=False):
    url: str
    description: str
    events: List[str]


class UpdateWebhookEndpointRequest(TypedDict, total=False):
    url: str
    description: Optional[str]
    events: List[str]
    status: WebhookEndpointStatus


class CreateWebhookEndpointResponse(TypedDict, total=False):
    endpoint: WebhookEndpoint
    signingSecret: str


__all__ = [
    "AttachRefundTxRequest",
    "AutopayMode",
    "CancelMode",
    "CancelSubscriptionRequest",
    "ChainId",
    "ChangePlanRequest",
    "Checkout",
    "CheckoutMode",
    "CheckoutStatus",
    "CreateCheckoutRequest",
    "CreateCustomerRequest",
    "CreateInvoiceRequest",
    "CreatePriceRequest",
    "CreateProductRequest",
    "CreateSubscriptionRequest",
    "CreateWebhookEndpointRequest",
    "CreateWebhookEndpointResponse",
    "CursorPage",
    "Customer",
    "CustomerStatus",
    "InitiateRefundRequest",
    "InitiateRefundResponse",
    "Invoice",
    "InvoiceStatus",
    "LineItem",
    "ListCustomersQuery",
    "Payment",
    "PaymentStatus",
    "Price",
    "PriceInterval",
    "Product",
    "ProrationMode",
    "Subscription",
    "SubscriptionStatus",
    "TokenSymbol",
    "UnsignedRefundTx",
    "UpdateCustomerRequest",
    "UpdatePriceRequest",
    "UpdateProductRequest",
    "UpdateWebhookEndpointRequest",
    "WebhookEndpoint",
    "WebhookEndpointStatus",
]
