"""Polling helpers for waiting on resource state transitions.

Webhooks are the right tool for production, but in scripts, CI, and
tests it's often useful to block until a payment confirms or a
subscription transitions. ``wait_for`` and ``wait_for_async`` poll a
``.retrieve()`` callable at a fixed interval and return when the
predicate is satisfied.

Usage::

    payment = wait_for(
        os.payments.retrieve, "pay_…",
        until=lambda p: p["status"] == "confirmed",
        timeout=120,
    )

The async sibling has the same shape but takes an async fetcher::

    payment = await wait_for_async(
        aos.payments.retrieve, "pay_…",
        until=lambda p: p["status"] == "confirmed",
    )
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable
from typing import Any, Callable

DEFAULT_TIMEOUT_SECONDS = 120.0
DEFAULT_INTERVAL_SECONDS = 2.0


class TimeoutError(Exception):
    """Raised by :func:`wait_for` / :func:`wait_for_async` when the
    target state is not reached before the timeout elapses.

    Carries the last-observed resource so callers can inspect what state
    the resource was actually in.
    """

    def __init__(self, message: str, last: Any | None = None) -> None:
        super().__init__(message)
        self.last = last


def wait_for(
    retrieve: Callable[[str], Any],
    resource_id: str,
    *,
    until: Callable[[Any], bool],
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
    interval: float = DEFAULT_INTERVAL_SECONDS,
    sleep: Callable[[float], None] | None = None,
    now: Callable[[], float] | None = None,
) -> Any:
    """Poll ``retrieve(resource_id)`` every ``interval`` seconds until
    ``until(resource)`` returns truthy or ``timeout`` seconds elapse.

    Raises :class:`TimeoutError` if the predicate never matches in time.
    """

    _sleep = sleep or time.sleep
    _now = now or time.monotonic
    deadline = _now() + timeout
    last: Any = None
    while True:
        resource = retrieve(resource_id)
        last = resource
        if until(resource):
            return resource
        if _now() >= deadline:
            raise TimeoutError(
                f"{resource_id} did not reach target state within {timeout}s",
                last=last,
            )
        _sleep(interval)


async def wait_for_async(
    retrieve: Callable[[str], Awaitable[Any]],
    resource_id: str,
    *,
    until: Callable[[Any], bool],
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
    interval: float = DEFAULT_INTERVAL_SECONDS,
    sleep: Callable[[float], Awaitable[None]] | None = None,
    now: Callable[[], float] | None = None,
) -> Any:
    """Async counterpart of :func:`wait_for`."""

    _sleep = sleep or asyncio.sleep
    _now = now or time.monotonic
    deadline = _now() + timeout
    last: Any = None
    while True:
        resource = await retrieve(resource_id)
        last = resource
        if until(resource):
            return resource
        if _now() >= deadline:
            raise TimeoutError(
                f"{resource_id} did not reach target state within {timeout}s",
                last=last,
            )
        await _sleep(interval)


__all__ = [
    "DEFAULT_INTERVAL_SECONDS",
    "DEFAULT_TIMEOUT_SECONDS",
    "TimeoutError",
    "wait_for",
    "wait_for_async",
]
