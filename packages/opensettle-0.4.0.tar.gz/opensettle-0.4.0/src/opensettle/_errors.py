"""Typed error hierarchy for the OpenSettle SDK.

Mirrors the API's stable ``error.code`` taxonomy from
``@opensettle/shared/errors`` and the Node SDK's ``src/errors.ts``
character-for-character — same 12 codes, same subclasses, same fields.

Catchers can either:
  - check ``isinstance(err, OpenSettleError)`` for the broad case, then
    branch on ``err.code`` to handle specifics, or
  - catch the specific subclass (``InvalidRequestError``, ...) when the
    handler only cares about that family.

The base class always carries ``request_id`` so users can quote it in
support — this is the same ``request_id`` the API echoes back in every
error envelope.
"""

from __future__ import annotations

from typing import Any, Optional

try:  # pragma: no cover - exercised on Python 3.9/3.10
    from typing import Literal
except ImportError:  # pragma: no cover
    from typing_extensions import Literal

ErrorCode = Literal[
    "invalid_request",
    "invalid_state_transition",
    "unauthorized",
    "forbidden",
    "not_found",
    "conflict",
    "rate_limited",
    "internal_error",
    "chain_reverted",
    "insufficient_confirmations",
    "signing_required",
    "aal_required",
    "network_error",
]


class OpenSettleError(Exception):
    """Base class for every typed error raised by the SDK."""

    code: ErrorCode
    status: int
    request_id: Optional[str]
    param: Optional[str]

    def __init__(
        self,
        message: str,
        *,
        code: ErrorCode,
        status: int,
        request_id: Optional[str] = None,
        param: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status = status
        self.request_id = request_id
        self.param = param

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}(code={self.code!r}, status={self.status!r}, "
            f"request_id={self.request_id!r}, param={self.param!r}, "
            f"message={self.args[0]!r})"
        )


class InvalidRequestError(OpenSettleError):
    """The request payload failed validation."""


class InvalidStateTransitionError(OpenSettleError):
    """The resource is in a state that does not allow this operation."""


class AuthenticationError(OpenSettleError):
    """The API key was missing, malformed, revoked, or unrecognised."""


class ForbiddenError(OpenSettleError):
    """The API key authenticated but lacks permission for this route."""


class NotFoundError(OpenSettleError):
    """The addressed resource does not exist (or is not visible to this key)."""


class ConflictError(OpenSettleError):
    """The request collides with the current resource state (dup, race, FK)."""


class RateLimitError(OpenSettleError):
    """The caller exceeded a rate-limit bucket.

    ``retry_after`` is the seconds-to-wait the API advertised in its
    ``Retry-After`` header (numeric or HTTP-date), or ``None`` if not
    advertised.
    """

    retry_after: Optional[float]

    def __init__(
        self,
        message: str,
        *,
        status: int,
        request_id: Optional[str] = None,
        param: Optional[str] = None,
        retry_after: Optional[float] = None,
    ) -> None:
        super().__init__(
            message,
            code="rate_limited",
            status=status,
            request_id=request_id,
            param=param,
        )
        self.retry_after = retry_after


class SettlementError(OpenSettleError):
    """A chain-side or signing failure: revert, insufficient confs, missing sig."""


class StepUpRequiredError(OpenSettleError):
    """The route requires step-up auth (AAL=2). Re-authenticate and retry."""


class APIError(OpenSettleError):
    """Catch-all for unknown error codes and ``internal_error`` 5xx responses."""


class NetworkError(OpenSettleError):
    """Transport-level failure: timeout, DNS, connection refused, etc."""

    def __init__(self, message: str) -> None:
        super().__init__(
            message,
            code="network_error",
            status=0,
            request_id=None,
            param=None,
        )


def from_envelope(
    envelope: Any,
    status: int,
    retry_after: Optional[float],
) -> OpenSettleError:
    """Map a parsed API error envelope + HTTP status into the right subclass.

    Falls back to :class:`APIError` on unknown codes so a new server-side
    code never crashes older clients.
    """

    error = envelope.get("error") if isinstance(envelope, dict) else None
    code = error.get("code") if isinstance(error, dict) else None
    message = error.get("message") if isinstance(error, dict) else None
    request_id_raw = error.get("request_id") if isinstance(error, dict) else None
    param_raw = error.get("param") if isinstance(error, dict) else None

    if not isinstance(message, str) or not message:
        message = f"Request failed with status {status}"

    req_id: Optional[str] = request_id_raw if isinstance(request_id_raw, str) else None
    param: Optional[str] = param_raw if isinstance(param_raw, str) else None

    if code == "invalid_request":
        return InvalidRequestError(
            message, code="invalid_request", status=status, request_id=req_id, param=param
        )
    if code == "invalid_state_transition":
        return InvalidStateTransitionError(
            message,
            code="invalid_state_transition",
            status=status,
            request_id=req_id,
            param=param,
        )
    if code == "unauthorized":
        return AuthenticationError(
            message, code="unauthorized", status=status, request_id=req_id, param=param
        )
    if code == "forbidden":
        return ForbiddenError(
            message, code="forbidden", status=status, request_id=req_id, param=param
        )
    if code == "not_found":
        return NotFoundError(
            message, code="not_found", status=status, request_id=req_id, param=param
        )
    if code == "conflict":
        return ConflictError(
            message, code="conflict", status=status, request_id=req_id, param=param
        )
    if code == "rate_limited":
        return RateLimitError(
            message,
            status=status,
            request_id=req_id,
            param=param,
            retry_after=retry_after,
        )
    if code == "chain_reverted":
        return SettlementError(
            message, code="chain_reverted", status=status, request_id=req_id, param=param
        )
    if code == "insufficient_confirmations":
        return SettlementError(
            message,
            code="insufficient_confirmations",
            status=status,
            request_id=req_id,
            param=param,
        )
    if code == "signing_required":
        return SettlementError(
            message,
            code="signing_required",
            status=status,
            request_id=req_id,
            param=param,
        )
    if code == "aal_required":
        return StepUpRequiredError(
            message, code="aal_required", status=status, request_id=req_id, param=param
        )
    # internal_error or anything we don't recognise → forward-compat APIError.
    return APIError(message, code="internal_error", status=status, request_id=req_id, param=param)


__all__ = [
    "APIError",
    "AuthenticationError",
    "ConflictError",
    "ErrorCode",
    "ForbiddenError",
    "InvalidRequestError",
    "InvalidStateTransitionError",
    "NetworkError",
    "NotFoundError",
    "OpenSettleError",
    "RateLimitError",
    "SettlementError",
    "StepUpRequiredError",
    "from_envelope",
]
