"""Shared transport logic for the sync and async HTTP clients.

The two clients differ only in whether they ``await`` ``httpx`` calls
and ``asyncio.sleep`` vs ``time.sleep``. Every other concern — config
validation, URL building, header assembly, idempotency-key generation,
query encoding, retry policy, error mapping — lives here so the two
clients can never drift.
"""

from __future__ import annotations

import json as jsonlib
import secrets
import time
from collections.abc import Mapping
from email.utils import parsedate_to_datetime
from typing import Any, Optional, Union
from urllib.parse import quote, urlencode

from ._errors import (
    APIError,
    NetworkError,
    OpenSettleError,
    RateLimitError,
    from_envelope,
)
from ._version import SDK_VERSION

DEFAULT_BASE_URL = "https://api.opensettle.io"
DEFAULT_TIMEOUT_SECONDS = 30.0
DEFAULT_MAX_NETWORK_RETRIES = 3
RETRIABLE_STATUS = frozenset({408, 425, 429, 500, 502, 503, 504})

# Capped exponential backoff: 0.25, 0.5, 1, 2, 4s (then capped at 4s).
_BACKOFF_BASE = 0.25
_BACKOFF_CAP = 4.0


def is_live_key(api_key: str) -> bool:
    return api_key.startswith("sk_live_")


def is_test_key(api_key: str) -> bool:
    return api_key.startswith("sk_test_")


def assert_api_key_environment(api_key: str, test_mode: Optional[bool]) -> None:
    if not is_live_key(api_key) and not is_test_key(api_key):
        raise ValueError("OpenSettle: api_key must start with `sk_live_` or `sk_test_`")
    if test_mode is True and is_live_key(api_key):
        raise ValueError(
            "OpenSettle: test_mode is True but api_key is sk_live_… (refusing to send live traffic)"
        )
    if test_mode is False and is_test_key(api_key):
        raise ValueError(
            "OpenSettle: test_mode is False but api_key is sk_test_… (refusing to send to test API)"
        )


def generate_idempotency_key() -> str:
    """Generate a cryptographically random idempotency key.

    Format ``os_<hex>`` — readable, sortable enough by timestamp prefix
    when callers want to group, and 128 bits of entropy from
    ``secrets.token_hex`` so there is no realistic collision risk.
    """

    return f"os_{secrets.token_hex(16)}"


def encode_query(
    query: Optional[Mapping[str, Any]],
) -> str:
    if not query:
        return ""
    pairs: list[tuple[str, str]] = []
    for k, v in query.items():
        if v is None:
            continue
        if isinstance(v, bool):
            # Match the Node SDK's String(True) → "True" — but JSON-ish
            # `true`/`false` is far more useful on the wire and the API
            # accepts both. Choose lowercase to match query-string idiom.
            pairs.append((k, "true" if v else "false"))
        else:
            pairs.append((k, str(v)))
    if not pairs:
        return ""
    return "?" + urlencode(pairs, doseq=False)


def build_url(
    base_url: str,
    workspace_id: str,
    path: str,
    query: Optional[Mapping[str, Any]] = None,
) -> str:
    norm = path if path.startswith("/") else f"/{path}"
    ws_prefix = f"/v1/workspaces/{quote(workspace_id, safe='')}"
    return f"{base_url}{ws_prefix}{norm}{encode_query(query)}"


def build_raw_url(
    base_url: str,
    path: str,
    query: Optional[Mapping[str, Any]] = None,
) -> str:
    norm = path if path.startswith("/") else f"/{path}"
    return f"{base_url}{norm}{encode_query(query)}"


def lowercase_keys(headers: Optional[Mapping[str, str]]) -> dict[str, str]:
    if not headers:
        return {}
    return {k.lower(): v for k, v in headers.items()}


def build_headers(
    *,
    api_key: str,
    extra: Optional[Mapping[str, str]] = None,
    has_body: bool,
    idempotency_key: Union[None, str, bool] = None,
) -> dict[str, str]:
    headers: dict[str, str] = {
        "authorization": f"Bearer {api_key}",
        "accept": "application/json",
        "user-agent": f"opensettle-python/{SDK_VERSION}",
    }
    headers.update(lowercase_keys(extra))
    if has_body:
        headers["content-type"] = "application/json"
    if idempotency_key and "idempotency-key" not in headers:
        if idempotency_key is True:
            headers["idempotency-key"] = generate_idempotency_key()
        else:
            headers["idempotency-key"] = idempotency_key
    return headers


def encode_body(body: Any) -> Optional[str]:
    if body is None:
        return None
    return jsonlib.dumps(body, separators=(",", ":"))


def normalize_base_url(base_url: Optional[str]) -> str:
    return (base_url or DEFAULT_BASE_URL).rstrip("/")


def parse_retry_after(value: Optional[str]) -> Optional[float]:
    """Parse ``Retry-After``. Numeric seconds or HTTP-date; ``None`` if
    unparseable or missing."""

    if value is None:
        return None
    stripped = value.strip()
    if not stripped:
        return None
    try:
        seconds = float(stripped)
        if seconds >= 0:
            return seconds
        return None
    except ValueError:
        pass
    try:
        dt = parsedate_to_datetime(stripped)
    except (TypeError, ValueError):
        return None
    delta: float = dt.timestamp() - time.time()
    return delta if delta > 0 else 0.0


def backoff_seconds(attempt: int) -> float:
    """Capped exponential: 0.25, 0.5, 1, 2, 4 (then capped)."""

    return float(min(_BACKOFF_CAP, _BACKOFF_BASE * (2**attempt)))


def parse_response_body(text: str, status: int) -> tuple[Any, Optional[OpenSettleError]]:
    """Try to parse ``text`` as JSON. Returns ``(data, None)`` on success,
    ``(None, APIError)`` on a 2xx with malformed JSON."""

    if not text:
        return None, None
    try:
        return jsonlib.loads(text), None
    except (ValueError, jsonlib.JSONDecodeError):
        return None, APIError(
            "Server returned a 2xx with non-JSON body",
            code="internal_error",
            status=status,
        )


def map_error(text: str, status: int, retry_after_header: Optional[str]) -> OpenSettleError:
    envelope: Any = None
    if text:
        try:
            envelope = jsonlib.loads(text)
        except (ValueError, jsonlib.JSONDecodeError):
            envelope = None
    retry_after = parse_retry_after(retry_after_header)
    return from_envelope(envelope, status, retry_after)


def is_retriable_error(err: OpenSettleError) -> bool:
    if isinstance(err, NetworkError):
        return True
    return err.status in RETRIABLE_STATUS


def wait_seconds_for_error(err: OpenSettleError, attempt: int) -> float:
    if isinstance(err, RateLimitError) and err.retry_after is not None:
        return err.retry_after
    return backoff_seconds(attempt)


def unwrap(resp: Any, key: str) -> Any:
    """Strip the API's singleton-envelope wrapper.

    The API returns most singleton responses as ``{"customer": {...}}``,
    ``{"product": {...}}`` etc. — a single-key wrapper around the
    resource. This helper unwraps that wrapper when present, and is a
    no-op for:

    - lists (no matching key)
    - multi-key envelopes such as the refund response
      (``{payment, unsignedTx}``) or the webhook create response
      (``{endpoint, signingSecret}``)
    - ``None`` (204 No Content) and other non-dict values
    """

    if isinstance(resp, dict) and len(resp) == 1 and key in resp:
        return resp[key]
    return resp


__all__ = [
    "DEFAULT_BASE_URL",
    "DEFAULT_MAX_NETWORK_RETRIES",
    "DEFAULT_TIMEOUT_SECONDS",
    "RETRIABLE_STATUS",
    "assert_api_key_environment",
    "backoff_seconds",
    "build_headers",
    "build_raw_url",
    "build_url",
    "encode_body",
    "encode_query",
    "generate_idempotency_key",
    "is_live_key",
    "is_retriable_error",
    "is_test_key",
    "lowercase_keys",
    "map_error",
    "normalize_base_url",
    "parse_response_body",
    "parse_retry_after",
    "unwrap",
    "wait_seconds_for_error",
]
