"""Verify signed OpenSettle webhook deliveries.

Signing scheme matches the API
(``apps/api/src/services/webhook-deliver.ts::signPayload``) and the
Node SDK (``packages/sdk/src/webhooks.ts``) exactly:

  header  : ``x-opensettle-signature: t=<unix>,v1=<hex_hmac_sha256>``
  message : ``<unix>.<raw_body>``
  secret  : the per-endpoint signing secret returned by
            ``POST /v1/workspaces/:ws/webhook_endpoints`` (or rotated
            via ``…/rotate``)

The verifier is constant-time. It raises :class:`WebhookVerificationError`
with a typed ``reason`` on every failure path so handlers can return a
400 with confidence — the caller already knows the request didn't come
from us.

Pass ``tolerance`` (seconds) to reject deliveries whose timestamp is
too old. Default is 300s (5 min); set 0 to disable timestamp checking
entirely (NOT recommended outside replay-driven tests).
"""

from __future__ import annotations

import hmac
import json
import time
from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Optional, Union

try:  # pragma: no cover - exercised on Python 3.9/3.10
    from typing import Literal
except ImportError:  # pragma: no cover
    from typing_extensions import Literal

VerificationReason = Literal[
    "missing_header",
    "malformed_header",
    "stale_timestamp",
    "signature_mismatch",
    "invalid_body",
]


@dataclass(frozen=True)
class VerifiedWebhook:
    """Result of a successful :func:`verify_webhook` call."""

    data: Any
    """The decoded JSON body."""

    timestamp: int
    """Unix epoch seconds from the signature header."""


class WebhookVerificationError(Exception):
    """Raised when a signed-webhook delivery cannot be verified.

    ``reason`` is one of:

    ``missing_header``
        No ``x-opensettle-signature`` header on the request.
    ``malformed_header``
        Header present but not in the expected ``t=…,v1=…`` form, or
        ``t`` was non-integer / ``v1`` was non-hex.
    ``stale_timestamp``
        Timestamp is outside the tolerance window.
    ``signature_mismatch``
        HMAC did not match — body was tampered with or the secret is
        wrong.
    ``invalid_body``
        Signature verified but the body is not valid JSON.
    """

    reason: VerificationReason

    def __init__(self, message: str, reason: VerificationReason) -> None:
        super().__init__(message)
        self.reason = reason


DEFAULT_TOLERANCE_SECONDS = 300


def verify_webhook(
    *,
    raw_body: Union[str, bytes],
    signature_header: Optional[str],
    secret: str,
    tolerance: float = DEFAULT_TOLERANCE_SECONDS,
    now: Optional[int] = None,
) -> VerifiedWebhook:
    """Verify a signed-webhook delivery.

    Args:
        raw_body: Exact bytes of the request body (``str`` or ``bytes``).
            Do **not** parse and re-serialize — the signature is bound
            to the byte-for-byte body.
        signature_header: The ``x-opensettle-signature`` header value.
        secret: The endpoint's signing secret (``whsec_…``).
        tolerance: Window in seconds within which the signed timestamp
            must fall. Default 300. Use 0 to disable the check.
        now: Override the "current" epoch (mainly for tests).

    Returns:
        A :class:`VerifiedWebhook` with the decoded JSON body and the
        signed timestamp.

    Raises:
        WebhookVerificationError: with a typed ``reason``.
    """

    if not signature_header:
        raise WebhookVerificationError("Missing x-opensettle-signature header", "missing_header")

    parsed = _parse_signature_header(signature_header)
    if parsed is None:
        raise WebhookVerificationError("Malformed signature header", "malformed_header")
    timestamp, v1 = parsed

    if tolerance > 0:
        now_seconds = now if now is not None else int(time.time())
        if abs(now_seconds - timestamp) > tolerance:
            raise WebhookVerificationError(
                f"Timestamp {timestamp} is outside the {tolerance}s tolerance "
                f"window (now={now_seconds})",
                "stale_timestamp",
            )

    body_bytes = raw_body if isinstance(raw_body, bytes) else raw_body.encode("utf-8")

    message = f"{timestamp}.".encode() + body_bytes
    expected = hmac.new(secret.encode("utf-8"), message, sha256).hexdigest()

    # Constant-time compare requires equal-length inputs; bail before
    # ``compare_digest`` if the lengths differ to short-circuit cleanly.
    if len(expected) != len(v1):
        raise WebhookVerificationError("Signature mismatch", "signature_mismatch")
    if not hmac.compare_digest(expected, v1):
        raise WebhookVerificationError("Signature mismatch", "signature_mismatch")

    try:
        data = json.loads(body_bytes)
    except (ValueError, json.JSONDecodeError) as exc:
        raise WebhookVerificationError(f"Body is not valid JSON: {exc}", "invalid_body") from exc

    return VerifiedWebhook(data=data, timestamp=timestamp)


def _parse_signature_header(header: str) -> Optional[tuple[int, str]]:
    """Parse ``t=<int>,v1=<hex>``. Unknown keys are tolerated (forward-compat).

    Returns ``(timestamp, v1_hex)`` on success; ``None`` if the header
    is malformed (missing ``t`` or ``v1``, non-integer ``t``, non-hex
    ``v1``).
    """

    timestamp: Optional[int] = None
    v1: Optional[str] = None
    parts = [p.strip() for p in header.split(",") if p.strip()]
    for part in parts:
        eq = part.find("=")
        if eq <= 0:
            return None
        key = part[:eq].strip()
        value = part[eq + 1 :].strip()
        if key == "t":
            try:
                timestamp = int(value, 10)
            except ValueError:
                return None
        elif key == "v1":
            if not value or not _is_hex(value):
                return None
            v1 = value
        # Unknown keys are ignored (forward-compat for v2 signatures).
    if timestamp is None or v1 is None:
        return None
    return timestamp, v1


def _is_hex(s: str) -> bool:
    if not s:
        return False
    return all(ch in "0123456789abcdefABCDEF" for ch in s)


__all__ = [
    "DEFAULT_TOLERANCE_SECONDS",
    "VerificationReason",
    "VerifiedWebhook",
    "WebhookVerificationError",
    "verify_webhook",
]
