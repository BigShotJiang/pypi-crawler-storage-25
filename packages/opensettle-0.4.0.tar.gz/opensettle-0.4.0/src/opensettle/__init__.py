"""Official Python SDK for the OpenSettle API.

Public surface is intentionally narrow: the high-level clients
(:class:`OpenSettle`, :class:`AsyncOpenSettle`), the typed error
hierarchy, and the webhook verifier. Everything else is private and may
change without a major-version bump.
"""

from __future__ import annotations

from ._errors import (
    APIError,
    AuthenticationError,
    ConflictError,
    ErrorCode,
    ForbiddenError,
    InvalidRequestError,
    InvalidStateTransitionError,
    NetworkError,
    NotFoundError,
    OpenSettleError,
    RateLimitError,
    SettlementError,
    StepUpRequiredError,
)
from ._pagination import aiterate, paginate
from ._version import SDK_VERSION
from ._wait import TimeoutError as WaitTimeoutError
from ._wait import wait_for, wait_for_async
from ._webhooks import (
    VerifiedWebhook,
    WebhookVerificationError,
    verify_webhook,
)
from .client import AsyncOpenSettle, OpenSettle

__all__ = [
    "SDK_VERSION",
    "APIError",
    "AsyncOpenSettle",
    "AuthenticationError",
    "ConflictError",
    "ErrorCode",
    "ForbiddenError",
    "InvalidRequestError",
    "InvalidStateTransitionError",
    "NetworkError",
    "NotFoundError",
    "OpenSettle",
    "OpenSettleError",
    "RateLimitError",
    "SettlementError",
    "StepUpRequiredError",
    "VerifiedWebhook",
    "WaitTimeoutError",
    "WebhookVerificationError",
    "aiterate",
    "paginate",
    "verify_webhook",
    "wait_for",
    "wait_for_async",
]
