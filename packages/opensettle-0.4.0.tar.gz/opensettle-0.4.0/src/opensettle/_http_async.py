"""Asynchronous HTTP client built on ``httpx.AsyncClient``.

Mirror of :mod:`opensettle._http`. The two clients share the
transport core in :mod:`opensettle._transport` — they only differ in
``await`` and ``asyncio.sleep`` vs ``time.sleep``.
"""

from __future__ import annotations

import asyncio
from collections.abc import Mapping
from typing import Any, Optional, Union

import httpx
from typing_extensions import Self

from ._errors import NetworkError, OpenSettleError
from ._transport import (
    DEFAULT_MAX_NETWORK_RETRIES,
    DEFAULT_TIMEOUT_SECONDS,
    assert_api_key_environment,
    build_headers,
    build_raw_url,
    build_url,
    encode_body,
    is_retriable_error,
    map_error,
    normalize_base_url,
    parse_response_body,
    wait_seconds_for_error,
)


class AsyncHttpClient:
    """Async sibling of :class:`opensettle._http.HttpClient`."""

    api_key: str
    workspace_id: str
    base_url: str
    timeout: float
    max_network_retries: int

    def __init__(
        self,
        *,
        api_key: str,
        workspace_id: str,
        base_url: Optional[str] = None,
        test_mode: Optional[bool] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_network_retries: int = DEFAULT_MAX_NETWORK_RETRIES,
        transport: Optional[httpx.AsyncBaseTransport] = None,
        _client: Optional[httpx.AsyncClient] = None,
        _sleep: Any = None,
    ) -> None:
        if not api_key:
            raise ValueError("OpenSettle: api_key is required")
        if not workspace_id:
            raise ValueError("OpenSettle: workspace_id is required")
        assert_api_key_environment(api_key, test_mode)

        self.api_key = api_key
        self.workspace_id = workspace_id
        self.base_url = normalize_base_url(base_url)
        self.timeout = timeout
        self.max_network_retries = max_network_retries
        if _client is not None:
            self._client = _client
            self._owns_client = False
        else:
            self._client = httpx.AsyncClient(timeout=timeout, transport=transport)
            self._owns_client = True
        self._sleep = _sleep if _sleep is not None else asyncio.sleep

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()

    def url(self, path: str, query: Optional[Mapping[str, Any]] = None) -> str:
        return build_url(self.base_url, self.workspace_id, path, query)

    def raw_url(self, path: str, query: Optional[Mapping[str, Any]] = None) -> str:
        return build_raw_url(self.base_url, path, query)

    async def request(
        self,
        path: str,
        *,
        method: str = "GET",
        body: Any = None,
        query: Optional[Mapping[str, Any]] = None,
        idempotency_key: Union[None, str, bool] = None,
        headers: Optional[Mapping[str, str]] = None,
        timeout: Optional[float] = None,
        max_network_retries: Optional[int] = None,
    ) -> Any:
        return await self._request_at(
            self.url(path, query),
            method=method,
            body=body,
            idempotency_key=idempotency_key,
            headers=headers,
            timeout=timeout,
            max_network_retries=max_network_retries,
        )

    async def request_raw(
        self,
        path: str,
        *,
        method: str = "GET",
        body: Any = None,
        query: Optional[Mapping[str, Any]] = None,
        idempotency_key: Union[None, str, bool] = None,
        headers: Optional[Mapping[str, str]] = None,
        timeout: Optional[float] = None,
        max_network_retries: Optional[int] = None,
    ) -> Any:
        return await self._request_at(
            self.raw_url(path, query),
            method=method,
            body=body,
            idempotency_key=idempotency_key,
            headers=headers,
            timeout=timeout,
            max_network_retries=max_network_retries,
        )

    async def _request_at(
        self,
        url: str,
        *,
        method: str,
        body: Any,
        idempotency_key: Union[None, str, bool],
        headers: Optional[Mapping[str, str]],
        timeout: Optional[float],
        max_network_retries: Optional[int],
    ) -> Any:
        body_text = encode_body(body)
        final_headers = build_headers(
            api_key=self.api_key,
            extra=headers,
            has_body=body_text is not None,
            idempotency_key=idempotency_key,
        )
        request_timeout = timeout if timeout is not None else self.timeout
        budget = (
            max_network_retries if max_network_retries is not None else self.max_network_retries
        )

        last_error: Optional[OpenSettleError] = None
        for attempt in range(budget + 1):
            try:
                resp = await self._client.request(
                    method,
                    url,
                    content=body_text,
                    headers=final_headers,
                    timeout=request_timeout,
                )
            except httpx.HTTPError as exc:
                err = NetworkError(f"Network error: {exc}")
                if attempt < budget:
                    await self._sleep(wait_seconds_for_error(err, attempt))
                    last_error = err
                    continue
                raise err from exc

            if resp.status_code < 400:
                if resp.status_code == 204 or not resp.content:
                    return None
                data, parse_err = parse_response_body(resp.text, resp.status_code)
                if parse_err is not None:
                    raise parse_err
                return data

            api_err = map_error(resp.text, resp.status_code, resp.headers.get("retry-after"))
            if is_retriable_error(api_err) and attempt < budget:
                await self._sleep(wait_seconds_for_error(api_err, attempt))
                last_error = api_err
                continue
            raise api_err

        raise last_error or RuntimeError("OpenSettle: request loop exited unexpectedly")


__all__ = ["AsyncHttpClient"]
