"""Cursor-pagination helpers — sync and async iterators that follow
the API's ``{data, nextCursor, hasMore}`` envelope automatically.

Resource list methods continue to return a single page (``dict``) for
backward compatibility. The ``iter()`` / ``aiter()`` companions auto-page
across the whole result set.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator, Mapping
from typing import Any, Callable, Optional


def paginate(
    fetch: Callable[..., Any],
    **initial_query: Any,
) -> Iterator[Any]:
    """Yield every item across all pages.

    ``fetch`` is a list-method callable that takes ``**kwargs`` (cursor,
    limit, plus any filters) and returns the API's page envelope
    (a dict with ``data``, ``nextCursor``, ``hasMore``).

    Usage::

        for customer in paginate(os.customers.list, status="active"):
            print(customer["id"])
    """

    query: dict[str, Any] = {k: v for k, v in initial_query.items() if v is not None}
    while True:
        page = fetch(**query)
        if not isinstance(page, Mapping):
            return
        data = page.get("data") or []
        yield from data
        next_cursor: Optional[str] = page.get("nextCursor")
        has_more = bool(page.get("hasMore"))
        if not has_more or not next_cursor:
            return
        query["cursor"] = next_cursor


async def aiterate(
    fetch: Callable[..., Any],
    **initial_query: Any,
) -> AsyncIterator[Any]:
    """Async counterpart of :func:`paginate`.

    ``fetch`` is an async list-method callable. Usage::

        async for c in aiterate(aos.customers.list, status="active"):
            print(c["id"])
    """

    query: dict[str, Any] = {k: v for k, v in initial_query.items() if v is not None}
    while True:
        page = await fetch(**query)
        if not isinstance(page, Mapping):
            return
        data = page.get("data") or []
        for item in data:
            yield item
        next_cursor: Optional[str] = page.get("nextCursor")
        has_more = bool(page.get("hasMore"))
        if not has_more or not next_cursor:
            return
        query["cursor"] = next_cursor


__all__ = ["aiterate", "paginate"]
