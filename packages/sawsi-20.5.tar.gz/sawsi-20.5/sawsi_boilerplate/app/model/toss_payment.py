import time
import uuid
from typing import Optional
from pydantic import fields
from sawsi.model.base import DynamoModel, sync
import api


@sync
class TossPayment(DynamoModel):
    """토스페이먼츠 결제 내역"""
    __dynamo__ = api.dynamo
    _table = 'toss_payment'
    _indexes = [
        ('user_id', 'crt'),
        ('order_id', 'crt'),
    ]

    id: str = fields.Field(default_factory=lambda: str(uuid.uuid4()))
    crt: float = fields.Field(default_factory=time.time)
    user_id: str

    # 결제 식별
    payment_key: str  # 토스 paymentKey
    order_id: str  # 가맹점 주문 ID
    order_name: str = ''

    # 결제 상태
    # READY, IN_PROGRESS, WAITING_FOR_DEPOSIT, DONE,
    # CANCELED, PARTIAL_CANCELED, ABORTED, EXPIRED
    status: str = 'READY'
    method: Optional[str] = None  # 카드, 가상계좌, 간편결제, 계좌이체, 휴대폰 등

    # 금액 / 통화
    currency: str = 'KRW'  # KRW, USD, JPY 등
    total_amount: float = 0
    balance_amount: float = 0  # 취소 가능 잔액
    supplied_amount: float = 0  # 공급가액
    vat: float = 0

    # 시간
    requested_at: Optional[str] = None
    approved_at: Optional[str] = None

    # 토스 원본 응답
    raw_response: Optional[dict] = None

    # 취소 내역
    cancels: Optional[list] = None

    def is_paid(self) -> bool:
        return self.status == 'DONE'

    def is_canceled(self) -> bool:
        return self.status in ('CANCELED', 'PARTIAL_CANCELED')

    def view(self) -> dict:
        return {
            'id': self.id,
            'user_id': self.user_id,
            'payment_key': self.payment_key,
            'order_id': self.order_id,
            'order_name': self.order_name,
            'status': self.status,
            'method': self.method,
            'currency': self.currency,
            'total_amount': self.total_amount,
            'balance_amount': self.balance_amount,
            'requested_at': self.requested_at,
            'approved_at': self.approved_at,
            'cancels': self.cancels,
        }
