import time
from typing import Optional
from sawsi.model.base import DynamoModel, sync
import api


@sync
class GoogleRevocation(DynamoModel):
    """Google Play 환불 내역"""
    __dynamo__ = api.dynamo
    _table = 'google_revocation'
    _indexes = []

    purchase_token: str
    order_id: str
    product_type: Optional[int] = None
    refund_type: Optional[int] = None


@sync
class GoogleSubscription(DynamoModel):
    """Google Play 인앱 구독 상태"""
    __dynamo__ = api.dynamo
    _table = 'google_subscription'
    _indexes = [
        ('user_id', 'crt'),
        ('purchase_token', 'crt'),
    ]

    user_id: str

    # 구독 상태
    subscription_id: str  # product_id 역할
    purchase_token: str
    order_id: str

    start_time_ms: int
    expiry_time_ms: int

    auto_renewing: bool = False
    acknowledged: bool = False
    payment_state: int = -1  # 0: 결제 전, 1: 결제 완료, 2: 무료 체험

    price_amount_micros: int = 0
    price_currency_code: str = 'USD'

    def is_active(self) -> bool:
        if self.is_refunded():
            return False
        now_ms = time.time() * 1000
        return self.expiry_time_ms > now_ms

    def is_refunded(self) -> bool:
        revocation = GoogleRevocation.get(self.order_id)
        return revocation is not None

    def view(self) -> dict:
        return {
            'id': self.id,
            'user_id': self.user_id,
            'subscription_id': self.subscription_id,
            'is_active': self.is_active(),
            'start_time_ms': self.start_time_ms,
            'expiry_time_ms': self.expiry_time_ms,
            'auto_renewing': self.auto_renewing,
            'acknowledged': self.acknowledged,
        }
