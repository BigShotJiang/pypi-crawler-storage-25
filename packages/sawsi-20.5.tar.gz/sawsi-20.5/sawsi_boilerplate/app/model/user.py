"""
This is sample code to tell how to use sawsi framework.
You could delete this file after know how to use this framework.
"""

import time
import uuid
import api
from pydantic import fields, BaseModel
from typing import Optional, Literal, TypeVar, Generic, Type
from sawsi.model.base import DynamoModel, sync


class Address(BaseModel):
    street: str
    city: str
    country: str


@sync
class User(DynamoModel):
    __dynamo__ = api.dynamo
    __create_default_index__ = True  # Optional 이며, 파티션 키 부하에 민감한 경우 전체 쿼리를 위한 인덱스를 제거하는데 사용됨.
    _table = 'user'
    _indexes = [
        ('email', 'crt'),
        ('google_sub', 'crt'),
        ('apple_sub', 'crt'),
        ('naver_sub', 'crt'),
        ('kakao_sub', 'crt'),
    ]

    id: str = fields.Field(default_factory=lambda: str(uuid.uuid4()))
    crt:float = fields.Field(default_factory=time.time)
    ptn:str = 'user'
    name: str
    age: Optional[int] = None
    gender: Optional[Literal["male", "female"]] = None
    address: Optional[Address] = None

    # 인증 관련
    password_hash: Optional[str] = None
    password_salt: Optional[str] = None
    email: str = ' '
    google_sub: str = ' '
    apple_sub: str = ' '
    naver_sub: str = ' '
    kakao_sub: str = ' '

    def is_subscribed_apple(self, product_id: str) -> bool:
        """Apple 구독이 활성 상태인지 확인 (product_id 기준)"""
        from {{app}}.model.subscription.apple_subscription import AppleSubscription
        subs = AppleSubscription.generate(
            pk_field='user_id', pk_value=self.id,
            sk_field='crt', reverse=True,
        )
        for sub in subs:
            if sub.product_id == product_id and sub.is_active():
                return True
        return False

    def is_subscribed_google(self, product_id: str) -> bool:
        """Google 구독이 활성 상태인지 확인 (subscription_id 기준)"""
        from {{app}}.model.subscription.google_subscription import GoogleSubscription
        subs = GoogleSubscription.generate(
            pk_field='user_id', pk_value=self.id,
            sk_field='crt', reverse=True,
        )
        for sub in subs:
            if sub.subscription_id == product_id and sub.is_active():
                return True
        return False

    def is_subscribed_toss(self, product_id: str) -> bool:
        """토스 정기결제 구독이 활성 상태인지 확인 (product_id 기준)"""
        from {{app}}.model.toss_billing import TossSubscription
        subs = TossSubscription.generate(
            pk_field='user_id', pk_value=self.id,
            sk_field='crt', reverse=True,
        )
        for sub in subs:
            if sub.product_id == product_id and sub.is_active():
                return True
        return False

    def view(self)->dict:
        return {
            'name': self.name,
            'age': self.age
        }


if __name__ == '__main__':
    # 모델 인스턴스 생성
    address_data = {'street': '123 Main St', 'city': 'Anytown', 'country': 'USA'}
    user_data = {'name': 'John Doe', 'age': 30, 'gender': 'male', 'address': address_data}
    user = User(**user_data)
    print('user.id', user.id)

    # 모델을 딕셔너리로 변환
    user_dict = user.model_dump()
    print(user_dict)
