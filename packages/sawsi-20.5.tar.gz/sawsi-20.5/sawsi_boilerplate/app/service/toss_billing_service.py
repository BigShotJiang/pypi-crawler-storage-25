"""
토스페이먼츠 자동결제(빌링) 서비스

정기결제 흐름:
1. 클라이언트에서 빌링 결제창 → 카드 등록 완료 → successUrl로 authKey, customerKey 전달
2. 서버에서 issue_billing_key 호출 → 토스 API로 빌링키 발급 → DB 저장
3. 구독 생성 (create_subscription) → 즉시 첫 결제 실행
4. 이후 주기마다 charge_subscription 호출 (스케줄러/크론에서)
"""
import time
import base64
import requests
from typing import Optional

import api
from {{app}}.model.toss_billing import TossBillingKey, TossSubscription
from {{app}}.model.toss_payment import TossPayment

TOSS_SECRET_KEY = api.secret_manager.get_secret_value('toss_secret_key')
TOSS_BASE_URL = 'https://api.tosspayments.com/v1'

INTERVAL_SECONDS = {
    'MONTHLY': 30 * 24 * 60 * 60,
    'YEARLY': 365 * 24 * 60 * 60,
}


# ============================================================
# 빌링키 관리
# ============================================================

def issue_billing_key(auth_key: str, customer_key: str, user_id: str) -> dict:
    """빌링키 발급

    클라이언트에서 결제창으로 카드 등록 후 받은 authKey로
    토스 API에 빌링키 발급을 요청하고 DB에 저장.

    Args:
        auth_key: 토스 결제창에서 받은 authKey
        customer_key: 가맹점 고객 식별 키
        user_id: 사용자 ID

    Returns:
        status, billing_key 포함 dict
    """
    response = {'status': 'failed', 'billing_key': None}

    result = _toss_issue_billing_key(auth_key, customer_key)
    if not result:
        return response

    if 'code' in result:
        response['error_code'] = result.get('code')
        response['error_message'] = result.get('message')
        return response

    billing_key_model = TossBillingKey(
        user_id=user_id,
        billing_key=result.get('billingKey'),
        customer_key=customer_key,
        card_company=result.get('card', {}).get('issuerCode'),
        card_number=result.get('card', {}).get('number'),
        card_type=result.get('card', {}).get('cardType'),
    )
    billing_key_model.put()

    response['status'] = 'succeed'
    response['billing_key'] = billing_key_model.view()
    return response


def delete_billing_key(billing_key_id: str) -> dict:
    """빌링키 비활성화 (soft delete)"""
    billing_key_model = TossBillingKey.get(billing_key_id)
    if not billing_key_model:
        return {'status': 'not_found'}

    billing_key_model.is_active = False
    billing_key_model.update()
    return {'status': 'succeed'}


# ============================================================
# 구독 관리
# ============================================================

def create_subscription(
        user_id: str, billing_key: str, customer_key: str,
        product_id: str, product_name: str,
        amount: float, currency: str = 'KRW',
        interval: str = 'MONTHLY',
) -> dict:
    """구독 생성 + 첫 결제 실행

    Args:
        user_id: 사용자 ID
        billing_key: 토스 billingKey
        product_id: 구독 상품 ID
        product_name: 구독 상품명
        amount: 결제 금액
        currency: 통화
        interval: 결제 주기 (MONTHLY, YEARLY)

    Returns:
        status, subscription, payment 포함 dict
    """
    response = {'status': 'failed', 'subscription': None, 'payment': None}

    now = time.time()
    period_seconds = INTERVAL_SECONDS.get(interval, INTERVAL_SECONDS['MONTHLY'])

    subscription = TossSubscription(
        user_id=user_id,
        product_id=product_id,
        product_name=product_name,
        billing_key=billing_key,
        customer_key=customer_key,
        amount=amount,
        currency=currency,
        interval=interval,
        status='ACTIVE',
        current_period_start=now,
        current_period_end=now + period_seconds,
    )
    subscription.put()

    # 첫 결제 실행
    payment_result = charge_subscription(subscription.id)
    if payment_result['status'] != 'succeed':
        subscription.status = 'PAYMENT_FAILED'
        subscription.update()
        response['status'] = 'payment_failed'
        response['subscription'] = subscription.view()
        response['error_code'] = payment_result.get('error_code')
        response['error_message'] = payment_result.get('error_message')
        return response

    response['status'] = 'succeed'
    response['subscription'] = subscription.view()
    response['payment'] = payment_result.get('payment')
    return response


def charge_subscription(subscription_id: str) -> dict:
    """구독 정기결제 실행

    빌링키로 결제를 실행하고 TossPayment에 기록.
    스케줄러/크론에서 주기적으로 호출.

    Args:
        subscription_id: 구독 ID

    Returns:
        status, payment 포함 dict
    """
    response = {'status': 'failed', 'payment': None}

    subscription = TossSubscription.get(subscription_id)
    if not subscription or subscription.status != 'ACTIVE':
        response['status'] = 'invalid_subscription'
        return response

    order_id = f'sub_{subscription.id}_{int(time.time())}'

    result = _toss_billing_confirm(
        billing_key=subscription.billing_key,
        customer_key=subscription.customer_key,
        amount=subscription.amount,
        order_id=order_id,
        order_name=subscription.product_name,
    )

    if not result:
        return response

    if 'code' in result:
        response['error_code'] = result.get('code')
        response['error_message'] = result.get('message')
        return response

    # 결제 내역 저장
    payment = TossPayment(
        id=result.get('paymentKey'),
        user_id=subscription.user_id,
        payment_key=result.get('paymentKey'),
        order_id=result.get('orderId'),
        order_name=result.get('orderName', ''),
        status=result.get('status', 'DONE'),
        method=result.get('method'),
        currency=result.get('currency', subscription.currency),
        total_amount=result.get('totalAmount', 0),
        balance_amount=result.get('balanceAmount', 0),
        supplied_amount=result.get('suppliedAmount', 0),
        vat=result.get('vat', 0),
        requested_at=result.get('requestedAt'),
        approved_at=result.get('approvedAt'),
        raw_response=result,
    )
    payment.put()

    # 구독 상태 갱신
    subscription.last_payment_key = payment.payment_key
    subscription.last_paid_at = time.time()
    subscription.update()

    response['status'] = 'succeed'
    response['payment'] = payment.view()
    return response


def renew_subscription(subscription_id: str) -> dict:
    """구독 갱신 (다음 기간으로 연장 + 결제)

    current_period_end가 지난 구독을 다음 기간으로 연장하고 결제 실행.
    스케줄러에서 호출.

    Args:
        subscription_id: 구독 ID

    Returns:
        status, subscription, payment 포함 dict
    """
    response = {'status': 'failed', 'subscription': None, 'payment': None}

    subscription = TossSubscription.get(subscription_id)
    if not subscription or subscription.status != 'ACTIVE':
        response['status'] = 'invalid_subscription'
        return response

    # 기간 연장
    period_seconds = INTERVAL_SECONDS.get(subscription.interval, INTERVAL_SECONDS['MONTHLY'])
    subscription.current_period_start = subscription.current_period_end
    subscription.current_period_end = subscription.current_period_start + period_seconds
    subscription.update()

    # 결제 실행
    payment_result = charge_subscription(subscription_id)
    if payment_result['status'] != 'succeed':
        subscription.status = 'PAYMENT_FAILED'
        subscription.update()
        response['status'] = 'payment_failed'
        response['subscription'] = subscription.view()
        return response

    response['status'] = 'succeed'
    response['subscription'] = subscription.view()
    response['payment'] = payment_result.get('payment')
    return response


def cancel_subscription(subscription_id: str) -> dict:
    """구독 취소

    즉시 취소되지 않고 current_period_end까지는 유지됨.

    Args:
        subscription_id: 구독 ID

    Returns:
        status, subscription 포함 dict
    """
    response = {'status': 'failed', 'subscription': None}

    subscription = TossSubscription.get(subscription_id)
    if not subscription:
        response['status'] = 'not_found'
        return response

    subscription.status = 'CANCELED'
    subscription.canceled_at = time.time()
    subscription.update()

    response['status'] = 'succeed'
    response['subscription'] = subscription.view()
    return response


# ============================================================
# 토스 API 호출
# ============================================================

def _get_auth_header() -> dict:
    credentials = base64.b64encode(f'{TOSS_SECRET_KEY}:'.encode()).decode()
    return {
        'Authorization': f'Basic {credentials}',
        'Content-Type': 'application/json',
    }


def _toss_issue_billing_key(auth_key: str, customer_key: str) -> Optional[dict]:
    """POST /v1/billing/authorizations/issue"""
    try:
        resp = requests.post(
            f'{TOSS_BASE_URL}/billing/authorizations/issue',
            headers=_get_auth_header(),
            json={
                'authKey': auth_key,
                'customerKey': customer_key,
            },
            timeout=30,
        )
        return resp.json()
    except Exception as e:
        print(f'Toss billing key issue error: {e}')
        return None


def _toss_billing_confirm(
        billing_key: str, customer_key: str,
        amount: float, order_id: str, order_name: str,
) -> Optional[dict]:
    """POST /v1/billing/{billingKey}"""
    try:
        resp = requests.post(
            f'{TOSS_BASE_URL}/billing/{billing_key}',
            headers=_get_auth_header(),
            json={
                'customerKey': customer_key,
                'amount': amount,
                'orderId': order_id,
                'orderName': order_name,
            },
            timeout=60,
        )
        return resp.json()
    except Exception as e:
        print(f'Toss billing confirm error: {e}')
        return None
