"""
구독 관리 서비스

Apple/Google 웹훅 데이터를 받아서 구독 상태를 저장/갱신합니다.
"""
import time
import base64
import json
import jwt
from typing import Optional

from {{app}}.model.subscription.apple_subscription import AppleSubscription, AppleRevocation
from {{app}}.model.subscription.google_subscription import GoogleSubscription, GoogleRevocation


# ============================================================
# Apple 웹훅 처리
# ============================================================

def handle_apple_webhook(signed_payload: str) -> dict:
    """Apple App Store Server Notification v2 웹훅 처리

    signed_payload(JWT)를 디코딩하여:
    1. REFUND 알림이면 AppleRevocation 생성
    2. 구독 정보를 AppleSubscription에 저장/갱신

    Args:
        signed_payload: Apple이 보내는 signedPayload (JWT)

    Returns:
        저장된 구독 정보 또는 에러 상태
    """
    response = {'status': 'failed', 'item': None}

    # 환불 처리 (REFUND 알림이면 적용)
    _handle_apple_revocation(signed_payload)

    # 영수증 파싱 (ASSN v2 → v1 호환 형식으로 변환)
    receipt_info = _extract_apple_receipt(signed_payload)
    if not receipt_info:
        return response

    latest_receipt_info = receipt_info.get('latest_receipt_info', [])
    if not latest_receipt_info:
        return response

    # original_transaction_id로 기존 구독에서 user_id 추정
    original_transaction_id = receipt_info.get('original_transaction_id')
    user_id = _find_apple_user_id(original_transaction_id)
    if not user_id:
        response['status'] = 'user_not_found'
        return response

    # 구독 저장
    subscription = _save_apple_subscription(receipt_info, user_id)
    response['status'] = 'succeed'
    response['item'] = subscription.view() if subscription else None
    return response


def validate_apple_receipt_for_user(receipt_info: dict, user_id: str) -> Optional[AppleSubscription]:
    """클라이언트가 직접 제출한 영수증 검증 결과를 저장

    클라이언트에서 Apple 영수증 검증 후 결과를 서버에 전달하는 경우 사용.
    (웹훅과 달리 user_id를 클라이언트에서 알고 있음)

    Args:
        receipt_info: Apple 영수증 검증 결과 (latest_receipt_info 포함)
        user_id: 사용자 ID

    Returns:
        저장된 AppleSubscription 또는 None
    """
    return _save_apple_subscription(receipt_info, user_id)


# ============================================================
# Google 웹훅 처리
# ============================================================

def handle_google_webhook(message: dict) -> dict:
    """Google Play Developer Notification (Pub/Sub) 웹훅 처리

    base64 인코딩된 message.data를 디코딩하여:
    1. voidedPurchaseNotification이면 GoogleRevocation 생성
    2. subscriptionNotification이면 구독 정보를 GoogleSubscription에 저장/갱신

    Google 웹훅에서는 구독 상태를 직접 알려주지 않고
    purchase_token과 subscription_id만 전달하므로,
    실제 구독 상태는 Google Play Developer API를 호출해서 확인해야 함.
    이 보일러플레이트에서는 메시지 파싱 + 저장 구조만 제공.

    Args:
        message: Google Pub/Sub 메시지 (data 필드에 base64 인코딩된 JSON)

    Returns:
        파싱된 결과 및 상태
    """
    response = {'status': 'failed', 'item': None}

    base64_data = message.get('data')
    if not base64_data:
        return response

    decoded = base64.b64decode(base64_data).decode('utf-8')
    payload = json.loads(decoded)

    # 환불 처리
    _handle_google_revocation(payload)

    # 구독 알림 처리
    notification = payload.get('subscriptionNotification')
    if not notification:
        return response

    purchase_token = notification.get('purchaseToken')
    subscription_id = notification.get('subscriptionId')

    # 기존 구독에서 user_id 추정
    user_id = _find_google_user_id(purchase_token)
    if not user_id:
        response['status'] = 'user_not_found'
        return response

    # TODO: Google Play Developer API로 실제 구독 상태 조회 후 저장
    # receipt = verify_google_subscription(subscription_id, purchase_token)
    # subscription = _save_google_subscription(receipt, user_id, subscription_id, purchase_token)

    response['status'] = 'succeed'
    response['purchase_token'] = purchase_token
    response['subscription_id'] = subscription_id
    response['user_id'] = user_id
    return response


def save_google_subscription_for_user(
        receipt: dict, user_id: str,
        subscription_id: str, purchase_token: str,
) -> Optional[GoogleSubscription]:
    """Google Play 구독 검증 결과를 저장

    클라이언트에서 purchase_token으로 서버에 검증 요청 →
    서버가 Google Play Developer API로 검증 →
    그 결과를 이 함수로 저장.

    Args:
        receipt: Google Play Developer API 응답
        user_id: 사용자 ID
        subscription_id: 구독 상품 ID
        purchase_token: 구매 토큰

    Returns:
        저장된 GoogleSubscription 또는 None
    """
    return _save_google_subscription(receipt, user_id, subscription_id, purchase_token)


# ============================================================
# Apple 내부 헬퍼
# ============================================================

def _extract_apple_receipt(signed_payload: str) -> Optional[dict]:
    """ASSN v2 signedPayload에서 영수증 정보 추출 (v1 호환 형식)"""
    try:
        decoded = jwt.decode(signed_payload, options={"verify_signature": False})
        data = decoded.get("data", {})
        environment = data.get("environment", "Unknown")

        latest_receipt_info = []
        original_transaction_id = None

        signed_tx = data.get("signedTransactionInfo")
        if signed_tx:
            tx = jwt.decode(signed_tx, options={"verify_signature": False})
            original_transaction_id = tx.get("originalTransactionId")
            latest_receipt_info.append({
                "transaction_id": tx.get("transactionId"),
                "original_transaction_id": original_transaction_id,
                "product_id": tx.get("productId"),
                "purchase_date_ms": tx.get("purchaseDate"),
                "expires_date_ms": tx.get("expiresDate"),
                "quantity": 1,
                "is_trial_period": "false",
                "is_in_intro_offer_period": "false",
            })

        pending_renewal_info = []
        signed_renewal = data.get("signedRenewalInfo")
        if signed_renewal:
            r = jwt.decode(signed_renewal, options={"verify_signature": False})
            pending_renewal_info.append({
                "original_transaction_id": r.get("originalTransactionId"),
                "auto_renew_status": str(int(r.get("autoRenewStatus", 0))),
                "auto_renew_product_id": r.get("autoRenewProductId"),
                "is_in_billing_retry_period": str(r.get("isInBillingRetryPeriod", False)).lower(),
            })

        return {
            "latest_receipt_info": latest_receipt_info,
            "pending_renewal_info": pending_renewal_info,
            "environment": environment,
            "original_transaction_id": original_transaction_id,
        }
    except Exception as e:
        print(f'Apple receipt extract error: {e}')
        return None


def _handle_apple_revocation(signed_payload: str):
    """REFUND 알림이면 AppleRevocation 생성"""
    try:
        decoded = jwt.decode(signed_payload, options={"verify_signature": False})
        if decoded.get("notificationType") != 'REFUND':
            return

        data = decoded.get("data", {})
        signed_tx = data.get("signedTransactionInfo")
        tx = jwt.decode(signed_tx, options={"verify_signature": False})

        revocation = AppleRevocation(
            id=tx.get("originalTransactionId"),
            original_transaction_id=tx.get("originalTransactionId"),
            product_id=tx.get("productId"),
            revocation_reason=tx.get("revocationReason"),
            revocation_date=tx.get("revocationDate", 0),
            raw_transaction=tx,
            environment=tx.get("environment", "Unknown"),
        )
        revocation.put()
    except Exception as e:
        print(f'Apple revocation handling error: {e}')


def _find_apple_user_id(original_transaction_id: str) -> Optional[str]:
    """original_transaction_id로 기존 구독의 user_id 추정"""
    if not original_transaction_id:
        return None
    subs = AppleSubscription.generate(
        pk_field='original_transaction_id', pk_value=original_transaction_id,
        sk_field='crt', reverse=True,
    )
    for sub in subs:
        return sub.user_id
    return None


def _save_apple_subscription(receipt_info: dict, user_id: str) -> Optional[AppleSubscription]:
    """영수증 정보로 AppleSubscription 저장"""
    infos = receipt_info.get('latest_receipt_info', [])
    if not infos:
        return None

    sorted_infos = sorted(infos, key=lambda x: int(x.get('expires_date_ms', 0)), reverse=True)
    latest = sorted_infos[0]

    renew_list = receipt_info.get('pending_renewal_info', [])
    renew = next(
        (r for r in renew_list if r.get('original_transaction_id') == latest.get('original_transaction_id')),
        {}
    )

    subscription = AppleSubscription(
        id=latest.get("transaction_id"),
        user_id=user_id,
        crt=int(latest.get("purchase_date_ms", 0)) / 1000,
        product_id=latest.get("product_id"),
        original_transaction_id=latest.get("original_transaction_id"),
        transaction_id=latest.get("transaction_id"),
        purchase_date_ms=int(latest.get("purchase_date_ms", 0)),
        expires_date_ms=int(latest.get("expires_date_ms", 0)),
        is_trial_period=latest.get("is_trial_period") == "true",
        is_intro_offer=latest.get("is_in_intro_offer_period") == "true",
        auto_renew_status=int(renew.get("auto_renew_status", -1)),
        auto_renew_product_id=renew.get("auto_renew_product_id", ''),
        is_in_billing_retry=renew.get("is_in_billing_retry_period") == "true",
        raw_receipt_json=latest,
        environment=receipt_info.get('environment', 'Production'),
    )
    subscription.put()
    return subscription


# ============================================================
# Google 내부 헬퍼
# ============================================================

def _handle_google_revocation(payload: dict):
    """voidedPurchaseNotification이면 GoogleRevocation 생성"""
    try:
        voided = payload.get('voidedPurchaseNotification')
        if not voided:
            return

        revocation = GoogleRevocation(
            id=voided.get('orderId', ''),
            purchase_token=voided.get('purchaseToken', ''),
            order_id=voided.get('orderId', ''),
            product_type=voided.get('productType'),
            refund_type=voided.get('refundType'),
        )
        revocation.put()
    except Exception as e:
        print(f'Google revocation handling error: {e}')


def _find_google_user_id(purchase_token: str) -> Optional[str]:
    """purchase_token으로 기존 구독의 user_id 추정"""
    if not purchase_token:
        return None
    subs = GoogleSubscription.generate(
        pk_field='purchase_token', pk_value=purchase_token,
        sk_field='crt', reverse=True,
    )
    for sub in subs:
        return sub.user_id
    return None


def _save_google_subscription(
        receipt: dict, user_id: str,
        subscription_id: str, purchase_token: str,
) -> Optional[GoogleSubscription]:
    """Google Play API 응답으로 GoogleSubscription 저장"""
    if not receipt or "expiryTimeMillis" not in receipt:
        return None

    subscription = GoogleSubscription(
        id=receipt.get("orderId", f"{user_id}-{int(time.time())}"),
        user_id=user_id,
        crt=int(receipt.get("startTimeMillis", 0)) / 1000,
        subscription_id=subscription_id,
        purchase_token=purchase_token,
        order_id=receipt.get("orderId", ''),
        start_time_ms=int(receipt.get("startTimeMillis", 0)),
        expiry_time_ms=int(receipt.get("expiryTimeMillis", 0)),
        auto_renewing=receipt.get("autoRenewing", False),
        acknowledged=receipt.get("acknowledgementState") == 1,
        payment_state=int(receipt.get("paymentState", -1)),
        price_amount_micros=int(receipt.get("priceAmountMicros", 0)),
        price_currency_code=receipt.get("priceCurrencyCode", "USD"),
    )
    subscription.put()
    return subscription
