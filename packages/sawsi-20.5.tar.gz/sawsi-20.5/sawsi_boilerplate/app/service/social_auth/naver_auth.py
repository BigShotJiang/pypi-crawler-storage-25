"""
네이버 OAuth 토큰 검증 서비스
"""
import requests
from typing import Optional


class NaverUserInfo:
    """네이버 사용자 정보"""

    def __init__(self, sub: str, email: str = None, name: str = None, profile_image: str = None):
        self.sub = sub  # 네이버 고유 사용자 ID
        self.email = email
        self.name = name
        self.profile_image = profile_image


def verify_naver_access_token(access_token: str) -> Optional[NaverUserInfo]:
    """
    네이버 Access 토큰으로 사용자 정보를 가져옵니다.

    네이버는 ID 토큰 방식이 아닌 Access 토큰으로 프로필 API를 호출하는 방식입니다.

    :param access_token: 네이버 OAuth에서 받은 Access 토큰
    :return: NaverUserInfo 또는 None (검증 실패 시)
    """
    try:
        response = requests.get(
            'https://openapi.naver.com/v1/nid/me',
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=10
        )

        if response.status_code != 200:
            return None

        data = response.json()

        if data.get('resultcode') != '00':
            return None

        profile = data.get('response', {})

        return NaverUserInfo(
            sub=profile.get('id'),
            email=profile.get('email'),
            name=profile.get('name', ''),
            profile_image=profile.get('profile_image')
        )

    except Exception as e:
        print(f'Naver token verification error: {e}')
        return None
