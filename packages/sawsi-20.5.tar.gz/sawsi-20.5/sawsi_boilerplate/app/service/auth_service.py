import hashlib
from typing import Optional
from secrets import token_urlsafe

from {{app}}.model.user import User
from {{app}}.model.user_session import UserSession, DeviceInfo
from sawsi.shared import hash_util


def get_me(session_id: str, o_c: str = None, req_ts: int = None) -> Optional[User]:
    """세션 ID로 사용자 조회

    클라이언트에서 받은 원본 session_id를 해시하여 DB 조회.
    DB에는 해시된 세션 ID가 저장되어 있음.
    보안 세션인 경우 o_c (OTP code) 검증을 추가로 수행.

    Args:
        session_id: 원본 세션 토큰 (클라이언트에서 전달받은 값)
        o_c: OTP 코드 (보안 세션인 경우 필수)
        req_ts: 요청 타임스탬프 (보안 세션인 경우 필수)

    Returns:
        User 객체 또는 None (세션 없거나 만료된 경우)

    Raises:
        보안 세션에서 OTP 검증 실패 시 ValueError
    """
    if not session_id:
        return None

    session_id_hash = hash_util.hash_password(session_id)
    session = UserSession.get(session_id_hash)
    if not session:
        return None

    # 보안 세션이면 OTP 검증
    validate_secure(o_c, session, req_ts)

    user = User.get(session.user_id)
    return user


def register(
        email: str, password: str, name: str,
        source_ip: str, device_info: Optional[dict] = None,
) -> dict:
    """이메일/비밀번호 회원가입

    Args:
        email: 이메일 주소
        password: 비밀번호 (평문)
        name: 사용자 이름
        source_ip: 요청 IP
        device_info: 디바이스 정보

    Returns:
        status, user_id, session_id 포함 dict
    """
    response = {
        'status': 'failed',
        'user_id': None,
        'session_id': None,
    }

    # 이미 가입된 이메일인지 확인
    existing = list(User.generate('email', email))
    if existing:
        response['status'] = 'already_registered'
        return response

    password_salt = hash_util.make_salt().decode('utf-8')
    password_hash = hash_util.hash_password(f'{password_salt}|{password}')

    user = User(
        name=name,
        email=email,
        password_hash=password_hash,
        password_salt=password_salt,
    )
    user.put()
    response['user_id'] = user.id

    # 가입 후 자동 로그인
    session_id = _create_user_session(user.id, source_ip, device_info)
    response['session_id'] = session_id
    response['status'] = 'succeed'
    return response


def login(
        email: str, password: str,
        source_ip: str, device_info: Optional[dict] = None,
) -> dict:
    """이메일/비밀번호 로그인

    Args:
        email: 이메일 주소
        password: 비밀번호 (평문)
        source_ip: 요청 IP
        device_info: 디바이스 정보

    Returns:
        status, user_id, session_id 포함 dict
    """
    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
    }

    users = list(User.generate(pk_field='email', pk_value=email))
    if not users:
        response['status'] = 'no_such_user'
        return response

    user = users[0]
    curr_password_hash = hash_util.hash_password(f'{user.password_salt}|{password}')
    if curr_password_hash != user.password_hash:
        return response

    session_id = _create_user_session(user.id, source_ip, device_info)
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['status'] = 'succeed'
    return response


def login_as_google(
        id_token: str,
        source_ip: str, device_info: Optional[dict] = None,
) -> dict:
    """Google OAuth 로그인 (미가입 유저는 자동 가입)

    Args:
        id_token: Google Sign-In에서 받은 ID 토큰
        source_ip: 요청 IP
        device_info: 디바이스 정보

    Returns:
        status, user_id, session_id, is_new_user 포함 dict
    """
    from {{app}}.service.social_auth.google_auth import verify_google_id_token

    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'is_new_user': False,
    }

    google_user = verify_google_id_token(id_token)
    if not google_user:
        response['status'] = 'invalid_token'
        return response

    # 기존 유저 찾기
    users = list(User.generate(pk_field='google_sub', pk_value=google_user.sub))
    if users:
        user = users[0]
    else:
        # 새 유저 생성
        user = User(
            name=google_user.name or '',
            email=google_user.email,
            google_sub=google_user.sub,
        )
        user.put()
        response['is_new_user'] = True

    session_id = _create_user_session(user.id, source_ip, device_info)
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['status'] = 'succeed'
    return response


def login_as_google_with_secure(
        id_token: str,
        source_ip: str, c_ts: int, req_ts: int,
        device_info: Optional[dict] = None,
) -> dict:
    """Google OAuth 보안 세션 로그인 (미가입 유저는 자동 가입)"""
    from {{app}}.service.social_auth.google_auth import verify_google_id_token

    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'is_new_user': False,
        'o_s': None,
    }

    google_user = verify_google_id_token(id_token)
    if not google_user:
        response['status'] = 'invalid_token'
        return response

    users = list(User.generate(pk_field='google_sub', pk_value=google_user.sub))
    if users:
        user = users[0]
    else:
        user = User(
            name=google_user.name or '',
            email=google_user.email,
            google_sub=google_user.sub,
        )
        user.put()
        response['is_new_user'] = True

    session_id, user_session = _create_user_session_secure(
        user.id, source_ip, device_info, c_ts, req_ts
    )
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['o_s'] = user_session.otp_secret
    response['status'] = 'succeed'
    return response


def login_as_apple(
        id_token: str,
        source_ip: str, user_name: str = None,
        device_info: Optional[dict] = None,
) -> dict:
    """Apple Sign-In 로그인 (미가입 유저는 자동 가입)

    Apple은 최초 로그인 시에만 이름을 제공하므로, 클라이언트에서 user_name을 별도 전달해야 함.

    Args:
        id_token: Apple Sign-In에서 받은 Identity Token
        source_ip: 요청 IP
        user_name: 클라이언트에서 전달받은 사용자 이름 (최초 로그인 시만 제공)
        device_info: 디바이스 정보

    Returns:
        status, user_id, session_id, is_new_user 포함 dict
    """
    from {{app}}.service.social_auth.apple_auth import verify_apple_id_token

    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'is_new_user': False,
    }

    apple_user = verify_apple_id_token(id_token, user_name=user_name)
    if not apple_user:
        response['status'] = 'invalid_token'
        return response

    # 기존 유저 찾기
    users = list(User.generate(pk_field='apple_sub', pk_value=apple_user.sub))
    if users:
        user = users[0]
    else:
        # 새 유저 생성
        user = User(
            name=apple_user.name or '',
            email=apple_user.email,
            apple_sub=apple_user.sub,
        )
        user.put()
        response['is_new_user'] = True

    session_id = _create_user_session(user.id, source_ip, device_info)
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['status'] = 'succeed'
    return response


def login_as_apple_with_secure(
        id_token: str,
        source_ip: str, c_ts: int, req_ts: int,
        user_name: str = None,
        device_info: Optional[dict] = None,
) -> dict:
    """Apple Sign-In 보안 세션 로그인 (미가입 유저는 자동 가입)"""
    from {{app}}.service.social_auth.apple_auth import verify_apple_id_token

    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'is_new_user': False,
        'o_s': None,
    }

    apple_user = verify_apple_id_token(id_token, user_name=user_name)
    if not apple_user:
        response['status'] = 'invalid_token'
        return response

    users = list(User.generate(pk_field='apple_sub', pk_value=apple_user.sub))
    if users:
        user = users[0]
    else:
        user = User(
            name=apple_user.name or '',
            email=apple_user.email,
            apple_sub=apple_user.sub,
        )
        user.put()
        response['is_new_user'] = True

    session_id, user_session = _create_user_session_secure(
        user.id, source_ip, device_info, c_ts, req_ts
    )
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['o_s'] = user_session.otp_secret
    response['status'] = 'succeed'
    return response


def login_as_naver(
        access_token: str,
        source_ip: str, device_info: Optional[dict] = None,
) -> dict:
    """네이버 OAuth 로그인 (미가입 유저는 자동 가입)

    네이버는 ID 토큰이 아닌 Access 토큰 방식을 사용.

    Args:
        access_token: 네이버 OAuth에서 받은 Access 토큰
        source_ip: 요청 IP
        device_info: 디바이스 정보

    Returns:
        status, user_id, session_id, is_new_user 포함 dict
    """
    from {{app}}.service.social_auth.naver_auth import verify_naver_access_token

    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'is_new_user': False,
    }

    naver_user = verify_naver_access_token(access_token)
    if not naver_user:
        response['status'] = 'invalid_token'
        return response

    # 기존 유저 찾기
    users = list(User.generate(pk_field='naver_sub', pk_value=naver_user.sub))
    if users:
        user = users[0]
    else:
        # 새 유저 생성
        user = User(
            name=naver_user.name or '',
            email=naver_user.email,
            naver_sub=naver_user.sub,
        )
        user.put()
        response['is_new_user'] = True

    session_id = _create_user_session(user.id, source_ip, device_info)
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['status'] = 'succeed'
    return response


def login_as_naver_with_secure(
        access_token: str,
        source_ip: str, c_ts: int, req_ts: int,
        device_info: Optional[dict] = None,
) -> dict:
    """네이버 OAuth 보안 세션 로그인 (미가입 유저는 자동 가입)"""
    from {{app}}.service.social_auth.naver_auth import verify_naver_access_token

    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'is_new_user': False,
        'o_s': None,
    }

    naver_user = verify_naver_access_token(access_token)
    if not naver_user:
        response['status'] = 'invalid_token'
        return response

    users = list(User.generate(pk_field='naver_sub', pk_value=naver_user.sub))
    if users:
        user = users[0]
    else:
        user = User(
            name=naver_user.name or '',
            email=naver_user.email,
            naver_sub=naver_user.sub,
        )
        user.put()
        response['is_new_user'] = True

    session_id, user_session = _create_user_session_secure(
        user.id, source_ip, device_info, c_ts, req_ts
    )
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['o_s'] = user_session.otp_secret
    response['status'] = 'succeed'
    return response


def login_as_kakao(
        access_token: str,
        source_ip: str, device_info: Optional[dict] = None,
) -> dict:
    """카카오 OAuth 로그인 (미가입 유저는 자동 가입)

    카카오는 ID 토큰이 아닌 Access 토큰 방식을 사용.

    Args:
        access_token: 카카오 OAuth에서 받은 Access 토큰
        source_ip: 요청 IP
        device_info: 디바이스 정보

    Returns:
        status, user_id, session_id, is_new_user 포함 dict
    """
    from {{app}}.service.social_auth.kakao_auth import verify_kakao_access_token

    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'is_new_user': False,
    }

    kakao_user = verify_kakao_access_token(access_token)
    if not kakao_user:
        response['status'] = 'invalid_token'
        return response

    # 기존 유저 찾기
    users = list(User.generate(pk_field='kakao_sub', pk_value=kakao_user.sub))
    if users:
        user = users[0]
    else:
        # 새 유저 생성
        user = User(
            name=kakao_user.name or '',
            email=kakao_user.email,
            kakao_sub=kakao_user.sub,
        )
        user.put()
        response['is_new_user'] = True

    session_id = _create_user_session(user.id, source_ip, device_info)
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['status'] = 'succeed'
    return response


def login_as_kakao_with_secure(
        access_token: str,
        source_ip: str, c_ts: int, req_ts: int,
        device_info: Optional[dict] = None,
) -> dict:
    """카카오 OAuth 보안 세션 로그인 (미가입 유저는 자동 가입)"""
    from {{app}}.service.social_auth.kakao_auth import verify_kakao_access_token

    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'is_new_user': False,
        'o_s': None,
    }

    kakao_user = verify_kakao_access_token(access_token)
    if not kakao_user:
        response['status'] = 'invalid_token'
        return response

    users = list(User.generate(pk_field='kakao_sub', pk_value=kakao_user.sub))
    if users:
        user = users[0]
    else:
        user = User(
            name=kakao_user.name or '',
            email=kakao_user.email,
            kakao_sub=kakao_user.sub,
        )
        user.put()
        response['is_new_user'] = True

    session_id, user_session = _create_user_session_secure(
        user.id, source_ip, device_info, c_ts, req_ts
    )
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['o_s'] = user_session.otp_secret
    response['status'] = 'succeed'
    return response


def login_with_secure(
        email: str, password: str,
        source_ip: str, c_ts: int, req_ts: int,
        device_info: Optional[dict] = None,
) -> dict:
    """보안 세션으로 로그인 (OTP 검증 요구 세션 생성)

    이 메소드로 로그인하면 이후 get_me 등 세션 기반 요청 시
    매 요청마다 o_c (OTP code)와 req_ts를 함께 보내야 함.

    클라이언트는 응답의 o_s (otp_secret)를 저장하고,
    sha256(otp_secret + timestamp) 로 o_c를 생성하여 매 요청에 포함.

    Args:
        email: 이메일 주소
        password: 비밀번호 (평문)
        source_ip: 요청 IP
        c_ts: 클라이언트 타임스탬프 (서버-클라 시간차 보정용)
        req_ts: 서버 요청 타임스탬프
        device_info: 디바이스 정보

    Returns:
        status, user_id, session_id, o_s 포함 dict
    """
    response = {
        'status': 'failed',
        'session_id': None,
        'user_id': None,
        'o_s': None,
    }

    users = list(User.generate(pk_field='email', pk_value=email))
    if not users:
        response['status'] = 'no_such_user'
        return response

    user = users[0]
    curr_password_hash = hash_util.hash_password(f'{user.password_salt}|{password}')
    if curr_password_hash != user.password_hash:
        return response

    session_id, user_session = _create_user_session_secure(
        user.id, source_ip, device_info, c_ts, req_ts
    )
    response['user_id'] = user.id
    response['session_id'] = session_id
    response['o_s'] = user_session.otp_secret
    response['status'] = 'succeed'
    return response


# --- 세션 생성 헬퍼 ---

def _create_user_session(user_id: str, source_ip: str, device_info: Optional[dict] = None) -> str:
    """일반 세션 생성 후 원본 세션 토큰 반환

    DB에는 해시된 토큰이 저장되고, 클라이언트에는 원본 토큰을 반환.
    """
    token = token_urlsafe(32)
    token_hash = hash_util.hash_password(token)
    user_session = UserSession(
        id=token_hash,
        user_id=user_id,
        source_ip=source_ip,
        device_info=DeviceInfo(**(device_info or {})),
    )
    user_session.put()
    return token


def _create_user_session_secure(
        user_id: str, source_ip: str,
        device_info: Optional[dict] = None,
        c_ts: int = None, req_ts: int = None,
) -> tuple:
    """보안 세션 생성. (원본 토큰, UserSession) 튜플 반환.

    use_secure=True로 생성되어 이후 요청마다 OTP 검증을 요구함.
    ts_offset은 서버시간 - 클라시간으로, OTP 검증 시 시간 보정에 사용.
    """
    token = token_urlsafe(32)
    token_hash = hash_util.hash_password(token)
    ts_offset = int(req_ts - c_ts) if c_ts else 0
    user_session = UserSession(
        id=token_hash,
        user_id=user_id,
        source_ip=source_ip,
        device_info=DeviceInfo(**(device_info or {})),
        use_secure=True,
        ts_offset=ts_offset,
    )
    user_session.put()
    return token, user_session


# --- OTP 보안 검증 ---

def validate_secure(o_c: str, session: UserSession, req_ts: int = None):
    """보안 세션의 OTP 코드(o_c) 검증

    use_secure=False인 세션이면 바로 통과.
    use_secure=True인 세션이면 o_c를 검증하여 실패 시 ValueError 발생.

    검증 방식: 서버 시간을 ts_offset으로 보정한 뒤,
    ±45초 윈도우 내에서 hash(otp_secret + timestamp)가 o_c와 일치하는지 확인.
    """
    if not session.use_secure:
        return True

    if not o_c or not req_ts:
        raise ValueError('보안 세션은 o_c와 req_ts가 필수입니다')

    std_ts = req_ts - session.ts_offset
    sec_window = 45
    for target_time in range(std_ts - sec_window, std_ts + sec_window):
        target_o_c = _create_o_c(session.otp_secret, target_time)
        if target_o_c == o_c:
            return True

    raise ValueError('OTP 검증 실패')


def _create_o_c(o_s: str, target_time: int) -> str:
    """OTP 코드 생성: sha256(otp_secret + timestamp)"""
    return hashlib.sha256((str(o_s) + str(target_time)).encode('utf-8')).hexdigest()
