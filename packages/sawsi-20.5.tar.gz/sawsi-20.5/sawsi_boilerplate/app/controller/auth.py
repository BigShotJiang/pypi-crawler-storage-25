from typing import Optional
from sawsi.handler.controller_decorator import controller
from {{app}}.service import auth_service


@controller
def register(
        email: str, password: str, name: str,
        source_ip: str, device_info: Optional[dict] = None,
):
    """이메일/비밀번호 회원가입"""
    return auth_service.register(
        email=email, password=password, name=name,
        source_ip=source_ip, device_info=device_info,
    )


@controller
def login(
        email: str, password: str,
        source_ip: str, device_info: Optional[dict] = None,
):
    """이메일/비밀번호 로그인"""
    return auth_service.login(
        email=email, password=password,
        source_ip=source_ip, device_info=device_info,
    )


@controller
def login_with_secure(
        email: str, password: str,
        source_ip: str, c_ts: int, req_ts: int,
        device_info: Optional[dict] = None,
):
    """보안 세션 로그인 (OTP 검증 요구)"""
    return auth_service.login_with_secure(
        email=email, password=password,
        source_ip=source_ip, c_ts=c_ts, req_ts=req_ts,
        device_info=device_info,
    )


@controller
def login_as_google(
        id_token: str,
        source_ip: str, device_info: Optional[dict] = None,
):
    """Google OAuth 로그인"""
    return auth_service.login_as_google(
        id_token=id_token,
        source_ip=source_ip, device_info=device_info,
    )


@controller
def login_as_apple(
        id_token: str,
        source_ip: str, user_name: str = None,
        device_info: Optional[dict] = None,
):
    """Apple Sign-In 로그인"""
    return auth_service.login_as_apple(
        id_token=id_token,
        source_ip=source_ip, user_name=user_name,
        device_info=device_info,
    )


@controller
def login_as_google_with_secure(
        id_token: str,
        source_ip: str, c_ts: int, req_ts: int,
        device_info: Optional[dict] = None,
):
    """Google OAuth 보안 세션 로그인"""
    return auth_service.login_as_google_with_secure(
        id_token=id_token,
        source_ip=source_ip, c_ts=c_ts, req_ts=req_ts,
        device_info=device_info,
    )


@controller
def login_as_apple_with_secure(
        id_token: str,
        source_ip: str, c_ts: int, req_ts: int,
        user_name: str = None,
        device_info: Optional[dict] = None,
):
    """Apple Sign-In 보안 세션 로그인"""
    return auth_service.login_as_apple_with_secure(
        id_token=id_token,
        source_ip=source_ip, c_ts=c_ts, req_ts=req_ts,
        user_name=user_name, device_info=device_info,
    )


@controller
def login_as_naver(
        access_token: str,
        source_ip: str, device_info: Optional[dict] = None,
):
    """네이버 OAuth 로그인"""
    return auth_service.login_as_naver(
        access_token=access_token,
        source_ip=source_ip, device_info=device_info,
    )


@controller
def login_as_naver_with_secure(
        access_token: str,
        source_ip: str, c_ts: int, req_ts: int,
        device_info: Optional[dict] = None,
):
    """네이버 OAuth 보안 세션 로그인"""
    return auth_service.login_as_naver_with_secure(
        access_token=access_token,
        source_ip=source_ip, c_ts=c_ts, req_ts=req_ts,
        device_info=device_info,
    )


@controller
def login_as_kakao(
        access_token: str,
        source_ip: str, device_info: Optional[dict] = None,
):
    """카카오 OAuth 로그인"""
    return auth_service.login_as_kakao(
        access_token=access_token,
        source_ip=source_ip, device_info=device_info,
    )


@controller
def login_as_kakao_with_secure(
        access_token: str,
        source_ip: str, c_ts: int, req_ts: int,
        device_info: Optional[dict] = None,
):
    """카카오 OAuth 보안 세션 로그인"""
    return auth_service.login_as_kakao_with_secure(
        access_token=access_token,
        source_ip=source_ip, c_ts=c_ts, req_ts=req_ts,
        device_info=device_info,
    )


@controller
def get_me(session_id: str, o_c: str = None, req_ts: int = None):
    """현재 사용자 정보 조회"""
    user = auth_service.get_me(session_id=session_id, o_c=o_c, req_ts=req_ts)
    return {
        'user': user.view() if user else None
    }
