from sawsi.handler.controller_decorator import controller
from {{app}}.model.user import User
from {{app}}.model.toss_billing import TossBillingKey, TossSubscription
from {{app}}.service import toss_billing_service


@controller
def issue_toss_billing_key(user: User, auth_key: str, customer_key: str):
    """빌링키 발급 (카드 등록)"""
    return toss_billing_service.issue_billing_key(
        auth_key=auth_key, customer_key=customer_key,
        user_id=user.id,
    )


@controller
def delete_toss_billing_key(user: User, billing_key_id: str):
    """빌링키 삭제"""
    return toss_billing_service.delete_billing_key(billing_key_id=billing_key_id)


@controller
def list_toss_billing_keys(user: User):
    """내 빌링키 목록 조회"""
    items = TossBillingKey.generate(
        pk_field='user_id', pk_value=user.id,
        sk_field='crt', reverse=True,
    )
    return {
        'items': [item.view() for item in items if item.is_active],
    }


@controller
def create_toss_subscription(
        user: User, billing_key: str, customer_key: str,
        product_id: str, product_name: str,
        amount: float, currency: str = 'KRW',
        interval: str = 'MONTHLY',
):
    """정기결제 구독 생성 + 첫 결제"""
    return toss_billing_service.create_subscription(
        user_id=user.id, billing_key=billing_key, customer_key=customer_key,
        product_id=product_id, product_name=product_name,
        amount=amount, currency=currency, interval=interval,
    )


@controller
def cancel_toss_subscription(user: User, subscription_id: str):
    """정기결제 구독 취소"""
    return toss_billing_service.cancel_subscription(subscription_id=subscription_id)


@controller
def list_toss_subscriptions(user: User):
    """내 구독 목록 조회"""
    items = TossSubscription.generate(
        pk_field='user_id', pk_value=user.id,
        sk_field='crt', reverse=True,
    )
    return {
        'items': [item.view() for item in items],
    }
