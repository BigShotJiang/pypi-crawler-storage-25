"""
Flask 기반 로컬 개발 서버 (로컬 테스팅용)

Usage:
    python local_server.py

클라이언트에서는 API URL을 http://localhost:PORT 으로 설정하면 됩니다.
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import traceback

# main handler import
from {{app}}.aws_handler import handler as main_handler

app = Flask(__name__)
PORT = 8000


@app.route('/', methods=['OPTIONS'])
def handle_options():
    """CORS preflight 요청 처리"""
    print("\n" + "="*60)
    print("[LOCAL SERVER] 🔍 OPTIONS preflight request received!")
    print("="*60)
    print(f"[LOCAL SERVER] Origin: {request.headers.get('Origin')}")
    print(f"[LOCAL SERVER] Access-Control-Request-Method: {request.headers.get('Access-Control-Request-Method')}")
    print('request.headers:', request.headers)
    # 브라우저가 요청한 헤더 리스트를 그대로 사용
    requested_headers = request.headers.get('Access-Control-Request-Headers', '')
    print(f"[LOCAL SERVER] Access-Control-Request-Headers: {requested_headers}")

    response = jsonify({'status': 'ok'})
    print('response.headers:', response.headers)
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'POST,OPTIONS'
    # 브라우저가 요청한 헤더를 그대로 허용 (대소문자 매칭 문제 해결)
    response.headers['Access-Control-Allow-Headers'] = '*'
    response.headers['Access-Control-Max-Age'] = '0'  # 캐시 비활성화

    print(f"[LOCAL SERVER] ✅ Responding with: Allow-Headers={response.headers.get('Access-Control-Allow-Headers')}")
    print("="*60 + "\n")
    return response


@app.route('/', methods=['POST'])
def handle_main_request():
    """
    POST 요청을 받아서 Lambda handler로 전달

    클라이언트 요청 형식:
    {
        "cmd": "{{app}}.controller.auth.login",
        "email": "user@example.com",
        "password": "password"
    }
    """
    try:
        # 클라이언트에서 보낸 JSON body
        body = request.get_json()
        if not body:
            return jsonify({'error': 'No JSON body provided'}), 400
        print('body request.headers:', request)
        # Lambda event 형식으로 변환
        # AWS Lambda는 헤더를 소문자로 변환하므로 동일하게 처리
        headers_lower = {k.lower(): v for k, v in request.headers.items()}
        # headers 우선, body fallback으로 session_id 추출
        # HTTP 헤더에서 underscore가 hyphen으로 변환될 수 있으므로 둘 다 체크
        headers_lower['session_id'] = (
            headers_lower.get('session_id') or
            headers_lower.get('session-id') or
            body.get('session_id')
        )
        event = {
            'body': json.dumps(body),
            'headers': headers_lower,
            'requestContext': {
                'requestId': 'local-dev-request'
            }
        }

        print(f"\n[LOCAL SERVER] Incoming request: cmd={body.get('cmd', 'N/A')}")
        print(f"[LOCAL SERVER] session_id: {headers_lower.get('session_id', 'None')[:20] if headers_lower.get('session_id') else 'None'}...")

        # WSGI 환경변수에서 직접 확인 (HTTP_ prefix 포함)
        print(f"\n[LOCAL SERVER] WSGI environ HTTP headers:")
        for key, value in request.environ.items():
            if key.startswith('HTTP_'):
                print(f"  {key}: {value}")


        # Lambda handler 호출
        response = main_handler(event, None)

        # Lambda 응답 파싱
        status_code = response.get('statusCode', 200)
        response_body_str = response.get('body', '{}')

        try:
            response_body = json.loads(response_body_str)
        except json.JSONDecodeError:
            response_body = {'result': response_body_str}

        print(f"[LOCAL SERVER] Response status: {status_code}")

        # CORS 헤더 추가
        response = jsonify(response_body)
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Credentials'] = 'true'
        return response, status_code

    except Exception as e:
        print(f"\n[LOCAL SERVER ERROR] {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500


@app.route('/health', methods=['GET'])
def health_check():
    """헬스체크 엔드포인트"""
    return jsonify({
        'status': 'ok',
        'handler': '{{app}}',
        'port': PORT
    })


if __name__ == '__main__':

    print("=" * 60)
    print("🚀 Local Development Server ({{app}} Handler)")
    print("=" * 60)
    print(f"Server running at: http://localhost:{PORT}")
    print(f"Health check: http://localhost:{PORT}/health")
    print("\nTo use this server, update your frontend .env.development.local:")
    print(f"  VITE_APP_API_URL=http://localhost:{PORT}")
    print("=" * 60)
    print()

    # Auto-reload 활성화 - 파일 변경 시 자동으로 서버 재시작
    # DISABLE_RELOADER=1 환경변수로 비활성화 가능 (PyCharm 디버깅 시)
    import os
    disable_reloader = os.environ.get('DISABLE_RELOADER', '').lower() in ('1', 'true', 'yes')

    if not disable_reloader:
        print("🔄 Auto-reload ENABLED - 파일 변경 시 자동 재시작됩니다")
    else:
        print("⚠️  Auto-reload DISABLED - 수동으로 서버를 재시작하세요")

    app.run(
        host='0.0.0.0',
        port=PORT,
        debug=True,
        use_reloader=not disable_reloader,  # 기본적으로 auto-reload 활성화
        threaded=True  # 멀티스레드 활성화
    )
