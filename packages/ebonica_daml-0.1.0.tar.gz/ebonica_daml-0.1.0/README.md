# DAML: Disagreement-Aware Multi-Learning

DAML is a production-level Python machine learning library designed to detect ambiguous or difficult examples through ensemble variance, filtering them based on an adaptive disagreement threshold.

## Key Features

- **DAMLRegressor & DAMLClassifier**: Core ML models compatible with the scikit-learn API. They dynamically retrain on difficult data points to improve performance.
- **Drift Detection**: Detect dataset feature shifts gracefully in production using simple thresholding rules matching your feature space.
- **Hyperparameter Tuning**: Cross-validation wrapper built specifically for fine-tuning the base ensemble.
- **Scikit-Learn API**: Seamless `fit`, `predict`, and `partial_fit` API style integrations.

## Installation

```bash
pip install ebonica-daml
```

Or from source for development:
```bash
git clone https://github.com/yourusername/ebonica-daml.git
cd ebonica-daml
pip install -r requirements.txt
pip install -e .
```

## Basic Usage

```python
from daml import DAMLRegressor
from sklearn.datasets import make_regression

X, y = make_regression(n_samples=500, n_features=10)
model = DAMLRegressor(n_models=5, lambda_param=1.0)
model.fit(X, y)
predictions = model.predict(X)
```

See `example_usage.py` for a larger, complete end-to-end example dealing with hyperparameter tuning, model training, and data drift detection scenarios.
