from setuptools import setup, find_packages

setup(
    name="ebonica-daml",
    version="0.1.0",
    description="Disagreement-Aware Multi-Learning (DAML) - A production-level Python ML library.",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Ebonica Saleth",
    author_email="ebonica7@gmail.com",
    url="https://github.com/yourusername/ebonica-daml",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "ebonica-daml=daml.core:main",
        ]
    },
    install_requires=[
        "numpy>=1.20.0",
        "scikit-learn>=1.0.0",
        "scipy>=1.7.0",
        "joblib>=1.1.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
