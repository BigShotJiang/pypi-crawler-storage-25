import numpy as np
import random
from .utils import setup_logger

logger = setup_logger(__name__)

class DAMLTensorAgent:
    """
    Reinforcement Learning module for DAML-X (Patent-level Concept).
    Learns an optimal policy mapping states (Disagreement, Error, Capacity, Drift)
    to discrete actions: Ignore, Soft-Reweight, Hard-Retrain, or Dynamic-Evolution.
    """
    def __init__(self, state_dim=4, num_actions=4, alpha=0.1, gamma=0.9, epsilon=0.1):
        # Action space:
        # 0 = IGNORE (Continue as is)
        # 1 = WEIGHT_UPDATE (EMA ensemble weights adjustment only)
        # 2 = RETRAIN_HARD (Subset training on critical examples)
        # 3 = EVOLVE_ENSEMBLE (Spawn new model / Retire weak model)
        
        self.num_actions = num_actions
        self.alpha = alpha     # Learning rate
        self.gamma = gamma     # Discount factor
        self.epsilon = epsilon # Exploration vs Exploitation
        
        # We discretize the state space for true Q-learning, or use a pseudo-linear approximator
        self.weights = np.zeros((self.num_actions, state_dim))
        
    def _get_q_values(self, state):
        """Linear approximation of Q(s, a) = weights * state"""
        return np.dot(self.weights, state)
        
    def select_action(self, state):
        """Epsilon-greedy action selection."""
        # Explore
        if random.uniform(0, 1) < self.epsilon:
            action = random.choice(range(self.num_actions))
            logger.debug(f"[RL] Exploration Action selected: {action}")
            return action
            
        # Exploit
        q_values = self._get_q_values(state)
        action = np.argmax(q_values)
        return action
        
    def update_policy(self, state, action, reward, next_state):
        """
        Policy Gradient / TD Update.
        reward = accuracy_gain - computational_cost
        """
        q_curr = self._get_q_values(state)[action]
        q_next = np.max(self._get_q_values(next_state))
        
        # Temporal Difference Target
        td_target = reward + self.gamma * q_next
        td_error = td_target - q_curr
        
        # Gradient descent update on approximator weights
        self.weights[action] += self.alpha * td_error * state
        
        logger.debug(f"[RL] Policy updated. TD Error: {td_error:.4f} | Reward: {reward:.4f}")
        
    def compute_reward(self, accuracy_before, accuracy_after, action, time_cost):
        """
        Multi-objective optimization function. 
        Balances accuracy gains against the computational overhead of the action.
        """
        acc_diff = accuracy_after - accuracy_before
        
        # Baseline penalties (Computational Cost approximation)
        action_costs = {
            0: 0.0,   # Ignore is free
            1: 0.1,   # Soft reweights are extremely cheap
            2: 1.0,   # Training on hard examples costs moderate time
            3: 3.0    # Spawning/Pruning evolving architectures is very expensive
        }
        
        cost_penalty = action_costs.get(action, 0.0) * time_cost
        
        reward = (acc_diff * 10.0) - cost_penalty 
        return reward
