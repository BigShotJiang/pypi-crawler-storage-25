import numpy as np
import logging

def setup_logger(name="DAML", level=logging.INFO):
    """Set up and return a logger for the given name."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(level)
    return logger

def compute_disagreement(preds):
    """Compute disagreement using variance across model predictions.
    
    Args:
        preds (np.ndarray): Predictions from multiple models.
        
    Returns:
        np.ndarray: Variance across predictions.
    """
    return np.var(preds, axis=0)

def compute_fusion_score(disagreement, confidence):
    """Compute fusion score S = D * (1 - C)
    
    Args:
        disagreement (np.ndarray): Disagreement scores.
        confidence (np.ndarray): Confidence scores.
        
    Returns:
        np.ndarray: Fusion scores.
    """
    return disagreement * (1.0 - confidence)

def compute_adaptive_threshold(fusion_scores, lambda_param=1.0):
    """Compute adaptive threshold tau = mean(S) + lambda * std(S)
    
    Args:
        fusion_scores (np.ndarray): Fusion scores.
        lambda_param (float): Hyperparameter controlling the threshold.
        
    Returns:
        float: Adaptive threshold.
    """
    return np.mean(fusion_scores) + lambda_param * np.std(fusion_scores)
