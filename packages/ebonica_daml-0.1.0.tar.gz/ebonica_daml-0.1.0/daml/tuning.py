import numpy as np
import warnings
from sklearn.model_selection import RandomizedSearchCV, cross_val_score
from sklearn.base import clone

from .utils import setup_logger

logger = setup_logger(__name__)

class DAMLTuner:
    """
    Advanced AutoML and Hyperparameter Optimization wrapper for DAMLPipelines.
    Utilizes powerful randomized searches for fast, high-quality optimization 
    over parameter distributions rather than static grid searches.
    """
    def __init__(self, model, param_distributions, n_iter=10, cv=3, scoring=None, n_jobs=-1, random_state=42):
        self.model = model
        self.param_distributions = param_distributions
        self.n_iter = n_iter
        self.cv = cv
        self.scoring = scoring
        self.n_jobs = n_jobs
        self.random_state = random_state
        
        # We wrap the model in RandomizedSearchCV for efficient tuning
        self.search_ = RandomizedSearchCV(
            estimator=self.model,
            param_distributions=self.param_distributions,
            n_iter=self.n_iter,
            cv=self.cv,
            scoring=self.scoring,
            n_jobs=self.n_jobs,
            random_state=self.random_state,
            verbose=1
        )
        
    @property
    def best_params_(self):
        """Metadata for best configuration."""
        if hasattr(self.search_, "best_params_"):
            return self.search_.best_params_
        return None
        
    @property
    def best_score_(self):
        """Cross-validated score of the best configuration."""
        if hasattr(self.search_, "best_score_"):
            return self.search_.best_score_
        return None

    def fit(self, X, y):
        """
        Execute AutoML optimization over the defined search space.
        Automatically retrains the absolutely best model on the full provided dataset.
        """
        logger.info(f"Initiating AutoML Randomized Search with {self.n_iter} iterations.")
        logger.info(f"Search space: {self.param_distributions}")
        
        # Execute cross-validated optimization
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            self.search_.fit(X, y)
        
        logger.info(f"AutoML Search Complete. Best Score: {self.best_score_:.4f}")
        logger.info(f"Ideal Configurations: {self.best_params_}")
        
        # Return the best completely fitted estimator pipeline
        return self.search_.best_estimator_

    def cross_validate(self, X, y):
        """
        Perform rigorous robust evaluation metrics without mutating the 
        internal estimator, suitable for final benchmark reporting.
        """
        logger.info("Running rigorous k-fold cross-validation...")
        scores = cross_val_score(
            self.model if self.best_params_ is None else self.search_.best_estimator_,
            X, y, cv=self.cv, scoring=self.scoring, n_jobs=self.n_jobs
        )
        
        report = {
            "mean_score": np.mean(scores),
            "std_deviation": np.std(scores),
            "all_scores": scores.tolist()
        }
        
        logger.info(f"Cross-Validation Results - Mean: {report['mean_score']:.4f} | StdDev: {report['std_deviation']:.4f}")
        return report
