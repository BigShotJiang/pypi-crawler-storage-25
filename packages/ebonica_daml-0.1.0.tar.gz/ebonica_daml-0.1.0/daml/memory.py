import numpy as np
from collections import deque
from .utils import setup_logger

logger = setup_logger(__name__)

class TemporalMemory:
    """
    Episodic memory module for DAML-X.
    Stores historical representations of drifts, disagreements, and ensemble states.
    Allows the system to detect recurring data distribution shifts (Concept Drift).
    """
    def __init__(self, capacity=10000):
        self.capacity = capacity
        # We use a deque for fast O(1) sliding window push/pops
        self.state_history = deque(maxlen=self.capacity)
        self.drift_signatures = deque(maxlen=self.capacity)

    def store_episode(self, state_vector, drift_signature, action_taken, reward):
        """
        Commit a learning episode to temporal memory.
        """
        episode = {
            "state": state_vector,
            "drift_signature": np.array(drift_signature),
            "action": action_taken,
            "reward": reward
        }
        self.state_history.append(episode)
        self.drift_signatures.append(np.array(drift_signature))

    def detect_recurring_drift(self, current_signature, similarity_threshold=0.85):
        """
        Check if the current drift pattern exactly matches a historical shift.
        Allows zero-shot adaptation if we've seen this concept before.
        """
        if len(self.drift_signatures) < 10:
            return None, 0.0

        # Compute cosine similarity between current drift and all historical drifts
        history_matrix = np.array(self.drift_signatures)
        curr_vec = np.array(current_signature)
        
        # Normalize for cosine similarity
        norm_history = np.linalg.norm(history_matrix, axis=1) + 1e-8
        norm_curr = np.linalg.norm(curr_vec) + 1e-8
        
        similarities = np.dot(history_matrix, curr_vec) / (norm_history * norm_curr)
        
        best_match_idx = np.argmax(similarities)
        best_similarity = similarities[best_match_idx]

        if best_similarity >= similarity_threshold:
            logger.info(f"Recurring drift detected! Similarity: {best_similarity:.2%}")
            return self.state_history[best_match_idx], best_similarity
            
        return None, best_similarity
