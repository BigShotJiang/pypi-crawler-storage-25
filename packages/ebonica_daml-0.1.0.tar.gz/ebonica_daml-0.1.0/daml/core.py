import numpy as np
import joblib
import warnings
from sklearn.base import BaseEstimator, RegressorMixin, ClassifierMixin, clone
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.utils import resample
from joblib import Parallel, delayed

from .utils import setup_logger, compute_disagreement, compute_fusion_score, compute_adaptive_threshold

logger = setup_logger(__name__)

class BaseDAMLPipeline(BaseEstimator):
    """
    Industry-ready Disagreement-Aware Multi-Learning (DAML) Pipeline.
    Integrates preprocessing, ensemble learning, uncertainty estimation, and parallelization.
    """
    def __init__(
        self, 
        base_estimator=None, 
        n_models=5, 
        lambda_param=1.0, 
        n_jobs=-1,
        random_state=None
    ):
        self.base_estimator = base_estimator
        self.n_models = n_models
        self.lambda_param = lambda_param
        self.n_jobs = n_jobs
        self.random_state = random_state
        
        self.imputer_ = SimpleImputer(strategy='mean')
        self.scaler_ = StandardScaler()
        self.models_ = []
        self._feature_importances = None

    def _init_models(self):
        """Initialize powerful models if none are provided."""
        if self.base_estimator is None:
            if isinstance(self, ClassifierMixin):
                base = RandomForestClassifier(n_estimators=10, random_state=self.random_state)
            else:
                base = RandomForestRegressor(n_estimators=10, random_state=self.random_state)
        else:
            base = clone(self.base_estimator)
            
        self.models_ = [clone(base) for _ in range(self.n_models)]

    def _fit_single_model(self, model, X, y, seed):
        """Train a single base model on a bootstrapped subset (parallelizable)."""
        rng = np.random.RandomState(seed)
        X_boot, y_boot = resample(X, y, random_state=rng.randint(10000))
        model.fit(X_boot, y_boot)
        return model

    def fit(self, X, y):
        """
        Fit the production pipeline. Handles preprocessing, multi-model ensemble training
        in parallel, hard-example mining based on disagreement variance, and model retraining.
        """
        X, y = check_X_y(X, y, force_all_finite='allow-nan')
        
        logger.info("Initializing Pipeline: Scaling and Imputing missing values...")
        X_processed = self.imputer_.fit_transform(X)
        X_processed = self.scaler_.fit_transform(X_processed)
        
        self._init_models()
        rng = np.random.RandomState(self.random_state)
        seeds = [rng.randint(100000) for _ in range(self.n_models)]
        
        logger.info(f"Phase 1: Training {self.n_models} base models in parallel (n_jobs={self.n_jobs}).")
        self.models_ = Parallel(n_jobs=self.n_jobs)(
            delayed(self._fit_single_model)(self.models_[i], X_processed, y, seeds[i])
            for i in range(self.n_models)
        )
        
        # DAML Core Adaptive Disagreement Retraining
        logger.info("Phase 2: Computing Disagreement and mining hard examples...")
        preds = np.array([m.predict(X_processed) for m in self.models_])
        variance = np.var(preds, axis=0) if not isinstance(self, ClassifierMixin) else np.std(preds, axis=0)
        
        # Advanced threshold calculation
        threshold = np.mean(variance) + self.lambda_param * np.std(variance)
        hard_mask = variance > threshold
        n_hard = np.sum(hard_mask)
        
        if n_hard > 0:
            logger.info(f"Retraining exclusively on {n_hard} difficult, high-variance examples.")
            X_hard, y_hard = X_processed[hard_mask], y[hard_mask]
            
            seeds = [rng.randint(100000) for _ in range(self.n_models)]
            self.models_ = Parallel(n_jobs=self.n_jobs)(
                delayed(self._fit_single_model)(self.models_[i], X_hard, y_hard, seeds[i])
                for i in range(self.n_models)
            )
        else:
            logger.warning("No hard examples found. Skipping retraining phase.")
            
        self._aggregate_feature_importances()
        self.is_fitted_ = True
        return self

    def partial_fit(self, X, y, classes=None):
        """
        Streaming capability for real-time incremental online learning.
        """
        if not hasattr(self, 'is_fitted_') or not self.is_fitted_:
            logger.warning("Pipeline is completely unfitted. Initializing full fit.")
            return self.fit(X, y)
            
        X, y = check_X_y(X, y, force_all_finite='allow-nan')
        X_processed = self.imputer_.transform(X)
        X_processed = self.scaler_.transform(X_processed)
        
        logger.info(f"Incrementally updating stream of size {len(X)}")
        for model in self.models_:
            if hasattr(model, "partial_fit"):
                if isinstance(self, ClassifierMixin) and classes is not None:
                    model.partial_fit(X_processed, y, classes=classes)
                else:
                    model.partial_fit(X_processed, y)
            else:
                # Provide a robustness fallback if base models do not support partial_fit
                model.fit(X_processed, y)
                
        self._aggregate_feature_importances()
        return self

    def predict(self, X, return_uncertainty=False):
        """
        Predict outcomes, providing predictive entropy/variance uncertainty estimation.
        """
        check_is_fitted(self, 'is_fitted_')
        X = check_array(X, force_all_finite='allow-nan')
        X_processed = self.imputer_.transform(X)
        X_processed = self.scaler_.transform(X_processed)
        
        all_preds = np.array([m.predict(X_processed) for m in self.models_])
        
        if isinstance(self, ClassifierMixin):
            final_pred = np.apply_along_axis(lambda x: np.bincount(x.astype(int)).argmax(), axis=0, arr=all_preds)
            # Predictive entropy / ensemble variance representation
            max_class = np.max(all_preds.astype(int)) + 1
            votes = np.apply_along_axis(lambda x: np.bincount(x.astype(int), minlength=max_class), axis=0, arr=all_preds)
            uncertainty = 1.0 - (np.max(votes, axis=0) / self.n_models)
        else:
            final_pred = np.mean(all_preds, axis=0)
            uncertainty = np.var(all_preds, axis=0)
            
        confidence_score = 1.0 / (1.0 + uncertainty + 1e-8)
        
        if return_uncertainty:
            return {
                "prediction": final_pred,
                "uncertainty": uncertainty,
                "confidence_score": confidence_score
            }
        return final_pred
        
    def _aggregate_feature_importances(self):
        """Aggregate explainability metrics (SHAP/Feature Importance) from base estimators."""
        importances = [m.feature_importances_ for m in self.models_ if hasattr(m, "feature_importances_")]
        if importances:
            self._feature_importances = np.mean(importances, axis=0)
            
    @property
    def feature_importances_(self):
        """Explainability metric - easily expose which features drive predictions."""
        if self._feature_importances is None:
            raise ValueError("Explainability: The underlying base models do not support feature importances.")
        return self._feature_importances
        
    def save_model(self, filepath):
        """Serialize DAML system to disk for simple API deployment."""
        joblib.dump(self, filepath)
        logger.info(f"Model successfully saved to {filepath}")
        
    @classmethod
    def load_model(cls, filepath):
        """Deserialize DAML system."""
        model = joblib.load(filepath)
        logger.info(f"Model successfully loaded from {filepath}")
        return model


class DAMLRegressor(BaseDAMLPipeline, RegressorMixin):
    """Production-grade Disagreement-Aware Multi-Learning Regressor."""
    pass

class DAMLClassifier(BaseDAMLPipeline, ClassifierMixin):
    """Production-grade Disagreement-Aware Multi-Learning Classifier."""
    pass
