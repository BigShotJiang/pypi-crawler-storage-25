import numpy as np
import copy
from sklearn.base import clone
from collections import deque
from .utils import setup_logger

logger = setup_logger(__name__)

class ModelEvolver:
    """
    Genetic algorithm-inspired evolution system for DAML-X.
    Dynamically prunes weak performing models and spawns fresh, highly specific 
    models trained on the exact failure patterns of the ensemble.
    """
    def __init__(self, max_capacity=15, min_capacity=3):
        self.max_capacity = max_capacity
        self.min_capacity = min_capacity
        
    def evaluate_members(self, pipeline, X_val, y_val):
        """
        Calculates the individual performance and diversity contribution 
        of every member in the ensemble.
        """
        from sklearn.metrics import mean_squared_error, accuracy_score
        
        scores = []
        labels_or_vals = hasattr(pipeline, "classes_")
        
        for idx, model in enumerate(pipeline.models_):
            preds = model.predict(X_val)
            
            if labels_or_vals:
                score = accuracy_score(y_val, preds)
            else:
                score = -mean_squared_error(y_val, preds) # Negative, so higher is better
                
            scores.append((idx, score))
            
        # Sort by best performance
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores
        
    def evolve(self, pipeline, X_val, y_val, X_hard, y_hard, base_estimator_blueprint):
        """
        Executes the natural selection loop: Death, Selection, and Mutation (Spawning).
        Mutations are models specialized specifically on hard examples.
        """
        logger.info("[Evolution] Commencing Natural Selection over the ML Ensemble.")
        
        # 1. Selection & Pruning (Death)
        scores = self.evaluate_members(pipeline, X_val, y_val)
        worst_idx, worst_score = scores[-1]
        best_idx, best_score = scores[0]
        
        if len(pipeline.models_) > self.min_capacity:
            # If the worst model is significantly causing drag, prune it out
            # Or if we hit max capacity and must make room for a better model
            if (best_score - worst_score > np.abs(0.2 * best_score)) or len(pipeline.models_) >= self.max_capacity:
                logger.warning(f"[Evolution] Pruning heavily underperforming model {worst_idx} (Score: {worst_score:.2f})")
                pipeline.models_.pop(worst_idx)
            
        # 2. Reproduction / Mutation (Spawning)
        # We spawn a brand new model trained exclusively on the failure modes (X_hard)
        if len(X_hard) > 5 and len(pipeline.models_) < self.max_capacity:
            logger.info(f"[Evolution] Spawning new, highly specialized model against {len(X_hard)} drift patterns.")
            
            mutated_model = clone(base_estimator_blueprint)
            mutated_model.fit(X_hard, y_hard)
            
            pipeline.models_.append(mutated_model)
            
        return pipeline
