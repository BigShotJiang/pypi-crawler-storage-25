#!/usr/bin/env python3
"""
========================================================
CyberSuite — Remote Utilities
========================================================
Read-only helpers for observing remote directory trees
via SSH/SFTP.

Rules:
  • Metadata only (names, extensions, sizes)
  • NO file downloads
  • NO writes
  • NO publisher assumptions
========================================================
"""

import posixpath
import paramiko
import stat


def walk_remote_tree(*, creds: dict, root_path: str):
    """
    Dumb, portable remote directory walk.
    Metadata-only. No chdir probing.
    Uses SSHClient for auth parity with picker + tests.
    """

    nodes = []
    dir_count = 0
    file_count = 0

    # --------------------------------------------------
    # SSH / SFTP setup (AUTH-SAFE)
    # --------------------------------------------------
    ssh = paramiko.SSHClient()
    ssh.load_system_host_keys()
    ssh.set_missing_host_key_policy(paramiko.WarningPolicy())

    ssh.connect(
        hostname=creds.get("host") or "",
        port=int(creds.get("port", 22)),
        username=creds.get("user"),
        password=creds.get("password") or None,
        key_filename=creds.get("key_filename") or None,
        timeout=10,
    )

    sftp = ssh.open_sftp()

    # --------------------------------------------------
    # Recursive walker
    # --------------------------------------------------
    def _walk(abs_path, rel_path):
        nonlocal dir_count, file_count

        try:
            entries = sftp.listdir_attr(abs_path)
        except Exception as e:
            print("[remote_utils] listdir_attr failed:", abs_path, repr(e))
            return

        dirs = []
        files = []

        for attr in entries:
            name = attr.filename

            if stat.S_ISDIR(attr.st_mode):
                dirs.append(name)
                dir_count += 1

            elif stat.S_ISREG(attr.st_mode):
                files.append(
                    {
                        "name": name,
                        "ext": posixpath.splitext(name)[1],
                        "size": attr.st_size,
                    }
                )
                file_count += 1

            else:
                # symlinks / devices / unknowns — ignored by design
                continue

        nodes.append(
            {
                "path": rel_path or ".",
                "dirs": sorted(dirs),
                "files": files,
            }
        )

        for d in dirs:
            next_abs = posixpath.join(abs_path, d)
            next_rel = f"{rel_path}/{d}" if rel_path else d
            _walk(next_abs, next_rel)

    # --------------------------------------------------
    # Execute walk (guaranteed cleanup)
    # --------------------------------------------------
    try:
        _walk(root_path, "")
    finally:
        try:
            sftp.close()
        finally:
            ssh.close()

    return nodes, dir_count, file_count
