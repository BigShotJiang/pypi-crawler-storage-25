#!/usr/bin/env python3
"""
========================================================
Suite Core — Input Matrix (Data Normalization)
========================================================
Parses supported data file formats into a unified structure:

{
    "meta": {...},
    "records": [...]
}

Supports: XML, JSON, CSV, Markdown (MD).

UI-agnostic.
Publisher / Mapper / Scribe safe.
"""

import os
import json
import csv
import xml.etree.ElementTree as ET
from suite_core.logging import get_logger, log_cli

logger = get_logger(__name__)


def parse_data_file(path: str) -> dict:
    """Dispatch parser by extension; return unified dict."""
    if not os.path.exists(path):
        msg = f"❌ Data file not found: {path}"
        log_cli(msg)
        logger.error(msg)
        return {"meta": {}, "records": []}

    ext = os.path.splitext(path)[1].lower()
    if ext == ".xml":
        return _parse_xml(path)
    if ext == ".json":
        return _parse_json(path)
    if ext == ".csv":
        return _parse_csv(path)
    if ext == ".md":
        return _parse_md(path)

    msg = f"⚠ Unsupported data format: {ext}"
    log_cli(msg)
    logger.warning(msg)
    return {"meta": {}, "records": []}


# ========================================================
# XML
# ========================================================
def _parse_xml(path: str) -> dict:
    meta, records = {}, []
    try:
        tree = ET.parse(path)
        root = tree.getroot()

        meta_block = root.find("meta")
        if meta_block is not None:
            for child in meta_block:
                key = child.tag.strip()
                val = (child.text or "").strip()
                if key:
                    meta[key] = val

            log_cli(f"🧭 Parsed META section ({len(meta)} fields)")
            logger.info("Parsed META block")

        for rec in root.findall(".//record"):
            row = {}
            for child in rec:
                key = child.tag.strip()
                val = (child.text or "").strip()
                if key:
                    row[key] = val
            if row:
                records.append(row)

        log_cli(f"📑 Parsed XML ({len(records)} records)")
        return {"meta": meta, "records": records}

    except Exception as e:
        msg = f"❌ XML parse error: {e}"
        log_cli(msg)
        logger.exception(msg)
        return {"meta": {}, "records": []}


# ========================================================
# JSON
# ========================================================
def _parse_json(path: str) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, dict) and "records" in data:
            meta = data.get("meta", {})
            records = data.get("records", [])
        else:
            meta = {}
            records = data if isinstance(data, list) else [data]

        log_cli(f"📑 Parsed JSON ({len(records)} records)")
        return {"meta": meta, "records": records}

    except Exception as e:
        msg = f"❌ JSON parse error: {e}"
        log_cli(msg)
        logger.exception(msg)
        return {"meta": {}, "records": []}


# ========================================================
# CSV
# ========================================================
def _parse_csv(path: str) -> dict:
    """CSV meta columns start with '__meta_'."""
    meta, records = {}, []

    try:
        with open(path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if (row.get("__meta_type") or "").strip().lower() == "meta":
                    for k, v in row.items():
                        if k and k.startswith("__meta_") and (v or "").strip():
                            meta[k.replace("__meta_", "")] = (v or "").strip()
                    continue

                clean = {
                    (k.strip() if k else ""): (v.strip() if v else "")
                    for k, v in row.items()
                    if not (k or "").startswith("__meta_")
                }

                if any(clean.values()):
                    records.append(clean)

        log_cli(f"📑 Parsed CSV ({len(records)} records, meta {len(meta)})")
        return {"meta": meta, "records": records}

    except Exception as e:
        msg = f"❌ CSV parse error: {e}"
        log_cli(msg)
        logger.exception(msg)
        return {"meta": {}, "records": []}


# ========================================================
# MARKDOWN  (house-schema parser)
# ========================================================
#
# Grammar:
#   [META] ... [/META]     → scalar key: value lines → meta dict
#   [RECORD] ... [/RECORD] → scalar key: value lines + [BLOCK] sections
#   [BLOCK] ... [/BLOCK]   → speaker: + multiline content: → {speaker, content}
#
# Content inside [BLOCK] is preserved verbatim (inline HTML not stripped).
# ========================================================

def _md_parse_scalar_lines(text: str) -> dict:
    """Parse 'key: value' lines from a text block. Blank lines skipped."""
    result = {}
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if ": " in line:
            key, _, val = line.partition(": ")
            result[key.strip()] = val.strip()
        elif line.endswith(":"):
            result[line[:-1].strip()] = ""
    return result


def _md_parse_block(body: str) -> dict:
    """Parse a single [BLOCK] body: speaker line + multiline content body."""
    speaker = ""
    content_lines = []
    in_content = False

    for line in body.splitlines():
        stripped = line.strip()
        if not in_content:
            if stripped.startswith("speaker:"):
                speaker = stripped[len("speaker:"):].strip()
            elif stripped == "content:":
                in_content = True
            elif stripped.startswith("content: "):
                content_lines.append(stripped[len("content: "):])
                in_content = True
        else:
            content_lines.append(line)

    return {"speaker": speaker, "content": "\n".join(content_lines).strip()}


def _md_parse_record(body: str) -> dict:
    """Parse a single [RECORD] body: scalar fields + zero or more [BLOCK] sections."""
    blocks = []
    scalars_text = ""
    remaining = body

    while "[BLOCK]" in remaining:
        before, _, after_open = remaining.partition("[BLOCK]")
        scalars_text += before
        if "[/BLOCK]" not in after_open:
            break
        block_body, _, remaining = after_open.partition("[/BLOCK]")
        blocks.append(_md_parse_block(block_body))
    scalars_text += remaining

    record = _md_parse_scalar_lines(scalars_text)
    if blocks:
        record["blocks"] = blocks
    return record


def _parse_md(path: str) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()

        # --- META ---
        meta = {}
        if "[META]" in text and "[/META]" in text:
            _, _, after_open = text.partition("[META]")
            meta_body, _, _ = after_open.partition("[/META]")
            meta = _md_parse_scalar_lines(meta_body)

        # --- RECORDS ---
        records = []
        remaining = text
        while "[RECORD]" in remaining:
            _, _, after_open = remaining.partition("[RECORD]")
            if "[/RECORD]" not in after_open:
                msg = "⚠ Markdown: unclosed [RECORD] block — skipped"
                log_cli(msg)
                logger.warning(msg)
                break
            record_body, _, remaining = after_open.partition("[/RECORD]")
            records.append(_md_parse_record(record_body))

        log_cli(f"📑 Parsed Markdown ({len(records)} records, {len(meta)} meta fields)")
        return {"meta": meta, "records": records}

    except Exception as e:
        msg = f"❌ Markdown parse error: {e}"
        log_cli(msg)
        logger.exception(msg)
        return {"meta": {}, "records": []}
