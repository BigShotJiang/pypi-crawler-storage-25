#!/usr/bin/env python3
"""
========================================================
CyberSuite — Safehouse (Core)
========================================================
Authoritative filesystem authority for all Suite-managed
persistent storage locations.

Responsibilities:
  • Provide canonical path helpers (NO business logic)
  • Delegate root resolution to instance_manager
  • Remain import-safe for all tools (Scribe / Publisher / Mapper)

Instance mode:  all paths resolve under
                ~/.cyberSuite/instances/<id>/
Legacy mode:    all paths resolve under
                ~/.cyberSuite/  (flat, pre-instance layout)

This module MUST:
  • Contain no tool-specific logic
  • Contain no credential logic
  • Never import from suite_bridge or UI layers
  • Be called only after bootstrap_instance() has run
========================================================
"""

from pathlib import Path
import json

from suite_core import instance_manager


# --------------------------------------------------------
# ROOT RESOLUTION
# --------------------------------------------------------

def get_safehouse_root() -> Path:
    """
    Return the canonical safehouse root for the active instance.

    Instance mode:  ~/.cyberSuite/instances/<id>/
    Legacy mode:    ~/.cyberSuite/

    Delegates to instance_manager — no path logic here.
    """
    return instance_manager.get_active_instance_root()


# --------------------------------------------------------
# ENSURE SAFEHOUSE EXISTS
# --------------------------------------------------------

def ensure_safehouse():
    """
    Ensure the active safehouse root and required subdirs exist.
    Safe to call repeatedly.
    """
    root = get_safehouse_root()
    for subdir in ("creds", "tmp", "mapper"):
        (root / subdir).mkdir(parents=True, exist_ok=True)

    _ensure_mapper_skeletons()


# --------------------------------------------------------
# ENSURE MAPPER CONFIGS EXIST (SKELETON ONLY)
# --------------------------------------------------------

def ensure_mapper_configs():
    """
    Ensure mapper config directory and minimal config files exist.
    Files are created ONLY if missing and NEVER overwritten.
    Note: inclusion_filter.json is seeded by instance_manager into common_policy/.
    """
    ensure_safehouse()

    if not _mapper_base_url_path().exists():
        _mapper_base_url_path().write_text(
            json.dumps(
                {
                    "sites": {
                        "example_site": {
                            "base_url": "https://www.example.com",
                            "meta": {
                                "description": "Example production website",
                                "owner": "",
                                "notes": "",
                            },
                        }
                    }
                },
                indent=2,
            ),
            encoding="utf-8",
        )


# --------------------------------------------------------
# MAPPER CONFIG SKELETONS (STRUCTURE ONLY)
# --------------------------------------------------------

def _ensure_mapper_skeletons():
    """
    Ensure mapper configuration skeletons exist.
    Creates minimal files ONLY if missing.
    Never overwrites user-edited content.
    Note: inclusion_filter.json is seeded by instance_manager into common_policy/.
    """
    if not _mapper_base_url_path().exists():
        _mapper_base_url_path().write_text(
            json.dumps(
                {
                    "sites": {
                        "example_site": {
                            "base_url": "https://www.example.com",
                            "meta": {
                                "description": "Example production website",
                                "owner": "",
                                "notes": "",
                            },
                        }
                    }
                },
                indent=2,
            ),
            encoding="utf-8",
        )


# --------------------------------------------------------
# INTERNAL PATH HELPERS (not exported)
# --------------------------------------------------------

def _mapper_dir() -> Path:
    return get_safehouse_root() / "mapper"


def _mapper_base_url_path() -> Path:
    return _mapper_dir() / "base_url.json"


def _mapper_filter_path() -> Path:
    return get_common_policy_dir() / "inclusion_filter.json"


# --------------------------------------------------------
# POLICY DIR (install-location scoped)
# --------------------------------------------------------

def get_policy_dir() -> Path:
    """
    DEPRECATED: get_policy_dir() is no longer supported.

    All policy files must now live in the instance tree:
      ~/.cyberSuite/instances/<id>/common_policy/

    Use get_common_policy_dir() instead.
    """
    raise RuntimeError(
        "get_policy_dir() is deprecated and no longer available. "
        "All policy must use get_common_policy_dir() pointing to "
        "~/.cyberSuite/instances/<id>/common_policy/"
    )


def get_common_policy_dir() -> Path:
    """
    Return the instance-local common policy directory:
      ~/.cyberSuite/instances/<id>/common_policy/

    Files are seeded on first launch by instance_manager.ensure_instance_safehouse().
    Edit them in place to configure live policy per instance.
    """
    return instance_manager.get_active_instance_root() / "common_policy"


def get_tracking_dir() -> Path:
    """
    Return the instance-local tracking snippet directory:
      ~/.cyberSuite/instances/<id>/common_policy/tracking/

    Files are seeded on first launch by instance_manager.ensure_instance_safehouse().
    Edit them in place to set live analytics snippets per instance.
    """
    return get_common_policy_dir() / "tracking"


# --------------------------------------------------------
# PATH HELPERS (exported)
# --------------------------------------------------------

def creds_path(filename: str) -> Path:
    """
    Return absolute path to a credentials file inside:
      <active_root>/creds/
    """
    ensure_safehouse()
    return get_safehouse_root() / "creds" / filename


def mapper_path(filename: str) -> Path:
    """
    Return absolute path to a mapper config file inside:
      <active_root>/mapper/
    """
    ensure_safehouse()
    return get_safehouse_root() / "mapper" / filename


def get_tmp_dir() -> Path:
    """
    Return the active tmp directory path.

      <active_root>/tmp/

    Replaces the former module-level TMP_DIR constant.
    Call sites must use get_tmp_dir() not a cached reference.
    """
    return get_safehouse_root() / "tmp"


# --------------------------------------------------------
# TMP PURGE (CRITICAL)
# --------------------------------------------------------

def purge_tmp(reason=None):
    """
    Hard purge of all run-scoped temp artifacts.
    `reason` is informational only (launch / exit / pre-publish).
    """
    ensure_safehouse()

    tmp = get_tmp_dir()
    if tmp.exists():
        import shutil

        for item in tmp.iterdir():
            if item.is_dir():
                shutil.rmtree(item, ignore_errors=True)
