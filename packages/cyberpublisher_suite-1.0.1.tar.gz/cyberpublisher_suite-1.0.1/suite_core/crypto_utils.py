#!/usr/bin/env python3
"""
========================================================
CyberSuite — Crypto Utilities (suite_core)
========================================================
Purpose:
--------
Minimal, auditable encryption helpers for data-at-rest.

Design:
-------
• Encrypt before disk write
• Decrypt immediately after read
• Plaintext exists only in memory
• Per-instance key (outside git)
• Fernet symmetric encryption

Key location:
-------------
Instance mode:  ~/.cyberSuite/instances/<id>/crypto.key
Legacy mode:    ~/.cyberSuite/crypto.key

The key path is resolved dynamically via instance_manager
so that legacy installs continue to decrypt correctly —
existing encrypted credentials remain readable.

Critical: Do NOT move the key without an explicit migration
tool that re-encrypts all stored credentials with the new key.
========================================================
"""

from cryptography.fernet import Fernet
from pathlib import Path

from suite_core import instance_manager


# --------------------------------------------------------
# Key management
# --------------------------------------------------------

def _key_path() -> Path:
    """
    Resolve the encryption key path for the active instance.

    Instance mode:  ~/.cyberSuite/instances/<id>/crypto.key
    Legacy mode:    ~/.cyberSuite/crypto.key

    Always computed at call time — never cached at import.
    """
    return instance_manager.get_active_instance_root() / "crypto.key"


def get_or_create_key() -> bytes:
    """
    Load existing encryption key or create one if missing.
    Key location is determined by the active instance.
    """
    key_file = _key_path()

    if not key_file.exists():
        key_file.parent.mkdir(parents=True, exist_ok=True)
        key = Fernet.generate_key()
        key_file.write_bytes(key)
        key_file.chmod(0o600)
        return key

    return key_file.read_bytes()


def _fernet() -> Fernet:
    return Fernet(get_or_create_key())


# --------------------------------------------------------
# Public helpers
# --------------------------------------------------------

def encrypt_bytes(data: bytes) -> bytes:
    return _fernet().encrypt(data)


def decrypt_bytes(data: bytes) -> bytes:
    return _fernet().decrypt(data)
