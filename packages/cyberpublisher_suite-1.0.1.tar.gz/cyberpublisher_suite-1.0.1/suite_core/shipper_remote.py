#!/usr/bin/env python3

from pathlib import Path
import paramiko
import os


def ship_remote(run_dir, remote_spec, overwrite=False):
    """
    Ship published output to a remote host via SFTP.

    Guarded:
      • No-op if output dir missing or empty
      • Only runs on successful publish

    Args:
        run_dir (str | Path):
            holding_tank/run_YYYYMMDD_HHMMSS
        remote_spec (dict):
            {
              "host": "...",
              "user": "...",
              "port": 22,
              "path": "/remote/output/dir",
              "keyfile": "...",       # optional
              "password": "..."       # optional
            }
        overwrite (bool):
            overwrite existing files if True
    """

    run_dir = Path(run_dir).resolve()
    src_dir = run_dir / "output"

    # --------------------------------------------------
    # GUARD — nothing to ship
    # --------------------------------------------------
    if not src_dir.exists() or not any(src_dir.iterdir()):
        return  # clean no-op

    host = remote_spec.get("host")
    user = remote_spec.get("user")
    port = int(remote_spec.get("port", 22))
    remote_path = remote_spec.get("path")

    if not all([host, user, remote_path]):
        raise RuntimeError("Incomplete remote_spec for remote publish")

    ssh = paramiko.SSHClient()
    ssh.load_system_host_keys()
    ssh.set_missing_host_key_policy(paramiko.WarningPolicy())

    try:
        # ---------------------------------------------
        # CONNECT (key preferred, fallback to password)
        # ---------------------------------------------
        keyfile = remote_spec.get("keyfile") or remote_spec.get("key_filename") or None
        if keyfile:
            key = paramiko.RSAKey.from_private_key_file(os.path.expanduser(keyfile))
            ssh.connect(host, port=port, username=user, pkey=key)
        else:
            ssh.connect(
                host,
                port=port,
                username=user,
                password=remote_spec.get("password"),
            )

        sftp = ssh.open_sftp()

        # ---------------------------------------------
        # ENSURE REMOTE DIRECTORY EXISTS
        # ---------------------------------------------
        _ensure_remote_dir(sftp, remote_path)

        # ---------------------------------------------
        # UPLOAD FILES
        # ---------------------------------------------
        for src_file in src_dir.iterdir():
            if not src_file.is_file():
                continue

            remote_file = str(Path(remote_path) / src_file.name)

            if not overwrite:
                try:
                    sftp.stat(remote_file)
                    continue  # exists, skip
                except FileNotFoundError:
                    pass

            tmp_remote = remote_file + ".tmp"

            sftp.put(str(src_file), tmp_remote)
            try:
                sftp.rename(tmp_remote, remote_file)
            except IOError:
                # Fallback for filesystems that don't support atomic rename
                try:
                    sftp.remove(remote_file)
                except IOError:
                    pass
                sftp.rename(tmp_remote, remote_file)

    finally:
        try:
            sftp.close()
        except Exception:
            pass
        ssh.close()


def _ensure_remote_dir(sftp, remote_path):
    """
    Create remote directories recursively if needed.
    """
    parts = Path(remote_path).parts
    current = ""

    for part in parts:
        current = f"{current}/{part}" if current else part
        try:
            sftp.stat(current)
        except FileNotFoundError:
            sftp.mkdir(current)


def fetch_remote_file(remote_spec, remote_path, local_dest):
    """
    Fetch a single remote file via SFTP into a local destination.

    Args:
        remote_spec (dict): creds + host info
        remote_path (str): full remote file path
        local_dest (Path): local destination file path
    """

    host = remote_spec.get("host")
    user = remote_spec.get("user")
    port = int(remote_spec.get("port", 22))

    if not all([host, user, remote_path]):
        raise RuntimeError("Incomplete remote_spec for remote fetch")

    ssh = paramiko.SSHClient()
    ssh.load_system_host_keys()
    ssh.set_missing_host_key_policy(paramiko.WarningPolicy())

    try:
        keyfile = remote_spec.get("keyfile") or remote_spec.get("key_filename") or None
        if keyfile:
            key = paramiko.RSAKey.from_private_key_file(os.path.expanduser(keyfile))
            ssh.connect(host, port=port, username=user, pkey=key)
        else:
            ssh.connect(
                host,
                port=port,
                username=user,
                password=remote_spec.get("password"),
            )

        sftp = ssh.open_sftp()

        local_dest = Path(local_dest)
        local_dest.parent.mkdir(parents=True, exist_ok=True)

        sftp.get(remote_path, str(local_dest))

    finally:
        try:
            sftp.close()
        except Exception:
            pass
        ssh.close()
