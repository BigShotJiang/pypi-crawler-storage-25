#!/usr/bin/env python3
"""
========================================================
CyberSuite — Credential Store (suite_core)
========================================================
Author: cyberfluence.com
Year:   2025
Team:   Gil & Z3k3
========================================================

Purpose
-------
Centralized credential persistence and validation layer
shared across ALL CyberSuite tools (Scribe, Publisher,
Mapper, future tools).

This module is NOT tool-specific.

Responsibilities
----------------
• Persist remote SSH credentials to disk
• Normalize legacy / shorthand scope aliases
• Cache credentials in-memory for runtime access
• Enforce password hygiene on application exit
• Provide SSH connection testing utility

Credential Scope Map
--------------------
Accepted aliases resolve to canonical filenames:

  tmpl | template | remote_tmpl  → remote_template.json
  data | remote_data             → remote_data.json
  out  | output | remote_out     → remote_output.json

Storage Location
----------------
All credentials are stored under:

  ~/.cyberSuite/creds/

Security Model
--------------
• Passwords are cached in memory only
• Password fields are wiped from disk on app exit
• Host / user / port / key_filename persist
• File permissions controlled by safehouse

Integrations
------------
• suite_core.safehouse  (path + lifecycle)
• suite_bridge.api     (save/test calls)
• JS modal_manager     (confirm-gated UI flow)
• Paramiko             (SSH connectivity test)

Design Notes
------------
This file was lifted from cyberSuite (BWP_009F)
and promoted to Suite-level infrastructure.

DO NOT import tool-specific modules here.
DO NOT add UI or policy logic here.

========================================================
"""


import json
import os
import atexit
from suite_core.safehouse import creds_path, ensure_safehouse
from suite_core.crypto_utils import encrypt_bytes, decrypt_bytes
from suite_core.safehouse import purge_tmp


def purge_tmp_if_bootstrapped():
    try:
        purge_tmp()
    except TypeError:
        pass


atexit.register(purge_tmp_if_bootstrapped)

# Track loaded creds in memory
_cached_creds: dict[str, dict] = {}


def load_creds(name: str) -> dict:
    """
    Load credentials from ~/.cyberSuite/creds/{name}.json
    Returns dict with keys:
      host, port, user, password, key_filename
    Always re-reads from disk if cache missing or empty.
    """
    ensure_safehouse()

    print("[CREDS LOAD] name =", name)

    alias_map = {
        "tmpl": "remote_template",
        "template": "remote_template",
        "remote_tmpl": "remote_template",
        "data": "remote_data",
        "remote_data": "remote_data",
        "out": "remote_output",
        "output": "remote_output",
        "remote_out": "remote_output",
    }
    name = alias_map.get(name, name)

    path = creds_path(f"{name}.json")
    print(f"[DEBUG] load_creds() looking for: {path}")

    if name in _cached_creds and os.path.exists(path):
        return _cached_creds[name]

    if os.path.exists(path):
        with open(path, "rb") as f:
            enc = f.read()

        try:
            raw = decrypt_bytes(enc)
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            # Fail-safe: unreadable / wrong key / corrupt file
            data = {}

        # Backward-compat defaults
        data.setdefault("host", "")
        data.setdefault("port", 22)
        data.setdefault("user", "")
        data.setdefault("password", "")
        data.setdefault("key_filename", "")
        data.setdefault("base_url", "")

        # ------------------------------------------------------------------
        # SSH alias resolution: if host has no dots/colons it's likely an
        # SSH config alias (e.g. "cyberflu") rather than a real hostname.
        # Resolve it via ~/.ssh/config so paramiko gets the actual address.
        # ------------------------------------------------------------------
        host = data.get("host", "")
        if host and "." not in host and ":" not in host:
            try:
                from suite_core.ssh_manager import resolve_ssh_alias

                ssh_resolved = resolve_ssh_alias(host)
                if ssh_resolved:
                    if ssh_resolved.get("hostname"):
                        data["host"] = ssh_resolved["hostname"]
                    if ssh_resolved.get("user") and not data.get("user"):
                        data["user"] = ssh_resolved["user"]
                    if ssh_resolved.get("port") and data.get("port") == 22:
                        data["port"] = ssh_resolved["port"]
                    if ssh_resolved.get("keyfile") and not data.get("key_filename"):
                        data["key_filename"] = ssh_resolved["keyfile"]
            except Exception:
                pass

        _cached_creds[name] = data
        return data

    return {
        "host": "",
        "port": 22,
        "user": "",
        "password": "",
        "key_filename": "",
        "base_url": "",
    }


def save_creds(name: str, creds: dict):
    """
    Save credentials dict to ~/.cyberSuite/creds/{name}.json
    Persists host, port, user, password, key_filename.
    Accepts short aliases (tmpl/data/out) and normalizes them.
    """
    ensure_safehouse()

    alias_map = {
        "tmpl": "remote_template",
        "template": "remote_template",
        "remote_tmpl": "remote_template",
        "data": "remote_data",
        "remote_data": "remote_data",
        "out": "remote_output",
        "output": "remote_output",
        "remote_out": "remote_output",
    }
    name = alias_map.get(name, name)

    path = creds_path(f"{name}.json")

    # 🔒 encrypt at rest
    raw = json.dumps(creds, indent=2).encode("utf-8")
    enc = encrypt_bytes(raw)

    with open(path, "wb") as f:
        f.write(enc)

    _cached_creds[name] = creds


def has_valid_creds(creds: dict) -> bool:
    """
    Creds are considered valid if:
      • host is present
      • AND (user OR key alias exists)
    Empty strings are invalid.
    """
    if not isinstance(creds, dict):
        return False

    host = (creds.get("host") or "").strip()
    user = (creds.get("user") or "").strip()
    key = (creds.get("key_filename") or "").strip()

    return bool(host and (user or key))


def clear(scope: str):
    """
    Delete persisted creds file and clear cache for scope.
    """
    ensure_safehouse()

    alias_map = {
        "tmpl": "remote_template",
        "template": "remote_template",
        "data": "remote_data",
        "out": "remote_output",
        "output": "remote_output",
    }
    name = alias_map.get(scope, scope)

    path = creds_path(f"{name}.json")

    if os.path.exists(path):
        os.remove(path)

    _cached_creds.pop(name, None)


def wipe_passwords():
    """
    On app exit, wipe all cached password fields in disk files.
    Host/user/port/key_filename are preserved.
    """
    for name, creds in _cached_creds.items():
        if creds.get("password"):
            creds["password"] = ""
            save_creds(name, creds)


atexit.register(wipe_passwords)


# ============================================================
# Remote connection test helper (Paramiko)
# ============================================================
def test_remote_connection(cred: dict) -> tuple[bool, str]:
    """
    Attempt to open an SSH connection with given creds.
    Tries keys first, password as fallback.
    Returns (success: bool, message: str).
    """
    import paramiko

    host = cred.get("host")
    port = int(cred.get("port", 22))
    user = cred.get("user")
    password = cred.get("password") or None
    key_filename = cred.get("key_filename") or None

    if not host or not user:
        return False, "Missing host or username"

    try:
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.WarningPolicy())

        ssh.connect(
            hostname=host,
            port=port,
            username=user,
            password=password,
            key_filename=key_filename,
            look_for_keys=True,
            allow_agent=True,
            timeout=5,
        )

        ssh.close()
        return True, f"Connected to {user}@{host}"

    except paramiko.AuthenticationException:
        return False, "Authentication failed — check SSH keys / password"

    except paramiko.SSHException as e:
        return False, f"SSH error: {str(e)}"

    except Exception as e:
        return False, f"Connection error: {str(e)}"
