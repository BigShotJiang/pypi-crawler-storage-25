#!/usr/bin/env python3
"""
========================================================
CyberSuite — Site Chart Builder
========================================================
Transforms flat map_index payload into hierarchical,
depth-limited site_chart structure.

PURE transformation:
- No filesystem access
- No shipping
- No mutation of input
========================================================
"""

from typing import Dict


def build_site_chart(map_payload: dict, depth_limit: int = 2) -> dict:
    """
    Build hierarchical site_chart structure from map_payload.

    Args:
        map_payload (dict): mapper map_index payload
        depth_limit (int): max directory nesting depth (1–5)

    Returns:
        dict: site_chart payload
    """

    nodes = map_payload.get("nodes", [])
    stats = map_payload.get("stats", {})
    run_info = map_payload.get("mapper_run", {})
    root_path = map_payload.get("root")

    # ------------------------------------------------
    # Build full internal tree (no trimming yet)
    # ------------------------------------------------
    tree: Dict = {"_files": [], "_dirs": {}}

    for node in nodes:
        raw_path = node.get("path", ".")
        parts = [] if raw_path in ("", ".") else raw_path.split("/")

        current = tree

        # Walk down directory structure
        for part in parts:
            current = current["_dirs"].setdefault(part, {"_files": [], "_dirs": {}})

        # Attach files
        for f in node.get("files", []):
            current["_files"].append(f)

        # Ensure subdirectories exist
        for d in node.get("dirs", []):
            current["_dirs"].setdefault(d, {"_files": [], "_dirs": {}})

    # ------------------------------------------------
    # Normalize structure with depth limiting
    # ------------------------------------------------
    def normalize(node: dict, current_depth: int) -> dict:
        result = {"files": node.get("_files", []), "dirs": []}

        if current_depth >= depth_limit:
            return result

        for name, subnode in sorted(node.get("_dirs", {}).items()):
            result["dirs"].append(
                {"name": name, **normalize(subnode, current_depth + 1)}
            )

        return result

    # ------------------------------------------------
    # Build clean root wrapper
    # ------------------------------------------------
    chart = {
        "schema_version": 1,
        "root_path": root_path,
        "mapper_run": run_info,
        "stats": stats,
        "root": normalize(tree, 0),
    }

    return chart
