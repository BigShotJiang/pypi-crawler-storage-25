from pathlib import Path
from suite_core.safehouse import get_safehouse_root


"""
============================================================
WRITE SAFETY GUARD — PORTABILITY & LIABILITY LOCK
============================================================

This guard enforces a hard invariant: the CyberSuite application
may ONLY write inside the active safehouse root:

  Instance mode:  ~/.cyberSuite/instances/<id>/**
  Legacy mode:    ~/.cyberSuite/**

Any attempt to write elsewhere is a fatal error by design.
This is NOT a debug aid — it permanently prevents filesystem
pollution, protects binary portability, and stops architectural
drift before it can recur.

Note: the former exception for .cyberSuite_prefs/instance.json
has been removed — that path was vestigial and is no longer used.
============================================================
"""


def assert_safe_write(path: Path):
    path = Path(path).resolve()
    safe_root = get_safehouse_root().resolve()

    if not str(path).startswith(str(safe_root)):
        raise RuntimeError(f"ILLEGAL WRITE OUTSIDE SAFEHOUSE: {path}")
