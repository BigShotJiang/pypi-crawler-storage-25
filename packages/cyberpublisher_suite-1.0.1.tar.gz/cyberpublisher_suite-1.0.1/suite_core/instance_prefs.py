#!/usr/bin/env python3
"""
========================================================
CyberSuite — Instance Prefs
========================================================
Non-authoritative preference memory.

Scope:
  • <active_root>/prefs/ui_prefs.json
  • <active_root>/prefs/theme_persist.json

Rules:
  • No secrets
  • Safe to delete
  • Read failures are non-fatal
  • Defaults must always exist
========================================================
"""

import json
import time
from pathlib import Path

from suite_core import instance_manager

SCHEMA_VERSION = 1

DEFAULT_PREFS = {
    "schema_version": SCHEMA_VERSION,
    "last_used": {
        "template_creds": None,
        "data_creds": None,
        "output_creds": None,
    },
    "last_paths": {
        "template": None,
        "data": None,
        "output": None,
    },
    "ui_state": {
        "overwrite_enabled": False,
        # optional, may be set by UI:
        # "theme": "default",
    },
    "timestamps": {
        "last_publish_epoch": None,
    },
}

DEFAULT_THEME_PERSIST = {
    "schema_version": SCHEMA_VERSION,
    "theme": "default",
}


# Filename for UI prefs — distinct from gui_policy/instance.json (the
# instance binding manifest). Renamed from "instance.json" to remove
# the naming collision risk.
_PREFS_FILENAME = "ui_prefs.json"


# --------------------------------------------------------
# Paths (active safehouse)
# --------------------------------------------------------
def _prefs_dir() -> Path:
    d = instance_manager.get_active_instance_root() / "prefs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _instance_prefs_path() -> Path:
    return _prefs_dir() / _PREFS_FILENAME


def _theme_persist_path() -> Path:
    return _prefs_dir() / "theme_persist.json"  # filename unchanged


# --------------------------------------------------------
# Instance prefs (instance.json)
# --------------------------------------------------------
def load_instance_prefs(project_root: Path | None = None) -> dict:
    """
    Load instance prefs (home safehouse).
    `project_root` is ignored (kept for backward compatibility).
    Returns defaults on any failure.
    """
    prefs_path = _instance_prefs_path()

    if not prefs_path.exists():
        return DEFAULT_PREFS.copy()

    try:
        with prefs_path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return DEFAULT_PREFS.copy()

    return validate_instance_prefs(data)


def validate_instance_prefs(data: dict) -> dict:
    """
    Ensure prefs conform to expected schema.
    Unknown keys are ignored.
    Missing keys get defaults.
    """
    prefs = DEFAULT_PREFS.copy()

    if not isinstance(data, dict):
        return prefs

    for key in prefs:
        pval = prefs[key]
        if key in data and isinstance(data[key], dict) and isinstance(pval, dict):
            pval.update(data[key])
        elif key in data:
            prefs[key] = data[key]

    prefs["schema_version"] = SCHEMA_VERSION
    return prefs


def write_instance_prefs(project_root: Path | None, prefs: dict) -> None:
    """
    Persist prefs safely (home safehouse).
    `project_root` is ignored (kept for backward compatibility).
    """
    prefs_path = _instance_prefs_path()
    prefs["schema_version"] = SCHEMA_VERSION

    with prefs_path.open("w", encoding="utf-8") as fh:
        json.dump(prefs, fh, indent=2, sort_keys=True)


def stamp_publish_time(prefs: dict) -> None:
    """
    Convenience helper for publish events.
    """
    prefs.setdefault("timestamps", {})
    prefs["timestamps"]["last_publish_epoch"] = int(time.time())


# --------------------------------------------------------
# Theme persistence (theme_persist.json)
# --------------------------------------------------------
def load_theme_persist() -> dict:
    """
    Load theme persistence (home safehouse).
    Returns defaults on any failure.
    """
    path = _theme_persist_path()

    if not path.exists():
        return DEFAULT_THEME_PERSIST.copy()

    try:
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return DEFAULT_THEME_PERSIST.copy()

    if not isinstance(data, dict):
        return DEFAULT_THEME_PERSIST.copy()

    out = DEFAULT_THEME_PERSIST.copy()
    out.update({k: v for k, v in data.items() if k in out})
    out["schema_version"] = SCHEMA_VERSION
    return out


def write_theme_persist(theme_key: str) -> None:
    """
    Persist theme selection safely (home safehouse).
    """
    path = _theme_persist_path()
    data = DEFAULT_THEME_PERSIST.copy()
    data["theme"] = str(theme_key) if theme_key else "default"
    data["schema_version"] = SCHEMA_VERSION

    with path.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
