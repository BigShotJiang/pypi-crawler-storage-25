#!/usr/bin/env python3
"""
Suite Core — Logging

- Narration (user-facing) stays in JS faux CLI.
- Logging (file logbook) lives here.

Files:
  ~/.cyberSuite/logs/runlog.jsonl   (auto snapshots + optional admin; trimmed)
  ~/.cyberSuite/logs/dev_log.jsonl  (dev firehose; only when enabled)

Policy:
- Auto floor: always write Snapshot-level to runlog.jsonl
- Trim: after each job_end, keep last 5 jobs per tool
- scope = output channel scope (local|remote)
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import os
import time
import logging as _logging
from typing import Any, Dict, Iterable, Optional

from suite_core import instance_manager


# ---------------------------------------------------------
# Path normalization (lock: /home/you → ~)
# ---------------------------------------------------------
_HOME = os.path.expanduser("~")


def _norm_path(p: str) -> str:
    if not p or not isinstance(p, str):
        return p
    return "~" + p[len(_HOME) :] if p.startswith(_HOME) else p


def normalize_snapshot(obj):
    """
    Recursively normalize any dict/list snapshot payload:
    - strings that look like home paths get ~ substitution
    - keeps everything else intact
    """
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            out[k] = normalize_snapshot(v)
        return out
    if isinstance(obj, list):
        return [normalize_snapshot(v) for v in obj]
    if isinstance(obj, str):
        return _norm_path(obj)
    return obj


# ---------------------------------------------------------
# Existing shim API (keep)
# ---------------------------------------------------------
def log_cli(msg: str):
    # NOTE: still available for any legacy stdout narration
    print(msg)


def get_logger(name: str):
    return _logging.getLogger(name)


# ---------------------------------------------------------
# File logging config
# ---------------------------------------------------------
TRIM_KEEP_PER_TOOL = 5  # locked


def _log_dir() -> Path:
    """Return the active log directory. Resolves per-instance after bootstrap."""
    return instance_manager.get_active_instance_root() / "logs"


def _runlog_path() -> Path:
    return _log_dir() / "runlog.jsonl"


def _devlog_path() -> Path:
    return _log_dir() / "dev_log.jsonl"


def _utc_iso(ts: Optional[float] = None) -> str:
    if ts is None:
        ts = time.time()
    # ISO-8601 UTC, seconds precision
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))


def _ensure_dirs() -> None:
    _log_dir().mkdir(parents=True, exist_ok=True)


def _jsonl_append(path: Path, obj: Dict[str, Any]) -> None:
    _ensure_dirs()
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
        f.write("\n")


@dataclass(frozen=True)
class RunlogEvent:
    ts: str
    run_id: str
    job_id: str
    tool: str  # "publisher" | "mapper"
    event: str  # "job_start" | "snapshot" | "job_end" | "warn" | "error"
    status: str  # "ok" | "warn" | "fail"
    scope: str  # "local" | "remote"
    timing_ms: Optional[int] = None
    message: Optional[str] = None
    snapshot: Optional[Dict[str, Any]] = None
    error: Optional[Dict[str, Any]] = None
    counts: Optional[Dict[str, Any]] = None


def emit_runlog_event(e: RunlogEvent, *, trim: bool = True) -> None:
    payload: Dict[str, Any] = {
        "ts": e.ts,
        "run_id": e.run_id,
        "job_id": e.job_id,
        "tool": e.tool,
        "event": e.event,
        "status": e.status,
        "scope": e.scope,
    }
    if e.timing_ms is not None:
        payload["timing_ms"] = e.timing_ms
    if e.message:
        payload["message"] = e.message
    if e.snapshot is not None:
        payload["snapshot"] = e.snapshot
    if e.error is not None:
        payload["error"] = e.error
    if e.counts is not None:
        payload["counts"] = e.counts

    _jsonl_append(_runlog_path(), payload)

    # Trim only after job_end (unless retain_all requested)
    if trim and e.event == "job_end":
        trim_runlog_keep_last_jobs_per_tool(TRIM_KEEP_PER_TOOL)


def emit_dev_event(obj: Dict[str, Any]) -> None:
    # Dev file is only written when caller decides (dev enabled)
    # but we provide the append primitive here.
    _jsonl_append(_devlog_path(), obj)


def _read_jsonl_lines(path: Path) -> Iterable[Dict[str, Any]]:
    if not path.exists():
        return []
    out = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                # If a line is corrupt, skip it (don't brick logging)
                continue
    return out


def trim_runlog_keep_last_jobs_per_tool(keep: int) -> None:
    """
    Keep last `keep` completed job_id blocks per tool, based on job_end events.
    Strategy:
      - Parse all events.
      - For each tool, find last N job_ids that have a job_end event.
      - Keep any events whose (tool, job_id) is in those sets.
    """
    runlog = _runlog_path()
    events = list(_read_jsonl_lines(runlog))
    if not events:
        return

    completed_by_tool: Dict[str, list[str]] = {}
    for ev in events:
        try:
            if ev.get("event") == "job_end":
                tool = str(ev.get("tool"))
                job_id = str(ev.get("job_id"))
                completed_by_tool.setdefault(tool, []).append(job_id)
        except Exception:
            continue

    keep_set: set[tuple[str, str]] = set()
    for tool, job_ids in completed_by_tool.items():
        last = job_ids[-keep:] if keep > 0 else []
        for jid in last:
            keep_set.add((tool, jid))

    # If we can't find any completed jobs, don't trim.
    if not keep_set:
        return

    kept_lines = []
    for ev in events:
        ev_tool = ev.get("tool")
        ev_job_id = ev.get("job_id")
        if (ev_tool, ev_job_id) in keep_set:
            kept_lines.append(ev)

    # Rewrite file atomically-ish (path bound once for consistency)
    _ensure_dirs()
    tmp = runlog.with_suffix(".jsonl.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for ev in kept_lines:
            f.write(json.dumps(ev, ensure_ascii=False, separators=(",", ":")))
            f.write("\n")
    tmp.replace(runlog)


# Convenience helpers for api.py wiring
def new_run_id() -> str:
    # cheap unique-ish id
    return f"run_{int(time.time()*1000)}"


def now_ts() -> str:
    return _utc_iso()
