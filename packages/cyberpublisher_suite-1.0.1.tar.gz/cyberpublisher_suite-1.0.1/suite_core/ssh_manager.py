# ========================================================
# CyberSuite — SSH Config Resolver
# ========================================================
# Author(s): Gil & Z3k3 — cyberfluence.com
# Path:      suite_core/ssh_manager.py
#
# Description:
#     Resolves SSH host aliases from ~/.ssh/config into
#     connection credential dicts. Silent — no logging,
#     no exceptions raised to caller.
#
# Inputs:
#     - host_alias (str) — SSH host alias to look up
#     - Reads: ~/.ssh/config (filesystem)
#
# Processing:
#     - Parses SSH config line-by-line
#     - Matches Host blocks to the requested alias
#     - Extracts hostname, user, port, identityfile
#     - Expands ~ in identity file paths
#
# Outputs:
#     - Returns dict: { hostname, user, port, keyfile }
#     - Returns None if alias not found or config missing
#     - Returns None on any parse exception (silent fail)
# ========================================================

import os
import paramiko
from pathlib import Path

SSH_CONFIG_PATH = Path.home() / ".ssh" / "config"


def resolve_ssh_alias(host_alias: str):
    """
    Resolve an SSH host alias from ~/.ssh/config.

    Returns:
        dict with keys: hostname, user, port, keyfile
        or None if alias not found or config missing.
    """
    if not host_alias:
        return None

    if not SSH_CONFIG_PATH.exists():
        return None

    try:
        ssh_config = paramiko.SSHConfig()
        with SSH_CONFIG_PATH.open() as f:
            ssh_config.parse(f)

        cfg = ssh_config.lookup(host_alias)

        # lookup() always returns a dict; an unrecognised alias returns
        # only wildcard (*) defaults — treat that as "not found"
        if cfg.get("hostname", host_alias) == host_alias and "user" not in cfg:
            return None

        resolved: dict[str, str | int] = {}

        hostname = cfg.get("hostname")
        if hostname:
            resolved["hostname"] = hostname

        user = cfg.get("user")
        if user:
            resolved["user"] = user

        port = cfg.get("port")
        if port:
            resolved["port"] = int(port)

        identity_files = cfg.get("identityfile")
        if identity_files:
            resolved["keyfile"] = os.path.expanduser(identity_files[0])

        return resolved if resolved else None

    except Exception:
        return None
