#!/usr/bin/env python3
"""
CyberSuite — Local Shipper
Path: suite_core/shipper_local.py

Purpose:
- Copy published output from holding_tank/run_x/output/
- Into final local output_path
- Obey overwrite flag
- No remote logic, no side effects
"""

import shutil
from pathlib import Path


def ship_local(run_dir, final_output_path, overwrite=False):
    """
    Copy files from run-scoped holding_tank output
    into the user-selected final output directory.

    Args:
        run_dir (str | Path):
            holding_tank/run_YYYYMMDD_HHMMSS
        final_output_path (str | Path):
            user-selected destination directory
        overwrite (bool):
            overwrite existing files if True
    """

    run_dir = Path(run_dir).resolve()
    src_dir = (run_dir / "output").resolve()
    dst_dir = Path(final_output_path).resolve()

    if not src_dir.exists() or not src_dir.is_dir():
        raise RuntimeError(f"Missing source output dir: {src_dir}")

    dst_dir.mkdir(parents=True, exist_ok=True)

    copied = []
    skipped = []

    for src_file in src_dir.iterdir():
        if not src_file.is_file():
            continue

        dst_file = dst_dir / src_file.name

        if dst_file.exists() and not overwrite:
            skipped.append(str(dst_file))
            continue

        shutil.copy2(src_file, dst_file)
        copied.append(str(dst_file))

    return {
        "copied": copied,
        "skipped": skipped,
        "destination": str(dst_dir),
    }
