// ============================================================
// CyberSuite — State Manager (Global Singleton)
// ============================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Copyright: cyberfluence.com 2025
// Path:      ui/js/core/state_manager.js
//
// Description:
//     Centralized state singleton (IIFE) for the CyberSuite
//     UI. Manages paths, modes (local/remote), file extensions,
//     options, SSH validity status, and display label updates.
//
// Inputs:
//     - setPath(type, path) — type: "template"|"data"|"output"
//     - setMode(type, mode) — mode: "local"|"remote"
//     - setOption(key, value) — overwrite, render_mode, etc.
//     - setDataExt(value), setOutputExt(value) — file extensions
//     - setSSHStatus(scope, ok) — scope: "tmpl"|"data"|"out"
//
// Processing:
//     - Stores state in private closure (not globally mutable)
//     - Updates DOM labels on path/mode changes
//     - Evaluates publish-button gate on every display update
//     - Logs all mutations to CLI via BridgeAPI.logToCli()
//     - getState() returns deep copy (not reference)
//
// Outputs:
//     - Exposed on window.StateManager
//     - Public API: setPath, setMode, setOption, getMode,
//       getState, getAllPaths, setOutputExt, setDataExt,
//       getDataExt, setSSHStatus, getSSHStatus
//     - DOM side-effects: updates label elements by ID
// ============================================================

const StateManager = (() => {

  const state = {
    template: { path: "", mode: "local" },
    data:     { path: "", mode: "local", ext: ".json" },
    output:   { path: "", mode: "local", ext: ".html" },
    options:  { overwrite: false, render_mode: false, logging: false, log_type: "User" }
  };

  // ============================================================
  // SSH VALIDITY STATE (v1.0.1 — in-memory only)
  // ============================================================
  const sshStatus = {
    tmpl: false,
    data: false,
    out:  false
  };

  const log = msg =>
    (window.BridgeAPI?.logToCli?.(msg)) || null;


  // ------------------------------------------------------------
  // PATHS / MODES
  // ------------------------------------------------------------
  function setPath(type, path) {
    if (!state[type]) return;
    state[type].path = path;

    log(`${type}: path → ${path}`);
    updateDisplay(type);
  }

  function setMode(type, mode) {
    if (!state[type]) return;
    state[type].mode = mode;

    log(`${type}: mode → ${mode}`);
    updateDisplay(type);
  }

  function setOption(key, value) {
    if (!state.options.hasOwnProperty(key)) return;
    state.options[key] = value;
    log(`option '${key}' → ${value}`);
  }

  function getMode(type) {
    if (!state[type]) return "local";
    return state[type].mode || "local";
  }

  function updateDisplay(type) {
    const id_map = {
      template: "lbl_tmpl_status",
      data:     "lbl_data_status",
      output:   "lbl_output_status"
    };

    const lbl = document.getElementById(id_map[type]);
    if (!lbl) return;

    const info = state[type].path || `No ${type} selected`;
    lbl.textContent = info;

    lbl.classList.remove("active_local", "active_remote", "warning");
    lbl.classList.add(state[type].mode === "local" ? "active_local" : "active_remote");

    PublishBtn.evaluatePathGate();
  }

  // ------------------------------------------------------------
  // SSH STATUS (NEW)
  // ------------------------------------------------------------
  function setSSHStatus(scope, ok) {
    if (!(scope in sshStatus)) return;
    sshStatus[scope] = !!ok;
    log(`ssh(${scope}): status → ${ok ? "OK" : "FAIL"}`);
  }

  function getSSHStatus(scope) {
    return !!sshStatus[scope];
  }

  // ------------------------------------------------------------
  // GETTERS
  // ------------------------------------------------------------
  function getState() {
    return JSON.parse(JSON.stringify(state));
  }

  function getAllPaths() {
    return {
      template: { path: state.template.path, mode: state.template.mode },
      data:     { path: state.data.path,     mode: state.data.mode     },
      output:   { path: state.output.path,   mode: state.output.mode   }
    };
  }

  // ------------------------------------------------------------
  // EXTENSIONS
  // ------------------------------------------------------------
  function setOutputExt(value) {
    state.output.ext = value;
    log(`output ext → ${value}`);
  }

  function setDataExt(value) {
    state.data.ext = value;
    log(`data ext → ${value}`);
  }

  function getDataExt() {
    return state.data.ext || ".xml";
  }


  return {
    // core
    setPath,
    setMode,
    setOption,
    getMode,
    getState,
    getAllPaths,

    // extensions
    setOutputExt,
    setDataExt,
    getDataExt,

    // ssh validity (NEW)
    setSSHStatus,
    getSSHStatus
  };

})();

window.StateManager = StateManager;

// EOF