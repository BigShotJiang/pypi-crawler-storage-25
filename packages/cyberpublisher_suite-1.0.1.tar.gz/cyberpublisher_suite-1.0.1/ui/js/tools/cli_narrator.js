// Path: ui/js/tools/cli_narrator.js
// Purpose: user-facing narration sink for faux CLI (NOT file logging)

(function () {
  function getCliEl() {
    return document.querySelector('textarea[name="cli_output"]');
  }

  function nowUtcStamp() {
    const d = new Date();
    // YYYY-MM-DD HH:MM UTC
    const yyyy = d.getUTCFullYear();
    const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
    const dd = String(d.getUTCDate()).padStart(2, "0");
    const hh = String(d.getUTCHours()).padStart(2, "0");
    const mi = String(d.getUTCMinutes()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${mi} UTC`;
  }

  function shortJobId(jobId) {
    if (!jobId) return "----";
    // keep it simple: last 4
    return String(jobId).slice(-4);
  }

  function ensureTrailingNewline(s) {
    return s.endsWith("\n") ? s : s + "\n";
  }

  function write(block) {
    const cli = getCliEl();
    if (!cli) return;
    cli.value = ensureTrailingNewline(block);
    cli.scrollTop = cli.scrollHeight;
  }

  function append(line) {
    const cli = getCliEl();
    if (!cli) return;
    cli.value += ensureTrailingNewline(line);
    cli.scrollTop = cli.scrollHeight;
  }

  // "Receipt footer" bridge string
  function jobFooter(jobId) {
    return `Job: ${shortJobId(jobId)} • ${nowUtcStamp()}`;
  }

  // Expose globally (simple)
  window.CliNarrator = {
    write,
    append,
    jobFooter,
    nowUtcStamp
  };
})();
