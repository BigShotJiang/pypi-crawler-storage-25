// ========================================================
// CyberSuite — Publisher Execution State Machine
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/publish/publisher_exec_state.js
//
// Description:
//     Finite state machine for publisher execution phases.
//     Pure state object — no DOM, no side effects.
//
// Inputs:
//     - Method calls: arm(), start(), complete(), reset()
//     - Each method is guarded by current phase
//
// Processing:
//     - Phase transitions: idle → ready → armed → running
//       → complete
//     - Transitions are one-way with guard clauses
//     - reset() returns to 'ready' (not 'idle')
//
// Outputs:
//     - Exports: publishExecState object with .phase
//       property and transition methods
//     - No events emitted; consumers poll .phase directly
// ========================================================

export const publishExecState = {
  phase: 'idle',
  // idle | ready | armed | running | complete

  arm() {
    if (this.phase === 'ready' || this.phase === 'complete') {
      this.phase = 'armed';
    }
  },

  start() {
    if (this.phase === 'armed') {
      this.phase = 'running';
    }
  },

  complete() {
    if (this.phase === 'running') {
      this.phase = 'complete';
    }
  },

  reset() {
    this.phase = 'ready';
  }
};
