// ========================================================
// CyberSuite — Publisher Path Display Module
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/publish/modules/publisher_paths.js
//
// Description:
//     Sets path text and scope-based CSS class on label
//     elements. Pure display utility — no state, no logic.
//
// Inputs:
//     - el (HTMLElement) — label element to update
//     - text (string) — path text to display
//     - scope (string) — "local" or "remote"
//
// Processing:
//     - Sets element textContent to path text
//     - Removes both active-local and active-remote classes
//     - Adds active-remote if scope is "remote", else active-local
//
// Outputs:
//     - Exports: setPathDisplay(el, text, scope)
//     - DOM side-effect: updates element text + CSS class
// ========================================================

export function setPathDisplay(el, text, scope) {
  if (!el) return;

  el.textContent = text;

  el.classList.remove('active-local', 'active-remote');

  if (scope === 'remote') {
    el.classList.add('active-remote');
  } else {
    el.classList.add('active-local');
  }
}
