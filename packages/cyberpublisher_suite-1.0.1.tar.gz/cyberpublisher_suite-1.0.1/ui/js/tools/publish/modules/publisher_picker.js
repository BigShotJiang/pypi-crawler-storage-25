// ========================================================
// CyberSuite — Publisher Picker Module (Template + Data)
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/publish/modules/publisher_picker.js
//
// Description:
//     Remote file picker for template and data intents.
//     Handles remote directory navigation, breadcrumb
//     rendering, file selection, and commit with validation.
//
// Inputs:
//     - Config object: { publisherState, remoteModal,
//       fileList, btnOpen, btnCancel, btnCloseX,
//       labels: { template, data }, getIntent }
//     - pywebview.api.pick_file() responses (remote listings)
//
// Processing:
//     - Normalizes CWD paths for remote navigation
//     - Renders file listings with click/dblclick handlers
//     - Validates file extension on commit (.txt for template,
//       configured ext for data)
//     - Renders breadcrumb navigation from CWD segments
//
// Outputs:
//     - Updates publisherState[intent].path and .isRemote
//     - Updates DOM labels via setPathDisplay()
//     - Returns public API: { show, populateRemotePicker,
//       navigateRemote, normalizeCwd }
// ========================================================

export function initPublisherPicker({
  publisherState,
  remoteModal,
  fileList,
  btnOpen,
  btnCancel,
  btnCloseX,
  labels,      // { template, data }
  getIntent    // () => currentIntent
}) {

  let selectedRemotePath = null;

  // ------------------------------------------------------
  // PATH NORMALIZATION
  // ------------------------------------------------------
  function normalizeCwd(cwd) {
    if (!cwd || cwd === '.') return '/';
    if (!cwd.startsWith('/')) cwd = '/' + cwd;
    return cwd.replace(/\/+/g, '/');
  }

  // ------------------------------------------------------
  // PATH DISPLAY
  // ------------------------------------------------------
  function setPathDisplay(el, text) {
    el.textContent = text;
    el.classList.remove('active-local', 'active-remote');
    el.classList.add('active-remote');
  }

  // ------------------------------------------------------
  // REMOTE NAVIGATION
  // ------------------------------------------------------
  async function navigateRemote(cwd) {
    cwd = normalizeCwd(cwd);

    const res = await window.pywebview.api.pick_file({
      intent: getIntent(),
      scope: 'remote',
      cwd
    });

    if (res && res.success) populateRemotePicker(res);
  }

  // ------------------------------------------------------
  // REMOTE PICKER RENDER (FILES ONLY)
  // ------------------------------------------------------
  function populateRemotePicker(result) {
    fileList.innerHTML = '';
    selectedRemotePath = null;

    renderBreadcrumbs(result.cwd);

    result.entries.forEach(entry => {
      const li = document.createElement('li');
      li.textContent = entry.name;
      li.className = entry.type;

      // SINGLE CLICK → highlight file only
      li.addEventListener('click', () => {
        if (entry.type === 'dir') return;

        clearActive();
        li.classList.add('active');
        selectedRemotePath = normalizeCwd(`${result.cwd}/${entry.name}`);
      });

      // DOUBLE CLICK
      li.addEventListener('dblclick', () => {

        // DIR → navigate
        if (entry.type === 'dir') {
          navigateRemote(`${result.cwd}/${entry.name}`);
          return;
        }

        // FILE → commit
        commitSelection(
          normalizeCwd(`${result.cwd}/${entry.name}`)
        );
      });

      fileList.appendChild(li);
    });
  }

  function clearActive() {
    fileList.querySelectorAll('li').forEach(n =>
      n.classList.remove('active')
    );
  }

  // ------------------------------------------------------
  // COMMIT SELECTION (TEMPLATE / DATA ONLY)
  // ------------------------------------------------------
  function commitSelection(path) {
    const intent = getIntent();

    // HARD VALIDATION — REMOTE COMMIT
    if (intent === 'template') {
      if (!path.toLowerCase().endsWith('.txt')) {
        pickerError('Template rejected — must be .txt');
        return;
      }
    }

    if (intent === 'data') {
      const requiredExt = (publisherState.data.ext || '').toLowerCase();
      if (!path.toLowerCase().endsWith(requiredExt)) {
        pickerError(`Data rejected — must be ${requiredExt}`);
        return;
      }
    }

    if (intent !== 'template' && intent !== 'data') return;

    const map = {
      template: [publisherState.template, labels.template],
      data:     [publisherState.data,     labels.data]
    };

    const [state, label] = map[intent];
    state.path = path;
    state.isRemote = true;

    setPathDisplay(label, path);
    hide();
  }


  // ------------------------------------------------------
  // MODAL VISIBILITY
  // ------------------------------------------------------
  function show() {
    remoteModal.classList.add('active');
  }

  function hide() {
    remoteModal.classList.remove('active');
  }

  // ------------------------------------------------------
  // OPEN BUTTON (FILES ONLY)
  // ------------------------------------------------------
  btnOpen.addEventListener('click', () => {
    if (!selectedRemotePath) return;
    commitSelection(selectedRemotePath);
  });

  btnCancel.addEventListener('click', hide);
  if (btnCloseX) btnCloseX.addEventListener('click', hide);

  // ------------------------------------------------------
  // BREADCRUMBS
  // ------------------------------------------------------
  function renderBreadcrumbs(cwd) {
    const bc = remoteModal.querySelector('[data-role="brdcrmbs"]');
    if (!bc) return;

    bc.innerHTML = '';
    cwd = normalizeCwd(cwd);

    const ul = document.createElement('ul');
    bc.appendChild(ul);

    const mkLink = (label, path) => {
      const li = document.createElement('li');
      const a  = document.createElement('a');
      a.href = '#';
      a.textContent = label;
      a.addEventListener('click', e => {
        e.preventDefault();
        navigateRemote(path);
      });
      li.appendChild(a);
      return li;
    };

    ul.appendChild(mkLink('mnt', '/'));

    const parts = cwd.split('/').filter(Boolean);
    let acc = '';
    parts.forEach(p => {
      acc += '/' + p;
      ul.appendChild(document.createElement('li')).textContent = '/';
      ul.appendChild(mkLink(p, acc));
    });
  }

  // ------------------------------------------------------
  // PUBLIC API
  // ------------------------------------------------------
  return {
    show,
    populateRemotePicker,
    navigateRemote,
    normalizeCwd
  };
}

// EOF
