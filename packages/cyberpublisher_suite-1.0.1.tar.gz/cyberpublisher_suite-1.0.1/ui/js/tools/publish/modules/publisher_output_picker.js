// ========================================================
// CyberSuite — Remote Output Picker (Module)
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/publish/modules/publisher_output_picker.js
//
// Description:
//     Dedicated remote output directory picker. Folder
//     navigation only — selection committed via Open button.
//     No publish logic, no mkdir logic.
//
// Inputs:
//     - Config object: { remoteModal, fileList, btnOpen,
//       btnCancel, btnCloseX, onCommit }
//     - pywebview.api.pick_file() responses (directory listings)
//     - User click/dblclick on directory entries
//
// Processing:
//     - Normalizes CWD paths (strips trailing slashes, dedupes)
//     - Renders directory-only listings (files filtered out)
//     - Single click selects, double click navigates deeper
//     - Open button commits selectedPath or currentCwd
//     - Renders breadcrumb navigation from CWD segments
//
// Outputs:
//     - Calls onCommit(path) with selected directory path
//     - Returns public API: { populate, show, hide }
//     - DOM: renders file listings and breadcrumbs in remoteModal
// ========================================================

export function initRemoteOutputPicker({
  remoteModal,
  fileList,
  btnOpen,
  btnCancel,
  btnCloseX,
  onCommit
}) {

  let selectedPath = null;
  let currentCwd   = null;

  // ------------------------------------------------------
  // OUTPUT-SAFE NORMALIZER (dirs only)
  // ------------------------------------------------------
  function normalizeOutputCwd(path) {
    if (!path) return '/';

    let p = path.replace(/\/+/g, '/');

    if (!p.startsWith('/')) {
      p = '/' + p;
    }

    // strip trailing slash except root
    if (p.length > 1 && p.endsWith('/')) {
      p = p.slice(0, -1);
    }

    return p;
  }

  async function navigateOutputRemote(nextCwd) {
  const res = await window.pywebview.api.pick_file({
    intent: 'output',
    scope: 'remote',
    cwd: nextCwd,
    allowed_exts: null
  });

  console.log('[out-picker] REQUEST cwd →', nextCwd);

  if (res && res.success) {
    populate(res);
  }
}

  // ------------------------------------------------------
  // MODAL VISIBILITY
  // ------------------------------------------------------
  function show() {
    remoteModal.classList.add('active');
  }

  function hide() {
    remoteModal.classList.remove('active');
  }



  // ------------------------------------------------------
  // BREADCRUMBS 
  // ------------------------------------------------------
  function renderBreadcrumbs(cwd) {
  const bc = remoteModal.querySelector('[data-role="brdcrmbs"]');
  if (!bc) return;

  bc.innerHTML = '';
  cwd = normalizeOutputCwd(cwd);

  const ul = document.createElement('ul');
  bc.appendChild(ul);

  const mkLink = (label, path) => {
    const li = document.createElement('li');
    const a  = document.createElement('a');
    a.href = '#';
    a.textContent = label;
    a.addEventListener('click', e => {
      e.preventDefault();
      navigateOutputRemote(path);
    });
    li.appendChild(a);
    return li;
  };

  ul.appendChild(mkLink('mnt', '/'));

  const parts = cwd.split('/').filter(Boolean);
  let acc = '';
  parts.forEach(p => {
    acc += '/' + p;
    ul.appendChild(document.createElement('li')).textContent = '/';
    ul.appendChild(mkLink(p, acc));
  });
}



  // ------------------------------------------------------
  // RENDER
  // ------------------------------------------------------
  function populate(result) {
    if (!result || !result.cwd) return;

    currentCwd   = normalizeOutputCwd(result.cwd);
    selectedPath = null;

    renderBreadcrumbs(currentCwd);


    console.log('[out-picker] cwd:', currentCwd);

    fileList.innerHTML = '';

    result.entries.forEach(entry => {
      if (entry.type !== 'dir') return; // OUTPUT = dirs only

      const li = document.createElement('li');
      li.textContent = entry.name;
      li.className   = 'dir';

      // SINGLE CLICK → select directory
      li.addEventListener('click', () => {
        fileList.querySelectorAll('li').forEach(n =>
          n.classList.remove('active')
        );

        li.classList.add('active');
        selectedPath = normalizeOutputCwd(
          `${currentCwd}/${entry.name}`
        );

        console.log('[out-picker] selectedPath:', selectedPath);
      });

      // DOUBLE CLICK → navigate directory (NO COMMIT)
      li.addEventListener('dblclick', () => {
        const next = normalizeOutputCwd(
          `${currentCwd}/${entry.name}`
        );
        console.log('[out-picker] navigate:', next);
        navigateOutputRemote(next);
      });

      fileList.appendChild(li);
    });
  }

  // ------------------------------------------------------
  // ACTIONS
  // ------------------------------------------------------
  btnOpen.addEventListener('click', () => {
    const path = selectedPath || currentCwd;

    console.log('[out-picker] OPEN commit:', path);

    if (!path) return;
    onCommit(path);
    hide();
  });

  btnCancel.addEventListener('click', hide);
  if (btnCloseX) btnCloseX.addEventListener('click', hide);

  // ------------------------------------------------------
  // PUBLIC API
  // ------------------------------------------------------
  return {
    populate,
    show,
    hide
  };
}

// EOF
