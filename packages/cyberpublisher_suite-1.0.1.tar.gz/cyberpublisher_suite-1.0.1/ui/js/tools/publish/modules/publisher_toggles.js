// ========================================================
// CyberSuite — Publisher Toggle Module
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/publish/modules/publisher_toggles.js
//
// Description:
//     Wires local/remote scope toggles for template, data,
//     and output. Enforces mutual exclusion and invalidates
//     stale paths on scope change. Also wires render mode toggle.
//
// Inputs:
//     - Config object with publisherState + 6 checkbox elements
//       (local/remote pairs for template, data, output)
//     - Change events on scope checkboxes and render mode toggle
//
// Processing:
//     - Checkbox change: unchecks opposite, updates isRemote flag
//     - Nullifies path on scope change (prevents stale state)
//     - Render mode: toggles indexMode option + updates label
//     - Calls disarmPublish() on render mode change (if available)
//
// Outputs:
//     - Mutates publisherState template/data/output isRemote + path
//     - Mutates publisherState.options.indexMode
//     - Updates render mode label text
// ========================================================

export function initPublisherToggles({
  publisherState,

  chkLocalTmpl,
  chkRemoteTmpl,
  btnTemplate,

  chkLocalData,
  chkRemoteData,
  btnData,

  chkLocalOutput,
  chkRemoteOutput,
  btnOutput
}) {

  // helper — sync picker button color to scope
  function setBtnScope(btn, isRemote) {
    if (!btn) return;
    btn.classList.remove('local-active', 'remote-active');
    btn.classList.add(isRemote ? 'remote-active' : 'local-active');
  }

  // -------------------------------
  // TEMPLATE
  // -------------------------------
  chkLocalTmpl.addEventListener('change', () => {
    chkRemoteTmpl.checked = !chkLocalTmpl.checked;
    publisherState.template.isRemote = !chkLocalTmpl.checked;
    publisherState.template.path = null; // 🔑 reset stale state
    setBtnScope(btnTemplate, publisherState.template.isRemote);
  });

  chkRemoteTmpl.addEventListener('change', () => {
    chkLocalTmpl.checked = !chkRemoteTmpl.checked;
    publisherState.template.isRemote = chkRemoteTmpl.checked;
    publisherState.template.path = null; // 🔑 reset stale state
    setBtnScope(btnTemplate, publisherState.template.isRemote);
  });

  // -------------------------------
  // DATA
  // -------------------------------
  chkLocalData.addEventListener('change', () => {
    chkRemoteData.checked = !chkLocalData.checked;
    publisherState.data.isRemote = !chkLocalData.checked;
    publisherState.data.path = null; // 🔑 reset stale state
    setBtnScope(btnData, publisherState.data.isRemote);
  });

  chkRemoteData.addEventListener('change', () => {
    chkLocalData.checked = !chkRemoteData.checked;
    publisherState.data.isRemote = chkRemoteData.checked;
    publisherState.data.path = null; // 🔑 reset stale state
    setBtnScope(btnData, publisherState.data.isRemote);
  });

// -------------------------------
// RENDER MODE (DOCS / INDEX)
// -------------------------------
const chkRenderMode = document.getElementById('chk_render_mode');
const lblRenderMode = document.getElementById('lbl_render_mode');

if (chkRenderMode) {
  // initial label sync
  lblRenderMode.textContent = chkRenderMode.checked ? 'Index mode' : 'Docs mode';

  chkRenderMode.addEventListener('change', () => {
    publisherState.options.indexMode = chkRenderMode.checked;

    lblRenderMode.textContent = chkRenderMode.checked
      ? 'Index mode'
      : 'Docs mode';

    // changing render mode invalidates publish snapshot
    if (typeof disarmPublish === 'function') {
      disarmPublish('render mode toggled');
    }
  });
}


  // -------------------------------
  // OUTPUT (do NOT change behavior — reset only)
  // -------------------------------
  chkLocalOutput.addEventListener('change', () => {
    chkRemoteOutput.checked = !chkLocalOutput.checked;
    publisherState.output.isRemote = !chkLocalOutput.checked;
    publisherState.output.path = null; // reset only, logic untouched
    setBtnScope(btnOutput, publisherState.output.isRemote);
  });

  chkRemoteOutput.addEventListener('change', () => {
    chkLocalOutput.checked = !chkRemoteOutput.checked;
    publisherState.output.isRemote = chkRemoteOutput.checked;
    publisherState.output.path = null; // reset only, logic untouched
    setBtnScope(btnOutput, publisherState.output.isRemote);
  });
}
