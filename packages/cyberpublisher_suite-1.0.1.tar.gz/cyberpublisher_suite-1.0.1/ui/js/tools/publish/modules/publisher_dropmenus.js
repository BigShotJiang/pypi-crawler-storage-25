// ========================================================
// CyberSuite — Publisher Dropmenus
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/publish/modules/publisher_dropmenus.js
//
// Description:
//     Wires data and output file extension dropdown menus.
//     Reads initial values from StateManager and updates
//     on user selection.
//
// Inputs:
//     - Config object: { publisherState }
//     - DOM: #data_ext_select, #output_ext_select dropdowns
//     - Click events on [data-value] dropdown option elements
//     - StateManager.getDataExt() / getState().output.ext
//
// Processing:
//     - Initializes dropdown display from StateManager values
//     - On option click: updates display text + StateManager ext
//     - Respects .disabled class on dropdown container (no-op)
//
// Outputs:
//     - Calls StateManager.setDataExt() / setOutputExt()
//     - Updates dropdown .dropdown-selected text content
// ========================================================

export function initPublisherDropmenus({ publisherState }) {

  // ------------------------------------------------------
  // DATA FILE EXTENSION DROPDOWN
  // ------------------------------------------------------
  const dataExtSelect = document.getElementById('data_ext_select');
  if (dataExtSelect) {

    const selected = dataExtSelect.querySelector('.dropdown-selected');
    const options  = dataExtSelect.querySelectorAll('.dropdown-options [data-value]');

    // init from StateManager (authoritative)
    const currentDataExt = StateManager.getDataExt();
    selected.textContent = currentDataExt;

    options.forEach(opt => {
      opt.addEventListener('click', () => {
        if (dataExtSelect.classList.contains('disabled')) return;

        const val = opt.dataset.value;
        if (!val) return;

        selected.textContent = val;
        StateManager.setDataExt(val);

        console.log('[publisher] data.ext =', val);
      });
    });
  }

  // ------------------------------------------------------
  // OUTPUT FILE EXTENSION DROPDOWN
  // ------------------------------------------------------
  const outputExtSelect = document.getElementById('output_ext_select');
  if (outputExtSelect) {

    const selected = outputExtSelect.querySelector('.dropdown-selected');
    const options  = outputExtSelect.querySelectorAll('.dropdown-options [data-value]');

    // init from StateManager (authoritative)
    const currentOutputExt = StateManager.getState().output.ext;
    selected.textContent = currentOutputExt;

    options.forEach(opt => {
      opt.addEventListener('click', () => {
        if (outputExtSelect.classList.contains('disabled')) return;

        const val = opt.dataset.value;
        if (!val) return;

        selected.textContent = val;
        StateManager.setOutputExt(val);

        console.log('[publisher] output.ext =', val);
      });
    });
  }
}
