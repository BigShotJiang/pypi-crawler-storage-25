// ========================================================
// CyberSuite — Publisher UI Controller
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/publish/publisher_ui.js
//
// Description:
//     Master controller for the Publisher tool panel.
//     Wires DOM elements, pickers, toggles, dropmenus,
//     and the publish execution flow after panel injection.
//
// Inputs:
//     - DOM: Panel elements (buttons, checkboxes, labels,
//       remote picker overlay) — resolved by ID after injection
//     - Imports: publisherState, picker modules, path display,
//       output picker, dropmenus
//     - User actions: click events on template/data/output
//       buttons, publish button, reset button
//
// Processing:
//     - Initializes sub-modules (toggles, pickers, dropmenus)
//     - Validates publish eligibility (template + data + output)
//     - Manages arm/confirm/execute publish flow
//     - Delegates file picking to pywebview.api.pick_file()
//     - Enforces file extension validation per intent
//
// Outputs:
//     - Updates publisherState with selected paths/scopes
//     - Updates DOM labels with path display
//     - Calls pywebview.api.publish() on confirmed execution
//     - Exposes window.initPublisherUI for panel_switcher
// ========================================================

import { publisherState } from './publisher_state.js';
import { initPublisherPicker } from './modules/publisher_picker.js';
import { initPublisherToggles } from './modules/publisher_toggles.js';
import { setPathDisplay } from './modules/publisher_paths.js';
import { initRemoteOutputPicker } from './modules/publisher_output_picker.js';
import { initPublisherDropmenus } from './modules/publisher_dropmenus.js';

console.log('output picker import =', initRemoteOutputPicker);

// ------------------------------------------------------------------
// GLOBAL PICKER ERROR — FALLBACK HANDLER
//
// This intentionally uses `alert()` as a LAST-RESORT safety net.
//
// Rationale:
// - Picker modules may fail before UI state or modals are initialized
// - This guarantees the user sees *something* instead of silent failure
// - NOT part of the normal UX path (scribe is fully modalized)
//
// Future plan:
// - When Publisher UI is fully normalized to generic modals,
//   this can be safely upgraded to call `openGenericInfoModal()`
//   with `alert()` retained only as a hard fallback.
//
// In short:
//   Safety > Silence
// ------------------------------------------------------------------
window.pickerError = function (msg) {
  if (typeof openGenericInfoModal === 'function') {
    openGenericInfoModal(msg);
  } else {
    alert(msg); // absolute fallback
  }
};


// ------------------------------------------------------
// LOG CONFIG — read live from DOM (shared across tools)
// ------------------------------------------------------
function getLogCfgFromUI() {
  const chk = document.getElementById("chk_logging");
  const selected = document.querySelector("#log_mode_select .dropdown-selected");
  const raw = selected ? selected.textContent.trim() : "User";
  const level = raw.toLowerCase() === "user" ? "snapshot" : raw.toLowerCase();
  return { retain_all: !!(chk && chk.checked), level };
}

// ------------------------------------------------------
// PUBLISH GUARDS
// ------------------------------------------------------
function getPublishEligibility(state) {
  const missing = [];
  if (!state.template.path) missing.push('template');
  if (!state.data.path)     missing.push('data');
  if (!state.output.path)   missing.push('output');

  return {
    ok: missing.length === 0,
    missing
  };
}

// ------------------------------------------------------
// PUBLISH CONFIRM UI HELPERS
// ------------------------------------------------------
function showPublishConfirm(show) {
  const wrap = document.querySelector('[data-role="publish-confirm"]');
  if (!wrap) return;

  wrap.classList.toggle('hidden', !show);

  if (!show) {
    const chk = wrap.querySelector('[data-role="publish-check"]');
    if (chk) chk.checked = false;
  }
}

function isPublishConfirmed() {
  const chk = document.querySelector('[data-role="publish-check"]');
  return !!chk && chk.checked === true;
}

// ========================================================
// INIT — CALLED AFTER PANEL INJECTION
// ========================================================
function initPublisherUI() {
  console.log('[publisher] initPublisherUI()');
  console.log('[publisher_ui] controller loaded');
  window.trapTabCycle(document.querySelector('.publisher-panel'));

  // ------------------------------------------------------
  // EVENT WIRING — prevent duplicate handlers on re-init
  // ------------------------------------------------------
  window.__pub_abort?.abort();
  window.__pub_abort = new AbortController();
  const { signal } = window.__pub_abort;

  // ------------------------------------------------------
  // DOM CACHE
  // ------------------------------------------------------
  const btnTemplate   = document.getElementById('btn_template');
  const btnData       = document.getElementById('btn_data');
  const btnOutput     = document.getElementById('btn_output');

  const chkLocalTmpl    = document.getElementById('chk_local_tmpl');
  const chkRemoteTmpl   = document.getElementById('chk_remote_tmpl');
  const chkLocalData    = document.getElementById('chk_local_data');
  const chkRemoteData   = document.getElementById('chk_remote_data');
  const chkLocalOutput  = document.getElementById('chk_local_out');
  const chkRemoteOutput = document.getElementById('chk_remote_out');

  // 🔑 OVERWRITE TOGGLE (MISSING BEFORE)
  const chkOverwrite = document.getElementById('chk_overwrite');

  const lblTmplStatus   = document.getElementById('lbl_tmpl_status');
  const lblDataStatus   = document.getElementById('lbl_data_status');
  const lblOutputStatus = document.getElementById('lbl_output_status');

  const remoteModal = document.getElementById('remote_picker_overlay');
  const fileList    = remoteModal.querySelector('.file-listing');
  const btnOpen     = remoteModal.querySelector('[data-action="picker-open"]');
  const btnCancel   = remoteModal.querySelector('[data-action="picker-cancel"]');
  const btnCloseX   = remoteModal.querySelector('.modal-close');

  if (!window.pywebview?.api) {
    console.warn('[publisher] pywebview API not ready yet (will retry on action)');
  }

  // ------------------------------------------------------
  // STATE
  // ------------------------------------------------------
  publisherState.__armed = false;

  function disarmPublish(reason) {
    if (!publisherState.__armed) return;
    publisherState.__armed = false;
    showPublishConfirm(false);
    console.log('[publisher] disarmed:', reason);
  }

  let currentIntent = 'template';
  const getIntent = () => currentIntent;

  // ------------------------------------------------------
  // INIT TOGGLES
  // ------------------------------------------------------
  initPublisherToggles({
    publisherState,
    chkLocalTmpl,
    chkRemoteTmpl,
    btnTemplate,
    chkLocalData,
    chkRemoteData,
    btnData,
    chkLocalOutput,
    chkRemoteOutput,
    btnOutput
  });

  initPublisherDropmenus({ publisherState });


  // ------------------------------------------------------
  // OVERWRITE TOGGLE WIRING  ✅ FIX
  // ------------------------------------------------------
  if (chkOverwrite) {
    chkOverwrite.addEventListener('change', () => {
      publisherState.options.overwrite = chkOverwrite.checked;
      console.log('[publisher] overwrite =', publisherState.options.overwrite);
      disarmPublish('overwrite changed');
    }, { signal });
  }

  // ------------------------------------------------------
  // LOGGING CONTROLS
  // --- Logging toggle enables/disables the Log Mode dropdown ---
  // ------------------------------------------------------
  const chkLogging = document.getElementById('chk_logging');
  const logModeWrap = document.getElementById('log_mode_select');
  const logModeTooltip = logModeWrap?.closest('.tooltip');

  function syncLogModeUI() {
    const on = !!(chkLogging && chkLogging.checked);
    logModeWrap?.classList.toggle('disabled', !on);
    if (logModeTooltip) {
      logModeTooltip.dataset.tooltip = on
        ? 'Select logging mode'
        : 'You must enable logging to select logging mode';
    }
  }

  chkLogging?.addEventListener('change', () => {
    publisherState.options.logging = chkLogging.checked;
    syncLogModeUI();
  }, { signal });
  syncLogModeUI();

  const logModeSelect = document.getElementById('log_mode_select');
  const logSelected = logModeSelect?.querySelector('.dropdown-selected');

  logModeSelect?.addEventListener('click', (e) => {
    if (logModeSelect.classList.contains('disabled')) return;
    const opt = e.target.closest('[data-value]');
    if (!opt) return;
    if (logSelected) logSelected.textContent = opt.dataset.value;
    publisherState.options.logMode = opt.dataset.value;
  }, { signal });

  // ------------------------------------------------------
  // PICKERS
  // ------------------------------------------------------
  const picker = initPublisherPicker({
    publisherState,
    remoteModal,
    fileList,
    btnOpen,
    btnCancel,
    btnCloseX,
    labels: {
      template: lblTmplStatus,
      data: lblDataStatus,
      output: lblOutputStatus
    },
    getIntent
  });

  const remoteOutputPicker = initRemoteOutputPicker({
    remoteModal,
    fileList,
    btnOpen,
    btnCancel,
    btnCloseX,
    onCommit: (path) => {
      publisherState.output.path = path;
      publisherState.output.isRemote = true;
      setPathDisplay(lblOutputStatus, path, 'remote');
      disarmPublish('output changed (remote)');
    }
  });

  
  // ------------------------------------------------------
  // PICK TEMPLATE
  // ------------------------------------------------------
  btnTemplate.addEventListener('click', async () => {
    currentIntent = 'template';

    const res = await window.pywebview.api.pick_file({
      intent: 'template',
      scope: publisherState.template.isRemote ? 'remote' : 'local',
      cwd: publisherState.template.path || '/',
      allowed_exts: ['.txt']
    });

    if (res && res.needs_creds) {
      const btn = document.querySelector(
        `[data-open-modal="${currentIntent}"]`
      );
      btn?.click();
      return;
    }

    if (!res || res.success === false) {
      pickerError('Invalid file type — please try again');
      return;
    }

    if (res.path && !res.path.toLowerCase().endsWith('.txt')) {
      pickerError('Template rejected — must be .txt');
      return;
    }

    if (res.scope === 'remote') {
      picker.populateRemotePicker(res);
      picker.show();
      return;
    }

    publisherState.template.path = res.path;
    publisherState.template.isRemote = false;
    setPathDisplay(lblTmplStatus, res.path, 'local');
    disarmPublish('template changed');
  }, { signal });

  // ------------------------------------------------------
  // PICK DATA
  // ------------------------------------------------------
  btnData.addEventListener('click', async () => {
    currentIntent = 'data';

    const res = await window.pywebview.api.pick_file({
      intent: 'data',
      scope: publisherState.data.isRemote ? 'remote' : 'local',
      cwd: publisherState.data.path || '/',
      allowed_exts: [StateManager.getDataExt()]
    });

    if (res && res.needs_creds) {
      const btn = document.querySelector(
        `[data-open-modal="${currentIntent}"]`
      );
      btn?.click();
      return;
    }

    if (!res || res.success === false) {
      pickerError('Invalid file type — please try again');
      return;
    }

    const requiredExt = (publisherState.data.ext || '').toLowerCase();
    if (res.path && !res.path.toLowerCase().endsWith(requiredExt)) {
      pickerError(`Data rejected — must be ${requiredExt}`);
      return;
    }

    if (res.scope === 'remote') {
      picker.populateRemotePicker(res);
      picker.show();
      return;
    }

    publisherState.data.path = res.path;
    publisherState.data.isRemote = false;
    setPathDisplay(lblDataStatus, res.path, 'local');
    disarmPublish('data changed');
  }, { signal });

  // ------------------------------------------------------
  // PICK OUTPUT
  // ------------------------------------------------------
  btnOutput.addEventListener('click', async () => {
    currentIntent = 'output';

    const res = await window.pywebview.api.pick_file({
      intent: 'output',
      scope: publisherState.output.isRemote ? 'remote' : 'local',
      cwd: publisherState.output.isRemote && publisherState.output.path
        ? publisherState.output.path
        : '/',
      allowed_exts: null
    });

    if (res && res.needs_creds) {
      const btn = document.querySelector(
        `[data-open-modal="${currentIntent}"]`
      );
      btn?.click();
      return;
    }

    if (!res || res.success === false) return;

    if (res.scope === 'remote') {
      remoteOutputPicker.populate(res);
      remoteOutputPicker.show();
      return;
    }

    publisherState.output.path = res.path;
    publisherState.output.isRemote = false;
    setPathDisplay(lblOutputStatus, res.path, 'local');
    disarmPublish('output changed');
  }, { signal });


// ------------------------------------------------------
// CLEAR SYSTEM OUTPUT
// ------------------------------------------------------
document.addEventListener("click", (e) => {
  const btn = e.target.closest('[data-action="clear-output"]');
  if (!btn) return;

  const cli = document.querySelector('textarea[name="cli_output"]');
  if (!cli) return;

  const tag = (cli.tagName || "").toLowerCase();
  if (tag === "textarea" || tag === "input") cli.value = "";
  else cli.textContent = "";
}, { signal });

// ------------------------------------------------------
// PUBLISH
// ------------------------------------------------------
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-action="publish"]');
  if (!btn) return;

  // ----------------------------------------------
  // Eligibility guard — truthful, moment-by-moment
  // ----------------------------------------------
  const { ok, missing } = getPublishEligibility(publisherState);
  if (!ok) {
    // HARD RULE: confirm UI is never shown if not eligible
    publisherState.__armed = false;
    showPublishConfirm(false);

    openGenericInfoModal(
      `Missing required input${missing.length > 1 ? 's' : ''}:\n\n• ${missing.join('\n• ')}`
    );
    return;
  }

  // ----------------------------------------------
  // Arm publish + show snapshot / confirm
  // ----------------------------------------------
  if (!publisherState.__armed) {
    publisherState.__armed = true;

    // Narration: confirm receipt (user-facing)
    const jobId = crypto?.randomUUID ? crypto.randomUUID() : `job_${Date.now()}`;
    publisherState.__job_id = jobId;

    const tScope = publisherState.template.isRemote ? "REMOTE 🌐" : "LOCAL 📁";
    const dScope = publisherState.data.isRemote ? "REMOTE 🌐" : "LOCAL 📁";
    const oScope = publisherState.output.isRemote ? "REMOTE 🌐" : "LOCAL 📁";

    const lines = [
      "PUBLISH — Confirm Snapshot",
      `Template (${tScope}): ${publisherState.template.path || "[none]"}`,
      `Data     (${dScope}): ${publisherState.data.path || "[none]"}`,
      `Output   (${oScope}): ${publisherState.output.path || "[none]"}`,
      (() => {
        const on = [];
        if (publisherState.options.remote_out) on.push("remote_out");
        if (publisherState.options.dry_run)    on.push("dry_run");
        if (publisherState.options.validate)   on.push("validate");
        if (publisherState.options.overwrite)  on.push("overwrite");
        if (publisherState.options.indexMode)  on.push("index_mode");
        return `Options: ${on.length ? on.join(", ") : "(none)"}`;
      })(),
      window.CliNarrator.jobFooter(jobId)
    ];

    window.CliNarrator.append(lines.join("\n"));

    showPublishConfirm(true);
    return;
  }

  // ----------------------------------------------
  // Confirm gate
  // ----------------------------------------------
  if (!isPublishConfirmed()) return;

  // ----------------------------------------------
  // EXECUTION BOUNDARY — side effects start here
  // ----------------------------------------------
  publisherState.__armed = false;
  showPublishConfirm(false);

  // ✅ Narration header (separates runs)
  const _scopeEmoji = publisherState.output.isRemote ? "🌐" : "📁";
  const _scopeLabel = publisherState.output.isRemote ? "REMOTE" : "LOCAL";
  window.CliNarrator.append(
    `✅ Publish began: ${window.CliNarrator.nowUtcStamp()}`
  );

  btn.classList.add('inactive');

  const res = await window.pywebview.api.publish({
    job_id:   publisherState.__job_id,
    template: { ...publisherState.template },
    data:     { ...publisherState.data },
    output:   { ...publisherState.output, ext: StateManager.getState().output.ext },
    options:  { ...publisherState.options },
    log: getLogCfgFromUI()
  });

  btn.classList.remove('inactive');

  // ✅ Narration report (post-run)
  const _ok = !!res?.ok;
  const files = Array.isArray(res?.files) ? res.files : [];
  const execMs = (typeof res?.timing_ms === "number") ? res.timing_ms : null;
  const outPath = publisherState.output.path || "[no output]";

  console.log("[publisher_ui] files for narration:", files);

  window.CliNarrator.append(
    [
      _ok ? "✅ Publish complete" : "❌ Publish failed",
      `${window.CliNarrator.nowUtcStamp()}`,
      `Files: ${files.length}`,
      `Target (${_scopeLabel} ${_scopeEmoji}): ${outPath}`,
      ...files.map(f => `${_scopeEmoji} ${String(f).split("/").pop()}`),
      "################",
      `executed: ${execMs !== null ? execMs : "?"} ms`,
      "Always verify output at target.",
      "################"
    ].join("\n")
  );

  console.log('[publisher] publish result →', res);
}, { signal });

// ------------------------------------------------------
// RESET PATHS (paths only — no config reset)
// ------------------------------------------------------
const btnResetPaths = document.querySelector(
  '.publish_btn[data-action="reset"]'
);

if (btnResetPaths) {
  btnResetPaths.addEventListener('click', () => {

    // clear paths only
    publisherState.template.path = null;
    publisherState.data.path     = null;
    publisherState.output.path   = null;

    // reset labels
    lblTmplStatus.textContent   = 'No Template Selected';
    lblDataStatus.textContent   = 'No Data File Selected';
    lblOutputStatus.textContent = 'No Output Selected';

    // disarm publish + hide confirm
    publisherState.__armed = false;
    showPublishConfirm(false);

    console.log('[publisher] paths reset');
  }, { signal });
}

  // ------------------------------------------------------
  // INITIAL STATE
  // ------------------------------------------------------
  publisherState.output.ext ??= '.html';


  chkLocalTmpl.checked    = true;
  chkRemoteTmpl.checked   = false;
  chkLocalData.checked    = true;
  chkRemoteData.checked   = false;
  chkLocalOutput.checked  = true;
  chkRemoteOutput.checked = false;

  lblTmplStatus.textContent   = 'No Template Selected';
  lblDataStatus.textContent   = 'No Data File Selected';
  lblOutputStatus.textContent = 'No Output Selected';
}

// ========================================================
window.initPublisherUI = initPublisherUI;
// ========================================================
