// ========================================================
// CyberSuite — Publisher State (Pure State Holder)
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/publish/publisher_state.js
//
// Description:
//     Pure state object for the Publisher tool. Tracks
//     template/data/output paths, remote flags, and options.
//     No DOM access, no bridge calls.
//
// Inputs:
//     - Direct property assignment from publisher_ui.js
//       and picker modules
//
// Processing:
//     - Passive state container — no logic, no validation
//     - Consumers read/write properties directly
//
// Outputs:
//     - Exports: publisherState object
//     - Properties: template, data, output (path + isRemote),
//       options (overwrite, indexMode, logging, logMode)
// ========================================================

export const publisherState = {
  template: {
    isRemote: false,
    path: null
  },

  data: {
    isRemote: false,
    path: null
  },

  output: {
    isRemote: false,
    path: null
  },

  options: {
    overwrite: false,
    indexMode: false,
    logging: false,
    logMode: 'User'
  }
};
