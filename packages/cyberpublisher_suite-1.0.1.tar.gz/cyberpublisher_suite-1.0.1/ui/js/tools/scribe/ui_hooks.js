// ============================================================
// CyberScribe — UI Hooks (CyberSuite integrated)
// ============================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/scribe/ui_hooks.js
//
// Description:
//     Master controller for the Scribe tool. Wires Create
//     and Append panels, form collection, JSON save/load,
//     theme switching, and top-bar navigation.
//
// Inputs:
//     - DOM: Create panel inputs (file-name, title, h1, h2)
//     - DOM: Append panel inputs + CLI textarea for pg_cnt
//     - DOM: Top-bar buttons (create, edit, reload, close)
//     - ScribeModel API (engineNew, engineAppend, engineSave)
//     - pywebview.api: pick_file, scribe_save_json, load_json_file
//
// Processing:
//     - Create: collects form fields → ScribeModel.engineNew →
//       pick output dir → scribe_save_json
//     - Append: load JSON → collect record fields →
//       ScribeModel.engineAppend → scribe_save_json
//     - Validates via ScribeModel; shows errors via generic modal
//     - Escapes HTML content for JSON storage
//     - Manages loadedDoc/loadedPath state for append operations
//
// Outputs:
//     - Saves JSON files via pywebview.api.scribe_save_json
//     - Displays success/error via openGenericInfoModal
//     - Exposes window.initScribeUI for panel_switcher
//     - Sets theme and channel visibility on nav actions
// ============================================================

// ------------------------------------------------------------
// GLOBAL STATE (tool-scoped, not DOM-scoped)
// ------------------------------------------------------------
const root = document.documentElement;

let loadedDoc  = null;
let loadedPath = null;

// ------------------------------------------------------------
// SCRIBE UI — USER-FACING MESSAGES (SINGLE SOURCE)
// ------------------------------------------------------------
const SCRIBE_MSG = {
  INVALID_filename: 'Missing or invalid File Name: "need-file-name"',
  MISSING_filename: 'Missing or invalid File Name: "need-file-name"',
  MISSING_doc_title: 'Missing document title: "No File Title"',
  MISSING_h1_cnt: 'Missing H1: "My Topic Heading"',
  MISSING_h2_cnt: 'Missing H2: "Topic supporting subheading"',
  MISSING_pg_cnt: 'Missing page content',
  DUPLICATE_filename: 'An entry with this filename already exists',

  DOC_NOT_LOADED: 'No JSON file loaded',
  DOC_INVALID: 'Invalid document',
  save_cancelled: 'Save cancelled',
  json_load_failed: 'Failed to load JSON',

  create_success: path => `JSON created:\n${path}`,
  append_success: 'Entry appended and saved successfully.'
};

// ------------------------------------------------------------
// THEME / CHANNEL VISIBILITY
// ------------------------------------------------------------
function setTheme(t) {
  root.setAttribute("data-theme", t);
}

function showChannel(name) {
  document.querySelectorAll(".channel").forEach(c => {
    c.classList.toggle("active", c.dataset.channel === name);
  });
}

// ------------------------------------------------------------
// HTML → JSON ESCAPER
// ------------------------------------------------------------
function escapeHtmlForJson(html) {
  const el = document.createElement("textarea");
  el.textContent = html;
  return el.value;
}

// ============================================================
// INIT — CALLED BY panel_switcher.js AFTER PANEL INJECTION
// ============================================================
function initScribeUI() {
  console.log("[scribe] initScribeUI()");

  const createPanel = document.querySelector(".scribe-create-panel");
  const appendPanel = document.querySelector(".scribe-append-panel");

  if (!createPanel && !appendPanel) {
    console.warn("[scribe] no scribe panels found — abort init");
    return;
  }

  const btnCreate = document.getElementById("btn_topbar_create");
  const btnEdit   = document.getElementById("btn_topbar_edit");
  const btnReload = document.getElementById("btn_topbar_reload");
  const btnClose  = document.getElementById("btn_app_close");

  // ==========================================================
  // CREATE PANEL
  // ==========================================================
  if (createPanel) {
    window.trapTabCycle(createPanel);

    const btnCreateSave = createPanel.querySelector(
      '.publish_btn[data-action="create"]'
    );

    const btnResetForm = createPanel.querySelector(
      '.publish_btn[data-action="reset"]'
    );

    function collectCreateFields() {
      const meta = {};
      let fileName = "";

      createPanel.querySelectorAll("input, textarea").forEach(el => {
        const v = el.value.trim();
        if (!v) return;

        if (el.name === "file-name") fileName = v;
        else meta[el.name] = v;
      });

      meta.filename = fileName;

      return { fileName, meta };
    }

    if (btnCreateSave) {
      btnCreateSave.addEventListener("click", async () => {

        const { fileName, meta } = collectCreateFields();

        const res = ScribeModel.engineNew(meta, fileName);
        if (!res.ok) {
          openGenericInfoModal(SCRIBE_MSG[res.error] || res.error);
          return;
        }

        const jsonRes = ScribeModel.engineSave(res.doc);
        if (!jsonRes.ok) {
          openGenericInfoModal(SCRIBE_MSG[jsonRes.error] || jsonRes.error);
          return;
        }

        const pick = await window.pywebview.api.pick_file({
          intent: "output",
          scope: "local",
          mode: "directory",
          purpose: "scribe_create"
        });

        if (!pick || pick.success === false) {
          openGenericInfoModal(SCRIBE_MSG.save_cancelled);
          return;
        }

        const saveResp = await window.pywebview.api.scribe_save_json(
          jsonRes.json,
          res.fileName,
          pick.path
        );

        if (!saveResp.ok) {
          openGenericInfoModal(saveResp.error);
          return;
        }

        openGenericInfoModal(
          SCRIBE_MSG.create_success(saveResp.path)
        );
      });
    }

    if (btnResetForm) {
      btnResetForm.addEventListener("click", () => {
        createPanel.querySelectorAll("input, textarea").forEach(el => {
          el.value = "";
        });
      });
    }
  }

// ==========================================================
// APPEND PANEL — LOAD JSON
// ==========================================================
if (appendPanel) {
  window.trapTabCycle(appendPanel);

  const btnAppendLoad  = appendPanel.querySelector('[data-action="load-json"]');
  const btnAppendReset = appendPanel.querySelector(
    '.publish_btn[data-action="reset"]'
  );

  const pathDisplay = appendPanel.querySelector(".path_display");
  const primer      = appendPanel.querySelector(".append-primer");

  if (btnAppendReset) {
    btnAppendReset.addEventListener("click", wipeAppendInputs);
  }

  if (btnAppendLoad) {
    btnAppendLoad.addEventListener("click", async () => {

      const pick = await window.pywebview.api.pick_file({
        intent: "data",
        scope: "local",
        mode: "file"
      });

      if (!pick || pick.success === false) return;

      const resp = await window.pywebview.api.load_json_file(pick.path);
      if (!resp || !resp.ok) {
        openGenericInfoModal(
          SCRIBE_MSG[resp?.error] || SCRIBE_MSG.json_load_failed
        );
        return;
      }

      loadedDoc  = resp.doc;
      loadedPath = pick.path;

      if (pathDisplay) {
        pathDisplay.textContent = `Loaded: ${pick.path}`;
      }

      if (primer && loadedDoc) {
        const lastRec =
          Array.isArray(loadedDoc.records) && loadedDoc.records.length
            ? loadedDoc.records[loadedDoc.records.length - 1]
            : null;

        primer.innerHTML = lastRec
          ? `<strong>Last entry:</strong>
             ${lastRec.filename || "(no filename)"} —
             ${lastRec.h1_cnt || "(no h1)"}<br>
             <em>${lastRec.timestamp || ""}</em>`
          : `<strong>New file:</strong>
             ${loadedDoc.meta?.title || "(untitled)"}<br>
             <em>No entries yet</em>`;
      }
    });
  }
}

  // ==========================================================
  // APPEND — SAVE ENTRY
  // ==========================================================
  const btnAppendSave = appendPanel?.querySelector(
    '.publish_btn[data-action="append"]'
  );

  if (btnAppendSave) {
    btnAppendSave.addEventListener("click", async () => {

      if (!loadedDoc || !loadedPath) {
        openGenericInfoModal(SCRIBE_MSG.DOC_NOT_LOADED);
        return;
      }

      const record = {};
      appendPanel.querySelectorAll("input, textarea").forEach(el => {
        if (!el.name) return;
        const v = el.value.trim();
        if (v) record[el.name] = v;
      });

      const res = ScribeModel.engineAppend(loadedDoc, record);
      if (!res.ok) {
        openGenericInfoModal(SCRIBE_MSG[res.error] || res.error);
        return;
      }

      const jsonRes = ScribeModel.engineSave(res.doc);
      if (!jsonRes.ok) {
        openGenericInfoModal(SCRIBE_MSG[jsonRes.error] || jsonRes.error);
        return;
      }

      const saveResp = await window.pywebview.api.scribe_save_json(
        jsonRes.json,
        loadedPath.split("/").pop(),
        loadedPath.replace(/\/[^/]+$/, "")
      );

      if (!saveResp.ok) {
        openGenericInfoModal(saveResp.error);
        return;
      }

      openGenericInfoModal(
        SCRIBE_MSG.append_success,
        wipeAppendInputs
      );
    });
  }

// ----------------------------------------------------------
// APPEND UI — WIPE INPUTS
// ----------------------------------------------------------
function wipeAppendInputs() {
  if (!appendPanel) return;
  appendPanel.querySelectorAll("input, textarea").forEach(el => {
    el.value = "";
  });
}


  // ==========================================================
  // TOP BAR NAV
  // ==========================================================
  if (btnCreate) btnCreate.addEventListener("click", () => {
    setTheme("create");
    showChannel("create");
  });

  if (btnEdit) btnEdit.addEventListener("click", () => {
    setTheme("append");
    showChannel("append");
  });

  if (btnReload) btnReload.addEventListener("click", () => window.location.reload());
  if (btnClose)  btnClose.addEventListener("click", () => window.close());

  setTheme("create");
  showChannel("landing");
}

// ------------------------------------------------------------
// EXPORT
// ------------------------------------------------------------
window.initScribeUI = initScribeUI;
