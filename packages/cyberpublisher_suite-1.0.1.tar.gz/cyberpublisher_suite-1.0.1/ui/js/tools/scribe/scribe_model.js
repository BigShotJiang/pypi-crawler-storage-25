// ============================================================
// CyberScribe — Core Document Model
// ============================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/scribe/scribe_model.js
//
// Description:
//     Pure data model for Scribe documents. Strings-only,
//     no inference, no magic. Create = meta only, Append =
//     records only. Emits canonical error keys.
//
// Inputs:
//     - engineNew(metaFields, fileBaseName) — create document
//     - engineAppend(existingDoc, recordFields) — add record
//     - engineSave(doc) — serialize document to JSON
//
// Processing:
//     - Validates meta fields (title, h1, h2 required)
//     - Sanitizes filenames (alphanumeric + hyphen/underscore)
//     - Validates record fields (filename, doc_title, h1, h2, pg_cnt)
//     - Checks for duplicate filenames in existing records
//     - Adds timestamps on create and append
//
// Outputs:
//     - Returns { ok, doc, fileName } on create success
//     - Returns { ok, doc } on append success
//     - Returns { ok, json } on serialize success
//     - Returns { ok: false, error: "ERROR_KEY" } on failure
//     - Exposed as IIFE singleton: ScribeModel
// ============================================================

const ScribeModel = (() => {

  // ------------------------------------------------------------
  // UTILITIES
  // ------------------------------------------------------------
  function isString(v) {
    return typeof v === "string";
  }

  function nowTimestamp() {
    return new Date().toISOString();
  }

  function sanitizeFileName(name) {
    if (!isString(name)) return null;
    const trimmed = name.trim();
    if (!trimmed) return null;
    if (/[\/\\.]/.test(trimmed)) return null;

    const safe = trimmed.replace(/[^a-zA-Z0-9_-]/g, "");
    return safe || null;
  }

  // ------------------------------------------------------------
  // META VALIDATION (CREATE)
  // ------------------------------------------------------------
  function validateCreateMeta(meta) {
    if (!meta || typeof meta !== "object") {
      return { ok: false, error: "DOC_INVALID" };
    }

    if (!meta.title || !meta.title.trim()) {
      return { ok: false, error: "MISSING_doc_title" };
    }

    if (!meta.h1 || !meta.h1.trim()) {
      return { ok: false, error: "MISSING_h1_cnt" };
    }

    if (!meta.h2 || !meta.h2.trim()) {
      return { ok: false, error: "MISSING_h2_cnt" };
    }

    return { ok: true };
  }

  // ------------------------------------------------------------
  // CREATE
  // ------------------------------------------------------------
  function createNewDocument(metaFields, fileBaseName) {
    const safe = sanitizeFileName(fileBaseName);
    if (!safe) {
      return { ok: false, error: "INVALID_filename" };
    }

    const metaCheck = validateCreateMeta(metaFields);
    if (!metaCheck.ok) return metaCheck;

    const meta = {
      filename: safe,
      title: metaFields.title,
      author: metaFields.author || "",
      description: metaFields.description || "",
      h1: metaFields.h1,
      h2: metaFields.h2,
      created: nowTimestamp()
    };

    return {
      ok: true,
      doc: {
        meta,
        records: []
      },
      fileName: `${safe}.json`
    };
  }

  // ------------------------------------------------------------
  // APPEND
  // ------------------------------------------------------------
  function appendRecord(existingDoc, recordFields) {

    if (!existingDoc || !Array.isArray(existingDoc.records)) {
      return { ok: false, error: "DOC_NOT_LOADED" };
    }

    const REQUIRED_RECORD_FIELDS = [
      "filename",
      "doc_title",
      "h1_cnt",
      "h2_cnt",
      "pg_cnt"
    ];

    for (const k of REQUIRED_RECORD_FIELDS) {
      if (!(k in recordFields) || !isString(recordFields[k]) || !recordFields[k].trim()) {
        return { ok: false, error: `MISSING_${k}` };
      }
    }

    if (existingDoc.records.find(r => r.filename === recordFields.filename)) {
      return { ok: false, error: "DUPLICATE_filename" };
    }

    existingDoc.records.push({
      ...recordFields,
      timestamp: nowTimestamp()
    });

    existingDoc.meta.updated = nowTimestamp();
    return { ok: true, doc: existingDoc };
  }

  // ------------------------------------------------------------
  // SERIALIZE
  // ------------------------------------------------------------
  function stringifyDocument(doc) {
    if (!doc || typeof doc !== "object") {
      return { ok: false, error: "DOC_INVALID" };
    }
    return { ok: true, json: JSON.stringify(doc, null, 2) };
  }

  // ------------------------------------------------------------
  // PUBLIC API
  // ------------------------------------------------------------
  return {
    engineNew: createNewDocument,
    engineAppend: appendRecord,
    engineSave: stringifyDocument
  };

})();
