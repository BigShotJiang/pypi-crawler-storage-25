// ========================================================
// CyberSuite — Mapper State (Pure State, No UI)
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/mapper/mapper_state.js
//
// Description:
//     In-memory state holder for the Mapper tool.
//     Tracks target/output paths, scope (local/remote),
//     mapping options, and run status. No DOM access.
//
// Inputs:
//     - Setter calls: setMapperTarget(scope, path),
//       setMapperOutput(scope, path),
//       setMapperOption(key, value)
//     - resetMapperState() clears paths and run status
//
// Processing:
//     - Direct property assignment with key validation
//       (setMapperOption guards against unknown keys)
//     - resetMapperState nullifies paths and run state
//       but preserves options
//
// Outputs:
//     - Exports: getMapperState, setMapperTarget,
//       setMapperOutput, setMapperOption, resetMapperState
//     - getMapperState() returns direct reference (not copy)
// ========================================================

const mapperState = {
  target: {
    scope: "local",
    path: null
  },
  output: {
    scope: "local",
    path: null
  },
  options: {
    baseUrl: null,  
    genChart: false,
    useFilter: true,
    updateLog: true,
    depth: 3
  },
  run: {
    confirmed: false,
    lastResult: null
  }
};

function resetMapperState() {
  mapperState.target.path = null;
  mapperState.output.path = null;
  mapperState.run.confirmed = false;
  mapperState.run.lastResult = null;
}

function getMapperState() {
  return mapperState;
}

function setMapperTarget(scope, path) {
  mapperState.target.scope = scope;
  mapperState.target.path = path;
}

function setMapperOutput(scope, path) {
  mapperState.output.scope = scope;
  mapperState.output.path = path;
}

function setMapperOption(key, value) {
  if (key in mapperState.options) {
    mapperState.options[key] = value;
  }
}

export {
  getMapperState,
  setMapperTarget,
  setMapperOutput,
  setMapperOption,
  resetMapperState
};
