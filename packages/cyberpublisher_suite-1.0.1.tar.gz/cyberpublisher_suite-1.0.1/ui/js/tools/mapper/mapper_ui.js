// ========================================================
// CyberSuite — Mapper UI Controller
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/mapper/mapper_ui.js
//
// Description:
//     Master controller for the Mapper tool panel.
//     Wires DOM elements, toggles, pickers, options, and
//     the map execution flow after panel injection.
//
// Inputs:
//     - DOM: Panel elements (buttons, checkboxes, labels)
//       resolved by ID after injection
//     - Imports: mapperState functions, initMapperToggles,
//       initRemoteOutputPicker (reused from publisher)
//     - User actions: click events on target/output buttons,
//       map button, reset button, option checkboxes
//
// Processing:
//     - Initializes sub-modules (toggles, remote pickers)
//     - Validates map eligibility (target + output required)
//     - Manages arm/confirm/execute map flow
//     - Delegates directory picking to pywebview.api.pick_file()
//     - Reuses publisher remote output picker for remote dirs
//
// Outputs:
//     - Updates mapperState with selected paths/scopes/options
//     - Updates DOM labels with path display
//     - Calls pywebview.api.map() on confirmed execution
//     - Exposes window.initMapperUI for panel_switcher
// ========================================================


import {
  getMapperState,
  setMapperTarget,
  setMapperOutput,
  setMapperOption,
  resetMapperState
} from "./mapper_state.js";

import { initMapperToggles } from "./mapper_toggles.js";
import { initRemoteOutputPicker } from "../publish/modules/publisher_output_picker.js";
import { setPathDisplay } from "../publish/modules/publisher_paths.js";

// ------------------------------------------------------
// LOG CONFIG — read live from DOM (shared across tools)
// ------------------------------------------------------
function getLogCfgFromUI() {
  const chk = document.getElementById("chk_logging");
  const selected = document.querySelector("#log_mode_select .dropdown-selected");
  const raw = selected ? selected.textContent.trim() : "User";
  const level = raw.toLowerCase() === "user" ? "snapshot" : raw.toLowerCase();
  return { retain_all: !!(chk && chk.checked), level };
}

// ==================================================
// MAP GUARD HELPERS
// ==================================================
function getMapEligibility(state) {
  const missing = [];
  if (!state.target.path) missing.push("target");
  if (!state.output.path) missing.push("output");
  return { ok: missing.length === 0, missing };
}

function showMapConfirm(show) {
  const wrap = document.querySelector('[data-role="map-confirm"]');
  if (!wrap) return;

  wrap.classList.toggle("hidden", !show);
  if (!show) {
    const chk = wrap.querySelector('[data-role="map-check"]');
    if (chk) chk.checked = false;
  }
}

function isMapConfirmed() {
  const chk = document.querySelector('[data-role="map-check"]');
  return !!chk && chk.checked === true;
}

// ==================================================
// LABEL UPDATE
// ==================================================
function updateLabels(lblTarget, lblOutput) {
  const s = getMapperState();

  if (lblTarget) {
    if (s.target.path) {
      setPathDisplay(lblTarget, s.target.path, s.target.scope);
    } else {
      lblTarget.textContent = "No Target Directory Selected";
      lblTarget.classList.remove("active-local", "active-remote");
    }
  }

  if (lblOutput) {
    if (s.output.path) {
      setPathDisplay(lblOutput, s.output.path, s.output.scope);
    } else {
      lblOutput.textContent = "No Output Directory Selected";
      lblOutput.classList.remove("active-local", "active-remote");
    }
  }
}

// ==================================================
// INIT
// ==================================================
window.initMapperUI = function () {
  console.log("[mapper] UI initialized");
  window.trapTabCycle(document.querySelector('.mapper-panel'));

  const mapperState = getMapperState();
  mapperState.__armed = false;

  let pendingRemotePicker = null;

  function disarmMap(reason) {
    if (!mapperState.__armed) return;
    mapperState.__armed = false;
    showMapConfirm(false);
    console.log("[mapper] disarmed:", reason);
  }

  // --------------------------------------------------
  // INIT: Sync Update Log toggle from state
  // --------------------------------------------------
  const chkUpdateLog = document.getElementById("chk_mapper_update_log");

  if (chkUpdateLog) {
    // Default ON if undefined
    if (mapperState.options.updateLog === undefined) {
      mapperState.options.updateLog = true;
    }

    chkUpdateLog.checked = mapperState.options.updateLog;

    chkUpdateLog.addEventListener("change", () => {
      mapperState.options.updateLog = chkUpdateLog.checked;
      disarmMap("updateLog changed");
    });
  }

  // --------------------------------------------------
  // INIT: Sync Depth dropdown from state
  // --------------------------------------------------
  const depthSelect = document.getElementById("mapper_depth_select");
  const depthDisplay = depthSelect?.querySelector(".dropdown-selected");

  if (depthSelect && depthDisplay) {
    // Ensure default exists
    if (!mapperState.options.depth) {
      mapperState.options.depth = 3;
    }

    depthDisplay.textContent = mapperState.options.depth;

    depthSelect.addEventListener("click", (e) => {
      const val = e.target?.dataset?.value;
      if (!val) return;

      const depth = parseInt(val, 10);
      mapperState.options.depth = depth;
      depthDisplay.textContent = depth;

      disarmMap("depth changed");
    });
  }


  // -----------------------------
  // Base URL input
  // -----------------------------
  const baseUrlInput = document.getElementById("mapper_base_url");
  baseUrlInput?.addEventListener("input", e => {
    setMapperOption("baseUrl", e.target.value.trim());
    disarmMap("base_url changed");
  });

  // -----------------------------
  // Shared remote picker UI
  // -----------------------------
  const remoteModal = document.getElementById("remote_picker_overlay");
  const fileList    = remoteModal?.querySelector(".file-listing");
  const btnOpen     = remoteModal?.querySelector('[data-action="picker-open"]');
  const btnCancel   = remoteModal?.querySelector('[data-action="picker-cancel"]');
  const btnCloseX   = remoteModal?.querySelector(".modal-close");

  // -----------------------------
  // Target refs
  // -----------------------------
  const btnTarget = document.getElementById("btn_mapper_target");
  const lblTarget = document.getElementById("lbl_mapper_target_status");
  const chkLocalT = document.getElementById("chk_mapper_local_target");
  const chkRemoteT = document.getElementById("chk_mapper_in");

  // -----------------------------
  // Output refs
  // -----------------------------
  const btnOutput = document.getElementById("btn_mapper_output");
  const lblOutput = document.getElementById("lbl_mapper_output_status");
  const chkLocalO = document.getElementById("chk_mapper_local_out");
  const chkRemoteO = document.getElementById("chk_mapper_out");

  // -----------------------------
  // Options
  // -----------------------------
  const chkChart  = document.getElementById("chk_mapper_enable_chart");
  const chkFilter = document.getElementById("chk_mapper_include_exclude");
  const chkLog    = document.getElementById("chk_mapper_update_log");

  const btnReset = document.querySelector('[data-action="reset"]');

  // -----------------------------
  // INIT TOGGLES
  // -----------------------------
  initMapperToggles({
    mapperState,
    chkLocalTarget: chkLocalT,
    chkRemoteTarget: chkRemoteT,
    btnTarget,
    chkLocalOutput: chkLocalO,
    chkRemoteOutput: chkRemoteO,
    btnOutput
  });

  [chkLocalT, chkRemoteT, chkLocalO, chkRemoteO].forEach(chk => {
    chk?.addEventListener("change", () => updateLabels(lblTarget, lblOutput));
  });

  chkChart?.addEventListener("change", e => {
  console.log("Chart toggle changed →", e.target.checked);
  setMapperOption("genChart", e.target.checked);
  disarmMap("option changed");
});


  chkFilter?.addEventListener("change", e => {
    setMapperOption("useFilter", e.target.checked);
    disarmMap("option changed");
  });

  chkLog?.addEventListener("change", e => {
    setMapperOption("updateLog", e.target.checked);
    disarmMap("option changed");
  });

  // -----------------------------
  // Remote pickers
  // -----------------------------
  const remoteTargetPicker = initRemoteOutputPicker({
    remoteModal,
    fileList,
    btnOpen,
    btnCancel,
    btnCloseX,
    onCommit: path => {
      setMapperTarget("remote", path);
      updateLabels(lblTarget, lblOutput);
      disarmMap("target changed (remote)");
    }
  });

  const remoteOutputPicker = initRemoteOutputPicker({
    remoteModal,
    fileList,
    btnOpen,
    btnCancel,
    btnCloseX,
    onCommit: path => {
      setMapperOutput("remote", path);
      updateLabels(lblTarget, lblOutput);
      disarmMap("output changed (remote)");
    }
  });

  // -----------------------------
  // TARGET PICKER
  // -----------------------------
  btnTarget?.addEventListener("click", async () => {
    const { target } = mapperState;

    if (target.scope === "remote") {
      const res = await window.pywebview.api.pick_file({
        intent: "output",
        scope: "remote",
        cwd: target.path || "/"
      });

      if (res?.needs_creds) {
        pendingRemotePicker = () => btnTarget.click();
        document.querySelector('[data-open-modal="output"]')?.click();
        return;
      }

      if (res?.success) {
        remoteTargetPicker.populate(res);
        remoteTargetPicker.show();
      }
      return;
    }

    const res = await window.BridgeAPI?.pick_file({
      intent: "output",
      scope: "local"
    });

    if (!res?.success) return;

    setMapperTarget("local", res.path);
    updateLabels(lblTarget, lblOutput);
    disarmMap("target changed (local)");
  });

  // -----------------------------
  // OUTPUT PICKER
  // -----------------------------
  btnOutput?.addEventListener("click", async () => {
    const { output } = mapperState;

    if (output.scope === "remote") {
      const res = await window.pywebview.api.pick_file({
        intent: "output",
        scope: "remote",
        cwd: output.path || "/"
      });

      if (res?.needs_creds) {
        pendingRemotePicker = () => btnOutput.click();
        document.querySelector('[data-open-modal="output"]')?.click();
        return;
      }

      if (res?.success) {
        remoteOutputPicker.populate(res);
        remoteOutputPicker.show();
      }
      return;
    }

    const res = await window.BridgeAPI?.pick_file({
      intent: "output",
      scope: "local"
    });

    if (!res?.success) return;

    setMapperOutput("local", res.path);
    updateLabels(lblTarget, lblOutput);
    disarmMap("output changed (local)");
  });

  function purgeMapperRunState() {
  mapperState.target.path = null;
  mapperState.output.path = null;
  mapperState.__armed = false;
  showMapConfirm(false);
  updateLabels(lblTarget, lblOutput);
  console.log("[mapper] run state purged");
}


  // -----------------------------
  // MAP ACTION
  // -----------------------------
  document.addEventListener("click", async e => {
    const btn = e.target.closest('[data-action="map"]');
    if (!btn) return;

  // 🔒 GUARDS — sitemap rules
  const isLocalLocal =
    mapperState.target.scope === "local" &&
    mapperState.output.scope === "local";

  const isRemoteRemote =
    mapperState.target.scope === "remote" &&
    mapperState.output.scope === "remote";

  // --- Local → Local: requires site_chart toggle (genChart)
  if (isLocalLocal && !mapperState.options.genChart) {
    openGenericInfoModal(
      "sitemap.xml is not produced in Local → Local mode.\n\n" +
      "To run Local → Local mapping, enable the Site Chart toggle (site_chart.json)."
    );
    return;
  }

  // Force Local→Local to chart regardless of explicit sitemap selection
  const explicitMode = (mapperState.options.mode || "").trim().toLowerCase();
  const effectiveMode = isLocalLocal
    ? "chart"
    : (explicitMode
        ? explicitMode
        : (isRemoteRemote && (mapperState.options.baseUrl || "").trim() ? "sitemap" : "chart")
      );

  // --- Remote → Remote: base URL required (always block if missing)
  if (isRemoteRemote && !(mapperState.options.baseUrl || "").trim()) {
    openGenericInfoModal(
      "Base URL is required to generate sitemap.xml.\n\n" +
      "Please enter a valid Base URL (e.g. https://example.com) " +
      "in the Output section before running the mapper.",
      () => {
        const input = document.getElementById("mapper_base_url");
        if (!input) return;

        input.classList.add("mapper-input-error");
        input.focus();

        setTimeout(() => {
          input.classList.remove("mapper-input-error");
        }, 2500);
      }
    );
    return;
  }


    const { ok } = getMapEligibility(mapperState);
    if (!ok) return;

    if (!mapperState.__armed) {
      mapperState.__armed = true;

      const jobId = crypto?.randomUUID ? crypto.randomUUID() : `job_${Date.now()}`;
      mapperState.__job_id = jobId;

      const tEmoji = mapperState.target.scope === "remote" ? "🌐" : "📁";
      const oEmoji = mapperState.output.scope === "remote" ? "🌐" : "📁";
      const tLabel = mapperState.target.scope === "remote" ? "REMOTE" : "LOCAL";
      const oLabel = mapperState.output.scope === "remote" ? "REMOTE" : "LOCAL";

      // ✅ Narration header (separates runs)
      window.CliNarrator.append(`✅ Map began: ${window.CliNarrator.nowUtcStamp()}`);

      const lines = [
        "MAPPER — Confirm Snapshot",
        `Target (${tLabel} ${tEmoji}): ${mapperState.target.path || "[none]"}`,
        `Output (${oLabel} ${oEmoji}): ${mapperState.output.path || "[none]"}`,
        `Mode: ${effectiveMode}`,
        `Base URL: ${mapperState.options.baseUrl || "[none]"}`,
        (() => {
          const on = [];
          if (mapperState.options.genChart)  on.push("gen_chart");
          if (mapperState.options.useFilter) on.push("use_filter");
          if (mapperState.options.updateLog) on.push("update_log");
          if (mapperState.options.depth)     on.push(`depth=${mapperState.options.depth}`);
          return `Options: ${on.length ? on.join(", ") : "(none)"}`;
        })(),
        window.CliNarrator.jobFooter(jobId)
      ];

      // ✅ Append (do not overwrite previous runs)
      window.CliNarrator.append(lines.join("\n"));

      showMapConfirm(true);
      return;
    }

    if (!isMapConfirmed()) return;

    mapperState.__armed = false;
    showMapConfirm(false);

    btn.classList.add("inactive");

    // ✅ SNAPSHOT FIRST
    const payload = {
      target:  { ...mapperState.target },
      output:  { ...mapperState.output },
      options: {
        baseUrl: (mapperState.options.baseUrl || "").trim(),
        mode: effectiveMode,
        genChart: mapperState.options.genChart,
        useFilter: mapperState.options.useFilter,
        updateLog: mapperState.options.updateLog,
        depth: mapperState.options.depth
      }

    };

    payload.job_id = mapperState.__job_id;
    payload.log = getLogCfgFromUI();

    const res = await window.pywebview.api.map(payload);

    // ✅ Narration report (post-run)
    const _ok = !!res?.success;
    const c = res?.counts || {};
    const ms = (typeof res?.timing_ms === "number") ? res.timing_ms : "?";
    const outEmoji = mapperState.output.scope === "remote" ? "🌐" : "📁";
    const outLabel = mapperState.output.scope === "remote" ? "REMOTE" : "LOCAL";
    const outPath = mapperState.output.path || "[no output]";

    const art = res?.artifacts || {};
    const artNames = [];
    if (art.map_index) artNames.push("map_index.json");
    if (art.sitemap)   artNames.push("sitemap.xml");
    artNames.push("robots.txt");
    if (mapperState.options.genChart) artNames.push("site_chart.json");

    window.CliNarrator.append(
      [
        _ok ? "✅ Map complete" : "❌ Map failed",
        `${window.CliNarrator.nowUtcStamp()}`,
        `Dirs: ${c.directories ?? "?"} | Files: ${c.files ?? "?"}`,
        `Target (${outLabel} ${outEmoji}): ${outPath}`,
        `Artifacts: ${artNames.join(", ")}`,
        "################",
        `executed: ${ms} ms`,
        "Always verify output at target.",
        "################"
      ].join("\n")
    );

    // ✅ PURGE AFTER RUN COMPLETES
    purgeMapperRunState();

    console.log("[mapper] map result →", res);
    btn.classList.remove("inactive");

  });

  // -----------------------------
  // Reset
  // -----------------------------
  btnReset?.addEventListener("click", () => {
    resetMapperState();
    updateLabels(lblTarget, lblOutput);
    disarmMap("reset");
    console.log("[mapper] state reset");
  });

  updateLabels(lblTarget, lblOutput);
};
