// ========================================================
// CyberSuite — Mapper Toggle Module
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/tools/mapper/mapper_toggles.js
//
// Description:
//     Wires local/remote scope toggles for mapper target
//     and output. Enforces mutual exclusion and invalidates
//     stale paths on scope change. No picker logic, no UI.
//
// Inputs:
//     - Config object: { mapperState, chkLocalTarget,
//       chkRemoteTarget, chkLocalOutput, chkRemoteOutput }
//     - Change events on scope checkbox elements
//
// Processing:
//     - Checkbox change: unchecks opposite, updates scope
//     - Nullifies path on scope change (prevents stale state)
//
// Outputs:
//     - Mutates mapperState.target.scope/path
//     - Mutates mapperState.output.scope/path
//     - Exports: initMapperToggles function
// ========================================================

export function initMapperToggles({
  mapperState,

  chkLocalTarget,
  chkRemoteTarget,
  btnTarget,

  chkLocalOutput,
  chkRemoteOutput,
  btnOutput
}) {

  // helper — sync picker button color to scope
  function setBtnScope(btn, isRemote) {
    if (!btn) return;
    btn.classList.remove('local-active', 'remote-active');
    btn.classList.add(isRemote ? 'remote-active' : 'local-active');
  }

  // -------------------------------
  // TARGET
  // -------------------------------
  chkLocalTarget.addEventListener('change', () => {
    chkRemoteTarget.checked = !chkLocalTarget.checked;
    mapperState.target.scope = chkLocalTarget.checked ? 'local' : 'remote';
    mapperState.target.path  = null; // 🔑 invalidate
    setBtnScope(btnTarget, mapperState.target.scope === 'remote');
  });

  chkRemoteTarget.addEventListener('change', () => {
    chkLocalTarget.checked = !chkRemoteTarget.checked;
    mapperState.target.scope = chkRemoteTarget.checked ? 'remote' : 'local';
    mapperState.target.path  = null; // 🔑 invalidate
    setBtnScope(btnTarget, mapperState.target.scope === 'remote');
  });

  // -------------------------------
  // OUTPUT
  // -------------------------------
  chkLocalOutput.addEventListener('change', () => {
    chkRemoteOutput.checked = !chkLocalOutput.checked;
    mapperState.output.scope = chkLocalOutput.checked ? 'local' : 'remote';
    mapperState.output.path  = null; // 🔑 invalidate
    setBtnScope(btnOutput, mapperState.output.scope === 'remote');
  });

  chkRemoteOutput.addEventListener('change', () => {
    chkLocalOutput.checked = !chkRemoteOutput.checked;
    mapperState.output.scope = chkRemoteOutput.checked ? 'remote' : 'local';
    mapperState.output.path  = null; // 🔑 invalidate
    setBtnScope(btnOutput, mapperState.output.scope === 'remote');
  });
}
