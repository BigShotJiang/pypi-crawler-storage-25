// ========================================================
// CyberSuite — Generic Info Modal
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/modals/generic_info_modal.js
//
// Description:
//     Provides a reusable info/alert modal for displaying
//     messages to the user. Supports an optional close
//     callback for cleanup after dismissal.
//
// Inputs:
//     - message (string) — content to display in modal body
//     - onClose (function|null) — optional callback invoked
//       on modal close
//     - Click events on .modal-close or [data-action="close-modal"]
//       within the generic-info overlay
//
// Processing:
//     - Locates overlay by [data-modal-type="generic-info"]
//     - Sets inner HTML of #generic-info-body
//     - Stashes onClose callback on overlay element
//     - Close handler fires callback then nullifies it
//
// Outputs:
//     - Opens/closes generic-info modal overlay (.active class)
//     - Exposes openGenericInfoModal() as global function
//     - Invokes onClose callback on dismissal (if provided)
// ========================================================

  // --------------------------------------------
  // GENERIC INFO MODAL — HELPER
  // --------------------------------------------
  function openGenericInfoModal(message, onClose = null) {
    const overlay = document.querySelector(
      '.modal-overlay[data-modal-type="generic-info"]'
    );
    if (!overlay) return;

    const body = overlay.querySelector('#generic-info-body');
    if (body) body.innerHTML = `<p>${message}</p>`;
    // stash optional close callback on the overlay
    overlay._onClose = onClose;

    setTimeout(() => {
  overlay.classList.add('active');
}, 0);

  }

// --------------------------------------------
// GENERIC INFO MODAL — CLOSE HOOK (CLICK-BASED)
// --------------------------------------------
document.addEventListener("click", (e) => {

  const closeBtn = e.target.closest(
    '.modal-overlay[data-modal-type="generic-info"] .modal-close, ' +
    '.modal-overlay[data-modal-type="generic-info"] [data-action="close-modal"]'
  );

  if (!closeBtn) return;

  const overlay = closeBtn.closest('.modal-overlay');
  if (!overlay) return;

  if (typeof overlay._onClose === 'function') {
    overlay._onClose();   // ← calls wipeAppendInputs
    overlay._onClose = null;
  }
});

// --------------------------------------------
// EXTERNAL LINKS IN GENERIC INFO MODAL
// --------------------------------------------
document.addEventListener("click", async (e) => {
  const link = e.target.closest(
    '.modal-overlay[data-modal-type="generic-info"] a[href]'
  );
  if (!link) return;

  const href = (link.getAttribute("href") || "").trim();
  if (!/^https?:\/\//i.test(href)) return;

  e.preventDefault();

  try {
    if (window.pywebview?.api?.open_external_url) {
      await window.pywebview.api.open_external_url(href);
    }
  } catch (err) {
    console.error("Failed to open external URL:", err);
  }
});
