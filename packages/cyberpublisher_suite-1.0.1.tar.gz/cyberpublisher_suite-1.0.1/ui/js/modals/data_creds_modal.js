/**
 * ============================================================
 * CyberSuite — Data Remote Credentials Modal
 * ============================================================
 * Author(s): Gil & Z3k3 — cyberfluence.com
 * Path:      ui/js/modals/data_creds_modal.js
 *
 * Description:
 *     UI-only behavior for DATA remote credentials.
 *     Handles test/save/purge flow scoped strictly to data.
 *     Mirrors output/template modal behavior.
 *
 * Inputs:
 *     - Click events on [data-open-modal="data"] (modal open)
 *     - Click events on [data-action="save"|"purge"] within
 *       data-scoped creds modal
 *     - Input events on form fields (resets test-passed flag)
 *
 * Processing:
 *     - Opens modal and loads saved creds via BridgeAPI.fillCredFields
 *     - Save: validates test-passed, resolves SSH config, persists
 *     - Purge: clears creds via pywebview.api.clearCreds
 *     - Input changes reset test-passed flag and disable Save
 *
 * Outputs:
 *     - Exposes window.dataCredsTestPassed session flag
 *     - Exposes window.setDataCredsSaveEnabled toggle
 *     - Calls pywebview.api.saveConnection / clearCreds
 *     - Updates status message with ok/error class
 * ============================================================
 */

/* ------------------------------------------------------------
   Session Guard (UI only, DATA scope only)
------------------------------------------------------------ */

const dataCredsTestPassed = { value: false };
window.dataCredsTestPassed = dataCredsTestPassed;

/* ------------------------------------------------------------
   Utilities
------------------------------------------------------------ */

function setSaveButtonState(enabled) {
  const btn = document.querySelector(
    '[data-modal-type="creds"][data-creds-scope="data"] [data-action="save"]'
  );
  if (!btn) return;
  btn.classList.toggle('inactive', !enabled);
}

function resetDataCredsState() {
  dataCredsTestPassed.value = false;
  setSaveButtonState(false);
}

function showDataCredsStatus(message, ok, duration = 5000) {
  const statusEl = document.querySelector(
    '[data-modal-type="creds"][data-creds-scope="data"] [data-role="status"]'
  );
  if (!statusEl) return;

  statusEl.textContent = message;
  statusEl.classList.toggle('ok', ok);
  statusEl.classList.toggle('error', !ok);
  statusEl.classList.add('visible');

  setTimeout(() => {
    statusEl.classList.remove('visible');
  }, duration);
}

/* expose save toggle hook */
window.setDataCredsSaveEnabled = setSaveButtonState;

/* ------------------------------------------------------------
   DATA MODAL OPEN
------------------------------------------------------------ */

document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-open-modal="data"]');
  if (!btn) return;

  window.BridgeAPI?.fillCredFields?.('data');
  resetDataCredsState();
});

/* ------------------------------------------------------------
   SAVE HANDLER
------------------------------------------------------------ */

document.addEventListener('click', async (e) => {
  const saveBtn = e.target.closest(
    '[data-modal-type="creds"][data-creds-scope="data"] [data-action="save"]'
  );
  if (!saveBtn) return;

  const modal = saveBtn.closest(
    '[data-modal-type="creds"][data-creds-scope="data"]'
  );
  if (!modal) return;

  // Guards
  if (saveBtn.classList.contains('inactive')) return;
  if (!dataCredsTestPassed.value) return;
  if (!window.pywebview?.api?.saveConnection) return;

  const creds = collectCreds('data');

  // ---------------------------------------------
  // SSH alias resolve (silent)
  // ---------------------------------------------
  if (creds.host && !creds.user) {
    const res = await window.pywebview.api.resolve_ssh_config(creds);

    if (!res?.success) {
      showDataCredsStatus('SSH config failed', false);
      return;
    }

    Object.assign(creds, res.resolved);
  }

  // ---------------------------------------------
  // SAVE
  // ---------------------------------------------
  const result = await window.pywebview.api.saveConnection('data', creds);

  if (!result?.ok) {
    showDataCredsStatus('Save failed', false);
    return;
  }

  showDataCredsStatus('Credentials saved', true, 2000);

  setTimeout(() => {
    modal.closest('.modal-overlay')?.classList.remove('active');
  }, 2000);
});

  // ---------------------------------------------
  // RESTORE CLEAN/FRESH STATE TO TEST BTN AFTER A TEST
  // ---------------------------------------------
  document.addEventListener('input', (e) => {
    const modal = e.target.closest(
      '[data-modal-type="creds"][data-creds-scope="data"]'
    );
    if (!modal) return;

    dataCredsTestPassed.value = false;
    setSaveButtonState(false);
  });


/* ------------------------------------------------------------
   PURGE
------------------------------------------------------------ */

document.addEventListener('click', async (e) => {
  const btn = e.target.closest(
    '[data-modal-type="creds"][data-creds-scope="data"] [data-action="purge"]'
  );
  if (!btn) return;

  if (!window.pywebview?.api?.clearCreds) return;

  await window.pywebview.api.clearCreds('data');
  resetDataCredsState();
  showDataCredsStatus('Credentials purged', false, 2500);
});
