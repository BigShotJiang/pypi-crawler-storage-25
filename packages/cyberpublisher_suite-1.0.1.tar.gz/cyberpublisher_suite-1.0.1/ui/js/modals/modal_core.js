/**
 * ============================================================
 * CyberSuite — Modal Core
 * ============================================================
 * Author(s): Gil & Z3k3 — cyberfluence.com
 * Path:      ui/js/modals/modal_core.js
 *
 * Description:
 *     Generic modal open / close / delegation plumbing.
 *     NO feature-specific logic, NO creds logic, NO state
 *     management. This file must stay boring.
 *
 * Inputs:
 *     - Click events on [data-open-modal] elements (open)
 *     - Click events on .modal-close / [data-action="close-modal"] (close)
 *     - Click events on [data-action="test"] inside modals (delegation)
 *     - Change events on .eye-toggle_chk (password visibility)
 *
 * Processing:
 *     - Opens modals by matching data-creds-scope to overlay
 *     - Closes modals by traversing to parent .modal-overlay
 *     - Traps keyboard focus inside active modal (Tab cycling)
 *     - Toggles password field type on eye-toggle checkbox
 *     - Delegates test-connection clicks to window.testConnection()
 *
 * Outputs:
 *     - Adds/removes .active class on .modal-overlay elements
 *     - Attaches/detaches focus trap keydown handlers
 *     - No return values; all effects are DOM mutations
 * ============================================================
 */


/* ------------------------------------------------------------
   OPEN MODAL
------------------------------------------------------------ */

document.addEventListener("click", e => {
  console.log("🖱 CLICK:", e.target);

  const btn = e.target.closest("[data-open-modal]");
  if (!btn) return;

  const scope = btn.dataset.openModal;
  console.log("➡️ OPEN MODAL:", scope);

  const overlay = document.querySelector(
    `.modal-overlay[data-creds-scope="${scope}"]`
  );

  console.log("🎯 FOUND OVERLAY:", overlay);

  if (overlay) {
    overlay.classList.add("active");
    trapFocus(overlay);
  }
});

/* ------------------------------------------------------------
   CLOSE MODAL (X button + bottom Close button)
------------------------------------------------------------ */

document.addEventListener("click", (e) => {

  // Top-right ✕ button
  const closeIcon = e.target.closest(".modal-close");
  if (closeIcon) {
    const overlay = closeIcon.closest(".modal-overlay");
    if (overlay) {
      overlay.classList.remove("active");
      releaseFocus(overlay);
      console.log("❌ CLOSE MODAL (icon)");
    }
    return;
  }

  // Bottom Close button
  const closeAction = e.target.closest('[data-action="close-modal"]');
  if (closeAction) {
    const overlay = closeAction.closest(".modal-overlay");
    if (overlay) {
      overlay.classList.remove("active");
      releaseFocus(overlay);
      console.log("❌ CLOSE MODAL (action)");
    }
    return;
  }

});



// ============================================================
// PASSWORD VISIBILITY TOGGLE 
// ============================================================

document.addEventListener("change", e => {
  const chk = e.target.closest(".eye-toggle_chk");
  if (!chk) return;

  const modal = chk.closest(".modal");
  const pass  = modal?.querySelector('[data-field="pass"]');
  if (!pass) return;

  pass.type = chk.checked ? "text" : "password";
});


// ============================================================
// MODAL FOCUS TRAP (UNIVERSAL)
// ============================================================
function trapFocus(overlay) {

  const modal = overlay.querySelector('.modal');
  if (!modal) return;

  const focusables = Array.from(
    modal.querySelectorAll(
      'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )
  ).filter(el => el.offsetParent !== null); // visible only

  if (!focusables.length) return;

  const first = focusables[0];
  const last  = focusables[focusables.length - 1];

  function handleTab(e) {
    if (e.key !== 'Tab') return;

    if (e.shiftKey) {
      if (document.activeElement === first) {
        e.preventDefault();
        e.stopPropagation();
        last.focus();
      }
    } else {
      if (document.activeElement === last) {
        e.preventDefault();
        e.stopPropagation();
        first.focus();
      }
    }
  }

  modal.__focusTrapHandler = handleTab;
  modal.addEventListener('keydown', handleTab);

  // Ensure focus is INSIDE modal
  setTimeout(() => {
    if (!modal.contains(document.activeElement)) {
      first.focus();
    }
  }, 0);
}

function releaseFocus(overlay) {
  const modal = overlay?.querySelector('.modal');
  if (!modal?.__focusTrapHandler) return;

  modal.removeEventListener('keydown', modal.__focusTrapHandler);
  delete modal.__focusTrapHandler;
}



/* ------------------------------------------------------------
   MODAL ACTION DELEGATION
------------------------------------------------------------ */

document.addEventListener("click", e => {
  const modal = e.target.closest(".modal");
  if (!modal) return;

  const scope = modal.dataset.credsScope;

  // TEST
  if (e.target.closest('[data-action="test"]')) {
    console.log("🧪 TEST click, scope =", scope);
    window.testConnection?.(scope);
    return;
  }

});
