/**
 * ============================================================
 * CyberSuite — Template Remote Credentials Modal
 * ============================================================
 * Author(s): Gil & Z3k3 — cyberfluence.com
 * Path:      ui/js/modals/template_creds_modal.js
 *
 * Description:
 *     UI-only behavior for TEMPLATE remote credentials.
 *     Handles test/save/purge flow scoped strictly to template.
 *     Includes two-stage purge with confirmation checkbox.
 *
 * Inputs:
 *     - Click events on [data-open-modal="template"] (modal open)
 *     - Click events on [data-action="save"|"purge"|"cancel"]
 *       within template-scoped creds modal
 *     - Change events on [data-role="purge-check"] (purge confirm)
 *     - Input events on form fields (resets test-passed flag)
 *
 * Processing:
 *     - Opens modal and loads saved creds via BridgeAPI.fillCredFields
 *     - Save: validates test-passed, resolves SSH config, persists
 *     - Purge: two-stage arm → confirm → execute via clearCreds
 *     - Close/cancel: resets all creds and purge state
 *     - Input changes reset test-passed flag and disable Save
 *
 * Outputs:
 *     - Exposes window.templateCredsTestPassed session flag
 *     - Exposes window.setTemplateCredsSaveEnabled toggle
 *     - Calls pywebview.api.saveConnection / clearCreds
 *     - Updates status message with ok/error opacity toggle
 * ============================================================
 */

/* ------------------------------------------------------------
   Session Guard (UI only, TEMPLATE scope only)
------------------------------------------------------------ */

const templateCredsTestPassed = { value: false };

/* expose minimal hooks for ui_components.js */
window.templateCredsTestPassed = templateCredsTestPassed;
window.setTemplateCredsSaveEnabled = setSaveButtonState;


/* ------------------------------------------------------------
   Utilities
------------------------------------------------------------ */

function resetTemplateCredsState() {
  templateCredsTestPassed.value = false;
  setSaveButtonState(false);
  resetTemplatePurgeState();
}


/* ------------------------------------------------------------
   Purge State Reset (CRITICAL SAFETY)
------------------------------------------------------------ */

function resetTemplatePurgeState() {
  const modal = document.querySelector(
    '[data-modal-type="creds"][data-creds-scope="template"]'
  );
  if (!modal) return;

  const purgeBtn     = modal.querySelector('[data-action="purge"]');
  const confirmWrap  = modal.querySelector('[data-role="purge-confirm"]');
  const confirmCheck = modal.querySelector('[data-role="purge-check"]');

  // Reset purge button state
  if (purgeBtn) {
    purgeBtn.dataset.armed = 'false';
    purgeBtn.classList.remove('armed');
  }

  // Hide and uncheck confirmation
  if (confirmWrap) confirmWrap.classList.add('hidden');
  if (confirmCheck) confirmCheck.checked = false;
}

/* ------------------------------------------------------------
   Button State (Save)
------------------------------------------------------------ */

function setSaveButtonState(enabled) {
  const btn = document.querySelector(
    '[data-modal-type="creds"][data-creds-scope="template"] [data-action="save"]'
  );
  if (!btn) return;

  btn.classList.toggle('inactive', !enabled);
}


/* ------------------------------------------------------------
   Status Message
------------------------------------------------------------ */

function showTemplateCredsStatus(message, ok, duration = 5000) {
  const statusEl = document.querySelector(
    '[data-modal-type="creds"][data-creds-scope="template"] [data-role="status"]'
  );
  if (!statusEl) return;

  statusEl.textContent = message;
  statusEl.classList.toggle('ok', ok);
  statusEl.classList.toggle('error', !ok);
  statusEl.classList.add('visible');

  setTimeout(() => {
    statusEl.classList.remove('visible');
  }, duration);
}


/* ------------------------------------------------------------
   TEMPLATE MODAL OPEN HOOK
------------------------------------------------------------ */

document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-open-modal="template"]');
  if (!btn) return;

  if (window.BridgeAPI?.fillCredFields) {
    window.BridgeAPI.fillCredFields('template');
  }

  resetTemplateCredsState();
});


/* ------------------------------------------------------------
   MODAL CLOSE (X, Cancel, Overlay)
------------------------------------------------------------ */

document.addEventListener('click', (e) => {
  const closeBtn = e.target.closest('.modal-close, [data-action="cancel"]');
  if (!closeBtn) return;

  const modal = closeBtn.closest(
    '[data-modal-type="creds"][data-creds-scope="template"]'
  );
  if (!modal) return;

  resetTemplateCredsState();
});


/* ------------------------------------------------------------
   SAVE CREDENTIALS
------------------------------------------------------------ */

document.addEventListener('click', async (e) => {
  const saveBtn = e.target.closest('[data-action="save"]');
  if (!saveBtn) return;

  const modal = saveBtn.closest(
    '[data-modal-type="creds"][data-creds-scope="template"]'
  );
  if (!modal) return;

  // Guards
  if (saveBtn.classList.contains('inactive')) return;
  if (!templateCredsTestPassed.value) return;
  if (!window.pywebview?.api?.saveConnection) return;

  const creds = collectCreds('template');

  // ---------------------------------------------
  // SSH config resolve on save (silent)
  // ---------------------------------------------
  if (creds.host && !creds.user) {
    const res = await window.pywebview.api.resolve_ssh_config(creds);

    if (!res?.success) {
      showTemplateCredsStatus('SSH config failed', false);
      return;
    }

    Object.assign(creds, res.resolved);
  }


  const result = await window.pywebview.api.saveConnection('template', creds);

  if (result === false) {
    showTemplateCredsStatus('Save failed', false);
    return;
  }

  showTemplateCredsStatus('Credentials saved', true, 2000);

  setTimeout(() => {
    resetTemplateCredsState();
    const overlay = modal.closest('.modal-overlay');
    overlay?.classList.remove('active');
  }, 2000);
});


  // ---------------------------------------------
  // RESTORE CLEAN/FRESH STATE TO TEST BTN AFTER A TEST
  // ---------------------------------------------
  document.addEventListener('input', (e) => {
  const modal = e.target.closest(
    '[data-modal-type="creds"][data-creds-scope="template"]'
  );
  if (!modal) return;

  templateCredsTestPassed.value = false;
  setSaveButtonState(false);
});


/* ------------------------------------------------------------
   PURGE BUTTON CLICK (Two-stage safety)
------------------------------------------------------------ */

document.addEventListener('click', async (e) => {
  const purgeBtn = e.target.closest('[data-action="purge"]');
  if (!purgeBtn) return;

  const modal = purgeBtn.closest(
    '[data-modal-type="creds"][data-creds-scope="template"]'
  );
  if (!modal) return;

  const confirmWrap  = modal.querySelector('[data-role="purge-confirm"]');
  const confirmCheck = modal.querySelector('[data-role="purge-check"]');

  const isArmed = purgeBtn.dataset.armed === 'true';

  // FIRST CLICK → Show confirmation
  if (!isArmed) {
    confirmWrap?.classList.remove('hidden');
    purgeBtn.dataset.armed = 'true';
    purgeBtn.classList.add('armed');
    return;
  }

  // SECOND CLICK → Check if confirmed
  if (!confirmCheck?.checked) {
    // Not confirmed yet - do nothing
    return;
  }

  // EXECUTE PURGE
  if (!window.pywebview?.api?.clearCreds) return;

  await window.pywebview.api.clearCreds('template');

  // Clear form fields
  modal.querySelectorAll('[data-field]').forEach(el => el.value = '');

  // Reset state
  resetTemplateCredsState();

  showTemplateCredsStatus('Credentials purged', false, 2500);
});


/* ------------------------------------------------------------
   CONFIRMATION CHECKBOX (Show/hide on check/uncheck)
------------------------------------------------------------ */

document.addEventListener('change', (e) => {
  const confirmCheck = e.target;
  if (!confirmCheck.matches('[data-role="purge-check"]')) return;

  const modal = confirmCheck.closest(
    '[data-modal-type="creds"][data-creds-scope="template"]'
  );
  if (!modal) return;

  const confirmWrap = modal.querySelector('[data-role="purge-confirm"]');
  const purgeBtn    = modal.querySelector('[data-action="purge"]');

  // If UNCHECKED → Hide wrapper and disarm button
  if (!confirmCheck.checked) {
    confirmWrap?.classList.add('hidden');
    if (purgeBtn) {
      purgeBtn.dataset.armed = 'false';
      purgeBtn.classList.remove('armed');
    }
  }
  // If CHECKED → Just enable the purge (wrapper already visible)
  // Button is already armed from first click
});