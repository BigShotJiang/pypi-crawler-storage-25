/**
 * ============================================================
 * CyberSuite — Output Remote Credentials Modal
 * ============================================================
 * Author(s): Gil & Z3k3 — cyberfluence.com
 * Path:      ui/js/modals/output_creds_modal.js
 *
 * Description:
 *     UI-only behavior for OUTPUT remote credentials.
 *     Handles test/save/purge flow scoped strictly to output.
 *
 * Inputs:
 *     - Click events on [data-open-modal="output"] (modal open)
 *     - Click events on [data-action="save"|"purge"] within
 *       output-scoped creds modal
 *     - Input events on form fields (resets test-passed flag)
 *
 * Processing:
 *     - Opens modal and loads saved creds via BridgeAPI.fillCredFields
 *     - Save: validates test-passed, resolves SSH config, persists
 *     - Purge: clears creds via pywebview.api.clearCreds
 *     - Input changes reset test-passed flag and disable Save
 *
 * Outputs:
 *     - Exposes window.outputCredsTestPassed session flag
 *     - Exposes window.setOutputCredsSaveEnabled toggle
 *     - Calls pywebview.api.saveConnection / clearCreds
 *     - Updates status message with ok/error class
 * ============================================================
 */


/* ------------------------------------------------------------
   Session Guard (UI only, OUTPUT scope only)
------------------------------------------------------------ */

const outputCredsTestPassed = { value: false };

/* expose minimal hooks for ui_components.js */
window.outputCredsTestPassed = outputCredsTestPassed;
window.setOutputCredsSaveEnabled = setSaveButtonState;


/* ------------------------------------------------------------
   Utilities
------------------------------------------------------------ */

function resetOutputCredsState() {
  outputCredsTestPassed.value = false;
  setSaveButtonState(false);
}


/* ------------------------------------------------------------
   Button State (Save)
------------------------------------------------------------ */

function setSaveButtonState(enabled) {
  const btn = document.querySelector(
    '[data-modal-type="creds"][data-creds-scope="output"] [data-action="save"]'
  );
  if (!btn) return;

  btn.classList.toggle('inactive', !enabled);
}


/* ------------------------------------------------------------
   Status Message (class-only, no inline styles)
------------------------------------------------------------ */

function showOutputCredsStatus(message, ok, duration = 5000) {
  const statusEl = document.querySelector(
    '[data-modal-type="creds"][data-creds-scope="output"] [data-role="status"]'
  );
  if (!statusEl) return;

  statusEl.textContent = message;
  statusEl.classList.toggle('ok', ok);
  statusEl.classList.toggle('error', !ok);
  statusEl.classList.add('visible');

  setTimeout(() => {
    statusEl.classList.remove('visible');
  }, duration);
}


/* ------------------------------------------------------------
   OUTPUT MODAL OPEN HOOK
------------------------------------------------------------ */

document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-open-modal="output"]');
  if (!btn) return;

  if (window.BridgeAPI?.fillCredFields) {
    window.BridgeAPI.fillCredFields('output');
  }

  resetOutputCredsState();
});


/* ------------------------------------------------------------
   Event Wiring
------------------------------------------------------------ */

document.addEventListener('click', async (e) => {
  const actionEl = e.target.closest('[data-action]');
  if (!actionEl) return;

  const modal = actionEl.closest(
    '[data-modal-type="creds"][data-creds-scope="output"]'
  );
  if (!modal) return;

  const action = actionEl.dataset.action;

  /* ---- SAVE + CLOSE ---- */
  if (action === 'save') {

    if (actionEl.classList.contains('inactive')) return;
    if (!outputCredsTestPassed.value) return;
    if (!window.pywebview?.api?.saveConnection) return;

    const creds = collectCreds('output');

    // ---------------------------------------------
    // SSH config resolve on save (silent)
    // ---------------------------------------------
    if (creds.host && !creds.user) {
      const res = await window.pywebview.api.resolve_ssh_config(creds);

      if (!res || !res.success) {
        showOutputCredsStatus('SSH config failed', false);
        return;
      }

      Object.assign(creds, res.resolved);
    }

    // ---------------------------------------------
    // SAVE
    // ---------------------------------------------
    const result = await window.pywebview.api.saveConnection('output', creds);

    if (!result || result.ok !== true) {
      showOutputCredsStatus('Save failed', false);
      return;
    }

    showOutputCredsStatus('Credentials saved', true, 2000);


    await window.pywebview.api.resolve_ssh_config(creds);

    if (!result || result.ok !== true) {
      showOutputCredsStatus('Save failed', false);
      return;
    }

    showOutputCredsStatus('Credentials saved', true, 2000);

    setTimeout(() => {
      modal.closest('.modal-overlay')?.classList.remove('active');
    }, 2000);
  }
});

  // ---------------------------------------------
  // RESTORE CLEAN/FRESH STATE TO TEST BTN AFTER A TEST
  // ---------------------------------------------
  document.addEventListener('input', (e) => {
    const modal = e.target.closest(
      '[data-modal-type="creds"][data-creds-scope="output"]'
    );
    if (!modal) return;

    outputCredsTestPassed.value = false;
    setSaveButtonState(false);
  });


/* ------------------------------------------------------------
   Purge Flow
------------------------------------------------------------ */

document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-action="purge"]');
  if (!btn) return;

  const modal = btn.closest(
    '[data-modal-type="creds"][data-creds-scope="output"]'
  );
  if (!modal) return;

  if (btn.classList.contains('inactive')) return;
  if (!window.pywebview?.api?.clearCreds) return;

  await window.pywebview.api.clearCreds('output');

  resetOutputCredsForm(modal);
  resetOutputCredsState();

  showOutputCredsStatus('Credentials purged', false, 2500);
});


/* ------------------------------------------------------------
   Expected External Hooks (DO NOT DEFINE HERE)
------------------------------------------------------------ */

// collectCreds('output')       → ui_components.js
// resetOutputCredsForm(modal)  → ui_components.js
