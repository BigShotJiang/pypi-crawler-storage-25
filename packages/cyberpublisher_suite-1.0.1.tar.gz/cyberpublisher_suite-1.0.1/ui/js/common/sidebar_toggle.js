// ========================================================
// CyberSuite — Sidebar Toggle + Landing Links
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/common/sidebar_toggle.js
//
// Description:
//     Handles sidebar collapse/expand, landing-page panel
//     navigation links, and meta-modal launches (theme/info).
//
// Inputs:
//     - Click events on #sidebar_handle (toggle)
//     - Click events on landing <dd> elements (panel nav)
//     - Click events on [data-modal] elements (modal open)
//     - DOMContentLoaded event (init landing links)
//
// Processing:
//     - Toggles .collapsed class on sidebar element
//     - Maps landing text to panel IDs via TOOL_PANEL_MAP
//     - Maps meta keywords to modal types via META_MODAL_MAP
//     - Opens modals by matching [data-modal-type] overlays
//
// Outputs:
//     - DOM class mutations on sidebar and modal overlays
//     - Sets data-panel / data-modal attributes on landing items
//     - No return values; all effects are DOM mutations
// ========================================================

// ========================================================
// SIDEBAR TOGGLE
// ========================================================

const sidebar = document.getElementById('sidebar');
const handle  = document.getElementById('sidebar_handle');

// Toggle sidebar open / closed
handle.addEventListener('click', (e) => {
  e.stopPropagation();
  sidebar.classList.toggle('collapsed');
});

// Click anywhere else closes sidebar
document.addEventListener('click', () => {
  if (!sidebar.classList.contains('collapsed')) {
    sidebar.classList.add('collapsed');
  }
});



// ========================================================
// LANDING PANEL LINKS (DATA-DRIVEN)
// ========================================================

const TOOL_PANEL_MAP = {
  'create':    'panel-scribe-create',
  'append':    'panel-scribe-append',
  'publisher': 'panel-publisher',
  'mapper':    'panel-mapper'
};

const META_MODAL_MAP = {
  'themes': 'theme',
  'about':  'info'
};

function activateLandingLinks() {
  const landingList = document.querySelector('.landing_cnt_list dl');
  if (!landingList) return;

  const items = landingList.querySelectorAll('dd');

  items.forEach(dd => {
    const text = dd.textContent.trim().toLowerCase();

    const key = text
      .replace(/^~/, '')
      .replace(/['"]/g, '')
      .split(/\s+/)[0]
      .trim();

    if (TOOL_PANEL_MAP[key]) {
      dd.setAttribute('data-panel', TOOL_PANEL_MAP[key]);
      dd.classList.add('landing-link');
      dd.style.cursor = 'pointer';
    }
    else if (META_MODAL_MAP[key]) {
      dd.setAttribute('data-modal', META_MODAL_MAP[key]);
      dd.classList.add('landing-link');
      dd.style.cursor = 'pointer';
    }
  });
}

// Init after DOM ready
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(activateLandingLinks, 100);
});

// Re-run when returning to landing
document.addEventListener('click', (e) => {
  const link = e.target.closest('[data-panel="panel-landing"]');
  if (!link) return;

  setTimeout(activateLandingLinks, 100);
});


// ========================================================
// MODAL OPEN HANDLER (AUTHORITATIVE, SINGLE)
// ========================================================

document.addEventListener("click", (e) => {
  const link = e.target.closest("[data-modal]");
  if (!link) return;

  e.preventDefault();

  const modalName = link.dataset.modal;

  const modal = document.querySelector(
    `.modal-overlay[data-modal-type="${modalName}"]`
  );

  if (!modal) {
    console.warn("[ui] modal not found:", modalName);
    return;
  }

  modal.classList.add("active");
});


// EOF
