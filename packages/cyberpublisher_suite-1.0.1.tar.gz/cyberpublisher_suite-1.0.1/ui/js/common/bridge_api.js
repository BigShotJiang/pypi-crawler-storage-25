// ============================================================
// CyberSuite — Bridge API (JS → Python)
// ============================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/common/bridge_api.js
//
// Description:
//     JavaScript-side adapter layer for all pywebview.api
//     calls. Provides null-safe wrappers with form-field
//     collection fallbacks. Single source of truth for
//     bridge communication.
//
// Inputs:
//     - scope (string) — credential scope ("template",
//       "data", "output")
//     - creds (object|null) — credential payload; if null,
//       collected from DOM form fields via [data-field]
//     - spec (object) — pick_file specification
//
// Processing:
//     - Guards all calls with pywebview.api availability checks
//     - saveConnection: collects form fields if creds not passed
//     - fillCredFields: loads persisted creds and populates DOM
//     - testConnection: pass-through to pywebview.api
//     - clearCreds: pass-through to pywebview.api
//     - pick_file: pass-through to pywebview.api
//
// Outputs:
//     - Attaches methods to window.BridgeAPI namespace
//     - Returns pywebview.api responses (async) or undefined
//     - Populates DOM form fields on fillCredFields success
// ============================================================
window.BridgeAPI = window.BridgeAPI || {};


// ============================================================
// SAVE CREDS (called by UI layer)
// ============================================================
window.BridgeAPI.saveConnection = async function (scope, creds) {
  if (!window.pywebview?.api?.saveConnection) {
    console.warn("[bridge_api] pywebview.api.saveConnection unavailable");
    return;
  }

  // If creds not passed, collect from form
  if (!creds) {
    const modal = document.querySelector(`[data-creds-scope="${scope}"]`);
    if (!modal) {
      console.warn("[bridge_api] saveConnection: modal not found for scope:", scope);
      return;
    }

    const get = field => modal.querySelector(`[data-field="${field}"]`)?.value || "";

    creds = {
      host: get("host").trim(),
      port: get("port").trim() || "22",
      user: get("user").trim(),
      password: get("pass"),
      key_filename: ""
    };
  }

  console.log("[bridge_api] saveConnection:", { scope, host: creds.host });
  return window.pywebview.api.saveConnection(scope, creds);
};


// ============================================================
// LOAD SAVED CREDS INTO FORM (called by UI layer)
// ============================================================
window.BridgeAPI.fillCredFields = async function (scope) {
  if (!window.pywebview?.api?.load_creds) {
    console.warn("[bridge_api] pywebview.api.load_creds unavailable");
    return;
  }

  console.log("[bridge_api] fillCredFields request:", scope);

  try {
    const result = await window.pywebview.api.load_creds(scope);
    console.log("[bridge_api] creds returned:", result);

    if (!result?.ok || !result.creds) return;

    const modal = document.querySelector(`[data-creds-scope="${scope}"]`);
    if (!modal) {
      console.warn("[bridge_api] fillCredFields: modal not found for scope:", scope);
      return;
    }

    // Populate form fields via data-field selectors
    Object.entries(result.creds).forEach(([key, val]) => {
      const el = modal.querySelector(`[data-field="${key}"]`);
      if (el && val !== undefined && val !== null) {
        el.value = val;
        console.log(`[bridge_api] filled ${key}:`, val);
      }
    });

  } catch (err) {
    console.error("[bridge_api] fillCredFields failed:", err);
  }
};


// ============================================================
// SSH TEST ADAPTER
// ============================================================
window.BridgeAPI.testConnection = async function (scope, payload) {
  if (!window.pywebview?.api?.testConnection) return;
  return window.pywebview.api.testConnection(scope, payload);
};


// ============================================================
// CLEAR CREDS ADAPTER
// ============================================================
window.BridgeAPI.clearCreds = function (scope) {
  if (!window.pywebview?.api?.clear_creds) return;
  console.log("[bridge_api] clearCreds:", scope);
  return window.pywebview.api.clear_creds(scope);
};


// ============================================================
// PICK FILE ADAPTER  ✅ FIX
// ============================================================
window.BridgeAPI.pick_file = async function (spec) {
  if (!window.pywebview?.api?.pick_file) {
    console.warn("[bridge_api] pywebview.api.pick_file unavailable");
    return null;
  }

  console.log("[bridge_api] pick_file:", spec);
  return window.pywebview.api.pick_file(spec);
};


// ============================================================
// LOAD CONFIRM
// ============================================================
console.log("🔧 bridge_api loaded");

// EOF
