// ============================================================
// CyberSuite — Purge Creds Button (DATA-DRIVEN, KISS)
// ============================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/common/purge_btn.js
//
// Description:
//     Two-stage purge button for credential modals.
//     First click arms (shows confirm checkbox), second
//     click executes purge. One-shot + destructive.
//
// Inputs:
//     - Click events on [data-action="purge"] buttons
//     - Change events on [data-role="purge-check"] checkboxes
//     - Scoped to modals with [data-modal-type="creds"]
//
// Processing:
//     - First click: shows confirmation checkbox
//     - Checkbox change: enables/disables purge button
//     - Second click (if confirmed): calls pywebview.api.clear_creds()
//     - Resets all form fields and checkbox state after purge
//
// Outputs:
//     - Calls pywebview.api.clear_creds(scope) on confirmed purge
//     - Clears all [data-field] inputs in parent modal
//     - Toggles .inactive and .hidden classes on purge UI
// ============================================================

(function () {

  function getModal(el) {
    return el.closest('[data-modal-type="creds"]');
  }

  function resetUI(modal) {
    // clear inputs
    modal.querySelectorAll('[data-field]').forEach(el => {
      el.value = '';
    });

    // reset purge confirm checkbox
    const chk = modal.querySelector('[data-role="purge-check"]');
    if (chk) {
      chk.checked = false;
      chk.closest('.action_conf')?.classList.add('hidden');
    }

    // disable purge button again
    modal.querySelector('[data-action="purge"]')
         ?.classList.add('inactive');
  }

  // ----------------------------
  // PURGE BUTTON CLICK
  // ----------------------------
  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-action="purge"]');
    if (!btn) return;

    // 🔑 CRITICAL: prevent label / checkbox bubbling
    e.stopPropagation();

    const modal = getModal(btn);
    if (!modal) return;

    const scope = modal.dataset.credsScope;
    const chk   = modal.querySelector('[data-role="purge-check"]');
    if (!chk) return;

    // FIRST CLICK → ARM (show confirmation)
    if (!chk.checked) {
      chk.closest('.action_conf')?.classList.remove('hidden');
      return;
    }

    // SECOND CLICK → NUKE
    if (!window.pywebview?.api?.clear_creds) return;

    await window.pywebview.api.clear_creds(scope);

    resetUI(modal);
  });

  // ----------------------------
  // CONFIRM CHECKBOX CHANGE
  // ----------------------------
  document.addEventListener('change', (e) => {
    if (!e.target.matches('[data-role="purge-check"]')) return;

    const modal = getModal(e.target);
    if (!modal) return;

    // enable / disable purge button ONLY
    modal.querySelector('[data-action="purge"]')
         ?.classList.toggle('inactive', !e.target.checked);
  });

})();
