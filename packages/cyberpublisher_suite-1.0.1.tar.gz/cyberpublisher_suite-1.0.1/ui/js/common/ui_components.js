// ============================================================
// CyberSuite — UI Components (Global Helpers)
// ============================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/common/ui_components.js
//
// Description:
//     Globally callable helpers for inline HTML handlers.
//     Thin JS → BridgeAPI adapter. No business logic.
//     Requires pywebview and StateManager to be loaded first.
//
// Inputs:
//     - scope (string) — creds scope for modal operations
//     - pywebviewready event — binds BridgeAPI.py
//     - Click/change events delegated from inline HTML handlers
//     - Live form field values via [data-field] selectors
//
// Processing:
//     - openCredsWin/closeCredsWin: modal overlay toggles
//     - collectCreds: reads live form values into creds object
//     - testConnection: sends live creds to Python SSH test,
//       updates per-scope session flags and StateManager SSH status
//     - saveConnection: delegates to BridgeAPI.saveConnection
//     - clearCreds: purges creds via pywebview.api + resets form
//     - showSSHStatus: renders timed status message with ok/error class
//
// Outputs:
//     - Attaches to window: openCredsWin, closeCredsWin,
//       testConnection, saveConnection, clearCreds, showSSHStatus
//     - Updates StateManager.setSSHStatus on test results
//     - Toggles per-scope *CredsTestPassed flags and save button state
// ============================================================


// ------------------------------------------------------------
// BRIDGE BINDING (SINGLE SOURCE OF TRUTH)
// ------------------------------------------------------------
document.addEventListener("pywebviewready", () => {
  window.BridgeAPI.py = window.pywebview.api;
  console.log("🔌 BridgeAPI.py bound");
});



// ------------------------------------------------------------
// MODAL HELPERS (DATA-DRIVEN)
// ------------------------------------------------------------
window.openCredsWin = function (scope) {
  const modal = document.querySelector(
    `.modal[data-modal-type="creds"][data-creds-scope="${scope}"]`
  );

  if (!modal) {
    console.warn("[ui_components] openCredsWin: modal not found for scope:", scope);
    return;
  }

  modal.closest(".modal-overlay").classList.add("active");
};

window.closeCredsWin = function (scope) {
  const modal = document.querySelector(
    `.modal[data-modal-type="creds"][data-creds-scope="${scope}"]`
  );

  if (!modal) {
    console.warn("[ui_components] closeCredsWin: modal not found for scope:", scope);
    return;
  }

  modal.classList.remove("active");
};


// ------------------------------------------------------------
// COLLECT LIVE CREDS FROM FORM (DATA-FIELD DRIVEN)
// ------------------------------------------------------------
function collectCreds(scope) {
  const modal = document.querySelector(`[data-creds-scope="${scope}"]`);
  if (!modal) {
    console.warn("[ui_components] collectCreds: modal not found for scope:", scope);
    return null;
  }

  const get = field => modal.querySelector(`[data-field="${field}"]`)?.value || "";

  return {
    host: get("host").trim(),
    port: parseInt(get("port") || "22", 10),
    user: get("user").trim(),
    password: get("pass"),
    key_filename: get("key")
  };
}


// ============================================================
// SSH TEST (LIVE CREDS → Python)
// ============================================================
window.testConnection = async function (scope) {

  if (!window.pywebview?.api?.testConnection) {
    console.warn("[ui] pywebview.api.testConnection unavailable");
    return;
  }

  const modal = document.querySelector(`[data-creds-scope="${scope}"]`);
  if (!modal) {
    console.warn("[ui] testConnection: modal not found for scope:", scope);
    return;
  }

  // Collect LIVE form values via data-field selectors
  const get = field => modal.querySelector(`[data-field="${field}"]`)?.value || "";

  const creds = {
    host: get("host").trim(),
    port: get("port").trim() || "22",
    user: get("user").trim(),
    password: get("pass"),
    key_filename: ""
  };

  console.log("[ui] testConnection collected:", { scope, host: creds.host, user: creds.user });

  // 🔑 PYWEBVIEW BOUNDARY — MUST SEND STRING
  const payload = JSON.stringify(creds);

  // Pessimistic default — always start FAIL
  if (window.StateManager?.setSSHStatus) {
    StateManager.setSSHStatus(scope, false);
  }

  // --------------------------------------------------
  // SSH alias short-circuit (UI-level)
  // --------------------------------------------------
  if (payload.host_alias && !payload.host && !payload.user) {
    console.log('[ui] SSH alias present, bypassing field validation');

    // Treat as "test passed" so Save can proceed
    if (scope === 'template' && window.templateCredsTestPassed) {
      window.templateCredsTestPassed.value = true;
      window.setTemplateCredsSaveEnabled?.(true);
    }

    if (scope === 'data' && window.dataCredsTestPassed) {
      window.dataCredsTestPassed.value = true;
      window.setDataCredsSaveEnabled?.(true);
    }

    if (scope === 'output' && window.outputCredsTestPassed) {
      window.outputCredsTestPassed.value = true;
      window.setOutputCredsSaveEnabled?.(true);
    }

    return; // ⬅️ DO NOT call testConnection yet
  }


  try {
    const result = await window.pywebview.api.testConnection(scope, payload);
    const ok  = !!result?.ok;
    const msg = result?.message || (ok ? "Connection OK" : "Connection failed");

    console.log("[ui] testConnection result:", { scope, ok, msg });

    // Template creds modal session flag + Save enable
    if (scope === 'template' && ok && window.templateCredsTestPassed) {
      window.templateCredsTestPassed.value = true;
      window.setTemplateCredsSaveEnabled?.(true);
    }

    // Data creds modal session flag + Save enable
    if (scope === 'data' && ok && window.dataCredsTestPassed) {
      window.dataCredsTestPassed.value = true;
      window.setDataCredsSaveEnabled?.(true);
    }

    // Output creds modal session flag + Save enable
    if (scope === 'output' && ok && window.outputCredsTestPassed) {
      window.outputCredsTestPassed.value = true;
      window.setOutputCredsSaveEnabled?.(true);
    }



    // Render status FIRST (pure UI)
    if (window.showSSHStatus) {
      showSSHStatus(scope, msg, ok);
    }

    // AUTHORITATIVE latch — Save gate depends on this
    if (window.StateManager?.setSSHStatus) {
      StateManager.setSSHStatus(scope, ok);
    }

    return result;

  } catch (err) {

    if (window.showSSHStatus) {
      showSSHStatus(scope, `❌ ${err}`, false);
    }

    if (window.StateManager?.setSSHStatus) {
      StateManager.setSSHStatus(scope, false);
    }

    console.error("[ssh-test]", err);
  }
};



// ------------------------------------------------------------
// SAVE CREDS (INLINE HTML ENTRY POINT)
// ------------------------------------------------------------
window.saveConnection = async function (scope) {
  if (!window.BridgeAPI?.saveConnection) {
    console.warn("[ui_components] BridgeAPI.saveConnection unavailable");
    return;
  }

  const creds = collectCreds(scope);
  if (!creds) return;

  console.log("[ui] saveConnection called:", { scope, host: creds.host });
  return BridgeAPI.saveConnection(scope, creds);
};


// ------------------------------------------------------------
// PURGE CREDS (OPTIONAL)
// ------------------------------------------------------------
window.clearCreds = function (scope) {
  if (!window.pywebview?.api?.clear_creds) {
    console.warn("[ui_components] clear_creds unavailable");
    return;
  }

  window.pywebview.api.clear_creds(scope);
  console.log("[ui] clearCreds called:", scope);

  const modal = document.querySelector(`[data-creds-scope="${scope}"]`);
  if (!modal) return;

  // Clear all input fields via data-field selectors
  ["host", "port", "user", "pass", "key"].forEach(field => {
    const el = modal.querySelector(`[data-field="${field}"]`);
    if (el) el.value = "";
  });

  if (window.StateManager?.setSSHStatus) {
    StateManager.setSSHStatus(scope, false);
  }
};

// ------------------------------------------------------------
// SSH STATUS DISPLAY
// ------------------------------------------------------------
window.showSSHStatus = function (scope, message, ok = false) {
  const el = document.getElementById(`ssh_test_status_${scope}`);
  if (!el) {
    console.warn(`[ui] ssh_test_status_${scope} element not found`);
    return;
  }

  el.textContent = message;

  // semantic state → CSS owns presentation
  el.classList.remove('ok', 'error');
  el.classList.add(ok ? 'ok' : 'error');
  el.classList.add('visible');

  setTimeout(() => {
    el.classList.remove('visible');
  }, 6000);
};


// ------------------------------------------------------------
// DROPDOWN aria-expanded sync
// Dropdowns open via CSS :hover; this keeps aria-expanded in step.
// ------------------------------------------------------------
document.addEventListener("mouseover", e => {
  const dropdown = e.target.closest("[role='combobox']");
  if (dropdown && !dropdown.classList.contains("disabled")) {
    dropdown.setAttribute("aria-expanded", "true");
  }
});

document.addEventListener("mouseout", e => {
  const dropdown = e.target.closest("[role='combobox']");
  if (dropdown && !dropdown.contains(e.relatedTarget)) {
    dropdown.setAttribute("aria-expanded", "false");
  }
});

document.addEventListener("click", e => {
  const opt = e.target.closest("[role='option']");
  if (opt) {
    const dropdown = opt.closest("[role='combobox']");
    if (dropdown) dropdown.setAttribute("aria-expanded", "false");
  }
});

// ------------------------------------------------------------
// CYCLICAL TAB TRAP
// ------------------------------------------------------------
window.trapTabCycle = function (container, { initialFocusSelector } = {}) {
  if (!container) return () => {};

  const focusables = () =>
    Array.from(
      container.querySelectorAll(
        'a[href], button:not([disabled]), textarea:not([disabled]), ' +
        'input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
      )
    ).filter(el => el.offsetParent !== null);

  const onKeyDown = (e) => {
    if (e.key !== "Tab") return;

    const els = focusables();
    if (!els.length) return;

    const first = els[0];
    const last  = els[els.length - 1];

    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  };

  container.addEventListener("keydown", onKeyDown);
  return () => container.removeEventListener("keydown", onKeyDown);
};

// ------------------------------------------------------------
// LOAD CONFIRM
// ------------------------------------------------------------
console.log("🔧 ui_components loaded");

// EOF