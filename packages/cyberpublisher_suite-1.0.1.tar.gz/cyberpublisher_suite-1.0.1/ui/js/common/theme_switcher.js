// ========================================================
// CyberSuite — Theme Switcher (JSON-persisted)
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/common/theme_switcher.js
//
// Persists theme via pywebview bridge (NOT localStorage).
// ========================================================

(function () {
  const THEME_LINK = document.getElementById('theme-vars');
  const BASE_PATH = '../styles/themes/';

  const FILE_MAP = {
    default:    'vars-default.css',
    mint:       'vars-mint.css',
    strawberry: 'vars-strawb.css',
    kauai:      'vars-kauai.css',
    sunset:     'vars-teqsunset.css',
    aurora:     'vars-aurora.css',
    dark:       'vars-drkdev.css',
    matrix:     'vars-matrix.css'
  };

  // ✅ awaitable theme apply (waits for CSS to load)
  function applyThemeAsync(key) {
    return new Promise((resolve) => {
      const file = FILE_MAP[key];
      if (!file || !THEME_LINK) return resolve(false);

      const href = BASE_PATH + file;

      // If already set, still resolve next tick (keeps ordering consistent)
      if (THEME_LINK.href && THEME_LINK.href.endsWith(href)) {
        return requestAnimationFrame(() => resolve(true));
      }

      const done = () => {
        clearTimeout(timer);
        THEME_LINK.removeEventListener('load', done);
        THEME_LINK.removeEventListener('error', done);
        requestAnimationFrame(() => resolve(true));
      };

      const timer = setTimeout(done, 300); // bail if load event never fires (pywebview)
      THEME_LINK.addEventListener('load', done, { once: true });
      THEME_LINK.addEventListener('error', done, { once: true });
      THEME_LINK.href = href;
    });
  }

  // ---------- Bridge helpers ----------
  function hasBridge() {
    return (typeof window.pywebview === 'object' && window.pywebview && window.pywebview.api);
  }

  async function loadPrefs() {
    if (!hasBridge()) return null;
    if (typeof window.pywebview.api.load_instance_prefs === 'function') return await window.pywebview.api.load_instance_prefs();
    if (typeof window.pywebview.api.get_instance_prefs === 'function')  return await window.pywebview.api.get_instance_prefs();
    if (typeof window.pywebview.api.instance_prefs === 'function')      return await window.pywebview.api.instance_prefs();
    console.warn('[theme_switcher] No prefs read API exposed on pywebview.api');
    return null;
  }

  async function savePrefs(prefs) {
    if (!hasBridge()) return false;
    if (typeof window.pywebview.api.write_instance_prefs === 'function') return await window.pywebview.api.write_instance_prefs(prefs);
    if (typeof window.pywebview.api.save_instance_prefs === 'function')  return await window.pywebview.api.save_instance_prefs(prefs);
    if (typeof window.pywebview.api.set_instance_prefs === 'function')   return await window.pywebview.api.set_instance_prefs(prefs);
    console.warn('[theme_switcher] No prefs write API exposed on pywebview.api');
    return false;
  }

  async function restoreThemeFromJson() {
    try {
      const prefs = await loadPrefs();
      const key = prefs?.ui_state?.theme;
      if (key && FILE_MAP[key]) {
        await applyThemeAsync(key);
        // optional: signal “theme is fully applied”
        window.dispatchEvent(new CustomEvent('cybersuite:theme-ready', { detail: { theme: key } }));
      }
    } catch (err) {
      // fail silent
    }
  }

  async function persistThemeToJson(key) {
    try {
      const prefs = (await loadPrefs()) || {};
      prefs.ui_state = prefs.ui_state || {};
      prefs.ui_state.theme = key;
      await savePrefs(prefs);
    } catch (err) {
      // fail silent
    }
  }

  window.addEventListener('pywebviewready', () => {
    restoreThemeFromJson();
  });

  const themeList = document.getElementById('theme-list');
  if (themeList) {
    themeList.addEventListener('click', async (e) => {
      const link = e.target.closest('[data-theme]');
      if (!link) return;

      e.preventDefault();
      const key = link.dataset.theme;

      await applyThemeAsync(key);
      await persistThemeToJson(key);

      const modal = link.closest('.modal-overlay');
      if (modal) modal.classList.remove('active');
    });
  }
})();
