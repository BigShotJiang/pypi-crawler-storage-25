// ============================================================
// CyberSuite — Action Controller (MINIMAL)
// ============================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/common/action_controller.js
//
// Description:
//     Centralized confirmation arming for irreversible
//     actions (publish, purge). UI-only — no business logic.
//
// Inputs:
//     - Click events on [data-action="publish"] buttons
//     - Click events on [data-action="purge"] buttons
//       within [data-modal-type="creds"] modals
//
// Processing:
//     - Publish: reveals [data-role="publish-confirm"] element
//     - Purge: reveals [data-role="purge-confirm"] inside
//       the scoped creds modal
//
// Outputs:
//     - Removes .hidden class from confirmation UI elements
//     - No API calls; purely visual state changes
// ============================================================

(function () {

  // ----------------------------
  // PUBLISH (arm confirmation)
  // ----------------------------
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action="publish"]');
    if (!btn) return;

    const conf = document.querySelector('[data-role="publish-confirm"]');
    conf?.classList.remove('hidden');
  });

  // ----------------------------
  // PURGE CREDS (arm confirmation)
  // NOTE: execution still handled by existing purge logic
  // ----------------------------
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action="purge"]');
    if (!btn) return;

    const modal = btn.closest('[data-modal-type="creds"]');
    if (!modal) return;

    const conf = modal.querySelector('[data-role="purge-confirm"]');
    conf?.classList.remove('hidden');
  });

})();
