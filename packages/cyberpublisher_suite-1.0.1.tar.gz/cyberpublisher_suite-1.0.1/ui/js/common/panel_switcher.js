// ========================================================
// CyberSuite — Panel Switcher
// ========================================================
// Author(s): Gil & Z3k3 — cyberfluence.com
// Path:      ui/js/common/panel_switcher.js
//
// Description:
//     Handles tool panel content swaps. Injects panel DOM
//     from <template> elements and fires tool-specific init
//     hooks after injection.
//
// Inputs:
//     - panelId (string) — ID of <template> element to load
//     - Click events on [data-panel] links (panel navigation)
//     - DOMContentLoaded event (loads default panel)
//
// Processing:
//     - Clones <template> content into #content container
//     - Calls window.initPublisherUI() for publisher panels
//     - Calls window.initScribeUI() for scribe panels
//     - Calls window.initMapperUI() for mapper panels
//     - Ignores clicks on [data-modal] to avoid conflicts
//
// Outputs:
//     - Replaces #content children with panel DOM
//     - Triggers tool init functions on window (side effects)
//     - Default panel: panel-publisher on DOMContentLoaded
// ========================================================

// ---------------------------------------------------------
// Core panel loader
// ---------------------------------------------------------
function loadPanel(panelId) {
  console.log('[panel_switcher] loadPanel:', panelId);

  const tmplt = document.getElementById(panelId);
  const content = document.getElementById('content');

  console.log('[panel-loader] loading:', panelId);
  console.log('[panel-loader] initPublisherUI exists:', typeof window.initPublisherUI);

  if (!tmplt) {
    console.warn('[panel_switcher] Panel not found:', panelId);
    return;
  }

  // -------------------------------------------------------
  // Inject panel DOM (ONCE)
  // -------------------------------------------------------
  content.replaceChildren(tmplt.content.cloneNode(true));
  console.log('[panel_switcher] panel injected:', tmplt.id);

  // -------------------------------------------------------
  // Tool-specific init hooks (POST injection ONLY)
  // -------------------------------------------------------
  if (tmplt.id.startsWith('panel-publisher') && window.initPublisherUI) {
    window.initPublisherUI();
  }

  if (tmplt.id.startsWith('panel-scribe') && window.initScribeUI) {
    window.initScribeUI();
  }

  if (tmplt.id.startsWith('panel-mapper') && window.initMapperUI) {
    window.initMapperUI();
  }
}

// ---------------------------------------------------------
// Panel link handler (STRICT)
// ---------------------------------------------------------
document.addEventListener('click', (e) => {

  // 🚫 Ignore modal links completely
  if (e.target.closest('[data-modal]')) return;

  const link = e.target.closest('[data-panel]');
  if (!link) return;

  e.preventDefault();
  loadPanel(link.dataset.panel);
});

// ---------------------------------------------------------
// Initial load (default landing panel)
// ---------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  loadPanel('panel-publisher');
});
