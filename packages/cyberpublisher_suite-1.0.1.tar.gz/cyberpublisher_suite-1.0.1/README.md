# cyberSuite 1.0.1

cyberSuite is a desktop-first, file-based publishing toolkit for structured content creation, rendering, shipping, and site mapping.

It combines four cooperating tools in one application:

- **Scribe** — create and append structured JSON content
- **Publisher** — render output from templates and data sourced locally or remotely
- **Mapper** — generate sitemap and related map artifacts
- **Site Chart** — produce structural JSON output for inspection

## Status

Current release line: **1.0.1**

## Requirements

- Python 3.13 recommended
- Linux desktop environment tested
- `pywebview` with GTK backend
- additional Python dependencies as required by the project

## Quick start

Clone the project, enter the repo, create a virtual environment, install dependencies, and launch the app:

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements-dev-freeze.txt
python3 app.py
