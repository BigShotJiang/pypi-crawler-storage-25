#!/usr/bin/env python3
"""
CyberSuite — Bridge API (Suite ↔ JS)
Path: proj_root/suite_bridge/api.py
"""

# --------------------------------------------------------
# Imports
# --------------------------------------------------------
from pathlib import Path
import json
import time
import os
import traceback

from suite_core.instance_prefs import (
    load_instance_prefs,
    write_instance_prefs,
    stamp_publish_time,
)
from suite_core.creds import load_creds, save_creds, test_remote_connection
from suite_bridge.remote_bridge import resolve_remote_creds
from publisher_core.pub_core import PublisherCore
from suite_core.utils import assert_safe_write
from suite_core.safehouse import get_tmp_dir, ensure_mapper_configs
from mapper_core.sitemap_generator import generate_sitemap
from suite_core.shipper_internal import ship_local
from suite_core.shipper_remote import ship_remote
from suite_core.logging import (
    emit_runlog_event,
    emit_dev_event,
    RunlogEvent,
    normalize_snapshot,
    new_run_id,
    now_ts,
)


# ============================================================
# SuiteAPI
# ============================================================
class SuiteAPI:
    """
    JS ↔ Python bridge object.
    Injected into PyWebView as `window.pywebview.api`.
    """

    # --------------------------------------------------------
    # INIT
    # --------------------------------------------------------
    def __init__(self):
        ensure_mapper_configs()
        self.instance_prefs = load_instance_prefs()
        self.run_id = new_run_id()

    # ====================================================
    # THEME PERSISTENCE
    # ====================================================
    def load_instance_prefs(self):
        return load_instance_prefs()

    def write_instance_prefs(self, prefs: dict):
        write_instance_prefs(None, prefs)
        return {"ok": True}

    # ====================================================
    # PICKER API
    # ====================================================
    def pick_file(self, spec: dict):
        from suite_bridge.pickers.picker import pick_file_by_intent

        return pick_file_by_intent(spec)

    # ====================================================
    # SCRIBE
    # ====================================================
    def scribe_save_json(self, json_text: str, filename: str, target_dir: str):
        try:
            out_dir = Path(target_dir).expanduser().resolve()
            final_path = out_dir / filename
            final_path.write_text(json_text, encoding="utf-8")
            return {"ok": True, "path": str(final_path)}
        except Exception as e:
            print("[api] scribe_save_json error:", e)
            return {"ok": False, "error": str(e)}

    def load_json_file(self, path: str):
        with open(path, "r", encoding="utf-8") as f:
            return {"ok": True, "doc": json.load(f)}

    # ====================================================
    # WRITE MANIFEST
    # ====================================================
    @staticmethod
    def write_manifest(run_dir, payload, result):
        run_dir = Path(run_dir).resolve()
        assert_safe_write(run_dir)
        run_dir.mkdir(parents=True, exist_ok=True)

        manifest_path = run_dir / "manifest.json"

        manifest = {
            "timestamp": time.time(),
            "template": payload.get("template", {}),
            "data": payload.get("data", {}),
            "output": payload.get("output", {}),
            "options": payload.get("options", {}),
            "files": result.files,
            "success": result.success,
            "errors": result.errors,
        }

        with manifest_path.open("w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

    # ====================================================
    # PUBLISH
    # ====================================================
    def publish(self, payload: dict):
        job_id = payload.get("job_id") or new_run_id()
        t_start = time.time()
        scope = "remote" if (payload.get("output") or {}).get("isRemote") else "local"

        # Log config — parsed before try so retain_all/dev_on are visible in except
        log_cfg = payload.get("log", {}) or {}
        retain_all = bool(log_cfg.get("retain_all", False))
        level = (log_cfg.get("level") or "snapshot").strip().lower()
        dev_on = level == "dev"

        try:
            template = payload.get("template", {})
            data = payload.get("data", {})
            output = payload.get("output", {})
            options = payload.get("options", {})
            mode = (options.get("mode") or "sitemap").strip().lower()

            if not output.get("path"):
                return {"ok": False, "error": "No output path provided"}

            dry_run = bool(payload.get("dry_run", False))
            overwrite = bool(options.get("overwrite", False))
            mode = "index" if options.get("indexMode") else "docs"

            raw_target = (options.get("publish_target") or "dev").strip().lower()
            publish_target = (
                raw_target if raw_target in ("dev", "stage", "prod") else "dev"
            )

            # --------------------------------------------------
            # LOG: job_start
            # --------------------------------------------------
            emit_runlog_event(
                RunlogEvent(
                    ts=now_ts(),
                    run_id=self.run_id,
                    job_id=job_id,
                    tool="publisher",
                    event="job_start",
                    status="ok",
                    scope=scope,
                ),
                trim=(not retain_all),
            )

            if dev_on:
                emit_dev_event(
                    {
                        "ts": now_ts(),
                        "run_id": self.run_id,
                        "job_id": job_id,
                        "tool": "publisher",
                        "event": "job_start",
                        "scope": scope,
                        "payload": normalize_snapshot(payload),
                    }
                )

            # --------------------------------------------------
            # LOG: snapshot (confirm receipt mirror)
            # --------------------------------------------------
            emit_runlog_event(
                RunlogEvent(
                    ts=now_ts(),
                    run_id=self.run_id,
                    job_id=job_id,
                    tool="publisher",
                    event="snapshot",
                    status="ok",
                    scope=scope,
                    snapshot=normalize_snapshot(
                        {
                            "mode": mode,
                            "template": {
                                "path": template.get("path"),
                                "remote": bool(template.get("isRemote")),
                            },
                            "data": {
                                "path": data.get("path"),
                                "remote": bool(data.get("isRemote")),
                            },
                            "output": {
                                "path": output.get("path"),
                                "remote": bool(output.get("isRemote")),
                            },
                            "options": {
                                "overwrite": overwrite,
                                "dry_run": dry_run,
                                "index_mode": mode == "index",
                            },
                        }
                    ),
                ),
                trim=(not retain_all),
            )

            from suite_core.safehouse import purge_tmp

            purge_tmp(reason="pre_publish")

            ts = time.strftime("%Y%m%d_%H%M%S")
            run_dir = get_tmp_dir() / f"run_{ts}"
            assert_safe_write(run_dir)

            out_dir = run_dir / "output"
            assert_safe_write(out_dir)
            out_dir.mkdir(parents=True, exist_ok=True)

            from suite_core.shipper_remote import fetch_remote_file

            input_dir = run_dir / "input"
            assert_safe_write(input_dir)
            (input_dir / "template").mkdir(parents=True, exist_ok=True)
            (input_dir / "data").mkdir(parents=True, exist_ok=True)

            tmpl_local = template.get("path")
            data_local = data.get("path")

            if template.get("isRemote"):
                tmpl_local = input_dir / "template" / Path(template["path"]).name
                tmpl_creds = load_creds("template")
                tmpl_spec = {**tmpl_creds, "path": template["path"]}
                fetch_remote_file(tmpl_spec, template["path"], tmpl_local)

            if data.get("isRemote"):
                data_local = input_dir / "data" / Path(data["path"]).name
                data_creds = load_creds("data")
                data_spec = {**data_creds, "path": data["path"]}
                fetch_remote_file(data_spec, data["path"], data_local)

            core = PublisherCore(
                template_path=str(tmpl_local),
                data_path=str(data_local),
                output_path=str(out_dir),
                output_ext=output.get("ext", ".html"),
                dry_run=dry_run,
                mode=mode,
                overwrite=overwrite,
                publish_target=publish_target,
            )

            result = core.run()

            if dev_on:
                emit_dev_event(
                    {
                        "ts": now_ts(),
                        "run_id": self.run_id,
                        "job_id": job_id,
                        "tool": "publisher",
                        "event": "result",
                        "scope": scope,
                        "success": bool(result.success),
                        "files": result.files,
                        "errors": result.errors,
                    }
                )

            SuiteAPI.write_manifest(run_dir, payload, result)

            if result.success:
                if output.get("isRemote"):
                    out_creds = load_creds("output")
                    out_spec = {**out_creds, "path": output["path"]}
                    ship_remote(
                        run_dir=run_dir, remote_spec=out_spec, overwrite=overwrite
                    )
                else:
                    ship_local(
                        run_dir=run_dir,
                        final_output_path=output.get("path"),
                        overwrite=overwrite,
                    )

                stamp_publish_time(self.instance_prefs)
                write_instance_prefs(None, self.instance_prefs)

            # --------------------------------------------------
            # LOG: job_end
            # --------------------------------------------------
            emit_runlog_event(
                RunlogEvent(
                    ts=now_ts(),
                    run_id=self.run_id,
                    job_id=job_id,
                    tool="publisher",
                    event="job_end",
                    status="ok" if result.success else "fail",
                    scope=scope,
                    timing_ms=int((time.time() - t_start) * 1000),
                    counts={"files_written": len(result.files)},
                    error={"message": result.errors[0]} if result.errors else None,
                ),
                trim=(not retain_all),
            )

            return {
                "ok": result.success,
                "logs": result.logs,
                "errors": result.errors,
                "files": result.files,
                "timing_ms": int((time.time() - t_start) * 1000),
            }

        except Exception as e:
            try:
                if dev_on:
                    emit_dev_event(
                        {
                            "ts": now_ts(),
                            "run_id": self.run_id,
                            "job_id": job_id,
                            "tool": "publisher",
                            "event": "exception",
                            "scope": scope,
                            "message": str(e),
                            "trace": traceback.format_exc(),
                        }
                    )
                emit_runlog_event(
                    RunlogEvent(
                        ts=now_ts(),
                        run_id=self.run_id,
                        job_id=job_id,
                        tool="publisher",
                        event="error",
                        status="fail",
                        scope=scope,
                        error={"type": type(e).__name__, "message": str(e)},
                    ),
                    trim=(not retain_all),
                )
                emit_runlog_event(
                    RunlogEvent(
                        ts=now_ts(),
                        run_id=self.run_id,
                        job_id=job_id,
                        tool="publisher",
                        event="job_end",
                        status="fail",
                        scope=scope,
                        timing_ms=int((time.time() - t_start) * 1000),
                    ),
                    trim=(not retain_all),
                )
            except Exception:
                pass
            print("[api] publish error:", e)
            return {"ok": False, "error": str(e)}

    # ====================================================
    # CREDS
    # ====================================================
    def has_creds(self, scope: str) -> bool:
        creds = load_creds(scope)
        host = (creds.get("host") or "").strip()
        user = (creds.get("user") or "").strip()
        return bool(host and user)

    def resolve_ssh_config(self, payload: dict):
        return resolve_remote_creds(payload)

    def testConnection(self, scope: str, creds_json: str):
        creds = json.loads(creds_json)
        if creds.get("host") and not creds.get("user"):
            return {"ok": True, "message": "SSH alias accepted", "scope": scope}
        ok, msg = test_remote_connection(creds)
        return {"ok": ok, "message": msg, "scope": scope}

    def saveConnection(self, scope: str, creds: dict):
        scope_key = scope.lower()
        if scope_key in ("out", "output", "remote_output"):
            base_url = (creds.get("base_url") or "").strip()
            creds["base_url"] = base_url
        save_creds(scope, creds)
        return {"ok": True, "scope": scope}

    def load_creds(self, scope: str):
        return {"ok": True, "creds": load_creds(scope)}

    def clear_creds(self, scope: str):
        from suite_core import creds, state

        creds.clear(scope)
        state.clear_creds(scope)
        return {"success": True}

    # ====================================================
    # MAP
    # ====================================================
    def map(self, payload: dict):
        job_id = payload.get("job_id") or new_run_id()
        t_start = time.time()
        scope = (
            "remote"
            if (payload.get("target") or {}).get("scope") == "remote"
            else "local"
        )

        # Log config — parsed before try so retain_all/dev_on are visible in except
        log_cfg = payload.get("log", {}) or {}
        retain_all = bool(log_cfg.get("retain_all", False))
        level = (log_cfg.get("level") or "snapshot").strip().lower()
        dev_on = level == "dev"

        try:
            target = payload.get("target", {})
            output = payload.get("output", {})
            options = payload.get("options", {})

            if not target or not output:
                return {"success": False, "error": "Missing target or output"}

            base_url = (options.get("baseUrl") or "").strip()
            mode = (options.get("mode") or "sitemap").strip().lower()
            gen_chart = bool(options.get("genChart", False))
            depth_limit = int(options.get("depth", 2))
            update_log = bool(options.get("updateLog", True))

            target_path = target.get("path")

            if target.get("scope") == "local":
                target_path = Path(target_path).expanduser().resolve()
                if not target_path.exists():
                    return {"success": False, "error": "Target path does not exist"}

            # --------------------------------------------------
            # LOG: job_start
            # --------------------------------------------------
            emit_runlog_event(
                RunlogEvent(
                    ts=now_ts(),
                    run_id=self.run_id,
                    job_id=job_id,
                    tool="mapper",
                    event="job_start",
                    status="ok",
                    scope=scope,
                ),
                trim=(not retain_all),
            )

            if dev_on:
                emit_dev_event(
                    {
                        "ts": now_ts(),
                        "run_id": self.run_id,
                        "job_id": job_id,
                        "tool": "mapper",
                        "event": "job_start",
                        "scope": scope,
                        "payload": normalize_snapshot(payload),
                    }
                )

            # --------------------------------------------------
            # LOG: snapshot
            # --------------------------------------------------
            emit_runlog_event(
                RunlogEvent(
                    ts=now_ts(),
                    run_id=self.run_id,
                    job_id=job_id,
                    tool="mapper",
                    event="snapshot",
                    status="ok",
                    scope=scope,
                    snapshot=normalize_snapshot(
                        {
                            "target": {
                                "path": str(target_path),
                                "scope": target.get("scope", "local"),
                            },
                            "output": {
                                "path": output.get("path"),
                                "scope": output.get("scope", "local"),
                            },
                            "options": {
                                "mode": mode,
                                "base_url": base_url or None,
                                "gen_chart": gen_chart or None,
                                "update_log": update_log or None,
                                "depth": depth_limit,
                            },
                        }
                    ),
                ),
                trim=(not retain_all),
            )

            from suite_core.safehouse import purge_tmp

            purge_tmp(reason="pre_map")

            run_epoch = int(time.time())
            timestamp_hm = time.strftime("%Y-%m-%d %H:%M", time.gmtime(run_epoch))

            ts = time.strftime("%Y%m%d_%H%M%S")
            run_dir = get_tmp_dir() / f"run_{ts}" / "mapper"
            assert_safe_write(run_dir)
            run_dir.mkdir(parents=True, exist_ok=True)

            output_dir = run_dir / "output"
            assert_safe_write(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            # --------------------------------------------------
            # WALK TREE
            # --------------------------------------------------
            nodes = []
            dir_count = 0
            file_count = 0

            if target.get("scope") == "remote":
                from suite_core.remote_utils import walk_remote_tree

                out_creds = load_creds("output")
                nodes, dir_count, file_count = walk_remote_tree(
                    creds=out_creds,
                    root_path=target_path,
                )
            else:
                # ==========================================================
                # NOTE — FUTURE ARTIFACT EXCLUSION POINT
                # ----------------------------------------------------------
                # If we later decide to exclude generated artifacts
                # (e.g., site_chart.json, sitemap.xml, robots.txt,
                # site_log.txt, or other system-managed files),
                # filtering should happen HERE — during tree walk —
                # not inside site_chart_builder.
                #
                # Rationale:
                #   - map_index.json is our canonical snapshot.
                #   - Filtering here ensures ALL downstream consumers
                #     (sitemap, chart, logs, future tools) inherit
                #     the same filtered reality.
                #
                # Files that may need updates if exclusion is added:
                #   - suite_core/remote_utils.py
                #   - suite_core/site_chart_builder.py
                #   - mapper UI toggle wiring
                #   - possible .cybersuiteignore implementation
                #
                # DO NOT implement exclusion in downstream generators.
                # This is the correct architectural seam.
                # ==========================================================

                for root, dirs, files in os.walk(target_path):
                    rel_root = Path(root).relative_to(target_path)
                    rel_path = str(rel_root) if str(rel_root) else "."
                    dir_count += 1

                    file_entries = []
                    for fname in sorted(files):
                        fpath = Path(root) / fname
                        try:
                            size = fpath.stat().st_size
                        except Exception:
                            size = None

                        file_entries.append(
                            {"name": fname, "ext": Path(fname).suffix, "size": size}
                        )
                        file_count += 1

                    nodes.append(
                        {"path": rel_path, "dirs": sorted(dirs), "files": file_entries}
                    )

            # --------------------------------------------------
            # BUILD CANONICAL MAP INDEX
            # --------------------------------------------------
            map_payload = {
                "schema_version": 1,
                "root": str(target_path),
                "mapper_run": {
                    "epoch": run_epoch,
                    "date": timestamp_hm,
                },
                "stats": {
                    "directories": dir_count,
                    "files": file_count,
                },
                "nodes": nodes,
            }

            map_file = run_dir / "map_index.json"
            with map_file.open("w", encoding="utf-8") as f:
                json.dump(map_payload, f, indent=2)

            # --------------------------------------------------
            # OPTIONAL SITE CHART
            # --------------------------------------------------
            if gen_chart:
                from suite_core.site_chart_builder import build_site_chart

                site_chart_payload = build_site_chart(
                    map_payload,
                    depth_limit=depth_limit,
                )

                site_chart_path = output_dir / "site_chart.json"
                with site_chart_path.open("w", encoding="utf-8") as f:
                    json.dump(site_chart_payload, f, indent=2)

            # --------------------------------------------------
            # OPTIONAL SITEMAP
            # --------------------------------------------------
            sitemap_path = None
            if mode == "sitemap" and base_url:
                sitemap_xml = generate_sitemap(map_payload, base_url)

                timestamp_block_xml = (
                    "<!--\n"
                    "=== CYBERSUITE_MAPPER_RUN ===\n"
                    f"DATE: {timestamp_hm}\n"
                    f"EPOCH: {run_epoch}\n"
                    "=============================\n"
                    "-->\n"
                )

                sitemap_xml = (
                    '<?xml version="1.0" encoding="UTF-8"?>\n'
                    + timestamp_block_xml
                    + sitemap_xml.split("?>", 1)[-1].lstrip()
                )

                sitemap_path = output_dir / "sitemap.xml"
                with sitemap_path.open("w", encoding="utf-8") as f:
                    f.write(sitemap_xml)

            # --------------------------------------------------
            # ROBOTS
            # --------------------------------------------------
            robots_path = output_dir / "robots.txt"
            robots_content = (
                "=== CYBERSUITE_MAPPER_RUN ===\n"
                f"DATE: {timestamp_hm}\n"
                f"EPOCH: {run_epoch}\n"
                "=============================\n"
                "User-agent: *\n"
                "Allow: /\n\n"
            )

            if sitemap_path and base_url:
                robots_content += f"Sitemap: {base_url.rstrip('/')}/sitemap.xml\n"

            with robots_path.open("w", encoding="utf-8") as f:
                f.write(robots_content)

            # --------------------------------------------------
            # OPTIONAL SITE LOG
            # --------------------------------------------------
            if update_log:
                site_log_path = output_dir / "site_log.txt"
                with site_log_path.open("a", encoding="utf-8") as f:
                    f.write(
                        f"=== CYBERSUITE_MAPPER_RUN ===\n"
                        f"DATE: {timestamp_hm}\n"
                        f"EPOCH: {run_epoch}\n"
                        f"dirs={dir_count} | files={file_count}\n\n"
                    )

            # --------------------------------------------------
            # SHIP
            # --------------------------------------------------
            if target.get("scope") == "remote":
                out_creds = load_creds("output")
                ship_remote(
                    run_dir=run_dir,
                    remote_spec={**out_creds, "path": target_path},
                    overwrite=True,
                )
            else:
                for artifact in output_dir.iterdir():
                    if not artifact.is_file():
                        continue

                    final_path = Path(target_path) / artifact.name

                    # --- APPEND site_log.txt instead of overwrite ---
                    if artifact.name == "site_log.txt" and update_log:
                        with open(artifact, "r", encoding="utf-8") as src:
                            content = src.read()

                        with open(final_path, "a", encoding="utf-8") as dst:
                            dst.write(content)

                    else:
                        with open(artifact, "rb") as src, open(final_path, "wb") as dst:
                            dst.write(src.read())

            # --------------------------------------------------
            # LOG: job_end
            # --------------------------------------------------
            emit_runlog_event(
                RunlogEvent(
                    ts=now_ts(),
                    run_id=self.run_id,
                    job_id=job_id,
                    tool="mapper",
                    event="job_end",
                    status="ok",
                    scope=scope,
                    timing_ms=int((time.time() - t_start) * 1000),
                    counts={"directories": dir_count, "files": file_count},
                ),
                trim=(not retain_all),
            )

            if dev_on:
                emit_dev_event(
                    {
                        "ts": now_ts(),
                        "run_id": self.run_id,
                        "job_id": job_id,
                        "tool": "mapper",
                        "event": "result",
                        "scope": scope,
                        "success": True,
                        "directories": dir_count,
                        "files": file_count,
                    }
                )

            return {
                "success": True,
                "mapped": True,
                "run_dir": str(run_dir),
                "artifacts": {
                    "map_index": str(map_file),
                    "sitemap": str(sitemap_path) if sitemap_path else None,
                },
                "counts": {
                    "directories": dir_count,
                    "files": file_count,
                },
                "timing_ms": int((time.time() - t_start) * 1000),
            }

        except Exception as e:
            try:
                if dev_on:
                    emit_dev_event(
                        {
                            "ts": now_ts(),
                            "run_id": self.run_id,
                            "job_id": job_id,
                            "tool": "mapper",
                            "event": "exception",
                            "scope": scope,
                            "message": str(e),
                            "trace": traceback.format_exc(),
                        }
                    )
                emit_runlog_event(
                    RunlogEvent(
                        ts=now_ts(),
                        run_id=self.run_id,
                        job_id=job_id,
                        tool="mapper",
                        event="error",
                        status="fail",
                        scope=scope,
                        error={"type": type(e).__name__, "message": str(e)},
                    ),
                    trim=(not retain_all),
                )
                emit_runlog_event(
                    RunlogEvent(
                        ts=now_ts(),
                        run_id=self.run_id,
                        job_id=job_id,
                        tool="mapper",
                        event="job_end",
                        status="fail",
                        scope=scope,
                        timing_ms=int((time.time() - t_start) * 1000),
                    ),
                    trim=(not retain_all),
                )
            except Exception:
                pass
            print("[api] map error:", e)
            return {"success": False, "error": str(e)}

        def open_external_url(self, url):
            import webbrowser

        if not isinstance(url, str):
            return {"success": False, "error": "URL must be a string"}

        url = url.strip()
        if not (url.startswith("http://") or url.startswith("https://")):
            return {"success": False, "error": "Only http/https URLs are allowed"}

        try:
            opened = webbrowser.open_new_tab(url)
            return {"success": bool(opened)}
        except Exception as e:
            return {"success": False, "error": str(e)}
