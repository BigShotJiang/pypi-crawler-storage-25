# ========================================================
# CyberSuite — Remote Bridge (SSH Alias Resolution)
# ========================================================
# Author(s): Gil & Z3k3 — cyberfluence.com
# Path:      suite_bridge/remote_bridge.py
#
# Description:
#     Bridge-layer adapter that wraps ssh_manager for
#     the JS/Python bridge. Translates UI payloads into
#     SSH resolution calls and returns bridge-compatible
#     result dicts.
#
# Inputs:
#     - payload (dict) with key "host_alias" or "host"
#       (from JS bridge call)
#
# Processing:
#     - Extracts host alias from payload
#     - Delegates to suite_core.ssh_manager.resolve_ssh_alias()
#
# Outputs:
#     - Returns { "success": True, "resolved": {...} }
#     - Returns { "success": False, "error": "..." } on failure
# ========================================================

from suite_core.ssh_manager import resolve_ssh_alias


def resolve_remote_creds(payload: dict):
    """
    Attempt silent SSH config resolution using host alias.
    """
    host_alias = payload.get("host_alias") or payload.get("host")
    if not host_alias:
        return {"success": False, "error": "SSH config failed"}

    resolved = resolve_ssh_alias(str(host_alias))

    if not resolved:
        return {"success": False, "error": "SSH config failed"}

    return {"success": True, "resolved": resolved}
