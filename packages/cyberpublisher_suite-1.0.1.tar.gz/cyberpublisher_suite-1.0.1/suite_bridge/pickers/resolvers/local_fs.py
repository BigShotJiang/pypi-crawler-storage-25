#!/usr/bin/env python3
"""
========================================================
CyberSuite — Local Filesystem Picker (Resolver)
Copywrite: cyberfluence.com 2025
A collaborative work of team 'Gil' and 'Z3k3'
========================================================
Path:
  suite_bridge/pickers/resolvers/local_fs.py
========================================================
Purpose:
  • Provide OS-native filesystem pickers.
  • Handle LOCAL filesystem interactions only.
  • Serve as a resolver for picker intents.
========================================================
Scope (v0):
  • Output file picker (write)
  • Local only
  • No filtering (yet)   <-- (now enforced post-select)
  • No context logic (yet)
========================================================
Notes:
  • Uses pywebview native dialogs (not tkinter).
  • Returns normalized picker payload.
  • Remote handling lives elsewhere.
========================================================
Happy coding, code = {:isPoetry;}
<!-- Will code for Beer! -->
========================================================
"""

import webview
import os


# ========================================================
# Helpers
# ========================================================
def _ext_allowed(path, allowed_exts):
    """
    Enforce extension filtering AFTER native dialog selection.
    pywebview cannot hide files, so we reject invalid picks.
    """
    if not allowed_exts:
        return True
    return os.path.splitext(path)[1].lower() in allowed_exts


# ========================================================
# Output File Picker (Save)
# ========================================================
def pick_output_file_local(allowed_exts=None):
    """
    Open OS-native Save File dialog.

    allowed_exts: list[str] | None
      (accepted but not enforced at dialog level)

    Returns (success):
      {
        "success": True,
        "path": "/full/path/file.json",
        "is_remote": False,
        "resource_type": "file"
      }

    Returns (failure):
      {
        "success": False,
        "error": "No file selected"
      }
    """

    path = webview.windows[0].create_file_dialog(
        webview.SAVE_DIALOG, allow_multiple=False
    )

    if not path:
        return {"success": False, "error": "No file selected"}

    return {
        "success": True,
        "path": path[0],
        "is_remote": False,
        "resource_type": "file",
    }


# ========================================================
# Template Picker (Open)
# ========================================================
def pick_template_local(allowed_exts=None):
    """
    Open OS-native Open File dialog for templates.

    allowed_exts: list[str] | None
      (ENFORCED post-select)
    """

    path = webview.windows[0].create_file_dialog(
        webview.OPEN_DIALOG, allow_multiple=False
    )

    if not path:
        return {"success": False, "error": "No template selected"}

    selected = path[0]

    if not _ext_allowed(selected, allowed_exts):
        return {
            "success": False,
            "error": f"Invalid template file type (allowed: {allowed_exts})",
        }

    return {
        "success": True,
        "path": selected,
        "is_remote": False,
        "resource_type": "file",
    }


# ========================================================
# Data File Picker (Open)
# ========================================================
def pick_data_file_local(allowed_exts=None):
    """
    Open OS-native Open File dialog for data files.

    allowed_exts: list[str] | None
      (ENFORCED post-select)
    """

    path = webview.windows[0].create_file_dialog(
        webview.OPEN_DIALOG, allow_multiple=False
    )

    if not path:
        return {"success": False, "error": "No data file selected"}

    selected = path[0]

    if not _ext_allowed(selected, allowed_exts):
        return {
            "success": False,
            "error": f"Invalid data file type (allowed: {allowed_exts})",
        }

    return {
        "success": True,
        "path": selected,
        "is_remote": False,
        "resource_type": "file",
    }


# ========================================================
# Output Directory Picker
# ========================================================
def pick_output_dir_local():
    """
    Open OS-native Directory dialog.

    Returns (success):
      {
        "success": True,
        "path": "/full/path/to/dir",
        "is_remote": False,
        "resource_type": "directory"
      }

    Returns (failure):
      {
        "success": False,
        "error": "No directory selected"
      }
    """

    path = webview.windows[0].create_file_dialog(
        webview.FOLDER_DIALOG, allow_multiple=False
    )

    if not path:
        return {"success": False, "error": "No directory selected"}

    return {
        "success": True,
        "path": path[0],
        "is_remote": False,
        "resource_type": "directory",
    }
