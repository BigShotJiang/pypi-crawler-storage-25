"""
CyberSuite — Remote Filesystem Picker (SSH Dress Rehearsal)
Path: suite_bridge/pickers/resolvers/remote_fs.py
========================================================
Purpose:
  • Establish SSH/SFTP connection
  • List a single directory (no traversal yet)
  • Return entries as data payload
========================================================
"""

import paramiko
import stat
from suite_core.creds import load_creds


def normalize_cwd(cwd):
    if not cwd or cwd == ".":
        return "/"
    cwd = cwd.replace("/./", "/")
    if not cwd.startswith("/"):
        cwd = "/" + cwd
    return cwd.rstrip("/") or "/"


def pick_remote_by_intent(intent: str, spec: dict, allowed_exts=None):
    print("🔥 REMOTE PICKER ACTIVE | allowed_exts =", allowed_exts)

    print("[remote_fs] pick_remote_by_intent called:", intent, spec)
    print("[remote_fs] allowed_exts:", allowed_exts)

    # --------------------------------------------------
    # Load credentials
    # --------------------------------------------------
    creds = load_creds(intent)
    print("[remote_fs] creds loaded keys:", list(creds.keys()) if creds else None)
    print("[remote_fs] creds raw:", repr(creds))

    if not creds:
        return {"success": False, "error": "No remote credentials available"}

    # --------------------------------------------------
    # Normalize cwd (CRITICAL)
    # --------------------------------------------------
    cwd = spec.get("cwd", ".")
    cwd = normalize_cwd(cwd)
    print("[remote_fs] cwd request:", cwd)

    # --------------------------------------------------
    # SSH / SFTP work continues below…
    # --------------------------------------------------
    host = creds.get("host")
    user = creds.get("user")
    port = int(creds.get("port", 22))
    password = creds.get("password")

    print(f"[remote_fs] connecting to {user}@{host}:{port}")

    ssh = paramiko.SSHClient()
    ssh.load_system_host_keys()
    ssh.set_missing_host_key_policy(paramiko.WarningPolicy())

    try:
        ssh.connect(
            hostname=host or "",
            port=port,
            username=user,
            password=password,
            timeout=10,
        )

        sftp = ssh.open_sftp()

        # IMPORTANT: do NOT guess paths yet
        print("[remote_fs] cwd request:", cwd)

        entries = []

        for attr in sftp.listdir_attr(cwd):
            is_dir = stat.S_ISDIR(attr.st_mode or 0)
            name = attr.filename

            # ----------------------------------------------
            # FILTER FILES BY EXTENSION (TRUE BLINDNESS)
            # ----------------------------------------------
            if not is_dir and allowed_exts:
                name_lower = name.lower()
                if not any(name_lower.endswith(ext) for ext in allowed_exts):
                    continue

            entries.append({"name": name, "type": "dir" if is_dir else "file"})

        sftp.close()
        ssh.close()

        return {
            "success": True,
            "scope": "remote",
            "intent": intent,
            "cwd": cwd,
            "entries": entries,
        }

    except Exception as e:
        print("[remote_fs] ERROR:", e)
        return {"success": False, "error": str(e)}
