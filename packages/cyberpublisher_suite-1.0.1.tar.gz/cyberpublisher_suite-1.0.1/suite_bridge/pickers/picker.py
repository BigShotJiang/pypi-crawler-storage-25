#!/usr/bin/env python3
"""
========================================================
CyberSuite — Picker Public API (Intent Router)
========================================================
Path:
  suite_bridge/pickers/picker.py
========================================================
Purpose:
  • Expose the ONLY public picker interface for CyberSuite.
  • Accept picker *intent specs* (what is needed).
  • Route intents to the correct resolver (local / remote).
========================================================
Design Rule:
  Intent in → normalized result out.
========================================================
"""

# ========================================================
# Imports
# ========================================================
from .resolvers.local_fs import (
    pick_template_local,
    pick_data_file_local,
    pick_output_dir_local,
)
from suite_core.creds import load_creds, has_valid_creds


# ========================================================
# Public Picker Entry Point
# ========================================================
def pick_file_by_intent(spec: dict):
    print("[picker] pick_file_by_intent called with:", spec)

    """
    Intent-driven picker router.

    spec example:
    {
        "intent": "template" | "data" | "output",
        "scope":  "local" | "remote",
        "allowed_exts": [".xml", ".json"] | None
    }
    """

    intent = spec.get("intent")
    if intent is None:
        return {"success": False, "error": "Missing intent"}
    scope = spec.get("scope", "local")
    allowed_exts = spec.get("allowed_exts")

    # ------------------------------------------------------------
    # Remote creds gate (authoritative)
    # ------------------------------------------------------------
    if scope == "remote":
        creds = load_creds(intent)
        if not has_valid_creds(creds):
            return {
                "success": False,
                "needs_creds": True,
                "intent": intent,
            }

    # ====================================================
    # REMOTE
    # ====================================================
    if scope == "remote":
        from .resolvers.remote_fs import pick_remote_by_intent

        return pick_remote_by_intent(
            intent=intent,
            spec=spec,
            allowed_exts=allowed_exts,
        )

    # ====================================================
    # LOCAL
    # ====================================================
    if scope != "local":
        return {"success": False, "error": "Unknown picker scope"}

    if intent == "template":
        return pick_template_local(allowed_exts=allowed_exts)

    if intent == "data":
        return pick_data_file_local(allowed_exts=allowed_exts)

    if intent == "output":
        return pick_output_dir_local()

    return {"success": False, "error": f"Unknown picker intent: {intent}"}
