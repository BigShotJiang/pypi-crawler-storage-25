#!/usr/bin/env python3

import sys
import webview
import argparse
from pathlib import Path

from suite_core.instance_manager import bootstrap_instance
from suite_core.safehouse import ensure_safehouse, purge_tmp
from suite_bridge.api import SuiteAPI


# ----------------------------
# UI paths
# ----------------------------
def resource_path(relative: Path) -> Path:
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / relative

    pip_data_path = Path(sys.prefix) / relative
    if pip_data_path.exists():
        return pip_data_path

    return (BASE_DIR / relative).resolve()


def main():
    # ---------------------------------------------------------
    # BOOTSTRAP — must run before any safehouse or crypto access
    # ---------------------------------------------------------
    bootstrap_instance()

    # ---------------------------------------------------------
    # SAFEHOUSE — now safe to access (instance path is set)
    # ---------------------------------------------------------
    purge_tmp(reason="app_launch")
    ensure_safehouse()

    # ----------------------------
    # CLI args
    # ----------------------------
    parser = argparse.ArgumentParser()
    parser.add_argument("--dev", action="store_true", help="Enable dev tools")
    args = parser.parse_args()

    DEBUG_MODE = args.dev

    # ---------------------------------------------------------
    # API (stateful)
    # ---------------------------------------------------------
    api = SuiteAPI()

    # ---------------------------------------------------------
    # DIAGNOSTICS — API VISIBILITY (TEMP)
    # ---------------------------------------------------------
    print("[diag] api object:", api)
    print("[diag] api public methods:", [m for m in dir(api) if not m.startswith("_")])

    # ----------------------------
    # CREATE WINDOW
    # ----------------------------
    window = webview.create_window(
        "CyberSuite1.0.1",
        url="file://" + str(resource_path(Path("ui/html/index.html"))),
        width=1200,
        height=880,
        js_api=api,
    )

    # ----------------------------
    # START
    # ----------------------------
    webview.start(gui="gtk", debug=DEBUG_MODE, http_server=True)


if __name__ == "__main__":
    main()
