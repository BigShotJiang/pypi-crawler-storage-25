#!/usr/bin/env python3
"""
========================================================
CyberMapper — Core Engine (v1)
========================================================
Responsibilities:
- Scan a target directory
- Apply inclusion filter (extensions only)
- Return structured map data

Forbidden knowledge:
- UI
- pickers
- confirmations
- creds UX
========================================================
"""

import os
import time
import json
from pathlib import Path
from suite_core.logging import log_cli
from suite_core.safehouse import get_common_policy_dir

DEFAULT_FILTER = {"include_extensions": [".html", ".htm", ".php", ".xhtml", ".txt"]}


# ----------------------------------------------------
# LOAD INCLUSION FILTER
# ----------------------------------------------------
def load_inclusion_filter():
    filter_path = get_common_policy_dir() / "inclusion_filter.json"
    if filter_path.exists():
        try:
            with open(filter_path, "r") as f:
                data = json.load(f)
            return data.get("include_extensions", [])
        except Exception as e:
            log_cli(f"[WARN] Invalid inclusion_filter.json — using defaults ({e})")
    return DEFAULT_FILTER["include_extensions"]


# ----------------------------------------------------
# LOCAL DIRECTORY SCAN
# ----------------------------------------------------
def scan_directory_local(target_dir: str):
    target = Path(target_dir)

    if not target.exists() or not target.is_dir():
        raise FileNotFoundError(f"Invalid target directory: {target_dir}")

    include_exts = load_inclusion_filter()
    results = []

    for root, _, files in os.walk(target):
        for name in files:
            if not any(name.lower().endswith(ext) for ext in include_exts):
                continue

            full_path = Path(root) / name
            rel_path = full_path.relative_to(target)

            results.append({"path": str(rel_path), "title": "", "meta_desc": ""})

    return sorted(results, key=lambda x: x["path"])


# ----------------------------------------------------
# PUBLIC ENTRY POINT
# ----------------------------------------------------
def generate_map(target_dir: str):
    t0 = time.time()

    files = scan_directory_local(target_dir)
    elapsed = round(time.time() - t0, 3)

    return {
        "meta": {
            "scanned_root": str(Path(target_dir).resolve()),
            "mode": "local",
            "file_count": len(files),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "elapsed": elapsed,
        },
        "files": files,
    }


# ----------------------------------------------------
# CLI TEST HARNESS
# ----------------------------------------------------
if __name__ == "__main__":
    import sys
    import pprint

    if len(sys.argv) != 2:
        print("Usage: python3 map_core.py <target_dir>")
        sys.exit(1)

    pprint.pprint(generate_map(sys.argv[1]))
