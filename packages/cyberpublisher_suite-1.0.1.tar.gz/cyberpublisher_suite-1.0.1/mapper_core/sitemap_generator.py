#!/usr/bin/env python3
"""
========================================================
CyberSuite — Sitemap Generator (Mapper)
========================================================
Generates sitemap.xml body from mapper_index.json payload.

Rules:
- Emits ONLY <loc> and <lastmod>
- Includes ONLY: .html, .htm, .php
- No XML declaration
- No timestamp block
- No robots parsing
- No filesystem access
- No crawling
- PURE generator (no side effects)
========================================================
"""

from xml.etree.ElementTree import Element, SubElement, tostring

VALID_EXTS = (".html", ".htm", ".php")


def generate_sitemap(map_index: dict, base_url: str) -> str:
    """
    Generate sitemap XML BODY (no header, no stamp).

    Args:
        map_index (dict): Parsed mapper_index.json payload
        base_url (str): Site base URL (e.g. https://example.com)

    Returns:
        str: <urlset> XML string only
    """

    # ------------------------------------------------
    # Normalize inputs
    # ------------------------------------------------
    base_url = (base_url or "").rstrip("/")

    mapper_run = map_index.get("mapper_run", {})
    date = mapper_run.get("date")

    # ------------------------------------------------
    # XML root (namespace REQUIRED)
    # ------------------------------------------------
    urlset = Element(
        "urlset",
        attrib={"xmlns": "http://www.sitemaps.org/schemas/sitemap/0.9"},
    )

    # ------------------------------------------------
    # URL entries
    # ------------------------------------------------
    for node in map_index.get("nodes", []):
        rel_path = (node.get("path") or ".").strip("/")

        for f in node.get("files", []):
            ext = (f.get("ext") or "").lower()
            if ext not in VALID_EXTS:
                continue

            url_el = SubElement(urlset, "url")

            if rel_path in ("", "."):
                loc_text = f"{base_url}/{f['name']}"
            else:
                loc_text = f"{base_url}/{rel_path}/{f['name']}"

            loc = SubElement(url_el, "loc")
            loc.text = loc_text.strip()

            lastmod = SubElement(url_el, "lastmod")
            lastmod.text = date

    # Return only the body — stamping handled upstream
    return tostring(urlset, encoding="unicode")
