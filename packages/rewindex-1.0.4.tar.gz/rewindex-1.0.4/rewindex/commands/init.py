# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import click
import questionary

from rewindex.config.defaults import REWINDEX_DIR, SNAPSHOTS_DIR
from rewindex.config.loader import config_exists, save_config, load_config
from rewindex.daemon.runner import restart_daemon


@click.command()
@click.option("--project", default=None, help="Project name.")
@click.option("--folder", default=None, help="Folder to watch.")
@click.option("--license", "license_key", default=None, help="Pro license key (validates immediately).")
def init_cmd(project: str | None, folder: str | None, license_key: str | None) -> None:
    """Initialize a project and start the daemon.

    \b
    rewindex init                                        interactive wizard
    rewindex init --project <name> --folder <path>       non-interactive
    rewindex init --project <name> --folder <path> --license <key>

    Run once per project. Safe to re-run — merges with existing config.
    """
    non_interactive = project is not None and folder is not None

    if non_interactive:
        _run_init(project, os.path.expanduser(folder), interactive=False, license_key=license_key)
    else:
        _interactive_init()


def _interactive_init() -> None:
    from rewindex.ui.welcome import show_logo
    show_logo()

    project = questionary.text("What is your project name?").ask()
    if not project:
        click.echo("Setup cancelled.")
        return

    folder = questionary.path("Which folder would you like to watch? (file path)").ask()
    if not folder:
        click.echo("Setup cancelled.")
        return

    _run_init(project.strip(), os.path.expanduser(folder.strip()), interactive=True)


def _activate_license(license_key: str) -> None:
    from rewindex.license import activate_license
    from rewindex.config.urls import LINK_SUBSCRIPTION
    try:
        activate_license(license_key)
        click.echo("\nLicense activated — Pro plan.")
    except ConnectionError:
        click.echo("Warning: could not validate license (offline). Will retry later.")
    except ValueError:
        click.echo(f"Warning: license key is not valid. Continuing as Free tier.")
        click.echo(f"Update later with: rewindex member --license [key]")


def _offer_license() -> None:
    from rewindex.config.urls import LINK_PRICING
    click.echo("")
    confirm = questionary.confirm("Do you have a Pro license key?", default=False).ask()
    if not confirm:
        click.echo(f"\nSkipping — Free tier activated.")
        click.echo(f"\nUpgrade anytime: {LINK_PRICING}")
        return
    key = questionary.text("Enter license key:").ask()
    if key and key.strip():
        _activate_license(key.strip())
    else:
        click.echo("Skipping — Free tier activated.")


def _install_autostart_silent() -> None:
    """Install autostart without prompting — used in non-interactive mode."""
    import platform
    try:
        system = platform.system()
        if system == "Darwin":
            from rewindex.autostart.macos import install
        elif system == "Linux":
            from rewindex.autostart.linux import install
        else:
            return
        install()
        click.echo("Autostart registered.")
    except Exception as e:
        click.echo(f"Autostart setup failed: {e}")


def _offer_autostart() -> None:
    import platform
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text

    console = Console()
    content = Text()
    content.append("Y", style="bold bright_green")
    content.append("  →  ", style="dim")
    content.append("Rewindex boots with your machine  ", style="white")
    content.append("(recommended)\n", style="bold bright_green")
    content.append("N", style="bold yellow")
    content.append("  →  ", style="dim")
    content.append("run ", style="white")
    content.append("'rewindex start'", style="bold white")
    content.append(" manually after every reboot", style="white")

    console.print()
    console.print(Panel(
        content,
        title="[bold cyan]Autostart[/bold cyan]",
        border_style="cyan",
        padding=(1, 2),
    ))
    console.print()

    confirm = questionary.confirm(
        "Start Rewindex automatically on login?",
        default=True,
    ).ask()
    if not confirm:
        return
    try:
        system = platform.system()
        if system == "Darwin":
            from rewindex.autostart.macos import install
        elif system == "Linux":
            from rewindex.autostart.linux import install
        else:
            click.echo("Autostart not supported on this platform.")
            return
        install()
        click.echo("Autostart registered.")
    except Exception as e:
        click.echo(f"Autostart setup failed: {e}")


def _run_init(project: str, folder: str, interactive: bool, license_key: str | None = None) -> None:
    if not os.path.isdir(folder):
        click.echo(f"Error: folder does not exist: {folder}")
        return

    # Load existing config or start fresh
    if config_exists():
        config = load_config()
    else:
        from rewindex.config.defaults import DEFAULT_CONFIG
        import copy
        config = copy.deepcopy(DEFAULT_CONFIG)

    from rewindex.utils.validation import validate_project_name
    try:
        validate_project_name(project)
    except ValueError as e:
        click.echo(f"Error: {e}")
        return

    # Block duplicate folder — prevent two projects watching the same directory.
    # Uses inode+device comparison to catch bind mounts and other path aliases.
    from rewindex.utils.validation import same_folder
    for p in config.get("projects", []):
        if p["name"] == project:
            continue  # same project updating its own folder is fine
        existing_folder = os.path.expanduser(p["folders"][0])
        if same_folder(folder, existing_folder):
            click.echo(
                f"Error: folder '{folder}' is already watched by project '{p['name']}'. "
                f"Each folder can only belong to one project."
            )
            return

    # Add project if not already present
    existing_names = [p["name"] for p in config.get("projects", [])]
    if project not in existing_names:
        from rewindex.license import is_pro
        from rewindex.config.defaults import FREE_MAX_PROJECTS
        if not is_pro() and len(config["projects"]) >= FREE_MAX_PROJECTS:
            from rewindex.config.urls import LINK_SUBSCRIPTION
            click.echo(f"\nError: Free tier supports {FREE_MAX_PROJECTS} project.")
            click.echo(f"Remove existing project first, or upgrade to Pro: {LINK_SUBSCRIPTION}")
            return
        config["projects"].append({"name": project, "folders": [folder]})
    else:
        for p in config["projects"]:
            if p["name"] == project:
                p.pop("folder", None)
                folders = p.get("folders", [])
                if folder not in folders:
                    folders.append(folder)
                p["folders"] = folders

    try:
        os.makedirs(REWINDEX_DIR, exist_ok=True)
        os.chmod(REWINDEX_DIR, 0o700)
    except PermissionError:
        click.echo(
            f"Error: no write permission to {REWINDEX_DIR}\n"
            "Check folder permissions and try again."
        )
        return

    try:
        os.makedirs(os.path.join(SNAPSHOTS_DIR, project), exist_ok=True)
        save_config(config)
    except PermissionError:
        click.echo(
            f"Error: no write permission to {SNAPSHOTS_DIR}\n"
            "Check folder permissions and try again."
        )
        return

    from rewindex.version import init_rewindex_json
    init_rewindex_json()

    # Activate license if provided
    if license_key:
        _activate_license(license_key)
    elif interactive:
        _offer_license()
    else:
        click.echo("\nSkipping — Free tier activated.")

    if interactive:
        _offer_autostart()
        from rewindex.ui.welcome import show_welcome
        show_welcome(project)
    else:
        _install_autostart_silent()

    # Start daemon
    click.echo(f"\nDaemon started. Watching: {folder}")
    click.echo(f"Project: {project}")
    click.echo()
    restart_daemon(config)
