# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import click

from rewindex.config.validator import ConfigState, auto_restore_if_needed, check_config


class _PaddedGroup(click.Group):
    def get_help(self, ctx: click.Context) -> str:
        return "\n" + super().get_help(ctx) + "\n"

    def format_help(self, ctx, formatter):
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_commands(ctx, formatter)
        formatter.write(
            "\nOptions:\n"
            "  -p <name|PJ1>   Target a specific project\n"
            "                  Auto-detected from CWD if omitted\n"
            "\nExamples:\n"
            "  rewindex log -p MyProject\n"
            '  rewindex snap -p PJ1 "checkpoint"\n'
            "  rewindex rewind SS3 --yes -p MyProject\n"
        )
        self.format_epilog(ctx, formatter)

_SETUP_EXEMPT = {"init", "_run", "uninstall"}


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("rewindex")
    except Exception:
        from rewindex.version import _DEFAULT
        return _DEFAULT.get("rewindex_version", "?")


def _show_get_started() -> None:
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text

    console = Console()
    content = Text()
    content.append("Get started in 2 steps:\n\n", style="bold white")
    content.append("  1. ", style="dim")
    content.append("Set up your first project:\n", style="white")
    content.append("     rewindex init\n\n", style="bold cyan")
    content.append("  2. ", style="dim")
    content.append("That's it — Rewindex starts watching automatically.\n\n", style="white")
    content.append("Run ", style="dim")
    content.append("rewindex --help", style="bold cyan")
    content.append(" for all commands.", style="dim")

    console.print()
    console.print(Panel(
        content,
        title="[bold bright_green]Welcome to Rewindex[/bold bright_green]",
        border_style="cyan",
        padding=(1, 2),
    ))
    console.print()


@click.group(name="rewindex", cls=_PaddedGroup, invoke_without_command=True, context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(_get_version(), "-v", "--version", prog_name="rewindex")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """File snapshot tool — every change saved, every mistake undone.

    \b
    ── SETUP ─────────────────────────────────────────────
      init               Initialize a project and start the daemon
      start / stop       Start or stop the daemon
      restart            Restart the daemon
      status             Show daemon status and active projects

    \b
    ── HISTORY ───────────────────────────────────────────
      log                List sessions
      log sn             Flat list of all snapshots
      log <FileID>       Show version history for a specific file
      log <SS>           Show full project state at a session
      diff <FileID>      Show diff between file versions

    \b
    ── SNAPSHOT ──────────────────────────────────────────
      snap               Snap all changed files into a session
      snap "message"     Snap with a session note

    \b
    ── REWIND ────────────────────────────────────────────
      rewind <SS> --yes          Restore entire project to session state
      rewind <FileID> <v> --yes  Restore one file to a specific version
      rewind SN -<n> --yes       Rewind back N snapshots (all affected files)

    \b
    ── ANNOTATE ──────────────────────────────────────────
      note <FileID> [v] "msg"    Annotate a file version
      note SS [id|latest] "msg"  Annotate a session
      note <SN> "msg"            Annotate a snap

    \b
    ── PROJECT ───────────────────────────────────────────
      project                    List all projects
      project add <name> <path>  Add a project
      project remove / rename
      project add-folder / remove-folder
      project exclude add / remove

    \b
    ── SETTINGS ──────────────────────────────────────────
      member                     Show plan / activate license
      setting                    Show or update session limits
      setting precompute on|off  Toggle pre-compute fullbase (Pro)

    \b
    ── MAINTENANCE ───────────────────────────────────────
      update                     Update Rewindex
      cleanup --trash            Manage trashed projects
      uninstall                  Uninstall Rewindex

    \b
    ── IDs ───────────────────────────────────────────────
      SS3      Session     — a group of snaps
      SN42     Snap        — a single file at a point in time
      D1VS     FileID      — stable 4-char file identifier
      v3       Version     — file version number
      PJ1      Project     — a watched folder

    \b
    ── META ──────────────────────────────────────────────
      -v, --version   Show version and exit
      -h, --help      Show this message and exit
    \b
    """
    ctx.ensure_object(dict)
    command = ctx.invoked_subcommand

    if command is None:
        state = check_config()
        if state == ConfigState.MISSING:
            _show_get_started()
        else:
            click.echo(ctx.get_help())
        return

    if command in _SETUP_EXEMPT:
        return

    restored, message = auto_restore_if_needed()
    state = check_config()

    if restored:
        click.echo(f"[rewindex] {message}")

    if state in (ConfigState.MISSING, ConfigState.CORRUPTED_NO_BACKUP):
        click.echo(f"[rewindex] {message}")
        ctx.exit(1)

    click.echo()


@cli.result_callback()
def _after_command(*args, **kwargs) -> None:
    click.echo()


@click.command(hidden=True)
def _run_cmd() -> None:
    """Internal: background daemon process entry point."""
    from rewindex.daemon.runner import run_daemon_process
    run_daemon_process()


def main() -> None:
    from rewindex.commands.init import init_cmd
    from rewindex.commands.start import start_cmd
    from rewindex.commands.stop import stop_cmd
    from rewindex.commands.restart import restart_cmd
    from rewindex.commands.status import status_cmd
    from rewindex.commands.snap import snap_cmd
    from rewindex.commands.log import log_cmd
    from rewindex.commands.diff import diff_cmd
    from rewindex.commands.rewind import rewind_cmd
    from rewindex.commands.project import project_cmd
    from rewindex.commands.update import update_cmd
    from rewindex.commands.note import note_cmd
    from rewindex.commands.uninstall import uninstall_cmd
    from rewindex.commands.member import member_cmd
    from rewindex.commands.setting import setting_cmd
    from rewindex.commands.cleanup import cleanup_cmd

    cli.add_command(init_cmd, "init")
    cli.add_command(start_cmd, "start")
    cli.add_command(stop_cmd, "stop")
    cli.add_command(restart_cmd, "restart")
    cli.add_command(status_cmd, "status")
    cli.add_command(snap_cmd, "snap")
    cli.add_command(log_cmd, "log")
    cli.add_command(diff_cmd, "diff")
    cli.add_command(rewind_cmd, "rewind")
    cli.add_command(project_cmd, "project")
    cli.add_command(update_cmd, "update")
    cli.add_command(note_cmd, "note")
    cli.add_command(uninstall_cmd, "uninstall")
    cli.add_command(member_cmd, "member")
    cli.add_command(setting_cmd, "setting")
    cli.add_command(cleanup_cmd, "cleanup")
    cli.add_command(_run_cmd, "_run")

    cli()
