# Re-export all public APIs to maintain backward compatibility
# Usage: from adam_community.util import execCmd, runCmd, ...

from .config import (
    ADAM_API_HOST,
    ADAM_API_TOKEN,
    ADAM_TASK_ID,
    ADAM_USER_ID,
    CONDA_ENV,
    ADAM_TASK_DIR,
)

from .cmd import (
    runCmd,
    execCmd,
    CmdResult,
)

from .api import (
    retry_on_exception,
    _make_http_request,
    messageSend,
    completionCreate,
    DynamicObject,
)

from .rag import (
    RAG,
    knowledgeSearch,
)

from .state import (
    _StatesManager,
    setState,
    getState,
    trackPath,
)

from .markdown import (
    markdown_color,
    markdown_terminal,
)

__all__ = [
    # config
    'ADAM_API_HOST',
    'ADAM_API_TOKEN',
    'ADAM_TASK_ID',
    'ADAM_USER_ID',
    'CONDA_ENV',
    'ADAM_TASK_DIR',
    # cmd
    'runCmd',
    'execCmd',
    'CmdResult',
    # api
    'retry_on_exception',
    '_make_http_request',
    'messageSend',
    'completionCreate',
    'DynamicObject',
    # rag
    'RAG',
    'knowledgeSearch',
    # state
    '_StatesManager',
    'setState',
    'getState',
    'trackPath',
    # markdown
    'markdown_color',
    'markdown_terminal',
]
