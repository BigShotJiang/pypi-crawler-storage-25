import os

ADAM_API_HOST = os.getenv('ADAM_API_HOST', 'https://sidereus-ai.com')
ADAM_API_TOKEN = os.getenv('ADAM_API_TOKEN')
ADAM_TASK_ID = os.getenv('ADAM_TASK_ID')
ADAM_USER_ID = os.getenv('ADAM_USER_ID')
CONDA_ENV = os.getenv('CONDA_ENV')
ADAM_TASK_DIR = os.getenv('ADAM_TASK_DIR')
