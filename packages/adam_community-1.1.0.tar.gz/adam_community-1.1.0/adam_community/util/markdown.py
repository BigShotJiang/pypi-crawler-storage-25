def markdown_color(content, color):
    return f'<span style="color: {color}">{content}</span>'


def markdown_terminal(content, conda_env="base", user="Adam", workdir=""):
    user = markdown_color(f"{user}@Adam", "green")
    workdir = markdown_color(f":~/{workdir}", "blue")
    return f'({conda_env}) {user}{workdir}$ {content}'
