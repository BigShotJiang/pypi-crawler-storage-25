"""Mathematical utilities for Trilobite."""
