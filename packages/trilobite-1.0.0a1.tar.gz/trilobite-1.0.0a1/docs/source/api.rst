.. image:: ./images/logo.svg
   :width: 200px
   :align: center

.. _api:

API
===

This page provides the complete reference for all public classes, functions, and modules in the Trilobite codebase.

Trilobite is modular by design, and its API is organized into several key modules.
Below is an overview of the main modules available:

Trilobite Models
------------------
The most relevant modules for typical users working with Trilobite is the set of model implementations. These
are all located in the :mod:`models` subpackage and include various forward models of radio emission
in different scenarios. These models can be used to simulate observations, fit data, and perform inference.

.. autosummary::
    :toctree: _as_gen
    :recursive:
    :template: module.rst

    trilobite.models.core
    trilobite.models.generic
    trilobite.models.SEDs
    trilobite.models.GRBs
    trilobite.models.supernovae

Data Modules
------------
The data modules provide classes and functions for handling observational data, including loading, processing,
and visualizing data sets.

.. autosummary::
    :toctree: _as_gen
    :recursive:
    :template: module.rst

    trilobite.data.core
    trilobite.data.light_curve
    trilobite.data.photometry
    trilobite.data.optical_photometry

Inference Modules
-----------------

The inference modules contain tools and algorithms for fitting models to observational data, performing parameter
estimation, and conducting statistical analysis.

.. autosummary::
    :toctree: _as_gen
    :recursive:
    :template: module.rst

    trilobite.inference.prior
    trilobite.inference.likelihood
    trilobite.inference.sampling
    trilobite.inference.problem



Physics and Computation Modules
-------------------------------
Underlying all of the models and inference pipelines in Trilobite are a set of physics and computation modules.
These modules implement the core algorithms for simulating plasma dynamics, radiation processes, and numerical methods.

Physics
^^^^^^^
The physics modules implement the core physical processes modeled in Trilobite, including shock dynamics,
radiation mechanisms, and ejecta evolution.

.. autosummary::
    :toctree: _as_gen
    :recursive:
    :template: module.rst

    trilobite.radiation
    trilobite.dynamics

Computation
^^^^^^^^^^^
The computation modules provide the numerical methods and algorithms used throughout Trilobite. This includes solvers
for differential equations, interpolation routines, and data handling utilities.

.. autosummary::
    :toctree: _as_gen
    :recursive:
    :template: module.rst

    trilobite.parallel

Utilities
---------
The utilities modules contain helper functions and classes that support the main functionality of Trilobite.
These include data I/O, configuration management, and common mathematical operations.

.. autosummary::
    :toctree: _as_gen
    :recursive:
    :template: module.rst

    trilobite.utils.plot_utils
    trilobite.utils.io_utils
    trilobite.utils.log
    trilobite.utils.config
    trilobite.utils.misc_utils
    trilobite.utils.phot_utils
    trilobite.physics_utils
    trilobite.math_utils
