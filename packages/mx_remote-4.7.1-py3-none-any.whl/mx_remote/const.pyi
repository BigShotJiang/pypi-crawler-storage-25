from _typeshed import Incomplete

VERSION: str
__version__ = VERSION
MX_BCAST_UDP_PORT: int
MX_MCAST_UDP_IP: str
MX_MCAST_UDP_PORT: int
BASE_PATH: Incomplete
