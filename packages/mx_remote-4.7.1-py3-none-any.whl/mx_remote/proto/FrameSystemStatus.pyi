from .FrameBase import FrameBase as FrameBase
from typing import override

class FrameSystemStatus(FrameBase):
    @override
    def process(self) -> None: ...
    @property
    def status(self) -> int | None: ...
    @property
    def message(self) -> str | None: ...
