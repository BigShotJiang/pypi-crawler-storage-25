from ..Interface import V2IPStreamSourcesList as V2IPStreamSourcesList
from .FrameBase import FrameBase as FrameBase
from .V2IPConfig import V2IPConfig as V2IPConfig, V2IPStreamSourcesImpl as V2IPStreamSourcesImpl
from functools import cached_property

class FrameV2IPSources(FrameBase):
    @property
    def nb_sources(self) -> int: ...
    @cached_property
    def sources(self) -> V2IPStreamSourcesList: ...
    def process(self) -> None: ...
