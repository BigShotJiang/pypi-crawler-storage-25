from ..Interface import SystemTemperature as SystemTemperature
from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameSysTemperature(FrameBase):
    @cached_property
    def nb_sensors(self) -> int | None: ...
    @cached_property
    def temperature(self) -> SystemTemperature: ...
    def process(self) -> None: ...
