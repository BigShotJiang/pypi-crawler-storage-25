from ..Interface import BayBase as BayBase
from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameRCIr(FrameBase):
    @cached_property
    def bay(self) -> BayBase | None: ...
    @cached_property
    def timestamp(self) -> int | None: ...
