from ..Interface import BayBase as BayBase
from .FrameBase import FrameBase as FrameBase
from .FrameHeader import FrameHeader as FrameHeader
from functools import cached_property

class FrameVolumeUp(FrameBase):
    @cached_property
    def bay(self) -> BayBase | None: ...
    def process(self) -> None: ...
