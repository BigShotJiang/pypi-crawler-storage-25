from .FrameBase import FrameBase as FrameBase
from .LinkConfig import LinkConfig as LinkConfig
from functools import cached_property

class FrameLinks(FrameBase):
    @cached_property
    def nb_links(self) -> int: ...
    @cached_property
    def links(self) -> list[LinkConfig]: ...
    def process(self) -> None: ...
