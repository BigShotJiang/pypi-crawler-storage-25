from ..Interface import BayBase as BayBase
from .Constants import RCKey as RCKey
from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameRCKey(FrameBase):
    @cached_property
    def bay(self) -> BayBase | None: ...
    @cached_property
    def key(self) -> RCKey | None: ...
    def process(self) -> None: ...
