from .BayConfig import BayConfig as BayConfig
from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameBayConfigSecondary(FrameBase):
    @cached_property
    def nb_bays(self) -> int: ...
    @cached_property
    def bays(self) -> list[BayConfig]: ...
    def process(self) -> None: ...
