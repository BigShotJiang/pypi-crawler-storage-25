from ..Interface import FilteredDevices as FilteredDevices
from ..Uid import MxrDeviceUid as MxrDeviceUid
from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameFilterStatus(FrameBase):
    @cached_property
    def filtered(self) -> FilteredDevices: ...
    @cached_property
    def target_uid(self) -> MxrDeviceUid | None: ...
    def process(self) -> None: ...
