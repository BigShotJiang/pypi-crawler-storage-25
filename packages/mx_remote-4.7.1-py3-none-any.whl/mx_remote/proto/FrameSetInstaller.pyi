from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameSetInstaller(FrameBase):
    @cached_property
    def installer_id(self) -> int | None: ...
