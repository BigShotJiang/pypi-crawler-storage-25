from ..Interface import BayBase as BayBase, DeviceRegistry as DeviceRegistry
from .FrameBase import FrameBase as FrameBase

class FrameSetName(FrameBase):
    @staticmethod
    def construct(mxr: DeviceRegistry, target: BayBase, name: str) -> FrameBase | None: ...
