##################################################
##         MX Remote Python Interface           ##
##                                              ##
## author: Lars Op den Kamp (lars@opdenkamp.eu) ##
## copyright (c) 2026 Op den Kamp IT Solutions  ##
##################################################
'''Protocol frame for system temperature sensor readings.'''

from functools import cached_property
from .FrameBase import FrameBase
from ..Interface import SystemTemperature

class FrameSysTemperature(FrameBase):
    '''System temperature frame, sent periodically by devices on the network.'''
    @cached_property
    def nb_sensors(self) -> int|None:
        '''Number of temperature sensor readings in this frame.'''
        return self.payload_u8(0)

    @cached_property
    def temperature(self) -> SystemTemperature:
        '''List of all temperature readings in this frame.'''
        rv = SystemTemperature([])
        ptr = 0
        if (self.nb_sensors is None):
            return rv
        while ptr < self.nb_sensors:
            ptr = ptr + 1
            pl = self.payload_u8(ptr)
            if (pl is not None):
                rv.append(pl)
        return rv

    def process(self) -> None:
        '''Update the local device cache with temperature readings.'''
        if ((dev := self.remote_device) is not None):
            dev.on_mxr_update(self.temperature)

    def __str__(self) -> str:
        return "temperature: {}".format(str(self.temperature))

