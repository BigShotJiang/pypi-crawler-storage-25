from ..Interface import DeviceBase as DeviceBase, DeviceRegistry as DeviceRegistry, MxrDeviceUid as MxrDeviceUid
from .FrameBase import FrameBase as FrameBase
from enum import IntEnum
from functools import cached_property

class MeshOperation(IntEnum):
    REGISTER: int
    UNREGISTER: int
    REPLACE: int
    REGENERATE_ADDRESSES: int
    REPORT_CONTROLLER: int
    PROMOTE_CONTROLLER: int
    REPORT_MEMBERSHIP: int

class FrameMeshOperation(FrameBase):
    @staticmethod
    def construct(mxr: DeviceRegistry, operation: MeshOperation, target: DeviceBase, option: DeviceBase | None = None) -> FrameBase | None: ...
    @cached_property
    def operation(self) -> MeshOperation | None: ...
    @cached_property
    def target_uid(self) -> MxrDeviceUid | None: ...
    @cached_property
    def parameter(self) -> MxrDeviceUid | None: ...
    def process(self) -> None: ...
