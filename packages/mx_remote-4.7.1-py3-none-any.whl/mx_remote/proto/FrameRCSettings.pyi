from .FrameBase import FrameBase as FrameBase

class FrameRCSettings(FrameBase):
    def process(self) -> None: ...
