from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameEDID(FrameBase):
    @cached_property
    def port(self) -> str | None: ...
