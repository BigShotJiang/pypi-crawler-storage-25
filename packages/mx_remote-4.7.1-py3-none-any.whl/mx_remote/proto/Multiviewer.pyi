from ..Uid import MxrDeviceUid as MxrDeviceUid
from _typeshed import Incomplete
from abc import ABC, abstractmethod
from enum import IntEnum

class MultiviewerOpcode(IntEnum):
    STATUS: int
    VIEW_MODE: int
    VIDEO_SOURCE: int
    AUDIO_SOURCE: int
    AUDIO_VOLUME: int
    EDID_TEMPLATE: int
    ROUTE_RC: int
    PIP_SIZE: int
    PIP_POSITION: int
    ASPECT: int
    AUTO_SWITCH: int
    OUTPUT_MODE: int
    OUTPUT_ITC_MODE: int
    HDCP_MODE: int
    CONFIG_SOURCE: int
    AUTO_ROUTE: int
    UNKNOWN: int

class MultiviewerViewMode(IntEnum):
    UNKNOWN: int
    SINGLE: int
    PIP: int
    TWO_SCREEN_LARGE: int
    TWO_SCREEN_SMALL: int
    THREE_SCREEN_LARGE: int
    THREE_SCREEN_SMALL: int
    FOUR_SCREEN_LARGE: int
    FOUR_SCREEN_SMALL: int

class MultiviewerPipPosition(IntEnum):
    UNKNOWN: int
    LEFT_TOP: int
    LEFT_BOTTOM: int
    RIGHT_TOP: int
    RIGHT_BOTTOM: int

class MultiviewerPipSize(IntEnum):
    UNKNOWN: int
    SMALL: int
    MEDIUM: int
    LARGE: int

class MultiviewerOutputMode(IntEnum):
    UNKNOWN: int
    OUT_4096x2160P60: int
    OUT_4096x2160P50: int
    OUT_3840x2160P60: int
    OUT_3840x2160P50: int
    OUT_3840x2160P30: int
    OUT_3840x2160P25: int
    OUT_1920x1200P60RB: int
    OUT_1920x1080P60: int
    OUT_1920x1080P50: int
    OUT_1360x768P60: int
    OUT_1280x800P60: int
    OUT_1280x720P60: int
    OUT_1280x720P50: int
    OUT_1024x768P60: int

class MultiviewerHDCPMode(IntEnum):
    UNKNOWN: int
    V1_4: int
    V2_2: int

class MultiviewerITCMode(IntEnum):
    UNKNOWN: int
    VIDEO: int
    PC: int

class MultiviewerEDIDTemplate(IntEnum):
    UNKNOWN: int
    EDID_4K60_STEREO: int
    EDID_4K60_51: int
    EDID_4K60_71: int
    EDID_4K30_STEREO: int
    EDID_4K30_51: int
    EDID_4K30_71: int
    EDID_1080P_STEREO: int
    EDID_1080P_51: int
    EDID_1080P_71: int
    EDID_1920x1200: int
    EDID_1680x1050: int
    EDID_1600x1200: int
    EDID_1440x900: int
    EDID_1360x768: int
    EDID_1280x1024: int
    EDID_1024x768: int
    EDID_720P: int
    EDID_COPY_OUTPUT: int
    EDID_CUSTOM: int

class MultiviewerAspectRatio(IntEnum):
    UNKNOWN: int
    ASPECT_FULL: int
    ASPECT_16_9: int

class MultiviewerBoolSetting(IntEnum):
    UNKNOWN: int
    OFF: int
    ON: int

class MultiviewerSource(IntEnum):
    UNKNOWN: int
    SOURCE_1: int
    SOURCE_2: int
    SOURCE_3: int
    SOURCE_4: int

class MultiviewerConfig(ABC):
    @property
    @abstractmethod
    def uid(self) -> MxrDeviceUid | None: ...
    @abstractmethod
    def mapping(self, idx: int) -> MxrDeviceUid | None: ...
    @property
    @abstractmethod
    def mappings(self) -> list[MxrDeviceUid | None]: ...
    @property
    @abstractmethod
    def mcu_version(self) -> str | None: ...
    @property
    @abstractmethod
    def scaler_version(self) -> str | None: ...
    @property
    @abstractmethod
    def hw_view_mode(self) -> int | None: ...
    @property
    @abstractmethod
    def view_mode(self) -> MultiviewerViewMode: ...
    @property
    @abstractmethod
    def pip_position(self) -> MultiviewerPipPosition: ...
    @property
    @abstractmethod
    def pip_size(self) -> MultiviewerPipSize: ...
    @property
    @abstractmethod
    def output_mode(self) -> MultiviewerOutputMode: ...
    @property
    @abstractmethod
    def hdcp_mode(self) -> MultiviewerHDCPMode: ...
    @property
    @abstractmethod
    def output_itc_mode(self) -> MultiviewerITCMode: ...
    @property
    @abstractmethod
    def edid_template(self) -> MultiviewerEDIDTemplate: ...
    @property
    @abstractmethod
    def aspect_ratio(self) -> MultiviewerAspectRatio: ...
    @property
    @abstractmethod
    def auto_switch(self) -> MultiviewerBoolSetting: ...
    @property
    @abstractmethod
    def audio_source(self) -> MultiviewerSource: ...
    @property
    @abstractmethod
    def audio_volume(self) -> int: ...
    @property
    @abstractmethod
    def audio_muted(self) -> MultiviewerBoolSetting: ...
    @abstractmethod
    def video_source(self, screen: int) -> MultiviewerSource: ...
    @property
    @abstractmethod
    def remote_control(self) -> MultiviewerSource: ...

class MultiviewerScreenMode(IntEnum):
    UNKNOWN: int
    MODE_1: int
    MODE_2: int

class MultiviewerHWViewMode(IntEnum):
    UNKNOWN: int
    SINGLE: int
    PIP: int
    TWO: int
    THREE: int
    FOUR: int

class MultiviewerConfigData:
    hw_view_mode: Incomplete
    view_mode: Incomplete
    pip_position: Incomplete
    pip_size: Incomplete
    output_mode: Incomplete
    hdcp_mode: Incomplete
    output_itc_mode: Incomplete
    edid_template: Incomplete
    screen_mode: Incomplete
    screen_aspect: Incomplete
    auto_switch: Incomplete
    audio_source: Incomplete
    volume: Incomplete
    muted: Incomplete
    video_sources: Incomplete
    rc_route: Incomplete
    def __init__(self, *, hw_view_mode: MultiviewerHWViewMode = ..., view_mode: MultiviewerViewMode = ..., pip_position: MultiviewerPipPosition = ..., pip_size: MultiviewerPipSize = ..., output_mode: MultiviewerOutputMode = ..., hdcp_mode: MultiviewerHDCPMode = ..., output_itc_mode: MultiviewerITCMode = ..., edid_template: MultiviewerEDIDTemplate = ..., screen_mode: MultiviewerScreenMode = ..., screen_aspect: MultiviewerAspectRatio = ..., auto_switch: bool = False, audio_source: int = 0, volume: int = 50, muted: bool = False, video_sources: tuple[int, int, int, int] = (0, 1, 2, 3), rc_route: int = 0) -> None: ...
    def pack(self) -> bytes: ...

def pack_multiviewer_settings(*, uid: bytes, mappings: list[bytes] | tuple[bytes, ...] = ..., fw_mcu: str = '', fw_scaler: str = '', config: MultiviewerConfigData | None = None) -> bytes: ...
