from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameSetupStatus(FrameBase):
    @cached_property
    def setup_completed(self) -> bool | None: ...
