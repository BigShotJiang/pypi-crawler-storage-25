from ..Uid import MxrDeviceUid as MxrDeviceUid
from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameFactoryReset(FrameBase):
    @cached_property
    def is_broadcast_all(self) -> bool: ...
    @cached_property
    def target_uid(self) -> MxrDeviceUid | None: ...
