from ..Interface import DeviceRegistry as DeviceRegistry
from .FrameBase import FrameBase as FrameBase

class FrameDiscover(FrameBase):
    @staticmethod
    def construct(mxr: DeviceRegistry) -> FrameBase | None: ...

def constructFrameDiscover(mxr: DeviceRegistry) -> FrameBase | None: ...
