from ..Interface import BayBase as BayBase, ConnectStatus as ConnectStatus
from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FrameConnectStatus(FrameBase):
    @cached_property
    def bay(self) -> BayBase | None: ...
    @cached_property
    def connected(self) -> ConnectStatus: ...
    def process(self) -> None: ...
