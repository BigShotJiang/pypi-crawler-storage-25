from ..Interface import BayBase as BayBase, PowerStatus as PowerStatus
from .FrameBase import FrameBase as FrameBase
from functools import cached_property

class FramePowerChange(FrameBase):
    @cached_property
    def bay(self) -> BayBase | None: ...
    @cached_property
    def power(self) -> bool | None: ...
    def process(self) -> None: ...
