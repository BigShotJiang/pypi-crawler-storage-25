from _typeshed import Incomplete
from enum import IntEnum, IntFlag

MXR_PROTOCOL_VERSION: int
MXR_OPCODE_VERSIONS: dict[int, int]
V2IP_AUDIO_DEFAULT_SAMPLE_RATE: int
V2IP_AUDIO_DEFAULT_CHANNELS: int
V2IP_AUDIO_MIN_CHANNELS: int
V2IP_AUDIO_MAX_CHANNELS: int

class DeviceFeature(IntFlag):
    IR_RX: Incomplete
    IR_TX: Incomplete
    CEC: Incomplete
    V2IP_SOURCE: Incomplete
    V2IP_SINK: Incomplete
    VIDEO_ROUTING: Incomplete
    AUDIO_ROUTING: Incomplete
    VOLUME_CONTROL: Incomplete
    AUDIO_RETURN: Incomplete
    REMOTE_CONTROL: Incomplete
    SETUP_COMPLETED: Incomplete
    MESH_MASTER: Incomplete
    STATUS_NOTIFY: Incomplete
    STATUS_WARNING: Incomplete
    STATUS_ERROR: Incomplete
    STATUS_REBOOTING: Incomplete
    MESH_MEMBER: Incomplete
    AUDIO_AMPLIFIER: Incomplete
    BOOTING: Incomplete
    MANAGER: Incomplete
    STATUS_POWER_SAVE: Incomplete
    MESH: Incomplete
    MULTIVIEWER: Incomplete
    STATUS_CRASHED: Incomplete
    BOOT_BIT: Incomplete

BAY_FEATURE_DOLBY_IN_POS: int

class BayFeaturesMask(IntFlag):
    HDMI_OUT: Incomplete
    HDMI_IN: Incomplete
    AUDIO_DIG_OUT: Incomplete
    AUDIO_DIG_IN: Incomplete
    AUDIO_ANA_OUT: Incomplete
    AUDIO_ANA_IN: Incomplete
    IR_IN: Incomplete
    IR_OUT: Incomplete
    AUDIO_AMP_OUT: Incomplete
    RC_OUT: Incomplete
    RC_IN: Incomplete
    DOLBY: Incomplete
    AUTO_OFF: Incomplete
    V2IP_SOURCE_REMOTE: Incomplete
    V2IP_SINK_REMOTE: Incomplete
    V2IP_SOURCE_LOCAL: Incomplete
    V2IP_SINK_LOCAL: Incomplete
    def toJson(self) -> str: ...

class BayStatusMask(IntFlag):
    FAULT: Incomplete
    HIDDEN: Incomplete
    POWERED: Incomplete
    SIGNAL_DETECTED: Incomplete
    HPD_DETECTED: Incomplete
    SIGNAL_SCRAMBLED: Incomplete
    HDBT_CONNECTED: Incomplete
    CEC_DETECTED: Incomplete
    POWERED_ON: Incomplete
    POWERED_OFF: Incomplete
    AUDIO_ARC_HDMI: Incomplete
    AUDIO_ARC_OPTICAL: Incomplete
    AUDIO_ARC_ANALOG: Incomplete
    OFFLINE: Incomplete
    DECODER_DISABLED: Incomplete
    ENCODER_DISABLED: Incomplete
    CEC_DISABLED: Incomplete
    ENCODER_ERROR: Incomplete

BAY_STATUS_RC_TYPE_SHIFT: int
BAY_STATUS_RC_TYPE_MASK: Incomplete
BAY_STATUS_HDCP_STATUS_SHIFT: int
BAY_STATUS_HDCP_STATUS_MASK: Incomplete

def bay_status_rc_type(status: int) -> int: ...
def bay_status_hdcp(status: int) -> int: ...

class LinkFeature(IntFlag):
    NONE: int
    VIDEO_HDMI: Incomplete
    AUDIO_OPTICAL: Incomplete
    AUDIO_ANALOG: Incomplete
    IR: Incomplete
    RC: Incomplete

class RCAction(IntEnum):
    ACTION_POWER_TOGGLE: int
    ACTION_POWER_ON: int
    ACTION_POWER_OFF: int
    ACTION_VOLUME_DOWN: int
    ACTION_VOLUME_UP: int
    ACTION_VOLUME_MUTE: int

class RCKey(IntEnum):
    KEY_0: int
    KEY_1: int
    KEY_2: int
    KEY_3: int
    KEY_4: int
    KEY_5: int
    KEY_6: int
    KEY_7: int
    KEY_8: int
    KEY_9: int
    KEY_SELECT: int
    KEY_BACK: int
    KEY_UP: int
    KEY_DOWN: int
    KEY_LEFT: int
    KEY_RIGHT: int
    KEY_MENU: int
    KEY_CONTENT_MENU: int
    KEY_CHANNEL_UP: int
    KEY_CHANNEL_DOWN: int
    KEY_PLAY: int
    KEY_PAUSE: int
    KEY_STOP: int
    KEY_RECORD: int
    KEY_FAST_FORWARD: int
    KEY_REWIND: int
    KEY_RED: int
    KEY_GREEN: int
    KEY_YELLOW: int
    KEY_BLUE: int
    KEY_HELP: int
    KEY_INFORMATION: int
    KEY_TEXT: int
    KEY_GUIDE: int
    KEY_VIDEO_ON_DEMAND: int
    KEY_PREVIOUS_CHANNEL: int
    KEY_3D_MODE: int
    KEY_SUBTITLE: int
    KEY_SOUND_SELECT: int
    KEY_INPUT_SELECT: int
    KEY_EJECT: int
    KEY_NEXT_CHAPTER: int
    KEY_PREVIOUS_CHAPTER: int
    KEY_CUSTOM_CEC: int
    KEY_INTERACTIVE: int
    KEY_SEARCH: int
    KEY_SKY: int
    KEY_CUSTOM_SKY: int

class RCType(IntEnum):
    IR: int
    CEC: int
    SKY_UK: int
    TIVO: int
    KODI: int
    DISH: int
    DIRECTV: int
    MX_REMOTE: int
    @staticmethod
    def values() -> dict[int, str]: ...

class EdidProfile(IntEnum):
    TEMPLATE_1080P_STEREO: int
    FIXED: int
    TEMPLATE_4K: int
    TEMPLATE_1080P_5_1: int
    TEMPLATE_720P: int
    TEMPLATE_1080P_7_1: int
    TEMPLATE_4K_7_1: int
    TEMPLATE_4K_HDR_STEREO: int
    TEMPLATE_4K_HDR_7_1: int
    TEMPLATE_4K_HDR_AVR_ONLY: int
    LOWEST_COMMON_DENOMINATOR: int
    LOWEST_COMMON_DENOMINATOR_ALL: int
    TEMPLATE_4K_HDR_ATMOS: int
    SINK_1: int
    SINK_2: int
    SINK_3: int
    SINK_4: int
    SINK_5: int
    SINK_6: int
    SINK_7: int
    SINK_8: int
    SINK_9: int
    SINK_10: int
    SINK_11: int
    SINK_12: int
    SINK_13: int
    SINK_14: int
    SINK_15: int
    SINK_16: int
    SINK_17: int
    SINK_18: int
    SINK_19: int
    SINK_20: int
    SINK_21: int
    SINK_22: int
    SINK_23: int
    SINK_24: int
    SINK_25: int
    SINK_26: int
    SINK_27: int
    SINK_28: int
    SINK_29: int
    SINK_30: int
    SINK_31: int
    SINK_32: int
    CUSTOM_0: int
    CUSTOM_1: int
    CUSTOM_2: int
    CUSTOM_3: int
    CUSTOM_4: int
    CUSTOM_5: int
    CUSTOM_6: int
    CUSTOM_7: int
    CUSTOM_8: int
    CUSTOM_9: int
    CUSTOM_10: int
    UNKNOWN: int
    def values(nb_sinks: int | None = None) -> dict[int, str]: ...

class FirmwareType(IntEnum):
    UNKNOWN: int
    FPGA: int
    LINUX: int
    LOADING_OVERLAY: int
    def __init__(self, val: int | None) -> None: ...

class UtpLinkSpeed(IntEnum):
    UNKNOWN: int
    L_10M: int
    L_100M: int
    L_200M: int
    L_1G: int
