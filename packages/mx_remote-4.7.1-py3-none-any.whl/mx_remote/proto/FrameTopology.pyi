from ..Uid import MxrDeviceUid as MxrDeviceUid
from .FrameBase import FrameBase as FrameBase
from _typeshed import Incomplete
from functools import cached_property

class TopologyEntry:
    uid: Incomplete
    mask: Incomplete
    def __init__(self, uid: MxrDeviceUid, mask: int) -> None: ...

class FrameTopology(FrameBase):
    @cached_property
    def topology(self) -> list[TopologyEntry]: ...
    @cached_property
    def topology_user_string(self) -> list[str]: ...
    def process(self) -> None: ...
