from ..Interface import DeviceBase as DeviceBase, DeviceRegistry as DeviceRegistry
from .FrameBase import FrameBase as FrameBase

class FrameReboot(FrameBase):
    @staticmethod
    def construct(mxr: DeviceRegistry, target: DeviceBase) -> FrameBase | None: ...
