from ..Interface import DeviceBase as DeviceBase, DeviceRegistry as DeviceRegistry, EdidProfile as EdidProfile
from .FrameBase import FrameBase as FrameBase

class FrameEDIDProfile(FrameBase):
    @staticmethod
    def construct(mxr: DeviceRegistry, target: DeviceBase, profile: EdidProfile) -> FrameBase | None: ...
