from .FrameBase import FrameBase as FrameBase

class FrameDebug(FrameBase):
    def process(self) -> None: ...
