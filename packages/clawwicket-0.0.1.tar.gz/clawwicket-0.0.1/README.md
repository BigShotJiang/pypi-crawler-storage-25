# ClawWicket
Reserved name for an OpenClaw extension that adds governed outcomes via declarative charters.
Coming soon. See repo when it goes public.
