"""Version information for RefChecker."""

__version__ = "3.0.65"
