
__authors__ = ["Lorenzo Raimondi, Luca Rebuffi"]
__license__ = "BSD-3"
__date__ = "2025-now"

import os
from setuptools import setup

PACKAGES     = ["okona"]
PACKAGE_DATA = {}

INSTALL_REQUIRES = (
    'setuptools',
    'numpy',
    'scipy',
    'numba'
)

README_FILE      = os.path.join(os.path.dirname(__file__), 'README.md')
LONG_DESCRIPTION = open(README_FILE).read()

setup(name='okona',
      version='0.0.2',
      description='shadow implementation in python',
      long_description=LONG_DESCRIPTION,
      author='Lorenzo Raimondi, Luca Rebuffi',
      author_email='lraimondi@lbl.gov, lrebuffi@anl.gov',
      url='https://github.com/oasys-kit/OKONA/',
      download_url='https://github.com/oasys-kit/OKONA/',
      packages=PACKAGES,
      install_requires=INSTALL_REQUIRES,
     )

