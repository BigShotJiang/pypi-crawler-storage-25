#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 09:41:30 2025

@author: lraimondi
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import lfilter
from scipy.integrate import cumulative_trapezoid

class SurfaceErrorGenerator:
    """
    Manages the creation, combination, and handling of mirror surface error profiles,
    including figure errors and micro-roughness.
    """
    def __init__(self, wavelength=None):
        """
        Initializes the SurfaceManager.

        Args:
            wavelength (float, optional): The wavelength of light for phase calculations [meters].
        """
        if wavelength:
            self.wavelength = wavelength
            self.k = 2 * np.pi / wavelength

    # --- Generation Methods ---

    def generate_figure_error_from_psd(self, mirror_length, slope_error_rms, sampling_step=1e-3, alpha=2.5):
        """
        Generates a 1D figure error profile based on a power-law PSD model.
        """
        print("\n--- Generating Figure Error from Power-Law PSD Model ---")
        N = int(mirror_length / sampling_step)
        if N % 2 != 0: N += 1 # Ensure N is even for FFT
        x = np.linspace(-mirror_length / 2, mirror_length / 2, N, endpoint=False)
        f = np.fft.fftfreq(N, d=sampling_step)
        
        f0 = 1 / mirror_length
        with np.errstate(divide='ignore'):
            psd = 1 / (f0**2 + f**2)**(alpha / 2.0)
        psd[f == 0] = 0

        random_phases = np.exp(1j * 2 * np.pi * np.random.default_rng().random(N))
        fourier_profile = np.sqrt(psd) * random_phases
        
        height_profile_unscaled = np.fft.ifft(fourier_profile).real

        slope_profile_unscaled = np.gradient(height_profile_unscaled, x)
        current_slope_rms = np.std(slope_profile_unscaled)
        
        if current_slope_rms < 1e-12:
            return x, np.zeros_like(x)
            
        scale_factor = slope_error_rms / current_slope_rms
        height_profile = height_profile_unscaled * scale_factor
        
        print(f"-> Generated figure error profile with RMS height: {np.std(height_profile)*1e9:.3f} nm")
        return x, height_profile

    def generate_figure_error_from_ar_model(self, mirror_length, slope_error_rms, sampling_step=1e-3, ar_coeffs=None):
        """
        Generates a 1D figure error profile using an Autoregressive (AR) model for the surface slope.
        """
        print("\n--- Generating Figure Error from AR Model ---")
        if ar_coeffs is None:
            ar_coeffs = np.array([1.3, -1.5, 0.7])
            print(f"Using default AR(2) model with coefficients: {ar_coeffs}")

        N = int(mirror_length / sampling_step)
        N_extended = N * 2
        
        rng = np.random.default_rng()
        white_noise_slope = rng.standard_normal(N_extended)

        slope_profile_unscaled_extended = lfilter([1.0], ar_coeffs, white_noise_slope)
        transient_length = N // 2
        slope_profile_unscaled = slope_profile_unscaled_extended[transient_length : transient_length + N]

        current_slope_rms = np.std(slope_profile_unscaled)
        if current_slope_rms < 1e-12:
            x = np.linspace(-mirror_length / 2, mirror_length / 2, N, endpoint=False)
            return x, np.zeros(N)
        
        scale_factor = slope_error_rms / current_slope_rms
        final_slope = slope_profile_unscaled * scale_factor
        print(f"Generated slope profile with RMS: {np.std(final_slope)*1e9:.2f} nrad")

        x = np.linspace(-mirror_length / 2, mirror_length / 2, N, endpoint=False)
        height_profile = cumulative_trapezoid(final_slope, x, initial=0)
        
        height_profile -= np.mean(height_profile)
        poly_coeffs = np.polyfit(x, height_profile, 1)
        height_profile -= np.polyval(poly_coeffs, x)
        
        print(f"-> Generated figure error profile with RMS height: {np.std(height_profile)*1e9:.3f} nm")
        return x, height_profile

    def generate_microroughness_from_broken_power_law(self, length, height_rms, correlation_length, n_low, n_high, sampling_step=5e-7):
        """
        Generates a 1D microroughness profile and its PSD from a smooth broken power-law model.
        """
        print("\n--- Generating Microroughness from Broken Power-Law Model ---")
        N = int(length / sampling_step)
        if N % 2 != 0: N += 1
        x = np.linspace(0, length, N, endpoint=False)
        f = np.fft.fftfreq(N, d=sampling_step)
        
        f_break = 1 / correlation_length
        with np.errstate(divide='ignore'):
            psd_shape = (np.abs(f))**(-n_low) * (1 + (np.abs(f) / f_break)**2)**(-(n_high - n_low) / 2.0)
        psd_shape[f == 0] = 0

        random_phases = np.exp(1j * 2 * np.pi * np.random.default_rng().random(N))
        fourier_profile_unscaled = np.sqrt(psd_shape) * random_phases
        height_profile_unscaled = np.fft.ifft(fourier_profile_unscaled).real
        
        current_height_rms = np.std(height_profile_unscaled)
        if current_height_rms < 1e-12:
            return x, np.zeros_like(x), f, np.zeros_like(f)
            
        scale_factor = height_rms / current_height_rms
        height_profile = height_profile_unscaled * scale_factor
        print(f"Generated roughness profile with RMS height: {np.std(height_profile)*1e9:.3f} nm")

        variance = height_rms**2
        df = f[1] - f[0]
        positive_freq_mask = f > 0
        integral_of_shape = 2 * np.sum(psd_shape[positive_freq_mask]) * df
        
        psd_scale_factor = variance / integral_of_shape if integral_of_shape > 0 else 0
        final_psd = psd_shape * psd_scale_factor

        return x, height_profile, f, final_psd

    # --- Utility Methods ---

    def get_total_error_profile(self, mirror_axis, figure_error_data=None, roughness_data=None):
        """
        Combines figure error and roughness onto a common mirror axis.
        """
        print("\n--- Combining profiles onto a common axis ---")
        total_error = np.zeros_like(mirror_axis)
        
        if figure_error_data and figure_error_data[0] is not None:
            pos, height = figure_error_data
            interp_figure_error = np.interp(mirror_axis, pos, height, left=0, right=0)
            total_error += interp_figure_error
            print("Added figure error to total profile.")
            
        if roughness_data and roughness_data[0] is not None:
            pos, height = roughness_data
            interp_roughness = np.interp(mirror_axis, pos, height, left=0, right=0)
            total_error += interp_roughness
            print("Added roughness to total profile.")
        
        if len(total_error) > 0:
            total_rms_nm = np.std(total_error) * 1e9
            print(f"-> Total combined profile RMS: {total_rms_nm:.3f} nm")
            
        return total_error

    def create_figure_error_data_file(self, x, height_profile, data_file:str="figure_error_profile.txt", show:bool=False):
        np.savetxt(data_file, np.vstack((x, height_profile)).T, header="Position (m)\tHeight Error (m)", fmt='%.9e', delimiter='\t')
        print(f"Saved {data_file}")
        if show:
            plt.style.use('seaborn-v0_8-whitegrid')

            fig1, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)
            final_slope = np.gradient(height_profile, x)
            ax1.plot(x * 1000, height_profile * 1e9, 'dodgerblue')
            ax1.set_title(f"Figure Error Profile (RMS Height = {np.std(height_profile) * 1e9:.3f} nm)")
            ax1.set_ylabel("Height Error (nm)")
            ax2.plot(x * 1000, final_slope * 1e6, 'firebrick')
            ax2.set_title(f"Slope Error Profile (RMS = {np.std(final_slope) * 1e6:.3f} µrad)")
            ax2.set_xlabel("Position along mirror (mm)")
            ax2.set_ylabel("Slope Error (μrad)")
            fig1.tight_layout()

            plt.show()

    def create_microroughness_psd_data_file(self, x, height_profile, f, final_psd,
                                            data_file:str="microroughness_psd.txt", show:bool=False, correlation_length:float=0.0):
        valid_freq = f > 0
        wavelength_out_um = (1 / f[valid_freq]) * 1e6
        psd_out_nm2_um = final_psd[valid_freq] * 1e24
        sort_idx = np.argsort(wavelength_out_um)
        psd_data = np.vstack((wavelength_out_um[sort_idx], psd_out_nm2_um[sort_idx])).T
        np.savetxt(data_file, psd_data, header="Wavelength (um)\tPSD (nm^2 * um)", fmt='%.9e', delimiter='\t')
        print(f"Saved {data_file}")

        if show:
            plt.style.use('seaborn-v0_8-whitegrid')

            fig2, (ax3, ax4) = plt.subplots(1, 2, figsize=(12, 6))
            ax3.plot(x * 1e6, height_profile * 1e9, 'seagreen')
            ax3.set_title(f"Microroughness Profile (RMS = {np.std(height_profile) * 1e9:.3f} nm)")
            ax3.set_xlabel("Position (μm)")
            ax3.set_ylabel("Height (nm)")
            ax4.loglog(wavelength_out_um[sort_idx], psd_out_nm2_um[sort_idx], 'darkorange')
            ax4.set_title("Microroughness PSD")
            ax4.set_xlabel("Spatial Wavelength (µm)")
            ax4.set_ylabel(r"PSD (nm$^2$ µm)")
            ax4.invert_xaxis()
            ax4.axvline(correlation_length * 1e6, color='k', ls='--', label=f"Break @ {correlation_length * 1e6:.1f} µm")
            ax4.legend()
            fig2.tight_layout()

            plt.show()


def main():
    """
    Main function to generate surface profiles, save data, and create plots.
    """
    print("--- Full Surface Synthesis Script ---")
    
    # --- Configuration ---
    USE_AR_MODEL_FOR_FIGURE_ERROR = True

    # --- Parameters for Figure Error ---
    figure_error_params = {
        'mirror_length': 0.640,
        'slope_error_rms': 500e-9,
        'sampling_step': 1e-3,# 50 nrad
    }

    # --- Parameters for Microroughness ---
    microroughness_params = {
        'patch_length': 1.0e-3,
        'height_rms': 0.8e-9,
        'correlation_length': 35.6e-6,
        'n_low': 1.54,
        'n_high': 1.0,
        'step' : 1e-8,
    }

    # --- Processing ---
    surface_gen = SurfaceErrorGenerator()

    # 1. Generate Figure Error
    if USE_AR_MODEL_FOR_FIGURE_ERROR:
        x_fig, h_fig = surface_gen.generate_figure_error_from_ar_model(
            mirror_length=figure_error_params['mirror_length'],
            slope_error_rms=figure_error_params['slope_error_rms'],
            sampling_step=figure_error_params['sampling_step']
        )
    else:
        x_fig, h_fig = surface_gen.generate_figure_error_from_psd(
            mirror_length=figure_error_params['mirror_length'],
            slope_error_rms=figure_error_params['slope_error_rms']
        )
    
    # 2. Generate Microroughness
    x_rough, h_rough, f_rough_si, psd_rough_si = surface_gen.generate_microroughness_from_broken_power_law(
        length=microroughness_params['patch_length'],
        height_rms=microroughness_params['height_rms'],
        correlation_length=microroughness_params['correlation_length'],
        n_low=microroughness_params['n_low'],
        n_high=microroughness_params['n_high'],
        sampling_step=microroughness_params['step'],
    )
    
    # 3. Combine Profiles
    # For a full-length profile, we need to generate roughness over the whole mirror
    # Here, for demonstration, we combine over a small central patch.
    x_rough_centered = x_rough - microroughness_params['patch_length'] / 2
    h_fig_interp = np.interp(x_rough_centered, x_fig, h_fig)
    h_total = h_rough + h_fig_interp

    # --- Save Data to Files ---
    print("\n--- Saving Data ---")

    surface_gen.create_figure_error_data_file(x_fig, h_fig, show=True)
    surface_gen.create_microroughness_psd_data_file(x_rough, h_rough, f_rough_si, psd_rough_si,
                                                    show=True, correlation_length=microroughness_params['correlation_length'])


if __name__ == "__main__":
    main()