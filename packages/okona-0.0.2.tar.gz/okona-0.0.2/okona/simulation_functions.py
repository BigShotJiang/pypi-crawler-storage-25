#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import traceback
from typing import Any

import numpy as np

# Import all the necessary classes from the other python files
from okona.optics_elements import PlaneMirror, EllipticalMirror, Slit, Detector, RayTracingPropagator
from okona.beamline_manager import BeamlineManager
from okona.surface_errors import SurfaceManager

def simulate_single_mode_wave_optics(args):
    """
    This function encapsulates the entire simulation for a single coherent mode.
    It is designed to be run in parallel on different CPU cores.
    """
    try:
        E_mode, beamline_config, generated_roughness_data, global_max_points, wavelength, x_mode = __simulate_single_node_init(args)

        bl = BeamlineManager(wavelength, global_max_points=global_max_points)
        for el_config in beamline_config['elements']:
            bl.add_element(el_config['element_object'],
                           el_config['distance'],
                           el_config.get('propagator', 'fresnel'),
                           el_config.get('max_points_before'))
        bl.run(x_mode, E_mode)

        return bl.history, generated_roughness_data
    except Exception as ex:
        print(f"Emitted an exception while simulating the single mode {ex}.")
        raise ex

def simulate_single_mode_ray_tracing(args):
    """
    This function encapsulates the entire simulation for a single coherent mode.
    It is designed to be run in parallel on different CPU cores.
    """
    E_mode, beamline_config, generated_roughness_data, global_max_points, wavelength, x_mode = __simulate_single_node_init(args)

    tracer = RayTracingPropagator(beamline_config,
                                  source_fwhm=beamline_config['target_size_fwhm'],
                                  source_div_fwhm=beamline_config['target_divergence_fwhm'])
    history, _ = tracer.run(x_mode, E_mode)

    return history, generated_roughness_data

def __simulate_single_node_init(args) -> tuple[Any, Any, Any, dict[Any, Any], Any, Any]:
    i, _, x_mode, E_mode, beamline_config, global_max_points = args

    wavelength = beamline_config['wavelength']
    sm_worker = SurfaceManager(wavelength)
    generated_roughness_data = {}

    for el_config in beamline_config['elements']:
        constructor_args = el_config['constructor_args'].copy()

        if 'surface_config' in el_config:
            surf_conf = el_config['surface_config']
            mirror_length, mirror_angle = constructor_args['length'], constructor_args['angle']

            num_points_for_profile = surf_conf.get('calculated_sampling_points', surf_conf.get('axis_points', 2 ** 15))

            rough_data = sm_worker.generate_roughness_from_psd(
                surf_conf['psd_filepath'],
                mirror_length,
                num_points=num_points_for_profile,
                verbose=(i == 0)
            )
            generated_roughness_data[constructor_args['name']] = rough_data

            mirror_axis = np.linspace(-mirror_length / 2, mirror_length / 2, int(num_points_for_profile))

            total_error_unfiltered = sm_worker.get_total_error_profile(mirror_axis, surf_conf['figure_error_data'], rough_data, verbose=(i == 0))

            cutoff = surf_conf.get('high_pass_wavelength_cutoff_m')

            if cutoff == 0:
                total_error_to_use = np.zeros_like(mirror_axis)
                if i == 0:
                    print(f"  -> Using perfectly smooth surface for {constructor_args['name']} as it meets the smoothness criteria.")
            elif cutoff is not None and np.isfinite(cutoff):
                total_error_to_use = sm_worker.filter_profile_by_wavelength(mirror_axis, total_error_unfiltered, cutoff)
            else:
                total_error_to_use = total_error_unfiltered

            phase_error = sm_worker.get_phase_error(total_error_to_use, mirror_angle)
            constructor_args['phase_error_profile'] = {'x': mirror_axis, 'phase': phase_error}

        # This globals() call is what allows the string 'element_type' to be
        # converted into an actual class. It's why the imports at the top
        # of this file are essential.
        element_class = globals()[el_config['element_type']]
        el_config['element_object'] = element_class(**constructor_args)

    return E_mode, beamline_config, generated_roughness_data, global_max_points, wavelength, x_mode
