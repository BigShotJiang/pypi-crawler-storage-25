#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 10:29:25 2025

@author: lraimondi
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter1d
from scipy.integrate import cumulative_trapezoid
import inspect
import concurrent.futures
import time
import os
from datetime import datetime

# Import the new helper functions and the new Sampling class
from okona.optics_elements import (FreeSpacePropagator, HuygensFresnelPropagator,
                             resample_field, OpticalElement, Detector,
                             PlaneMirror, EllipticalMirror, Slit, NewSampling)
from okona.surface_errors import SurfaceManager

class BeamlineManager:
    """
    Manages the beamline with optimized sampling and propagation methods.
    (This class handles a SINGLE mode propagation, used by the worker)
    """
    def __init__(self, wavelength, global_max_points=None):
        self.wavelength = wavelength
        self.elements = []
        self.history = []
        self.sampler = NewSampling()  # <--- CHANGED TO NewSampling
        #  global point limiter for memory management
        self.global_max_points = global_max_points

    def add_element(self, element, distance_from_previous, propagator='fresnel', max_points_before=None):
        # ... (function is unchanged) ...
        self.elements.append({
            'element': element,
            'distance': distance_from_previous,
            'propagator': propagator,
            'max_points_before': max_points_before
        })

    def run(self, source_x, source_E):
        # ... (function is unchanged) ...
        x, E = source_x, source_E
        self.history = [{'name': 'Source', 'x': x, 'E': E, 'element_object': OpticalElement(name='Source')}]

        for i, el_info in enumerate(self.elements):
            target_element = el_info['element']
            distance_of_current_propagation = el_info['distance']
            propagator_type = el_info['propagator']
            max_points = el_info.get('max_points_before')

           
            # First, check for the specific per-element limit
            if max_points and len(x) > max_points:
                print(f"  - BeamlineManager: Resampling field from {len(x)} to {max_points} points (per-element setting).")
                x, E = resample_field(x, E, max_points)
            # Then, check for the global limit as a fallback
            elif self.global_max_points and len(x) > self.global_max_points:
                print(f"  - BeamlineManager: Resampling field from {len(x)} to {self.global_max_points} points (global setting).")
                x, E = resample_field(x, E, self.global_max_points)


            if distance_of_current_propagation > 0:
                previous_element_object = self.history[-1]['element_object']
                is_last_element = (i == len(self.elements) - 1)

                if is_last_element:
                    distance_to_next = distance_of_current_propagation
                else:
                    distance_to_next = self.elements[i+1]['distance']

                final_N = self.sampler.get_required_input_points(
                    current_element=previous_element_object,  # Light leaves from here
                    next_element=target_element,              # Light travels to here
                    distance=distance_of_current_propagation, # Distance between them
                    wavelength=self.wavelength
                )
                print(f"  - Calculated N for {target_element.name}: {final_N} points (using d={distance_to_next:.2f}m)")

                element_width = target_element.x[-1] - target_element.x[0] if hasattr(target_element, 'x') and len(target_element.x) > 1 else 0
                padding_factor = 1.#2.5
                final_width = element_width * padding_factor

                if i == 0:
                    initial_beam_width = x[-1] - x[0]
                    final_width = max(final_width, initial_beam_width * 2.0)

                if final_width <= 0: final_width = 1e-3
                x_target = np.linspace(-final_width / 2, final_width / 2, final_N)

                if propagator_type == 'huygens':
                    propagator = HuygensFresnelPropagator(self.wavelength, distance_of_current_propagation)
                    x, E = propagator.propagate(x, E, x_target)
                else: # Default to the more robust Angular Spectrum propagator
                    propagator = FreeSpacePropagator(self.wavelength, distance_of_current_propagation)
                    x, E = propagator.propagate(x, E, x_out_required=x_target)

            if isinstance(target_element, Detector):
                self.history.append({'name': target_element.name, 'x': x, 'E': E, 'element_object': target_element})
                break
            else:
                if 'wavelength' in inspect.signature(target_element.apply).parameters:
                    x, E = target_element.apply(x, E, wavelength=self.wavelength)
                else:
                    x, E = target_element.apply(x, E)
                self.history.append({'name': target_element.name, 'x': x, 'E': E, 'element_object': target_element})

        return x, E


#==============================================================================
#  BEAMLINE PRE-PROCESSOR CLASS
#==============================================================================
class BeamlineProcessor:
    """
    Handles generic pre-processing tasks on the beamline_config dictionary.
    """
    def __init__(self, wavelength):
        self.wavelength = wavelength
        self.sm_preprocessor = SurfaceManager(wavelength)
        self.temp_sampler = NewSampling()

    def process_ashenbach_cutoff(self, beamline_config):
        """
        Calculates and applies the 'ashenbach' high-pass filter cutoff.
        """
        print("\n--- Pre-processing beamline configuration (Ashenbach Cutoff) ---")
        for el_config in beamline_config['elements']:
            if 'surface_config' in el_config and el_config['surface_config'].get('high_pass_wavelength_cutoff_m') == 'ashenbach':
                name = el_config['constructor_args']['name']
                print(f"  - Calculating smooth surface cutoff for: {name}")
                surf_conf = el_config['surface_config']
                mirror_angle, mirror_length = el_config['constructor_args']['angle'], el_config['constructor_args']['length']
                
                # Use the specified 'axis_points' for this pre-calculation
                axis_points_for_calc = surf_conf.get('axis_points', 2**16)
                mirror_axis = np.linspace(-mirror_length / 2, mirror_length / 2, int(axis_points_for_calc))
                roughness_data = self.sm_preprocessor.generate_roughness_from_psd(surf_conf['psd_filepath'], mirror_length, num_points=axis_points_for_calc, verbose=False)
                total_error_profile = self.sm_preprocessor.get_total_error_profile(mirror_axis, surf_conf['figure_error_data'], roughness_data, verbose=False)
                
                total_profile_freqs, total_profile_psd = self.sm_preprocessor.calculate_psd_from_profile(mirror_axis, total_error_profile)
                
                target_sigma = self.wavelength / (4 * np.pi * np.sin(mirror_angle))
                print(f"    -> Target RMS from condition: {target_sigma * 1e9:.4f} nm")
                
                # --- FIX: Removed hardcoded value and re-enabled correct calculation ---
                ashenbach_cutoff = self.sm_preprocessor.get_cutoff_for_target_rms(total_profile_freqs, total_profile_psd, target_sigma)
                
                if ashenbach_cutoff is not None:
                    el_config['surface_config']['high_pass_wavelength_cutoff_m'] = ashenbach_cutoff
                    if ashenbach_cutoff == 0:
                         print(f"    -> SUCCESS: Surface is already smoother than required. Using a perfect surface.")
                    else:
                         print(f"    -> SUCCESS: Calculated cutoff wavelength: {ashenbach_cutoff * 1e3:.3f} mm")
                else:
                    print(f"    -> FAILED: Could not calculate cutoff. Using full unfiltered profile.")
                    el_config['surface_config']['high_pass_wavelength_cutoff_m'] = None
        return beamline_config

    def process_sampling_points(self, beamline_config):
        """
        Calculates and inserts the optimal sampling points for each element.
        """
        print("\n--- Pre-calculating optimal sampling points for propagation ---")
        
        for i, el_config in enumerate(beamline_config['elements']):
            
            # ---Robustly get the element class to resolve scope errors ---
            element_type_str = el_config['element_type']
            constructor_args = el_config['constructor_args']
            
            # Find the class that was imported at the top of this file
            if element_type_str == 'PlaneMirror':
                element_class = PlaneMirror
            elif element_type_str == 'EllipticalMirror':
                element_class = EllipticalMirror
            elif element_type_str == 'Slit':
                element_class = Slit
            elif element_type_str == 'Detector':
                element_class = Detector
            else:
                print(f"Warning: Unknown element type {element_type_str}. Skipping.")
                continue
                
            current_element_object = element_class(**constructor_args)
            
            if isinstance(current_element_object, (PlaneMirror, EllipticalMirror)) and 'surface_config' in el_config:
                is_last_element = (i == len(beamline_config['elements']) - 1)
                
                if is_last_element:
                    # If the mirror is the last element, we can't look forward.
                    # We just use a default dummy element with aperture 0.
                    next_element_object = OpticalElement(name='Dummy')
                    distance_to_next = el_config['distance']
                else:
                    # Look ahead to the NEXT element in the config dictionary
                    next_el_config = beamline_config['elements'][i+1]
                    next_type_str = next_el_config['element_type']
                    next_args = next_el_config['constructor_args']
                    
                    if next_type_str == 'PlaneMirror': next_class = PlaneMirror
                    elif next_type_str == 'EllipticalMirror': next_class = EllipticalMirror
                    elif next_type_str == 'Slit': next_class = Slit
                    elif next_type_str == 'Detector': next_class = Detector
                    else: next_class = OpticalElement
                    
                    # Temporarily instantiate the next element just to get its aperture
                    next_element_object = next_class(**next_args)
                    distance_to_next = next_el_config['distance']
                
                # Now we have both the current and next elements defined!
                num_points = self.temp_sampler.get_required_input_points(
                    current_element=current_element_object,
                    next_element=next_element_object,
                    distance=distance_to_next,
                    wavelength=self.wavelength
                )
                
                el_config['surface_config']['calculated_sampling_points'] = num_points
                print(f"  - Calculated {num_points} sampling points for: {current_element_object.name}")
                
        return beamline_config

#==============================================================================
#  SIMULATION RUNNER CLASS
#==============================================================================
class SimulationRunner:
    """
    Manages the parallel execution of the simulation and aggregates results.
    """
    def __init__(self, source, beamline_config, simulate_single_mode_func):
        # ... (class content is unchanged) ...
        self.source = source
        self.beamline_config = beamline_config
        self.simulate_single_mode_func = simulate_single_mode_func
        self.num_workers = int(os.cpu_count() * 0.85) if os.cpu_count() else 1

    def _estimate_simulation_time(self, tasks):
        if not tasks: return 0
        print("\n--- Estimating Simulation Time ---")
        start_time = time.time()
        # Run the first task to get a baseline time
        self.simulate_single_mode_func(tasks[0])
        single_core_time = time.time() - start_time
        total_time_estimate = (single_core_time * len(tasks)) / self.num_workers
        print(f"  - Single mode simulation time: {single_core_time:.2f} seconds")
        print(f"  - Estimated total time for {len(tasks)} modes on {self.num_workers} cores: {total_time_estimate/60:.2f} minutes")

    def run_parallel(self):
        print(f"\n--- Pre-generating {self.source.num_modes} source modes ---")
        initial_modes = list(self.source.get_modes())
        tasks = [(i, self.source.num_modes, x, E, self.beamline_config, 2**26) for i, (x, E) in enumerate(initial_modes)]
        
        self._estimate_simulation_time(tasks)

        # Run in parallel
        print(f"\n--- Starting parallel simulation on {self.num_workers} cores ---")
        total_history_intensities, history_for_plotting, roughness_for_plotting = None, None, None
        start_time = time.time()
        
        with concurrent.futures.ProcessPoolExecutor(max_workers=self.num_workers) as executor:
            for i, (single_mode_history, single_mode_roughness) in enumerate(executor.map(self.simulate_single_mode_func, tasks)):
                if not single_mode_history: continue
                
                if history_for_plotting is None:
                    history_for_plotting, roughness_for_plotting = single_mode_history, single_mode_roughness
                    total_history_intensities = [np.abs(step['E'])**2 for step in single_mode_history]
                else:
                    for j, step in enumerate(single_mode_history):
                        if j < len(total_history_intensities) and total_history_intensities[j].shape == np.abs(step['E']).shape:
                            total_history_intensities[j] += np.abs(step['E'])**2
                
                elapsed_time = time.time() - start_time
                print(f"\r  -> Progress: {i+1}/{self.source.num_modes} ({(i+1)/self.source.num_modes*100:.1f}%) | Time remaining: {(elapsed_time/(i+1))*(self.source.num_modes-(i+1))/60:.2f} min", end="")
        
        print("\n\n--- Simulation Complete ---")
        
        # Return a dictionary of all results
        return {
            "history_for_plotting": history_for_plotting,
            "total_history_intensities": total_history_intensities,
            "roughness_for_plotting": roughness_for_plotting,
            "source": self.source,
            "beamline_config": self.beamline_config
        }

    def run_sequential(self):
        print(f"\n--- Pre-generating {self.source.num_modes} source modes ---")
        initial_modes = list(self.source.get_modes())
        tasks = [(i, self.source.num_modes, x, E, self.beamline_config, 2 ** 26) for i, (x, E) in enumerate(initial_modes)]

        self._estimate_simulation_time(tasks)

        # Run in parallel
        print(f"\n--- Starting parallel simulation on {self.num_workers} cores ---")
        total_history_intensities, history_for_plotting, roughness_for_plotting = None, None, None
        start_time = time.time()

        for i in range(len(tasks)):
            single_mode_history, single_mode_roughness = self.simulate_single_mode_func(tasks[i])

            if single_mode_history:
                if history_for_plotting is None:
                    history_for_plotting, roughness_for_plotting = single_mode_history, single_mode_roughness
                    total_history_intensities = [np.abs(step['E']) ** 2 for step in single_mode_history]
                else:
                    for j, step in enumerate(single_mode_history):
                        if j < len(total_history_intensities) and total_history_intensities[j].shape == np.abs(step['E']).shape:
                            total_history_intensities[j] += np.abs(step['E']) ** 2

                elapsed_time = time.time() - start_time
                print(f"\r  -> Progress: {i + 1}/{self.source.num_modes} ({(i + 1) / self.source.num_modes * 100:.1f}%) | Time remaining: {(elapsed_time / (i + 1)) * (self.source.num_modes - (i + 1)) / 60:.2f} min", end="")

        print("\n\n--- Simulation Complete ---")

        # Return a dictionary of all results
        return {
            "history_for_plotting": history_for_plotting,
            "total_history_intensities": total_history_intensities,
            "roughness_for_plotting": roughness_for_plotting,
            "source": self.source,
            "beamline_config": self.beamline_config
        }


#==============================================================================
#  RESULTS MANAGER CLASS
#==============================================================================
class ResultsManager:
    """
    Handles plotting and saving all simulation results.
    """
    def __init__(self, results_data):
        # ... (class content is unchanged) ...
        self.results = results_data
        self.history = results_data.get("history_for_plotting")
        self.intensities = results_data.get("total_history_intensities")
        self.roughness = results_data.get("roughness_for_plotting")
        self.source = results_data.get("source")
        self.config = results_data.get("beamline_config")

    def _compute_fwhm(self, x, intensity):
        # ... (function is unchanged) ...
        if np.max(intensity) == 0: return 0.0
        half_max = np.max(intensity) / 2.0
        indices = np.where(intensity >= half_max)[0]
        return x[indices[-1]] - x[indices[0]] if len(indices) >= 2 else 0.0

    def _compute_hew(self, x, intensity):
        # ... (function is unchanged) ...
        if np.sum(intensity) <= 0: return 0.0
        cum_energy = cumulative_trapezoid(np.abs(intensity), x, initial=0)
        total_energy = cum_energy[-1]
        if total_energy == 0: return 0.0
        try:
            x_low = np.interp(0.25 * total_energy, cum_energy, x)
            x_high = np.interp(0.75 * total_energy, cum_energy, x)
            return x_high - x_low
        except Exception as e:
            print(f"Warning: Could not compute HEW. ({e})")
            return 0.0

    def plot_all_results(self):
        # ... (function is unchanged) ...
        if self.history is None:
            print("Error: No valid results to plot.")
            return

        self._plot_source()
        self._plot_surface_errors()
        self._plot_slit_profile()
        self._plot_propagation_history()
        self._plot_detector()

    def _plot_source(self):
        # ... (function is unchanged) ...
        total_source_intensity = self.intensities[0]
        plt.figure(figsize=(8, 6))
        source_fwhm = self._compute_fwhm(self.history[0]['x'], total_source_intensity)
        plt.plot(self.history[0]['x'] * 1e6, total_source_intensity / np.max(total_source_intensity), color='purple')
        plt.title(f'Effective Source Intensity (Sum of {self.source.num_modes} Modes)')
        plt.xlabel("Position (µm)")
        plt.ylabel("Normalized Intensity")
        plt.grid(True)
        target_size_fwhm = self.config.get('target_size_fwhm', 0)
        plt.figtext(0.5, 0.01, f'Effective Source FWHM = {source_fwhm*1e6:.2f} µm (Target: {target_size_fwhm*1e6:.2f} µm)', ha='center', fontsize=12)
        if source_fwhm > 0:
            plt.xlim(-4 * source_fwhm * 1e6, 4 * source_fwhm * 1e6)
        plt.show()

    def _plot_surface_errors(self):
        # Need to find the original fig_err data from the config
        loaded_fig_errors = {}
        for el in self.config['elements']:
            if 'surface_config' in el:
                name_key = el['constructor_args']['name']
                loaded_fig_errors[name_key] = el['surface_config']['figure_error_data']

        # Attempt to get data under 'EM1', fallback to 'Focusing Mirror' if named differently in config
        em1_fig_err = loaded_fig_errors.get('EM1', loaded_fig_errors.get('Focusing Mirror'))
        em1_roughness = self.roughness.get('EM1', self.roughness.get('Focusing Mirror')) if self.roughness else None

        # Create a 1x2 grid specifically for EM1
        fig, axs = plt.subplots(1, 2, figsize=(12, 4))
        fig.suptitle('Loaded Surface Error Profiles: EM1 (Roughness is a sample from Mode 1)', fontsize=14, y=1.05)
        
        # Plot Figure Error
        ax = axs[0]
        if em1_fig_err and em1_fig_err[0] is not None and len(em1_fig_err[1]) > 0:
            ax.plot(em1_fig_err[0] * 1000, em1_fig_err[1] * 1e9)
            ax.set_title(f"EM1 Figure Error (RMS: {np.std(em1_fig_err[1] * 1e9):.3f} nm)")
        else:
            ax.set_title("EM1 Figure Error (Not Loaded)")
        ax.set_ylabel("Height (nm)")
        ax.set_xlabel("Position (mm)")
        ax.grid(True)

        # Plot Roughness
        ax = axs[1]
        if em1_roughness and em1_roughness[0] is not None and len(em1_roughness[1]) > 0:
            ax.plot(em1_roughness[0] * 1000, em1_roughness[1] * 1e9)
            ax.set_title(f"EM1 Roughness (RMS: {np.std(em1_roughness[1] * 1e9):.3f} nm)")
        else:
            ax.set_title("EM1 Roughness (Not Generated)")
        ax.set_ylabel("Height (nm)")
        ax.set_xlabel("Position (mm)")
        ax.grid(True)

        plt.tight_layout()
        plt.show()

    def _plot_slit_profile(self):
        
        slit_step_index = next((idx for idx, el in enumerate(self.history) if el['name'] == 'Slit'), None)
        if slit_step_index is not None:
            slit_data = self.history[slit_step_index]
            total_slit_intensity = self.intensities[slit_step_index]
            slit_fwhm = self._compute_fwhm(slit_data['x'], total_slit_intensity)
            slit_hew = self._compute_hew(slit_data['x'], total_slit_intensity)
            plt.figure(figsize=(8, 6))
            plt.plot(slit_data['x'] * 1e6, total_slit_intensity / np.max(total_slit_intensity), color='darkcyan')
            plt.title(f"Beam Profile at Slit (Secondary Source)\nFWHM = {slit_fwhm*1e6:.2f} µm | HEW = {slit_hew*1e6:.2f} µm")
            plt.xlabel("Position (µm)")
            plt.ylabel("Normalized Intensity")
            plt.grid(True)
            if slit_fwhm > 0:
                plt.xlim(-4 * slit_fwhm * 1e6, 4 * slit_fwhm * 1e6)
            plt.show()

    def _plot_propagation_history(self):
        
        plt.figure(figsize=(10, 12))
        for i, step in enumerate(self.history):
            plt.subplot(len(self.history), 1, i + 1)
            intensity = self.intensities[i]
            if np.max(intensity) == 0: continue
            
            element_obj = step['element_object']
            
            if isinstance(element_obj, (PlaneMirror, EllipticalMirror)):
                if np.sin(element_obj.angle) > 1e-9:
                    x_footprint = step['x'] / np.sin(element_obj.angle)
                    mirror_axis = np.linspace(-element_obj.length / 2, element_obj.length / 2, 2048)
                    intensity_on_mirror = np.interp(mirror_axis, x_footprint, intensity, left=0, right=0)
                    if np.max(intensity_on_mirror) > 0:
                        plt.plot(mirror_axis * 1000, intensity_on_mirror / np.max(intensity_on_mirror))
                    plt.xlabel("Position along mirror (mm)")
                else:
                     plt.plot(step['x'] * 1e6, intensity / np.max(intensity))
                     plt.xlabel("Position (µm)")
            else:
                plt.plot(step['x'] * 1e6, intensity / np.max(intensity))
                plt.xlabel("Position (µm)")

            plt.title(f"Intensity at: {step['name']} (Sum of All Modes)")
            plt.ylabel("Norm. Intensity")
            plt.grid(True)
        plt.suptitle("Beamline Intensity Profiles (Sum of All Modes)", fontsize=16, y=0.99)
        plt.tight_layout(rect=[0, 0, 1, 0.98])
        plt.show()

    def _plot_detector(self):
        total_detector_intensity = self.intensities[-1]
        final_detector_x_axis = self.history[-1]['x']
        
        if np.max(total_detector_intensity) > 0:
            smoothed_I = gaussian_filter1d(total_detector_intensity, sigma=1)
            plt.figure(figsize=(8, 6))
            
            # X-axis is converted to µm here
            plt.plot(final_detector_x_axis * 1e6, total_detector_intensity / np.max(total_detector_intensity), label='Raw Intensity', alpha=0.3)
            plt.plot(final_detector_x_axis * 1e6, smoothed_I / np.max(smoothed_I), label='Smoothed Intensity', color='firebrick')
            
            final_fwhm = self._compute_fwhm(final_detector_x_axis, smoothed_I)
            final_hew = self._compute_hew(final_detector_x_axis, smoothed_I)
            
            print(f"\n--- Results ---")
            print(f"Final Spot FWHM (smoothed): {final_fwhm*1e6:.4f} µm")
            print(f"Final Spot HEW (smoothed):  {final_hew*1e6:.4f} µm")

            final_coherence_length = self.source.sigma_mu
            target_size_fwhm = self.config.get('target_size_fwhm', 0)
            target_divergence_fwhm = self.config.get('target_divergence_fwhm', 0)
            wavelength = self.config.get('wavelength', 1e-10)
            
            print(f"\n--- Source Coherence Properties ---")
            print(f"  - Total Source FWHM Size:       {target_size_fwhm*1e6:.3f} µm")
            print(f"  - Total Source FWHM Divergence: {target_divergence_fwhm*1e6:.3f} µrad")
            
            # Calculate Theoretical Visibility (from phase space area)
            fwhm_to_rms = 1 / (2 * np.sqrt(2 * np.log(2)))
            total_sigma_s = target_size_fwhm * fwhm_to_rms
            total_sigma_div = target_divergence_fwhm * fwhm_to_rms
            phase_space_area = total_sigma_s * total_sigma_div
            diffraction_limit = wavelength / (4 * np.pi)
            theoretical_visibility = min(1.0, diffraction_limit / phase_space_area) if phase_space_area > 0 else 1.0
            
            print(f"  -> Theoretical 1D Coherent Fraction: {theoretical_visibility*100:.2f}%")
            
            if final_coherence_length is not None and np.isfinite(final_coherence_length) and final_coherence_length > 0:
                global_coherence = final_coherence_length / total_sigma_s
                
                # Calculate Simulated Visibility (from GSM M-factor)
                M_factor = np.sqrt(1 + (2 * total_sigma_s / final_coherence_length)**2)
                simulated_visibility = 1.0 / M_factor
                
                print(f"  - Total RMS Source Size (sigma_s):      {total_sigma_s*1e6:.3f} µm")
                print(f"  - Transverse Coherence Length (sigma_mu): {final_coherence_length*1e6:.3f} µm")
                print(f"  - Global Coherence Degree (sigma_mu / sigma_s): {global_coherence:.4f}")
                print(f"  -> Simulated 1D Coherent Fraction (1/M): {simulated_visibility*100:.2f}%")
            else:
                print(f"  - Source is Fully Coherent (sigma_mu = infinity)")
                print(f"  -> Simulated 1D Coherent Fraction: 100.00%")
                
            title_str = (f'Final Detector Spot (Sum of {self.source.num_modes} Modes)\n'
                         f'FWHM = {final_fwhm*1e6:.4f} µm | HEW = {final_hew*1e6:.4f} µm')
            
            plt.title(title_str)
            plt.xlabel("Position (µm)")
            plt.ylabel("Normalized Intensity")
            plt.grid(True)
            plt.legend()
            
            if final_fwhm > 0:
                # Set static limits to -50 and 50 µm 
                plt.xlim(-200, 200)
                
            plt.tight_layout()
            plt.show()
           
        else:
            print("Simulation resulted in zero intensity at the detector.")
    def save_detector_file(self, sim_plane, source_type):
        # ... (function is unchanged) ...
        if self.history is None or self.intensities is None:
            print("No data to save.")
            return

        total_detector_intensity = self.intensities[-1]
        final_detector_x_axis = self.history[-1]['x']
        
        if np.max(total_detector_intensity) > 0:
            smoothed_I = gaussian_filter1d(total_detector_intensity, sigma=1)
        else:
            smoothed_I = total_detector_intensity

        current_time = datetime.now()
        date_str = current_time.strftime("%m-%d-%Y")
        time_str = current_time.strftime("%H-%M")
        wavelength_nm = self.config['wavelength'] * 1e9
            
        output_filename = f"detector_spot_{sim_plane}_wl_{wavelength_nm:.4f}nm_{date_str}_{time_str}.txt"
        header_text = (f"Position (m)    Intensity (arb. units)\n"
                       f"Simulation Plane: {sim_plane.upper()}\n"
                       f"Source Type: {source_type}\n"
                       f"Wavelength: {self.config['wavelength']} m\n"
                       f"Date: {current_time.strftime('%m/%d/%Y')}\n"
                       f"Time: {current_time.strftime('%H:%M')}")
        data_to_save = np.column_stack((final_detector_x_axis, smoothed_I))
        np.savetxt(output_filename, data_to_save, header=header_text, fmt='%-18.10e')
        print(f"Final detector profile saved to: {output_filename}")