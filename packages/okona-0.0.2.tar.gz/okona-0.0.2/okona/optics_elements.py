#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug  5 10:46:02 2025

@author: lraimondi
"""

import numpy as np
from scipy.stats import qmc, norm
import okona.propagator_kernel as propagator_kernel

CYTHON_AVAILABLE = False

PI = np.pi

# --- Field Resampling Function ---
def resample_field(x_in, E_in, max_points):
    if len(x_in) <= max_points:
        return x_in, E_in

    print(f"    -> Downsampling field from {len(x_in)} to {max_points} points for memory management.")
    x_out = np.linspace(x_in[0], x_in[-1], max_points)
    
    E_out_real = np.interp(x_out, x_in, np.real(E_in), left=0, right=0)
    E_out_imag = np.interp(x_out, x_in, np.imag(E_in), left=0, right=0)
    E_out = E_out_real + 1j * E_out_imag
    
    return x_out, E_out

# --- Grid Optimization Function ---
def get_required_grid_size(wavelength, distance, input_width, N_in):
    if N_in == 0 or input_width == 0:
        return 0, 0
    dx_in = input_width / N_in
    output_width = wavelength * distance / dx_in
    N_out = N_in
    return output_width, N_out

#==============================================================================
#  NEW: SOURCE FACTORY
#==============================================================================

class SourceFactory:
    """
    Handles the calculation and creation of partially coherent sources.
    This encapsulates the logic from the main script's 'calculate_source_parameters' function.
    """
    def __init__(self):
        self.fwhm_to_rms = 1 / (2 * np.sqrt(2 * np.log(2)))
        self.rms_to_fwhm = 1 / self.fwhm_to_rms

    
    def create_source(self, source_type, simulation_plane, wavelength, 
                        electron_sigma_s_h=None, electron_sigma_div_h=None, 
                        electron_sigma_s_v=None, electron_sigma_div_v=None, 
                        target_size_fwhm=None, target_divergence_fwhm=None, # <-- New Inputs
                        undulator_L=None, num_modes=1024, N=8192,
                        source_model='gsm', coherence_length=None):
        """
        Calculates source parameters and returns an instantiated Source object.
        Can work forward (e-beam -> total beam) or backward (target beam -> e-beam).
        """
        print(f"\n--- Calculating parameters for '{source_type}' source in {simulation_plane.upper()} plane ---")

        # --- REVERSE CALCULATION: From Target Photon Beam to Electron Beam ---
        if target_size_fwhm is not None and target_divergence_fwhm is not None:
            print("  - Mode: Reverse-engineering electron beam from target photon beam inputs.")
            if source_type == 'undulator' and undulator_L is None:
                raise ValueError("undulator_L must be provided for 'undulator' source type.")
                
            total_sigma_s = target_size_fwhm * self.fwhm_to_rms
            total_sigma_div = target_divergence_fwhm * self.fwhm_to_rms
            
            if source_type == 'undulator':
                photon_sigma_div = np.sqrt(wavelength / (2 * undulator_L))
                photon_sigma_s = (wavelength / (4 * np.pi * photon_sigma_div))
                
                var_e_s = total_sigma_s**2 - photon_sigma_s**2
                var_e_div = total_sigma_div**2 - photon_sigma_div**2
                
                electron_sigma_s = np.sqrt(var_e_s) if var_e_s > 0 else 0.0
                electron_sigma_div = np.sqrt(var_e_div) if var_e_div > 0 else 0.0
                
                print(f"  - Intrinsic Photon RMS size:    {photon_sigma_s*1e6:.3f} µm")
                print(f"  - Intrinsic Photon RMS div:     {photon_sigma_div*1e6:.3f} µrad")
                print(f"  -> Deduced e-beam RMS size:     {electron_sigma_s*1e6:.3f} µm")
                print(f"  -> Deduced e-beam RMS div:      {electron_sigma_div*1e6:.3f} µrad")
                
                if var_e_s < 0 or var_e_div < 0:
                    print("  *** WARNING: Target size/div is SMALLER than the intrinsic diffraction limit! E-beam set to 0. ***")

            emitter_fwhm = (wavelength / (4 * np.pi * (np.sqrt(wavelength / (2 * undulator_L))))) * self.rms_to_fwhm if source_type == 'undulator' else target_size_fwhm * 0.99
            
            # Calculate 1D Coherence Fraction (Visibility)
            phase_space_area = total_sigma_s * total_sigma_div
            diffraction_limit = wavelength / (4 * np.pi)
            coherent_fraction = min(1.0, diffraction_limit / phase_space_area) if phase_space_area > 0 else 1.0
            
            print(f"  -> 1D Coherent Fraction (Visibility): {coherent_fraction*100:.2f}%")

        # --- FORWARD CALCULATION: From Electron Beam to Total Photon Beam ---
        else:
            print("  - Mode: Forward-calculating total beam from electron beam inputs.")
            if simulation_plane == 'horizontal':
                electron_sigma_s, electron_sigma_div = electron_sigma_s_h, electron_sigma_div_h
            else:
                electron_sigma_s, electron_sigma_div = electron_sigma_s_v, electron_sigma_div_v

            if source_type == 'undulator':
                photon_sigma_div = np.sqrt(wavelength / (2 * undulator_L))
                photon_sigma_s = (wavelength / (4 * np.pi * photon_sigma_div))
                
                total_sigma_s = np.sqrt(electron_sigma_s**2 + photon_sigma_s**2)
                total_sigma_div = np.sqrt(electron_sigma_div**2 + photon_sigma_div**2)
                
                target_size_fwhm = total_sigma_s * self.rms_to_fwhm
                target_divergence_fwhm = total_sigma_div * self.rms_to_fwhm
                emitter_fwhm = photon_sigma_s * self.rms_to_fwhm
                
                print(f"  - Photon (emitter) RMS size:    {photon_sigma_s*1e6:.3f} µm")
                print(f"  - Electron beam RMS size:       {electron_sigma_s*1e6:.3f} µm")
                print(f"  -> Total (target) FWHM size:    {target_size_fwhm*1e6:.3f} µm")
                
                phase_space_area = total_sigma_s * total_sigma_div
                diffraction_limit = wavelength / (4 * np.pi)
                coherent_fraction = min(1.0, diffraction_limit / phase_space_area) if phase_space_area > 0 else 1.0
                print(f"  -> 1D Coherent Fraction (Visibility): {coherent_fraction*100:.2f}%")

            elif source_type in ['bending_magnet', 'wiggler']:
                target_size_fwhm = electron_sigma_s * self.rms_to_fwhm
                target_divergence_fwhm = electron_sigma_div * self.rms_to_fwhm
                emitter_fwhm = target_size_fwhm * 0.99
                print(f"  - Target FWHM size (e-beam):    {target_size_fwhm*1e6:.3f} µm")
                
        self.target_size_fwhm = target_size_fwhm
        self.target_divergence_fwhm = target_divergence_fwhm

        # --- Instantiate the chosen source model ---
        if source_model == 'gsm':
            source_object = GaussianSchellModelSource(
                wavelength=wavelength,
                size=target_size_fwhm,
                divergence=target_divergence_fwhm,
                num_modes=num_modes, 
                N=N,
                coherence_length=coherence_length
            )
        else:
            source_object = PartiallyCoherentSource(
                wavelength=wavelength,
                size=target_size_fwhm,
                divergence=target_divergence_fwhm,
                num_modes=num_modes, 
                emitter_fwhm=emitter_fwhm,
                N=N,
                coherence_length=coherence_length
            )
        
        config_updates = {
            'target_size_fwhm': target_size_fwhm,
            'target_divergence_fwhm': target_divergence_fwhm
        }
        
        return source_object, config_updates

#==============================================================================
#  1. SOURCE CLASSES
#==============================================================================
class PartiallyCoherentSource:
    # ... (class is unchanged from your file) ...
    """
    Models a partially coherent source using a Schell-model approximation.
    The final beam properties are a convolution of a base emitter's properties
    and the statistical distributions of position and angle offsets.
    This implementation is now physically self-consistent.
    """
    def __init__(self, wavelength, size, divergence, N=8192, grid_factor=82, num_modes=100, emitter_fwhm=5e-6, coherence_length=None):
        self.wavelength = wavelength
        self.num_modes = num_modes
        self.N = N
        self.k = 2 * np.pi / wavelength
        self.emitter_fwhm = emitter_fwhm
       

        print("--- Source Initialized (PartiallyCoherentSource) ---")
        print(f"  Target Size (FWHM): {size*1e6:.2f} µm")

        # Convert FWHM inputs to standard deviation (sigma) values
        sigma_total_pos = size / (2 * np.sqrt(2 * np.log(2)))
        sigma_total_angle = divergence / (2 * np.sqrt(2 * np.log(2)))
        
        # --- LOGIC for coherence level ---
        if coherence_length is not None:
            sigma_mu = coherence_length
            print(f"  - Using user-defined Coherence Length (sigma_mu): {sigma_mu*1e6:.3f} µm")
            # Back-calculate the implied divergence from the coherence length and size
            sigma_theta_coherent_sq = 1 / (4 * self.k**2 * sigma_total_pos**2)
            sigma_mu_inv_sq = 1 / sigma_mu**2 if sigma_mu > 1e-12 else 0
            
            sigma_theta_sq = sigma_mu_inv_sq / self.k**2 + sigma_theta_coherent_sq
            sigma_total_angle = np.sqrt(sigma_theta_sq)
            implied_divergence_fwhm = sigma_total_angle * (2 * np.sqrt(2 * np.log(2)))
            print(f"  - Implied Source Divergence (FWHM): {implied_divergence_fwhm*1e6:.2f} µrad (Input `divergence` is ignored)")
        else:
            sigma_total_angle = divergence / (2 * np.sqrt(2 * np.log(2)))
            print(f"  - Target Divergence (FWHM): {divergence*1e6:.2f} µrad")
        sigma_theta_coherent_sq = 1 / (4 * self.k**2 * sigma_total_pos**2)
        if sigma_total_angle**2 <= sigma_theta_coherent_sq:
            sigma_mu = np.inf
        else:
            sigma_mu_inv_sq = self.k**2 * (sigma_total_angle**2 - sigma_theta_coherent_sq)
            sigma_mu = 1 / np.sqrt(sigma_mu_inv_sq)
        self.sigma_mu = sigma_mu # Store the coherence length as an attribute  

        # Properties of the base emitter
        sigma_emitter_pos = emitter_fwhm / (2 * np.sqrt(2 * np.log(2)))
        # Intrinsic divergence (std dev) of the base emitter due to diffraction
        sigma_emitter_angle = wavelength / (2 * PI * sigma_emitter_pos)

       
        
        # Calculate the required variance for the position offsets
        variance_pos_offset = sigma_total_pos**2 - sigma_emitter_pos**2
        if variance_pos_offset < 0:
            raise ValueError(f"emitter_fwhm ({emitter_fwhm*1e6:.2f} µm) cannot be larger than the final desired size ({size*1e6:.2f} µm).")
        sigma_pos_offset = np.sqrt(variance_pos_offset)

        # Calculate the required variance for the angle offsets
        variance_angle_offset = sigma_total_angle**2 - sigma_emitter_angle**2
        if variance_angle_offset < 0:
            if coherence_length is not None:
                raise ValueError(f"The intrinsic divergence of the emitter ({sigma_emitter_angle*1e6:.2f} µrad) is larger than the divergence implied by the coherence length ({sigma_total_angle*1e6:.2f} µrad). Make the emitter_fwhm larger.")
            else:
                 raise ValueError(f"The intrinsic divergence of the emitter ({sigma_emitter_angle*1e6:.2f} µrad) is larger than the final desired divergence ({divergence*1e6:.2f} µrad). Make the emitter_fwhm larger to make it less divergent.")
        sigma_angle_offset = np.sqrt(variance_angle_offset)

        # Create the spatial grid
        self.x = np.linspace(-grid_factor * size, grid_factor * size, N)
        
        # Generate random offsets for each mode using a Sobol sequence for efficiency
        sampler = qmc.Sobol(d=2, scramble=True)
        sample_points = sampler.random(n=self.num_modes)
        self.position_offsets = norm.ppf(sample_points[:, 0], scale=sigma_pos_offset)
        self.angle_offsets = norm.ppf(sample_points[:, 1], scale=sigma_angle_offset)

        print(f"  Using Emitter FWHM: {emitter_fwhm*1e6:.2f} µm")

    def get_modes(self):
        """Generator for the coherent modes."""
        sigma_emitter_pos = self.emitter_fwhm / (2 * np.sqrt(2 * np.log(2)))
        E_base_field = np.exp(-self.x**2 / (2 * sigma_emitter_pos)**2)
        for i in range(self.num_modes):
            x_offset, angle_offset = self.position_offsets[i], self.angle_offsets[i]
            
            # Shift the base emitter field
            E_shifted = np.interp(self.x, self.x - x_offset, E_base_field, left=0, right=0)
            
            # Apply a phase tilt for the angle offset
            phase_tilt = np.exp(1j * self.k * self.x * np.sin(angle_offset))
            
            yield self.x, E_shifted * phase_tilt


class GaussianSchellModelSourceWigner:
    # ... (class is unchanged from your file) ...
    """
    Models a partially coherent source using the Gaussian-Schell model (GSM),
    decomposed into a deterministic sum of coherent Hermite-Gaussian modes.

    This implementation is based on the analytical method described in:
    A. M. Al-Rawashdeh, et al., "Efficient method for simulating partially
    coherent hard-x-ray-beam propagation in complex optical systems,"
    Optica 9, 842-851 (2022). (https://doi.org/10.1364/OPTICA.458888)

    This version uses a numerically stable recurrence relation to generate the
    modes, avoiding issues with direct evaluation of high-order Hermite polynomials.

    NOTE: For highly incoherent sources (large M^2 factor), a very large number
    of modes is required to accurately reconstruct the source properties. If the
    specified 'num_modes' is too low, the resulting beam will appear smaller
    and more coherent than the target.
    """
    def __init__(self, wavelength, size, divergence, N=8192, num_modes=100, grid_width_factor=25):
        """
        Initializes the source based on its physical properties.

        Args:
            wavelength (float): Wavelength of the radiation [m].
            size (float): The FWHM of the source intensity profile [m].
            divergence (float): The FWHM of the far-field divergence [rad].
            N (int): Number of points in the computational grid.
            num_modes (int): The number of Hermite-Gaussian modes to use in the decomposition.
            grid_width_factor (float): The factor determining the total grid width
                                       relative to the source FWHM size.
        """
        self.wavelength = wavelength
        self.num_modes = num_modes
        self.k = 2 * PI / wavelength
        self.N = N
        

        print("--- Source Initialized (GaussianSchellModelSource - Recurrence Method) ---")
        print(f"  - Target Source Size (FWHM): {size*1e6:.2f} µm")
        print(f"  - Target Source Divergence (FWHM): {divergence*1e6:.2f} µrad")
        print(f"  - Number of coherent modes: {self.num_modes}")

        # --- 1. Convert FWHM inputs to physical RMS values (sigma) ---
        sigma_s = size / (2 * np.sqrt(2 * np.log(2)))
        sigma_theta = divergence / (2 * np.sqrt(2 * np.log(2)))

        # --- 2. Calculate the transverse coherence length (sigma_mu) ---
        sigma_theta_coherent_sq = 1 / (4 * self.k**2 * sigma_s**2)
        if sigma_theta**2 <= sigma_theta_coherent_sq:
            print("  - Source is effectively fully coherent.")
            sigma_mu = np.inf
        else:
            sigma_mu_inv_sq = self.k**2 * (sigma_theta**2 - sigma_theta_coherent_sq)
            sigma_mu = 1 / np.sqrt(sigma_mu_inv_sq)
            print(f"  - Calculated Coherence Length (sigma_mu): {sigma_mu*1e6:.3f} µm")
        self.sigma_mu = sigma_mu    

        # --- 3. Calculate the beam quality factor (M) ---
        if np.isinf(sigma_mu):
            M_factor = 1.0
        else:
            M_factor = np.sqrt(1 + (2 * sigma_s / sigma_mu)**2)
        print(f"  - Beam Quality Factor (M): {M_factor:.3f}")
        
        M_squared = M_factor**2

        # --- 4. Calculate the mode weights (eigenvalues lambda_n) ---
        p = (M_squared - 1) / (M_squared + 1)
        mode_indices = np.arange(self.num_modes)
        
        # The eigenvalues (weights) lambda_n. The sum of these for n=0 to inf is 1.
        self.weights = (2 / (M_squared + 1)) * (p**mode_indices)
        
        # --- 5. Calculate the waist size (w_m) of the Hermite-Gaussian modes ---
        self.w_m = (2 * sigma_s) / M_factor
        print(f"  - Base Mode Waist (w_m): {self.w_m*1e6:.3f} µm")

        # --- 6. Create the final output spatial grid ---
        self.x = np.linspace(-grid_width_factor * size / 2, grid_width_factor * size / 2, N)

        # --- 7. Check for sufficient number of modes and warn the user if necessary ---
        # The average mode number provides a scale for how many modes are significant.
        n_avg = (M_squared - 1) / 2
        # A common rule of thumb is to use at least 3-4 times the average mode number
        # to capture the significant part of the mode distribution.
        suggested_modes = int(np.ceil(n_avg * 4))

        print(f"  - Calculated Average Mode Number (n_avg): {n_avg:.1f}")
        if self.num_modes < n_avg and M_factor > 1.5:
            print(f"\n  *** WARNING: INSUFFICIENT MODES FOR ACCURATE SIMULATION ***")
            print(f"  The specified number of modes ({self.num_modes}) is significantly less than the average mode number ({n_avg:.1f}).")
            print(f"  This will result in a simulated source that is much SMALLER and MORE COHERENT than the target.")
            print(f"  For an accurate representation, please increase 'num_modes' to at least {suggested_modes} or more.\n")


    def get_modes(self):
        """
        Generator that yields each coherent Hermite-Gaussian mode.

        This method uses a stable three-term recurrence relation to generate
        the Hermite-Gaussian eigenfunctions, avoiding numerical overflow that
        can occur with direct evaluation of high-order polynomials.
        """
        if self.num_modes == 0:
            return

        # Normalize the weights for the finite sum of modes being used.
        # This conserves power for the truncated mode set.
        total_power_in_model = np.sum(self.weights)
        if total_power_in_model > 1e-12:
            normalized_weights = self.weights / total_power_in_model
        else:
            normalized_weights = self.weights

        # --- Setup for Recurrence Relation ---
        # The recurrence generates the orthonormal eigenfunctions Psi_n.
        # The final mode field is E_n = sqrt(power_n) * Psi_n.
        
        # Dimensionless coordinate
        xi = np.sqrt(2) * self.x / self.w_m

        # Calculate Psi_0 (n=0 mode)
        # N0_sq = (2/pi)^(1/2) / w_m
        N0_sq = np.sqrt(2/PI) / self.w_m
        Psi_0 = np.sqrt(N0_sq) * np.exp(-self.x**2 / self.w_m**2)
        
        # Yield the first mode (n=0)
        power_0 = normalized_weights[0]
        E_0 = np.sqrt(power_0) * Psi_0
        yield self.x, E_0

        if self.num_modes == 1:
            return

        # --- Iterate to generate higher-order modes ---
        Psi_prev = Psi_0
        # Calculate Psi_1 (n=1 mode) using the first step of the recurrence
        Psi_curr = np.sqrt(2) * xi * Psi_prev

        # Yield the second mode (n=1)
        power_1 = normalized_weights[1]
        E_1 = np.sqrt(power_1) * Psi_curr
        yield self.x, E_1

        if self.num_modes == 2:
            return

        # Loop for n > 1
        for n in range(1, self.num_modes - 1):
            # Recurrence relation for orthonormal functions:
            # Psi_{n+1} = sqrt(2/(n+1)) * xi * Psi_n - sqrt(n/(n+1)) * Psi_{n-1}
            Psi_next = np.sqrt(2 / (n + 1)) * xi * Psi_curr - np.sqrt(n / (n + 1)) * Psi_prev
            
            # Yield the (n+1)th mode
            power_next = normalized_weights[n + 1]
            E_next = np.sqrt(power_next) * Psi_next
            yield self.x, E_next
            
            # Update for the next iteration
            Psi_prev = Psi_curr
            Psi_curr = Psi_next


class GaussianSchellModelSource:
    """
    Models a partially coherent source using the Gaussian-Schell model (GSM),
    decomposed into a deterministic sum of coherent Hermite-Gaussian modes.

    This implementation is based on the analytical method described in:
    A. M. Al-Rawashdeh, et al., "Efficient method for simulating partially
    coherent hard-x-ray-beam propagation in complex optical systems,"
    Optica 9, 842-851 (2022).
    """
    def __init__(self, wavelength, size, divergence, N=8192, num_modes='auto', grid_width_factor=25, coherence_length=None):
        self.wavelength = wavelength
        self.k = 2 * np.pi / wavelength
        self.N = N

        print("--- Source Initialized (GaussianSchellModelSource) ---")
        print(f"  - Target Source Size (FWHM): {size*1e6:.2f} µm")

        # Convert FWHM to sigma (RMS)
        sigma_s = size / (2 * np.sqrt(2 * np.log(2)))

        # Handle Coherence Length Calculation
        if coherence_length is not None:
            self.sigma_mu = coherence_length
            print(f"  - Using user-defined Coherence Length (sigma_mu): {self.sigma_mu*1e6:.3f} µm")
            sigma_theta_coherent_sq = 1 / (4 * self.k**2 * sigma_s**2)
            sigma_mu_inv_sq = 1 / self.sigma_mu**2 if self.sigma_mu > 1e-12 else 0
            sigma_theta_sq = sigma_mu_inv_sq / self.k**2 + sigma_theta_coherent_sq
            sigma_theta = np.sqrt(sigma_theta_sq)
            implied_divergence = sigma_theta * (2 * np.sqrt(2 * np.log(2)))
            print(f"  - Implied Source Divergence (FWHM): {implied_divergence*1e6:.2f} µrad (Input `divergence` is ignored)")
        else:
            print(f"  - Target Source Divergence (FWHM): {divergence*1e6:.2f} µrad")
            sigma_theta = divergence / (2 * np.sqrt(2 * np.log(2)))
            sigma_theta_coherent_sq = 1 / (4 * self.k**2 * sigma_s**2)
            
            if sigma_theta**2 <= sigma_theta_coherent_sq:
                print("  - Source is effectively fully coherent.")
                self.sigma_mu = np.inf
            else:
                sigma_mu_inv_sq = self.k**2 * (sigma_theta**2 - sigma_theta_coherent_sq)
                self.sigma_mu = 1 / np.sqrt(sigma_mu_inv_sq)
                print(f"  - Calculated Coherence Length (sigma_mu): {self.sigma_mu*1e6:.3f} µm")

        # Beam Quality Factor (M)
        if np.isinf(self.sigma_mu):
            M_factor = 1.0
        else:
            M_factor = np.sqrt(1 + (2 * sigma_s / self.sigma_mu)**2)
        print(f"  - Beam Quality Factor (M): {M_factor:.3f}")
        
        M_squared = M_factor**2
        
        # --- NEW AUTO-MODE LOGIC ---
        n_avg = (M_squared - 1) / 2
        print(f"  - Calculated Average Mode Number (n_avg): {n_avg:.1f}")
        
        if num_modes == 'auto' or num_modes is None:
            suggested_modes = max(1, int(np.ceil(n_avg * 4)))
            self.num_modes = suggested_modes
            print(f"  -> AUTO-SETTING number of coherent modes to: {self.num_modes}")
        else:
            self.num_modes = int(num_modes)
            print(f"  - Number of coherent modes: {self.num_modes}")
            suggested_modes = max(1, int(np.ceil(n_avg * 4)))
            if self.num_modes < n_avg and M_factor > 1.5:
                print(f"\n  *** WARNING: INSUFFICIENT MODES FOR ACCURATE SIMULATION ***")
                print(f"  The specified number of modes ({self.num_modes}) is less than the average mode number ({n_avg:.1f}).")
                print(f"  This will result in a simulated source that is much SMALLER and MORE COHERENT than the target.")
                print(f"  For an accurate representation, increase 'num_modes' to at least {suggested_modes} or more.\n")
        
        # Calculate Mode Weights (eigenvalues) using the resolved self.num_modes
        p = (M_squared - 1) / (M_squared + 1)
        mode_indices = np.arange(self.num_modes)
        self.weights = (2 / (M_squared + 1)) * (p**mode_indices)
        
        self.w_m = (2 * sigma_s) / M_factor
        print(f"  - Base Mode Waist (w_m): {self.w_m*1e6:.3f} µm")

        # Output spatial grid
        self.x = np.linspace(-grid_width_factor * size / 2, grid_width_factor * size / 2, N)
    def get_modes(self):
        """
        Generator yielding each coherent Hermite-Gaussian mode using a numerically 
        stable three-term recurrence relation.
        """
        if self.num_modes == 0:
            return

        total_power_in_model = np.sum(self.weights)
        if total_power_in_model > 1e-12:
            normalized_weights = self.weights / total_power_in_model
        else:
            normalized_weights = self.weights

        xi = np.sqrt(2) * self.x / self.w_m
        N0_sq = np.sqrt(2 / np.pi) / self.w_m
        
        # Base Mode (n=0)
        Psi_0 = np.sqrt(N0_sq) * np.exp(-self.x**2 / self.w_m**2)
        power_0 = normalized_weights[0]
        E_0 = np.sqrt(power_0) * Psi_0
        yield self.x, E_0

        if self.num_modes == 1:
            return

        # First Order Mode (n=1)
        Psi_prev = Psi_0
        Psi_curr = np.sqrt(2) * xi * Psi_prev
        power_1 = normalized_weights[1]
        E_1 = np.sqrt(power_1) * Psi_curr
        yield self.x, E_1

        if self.num_modes == 2:
            return

        # Higher Order Modes (n > 1) via recurrence
        for n in range(1, self.num_modes - 1):
            Psi_next = np.sqrt(2 / (n + 1)) * xi * Psi_curr - np.sqrt(n / (n + 1)) * Psi_prev
            power_next = normalized_weights[n + 1]
            E_next = np.sqrt(power_next) * Psi_next
            yield self.x, E_next
            
            # Shift states for next iteration
            Psi_prev = Psi_curr
            Psi_curr = Psi_next

#==============================================================================
#  2. PROPAGATORS
#==============================================================================
class FreeSpacePropagator:
    # ... (class is unchanged from your file) ...
    """
    Propagates a field using the Angular Spectrum Method (ASM).
    This is more accurate than the Fresnel approximation for a wider range of distances.
    """
    def __init__(self, wavelength, distance):
        self.wavelength = wavelength
        self.distance = distance
        self.k = 2 * np.pi / wavelength

    def propagate(self, x_in, E_in, x_out_required=None):
        N_in = len(x_in)
        if N_in == 0:
            if x_out_required is not None:
                return x_out_required, np.zeros_like(x_out_required, dtype=complex)
            return np.array([]), np.array([])
            
        dx_in = x_in[1] - x_in[0] if N_in > 1 else 1e-9

        # The output grid for ASM has the same spacing as the input grid
        if x_out_required is None:
            x_out_required = x_in
        
        # --- Angular Spectrum Method Implementation ---
        E_freq = np.fft.fft(E_in)
        fx = np.fft.fftfreq(N_in, d=dx_in)
        kz = np.lib.scimath.sqrt(self.k**2 - (2 * np.pi * fx)**2)
        H = np.exp(1j * kz * self.distance)
        E_out_propagated = np.fft.ifft(E_freq * H)

        if x_out_required is not x_in and not np.array_equal(x_out_required, x_in):
             E_out_real = np.interp(x_out_required, x_in, np.real(E_out_propagated), left=0, right=0)
             E_out_imag = np.interp(x_out_required, x_in, np.imag(E_out_propagated), left=0, right=0)
             E_out = E_out_real + 1j * E_out_imag
        else:
            E_out = E_out_propagated
            x_out_required = x_in

        return x_out_required, E_out

class HuygensFresnelPropagator:
    # ... (class is unchanged from your file) ...
    """
    Propagates a field by using the compiled Cython kernel for the
    Huygens-Fresnel integral. Falls back to a slow Python implementation
    if the Cython module is not compiled.
    """
    def __init__(self, wavelength, distance):
        self.wavelength = wavelength
        self.distance = distance
        self.k = 2 * np.pi / wavelength

    def propagate(self, x_in, E_in, x_out):
        """
        Args:
            x_in (np.ndarray): Input coordinate grid.
            E_in (np.ndarray): Input complex field.
            x_out (np.ndarray): Output coordinate grid.
        """
        if CYTHON_AVAILABLE:
            # --- Use the fast Cython kernel ---
            # Ensure arrays are C-contiguous for Cython
            x_in = np.ascontiguousarray(x_in, dtype=np.float64)
            E_in = np.ascontiguousarray(E_in, dtype=np.complex128)
            x_out = np.ascontiguousarray(x_out, dtype=np.float64)
            
            E_out = propagator_kernel.huygens_kernel(x_in, E_in, x_out, self.k, self.distance)
            return x_out, E_out
        else:
            # --- Fallback to the original slow Python implementation ---
            print("    -> Executing SLOW Python Huygens-Fresnel propagation...")
            dx_in = x_in[1] - x_in[0]
            E_out = np.zeros_like(x_out, dtype=complex)
            
            # This loop is the bottleneck that Cython replaces
            for i, x_out_i in enumerate(x_out):
                r = np.sqrt(self.distance**2 + (x_out_i - x_in)**2)
                integrand = E_in * np.exp(1j * self.k * r) / r
                E_out[i] = np.sum(integrand)

            prefactor = (1 / (1j * self.wavelength))
            return x_out, E_out * prefactor * dx_in
        
class RayTracingPropagator:
    """
    Performs a 1D ray-tracing simulation through a defined beamline.
    This represents the geometric optics limit (lambda -> 0).
    """
    def __init__(self, beamline_config, source_fwhm, source_div_fwhm, num_rays=2**16):
        self.beamline_config = beamline_config
        self.num_rays = num_rays
        self.source_fwhm = source_fwhm
        self.source_div_fwhm = source_div_fwhm
        self.history = []

    def _generate_rays_from_source(self):
        sigma_s = self.source_fwhm / (2 * np.sqrt(2 * np.log(2)))
        sigma_theta = self.source_div_fwhm / (2 * np.sqrt(2 * np.log(2)))
        rng = np.random.default_rng()
        initial_positions = rng.normal(loc=0, scale=sigma_s, size=self.num_rays)
        initial_angles = rng.normal(loc=0, scale=sigma_theta, size=self.num_rays)
        return np.vstack((initial_positions, initial_angles))

    def run(self, x_source, E_source):
        rays = self._generate_rays_from_source()
        self.history.append({'name': 'Source', 'rays': rays.copy(), 'element_object': OpticalElement(name='Source')})

        for el_config in self.beamline_config['elements']:
            element = el_config['element_object']
            distance = el_config['distance']
            rays[0, :] += rays[1, :] * distance

            if isinstance(element, (PlaneMirror, EllipticalMirror)):
                if not hasattr(element, 'phase_error_profile') or element.phase_error_profile is None:
                    continue

                # --- NEW: Robust Analytical Slope Extraction ---
                k_wave = 2 * np.pi / self.beamline_config['wavelength']
                E_phase = element.phase_error_profile['phase']
                mirror_axis = element.phase_error_profile['x']
                
                # Calculate the complex derivative dE/dx
                dE_dx = np.gradient(E_phase, mirror_axis)
                
                # Analytically extract phase derivative d(phi)/dx bypassing phase wraps
                # d(phi)/dx = Im( E_phase_conjugate * dE/dx )
                dphi_dx = np.imag(np.conj(E_phase) * dE_dx)
                
                # Physical relation: d(phi)/dx = -2 * k * sin(theta) * (dh/dx)
                mirror_slope = dphi_dx / (-2 * k_wave * np.sin(element.angle))
                # -----------------------------------------------

                x_mirror_coord = rays[0, :] / np.sin(element.angle)
                
                # Mask for rays physically hitting the mirror
                on_mirror_mask = np.abs(x_mirror_coord) <= (element.length / 2)
                
                if isinstance(element, EllipticalMirror):
                    if element.p > 0 and element.q > 0:
                        f_eff = 1.0 / (1.0 / element.p + 1.0 / element.q)
                        rays[1, on_mirror_mask] -= rays[0, on_mirror_mask] / f_eff

                # Strict Boundary Check: Mask for rays hitting the *measured* area of the mirror
                measured_min, measured_max = mirror_axis[0], mirror_axis[-1]
                on_measured_mask = (x_mirror_coord >= measured_min) & (x_mirror_coord <= measured_max) & on_mirror_mask

                # Rays outside the measured area but on the physical mirror get absorbed to prevent ghost peaks
                rays[:, on_mirror_mask & ~on_measured_mask] = np.nan

                # Apply slopes ONLY to rays hitting the measured profile
                local_slopes = np.interp(x_mirror_coord[on_measured_mask], mirror_axis, mirror_slope)
                rays[1, on_measured_mask] += 2 * local_slopes
                
                # Rays missing the mirror entirely get absorbed
                rays[:, ~on_mirror_mask] = np.nan

            elif isinstance(element, Slit):
                on_slit_mask = np.abs(rays[0, :]) <= (element.slit_width / 2)
                rays[:, ~on_slit_mask] = np.nan
            
            # Filter out all absorbed rays to keep array compact
            rays = rays[:, ~np.isnan(rays[0,:])]
            self.history.append({'name': element.name, 'rays': rays.copy(), 'element_object': element})
        
        return self._convert_history_to_field_format()

    def _convert_history_to_field_format(self):
        field_history = []
        for step in self.history:
            rays = step['rays']
            element = step['element_object']

            # Enforce a deterministic grid based on the element's existing x-axis to align parallel runs
            if hasattr(element, 'x') and element.x is not None and len(element.x) > 1:
                x_centers = element.x
                dx = x_centers[1] - x_centers[0]
                # Reconstruct histogram bin edges from the known centers
                x_grid = np.append(x_centers - dx/2, x_centers[-1] + dx/2)
            else:
                # Fallback for elements without a defined grid (like the source)
                x_grid = np.linspace(-5e-3, 5e-3, 16385) 
                x_centers = (x_grid[:-1] + x_grid[1:]) / 2

            if rays.shape[1] > 1:
                # Calculate intensity using strict histogram bins
                intensity, _ = np.histogram(rays[0,:], bins=x_grid)
                E_field = np.sqrt(intensity.astype(np.float64))
            else:
                E_field = np.zeros_like(x_centers)

            field_history.append({
                'name': step['name'], 'x': x_centers, 'E': E_field, 'element_object': element
            })
            
        return field_history, {}

#==============================================================================
#  3. OPTICAL ELEMENTS
#==============================================================================
class OpticalElement:
    
    def __init__(self, name='element'):
        self.name = name
    def apply(self, x, E_in, **kwargs):
        return x, E_in

class Slit(OpticalElement):
    
    def __init__(self, slit_width, name='slit'):
        super().__init__(name=name)
        self.slit_width = slit_width
        self.x = np.linspace(-slit_width, slit_width, 2048)
    def apply(self, x, E_in, **kwargs):
        transmission = (np.abs(x) <= self.slit_width / 2).astype(float)
        return x, E_in * transmission

class PlaneMirror(OpticalElement):
    # ... (class is unchanged from your file) ...
    def __init__(self, length, angle, name='plane_mirror', phase_error_profile=None):
        super().__init__(name=name)
        self.length = length
        self.angle = angle
        self.phase_error_profile = phase_error_profile
        
        if self.phase_error_profile and 'x' in self.phase_error_profile:
            mirror_axis = self.phase_error_profile['x']
        else:
            mirror_axis = np.linspace(-self.length / 2, self.length / 2, 4096)
        self.x = mirror_axis * np.sin(self.angle)
        
    def apply(self, x, E_in, **kwargs):
        x_mirror = x / np.sin(self.angle)
        transmission = (np.abs(x_mirror) <= self.length / 2).astype(float)
        
        total_phase_multiplier = np.ones_like(x, dtype=complex)
        
        if self.phase_error_profile is not None:
            idx_mirror = np.where(transmission == 1)[0]
            if len(idx_mirror) > 0:
                error_phase = np.interp(x_mirror[idx_mirror],
                                        self.phase_error_profile['x'],
                                        self.phase_error_profile['phase'])
                total_phase_multiplier[idx_mirror] *= error_phase
                
        E_out = E_in * transmission * total_phase_multiplier
        
        return x, E_out

class EllipticalMirror(OpticalElement):
    
    def __init__(self, p_distance, q_distance, length, angle, name='elliptical_mirror', phase_error_profile=None):
        super().__init__(name=name)
        self.p = p_distance 
        self.q = q_distance
        self.length = length
        self.angle = angle
        self.phase_error_profile = phase_error_profile

        if self.phase_error_profile and 'x' in self.phase_error_profile:
            mirror_axis = self.phase_error_profile['x']
        else:
            mirror_axis = np.linspace(-self.length / 2, self.length / 2, 8192)
        self.x = mirror_axis * np.sin(self.angle)

    def apply(self, x, E_in, wavelength):
        k = 2 * PI / wavelength
        f_eff = 1.0 / (1.0 / self.p + 1.0 / self.q) if self.p > 0 and self.q > 0 else 1e10
        x_mirror = x / np.sin(self.angle)
        
        transmission = (np.abs(x_mirror) <= self.length / 2).astype(float)
        
        total_phase_multiplier = np.ones_like(x, dtype=complex)
        
        idx_mirror = np.where(transmission == 1)[0]
        if len(idx_mirror) > 0:
            ideal_phase = np.exp(-1j * k * x[idx_mirror]**2 / (2 * f_eff))
            total_phase_multiplier[idx_mirror] *= ideal_phase
            
            if self.phase_error_profile is not None:
                error_phase = np.interp(x_mirror[idx_mirror],
                                        self.phase_error_profile['x'],
                                        self.phase_error_profile['phase'])
                total_phase_multiplier[idx_mirror] *= error_phase

        E_out = E_in * transmission * total_phase_multiplier
        
        return x, E_out

#==============================================================================
#  4. DETECTOR
#==============================================================================
class Detector(OpticalElement):
    # ... (class is unchanged from your file) ...
    def __init__(self, width, N, name='detector'):
        super().__init__(name=name)
        self.width = width
        self.N = N
        self.x = np.linspace(-width/2, width/2, N)
    def measure(self, x_in, E_in):
        E_resampled_real = np.interp(self.x, x_in, np.real(E_in), left=0, right=0)
        E_resampled_imag = np.interp(self.x, x_in, np.imag(E_in), left=0, right=0)
        E_resampled = E_resampled_real + 1j * E_resampled_imag
        intensity = np.abs(E_resampled)**2
        return self.x, intensity

#==============================================================================
#  5. OLD SAMPLING CLASS
#==============================================================================
class Sampling:
   
    """
    Calculates the required number of sampling points for an optical element
    based on the propagation physics.
    """
    def get_number_of_points(self, current_element, distance_to_next, wavelength, previous_element=None):
        """
        Computes the suggested number of points for the current element's grid.
        """
        default_N = 4096
        aperture = self._get_aperture(current_element)
        element_length = self._get_length(current_element)

        if isinstance(current_element, Detector) and isinstance(previous_element, (PlaneMirror, EllipticalMirror)):
            prev_aperture = self._get_aperture(previous_element)
            if prev_aperture == 0: return default_N
            min_step = (wavelength * distance_to_next) / (prev_aperture * 2 * PI)
        else:
            if aperture == 0: return default_N
            min_step = (wavelength * distance_to_next) / (aperture * 2 * PI)

        if min_step == 0: return default_N
        N = int(np.ceil(element_length / min_step))*1
        if N <= 0: return default_N
        return max(default_N, N)

    def _get_aperture(self, element):
        """Helper function to get the effective aperture of an element."""
        if isinstance(element, (PlaneMirror, EllipticalMirror)):
            return element.length * np.sin(element.angle)
        elif isinstance(element, Slit):
            return element.slit_width
        elif isinstance(element, Detector):
            return element.width
        return 0

    def _get_length(self, element):
        """Helper function to get the physical length/width for the grid calculation."""
        if isinstance(element, (PlaneMirror, EllipticalMirror)):
            return element.length * np.sin(element.angle)
        elif isinstance(element, Slit):
            return element.slit_width
        elif isinstance(element, Detector):
            return element.width
        return 0

#==============================================================================
#  5. NEW SAMPLING CLASS (FIXED)
#==============================================================================
class NewSampling:
   
    """
    Calculates the required number of sampling points for an optical element's
    grid based on a forward-looking physical model.
    """
    def get_required_input_points(self, current_element, next_element, distance, wavelength):
        default_N = 4096

        # 1. Get the projected aperture of the NEXT element (A_next)
        A_next = self._get_aperture(next_element)
        if A_next <= 1e-9:
            return default_N

        # 2. Get the sine of the incident angle of the CURRENT element
        sin_alpha_current = 1.0  # Default for non-mirror elements
        if isinstance(current_element, (PlaneMirror, EllipticalMirror)):
            if np.sin(current_element.angle) > 1e-9:
                sin_alpha_current = np.sin(current_element.angle)
            else:
                return default_N

        # 3. Calculate the minimum required step size for the current grid (dx_current)
        denominator = (2 * PI * A_next * sin_alpha_current)
        if denominator == 0:
            return default_N
        
        # Actually define min_step ---
        min_step = (wavelength * distance) / denominator
        
        min_step_phase = np.inf
        if isinstance(current_element, EllipticalMirror) and current_element.p > 0 and current_element.q > 0:
            f_eff = 1.0 / (1.0 / current_element.p + 1.0 / current_element.q)
            
            # Phase aliasing depends on the APERTURE, not the physical length! ---
            current_aperture = self._get_aperture(current_element)
            if current_aperture > 0:
                min_step_phase = (wavelength * f_eff) / current_aperture

        # Use whichever step size is STRICTER (smaller)
        final_min_step = min(min_step, min_step_phase)

        # 4. Get the physical transverse length of the CURRENT element grid
        # --- FIX 3: The grid must span the APERTURE, not the physical mirror length ---
        L_current = self._get_aperture(current_element)
        if L_current == 0:
            # Fallback for Source
            L_current = 10e-3 # 10 mm default source grid width

        # 5. Calculate the total number of points required
        N = int(np.ceil(L_current / final_min_step))
        
        # Enforce a higher absolute minimum N when dealing with steep surface errors
        return max(8192, N)

    def _get_aperture(self, element):
        """Helper function to get the effective (projected) aperture of an element."""
        if isinstance(element, (PlaneMirror, EllipticalMirror)):
            return element.length * np.sin(element.angle)
        elif isinstance(element, Slit):
            return element.slit_width
        elif isinstance(element, Detector):
            return element.width
        return 0

    def _get_length(self, element):
        """
        Helper function to get the physical length for the grid calculation.
        (Note: Unused in the fixed version, but kept for compatibility).
        """
        if isinstance(element, (PlaneMirror, EllipticalMirror)):
            return element.length
        elif isinstance(element, Slit):
            return element.slit_width
        elif isinstance(element, Detector):
            return element.width
        elif hasattr(element, 'name') and element.name == 'Source':
            return 0
        return 0
#==============================================================================
#  6. SURFACE SCATTERING MODELS
#==============================================================================

class SmoothSurfaceApproximation(OpticalElement):
    # ... (class is unchanged from your file) ...
    """
    Models the effect of surface roughness on specular reflection using the
    Debye-Waller factor, as described in the smooth surface limit.

    This element attenuates the amplitude of the electric field to account for
    intensity lost to diffuse scattering from a rough surface. The attenuation
    is based on the RMS roughness of the surface, the wavelength, and the
    grazing incidence angle.

    This is based on the formula for specular reflectivity from a rough surface:
    R_specular = R_smooth * exp( - (4 * pi * sigma * sin(theta) / lambda)^2 )

    The electric field is attenuated by the square root of this factor.
    """
    def __init__(self, name, wavelength, angle_rad, height_profile_m):
        """
        Initializes the smooth surface scattering element.

        Args:
            name (str): A descriptive name for the element.
            wavelength (float): The wavelength of the radiation [m].
            angle_rad (float): The grazing incidence angle [radians].
            height_profile_m (np.ndarray): A 1D numpy array of the total surface
                                           height errors (figure + roughness) [m].
        """
        super().__init__(name=name)
        self.wavelength = wavelength
        self.angle_rad = angle_rad
        self.height_profile = height_profile_m

        # Calculate the RMS roughness (sigma) from the provided height profile.
        if self.height_profile is None or len(self.height_profile) == 0:
            self.sigma_rms = 0.0
        else:
            self.sigma_rms = np.std(self.height_profile)

        # Calculate the argument of the Debye-Waller exponential (often called 'g')
        # g = (4 * pi * sigma * sin(theta) / lambda)^2
        if self.sigma_rms > 1e-12 and np.sin(self.angle_rad) > 1e-9:
            g = (4 * np.pi * self.sigma_rms * np.sin(self.angle_rad) / self.wavelength)**2
        else:
            g = 0.0

        # The intensity is attenuated by exp(-g). The electric field is attenuated
        # by the square root of that, which is exp(-g/2).
        self.attenuation_factor = np.exp(-g / 2.0)

        print(f"--- {self.name} Initialized (SmoothSurfaceApproximation) ---")
        print(f"  - Surface RMS Height (sigma): {self.sigma_rms * 1e9:.3f} nm")
        print(f"  - Field Attenuation Factor: {self.attenuation_factor:.4f}")


    def apply(self, x, E_in, **kwargs):
        """
        Applies the attenuation to the incoming electric field.

        Args:
            x (np.ndarray): The coordinate grid.
            E_in (np.ndarray): The complex electric field.

        Returns:
            tuple: The coordinate grid and the attenuated complex electric field.
        """
        # This element does not change the beam's coordinates, it only reduces its amplitude.
        return x, E_in * self.attenuation_factor