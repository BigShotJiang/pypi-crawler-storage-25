#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  3 09:20:27 2025

@author: lraimondi
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import cumulative_trapezoid

class SurfaceManager:
    """
    Manages the creation and handling of mirror surface error profiles,
    including figure errors and micro-roughness from PSD data.
    """
    def __init__(self, wavelength):
        self.wavelength = wavelength
        self.k = 2 * np.pi / wavelength

    def load_figure_error(self, filepath):
        try:
            print(f"Loading figure error from: {filepath}")
            data = np.loadtxt(filepath)
            position = data[:, 0]
            height = data[:, 1]
            position -= position.mean()
            print(f"Successfully loaded figure error.")
            return position, height
        except Exception as e:
            print(f"Warning: Could not load figure error file '{filepath}': {e}")
            return None, None

    @staticmethod
    def _generate_profile_from_psd_core(frequencies, psd):
        if len(frequencies) < 2:
            return np.array([0]), np.array([0])
        df = np.mean(np.diff(frequencies))
        if df <= 0:
            return np.array([0]), np.array([0])
        length_um = 1.0 / df
        n_total = int(np.ceil(frequencies[-1] / df)) * 2
        full_fx = np.fft.fftfreq(n_total, d=length_um / n_total)
        positive_fx = full_fx[1:n_total//2]
        interp_psd_nm2_um = np.interp(positive_fx, frequencies, psd, left=0, right=0)
        unscaled_amplitudes = np.sqrt(interp_psd_nm2_um)
        rng = np.random.default_rng()
        random_phases = rng.uniform(0, 2 * np.pi, len(positive_fx))
        fourier_spectrum_unscaled = np.zeros(n_total, dtype=complex)
        fourier_spectrum_unscaled[1:n_total//2] = unscaled_amplitudes * np.exp(1j * random_phases)
        fourier_spectrum_unscaled[n_total//2 + 1:] = np.conj(fourier_spectrum_unscaled[1:n_total//2][::-1])
        height_profile_unscaled = np.fft.ifft(fourier_spectrum_unscaled).real * n_total
        target_variance_nm2 = np.sum(interp_psd_nm2_um * df)
        target_rms_nm = np.sqrt(target_variance_nm2)
        current_rms = np.std(height_profile_unscaled)
        if current_rms > 1e-9:
            scale_factor = target_rms_nm / current_rms
            height_profile_nm = height_profile_unscaled * scale_factor
        else:
            height_profile_nm = np.zeros(n_total)
        position_profile_um = np.linspace(-length_um / 2, length_um / 2, n_total, endpoint=False)
        return height_profile_nm, position_profile_um

  
    def generate_roughness_from_psd(self, psd_filepath, mirror_length, num_points=None, verbose=True):
        if verbose:
            print(f"\n--- Generating FULL non-tiled roughness for mirror length {mirror_length} m from PSD file: {psd_filepath} ---")
        try:
            psd_data = np.loadtxt(psd_filepath)
        except Exception as e:
            if verbose: print(f"Error: Could not load PSD file '{psd_filepath}': {e}")
            return None, None

        # 1. Parse the input PSD file
        wavelengths_um, psd_values_nm2_um = psd_data[:, 0], psd_data[:, 1]
        valid = (wavelengths_um > 0) & (psd_values_nm2_um >= 0)
        frequencies_um_inv = 1 / wavelengths_um[valid]
        psd_values_nm2_um = psd_values_nm2_um[valid]
        
        # Sort by frequency to ensure interpolation works correctly
        sort_indices = np.argsort(frequencies_um_inv)
        sorted_frequencies, sorted_psd = frequencies_um_inv[sort_indices], psd_values_nm2_um[sort_indices]

        # 2. Set up the spatial grid for the FULL mirror length
        final_num_points = int(num_points) if num_points is not None else 2**16
        if final_num_points % 2 != 0:
            final_num_points += 1 # Ensure N is even for clean FFT operations
            
        position_m = np.linspace(-mirror_length / 2.0, mirror_length / 2.0, final_num_points, endpoint=False)
        mirror_length_um = mirror_length * 1e6
        dx_um = mirror_length_um / final_num_points

        # 3. Create a new, fine frequency grid representing the whole mirror
        # The lowest frequency here will naturally be 1 / mirror_length
        f_grid = np.fft.rfftfreq(final_num_points, d=dx_um)

        # 4. Interpolate the loaded PSD onto this new, full-mirror frequency grid
        interp_psd = np.interp(f_grid, sorted_frequencies, sorted_psd, left=0, right=0)

        # 5. Generate random phases and apply the PSD amplitudes
        rng = np.random.default_rng()
        random_phases = rng.uniform(0, 2 * np.pi, len(f_grid))
        
        spectrum = np.sqrt(interp_psd) * np.exp(1j * random_phases)
        spectrum[0] = 0.0 # Remove any DC offset (piston error)
        
        # 6. Inverse FFT to get the continuous spatial profile across the whole mirror
        height_unscaled = np.fft.irfft(spectrum, n=final_num_points)

        # 7. Scale the generated profile to exactly match the target RMS variance of the input PSD
        target_variance_nm2 = np.trapezoid(sorted_psd, sorted_frequencies) 
        target_rms_nm = np.sqrt(target_variance_nm2) if target_variance_nm2 > 0 else 0.0
        
        current_rms = np.std(height_unscaled)
        if current_rms > 1e-12:
            height_nm = height_unscaled * (target_rms_nm / current_rms)
        else:
            height_nm = np.zeros_like(height_unscaled)

        height_m = height_nm * 1e-9

        if verbose:
            print(f"-> Generated full continuous roughness profile with {len(position_m)} points and RMS: {np.std(height_m)*1e9:.3f} nm")

        return position_m, height_m

    def get_total_error_profile(self, mirror_axis, figure_error_data=None, roughness_data=None, verbose=True):
        if verbose:
            print("\n--- Combining profiles onto a common axis ---")
        total_error = np.zeros_like(mirror_axis)
        if figure_error_data and figure_error_data[0] is not None:
            pos, height = figure_error_data
            total_error += np.interp(mirror_axis, pos, height, left=0, right=0)
            if verbose: print("Added figure error to total profile.")
        if roughness_data and roughness_data[0] is not None:
            pos, height = roughness_data
            total_error += np.interp(mirror_axis, pos, height, left=0, right=0)
            if verbose: print("Added roughness to total profile.")
        if len(total_error) > 0 and verbose:
            total_rms_nm = np.std(total_error) * 1e9
            print(f"-> Total combined profile RMS: {total_rms_nm:.3f} nm")
        return total_error

    def get_phase_error(self, height_profile, grazing_angle_rad):
        opd = 2 * height_profile * np.sin(grazing_angle_rad)
        phase_shift = -(2 * np.pi / self.wavelength) * opd
        return np.exp(1j * phase_shift)

    def get_phase_error(self, height_profile, grazing_angle_rad):
        """
        Converts a height error profile into a complex phase error array.
        """
        opd = 2 * height_profile * np.sin(grazing_angle_rad)
        phase_shift = -self.k * opd
        return np.exp(1j * phase_shift)
    
    def filter_profile_by_wavelength(self, position_m, height_m, cutoff_wavelength_m):
        """
        Applies a low-pass filter to a surface profile using an FFT.

        This removes spatial frequencies corresponding to wavelengths shorter
        than the specified cutoff wavelength.

        Args:
            position_m (np.ndarray): The 1D array of surface positions [m].
            height_m (np.ndarray): The 1D array of surface heights [m].
            cutoff_wavelength_m (float): The cutoff spatial wavelength [m]. All
                                         wavelengths shorter than this will be
                                         removed.

        Returns:
            np.ndarray: The new, filtered height profile in meters.
        """
        if cutoff_wavelength_m is None or not np.isfinite(cutoff_wavelength_m) or cutoff_wavelength_m <= 0:
            # If no valid cutoff is given, return the original profile
            return height_m

        print(f"  -> Applying low-pass filter with cutoff wavelength: {cutoff_wavelength_m * 1e3:.2f} mm")

        n_points = len(position_m)
        if n_points < 2:
            return height_m

        # Perform the FFT on the height profile
        fft_profile = np.fft.fft(height_m)
        
        # Calculate the spatial frequencies for the FFT
        sampling_interval = np.mean(np.diff(position_m))
        fft_freqs = np.fft.fftfreq(n_points, d=sampling_interval)

        # The cutoff frequency is the reciprocal of the cutoff wavelength
        cutoff_frequency = 1.0 / cutoff_wavelength_m

        # Create a boolean mask to zero out the high frequencies.
        # We apply the filter to both positive and negative frequencies.
        fft_profile[np.abs(fft_freqs) > cutoff_frequency] = 0

        # Perform the inverse FFT to get the filtered profile
        filtered_height_m = np.fft.ifft(fft_profile).real

        # --- Verification ---
        original_rms = np.std(height_m) * 1e9
        filtered_rms = np.std(filtered_height_m) * 1e9
        print(f"     - Profile RMS changed from {original_rms:.3f} nm to {filtered_rms:.3f} nm.")

        return filtered_height_m
    
    def calculate_psd_from_profile(self, position_m, height_m):
        n_points = len(height_m)
        if n_points < 2: return np.array([]), np.array([])
        sampling_interval = np.mean(np.diff(position_m))
        fft_height = np.fft.fft(height_m)
        psd_2sided = (sampling_interval / n_points) * np.abs(fft_height)**2
        frequencies = np.fft.fftfreq(n_points, d=sampling_interval)
        positive_freq_mask = frequencies > 0
        freqs_1sided = frequencies[positive_freq_mask]
        psd_1sided = 2 * psd_2sided[positive_freq_mask]
        sort_indices = np.argsort(freqs_1sided)
        return freqs_1sided[sort_indices], psd_1sided[sort_indices]

    
    def get_cutoff_for_target_rms(self, frequencies_m_inv, psd_values_m3, target_rms_m):
        """
        Calculates the spatial cutoff wavelength based on the RMS of the removed,
        high-frequency portion of the spectrum.

        Args:
            frequencies_m_inv (np.ndarray): Array of spatial frequencies [1/m].
            psd_values_m3 (np.ndarray): Array of PSD values [m^3].
            target_rms_m (float): The target RMS for the high-frequency part [m].

        Returns:
            float: The corresponding high-pass cutoff spatial wavelength [m],
                   or a special value (inf or 0) if the condition cannot be met.
        """
        if target_rms_m is None or target_rms_m <= 0 or len(frequencies_m_inv) < 2:
            return None
            
        sort_indices = np.argsort(frequencies_m_inv)
        sorted_freqs, sorted_psd = frequencies_m_inv[sort_indices], psd_values_m3[sort_indices]
        
        # --- Correct Physical Model ---
        # The integral of the PSD from a cutoff frequency (fc) to infinity should
        # equal the target variance.
        # integral[fc to inf] (PSD) = target_variance
        # This is equivalent to:
        # integral[0 to inf] (PSD) - integral[0 to fc] (PSD) = target_variance
        # So, the variance of the part we KEEP is:
        # integral[0 to fc] (PSD) = total_variance - target_variance

        cumulative_variance = cumulative_trapezoid(sorted_psd, sorted_freqs, initial=0)
        total_variance = cumulative_variance[-1]
        target_variance = target_rms_m**2

        if target_variance >= total_variance:
            # The required RMS of the scattered part is larger than or equal to the
            # total RMS of the entire surface. This means the surface is already
            # perfectly smooth according to the criterion. All defects should be
            # kept (i.e., filtered out), so we use a zero-error profile.
            # We return a cutoff of 0 as a special flag for this case.
            return 0.0

        # Calculate the variance of the low-frequency part we want to keep.
        variance_of_kept_part = total_variance - target_variance
        
        # Find the cutoff frequency by interpolating on the cumulative variance.
        try:
            cutoff_frequency = np.interp(variance_of_kept_part, cumulative_variance, sorted_freqs)
        except Exception:
            return None

        # The cutoff wavelength is the reciprocal of the cutoff frequency.
        return 1.0 / cutoff_frequency if cutoff_frequency > 0 else np.inf


    

def main():
    """
    Example usage of the SurfaceManager class to load, generate, and combine profiles.
    """
    print("--- Surface Profile Combination Script ---")
    
    figure_error_file = "figure_error_profile.txt"
    psd_file = "microroughness_psd.txt"
    mirror_length = 0.64
    xray_wavelength = 1.54e-10
    num_points_final = 2**16

    surface_gen = SurfaceManager(wavelength=xray_wavelength)
    
    figure_error_data = surface_gen.load_figure_error(figure_error_file)
    
    roughness_data = surface_gen.generate_roughness_from_psd(
        psd_filepath=psd_file,
        mirror_length=mirror_length
    )

    mirror_axis = np.linspace(-mirror_length / 2, mirror_length / 2, num_points_final)
    total_error_m = surface_gen.get_total_error_profile(
        mirror_axis=mirror_axis,
        figure_error_data=figure_error_data,
        roughness_data=roughness_data
    )

    if total_error_m is not None and len(total_error_m) > 0:
        print("\nPlotting the results...")
        plt.style.use('seaborn-v0_8-whitegrid')
        fig, ax = plt.subplots(figsize=(12, 6))
        
        ax.plot(mirror_axis * 1e3, total_error_m * 1e9, color='rebeccapurple', label='Total Combined Error')
        
        if figure_error_data[0] is not None:
            fig_pos_m, fig_h_m = figure_error_data
            ax.plot(fig_pos_m * 1e3, fig_h_m * 1e9, color='gray', linestyle='--', alpha=0.7, label='Original Figure Error')

        ax.set_title(f"Combined Surface Error Profile for {mirror_length*1e3:.0f} mm Mirror")
        ax.set_xlabel("Position along mirror (mm)")
        ax.set_ylabel("Height Error (nm)")
        ax.legend()
        
        rms_val = np.std(total_error_m) * 1e9
        ax.text(0.05, 0.95, f"Total RMS = {rms_val:.3f} nm", transform=ax.transAxes,
                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        plt.tight_layout()
        plt.show()
    else:
        print("\nCould not generate a final profile. Skipping plot.")


if __name__ == "__main__":
    main()
