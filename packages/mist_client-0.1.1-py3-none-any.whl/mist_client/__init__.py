"""
MIST Client: CLI client for the MIST mission control system.

This package provides both a command-line interface and a Python library for
downloading telemetry data from Yamcs.
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("mist-client")
except PackageNotFoundError:
    # Package not installed, use fallback
    __version__ = "0.0.0.dev0"

from .telemetry_downloader import TelemetryDownloader, Telemetry

__all__ = ["TelemetryDownloader", "Telemetry"]
