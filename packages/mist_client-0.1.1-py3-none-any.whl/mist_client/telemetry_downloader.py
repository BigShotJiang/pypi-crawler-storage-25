"""
Telemetry downloader for Yamcs.

This module provides the TelemetryDownloader class for retrieving telemetry
data from a Yamcs instance.
"""

import struct
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional, Tuple

from yamcs.client import YamcsClient


# CCSDS and PUS TM header constants
CCSDS_HEADER_SIZE = 6  # bytes 0-5
PUS_SECONDARY_HEADER_SIZE = 8  # bytes 6-13
PUS_TM_HEADER_SIZE = CCSDS_HEADER_SIZE + PUS_SECONDARY_HEADER_SIZE  # 14 bytes total
PUS_TM_CHECKSUM_SIZE = 2  # 2 bytes at end of packet (not included in data length)

# Bit positions in CCSDS header
APID_BIT_OFFSET = 5
APID_BIT_LENGTH = 11


@dataclass
class BlockMetadata:
    """
    Metadata for an incomplete defragmented block.

    Attributes:
        block_name: Yamcs packet name (e.g., "/PUS/HOUSEKEEPING")
        last_seen_time: UTC timestamp when the last fragment was received
        tail_count: Expected number of fragments minus one (last fragment index)
    """

    block_name: str
    last_seen_time: datetime
    tail_count: int

    @classmethod
    def from_yamcs_metadata(cls, metadata: dict) -> "BlockMetadata":
        """
        Create BlockMetadata from Yamcs object metadata.

        Args:
            metadata: Dictionary with blockName, lastSeenTimestamp, tailCount

        Returns:
            BlockMetadata instance

        Raises:
            ValueError: If metadata is invalid
        """
        block_name = metadata.get('blockName')
        last_seen_timestamp = metadata.get('lastSeenTimestamp')
        tail_count = metadata.get('tailCount')

        if not all([block_name, last_seen_timestamp is not None, tail_count is not None]):
            raise ValueError("Invalid metadata: missing required fields")

        last_seen_time = datetime.fromtimestamp(int(last_seen_timestamp), tz=timezone.utc)

        return cls(
            block_name=block_name,
            last_seen_time=last_seen_time,
            tail_count=int(tail_count),
        )


@dataclass
class Telemetry:
    """
    Represents a telemetry packet or defragmented block.

    Attributes:
        apid: Application Process ID (11-bit value)
        packet_name: Yamcs packet name (e.g., "/PUS/HOUSEKEEPING")
        time: Generation timestamp
        data: Telemetry source data (headers stripped)
        holes: List of (start, end) byte ranges for missing fragments (empty if complete)
    """

    apid: int
    packet_name: str
    time: datetime
    data: bytes
    holes: List[Tuple[int, int]]

    def is_complete(self) -> bool:
        """Check if this telemetry has no missing fragments."""
        return len(self.holes) == 0


class TelemetryDownloader:
    """
    Downloads telemetry data from a Yamcs instance.

    This class provides methods to retrieve telemetry packets from Yamcs,
    including support for defragmented blocks. It can return telemetry data
    as Python objects for programmatic use, or save them to disk.

    Args:
        url: Yamcs server URL (e.g., 'localhost:8090')
        instance: Yamcs instance name
        tls: Use TLS for the connection (default: False)

    Example:
        >>> from datetime import datetime, timedelta, timezone
        >>> td = TelemetryDownloader(url="localhost:8090", instance="mist")
        >>> now = datetime.now(tz=timezone.utc)
        >>> start = now - timedelta(hours=1)
        >>> telemetries = td.get_telemetry(
        ...     packet_name="/PUS/HOUSEKEEPING",
        ...     start=start,
        ...     stop=now
        ... )
        >>> for tm in telemetries:
        ...     print(f"APID={tm.apid}, packet={tm.packet_name}, data_len={len(tm.data)}")
    """

    def __init__(self, url: str = "localhost:8090", instance: str = "mist", tls: bool = False, fragments_bucket: str = "mist-fragments"):
        """
        Initialize the telemetry downloader.

        Args:
            url: Yamcs server URL
            instance: Yamcs instance name
            tls: Use TLS for the connection (default: False)
            fragments_bucket: Bucket name for incomplete fragments (default: mist-fragments)
        """
        self.url = url
        self.tls = tls
        self.instance = instance
        self.fragments_bucket = fragments_bucket
        self.client = YamcsClient(url, tls=tls)
        self.archive = self.client.get_archive(instance=self.instance)
        self.storage = self.client.get_storage_client()

    def get_telemetry(
        self,
        packet_name: str,
        start: Optional[datetime] = None,
        stop: Optional[datetime] = None,
        defrag: Optional[str] = None,
    ) -> List[Telemetry]:
        """
        Retrieve telemetry packets from Yamcs.

        Args:
            packet_name: Yamcs packet name (e.g., "/PUS/HOUSEKEEPING")
            start: Start time (inclusive). If None, uses all available data.
            stop: Stop time (exclusive). If None, uses all available data.
            defrag: Defragmentation mode:
                - None: Return packets as-is
                - "complete": Return only complete defragmented blocks (Yamcs auto-defragments)
                - "all": Return complete blocks + incomplete blocks from fragments bucket

        Returns:
            List of Telemetry objects with headers stripped (source data only)

        Raises:
            ValueError: If defrag mode is invalid
        """
        if defrag and defrag not in ("complete", "all"):
            raise ValueError(f"Invalid defrag mode: {defrag}. Must be 'complete' or 'all'")

        telemetries = []

        # Download completed telemetry packets
        for packet in self.archive.stream_packets(name=packet_name, start=start, stop=stop):
            tm = self._packet_to_telemetry(packet, packet_name)
            telemetries.append(tm)

        # If defrag="all", also retrieve incomplete blocks from mist-fragments bucket
        if defrag == "all":
            incomplete = self._get_incomplete_fragments(packet_name, start, stop)
            telemetries.extend(incomplete)

        return telemetries

    def _packet_to_telemetry(self, packet, packet_name: str) -> Telemetry:
        """
        Convert a Yamcs packet to a Telemetry object.

        Args:
            packet: Yamcs packet object with binary data
            packet_name: Yamcs packet name (e.g., "/PUS/HOUSEKEEPING")

        Returns:
            Telemetry object with headers stripped, or None if packet is invalid
        """
        # Get the raw binary packet data
        raw_data = packet.binary

        if len(raw_data) < PUS_TM_HEADER_SIZE + PUS_TM_CHECKSUM_SIZE:
            # Packet too small, skip
            raise ValueError(f"Packet too small to contain valid PUS TM data: {len(raw_data)} bytes")

        # Parse APID from bits 5-15 (across bytes 0-1)
        # Byte 0: [version(3) | type(1) | secondary_header_flag(1) | apid_high(3)]
        # Byte 1: [apid_low(8)]
        apid_high = raw_data[0] & 0x07  # Lower 3 bits of byte 0
        apid_low = raw_data[1]
        apid = (apid_high << 8) | apid_low

        # Get generation time from packet metadata
        generation_time = packet.generation_time

        # Strip the PUS TM header (14 bytes) and checksum (2 bytes) to get source data
        source_data = raw_data[PUS_TM_HEADER_SIZE:-PUS_TM_CHECKSUM_SIZE]

        return Telemetry(
            apid=apid,
            packet_name=packet_name,
            time=generation_time,
            data=source_data,
            holes=[],
        )

    def _read_block_metadata(self, bucket, block_key: str) -> BlockMetadata:
        """
        Read metadata for an incomplete block from the bucket.

        Args:
            bucket: Yamcs bucket object
            block_key: Block key prefix (e.g., "b100_5/")

        Returns:
            BlockMetadata instance

        Raises:
            ValueError: If metadata cannot be read
        """
        meta_object_name = block_key + "meta"
        
        # The python client does not expose metadata for bucket objects, so we'll send a custom request through its context
        scheme = "https" if self.tls else "http"
        api_path = f"{scheme}://{self.url}/api/storage/buckets/{self.fragments_bucket}/objectInfo/{meta_object_name}"
        response = self.client.ctx.session.get(api_path)
        obj_data = response.json()
        
        # Extract metadata from the response
        if 'metadata' not in obj_data:
            raise ValueError(f"No metadata found in API response for {meta_object_name}")
        
        return BlockMetadata.from_yamcs_metadata(obj_data['metadata'])

    def _get_incomplete_fragments(
        self,
        packet_name: str,
        start: Optional[datetime],
        stop: Optional[datetime],
    ) -> List[Telemetry]:
        """
        Retrieve incomplete defragmented blocks from fragments bucket.

        Filters blocks by packet name and time range using metadata before assembly.

        Args:
            packet_name: Packet name to filter by (e.g., "/PUS/HOUSEKEEPING")
            start: Start time filter (inclusive)
            stop: Stop time filter (exclusive)

        Returns:
            List of Telemetry objects for incomplete blocks with holes filled
        """
        incomplete_telemetries = []

        try:
            bucket = self.storage.get_bucket(self.fragments_bucket)
        except Exception:
            # Bucket doesn't exist or can't be accessed
            return incomplete_telemetries

        # List all objects to find block directories
        listing = bucket.list_objects()

        # Group fragments by block key (b{apid}_{blockId}/)
        block_keys = set()
        for obj in listing.objects:
            # Object names like: b100_5/f00, b100_5/f01, b100_5/meta
            parts = obj.name.split("/")
            if len(parts) == 2 and parts[0].startswith("b"):
                block_keys.add(parts[0] + "/")

        # Process each incomplete block
        for block_key in block_keys:
            try:
                # Read metadata FIRST to filter before assembling
                metadata = self._read_block_metadata(bucket, block_key)

                # Filter by packet name (strict match)
                if metadata.block_name != packet_name:
                    continue

                # Filter by time range
                if start and metadata.last_seen_time < start:
                    continue
                if stop and metadata.last_seen_time >= stop:
                    continue

                # Passed filters - assemble the block
                tm = self._assemble_incomplete_block(bucket, block_key, metadata)
                incomplete_telemetries.append(tm)
            except Exception as e:
                # Skip blocks that can't be assembled
                print(f"Warning: Failed to process block {block_key}: {e}")
                continue

        return incomplete_telemetries

    def _assemble_incomplete_block(self, bucket, block_key: str, metadata: BlockMetadata) -> Telemetry:
        """
        Assemble an incomplete block from fragments in the bucket.

        Args:
            bucket: Yamcs bucket object
            block_key: Block key prefix (e.g., "b100_5/")
            metadata: Block metadata with packet name, timestamp, and tail count

        Returns:
            Telemetry object for the incomplete block
        """
        # Parse APID and block ID from block key (format: b{apid}_{blockId}/)
        key_without_slash = block_key.rstrip("/")
        if not key_without_slash.startswith("b"):
            raise ValueError(f"Invalid block key format: {block_key}")

        parts = key_without_slash[1:].split("_")
        if len(parts) != 2:
            raise ValueError(f"Invalid block key format: {block_key}")

        try:
            apid = int(parts[0])
            block_id = int(parts[1])
        except ValueError:
            raise ValueError(f"Invalid block key format: {block_key}")

        # Use metadata for tail count, packet name, and generation time
        expected_count = metadata.tail_count + 1

        # List all fragments for this block
        fragment_listing = bucket.list_objects(prefix=block_key + "f")
        fragments = {}

        for obj in fragment_listing.objects:
            fragment_name = obj.name
            if not fragment_name.startswith(block_key + "f"):
                raise ValueError(f"Invalid fragment name format: {fragment_name}")

            # Parse fragment number from name (e.g., "b100_5/f00" -> 0)
            fragment_num_str = fragment_name[len(block_key) + 1 :]  # Skip "b100_5/f"
            try:
                fragment_num = int(fragment_num_str)
            except ValueError:
                raise ValueError(f"Invalid fragment name format: {fragment_name}")

            # Download fragment data (already unwrapped, no 3-byte header)
            fragment_data = bucket.download_object(fragment_name)
            fragments[fragment_num] = fragment_data

        if not fragments:
            raise ValueError(f"No fragments found for block {block_key}, expected at least one")

        # Determine fragment data size (all fragments except last should be same size)
        fragment_sizes = [len(data) for data in fragments.values()]
        fragment_data_size = fragment_sizes[0]

        # Check if we have the last fragment
        if metadata.tail_count in fragments:
            last_fragment_size = len(fragments[metadata.tail_count])
            block_size = fragment_data_size * metadata.tail_count + last_fragment_size
        else:
            # Assume last fragment is same size as others
            block_size = fragment_data_size * expected_count

        # Assemble block data and detect holes
        block_data = bytearray(block_size)
        holes = []

        for i in range(expected_count):
            offset = i * fragment_data_size

            if i in fragments:
                # Fragment present - copy data
                data = fragments[i]
                block_data[offset : offset + len(data)] = data
            else:
                # Fragment missing - record hole and fill with dummy data
                if i == metadata.tail_count:
                    # Last fragment might be smaller
                    end_offset = block_size
                else:
                    end_offset = offset + fragment_data_size

                holes.append((offset, end_offset - 1))
                self._fill_hole(block_data, offset, end_offset - 1)

        return Telemetry(
            apid=apid,
            packet_name=metadata.block_name,
            time=metadata.last_seen_time,
            data=bytes(block_data),
            holes=holes,
        )

    def _fill_hole(self, data: bytearray, start: int, end: int) -> None:
        """
        Fill a hole in the data with a repeating pattern.

        The pattern is 8 bytes: 4 bytes for start offset, 4 bytes for end offset
        (big-endian encoding), matching Defragmenter.java behavior.

        Args:
            data: Data buffer to fill
            start: Start byte offset of the hole
            end: End byte offset of the hole (inclusive)
        """
        # Fill with 8-byte pattern: start(4) + end(4) in big-endian
        for i in range(start, end + 1):
            pattern_offset = i % 8
            if pattern_offset < 4:
                # First 4 bytes: start offset
                byte_val = (start >> (8 * (3 - pattern_offset))) & 0xFF
            else:
                # Last 4 bytes: end offset
                byte_val = (end >> (8 * (7 - pattern_offset))) & 0xFF
            data[i] = byte_val
