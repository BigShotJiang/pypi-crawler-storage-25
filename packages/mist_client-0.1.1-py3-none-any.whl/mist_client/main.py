"""
Command-line interface for mist-client.

Provides commands for downloading telemetry from the mission control system.
"""

import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import click
from dateutil import parser as date_parser

from . import __version__
from .telemetry_downloader import TelemetryDownloader


@click.group()
@click.version_option(version=__version__, prog_name="mist-cli")
def cli():
    """
    MIST Client - Download telemetry from the mission control system.

    \b
    Examples:
      # Download housekeeping telemetry from the last hour
      mist-cli tm get -p "/PUS/HOUSEKEEPING" -f /tmp/telemetry
    \b
      # Download with specific time range
      mist-cli tm get -p "/PUS/TC_VERIFICATION" -a "2026-03-26T00:00:00" -b "2026-03-27T00:00:00" -f ./output
    \b
      # Download with defragmentation (all blocks including incomplete)
      mist-cli tm get -p "/PUS/Large_Data" --defrag all -f ./fragments
    """
    pass


@cli.group()
def tm():
    """Telemetry operations."""
    pass


@tm.command(name="list")
@click.option(
    "--url",
    default="localhost:8090",
    help="Yamcs server URL (default: localhost:8090)",
)
def list_packets(url):
    """
    List available telemetry packet formats from Yamcs MDB.

    Environment variables:
      YAMCS_INSTANCE: Yamcs instance name (default: mist)

    Shows the packet names that can be used with the 'get' command.

    \b
    Example:
      mist-cli tm list
    """
    try:
        downloader = TelemetryDownloader(
            url=url,
            instance=os.environ.get("YAMCS_INSTANCE", "mist"),
            fragments_bucket=os.environ.get("YAMCS_FRAGMENTS_BUCKET", "mist-fragments")
        )
        mdb = downloader.client.get_mdb(instance=downloader.instance)
    except Exception as e:
        click.echo(f"Error connecting to Yamcs: {e}", err=True)
        sys.exit(1)

    click.echo(f"Telemetry packets in Yamcs instance '{downloader.instance}':\n")

    try:
        # Get space systems to organize packets
        space_systems = {}
        
        # List all containers (packets) from the MDB
        archive = downloader.archive
        packet_names = list(archive.list_packet_names())
        
        if not packet_names:
            click.echo("No telemetry packets found in MDB")
            return

        # Group by space system (prefix before /)
        for name in sorted(packet_names):
            if "/" == name[0]:
                space_system, packet = name[1:].split("/", 1)
            else:
                raise ValueError(f"Invalid packet name '{name}' (expected format '/SpaceSystem/PacketName')")
            
            if space_system not in space_systems:
                space_systems[space_system] = []
            space_systems[space_system].append(packet)

        # Display organized list
        for space_system in sorted(space_systems.keys()):
            click.echo(f"[{space_system}]")
            for packet in sorted(space_systems[space_system]):
                full_name = f"/{space_system}/{packet}" if space_system != "(root)" else packet
                click.echo(f"  {full_name}")
            click.echo()

        click.echo(f"Total: {len(packet_names)} packet(s)")
        click.echo("\nUse these names with: mist-cli tm get -p <PACKET_NAME> -f <FOLDER>")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@tm.command()
@click.option(
    "-p",
    "--packet-name",
    required=True,
    help="Yamcs packet name (e.g., '/PUS/HOUSEKEEPING')",
)
@click.option(
    "-a",
    "--after",
    default=None,
    help='Start time (inclusive). ISO format or relative (e.g., "2026-03-26T00:00:00"). Defaults to 24 hours ago.',
)
@click.option(
    "-b",
    "--before",
    default=None,
    help='Stop time (exclusive). ISO format (e.g., "2026-03-27T00:00:00"). Defaults to now.',
)
@click.option(
    "-f",
    "--folder",
    required=True,
    type=click.Path(file_okay=False, dir_okay=True, path_type=Path),
    help="Output folder for telemetry files",
)
@click.option(
    "--defrag",
    type=click.Choice(["complete", "all"], case_sensitive=False),
    default=None,
    help="Defragmentation mode: 'complete' for only complete blocks, 'all' for complete + incomplete",
)
@click.option(
    "--url",
    default="localhost:8090",
    help="Yamcs server URL (default: localhost:8090)",
)
def get(packet_name, after, before, folder, defrag, url):
    """
    Download telemetry packets from Yamcs.

    Telemetry files are saved with PUS TM headers and checksum stripped (14 byte header removed and 2 byte checksum removed).
    Files are named: {id}_{apid}_{packet_name}_{timestamp}.tm (id is zero-padded to 5 digits)

    Environment variables:
      YAMCS_INSTANCE: Yamcs instance name (default: mist)
      YAMCS_FRAGMENTS_BUCKET: Fragments bucket name (default: mist-fragments)

    When using `--defrag all`, incomplete blocks may be downloaded with missing fragments (holes). For these files:
    - Holes are filled with a repeating 8-byte pattern: 4 bytes start offset + 4 bytes end offset (big-endian)
    - A `.holes` file is created listing all missing byte ranges

    \b
    Examples:
      # Download last hour of housekeeping
      mist-cli tm get -p "/PUS/HOUSEKEEPING" -f /tmp/telemetry
    \b
      # Download specific time range
      mist-cli tm get -p "/PUS/TC_VERIFICATION" \\
        -a "2026-03-26T00:00:00" -b "2026-03-27T00:00:00" -f ./output
    \b
      # Download with defragmentation
      mist-cli tm get -p "/PUS/Large_Data" --defrag all -f ./fragments
    """
    # Parse time arguments
    try:
        if after:
            start_time = date_parser.parse(after)
            # Ensure timezone-aware
            if start_time.tzinfo is None:
                start_time = start_time.replace(tzinfo=timezone.utc)
        else:
            # Default to 24 hours ago
            start_time = datetime.now(tz=timezone.utc) - timedelta(hours=24)

        if before:
            stop_time = date_parser.parse(before)
            # Ensure timezone-aware
            if stop_time.tzinfo is None:
                stop_time = stop_time.replace(tzinfo=timezone.utc)
        else:
            # Default to now
            stop_time = datetime.now(tz=timezone.utc)

    except Exception as e:
        click.echo(f"Error parsing time: {e}", err=True)
        sys.exit(1)

    # Validate time range
    if start_time >= stop_time:
        click.echo("Error: Start time must be before stop time", err=True)
        sys.exit(1)

    # Create downloader
    try:
        downloader = TelemetryDownloader(
            url=url,
            instance=os.environ.get("YAMCS_INSTANCE", "mist"),
            fragments_bucket=os.environ.get("YAMCS_FRAGMENTS_BUCKET", "mist-fragments")
        )
    except Exception as e:
        click.echo(f"Error connecting to Yamcs: {e}", err=True)
        sys.exit(1)

    # Display parameters
    click.echo(f"Downloading telemetry from Yamcs:")
    click.echo(f"  Instance: {downloader.instance}")
    click.echo(f"  URL: {url}")
    click.echo(f"  Packet: {packet_name}")
    click.echo(f"  Start: {start_time.isoformat()}")
    click.echo(f"  Stop: {stop_time.isoformat()}")
    if defrag:
        click.echo(f"  Defrag: {defrag}")
    click.echo()

    # Download telemetry
    try:
        with click.progressbar(
            length=0, label="Downloading packets", show_eta=False, show_percent=False
        ) as bar:
            telemetries = downloader.get_telemetry(
                packet_name=packet_name, start=start_time, stop=stop_time, defrag=defrag
            )
            bar.update(1)

        click.echo(f"Retrieved {len(telemetries)} telemetry packets")

        if not telemetries:
            click.echo("No telemetry found in the specified time range")
            return

        # Count complete vs incomplete
        complete_count = sum(1 for tm in telemetries if tm.is_complete())
        incomplete_count = len(telemetries) - complete_count

        if incomplete_count > 0:
            click.echo(
                f"  Complete: {complete_count}, Incomplete: {incomplete_count}"
            )

        # Save to disk
        click.echo(f"\nSaving to {folder}...")
        file_count = save_telemetry(telemetries, str(folder))
        click.echo(f"✓ Wrote {file_count} files")

        if incomplete_count > 0:
            click.echo(
                f"\nNote: {incomplete_count} files have holes (see .holes files for details)"
            )

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

def save_telemetry(telemetries, output_folder):
    """
    Save telemetry data to files on disk.

    Files are named: {id}_{apid}_{packet_name}_{timestamp}.tm
    where id is zero-padded to 5 digits,
    packet_name is sanitized (leading slash removed, remaining slashes replaced with underscores)
    and timestamp is in format: yyyy-MM-ddTHH.mm.ssZ

    Args:
        telemetries: List of Telemetry objects to save
        output_folder: Directory path to save files

    Returns:
        Number of files written

    Raises:
        OSError: If output folder can't be created or files can't be written
    """
    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    file_count = 0
    for i, tm in enumerate(telemetries):
        # Format timestamp in UTC: 2026-03-27T15:30:45 -> 2026-03-27T15.30.45Z
        # Ensure we're working in UTC timezone for consistency with Yamcs
        time_utc = tm.time.astimezone(timezone.utc)
        timestamp_str = time_utc.strftime("%Y-%m-%dT%H.%M.%SZ")

        # Sanitize packet name for filename: /PUS/HOUSEKEEPING -> PUS_HOUSEKEEPING
        safe_packet_name = tm.packet_name.lstrip("/").replace("/", "_")

        # Create filename
        filename = f"{i:05d}_{tm.apid}_{safe_packet_name}_{timestamp_str}.tm"
        filepath = os.path.join(output_folder, filename)

        # Write source data (headers already stripped)
        with open(filepath, "wb") as f:
            f.write(tm.data)

        file_count += 1

        # If there are holes, write a .holes file with hole information
        if tm.holes:
            holes_filename = f"{filename}.holes"
            holes_filepath = os.path.join(output_folder, holes_filename)
            with open(holes_filepath, "w") as f:
                f.write(f"Incomplete block with {len(tm.holes)} hole(s):\n")
                for start, end in tm.holes:
                    f.write(f"  [{start:6d} - {end:6d}] ({end - start + 1} bytes)\n")

    return file_count


if __name__ == "__main__":
    cli()
