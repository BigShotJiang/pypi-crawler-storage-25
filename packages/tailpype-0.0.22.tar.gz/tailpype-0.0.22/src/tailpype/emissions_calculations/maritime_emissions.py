"""
This module provides functionality for the calculation of emissions from seafaring vessels. Much of it is based on
the NOx Technical Code (NTC) of the IMO, which provides a standardized method for calculating NOx emissions from
marine engines.
"""

import numpy as np


def humidity_correction(intermediate_air_cooler: bool, h_a: float, t_a: float, t_sc: float=None,
                        t_scref: float=None) -> \
        float:

    if intermediate_air_cooler:
        if any([x_ is None for x_ in [t_sc, t_scref]]):
            raise ValueError('Charge air temperature T_SC and charge air temperature at each mode point corresponding'
                             'to a seawater temperature of 25°C T_SCRef is required for compression ignition engines '
                             'with intermediate air cooler !')
        k_hd = 1 / (1.0 - 0.012 * (h_a - 10.71) + 0.00275 * (t_a - 298.0) + 0.00285 * (t_sc - t_scref))
    else:
        k_hd = 1 / (1.0 - 0.0182 * (h_a - 10.71) + 0.0045 * (t_a - 298.0))

    return k_hd


def q_mew_carbon_balance_method(q_mf : float, co2_d: float, co_d: float, hc_w: float,
                                co2_ad: float=0.0003, h_a: float=0.0) -> float:
    """
    'Carbon balance, 1-step calculation procedure' acc. to ISO 8178-4:2020(E).
    :param q_mf:
    :param co2_d:
    :param co_d:
    :param hc_w:
    :param co2_ad:
    :param h_a:
    :return:
    """

    # TODO: Implement that fuel properties are accepted as input
    mass_ratios = {
        'alpha': 0.136,  # mass hydrogen ratio (H/C)
        'beta': 0.862,  # mass carbon ratio (C/C)
        'gamma': 0.0,  # mass sulphur ratio (S/C)
        'delta': 0.0,  # mass nitrogen ratio (N/C)
        'epsilon': 0.0  # mass oxygen ratio (O/C)
    }  # cf. NTC 2008 6.4.11.1 - Distillate fuel oil; 'gamma' has been added for the sake of completeness

    mass_ratios = {
        'alpha': 13.45 / 100,  # mass hydrogen ratio (H/C)
        'beta': 86.50 / 100,  # mass carbon ratio (C/C)
        'gamma': 0.05 / 100,  # mass sulphur ratio (S/C)
        'delta': 0.00 / 100,  # mass nitrogen ratio (N/C)
        'epsilon': 0.00 / 100  # mass oxygen ratio (O/C)
    }  # ISO 8178

    w_alf = mass_ratios['alpha'] * 100
    w_bet = mass_ratios['beta'] * 100
    w_gam = mass_ratios['gamma'] * 100
    w_del = mass_ratios['delta'] * 100
    w_eps = mass_ratios['epsilon'] * 100

    f_fd = -0.055586 * w_alf + 0.008002 * w_del + 0.0070046 * w_eps
    f_c = (co2_d - co2_ad) * 0.5441 + co_d / 18522.0 + hc_w / 17355.0

    q_mew = 1.4 * (w_bet * w_bet)
    q_mew = q_mew / (((1.4 * w_bet) / f_c + (w_alf * 0.08936) - 1.0) * 1.0 / 1.293 + f_fd)
    q_mew = q_mew / (f_c * f_c)
    q_mew = q_mew + (w_alf * 0.08936) - 1.0
    q_mew = q_mew * (1 + h_a / 1000.0) + 1.0
    q_mew = q_mew * q_mf

    return q_mew


def q_mew_carbon_balance_method_array(x_array: np.ndarray) -> float:
    """
    
    :param x_array:
    :return: 
    """
    
    return q_mew_carbon_balance_method(q_mf=x_array[0], co2_d=x_array[1], co_d=x_array[2],
                                       hc_w=x_array[3], co2_ad=x_array[4], h_a=x_array[5])
