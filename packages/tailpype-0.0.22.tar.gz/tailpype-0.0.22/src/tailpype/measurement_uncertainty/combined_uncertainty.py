"""
TODO: Refer to GUM1995!
"""

import inspect
import numpy as np
import sympy

from scipy.differentiate import jacobian
from typing import Any, Callable


# ----------------------------------------------------------------------------------------------------------------------
# classes

class Function:

    def __init__(self, name: str, function: Callable, x_0: dict[str, float], u_2: dict[str, float] = None):
        """

        :param name:
        :param function:
        :param x_0: Dictionary of evaluation points (values of the variables of the function). For the keys use the
        variable names as strings. Make sure that for every variable a value is given.
        :param u_2: Dictionary of uncertainties (variances of the variables of the function. For the keys use the
        variable names as strings. Make sure that for every variable an uncertainty is given. Use 0.0 if there is no
        (relevant) uncertainty related to this variable.
        """

        # Input check
        self.variables = list(inspect.signature(function).parameters.keys())
        if any([u_ < 0.0 for u_ in u_2.values()]):
            raise 'Uncertainties must not be negative !'
        if len(u_2) != len(self.variables):
            raise 'For every variable an uncertainty has to be given. Use 0.0 if the value is known exactly.'

        print('Creating new Function object.', flush=True)

        self.name = name
        self.function = function
        self.x_0 = x_0
        self.u_2 = u_2
        self.variables_symb = sympy.symbols(self.variables)
        self.function_diff_1 = {}
        self.function_diff_2 = {}
        self.function_diff_1_lambda = {}
        self.function_diff_2_lambda = {}
        self.rel_cond = {}
        self.rel_cond_lambda = {}
        self.combined_uncertainty = 0.0

        for var_1 in self.variables_symb:

            print('Calculating 1st derivative with respect to {}.'.format(var_1), flush=True)
            self.function_diff_1[str(var_1)] = sympy.simplify(sympy.diff(self.function(*self.variables_symb), var_1))
            self.function_diff_1_lambda[str(var_1)] =\
                sympy.lambdify([*self.variables_symb], self.function_diff_1[str(var_1)], 'numpy')

            self.function_diff_2[str(var_1)] = {}
            self.function_diff_2_lambda[str(var_1)] = {}
            for var_2 in self.variables_symb:

                print('Calculating 2nd derivative with respect to {} and {}.'.format(var_1, var_2), flush=True)
                self.function_diff_2[str(var_1)][str(var_2)] =\
                    sympy.simplify(sympy.diff(self.function_diff_1[str(var_1)], var_2))
                self.function_diff_2_lambda[str(var_1)][str(var_2)] = \
                    sympy.lambdify([*self.variables_symb], self.function_diff_2[str(var_1)][str(var_2)], 'numpy')

            print('Calculating relative condition number with respect to {}.'.format(var_1), flush=True)
            self.rel_cond[str(var_1)] =\
                abs(self.function_diff_1[str(var_1)]) * abs(var_1) / abs(self.function(*self.variables_symb))
            self.rel_cond_lambda[str(var_1)] =\
                sympy.lambdify([*self.variables_symb], self.rel_cond[str(var_1)], 'numpy')

            # This part relies on that the 2nd derivative with respect to var_1 is already known. So be careful when
            # making changes.
            self.combined_uncertainty +=\
                abs(self.function_diff_1_lambda[str(var_1)](**self.x_0)) ** 2 * u_2[str(var_1)]


    def get_first_derivatives(self) -> tuple[dict[str, str], dict[str, Any], dict[str, float]]:

        return self.function_diff_1_lambda,\
            self.function_diff_1_lambda,\
            {str(var_): self.function_diff_1_lambda[str(var_)](**self.x_0) for var_ in self.variables_symb}

    def get_second_derivatives(self) -> tuple[dict[str, float], dict[str, Any], dict[str, float]]:

        return self.function_diff_2,\
            self.function_diff_2_lambda,\
            {str(var_): self.function_diff_2_lambda[str(var_)](**self.x_0) for var_ in self.variables_symb}

    def get_relative_condition_number(self) -> tuple[dict[str, float], dict[str, Any], dict[str, float]]:

        return self.rel_cond,\
            self.rel_cond_lambda,\
            {str(var_): self.rel_cond_lambda[str(var_)](**self.x_0) for var_ in self.variables_symb}

    def get_combined_uncertainty(self) -> float:

        return self.combined_uncertainty


def combined_uncertainty_gum1995(f: Callable, x0: np.ndarray, u2: np.ndarray) -> np.ndarray:

    jacobian_mtx = jacobian(f, np.asarray(x0, dtype=float)).df

    u2_combined = (jacobian_mtx**2) @ np.array(u2).reshape(-1, 1)

    return u2_combined


if __name__ == '__main__':

    def f_test(x: np.ndarray):

        c_species, molar_mass_species, molar_mass_balance, c_f, flow_mix, flow_n2 = x

        # https://products.bronkhorst.com/media/jxen4aix/917022-manual-general-instructions-digital-laboratory-style-and-in-flow.pdf

        res_conc = (flow_mix * c_f * c_species / molar_mass_species) /\
                   (flow_mix * c_f * c_species / molar_mass_species +
                    flow_mix * c_f * (1.0 - c_species) / molar_mass_balance +
                    flow_n2 / 22.4) * 1.0e6

        return res_conc

    x_0 = np.array([0.05, 32.042, 18.01528, 1.028, 20.0, 900.0])
    u2 = (x_0 * 0.02)**2

    f_res = f_test(x_0)
    f_u2 = combined_uncertainty_gum1995(f_test, x_0, u2)

    import src.tailpype.emissions_calculations.maritime_emissions as maritime_emissions

    fun_test = maritime_emissions.q_mew_carbon_balance_method_array
    res_ = combined_uncertainty_gum1995(fun_test,
                                        np.array([1000.0, 9.0, 500, 100.0, 0.0003, 1.0]),
                                        np.array([1000.0, 9.0, 500, 100.0, 0.0003, 1.0]) * 0.02)  # 2.0%

    print('DEBUG point !')
