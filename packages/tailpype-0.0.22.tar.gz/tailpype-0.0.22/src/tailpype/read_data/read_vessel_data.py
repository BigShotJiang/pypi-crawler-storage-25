"""
This module provides functionality to read data from vessel/bridge/engine management systems. Due to the multitude of
suppliers and formats, functions might only be applicable for a limited number of ships.
"""

import glob
import os
import pandas as pd
import re

from pathlib import Path
from typing import Union


# ----------------------------------------------------------------------------------------------------------------------
# constants

columns_dict = {}
for ae_ in (1, 2, 3):
    columns_dict[f'/Fleet/imo9971252/Power_Plant/Diesel_Generators/{ae_:1d}/Fuel_Oil_System/' \
                 f'FO_Inlet_Mass_Flow (kg/h)'] = f'AE{ae_:1d} FO_Inlet_Mass_Flow (kg/h)'
    columns_dict[f'/Fleet/imo9971252/Power_Plant/Diesel_Generators/{ae_:1d}/Fuel_Oil_System/' \
                 f'FO_Inlet_Temp (degC)'] = f'AE{ae_:1d} FO_Inlet_Temp (degC)'
    columns_dict[f'/Fleet/imo9971252/Power_Plant/Diesel_Generators/{ae_:1d}/Fuel_Oil_System/' \
                 f'FO_Out_Mass_Flow (kg/h)'] = f'AE{ae_:1d} FO_Out_Mass_Flow (kg/h)'
    columns_dict[f'/Fleet/imo9971252/Power_Plant/Diesel_Generators/{ae_:1d}/' \
                 f'Generator_Power (kW)'] = f'AE{ae_:1d} Generator_Power (kW)'
    columns_dict[f'/Fleet/imo9971252/Power_Plant/Diesel_Generators/{ae_:1d}/' \
                 f'RPM (rpm)'] = f'AE{ae_:1d} RPM (rpm)'
    columns_dict[f'/Fleet/imo9971252/Power_Plant/Diesel_Generators/{ae_:1d}/' \
                 f'Run (Euc)'] = f'AE{ae_:1d} Run (Euc)'


# ----------------------------------------------------------------------------------------------------------------------

def extract_last_segment(s: str):
    segments = re.split(r'/(?=(?:[^()]*\([^()]*\))*[^()]*$)', s)
    return segments[-1] if segments else s


def get_column_name(clmn_: str):

    if clmn_ in columns_dict.keys():
        # columns of auxiliary engines are not unique
        clmn_ = columns_dict[clmn_]
    else:
        clmn_ = extract_last_segment(clmn_)

    return clmn_


def read_vessel_data_kongsberg(path_to_data: Union[str, Path], vessel_id: str) -> pd.DataFrame:
    """
    This function reads data that has been obtained from onboard data systems supplied by Kongsberg. It relies on that
    the "if"-part of the if/elif clause is processed at least once before the "elif"s are. Failing to do so will
    cause errors.
    :param path_to_data: location of the files (.csv)
    :param vessel_id: unique identifier of the ship (vessel name)
    :return: pandas DataFrame containing the data
    """

    files_ = glob.iglob(os.path.join(path_to_data, '*.csv'), recursive=False)

    df_vessel_data = pd.DataFrame(columns=['datetime (UTC) [-]'])

    for file_ in files_:

        if any([name_ in file_ for name_ in ('Auxiliary Engine', 'Bridge', 'Main Engine')]):
            df_iter = pd.read_csv(file_, sep=',', decimal='.')
            df_iter.columns = [get_column_name(clmn_) for clmn_ in df_iter.columns]
            columns_old = set(df_iter.columns)
            df_iter = df_iter.dropna(how='all', axis=1).dropna(how='all', axis=0).reset_index(drop=True)
            columns_diff = columns_old - set(df_iter.columns)
            if len(columns_diff) > 0:
                print(f'{vessel_id} - {os.path.basename(file_)}: Columns {columns_diff} were dropped because they were '
                      f'all NaN.')
            df_iter = df_iter.ffill(axis=0, limit=60)  # data is in 0.2Hz --> fill max 5 minutes
            df_iter['datetime (UTC) [-]'] = \
                pd.to_datetime(df_iter['Time (Format: YYYY-MM-DDThh:mm:ss.ffffffZ ISO 8601)'])
            df_iter = df_iter.resample('1s', on='datetime (UTC) [-]').last()
            df_iter = df_iter.reset_index()
            df_iter = df_iter.ffill(axis=0, limit=None)  # Carry-down values
            # It is assumed that one file contains one time interval w/o gaps other than caused by resampling.
            # Therefore, no limit is needed.
            df_vessel_data = df_vessel_data.merge(df_iter, on=['datetime (UTC) [-]'], how='outer')
        elif any([name_ in file_ for name_ in ('Power_PlantDiesel_Generators3Generator_Power692',)]):
            df_iter = pd.read_csv(file_, sep=',', decimal='.')
            df_iter = df_iter.drop(labels=['id', 'type', 'quality'], axis=1)
            df_iter = df_iter.dropna(how='all', axis=1).dropna(how='all', axis=0).reset_index(drop=True)
            df_iter = df_iter.rename(mapper={'value': 'AE3 Power [kW]'}, axis=1)
            df_iter['datetime (UTC) [-]'] = pd.to_datetime(df_iter['time'], format='ISO8601')
            df_iter = df_iter[['datetime (UTC) [-]', 'AE3 Power [kW]']]. \
                resample('1s', on='datetime (UTC) [-]').last()
            df_vessel_data = df_vessel_data.merge(df_iter, on=['datetime (UTC) [-]'], how='left')
        elif any([name_ in file_ for name_ in ('PropulsionDiesel_Engines1Fuel_Oil_SystemFO_Flow',)]):
            df_iter = pd.read_csv(file_, sep=',', decimal='.')

            df_iter_liter_per_h = df_iter[df_iter['id'] == '1:1:MOD.823FI107/Meas1/PRIM']
            df_iter_liter_per_h = df_iter_liter_per_h.drop(labels=['id', 'type', 'quality'], axis=1)
            df_iter_liter_per_h = \
                df_iter_liter_per_h.dropna(how='all', axis=1).dropna(how='all', axis=0).reset_index(drop=True)
            df_iter_liter_per_h = df_iter_liter_per_h.rename(mapper={'value': 'FO_Flow_2 [L/h]'}, axis=1)
            df_iter_liter_per_h['datetime (UTC) [-]'] = pd.to_datetime(df_iter_liter_per_h['time'], format='ISO8601')
            df_iter_liter_per_h = df_iter_liter_per_h[['datetime (UTC) [-]', 'FO_Flow_2 [L/h]']]. \
                resample('1s', on='datetime (UTC) [-]').last()
            df_vessel_data = df_vessel_data.merge(df_iter_liter_per_h, on=['datetime (UTC) [-]'], how='left')

            df_iter_kg_per_h = df_iter[df_iter['id'] == '1:1:MOD.823FI107A/Meas1/PRIM']
            df_iter_kg_per_h = df_iter_kg_per_h.drop(labels=['id', 'type', 'quality'], axis=1)
            df_iter_kg_per_h = df_iter_kg_per_h.dropna(how='all', axis=1).dropna(how='all', axis=0).reset_index(
                drop=True)
            df_iter_kg_per_h = df_iter_kg_per_h.rename(mapper={'value': 'FO_Flow_2 [kg/h]'}, axis=1)
            df_iter_kg_per_h['FO_Flow_2 [kg/h]'] = 1000.0 * df_iter_kg_per_h['FO_Flow_2 [kg/h]']
            df_iter_kg_per_h['datetime (UTC) [-]'] = pd.to_datetime(df_iter_kg_per_h['time'], format='ISO8601')
            df_iter_kg_per_h = df_iter_kg_per_h[['datetime (UTC) [-]', 'FO_Flow_2 [kg/h]']]. \
                resample('1s', on='datetime (UTC) [-]').last()
            df_vessel_data = df_vessel_data.merge(df_iter_kg_per_h, on=['datetime (UTC) [-]'], how='left')

            df_vessel_data['ME FO density [kg/L]'] = \
                df_vessel_data['FO_Flow_2 [kg/h]'] / df_vessel_data['FO_Flow_2 [L/h]']

        elif any([name_ in file_ for name_ in ('Engine_fuel_flow_logs',)]):
            df_iter = pd.read_csv(file_, sep=',', decimal='.')
            df_iter = df_iter.dropna(how='all', axis=1).dropna(how='all', axis=0).reset_index(drop=True)
            df_iter['datetime (UTC) [-]'] = \
                pd.to_datetime(df_iter['Date'] + ' ' + df_iter['UTC time'],
                               dayfirst=True,  # interprets 8-9-2025 as 8 September 2025
                               utc=True  # make timezone-aware in UTC
                               )
            df_iter = df_iter.resample('1s', on='datetime (UTC) [-]').last()
            df_iter = df_iter.reset_index()
            df_iter = df_iter.ffill(axis=0, limit=None)
            df_iter = df_iter.bfill(axis=0, limit=None)  # Carry-up values
            # It is assumed that one file contains one time interval w/o gaps other than caused by resampling.
            # Therefore, no limit is needed.
            df_vessel_data = df_vessel_data.merge(df_iter, on=['datetime (UTC) [-]'], how='left')

    df_vessel_data['AE3 Generator_Power (kW)'] = \
        df_vessel_data['AE3 Generator_Power (kW)'].fillna(df_vessel_data['AE3 Power [kW]'])

    df_vessel_data['ME MGO net flow [kg/h]'] = \
        (df_vessel_data['ME MGO in [L/h] - MEflowm'] - df_vessel_data['ME MGO out [L/h] - MEflowm']) * 0.845
    df_vessel_data['ME Share of pilot fuel [kg MGO/kg LNG]'] = \
        df_vessel_data['ME MGO net flow [kg/h]'] / df_vessel_data['ME LNG [kg/h] - LNGdisp']
    # see Fuel oil report.pdf for density of pilot fuel

    df_vessel_data['DG3 MGO in [kg/h] - DG3flowm'] = df_vessel_data['DG3 MGO in [L/h] - DG3flowm'] * 0.845
    df_vessel_data['DG3 MGO out [kg/h] - DG3flowm'] = df_vessel_data['DG3 MGO out [L/h] - DG3flowm'] * 0.845

    df_vessel_data['AE3 MGO net flow [kg/h]'] =\
        df_vessel_data['AE3 FO_Inlet_Mass_Flow (kg/h)'] - df_vessel_data['AE3 FO_Out_Mass_Flow (kg/h)']
    df_vessel_data['AE3 MGO net flow [kg/h]'] =\
        df_vessel_data['AE3 MGO net flow [kg/h]'].fillna(
            -(df_vessel_data['DG3 MGO in [L/h] - DG3flowm'] - df_vessel_data['DG3 MGO out [L/h] - DG3flowm']) * 0.845)
    # note the "-" before to correct for the different naming conventions of in/out
    df_vessel_data['AE3 Share of pilot fuel [kg MGO/kg LNG]'] = \
        df_vessel_data['AE3 MGO net flow [kg/h]'] / df_vessel_data['DG3 LNG [kg/h] - DG3gasm']
    # see Fuel oil report.pdf for density of pilot fuel

    return df_vessel_data