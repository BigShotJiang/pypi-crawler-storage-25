# ToothFairyAI MCP Server - Complete Tool Reference

**Version:** 0.8.0 (aligned with ToothFairyAI SDK)

This document provides a comprehensive reference for all tools available in the ToothFairyAI MCP Server. Use this guide to understand what each tool does, its parameters, and when to use it.

> **Transport**: This server uses **Streamable HTTP** transport for remote connections (recommended over SSE for better reliability and automatic reconnection support).

---

## SDK Integration Guidelines

When using the ToothFairyAI SDK directly (via MCP tools or programmatically):

### Client Configuration
```python
from toothfairyai import ToothFairyClient

client = ToothFairyClient(
    api_key="your-api-key",
    workspace_id="your-workspace-id",
    base_url="https://api.toothfairyai.com",  # or toothfairylab.link for dev
    ai_url="https://ai.toothfairyai.com",
    ai_stream_url="https://ais.toothfairyai.com",
    timeout=120
)
```

### Authorisation Types

| Type | Use Case | Required Fields |
|------|----------|-----------------|
| `oauth` | OAuth2 client credentials flow | client_id, client_secret, authorization_base_url, grant_type, scope |
| `bearer` | Static Bearer token | token_secret |
| `apikey` | API key authentication | token_secret |
| `none` | No authentication | None |

### Function (Tool) Parameters

Parameters MUST use JSON Schema format:
```json
{
  "type": "object",
  "properties": {
    "param_name": {"type": "string", "description": "..."}
  },
  "required": ["param_name"]
}
```

### Key Field Mappings

| SDK Field | API Field | Notes |
|-----------|-----------|-------|
| `auth_type` | `authorisationType` | Use "oauth" for OAuth APIs |
| `authorisation_id` | `authorisationID` | Reference the authorisation ID |
| `request_type` | `requestType` | HTTP method |

### Critical: Authorisation ID on Function Creation

When creating a function with `authorisation_id`, the create API maps it to `authorisation_key` internally but does NOT set `authorisation_id` in the response. The UI reads `authorisation_id` to populate the Authorisation dropdown. **After creating a function, always check if `response.authorisation_id` is null. If so, call `update_toothfairy_function` with `{authorisation_id: '<id>'}` to fix the UI dropdown.**

### Critical: GraphQL Two-Step Flow

The create API does NOT accept `graphql_query`, `graphql_operation_name`, or `graphql_mutation`. For GraphQL functions:

1. **Create** the function with `request_type='graphql_query'`, `url`, `authorisation_type`, etc.
2. **Update** the function with: `{graphql_query: 'query Name(...) { ... }', graphql_operation_name: 'Name', graphql_mutation: ''}`
3. **Also verify** `authorisation_id` is set (combine with step 2 if needed)

### Widget Context Parameters (static_args with tfCustomerId)

When an agent is embedded as a widget, the URL includes `?tfCustomerId=<workspaceId>`. Use `static_args` to inject this runtime value into API calls:

```json
// Workspace-scoped query: agent never needs workspace ID
{"static_args": {"workspaceId": "tfCustomerId", "limit": 500}}

// Single entity by workspace ID
{"static_args": {"id": "tfCustomerId"}}

// Dynamic params: agent supplies IDs from prior queries
{"parameters": {"type": "object", "properties": {"projectId": {"type": "string"}}, "required": ["projectId"]}}
```

### Agentic Tooling 2.0 (AT 2.0) Configuration

For multi-function retriever agents, configure these fields. **Default to `useInterleavedReasoning=true` for any agent with tools, internet search, or code execution** unless the user explicitly wants a simpler agent.

| Field | Purpose | Example |
|-------|---------|---------|
| `custom_tooling_instructions` | Navigation logic for the agent's functions | Bootstrap instructions, navigation patterns, important rules |
| `has_code` | Enable code execution for data aggregation | `true` for agents that calculate totals or filter data |
| `use_interleaved_reasoning` | Enable AT 2.0 adaptive mode | `true` (available via API, default for capable agents) |
| `interleaved_preset` | Execution time/call limits preset | `"medium"` (1hr / 300 calls) |
| `max_total_tool_calls` | Max total tool calls per conversation turn | `50` (1-100) |
| `max_consecutive_same_tool` | Max consecutive calls to the same tool | `5` (1-50) |
| `max_consecutive_failures` | Max consecutive failures before stopping | `3` (1-20) |

**CRITICAL constraints when `useInterleavedReasoning=true`:**
- `agenticRAG` MUST be `false` — they are mutually exclusive (interleaved reasoning replaces agenticRAG)
- `llmBaseModel` MUST be an interleaved-capable model (only a subset of models support this mode)
- `reasoningMode` MUST be `"always"`

**Retriever agents with `useInterleavedReasoning=true` can also populate `agentsPool`** (like planner agents) to delegate subtasks to other specialist agents.

### Critical: Assign Functions to the Agent

Creating functions is **NOT enough** — they must be assigned to the agent via the `agent_functions` array. After creating functions, call `update_toothfairy_agent` with the complete list of function IDs:

```json
{
  "agent_functions": [
    "existing-fn-id-1",
    "existing-fn-id-2", 
    "new-fn-id-3",
    "new-fn-id-4"
  ]
}
```

**WARNING**: The `agent_functions` array is **replaced entirely** on update. You must include ALL function IDs (existing + new). Omitting existing IDs will remove them from the agent.

### Validation Models (SDK v0.5.9+)

The SDK provides **Pydantic validation models** to catch payload errors before API calls. These models validate field types, required fields, and constraints.

**Available Models:**
- `AgentCreateModel` - Validates agent creation (requires `interpolation_string` >= 128 chars)
- `AgentFunctionCreateModel` - Validates function creation (`description` required)
- `ScheduledJobCreateModel` - Validates scheduled jobs (`custom_prompt_id` required)
- `DocumentCreateModel` - Validates documents (`user_id` required, no `content` field)
- `ConnectionCreateModel` - Validates connections (`name` required)
- `FolderCreateModel` - Validates folders (uses `name`, not `label`)
- `EntityCreateModel` - Validates entities (validates `background_color` hex format)
- `MemberCreateModel` - Validates members (uses `user_id`, not `email`)
- Plus models for: Prompt, Authorisation, Hook, Benchmark, Chat, Channel, Secret

**Usage Example:**
```python
from toothfairyai.models import AgentCreateModel

# Validate before API call
try:
    validated = AgentCreateModel(
        label="My Agent",
        mode="chatter",
        interpolation_string="You are a helpful assistant...",  # Must be >= 128 chars
        goals="Help users"
    )
    # Use validated.model_dump() for API payload
except ValidationError as e:
    print(f"Validation failed: {e}")
```

**Key Validation Rules:**
- Agent `interpolation_string` must be >= 128 characters
- AgentFunction `description` is required (AI uses it to decide when to call)
- ScheduledJob `custom_prompt_id` is required
- Document `user_id` is required (no `content` field - content is separate)
- CronJobFrequency uses UPPERCASE: `DAILY`, `HOURLY`, `WEEKLY`, etc.

**Note:** Validation models are OPTIONAL. Existing SDK code without models continues to work.

---

## Important: Three Types of Tools

This MCP server contains **three distinct categories of tools** with different authentication requirements:

### 1. Documentation Tools (13 tools) - **NO AUTH REQUIRED**
Access documentation, API specs, and release notes without any authentication.
- `search_docs`, `search_api_endpoints`, `explain_api_domains`
- `get_api_spec`, `get_a2a_spec`, `get_voice_spec`
- `list_release_notes`, `get_latest_release_notes`, `search_release_notes`, `get_release_note`

### 2. Public Endpoint Tools (3 tools) - **NO AUTH REQUIRED**
Access public endpoints to browse resources before signing up.
- `fetch_toothfairy_announcement` - System announcements
- `fetch_toothfairy_hireable_agents` - Browse agent templates
- `fetch_ai_models_list` - AI models and pricing

### 3. SDK Tools (93 tools) - **API KEY REQUIRED**
Perform actual operations on your ToothFairyAI workspace. These require:
- `api_key`: Your ToothFairyAI API key
- `workspace_id`: Your workspace UUID
- `region`: API region (au/eu/us)

**⚠️ IMPORTANT**: When using this MCP, **do NOT assume an API key is required by default**. Many tools work without authentication! Only SDK tools that perform operations on your workspace require credentials.

---

## Quick Reference

| Category | Tools | Authentication Required |
|----------|-------|------------------------|
| Documentation | 10 | **No** |
| Public Utils | 4 | **No** |
| Credential Validation | 1 | Yes |
| Agent Management | 6 | Yes |
| Agent Functions | 5 | Yes |
| Authorisations | 5 | Yes |
| Secrets | 2 | Yes |
| Documents | 6 | Yes |
| Entities | 6 | Yes |
| Folders | 6 | Yes |
| Chats | 5 | Yes |
| Prompts | 5 | Yes |
| Members | 4 | Yes |
| Channels | 5 | Yes |
| Connections | 3 | Yes |
| Benchmarks | 5 | Yes |
| Hooks | 5 | Yes |
| Scheduled Jobs | 5 | Yes |
| Sites | 4 | Yes |
| Dictionary | 2 | Yes |
| Request Logs | 2 | Yes |
| Settings | 4 | Yes |
| Billing | 1 | Yes |
| Embeddings | 1 | Yes |
| Fine-Tuning | 6 | 1 No, 5 Yes |
| Training Data (MagicWand) | 2 | Yes |
| **Total** | **109** | |

### Authentication Parameters

**Only SDK tools** (the 85 tools that perform workspace operations) require these parameters:

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | ToothFairyAI API key from Admin > API Integration |
| `workspace_id` | string | Yes | Your workspace UUID |
| `region` | string | No | API region: `"au"` (default), `"eu"`, or `"us"` |

### Response Format

All SDK tools return a consistent response format:

```json
{
  "success": true,
  "message": "Operation completed successfully",
  "data": { ... }
}
```

Or on error:

```json
{
  "success": false,
  "error": "Error message description"
}
```

---

## Documentation Tools (No Auth Required)

These tools provide access to ToothFairyAI documentation and API specifications without authentication.

### `search_docs`

Search across all ToothFairyAI documentation.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | Yes | - | Search query string |
| `limit` | int | No | 10 | Maximum number of results |
| `source` | string | No | None | Filter: `"docs"`, `"api"`, or `None` for all |

**Returns:** List of search results with title, uri, snippet, and relevance score.

**Example:**
```python
search_docs(query="agent creation", limit=5, source="docs")
```

---

### `search_api_endpoints`

Search for specific API endpoints across all ToothFairyAI APIs.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | Yes | - | Search query (matches path, summary, description, tags) |
| `limit` | int | No | 20 | Maximum number of results |

**Returns:** List of endpoints with method, path, summary, tags, API type, and base domain.

**Example:**
```python
search_api_endpoints(query="create agent", limit=10)
```

---

### `explain_api_domains`

Get detailed explanation of ToothFairyAI API domains and when to use each.

**Parameters:** None

**Returns:** Comprehensive guide explaining Platform API vs AI Services API vs Voice API.

**Example:**
```python
explain_api_domains()
```

---

### `list_doc_categories`

List all available documentation categories.

**Parameters:** None

**Returns:** List of category names (e.g., `["agents", "settings", "guides"]`).

**Example:**
```python
list_doc_categories()
```

---

### `get_doc_by_topic`

Get full documentation content for a specific topic.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `topic` | string | Yes | Topic to find (e.g., "agents", "prompting", "channels") |

**Returns:** Full markdown content of the most relevant document.

**Example:**
```python
get_doc_by_topic("webhooks")
```

---

### `get_agent_creation_guide`

Get the comprehensive guide for creating ToothFairyAI agents.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `section` | string | No | None | Specific section to retrieve |

**Available sections:** `modes`, `core-fields`, `mode-config`, `tools`, `features`, `departments`, `models`, `uploads`, `voice`, `planner`, `validation`, `best-practices`, `examples`, `quick-reference`

**Returns:** Agent creation guide content (full or specific section).

**Example:**
```python
get_agent_creation_guide(section="examples")
```

---

## Release Notes Tools (No Auth Required)

These tools provide access to ToothFairyAI release notes and product updates.

### `list_release_notes`

List all available ToothFairyAI release notes.

**Parameters:** None

**Returns:** List of release notes sorted by version (newest first), with version, release_date, title, summary, and uri.

**Example:**
```python
list_release_notes()
```

---

### `get_latest_release_notes`

Get the most recent ToothFairyAI release notes.

**Parameters:** None

**Returns:** Full markdown content of the latest release notes including all new features, improvements, and fixes.

**Example:**
```python
get_latest_release_notes()
```

---

### `get_release_notes`

Get release notes for a specific version.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `version` | string | Yes | Version number (e.g., "0.668.0", "v0.668.0", or "0.668") |

**Returns:** Full markdown content of the release notes for that version.

**Example:**
```python
get_release_notes(version="0.668.0")
```

---

### `search_release_notes`

Search release notes by keyword or phrase.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | Yes | - | Search query (e.g., "voice agents", "MCP", "agentic tooling") |
| `limit` | int | No | 10 | Maximum number of results |

**Returns:** List of matching release notes with version, title, snippet, and relevance score.

**Example:**
```python
search_release_notes(query="voice agents", limit=5)
```

---

## Public Utils Tools (No Auth Required)

These tools access public endpoints that do not require API key or workspace ID. Use them to browse available resources before signing up or to get public information.

### `fetch_toothfairy_announcement`

Fetch the latest ToothFairyAI system announcement. Useful for checking service status, maintenance notices, and important updates.

**Parameters:** None

**Returns:** 
- `success`: Boolean indicating if the request succeeded
- `last_announcement_int`: Integer identifier for the announcement
- `announcement`: The announcement message text
- `raw_response`: Complete API response

**Example:**
```python
fetch_toothfairy_announcement()
```

---

### `fetch_toothfairy_hireable_agents`

Fetch available hireable agents with optional filtering. Browse pre-configured agents that can be used as templates or inspiration.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `label` | string | No | None | Filter by agent name (case-insensitive substring match) |
| `description` | string | No | None | Filter by agent description (case-insensitive substring match) |
| `mode` | string | No | None | Filter by agent mode (e.g., "coder", "retriever", "chatter", "planner", "voice") |
| `department` | string | No | None | Filter by department (e.g., "SALES", "MARKETING", "ENGINEERING") |

**Returns:**
- `success`: Boolean indicating if the request succeeded
- `count`: Number of agents returned
- `agents`: List of agent objects with configuration details
- `raw_response`: Complete API response

**Example:**
```python
# Get all hireable agents
fetch_toothfairy_hireable_agents()

# Filter by mode
fetch_toothfairy_hireable_agents(mode="coder")

# Filter by department
fetch_toothfairy_hireable_agents(department="SALES")
```

---

### `fetch_ai_models_list`

Fetch the complete list of AI models supported by ToothFairyAI, including pricing information and model characteristics. This is a PUBLIC endpoint that does not require authentication.

**Parameters:** None

**Returns:**
- `success`: Boolean indicating if the request succeeded
- `count`: Number of models returned
- `models`: List of AI models with details including:
  - Model name and provider
  - Pricing information
  - Context window size
  - Supported features
- `error`: Error message if the request failed

**Example:**
```python
fetch_ai_models_list()
```

---

## Credential Validation

### `validate_toothfairy_credentials`

Validate ToothFairyAI API credentials before performing operations. **Always call this first.**

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | ToothFairyAI API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `region` | string | No | `"au"` | API region |

**Returns:** Success/failure status with message.

**Example:**
```python
validate_toothfairy_credentials(
    api_key="your-api-key",
    workspace_id="your-workspace-id",
    region="au"
)
```

---

## Agent Management (6 tools)

### `create_toothfairy_agent`

Create a new AI agent in your workspace.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `label` | string | Yes | - | Human-readable agent name |
| `mode` | string | Yes | - | Agent mode: `"chatter"`, `"retriever"`, `"coder"`, `"planner"`, `"voice"` |
| `interpolation_string` | string | Yes | - | System prompt defining agent personality |
| `goals` | string | Yes | - | High-level objectives for the agent |
| `region` | string | No | `"au"` | API region |
| `temperature` | float | No | 0.3 | Response randomness (0.001-1.0) |
| `max_tokens` | int | No | 4096 | Maximum response length |
| `description` | string | No | None | Brief agent description |
| `agentic_rag` | bool | No | False | Enable multi-step RAG (retriever mode only) |
| `has_code` | bool | No | False | Enable code execution |
| `charting` | bool | No | False | Enable chart generation (retriever mode only) |
| `allow_internet_search` | bool | No | False | Enable web search |
| `enable_json_output` | bool | No | False | Enable structured JSON output mode |
| `json_output_structure` | dict | No | None | JSON schema defining output structure (required if enable_json_output=True) |

**Structured Output:**
When `enable_json_output=True`, the agent will respond in structured JSON format matching the schema provided in `json_output_structure`. Works with both `chatter` and `retriever` modes.

**Example - Structured Output:**
```python
create_toothfairy_agent(
    api_key="key",
    workspace_id="ws-id",
    label="FAQ Bot",
    mode="retriever",
    interpolation_string="You are an FAQ assistant. Answer questions from the knowledge base.",
    goals="Provide structured answers",
    enable_json_output=True,
    json_output_structure={
        "type": "object",
        "properties": {
            "answer": {"type": "string"},
            "confidence": {"type": "number"},
            "sources": {"type": "array", "items": {"type": "string"}}
        }
    }
)
```

**Returns:** Created agent data.

**Example:**
```python
create_toothfairy_agent(
    api_key="key",
    workspace_id="ws-id",
    label="Research Assistant",
    mode="retriever",
    interpolation_string="You are a helpful research assistant...",
    goals="Help users find and analyze information",
    agentic_rag=True,
    allow_internet_search=True
)
```

---

### `get_toothfairy_agent`

Get details of a specific agent by ID.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `agent_id` | string | Yes | Agent UUID to retrieve |
| `region` | string | No | API region (default: `"au"`) |

**Returns:** Agent details including configuration, stats, and metadata.

---

### `update_toothfairy_agent`

Update an existing agent's configuration.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `agent_id` | string | Yes | Agent UUID to update |
| `updates` | dict | Yes | Fields to update (e.g., `{"label": "New Name", "temperature": 0.5}`) |
| `region` | string | No | API region (default: `"au"`) |

**Note:** Agent `mode` cannot be changed after creation.

**Returns:** Updated agent data.

---

### `delete_toothfairy_agent`

Delete an agent permanently. **WARNING: Irreversible.**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `agent_id` | string | Yes | Agent UUID to delete |
| `region` | string | No | API region (default: `"au"`) |

**Returns:** Success confirmation.

---

### `list_toothfairy_agents`

List all agents in a workspace.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `region` | string | No | `"au"` | API region |
| `limit` | int | No | 100 | Maximum results |

**Returns:** List of agents with basic info.

---

### `search_toothfairy_agents`

Search agents by label.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `search_term` | string | Yes | Search query for agent labels |
| `region` | string | No | API region (default: `"au"`) |

**Returns:** Matching agents.

---

## Agent Functions (5 tools)

Agent Functions are external API tools that agents can call during conversations.

### `create_toothfairy_function`

Create a new function (external API tool) for agents.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `name` | string | Yes | - | Function name (e.g., `"search_tickets"`) |
| `description` | string | Yes | - | What the function does (AI uses this to decide when to call) |
| `url` | string | Yes | - | Endpoint URL (supports `{{variable}}` substitution) |
| `region` | string | No | `"au"` | API region |
| `request_type` | string | No | `"GET"` | HTTP method: `"GET"`, `"POST"`, `"PUT"`, `"PATCH"`, `"DELETE"` |
| `authorisation_type` | string | No | `"none"` | Auth type: `"oauth"`, `"bearer"`, `"apikey"`, `"none"` |
| `authorisation_id` | string | No | None | ID of the authorisation to use (from create_authorisation) |
| `parameters` | dict | No | None | JSON Schema format: `{"type": "object", "properties": {...}}` |
| `headers` | list | No | None | Custom headers: `[{"name": "X-Custom", "value": "value"}]` |
| `static_args` | dict | No | None | Static args always passed: `{"key": "value"}` |

**Important:**
- Use `authorisation_type: "oauth"` for OAuth APIs (NOT "bearer")
- `authorisation_id` must reference the ID from `create_toothfairy_authorisation`
- `parameters` MUST use JSON Schema format, not list format

**Example:**
```python
# Step 1: Create Authorisation (without secret)
auth = create_toothfairy_authorisation(
    api_key="...",
    workspace_id="...",
    name="SharePoint Graph API",
    auth_type="oauth",
    client_id="your-client-id",
    authorization_base_url="https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
    grant_type="client_credentials",
    scope="https://graph.microsoft.com/.default"
)

# Step 2: Create Secret with client secret value
secret = create_toothfairy_secret(
    api_key="...",
    workspace_id="...",
    authorisation_id=auth["data"]["id"],
    password_secret_value="your-actual-client-secret-value"
)

# Step 3: Create function referencing the authorisation
create_toothfairy_function(
    api_key="...",
    workspace_id="...",
    name="sharepoint_search",
    description="Use this tool when the user wants to search for files...",
    url="https://graph.microsoft.com/v1.0/search/query",
    request_type="POST",
    authorisation_type="oauth",
    authorisation_id=auth["data"]["id"],
    parameters={
        "type": "object",
        "properties": {
            "search_query": {"type": "string", "description": "Search query"}
        },
        "required": ["search_query"]
    }
)
```

---

### `get_toothfairy_function`

Get function details by ID.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `function_id` | string | Yes | Function UUID |
| `region` | string | No | API region (default: `"au"`) |

---

### `update_toothfairy_function`

Update an existing function.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `function_id` | string | Yes | Function UUID |
| `updates` | dict | Yes | Fields to update |
| `region` | string | No | API region (default: `"au"`) |

---

### `delete_toothfairy_function`

Delete a function. **WARNING: Irreversible.**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `function_id` | string | Yes | Function UUID |
| `region` | string | No | API region (default: `"au"`) |

---

### `list_toothfairy_functions`

List all functions in a workspace.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `region` | string | No | `"au"` | API region |
| `limit` | int | No | 100 | Maximum results |

---

## Authorisations (5 tools)

Authorisations store API credentials (keys, tokens, OAuth) for functions.

**IMPORTANT: Two-Step Flow for Secrets**

1. Create Authorisation first (without secret values)
2. Create Secret linked to Authorisation (with actual secret value)

### `create_toothfairy_authorisation`

Create a new authorisation record (without secret values).

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `name` | string | Yes | - | Human-readable name |
| `auth_type` | string | Yes | - | Type: `"oauth"`, `"bearer"`, `"apikey"`, `"none"` |
| `region` | string | No | `"au"` | API region |
| `description` | string | No | None | Purpose description |
| `scope` | string | No | None | OAuth scope (e.g., "https://graph.microsoft.com/.default") |
| `grant_type` | string | No | None | OAuth grant type (e.g., "client_credentials") |
| `client_id` | string | No | None | OAuth client ID |
| `authorization_base_url` | string | No | None | OAuth token endpoint URL |

**Note:** Do NOT pass secret values (client_secret, token_secret) here. Use `create_toothfairy_secret` after.

---

### `get_toothfairy_authorisation`

Get authorisation by ID. Note: Sensitive values may be masked.

---

### `update_toothfairy_authorisation`

Update an authorisation record.

---

### `delete_toothfairy_authorisation`

Delete an authorisation. **WARNING: Irreversible.** Ensure no functions reference it.

---

### `list_toothfairy_authorisations`

List all authorisations in a workspace.

---

## Secrets (2 tools)

Secrets store encrypted sensitive values linked to Authorisations.

**REQUIRED for all auth types except "none".** Call this after `create_toothfairy_authorisation`.

### `create_toothfairy_secret`

Create a secret linked to an authorisation.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `authorisation_id` | string | Yes | Authorisation UUID from `create_toothfairy_authorisation` |
| `password_secret_value` | string | Yes | The actual secret value (API key, client secret, bearer token) |
| `region` | string | No | API region (default: `"au"`) |

**Example - OAuth Flow (Two Steps):**
```python
# Step 1: Create Authorisation (without secret)
auth = create_toothfairy_authorisation(
    api_key="...",
    workspace_id="...",
    name="SharePoint Graph API",
    auth_type="oauth",
    client_id="your-client-id",
    authorization_base_url="https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
    grant_type="client_credentials",
    scope="https://graph.microsoft.com/.default"
)

# Step 2: Create Secret with client secret value
secret = create_toothfairy_secret(
    api_key="...",
    workspace_id="...",
    authorisation_id=auth["data"]["id"],
    password_secret_value="your-actual-client-secret-value"
)
```

**Example - Bearer Token Flow:**
```python
# Step 1: Create Authorisation
auth = create_toothfairy_authorisation(
    api_key="...",
    workspace_id="...",
    name="API Token",
    auth_type="bearer"
)

# Step 2: Create Secret with token value
secret = create_toothfairy_secret(
    api_key="...",
    workspace_id="...",
    authorisation_id=auth["data"]["id"],
    password_secret_value="your-bearer-token-value"
)

---

### `delete_toothfairy_secret`

Delete a secret. **WARNING: Irreversible.**

---

## Documents (6 tools)

Documents are knowledge base entries that agents can search and reference.

### `create_toothfairy_document`

Create a new document in the knowledge base.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `title` | string | Yes | - | Document title |
| `region` | string | No | `"au"` | API region |
| `content` | string | No | None | Document content (markdown supported) |
| `folder_id` | string | No | None | Parent folder UUID |
| `topics` | list | No | None | List of topic IDs to associate |

---

### `get_toothfairy_document`

Get document by ID.

---

### `update_toothfairy_document`

Update a document.

---

### `delete_toothfairy_document`

Delete a document. **WARNING: Irreversible.**

---

### `list_toothfairy_documents`

List documents in a workspace.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `region` | string | No | `"au"` | API region |
| `limit` | int | No | 100 | Maximum results |
| `folder_id` | string | No | None | Filter by folder |

---

### `search_toothfairy_documents`

Search documents by text content.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `text` | string | Yes | - | Search query |
| `region` | string | No | `"au"` | API region |
| `limit` | int | No | 10 | Maximum results |

---

## Entities (6 tools)

Entities are Topics, Intents, or Named Entity Recognition (NER) items.

### `create_toothfairy_entity`

Create a new entity.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `label` | string | Yes | - | Entity name |
| `entity_type` | string | Yes | - | Type: `"topic"`, `"intent"`, `"ner"` |
| `region` | string | No | `"au"` | API region |
| `description` | string | No | None | Entity description |
| `emoji` | string | No | None | Display emoji |

---

### `get_toothfairy_entity`

Get entity by ID.

---

### `update_toothfairy_entity`

Update an entity.

---

### `delete_toothfairy_entity`

Delete an entity. **WARNING: Irreversible.**

---

### `list_toothfairy_entities`

List entities with optional type filter.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `region` | string | No | `"au"` | API region |
| `entity_type` | string | No | None | Filter: `"topic"`, `"intent"`, `"ner"` |
| `limit` | int | No | 100 | Maximum results |

---

### `search_toothfairy_entities`

Search entities by label.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `search_term` | string | Yes | - | Search query |
| `region` | string | No | `"au"` | API region |
| `entity_type` | string | No | None | Filter by type |

---

## Folders (6 tools)

Folders organize documents in the knowledge base.

### `create_toothfairy_folder`

Create a new folder.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `label` | string | Yes | - | Folder name |
| `region` | string | No | `"au"` | API region |
| `parent_id` | string | No | None | Parent folder UUID for nesting |

---

### `get_toothfairy_folder`

Get folder by ID.

---

### `update_toothfairy_folder`

Update a folder.

---

### `delete_toothfairy_folder`

Delete a folder. **WARNING: Irreversible.**

---

### `list_toothfairy_folders`

List all folders.

---

### `get_toothfairy_folder_tree`

Get the complete hierarchical folder tree structure.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `region` | string | No | API region (default: `"au"`) |

---

## Chats (5 tools)

Chats are conversation sessions with agents.

### `create_toothfairy_chat`

Create a new chat session.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `agent_id` | string | Yes | - | Agent UUID for this chat |
| `region` | string | No | `"au"` | API region |
| `title` | string | No | None | Chat session title |

---

### `get_toothfairy_chat`

Get chat session by ID (includes message history).

---

### `delete_toothfairy_chat`

Delete a chat session. **WARNING: Irreversible.**

---

### `list_toothfairy_chats`

List all chat sessions.

---

### `send_toothfairy_message`

Send a message to an agent and get a response.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `agent_id` | string | Yes | - | Agent UUID to message |
| `message` | string | Yes | - | User message content |
| `region` | string | No | `"au"` | API region |
| `chat_id` | string | No | None | Existing chat UUID (creates new if not provided) |

**Returns:** Agent response with message content and metadata.

**Example:**
```python
send_toothfairy_message(
    api_key="key",
    workspace_id="ws-id",
    agent_id="agent-uuid",
    message="What is ToothFairyAI?"
)
```

---

## Prompts (5 tools)

Prompts are reusable text templates with variable interpolation.

### `create_toothfairy_prompt`

Create a new prompt template.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `label` | string | Yes | Prompt name |
| `interpolation_string` | string | Yes | Template text with `{{variables}}` |
| `region` | string | No | API region (default: `"au"`) |

---

### `get_toothfairy_prompt`

Get prompt by ID.

---

### `update_toothfairy_prompt`

Update a prompt template.

---

### `delete_toothfairy_prompt`

Delete a prompt. **WARNING: Irreversible.**

---

### `list_toothfairy_prompts`

List all prompt templates.

---

## Members (4 tools)

Members are users in a workspace.

### `get_toothfairy_member`

Get member by ID.

---

### `update_toothfairy_member`

Update member details (role, permissions, etc.).

---

### `delete_toothfairy_member`

Remove a member from workspace. **WARNING: Irreversible.**

---

### `list_toothfairy_members`

List all workspace members.

---

## Channels (5 tools)

Channels are communication integrations (Slack, Teams, WhatsApp, etc.).

### `create_toothfairy_channel`

Create a new channel integration.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `name` | string | Yes | Channel display name |
| `channel` | string | Yes | Channel type (e.g., `"slack"`, `"teams"`) |
| `provider` | string | Yes | Provider identifier |
| `region` | string | No | API region (default: `"au"`) |

---

### `get_toothfairy_channel`

Get channel by ID.

---

### `update_toothfairy_channel`

Update channel configuration.

---

### `delete_toothfairy_channel`

Delete a channel. **WARNING: Irreversible.**

---

### `list_toothfairy_channels`

List all channels.

---

## Connections (3 tools)

Connections are database connections for data querying.

### `get_toothfairy_connection`

Get database connection by ID.

---

### `delete_toothfairy_connection`

Delete a connection. **WARNING: Irreversible.**

---

### `list_toothfairy_connections`

List all database connections.

---

## Benchmarks (5 tools)

Benchmarks are test suites for evaluating agent performance. Each benchmark contains a list of questions with expected answers that are used to score an agent's responses.

### Benchmark Question Format

Each question in the `questions` array is a dict with these keys:

| Key | Required | Max Length | Description |
|-----|----------|------------|-------------|
| `question` | **Yes** | 6000 chars | The question to ask the agent |
| `answer` | **Yes** | 6000 chars | The expected correct answer |
| `reasoning` | No | 6000 chars | Why this answer is correct (helps reviewer model evaluate) |
| `context` | No | 6000 chars | Additional context for evaluation |

**Example:**
```json
[
  {"question": "What is the refund policy?", "answer": "Refunds within 30 days", "reasoning": "Policy doc states 30-day window", "context": "Refund section"},
  {"question": "How do I reset my password?", "answer": "Click Forgot Password on the login page"}
]
```

### Benchmark CSV File Format

When uploading a benchmark via CSV file (using `upload_toothfairy_document`):

- **Delimiter:** semicolon (`;`) — NOT comma
- **All fields must be double-quoted**
- **No header row** — every row is data
- **2-4 fields per row:** `"question";"answer";"reasoning";"context"`
- **Max file size:** 10MB

**Example CSV:**
```
"What is the refund policy?";"Refunds within 30 days";"Policy doc states 30-day window";"Refund section"
"How do I reset my password?";"Click Forgot Password on the login page"
"What are the business hours?";"Mon-Fri 9am-5pm"
```

### Benchmark Type Compatibility

| Type | SDK Value | Min Questions | Max Questions | Description |
|------|-----------|---------------|---------------|-------------|
| Standard BM | `"bm"` | 1 | No limit | Agent answers questions, reviewer scores responses |
| ABM Static | `"abm"` mode `"static"` | 10 | 200 | Examiner follows scripted questions from benchmark |
| ABM Dynamic | `"abm"` mode `"dynamic"` | 1 | No limit | AI-generated probing questions by examiner agent |

### `create_toothfairy_benchmark`

Create a new benchmark.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `name` | string | Yes | - | Benchmark name (max 255 chars) |
| `region` | string | No | `"au"` | API region |
| `description` | string | No | None | Benchmark description (max 2048 chars) |
| `questions` | list | No | None | Question dicts (see format above) |

**Example:**
```python
create_toothfairy_benchmark(
    api_key="...",
    workspace_id="...",
    name="Refund Policy QA",
    description="Tests agent knowledge of refund policies",
    questions=[
        {"question": "What is the refund policy?", "answer": "Refunds within 30 days", "reasoning": "Policy doc states 30-day window"},
        {"question": "Are digital products refundable?", "answer": "No, digital products are non-refundable"}
    ]
)
```

---

### `get_toothfairy_benchmark`

Get benchmark by ID.

---

### `update_toothfairy_benchmark`

Update a benchmark.

---

### `delete_toothfairy_benchmark`

Delete a benchmark. **WARNING: Irreversible.**

---

### `list_toothfairy_benchmarks`

List all benchmarks.

---

## Benchmark Runs (5 tools)

Benchmark runs execute a benchmark against an agent and produce a score. Runs are asynchronous — create one, then poll for completion or use the wait tool.

### Run Types and Scoring

| Type | Score Field | Range | Description |
|------|-------------|-------|-------------|
| `"bm"` (Standard) | `scoring_summary.average_overall_score` | 0-1 | Weighted average of correctness, reasoning, context_usage |
| `"abm"` (Consistency) | `consistency_summary.average_consistency_score` | 0-1 | How consistently the agent answers the same question |

### Run Lifecycle

1. `run_toothfairy_benchmark` — Start a run (returns `status="dispatched"`)
2. `get_toothfairy_benchmark_run` — Check status/score
3. `wait_for_toothfairy_benchmark_run` — Block until completed
4. `cancel_toothfairy_benchmark_run` — Cancel an in-progress run
5. `list_toothfairy_benchmark_runs` — List all runs with filters

### `run_toothfairy_benchmark`

Start a benchmark run to evaluate an agent's performance.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `benchmark_id` | string | Yes | - | ID of the benchmark to run |
| `agent_id` | string | Yes | - | ID of the agent to test |
| `type` | string | No | `"bm"` | Run type: `"bm"` or `"abm"` |
| `mode` | string | No | None | ABM mode: `"static"` or `"dynamic"` |
| `reviewer_agent_id` | string | No | `"sorcerer"` | Reviewer agent ID |
| `weights` | dict | No | None | Category weights, e.g. `{"correctness": 0.5, "reasoning": 0.3, "context_usage": 0.2}` |
| `passing_score` | float | No | 0.9 | Minimum score to pass (0-1) |
| `num_questions` | int | No | All | Number of questions to use |
| `name` | string | No | None | Optional name for the run |

**Example:**
```python
run = run_toothfairy_benchmark(
    api_key="...",
    workspace_id="...",
    benchmark_id="fd7d5e71-...",
    agent_id="c4dabb59-...",
    type="bm",
    name="Baseline BM Run"
)
# Returns: {"id": "...", "status": "dispatched"}
```

---

### `get_toothfairy_benchmark_run`

Get a benchmark run by ID with score and detailed metadata.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `run_id` | string | Yes | ID of the benchmark run |

**Returns:** BenchmarkRun with `status`, `score`, `batch_meta` containing:
- For BM: `scoring_summary` with `average_overall_score`, `pass_rate`, `average_by_category`
- For ABM: `consistency_summary` with `average_consistency_score`

---

### `list_toothfairy_benchmark_runs`

List benchmark runs with optional filters.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `agent_id` | string | No | None | Filter by agent ID |
| `benchmark_id` | string | No | None | Filter by benchmark ID |
| `type` | string | No | None | Filter by type (`"bm"` or `"abm"`) |
| `status` | string | No | None | Filter by status |
| `limit` | int | No | 20 | Max runs to return |

---

### `cancel_toothfairy_benchmark_run`

Cancel a running benchmark. **WARNING: Irreversible.**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `run_id` | string | Yes | ID of the run to cancel |

---

### `wait_for_toothfairy_benchmark_run`

Block until a benchmark run completes (status = completed/inError/cancelled).

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `run_id` | string | Yes | - | ID of the benchmark run |
| `poll_interval` | float | No | 10.0 | Seconds between status checks |
| `timeout` | float | No | 1800.0 | Max seconds to wait (30 min) |

**Returns:** Final BenchmarkRun with `score` and `batch_meta`.

**Example — Full baseline flow:**
```python
# 1. Run the benchmark
run = run_toothfairy_benchmark(
    benchmark_id="...", agent_id="...", type="bm"
)

# 2. Wait for completion (blocks up to 30 min)
result = wait_for_toothfairy_benchmark_run(run_id=run["id"])

# 3. Check score
print(f"Score: {result['score']}")  # e.g. 0.9067
print(f"Categories: {result['batch_meta']['scoring_summary']['average_by_category']}")
```

---

## Hooks (5 tools)

Hooks execute custom code during agent workflows.

### `create_toothfairy_hook`

Create a new hook.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `name` | string | Yes | - | Hook name |
| `function_name` | string | Yes | - | Entry point function name |
| `region` | string | No | `"au"` | API region |
| `custom_execution_code` | string | No | None | Custom JavaScript/Python code |

---

### `get_toothfairy_hook`

Get hook by ID.

---

### `update_toothfairy_hook`

Update a hook.

---

### `delete_toothfairy_hook`

Delete a hook. **WARNING: Irreversible.**

---

### `list_toothfairy_hooks`

List all hooks.

---

## Scheduled Jobs (5 tools)

Scheduled Jobs automate recurring agent tasks.

### `create_toothfairy_scheduled_job`

Create a new scheduled job.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `name` | string | Yes | Job name |
| `agent_id` | string | Yes | Agent UUID to run |
| `schedule` | dict | Yes | Schedule configuration (cron-like) |
| `region` | string | No | API region (default: `"au"`) |

---

### `get_toothfairy_scheduled_job`

Get scheduled job by ID.

---

### `update_toothfairy_scheduled_job`

Update a scheduled job.

---

### `delete_toothfairy_scheduled_job`

Delete a scheduled job. **WARNING: Irreversible.**

---

### `list_toothfairy_scheduled_jobs`

List all scheduled jobs.

---

## Sites (4 tools)

Sites are web deployments or embedded chat widgets.

### `get_toothfairy_site`

Get site by ID.

---

### `update_toothfairy_site`

Update site configuration.

---

### `delete_toothfairy_site`

Delete a site. **WARNING: Irreversible.**

---

### `list_toothfairy_sites`

List all sites.

---

## Dictionary (2 tools)

Dictionary entries define custom terminology and definitions.

### `get_toothfairy_dictionary_entry`

Get dictionary entry by ID.

---

### `list_toothfairy_dictionary_entries`

List all dictionary entries.

---

## Request Logs (2 tools)

Request logs track API usage and agent interactions.

### `get_toothfairy_request_log`

Get request log by ID.

---

### `list_toothfairy_request_logs`

List all request logs.

---

## Settings (4 tools)

Workspace-level configuration settings.

### `get_toothfairy_charting_settings`

Get charting/visualization settings.

---

### `update_toothfairy_charting_settings`

Update charting settings.

---

### `get_toothfairy_embeddings_settings`

Get embeddings model settings.

---

### `update_toothfairy_embeddings_settings`

Update embeddings settings.

---

## Billing (1 tool)

### `get_toothfairy_month_costs`

Get monthly usage costs and intelligence budget consumption.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `region` | string | No | `"au"` | API region |
| `year` | int | No | Current | Year to query |
| `month` | int | No | Current | Month to query (1-12) |

---

## Embeddings (1 tool)

### `create_toothfairy_embedding`

Generate text embeddings for semantic search.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `api_key` | string | Yes | API key |
| `workspace_id` | string | Yes | Workspace UUID |
| `text` | string | Yes | Text to embed |
| `region` | string | No | API region (default: `"au"`) |

**Returns:** Vector embedding array.

---

## Fine-Tuning (6 tools)

Fine-tuning tools manage training jobs, datasets, and fine-tuned models. Supports SFT, DPO, GRPO, KTO, and CPT training methods with LoRA training on ToothFairyAI infrastructure.

**Note:** Fine-tuning API access requires Business or Enterprise subscription.

### Training Types

| Type | SDK Value | Document Source | Description |
|------|-----------|-----------------|-------------|
| SFT (Supervised Fine-Tuning) | `conversationalTraining` | Conversation documents | Standard instruction-following fine-tuning |
| DPO (Direct Preference Optimization) | `generativeTraining` | Preference documents | Train on chosen/rejected response pairs |
| GRPO (Group Relative Policy Optimization) | `grpoTraining` | Conversation documents | Self-generated completions with reward functions |
| KTO (Kahneman-Tversky Optimization) | `ktoTraining` | Preference documents | Unpaired preference training |
| CPT (Continued Pre-Training) | `continuedPretraining` | Conversation documents | Domain adaptation from plain text |

### Job Lifecycle

```
dispatched → inProgress → datasetReady → training → completed
                                                 ↘ inError
                                                 ↘ cancelled
```

### `list_toothfairy_trainable_models`

List all trainable models with configurations, supported training methods, instance types, and estimated UoI cost per hour. **PUBLIC endpoint — no authentication required.**

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `region` | string | No | `"au"` | API region |

**Returns:** List of trainable models with:
- Model ID, label, and size category
- Supported training methods (SFT, DPO)
- Instance type and estimated UoI/hour
- LoRA constraints (max rank, target modules)
- Fine-tuned model name prefix

**Example:**
```python
list_toothfairy_trainable_models()
```

---

### `list_toothfairy_training_jobs`

List all fine-tuning jobs for the authenticated workspace.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `region` | string | No | `"au"` | API region |

**Returns:** List of training jobs with ID, name, status, training type, base model, and timestamps.

---

### `generate_toothfairy_training_dataset`

Generate a training dataset from workspace documents. Returns a `training_log_id` for tracking progress.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `name` | string | Yes | - | Human-readable job name |
| `training_type` | string | Yes | - | Training method (see table above) |
| `base_model` | string | Yes | - | Model ID from `list_toothfairy_trainable_models` |
| `region` | string | No | `"au"` | API region |
| `topics` | list | No | None | Topic IDs to filter documents |
| `lora_r` | int | No | 8 | LoRA rank (1-128) |
| `lora_alpha` | int | No | 8 | LoRA alpha (1-128) |
| `num_epochs` | int | No | 1 | Training epochs |
| `batch_size` | int | No | 2 | Batch size per device |
| `learning_rate` | string | No | "2e-4" | Learning rate |
| `max_seq_length` | int | No | 2048 | Max sequence length |

**Returns:** Dict with `training_log_id`, `status` ("dispatched"), and `message`.

**Example:**
```python
generate_toothfairy_training_dataset(
    api_key="...",
    workspace_id="...",
    name="my-sft-job",
    training_type="conversationalTraining",
    base_model="toothfairyai/Llama-3.2-1B-Instruct",
    lora_r=16,
    num_epochs=3
)
```

---

### `get_toothfairy_training_status`

Get detailed status of a fine-tuning job including metrics and download URLs.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `training_log_id` | string | Yes | - | ID from `generate_toothfairy_training_dataset` |
| `region` | string | No | `"au"` | API region |

**Returns:** Training status with:
- Dataset info (paths, num examples)
- Training metadata (duration, UoI consumed, LoRA config, metrics)
- Presigned download URLs (LoRA adapter, config, metrics, charts)
- Error message if status is `inError`

**Example:**
```python
status = get_toothfairy_training_status(
    api_key="...",
    workspace_id="...",
    training_log_id="abc123-def456"
)
# Check if dataset is ready, then start training
if status["data"]["status"] == "datasetReady":
    start_toothfairy_training(...)
```

---

### `start_toothfairy_training`

Start a fine-tuning training job. The job must be in `datasetReady` status.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `training_log_id` | string | Yes | - | Training log ID |
| `region` | string | No | `"au"` | API region |
| `use_spot_instances` | bool | No | True | Use spot instances (up to 70% savings) |
| `hyperparameters_override` | dict | No | None | Override LoRA/epoch/lr/batch settings |
| `grpo_reward_funcs` | string | No | "default" | Reward functions for GRPO |
| `grpo_num_generations` | int | No | 4 | Completions per prompt for GRPO |
| `dpo_beta` | float | No | 0.1 | DPO preference strength |
| `kto_beta` | float | No | 0.1 | KTO beta parameter |

**Returns:** Dict with `training_log_id`, `status` ("training"), `estimated_uoi_cost`, `instance_type`.

**Example:**
```python
start_toothfairy_training(
    api_key="...",
    workspace_id="...",
    training_log_id="abc123-def456",
    use_spot_instances=True
)
```

---

### `cancel_toothfairy_training`

Cancel a running fine-tuning job.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `training_log_id` | string | Yes | - | Training log ID to cancel |
| `region` | string | No | `"au"` | API region |

**Returns:** Dict with `training_log_id`, `status` ("cancellationRequested"), and `message`.

---

## Training Data Generation - MagicWand (2 tools)

MagicWand transforms existing chat conversations or uploaded files into structured training data for fine-tuning. This is the data preparation step before running `generate_toothfairy_training_dataset`.

### `generate_toothfairy_training_data_from_chat`

Transform an existing chat conversation into training data.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `chat_id` | string | Yes | - | Chat UUID to transform |
| `training_type` | string | No | `"conversationalTraining"` | Training method |
| `user_id` | string | No | None | User UUID |
| `create_document` | bool | No | True | Create document in knowledge base |
| `system_message` | string | No | None | Custom system message for training data |
| `instructions` | string | No | None | LLM refinement instructions (e.g., "simplify responses") |
| `title` | string | No | None | Document title |
| `topics` | list | No | None | Topic IDs to associate |
| `status` | string | No | `"draft"` | "draft" or "published" |
| `scope` | string | No | `"training"` | "training" or "validation" |
| `non_preferred_responses` | list | No | None | For DPO - manually provided non-preferred responses |
| `tools` | list | No | None | Function calling tools schema |
| `generate_non_preferred` | bool | No | False | Auto-generate non-preferred for DPO |
| `region` | string | No | `"au"` | API region |

**Returns:** Dict with `rawTrainingData`, `messageCount`, `sourceType="chat"`, `documentCreated`, and optionally `document` details.

**Example:**
```python
generate_toothfairy_training_data_from_chat(
    api_key="...",
    workspace_id="...",
    chat_id="chat-uuid",
    training_type="conversationalTraining",
    instructions="Make responses more concise",
    create_document=True,
    topics=["topic-1", "topic-2"]
)
```

---

### `generate_toothfairy_training_data_from_file`

Transform an uploaded file into training data using LLM synthesis.

Supported file types: PDF, DOCX, XLSX, PPTX, TXT, MD, CSV, JSON.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `api_key` | string | Yes | - | API key |
| `workspace_id` | string | Yes | - | Workspace UUID |
| `file_key` | string | Yes | - | S3 file key (e.g., "workspace-id/document.pdf") |
| `training_type` | string | No | `"conversationalTraining"` | Training method |
| `user_id` | string | No | None | User UUID |
| `create_document` | bool | No | True | Create document in knowledge base |
| `system_message` | string | No | None | Custom system message |
| `instructions` | string | No | None | LLM refinement instructions |
| `title` | string | No | None | Document title |
| `topics` | list | No | None | Topic IDs to associate |
| `status` | string | No | `"draft"` | "draft" or "published" |
| `scope` | string | No | `"training"` | "training" or "validation" |
| `chunk_size` | int | No | 2000 | Characters per chunk (500-10000) |
| `overlap_percent` | float | No | 0.15 | Overlap between chunks (0.0-0.3) |
| `num_turns` | int | No | 5 | Conversation turns per chunk (1-10) |
| `samples_per_chunk` | int | No | 1 | Samples per chunk (1-3) |
| `region` | string | No | `"au"` | API region |

**Returns:** Dict with `rawTrainingData`, `messageCount`, `sourceType="file"`, `chunksProcessed`, `chunksConfig`, and optionally `document` details.

**Example:**
```python
generate_toothfairy_training_data_from_file(
    api_key="...",
    workspace_id="...",
    file_key="workspace-uuid/policy-handbook.pdf",
    training_type="conversationalTraining",
    chunk_size=3000,
    num_turns=8,
    instructions="Focus on policy compliance questions",
    create_document=True
)
```

---

## Common Workflows

### 1. Creating Your First Agent

```python
# Step 1: Validate credentials
validate_toothfairy_credentials(api_key="...", workspace_id="...", region="au")

# Step 2: Read the agent creation guide
get_agent_creation_guide(section="examples")

# Step 3: Create the agent
create_toothfairy_agent(
    api_key="...",
    workspace_id="...",
    label="Customer Support Agent",
    mode="retriever",
    interpolation_string="You are a helpful customer support agent for Acme Corp...",
    goals="Answer customer questions accurately using the knowledge base.",
    agentic_rag=True,
    temperature=0.3
)
```

### 2. Setting Up Knowledge Base

```python
# Create folder structure
create_toothfairy_folder(api_key="...", workspace_id="...", label="Product Docs")

# Add documents
create_toothfairy_document(
    api_key="...",
    workspace_id="...",
    title="Getting Started Guide",
    content="# Welcome to Acme...",
    folder_id="folder-uuid"
)

# Create topics for organization
create_toothfairy_entity(
    api_key="...",
    workspace_id="...",
    label="Pricing",
    entity_type="topic"
)
```

### 3. Sending Messages to an Agent

```python
# Send a message and get response
response = send_toothfairy_message(
    api_key="...",
    workspace_id="...",
    agent_id="agent-uuid",
    message="What are your business hours?"
)
```

---

## Error Handling

| Error | Cause | Solution |
|-------|-------|----------|
| `401 Unauthorized` | Invalid API key | Check key in Admin > API Integration |
| `403 Forbidden` | Insufficient permissions | Upgrade to Business/Enterprise |
| `404 Not Found` | Invalid ID or wrong endpoint | Verify UUIDs and API domain |
| `429 Too Many Requests` | Rate limit exceeded | Wait and retry with backoff |
| `Budget Exceeded` | Monthly UoI limit reached | Upgrade plan or wait for reset |

---

## Version History

- **0.5.6** - Initial comprehensive documentation aligned with SDK

