"""Skill template for creating ToothFairyAI agents.

This skill guides AI assistants through the agent creation process
with validation rules and example payloads.
"""

CREATE_AGENT_SKILL = {
    "name": "create-agent",
    "description": "Create a new ToothFairyAI agent with proper validation",
    "steps": [
        {
            "step": 1,
            "title": "Determine agent mode",
            "description": "Choose the appropriate agent mode based on use case",
            "options": {
                "retriever": "RAG-based agent with knowledge search (can enable agenticRAG, hasCode, charting)",
                "coder": "Code generation agent (REQUIRES has_code=True, CANNOT have agenticRAG)",
                "chatter": "Creative conversational agent (agenticRAG must be false)",
                "planner": "Planning and orchestration agent",
                "voice": "Voice-enabled agent (latency-sensitive, NEVER enable agenticRAG)",
                "accuracy": "High-accuracy mode for complex reasoning",
            },
        },
        {
            "step": 2,
            "title": "Validate mode-specific constraints",
            "description": "CRITICAL: These constraints are validated BEFORE API call",
            "constraints": {
                "coder_mode": {
                    "requires": "has_code=True",
                    "forbids": "agenticRAG=True",
                    "error": "Coder agents cannot have agenticRAG enabled",
                },
                "voice_mode": {
                    "forbids": "agenticRAG=True",
                    "reason": "Voice agents are latency-sensitive, agenticRAG adds overhead",
                },
                "retriever_mode": {
                    "allows": ["agenticRAG=True", "hasCode=True", "charting=True"],
                    "note": "Most flexible mode for knowledge-based agents",
                },
            },
        },
        {
            "step": 3,
            "title": "Set required parameters",
            "required": ["label", "mode", "interpolation_string", "goals", "api_key", "workspace_id"],
            "descriptions": {
                "label": "Human-readable agent name (string)",
                "mode": "Agent mode from: retriever, coder, chatter, planner, voice, accuracy",
                "interpolation_string": "System prompt/instructions for the agent (string)",
                "goals": "Agent's purpose and objectives (string)",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 4,
            "title": "Set optional parameters with validation",
            "optional": {
                "temperature": {
                    "type": "float",
                    "range": "0.001 to 1.0",
                    "default": 0.3,
                    "error": "Temperature must be between 0.001 and 1.0",
                },
                "max_tokens": {
                    "type": "integer",
                    "range": "positive integer",
                    "default": 4096,
                    "error": "max_tokens must be a positive integer",
                },
                "agentic_rag": {
                    "type": "boolean",
                    "constraint": "Mode-dependent (see step 2)",
                },
                "has_code": {
                    "type": "boolean",
                    "constraint": "REQUIRED for coder mode",
                },
                "charting": {
                    "type": "boolean",
                    "description": "Enable chart generation capabilities",
                },
                "parent_agent_id": {
                    "type": "string",
                    "api_field": "parentAgentID",
                    "description": "Parent agent ID for hierarchical agents",
                },
                "enable_json_output": {
                    "type": "boolean",
                    "default": False,
                    "description": "Enable structured JSON output mode",
                    "requires": "json_output_structure",
                },
                "json_output_structure": {
                    "type": "dict",
                    "description": "JSON schema defining the output structure (required if enable_json_output=True)",
                    "example": {
                        "type": "object",
                        "properties": {
                            "answer": {"type": "string"},
                            "confidence": {"type": "number"},
                            "sources": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                },
            },
        },
        {
            "step": 5,
            "title": "Build API payload with correct field mappings",
            "description": "SDK automatically converts snake_case to camelCase with exceptions",
            "field_mappings": {
                "parent_agent_id": "parentAgentID",
                "agentic_rag": "agenticRAG",
                "has_ner": "hasNER",
                "has_code": "hasCode",
                "allow_external_api": "allowExternalAPI",
                "code_execution_environment_id": "codeExecutionEnvironmentID",
                "custom_tooling_instructions": "customToolingInstructions",
                "use_interleaved_reasoning": "useInterleavedReasoning",
                "interleaved_preset": "interleavedPreset",
            },
        },
        {
            "step": 6,
            "title": "Configure Agentic Tooling 2.0 (RECOMMENDED for capable agents)",
            "description": "Agentic Tooling 2.0 (AT 2.0) enables an adaptive digital worker that autonomously decides which tools to use, when, and how many times. For any agent with tools (agent_functions), internet search (allow_internet_search), or code execution (has_code), you should enable useInterleavedReasoning=True unless the user specifically requests a simpler agent.",
            "fields": {
                "use_interleaved_reasoning": {
                    "type": "boolean",
                    "description": "Set to True to enable AT 2.0 mode. DEFAULT to True for any agent with tools, internet search, or code execution — unless the user explicitly wants a simpler setup.",
                    "constraints": [
                        "agenticRAG MUST be False (interleaved reasoning replaces and conflicts with agenticRAG)",
                        "reasoning_mode MUST be 'always'",
                        "llm_base_model MUST be an interleaved-capable model (only a subset of models support this mode — check available models before selecting)",
                    ],
                    "note": "Now available via the API. When enabled for retriever agents, you can also populate agentsPool to delegate subtasks to other agents (like planner mode).",
                },
                "custom_tooling_instructions": {
                    "type": "string",
                    "description": "CRITICAL for multi-function agents. Provides the agent with navigation logic: which functions to call when, how to chain them, and how to resolve parameters. Without this, the agent cannot effectively use its tools.",
                    "pattern": "Include: (1) Session bootstrap instructions - which functions to call at session start, (2) Navigation patterns - how to resolve user requests to specific functions, (3) Important rules - e.g., never ask for workspace ID if tfCustomerId is used.",
                },
                "interleaved_preset": {
                    "type": "string",
                    "description": "Execution preset for AT 2.0 - controls time limits and max tool calls. Recommended 'medium' for most capable agents.",
                    "options": ["short", "medium", "long", "marathon"],
                    "defaults": {"short": "30 min / 150 calls", "medium": "1 hr / 300 calls", "long": "2 hr / 500 calls", "marathon": "4 hr / 1000 calls"},
                    "note": "Available via the API. Use 'medium' as default for capable agents.",
                },
                "has_code": {
                    "type": "boolean",
                    "description": "Enable code execution for data aggregation and calculations. Recommended True for AT 2.0 agents that need to compute totals, filter data, or transform results.",
                },
            },
            "requirements": {
                "must_use_interleaved_model": True,
                "reasoning_mode": "always",
                "agentic_rag_must_be_false": True,
                "retriever_mode_only": True,
                "default_for_capable_agents": True,
            },
        },
        {
            "step": 7,
            "title": "Configure agentsPool for retriever+interleaved agents (optional)",
            "description": "When a retriever agent has useInterleavedReasoning=True, it can optionally populate agentsPool (like planner agents) to delegate subtasks to other agents. This turns a retriever into a capable delegating agent that can coordinate work across multiple specialist agents.",
            "fields": {
                "agents_pool": {
                    "type": "list[str]",
                    "description": "List of agent IDs that this retriever+interleaved agent can delegate tasks to. Works the same as agentsPool for planner mode — the agent can spawn or route tasks to these agents during execution. Only effective when useInterleavedReasoning=True.",
                    "note": "Previously agentsPool was only for planner mode. Now retriever agents with interleaved reasoning can also use it for delegation.",
                },
            },
        },
    ],
    "examples": {
        "minimal_retriever": {
            "description": "Minimal retriever agent with knowledge search",
            "payload": {
                "label": "Knowledge Assistant",
                "mode": "retriever",
                "interpolation_string": "You are a helpful knowledge assistant. Search the knowledge base to answer questions accurately.",
                "goals": "Help users find information from the knowledge base",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "coder_agent": {
            "description": "Code generation agent (NOTE: has_code=True is REQUIRED)",
            "payload": {
                "label": "Python Developer",
                "mode": "coder",
                "interpolation_string": "You are an expert Python developer. Write clean, efficient, well-documented code.",
                "goals": "Help users write and debug Python code",
                "has_code": True,
                "temperature": 0.2,
                "max_tokens": 8192,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
            "validation_note": "has_code MUST be True. agenticRAG MUST NOT be True.",
        },
        "advanced_retriever": {
            "description": "Advanced retriever with agenticRAG and charting",
            "payload": {
                "label": "Analytics Assistant",
                "mode": "retriever",
                "interpolation_string": "You are an analytics assistant. Search knowledge, analyze data, and create visualizations.",
                "goals": "Provide data insights with charts and visualizations",
                "agentic_rag": True,
                "charting": True,
                "temperature": 0.3,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "structured_output_retriever": {
            "description": "Retriever with structured JSON output for reliable parsing",
            "payload": {
                "label": "FAQ Bot",
                "mode": "retriever",
                "interpolation_string": "You are an FAQ assistant. Answer questions from the knowledge base. Always respond in structured JSON format.",
                "goals": "Provide structured answers to frequently asked questions",
                "enable_json_output": True,
                "json_output_structure": {
                    "type": "object",
                    "properties": {
                        "answer": {"type": "string"},
                        "confidence": {"type": "number"},
                        "sources": {"type": "array", "items": {"type": "string"}},
                    },
                },
                "temperature": 0.2,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "structured_output_chatter": {
            "description": "Chatter with structured JSON output for content generation",
            "payload": {
                "label": "Content Generator",
                "mode": "chatter",
                "interpolation_string": "You are a content generation assistant. Generate marketing copy in structured JSON format.",
                "goals": "Generate structured marketing content",
                "enable_json_output": True,
                "json_output_structure": {
                    "type": "object",
                    "properties": {
                        "headline": {"type": "string"},
                        "body": {"type": "string"},
                        "cta": {"type": "string"},
                        "tone": {"type": "string"},
                    },
                },
                "temperature": 0.7,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "temperature_out_of_range": {
            "cause": "temperature value outside 0.001-1.0 range",
            "solution": "Use a value between 0.001 and 1.0 (e.g., 0.3)",
        },
        "coder_without_has_code": {
            "cause": "Coder mode requires has_code=True",
            "solution": "Set has_code=True when mode='coder'",
        },
        "coder_with_agentic_rag": {
            "cause": "Coder mode cannot have agenticRAG enabled",
            "solution": "Remove agentic_rag=True or use retriever mode instead",
        },
        "voice_with_agentic_rag": {
            "cause": "Voice mode cannot have agenticRAG (latency impact)",
            "solution": "Remove agentic_rag=True for voice agents",
        },
        "json_output_without_structure": {
            "cause": "enable_json_output=True requires json_output_structure",
            "solution": "Provide a JSON schema in json_output_structure",
        },
        "invalid_json_structure": {
            "cause": "json_output_structure is not a valid JSON Schema",
            "solution": "Use proper JSON Schema format with type, properties, etc.",
        },
        "at20_without_custom_tooling_instructions": {
            "cause": "Agent has many functions but no customToolingInstructions, so it cannot navigate between tools effectively",
            "solution": "Write customToolingInstructions that define: (1) session bootstrap functions, (2) navigation patterns for each request type, (3) important rules like never asking for auto-injected params.",
        },
        "at20_without_reasoning": {
            "cause": "AT 2.0 (useInterleavedReasoning) requires reasoning_mode='always' and an interleaved-capable model",
            "solution": "Set reasoning_mode='always' and use an interleaved-capable model (only a subset of models support this mode).",
        },
        "at20_with_agentic_rag": {
            "cause": "useInterleavedReasoning=True and agenticRAG=True cannot both be enabled — they conflict",
            "solution": "Set agenticRAG=False when enabling useInterleavedReasoning. Interleaved reasoning replaces agenticRAG.",
        },
        "at20_with_non_interleaved_model": {
            "cause": "useInterleavedReasoning=True requires an interleaved-capable model, but a standard model was selected",
            "solution": "Use only an interleaved-capable model. Check available models for the interleaved-compatible subset.",
        },
    },
    "patterns": {
        "multi_function_agent": {
            "description": "When building an agent with many GraphQL functions against the same API, use this pattern",
            "key_principles": [
                "Organize functions into tiers: bootstrap (workspace-scoped), project-scoped, and entity-detail",
                "Use customToolingInstructions to tell the agent which tier to call and when",
                "Use static_args with tfCustomerId for workspace-scoped functions so the agent never asks for the workspace ID",
                "Write the interpolation_string (system prompt) with domain-specific context and data interpretation rules",
                "Enable has_code=True for data aggregation and calculation capabilities",
                "Use descriptive function names (fetch_X, fetch_X_by_Y) so the agent can select the right tool",
                "Write function descriptions that include WHEN to use them, not just WHAT they do",
            ],
            "critical_step": {
                "title": "ASSIGN functions to the agent after creating them",
                "description": "CRITICAL: Creating functions is NOT enough. Functions must be ASSIGNED to the agent via the agent_functions array. Without this step, the agent cannot see or use any of the functions you created.",
                "workflow": [
                    "1. Create all functions (collect function IDs from responses)",
                    "2. Update the agent with agent_functions: [<id1>, <id2>, ...] — include ALL function IDs, not just new ones",
                    "3. Verify the agent's agent_functions array contains all expected IDs",
                ],
                "field": "agent_functions",
                "api_field": "agentFunctions",
                "warning": "When updating agent_functions, you must provide the COMPLETE list. Omitting existing function IDs will REMOVE them from the agent. Always include all previously assigned IDs plus the new ones.",
            },
            "function_tiers": {
                "tier_1_bootstrap": {
                    "description": "Workspace-scoped list queries called at session start. Use static_args with tfCustomerId.",
                    "example_functions": "fetch_projects, fetch_clients, fetch_members, fetch_cost_codes",
                    "static_args_pattern": "{workspaceId: 'tfCustomerId', limit: 500}",
                },
                "tier_2_scoped": {
                    "description": "Scoped queries where the agent derives IDs from cached Tier 1 data. Dynamic parameter schema.",
                    "example_functions": "fetch_sheets_by_project, fetch_dockets_by_project",
                    "parameters_pattern": "{type: 'object', properties: {projectId: {type: 'string', description: 'The project ID'}}, required: ['projectId']}",
                },
                "tier_3_detail": {
                    "description": "Single entity lookups by ID from prior query results. Dynamic parameter schema.",
                    "example_functions": "fetch_project, fetch_docket, fetch_user",
                    "parameters_pattern": "{type: 'object', properties: {id: {type: 'string', description: 'The entity ID'}}, required: ['id']}",
                },
            },
            "custom_tooling_instructions_template": [
                "## Session Bootstrap",
                "On the FIRST user message, call these functions IN PARALLEL: [list bootstrap functions]",
                "",
                "## Navigation Patterns",
                "- User asks about X → find ID from cached data → call fetch_X_by_Y",
                "- User asks about costs → cross-reference with fetch_cost_codes + fetch_project_cost_codes",
                "",
                "## Important Rules",
                "- NEVER ask for workspace ID (auto-injected via tfCustomerId)",
                "- ALWAYS resolve names to IDs from cached data before detail queries",
                "- Call multiple functions in parallel when possible",
            ],
        },
    },
}