# Numera/Core/Matrices/matrix.py
import numpy as np
from . import _matrix_core as _core

class Matrix:
    def __init__(self, data):
        self._data = np.array(data, dtype=np.float64)
        if self._data.ndim != 2:
            raise ValueError("Une matrice doit être 2D")

    @property
    def shape(self):
        return self._data.shape

    @property
    def T(self):
        return Matrix(self._data.T)

    # ── Opérateurs ─────────────────────────────────────────────
    def __repr__(self):
        return f"Matrix(\n{self._data}\n)"

    def __add__(self, other):
        if isinstance(other, (int, float)):
            return Matrix(self._data + other)
        return Matrix(self._data + other._data)

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        if isinstance(other, (int, float)):
            return Matrix(self._data - other)
        return Matrix(self._data - other._data)

    def __rsub__(self, other):
        if isinstance(other, (int, float)):
            return Matrix(other - self._data)
        return Matrix(other._data - self._data)

    def __mul__(self, other):
        if isinstance(other, (int, float)):
            return Matrix(self._data * other)
        return Matrix(self._data * other._data)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        if isinstance(other, (int, float)):
            return Matrix(self._data / other)
        return Matrix(self._data / other._data)

    def __neg__(self):
        return Matrix(-self._data)

    def __matmul__(self, other):
        return Matrix(_core.dot(self._data, other._data))

    def __gt__(self, val):
        return Matrix((self._data > val).astype(np.float64))

    # ── Fonctions élément par élément ──────────────────────────
    def apply(self, func):
        """Applique une fonction sur chaque élément"""
        return Matrix(func(self._data))

    def exp(self):
        return Matrix(np.exp(self._data))

    def log(self):
        return Matrix(np.log(self._data + 1e-8))

    def clip(self, min_val, max_val):
        return Matrix(np.clip(self._data, min_val, max_val))

    def maximum(self, val):
        """ReLU-friendly : max(val, element)"""
        return Matrix(np.maximum(val, self._data))

    # ── Réductions ─────────────────────────────────────────────
    def sum(self, axis=None, keepdims=False):
        result = self._data.sum(axis=axis, keepdims=keepdims)
        if isinstance(result, np.ndarray) and result.ndim == 2:
            return Matrix(result)
        return result

    def mean(self, axis=None, keepdims=False):
        result = self._data.mean(axis=axis, keepdims=keepdims)
        if isinstance(result, np.ndarray) and result.ndim == 2:
            return Matrix(result)
        return result

    # ── Algèbre linéaire ───────────────────────────────────────
    def det(self):
        return _core.determinant(self._data)

    def inv(self):
        return Matrix(_core.inverse(self._data))

    def eigenvalues(self):
        return _core.eigen(self._data)