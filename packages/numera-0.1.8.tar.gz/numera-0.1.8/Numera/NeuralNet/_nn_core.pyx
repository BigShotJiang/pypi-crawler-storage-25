# Numera/NeuralNet/_nn_core.pyx
# cython: language_level=3
# cython: boundscheck=False
# cython: wraparound=False
# cython: cdivision=True

import numpy as np
cimport numpy as np
from libc.math cimport exp, log, sqrt, tanh, pow, fabs

# ── Génération de matrices ─────────────────────────────────────
def zeros(int rows, int cols):
    return np.zeros((rows, cols), dtype=np.float64)

def ones(int rows, int cols):
    return np.ones((rows, cols), dtype=np.float64)

def random_matrix(int rows, int cols):
    return np.random.randn(rows, cols)

# ── Fonctions d'activation ─────────────────────────────────────
def sigmoid(double[:, :] X):
    cdef int n = X.shape[0]
    cdef int m = X.shape[1]
    cdef np.ndarray[double, ndim=2] out = np.empty((n, m), dtype=np.float64)
    cdef double[:, :] ov = out
    cdef int i, j
    for i in range(n):
        for j in range(m):
            ov[i, j] = 1.0 / (1.0 + exp(-X[i, j]))
    return out

def sigmoid_deriv(double[:, :] X):
    cdef int n = X.shape[0]
    cdef int m = X.shape[1]
    cdef np.ndarray[double, ndim=2] out = np.empty((n, m), dtype=np.float64)
    cdef double[:, :] ov = out
    cdef double s
    cdef int i, j
    for i in range(n):
        for j in range(m):
            s = 1.0 / (1.0 + exp(-X[i, j]))
            ov[i, j] = s * (1.0 - s)
    return out

def relu(double[:, :] X):
    cdef int n = X.shape[0]
    cdef int m = X.shape[1]
    cdef np.ndarray[double, ndim=2] out = np.empty((n, m), dtype=np.float64)
    cdef double[:, :] ov = out
    cdef int i, j
    for i in range(n):
        for j in range(m):
            ov[i, j] = X[i, j] if X[i, j] > 0.0 else 0.0
    return out

def relu_deriv(double[:, :] X):
    cdef int n = X.shape[0]
    cdef int m = X.shape[1]
    cdef np.ndarray[double, ndim=2] out = np.empty((n, m), dtype=np.float64)
    cdef double[:, :] ov = out
    cdef int i, j
    for i in range(n):
        for j in range(m):
            ov[i, j] = 1.0 if X[i, j] > 0.0 else 0.0
    return out

def tanh_f(double[:, :] X):
    cdef int n = X.shape[0]
    cdef int m = X.shape[1]
    cdef np.ndarray[double, ndim=2] out = np.empty((n, m), dtype=np.float64)
    cdef double[:, :] ov = out
    cdef int i, j
    for i in range(n):
        for j in range(m):
            ov[i, j] = tanh(X[i, j])
    return out

def tanh_deriv(double[:, :] X):
    cdef int n = X.shape[0]
    cdef int m = X.shape[1]
    cdef np.ndarray[double, ndim=2] out = np.empty((n, m), dtype=np.float64)
    cdef double[:, :] ov = out
    cdef double t
    cdef int i, j
    for i in range(n):
        for j in range(m):
            t = tanh(X[i, j])
            ov[i, j] = 1.0 - t * t
    return out

def softmax(double[:, :] X):
    cdef int n = X.shape[0]
    cdef int m = X.shape[1]
    cdef np.ndarray[double, ndim=2] out = np.empty((n, m), dtype=np.float64)
    cdef double[:, :] ov = out
    cdef double row_max, row_sum
    cdef int i, j
    for i in range(n):
        row_max = X[i, 0]
        for j in range(1, m):
            if X[i, j] > row_max:
                row_max = X[i, j]
        row_sum = 0.0
        for j in range(m):
            ov[i, j] = exp(X[i, j] - row_max)
            row_sum += ov[i, j]
        for j in range(m):
            ov[i, j] /= row_sum
    return out

# ── Fonctions de perte ─────────────────────────────────────────
def mse(double[:, :] y_pred, double[:, :] y_true):
    """Mean Squared Error"""
    cdef int n = y_pred.shape[0]
    cdef int m = y_pred.shape[1]
    cdef double total = 0.0
    cdef double diff
    cdef int i, j
    for i in range(n):
        for j in range(m):
            diff = y_pred[i, j] - y_true[i, j]
            total += diff * diff
    return total / (n * m)

def mse_deriv(double[:, :] y_pred, double[:, :] y_true):
    """Dérivée MSE"""
    cdef int n = y_pred.shape[0]
    cdef int m = y_pred.shape[1]
    cdef np.ndarray[double, ndim=2] out = np.empty((n, m), dtype=np.float64)
    cdef double[:, :] ov = out
    cdef int i, j
    for i in range(n):
        for j in range(m):
            ov[i, j] = 2.0 * (y_pred[i, j] - y_true[i, j]) / (n * m)
    return out

def binary_cross_entropy(double[:, :] y_pred, double[:, :] y_true):
    """Binary Cross-Entropy"""
    cdef int n = y_pred.shape[0]
    cdef int m = y_pred.shape[1]
    cdef double total = 0.0
    cdef double p
    cdef int i, j
    for i in range(n):
        for j in range(m):
            p = y_pred[i, j]
            if p < 1e-8: p = 1e-8
            if p > 1.0 - 1e-8: p = 1.0 - 1e-8
            total += y_true[i, j] * log(p) + (1.0 - y_true[i, j]) * log(1.0 - p)
    return -total / n

def cross_entropy(double[:, :] y_pred, double[:, :] y_true):
    """Categorical Cross-Entropy (multiclasse)"""
    cdef int n = y_pred.shape[0]
    cdef int m = y_pred.shape[1]
    cdef double total = 0.0
    cdef double p
    cdef int i, j
    for i in range(n):
        for j in range(m):
            p = y_pred[i, j]
            if p < 1e-8: p = 1e-8
            total += y_true[i, j] * log(p)
    return -total / n

# ── Initialisation des poids ───────────────────────────────────
def xavier(int fan_in, int fan_out):
    """Initialisation Xavier / Glorot"""
    cdef double limit = sqrt(6.0 / (fan_in + fan_out))
    return np.random.uniform(-limit, limit, (fan_in, fan_out))

def he(int fan_in, int fan_out):
    """Initialisation He (recommandée pour ReLU)"""
    cdef double std = sqrt(2.0 / fan_in)
    return np.random.randn(fan_in, fan_out) * std