# Numera/Math/_math_core.pyx
# cython: language_level=3
# cython: boundscheck=False
# cython: wraparound=False
# cython: cdivision=True

import numpy as np
cimport numpy as np
from libc.math cimport log, log2, log10, exp, pow, sqrt, fabs
from libc.math cimport M_PI, M_E, INFINITY, NAN, floor, ceil, round, trunc
from libc.math cimport sin, cos, tan, asin, acos, atan, atan2
from libc.math cimport fmin, fmax, isnan, isinf
from libc.stdint cimport int64_t

# ── Constantes ─────────────────────────────────────────────────
PI   = M_PI
E    = M_E
PHI  = (1.0 + 5.0 ** 0.5) / 2.0
INF  = INFINITY
NAN_ = NAN

# ── Logarithmes ────────────────────────────────────────────────
def ln(double x):
    if x <= 0: raise ValueError("ln défini uniquement pour x > 0")
    return log(x)

def log_b(double x, double base=10.0):
    if x <= 0: raise ValueError("log défini uniquement pour x > 0")
    if base <= 0 or base == 1: raise ValueError("base invalide")
    return log(x) / log(base)

def log2_f(double x):
    if x <= 0: raise ValueError("log2 défini uniquement pour x > 0")
    return log2(x)

def log10_f(double x):
    if x <= 0: raise ValueError("log10 défini uniquement pour x > 0")
    return log10(x)

def log_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        if arr[i] <= 0: raise ValueError(f"Valeur non positive à l'indice {i}")
        out[i] = log(arr[i])
    return out

# ── Exponentielles & puissances ────────────────────────────────
def exp_f(double x):
    return exp(x)

def exp_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        out[i] = exp(arr[i])
    return out

def pow_f(double x, double p):
    return pow(x, p)

def sqrt_f(double x):
    if x < 0: raise ValueError("sqrt défini uniquement pour x >= 0")
    return sqrt(x)

def sqrt_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        if arr[i] < 0: raise ValueError(f"Valeur négative à l'indice {i}")
        out[i] = sqrt(arr[i])
    return out

# ── Sommes & produits ──────────────────────────────────────────
def sum_f(double[:] arr):
    cdef int n = arr.shape[0]
    cdef double total = 0.0
    cdef int i
    for i in range(n):
        total += arr[i]
    return total

def product(double[:] arr):
    cdef int n = arr.shape[0]
    cdef double total = 1.0
    cdef int i
    for i in range(n):
        total *= arr[i]
    return total

def cumsum(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef double acc = 0.0
    cdef int i
    for i in range(n):
        acc += arr[i]
        out[i] = acc
    return out

def cumprod(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef double acc = 1.0
    cdef int i
    for i in range(n):
        acc *= arr[i]
        out[i] = acc
    return out

def diff(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n - 1, dtype=np.float64)
    cdef int i
    for i in range(n - 1):
        out[i] = arr[i + 1] - arr[i]
    return out

# ── Combinatoire ───────────────────────────────────────────────
def factorial(int64_t n):
    if n < 0: raise ValueError("Factorielle définie pour n >= 0")
    if n == 0 or n == 1: return 1
    cdef int64_t result = 1
    cdef int64_t i
    for i in range(2, n + 1):
        result *= i
    return result

def combination(int64_t n, int64_t k):
    if k < 0 or k > n: raise ValueError("Invalide : besoin de 0 <= k <= n")
    if k == 0 or k == n: return 1
    if k > n - k: k = n - k
    cdef int64_t result = 1
    cdef int64_t i
    for i in range(k):
        result = result * (n - i) // (i + 1)
    return result

def permutation(int64_t n, int64_t k):
    if k < 0 or k > n: raise ValueError("Invalide : besoin de 0 <= k <= n")
    cdef int64_t result = 1
    cdef int64_t i
    for i in range(n, n - k, -1):
        result *= i
    return result

# ── Arrondis ───────────────────────────────────────────────────
def floor_f(double x):
    return floor(x)

def floor_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        out[i] = floor(arr[i])
    return out

def ceil_f(double x):
    return ceil(x)

def ceil_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        out[i] = ceil(arr[i])
    return out

def round_f(double x, int decimals=0):
    cdef double factor = 10.0 ** decimals
    return round(x * factor) / factor

def trunc_f(double x):
    return trunc(x)

# ── Valeurs ────────────────────────────────────────────────────
def abs_f(double x):
    return fabs(x)

def abs_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        out[i] = fabs(arr[i])
    return out

def sign_f(double x):
    if x > 0: return 1.0
    if x < 0: return -1.0
    return 0.0

def sign_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        if arr[i] > 0:   out[i] = 1.0
        elif arr[i] < 0: out[i] = -1.0
        else:            out[i] = 0.0
    return out

def min_f(double[:] arr):
    cdef int n = arr.shape[0]
    cdef double m = arr[0]
    cdef int i
    for i in range(1, n):
        if arr[i] < m: m = arr[i]
    return m

def max_f(double[:] arr):
    cdef int n = arr.shape[0]
    cdef double m = arr[0]
    cdef int i
    for i in range(1, n):
        if arr[i] > m: m = arr[i]
    return m

def clip_f(double x, double min_val, double max_val):
    if x < min_val: return min_val
    if x > max_val: return max_val
    return x

def clip_array(double[:] arr, double min_val, double max_val):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        if arr[i] < min_val:   out[i] = min_val
        elif arr[i] > max_val: out[i] = max_val
        else:                  out[i] = arr[i]
    return out

# ── Trigonométrie ──────────────────────────────────────────────
def sin_f(double x):
    return sin(x)

def sin_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        out[i] = sin(arr[i])
    return out

def cos_f(double x):
    return cos(x)

def cos_array(double[:] arr):
    cdef int n = arr.shape[0]
    cdef np.ndarray[double] out = np.empty(n, dtype=np.float64)
    cdef int i
    for i in range(n):
        out[i] = cos(arr[i])
    return out

def tan_f(double x):
    return tan(x)

def asin_f(double x):
    if x < -1 or x > 1: raise ValueError("asin défini pour x dans [-1, 1]")
    return asin(x)

def acos_f(double x):
    if x < -1 or x > 1: raise ValueError("acos défini pour x dans [-1, 1]")
    return acos(x)

def atan_f(double x):
    return atan(x)

def atan2_f(double y, double x):
    return atan2(y, x)

def degrees(double x):
    return x * (180.0 / M_PI)

def radians(double x):
    return x * (M_PI / 180.0)

# ── Comparaisons ───────────────────────────────────────────────
def isnan_f(double x):
    return bool(isnan(x))

def isinf_f(double x):
    return bool(isinf(x))

def isclose_f(double a, double b, double rel_tol=1e-9, double abs_tol=0.0):
    return fabs(a - b) <= fmax(rel_tol * fmax(fabs(a), fabs(b)), abs_tol)
