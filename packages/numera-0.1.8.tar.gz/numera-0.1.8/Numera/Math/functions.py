# Numera/Math/functions.py
import numpy as np
from . import _math_core as _core


class Math:

    # ── Constantes ─────────────────────────────────────────────
    PI  = _core.PI
    E   = _core.E
    PHI = _core.PHI
    INF = _core.INF
    NAN = _core.NAN_

    # ── Logarithmes ────────────────────────────────────────────
    @staticmethod
    def ln(x):
        """Logarithme naturel (base e)"""
        if hasattr(x, '__len__'):
            return _core.log_array(np.array(x, dtype=np.float64))
        return _core.ln(x)

    @staticmethod
    def log(x, base=10.0):
        """Logarithme en base quelconque (défaut base 10)"""
        return _core.log_b(x, base)

    @staticmethod
    def log2(x):
        return _core.log2_f(x)

    @staticmethod
    def log10(x):
        return _core.log10_f(x)

    # ── Exponentielles & puissances ────────────────────────────
    @staticmethod
    def exp(x):
        """e^x — accepte un scalaire ou une liste"""
        if hasattr(x, '__len__'):
            return _core.exp_array(np.array(x, dtype=np.float64))
        return _core.exp_f(x)

    @staticmethod
    def pow(x, p):
        return _core.pow_f(x, p)

    @staticmethod
    def sqrt(x):
        """Racine carrée — accepte un scalaire ou une liste"""
        if hasattr(x, '__len__'):
            return _core.sqrt_array(np.array(x, dtype=np.float64))
        return _core.sqrt_f(x)

    # ── Sommes & produits ──────────────────────────────────────
    @staticmethod
    def sum(arr):
        return _core.sum_f(np.array(arr, dtype=np.float64))

    @staticmethod
    def product(arr):
        return _core.product(np.array(arr, dtype=np.float64))

    @staticmethod
    def cumsum(arr):
        return _core.cumsum(np.array(arr, dtype=np.float64))

    @staticmethod
    def cumprod(arr):
        return _core.cumprod(np.array(arr, dtype=np.float64))

    @staticmethod
    def diff(arr):
        """Différences successives"""
        return _core.diff(np.array(arr, dtype=np.float64))

    # ── Combinatoire ───────────────────────────────────────────
    @staticmethod
    def factorial(n):
        """n! — ex: factorial(5) = 120"""
        return _core.factorial(n)

    @staticmethod
    def C(n, k):
        """Combinaisons C(n,k) — ex: C(5,2) = 10"""
        return _core.combination(n, k)

    @staticmethod
    def P(n, k):
        """Permutations P(n,k) — ex: P(5,2) = 20"""
        return _core.permutation(n, k)

    # ── Arrondis ───────────────────────────────────────────────
    @staticmethod
    def floor(x):
        if hasattr(x, '__len__'):
            return _core.floor_array(np.array(x, dtype=np.float64))
        return _core.floor_f(x)

    @staticmethod
    def ceil(x):
        if hasattr(x, '__len__'):
            return _core.ceil_array(np.array(x, dtype=np.float64))
        return _core.ceil_f(x)

    @staticmethod
    def round(x, decimals=0):
        return _core.round_f(x, decimals)

    @staticmethod
    def trunc(x):
        return _core.trunc_f(x)

    # ── Valeurs ────────────────────────────────────────────────
    @staticmethod
    def abs(x):
        if hasattr(x, '__len__'):
            return _core.abs_array(np.array(x, dtype=np.float64))
        return _core.abs_f(x)

    @staticmethod
    def sign(x):
        if hasattr(x, '__len__'):
            return _core.sign_array(np.array(x, dtype=np.float64))
        return _core.sign_f(x)

    @staticmethod
    def min(arr):
        return _core.min_f(np.array(arr, dtype=np.float64))

    @staticmethod
    def max(arr):
        return _core.max_f(np.array(arr, dtype=np.float64))

    @staticmethod
    def clip(x, min_val, max_val):
        if hasattr(x, '__len__'):
            return _core.clip_array(np.array(x, dtype=np.float64), min_val, max_val)
        return _core.clip_f(x, min_val, max_val)

    # ── Trigonométrie ───────────────────────────────────────────
    @staticmethod
    def sin(x):
        if hasattr(x, '__len__'):
            return _core.sin_array(np.array(x, dtype=np.float64))
        return _core.sin_f(x)

    @staticmethod
    def cos(x):
        if hasattr(x, '__len__'):
            return _core.cos_array(np.array(x, dtype=np.float64))
        return _core.cos_f(x)

    @staticmethod
    def tan(x):
        return _core.tan_f(x)

    @staticmethod
    def asin(x):
        return _core.asin_f(x)

    @staticmethod
    def acos(x):
        return _core.acos_f(x)

    @staticmethod
    def atan(x):
        return _core.atan_f(x)

    @staticmethod
    def atan2(y, x):
        return _core.atan2_f(y, x)

    @staticmethod
    def degrees(x):
        """Radians → degrés"""
        return _core.degrees(x)

    @staticmethod
    def radians(x):
        """Degrés → radians"""
        return _core.radians(x)

    # ── Comparaisons ───────────────────────────────────────────
    @staticmethod
    def isnan(x):
        return _core.isnan_f(x)

    @staticmethod
    def isinf(x):
        return _core.isinf_f(x)

    @staticmethod
    def isclose(a, b, rel_tol=1e-9, abs_tol=0.0):
        return _core.isclose_f(a, b, rel_tol, abs_tol)