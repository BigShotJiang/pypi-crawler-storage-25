import importlib
from dataclasses import dataclass

import pytest


@dataclass
class M:
    name: str
    stuff: str


@pytest.mark.parametrize(
    "m",
    [
        ## 1 Core
        (M("valarray.core", "ValidatedArray")),
        (M("valarray.core", "ArrayTypeAdapter")),
        (M("valarray.core", "Comparisons")),
        (M("valarray.core", "GenericErrors")),
        ### 1.1 validation functions
        (M("valarray.core.validation_functions", "validate_array")),
        (M("valarray.core.validation_functions", "validate_dtype")),
        (M("valarray.core.validation_functions", "validate_shape")),
        (M("valarray.core.validation_functions", "validate_array_values")),
        (M("valarray.core.validation_functions", "validate_field_values")),
        ### 1.1.1 validation functions utils
        (M("valarray.core.validation_functions.utils", "apply_validator")),
        ### 1.2 types
        (M("valarray.core.types", "ArrayP")),
        (M("valarray.core.types", "ArrayT")),
        (M("valarray.core.types", "DTypeLikeT")),
        (M("valarray.core.types", "DTypeT")),
        (M("valarray.core.types", "ArrayIndicesT")),
        (M("valarray.core.types", "ComparableValueT")),
        (M("valarray.core.types", "AxSizes")),
        (M("valarray.core.types", "ComparisonOperator")),
        ### 1.3 errors and exceptions
        (M("valarray.core.errors_exceptions", "ValidationErrorList")),
        (M("valarray.core.errors_exceptions", "ValidationError")),
        (M("valarray.core.errors_exceptions", "CannotCreateArrayError")),
        (M("valarray.core.errors_exceptions", "IncorrectDTypeError")),
        (M("valarray.core.errors_exceptions", "CannotCoerceDTypeError")),
        (M("valarray.core.errors_exceptions", "IncorrectAxNumberError")),
        (M("valarray.core.errors_exceptions", "IncorrectAxSizesError")),
        (M("valarray.core.errors_exceptions", "InvalidArrayValuesError")),
        (M("valarray.core.errors_exceptions", "InvalidFieldValuesError")),
        (M("valarray.core.errors_exceptions", "ValidationException")),
        (M("valarray.core.errors_exceptions", "CreateArrayException")),
        (M("valarray.core.errors_exceptions", "CoerceDTypeException")),
        ### 1.4 validators
        (M("valarray.core.validators", "ComparisonValidator")),
        (M("valarray.core.validators", "ValidationResult")),
        (M("valarray.core.validators", "Validator")),
        ### 1.5 utils
        (M("valarray.core.utils", "ax_sizes_from_schema")),
        (M("valarray.core.utils", "constraints_to_validators")),
        (M("valarray.core.utils", "setup_array")),
        ### 1.6 axes_and fields
        (M("valarray.core.axes_and_fields", "FieldsTuple")),
        (M("valarray.core.axes_and_fields", "AxesTuple")),
        (M("valarray.core.axes_and_fields", "Field")),
        ### 1.7 data_structures
        (M("valarray.core.data_structures", "AxisNameAndIdx")),
        (M("valarray.core.data_structures", "FieldNameAndIdx")),
        ### 1.8 string_utils
        (M("valarray.core.string_utils", "constraints_string")),
        (M("valarray.core.string_utils", "validators_heading_and_lines")),
        (M("valarray.core.string_utils", "field_heading_and_lines")),
        (M("valarray.core.string_utils", "array_name_and_type_string")),
        (M("valarray.core.string_utils", "dtype_string")),
        (M("valarray.core.string_utils", "schema_heading_and_lines")),
        (M("valarray.core.string_utils", "validated_array_heading_and_lines")),
        (M("valarray.core.string_utils", "offset_lines")),
        ## 2 Numpy
        (M("valarray.numpy", "ValidatedNumpyArray")),
        (M("valarray.numpy", "NumpyArrayTypeAdapter")),
        (M("valarray.numpy", "NumpyComparisons")),
        (M("valarray.numpy", "NumpyValidator")),
        (M("valarray.numpy", "NumpyErrors")),
        (M("valarray.numpy", "Field")),
        ### 2.1 validation functions
        (M("valarray.numpy.validation_functions", "validate_array")),
        (M("valarray.numpy.validation_functions", "validate_dtype")),
        (M("valarray.numpy.validation_functions", "validate_shape")),
        (M("valarray.numpy.validation_functions", "validate_array_values")),
        (M("valarray.numpy.validation_functions", "validate_field_values")),
        ### 2.2 types
        (M("valarray.numpy.types", "NumpyDTypeT")),
        (M("valarray.numpy.types", "AdvancedIndex")),
        ### 2.3 errors and exceptions
        (M("valarray.numpy.errors_exceptions", "NumpyIncorrectDTypeError")),
        (M("valarray.numpy.errors_exceptions", "NumpyCannotCoerceDTypeError")),
        (M("valarray.numpy.errors_exceptions", "NumpyInvalidArrayValuesError")),
        (M("valarray.numpy.errors_exceptions", "NumpyInvalidFieldValuesError")),
        ### 2.4 validators
        # NA
        ### 2.5 utils
        # NA
        ### 2.6 axes_and fields
        (M("valarray.core.axes_and_fields", "FieldsTuple")),
        (M("valarray.core.axes_and_fields", "AxesTuple")),
        (M("valarray.core.axes_and_fields", "Field")),
    ],
)
def test_imports(m: M):

    mod = importlib.import_module(m.name)

    if not m.stuff in dir(mod):
        raise ImportError(f"Cannot import: '{m.stuff}' from '{m.name}'")
