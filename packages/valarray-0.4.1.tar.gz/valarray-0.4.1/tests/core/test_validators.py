from collections.abc import Callable
from contextlib import nullcontext as does_not_raise

import pytest

from tests.core.classes_for_testing import (
    TestArray,
    TestBoolValidator,
    TestComparisons,
    TestDummyValidator,
    TestResultValidator,
    TestValueErrorValidator,
)
from tests.core.classes_for_testing.validators import (
    TestWithDescriptionDummyValidator,
    TestWitoutDescriptionAndReprDummyValidator,
)
from valarray.core.types import ArrayIndicesT, ArrayT, ComparisonOperator
from valarray.core.validation_functions.utils import apply_validator
from valarray.core.validators import ComparisonValidator, ValidationResult, Validator
from valarray.core.validators.value_comparisons import _get_comparison


@pytest.mark.parametrize(
    "operator, expected_fn, expectation",
    [
        ("lt", TestComparisons().where_not_lt, does_not_raise()),
        ("le", TestComparisons().where_not_le, does_not_raise()),
        ("ge", TestComparisons().where_not_ge, does_not_raise()),
        ("gt", TestComparisons().where_not_gt, does_not_raise()),
        ("eq", TestComparisons().where_not_eq, does_not_raise()),
        ("x", ..., pytest.raises(NotImplementedError)),
    ],
)
def test_get_comparison(
    operator: ComparisonOperator,
    expected_fn: Callable,
    expectation: does_not_raise | pytest.RaisesExc[Exception],
):
    with expectation:
        fn = _get_comparison(operator, TestComparisons())

    if not isinstance(expectation, does_not_raise):
        return

    assert (
        fn.__func__ == expected_fn.__func__
    ), "actual/expected values for 'fn' are not equal"


@pytest.mark.parametrize(
    "validator, expected_error_string",
    [
        (ComparisonValidator("lt", 0, TestComparisons()), ">= 0"),
        (ComparisonValidator("le", 0, TestComparisons()), "> 0"),
        (ComparisonValidator("ge", 0, TestComparisons()), "< 0"),
        (ComparisonValidator("gt", 0, TestComparisons()), "<= 0"),
        (ComparisonValidator("eq", 0, TestComparisons()), "!= 0"),
        (TestDummyValidator(), "TestDummyValidator"),
    ],
)
def test_validator_error_string(validator: Validator, expected_error_string: str):
    error_string = validator.error_string

    assert (
        error_string == expected_error_string
    ), "actual/expected values for 'error_string' are not equal"


@pytest.mark.parametrize(
    "validator, expected_description",
    [
        (
            ComparisonValidator("lt", 0, TestComparisons()),
            "ComparisonValidator(operator='lt', value=0, comparisons=TestComparisons())",
        ),
        (TestWithDescriptionDummyValidator(), "Dummy: description"),
        (
            TestWitoutDescriptionAndReprDummyValidator(),
            "TestWitoutDescriptionAndReprDummyValidator(...)",
        ),
    ],
)
def test_validator_description(validator: Validator, expected_description: str):
    description = validator.description

    assert (
        description == expected_description
    ), "actual/expected values for 'description' are not equal"


COMP_VAL = ComparisonValidator("gt", 0, TestComparisons())


@pytest.mark.parametrize(
    "validator, arr, expected_validation_result",
    [
        (COMP_VAL, TestArray(val=[1, 1, 1]), ValidationResult("OK")),
        (
            COMP_VAL,
            TestArray(val=[0, 1, 0]),
            ValidationResult("FAIL", indices_invalid=[0, 2]),
        ),
        (TestBoolValidator(), TestArray(val=[1]), ValidationResult("OK")),
        (TestBoolValidator(), TestArray(val=[0]), ValidationResult("FAIL")),
        (TestResultValidator(), TestArray(val=[1]), ValidationResult("OK")),
        (
            TestResultValidator(),
            TestArray(val=[0]),
            ValidationResult("FAIL", msg="result"),
        ),
        (TestValueErrorValidator(), TestArray(val=[1]), ValidationResult("OK")),
        (
            TestValueErrorValidator(),
            TestArray(val=[0]),
            ValidationResult("FAIL", msg="value_error"),
        ),
    ],
)
def test_apply_validator(
    validator: Validator[ArrayT, ArrayIndicesT],
    arr: ArrayT,
    expected_validation_result: ValidationResult,
):
    validation_result = apply_validator(validator, arr)

    assert (
        validation_result == expected_validation_result
    ), "actual/expected values for 'validation_result' are not equal"
    assert (
        validation_result == expected_validation_result
    ), "actual/expected values for 'validation_result' are not equal"
