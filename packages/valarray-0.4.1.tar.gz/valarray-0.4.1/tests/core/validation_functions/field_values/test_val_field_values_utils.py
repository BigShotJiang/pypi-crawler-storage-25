import pytest

from tests.core.classes_for_testing import (
    TestBoolValidator,
    TestComparisons,
    TestDummyValidator,
)
from valarray.core.axes_and_fields import AxesTuple, Field
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.validation_functions.field_values.types_and_data_structures import (
    _FieldValidatorDict,
    _ResolvedAx,
    _ResolvedAxesTuple,
    _ResolvedField,
)
from valarray.core.validation_functions.field_values.utils import (
    _resolve_field,
    gather_validators,
    resolve_schema,
)
from valarray.core.validators import ComparisonValidator

RESOLVED_FIELD_STR = _ResolvedField(
    FieldNameAndIdx(name="field_string", idx=0), tuple()
)
RESOLVED_FIELD_NO_NAME = _ResolvedField(FieldNameAndIdx(idx=0), validators=tuple())

RESOLVED_FIELD_WITH_VALIDATORS = _ResolvedField(
    FieldNameAndIdx(name="example_field", idx=0),
    validators=(
        ComparisonValidator(operator="ge", value=0, comparisons=TestComparisons()),
        TestDummyValidator(),
    ),
)


@pytest.mark.parametrize(
    "i, fld, expected_resolved_field",
    [
        (
            0,
            "field_string",
            RESOLVED_FIELD_STR,
        ),
        (
            0,
            Field(),
            RESOLVED_FIELD_NO_NAME,
        ),
        (
            0,
            Field(name="example_field", ge=0, validators=(TestDummyValidator(),)),
            RESOLVED_FIELD_WITH_VALIDATORS,
        ),
    ],
)
def test__resolve_field(
    i: int,
    fld: str | Field,
    expected_resolved_field: _ResolvedField,
):
    resolved_field = _resolve_field(i, fld, TestComparisons())

    assert (
        resolved_field == expected_resolved_field
    ), "actual/expected values for 'resolved_field' are not equal"


SCHEMA = (16, "example_ax", ("example_field",))

RESOLVED_SCHEMA = (
    _ResolvedAx(AxisNameAndIdx(name="_sized_16", idx=0), fields=tuple()),
    _ResolvedAx(AxisNameAndIdx(name="example_ax", idx=1), fields=tuple()),
    _ResolvedAx(
        AxisNameAndIdx(name="_sized_1", idx=2),
        fields=(
            _ResolvedField(FieldNameAndIdx(0, "example_field"), validators=tuple()),
        ),
    ),
)


@pytest.mark.parametrize(
    "array_schema, expected_resolved_schema",
    [
        (SCHEMA, RESOLVED_SCHEMA),
    ],
)
def test_resolve_schema(
    array_schema: AxesTuple,
    expected_resolved_schema: _ResolvedAxesTuple,
):
    comparisons = TestComparisons()
    resolved_schema = resolve_schema(array_schema, comparisons)

    assert (
        resolved_schema == expected_resolved_schema
    ), "actual/expected values for 'resolved_schema' are not equal"


COMP_VAL1 = ComparisonValidator("ge", 0, TestComparisons())
COMP_VAL2 = ComparisonValidator("lt", 10, TestComparisons())

RESOLVED_SCHEMA_WITH_VALIDATORS = (
    _ResolvedAx(AxisNameAndIdx(idx=0), fields=tuple()),
    _ResolvedAx(
        AxisNameAndIdx(idx=1),
        fields=(
            _ResolvedField(FieldNameAndIdx(0, "field_0"), validators=(COMP_VAL1,)),
        ),
    ),
    _ResolvedAx(
        AxisNameAndIdx(idx=2),
        fields=(
            _ResolvedField(
                FieldNameAndIdx(0, "example_field"),
                validators=(TestBoolValidator(),),
            ),
            _ResolvedField(
                FieldNameAndIdx(1, "field_1"), validators=(COMP_VAL1, COMP_VAL2)
            ),
            _ResolvedField(FieldNameAndIdx(2, "field_2"), validators=tuple()),
            _ResolvedField(FieldNameAndIdx(1, "field_4"), validators=(COMP_VAL1,)),
        ),
    ),
)
# pyright:reportUnhashable=false
# Because of *shenanigans* Validator subclasses do not have explicit __hash__ method defined,
# but are still hashable. This is not user facing, I can live with that.
EXPECTED_VAL_DICT = {
    COMP_VAL1: {
        AxisNameAndIdx(idx=1): [FieldNameAndIdx(0, "field_0")],
        AxisNameAndIdx(idx=2): [
            FieldNameAndIdx(1, "field_1"),
            FieldNameAndIdx(1, "field_4"),
        ],
    },
    TestBoolValidator(): {AxisNameAndIdx(idx=2): [FieldNameAndIdx(0, "example_field")]},
    COMP_VAL2: {AxisNameAndIdx(idx=2): [FieldNameAndIdx(1, "field_1")]},
}


@pytest.mark.parametrize(
    "resolved_schema, expected_val_dict",
    [
        (RESOLVED_SCHEMA_WITH_VALIDATORS, EXPECTED_VAL_DICT),
    ],
)
def test_gather_validators(
    resolved_schema: _ResolvedAxesTuple, expected_val_dict: _FieldValidatorDict
):
    val_dict = gather_validators(resolved_schema)

    assert (
        val_dict == expected_val_dict
    ), "actual/expected values for 'val_dict' are not equal"
