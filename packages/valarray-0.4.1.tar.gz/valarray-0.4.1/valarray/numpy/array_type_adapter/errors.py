from dataclasses import dataclass
from typing import Any

import numpy as np
import numpy.typing as npt

from valarray.core import GenericErrors
from valarray.numpy.errors_exceptions import (
    NumpyCannotCoerceDTypeError,
    NumpyIncorrectDTypeError,
    NumpyInvalidArrayValuesError,
    NumpyInvalidFieldValuesError,
)
from valarray.numpy.types import AdvancedIndex


@dataclass
class NumpyErrors(
    GenericErrors[npt.NDArray[Any], npt.DTypeLike, np.dtype, AdvancedIndex]
):
    """(introduced ***v0.2.4***, last_modified ***v0.4***)"""

    incorrect_dtype: type[NumpyIncorrectDTypeError] = NumpyIncorrectDTypeError
    cannot_coerce_dtype: type[NumpyCannotCoerceDTypeError] = NumpyCannotCoerceDTypeError
    invalid_array_values: type[NumpyInvalidArrayValuesError] = (
        NumpyInvalidArrayValuesError
    )
    invalid_field_values: type[NumpyInvalidFieldValuesError] = (
        NumpyInvalidFieldValuesError
    )
