from types import EllipsisType
from typing import Any, Generic

import numpy as np
import numpy.typing as npt

from valarray.core import ValidatedArray
from valarray.core.validators import Validator

from .array_type_adapter import NumpyArrayTypeAdapter
from .axes_and_fields import AxesTuple
from .types import AdvancedIndex, NumpyDTypeT


class ValidatedNumpyArray(
    ValidatedArray[npt.NDArray[Any], npt.DTypeLike, np.dtype, AdvancedIndex, object],
    Generic[NumpyDTypeT],
):
    """Base validated numpy array.

    To implement a validated array, inherit from this class and set the following class variables:
    - `dtype` - expected data type specification (such as `float`,`"float64"`, `np.float64`).
        If not specified, do not validate data type.
        For full list of accepted values, see:
            https://numpy.org/doc/stable/reference/arrays.dtypes.html#specifying-and-constructing-data-types
    - `schema` - expected shape specification (of type `valarray.numpy.axes_and_fields.AxesTuple`).
        If not specified, do not validate shape.
    - `lt`/`le`/`ge`/`gt`/`eq` - basic array value constraints -> less (or equal) than, greater (or equal) than, equal to
    - `validators` - optional list of validators applied to the whole array.

    You should also specify generic type variables:
    - `NumpyDTypeT` - data type hint for array accessed through `array`/`a_` property.

    ```
    class ExampleArray(ValidatedNumpyArray):
        dtype = np.float32

    class ExampleArray2(ValidatedNumpyArray):
        dtype = "float32"
    ```

    (introduced ***v0.1***, last_modified ***v0.3***)
    """

    schema: AxesTuple[NumpyDTypeT] | EllipsisType = ...
    validators: tuple[
        Validator[npt.NDArray[NumpyDTypeT], AdvancedIndex],
        ...,
    ] = ()

    @property
    def ata(self) -> NumpyArrayTypeAdapter:
        return NumpyArrayTypeAdapter()

    @property
    def array(self) -> npt.NDArray[NumpyDTypeT]:
        """Access underlying `np.array`

        (introduced ***v0.1***)
        """
        return self._array

    a_ = array
