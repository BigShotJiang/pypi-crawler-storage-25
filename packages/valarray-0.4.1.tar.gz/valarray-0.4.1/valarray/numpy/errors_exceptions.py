"""
*import* `NumpyIncorrectDTypeError` **ValidationError**

*import* `NumpyCannotCoerceDTypeError` **ValidationError**

*import* `NumpyInvalidArrayValuesError` **ValidationError**
"""

from typing import Any, Self

import numpy as np
import numpy.typing as npt

from valarray.core.errors_exceptions import (
    CannotCoerceDTypeError,
    IncorrectDTypeError,
    InvalidArrayValuesError,
    InvalidFieldValuesError,
)

from .types import AdvancedIndex


class NumpyIncorrectDTypeError(IncorrectDTypeError[npt.DTypeLike, np.dtype]):
    """***Validation error:*** Array has the wrong data type.

    Attributes:
        actual_dtype (np.dtype): Data type of the actual array.
        expected_dtype (np.dtype): Expected data type.
        expected_dtypelike (npt.DTypeLike):
            Expected data type specification (`numpy.typing.DTypeLike`)
            from `ValidatedArray.dtype`.

    Examples:
    ```
    err = NumpyIncorrectDTypeError(
        np.dtype(np.float32), np.dtype(np.float64), np.float64
    )
    print(err.msg)
    >>> "Incorrect DType: 'float32', expected 'float64'."
    ```

    (introduced ***v0.2.4***)
    """


class NumpyCannotCoerceDTypeError(CannotCoerceDTypeError[npt.DTypeLike, np.dtype]):
    """***Validation error:*** Array type adapter is not able to convert an existing array
    to specified data type when creating an instance of ValidatedArray.

    Attributes:
        actual_dtype (np.dtype): Data type of array passed to `ValidatedArray.__init__`.
        target_dtype (np.dtype): Data type to convert to (as a data type object).
        target_dtypelike (npt.DTypeLike):
            Expected data type specification (`numpy.typing.DTypeLike`) from `ValidatedArray.dtype`.

    Examples:
    ```
    err = NumpyCannotCoerceDTypeError(np.dtype("<U1"), np.dtype(int), int)
    print(err.msg)
    >>> "Cannot coerce data type from: '<U1' to 'int64'."
    ```

    (introduced ***v0.2.4***)
    """


class NumpyInvalidArrayValuesError(
    InvalidArrayValuesError[npt.NDArray[Any], AdvancedIndex]
):
    """***ValidationError:*** Array has wrong values.

    Attributes:
        validator: (Validator[npt.NDArray[Any], AdvancedIndex]):
            Validator applied to the whole array.
        invalid_values (Optional[list[Any]]):
            Values causing the validation to fail. Defaults to None.
        invalid_indices (Optional[AdvancedIndex]): Indices of invalid values.
        result_msg (Optional[str]): Optional message returned by validator.

    Examples:
    ```
    err = NumpyInvalidArrayValuesError(
        validator=ExampleValidator("bool"),
        invalid_values=[1],
        invalid_indices=np.array([[1, 1, 0], [1, 0, 1]], dtype=np.bool_),
    )
    print(err.msg)
    >>> Invalid Array Values (ExampleValidator):
        [1]

    err = NumpyInvalidArrayValuesError(
        validator=ExampleValidator("tuple"),
        invalid_values=[1],
        invalid_indices=(np.array([0, 1]), np.array([2, 1])),
    )

    print(err.msg)
    >>> Invalid Array Values (ExampleValidator):
        [1]
    ```

    (introduced ***v0.3***, last_modified ***v0.4***)"""

    def __eq__(self, other: Self):
        other_vars = vars(other)

        for k, v in vars(self).items():
            other_v = other_vars.get(k)

            # NOTE: stack, because field can be a tuple of arrays.
            # pyright complains, but numpy can actually stack `None's`
            stacked_v = np.stack([v])
            stacked_other_v = np.stack(
                [other_v]  # pyright: ignore[reportArgumentType,reportCallIssue]]
            )

            if not np.all(stacked_v == stacked_other_v):
                return False

        return True


class NumpyInvalidFieldValuesError(
    InvalidFieldValuesError[npt.NDArray[Any], AdvancedIndex]
):
    """***ValidationError:*** Field or fields have wrong values.

    Attributes:
        validator: (Validator[npt.NDArray[Any], AdvancedIndex]):
            Validator applied to array field(s).
        invalid_values (Optional[InvalidFieldValues]):
            Values causing the validation to fail, organized by axis and field. Defaults to None.

    Examples:
    ```
    err = NumpyInvalidFieldValuesError(
        validator=IsEvenValidator("bool"),
        invalid_values={
            AxisNameAndIdx(1, "example_axis"): {
                FieldNameAndIdx(0, "example_field"): [1]
            }
        },
    )
    print(err.msg)
    >>> Invalid Field Values (IsEvenValidator):
        Axis < 1 >: 'example_axis'
                Field < 0 >: 'example_field': [1]
    ```

    (introduced ***v0.4***)
    """
