"""
*import* `Validator` **ABC**

*import* `ValidationResult` **dataclass**

*import* `ComparisonValidator` **Validator**
"""

# pyright: reportUnusedImport=false

# NOTE: Wanted Validator to be imported from 'valarray.core', but that caused circular imports.
from .base import ValidationResult, Validator
from .value_comparisons import ComparisonValidator
