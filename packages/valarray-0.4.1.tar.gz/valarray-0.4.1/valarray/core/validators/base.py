from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Generic, Literal, Optional

from valarray.core.types import ArrayIndicesT, ArrayT


@dataclass
class ValidationResult(Generic[ArrayIndicesT]):
    """Result of `Validator.validate()` method.

    Attributes:
        status(Literal["OK", "FAIL"]): Whether validation is succesfull (`OK`) or not (`FAIL`).
        indices_invalid(Optional[ArrayIndicesT]):
            Optional indices of values that failed validation. Defaults to None.
        msg (Optional[str]): Optional message to be added to
            `valarray.core.errors_exceptions.InvalidArrayValuesError`.
            Defaults to None.

    (introduced ***v0.3***)
    """

    status: Literal["OK", "FAIL"]
    indices_invalid: Optional[ArrayIndicesT] = None
    msg: Optional[str] = None


class Validator(ABC, Generic[ArrayT, ArrayIndicesT]):
    """Generic validator base class.

    Type variables:
        - `ArrayT` - type of array object
        - `ArrayIndexT` - object(s) that can select values from array using `__getitem__` method.

    Subclasses need to implement:
        **abstract method**
        - `validate` -
            Method to validate an array.

    Subclasses can optionally implement:
        **abstract property**
        - `error_string` -
            String representation of validator used in error messages.
            If not implemented defaults to class name.
        - `description` -
            String representation of validator used in `__str__` method
            of `ValidatedArrray` or `Field`. Should fit on one line.
            If not implemented defaults to `__repr__` (which defaults to `<ClassName>(...)`).

    (introduced ***v0.3***)
    """

    @abstractmethod
    def validate(
        self, arr: ArrayT
    ) -> Optional[bool | ValidationResult[ArrayIndicesT]]: ...

    @property
    def error_string(self) -> str:
        return self.__class__.__name__

    @property
    def description(self) -> str:
        return repr(self)

    def __repr__(self) -> str:
        """Default repr: `<ClassName>(...)`"""
        return f"{self.__class__.__name__}(...)"

    # HACK: This nonsense should ensure that every subclass has a hash method that
    # returns hash created from instance attributes after initialization and class name
    def __post_init__(self):
        cls_name = self.__class__.__name__
        name_hash = int.from_bytes(
            cls_name.encode("utf-8"), byteorder="big", signed=False
        )

        # NOTE: hash of vars().values() is not deterministic, but converted to tuple it is
        attr_hash = hash(tuple(vars(self).values()))

        self.__hash = name_hash + attr_hash  # pylint:disable=W0201
        self.__class__.__hash__ = Validator.__hash__

    def __hash__(self) -> int:
        return self.__hash
