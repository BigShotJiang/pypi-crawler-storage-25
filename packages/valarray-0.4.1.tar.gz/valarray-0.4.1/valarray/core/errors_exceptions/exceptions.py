from typing import Generic, Optional

from .error_list import ValidationErrorList
from .validation_errors.array_creation import CannotCreateArrayError
from .validation_errors.base import ValidationErrorT
from .validation_errors.dtype import CannotCoerceDTypeError


# TODO: ugh, typing issues, pls fix ->
# except ValidationException as exc:
#    exc.errs -> 'Unknown'
class ValidationException(ValueError, Generic[ValidationErrorT]):
    """Exception caused by failed array validation.

    Attributes:
        cls_name (Optional[str]):
            Optional name of ValidatedArray subclass that caused this exception.
        errs (ValidationErrorList[ValidationError):
            List of validation errors responsible.

    (introduced ***v0.1***, last_modified ***v0.4***)
    """

    def __init__(
        self,
        cls_name: Optional[str],
        errs: ValidationErrorList[ValidationErrorT],
        *args: object,
    ) -> None:

        super().__init__(*args)

        self.cls_name = cls_name
        self.errs = errs
        """List of validation errors."""

    def __str__(self) -> str:
        prefix = f"'{self.cls_name}' " if self.cls_name is not None else ""
        err_msgs = "\n".join([e.msg for e in self.errs])
        return f"{prefix}validation failed:\n" + err_msgs


class CreateArrayException(ValidationException):
    """Special case of `ValidationException`
    on failure to create a validated array from generic data.

    Attributes:
        cls_name (str):
            Name of ValidatedArray subclass that caused this exception.
        errs (ValidationErrorList[CannotCreateArrayError]): List containing error responsible.

    (introduced ***v0.1***, last_modified ***v0.4***)
    """

    def __init__(self, cls_name: str) -> None:
        super().__init__(
            cls_name=cls_name, errs=ValidationErrorList([CannotCreateArrayError()])
        )


class CoerceDTypeException(ValidationException):
    """Special case of `ValidationException`
    on failure to coerce the data type of an existing array.

    Attributes:
        cls_name (str):
            Name of ValidatedArray subclass that caused this exception.
        errs (ValidationErrorList[CannotCoerceDTypeError]):
            List containing error with actual and target data type information.

    (introduced ***v0.1***, last_modified ***v0.4***)
    """

    def __init__(self, cls_name: str, err: CannotCoerceDTypeError) -> None:
        super().__init__(cls_name=cls_name, errs=ValidationErrorList([err]))
