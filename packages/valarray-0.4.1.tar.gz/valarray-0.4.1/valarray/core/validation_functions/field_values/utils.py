from functools import lru_cache
from typing import Any, Literal

from valarray import settings
from valarray.core.array_type_adapter import ArrayTypeAdapter, Comparisons
from valarray.core.axes_and_fields import AxesTuple, Field
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.types import ArrayIndicesT, ArrayT, ComparableValueT
from valarray.core.utils import constraints_to_validators
from valarray.core.validation_functions.utils import apply_validator

from .types_and_data_structures import (
    AnyValidator,
    _FieldValidatorDict,
    _ResolvedAx,
    _ResolvedAxesTuple,
    _ResolvedField,
)


def _resolve_field(
    i: int,
    fld: str | Field[ArrayT, ArrayIndicesT, ComparableValueT],
    comparisons: Comparisons[ArrayT, ArrayIndicesT, ComparableValueT],
) -> _ResolvedField[ArrayT, ArrayIndicesT, ComparableValueT]:
    """Get index, (optional) name and full list of validators for field.

    ## Examples:
    ```
    _resolve_field(i=0, fld="field_string", comparisons=...)
    >>> _ResolvedField(FieldNameAndIdx(name="field_string", idx=0), [])

    _resolve_field(
        i=0,
        fld=Field(name="example_field", ge=0, validators=()),
        comparisons=...,
    )
    >>> _ResolvedField(
        FieldNameAndIdx(name="example_field", idx=0),
        validators=[] + [ComparisonValidator(operator="ge", value=0, comparisons=...)],
    )

    _resolve_field(
        i=0,
        fld=Field(),
        comparisons=NumpyComparisons(),
    )
    >>> _ResolvedField(FieldNameAndIdx(idx=0), validators=[])
    ```
    """
    if isinstance(fld, str):
        return _ResolvedField(FieldNameAndIdx(i, fld), tuple())

    validators = constraints_to_validators(
        fld.lt, fld.le, fld.ge, fld.gt, fld.eq, comparisons
    ) + list(fld.validators)

    return _ResolvedField(FieldNameAndIdx(i, fld.name), tuple(validators))


@lru_cache(settings.function_cache_size)
def resolve_schema(
    array_schema: AxesTuple[ArrayT, ArrayIndicesT, ComparableValueT],
    comparisons: Comparisons[ArrayT, ArrayIndicesT, ComparableValueT],
) -> _ResolvedAxesTuple[ArrayT, ArrayIndicesT, ComparableValueT]:
    """Get name, index and list of field for each axis in schema.

    ## Example:
    ```
    resolve_schema(
        (16, "example_ax", ("example_field",)), TestComparisons()
    )
    >>> (
        _ResolvedAx(AxisNameAndIdx(name="axis_0_len_16", idx=0), fields=[]),
        _ResolvedAx(AxisNameAndIdx(name="example_ax", idx=1), fields=[]),
        _ResolvedAx(
            AxisNameAndIdx(name="axis_2_len_1", idx=2),
            fields=[
                _ResolvedField(FieldNameAndIdx("example_field", idx=0), validators=[])
            ],
        ),
    )
    ```
    """
    axes: list[_ResolvedAx[ArrayT, ArrayIndicesT, ComparableValueT]] = []

    for ax_i, ax in enumerate(array_schema):
        if isinstance(ax, str):
            name = ax
        else:
            size = ax if isinstance(ax, int) else len(ax)
            name = f"_sized_{size}"

        if isinstance(ax, (str, int)):
            fields = []
        else:
            fields = [_resolve_field(f_i, f, comparisons) for f_i, f in enumerate(ax)]

        axes.append(_ResolvedAx(AxisNameAndIdx(ax_i, name), tuple(fields)))

    return tuple(axes)


@lru_cache(settings.function_cache_size)
def gather_validators(
    resolved_schema: _ResolvedAxesTuple[ArrayT, ArrayIndicesT, ComparableValueT],
) -> _FieldValidatorDict[ArrayT, ArrayIndicesT, ComparableValueT]:
    val_dict: _FieldValidatorDict[ArrayT, ArrayIndicesT, ComparableValueT] = {}

    for ax in resolved_schema:
        for fld in ax.fields:
            for val in fld.validators:
                if val_dict.get(val) is None:
                    val_dict[val] = {}

                if val_dict[val].get(ax.name_and_index) is None:
                    val_dict[val][ax.name_and_index] = []

                val_dict[val][ax.name_and_index].append(fld.name_and_index)

    return val_dict


def process_axis(
    arr: ArrayT,
    validator: AnyValidator[ArrayT, ArrayIndicesT, ComparableValueT],
    ax: AxisNameAndIdx,
    fields: list[FieldNameAndIdx],
    ata: ArrayTypeAdapter[ArrayT, Any, Any, ArrayIndicesT, ComparableValueT],
) -> tuple[Literal["FAIL", "OK"], dict[FieldNameAndIdx, Any] | None]:
    arr_subset = ata.select_subset(arr, ax, fields)

    res = apply_validator(validator, arr_subset)

    if res.status == "FAIL":
        invalid_values = ata.get_values_from_subset(
            arr_subset, res.indices_invalid, ax, fields
        )
    else:
        invalid_values = None

    return res.status, invalid_values
