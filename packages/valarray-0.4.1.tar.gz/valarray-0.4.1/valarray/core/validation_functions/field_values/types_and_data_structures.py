from dataclasses import dataclass
from typing import Generic

from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.types import ArrayIndicesT, ArrayT, ComparableValueT
from valarray.core.validators import ComparisonValidator, Validator

AnyValidator = (
    Validator[ArrayT, ArrayIndicesT]
    | ComparisonValidator[ArrayT, ArrayIndicesT, ComparableValueT]
)

# NOTE: fields and validators for _ResolvedAx and _ResolvedField need to be tuples,
# because lru_cache need function inputs and outputs to be hashable and list isn't


@dataclass(unsafe_hash=True)
class _ResolvedField(Generic[ArrayT, ArrayIndicesT, ComparableValueT]):
    """Field name and index + list of all validators (including `ComparisonValidator`s)

    ### Example:
    ```
    _ResolvedField(
        name_and_index=FieldNameAndIdx(name="example_field", idx=1),
        validators=[
            ComparisonValidator(operator="ge", value=1, comparisons=...),
            ...
        ],
    )
    ```
    """

    name_and_index: FieldNameAndIdx

    validators: tuple[AnyValidator, ...]

    def __str__(self) -> str:
        val_list = [f"-> '{str(v)}': {repr(v)}" for v in self.validators]
        val_s = "\n" + "\n".join(val_list) if val_list else " -> NA"
        return str(self.name_and_index) + val_s


@dataclass(unsafe_hash=True)
class _ResolvedAx(Generic[ArrayT, ArrayIndicesT, ComparableValueT]):
    """Axis name and index + list of fields (name and index + list of all validators)

    ### Example:
    ```
    _ResolvedAx(
        name_and_index=AxisNameAndIdx("example_axis", idx=0),
        fields=[
            _ResolvedField(
                name_and_index=FieldNameAndIdx(name="example_field_a", idx=0),
                validators=[
                    ComparisonValidator(
                        operator="ge", value=1, comparisons=...
                    ),
                    ...
                ],
            ),
            _ResolvedField(
                name_and_index=FieldNameAndIdx(name="example_field", idx=1),
                validators=[
                    ComparisonValidator(
                        operator="lt", value=100, comparisons=...
                    ),
                    ...
                ],
            ),
        ],
    )
    ```
    """

    name_and_index: AxisNameAndIdx
    fields: tuple[_ResolvedField[ArrayT, ArrayIndicesT, ComparableValueT], ...]

    def __str__(self) -> str:
        val_s = (
            "\n\n" + "\n".join([str(f) for f in self.fields])
            if self.fields
            else " -> NA"
        )
        return str(self.name_and_index) + val_s


_ResolvedAxesTuple = tuple[_ResolvedAx[ArrayT, ArrayIndicesT, ComparableValueT], ...]


_FieldValidatorDict = dict[
    AnyValidator[ArrayT, ArrayIndicesT, ComparableValueT],
    dict[AxisNameAndIdx, list[FieldNameAndIdx]],
]
