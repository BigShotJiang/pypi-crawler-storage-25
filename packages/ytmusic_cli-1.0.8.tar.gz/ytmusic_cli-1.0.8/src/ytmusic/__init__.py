"""YouTube Music Library - Download YouTube playlists with metadata."""

from importlib import metadata

__all__ = ["__version__"]

try:
    __version__ = metadata.version("ytmusic-cli")
except metadata.PackageNotFoundError:  # pragma: no cover - local dev without install
    __version__ = "0.0.0"
