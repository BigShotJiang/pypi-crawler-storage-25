"""YouTube playlist and audio downloading functionality."""

import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from pytubefix import Playlist, YouTube
from pytubefix.cli import on_progress
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn

from ytmusic.metadata import download_cover_art, search_itunes_metadata
from ytmusic.tagger import embed_metadata
from ytmusic.utils import extract_song_info, format_filename_from_metadata, sanitize_filename

console = Console()


class PlaylistDownloader:
    """Handles downloading and processing of YouTube playlists."""

    def __init__(self, similarity_threshold: float = 0.5, output_dir: str = "music_library"):
        self.similarity_threshold = similarity_threshold
        self.output_dir = Path(output_dir)
        self.skipped_count = 0
        self.downloaded_count = 0
        self.error_count = 0

    def get_best_audio_stream(self, yt: YouTube) -> Optional:
        """Get the best quality audio-only stream."""
        audio_streams = yt.streams.filter(only_audio=True)

        if not audio_streams:
            return None

        # Prefer AAC/mp4a codec for best compatibility
        for stream in audio_streams:
            if stream.audio_codec and ("mp4a" in stream.audio_codec or "aac" in stream.audio_codec):
                return stream

        # Fall back to first available
        return audio_streams.first()

    def _unique_path(self, path: Path) -> Path:
        """Ensure output path does not collide with an existing file."""
        if not path.exists():
            return path

        counter = 1
        while True:
            candidate = path.with_name(f"{path.stem}_{counter}{path.suffix}")
            if not candidate.exists():
                return candidate
            counter += 1

    def _convert_to_m4a(self, source_path: Path) -> Path | None:
        """Convert audio to M4A using ffmpeg if available."""
        if shutil.which("ffmpeg") is None:
            return None

        target_path = self._unique_path(source_path.with_suffix(".m4a"))
        try:
            subprocess.run(
                [
                    "ffmpeg",
                    "-y",
                    "-i",
                    str(source_path),
                    "-vn",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "192k",
                    str(target_path),
                ],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return target_path
        except subprocess.CalledProcessError:
            return None

    def download_song(self, video_url: str, playlist_dir: Path, idx: int, total: int) -> bool:
        """Download and process a single song. Returns True if successful."""
        try:
            yt = YouTube(video_url, on_progress_callback=on_progress)
            youtube_title = yt.title

            # Extract song info
            artist, song = extract_song_info(youtube_title)

            # Search metadata first (before downloading)
            metadata = None
            similarity = 0.0

            if artist and song:
                metadata, similarity = search_itunes_metadata(artist, song, youtube_title)

            if not metadata:
                metadata, similarity = search_itunes_metadata(None, youtube_title, youtube_title)

            # Skip if similarity is too low
            if similarity < self.similarity_threshold:
                console.print(
                    f"[yellow]⏭[/yellow] Skipping (low similarity {similarity:.0%}): {youtube_title}"
                )
                self.skipped_count += 1
                return False

            # Generate filename from metadata
            target_filename = format_filename_from_metadata(metadata) or sanitize_filename(
                youtube_title
            )
            target_filename = sanitize_filename(target_filename)

            # Check if already exists
            existing_files = list(playlist_dir.glob(f"{target_filename}.*"))
            if existing_files:
                console.print(
                    f"[yellow]⏭[/yellow] Skipping (already exists): {existing_files[0].name}"
                )
                self.skipped_count += 1
                return False

            # Get audio stream
            audio_stream = self.get_best_audio_stream(yt)
            if not audio_stream:
                console.print(f"[red]✗[/red] No audio stream for: {youtube_title}")
                self.error_count += 1
                return False

            # Download
            temp_file = audio_stream.download(output_path=str(playlist_dir), filename=f"temp_{idx}")
            file_ext = Path(temp_file).suffix

            # Rename to final filename
            final_filename = f"{target_filename}{file_ext}"
            final_path = playlist_dir / final_filename

            # Handle duplicates
            final_path = self._unique_path(final_path)

            os.rename(temp_file, final_path)

            # Convert unsupported formats to M4A if possible
            supported_exts = {".m4a", ".mp4", ".aac", ".mp3"}
            if final_path.suffix.lower() not in supported_exts:
                converted_path = self._convert_to_m4a(final_path)
                if converted_path:
                    final_path.unlink(missing_ok=True)
                    final_path = converted_path
                    file_ext = final_path.suffix
                else:
                    console.print(
                        "[yellow]⚠ Unsupported format and ffmpeg not available for conversion.[/yellow]"
                    )

            # Download cover art
            cover_art = None
            if metadata and metadata.get("cover_url"):
                cover_art = download_cover_art(metadata["cover_url"])

            # Embed metadata
            embed_metadata(str(final_path), file_ext, metadata, cover_art)

            console.print(
                f"[green]✓[/green] Downloaded: [bold]{final_path.name}[/bold] ([cyan]{similarity:.0%}[/cyan] match)"
            )
            self.downloaded_count += 1
            return True

        except Exception as e:
            console.print(f"[red]✗[/red] Error processing video: {e}")
            self.error_count += 1
            return False

    def process(self, playlist_url: str):
        """Process entire playlist."""
        console.print(
            Panel.fit(
                "[bold cyan]🎵 YouTube Music Library[/bold cyan]",
                subtitle=f"Threshold: {self.similarity_threshold:.0%}",
                border_style="cyan",
            )
        )

        # Fetch playlist info
        with console.status("[bold green]Fetching playlist info..."):
            playlist = Playlist(playlist_url)
            playlist_title = sanitize_filename(playlist.title)

        console.print(f"[green]✓[/green] Playlist: [bold]{playlist.title}[/bold]")
        console.print(f"[green]✓[/green] {len(playlist.video_urls)} videos\n")

        # Create output directory
        playlist_dir = self.output_dir / playlist_title
        playlist_dir.mkdir(parents=True, exist_ok=True)

        # Process videos
        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(bar_width=40),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Processing songs...", total=len(playlist.video_urls))

            for idx, video_url in enumerate(playlist.video_urls, 1):
                progress.update(task, description=f"[{idx}/{len(playlist.video_urls)}]")
                self.download_song(video_url, playlist_dir, idx, len(playlist.video_urls))
                progress.advance(task)

        # Summary
        console.print("\n[bold green]✓ Complete![/bold green]")
        console.print(f"  Downloaded: {self.downloaded_count}")
        console.print(f"  Skipped: {self.skipped_count}")
        console.print(f"  Errors: {self.error_count}")
        console.print(f"\nLocation: {playlist_dir}")
