"""Utilities for string manipulation and file operations."""

import re
from difflib import SequenceMatcher


def sanitize_filename(filename: str) -> str:
    """Remove invalid characters from filename."""
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, "")
    return filename.strip()


def calculate_similarity(a: str, b: str) -> float:
    """Calculate similarity ratio between two strings (0.0 to 1.0)."""
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def extract_song_info(title: str) -> tuple:
    """
    Extract artist and song title from YouTube video title.
    Common formats: "Artist - Song", "Artist — Song", "Artist: Song"
    """
    patterns = [
        r"^(.*?)\s*[-—:]\s*(.*?)(?:\s*\(|\s*\[|$)",  # Artist - Song
        r'^(.*?)\s+"(.*?)"',  # Artist "Song"
    ]

    for pattern in patterns:
        match = re.match(pattern, title.strip())
        if match:
            artist = match.group(1).strip()
            song = match.group(2).strip()
            return artist, song

    return None, title.strip()


def format_filename_from_metadata(metadata: dict) -> str:
    """Generate filename from metadata (Artist - Song format)."""
    if metadata.get("artist") and metadata.get("title"):
        return f"{metadata['artist']} - {metadata['title']}"
    return None
