"""Music metadata search and embedding functionality."""

from typing import Any

import requests
from rich.console import Console

from ytmusic.utils import calculate_similarity

console = Console()
ITUNES_SEARCH_URL = "https://itunes.apple.com/search"


def search_itunes_metadata(
    artist: str, song: str, original_title: str
) -> tuple[dict[str, Any] | None, float]:
    """Search for song metadata on iTunes API. Returns metadata and similarity score."""
    try:
        query = f"{artist} {song}" if artist else song
        params = {"term": query, "media": "music", "entity": "song", "limit": 5}

        response = requests.get(ITUNES_SEARCH_URL, params=params, timeout=10)
        data = response.json()

        if data["resultCount"] > 0:
            best_match = None
            best_similarity = 0.0

            for result in data["results"]:
                result_title = result.get("trackName", "")
                result_artist = result.get("artistName", "")

                # Calculate similarity with original title
                full_result = f"{result_artist} - {result_title}"
                similarity = calculate_similarity(original_title, full_result)

                # Also check individual components
                title_sim = calculate_similarity(song.lower(), result_title.lower())
                if artist:
                    artist_sim = calculate_similarity(artist.lower(), result_artist.lower())
                    similarity = max(similarity, (title_sim + artist_sim) / 2)
                else:
                    similarity = max(similarity, title_sim)

                if similarity > best_similarity:
                    best_similarity = similarity
                    best_match = {
                        "title": result.get("trackName"),
                        "artist": result.get("artistName"),
                        "album": result.get("collectionName"),
                        "year": result.get("releaseDate", "")[:4]
                        if result.get("releaseDate")
                        else None,
                        "genre": result.get("primaryGenreName"),
                        "cover_url": result.get("artworkUrl100", "").replace(
                            "100x100bb", "600x600bb"
                        ),
                        "track_number": result.get("trackNumber"),
                        "disc_number": result.get("discNumber"),
                    }

            return best_match, best_similarity
    except Exception as e:
        console.print(f"[yellow]⚠ Metadata search failed: {e}[/yellow]")

    return None, 0.0


def download_cover_art(url: str) -> bytes | None:
    """Download album cover art."""
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            return response.content
    except Exception:
        pass
    return None
