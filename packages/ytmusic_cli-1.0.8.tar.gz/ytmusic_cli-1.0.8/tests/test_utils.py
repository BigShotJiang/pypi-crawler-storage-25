"""Tests for ytmusic CLI tool."""

from ytmusic.utils import calculate_similarity, extract_song_info, sanitize_filename


class TestUtils:
    """Test utility functions."""

    def test_sanitize_filename(self):
        """Test filename sanitization."""
        assert sanitize_filename("Artist - Song.mp3") == "Artist - Song.mp3"
        assert sanitize_filename("Artist<Song>.mp3") == "ArtistSong.mp3"
        assert sanitize_filename("Artist:Song?.mp3") == "ArtistSong.mp3"

    def test_calculate_similarity(self):
        """Test string similarity calculation."""
        assert calculate_similarity("hello", "hello") == 1.0
        assert calculate_similarity("hello", "world") < 0.5
        assert calculate_similarity("", "test") == 0.0

    def test_extract_song_info(self):
        """Test song info extraction from titles."""
        artist, song = extract_song_info("Artist - Song Title")
        assert artist == "Artist"
        assert song == "Song Title"

        artist, song = extract_song_info("Just a title")
        assert artist is None
        assert song == "Just a title"
