"""Main Code."""

import asyncio
import sys
from datetime import datetime
from datetime import timezone
from pathlib import Path
from typing import Annotated
from typing import Any

import httpx
import tomllib
from cyclopts import App
from cyclopts import Parameter
from packaging.requirements import InvalidRequirement
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.version import InvalidVersion
from packaging.version import parse as parse_version

from .cache import PyPICache
from .cache import get_default_cache

# Create the Cyclopts app
app = App()


def _setup_cache(cache: bool, clear_cache: bool, short: bool) -> PyPICache:
    """Set up and configure cache instance."""
    cache_instance = get_default_cache()
    cache_instance.enabled = cache

    if clear_cache:
        cleared = cache_instance.clear()
        if not short:
            print(f"Cleared {cleared} cache entries")

    return cache_instance


def _show_cache_stats(cache_instance: PyPICache, cache_stats: bool, short: bool) -> None:
    """Show cache statistics if requested."""
    if cache_stats and not short:
        stats = cache_instance.get_stats()
        print("\nCache Statistics:")
        print(f"  Enabled: {stats['enabled']}")
        print(f"  Hits: {stats['hits']}")
        print(f"  Misses: {stats['misses']}")
        print(f"  Expired: {stats['expired']}")
        print(f"  Errors: {stats['errors']}")
        print(f"  Total entries: {stats['total_entries']}")
        print(f"  Cache directory: {stats['cache_dir']}")


async def _check_dependency_groups(  # noqa: PLR0913
    data: dict,
    short: bool,
    compat_ok: bool,
    client: httpx.AsyncClient,
    cache_instance: PyPICache,
    min_age_days: int = 0,
    library: bool = False,
) -> bool:
    """Check all dependency groups and return True if updates needed."""
    needs_update = False
    dep_groups = data.get("dependency-groups", {})

    for group_name, dependencies in dep_groups.items():
        if not short:
            print(f"\nChecking dependency group [{group_name}]")

        if await process_dependencies(
            dependencies=dependencies,
            short=short,
            client=client,
            compat_ok=compat_ok,
            cache=cache_instance,
            min_age_days=min_age_days,
            library=library,
        ):
            needs_update = True

    return needs_update


@app.default
async def check(  # noqa: PLR0913
    pyproject_toml: Annotated[
        Path,
        Parameter(help="Full path to pyproject.toml file to check."),
    ] = Path("./pyproject.toml"),
    short: Annotated[
        bool,
        Parameter(help="Should only the shortest possible output be produced."),
    ] = False,
    groups: Annotated[
        bool,
        Parameter(help="Should dependencies in groups be checked."),
    ] = False,
    compat_ok: Annotated[
        bool,
        Parameter(help="Compatible versions are considered OK and won't cause an exit code of 1"),
    ] = False,
    cache: Annotated[
        bool,
        Parameter(help="Enable caching of PyPI API responses (default: False)."),
    ] = False,
    clear_cache: Annotated[
        bool,
        Parameter(help="Clear all cache entries before checking."),
    ] = False,
    cache_stats: Annotated[
        bool,
        Parameter(help="Show cache statistics after checking."),
    ] = False,
    min_age: Annotated[
        int,
        Parameter(help="Ignore updates younger than this many days (supply-chain quarantine)."),
    ] = 0,
    library: Annotated[
        bool,
        Parameter(
            help=(
                "Library mode: check constraint hygiene (no exact pins, no tight upper bounds) "
                "and flag only incompatible updates. Compatible updates are silent."
            )
        ),
    ] = False,
) -> None:
    """Check listed dependencies against latest versions available on Pypi.org."""
    if not short:
        print(f"Checking dependencies in {pyproject_toml.resolve()}")

    with pyproject_toml.open("rb") as definitions:
        data = tomllib.load(definitions)

    exit_code: int = 0

    # Handle cache options
    cache_instance = _setup_cache(cache, clear_cache, short)

    # Check main dependencies
    dependencies = data.get("project", {}).get("dependencies")

    async with httpx.AsyncClient() as client:
        if await process_dependencies(
            dependencies=dependencies,
            short=short,
            client=client,
            compat_ok=compat_ok,
            cache=cache_instance,
            min_age_days=min_age,
            library=library,
        ):
            exit_code = 1

        # Check dependency groups if requested
        if groups:
            if await _check_dependency_groups(
                data, short, compat_ok, client, cache_instance, min_age_days=min_age, library=library
            ):
                exit_code = 1

    # Show cache statistics if requested
    _show_cache_stats(cache_instance, cache_stats, short)

    sys.exit(exit_code)


async def process_dependencies(  # noqa: PLR0913
    dependencies: list[Any],
    short: bool,
    compat_ok: bool,
    client: httpx.AsyncClient,
    cache: PyPICache | None = None,
    min_age_days: int = 0,
    library: bool = False,
) -> bool:
    """Check all dependencies for updates concurrently.

    Return True if incompatible update is available or if compat_ok is False on any update available.
    In library mode, also checks constraint hygiene and forces compatible updates to be silent.
    """
    if not dependencies:
        dependencies = []

    remote_deps = [dep for dep in dependencies if not is_local_dependency(dependency=dep)]

    flag_update = False

    if library:
        for dep in remote_deps:
            try:
                package_name, version_spec, _ = parse_dependency(dependency=dep)
            except ValueError:
                continue
            for msg, is_error in classify_library_constraint(version_spec=version_spec, package_name=package_name):
                print(msg)
                flag_update |= is_error

    results = await asyncio.gather(
        *[
            check_dependency(
                dependency=dep,
                short=short,
                compat_ok=compat_ok,
                client=client,
                cache=cache,
                min_age_days=min_age_days,
                library=library,
            )
            for dep in remote_deps
        ]
    )

    for output, flag in results:
        if output is not None:
            print(output)
        flag_update |= flag

    return flag_update


def parse_dependency(dependency: str) -> tuple[str, str, str | None]:
    """Parse a dependency string into (package_name, version_constraint, environment_marker)."""
    try:
        req = Requirement(dependency)
        return (req.name, str(req.specifier) if req.specifier else "", str(req.marker) if req.marker else None)
    except InvalidRequirement as e:
        raise ValueError(f"Invalid dependency format '{dependency}'") from e


def is_version_compatible(current_spec: str, latest_version: str) -> bool:
    """Check if the latest version satisfies the current version constraints."""
    if not current_spec:
        return True  # No constraints means any version is acceptable

    try:
        specifier = SpecifierSet(current_spec)
        return parse_version(latest_version) in specifier
    except InvalidVersion:
        return False


def is_version_old_enough(upload_time: datetime | None, min_age_days: int) -> bool:
    """Return True if the version is at least min_age_days old, or if the age check is disabled."""
    if min_age_days <= 0 or upload_time is None:
        return True
    return (datetime.now(timezone.utc) - upload_time).days >= min_age_days


def is_latest_version(current_spec: str, latest_version: str) -> bool:
    """Check if the latest version has been specified."""
    if not current_spec:
        return True  # No constraints means any version is acceptable

    try:
        specifier = SpecifierSet(current_spec)
        latest_specified = False
        for spec in specifier:
            if latest_version == spec.version:
                latest_specified = True
        return latest_specified
    except InvalidVersion:
        return False


def _is_tight_upper_bound(version_str: str) -> bool:
    """Return True if a '<' specifier version is not at a major boundary (e.g. <2.5 is tight, <3 is not)."""
    v = parse_version(version_str)
    return v.minor != 0 or v.micro != 0


def classify_library_constraint(version_spec: str, package_name: str) -> list[tuple[str, bool]]:
    """Return hygiene violations for a library version specifier.

    Each entry is (message, is_error). is_error=True causes exit code 1; False is a warning only.
    An empty list means the constraint is library-safe.
    """
    if not version_spec:
        return [(f"⚠️  {package_name}: no version constraint — consumers get no minimum guarantee", False)]

    violations: list[tuple[str, bool]] = []
    try:
        specifier_set = SpecifierSet(version_spec)
    except Exception:
        return violations

    for spec in specifier_set:
        op: str = spec.operator
        ver: str = spec.version

        if op == "==":
            msg = f"❌ {package_name}: exact pin ({op}{ver}) blocks consumers — use >={ver}"
            violations.append((msg, True))
        elif op == "~=":
            if len(ver.split(".")) >= 3:
                minor_spec = ".".join(ver.split(".")[:2])
                msg = (
                    f"❌ {package_name}: patch-level compatible release ({op}{ver}) is too tight"
                    f" for a library — use ~={minor_spec}"
                )
                violations.append((msg, True))
        elif op == "<":
            if _is_tight_upper_bound(ver):
                next_major = parse_version(ver).major + 1
                msg = f"❌ {package_name}: tight upper bound ({op}{ver}) — use <{next_major} instead"
                violations.append((msg, True))

    return violations


def _classify_update(  # noqa: PLR0913
    package_name: str,
    version_spec: str,
    latest_version: str,
    upload_time: datetime | None,
    short: bool,
    compat_ok: bool,
    min_age_days: int,
    library: bool = False,
) -> tuple[str | None, bool]:
    """Classify an available update into an output message and needs_update flag."""
    if is_latest_version(current_spec=version_spec, latest_version=latest_version):
        output = f"\u2705\ufe0f {package_name}{version_spec} is up to date" if not short else None
        return (output, False)

    if library and is_version_compatible(current_spec=version_spec, latest_version=latest_version):
        output = f"\u2705\ufe0f {package_name}{version_spec} is up to date" if not short else None
        return (output, False)

    if min_age_days > 0 and upload_time is not None:
        age_days = (datetime.now(timezone.utc) - upload_time).days
        if age_days < min_age_days:
            return (
                f"\u23f3 {package_name}: {latest_version} is only {age_days} day(s) old (min-age: {min_age_days})",
                False,
            )

    if not is_version_compatible(version_spec, latest_version):
        return (f"\u274c {package_name}: {version_spec} \u2192 Latest: {latest_version}", True)

    return (
        f"\u26a0\ufe0f {package_name}: {version_spec} \u2192 Latest: {latest_version}",
        not compat_ok,
    )


async def check_dependency(  # noqa: PLR0913
    dependency: str,
    short: bool,
    compat_ok: bool,
    client: httpx.AsyncClient,
    cache: PyPICache | None = None,
    min_age_days: int = 0,
    library: bool = False,
) -> tuple[str | None, bool]:
    """Check if a dependency needs an update.

    Returns (output_line, needs_update). output_line is None when there is no output to show.
    needs_update is True when a newer version is available and outside version spec, or compat_ok
    is False and a newer compatible version exists. In library mode, compatible updates are silent.
    """
    try:
        package_name, version_spec, _ = parse_dependency(dependency)

        if not version_spec:
            return (None, False)

        latest_version, upload_time = await get_latest_pypi_version(
            package_name=package_name, client=client, cache=cache
        )

        return _classify_update(
            package_name=package_name,
            version_spec=version_spec,
            latest_version=latest_version,
            upload_time=upload_time,
            short=short,
            compat_ok=compat_ok,
            min_age_days=min_age_days,
            library=library,
        )

    except ValueError as e:
        return (f"❌ Error checking {dependency}: {e!r}", False)
    except (httpx.HTTPStatusError, httpx.RequestError) as e:
        return (f"❌ Network error for {package_name}: {e!r}", False)


def is_local_dependency(dependency: str) -> bool:
    """Check if dependency is a local path or URL."""
    if not dependency:
        return True

    return (
        " @" in dependency
        or ("/" in dependency and "://" not in dependency)
        or any(dependency.startswith(prefix) for prefix in ["file://", "https://", "http://", "git+https://"])
    )


def _get_cached_version(cache: PyPICache | None, package_name: str) -> tuple[str, datetime | None] | None:
    """Return (version, upload_time) from cache if present, otherwise None."""
    if not (cache and cache.enabled):
        return None
    cached_data = cache.get(package_name)
    if not (cached_data and "version" in cached_data):
        return None
    upload_time: datetime | None = None
    if cached_data.get("upload_time"):
        upload_time = datetime.fromisoformat(str(cached_data["upload_time"]))
    return str(cached_data["version"]), upload_time


def _earliest_upload_time(urls: list[dict]) -> datetime | None:
    """Return the earliest upload timestamp from a PyPI urls list, or None."""
    times = [datetime.fromisoformat(u["upload_time_iso_8601"]) for u in urls if u.get("upload_time_iso_8601")]
    return min(times) if times else None


async def get_latest_pypi_version(
    package_name: str, client: httpx.AsyncClient, cache: PyPICache | None = None
) -> tuple[str, datetime | None]:
    """Get latest version and its earliest upload time for a package on Pypi.org."""
    cached = _get_cached_version(cache=cache, package_name=package_name)
    if cached is not None:
        return cached

    response = await client.get(f"https://pypi.org/pypi/{package_name}/json")
    response.raise_for_status()
    response_data = response.json()
    latest_version = str(response_data["info"]["version"])
    upload_time = _earliest_upload_time(urls=response_data.get("urls", []))

    if cache and cache.enabled:
        cache.set(
            package_name,
            {
                "version": latest_version,
                "upload_time": upload_time.isoformat() if upload_time else None,
                "package_info": response_data["info"],
            },
        )

    return latest_version, upload_time


def main() -> None:
    """Run actual processing."""
    app()
