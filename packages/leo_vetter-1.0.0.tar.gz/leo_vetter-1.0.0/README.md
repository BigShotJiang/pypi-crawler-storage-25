## 🦁 LEO-Vetter: for Lazy Exoplanet Operations ##

LEO-Vetter (the Lazy-Exoplanet-Operations Vetter) is a tool for automated vetting of transit signals found in light curve data. Inspired by the Kepler Robovetter, LEO-Vetter computes vetting metrics and then checks those metrics against a series of pass-fail thresholds. If a signal passes all checks, it is considered a planet candidate (PC). If a signal fails at least one test, it may be either an astrophysical false positive (FP; e.g. eclipsing binary, nearby eclipsing signal) or false alarm (FA; e.g. systematic, stellar variability). LEO-Vetter also produces vetting reports for quick manual inspection of the signal.

Flux-level vetting can work on light curves from any source, including (but not limited to) Kepler, K2, and TESS. Pixel-level vetting has been implemented for TESS usage only.

### Usage ###

Check out the tutorials for full usage, but at its simplest it will look something like the following:

```
from leo_vetter.main import TCELightCurve
from leo_vetter.pixel import pixel_vetting
from leo_vetter.thresholds import check_thresholds

tlc = TCELightCurve(ID, time, raw, flux, flux_err, period, epoch, duration)

# Run flux-level vetting
# "star" is a dict containing stellar properties like mass, radius, etc.
tlc.compute_flux_metrics(star)

# Run pixel-level vetting
# "sectors" is a list of desired sectors for making difference images
tdi, good_sectors, good_pixel_data, good_centroids = pixel_vetting(tlc, star, sectors)

# Check metrics against pass-fail thresholds
FA = check_thresholds(tlc.metrics, "FA")
FP = check_thresholds(tlc.metrics, "FP")
```

Important note: The thresholds that determine whether a signal passes or fails work pretty well for TESS-observed FGKM dwarf stars, but no single set of thresholds will work for all use-cases. You can try changing the thresholds (or even adding/removing tests) to optimize this tool for your own purposes (see Tutorial 4).

### Installation ###

LEO-Vetter is pip-installable:

```
pip install leo-vetter
```

If you also want to run pixel-level vetting (recommended), you will need to install the `transit-diffImage` package available [here](https://github.com/stevepur/transit-diffImage):

```
git clone https://github.com/stevepur/transit-diffImage.git
cd transit-diffImage
pip install .
```

### Citing LEO-Vetter ###

Please cite [our paper](https://ui.adsabs.harvard.edu/abs/2025AJ....170..280K/abstract) if you find this package useful 😊

Kunimoto, M., Bryson, S., Jaffee, D., et al. (2025) The Astronomical Journal, 170, 280
