"""Tests for comment/string-aware SQL statement splitting (Snowflake execute path)."""

from point_topic_mcp.connectors.snowflake import non_empty_sql_statements, split_sql_statements


def test_semicolon_in_line_comment_does_not_split():
    sql = "select 1 -- note: end;\nfrom dual"
    assert non_empty_sql_statements(sql) == [sql.strip()]


def test_semicolon_in_block_comment_does_not_split():
    sql = "select 1 /* a;b */ from dual"
    assert non_empty_sql_statements(sql) == [sql.strip()]


def test_two_real_statements_split():
    sql = "select 1 from dual; select 2 from dual"
    parts = non_empty_sql_statements(sql)
    assert len(parts) == 2
    assert parts[0].strip() == "select 1 from dual"
    assert parts[1].strip() == "select 2 from dual"


def test_semicolon_inside_single_quoted_string():
    sql = "select 'a;b' as x from dual"
    assert non_empty_sql_statements(sql) == [sql.strip()]


def test_semicolon_inside_double_quoted_identifier():
    sql = 'select 1 as "x;y" from dual'
    assert non_empty_sql_statements(sql) == [sql.strip()]


def test_trailing_semicolon_one_statement():
    sql = "select 1 from dual;"
    parts = non_empty_sql_statements(sql)
    assert len(parts) == 1
    assert parts[0] == "select 1 from dual"


def test_split_preserves_comment_text_in_segment():
    sql = "select 1 -- foo;bar\n;"
    parts = split_sql_statements(sql)
    assert len(parts) == 2
    assert "foo;bar" in parts[0]
