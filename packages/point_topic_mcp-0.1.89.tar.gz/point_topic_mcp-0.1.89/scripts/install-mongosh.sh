#!/bin/bash
# Install mongosh for GBS tools. Required for MongoDB connection (avoids Python SSL issues).
# Run: ./scripts/install-mongosh.sh   or   bash scripts/install-mongosh.sh
set -e

if command -v mongosh &>/dev/null; then
    echo "mongosh already installed: $(mongosh --version 2>/dev/null | head -1 || mongosh --version)"
    exit 0
fi

echo "Installing mongosh..."
case "$(uname -s)" in
    Darwin)
        if command -v brew &>/dev/null; then
            brew install mongosh
        else
            echo "macOS: install Homebrew first (https://brew.sh) then run: brew install mongosh"
            exit 1
        fi
        ;;
    Linux)
        if [ -f /etc/os-release ]; then
            . /etc/os-release
            case "$ID" in
                ubuntu|debian|pop)
                    curl -fsSL https://www.mongodb.org/static/pgp/server-8.0.asc | sudo gpg -o /usr/share/keyrings/mongodb-server-8.0.gpg --dearmor
                    echo "deb [ signed-by=/usr/share/keyrings/mongodb-server-8.0.gpg ] https://repo.mongodb.org/apt/ubuntu $(lsb_release -cs)/mongodb-org/8.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-8.0.list
                    sudo apt-get update
                    sudo apt-get install -y mongodb-mongosh
                    ;;
                amazon|rhel|fedora|centos|rocky|almalinux)
                    if ! sudo yum install -y mongodb-mongosh 2>/dev/null && ! sudo dnf install -y mongodb-mongosh 2>/dev/null; then
                        echo "Adding MongoDB repo and retrying..."
                        if [[ "$ID" == "amazon" ]]; then
                            REPO_VER="2"
                            [[ -n "$VERSION_ID" && "$VERSION_ID" == "2023" ]] && REPO_VER="2023"
                            BASE="https://repo.mongodb.org/yum/amazon/${REPO_VER}/mongodb-org/8.0/x86_64/"
                        else
                            MAJOR="${VERSION_ID%%.*}"
                            [[ -z "$MAJOR" ]] && MAJOR="9"
                            BASE="https://repo.mongodb.org/yum/redhat/${MAJOR}/mongodb-org/8.0/x86_64/"
                        fi
                        echo "[mongodb-org-8.0]
name=MongoDB Repository
baseurl=${BASE}
gpgcheck=1
enabled=1
gpgkey=https://www.mongodb.org/static/pgp/server-8.0.asc" | sudo tee /etc/yum.repos.d/mongodb-org-8.0.repo
                        sudo dnf install -y mongodb-mongosh 2>/dev/null || sudo yum install -y mongodb-mongosh
                    fi
                    ;;
                *)
                    echo "Unsupported Linux: $ID. Install manually: https://www.mongodb.com/docs/mongodb-shell/install/"
                    exit 1
                    ;;
            esac
        else
            echo "Could not detect Linux distro. Install manually: https://www.mongodb.com/docs/mongodb-shell/install/"
            exit 1
        fi
        ;;
    *)
        echo "Unsupported OS. Install mongosh manually: https://www.mongodb.com/docs/mongodb-shell/install/"
        exit 1
        ;;
esac

echo "mongosh installed: $(mongosh --version 2>/dev/null | head -1 || true)"
exit 0
