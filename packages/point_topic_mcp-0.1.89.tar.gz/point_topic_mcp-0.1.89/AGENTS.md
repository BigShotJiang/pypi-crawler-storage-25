# AGENTS.md - Point Topic MCP Codebase Guide
# UK broadband data analysis MCP server (Python 3.12+, FastMCP)

# Purpose: Single source of truth for AI agents working on this codebase.
# Keep concise: agents parse this on every task.
# For full README: see ./README.md
```

# Architecture (Mermaid)

```mermaid
flowchart TB
    subgraph Clients
        CD[Claude Desktop]
        CR[Cursor]
        MI[MCP Inspector]
    end
    
    subgraph Deployment
        ST[server_local.py<br/>Stdio Transport]
        HT[server_http.py<br/>HTTP + Auth0 OAuth]
    end
    
    subgraph Core
        TD[Tools Discovery<br/>__init__.py]
        PD[Prompts Discovery<br/>__init__.py]
        TM[ToolManager<br/>Dynamic registration]
        MM[PermissionMiddleware<br/>Auth0 RBAC]
    end
    
    subgraph Tools
        DB[Database Tools<br/>Snowflake queries]
        CH[Chart Tools<br/>Public/private charts]
        GB[GBS Tools<br/>MongoDB statistics]
        GH[GitHub Tools<br/>Org management]
        SI[Server Info Tools<br/>Capabilities]
    end
    
    subgraph Context
        GA[Context Assembly]
        DS[Datasets<br/>upc, tariffs, etc.]
        GI[General DB Instructions]
    end
    
    subgraph Connectors
        SF[snowflake.py<br/>Async SQL executor]
        MO[mongodb_utils.py<br/>mongosh subprocess]
        S3[s3_utils.py<br/>Source file archival]
    end
    
    subgraph Auth
        D[decorators.py<br/>@public/@requires_permissions]
        MW[middleware.py<br/>PermissionMiddleware]
        AH[auth0_helpers.py<br/>JWT verifier]
    end
    
    CD --> ST
    CR --> ST
    MI --> ST
    HT --> AH
    
    ST --> TD --> DB
    ST --> TD --> CH
    ST --> TD --> GB
    ST --> TD --> GH
    ST --> TD --> SI
    ST --> PD
    ST --> MM
    
    DB --> SF
    GB --> MO
    GB --> S3
    
    DB --> GA --> DS
    GA --> GI
```

# Directory Map

```
point-topic-mcp/
├── src/point_topic_mcp/
│   ├── server_local.py         # Stdio entry (default)
│   ├── server_http.py          # HTTP entry (Auth0)
│   ├── install_mongosh.py      # mongosh installer script
│   ├── tools/                  # Auto-discovered tool modules
│   │   ├── __init__.py         # Tool discovery & registration
│   │   ├── database_tools.py   # Snowflake SQL tools
│   │   ├── chart_tools.py      # Chart API tools
│   │   ├── gbs_tools.py        # MongoDB statistics tools
│   │   ├── github_tools.py     # GitHub org tools
│   │   └── server_info_tools.py# Capability reporting
│   ├── prompts/                # Auto-discovered prompt modules
│   │   ├── __init__.py         # Prompt discovery & registration
│   │   └── upc_prompts.py      # UPC analysis templates
│   ├── core/                   # Shared utilities
│   │   ├── utils.py            # check_env_vars, dynamic_docstring
│   │   ├── tool_manager.py     # Dynamic tool registration
│   │   ├── context_assembly.py # Dataset discovery & assembly
│   │   ├── mongodb_utils.py    # mongosh subprocess wrapper
│   │   └── s3_utils.py         # S3 archival for sources
│   ├── connectors/
│   │   └── snowflake.py        # SnowflakeDB: safe async queries
│   ├── auth/                   # Auth0 RBAC
│   │   ├── decorators.py       # @public, @requires_permissions
│   │   ├── middleware.py       # PermissionMiddleware
│   │   └── auth0_helpers.py    # JWT verification
│   └── context/
│       ├── general_db_instructions.py
│       └── datasets/           # Auto-discovered datasets
│           ├── upc.py          # Availability (postcode-level)
│           ├── upc_take_up.py  # Adoption/subscribers
│           ├── upc_forecast.py # Coverage projections
│           ├── tariffs.py      # ISP pricing
│           ├── ontology.py     # Tech classification
│           └── bi_reports.py   # Report metadata
├── tests/                      # pytest test suite
│   ├── eval_set.py             # Eval question bank
│   ├── test_gbs_tools.py
│   ├── test_mongodb_utils.py
│   ├── test_notifications.py
│   ├── test_permissions.py
│   ├── test_registration.py
│   ├── test_sql_statements_split.py
│   └── test_tool_manager.py
├── infrastructure/             # Auth0 deployment scripts
│   ├── auth0-setup.sh
│   ├── auth0-cheat-sheet.sh
│   └── auth0-credentials.json
└── pyproject.toml              # v0.1.85, Python >=3.12
```

# Key Design Patterns

## 1. Auto-Discovery (tools, prompts, datasets)

| Component | Location Pattern | Registration | Name Convention |
|-----------|-----------------|--------------|-----------------|
| Tools | `tools/*_tools.py` | `tools/__init__.py:register_tools()` | `{module}_{func_name}` (prefixed) |
| Prompts | `prompts/*_prompts.py` | `prompts/__init__.py:register_prompts()` | Function name only |
| Datasets | `context/datasets/*.py` | `core/context_assembly.py` | Module name only |

**Just create a file with public functions** — no decorators needed for registration.

## 2. Conditional Tool Registration

```python
# tools/database_tools.py
from point_topic_mcp.core.utils import check_env_vars

if check_env_vars('snowflake_tools', ['SNOWFLAKE_USER', 'SNOWFLAKE_PASSWORD']):
    def execute_query(sql_query: str, ctx=None) -> str:
        """Execute safe read-only SQL."""
        ...
```

- Tools only appear when required env vars are set.
- `check_env_vars()` tracks requirements for `get_mcp_server_capabilities()`.
- Skipped tools log: `[MCP] Skipping {name}: missing env vars [...]`.

## 3. Dynamic Docstrings

```python
from point_topic_mcp.core.utils import dynamic_docstring
from point_topic_mcp.core.context_assembly import list_datasets

@dynamic_docstring([("{DATASETS}", list_datasets)])
def assemble_dataset_context(dataset_names: list[str], ctx=None) -> str:
    """Full context for one or more datasets.\n{DATASETS}"""
```

Placeholders replaced at module load time (not at call time).

## 4. Dynamic Tool Registration (Runtime)

```python
from point_topic_mcp.core.tool_manager import ToolManager
tool_manager = ToolManager(mcp)

async def my_analyzer(dataset_id: str) -> dict: ...
tool_manager.register_tool(name="analyze_dataset", description="...", function=my_analyzer)

# Notify clients (call from within a tool)
await ctx.send_notification(mcp.types.ToolListChangedNotification())
```

## 5. Permission Middleware (Three-Tier Access)

| Level | What They See |
|-------|--------------|
| **Unauthenticated** | Only `@public` tools (stdio: admin via ADMIN_API_KEY) |
| **Authenticated** | `@public` + tools matching their `@requires_permissions` |
| **ptAdmin** | All tools |

Stdio mode: `ADMIN_API_KEY` grants ptAdmin. HTTP mode: Auth0 JWT.

```python
# auth/decorators.py
@public                          # Everyone
@requires_permissions(["read:data"])  # Specific scope
```

## 6. Dataset System (Lazy Loading)

```python
# context/datasets/upc.py
def get_dataset_summary():
    """Short. Always visible in agent prompt."""
    return "UK broadband availability at postcode level."

def get_db_info():
    """Full schema + instructions + examples. Only loaded on demand."""
    return f"{DB_INFO}\n\n{DB_SCHEMA}\n\n{SQL_EXAMPLES}"
```

# Tool Reference

## Database Tools (requires: `SNOWFLAKE_USER`, `SNOWFLAKE_PASSWORD`)

| Function | Description | Key Args |
|----------|-------------|----------|
| `database_tools_assemble_dataset_context` | Get schema/instructions/examples | `dataset_names: list[str]` |
| `database_tools_execute_query` | Safe SQL (SELECT/WITH/SHOW/DESCRIBE/EXPLAIN only) | `sql_query: str` |
| `database_tools_execute_multi_query` | Multiple semicolon-separated queries | `queries: str` |
| `database_tools_get_query_status` | Check query state | `query_id: str` |
| `database_tools_cancel_query` | Cancel by query_id | `query_id: str` |
| `database_tools_describe_table` | Get table schema | `table_name: str` |
| `database_tools_get_la_code` | LA lookup | various |
| `database_tools_get_la_list_full` | All local authorities | - |

**Async execution**: Queries submit async, return `query_id:` immediately. Poll with `get_query_status`.

## Chart Tools (public: always; private: `CHART_API_KEY`)

| Function | Auth | Description |
|----------|------|-------------|
| `chart_tools_get_point_topic_public_chart_catalog` | None | Browse public charts |
| `chart_tools_get_point_topic_public_chart_csv` | None | Get chart CSV |
| `chart_tools_get_point_topic_chart_catalog` | Key | Private catalog (currently disabled) |
| `chart_tools_get_point_topic_chart_csv` | Key | Private chart CSV (currently disabled) |
| `chart_tools_generate_authenticated_chart_url` | Key | Signed URLs (currently disabled) |

## GBS Tools (requires: `PT_RESEARCH_DATABASE_URI`, mongosh)

| Function | Description |
|----------|-------------|
| `gbs_tools_list_operators` | List by country, returns Operator collection docs |
| `gbs_tools_get_gbs_status` | Statistics status for operator (with quarter distance) |
| `gbs_tools_add_statistic` | Insert Statistics document |
| `gbs_tools_create_source` | Create Source record (with optional S3 archival) |

Requires mongosh on PATH (install: `point-topic-mcp-install-mongosh`).

Valid enums: types=`[broadband, mobile, iptv]`, channels=`[Infrastructure, Retail]`, domains=`[Residential, Business, Total]`

## GitHub Tools (requires: `GITHUB_TOKEN`)

Admin-only tools for Point-Topic org: list repos, manage issues, PRs.

## Server Info (always available)

| Function | Description |
|----------|-------------|
| `server_info_tools_get_mcp_server_capabilities` | Debug missing credentials |

# Data Models

## Snowflake (UPC_CORE database, REPORTS schema)

| Table (prefix: `upc_core.reports.`) | Key Columns | Granularity |
|--------------------------------------|-------------|-------------|
| `upc_output` | postcode, premises, households, reported_at, la_name | Postcode |
| `fact_operator` | postcode, operator, tech, reported_at | Postcode+operator+tech |
| `upc_take_up` | operator, subscribers, reported_at | Operator+LA+period |
| `upc_forecast` | operator, premises, year | Operator+year |
| `tariffs` | operator, package_name, price | Operator+package |
| `ontology` | tech_category, tech_subcategory, operator | Tech+operator |

**CRITICAL**: `fact_operator` joins to `upc_output` can duplicate rows (multiple techs per postcode). Always deduplicate by postcode for operator footprint.

## MongoDB (pt-research-app via Prisma)

| Collection | Key Fields | Used By |
|-----------|------------|---------|
| `Operator` | name, country, technologies, _id | list_operators |
| `Statistics` | operatorId, period, type, channel, domain, subscribers, tech | get_gbs_status, add_statistic |
| `Sources` | operatorId, year, quarter, type, url, fileUrl | create_source |
| `GlobalVariables` | isCurrent, ... | find_global_variables_current |

# Environment Variables

| Variable | Required For | Notes |
|----------|-------------|-------|
| `SNOWFLAKE_USER` | database_tools | Snowflake login |
| `SNOWFLAKE_PASSWORD` | database_tools | Snowflake password |
| `CHART_API_KEY` | chart_tools (disabled) | Charts API key |
| `PT_RESEARCH_DATABASE_URI` | gbs_tools | MongoDB connection string |
| `PT_RESEARCH_TLS_SKIP_VERIFY` | gbs_tools | Set to `1` to skip TLS verify |
| `GITHUB_TOKEN` | github_tools | GitHub PAT |
| `AUTH0_DOMAIN` | server_http | Default: `point-topic.eu.auth0.com` |
| `AUTH0_CLIENT_ID` | server_http | Auth0 app client ID |
| `AUTH0_CLIENT_SECRET` | server_http | Auth0 app secret |
| `AUTH0_AUDIENCE` | server_http | Default: `https://point-topic-mcp.fastmcp.app/` |
| `MCP_BASE_URL` | server_http | Public server URL |
| `ADMIN_API_KEY` | stdio auth | Grants ptAdmin in local mode |

# Adding New Features

## New Tool
1. Create `tools/your_feature_tools.py`
2. Public function → auto-discovered as `your_feature_tools_{func_name}`
3. For conditional: wrap in `if check_env_vars('name', ['REQUIRED_ENV'])`
4. Add clear docstring (agents see it)

## New Prompt
1. Create `prompts/your_analysis_prompts.py`
2. Function returning `list[PromptMessage]` (with `role` + `TextContent`)
3. Auto-discovered: no registration needed

## New Dataset
1. Create `context/datasets/your_db.py`
2. Implement: `get_dataset_summary()` (concise, always visible) and `get_db_info()` (schema + instructions + examples)
3. Auto-discovered by `assemble_dataset_context`

# Key Business Rules (UK Broadband)

| Rule | Value |
|------|-------|
| UK premises | ~33M |
| UK households | ~30M |
| UK population | ~67M |
| Altnet exclusion list | BT, Sky, TalkTalk, Vodafone, Virgin Cable, Virgin Media RFOG, KCOM Lightstream |
| Virgin altnet variant | `nexfibre Virgin Media` IS altnet |
| CityFibre canonicalization | `operator like '%CityFibre%' → 'CityFibre'` |
| Fact operator dedup | `distinct operator_canonical` NOT `count(distinct operator)` |
| Total premises | `SUM(premises) FROM upc_output` directly, never from `fact_operator` join |

# Commands Reference

```bash
uv sync                          # Development setup
uv run point-topic-mcp           # Run stdio server
uv run python -m point_topic_mcp.server_http  # Run HTTP server
uv run mcp dev src/point_topic_mcp/server_local.py  # MCP Inspector
uv run mcp install src/point_topic_mcp/server_local.py --with "snowflake-connector-python[pandas]" -f .env  # Claude Desktop
uv build                         # Build wheel
pip install dist/point_topic_mcp-*.whl  # Test install
point-topic-mcp-install-mongosh  # Install mongosh (for GBS)
```

# Testing

```bash
uv run pytest tests/ -v         # All tests
uv run pytest tests/test_gbs_tools.py -v --run-gbs  # GBS tests (needs PT_RESEARCH_DATABASE_URI)
```

Test files: 8 total covering SQL parsing, tool manager, permissions, notifications, registration, GBS, MongoDB.

# Publishing (Maintainers)

```bash
aws secretsmanager get-secret-value --secret-id pypirc --query SecretString --output text > ~/.pypirc
./publish_to_pypi.sh
```

---

**For questions**: Check `README.md`, `pyproject.toml` (v0.1.85), or the specific module's docstring. This file is the architecture overview only.