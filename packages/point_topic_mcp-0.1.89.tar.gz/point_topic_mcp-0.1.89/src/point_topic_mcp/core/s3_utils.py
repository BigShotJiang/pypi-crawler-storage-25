"""S3 helpers for GBS source file archival.

Every stored file for a Source lands in ``pt-research-sources``:

- ``s3://bucket/key`` (same account): ``copy_object`` into the sources bucket.
- ``http(s)://...``: GET then ``put_object`` into the sources bucket.

IAM uses the normal AWS credential chain.
"""

from __future__ import annotations

import re
import uuid
from urllib.parse import quote

import boto3
import httpx
from botocore.exceptions import ClientError

S3_REGION = "eu-west-1"
SOURCES_BUCKET = "pt-research-sources"


def _client():
    return boto3.client("s3", region_name=S3_REGION)


def parse_s3_uri(uri: str) -> tuple[str, str]:
    """Parse ``s3://bucket/object-key``. Key may contain slashes.

    Raises RuntimeError if malformed.
    """
    u = uri.strip()
    if not u.lower().startswith("s3://"):
        raise RuntimeError("expected an s3:// URI")
    rest = u[5:]
    slash = rest.find("/")
    if slash < 0:
        raise RuntimeError("s3 URI must include a key, e.g. s3://my-bucket/path/to/file.pdf")
    bucket = rest[:slash].strip()
    key = rest[slash + 1 :].lstrip("/")
    if not bucket or not key:
        raise RuntimeError("s3 URI must have non-empty bucket and key")
    return bucket, key


def copy_to_sources_bucket(*, source_bucket: str, source_key: str, dest_key: str) -> str:
    """Copy an object into ``SOURCES_BUCKET`` at ``dest_key``. Returns permanent HTTPS URL."""
    try:
        cli = _client()
        cli.copy_object(
            Bucket=SOURCES_BUCKET,
            Key=dest_key,
            CopySource={"Bucket": source_bucket, "Key": source_key},
        )
        return _object_https_url(bucket=SOURCES_BUCKET, key=dest_key)
    except ClientError as e:
        raise RuntimeError(
            f"S3 copy_object failed from {source_bucket!r}/{source_key!r} "
            f"to {SOURCES_BUCKET!r}/{dest_key!r}: {e}"
        ) from e


def download_from_url(url: str) -> tuple[bytes, str]:
    """Download file from HTTP(S) URL. Returns (body_bytes, content_type).

    Raises RuntimeError on failure.
    """
    try:
        with httpx.Client(timeout=120.0, follow_redirects=True) as client:
            r = client.get(url)
            r.raise_for_status()
            ct = (
                r.headers.get("content-type", "application/octet-stream")
                .split(";")[0]
                .strip()
            )
            return r.content, ct
    except httpx.HTTPError as e:
        raise RuntimeError(f"Failed to download from URL: {e}") from e


def _safe_filename(name: str) -> str:
    base = name.replace("\\", "/").rsplit("/", 1)[-1] or "file"
    base = re.sub(r"[^a-zA-Z0-9._-]+", "_", base).strip("_") or "file"
    return base[:200]


def _object_https_url(*, bucket: str, key: str) -> str:
    encoded = quote(key, safe="/")
    return f"https://{bucket}.s3.{S3_REGION}.amazonaws.com/{encoded}"


def upload_to_sources_bucket(body: bytes, content_type: str, dest_key: str) -> str:
    """Upload bytes to SOURCES_BUCKET. Returns permanent HTTPS URL."""
    bucket = SOURCES_BUCKET
    try:
        cli = _client()
        cli.put_object(
            Bucket=bucket,
            Key=dest_key,
            Body=body,
            ContentType=content_type,
        )
        return _object_https_url(bucket=bucket, key=dest_key)
    except ClientError as e:
        raise RuntimeError(f"S3 put_object failed bucket={bucket!r} key={dest_key!r}: {e}") from e


def build_sources_dest_key(
    *,
    operator_id: str,
    year: int,
    quarter: int,
    original_filename: str,
) -> str:
    uid = uuid.uuid4().hex[:12]
    safe = _safe_filename(original_filename)
    return f"sources/{operator_id}/{year}Q{quarter}/{uid}_{safe}"
