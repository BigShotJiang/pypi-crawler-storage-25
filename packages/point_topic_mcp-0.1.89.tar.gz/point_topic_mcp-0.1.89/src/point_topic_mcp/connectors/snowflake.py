import snowflake.connector
from dotenv import load_dotenv
import os
import re
import time


def split_sql_statements(sql: str) -> list[str]:
    """
    Split SQL on semicolons that are not inside line comments (--), block comments (/* */),
    single-quoted strings ('' escape), or double-quoted delimited identifiers ("" escape).
    """
    parts: list[str] = []
    current: list[str] = []
    i = 0
    n = len(sql)
    # normal | line_comment | block_comment | squote | dquote
    state = "normal"

    while i < n:
        c = sql[i]
        if state == "normal":
            if c == "-" and i + 1 < n and sql[i + 1] == "-":
                state = "line_comment"
                current.append(c)
                current.append(sql[i + 1])
                i += 2
                continue
            if c == "/" and i + 1 < n and sql[i + 1] == "*":
                state = "block_comment"
                current.append(c)
                current.append(sql[i + 1])
                i += 2
                continue
            if c == "'":
                state = "squote"
                current.append(c)
                i += 1
                continue
            if c == '"':
                state = "dquote"
                current.append(c)
                i += 1
                continue
            if c == ";":
                parts.append("".join(current))
                current = []
                i += 1
                continue
            current.append(c)
            i += 1
            continue
        if state == "line_comment":
            current.append(c)
            if c in "\n\r":
                state = "normal"
            i += 1
            continue
        if state == "block_comment":
            current.append(c)
            if c == "*" and i + 1 < n and sql[i + 1] == "/":
                current.append(sql[i + 1])
                i += 2
                state = "normal"
                continue
            i += 1
            continue
        if state == "squote":
            current.append(c)
            if c == "'":
                if i + 1 < n and sql[i + 1] == "'":
                    current.append(sql[i + 1])
                    i += 2
                    continue
                state = "normal"
            i += 1
            continue
        if state == "dquote":
            current.append(c)
            if c == '"':
                if i + 1 < n and sql[i + 1] == '"':
                    current.append(sql[i + 1])
                    i += 2
                    continue
                state = "normal"
            i += 1
            continue

    parts.append("".join(current))
    return parts


def non_empty_sql_statements(sql: str) -> list[str]:
    """Statements from split_sql_statements with whitespace-only segments removed."""
    return [p.strip() for p in split_sql_statements(sql) if p.strip()]


class SnowflakeDB:
    """
    Class for connecting to the Snowflake database.
    
    Example usage:
        `db = SnowflakeDB()`
        `db.connect()`
        `result = db.execute_safe_query(sql_query)`
        `db.close_connection()`

    Attributes:
        user (str): Snowflake user.
        password (str): Snowflake password.
        account (str): Snowflake account.
        warehouse (str): Snowflake warehouse.
        database (str): Snowflake database.
        schema (str): Snowflake schema.
        connection (snowflake.connector.connection.SnowflakeConnection): Snowflake connection.
    """
    def __init__(self):
        load_dotenv()

        self.user = os.environ['SNOWFLAKE_USER']
        self.password = os.environ['SNOWFLAKE_PASSWORD']
        
        self.account = 'fz24086.eu-west-1'
        self.warehouse = 'COMPUTE_WH'
        self.database = 'UPC_CORE'
        self.schema = 'REPORTS'

        self.connection = None

    def connect(self):
        """Establishes a connection to the Snowflake database."""
        self.connection = snowflake.connector.connect(
            user=self.user,
            password=self.password,
            account=self.account,
            warehouse=self.warehouse,
            database=self.database,
            schema=self.schema
        )

    def close_connection(self):
        """Closes the Snowflake database connection."""
        if self.connection is not None:
            self.connection.close()

    def _fetchall_to_csv(self, cursor):
        """Convert fetchall results to CSV (no pandas required)."""
        import io

        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        output = io.StringIO()
        output.write(",".join(columns) + "\n")
        for row in rows:
            output.write(
                ",".join(str(cell) if cell is not None else "" for cell in row) + "\n"
            )
        return output.getvalue()

    def query_to_csv(self, query):
        """Executes a SQL query and returns results as CSV. Uses fetchall (no pandas)."""
        cursor = self.connection.cursor()
        try:
            cursor.execute(query)
            return self._fetchall_to_csv(cursor)
        finally:
            cursor.close()

    def execute_ddl(self, query):
        """Executes a DDL statement such as CREATE or ALTER and returns True if successful."""
        cursor = self.connection.cursor()
        try:
            cursor.execute(query)
            return True
        finally:
            cursor.close()

    def get_distinct_value_list(self, table, column):
        """Gets the distinct list of values for a given column in a given table."""
        query = f"select distinct {column} from {table}"
        return self.query_to_csv(query)

    def validate_safe_query(self, query: str) -> tuple[bool, str]:
        """
        Validates that a SQL query is safe to execute (read-only operations only).
        
        Returns:
            tuple[bool, str]: (is_valid, error_message)
        """
        # Remove comments and normalize whitespace
        clean_query = re.sub(r'--.*$', '', query, flags=re.MULTILINE)
        clean_query = re.sub(r'/\*.*?\*/', '', clean_query, flags=re.DOTALL)
        clean_query = clean_query.strip().upper()
        
        # Dangerous keywords that should never be allowed
        dangerous_keywords = [
            'DROP', 'DELETE', 'INSERT', 'UPDATE', 'CREATE', 'ALTER', 
            'TRUNCATE', 'REPLACE', 'MERGE', 'COPY', 'PUT', 'GET',
            'REMOVE', 'GRANT', 'REVOKE', 'USE', 'SET', 'UNSET',
            'CALL', 'EXECUTE', 'EXEC'
        ]
        
        # Check for dangerous keywords at word boundaries
        for keyword in dangerous_keywords:
            if re.search(rf'\b{keyword}\b', clean_query):
                return False, f"Query contains prohibited keyword: {keyword}"
        
        # Must start with SELECT, WITH, SHOW, DESCRIBE, or EXPLAIN
        allowed_start_keywords = ['SELECT', 'WITH', 'SHOW', 'DESCRIBE', 'DESC', 'EXPLAIN']
        
        starts_with_allowed = any(clean_query.startswith(keyword) for keyword in allowed_start_keywords)
        if not starts_with_allowed:
            return False, f"Query must start with one of: {', '.join(allowed_start_keywords)}"

        # Reject multiple statements; ignore semicolons inside comments/strings
        if len(non_empty_sql_statements(query)) > 1:
            return False, "Multiple statements not allowed"

        return True, ""

    def submit_async_query(self, query: str) -> tuple:
        """
        Validate and submit a query asynchronously.

        Returns (cursor, query_id) immediately — before execution completes.
        Raises ValueError on validation failure, Exception on submit failure.
        """
        is_valid, error_message = self.validate_safe_query(query)
        if not is_valid:
            raise ValueError(f"Query validation failed - {error_message}")
        cursor = self.connection.cursor()
        cursor.execute_async(query)
        return cursor, cursor.sfqid

    def poll_and_fetch(self, cursor, query_id: str) -> str:
        """
        Poll until a submitted async query settles, then return results as CSV.

        Returns string starting with `query_id:<id>` followed by CSV data,
        or an error/cancellation message.
        """
        running = {'RUNNING', 'QUEUED', 'RESUMING_WAREHOUSE', 'ABORTING'}
        while self.connection.get_query_status(query_id).name in running:
            time.sleep(0.5)

        try:
            self.connection.get_query_status_throw_if_error(query_id)
        except Exception as e:
            if getattr(e, 'errno', None) == 604:
                return f"query_id:{query_id}\nCANCELLED: query was cancelled"
            return f"query_id:{query_id}\nDATABASE ERROR: {str(e)}"

        cursor.get_results_from_sfqid(query_id)
        rows = cursor.fetchall()
        # description is populated after fetchall when using async execution
        columns = [desc[0] for desc in cursor.description]
        import io
        output = io.StringIO()
        output.write(",".join(columns) + "\n")
        for row in rows:
            output.write(",".join(str(cell) if cell is not None else "" for cell in row) + "\n")
        cursor.close()
        return f"query_id:{query_id}\n{output.getvalue()}"

    def execute_safe_query(self, query: str) -> str:
        """
        Executes a validated safe SQL query and returns results as CSV.

        Uses async execution internally so the query can be cancelled externally
        via cancel_query(query_id) while it is running.

        Returns string starting with `query_id:<snowflake_query_id>` followed
        by CSV data, or an error message.
        """
        try:
            cursor, query_id = self.submit_async_query(query)
        except ValueError as e:
            return f"ERROR: {e}"
        except Exception as e:
            return f"DATABASE ERROR: {str(e)}"
        return self.poll_and_fetch(cursor, query_id)
    
    def execute_safe_queries(self, queries: str) -> str:
        """
        Executes multiple validated safe SQL queries separated by semicolons.
        Each query is validated and executed separately.
        
        Args:
            queries: Multiple SQL queries separated by semicolons (must be read-only)
            
        Returns:
            str: Combined results with clear query separators
        """
        query_list = non_empty_sql_statements(queries)
        
        if len(query_list) == 1:
            # Single query, use the regular method
            return self.execute_safe_query(query_list[0])
        
        results = []
        for i, query in enumerate(query_list, 1):
            results.append(f"=== QUERY {i} ===")
            results.append(f"SQL: {query}")
            results.append("RESULTS:")
            
            # Execute each query individually
            result = self.execute_safe_query(query)
            results.append(result)
            results.append("")  # Empty line for separation
        
        return "\n".join(results)

    def check_query_status(self, query_id: str) -> str:
        """
        Returns the current status of a Snowflake query by ID.

        Returns one of: RUNNING, SUCCESS, CANCELLED, ERROR:<message>
        """
        raw = self.connection.get_query_status(query_id).name
        if raw in ('RUNNING', 'QUEUED', 'RESUMING_WAREHOUSE', 'ABORTING'):
            return 'RUNNING'
        if raw == 'SUCCESS':
            return 'SUCCESS'
        try:
            self.connection.get_query_status_throw_if_error(query_id)
        except Exception as e:
            if getattr(e, 'errno', None) == 604:
                return 'CANCELLED'
            return f'ERROR: {e}'
        return raw

    def cancel_query(self, query_id: str) -> str:
        """Cancels a running Snowflake query. Works from any connection."""
        self.connection.execute_string(f"select system$cancel_query('{query_id}')")
        return f"cancelled:{query_id}"

    def describe_table(self, table_name: str) -> str:
        """
        Describe a table in the Snowflake database.

        Args:
            table_name: The name of the table to describe. 
            Use the full database and schema name.
            e.g. "upc_core.reports.upc_output"

        Returns:
            The schema as CSV string
        """
        query = f"describe table {table_name}"
        cursor = self.connection.cursor()
        try:
            cursor.execute(query)
            columns = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()
            import io
            output = io.StringIO()
            output.write(','.join(columns) + '\n')
            for row in rows:
                output.write(','.join(str(cell) if cell is not None else '' for cell in row) + '\n')
            return output.getvalue()
        finally:
            cursor.close()