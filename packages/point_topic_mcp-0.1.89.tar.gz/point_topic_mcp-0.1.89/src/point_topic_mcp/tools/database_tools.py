"""Snowflake database query and analysis tools."""

import json
from typing import List, Optional
from fastmcp import Context
from point_topic_mcp.core.context_assembly import get_ontology_summary, list_datasets, assemble_context
from point_topic_mcp.core.utils import dynamic_docstring, check_env_vars
from dotenv import load_dotenv

load_dotenv()

# Snowflake database tools (require credentials)
if check_env_vars('snowflake_tools', ['SNOWFLAKE_USER', 'SNOWFLAKE_PASSWORD']):
    @dynamic_docstring([("{DATASETS}", list_datasets)])
    def assemble_dataset_context(
        dataset_names: List[str],
        ctx: Optional[Context] = None
    ) -> str:
        """
        Assemble full context (instructions, schema, examples) for one or more datasets.

        This is essential before executing a query, for the agent to understand how to query the datasets.

        Args:
            dataset_names: List of dataset names to include (e.g., ['upc', 'upc_take_up'])

        {DATASETS}

        Returns the complete context needed for querying these datasets.
        """
        return assemble_context(dataset_names)

    @dynamic_docstring([("SUMMARY", get_ontology_summary)])
    def assemble_ontology_context(
        ctx: Optional[Context] = None
    ) -> str:
        """
        Get context (instructions, schema, examples) for the ontology dataset

        This is essential before executing a query, for the agent to understand how to query the ontology

        Summary: {SUMMARY}

        """
        return assemble_context(['ontology'])

    async def execute_query(
        sql_query: str,
        ctx: Optional[Context] = None,
    ) -> str:
        """
        Execute safe SQL queries against the Snowflake database.
        Only read-only queries allowed (SELECT, WITH, SHOW, DESCRIBE, EXPLAIN).

        Multiple queries can be executed in one call by separating them with semicolons (;).
        Each query will be validated and executed separately, with clearly labeled results.

        You must first assemble the context for the datasets you are querying using the assemble_dataset_context tool.

        Args:
            sql_query: The SQL query or queries to execute (separated by semicolons for multiple queries)

        Returns:
            Results starting with `query_id:<id>` on the first line, followed by CSV data.
            The query_id can be passed to cancel_query() to cancel a running query,
            or to get_query_status() to check its current state.
            For multiple queries, each result section includes its own query_id.

        Examples:
            Single query: "SELECT COUNT(*) FROM table1"
            Multiple queries: "SELECT COUNT(*) FROM table1; SELECT AVG(price) FROM table2"
        """
        from point_topic_mcp.connectors.snowflake import SnowflakeDB, non_empty_sql_statements

        query_list = non_empty_sql_statements(sql_query)

        # multi-query: use existing path (cancellation not supported per-query)
        if len(query_list) > 1:
            sf = SnowflakeDB()
            sf.connect()
            result = sf.execute_safe_queries(sql_query)
            sf.close_connection()
            return result

        # single query: submit, emit query_id immediately via ctx, then fetch
        sf = SnowflakeDB()
        sf.connect()
        try:
            cursor, query_id = sf.submit_async_query(sql_query)
        except ValueError as e:
            sf.close_connection()
            return f"ERROR: {e}"
        except Exception as e:
            sf.close_connection()
            return f"DATABASE ERROR: {str(e)}"

        # Emit query_id mid-execution via MCP notifications/progress (not logging).
        # UPC Query Agent and other clients can subscribe to progress on tools/call.
        if ctx:
            report = getattr(ctx, "report_progress", None)
            if report is None:
                raise RuntimeError(
                    "execute_query requires Context.report_progress (FastMCP progress API). "
                    "Upgrade FastMCP or fix Context injection."
                )
            payload = json.dumps({"event": "query_executing", "query_id": query_id})
            await report(progress=0, total=None, message=payload)

        # run blocking poll loop in a thread so the event loop stays free
        # to flush progress notifications to the client
        import asyncio
        result = await asyncio.to_thread(sf.poll_and_fetch, cursor, query_id)
        sf.close_connection()
        return result

    def get_query_status(
        query_id: str,
        ctx: Optional[Context] = None
    ) -> str:
        """
        Check the current status of a Snowflake query.

        Useful for verifying a query is still running before cancelling it,
        or confirming a cancellation completed.

        Args:
            query_id: The query ID returned in the first line of execute_query results.

        Returns:
            JSON with query_id and status: RUNNING, SUCCESS, CANCELLED, or ERROR:<message>
        """
        import json
        from point_topic_mcp.connectors.snowflake import SnowflakeDB

        sf = SnowflakeDB()
        sf.connect()
        status = sf.check_query_status(query_id)
        sf.close_connection()
        return json.dumps({"query_id": query_id, "status": status})

    def cancel_query(
        query_id: str,
        ctx: Optional[Context] = None
    ) -> str:
        """
        Cancel a running Snowflake query.

        The query_id is returned in the first line of execute_query results.
        Intended for human-initiated cancellation (e.g. a cancel button in the UI)
        when a query is taking too long or was submitted in error.

        Args:
            query_id: The query ID to cancel.

        Returns:
            JSON confirming cancellation.
        """
        import json
        from point_topic_mcp.connectors.snowflake import SnowflakeDB

        sf = SnowflakeDB()
        sf.connect()
        sf.cancel_query(query_id)
        sf.close_connection()
        return json.dumps({"query_id": query_id, "status": "cancelled"})

    def describe_table(table_name: str, ctx: Optional[Context] = None) -> str:
        """
        Describe a table in the Snowflake database.

        Note the schema is already included in the assemble context function

        Args:
            table_name: The name of the table to describe.
            Use the full database and schema name.
            e.g. "upc_core.reports.upc_output"

        Returns:
            The schema as CSV string
        """
        from point_topic_mcp.connectors.snowflake import SnowflakeDB
        sf = SnowflakeDB()
        sf.connect()
        result = sf.describe_table(table_name)
        sf.close_connection()
        return result

    def get_la_code(la_name: str, ctx: Optional[Context] = None) -> str:
        """
        Get the LA code for a given LA name.

        Args:
            la_name: The name of the LA to get the code for

        Returns:
            The LA code for the given LA name

        Example:
            get_la_code("Westminster") -> "E09000033"
        """
        from point_topic_mcp.connectors.snowflake import SnowflakeDB

        sql_query = f"select distinct la_code from upc_core.reports.upc_output where lower(la_name) like lower('{la_name}')"
        sf = SnowflakeDB()
        sf.connect()
        result = sf.execute_safe_query(sql_query)
        sf.close_connection()
        return result

    def get_la_list_full(la_name: str, ctx: Optional[Context] = None) -> str:
        """
        Get the full list of LA codes and names.

        Can be used if the get_la_code tool doesn't match the LA name.

        Returns the full list of LA codes and names in CSV format.
        """
        from point_topic_mcp.connectors.snowflake import SnowflakeDB

        sql_query = "select distinct la_code, la_name from upc_core.reports.upc_output"
        sf = SnowflakeDB()
        sf.connect()
        result = sf.execute_safe_query(sql_query)
        sf.close_connection()
        return result

    def get_dataset_status(ctx: Optional[Context] = None) -> str:
        """
        Get the current status of all UPC datasets including latest available dates.

        This tells you:
        - The latest UPC data snapshot date (upc_reported_at)
        - The latest take-up data snapshot date (takeup_reported_at)
        - The latest forecast data snapshot date (forecast_reported_at)
        - Which datasets are currently available

        Use this to determine:
        - What date to filter for "current" or "latest" queries
        - Whether time-series tables are needed for historical analysis
        - Data freshness and availability

        Returns:
            CSV with dataset version and latest dates for each dataset
        """
        from point_topic_mcp.connectors.snowflake import SnowflakeDB

        sql_query = "select * from upc_client._status.upc_status"
        sf = SnowflakeDB()
        sf.connect()
        result = sf.execute_safe_query(sql_query)
        sf.close_connection()
        return result
