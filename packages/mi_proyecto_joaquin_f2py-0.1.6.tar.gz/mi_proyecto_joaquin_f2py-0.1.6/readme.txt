# Esto creará modulomodule.c y modulo-f2pywrappers2.f90 en tu carpeta ./src
cd ./src
python -m numpy.f2py modulo.pyf

# Como fortranobject.c no lo encuentra lo tengo que mover manualmente asi:
cp $(python -c "import numpy.f2py; import os; print(os.path.join(os.path.dirname(numpy.f2py.__file__), 'src', 'fortranobject.c'))") ./


!---------------------------------------
Para añadir una fase de test automático a tu flujo con pip, la forma más limpia y estándar en el ecosistema Python es utilizar pytest.

Si pytest no está, hay que instalarlo manualmente como

pip install pytest

Aquí tienes cómo configurarlo para que tu software en Fortran se valide nada más instalarse:

1. Estructura de archivos

mi_proyecto_joaquin_f2py/
├── src/ (tus archivos .f90, .pyf y los .c generados)
├── tests/
│   └── test_modulo.py  # <-- Nuevo archivo de tests
├── pyproject.toml
└── meson.build
└── __init__.py
└── readme.md

Ejecutar:

pip install .
pytest


!-----------------------------------------
Ahora quiero subir a PyPI (Python Package Index) mi_proyecto. Subiré el código fuente (también se puede subir con Wheel el binario ya compilado).

Hay que instalar la herramienta build:

pip install build

Inicializar un repositorio Git

git init
git add .
git commit -m "mi_proyecto_joaquin_f2py"

Y ejecutar:

python -m build

Esto generará una carpeta dist/ con dos archivos:

.tar.gz (sdist): El código fuente. Si alguien lo instala, su ordenador necesitará gfortran, gcc y ninja para compilarlo.

.whl (wheel): El paquete ya compilado para tu arquitectura (en tu caso, macOS ARM64). Ojo: Este wheel solo funcionará en otros Mac con Apple Silicon.

Ahora hay que subir a PyPI

pip install twine

Si no tengo cuenta, hay que tener una cuenta PyPI. Entro en pypi.org y me registro (YA ESTA). Ahora genero el Token en PyPI: Configuracion de cuenta; Añadir ficha de API; Ponerle un nombre (por ejemplo, "mi-token-fortran"); Se generan códigos de seguridad para recuperar cuenta; En Scope seleccionar "Entire account"; pulsar create token:

pypi-AgEIcHlwaS5vcmcCJGRiYjA5MmU5LTUwYzMtNGYzNy05N2JjLTg5NjgxYTlmZTBkMwACKlszLCJlZDQ0Nzg1Ny00ODA0LTQzYzItYjg0MS1kZDkxYzVlNTMxMzQiXQAABiCUztaKXF6Hodk-XHhBiSlD2Byms5HgQTh20I_VrZsbfw

Este toquen lo he guardado en /Usrs/joaquinlopez/.pypirc y en el fichero pypirc que tengo en la raiz de este directorio


Ahora ejecuto

twine upload dist/*

Requeriments en el ordenador remoto (gfortran, gcc, ninja)

Prueba de instalación remota:

pip install mi_proyecto_joaquin_f2py


!------------------------------------
Para subir una nueva versión, hay que crear una nueva versión tanto en el fichero meson.build como en el fichero pyproject.toml. Para automatizar esto y evitar que cada vez que se suba haya que cambiarlo a mano, se puede hacer lo siguiente:

Cambia en pyproject.toml lo siguiente

project]
name = "mi_proyecto_joaquin_f2py"
dynamic = ["version"]  # <--- Esto indica que la versión se toma de Meson
dependencies = ["numpy"]

[tool.meson-python]
# Opcional: esto asegura que meson-python busque la versión en el project() de meson.build

Para que python pueda consultar la versión (ej. modulo.__version__), añadir esto a mi_proyecto_joaquin_f2py/__init__.py

import importlib.metadata
__version__ = importlib.metadata.version("mi_proyecto_joaquin_f2py")

Ahora cambia la versión (sólo un número) en la primera línea de meson.build

rm -rf dist/
rm -rf builddir/
rm -rf .mesonpy-*
git add .
git commit -m "Actualizando a version 0.1.3"
git tag v0.1.3
python -m build --no-isolation
twine upload dist/*

