! --- Archivo: mis_funciones.f90 ---
MODULE constantes_y_calculos
    ! Asegura que las variables deban ser declaradas
    IMPLICIT NONE
    
    ! Variable pública accesible desde el programa principal
    REAL, PARAMETER :: PI = 3.14159265
    
    ! Todo lo que sea público por defecto o explícito
    PUBLIC :: area_circulo 
    
CONTAINS
    ! Función que se incluye en el módulo
    FUNCTION area_circulo(radio) RESULT(area)
        REAL, INTENT(IN) :: radio
        REAL :: area
        area = PI * radio**2
    END FUNCTION area_circulo
END MODULE constantes_y_calculos

