import modulo
import math

def test_area_circulo():
    radio = 5.0
    # Accedemos a través de la jerarquía de tu .pyf: modulo -> constantes_y_calculos -> area_circulo
    resultado = modulo.constantes_y_calculos.area_circulo(radio)
    esperado = math.pi * (radio**2)
    
    # Usamos math.isclose para comparar floats (por precisión decimal)
    assert math.isclose(resultado, esperado, rel_tol=1e-5), f"Error: {resultado} != {esperado}"

def test_constante_pi():
    # Si mantuviste la variable pi en el .pyf
    if hasattr(modulo.constantes_y_calculos, 'pi'):
        assert math.isclose(modulo.constantes_y_calculos.pi, 3.14159, rel_tol=1e-3)

