import importlib.metadata
__version__ = importlib.metadata.version("mi_proyecto_joaquin_f2py")

