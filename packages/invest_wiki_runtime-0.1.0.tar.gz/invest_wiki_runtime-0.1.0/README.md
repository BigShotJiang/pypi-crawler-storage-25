# invest-llm-wiki

面向中文开发者的 md-first 投资研究 wiki skill 包，优先支持 Claude Code、Codex、OpenClaw。

## 这个仓库是什么

`invest-llm-wiki` 是一个版本化 skill-pack 仓库，不是可直接 import 的应用 SDK。当前仓库包含 canonical skill catalog、agent-facing adapter README / manifests、`invest-wiki-runtime` 的 PyPI package source、preset/docs 脚手架，以及围绕这些 surface 的契约测试。

## 兼容环境

- Claude Code
- Codex
- OpenClaw

## 语言策略

默认 README 使用中文。英文说明保留在 `README.en.md`，用于开源发现和传播。

## For AI Agents

Use these entry points depending on the task:

- [skills/invest-wiki-dossier/SKILL.md](skills/invest-wiki-dossier/SKILL.md): ticker-first dossier orchestration, discover/materialize/render/validate.
- [skills/invest-wiki-ingest/SKILL.md](skills/invest-wiki-ingest/SKILL.md): scaffold source note / event / rollup / query pages from new material.
- [skills/invest-wiki-right-business/SKILL.md](skills/invest-wiki-right-business/SKILL.md), [skills/invest-wiki-right-people/SKILL.md](skills/invest-wiki-right-people/SKILL.md), [skills/invest-wiki-right-price/SKILL.md](skills/invest-wiki-right-price/SKILL.md): update the three judgment pages.
- [skills/invest-wiki-article/SKILL.md](skills/invest-wiki-article/SKILL.md), [skills/invest-wiki-lint/SKILL.md](skills/invest-wiki-lint/SKILL.md), [skills/invest-wiki-query/SKILL.md](skills/invest-wiki-query/SKILL.md): compose the final article, run maintenance checks, and materialize reusable query output.

Install the packaged skills with:

```bash
npx skills add xdsjs/invest-llm-wiki
```

Or install only what you need:

```bash
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-dossier
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-ingest
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-right-business
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-right-people
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-right-price
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-article
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-lint
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-query
```

Install the matching runtime version:

```bash
python3 -m pip install -U invest-wiki-runtime==0.1.0
```

Run the runtime directly from the skill:

```bash
python3 -m invest_wiki_runtime config get-root
python3 -m invest_wiki_runtime config set-root --root /absolute/path
python3 -m invest_wiki_runtime dossier run --ticker STZ
```

runtime root 配置文件仍然是 `~/.config/invest-llm-wiki/config.toml`。skill 会先检查 `config get-root` / `config set-root`，然后再执行对应业务命令。repo tag、skill 文案和 PyPI runtime 版本保持严格一致。

对仓库维护者而言，`scripts/sync/sync_surfaces.py` 和 `scripts/verify/verify_repo.py` 仍然保留，用来刷新 adapter manifests 与验证当前 repo surface；它们不是开发者安装技能包的入口。

`investment-research` 在这里仍然只是一个契约说明，不是已经安装好的运行时 preset。它定义的是技能包应该满足的文件与工作流边界。

## 计划中的 preset 形态

后续的 `investment-research` preset 预计包括：

- `invest-wiki-dossier`
- `invest-wiki-ingest`
- `invest-wiki-right-business`
- `invest-wiki-right-people`
- `invest-wiki-right-price`
- `invest-wiki-article`
- `invest-wiki-lint`
- `invest-wiki-query`

更多英文说明请见 `README.en.md`。
