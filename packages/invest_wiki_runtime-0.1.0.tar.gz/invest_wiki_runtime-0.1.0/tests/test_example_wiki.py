from pathlib import Path
import os
import shutil
import subprocess
import sys
import tempfile
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]
CLI = REPO_ROOT / "scripts" / "invest_wiki_cli.py"
EXAMPLE_ROOT = REPO_ROOT / "examples" / "minimal-company-wiki"
DEMO_ROOT = EXAMPLE_ROOT / "content" / "companies" / "DEMO"


class ExampleWikiTests(unittest.TestCase):
    def test_minimal_company_wiki_is_materialized(self) -> None:
        self.assertTrue((EXAMPLE_ROOT / "README.md").is_file())
        self.assertTrue((DEMO_ROOT / "basic.json").is_file())
        self.assertTrue((DEMO_ROOT / "calendar.json").is_file())
        self.assertTrue((DEMO_ROOT / "right-business.md").is_file())
        self.assertTrue((DEMO_ROOT / "right-people.md").is_file())
        self.assertTrue((DEMO_ROOT / "right-price.md").is_file())
        self.assertTrue((DEMO_ROOT / "wiki-article.md").is_file())
        self.assertTrue((DEMO_ROOT / "wiki-refs.json").is_file())
        self.assertTrue((DEMO_ROOT / "wiki-claims.jsonl").is_file())
        self.assertTrue((DEMO_ROOT / "dossier" / "index.md").is_file())
        self.assertTrue((DEMO_ROOT / "dossier" / "log.md").is_file())
        self.assertTrue((DEMO_ROOT / "dossier" / "wiki" / "sources" / "source-note-demo.md").is_file())

        article = (DEMO_ROOT / "wiki-article.md").read_text(encoding="utf-8")
        self.assertIn("## 公司概览", article)
        self.assertIn("DEMO", article)
        self.assertIn("wiki-refs.json", article)
        self.assertIn("wiki-claims.jsonl", article)

    def test_committed_example_can_be_copied_and_bootstrapped(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            target = Path(tmpdir) / "example"
            shutil.copytree(EXAMPLE_ROOT, target)
            self.assertTrue((target / "README.md").is_file())
            self.assertTrue((target / "content" / "companies" / "DEMO" / "wiki-article.md").is_file())

            bootstrap = subprocess.run(
                [
                    sys.executable,
                    str(CLI),
                    "dossier",
                    "run",
                    "--root",
                    str(target / "content"),
                    "--ticker",
                    "DEMO",
                ],
                cwd=REPO_ROOT,
                env={
                    **os.environ,
                    "INVEST_WIKI_DISABLE_NETWORK": "1",
                    "INVEST_WIKI_FIXTURE_PROVIDERS": "1",
                    "INVEST_WIKI_OUTPUT": "json",
                },
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(bootstrap.returncode, 0, bootstrap.stderr)

            dossier_root = target / "content" / "companies" / "DEMO" / "dossier"
            self.assertTrue((dossier_root / "wiki" / "sources").is_dir())
            self.assertTrue((dossier_root / "wiki" / "events").is_dir())
            self.assertTrue((dossier_root / "wiki" / "rollups").is_dir())
            self.assertTrue((dossier_root / "wiki" / "queries").is_dir())


if __name__ == "__main__":
    unittest.main()
