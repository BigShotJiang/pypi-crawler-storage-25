from pathlib import Path
import unittest

REPO_ROOT = Path(__file__).resolve().parents[1]


class RepoContractTests(unittest.TestCase):
    def test_p0_core_directories_exist(self) -> None:
        expected_dirs = [
            "skills",
            "presets",
            "src/invest_wiki_runtime/runtime/dossier",
            "src/invest_wiki_runtime/runtime/dossier/providers",
            "scripts/sync",
            "scripts/verify",
            "examples",
            ".github",
            ".github/workflows",
            ".claude",
            ".codex",
            "openclaw",
            "tests",
        ]
        for rel in expected_dirs:
            with self.subTest(rel=rel):
                self.assertTrue((REPO_ROOT / rel).is_dir(), rel)
        self.assertTrue((REPO_ROOT / "pyproject.toml").is_file())
        self.assertTrue((REPO_ROOT / "src" / "invest_wiki_runtime" / "__main__.py").is_file())
        self.assertTrue((REPO_ROOT / ".github" / "workflows" / "publish-runtime.yml").is_file())

    def test_gitignore_exists(self) -> None:
        gitignore = REPO_ROOT / ".gitignore"
        self.assertTrue(gitignore.is_file())
        content = gitignore.read_text(encoding="utf-8")
        self.assertIn(".DS_Store", content)
        self.assertIn("__pycache__/", content)

    def test_root_agents_md_exists(self) -> None:
        agents = REPO_ROOT / "AGENTS.md"
        self.assertTrue(agents.is_file())
        content = agents.read_text(encoding="utf-8")
        self.assertIn("Specs 与 Skills 的边界", content)
        self.assertIn("spec 可以描述 evolution", content)
        self.assertIn("skill 只应描述", content)
        self.assertIn("V1", content)
        self.assertIn("opencli integration", content)


if __name__ == "__main__":
    unittest.main()
