from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from invest_wiki_runtime.runtime.dossier.providers.base import DiscoveredSource
from invest_wiki_runtime.runtime.dossier.providers.earnings_calendar_provider import EarningsCalendarProvider
from invest_wiki_runtime.runtime.dossier.providers.official_web_provider import OfficialWebProvider
from invest_wiki_runtime.runtime.dossier.providers.sec_provider import SecProvider
from invest_wiki_runtime.runtime.dossier.providers.yfinance_provider import YFinanceProvider


class DossierProviderContractTests(unittest.TestCase):
    def test_discovered_source_payload_serializes_canonical_fields(self) -> None:
        source = DiscoveredSource(
            source_id="official-company-homepage",
            slot_id="official.company_homepage",
            source_type="official_web",
            title="Official company homepage",
            url="https://example.com",
            publisher="Example Inc.",
            discovered_at="2026-04-14T00:00:00Z",
            published_at=None,
            notes=None,
            materialization_status="pending",
            materialized_paths=("raw/homepage.md",),
        )

        payload = source.to_payload()

        self.assertEqual(
            payload,
            {
                "source_id": "official-company-homepage",
                "slot_id": "official.company_homepage",
                "source_type": "official_web",
                "title": "Official company homepage",
                "url": "https://example.com",
                "publisher": "Example Inc.",
                "discovered_at": "2026-04-14T00:00:00Z",
                "published_at": None,
                "notes": None,
                "source_origin": None,
                "document_family": None,
                "document_type": None,
                "materialization_status": "pending",
                "materialized_paths": ["raw/homepage.md"],
            },
        )

    def test_discovered_source_defaults_materialized_paths_to_empty_list(self) -> None:
        source = DiscoveredSource(
            source_id="official-company-homepage",
            slot_id="official.company_homepage",
            source_type="official_web",
            title="Official company homepage",
            url="https://example.com",
            publisher="Example Inc.",
            discovered_at="2026-04-14T00:00:00Z",
            published_at=None,
            notes=None,
        )

        self.assertEqual(source.to_payload()["materialized_paths"], [])

    @patch("invest_wiki_runtime.runtime.dossier.providers.yfinance_provider.yf.Ticker")
    def test_yfinance_snapshot_extracts_company_metadata(self, ticker_cls: object) -> None:
        fake_ticker = MagicMock()
        fake_ticker.info = {
            "longName": "NVIDIA Corporation",
            "currency": "USD",
            "exchange": "NMS",
            "website": "https://www.nvidia.com",
            "irWebsite": "https://investor.nvidia.com",
        }
        ticker_cls.return_value = fake_ticker

        snapshot = YFinanceProvider().snapshot("NVDA", "us")

        self.assertEqual(
            snapshot,
            {
                "company_name": "NVIDIA Corporation",
                "currency": "USD",
                "exchange": "NMS",
                "website": "https://www.nvidia.com",
                "irWebsite": "https://investor.nvidia.com",
            },
        )
        ticker_cls.assert_called_once_with("NVDA")

    @patch("invest_wiki_runtime.runtime.dossier.providers.earnings_calendar_provider.build_earnings_calendar")
    @patch("invest_wiki_runtime.runtime.dossier.providers.earnings_calendar_provider.yf.Ticker")
    @patch("invest_wiki_runtime.runtime.dossier.providers.earnings_calendar_provider._iso_now", return_value="2026-04-14T00:00:00Z")
    def test_earnings_calendar_provider_discovers_results_date_source(
        self,
        iso_now: object,
        ticker_cls: object,
        build_calendar: object,
    ) -> None:
        fake_ticker = MagicMock()
        ticker_cls.return_value = fake_ticker
        build_calendar.return_value = {
            "provider": "yfinance",
            "next_earnings_date": "2026-05-28",
            "earnings_window_start": "2026-05-28",
            "earnings_window_end": "2026-05-29",
        }

        sources = EarningsCalendarProvider().discover("NVDA")

        self.assertEqual(len(sources), 1)
        self.assertEqual(sources[0].slot_id, "events.earnings_calendar_or_results_date")
        self.assertEqual(sources[0].source_id, "events-earnings-calendar")
        self.assertEqual(sources[0].published_at, "2026-05-28")
        self.assertEqual(sources[0].url, "https://finance.yahoo.com/quote/NVDA")
        ticker_cls.assert_called_once_with("NVDA")
        build_calendar.assert_called_once_with(fake_ticker)
        self.assertTrue(iso_now.called)

    @patch("invest_wiki_runtime.runtime.dossier.providers.official_web_provider._iso_now", return_value="2026-04-14T00:00:00Z")
    @patch("invest_wiki_runtime.runtime.dossier.providers.official_web_provider._url_is_reachable", side_effect=lambda url: "investor" in url)
    def test_official_web_provider_discovers_homepage_and_investor_relations(
        self,
        reachable: object,
        iso_now: object,
    ) -> None:
        sources = OfficialWebProvider().discover(
            "NVDA",
            "us",
            company_name="NVIDIA",
            snapshot={
                "website": "www.nvidia.com",
                "irWebsite": "https://investor.nvidia.com",
            },
        )

        self.assertEqual([source.slot_id for source in sources], ["official.company_homepage", "official.ir_homepage_or_newsroom"])
        self.assertEqual(sources[0].url, "https://www.nvidia.com")
        self.assertEqual(sources[1].url, "https://investor.nvidia.com")
        self.assertTrue(iso_now.called)
        self.assertTrue(reachable.called)

    @patch("invest_wiki_runtime.runtime.dossier.providers.sec_provider._iso_now", return_value="2026-04-14T00:00:00Z")
    @patch("invest_wiki_runtime.runtime.dossier.providers.sec_provider.SECClient.fetch_submissions")
    @patch("invest_wiki_runtime.runtime.dossier.providers.sec_provider.SECClient.resolve_ticker", return_value=("1045810", "NVIDIA Corporation"))
    def test_sec_provider_discovers_us_filing_sources(
        self,
        resolve_ticker: object,
        fetch_submissions: object,
        iso_now: object,
    ) -> None:
        fetch_submissions.return_value = {
            "cik": "1045810",
            "filings": {
                "recent": {
                    "form": ["10-K", "10-Q", "8-K", "DEF 14A", "4"],
                    "filingDate": ["2025-02-21", "2025-05-22", "2025-03-18", "2025-04-02", "2025-04-10"],
                    "accessionNumber": [
                        "0001045810-25-000010",
                        "0001045810-25-000020",
                        "0001045810-25-000030",
                        "0001045810-25-000040",
                        "0001045810-25-000050",
                    ],
                    "primaryDocument": [
                        "annual.htm",
                        "quarterly.htm",
                        "current.htm",
                        "proxy.htm",
                        "form4.xml",
                    ],
                    "primaryDocDescription": [
                        "Annual report",
                        "Quarterly report",
                        "Current report",
                        "Proxy statement",
                        "Insider transaction",
                    ],
                    "reportDate": ["2025-01-31", "2025-04-30", "", "", ""],
                }
            },
        }

        sources = SecProvider(user_agent="ResearchBot/1.0").discover("NVDA")

        self.assertGreaterEqual(len(sources), 5)
        self.assertIn("regulatory.annual_report_latest", [source.slot_id for source in sources])
        self.assertIn("regulatory.periodic_reports_recent", [source.slot_id for source in sources])
        self.assertIn("regulatory.material_events_recent", [source.slot_id for source in sources])
        self.assertIn("governance.proxy_or_annual_meeting_materials", [source.slot_id for source in sources])
        self.assertIn("regulatory.ownership_or_insider_context", [source.slot_id for source in sources])
        self.assertTrue(all(source.url and source.url.startswith("https://www.sec.gov/Archives/edgar/data/") for source in sources))
        resolve_ticker.assert_called_once_with("NVDA")
        fetch_submissions.assert_called_once_with("1045810")
        self.assertTrue(iso_now.called)
