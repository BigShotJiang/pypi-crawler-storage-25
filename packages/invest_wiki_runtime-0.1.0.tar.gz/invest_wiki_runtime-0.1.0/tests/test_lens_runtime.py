from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]
CLI = REPO_ROOT / "scripts" / "invest_wiki_cli.py"


class LensRuntimeTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["INVEST_WIKI_DISABLE_NETWORK"] = "1"
        env["INVEST_WIKI_FIXTURE_PROVIDERS"] = "1"
        env["INVEST_WIKI_OUTPUT"] = "json"
        return subprocess.run(
            [sys.executable, str(CLI), *args],
            cwd=REPO_ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_prepare_initializes_right_business_contract(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            completed = self.run_cli("right-business", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            page = Path(tmpdir) / "companies" / "DEMO" / "right-business.md"
            body = page.read_text(encoding="utf-8")
            self.assertIn("## One-sentence judgment", body)
            self.assertIn("## Core thesis", body)

    def test_validate_detects_duplicate_judgment_and_thesis(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.run_cli("right-price", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            page = Path(tmpdir) / "companies" / "DEMO" / "right-price.md"
            page.write_text(
                (
                    "# Right Price\n\n"
                    "## One-sentence judgment\n\n"
                    "Same content.\n\n"
                    "## Core thesis\n\n"
                    "Same content.\n\n"
                    "## What the market seems to believe\n\nx\n\n"
                    "## Valuation framework\n\nx\n\n"
                    "## Key assumptions\n\nx\n\n"
                    "## Catalysts and timing\n\nx\n\n"
                    "## What breaks the thesis\n\nx\n\n"
                    "## What could change the judgment\n\nx\n"
                ),
                encoding="utf-8",
            )
            completed = self.run_cli("right-price", "validate", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "duplicate_block")

    def test_prepare_symlink_escape_returns_json_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.run_cli("right-business", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            page = Path(tmpdir) / "companies" / "DEMO" / "right-business.md"
            outside_page = Path(external_dir) / "outside-right-business.md"
            outside_page.write_text("outside baseline\n", encoding="utf-8")
            page.unlink()
            try:
                os.symlink(outside_page, page)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli("right-business", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)
            self.assertEqual(outside_page.read_text(encoding="utf-8"), "outside baseline\n")

    def test_prepare_rejects_symlinked_parent_company_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            company = Path(tmpdir) / "companies" / "DEMO"
            shutil.rmtree(company)
            external_company = Path(external_dir) / "DEMO"
            external_company.mkdir(parents=True, exist_ok=True)
            try:
                os.symlink(external_company, company)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli("right-business", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)
            self.assertFalse((external_company / "right-business.md").exists())

    def test_validate_rejects_symlinked_parent_company_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            company = Path(tmpdir) / "companies" / "DEMO"
            shutil.rmtree(company)
            external_company = Path(external_dir) / "DEMO"
            external_company.mkdir(parents=True, exist_ok=True)
            (external_company / "right-business.md").write_text("# outside\n", encoding="utf-8")
            try:
                os.symlink(external_company, company)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli("right-business", "validate", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)


if __name__ == "__main__":
    unittest.main()
