from __future__ import annotations

import tempfile
import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from invest_wiki_runtime.runtime.dossier.paths import (
    dossier_archive_path,
    dossier_index_path,
    dossier_log_jsonl_path,
    dossier_overview_path,
    dossier_raw_dir,
    dossier_registry_path,
)


class DossierPathTests(unittest.TestCase):
    def test_canonical_dossier_paths_follow_file_truth_layout(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            self.assertEqual(
                dossier_archive_path(root, "nvda"),
                root / "companies" / "NVDA" / "dossier" / "archive.json",
            )
            self.assertEqual(
                dossier_registry_path(root, "NVDA"),
                root / "companies" / "NVDA" / "dossier" / "source_registry.json",
            )
            self.assertEqual(
                dossier_overview_path(root, "NVDA"),
                root / "companies" / "NVDA" / "dossier" / "dossier.md",
            )
            self.assertEqual(
                dossier_index_path(root, "NVDA"),
                root / "companies" / "NVDA" / "dossier" / "index.md",
            )
            self.assertEqual(
                dossier_log_jsonl_path(root, "NVDA"),
                root / "companies" / "NVDA" / "dossier" / "log.jsonl",
            )
            self.assertEqual(
                dossier_raw_dir(root, "NVDA"),
                root / "companies" / "NVDA" / "dossier" / "raw",
            )
