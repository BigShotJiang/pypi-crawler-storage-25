from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from urllib.parse import urlparse

from invest_wiki_runtime.runtime.dossier.workspace import dossier_paths


REPO_ROOT = Path(__file__).resolve().parents[1]


class DossierMaterializationTests(unittest.TestCase):
    def test_raw_path_planner_groups_sec_10k_by_document_type(self) -> None:
        from invest_wiki_runtime.runtime.dossier.materialization.paths import reserve_raw_materialization_path

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            paths = dossier_paths(root, "DEMO")
            paths["raw"].mkdir(parents=True, exist_ok=True)
            source = {
                "source_id": "regulatory.annual_report_latest::0000016918-25-000022",
                "slot_id": "regulatory.annual_report_latest",
                "source_type": "filing",
                "title": "10-K",
                "url": "https://www.sec.gov/Archives/edgar/data/16918/000001691825000022/stz-20250228.htm",
                "publisher": "sec_edgar",
                "discovered_at": "2026-04-14T00:00:00Z",
                "published_at": "2025-04-23",
                "notes": "10-K",
            }

            reserved: set[Path] = set()
            target = reserve_raw_materialization_path(paths, source, reserved)

            self.assertEqual(
                target,
                paths["raw"] / "regulatory" / "10-k" / "regulatory-annual-report-latest-0000016918-25-000022.md",
            )

    def test_markitdown_materializer_downloads_sec_url_with_sec_user_agent(self) -> None:
        from invest_wiki_runtime.runtime.dossier.materialization.materializers import MarkItDownMaterializer

        converter = mock.MagicMock()
        converter.convert_uri.return_value = mock.MagicMock(markdown="# SEC filing\n\nconverted body")
        response = mock.MagicMock()
        response.content = b"<html><body>filing</body></html>"
        response.headers = {"content-type": "text/html; charset=utf-8"}
        response.raise_for_status.return_value = None

        source = {
            "source_id": "regulatory.annual_report_latest::0000016918-25-000022",
            "slot_id": "regulatory.annual_report_latest",
            "source_type": "filing",
            "title": "10-K",
            "url": "https://www.sec.gov/Archives/edgar/data/16918/000001691825000022/stz-20250228.htm",
            "publisher": "sec_edgar",
            "discovered_at": "2026-04-14T00:00:00Z",
            "published_at": "2025-04-23",
            "notes": "10-K",
        }

        with mock.patch(
            "invest_wiki_runtime.runtime.dossier.materialization.materializers.MarkItDown",
            return_value=converter,
        ), mock.patch(
            "invest_wiki_runtime.runtime.dossier.materialization.materializers.requests.get",
            return_value=response,
        ) as get_mock, mock.patch.dict(
            os.environ,
            {"SEC_USER_AGENT": "ResearchBot/1.0 (research@example.com)"},
            clear=False,
        ):
            markdown = MarkItDownMaterializer().convert(source)

        self.assertEqual(markdown, "# SEC filing\n\nconverted body")
        get_mock.assert_called_once()
        self.assertEqual(get_mock.call_args.kwargs["headers"]["User-Agent"], "ResearchBot/1.0 (research@example.com)")
        converted_ref = converter.convert_uri.call_args.args[0]
        self.assertEqual(urlparse(converted_ref).scheme, "file")

    def test_markitdown_materializer_falls_back_for_fixture_sources_without_env_flags(self) -> None:
        from invest_wiki_runtime.runtime.dossier.materialization.materializers import MarkItDownMaterializer

        source = {
            "source_id": "regulatory-annual-report-latest-2026-10k",
            "slot_id": "regulatory.annual_report_latest",
            "source_type": "filing",
            "title": "DEMO 10-K annual report",
            "url": "https://www.sec.gov/Archives/edgar/data/1045810/annual-10k.htm",
            "publisher": "sec_edgar",
            "discovered_at": "2026-04-14T00:00:00Z",
            "published_at": "2026-02-21",
            "notes": "report",
            "source_origin": "fixture",
        }

        with mock.patch(
            "invest_wiki_runtime.runtime.dossier.materialization.materializers.MarkItDown",
        ) as markitdown_cls, mock.patch(
            "invest_wiki_runtime.runtime.dossier.materialization.materializers.requests.get",
        ) as requests_get:
            markdown = MarkItDownMaterializer().convert(source)

        self.assertIn("Deterministic offline snapshot generated without live MarkItDown conversion.", markdown)
        self.assertIn("document_type: annual-report", markdown)
        markitdown_cls.assert_not_called()
        requests_get.assert_not_called()

    def test_materialization_report_rolls_up_success_failure_and_type_counts(self) -> None:
        from invest_wiki_runtime.runtime.dossier.materialization.report import build_materialization_report

        report = build_materialization_report(
            ticker="DEMO",
            sources=[
                {
                    "source_id": "annual-1",
                    "document_type": "10-k",
                    "materialization_status": "materialized",
                    "materialized_paths": ["raw/regulatory/10-k/annual-1.md"],
                },
                {
                    "source_id": "event-1",
                    "document_type": "earnings-calendar",
                    "materialization_status": "materialized",
                    "materialized_paths": ["raw/events/earnings-calendar/event-1.md"],
                },
                {
                    "source_id": "annual-2",
                    "document_type": "10-k",
                    "materialization_status": "failed",
                    "materialization_error": "ImportError: markitdown is not installed",
                    "materialized_paths": [],
                },
            ],
        )

        self.assertEqual(report["summary"]["discovered_total"], 3)
        self.assertEqual(report["summary"]["materialized_success"], 2)
        self.assertEqual(report["summary"]["materialized_failed"], 1)
        self.assertEqual(report["by_document_type"]["10-k"]["discovered_total"], 2)
        self.assertEqual(report["by_document_type"]["10-k"]["materialized_failed"], 1)
        self.assertEqual(report["failures"][0]["source_id"], "annual-2")

if __name__ == "__main__":
    unittest.main()
