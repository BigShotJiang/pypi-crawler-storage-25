from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]
CLI = REPO_ROOT / "scripts" / "invest_wiki_cli.py"
WRAPPER = REPO_ROOT / "scripts" / "invest_wiki"


class RuntimeCliTests(unittest.TestCase):
    def run_cli(self, *args: str, home: str | None = None) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["INVEST_WIKI_DISABLE_NETWORK"] = "1"
        env["INVEST_WIKI_FIXTURE_PROVIDERS"] = "1"
        env["INVEST_WIKI_OUTPUT"] = "json"
        if home is not None:
            env["HOME"] = home
        return subprocess.run(
            [sys.executable, str(CLI), *args],
            cwd=REPO_ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )

    def run_wrapper(self, *args: str, home: str | None = None) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["INVEST_WIKI_DISABLE_NETWORK"] = "1"
        env["INVEST_WIKI_FIXTURE_PROVIDERS"] = "1"
        env["INVEST_WIKI_OUTPUT"] = "json"
        if home is not None:
            env["HOME"] = home
        return subprocess.run(
            [str(WRAPPER), *args],
            cwd=REPO_ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_unknown_skill_returns_json_error(self) -> None:
        completed = self.run_cli("missing-skill", "run", "--root", str(REPO_ROOT), "--ticker", "DEMO")
        self.assertNotEqual(completed.returncode, 0)
        payload = json.loads(completed.stdout)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error_code"], "unknown_skill")

    def test_missing_ticker_returns_json_error(self) -> None:
        completed = self.run_cli("dossier", "run", "--root", str(REPO_ROOT))
        self.assertNotEqual(completed.returncode, 0)
        payload = json.loads(completed.stdout)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error_code"], "invalid_arguments")

    def test_missing_root_returns_json_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home:
            completed = self.run_cli("dossier", "run", "--ticker", "DEMO", home=tmp_home)
        self.assertNotEqual(completed.returncode, 0)
        payload = json.loads(completed.stdout)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error_code"], "missing_root_config")

    def test_malformed_flag_value_returns_json_error(self) -> None:
        completed = self.run_cli("dossier", "run", "--ticker", "--root", str(REPO_ROOT))
        self.assertNotEqual(completed.returncode, 0)
        payload = json.loads(completed.stdout)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error_code"], "invalid_arguments")

    def test_unknown_trailing_argument_returns_json_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO", "--strict")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")

    def test_invalid_ticker_returns_json_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            for ticker in ("../BAD", "A/B", "   "):
                with self.subTest(ticker=ticker):
                    completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", ticker)
                    self.assertNotEqual(completed.returncode, 0)
                    payload = json.loads(completed.stdout)
                    self.assertFalse(payload["ok"])
                    self.assertEqual(payload["error_code"], "invalid_arguments")
                    self.assertNotIn("Traceback", completed.stderr)

    def test_known_command_returns_structured_dossier_report(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertEqual(payload["status"], "ok")
            self.assertEqual(payload["module"], "dossier")
            self.assertEqual(payload["ticker"], "DEMO")
            self.assertTrue(payload["run_id"].startswith("dossier-"))
            self.assertEqual(payload["error"], "")

            report = payload["payload"]
            self.assertEqual(report["archive_ticker"], "DEMO")
            self.assertEqual(report["company_name"], "DEMO")
            self.assertEqual(report["summary"]["coverage_score"], 75)
            self.assertEqual(report["warnings"], [])

    def test_ticker_only_dossier_run_infers_us_market(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "nvda")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertEqual(payload["ticker"], "NVDA")
            self.assertEqual(payload["summary"]["market"], "us")

    def test_dossier_run_uses_persisted_market_in_response(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            company_root = Path(tmpdir) / "companies" / "NVDA"
            company_root.mkdir(parents=True, exist_ok=True)
            (company_root / "basic.json").write_text(
                json.dumps(
                    {
                        "ticker": "NVDA",
                        "company_name": "NVIDIA",
                        "market": "hk",
                        "summary": "",
                        "last_verified_at": "",
                    },
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )

            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "nvda")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertEqual(payload["ticker"], "NVDA")
            self.assertEqual(payload["summary"]["market"], "hk")

            basic = json.loads((company_root / "basic.json").read_text(encoding="utf-8"))
            archive = json.loads((company_root / "dossier" / "archive.json").read_text(encoding="utf-8"))
            self.assertEqual(basic["market"], "hk")
            self.assertEqual(archive["company"]["market"], "hk")

    def test_hk_ticker_dossier_run_persists_hk_market(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "0700.HK")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertEqual(payload["ticker"], "0700.HK")
            self.assertEqual(payload["summary"]["market"], "hk")

            company_root = Path(tmpdir) / "companies" / "0700.HK"
            basic = json.loads((company_root / "basic.json").read_text(encoding="utf-8"))
            archive = json.loads((company_root / "dossier" / "archive.json").read_text(encoding="utf-8"))
            self.assertEqual(basic["market"], "hk")
            self.assertEqual(archive["company"]["market"], "hk")

    def test_materialize_sanitizes_null_basic_strings(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            company_root = Path(tmpdir) / "companies" / "NVDA"
            company_root.mkdir(parents=True, exist_ok=True)
            (company_root / "basic.json").write_text(
                json.dumps(
                    {
                        "ticker": "NVDA",
                        "company_name": None,
                        "market": None,
                        "summary": None,
                        "last_verified_at": None,
                    },
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )

            completed = self.run_cli("dossier", "materialize", "--root", tmpdir, "--ticker", "NVDA")
            self.assertEqual(completed.returncode, 0, completed.stderr)

            basic = json.loads((company_root / "basic.json").read_text(encoding="utf-8"))
            archive = json.loads((company_root / "dossier" / "archive.json").read_text(encoding="utf-8"))

            self.assertEqual(basic["company_name"], "")
            self.assertEqual(basic["summary"], "")
            self.assertEqual(basic["last_verified_at"], "")
            self.assertEqual(basic["market"], "us")
            self.assertNotIn("None", (company_root / "basic.json").read_text(encoding="utf-8"))
            self.assertEqual(archive["company"]["company_name"], "NVDA")
            self.assertEqual(archive["company"]["market"], "us")
            self.assertNotIn("None", (company_root / "dossier" / "archive.json").read_text(encoding="utf-8"))

    def test_config_get_root_returns_missing_root_config_error_when_unconfigured(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home:
            completed = self.run_cli("config", "get-root", home=tmp_home)
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "missing_root_config")
            self.assertIn("config set-root --root /absolute/path", payload["message"])

    def test_config_set_root_persists_existing_absolute_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home, tempfile.TemporaryDirectory() as tmp_root:
            resolved_root = str(Path(tmp_root).resolve())
            completed = self.run_cli("config", "set-root", "--root", tmp_root, home=tmp_home)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["skill"], "config")
            self.assertEqual(payload["action"], "set-root")
            self.assertEqual(payload["root"], resolved_root)

            config_path = Path(tmp_home) / ".config" / "invest-llm-wiki" / "config.toml"
            self.assertEqual(payload["config_path"], str(config_path))
            self.assertEqual(
                config_path.read_text(encoding="utf-8"),
                'version = 1\n\n[runtime]\nroot = "{}"\n'.format(resolved_root.replace("\\", "\\\\")),
            )

    def test_config_set_root_rejects_nonexistent_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home, tempfile.TemporaryDirectory() as tmp_root_parent:
            missing_root = Path(tmp_root_parent) / "missing"
            completed = self.run_cli("config", "set-root", "--root", str(missing_root), home=tmp_home)
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_root_config")

    def test_config_set_root_rejects_companies_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home, tempfile.TemporaryDirectory() as tmp_root:
            content_root = Path(tmp_root)
            companies_root = content_root / "companies"
            companies_root.mkdir()

            completed = self.run_cli("config", "set-root", "--root", str(companies_root), home=tmp_home)
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_root_config")

    def test_known_command_uses_configured_root_when_root_flag_is_omitted(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home, tempfile.TemporaryDirectory() as tmp_root:
            configured = self.run_cli("config", "set-root", "--root", tmp_root, home=tmp_home)
            self.assertEqual(configured.returncode, 0, configured.stderr)

            completed = self.run_cli("dossier", "run", "--ticker", "DEMO", home=tmp_home)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertEqual(payload["status"], "ok")
            self.assertTrue((Path(tmp_root) / "companies" / "DEMO" / "dossier" / "archive.json").is_file())

    def test_runtime_command_returns_invalid_root_config_when_saved_root_disappears(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home, tempfile.TemporaryDirectory() as tmp_root_parent:
            missing_root = Path(tmp_root_parent) / "missing-root"
            config_dir = Path(tmp_home) / ".config" / "invest-llm-wiki"
            config_dir.mkdir(parents=True, exist_ok=True)
            (config_dir / "config.toml").write_text(
                f'version = 1\n\n[runtime]\nroot = "{missing_root}"\n',
                encoding="utf-8",
            )

            completed = self.run_cli("dossier", "run", "--ticker", "DEMO", home=tmp_home)
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_root_config")

    def test_wrapper_executes_cli_via_repo_entrypoint(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home:
            completed = self.run_wrapper("config", "get-root", home=tmp_home)
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "missing_root_config")
            self.assertNotIn("ModuleNotFoundError", completed.stderr)

    def test_cli_defaults_to_markdown_brief(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home:
            env = dict(os.environ)
            env["HOME"] = tmp_home
            env["INVEST_WIKI_DISABLE_NETWORK"] = "1"
            env["INVEST_WIKI_FIXTURE_PROVIDERS"] = "1"
            env.pop("INVEST_WIKI_OUTPUT", None)
            completed = subprocess.run(
                [sys.executable, str(CLI), "config", "get-root"],
                cwd=REPO_ROOT,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertNotEqual(completed.returncode, 0)
            self.assertTrue(completed.stdout.startswith("# Config Get Root"))
            self.assertIn("missing_root_config", completed.stdout)


if __name__ == "__main__":
    unittest.main()
