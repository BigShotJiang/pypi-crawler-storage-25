from __future__ import annotations

import json
import tempfile
import sys
import unittest
from pathlib import Path
from unittest.mock import patch


REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from invest_wiki_runtime.runtime.dossier.providers.base import DiscoveredSource
from invest_wiki_runtime.runtime.dossier.discover import discover_dossier


class DossierDiscoverTests(unittest.TestCase):
    @patch("invest_wiki_runtime.runtime.dossier.discover.EarningsCalendarProvider.discover", return_value=[])
    @patch("invest_wiki_runtime.runtime.dossier.discover.YFinanceProvider.snapshot")
    @patch("invest_wiki_runtime.runtime.dossier.discover.OfficialWebProvider.discover", return_value=[])
    @patch("invest_wiki_runtime.runtime.dossier.discover.SecProvider.discover", return_value=[])
    def test_discover_dossier_persists_seed_truth_with_provider_backed_inputs(
        self,
        sec_discover: object,
        official_discover: object,
        yfinance_snapshot: object,
        earnings_discover: object,
    ) -> None:
        yfinance_snapshot.return_value = {
            "company_name": "NVIDIA",
            "currency": "USD",
        }

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)

            result = discover_dossier(root, "NVDA", "us")

            self.assertTrue(
                (root / "companies" / "NVDA" / "dossier" / "source_registry.json").is_file()
            )
            self.assertTrue(
                (root / "companies" / "NVDA" / "dossier" / "archive.json").is_file()
            )
            self.assertEqual(result["summary"]["market"], "us")
            sec_discover.assert_called_once_with("NVDA")
            official_discover.assert_called_once_with(
                "NVDA",
                "us",
                company_name="NVIDIA",
                snapshot={"company_name": "NVIDIA", "currency": "USD"},
            )
            yfinance_snapshot.assert_called_once_with("NVDA", "us")
            earnings_discover.assert_called_once_with("NVDA")

    @patch("invest_wiki_runtime.runtime.dossier.discover.EarningsCalendarProvider.discover", return_value=[])
    @patch("invest_wiki_runtime.runtime.dossier.discover.YFinanceProvider.snapshot")
    @patch("invest_wiki_runtime.runtime.dossier.discover.OfficialWebProvider.discover", return_value=[])
    @patch("invest_wiki_runtime.runtime.dossier.discover.SecProvider.discover", return_value=[])
    def test_discover_dossier_uses_basic_company_name_when_snapshot_is_blank(
        self,
        sec_discover: object,
        official_discover: object,
        yfinance_snapshot: object,
        earnings_discover: object,
    ) -> None:
        yfinance_snapshot.return_value = {
            "currency": "USD",
        }

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            company_root = root / "companies" / "NVDA"
            company_root.mkdir(parents=True, exist_ok=True)
            (company_root / "basic.json").write_text(
                json.dumps(
                    {
                        "ticker": "NVDA",
                        "company_name": "NVIDIA",
                        "market": "us",
                        "summary": "",
                        "last_verified_at": "",
                    },
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )

            result = discover_dossier(root, "NVDA", "us")

            archive = json.loads((company_root / "dossier" / "archive.json").read_text(encoding="utf-8"))
            self.assertEqual(archive["company"]["company_name"], "NVIDIA")
            self.assertEqual(result["summary"]["market"], "us")
            official_discover.assert_called_once_with(
                "NVDA",
                "us",
                company_name="NVIDIA",
                snapshot={"currency": "USD"},
            )
            sec_discover.assert_called_once_with("NVDA")
            yfinance_snapshot.assert_called_once_with("NVDA", "us")
            earnings_discover.assert_called_once_with("NVDA")

    @patch("invest_wiki_runtime.runtime.dossier.discover.EarningsCalendarProvider.discover")
    @patch("invest_wiki_runtime.runtime.dossier.discover.YFinanceProvider.snapshot", return_value={"company_name": "NVIDIA", "currency": "USD"})
    @patch("invest_wiki_runtime.runtime.dossier.discover.OfficialWebProvider.discover", return_value=[])
    @patch("invest_wiki_runtime.runtime.dossier.discover.SecProvider.discover")
    def test_discover_dossier_builds_latest_earnings_event_bundle_from_calendar_and_filing_sources(
        self,
        sec_discover: object,
        official_discover: object,
        yfinance_snapshot: object,
        earnings_discover: object,
    ) -> None:
        sec_discover.return_value = [
            DiscoveredSource(
                source_id="regulatory.material_events_recent::8k",
                slot_id="regulatory.material_events_recent",
                source_type="filing",
                title="NVIDIA 8-K",
                url="https://www.sec.gov/Archives/edgar/data/1045810/8k.htm",
                publisher="sec_edgar",
                discovered_at="2026-04-14T00:00:00Z",
                published_at="2026-05-28",
                notes="8-K",
            ),
            DiscoveredSource(
                source_id="regulatory.periodic_reports_recent::10q",
                slot_id="regulatory.periodic_reports_recent",
                source_type="filing",
                title="NVIDIA 10-Q",
                url="https://www.sec.gov/Archives/edgar/data/1045810/10q.htm",
                publisher="sec_edgar",
                discovered_at="2026-04-14T00:00:00Z",
                published_at="2026-05-29",
                notes="10-Q",
            ),
        ]
        earnings_discover.return_value = [
            DiscoveredSource(
                source_id="events-earnings-calendar",
                slot_id="events.earnings_calendar_or_results_date",
                source_type="earnings_calendar",
                title="NVIDIA earnings calendar",
                url="https://finance.yahoo.com/quote/NVDA",
                publisher="yfinance",
                discovered_at="2026-04-14T00:00:00Z",
                published_at="2026-05-28",
                notes="yfinance earnings calendar snapshot",
            )
        ]

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)

            result = discover_dossier(root, "NVDA", "us")

            archive = json.loads((root / "companies" / "NVDA" / "dossier" / "archive.json").read_text(encoding="utf-8"))
            bundle_source = next(
                source for source in archive["sources"] if source["slot_id"] == "events.latest_earnings_event_bundle"
            )

            self.assertEqual(bundle_source["url"], "https://www.sec.gov/Archives/edgar/data/1045810/8k.htm")
            self.assertEqual(bundle_source["published_at"], "2026-05-28")
            self.assertEqual(result["summary"]["market"], "us")
            official_discover.assert_called_once()
            yfinance_snapshot.assert_called_once_with("NVDA", "us")


if __name__ == "__main__":
    unittest.main()
