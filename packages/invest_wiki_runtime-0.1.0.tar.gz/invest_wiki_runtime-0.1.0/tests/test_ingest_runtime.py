from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
CLI = REPO_ROOT / "scripts" / "invest_wiki_cli.py"


class IngestRuntimeTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["INVEST_WIKI_DISABLE_NETWORK"] = "1"
        env["INVEST_WIKI_FIXTURE_PROVIDERS"] = "1"
        env["INVEST_WIKI_OUTPUT"] = "json"
        return subprocess.run(
            [sys.executable, str(CLI), *args],
            cwd=REPO_ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_ingest_scaffold_creates_source_note_and_registers_index(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            payload_path = Path(tmpdir) / "source-note.json"
            payload_path.write_text(
                json.dumps({"page_type": "source_note", "slug": "source-note-demo", "title": "Demo Source Note"}),
                encoding="utf-8",
            )

            completed = self.run_cli(
                "ingest",
                "scaffold",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--page-type",
                "source_note",
                "--payload-file",
                str(payload_path),
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            response = json.loads(completed.stdout)
            self.assertTrue(response["ok"])
            self.assertEqual(response["skill"], "ingest")
            self.assertEqual(response["action"], "scaffold")

            source_note = (
                Path(tmpdir)
                / "companies"
                / "DEMO"
                / "dossier"
                / "wiki"
                / "sources"
                / "source-note-demo.md"
            )
            self.assertTrue(source_note.is_file())

            index_path = Path(tmpdir) / "companies" / "DEMO" / "dossier" / "index.md"
            self.assertIn("source-note-demo.md", index_path.read_text(encoding="utf-8"))

    def test_query_materialize_writes_page_and_includes_body_content(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            payload_path = Path(tmpdir) / "query.json"
            payload_path.write_text(
                json.dumps(
                    {
                        "slug": "what-broke-margin",
                        "title": "What Broke Margin?",
                        "body": "Deterministic packaged result",
                    }
                ),
                encoding="utf-8",
            )

            completed = self.run_cli(
                "query",
                "materialize",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--payload-file",
                str(payload_path),
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            response = json.loads(completed.stdout)
            self.assertTrue(response["ok"])
            self.assertEqual(response["skill"], "query")
            self.assertEqual(response["action"], "materialize")

            query_page = (
                Path(tmpdir)
                / "companies"
                / "DEMO"
                / "dossier"
                / "wiki"
                / "queries"
                / "what-broke-margin.md"
            )
            self.assertTrue(query_page.is_file())
            self.assertIn("Deterministic packaged result", query_page.read_text(encoding="utf-8"))

    def test_query_materialize_is_low_surprise_on_identical_rerun(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            payload_path = Path(tmpdir) / "query.json"
            payload_path.write_text(
                json.dumps(
                    {
                        "slug": "what-broke-margin",
                        "title": "What Broke Margin?",
                        "body": "Deterministic packaged result",
                    }
                ),
                encoding="utf-8",
            )
            first = self.run_cli(
                "query",
                "materialize",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--payload-file",
                str(payload_path),
            )
            self.assertEqual(first.returncode, 0, first.stderr)

            second = self.run_cli(
                "query",
                "materialize",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--payload-file",
                str(payload_path),
            )
            self.assertEqual(second.returncode, 0, second.stderr)
            second_response = json.loads(second.stdout)
            self.assertTrue(second_response["ok"])
            self.assertEqual(second_response["changed"], [])

    def test_ingest_scaffold_rejects_symlinked_page_escape(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            payload_path = Path(tmpdir) / "source-note.json"
            payload_path.write_text(
                json.dumps({"page_type": "source_note", "slug": "source-note-demo", "title": "Demo Source Note"}),
                encoding="utf-8",
            )
            company_root = Path(tmpdir) / "companies" / "DEMO"
            target_page = company_root / "dossier" / "wiki" / "sources" / "source-note-demo.md"
            outside_path = Path(external_dir) / "outside-source-note.md"
            outside_path.write_text("outside baseline\n", encoding="utf-8")
            try:
                os.symlink(outside_path, target_page)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli(
                "ingest",
                "scaffold",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--page-type",
                "source_note",
                "--payload-file",
                str(payload_path),
            )

            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertEqual(outside_path.read_text(encoding="utf-8"), "outside baseline\n")

    def test_ingest_scaffold_rejects_symlinked_index_escape(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            payload_path = Path(tmpdir) / "source-note.json"
            payload_path.write_text(
                json.dumps({"page_type": "source_note", "slug": "source-note-demo", "title": "Demo Source Note"}),
                encoding="utf-8",
            )
            index_path = Path(tmpdir) / "companies" / "DEMO" / "dossier" / "index.md"
            outside_index = Path(external_dir) / "outside-index.md"
            outside_index.write_text("outside index baseline\n", encoding="utf-8")
            index_path.unlink()
            try:
                os.symlink(outside_index, index_path)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli(
                "ingest",
                "scaffold",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--page-type",
                "source_note",
                "--payload-file",
                str(payload_path),
            )

            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertEqual(outside_index.read_text(encoding="utf-8"), "outside index baseline\n")

    def test_ingest_scaffold_rejects_structural_breakout_tag_value(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            payload_path = Path(tmpdir) / "source-note-bad-tags.json"
            payload_path.write_text(
                json.dumps(
                    {
                        "page_type": "source_note",
                        "slug": "source-note-demo",
                        "title": "Demo Source Note",
                        "tags": ["ok", "bad\n---\nbreakout"],
                    }
                ),
                encoding="utf-8",
            )

            completed = self.run_cli(
                "ingest",
                "scaffold",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--page-type",
                "source_note",
                "--payload-file",
                str(payload_path),
            )

            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            source_note = (
                Path(tmpdir)
                / "content"
                / "companies"
                / "DEMO"
                / "dossier"
                / "wiki"
                / "sources"
                / "source-note-demo.md"
            )
            self.assertFalse(source_note.exists())


if __name__ == "__main__":
    unittest.main()
