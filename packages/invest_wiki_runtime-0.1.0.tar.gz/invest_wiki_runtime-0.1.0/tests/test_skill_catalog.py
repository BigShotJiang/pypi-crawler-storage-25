from pathlib import Path
import re
import tomllib
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]

SKILLS = [
    "invest-wiki-dossier",
    "invest-wiki-ingest",
    "invest-wiki-right-business",
    "invest-wiki-right-people",
    "invest-wiki-right-price",
    "invest-wiki-article",
    "invest-wiki-lint",
    "invest-wiki-query",
]

SKILL_RUNTIME_KEYS = {
    "invest-wiki-dossier": "dossier",
    "invest-wiki-ingest": "ingest",
    "invest-wiki-right-business": "right-business",
    "invest-wiki-right-people": "right-people",
    "invest-wiki-right-price": "right-price",
    "invest-wiki-article": "article",
    "invest-wiki-lint": "lint",
    "invest-wiki-query": "query",
}

REQUIRED_SECTIONS = ["Trigger", "Do not use when", "Workflow", "Guardrails", "Resources"]
WORKFLOW_COMPLETENESS_MARKERS = {
    "invest-wiki-dossier": ["## 常见决策", "## 常见错误", "IR sidecar"],
    "invest-wiki-ingest": ["## Page Escalation Cheat Sheet", "## Common Mistakes", "source note -> event"],
    "invest-wiki-right-business": ["## When to Stop and Update Support Pages First", "## Common Mistakes", "完整商业史"],
    "invest-wiki-right-people": ["## When to Stop and Update Support Pages First", "## Common Mistakes", "时间语气"],
    "invest-wiki-right-price": ["## When This Remains a Right-Price Task vs. When to Hand Off", "## Common Mistakes", "允许不更新"],
    "invest-wiki-article": ["## Common Mistakes", "综合后的读者叙事", "不要先把文章写成最终版"],
    "invest-wiki-lint": ["## 报告写法", "## 何时停止", "当前只能报风险"],
    "invest-wiki-query": ["## 常见分支", "## 常见错误", "不是短期噪音"],
}


def read_skill_md(skill_name: str) -> str:
    return (REPO_ROOT / "skills" / skill_name / "SKILL.md").read_text(encoding="utf-8")


def read_skill_reference(skill_name: str, reference: str) -> str:
    return (REPO_ROOT / "skills" / skill_name / "references" / reference).read_text(encoding="utf-8")


def read_agents_md() -> str:
    return (REPO_ROOT / "AGENTS.md").read_text(encoding="utf-8")


def runtime_version() -> str:
    payload = tomllib.loads((REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    return payload["project"]["version"]


def parse_frontmatter(content: str) -> dict[str, str]:
    match = re.match(r"^---\n(.*?)\n---\n", content, re.S)
    assert match is not None, "missing frontmatter"
    frontmatter = {}
    for line in match.group(1).splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        frontmatter[key.strip()] = value.strip().strip('"')
    return frontmatter


class SkillCatalogTests(unittest.TestCase):
    def test_all_canonical_skills_exist(self) -> None:
        for skill in SKILLS:
            with self.subTest(skill=skill):
                base = REPO_ROOT / "skills" / skill
                self.assertTrue(base.is_dir(), skill)
                self.assertTrue((base / "SKILL.md").is_file(), skill)
                self.assertTrue((base / "references" / "file-rules.md").is_file(), skill)

    def test_skill_markdown_has_rewritten_contract_structure(self) -> None:
        version = runtime_version()
        for skill in SKILLS:
            with self.subTest(skill=skill):
                content = read_skill_md(skill)
                frontmatter = parse_frontmatter(content)
                self.assertEqual(frontmatter.get("name"), skill)
                self.assertTrue(frontmatter.get("description", "").strip())
                self.assertNotIn("Use when", frontmatter.get("description", ""))
                self.assertNotIn("面向中文开发者", content)
                for section in REQUIRED_SECTIONS:
                    self.assertIn(f"## {section}", content)
                self.assertIn("## 允许执行的 CLI 命令", content)
                self.assertIn(f"python3 -m pip install -U invest-wiki-runtime=={version}", content)
                self.assertIn("python3 -m invest_wiki_runtime", content)
                self.assertIn(f"python3 -m invest_wiki_runtime {SKILL_RUNTIME_KEYS[skill]}", content)
                self.assertNotIn("bootstrap_runtime.py", content)
                for marker in WORKFLOW_COMPLETENESS_MARKERS[skill]:
                    self.assertIn(marker, content)
                do_not_use_index = content.index("## Do not use when")
                cli_index = content.index("## 允许执行的 CLI 命令")
                workflow_index = content.index("## Workflow")
                self.assertLess(do_not_use_index, cli_index)
                self.assertLess(cli_index, workflow_index)

    def test_all_skills_require_runtime_root_preflight(self) -> None:
        version = runtime_version()
        for skill in SKILLS:
            with self.subTest(skill=skill):
                content = read_skill_md(skill)
                self.assertIn(f"python3 -m pip install -U invest-wiki-runtime=={version}", content)
                self.assertIn("python3 -m invest_wiki_runtime config get-root", content)
                self.assertIn("python3 -m invest_wiki_runtime config set-root --root /absolute/path", content)

    def test_dossier_skill_has_canonical_inspect_first_contract_language(self) -> None:
        skill = read_skill_md("invest-wiki-dossier")
        file_rules = read_skill_reference("invest-wiki-dossier", "file-rules.md")
        agents = read_agents_md()

        for content in (skill, file_rules):
            self.assertIn("inspect-first", content)
            self.assertIn("runtime CLI", content)
            self.assertNotIn("future extension", content)
            self.assertNotIn("future extensions", content)
            self.assertNotIn("not V1 requirements", content)
            self.assertNotIn("opencli-backed providers", content)

        self.assertIn("ticker-first", skill)
        self.assertIn("market is resolved by the runtime", skill)
        self.assertIn("archive.json", skill)
        self.assertIn("source_registry.json", skill)
        self.assertIn("dossier.md", skill)
        self.assertIn("discover", skill)
        self.assertIn("materialize", skill)
        self.assertIn("enrich", skill)
        self.assertIn("render", skill)
        self.assertIn("validate", skill)
        self.assertIn("Markdown brief", skill)
        self.assertIn("must not directly write", skill)
        self.assertIn("canonical dossier writes only happen through the runtime CLI", skill)
        self.assertIn("当前 runtime", skill)
        self.assertIn("provider contract", skill)
        self.assertIn("未接入的抓取链路", skill)
        self.assertIn("## 允许执行的 CLI 命令", skill)
        self.assertIn("python3 -m invest_wiki_runtime dossier run", skill)
        self.assertIn("python3 -m invest_wiki_runtime dossier log", skill)

        self.assertIn("canonical dossier files", file_rules)
        self.assertIn("ticker-first", file_rules)
        self.assertIn("market is resolved by the runtime", file_rules)
        self.assertIn("canonical dossier writes only happen through the runtime CLI", file_rules)
        self.assertIn("provider contract", file_rules)
        self.assertIn("Markdown brief", file_rules)

        self.assertIn("spec 可以描述 evolution", agents)
        self.assertIn("skill 只应描述", agents)
        self.assertIn("opencli integration", agents)
        self.assertIn("V1", agents)


if __name__ == "__main__":
    unittest.main()
