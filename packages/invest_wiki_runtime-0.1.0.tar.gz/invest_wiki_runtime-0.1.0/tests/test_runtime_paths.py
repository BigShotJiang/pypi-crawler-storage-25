from pathlib import Path
import unittest


from invest_wiki_runtime.runtime.paths import company_root, dossier_root


class RuntimePathsTests(unittest.TestCase):
    def test_company_root_is_under_root_companies_directory(self) -> None:
        root = Path("/tmp/wiki-content-root")
        self.assertEqual(company_root(root, "demo"), root / "companies" / "DEMO")
        self.assertEqual(dossier_root(root, "demo"), root / "companies" / "DEMO" / "dossier")


if __name__ == "__main__":
    unittest.main()
