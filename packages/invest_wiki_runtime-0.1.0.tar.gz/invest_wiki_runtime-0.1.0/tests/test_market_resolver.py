import unittest

from invest_wiki_runtime.runtime.dossier.market import infer_market, normalize_input_ticker


class MarketResolverTests(unittest.TestCase):
    def test_infer_market_defaults_us_for_ticker_only_inputs(self) -> None:
        self.assertEqual(infer_market("nvda"), "us")

    def test_normalize_input_ticker_uppercases(self) -> None:
        self.assertEqual(normalize_input_ticker("nvda"), "NVDA")

    def test_normalize_input_ticker_rejects_path_like_inputs(self) -> None:
        with self.assertRaises(ValueError):
            normalize_input_ticker("../NVDA")


if __name__ == "__main__":
    unittest.main()
