from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
CLI = REPO_ROOT / "scripts" / "invest_wiki_cli.py"


class LintRuntimeTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["INVEST_WIKI_DISABLE_NETWORK"] = "1"
        env["INVEST_WIKI_FIXTURE_PROVIDERS"] = "1"
        env["INVEST_WIKI_OUTPUT"] = "json"
        return subprocess.run(
            [sys.executable, str(CLI), *args],
            cwd=REPO_ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_lint_run_writes_report_when_requested(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "demo")
            self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "demo")

            completed = self.run_cli("lint", "run", "--root", tmpdir, "--ticker", "demo", "--write-report")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["skill"], "lint")
            self.assertEqual(payload["action"], "run")
            self.assertEqual(payload["ticker"], "DEMO")
            self.assertTrue(payload["valid"])
            self.assertEqual(payload["findings"], [])

            stamp = date.today().isoformat()
            lint_dir = Path(tmpdir) / "lint"
            json_report = lint_dir / f"{stamp}-DEMO.json"
            md_report = lint_dir / f"{stamp}-DEMO.md"
            index_report = lint_dir / "index.md"

            self.assertTrue(json_report.is_file())
            self.assertTrue(md_report.is_file())
            self.assertTrue(index_report.is_file())

            report_payload = json.loads(json_report.read_text(encoding="utf-8"))
            self.assertEqual(report_payload["date"], stamp)
            self.assertEqual(report_payload["ticker"], "DEMO")
            self.assertTrue(report_payload["valid"])
            self.assertEqual(report_payload["findings"], [])

            md_content = md_report.read_text(encoding="utf-8")
            self.assertIn(f"# Lint Report {stamp}", md_content)
            self.assertIn("- findings: 0", md_content)

            index_content = index_report.read_text(encoding="utf-8")
            self.assertIn(f"- `{stamp}-DEMO.md` / `{stamp}-DEMO.json`", index_content)

            self.assertEqual(
                payload["artifacts"],
                [
                    f"lint/{stamp}-DEMO.json",
                    f"lint/{stamp}-DEMO.md",
                    "lint/index.md",
                ],
            )

    def test_lint_run_without_write_report_is_pure_result_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "demo")
            self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "demo")

            completed = self.run_cli("lint", "run", "--root", tmpdir, "--ticker", "demo")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["skill"], "lint")
            self.assertEqual(payload["action"], "run")
            self.assertTrue(payload["valid"])
            self.assertEqual(payload["findings"], [])
            self.assertEqual(payload["changed"], [])
            self.assertEqual(payload["artifacts"], [])

            self.assertFalse((Path(tmpdir) / "lint").exists())

    def test_lint_run_write_report_preserves_reports_for_two_tickers_on_same_day(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "demo")
            self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "demo")
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "acme")
            self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "acme")

            first = self.run_cli("lint", "run", "--root", tmpdir, "--ticker", "demo", "--write-report")
            self.assertEqual(first.returncode, 0, first.stderr)
            second = self.run_cli("lint", "run", "--root", tmpdir, "--ticker", "acme", "--write-report")
            self.assertEqual(second.returncode, 0, second.stderr)

            stamp = date.today().isoformat()
            lint_dir = Path(tmpdir) / "lint"
            demo_json = lint_dir / f"{stamp}-DEMO.json"
            acme_json = lint_dir / f"{stamp}-ACME.json"
            demo_md = lint_dir / f"{stamp}-DEMO.md"
            acme_md = lint_dir / f"{stamp}-ACME.md"
            self.assertTrue(demo_json.is_file())
            self.assertTrue(acme_json.is_file())
            self.assertTrue(demo_md.is_file())
            self.assertTrue(acme_md.is_file())

            self.assertEqual(json.loads(demo_json.read_text(encoding="utf-8"))["ticker"], "DEMO")
            self.assertEqual(json.loads(acme_json.read_text(encoding="utf-8"))["ticker"], "ACME")

            index_content = (lint_dir / "index.md").read_text(encoding="utf-8")
            self.assertIn(f"- `{stamp}-DEMO.md` / `{stamp}-DEMO.json`", index_content)
            self.assertIn(f"- `{stamp}-ACME.md` / `{stamp}-ACME.json`", index_content)

    def test_lint_run_rejects_symlinked_lint_directory_escape_before_writing(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            content_dir = Path(tmpdir)
            content_dir.mkdir(parents=True, exist_ok=True)
            outside_dir = Path(external_dir)
            keep_file = outside_dir / "keep.txt"
            keep_file.write_text("outside baseline\n", encoding="utf-8")
            lint_link = content_dir / "lint"
            try:
                os.symlink(outside_dir, lint_link)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            stamp = date.today().isoformat()
            completed = self.run_cli("lint", "run", "--root", tmpdir, "--ticker", "demo", "--write-report")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertEqual(keep_file.read_text(encoding="utf-8"), "outside baseline\n")
            self.assertFalse((outside_dir / f"{stamp}-DEMO.json").exists())
            self.assertFalse((outside_dir / f"{stamp}-DEMO.md").exists())
            self.assertFalse((outside_dir / "index.md").exists())


if __name__ == "__main__":
    unittest.main()
