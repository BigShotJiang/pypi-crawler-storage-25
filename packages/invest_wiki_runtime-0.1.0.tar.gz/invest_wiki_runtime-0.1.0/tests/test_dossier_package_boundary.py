from __future__ import annotations

import importlib
from pathlib import Path
import sys
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = REPO_ROOT / "src"

if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))


class DossierPackageBoundaryTests(unittest.TestCase):
    def test_canonical_dossier_package_exists(self) -> None:
        expected_paths = [
            "pyproject.toml",
            "src/invest_wiki_runtime/__main__.py",
            "src/invest_wiki_runtime/cli.py",
            "src/invest_wiki_runtime/runtime/dossier",
            "src/invest_wiki_runtime/runtime/dossier/providers",
            "src/invest_wiki_runtime/runtime/dossier/templates",
            "src/invest_wiki_runtime/runtime/dossier/materialization/materialization-report.md.tmpl",
        ]
        for rel in expected_paths:
            with self.subTest(rel=rel):
                self.assertTrue((REPO_ROOT / rel).exists(), rel)

    def test_canonical_imports_are_loadable(self) -> None:
        modules = [
            "invest_wiki_runtime.runtime.dossier.discover",
            "invest_wiki_runtime.runtime.dossier.load",
            "invest_wiki_runtime.runtime.dossier.market",
            "invest_wiki_runtime.runtime.dossier.materialize",
            "invest_wiki_runtime.runtime.dossier.orchestrator",
            "invest_wiki_runtime.runtime.dossier.paths",
            "invest_wiki_runtime.runtime.dossier.providers.base",
            "invest_wiki_runtime.runtime.dossier.registry",
            "invest_wiki_runtime.runtime.dossier.render",
            "invest_wiki_runtime.runtime.dossier.schemas",
            "invest_wiki_runtime.runtime.dossier.validate",
            "invest_wiki_runtime.runtime.dossier.workspace",
        ]
        for module_name in modules:
            with self.subTest(module=module_name):
                self.assertIsNotNone(importlib.import_module(module_name))
