from pathlib import Path
import tomllib
import unittest

REPO_ROOT = Path(__file__).resolve().parents[1]


class DocsContractTests(unittest.TestCase):
    def runtime_version(self) -> str:
        payload = tomllib.loads((REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8"))
        return payload["project"]["version"]

    def assert_runtime_package_positioning(self, content: str) -> None:
        lowered = content.lower()
        self.assertIn("invest-wiki-runtime", content)
        self.assertIn("python3 -m invest_wiki_runtime", content)
        self.assertTrue(
            any(
                marker in lowered
                for marker in (
                    "pypi package",
                    "runtime package",
                    "published package",
                    "published pypi package",
                    "pypi",
                    "py p i",
                )
            ),
            "docs should position the runtime as a package distribution surface",
        )
        self.assertTrue(
            any(marker in lowered for marker in ("agent", "skills add", "skill")),
            "docs should mention agent-facing skill usage",
        )
        self.assertNotIn("scripts/invest_wiki_cli.py", content)
        self.assertNotIn("scripts/bootstrap_runtime.py", content)
        self.assertNotIn("bundled runner", lowered)

    def test_default_readme_reflects_current_repo_state_in_chinese(self) -> None:
        content = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
        version = self.runtime_version()
        self.assertIn("中文开发者", content)
        self.assertIn("Claude Code", content)
        self.assertIn("Codex", content)
        self.assertIn("OpenClaw", content)
        self.assertIn("README.en.md", content)
        self.assertIn("canonical skill catalog", content)
        self.assertIn("For AI Agents", content)
        self.assertIn("npx skills add xdsjs/invest-llm-wiki", content)
        self.assertIn(f"python3 -m pip install -U invest-wiki-runtime=={version}", content)
        self.assertIn("python3 -m invest_wiki_runtime config get-root", content)
        self.assertIn("scripts/sync/sync_surfaces.py", content)
        self.assertIn("scripts/verify/verify_repo.py", content)
        self.assertNotRegex(content, r"install_[a-z_]+\.sh")
        self.assertNotRegex(content, r"install_[a-z_]+\.py")
        self.assert_runtime_package_positioning(content)
        self.assertIn("~/.config/invest-llm-wiki/config.toml", content)
        self.assertIn("config set-root", content)
        self.assertIn("契约说明", content)
        self.assertIn("PyPI runtime 版本", content)
        self.assertNotIn("planned for later tasks", content)
        self.assertNotIn("Task 1 and Task 2 documentation", content)
        self.assertNotIn("scripts/" "install/", content)

    def test_chinese_alias_readme_targets_chinese_developers(self) -> None:
        content = (REPO_ROOT / "README.zh-CN.md").read_text(encoding="utf-8")
        version = self.runtime_version()
        self.assertIn("中文开发者", content)
        self.assertIn("README.en.md", content)
        self.assertIn("OpenClaw", content)
        self.assertIn("canonical skill catalog", content)
        self.assertIn("For AI Agents", content)
        self.assertIn("npx skills add xdsjs/invest-llm-wiki", content)
        self.assertIn(f"python3 -m pip install -U invest-wiki-runtime=={version}", content)
        self.assertIn("python3 -m invest_wiki_runtime config get-root", content)
        self.assertIn("scripts/sync/sync_surfaces.py", content)
        self.assertIn("scripts/verify/verify_repo.py", content)
        self.assertNotRegex(content, r"install_[a-z_]+\.sh")
        self.assertNotRegex(content, r"install_[a-z_]+\.py")
        self.assert_runtime_package_positioning(content)
        self.assertIn("~/.config/invest-llm-wiki/config.toml", content)
        self.assertIn("config set-root", content)
        self.assertIn("契约说明", content)
        self.assertIn("PyPI runtime 版本", content)
        self.assertNotIn("后续任务", content)
        self.assertNotIn("Task 1 和 Task 2 的文档", content)
        self.assertNotIn("scripts/" "install/", content)

    def test_english_readme_remains_available_for_discoverability(self) -> None:
        content = (REPO_ROOT / "README.en.md").read_text(encoding="utf-8")
        version = self.runtime_version()
        self.assertIn("Claude Code", content)
        self.assertIn("Codex", content)
        self.assertIn("OpenClaw", content)
        self.assertIn("Chinese-first", content)
        self.assertIn("canonical skill catalog", content)
        self.assertIn("For AI Agents", content)
        self.assertIn("npx skills add xdsjs/invest-llm-wiki", content)
        self.assertIn(f"python3 -m pip install -U invest-wiki-runtime=={version}", content)
        self.assertIn("python3 -m invest_wiki_runtime config get-root", content)
        self.assertIn("scripts/sync/sync_surfaces.py", content)
        self.assertIn("scripts/verify/verify_repo.py", content)
        self.assertNotRegex(content, r"install_[a-z_]+\.sh")
        self.assertNotRegex(content, r"install_[a-z_]+\.py")
        self.assert_runtime_package_positioning(content)
        self.assertIn("~/.config/invest-llm-wiki/config.toml", content)
        self.assertIn("config set-root", content)
        self.assertIn("documented here as a contract", content)
        self.assertNotIn("planned for later tasks", content)
        self.assertNotIn("Task 1 and Task 2 documentation", content)
        self.assertNotIn("scripts/" "install/", content)

    def test_preset_docs_exist(self) -> None:
        expected_files = [
            "presets/investment-research/README.md",
            "presets/investment-research/contract.md",
            "docs/contracts/page-model.md",
            "docs/architecture/adapter-surfaces.md",
        ]
        for rel in expected_files:
            with self.subTest(rel=rel):
                self.assertTrue((REPO_ROOT / rel).is_file(), rel)

    def test_preset_readme_describes_contract_not_implementation(self) -> None:
        content = (REPO_ROOT / "presets/investment-research/README.md").read_text(encoding="utf-8")
        self.assertIn("contract", content)
        self.assertIn("contract.md", content)
        self.assertIn("not yet implemented", content)
        self.assertNotIn("installed skill pack", content)

    def test_adapter_surfaces_reflect_current_bootstrap_state(self) -> None:
        content = (REPO_ROOT / "docs/architecture/adapter-surfaces.md").read_text(encoding="utf-8")
        self.assertIn("Current committed surfaces", content)
        self.assertIn("Current scaffolding", content)
        self.assertIn("Future generated surfaces", content)
        self.assertIn("skills/index.json", content)
        self.assertIn("npx skills add xdsjs/invest-llm-wiki", content)
        self.assertIn("scripts/sync/", content)
        self.assertIn("scripts/verify/", content)
        self.assertIn("pyproject.toml", content)
        self.assertIn("src/invest_wiki_runtime/", content)
        self.assertIn("invest-wiki-runtime", content)
        self.assert_runtime_package_positioning(content)
        self.assertIn("examples/minimal-company-wiki/", content)
        self.assertIn("contract-focused scaffolding", content)
        self.assertNotIn("scripts/" "install/", content)
        self.assertNotIn("until the example wiki task lands", content)
        self.assertIn("skills/` is the only canonical source", content)


if __name__ == "__main__":
    unittest.main()
