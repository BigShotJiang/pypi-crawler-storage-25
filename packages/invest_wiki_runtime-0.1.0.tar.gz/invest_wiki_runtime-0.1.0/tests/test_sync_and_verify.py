from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]
SYNC_SCRIPT = REPO_ROOT / "scripts" / "sync" / "sync_surfaces.py"
VERIFY_SCRIPT = REPO_ROOT / "scripts" / "verify" / "verify_repo.py"
ADAPTER_INDEXES = [
    ".claude/skills/index.json",
    ".codex/skills/index.json",
    "openclaw/skills/index.json",
]


def canonical_skills() -> list[str]:
    return sorted(
        path.name
        for path in (REPO_ROOT / "skills").iterdir()
        if path.is_dir() and (path / "SKILL.md").is_file()
    )


class SyncAndVerifyTests(unittest.TestCase):
    def test_sync_writes_adapter_indexes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_home:
            env = dict(os.environ)
            env["HOME"] = tmp_home
            completed = subprocess.run(
                [sys.executable, str(SYNC_SCRIPT)],
                cwd=REPO_ROOT,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertIn("synced adapter indexes for 8 skills", completed.stdout)

        expected = canonical_skills()
        for rel in ADAPTER_INDEXES:
            with self.subTest(rel=rel):
                index_path = REPO_ROOT / rel
                self.assertTrue(index_path.is_file(), rel)
                payload = json.loads(index_path.read_text(encoding="utf-8"))
                self.assertEqual(payload["skills"], expected)
                self.assertEqual(payload["generated_from"], "skills/")

    def test_verify_repo_succeeds(self) -> None:
        subprocess.run([sys.executable, str(SYNC_SCRIPT)], cwd=REPO_ROOT, check=True, text=True)
        self.assertTrue((REPO_ROOT / "pyproject.toml").is_file())
        self.assertTrue((REPO_ROOT / "src" / "invest_wiki_runtime" / "__main__.py").is_file())
        completed = subprocess.run(
            [sys.executable, str(VERIFY_SCRIPT)],
            cwd=REPO_ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("verification passed", completed.stdout)

    def test_verify_repo_contract_includes_runtime_package(self) -> None:
        content = VERIFY_SCRIPT.read_text(encoding="utf-8")
        self.assertIn("pyproject.toml", content)
        self.assertIn("src/invest_wiki_runtime/__main__.py", content)

    def test_sync_and_verify_expect_canonical_skill_count(self) -> None:
        skills = canonical_skills()
        self.assertEqual(len(skills), 8)
        self.assertEqual(
            skills,
            [
                "invest-wiki-article",
                "invest-wiki-dossier",
                "invest-wiki-ingest",
                "invest-wiki-lint",
                "invest-wiki-query",
                "invest-wiki-right-business",
                "invest-wiki-right-people",
                "invest-wiki-right-price",
            ],
        )


if __name__ == "__main__":
    unittest.main()
