from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]
CLI = REPO_ROOT / "scripts" / "invest_wiki_cli.py"


class ArticleRuntimeTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["INVEST_WIKI_DISABLE_NETWORK"] = "1"
        env["INVEST_WIKI_FIXTURE_PROVIDERS"] = "1"
        env["INVEST_WIKI_OUTPUT"] = "json"
        return subprocess.run(
            [sys.executable, str(CLI), *args],
            cwd=REPO_ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_article_prepare_initializes_article_and_sidecars(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            completed = self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            company = Path(tmpdir) / "companies" / "DEMO"
            self.assertTrue((company / "wiki-article.md").is_file())
            self.assertTrue((company / "wiki-refs.json").is_file())
            self.assertTrue((company / "wiki-claims.jsonl").is_file())

    def test_article_validate_catches_unknown_ref(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            company = Path(tmpdir) / "companies" / "DEMO"
            (company / "wiki-article.md").write_text(
                "# DEMO\n\n## 公司概览\n\nParagraph [ref:missing-ref]\n",
                encoding="utf-8",
            )
            completed = self.run_cli("article", "validate", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "unknown_ref_id")
            self.assertEqual(payload["details"]["unknown_ref_ids"], ["missing-ref"])

    def test_article_validate_requires_real_overview_heading(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            company = Path(tmpdir) / "companies" / "DEMO"
            (company / "wiki-article.md").write_text(
                "# DEMO\n\n正文仅提到 ## 公司概览，但这里不是标题。\n",
                encoding="utf-8",
            )
            completed = self.run_cli("article", "validate", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "missing_overview")

    def test_article_validate_rejects_duplicate_ref_id(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            company = Path(tmpdir) / "companies" / "DEMO"
            (company / "wiki-article.md").write_text(
                "# DEMO\n\n## 公司概览\n\nParagraph [ref:dup-ref]\n",
                encoding="utf-8",
            )
            (company / "wiki-refs.json").write_text(
                json.dumps(
                    [
                        {"ref_id": "dup-ref", "title": "A"},
                        {"ref_id": "dup-ref", "title": "B"},
                    ],
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )
            completed = self.run_cli("article", "validate", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "duplicate_ref_id")
            self.assertEqual(payload["details"]["duplicate_ref_ids"], ["dup-ref"])

    def test_article_prepare_symlink_escape_returns_json_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            company = Path(tmpdir) / "companies" / "DEMO"
            article_path = company / "wiki-article.md"
            outside_path = Path(external_dir) / "outside-article.md"
            outside_path.write_text("outside baseline\n", encoding="utf-8")
            article_path.unlink()
            try:
                os.symlink(outside_path, article_path)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)
            self.assertEqual(outside_path.read_text(encoding="utf-8"), "outside baseline\n")

    def test_article_prepare_rejects_symlinked_parent_company_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            company = Path(tmpdir) / "companies" / "DEMO"
            shutil.rmtree(company)
            external_company = Path(external_dir) / "DEMO"
            external_company.mkdir(parents=True, exist_ok=True)
            try:
                os.symlink(external_company, company)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli("article", "prepare", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)
            self.assertFalse((external_company / "wiki-article.md").exists())
            self.assertFalse((external_company / "wiki-refs.json").exists())
            self.assertFalse((external_company / "wiki-claims.jsonl").exists())

    def test_article_validate_rejects_symlinked_parent_company_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            company = Path(tmpdir) / "companies" / "DEMO"
            shutil.rmtree(company)
            external_company = Path(external_dir) / "DEMO"
            external_company.mkdir(parents=True, exist_ok=True)
            (external_company / "wiki-article.md").write_text("# outside\n", encoding="utf-8")
            (external_company / "wiki-refs.json").write_text("[]\n", encoding="utf-8")
            (external_company / "wiki-claims.jsonl").write_text("", encoding="utf-8")
            try:
                os.symlink(external_company, company)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli("article", "validate", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)


if __name__ == "__main__":
    unittest.main()
