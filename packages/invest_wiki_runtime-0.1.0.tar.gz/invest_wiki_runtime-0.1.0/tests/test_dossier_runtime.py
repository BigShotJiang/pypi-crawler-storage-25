from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest import mock


REPO_ROOT = Path(__file__).resolve().parents[1]
CLI = REPO_ROOT / "scripts" / "invest_wiki_cli.py"


class DossierRuntimeTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["INVEST_WIKI_DISABLE_NETWORK"] = "1"
        env["INVEST_WIKI_FIXTURE_PROVIDERS"] = "1"
        env["INVEST_WIKI_OUTPUT"] = "json"
        return subprocess.run(
            [sys.executable, str(CLI), *args],
            cwd=REPO_ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_dossier_run_materializes_seed_workspace(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "demo")

            self.assertEqual(completed.returncode, 0, completed.stderr)

            payload = json.loads(completed.stdout)
            self.assertEqual(payload["status"], "ok")
            self.assertEqual(payload["module"], "dossier")
            self.assertEqual(payload["ticker"], "DEMO")
            self.assertTrue(payload["run_id"])
            self.assertEqual(
                payload["payload"]["actions_run"],
                ["inspect", "discover", "materialize", "render", "validate"],
            )
            self.assertEqual(payload["payload"]["actions_skipped"], ["enrich"])
            self.assertIn("coverage_score", payload["payload"]["summary"])

            company_root = Path(tmpdir) / "companies" / "DEMO"
            self.assertTrue((company_root / "dossier" / "wiki" / "sources").is_dir())
            self.assertTrue((company_root / "dossier" / "wiki" / "events").is_dir())
            self.assertTrue((company_root / "dossier" / "wiki" / "rollups").is_dir())
            self.assertTrue((company_root / "dossier" / "wiki" / "queries").is_dir())
            self.assertTrue((company_root / "basic.json").is_file())
            self.assertTrue((company_root / "calendar.json").is_file())
            self.assertTrue((company_root / "dossier" / "index.md").is_file())
            self.assertTrue((company_root / "dossier" / "log.md").is_file())
            self.assertTrue((company_root / "dossier" / "archive.json").is_file())
            self.assertTrue((company_root / "dossier" / "source_registry.json").is_file())
            self.assertTrue((company_root / "dossier" / "dossier.md").is_file())
            self.assertTrue((company_root / "dossier" / "raw").is_dir())

            basic = json.loads((company_root / "basic.json").read_text(encoding="utf-8"))
            self.assertEqual(
                set(basic),
                {"ticker", "company_name", "market", "summary", "last_verified_at"},
            )
            self.assertEqual(basic["ticker"], "DEMO")

            calendar = json.loads((company_root / "calendar.json").read_text(encoding="utf-8"))
            self.assertEqual(
                set(calendar),
                {"company_events", "external_watchpoints", "last_verified_at"},
            )
            self.assertEqual(calendar["company_events"], [])
            self.assertEqual(calendar["external_watchpoints"], [])

            index_md = (company_root / "dossier" / "index.md").read_text(encoding="utf-8")
            self.assertIn("dossier/wiki/", index_md)

    def test_dossier_run_materializes_fixture_sources_into_raw_and_wiki_pages(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(completed.returncode, 0, completed.stderr)

            company_root = Path(tmpdir) / "companies" / "DEMO"
            dossier_root = company_root / "dossier"
            archive = json.loads((dossier_root / "archive.json").read_text(encoding="utf-8"))
            registry = json.loads((dossier_root / "source_registry.json").read_text(encoding="utf-8"))

            self.assertTrue(archive["sources"])
            materialized_source = next(
                source for source in archive["sources"] if source["slot_id"] == "official.company_homepage"
            )
            self.assertEqual(materialized_source["materialization_status"], "materialized")
            self.assertIn("raw/", materialized_source["materialized_paths"][0])
            self.assertTrue((dossier_root / materialized_source["materialized_paths"][0]).is_file())
            self.assertTrue((dossier_root / "wiki" / "sources" / "official-company-homepage.md").is_file())
            self.assertTrue((dossier_root / "wiki" / "events" / "latest-earnings-event-bundle.md").is_file())

            homepage_slot = next(slot for slot in registry["slots"] if slot["slot_id"] == "official.company_homepage")
            self.assertEqual(homepage_slot["status"], "materialized")
            self.assertGreaterEqual(homepage_slot["materialized_count"], 1)
            self.assertTrue(homepage_slot["materializations"])

            self.assertEqual(registry["summary"]["hard_blocking_missing"], 0)
            self.assertGreater(registry["summary"]["coverage_score"], 0)

    def test_dossier_log_appends_structured_event_and_rerenders_markdown(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")

            payload_path = Path(tmpdir) / "event.json"
            payload_path.write_text(
                json.dumps(
                    {
                        "event_type": "ingest_recorded",
                        "run_id": "run-1",
                        "summary": "created source shell",
                        "paths": ["dossier/wiki/sources/demo.md"],
                    }
                ),
                encoding="utf-8",
            )

            completed = self.run_cli(
                "dossier",
                "log",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--payload-file",
                str(payload_path),
            )

            self.assertEqual(completed.returncode, 0, completed.stderr)

            payload = json.loads(completed.stdout)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["skill"], "dossier")
            self.assertEqual(payload["action"], "log")

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            log_jsonl = (dossier_root / "log.jsonl").read_text(encoding="utf-8").strip().splitlines()
            self.assertEqual(len(log_jsonl), 1)
            event = json.loads(log_jsonl[0])
            self.assertEqual(event["event_type"], "ingest_recorded")
            self.assertEqual(event["run_id"], "run-1")
            self.assertEqual(event["summary"], "created source shell")
            self.assertEqual(event["paths"], ["dossier/wiki/sources/demo.md"])
            self.assertNotEqual(event["ts"], "1970-01-01T00:00:00Z")
            datetime.fromisoformat(event["ts"].replace("Z", "+00:00"))

            log_md = (dossier_root / "log.md").read_text(encoding="utf-8")
            self.assertIn("created source shell", log_md)
            self.assertIn("ingest_recorded", log_md)
            self.assertIn("dossier/wiki/sources/demo.md", log_md)

    def test_dossier_run_preserves_existing_log_events_on_rerun(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            first_run = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(first_run.returncode, 0, first_run.stderr)

            payload_path = Path(tmpdir) / "event.json"
            payload_path.write_text(
                json.dumps(
                    {
                        "event_type": "ingest_recorded",
                        "run_id": "run-1",
                        "summary": "created source shell",
                        "paths": ["dossier/wiki/sources/demo.md"],
                    }
                ),
                encoding="utf-8",
            )
            self.run_cli(
                "dossier",
                "log",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--payload-file",
                str(payload_path),
            )
            second_run = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(second_run.returncode, 0, second_run.stderr)
            second_payload = json.loads(second_run.stdout)
            self.assertEqual(second_payload["status"], "ok")
            self.assertEqual(second_payload["payload"]["actions_run"], ["inspect", "render", "validate"])
            self.assertEqual(
                second_payload["payload"]["actions_skipped"],
                ["discover", "materialize", "enrich"],
            )

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            log_jsonl = (dossier_root / "log.jsonl").read_text(encoding="utf-8").strip().splitlines()
            self.assertEqual(len(log_jsonl), 1)
            event = json.loads(log_jsonl[0])
            self.assertEqual(event["summary"], "created source shell")

    def test_dossier_run_rerenders_when_canonical_truth_changes(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            first_run = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(first_run.returncode, 0, first_run.stderr)

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            overview_path = dossier_root / "dossier.md"
            archive_path = dossier_root / "archive.json"

            original_overview = overview_path.read_text(encoding="utf-8")
            archive = json.loads(archive_path.read_text(encoding="utf-8"))
            archive["company"]["company_name"] = "Demo Holdings Rerendered"
            archive_path.write_text(json.dumps(archive, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            second_run = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(second_run.returncode, 0, second_run.stderr)

            payload = json.loads(second_run.stdout)
            self.assertEqual(payload["status"], "ok")
            self.assertIn("render", payload["payload"]["actions_run"])
            self.assertNotIn("render", payload["payload"]["actions_skipped"])

            updated_overview = overview_path.read_text(encoding="utf-8")
            self.assertIn("Demo Holdings Rerendered", updated_overview)
            self.assertNotEqual(updated_overview, original_overview)

    def test_dossier_log_before_bootstrap_returns_json_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            payload_path = Path(tmpdir) / "event.json"
            payload_path.write_text(
                json.dumps(
                    {
                        "event_type": "ingest_recorded",
                        "run_id": "run-1",
                        "summary": "created source shell",
                        "paths": ["dossier/wiki/sources/demo.md"],
                    }
                ),
                encoding="utf-8",
            )
            completed = self.run_cli(
                "dossier",
                "log",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--payload-file",
                str(payload_path),
            )
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)
            company_root = Path(tmpdir) / "companies" / "DEMO"
            self.assertFalse((company_root / "dossier" / "log.md").exists())
            self.assertFalse((company_root / "dossier" / "log.jsonl").exists())

    def test_dossier_log_missing_payload_file_returns_json_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            completed = self.run_cli("dossier", "log", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)

    def test_dossier_log_rejects_non_object_payload_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            payload_path = Path(tmpdir) / "bad.json"
            payload_path.write_text("[]", encoding="utf-8")
            completed = self.run_cli(
                "dossier",
                "log",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--payload-file",
                str(payload_path),
            )
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)

    def test_dossier_inspect_reports_suggested_actions_for_empty_workspace(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "inspect", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["action"], "inspect")
            self.assertEqual(
                payload["summary"]["suggested_actions"],
                ["discover", "materialize", "render", "validate"],
            )

    def test_dossier_discover_creates_registry_via_direct_action(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "discover", "--root", tmpdir, "--ticker", "DEMO")

            self.assertEqual(completed.returncode, 0, completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["action"], "discover")
            self.assertEqual(payload["ticker"], "DEMO")
            self.assertEqual(payload["summary"]["market"], "us")
            self.assertIn("companies/DEMO/dossier/source_registry.json", payload["changed"])
            self.assertIn("companies/DEMO/dossier/archive.json", payload["changed"])
            self.assertTrue(
                (Path(tmpdir) / "companies" / "DEMO" / "dossier" / "source_registry.json").is_file()
            )
            self.assertTrue(
                (Path(tmpdir) / "companies" / "DEMO" / "dossier" / "archive.json").is_file()
            )

    def test_dossier_materialize_direct_action_is_idempotent_for_canonical_writes(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            first = self.run_cli("dossier", "materialize", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(first.returncode, 0, first.stderr)
            first_payload = json.loads(first.stdout)
            self.assertTrue(first_payload["ok"])
            self.assertEqual(first_payload["action"], "materialize")
            self.assertIn("companies/DEMO/dossier/archive.json", first_payload["changed"])
            self.assertIn("companies/DEMO/dossier/source_registry.json", first_payload["changed"])

            second = self.run_cli("dossier", "materialize", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(second.returncode, 0, second.stderr)
            second_payload = json.loads(second.stdout)
            self.assertTrue(second_payload["ok"])
            self.assertEqual(second_payload["action"], "materialize")
            self.assertEqual(second_payload["changed"], [])

    def test_dossier_materialize_preserves_discover_seed_archive_truth(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            discover = self.run_cli("dossier", "discover", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(discover.returncode, 0, discover.stderr)

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            archive_path = dossier_root / "archive.json"
            archive = json.loads(archive_path.read_text(encoding="utf-8"))
            archive["company"]["company_name"] = "Demo Holdings"
            archive["config_snapshot"]["seed_source"] = "provider-discover"
            archive["market_data"]["currency"] = "USD"
            archive["sources"] = [
                {
                    "source_id": "official.company_homepage::demo",
                    "slot_id": "official.company_homepage",
                    "source_type": "website",
                    "title": "Demo Homepage",
                    "url": "https://example.com",
                    "publisher": "Demo",
                    "discovered_at": "2026-04-14T00:00:00Z",
                    "published_at": None,
                    "notes": None,
                    "materialization_status": "pending",
                    "materialized_paths": [],
                }
            ]
            archive_path.write_text(json.dumps(archive, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            materialize = self.run_cli("dossier", "materialize", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(materialize.returncode, 0, materialize.stderr)

            materialized_archive = json.loads(archive_path.read_text(encoding="utf-8"))
            self.assertEqual(materialized_archive["company"]["company_name"], "Demo Holdings")
            self.assertEqual(materialized_archive["config_snapshot"]["seed_source"], "provider-discover")
            self.assertEqual(materialized_archive["market_data"]["currency"], "USD")
            self.assertEqual(len(materialized_archive["sources"]), 1)
            self.assertEqual(
                materialized_archive["sources"][0]["source_id"],
                "official.company_homepage::demo",
            )

    def test_dossier_materialize_preserves_mapping_shaped_archive_source(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            discover = self.run_cli("dossier", "discover", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(discover.returncode, 0, discover.stderr)

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            archive_path = dossier_root / "archive.json"
            archive = json.loads(archive_path.read_text(encoding="utf-8"))
            archive["sources"] = {
                "source_id": "official.company_homepage::demo",
                "slot_id": "official.company_homepage",
                "source_type": "website",
                "title": "Demo Homepage",
                "url": "https://example.com",
                "publisher": "Demo",
                "discovered_at": "2026-04-14T00:00:00Z",
                "published_at": None,
                "notes": None,
                "materialization_status": "pending",
                "materialized_paths": [],
            }
            archive_path.write_text(json.dumps(archive, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            materialize = self.run_cli("dossier", "materialize", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(materialize.returncode, 0, materialize.stderr)

            materialized_archive = json.loads(archive_path.read_text(encoding="utf-8"))
            self.assertIsInstance(materialized_archive["sources"], dict)
            self.assertEqual(
                materialized_archive["sources"]["source_id"],
                "official.company_homepage::demo",
            )

    def test_dossier_materialize_uses_sec_user_agent_for_sec_archive_pages(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            from invest_wiki_runtime.runtime.dossier.source_materializer import materialize_archive_sources
            from invest_wiki_runtime.runtime.dossier.workspace import dossier_paths

            root = Path(tmpdir)
            paths = dossier_paths(root, "DEMO")
            for key in ("dossier", "raw", "wiki_sources", "wiki_events"):
                paths[key].mkdir(parents=True, exist_ok=True)

            source = {
                "source_id": "regulatory.annual_report_latest::0000016918-25-000022",
                "slot_id": "regulatory.annual_report_latest",
                "source_type": "filing",
                "title": "10-K",
                "url": "https://www.sec.gov/Archives/edgar/data/16918/000001691825000022/stz-20250228.htm",
                "publisher": "sec_edgar",
                "discovered_at": "2026-04-14T00:00:00Z",
                "published_at": "2025-04-23",
                "notes": "10-K",
            }

            class FakeResponse:
                def __init__(self, text: str, status_code: int) -> None:
                    self.text = text
                    self.content = text.encode("utf-8")
                    self.status_code = status_code
                    self.encoding = None
                    self.apparent_encoding = "utf-8"
                    self.headers = {"content-type": "text/html; charset=utf-8"}

                def raise_for_status(self) -> None:
                    if self.status_code >= 400:
                        raise RuntimeError(f"http {self.status_code}")

            def fake_get(
                url: str,
                *,
                timeout: int,
                headers: dict[str, str] | None = None,
                allow_redirects: bool | None = None,
            ) -> FakeResponse:
                self.assertEqual(
                    url,
                    "https://www.sec.gov/Archives/edgar/data/16918/000001691825000022/stz-20250228.htm",
                )
                self.assertEqual(timeout, 30)
                if (headers or {}).get("User-Agent") == "ResearchBot/1.0 (research@example.com)":
                    return FakeResponse("<html><body>SEC content</body></html>", 200)
                return FakeResponse("forbidden", 403)

            with mock.patch.dict(
                os.environ,
                {"INVEST_WIKI_DISABLE_NETWORK": "", "INVEST_WIKI_FIXTURE_PROVIDERS": ""},
                clear=False,
            ):
                converter = mock.MagicMock()
                converter.convert_uri.return_value = mock.MagicMock(markdown="# 10-K\n\nSEC content")
                with mock.patch(
                    "invest_wiki_runtime.runtime.dossier.materialization.materializers.requests.get",
                    side_effect=fake_get,
                ), mock.patch(
                    "invest_wiki_runtime.runtime.dossier.materialization.materializers.MarkItDown",
                    return_value=converter,
                ):
                    materialized_sources, changed = materialize_archive_sources(
                        root_path=root,
                        paths=paths,
                        archive_sources=[source],
                    )

            self.assertTrue(changed)
            raw_rel = materialized_sources[0]["materialized_paths"][0]
            raw_content = (paths["dossier"] / raw_rel).read_text(encoding="utf-8")
            self.assertIn("SEC content", raw_content)
            self.assertNotIn("Structured source materialization placeholder.", raw_content)
            self.assertEqual(
                raw_rel,
                "raw/regulatory/10-k/regulatory-annual-report-latest-0000016918-25-000022.md",
            )

    def test_dossier_materialize_writes_materialization_report_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            from invest_wiki_runtime.runtime.dossier.materialize import materialize_dossier

            root = Path(tmpdir)
            dossier_root = root / "companies" / "DEMO" / "dossier"
            dossier_root.mkdir(parents=True, exist_ok=True)
            archive_path = dossier_root / "archive.json"
            archive_path.write_text(
                json.dumps(
                    {
                        "version": "1.0.0",
                        "company": {"ticker": "DEMO", "company_name": "Demo Holdings", "market": "us"},
                        "run_info": {},
                        "config_snapshot": {},
                        "identity": {},
                        "financials": {},
                        "market_data": {},
                        "people": {},
                        "estimates": {},
                        "text_extracts": {},
                        "earnings_calendar": None,
                        "call_records": [],
                        "filings": [],
                        "sources": [
                            {
                                "source_id": "official-company-homepage",
                                "slot_id": "official.company_homepage",
                                "source_type": "official_web",
                                "title": "Demo homepage",
                                "url": "https://example.com",
                                "publisher": "company",
                                "discovered_at": "2026-04-14T00:00:00Z",
                                "materialization_status": "pending",
                                "materialized_paths": [],
                            }
                        ],
                    },
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )

            converter = mock.MagicMock()
            converter.convert_uri.return_value = mock.MagicMock(markdown="# Demo homepage\n\nconverted")
            with mock.patch(
                "invest_wiki_runtime.runtime.dossier.materialization.materializers.MarkItDown",
                return_value=converter,
            ):
                result = materialize_dossier(root, "DEMO", "us")

            self.assertIn("companies/DEMO/dossier/materialization-report.md", result["artifacts"])
            self.assertIn("companies/DEMO/dossier/materialization-report.json", result["artifacts"])
            report_json = json.loads((dossier_root / "materialization-report.json").read_text(encoding="utf-8"))
            report_md = (dossier_root / "materialization-report.md").read_text(encoding="utf-8")
            self.assertEqual(report_json["summary"]["discovered_total"], 1)
            self.assertEqual(report_json["summary"]["materialized_success"], 1)
            self.assertIn("materialized_success: 1", report_md)
            self.assertIn("company-homepage", report_md)

    def test_dossier_materialize_stage_writes_and_keeps_outputs_and_updates_registry(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            discover = self.run_cli("dossier", "discover", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(discover.returncode, 0, discover.stderr)

            from invest_wiki_runtime.runtime.dossier.materialize import materialize_dossier

            root = Path(tmpdir)
            first_result = materialize_dossier(root, "DEMO", "us")
            self.assertIn("companies/DEMO/basic.json", first_result["changed"])
            self.assertIn("companies/DEMO/calendar.json", first_result["changed"])
            self.assertIn("companies/DEMO/dossier/archive.json", first_result["artifacts"])
            self.assertIn("companies/DEMO/dossier/source_registry.json", first_result["artifacts"])
            self.assertIn("companies/DEMO/dossier/raw", first_result["artifacts"])
            self.assertIn("companies/DEMO/dossier/wiki/sources", first_result["artifacts"])
            self.assertIn("companies/DEMO/dossier/wiki/events", first_result["artifacts"])
            self.assertIn("companies/DEMO/dossier/wiki/rollups", first_result["artifacts"])
            self.assertIn("companies/DEMO/dossier/wiki/queries", first_result["artifacts"])

            dossier_root = root / "companies" / "DEMO" / "dossier"
            self.assertTrue((dossier_root / "raw").is_dir())
            self.assertTrue((dossier_root / "wiki" / "sources").is_dir())
            self.assertTrue((dossier_root / "wiki" / "events").is_dir())
            self.assertTrue((dossier_root / "wiki" / "rollups").is_dir())
            self.assertTrue((dossier_root / "wiki" / "queries").is_dir())

            registry = json.loads((dossier_root / "source_registry.json").read_text(encoding="utf-8"))
            self.assertEqual(registry["summary"]["hard_blocking_missing"], 0)
            self.assertEqual(registry["summary"]["coverage_score"], 75)
            self.assertTrue(registry["slots"])
            for slot in registry["slots"]:
                if slot["slot_id"] in {
                    "official.company_homepage",
                    "official.ir_homepage_or_newsroom",
                    "regulatory.annual_report_latest",
                    "regulatory.periodic_reports_recent",
                    "regulatory.material_events_recent",
                    "events.earnings_calendar_or_results_date",
                    "events.latest_earnings_event_bundle",
                    "governance.proxy_or_annual_meeting_materials",
                    "regulatory.ownership_or_insider_context",
                }:
                    self.assertEqual(slot["freshness_status"], "current")
                    self.assertTrue(slot["sources"])
                    self.assertGreaterEqual(slot["materialized_count"], 1)
                else:
                    self.assertEqual(slot["status"], "planned")
                    self.assertEqual(slot["found_count"], 0)
                    self.assertEqual(slot["materialized_count"], 0)
                    self.assertEqual(slot["freshness_status"], "unknown")
                    self.assertEqual(slot["sources"], [])
                    self.assertEqual(slot["materializations"], [])

            second_result = materialize_dossier(root, "DEMO", "us")
            self.assertEqual(second_result["changed"], [])
            self.assertTrue((dossier_root / "raw").is_dir())
            self.assertTrue((dossier_root / "wiki" / "sources").is_dir())
            self.assertTrue((dossier_root / "wiki" / "events").is_dir())
            self.assertTrue((dossier_root / "wiki" / "rollups").is_dir())
            self.assertTrue((dossier_root / "wiki" / "queries").is_dir())

    def test_dossier_materialize_stage_keeps_empty_basic_company_name_from_null(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            company_root = root / "companies" / "NVDA"
            company_root.mkdir(parents=True, exist_ok=True)
            (company_root / "basic.json").write_text(
                json.dumps(
                    {
                        "ticker": "NVDA",
                        "company_name": None,
                        "market": None,
                        "summary": None,
                        "last_verified_at": None,
                    },
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )

            from invest_wiki_runtime.runtime.dossier.materialize import materialize_dossier

            result = materialize_dossier(root, "NVDA", "us")
            self.assertIn("companies/NVDA/basic.json", result["changed"])

            basic = json.loads((company_root / "basic.json").read_text(encoding="utf-8"))
            archive = json.loads((company_root / "dossier" / "archive.json").read_text(encoding="utf-8"))

            self.assertEqual(basic["company_name"], "")
            self.assertEqual(basic["summary"], "")
            self.assertEqual(basic["last_verified_at"], "")
            self.assertEqual(basic["market"], "us")
            self.assertEqual(archive["company"]["company_name"], "NVDA")
            self.assertEqual(archive["company"]["market"], "us")

    def test_dossier_run_materializes_after_discover_when_scaffolding_is_still_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            discover = self.run_cli("dossier", "discover", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(discover.returncode, 0, discover.stderr)

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            registry_path = dossier_root / "source_registry.json"
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
            for slot in registry["slots"]:
                slot["status"] = "materialized"
                slot["found_count"] = max(int(slot.get("expected_min", 1) or 1), 1)
                slot["materialized_count"] = max(int(slot.get("expected_min", 1) or 1), 1)
                slot["freshness_status"] = "current"
                slot["gap_reason"] = ""
                if not slot.get("sources"):
                    slot["sources"] = ["canonical://archive.json"]
                if not slot.get("materializations"):
                    slot["materializations"] = ["dossier/dossier.md"]
            registry_path.write_text(json.dumps(registry, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(completed.returncode, 0, completed.stderr)

            payload = json.loads(completed.stdout)
            self.assertEqual(payload["status"], "ok")
            self.assertIn("materialize", payload["payload"]["actions_run"])
            self.assertFalse(payload["payload"]["actions_skipped"] == ["materialize"])

            company_root = Path(tmpdir) / "companies" / "DEMO"
            self.assertTrue((company_root / "basic.json").is_file())
            self.assertTrue((company_root / "calendar.json").is_file())
            self.assertTrue((company_root / "dossier" / "raw").is_dir())
            self.assertTrue((company_root / "dossier" / "wiki" / "sources").is_dir())
            self.assertTrue((company_root / "dossier" / "wiki" / "events").is_dir())
            self.assertTrue((company_root / "dossier" / "wiki" / "rollups").is_dir())
            self.assertTrue((company_root / "dossier" / "wiki" / "queries").is_dir())

    def test_dossier_render_direct_action_is_idempotent_for_markdown_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bootstrap = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(bootstrap.returncode, 0, bootstrap.stderr)

            first = self.run_cli("dossier", "render", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(first.returncode, 0, first.stderr)
            first_payload = json.loads(first.stdout)
            self.assertTrue(first_payload["ok"])
            self.assertEqual(first_payload["action"], "render")
            self.assertEqual(first_payload["changed"], [])

            second = self.run_cli("dossier", "render", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(second.returncode, 0, second.stderr)
            second_payload = json.loads(second.stdout)
            self.assertTrue(second_payload["ok"])
            self.assertEqual(second_payload["action"], "render")
            self.assertEqual(second_payload["changed"], [])

    def test_dossier_render_writes_overview_index_and_log_from_canonical_truth(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bootstrap = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(bootstrap.returncode, 0, bootstrap.stderr)

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            archive_path = dossier_root / "archive.json"
            registry_path = dossier_root / "source_registry.json"
            log_jsonl_path = dossier_root / "log.jsonl"

            archive = json.loads(archive_path.read_text(encoding="utf-8"))
            archive["company"]["company_name"] = "Demo Holdings"
            archive_path.write_text(json.dumps(archive, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            registry = json.loads(registry_path.read_text(encoding="utf-8"))
            for slot in registry["slots"][:2]:
                slot["status"] = "planned"
                slot["found_count"] = 0
                slot["materialized_count"] = 0
                slot["freshness_status"] = "unknown"
                slot["gap_reason"] = "not discovered"
                slot["sources"] = []
                slot["materializations"] = []
            registry_path.write_text(json.dumps(registry, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            log_jsonl_path.write_text(
                json.dumps(
                    {
                        "event_no": 1,
                        "event_type": "render_requested",
                        "run_id": "run-render",
                        "summary": "canonical truth changed",
                        "paths": ["companies/DEMO/dossier/archive.json"],
                        "ts": "2026-04-14T00:00:00Z",
                    },
                    ensure_ascii=False,
                )
                + "\n",
                encoding="utf-8",
            )

            first = self.run_cli("dossier", "render", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(first.returncode, 0, first.stderr)
            first_payload = json.loads(first.stdout)
            self.assertTrue(first_payload["ok"])
            self.assertEqual(first_payload["action"], "render")
            self.assertEqual(
                set(first_payload["changed"]),
                {
                    "companies/DEMO/dossier/dossier.md",
                    "companies/DEMO/dossier/index.md",
                    "companies/DEMO/dossier/log.md",
                },
            )

            overview = (dossier_root / "dossier.md").read_text(encoding="utf-8")
            self.assertIn("# Dossier", overview)
            self.assertIn("Demo Holdings", overview)
            self.assertIn("- coverage_score: 58", overview)
            self.assertIn("- hard_blocking_missing: 2", overview)

            index_md = (dossier_root / "index.md").read_text(encoding="utf-8")
            self.assertIn("# Dossier Index", index_md)
            self.assertIn("Demo Holdings", index_md)
            self.assertIn("`dossier.md`", index_md)
            self.assertIn("`log.md`", index_md)

            log_md = (dossier_root / "log.md").read_text(encoding="utf-8")
            self.assertIn("render_requested", log_md)
            self.assertIn("canonical truth changed", log_md)
            self.assertIn("companies/DEMO/dossier/archive.json", log_md)

            second = self.run_cli("dossier", "render", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(second.returncode, 0, second.stderr)
            second_payload = json.loads(second.stdout)
            self.assertTrue(second_payload["ok"])
            self.assertEqual(second_payload["action"], "render")
            self.assertEqual(second_payload["changed"], [])

    def test_dossier_render_counts_mapping_shaped_source_as_one(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bootstrap = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(bootstrap.returncode, 0, bootstrap.stderr)

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            archive_path = dossier_root / "archive.json"
            archive = json.loads(archive_path.read_text(encoding="utf-8"))
            archive["sources"] = {
                "source_id": "official.company_homepage::demo",
                "slot_id": "official.company_homepage",
                "source_type": "website",
                "title": "Demo Homepage",
                "url": "https://example.com",
                "publisher": "Demo",
                "discovered_at": "2026-04-14T00:00:00Z",
                "published_at": None,
                "notes": None,
                "materialization_status": "pending",
                "materialized_paths": [],
            }
            archive_path.write_text(json.dumps(archive, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            completed = self.run_cli("dossier", "render", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(completed.returncode, 0, completed.stderr)

            overview = (dossier_root / "dossier.md").read_text(encoding="utf-8")
            self.assertIn("\n- sources: 1\n", overview)

    def test_dossier_run_returns_structured_summary_payload(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(completed.returncode, 0, completed.stderr)

            payload = json.loads(completed.stdout)
            self.assertEqual(payload["status"], "ok")
            self.assertEqual(payload["module"], "dossier")
            self.assertEqual(payload["ticker"], "DEMO")
            self.assertTrue(payload["run_id"])
            self.assertEqual(payload["error"], "")
            self.assertEqual(payload["payload"]["archive_ticker"], "DEMO")
            self.assertIn("company_name", payload["payload"])
            self.assertIn("actions_run", payload["payload"])
            self.assertIn("actions_skipped", payload["payload"])
            self.assertIn("decision_reason", payload["payload"])
            self.assertIn("artifacts", payload["payload"])
            self.assertIn("summary", payload["payload"])
            self.assertIn("warnings", payload["payload"])
            self.assertIn("coverage_score", payload["payload"]["summary"])

    def test_dossier_validate_returns_invalid_arguments_when_archive_is_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bootstrap = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(bootstrap.returncode, 0, bootstrap.stderr)

            archive_path = Path(tmpdir) / "companies" / "DEMO" / "dossier" / "archive.json"
            archive_path.unlink()

            completed = self.run_cli("dossier", "validate", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertIn("missing dossier artifacts", payload["message"])
            self.assertNotIn("Traceback", completed.stderr)

    def test_dossier_validate_stage_fails_when_source_registry_is_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bootstrap = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(bootstrap.returncode, 0, bootstrap.stderr)

            root = Path(tmpdir)
            registry_path = root / "companies" / "DEMO" / "dossier" / "source_registry.json"
            registry_path.unlink()

            from invest_wiki_runtime.runtime.dossier.validate import validate_dossier

            with self.assertRaisesRegex(ValueError, "source_registry.json"):
                validate_dossier(root, "DEMO", "us")

    def test_dossier_run_rejects_symlinked_parent_company_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            company = Path(tmpdir) / "companies" / "DEMO"
            company.parent.mkdir(parents=True, exist_ok=True)
            external_company = Path(external_dir) / "DEMO"
            external_company.mkdir(parents=True, exist_ok=True)
            try:
                os.symlink(external_company, company)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)
            self.assertFalse((external_company / "basic.json").exists())
            self.assertFalse((external_company / "calendar.json").exists())
            self.assertFalse((external_company / "dossier").exists())

    def test_dossier_log_rejects_symlinked_log_jsonl_escape(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as external_dir:
            bootstrap = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(bootstrap.returncode, 0, bootstrap.stderr)
            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            log_jsonl = dossier_root / "log.jsonl"
            outside_log_jsonl = Path(external_dir) / "outside-log.jsonl"
            outside_log_jsonl.write_text('{"baseline":true}\n', encoding="utf-8")
            log_jsonl.unlink()
            try:
                os.symlink(outside_log_jsonl, log_jsonl)
            except (NotImplementedError, OSError):
                self.skipTest("symlink creation is not supported in this environment")

            payload_path = Path(tmpdir) / "event.json"
            payload_path.write_text(
                json.dumps(
                    {
                        "event_type": "ingest_recorded",
                        "run_id": "run-1",
                        "summary": "created source shell",
                        "paths": ["dossier/wiki/sources/demo.md"],
                    }
                ),
                encoding="utf-8",
            )
            completed = self.run_cli(
                "dossier",
                "log",
                "--root",
                tmpdir,
                "--ticker",
                "DEMO",
                "--payload-file",
                str(payload_path),
            )
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error_code"], "invalid_arguments")
            self.assertNotIn("Traceback", completed.stderr)
            self.assertEqual(outside_log_jsonl.read_text(encoding="utf-8"), '{"baseline":true}\n')

    def test_dossier_run_on_malformed_existing_log_jsonl_returns_json_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bootstrap = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertEqual(bootstrap.returncode, 0, bootstrap.stderr)

            dossier_root = Path(tmpdir) / "companies" / "DEMO" / "dossier"
            (dossier_root / "log.jsonl").write_text("{malformed json\n", encoding="utf-8")
            (dossier_root / "log.md").unlink()

            completed = self.run_cli("dossier", "run", "--root", tmpdir, "--ticker", "DEMO")
            self.assertNotEqual(completed.returncode, 0)
            payload = json.loads(completed.stdout)
            self.assertEqual(payload["status"], "failed")
            self.assertEqual(payload["module"], "dossier")
            self.assertEqual(payload["ticker"], "DEMO")
            self.assertIn("Expecting property name enclosed in double quotes", payload["error"])
            self.assertNotIn("Traceback", completed.stderr)
            self.assertFalse((dossier_root / "log.md").exists())


if __name__ == "__main__":
    unittest.main()
