from __future__ import annotations

import tempfile
import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from invest_wiki_runtime.runtime.dossier.load import (
    load_dossier_archive,
    load_dossier_registry,
    write_dossier_archive,
    write_dossier_registry,
)
from invest_wiki_runtime.runtime.dossier.registry import build_default_registry, compute_registry_summary
from invest_wiki_runtime.runtime.dossier.schemas import (
    validate_dossier_archive,
    validate_dossier_registry,
    validate_dossier_report,
)


class DossierSchemaTests(unittest.TestCase):
    def test_archive_validator_accepts_canonical_minimum_shape(self) -> None:
        archive = validate_dossier_archive(
            {
                "version": "1.0.0",
                "company": {"ticker": "NVDA", "company_name": "NVIDIA", "market": "us"},
                "run_info": {},
                "config_snapshot": {},
                "identity": {},
                "financials": {},
                "market_data": {},
                "people": {},
                "estimates": {},
                "text_extracts": {},
                "earnings_calendar": None,
                "call_records": [],
                "filings": [],
                "sources": [],
            }
        )
        self.assertEqual(archive["company"]["ticker"], "NVDA")

    def test_registry_validator_rejects_missing_summary(self) -> None:
        with self.assertRaises(ValueError):
            validate_dossier_registry(
                {
                    "registry_version": "1.0.0",
                    "template_id": "default",
                    "template_version": "1.0.0",
                    "company": {"ticker": "NVDA", "market": "us"},
                    "slots": [],
                }
            )

    def test_registry_validator_rejects_missing_summary_fields_and_non_list_slots(self) -> None:
        with self.subTest("missing summary fields"):
            with self.assertRaises(ValueError):
                validate_dossier_registry(
                    {
                        "registry_version": "1.0.0",
                        "template_id": "default",
                        "template_version": "1.0.0",
                        "company": {"ticker": "NVDA", "market": "us"},
                        "summary": {"slots_total": 0},
                        "slots": [],
                    }
                )

        with self.subTest("non list slots"):
            with self.assertRaises(ValueError):
                validate_dossier_registry(
                    {
                        "registry_version": "1.0.0",
                        "template_id": "default",
                        "template_version": "1.0.0",
                        "company": {"ticker": "NVDA", "market": "us"},
                        "summary": {
                            "slots_total": 0,
                            "required_total": 0,
                            "hard_blocking_missing": 0,
                            "soft_blocking_missing": 0,
                            "coverage_score": 100,
                        },
                        "slots": {},
                    }
                )

    def test_registry_validator_rejects_blank_template_identity_fields(self) -> None:
        base_registry = {
            "registry_version": "1.0.0",
            "template_id": "default",
            "template_version": "1.0.0",
            "company": {"ticker": "NVDA", "market": "us"},
            "summary": {
                "slots_total": 0,
                "required_total": 0,
                "hard_blocking_missing": 0,
                "soft_blocking_missing": 0,
                "coverage_score": 100,
            },
            "slots": [],
        }

        for key in ("template_id", "template_version"):
            with self.subTest(key=key):
                with self.assertRaises(ValueError):
                    validate_dossier_registry({**base_registry, key: "   "})

    def test_registry_validator_accepts_template_backed_us_registry(self) -> None:
        registry = validate_dossier_registry(build_default_registry("NVDA", "us"))

        self.assertEqual(registry["template_id"], "company-research-v1")
        self.assertEqual(registry["summary"]["slots_total"], 12)
        self.assertGreater(registry["summary"]["hard_blocking_missing"], 1)

    def test_compute_registry_summary_preserves_expected_min_zero_slots_as_satisfied(self) -> None:
        summary = compute_registry_summary(
            [
                {
                    "slot_id": "optional.disabled_slot",
                    "tier": "recommended",
                    "blocking_level": "soft",
                    "expected_min": 0,
                    "found_count": 0,
                    "materialized_count": 0,
                }
            ]
        )

        self.assertEqual(summary["slots_total"], 1)
        self.assertEqual(summary["required_total"], 0)
        self.assertEqual(summary["hard_blocking_missing"], 0)
        self.assertEqual(summary["soft_blocking_missing"], 0)
        self.assertEqual(summary["coverage_score"], 100)

    def test_archive_validator_rejects_non_list_call_records_and_invalid_sources(self) -> None:
        base_archive = {
            "version": "1.0.0",
            "company": {"ticker": "NVDA", "company_name": "NVIDIA", "market": "us"},
            "run_info": {},
            "config_snapshot": {},
            "identity": {},
            "financials": {},
            "market_data": {},
            "people": {},
            "estimates": {},
            "text_extracts": {},
            "earnings_calendar": None,
            "call_records": [],
            "filings": [],
            "sources": [],
        }

        with self.subTest("non list call records"):
            with self.assertRaises(ValueError):
                validate_dossier_archive({**base_archive, "call_records": {}})

        with self.subTest("invalid sources"):
            with self.assertRaises(ValueError):
                validate_dossier_archive({**base_archive, "sources": 1})

    def test_report_validator_requires_error_on_failed_status(self) -> None:
        with self.assertRaises(ValueError):
            validate_dossier_report(
                {
                    "status": "failed",
                    "module": "dossier",
                    "ticker": "NVDA",
                    "run_id": "run-1",
                    "error": "",
                }
            )

    def test_report_validator_rejects_ok_reports_missing_payload_contract_fields(self) -> None:
        with self.assertRaises(ValueError):
            validate_dossier_report(
                {
                    "status": "ok",
                    "module": "dossier",
                    "ticker": "NVDA",
                    "run_id": "run-1",
                    "payload": {
                        "archive_ticker": "NVDA",
                        "company_name": "NVIDIA",
                        "actions_run": ["inspect"],
                    },
                }
            )

    def test_report_validator_rejects_ok_report_payload_with_wrong_field_types(self) -> None:
        with self.assertRaises(ValueError):
            validate_dossier_report(
                {
                    "status": "ok",
                    "module": "dossier",
                    "ticker": "NVDA",
                    "run_id": "run-1",
                    "payload": {
                        "archive_ticker": "NVDA",
                        "company_name": "NVIDIA",
                        "actions_run": "inspect",
                        "actions_skipped": [],
                        "decision_reason": "ready",
                        "artifacts": [],
                        "summary": {
                            "slots_total": 1,
                            "hard_blocking_missing": 0,
                            "soft_blocking_missing": 0,
                            "coverage_score": 100,
                        },
                        "warnings": [],
                    },
                }
            )

    def test_report_validator_rejects_blank_identity_fields(self) -> None:
        base_report = {
            "status": "ok",
            "module": "dossier",
            "ticker": "NVDA",
            "run_id": "run-1",
        }

        for key in ("module", "ticker", "run_id"):
            with self.subTest(key=key):
                with self.assertRaises(ValueError):
                    validate_dossier_report({**base_report, key: "   "})

    def test_dossier_load_round_trip_uses_canonical_json_helpers(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            archive = {
                "version": "1.0.0",
                "company": {"ticker": "NVDA", "company_name": "NVIDIA", "market": "us"},
                "run_info": {},
                "config_snapshot": {},
                "identity": {},
                "financials": {},
                "market_data": {},
                "people": {},
                "estimates": {},
                "text_extracts": {},
                "earnings_calendar": None,
                "call_records": [],
                "filings": [],
                "sources": [],
            }
            registry = {
                "registry_version": "1.0.0",
                "template_id": "default",
                "template_version": "1.0.0",
                "company": {"ticker": "NVDA", "company_name": "NVIDIA", "market": "us"},
                "summary": {
                    "slots_total": 0,
                    "required_total": 0,
                    "hard_blocking_missing": 0,
                    "soft_blocking_missing": 0,
                    "coverage_score": 100,
                },
                "slots": [],
            }

            write_dossier_archive(root, "NVDA", archive)
            write_dossier_registry(root, "NVDA", registry)

            self.assertEqual(load_dossier_archive(root, "nvda")["company"]["ticker"], "NVDA")
            self.assertEqual(load_dossier_registry(root, "NVDA")["summary"]["slots_total"], 0)
            self.assertTrue((root / "companies" / "NVDA" / "dossier" / "archive.json").read_text(encoding="utf-8").endswith("\n"))
