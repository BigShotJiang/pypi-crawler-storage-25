from __future__ import annotations

import os
import tempfile
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from invest_wiki_runtime.runtime.dossier.orchestrator import inspect, run
from invest_wiki_runtime.runtime.dossier.registry import build_default_registry, suggest_actions
from invest_wiki_runtime.runtime.dossier.report import dossier_failed_report, dossier_success_report
from invest_wiki_runtime.runtime.dossier.schemas import validate_dossier_registry, validate_dossier_report


class DossierOrchestratorTests(unittest.TestCase):
    def test_inspect_for_empty_workspace_uses_default_registry_and_full_pipeline_actions(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, patch.dict(
            os.environ,
            {"INVEST_WIKI_DISABLE_NETWORK": "1", "INVEST_WIKI_FIXTURE_PROVIDERS": "1"},
            clear=False,
        ):
            result = inspect(Path(tmpdir), "nvda")

        self.assertEqual(result["ticker"], "NVDA")
        self.assertFalse(result["archive_exists"])
        self.assertFalse(result["overview_exists"])
        self.assertEqual(
            result["suggested_actions"],
            ["discover", "materialize", "render", "validate"],
        )
        self.assertGreater(result["summary"]["hard_blocking_missing"], 1)

    def test_inspect_with_canonical_truth_but_missing_overview_requests_render_then_validate(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, patch.dict(
            os.environ,
            {"INVEST_WIKI_DISABLE_NETWORK": "1", "INVEST_WIKI_FIXTURE_PROVIDERS": "1"},
            clear=False,
        ):
            root = Path(tmpdir)
            run(root, "nvda")
            (root / "companies" / "NVDA" / "dossier" / "dossier.md").unlink()

            result = inspect(root, "nvda")

        self.assertTrue(result["archive_exists"])
        self.assertFalse(result["overview_exists"])
        self.assertEqual(result["suggested_actions"], ["render", "validate"])
        self.assertEqual(result["summary"]["coverage_score"], 75)

    def test_run_executes_minimum_suggested_actions_and_returns_valid_report(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir, patch.dict(
            os.environ,
            {"INVEST_WIKI_DISABLE_NETWORK": "1", "INVEST_WIKI_FIXTURE_PROVIDERS": "1"},
            clear=False,
        ):
            report = run(Path(tmpdir), "nvda")

            self.assertEqual(report["status"], "ok")
            self.assertEqual(report["ticker"], "NVDA")
            self.assertEqual(
                report["payload"]["actions_run"],
                ["inspect", "discover", "materialize", "render", "validate"],
            )
            self.assertEqual(report["payload"]["actions_skipped"], ["enrich"])
            self.assertEqual(
                report["payload"]["decision_reason"],
                "inspect suggested discover -> materialize -> render -> validate",
            )
            self.assertGreaterEqual(len(report["payload"]["artifacts"]), 1)
            self.assertEqual(report["payload"]["summary"]["coverage_score"], 75)
            validate_dossier_report(report)

    def test_default_registry_counts_are_hard_blocking(self) -> None:
        registry = build_default_registry("nvda", "us")
        slot_ids = [slot["slot_id"] for slot in registry["slots"]]

        self.assertEqual(registry["company"]["ticker"], "NVDA")
        self.assertEqual(registry["template_id"], "company-research-v1")
        self.assertEqual(registry["summary"]["slots_total"], 12)
        self.assertEqual(registry["summary"]["required_total"], 7)
        self.assertGreater(registry["summary"]["hard_blocking_missing"], 1)
        self.assertEqual(registry["summary"]["soft_blocking_missing"], 5)
        self.assertEqual(registry["summary"]["coverage_score"], 0)
        self.assertEqual(
            slot_ids,
            [
                "official.company_homepage",
                "official.ir_homepage_or_newsroom",
                "regulatory.annual_report_latest",
                "regulatory.periodic_reports_recent",
                "regulatory.material_events_recent",
                "events.earnings_calendar_or_results_date",
                "events.latest_earnings_event_bundle",
                "governance.proxy_or_annual_meeting_materials",
                "official.investor_presentation_or_factbook",
                "reference.wikipedia_or_equivalent_profile",
                "events.recent_call_history",
                "regulatory.ownership_or_insider_context",
            ],
        )
        self.assertEqual(registry["slots"][0]["tier"], "required")
        self.assertEqual(registry["slots"][0]["blocking_level"], "hard")
        self.assertEqual(registry["slots"][0]["status"], "planned")
        self.assertEqual(registry["slots"][0]["expected_min"], 1)
        self.assertEqual(registry["slots"][0]["found_count"], 0)
        self.assertEqual(registry["slots"][0]["materialized_count"], 0)
        self.assertEqual(registry["slots"][0]["freshness_status"], "unknown")
        self.assertEqual(registry["slots"][0]["sources"], [])
        self.assertEqual(registry["slots"][0]["materializations"], [])
        validate_dossier_registry(build_default_registry("NVDA", "us"))

    def test_suggest_actions_for_empty_registry_asks_for_full_pipeline(self) -> None:
        registry = build_default_registry("NVDA", "us")

        self.assertEqual(
            suggest_actions(registry, archive_exists=False, overview_exists=False),
            ["discover", "materialize", "render", "validate"],
        )
        self.assertEqual(
            suggest_actions(registry, archive_exists=True, overview_exists=False),
            ["discover", "materialize", "render", "validate"],
        )

    def test_us_overrides_extend_periodic_report_hints_without_dropping_base_hint(self) -> None:
        registry = build_default_registry("NVDA", "us")
        slot = next(slot for slot in registry["slots"] if slot["slot_id"] == "regulatory.periodic_reports_recent")

        self.assertEqual(slot["source_hints"][0], "periodic_report")
        self.assertIn("10-K", slot["source_hints"])
        self.assertIn("10-Q", slot["source_hints"])

    def test_failed_report_requires_non_empty_error(self) -> None:
        with self.assertRaises(ValueError):
            dossier_failed_report("NVDA", "run-1", "   ")

        report = dossier_failed_report("NVDA", "run-1", "boom")
        self.assertEqual(report["status"], "failed")
        self.assertEqual(report["module"], "dossier")
        self.assertEqual(report["ticker"], "NVDA")
        self.assertEqual(report["run_id"], "run-1")
        self.assertEqual(report["error"], "boom")
        self.assertEqual(report["payload"]["archive_ticker"], "NVDA")
        self.assertEqual(report["payload"]["actions_run"], [])
        self.assertEqual(report["payload"]["actions_skipped"], [])
        self.assertEqual(report["payload"]["decision_reason"], "")
        self.assertEqual(report["payload"]["artifacts"], [])
        self.assertEqual(report["payload"]["warnings"], [])

    def test_success_report_shape_matches_plan_contract(self) -> None:
        report = dossier_success_report(
            "NVDA",
            "run-1",
            actions_run=["inspect", "render", "validate"],
            actions_skipped=["discover"],
            artifacts=["companies/NVDA/dossier/dossier.md"],
            summary={
                "slots_total": 1,
                "hard_blocking_missing": 0,
                "soft_blocking_missing": 0,
                "coverage_score": 100,
            },
            company_name="NVIDIA",
            warnings=["stale source"],
            decision_reason="truth exists and overview is current",
        )

        self.assertEqual(report["status"], "ok")
        self.assertEqual(report["module"], "dossier")
        self.assertEqual(report["ticker"], "NVDA")
        self.assertEqual(report["run_id"], "run-1")
        self.assertEqual(report["error"], "")
        self.assertEqual(report["payload"]["archive_ticker"], "NVDA")
        self.assertEqual(report["payload"]["company_name"], "NVIDIA")
        self.assertEqual(report["payload"]["actions_run"], ["inspect", "render", "validate"])
        self.assertEqual(report["payload"]["actions_skipped"], ["discover"])
        self.assertEqual(report["payload"]["decision_reason"], "truth exists and overview is current")
        self.assertEqual(report["payload"]["artifacts"], ["companies/NVDA/dossier/dossier.md"])
        self.assertEqual(report["payload"]["summary"]["coverage_score"], 100)
        self.assertEqual(report["payload"]["warnings"], ["stale source"])

    def test_report_validator_rejects_missing_payload_contract_fields(self) -> None:
        with self.assertRaises(ValueError):
            validate_dossier_report(
                {
                    "status": "ok",
                    "module": "dossier",
                    "ticker": "NVDA",
                    "run_id": "run-1",
                    "error": "",
                    "payload": {
                        "archive_ticker": "NVDA",
                        "company_name": "NVIDIA",
                        "actions_run": ["inspect"],
                    },
                }
            )
