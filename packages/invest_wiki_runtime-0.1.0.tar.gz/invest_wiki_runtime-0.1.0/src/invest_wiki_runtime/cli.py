#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from invest_wiki_runtime.runtime import article_sidecars
from invest_wiki_runtime.runtime import cli_brief
from invest_wiki_runtime.runtime import config as runtime_config
from invest_wiki_runtime.runtime import ingest_ops
from invest_wiki_runtime.runtime import lens_contracts
from invest_wiki_runtime.runtime import lint_rules
from invest_wiki_runtime.runtime.dossier import ops as dossier_ops
from invest_wiki_runtime.runtime.dossier import orchestrator as dossier_orchestrator
from invest_wiki_runtime.runtime.dossier.market import normalize_input_ticker
from invest_wiki_runtime.runtime.dossier.workspace import dossier_paths, resolve_market
from invest_wiki_runtime.runtime.paths import company_root
from invest_wiki_runtime.runtime.result_contract import error, ok


SUPPORTED_SKILLS = {
    "dossier",
    "ingest",
    "query",
    "right-business",
    "right-people",
    "right-price",
    "article",
    "lint",
    "config",
}
SUPPORTED_ACTIONS: dict[str, set[str]] = {
    "dossier": {"inspect", "discover", "materialize", "enrich", "render", "validate", "run", "log"},
    "ingest": {"scaffold"},
    "query": {"materialize"},
    "right-business": {"prepare", "validate"},
    "right-people": {"prepare", "validate"},
    "right-price": {"prepare", "validate"},
    "article": {"prepare", "validate"},
    "lint": {"run"},
    "config": {"get-root", "set-root"},
}


def _parse_args(argv: list[str]) -> tuple[argparse.Namespace, list[str]]:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("skill", nargs="?")
    parser.add_argument("action", nargs="?")
    parser.add_argument("--root")
    parser.add_argument("--ticker")
    parser.add_argument("--page-type")
    parser.add_argument("--payload-file")
    parser.add_argument("--write-report", action="store_true")
    try:
        return parser.parse_known_args(argv)
    except SystemExit:
        return (
            argparse.Namespace(
                skill=None,
                action=None,
                root=None,
                ticker=None,
                page_type=None,
                payload_file=None,
                write_report=False,
            ),
            ["__parse_error__"],
        )


def _emit(payload: dict[str, object], exit_code: int) -> int:
    output_mode = str(os.getenv("INVEST_WIKI_OUTPUT", "")).strip().lower()
    if output_mode == "json":
        sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    else:
        sys.stdout.write(cli_brief.render_cli_brief(payload))
    return exit_code


def _relative(root: Path, path: Path) -> str:
    root_resolved = root.resolve()
    path_resolved = path.resolve()
    try:
        return path_resolved.relative_to(root_resolved).as_posix()
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def _assert_within_root(root: Path, path: Path) -> None:
    root_resolved = root.resolve()
    resolved_target = path.resolve(strict=False)
    try:
        resolved_target.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def _load_payload(path_value: str | None) -> dict[str, object]:
    if not path_value:
        raise ValueError("missing required --payload-file")
    try:
        payload = json.loads(Path(path_value).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("invalid payload-file") from exc
    if not isinstance(payload, dict):
        raise ValueError("payload-file must contain a JSON object")
    return payload


def _add_market_summary(payload: dict[str, object], market: str) -> dict[str, object]:
    result = dict(payload)
    nested_payload = result.get("payload")
    if isinstance(nested_payload, dict):
        payload_copy = dict(nested_payload)
        summary = payload_copy.get("summary")
        if isinstance(summary, dict):
            summary_copy = dict(summary)
            summary_copy["market"] = market
            payload_copy["summary"] = summary_copy
            result["payload"] = payload_copy
            result["summary"] = summary_copy
    return result


def main(argv: list[str] | None = None) -> int:
    args, extras = _parse_args(sys.argv[1:] if argv is None else argv)
    skill = args.skill
    action = args.action
    root = args.root
    ticker = args.ticker

    if extras or skill is None or action is None:
        return _emit(
            error(skill or "", action or "", ticker, "invalid_arguments", "missing or invalid arguments"),
            1,
        )

    if skill not in SUPPORTED_SKILLS:
        return _emit(
            error(skill or "", action or "", ticker, "unknown_skill", f"unsupported skill: {skill}"),
            1,
        )

    if action not in SUPPORTED_ACTIONS.get(skill, set()):
        return _emit(
            error(skill, action or "", ticker, "invalid_arguments", f"unsupported action: {action}"),
            1,
        )

    if skill == "config" and action == "get-root":
        if root is not None:
            return _emit(error(skill, action, None, "invalid_arguments", "get-root does not accept --root"), 1)
        try:
            resolved_root = runtime_config.read_configured_root()
            return _emit(
                ok(
                    skill,
                    action,
                    None,
                    extra={"root": str(resolved_root), "config_path": str(runtime_config.config_path())},
                ),
                0,
            )
        except runtime_config.RuntimeConfigError as exc:
            return _emit(error(skill, action, None, exc.code, exc.message), 1)

    if skill == "config" and action == "set-root":
        if root is None:
            return _emit(error(skill, action, None, "invalid_arguments", "missing required arguments"), 1)
        try:
            resolved_root = runtime_config.write_configured_root(root)
            return _emit(
                ok(
                    skill,
                    action,
                    None,
                    extra={"root": str(resolved_root), "config_path": str(runtime_config.config_path())},
                ),
                0,
            )
        except runtime_config.RuntimeConfigError as exc:
            return _emit(error(skill, action, None, exc.code, exc.message), 1)

    if not ticker:
        return _emit(error(skill, action, ticker, "invalid_arguments", "missing required arguments"), 1)

    try:
        normalized_ticker = normalize_input_ticker(ticker)
    except ValueError as exc:
        return _emit(error(skill, action, ticker, "invalid_arguments", str(exc)), 1)

    try:
        root_path = runtime_config.resolve_runtime_root(root)
    except runtime_config.RuntimeConfigError as exc:
        return _emit(error(skill, action, normalized_ticker, exc.code, exc.message), 1)

    if skill in {"right-business", "right-people", "right-price"} and action == "prepare":
        try:
            page_path = company_root(root_path, normalized_ticker) / f"{skill}.md"
            _assert_within_root(root_path, page_path)
            changed: list[str] = []
            if lens_contracts.prepare_page(page_path, skill):
                changed.append(_relative(root_path, page_path))
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    changed=changed,
                    artifacts=[_relative(root_path, page_path)],
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill in {"right-business", "right-people", "right-price"} and action == "validate":
        try:
            page_path = company_root(root_path, normalized_ticker) / f"{skill}.md"
            _assert_within_root(root_path, page_path)
            is_valid, code = lens_contracts.validate_page(page_path, skill)
            if not is_valid:
                return _emit(error(skill, action, normalized_ticker, code, f"{skill} validation failed"), 1)
            return _emit(
                ok(skill, action, normalized_ticker, artifacts=[_relative(root_path, page_path)]),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "article" and action == "prepare":
        try:
            company = company_root(root_path, normalized_ticker)
            artifact_paths = [company / name for name in article_sidecars.ARTIFACT_FILES]
            for artifact_path in artifact_paths:
                _assert_within_root(root_path, artifact_path)
            changed_paths = article_sidecars.prepare(company, normalized_ticker)
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    changed=[_relative(root_path, path) for path in changed_paths],
                    artifacts=[_relative(root_path, artifact_path) for artifact_path in artifact_paths],
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "article" and action == "validate":
        try:
            company = company_root(root_path, normalized_ticker)
            artifact_paths = [company / name for name in article_sidecars.ARTIFACT_FILES]
            for artifact_path in artifact_paths:
                _assert_within_root(root_path, artifact_path)
            is_valid, code, details = article_sidecars.validate(company)
            if not is_valid:
                payload = error(skill, action, normalized_ticker, code, "article validation failed")
                if details:
                    payload["details"] = details
                return _emit(payload, 1)
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    artifacts=[_relative(root_path, company / name) for name in article_sidecars.ARTIFACT_FILES],
                    extra={"metrics": details},
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "lint" and action == "run":
        try:
            report = lint_rules.run(root_path, normalized_ticker, write_report=bool(args.write_report))
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    changed=list(report.get("changed", [])),
                    artifacts=list(report.get("artifacts", [])),
                    extra={
                        "valid": bool(report.get("valid", False)),
                        "findings": list(report.get("findings", [])),
                    },
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "dossier" and action == "inspect":
        try:
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    extra={"summary": dossier_orchestrator.inspect(root_path, normalized_ticker)},
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "dossier" and action == "discover":
        try:
            result = dossier_orchestrator.discover(root_path, normalized_ticker)
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    changed=list(result.get("changed", [])),
                    artifacts=list(result.get("artifacts", [])),
                    extra={"summary": result.get("summary", {})},
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "dossier" and action == "materialize":
        try:
            result = dossier_orchestrator.materialize(root_path, normalized_ticker)
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    changed=list(result.get("changed", [])),
                    artifacts=list(result.get("artifacts", [])),
                    extra={"summary": result.get("summary", {})},
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "dossier" and action == "enrich":
        try:
            result = dossier_orchestrator.enrich(root_path, normalized_ticker)
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    changed=list(result.get("changed", [])),
                    artifacts=list(result.get("artifacts", [])),
                    warnings=list(result.get("warnings", [])),
                    extra={"summary": result.get("summary", {})},
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "dossier" and action == "render":
        try:
            result = dossier_orchestrator.render(root_path, normalized_ticker)
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    changed=list(result.get("changed", [])),
                    artifacts=list(result.get("artifacts", [])),
                    extra={"summary": result.get("summary", {})},
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "dossier" and action == "validate":
        try:
            result = dossier_orchestrator.validate(root_path, normalized_ticker)
            return _emit(
                ok(
                    skill,
                    action,
                    normalized_ticker,
                    changed=list(result.get("changed", [])),
                    artifacts=list(result.get("artifacts", [])),
                    extra={"summary": result.get("summary", {})},
                ),
                0,
            )
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "dossier" and action == "run":
        try:
            payload = dossier_orchestrator.run(root_path, normalized_ticker)
            market = resolve_market(dossier_paths(root_path, normalized_ticker), normalized_ticker)
            return _emit(_add_market_summary(payload, market), 0 if payload.get("status") == "ok" else 1)
        except ValueError as exc:
            return _emit(error(skill, action, normalized_ticker, "invalid_arguments", str(exc)), 1)

    if skill == "dossier" and action == "log":
        try:
            payload = _load_payload(args.payload_file)
            return _emit(dossier_ops.log(root_path, normalized_ticker, payload), 0)
        except ValueError as exc:
            return _emit(error(skill, action, ticker, "invalid_arguments", str(exc)), 1)

    if skill == "ingest" and action == "scaffold":
        try:
            payload = _load_payload(args.payload_file)
            if not args.page_type:
                raise ValueError("missing required --page-type")
            return _emit(ingest_ops.scaffold(root_path, normalized_ticker, args.page_type, payload), 0)
        except ValueError as exc:
            return _emit(error(skill, action, ticker, "invalid_arguments", str(exc)), 1)

    if skill == "query" and action == "materialize":
        try:
            payload = _load_payload(args.payload_file)
            return _emit(ingest_ops.materialize_query(root_path, normalized_ticker, payload), 0)
        except ValueError as exc:
            return _emit(error(skill, action, ticker, "invalid_arguments", str(exc)), 1)

    return _emit(
        error(skill, action, ticker, "invalid_arguments", "unsupported command"),
        1,
    )


if __name__ == "__main__":
    raise SystemExit(main())
