from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.json_io import write_json


_REF_MARKER_RE = re.compile(r"\[ref:([^\]\s]+)\]")
_OVERVIEW_HEADING_RE = re.compile(r"(?m)^##\s+(公司概览|公司概况)\s*$")
ARTIFACT_FILES = ("wiki-article.md", "wiki-refs.json", "wiki-claims.jsonl")


def prepare(company: Path, ticker: str) -> list[Path]:
    company.mkdir(parents=True, exist_ok=True)
    article_path = company / "wiki-article.md"
    refs_path = company / "wiki-refs.json"
    claims_path = company / "wiki-claims.jsonl"

    changed: list[Path] = []
    if not article_path.exists():
        article_path.write_text(f"# {ticker}\n\n## 公司概览\n\n待补充。\n", encoding="utf-8")
        changed.append(article_path)
    if not refs_path.exists():
        write_json(refs_path, [])
        changed.append(refs_path)
    if not claims_path.exists():
        claims_path.write_text("", encoding="utf-8")
        changed.append(claims_path)
    return changed


def _load_refs(path: Path) -> tuple[bool, str, dict[str, Any], set[str]]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False, "invalid_refs", {}, set()

    if not isinstance(payload, list):
        return False, "invalid_refs", {}, set()

    ref_ids: set[str] = set()
    duplicate_ref_ids: set[str] = set()
    for item in payload:
        if not isinstance(item, dict):
            return False, "invalid_refs", {}, set()
        ref_id = item.get("ref_id")
        if not isinstance(ref_id, str) or not ref_id.strip():
            return False, "invalid_refs", {}, set()
        normalized = ref_id.strip()
        if normalized in ref_ids:
            duplicate_ref_ids.add(normalized)
        ref_ids.add(normalized)
    if duplicate_ref_ids:
        return False, "duplicate_ref_id", {"duplicate_ref_ids": sorted(duplicate_ref_ids)}, set()
    return True, "ok", {}, ref_ids


def _load_claims_count(path: Path) -> tuple[bool, int]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return False, 0

    count = 0
    for line in lines:
        if not line.strip():
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            return False, 0
        if not isinstance(payload, dict):
            return False, 0
        count += 1
    return True, count


def validate(company: Path) -> tuple[bool, str, dict[str, Any]]:
    article_path = company / "wiki-article.md"
    refs_path = company / "wiki-refs.json"
    claims_path = company / "wiki-claims.jsonl"

    if not article_path.exists():
        return False, "missing_article", {}
    if not refs_path.exists():
        return False, "missing_refs", {}
    if not claims_path.exists():
        return False, "missing_claims", {}

    article = article_path.read_text(encoding="utf-8")
    if _OVERVIEW_HEADING_RE.search(article) is None:
        return False, "missing_overview", {}

    refs_ok, refs_code, refs_details, known_ref_ids = _load_refs(refs_path)
    if not refs_ok:
        return False, refs_code, refs_details

    claims_ok, claims_count = _load_claims_count(claims_path)
    if not claims_ok:
        return False, "invalid_claims", {}

    inline_ref_ids = sorted(set(_REF_MARKER_RE.findall(article)))
    unknown_ref_ids = [ref_id for ref_id in inline_ref_ids if ref_id not in known_ref_ids]
    if unknown_ref_ids:
        return False, "unknown_ref_id", {"unknown_ref_ids": unknown_ref_ids}

    return True, "ok", {
        "refs_count": len(known_ref_ids),
        "claims_count": claims_count,
        "inline_ref_count": len(inline_ref_ids),
    }
