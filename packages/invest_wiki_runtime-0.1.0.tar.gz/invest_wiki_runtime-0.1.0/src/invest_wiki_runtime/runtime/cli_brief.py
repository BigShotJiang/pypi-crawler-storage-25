from __future__ import annotations

import json
from typing import Any


def _title_case(value: str) -> str:
    return value.replace("-", " ").strip().title()


def _code(value: object) -> str:
    return f"`{value}`"


def _format_scalar(value: object) -> str:
    if value is None or value == "":
        return "none"
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, (int, float)):
        return str(value)
    return _code(str(value))


def _render_list_section(title: str, items: list[object]) -> list[str]:
    lines = [f"## {title}", ""]
    if not items:
        lines.append("- none")
        return lines
    for item in items:
        lines.append(f"- {_format_scalar(item)}")
    return lines


def _render_mapping_section(title: str, mapping: dict[str, Any]) -> list[str]:
    lines = [f"## {title}", ""]
    if not mapping:
        lines.append("- none")
        return lines
    for key, value in mapping.items():
        if isinstance(value, list):
            rendered = ", ".join(_code(item) for item in value) if value else "none"
        elif isinstance(value, dict):
            rendered = _code(json.dumps(value, ensure_ascii=False, sort_keys=True))
        else:
            rendered = _format_scalar(value)
        lines.append(f"- {key}: {rendered}")
    return lines


def _render_dossier_report(payload: dict[str, Any]) -> str:
    status = str(payload.get("status", "")).strip() or "unknown"
    module = str(payload.get("module", "dossier")).strip() or "dossier"
    ticker = str(payload.get("ticker", "")).strip() or "unknown"
    body = dict(payload.get("payload", {})) if isinstance(payload.get("payload"), dict) else {}
    summary = dict(body.get("summary", {})) if isinstance(body.get("summary"), dict) else {}
    lines = [f"# {_title_case(module)} {_title_case(str(payload.get('action', 'run') or 'run'))}", ""]
    lines.extend(
        [
            f"- status: {_code(status)}",
            f"- ticker: {_code(ticker)}",
        ]
    )
    company_name = str(body.get("company_name", "")).strip()
    if company_name:
        lines.append(f"- company_name: {_code(company_name)}")
    run_id = str(payload.get("run_id", "")).strip()
    if run_id:
        lines.append(f"- run_id: {_code(run_id)}")
    if summary:
        for key in ("market", "coverage_score", "hard_blocking_missing", "soft_blocking_missing", "slots_total"):
            if key in summary:
                lines.append(f"- {key}: {_format_scalar(summary[key])}")
    decision_reason = str(body.get("decision_reason", "")).strip()
    if decision_reason:
        lines.append(f"- decision_reason: {decision_reason}")
    if payload.get("error"):
        lines.append(f"- error: {payload['error']}")
    lines.append("")
    lines.extend(_render_list_section("Actions Run", list(body.get("actions_run", []))))
    lines.append("")
    lines.extend(_render_list_section("Actions Skipped", list(body.get("actions_skipped", []))))
    lines.append("")
    lines.extend(_render_list_section("Artifacts", list(body.get("artifacts", []))))
    lines.append("")
    lines.extend(_render_list_section("Warnings", list(body.get("warnings", []))))
    return "\n".join(lines).rstrip() + "\n"


def _render_ok(payload: dict[str, Any]) -> str:
    skill = str(payload.get("skill", "")).strip() or "command"
    action = str(payload.get("action", "")).strip() or "run"
    lines = [f"# {_title_case(skill)} {_title_case(action)}", ""]
    lines.extend([f"- status: {_code('ok')}"])
    ticker = str(payload.get("ticker", "") or "").strip()
    if ticker:
        lines.append(f"- ticker: {_code(ticker)}")
    for key in ("root", "config_path", "valid"):
        if key in payload:
            lines.append(f"- {key}: {_format_scalar(payload[key])}")
    if "summary" in payload and isinstance(payload["summary"], dict):
        summary = dict(payload["summary"])
        lines.append("")
        lines.extend(_render_mapping_section("Summary", summary))
    if "metrics" in payload and isinstance(payload["metrics"], dict):
        lines.append("")
        lines.extend(_render_mapping_section("Metrics", dict(payload["metrics"])))
    if "details" in payload and isinstance(payload["details"], dict):
        lines.append("")
        lines.extend(_render_mapping_section("Details", dict(payload["details"])))
    if "findings" in payload:
        lines.append(f"- findings_count: {len(list(payload.get('findings', [])))}")
    lines.append("")
    lines.extend(_render_list_section("Changed", list(payload.get("changed", []))))
    lines.append("")
    lines.extend(_render_list_section("Artifacts", list(payload.get("artifacts", []))))
    lines.append("")
    lines.extend(_render_list_section("Warnings", list(payload.get("warnings", []))))
    return "\n".join(lines).rstrip() + "\n"


def _render_error(payload: dict[str, Any]) -> str:
    skill = str(payload.get("skill", "")).strip() or "command"
    action = str(payload.get("action", "")).strip() or "run"
    lines = [f"# {_title_case(skill)} {_title_case(action)}", ""]
    lines.extend(
        [
            f"- status: {_code('failed')}",
            f"- error_code: {_code(str(payload.get('error_code', 'unknown_error')))}",
            f"- message: {str(payload.get('message', '')).strip() or 'unknown error'}",
        ]
    )
    ticker = str(payload.get("ticker", "") or "").strip()
    if ticker:
        lines.append(f"- ticker: {_code(ticker)}")
    details = payload.get("details")
    if isinstance(details, dict):
        lines.append("")
        lines.extend(_render_mapping_section("Details", details))
    return "\n".join(lines).rstrip() + "\n"


def render_cli_brief(payload: dict[str, Any]) -> str:
    if payload.get("module") == "dossier" and "status" in payload:
        return _render_dossier_report(payload)
    if payload.get("ok") is True:
        return _render_ok(payload)
    if payload.get("ok") is False:
        return _render_error(payload)
    return _code(json.dumps(payload, ensure_ascii=False, sort_keys=True)) + "\n"
