from __future__ import annotations

import os
import re
from pathlib import Path


def normalize_ticker(ticker: str) -> str:
    normalized = ticker.strip().upper()
    if not normalized:
        raise ValueError("ticker is required")
    if normalized in {".", ".."}:
        raise ValueError("ticker contains invalid path components")
    if any(separator in normalized for separator in {"/", "\\", os.sep, os.altsep or ""} if separator):
        raise ValueError("ticker contains path separators")
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9._-]*", normalized):
        raise ValueError("ticker contains invalid characters")
    return normalized


def company_root(root: str | Path, ticker: str) -> Path:
    return Path(root) / "companies" / normalize_ticker(ticker)


def dossier_root(root: str | Path, ticker: str) -> Path:
    return company_root(root, ticker) / "dossier"
