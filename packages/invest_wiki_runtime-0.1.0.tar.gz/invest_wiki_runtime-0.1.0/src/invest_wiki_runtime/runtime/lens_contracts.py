from __future__ import annotations

import re
from pathlib import Path


CONTRACTS: dict[str, tuple[str, ...]] = {
    "right-business": (
        "# Right Business",
        "## One-sentence judgment",
        "## Core thesis",
        "## How the business makes money",
        "## Why customers buy",
        "## Delivery and operating model",
        "## Unit economics and durability",
        "## Moat and fragility",
        "## What could change the judgment",
    ),
    "right-people": (
        "# Right People",
        "## One-sentence judgment",
        "## Core thesis",
        "## Who is in charge",
        "## Incentives and capital allocation",
        "## Governance and trustworthiness",
        "## Execution record",
        "## Succession and organization risk",
        "## What could change the judgment",
    ),
    "right-price": (
        "# Right Price",
        "## One-sentence judgment",
        "## Core thesis",
        "## What the market seems to believe",
        "## Valuation framework",
        "## Key assumptions",
        "## Catalysts and timing",
        "## What breaks the thesis",
        "## What could change the judgment",
    ),
}

_RIGHT_PRICE_JUDGMENT = "## One-sentence judgment"
_RIGHT_PRICE_THESIS = "## Core thesis"


def _contract_for(lens: str) -> tuple[str, ...]:
    contract = CONTRACTS.get(lens)
    if contract is None:
        raise ValueError("unsupported lens")
    return contract


def _has_heading(content: str, heading: str) -> bool:
    pattern = rf"(?m)^{re.escape(heading)}\s*$"
    return re.search(pattern, content) is not None


def _section_body(content: str, heading: str) -> str:
    pattern = rf"(?ms)^{re.escape(heading)}\s*$\n?(.*?)(?=^##\s+|^#\s+|\Z)"
    match = re.search(pattern, content)
    if match is None:
        return ""
    return match.group(1).strip()


def _normalize_block(content: str) -> str:
    return " ".join(content.split()).casefold().strip()


def prepare_page(path: Path, lens: str) -> bool:
    contract = _contract_for(lens)
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n\n".join(contract) + "\n", encoding="utf-8")
    return True


def validate_page(path: Path, lens: str) -> tuple[bool, str]:
    contract = _contract_for(lens)
    if not path.exists():
        return False, "missing_page"

    content = path.read_text(encoding="utf-8")
    for heading in contract:
        if not _has_heading(content, heading):
            return False, "missing_heading"

    if lens == "right-price":
        judgment = _normalize_block(_section_body(content, _RIGHT_PRICE_JUDGMENT))
        thesis = _normalize_block(_section_body(content, _RIGHT_PRICE_THESIS))
        if judgment and thesis and judgment == thesis:
            return False, "duplicate_block"

    return True, "ok"
