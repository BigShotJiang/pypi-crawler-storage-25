from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python 3.11+ should provide tomllib
    tomllib = None


class RuntimeConfigError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def config_path() -> Path:
    return Path.home() / ".config" / "invest-llm-wiki" / "config.toml"


def _looks_like_companies_root(path: Path) -> bool:
    return path.name.strip().lower() == "companies"


def _validate_root_path(raw_root: str, *, error_code: str) -> Path:
    candidate = Path(raw_root).expanduser()
    if not candidate.is_absolute():
        raise RuntimeConfigError(error_code, "runtime root must be an absolute path")
    if not candidate.exists():
        raise RuntimeConfigError(error_code, "runtime root must point to an existing directory")
    if not candidate.is_dir():
        raise RuntimeConfigError(error_code, "runtime root must point to a directory")
    resolved = candidate.resolve()
    if _looks_like_companies_root(resolved):
        raise RuntimeConfigError(
            error_code,
            "runtime root must point to the content directory, not the companies directory",
        )
    return resolved


def _parse_config_text(content: str) -> dict[str, Any]:
    if tomllib is not None:
        try:
            return tomllib.loads(content)
        except tomllib.TOMLDecodeError as exc:  # type: ignore[attr-defined]
            raise RuntimeConfigError("invalid_root_config", "runtime config is not valid TOML") from exc

    result: dict[str, Any] = {}
    current_section: dict[str, Any] | None = None
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section_name = line[1:-1].strip()
            section: dict[str, Any] = {}
            result[section_name] = section
            current_section = section
            continue
        if "=" not in line or current_section is None:
            raise RuntimeConfigError("invalid_root_config", "runtime config is not valid TOML")
        key, value = [part.strip() for part in line.split("=", 1)]
        if value.startswith('"') and value.endswith('"'):
            current_section[key] = json.loads(value)
            continue
        try:
            current_section[key] = int(value)
        except ValueError as exc:
            raise RuntimeConfigError("invalid_root_config", "runtime config is not valid TOML") from exc
    return result


def _render_config(root: Path) -> str:
    return f"version = 1\n\n[runtime]\nroot = {json.dumps(str(root))}\n"


def read_configured_root() -> Path:
    path = config_path()
    if not path.exists():
        raise RuntimeConfigError(
            "missing_root_config",
            "runtime root is not configured; run `config set-root --root /absolute/path` through invest-wiki-runtime",
        )
    try:
        data = _parse_config_text(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise RuntimeConfigError("invalid_root_config", "runtime config could not be read") from exc

    runtime_section = data.get("runtime")
    if not isinstance(runtime_section, dict):
        raise RuntimeConfigError(
            "missing_root_config",
            "runtime root is not configured; run `config set-root --root /absolute/path` through invest-wiki-runtime",
        )

    raw_root = runtime_section.get("root")
    if not isinstance(raw_root, str) or not raw_root.strip():
        raise RuntimeConfigError(
            "missing_root_config",
            "runtime root is not configured; run `config set-root --root /absolute/path` through invest-wiki-runtime",
        )
    return _validate_root_path(raw_root, error_code="invalid_root_config")


def write_configured_root(raw_root: str) -> Path:
    root = _validate_root_path(raw_root, error_code="invalid_root_config")
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
            handle.write(_render_config(root))
            temp_path = Path(handle.name)
        temp_path.replace(path)
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()
    return root


def resolve_runtime_root(root_arg: str | None) -> Path:
    if root_arg is not None:
        return _validate_root_path(root_arg, error_code="invalid_arguments")
    return read_configured_root()
