from __future__ import annotations

from typing import Any


def ok(
    skill: str,
    action: str,
    ticker: str | None,
    *,
    changed: list[str] | None = None,
    artifacts: list[str] | None = None,
    warnings: list[str] | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "ok": True,
        "skill": skill,
        "action": action,
        "ticker": ticker,
        "changed": changed or [],
        "artifacts": artifacts or [],
        "warnings": warnings or [],
    }
    if extra:
        payload.update(extra)
    return payload


def error(
    skill: str,
    action: str,
    ticker: str | None,
    error_code: str,
    message: str,
) -> dict[str, Any]:
    return {
        "ok": False,
        "skill": skill,
        "action": action,
        "ticker": ticker,
        "error_code": error_code,
        "message": message,
    }
