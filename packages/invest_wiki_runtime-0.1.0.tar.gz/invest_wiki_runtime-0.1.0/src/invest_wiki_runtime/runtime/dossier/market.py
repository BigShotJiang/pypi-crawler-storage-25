from __future__ import annotations

from invest_wiki_runtime.runtime.paths import normalize_ticker


def normalize_input_ticker(ticker: str) -> str:
    return normalize_ticker(ticker)


def infer_market(ticker: str) -> str:
    normalized_ticker = normalize_input_ticker(ticker)
    return "hk" if normalized_ticker.endswith(".HK") else "us"
