from __future__ import annotations

import json
from copy import deepcopy
from functools import lru_cache
from pathlib import Path
from collections.abc import Mapping, Sequence
from typing import Any

from invest_wiki_runtime.runtime.paths import normalize_ticker


_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"
_BASE_TEMPLATE_PATH = _TEMPLATE_DIR / "source-template.v1.json"
_US_OVERRIDE_PATH = _TEMPLATE_DIR / "source-template.overrides.us.json"


def _int_value(value: Any) -> int:
    try:
        return max(int(value or 0), 0)
    except (TypeError, ValueError):
        return 0


@lru_cache(maxsize=1)
def _load_base_template() -> dict[str, Any]:
    return json.loads(_BASE_TEMPLATE_PATH.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _load_us_overrides() -> dict[str, Any]:
    return json.loads(_US_OVERRIDE_PATH.read_text(encoding="utf-8"))


def _merge_override_value(base_value: Any, override_value: Any) -> Any:
    if isinstance(base_value, list) and isinstance(override_value, list):
        merged: list[Any] = []
        for item in [*base_value, *override_value]:
            if item not in merged:
                merged.append(item)
        return merged
    return override_value


def _template_slots_for_market(market: str) -> list[dict[str, Any]]:
    template = deepcopy(_load_base_template())
    slots = [dict(slot) for slot in template.get("slots", []) if isinstance(slot, Mapping)]
    if str(market).strip().lower() == "us":
        overrides = _load_us_overrides().get("overrides", {})
        if isinstance(overrides, Mapping):
            for slot in slots:
                slot_id = str(slot.get("slot_id", "")).strip()
                override = overrides.get(slot_id)
                if isinstance(override, Mapping):
                    for key, override_value in dict(override).items():
                        slot[key] = _merge_override_value(slot.get(key), override_value)
    return slots


def compute_registry_summary(slots: Sequence[Mapping[str, Any]]) -> dict[str, int]:
    slots_total = 0
    required_total = 0
    hard_blocking_missing = 0
    soft_blocking_missing = 0
    satisfied_total = 0

    for slot in slots:
        slots_total += 1
        tier = str(slot.get("tier", "")).strip().lower()
        blocking_level = str(slot.get("blocking_level", "")).strip().lower()
        expected_min = _int_value(slot.get("expected_min", 0))
        found_count = _int_value(slot.get("found_count", 0))
        materialized_count = _int_value(slot.get("materialized_count", 0))
        available_count = max(found_count, materialized_count)
        is_satisfied = available_count >= expected_min

        if tier == "required":
            required_total += 1
        if is_satisfied:
            satisfied_total += 1
            continue
        if blocking_level == "hard":
            hard_blocking_missing += 1
        elif blocking_level == "soft":
            soft_blocking_missing += 1

    coverage_score = int((satisfied_total / slots_total) * 100) if slots_total else 0
    return {
        "slots_total": slots_total,
        "required_total": required_total,
        "hard_blocking_missing": hard_blocking_missing,
        "soft_blocking_missing": soft_blocking_missing,
        "coverage_score": coverage_score,
    }


def build_default_registry(ticker: str, market: str) -> dict[str, Any]:
    normalized_ticker = normalize_ticker(ticker)
    normalized_market = str(market).strip().lower() or "us"
    template = _load_base_template()
    slots = []
    for slot in _template_slots_for_market(normalized_market):
        next_slot = dict(slot)
        next_slot.update(
            {
                "status": "planned",
                "found_count": 0,
                "materialized_count": 0,
                "freshness_status": "unknown",
                "gap_reason": "not discovered",
                "sources": [],
                "materializations": [],
            }
        )
        slots.append(next_slot)

    registry: dict[str, Any] = {
        "registry_version": "1.0.0",
        "template_id": str(template.get("template_id", "")).strip(),
        "template_version": str(template.get("template_version", "")).strip(),
        "company": {
            "ticker": normalized_ticker,
            "market": normalized_market,
        },
        "summary": compute_registry_summary(slots),
        "slots": slots,
    }
    return registry


def suggest_actions(
    registry: Mapping[str, Any],
    *,
    archive_exists: bool,
    overview_exists: bool,
) -> list[str]:
    summary = registry.get("summary", {})
    if not isinstance(summary, Mapping):
        return ["discover", "materialize", "render", "validate"]

    hard_blocking_missing = _int_value(summary.get("hard_blocking_missing", 0))
    if hard_blocking_missing > 0 or not archive_exists:
        return ["discover", "materialize", "render", "validate"]
    if not overview_exists:
        return ["render", "validate"]
    return ["validate"]
