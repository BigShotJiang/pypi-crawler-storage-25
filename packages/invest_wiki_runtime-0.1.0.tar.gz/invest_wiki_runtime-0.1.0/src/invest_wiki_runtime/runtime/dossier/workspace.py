from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.load import load_dossier_registry
from invest_wiki_runtime.runtime.dossier.paths import (
    dossier_archive_path,
    dossier_index_path,
    dossier_log_jsonl_path,
    dossier_log_markdown_path,
    dossier_overview_path,
    dossier_raw_dir,
    dossier_registry_path,
)
from invest_wiki_runtime.runtime.dossier.registry import build_default_registry
from invest_wiki_runtime.runtime.dossier.market import infer_market
from invest_wiki_runtime.runtime.paths import company_root, dossier_root, normalize_ticker


def relative(root: Path, path: Path) -> str:
    root_resolved = root.resolve()
    path_resolved = path.resolve()
    try:
        return path_resolved.relative_to(root_resolved).as_posix()
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def assert_within_root(root: Path, path: Path) -> None:
    root_resolved = root.resolve()
    path_resolved = path.resolve(strict=False)
    try:
        path_resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def assert_paths_within_root(root: Path, paths: list[Path]) -> None:
    for path in paths:
        assert_within_root(root, path)


def read_json_if_exists(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def write_json_if_changed(path: Path, payload: dict[str, Any]) -> bool:
    content = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if path.exists() and path.read_text(encoding="utf-8") == content:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True


def write_text_if_changed(path: Path, content: str) -> bool:
    if path.exists() and path.read_text(encoding="utf-8") == content:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True


def _mtime_ns(path: Path) -> int:
    return path.stat().st_mtime_ns


def render_outputs_are_current(paths: dict[str, Path]) -> bool:
    render_outputs = (paths["overview"], paths["index"], paths["log_md"])
    if any(not path.exists() for path in render_outputs):
        return False

    render_inputs = [paths["archive"], paths["registry"]]
    if paths["log_jsonl"].exists():
        render_inputs.append(paths["log_jsonl"])

    newest_input = max(_mtime_ns(path) for path in render_inputs)
    oldest_output = min(_mtime_ns(path) for path in render_outputs)
    return newest_input <= oldest_output


def dossier_paths(root: Path, ticker: str) -> dict[str, Path]:
    normalized_ticker = normalize_ticker(ticker)
    company = company_root(root, normalized_ticker)
    dossier = dossier_root(root, normalized_ticker)
    basic = company / "basic.json"
    calendar = company / "calendar.json"
    archive = dossier_archive_path(root, normalized_ticker)
    registry = dossier_registry_path(root, normalized_ticker)
    overview = dossier_overview_path(root, normalized_ticker)
    index = dossier_index_path(root, normalized_ticker)
    log_jsonl = dossier_log_jsonl_path(root, normalized_ticker)
    log_md = dossier_log_markdown_path(root, normalized_ticker)
    materialization_report_json = dossier / "materialization-report.json"
    materialization_report_md = dossier / "materialization-report.md"
    raw = dossier_raw_dir(root, normalized_ticker)
    wiki = dossier / "wiki"
    wiki_sources = wiki / "sources"
    wiki_events = wiki / "events"
    wiki_rollups = wiki / "rollups"
    wiki_queries = wiki / "queries"
    assert_paths_within_root(
        root,
        [
            company,
            dossier,
            basic,
            calendar,
            archive,
            registry,
            overview,
            index,
            log_jsonl,
            log_md,
            materialization_report_json,
            materialization_report_md,
            raw,
            wiki,
            wiki_sources,
            wiki_events,
            wiki_rollups,
            wiki_queries,
        ],
    )
    return {
        "company": company,
        "dossier": dossier,
        "basic": basic,
        "calendar": calendar,
        "archive": archive,
        "registry": registry,
        "overview": overview,
        "index": index,
        "log_jsonl": log_jsonl,
        "log_md": log_md,
        "materialization_report_json": materialization_report_json,
        "materialization_report_md": materialization_report_md,
        "raw": raw,
        "wiki": wiki,
        "wiki_sources": wiki_sources,
        "wiki_events": wiki_events,
        "wiki_rollups": wiki_rollups,
        "wiki_queries": wiki_queries,
    }


def company_name(paths: dict[str, Path], ticker: str) -> str:
    if paths["archive"].exists():
        archive = read_json_if_exists(paths["archive"])
        company = archive.get("company", {})
        if isinstance(company, dict):
            return str(company.get("company_name", "")).strip()
    basic = read_json_if_exists(paths["basic"])
    return str(basic.get("company_name", "")).strip() or normalize_ticker(ticker)


def resolve_market(paths: dict[str, Path], ticker: str | None = None, market: str | None = None) -> str:
    normalized_market = str(market or "").strip().lower()
    if normalized_market:
        return normalized_market
    if paths["archive"].exists():
        archive = read_json_if_exists(paths["archive"])
        company = archive.get("company", {})
        if isinstance(company, dict):
            archive_market = str(company.get("market", "")).strip().lower()
            if archive_market:
                return archive_market
    basic = read_json_if_exists(paths["basic"])
    basic_market = str(basic.get("market", "")).strip().lower()
    if basic_market:
        return basic_market
    if ticker is not None:
        return infer_market(ticker)
    return "us"


def load_or_build_registry(
    root: Path,
    ticker: str,
    paths: dict[str, Path],
    market: str | None = None,
) -> dict[str, Any]:
    if paths["registry"].exists():
        return load_dossier_registry(root, ticker)
    return build_default_registry(ticker, resolve_market(paths, ticker, market))


def summary_from_registry(registry: dict[str, Any]) -> dict[str, Any]:
    summary = registry.get("summary", {})
    if not isinstance(summary, dict):
        return {
            "slots_total": 0,
            "hard_blocking_missing": 0,
            "soft_blocking_missing": 0,
            "coverage_score": 0,
        }
    return {
        "slots_total": int(summary.get("slots_total", 0) or 0),
        "hard_blocking_missing": int(summary.get("hard_blocking_missing", 0) or 0),
        "soft_blocking_missing": int(summary.get("soft_blocking_missing", 0) or 0),
        "coverage_score": int(summary.get("coverage_score", 0) or 0),
    }


def materialize_artifacts_exist(paths: dict[str, Path]) -> bool:
    required = (
        paths["basic"],
        paths["calendar"],
        paths["raw"],
        paths["wiki_sources"],
        paths["wiki_events"],
        paths["wiki_rollups"],
        paths["wiki_queries"],
        paths["materialization_report_json"],
        paths["materialization_report_md"],
    )
    return all(path.exists() for path in required)


def empty_string(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def minimal_archive(ticker: str, company_name: str, market: str) -> dict[str, Any]:
    return {
        "version": "1.0.0",
        "company": {
            "ticker": ticker,
            "company_name": company_name or ticker,
            "market": market,
        },
        "run_info": {},
        "config_snapshot": {},
        "identity": {},
        "financials": {},
        "market_data": {},
        "people": {},
        "estimates": {},
        "text_extracts": {},
        "earnings_calendar": None,
        "call_records": [],
        "filings": [],
        "sources": [],
    }
