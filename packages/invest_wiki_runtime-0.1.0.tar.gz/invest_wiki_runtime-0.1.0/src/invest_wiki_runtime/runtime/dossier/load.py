from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.paths import dossier_archive_path, dossier_registry_path
from invest_wiki_runtime.runtime.dossier.schemas import validate_dossier_archive, validate_dossier_registry


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_dossier_archive(root: str | Path, ticker: str, payload: dict[str, Any]) -> None:
    _write_json(Path(dossier_archive_path(root, ticker)), validate_dossier_archive(payload))


def load_dossier_archive(root: str | Path, ticker: str) -> dict[str, Any]:
    return validate_dossier_archive(_read_json(dossier_archive_path(root, ticker)))


def write_dossier_registry(root: str | Path, ticker: str, payload: dict[str, Any]) -> None:
    _write_json(Path(dossier_registry_path(root, ticker)), validate_dossier_registry(payload))


def load_dossier_registry(root: str | Path, ticker: str) -> dict[str, Any]:
    return validate_dossier_registry(_read_json(dossier_registry_path(root, ticker)))
