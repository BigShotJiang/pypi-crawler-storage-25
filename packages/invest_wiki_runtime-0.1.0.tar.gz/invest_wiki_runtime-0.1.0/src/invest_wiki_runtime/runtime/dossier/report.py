from __future__ import annotations

from typing import Any

from invest_wiki_runtime.runtime.dossier.schemas import validate_dossier_report


def _build_report(
    status: str,
    ticker: str,
    run_id: str,
    *,
    error: str = "",
    company_name: str = "",
    actions_run: list[str] | None = None,
    actions_skipped: list[str] | None = None,
    decision_reason: str = "",
    artifacts: list[str] | None = None,
    summary: dict[str, Any] | None = None,
    warnings: list[str] | None = None,
) -> dict[str, Any]:
    payload = {
        "archive_ticker": ticker,
        "company_name": company_name,
        "actions_run": actions_run or [],
        "actions_skipped": actions_skipped or [],
        "decision_reason": decision_reason,
        "artifacts": artifacts or [],
        "summary": summary or {
            "slots_total": 0,
            "hard_blocking_missing": 0,
            "soft_blocking_missing": 0,
            "coverage_score": 0,
        },
        "warnings": warnings or [],
    }
    return validate_dossier_report(
        {
            "status": status,
            "module": "dossier",
            "ticker": ticker,
            "run_id": run_id,
            "error": error,
            "payload": payload,
        }
    )


def dossier_success_report(
    ticker: str,
    run_id: str,
    *,
    actions_run: list[str],
    actions_skipped: list[str],
    artifacts: list[str],
    summary: dict[str, Any],
    company_name: str = "",
    warnings: list[str] | None = None,
    decision_reason: str = "",
) -> dict[str, Any]:
    return _build_report(
        "ok",
        ticker,
        run_id,
        company_name=company_name,
        actions_run=actions_run,
        actions_skipped=actions_skipped,
        artifacts=artifacts,
        summary=summary,
        warnings=warnings,
        decision_reason=decision_reason,
    )


def dossier_failed_report(
    ticker: str,
    run_id: str,
    error: str,
    *,
    company_name: str = "",
    actions_run: list[str] | None = None,
    actions_skipped: list[str] | None = None,
    decision_reason: str = "",
    artifacts: list[str] | None = None,
    summary: dict[str, Any] | None = None,
    warnings: list[str] | None = None,
) -> dict[str, Any]:
    error_text = str(error).strip()
    if not error_text:
        raise ValueError("error is required")
    return _build_report(
        "failed",
        ticker,
        run_id,
        error=error_text,
        company_name=company_name,
        actions_run=actions_run,
        actions_skipped=actions_skipped,
        artifacts=artifacts,
        summary=summary,
        warnings=warnings,
        decision_reason=decision_reason,
    )
