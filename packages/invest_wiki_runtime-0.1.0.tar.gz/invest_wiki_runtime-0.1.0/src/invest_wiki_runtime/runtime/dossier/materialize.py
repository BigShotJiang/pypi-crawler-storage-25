from __future__ import annotations

from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.market import infer_market
from invest_wiki_runtime.runtime.dossier.materialization.report import write_materialization_report
from invest_wiki_runtime.runtime.dossier.schemas import validate_dossier_archive, validate_dossier_registry
from invest_wiki_runtime.runtime.dossier.source_materializer import materialize_archive_sources, registry_with_materializations
from invest_wiki_runtime.runtime.dossier.workspace import (
    dossier_paths,
    empty_string,
    load_or_build_registry,
    minimal_archive,
    read_json_if_exists,
    relative,
    resolve_market,
    summary_from_registry,
    write_json_if_changed,
)
from invest_wiki_runtime.runtime.paths import normalize_ticker


def materialize_dossier(root: Path, ticker: str, market: str) -> dict[str, object]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    resolved_market = resolve_market(paths, normalized_ticker, market)
    if resolved_market in {"", "none", "null"}:
        resolved_market = infer_market(normalized_ticker)
    changed: list[str] = []
    basic_exists = paths["basic"].exists()

    for key in ("company", "dossier", "raw", "wiki_sources", "wiki_events", "wiki_rollups", "wiki_queries"):
        path = paths[key]
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            changed.append(relative(root_path, path))

    basic_payload = read_json_if_exists(paths["basic"]) or {
        "ticker": normalized_ticker,
        "company_name": "",
        "market": resolved_market,
        "summary": "",
        "last_verified_at": "",
    }
    archive_seed = read_json_if_exists(paths["archive"]) if paths["archive"].exists() else {}
    archive_company = archive_seed.get("company", {}) if isinstance(archive_seed.get("company", {}), dict) else {}
    basic_payload["ticker"] = normalized_ticker
    basic_company_name = empty_string(basic_payload.get("company_name", ""))
    if not basic_company_name and not basic_exists and archive_seed:
        basic_company_name = empty_string(archive_company.get("company_name", ""))
    basic_payload["company_name"] = basic_company_name
    basic_payload["market"] = resolved_market
    basic_payload["summary"] = empty_string(basic_payload.get("summary", ""))
    basic_payload["last_verified_at"] = empty_string(basic_payload.get("last_verified_at", ""))
    if write_json_if_changed(paths["basic"], basic_payload):
        changed.append(relative(root_path, paths["basic"]))

    calendar_payload = read_json_if_exists(paths["calendar"]) or {
        "company_events": [],
        "external_watchpoints": [],
        "last_verified_at": "",
    }
    if write_json_if_changed(paths["calendar"], calendar_payload):
        changed.append(relative(root_path, paths["calendar"]))

    archive_payload: dict[str, Any] = minimal_archive(
        normalized_ticker,
        str(basic_payload.get("company_name", "")).strip() or normalized_ticker,
        resolved_market,
    )
    config_snapshot = dict(archive_payload.get("config_snapshot", {}))
    config_snapshot["market"] = resolved_market
    archive_payload["config_snapshot"] = config_snapshot
    if archive_seed:
        archive_payload["version"] = str(archive_seed.get("version", archive_payload["version"])).strip() or "1.0.0"

        existing_company = archive_seed.get("company", {})
        if isinstance(existing_company, dict):
            merged_company = dict(existing_company)
            merged_company["ticker"] = normalized_ticker
            merged_company["company_name"] = (
                empty_string(merged_company.get("company_name", ""))
                or str(basic_payload.get("company_name", "")).strip()
                or normalized_ticker
            )
            merged_company["market"] = resolved_market
            archive_payload["company"] = merged_company

        for key in (
            "run_info",
            "config_snapshot",
            "identity",
            "financials",
            "market_data",
            "people",
            "estimates",
            "text_extracts",
        ):
            existing_value = archive_seed.get(key)
            if isinstance(existing_value, dict):
                archive_payload[key] = dict(existing_value)

        for key in ("call_records", "filings", "sources"):
            existing_value = archive_seed.get(key)
            if isinstance(existing_value, list):
                archive_payload[key] = list(existing_value)
            elif key == "sources" and isinstance(existing_value, dict):
                archive_payload[key] = dict(existing_value)

        if "earnings_calendar" in archive_seed:
            archive_payload["earnings_calendar"] = archive_seed.get("earnings_calendar")

        config_snapshot = dict(archive_payload.get("config_snapshot", {}))
        config_snapshot["market"] = resolved_market
        archive_payload["config_snapshot"] = config_snapshot

        archive_payload["market_data"] = dict(archive_payload.get("market_data", {}))

    materialized_sources, source_changes = materialize_archive_sources(
        root_path=root_path,
        paths=paths,
        archive_sources=archive_payload.get("sources", []),
    )
    archive_payload["sources"] = materialized_sources
    for path in source_changes:
        if path not in changed:
            changed.append(path)

    archive_payload = validate_dossier_archive(archive_payload)
    if write_json_if_changed(paths["archive"], archive_payload):
        changed.append(relative(root_path, paths["archive"]))

    report_changed = write_materialization_report(
        ticker=normalized_ticker,
        sources=_coerce_sources_list(archive_payload.get("sources", [])),
        json_path=paths["materialization_report_json"],
        markdown_path=paths["materialization_report_md"],
    )
    for path in report_changed:
        changed.append(relative(root_path, path))

    registry = validate_dossier_registry(
        registry_with_materializations(
            load_or_build_registry(root_path, normalized_ticker, paths, resolved_market),
            sources=archive_payload.get("sources", []),
            market=resolved_market,
        )
    )
    if write_json_if_changed(paths["registry"], registry):
        changed.append(relative(root_path, paths["registry"]))

    return {
        "changed": changed,
        "artifacts": [
            relative(root_path, paths["basic"]),
            relative(root_path, paths["calendar"]),
            relative(root_path, paths["archive"]),
            relative(root_path, paths["registry"]),
            relative(root_path, paths["materialization_report_json"]),
            relative(root_path, paths["materialization_report_md"]),
            relative(root_path, paths["raw"]),
            relative(root_path, paths["wiki_sources"]),
            relative(root_path, paths["wiki_events"]),
            relative(root_path, paths["wiki_rollups"]),
            relative(root_path, paths["wiki_queries"]),
        ],
        "summary": summary_from_registry(registry),
    }


def _coerce_sources_list(sources: object) -> list[dict[str, Any]]:
    if isinstance(sources, list):
        return [dict(item) for item in sources if isinstance(item, dict)]
    if isinstance(sources, dict):
        return [dict(sources)]
    return []
