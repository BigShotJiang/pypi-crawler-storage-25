from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.materialization.materializers import (
    MarkItDownMaterializer,
    StructuredSnapshotMaterializer,
)
from invest_wiki_runtime.runtime.dossier.materialization.paths import (
    describe_source,
    reserve_raw_materialization_path,
    slugify_source_id,
)
from invest_wiki_runtime.runtime.dossier.workspace import relative, write_text_if_changed


def _reserve_wiki_materialization_path(directory: Path, slug: str, reserved: set[Path]) -> Path:
    candidate = directory / f"{slug}.md"
    suffix = 2
    while candidate in reserved:
        candidate = directory / f"{slug}-{suffix}.md"
        suffix += 1
    reserved.add(candidate)
    return candidate


def _route_wiki_path(paths: dict[str, Path], source: Mapping[str, Any], reserved: set[Path]) -> Path:
    slot_id = str(source.get("slot_id", "")).strip().lower()
    slug = slugify_source_id(source)
    directory = paths["wiki_events"] if slot_id.startswith("events.") else paths["wiki_sources"]
    return _reserve_wiki_materialization_path(directory, slug, reserved)


def _metadata_lines(source: Mapping[str, Any], *, raw_path: str | None = None) -> list[str]:
    lines = [
        f"- source_id: `{str(source.get('source_id', '')).strip()}`",
        f"- slot_id: `{str(source.get('slot_id', '')).strip()}`",
        f"- source_origin: {str(source.get('source_origin', '')).strip() or 'unknown'}",
        f"- document_family: {str(source.get('document_family', '')).strip() or 'unknown'}",
        f"- document_type: {str(source.get('document_type', '')).strip() or 'unknown'}",
        f"- source_type: {str(source.get('source_type', '')).strip() or 'unknown'}",
        f"- publisher: {str(source.get('publisher', '')).strip() or 'unknown'}",
        f"- published_at: {str(source.get('published_at', '')).strip() or 'unknown'}",
    ]
    url = str(source.get("url", "")).strip()
    if url:
        lines.append(f"- url: {url}")
    notes = str(source.get("notes", "")).strip()
    if notes:
        lines.append(f"- notes: {notes}")
    if raw_path:
        lines.append(f"- raw_capture: `{raw_path}`")
    return lines


def _wiki_note_body(source: Mapping[str, Any], *, raw_path: str) -> str:
    title = str(source.get("title", "")).strip() or str(source.get("source_id", "")).strip() or "Source note"
    lines = [f"# {title}", "", "## Source Metadata", ""]
    lines.extend(_metadata_lines(source, raw_path=raw_path))
    lines.extend(
        [
            "",
            "## Summary",
            "",
            "Deterministic source note generated from dossier materialization.",
        ]
    )
    return "\n".join(lines).rstrip() + "\n"


def _materializer_for_source(source: Mapping[str, Any]) -> Any:
    descriptor = describe_source(source)
    if descriptor.materializer_kind == "structured":
        return StructuredSnapshotMaterializer()
    return MarkItDownMaterializer()


def _materialize_single_source(
    *,
    root_path: Path,
    paths: dict[str, Path],
    source: Mapping[str, Any],
    raw_reserved: set[Path],
    wiki_reserved: set[Path],
) -> tuple[dict[str, Any], list[str]]:
    changed: list[str] = []
    descriptor = describe_source(source)
    raw_path = reserve_raw_materialization_path(paths, source, raw_reserved)
    wiki_path = _route_wiki_path(paths, source, wiki_reserved)

    next_source = dict(source)
    next_source["document_family"] = descriptor.family
    next_source["document_type"] = descriptor.document_type
    next_source["materializer_kind"] = descriptor.materializer_kind

    try:
        raw_body = _materializer_for_source(next_source).convert(next_source, base_dir=paths["dossier"])
        wiki_body = _wiki_note_body(next_source, raw_path=relative(paths["dossier"], raw_path))
        if write_text_if_changed(raw_path, raw_body):
            changed.append(relative(root_path, raw_path))
        if write_text_if_changed(wiki_path, wiki_body):
            changed.append(relative(root_path, wiki_path))
        next_source["materialization_status"] = "materialized"
        next_source["materialized_paths"] = [
            relative(paths["dossier"], raw_path),
            relative(paths["dossier"], wiki_path),
        ]
        next_source.pop("materialization_error", None)
    except Exception as error:
        raw_path.unlink(missing_ok=True)
        wiki_path.unlink(missing_ok=True)
        next_source["materialization_status"] = "failed"
        next_source["materialized_paths"] = []
        next_source["materialization_error"] = f"{type(error).__name__}: {error}"
    return next_source, changed


def _coerce_archive_sources(archive_sources: object) -> tuple[list[dict[str, Any]], str]:
    if isinstance(archive_sources, list):
        return [dict(item) for item in archive_sources if isinstance(item, Mapping)], "list"
    if isinstance(archive_sources, Mapping):
        return [dict(archive_sources)], "mapping"
    return [], "list"


def materialize_archive_sources(
    *,
    root_path: Path,
    paths: dict[str, Path],
    archive_sources: object,
) -> tuple[object, list[str]]:
    sources, shape = _coerce_archive_sources(archive_sources)
    if not sources:
        return archive_sources if isinstance(archive_sources, Mapping) else [], []

    raw_reserved: set[Path] = set()
    wiki_reserved: set[Path] = set()
    materialized_sources: list[dict[str, Any]] = []
    changed: list[str] = []

    for source in sources:
        next_source, source_changed = _materialize_single_source(
            root_path=root_path,
            paths=paths,
            source=source,
            raw_reserved=raw_reserved,
            wiki_reserved=wiki_reserved,
        )
        materialized_sources.append(next_source)
        changed.extend(source_changed)

    if shape == "mapping":
        return materialized_sources[0], changed
    return materialized_sources, changed


def registry_with_materializations(
    registry: dict[str, Any],
    *,
    sources: object,
    market: str,
) -> dict[str, Any]:
    source_items, _shape = _coerce_archive_sources(sources)
    next_registry = dict(registry)
    next_slots: list[dict[str, Any]] = []
    for slot in registry.get("slots", []):
        if not isinstance(slot, Mapping):
            continue
        next_slot = dict(slot)
        slot_id = str(next_slot.get("slot_id", "")).strip()
        slot_sources = [source for source in source_items if str(source.get("slot_id", "")).strip() == slot_id]
        source_ids: list[str] = []
        materialization_paths: list[str] = []
        materialized_count = 0
        for source in slot_sources:
            source_id = str(source.get("source_id", "")).strip()
            if source_id and source_id not in source_ids:
                source_ids.append(source_id)
            paths_for_source = [
                str(path).strip()
                for path in source.get("materialized_paths", [])
                if isinstance(path, str) and str(path).strip()
            ]
            wiki_paths = [path for path in paths_for_source if path.startswith("wiki/")]
            for path in wiki_paths:
                if path not in materialization_paths:
                    materialization_paths.append(path)
            if str(source.get("materialization_status", "")).strip().lower() == "materialized":
                materialized_count += 1

        found_count = len(source_ids)
        expected_min = int(next_slot.get("expected_min", 0) or 0)
        if materialized_count >= expected_min and expected_min > 0:
            status = "materialized"
            gap_reason = ""
        elif found_count > 0:
            status = "discovered"
            gap_reason = "materialization incomplete" if materialized_count < expected_min else ""
        else:
            status = "planned"
            gap_reason = "not discovered"
        next_slot["market_scope"] = market
        next_slot["status"] = status
        next_slot["found_count"] = found_count
        next_slot["materialized_count"] = materialized_count
        next_slot["freshness_status"] = "current" if found_count > 0 else "unknown"
        next_slot["gap_reason"] = gap_reason
        next_slot["sources"] = source_ids
        next_slot["materializations"] = materialization_paths
        next_slots.append(next_slot)

    next_registry["slots"] = next_slots
    return next_registry
