from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Iterable, Mapping
from datetime import date
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.load import load_dossier_archive, load_dossier_registry
from invest_wiki_runtime.runtime.dossier.paths import dossier_archive_path, dossier_registry_path
from invest_wiki_runtime.runtime.dossier.registry import build_default_registry
from invest_wiki_runtime.runtime.dossier.schemas import validate_dossier_archive, validate_dossier_registry
from invest_wiki_runtime.runtime.dossier.workspace import company_name as resolve_company_name, dossier_paths
from invest_wiki_runtime.runtime.paths import normalize_ticker
from invest_wiki_runtime.runtime.dossier.providers.base import DiscoveredSource
from invest_wiki_runtime.runtime.dossier.providers.earnings_calendar_provider import EarningsCalendarProvider
from invest_wiki_runtime.runtime.dossier.providers.official_web_provider import OfficialWebProvider
from invest_wiki_runtime.runtime.dossier.providers.sec_provider import SecProvider
from invest_wiki_runtime.runtime.dossier.providers.yfinance_provider import YFinanceProvider


def _relative(root: Path, path: Path) -> str:
    root_resolved = root.resolve()
    path_resolved = path.resolve()
    try:
        return path_resolved.relative_to(root_resolved).as_posix()
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def _read_json_if_exists(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def _write_json_if_changed(path: Path, payload: dict[str, Any]) -> bool:
    content = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if path.exists() and path.read_text(encoding="utf-8") == content:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True


def _load_or_build_registry(root: Path, ticker: str, market: str) -> dict[str, Any]:
    registry_path = dossier_registry_path(root, ticker)
    if registry_path.exists():
        registry = load_dossier_registry(root, ticker)
    else:
        registry = build_default_registry(ticker, market)
    company = dict(registry.get("company", {}))
    company["ticker"] = ticker
    company["market"] = market
    registry["company"] = company
    return registry


def _registry_summary(registry: dict[str, Any], market: str) -> dict[str, Any]:
    summary = registry.get("summary", {})
    if not isinstance(summary, dict):
        summary = {}
    return {
        "slots_total": int(summary.get("slots_total", 0) or 0),
        "hard_blocking_missing": int(summary.get("hard_blocking_missing", 0) or 0),
        "soft_blocking_missing": int(summary.get("soft_blocking_missing", 0) or 0),
        "coverage_score": int(summary.get("coverage_score", 0) or 0),
        "market": market,
    }


def _dedupe_sources(sources: Iterable[DiscoveredSource]) -> list[DiscoveredSource]:
    deduped: list[DiscoveredSource] = []
    seen: set[tuple[str, str, str, str]] = set()
    for source in sources:
        key = (
            source.source_id,
            source.slot_id,
            source.title,
            source.url or "",
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(source)
    return deduped


def _parse_iso_date(value: object) -> date | None:
    text = str(value or "").strip()
    if len(text) < 10:
        return None
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return None


def _slot_priority(slot_id: str) -> int:
    priorities = {
        "regulatory.material_events_recent": 0,
        "regulatory.periodic_reports_recent": 1,
        "regulatory.annual_report_latest": 2,
        "events.earnings_calendar_or_results_date": 3,
    }
    return priorities.get(slot_id, 9)


def _build_latest_earnings_bundle_sources(
    sec_sources: Iterable[DiscoveredSource],
    earnings_sources: Iterable[DiscoveredSource],
) -> list[DiscoveredSource]:
    earnings_candidates = [
        source for source in earnings_sources if _parse_iso_date(source.published_at) is not None
    ]
    if not earnings_candidates:
        return []
    filing_candidates = [
        source
        for source in sec_sources
        if source.slot_id in {
            "regulatory.material_events_recent",
            "regulatory.periodic_reports_recent",
            "regulatory.annual_report_latest",
        }
        and _parse_iso_date(source.published_at) is not None
    ]

    bundle_sources: list[DiscoveredSource] = []
    for earnings_source in earnings_candidates:
        earnings_date = _parse_iso_date(earnings_source.published_at)
        if earnings_date is None:
            continue

        chosen_source = earnings_source
        if filing_candidates:
            filing_matches = sorted(
                filing_candidates,
                key=lambda source: (
                    abs((_parse_iso_date(source.published_at) - earnings_date).days),  # type: ignore[union-attr]
                    _slot_priority(source.slot_id),
                    -int(source.published_at.replace("-", "")[:8]),  # type: ignore[union-attr]
                ),
            )
            best_filing = filing_matches[0]
            best_date = _parse_iso_date(best_filing.published_at)
            if best_date is not None and abs((best_date - earnings_date).days) <= 3:
                chosen_source = best_filing

        bundle_sources.append(
            DiscoveredSource(
                source_id="latest-earnings-event-bundle",
                slot_id="events.latest_earnings_event_bundle",
                source_type=chosen_source.source_type,
                title=chosen_source.title,
                url=chosen_source.url,
                publisher=chosen_source.publisher,
                discovered_at=chosen_source.discovered_at,
                published_at=chosen_source.published_at or earnings_source.published_at,
                notes=f"latest earnings bundle derived from {chosen_source.source_id}",
                source_origin=chosen_source.source_origin,
            )
        )
        break
    return bundle_sources


def _merge_archive_sources(
    archive_sources: object,
    discovered_sources: Iterable[DiscoveredSource],
) -> list[dict[str, object]]:
    merged: list[dict[str, object]] = []
    seen_ids: set[str] = set()

    if isinstance(archive_sources, list):
        for item in archive_sources:
            if not isinstance(item, dict):
                continue
            source_id = str(item.get("source_id", "")).strip()
            if source_id:
                seen_ids.add(source_id)
            merged.append(dict(item))
    elif isinstance(archive_sources, Mapping):
        source_id = str(archive_sources.get("source_id", "")).strip()
        if source_id:
            seen_ids.add(source_id)
        merged.append(dict(archive_sources))

    for source in discovered_sources:
        if source.source_id in seen_ids:
            continue
        merged.append(source.to_payload())
        seen_ids.add(source.source_id)
    return merged


def _apply_discovered_sources(
    registry: dict[str, Any],
    discovered_sources: Iterable[DiscoveredSource],
    market: str,
) -> dict[str, Any]:
    sources_by_slot: dict[str, list[DiscoveredSource]] = defaultdict(list)
    for source in discovered_sources:
        sources_by_slot[source.slot_id].append(source)

    next_registry = dict(registry)
    next_company = dict(next_registry.get("company", {}))
    next_company["market"] = market
    next_registry["company"] = next_company

    next_slots: list[dict[str, Any]] = []
    for slot in next_registry.get("slots", []):
        if not isinstance(slot, dict):
            continue
        next_slot = dict(slot)
        slot_sources = sources_by_slot.get(str(next_slot.get("slot_id", "")).strip(), [])
        if slot_sources:
            existing_ids = [
                str(source_id).strip()
                for source_id in next_slot.get("sources", [])
                if str(source_id).strip()
            ]
            for source in slot_sources:
                if source.source_id not in existing_ids:
                    existing_ids.append(source.source_id)
            next_slot["market_scope"] = market
            next_slot["status"] = "materialized" if next_slot.get("status") == "materialized" else "discovered"
            next_slot["found_count"] = len(existing_ids)
            next_slot["freshness_status"] = "current"
            next_slot["gap_reason"] = ""
            next_slot["sources"] = existing_ids
        next_slots.append(next_slot)
    next_registry["slots"] = next_slots
    return next_registry


def _build_archive(
    root: Path,
    ticker: str,
    market: str,
    company_name: str,
    snapshot: dict[str, object],
    discovered_sources: Iterable[DiscoveredSource],
) -> dict[str, Any]:
    archive_path = dossier_archive_path(root, ticker)
    archive = load_dossier_archive(root, ticker) if archive_path.exists() else {
        "version": "1.0.0",
        "company": {},
        "run_info": {},
        "config_snapshot": {},
        "identity": {},
        "financials": {},
        "market_data": {},
        "people": {},
        "estimates": {},
        "text_extracts": {},
        "earnings_calendar": None,
        "call_records": [],
        "filings": [],
        "sources": [],
    }

    company = dict(archive.get("company", {}))
    company["ticker"] = ticker
    company["company_name"] = company_name or ticker
    company["market"] = market
    archive["company"] = company

    config_snapshot = dict(archive.get("config_snapshot", {}))
    config_snapshot["market"] = market
    archive["config_snapshot"] = config_snapshot

    market_data = dict(archive.get("market_data", {}))
    currency = str(snapshot.get("currency", "")).strip()
    if currency:
        market_data["currency"] = currency
    archive["market_data"] = market_data

    archive["sources"] = _merge_archive_sources(archive.get("sources", []), discovered_sources)
    return archive


def discover_dossier(root: Path, ticker: str, market: str) -> dict[str, object]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    normalized_market = str(market).strip().lower() or "us"

    snapshot_payload = YFinanceProvider().snapshot(normalized_ticker, normalized_market)
    snapshot = dict(snapshot_payload) if isinstance(snapshot_payload, Mapping) else {}
    current_company_name = resolve_company_name(paths, normalized_ticker)
    company_name = str(snapshot.get("company_name", "")).strip() or current_company_name
    sec_sources = list(SecProvider().discover(normalized_ticker) or [])
    official_sources = list(
        OfficialWebProvider().discover(
            normalized_ticker,
            normalized_market,
            company_name=company_name or None,
            snapshot=snapshot,
        )
        or []
    )
    earnings_sources = list(EarningsCalendarProvider().discover(normalized_ticker) or [])
    bundle_sources = _build_latest_earnings_bundle_sources(sec_sources, earnings_sources)
    discovered_sources = _dedupe_sources([*sec_sources, *official_sources, *earnings_sources, *bundle_sources])

    registry = _apply_discovered_sources(
        _load_or_build_registry(root_path, normalized_ticker, normalized_market),
        discovered_sources,
        normalized_market,
    )
    registry = validate_dossier_registry(registry)

    archive = _build_archive(
        root_path,
        normalized_ticker,
        normalized_market,
        company_name or normalized_ticker,
        snapshot,
        discovered_sources,
    )
    archive = validate_dossier_archive(archive)

    registry_path = dossier_registry_path(root_path, normalized_ticker)
    archive_path = dossier_archive_path(root_path, normalized_ticker)
    changed: list[str] = []
    if _write_json_if_changed(registry_path, registry):
        changed.append(_relative(root_path, registry_path))
    if _write_json_if_changed(archive_path, archive):
        changed.append(_relative(root_path, archive_path))

    return {
        "changed": changed,
        "artifacts": [
            _relative(root_path, registry_path),
            _relative(root_path, archive_path),
        ],
        "summary": _registry_summary(registry, normalized_market),
    }
