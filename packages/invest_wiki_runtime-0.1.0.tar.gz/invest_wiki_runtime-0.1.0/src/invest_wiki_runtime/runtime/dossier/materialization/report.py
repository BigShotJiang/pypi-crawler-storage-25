from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.materialization.paths import describe_source


DEFAULT_TEMPLATE = Path(__file__).with_name("materialization-report.md.tmpl")


def _normalize_source(source: Mapping[str, Any]) -> dict[str, Any]:
    normalized = dict(source)
    descriptor = describe_source(normalized)
    normalized["document_family"] = str(normalized.get("document_family") or descriptor.family)
    normalized["document_type"] = str(normalized.get("document_type") or descriptor.document_type)
    return normalized


def build_materialization_report(*, ticker: str, sources: list[dict[str, Any]]) -> dict[str, Any]:
    normalized_sources = [_normalize_source(source) for source in sources]
    by_document_type: dict[str, dict[str, int]] = defaultdict(
        lambda: {
            "discovered_total": 0,
            "materialized_success": 0,
            "materialized_failed": 0,
            "skipped": 0,
        }
    )
    failures: list[dict[str, str]] = []
    summary = {
        "discovered_total": len(normalized_sources),
        "materialized_success": 0,
        "materialized_failed": 0,
        "skipped": 0,
    }

    for source in normalized_sources:
        document_type = str(source.get("document_type", "source")).strip() or "source"
        bucket = by_document_type[document_type]
        bucket["discovered_total"] += 1
        status = str(source.get("materialization_status", "")).strip().lower()
        if status == "materialized":
            bucket["materialized_success"] += 1
            summary["materialized_success"] += 1
        elif status == "failed":
            bucket["materialized_failed"] += 1
            summary["materialized_failed"] += 1
            failures.append(
                {
                    "source_id": str(source.get("source_id", "")).strip(),
                    "document_type": document_type,
                    "error": str(source.get("materialization_error", "")).strip() or "unknown error",
                }
            )
        else:
            bucket["skipped"] += 1
            summary["skipped"] += 1

    return {
        "ticker": ticker,
        "summary": summary,
        "by_document_type": dict(sorted(by_document_type.items())),
        "failures": failures,
    }


def _render_document_type_rows(report: dict[str, Any]) -> str:
    rows = ["| document_type | discovered_total | materialized_success | materialized_failed | skipped |", "| --- | ---: | ---: | ---: | ---: |"]
    for document_type, counts in report.get("by_document_type", {}).items():
        rows.append(
            f"| {document_type} | {counts['discovered_total']} | {counts['materialized_success']} | {counts['materialized_failed']} | {counts['skipped']} |"
        )
    return "\n".join(rows)


def _render_failure_rows(report: dict[str, Any]) -> str:
    failures = report.get("failures", [])
    if not failures:
        return "No materialization failures."
    rows = ["| source_id | document_type | error |", "| --- | --- | --- |"]
    for item in failures:
        rows.append(f"| {item['source_id']} | {item['document_type']} | {item['error']} |")
    return "\n".join(rows)


def render_materialization_report_markdown(report: dict[str, Any], *, template_path: Path | None = None) -> str:
    path = template_path or DEFAULT_TEMPLATE
    template = path.read_text(encoding="utf-8")
    summary = report["summary"]
    return template.format(
        ticker=report["ticker"],
        discovered_total=summary["discovered_total"],
        materialized_success=summary["materialized_success"],
        materialized_failed=summary["materialized_failed"],
        skipped=summary["skipped"],
        document_type_rows=_render_document_type_rows(report),
        failure_rows=_render_failure_rows(report),
    )


def write_materialization_report(
    *,
    ticker: str,
    sources: list[dict[str, Any]],
    json_path: Path,
    markdown_path: Path,
) -> list[Path]:
    report = build_materialization_report(ticker=ticker, sources=sources)
    changed: list[Path] = []
    json_content = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    markdown_content = render_materialization_report_markdown(report)

    for path, content in ((json_path, json_content), (markdown_path, markdown_content)):
        if path.exists() and path.read_text(encoding="utf-8") == content:
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        changed.append(path)
    return changed
