from __future__ import annotations

import mimetypes
import os
import tempfile
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests

from invest_wiki_runtime.runtime.dossier.materialization.paths import describe_source
from invest_wiki_runtime.runtime.dossier.providers.base import (
    DEFAULT_SEC_USER_AGENT,
    fixture_providers_enabled,
    network_access_disabled,
)

try:
    from markitdown import MarkItDown
except Exception:  # pragma: no cover - optional at import time
    MarkItDown = None  # type: ignore[assignment]


def _source_reference(source: Mapping[str, Any], *, base_dir: Path | None = None) -> str | None:
    url = str(source.get("url", "")).strip()
    if url:
        return url
    path_value = str(source.get("path", "") or source.get("source_path", "")).strip()
    if not path_value:
        return None
    source_path = Path(path_value).expanduser()
    if not source_path.is_absolute() and base_dir is not None:
        source_path = base_dir / source_path
    return source_path.resolve().as_uri()


def _is_http_url(source_ref: str) -> bool:
    return urlparse(source_ref).scheme in {"http", "https"}


def _is_sec_url(source_ref: str) -> bool:
    hostname = (urlparse(source_ref).hostname or "").strip().lower()
    return hostname.endswith("sec.gov")


def _guess_suffix(source_ref: str, content_type: str | None) -> str:
    suffix = Path(urlparse(source_ref).path).suffix
    if suffix:
        return suffix
    if content_type:
        guessed = mimetypes.guess_extension(content_type.split(";", 1)[0].strip())
        if guessed:
            return guessed
    return ".bin"


def _download_url_to_tempfile(source_ref: str) -> Path:
    headers: dict[str, str] = {}
    if _is_sec_url(source_ref):
        headers["User-Agent"] = str(os.getenv("SEC_USER_AGENT", "")).strip() or DEFAULT_SEC_USER_AGENT
    response = requests.get(source_ref, timeout=30, headers=headers or None)
    response.raise_for_status()
    suffix = _guess_suffix(source_ref, response.headers.get("content-type"))
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as handle:
        handle.write(response.content)
        return Path(handle.name)


def _is_fixture_source(source: Mapping[str, Any]) -> bool:
    source_origin = str(source.get("source_origin", "")).strip().lower()
    if source_origin == "fixture":
        return True
    url = str(source.get("url", "")).strip().lower()
    return "example.com" in url


class MarkItDownMaterializer:
    def __init__(self, converter: Any | None = None):
        self._converter = converter

    def _load_converter(self) -> Any:
        if self._converter is not None:
            return self._converter
        if MarkItDown is None:
            raise ImportError("markitdown is not installed")
        self._converter = MarkItDown()
        return self._converter

    def _fallback_markdown(self, source: Mapping[str, Any]) -> str:
        descriptor = describe_source(source)
        title = str(source.get("title", "")).strip() or str(source.get("source_id", "")).strip() or "Source"
        lines = [f"# {title}", "", "## Metadata", ""]
        lines.extend(
            [
                f"- source_id: `{str(source.get('source_id', '')).strip()}`",
                f"- slot_id: `{str(source.get('slot_id', '')).strip()}`",
                f"- document_family: {descriptor.family}",
                f"- document_type: {descriptor.document_type}",
                f"- source_type: {str(source.get('source_type', '')).strip() or 'unknown'}",
                f"- publisher: {str(source.get('publisher', '')).strip() or 'unknown'}",
                f"- published_at: {str(source.get('published_at', '')).strip() or 'unknown'}",
            ]
        )
        url = str(source.get("url", "")).strip()
        if url:
            lines.append(f"- url: {url}")
        notes = str(source.get("notes", "")).strip()
        if notes:
            lines.append(f"- notes: {notes}")
        lines.extend(["", "## Snapshot", "", "Deterministic offline snapshot generated without live MarkItDown conversion."])
        return "\n".join(lines).rstrip() + "\n"

    def convert(self, source: Mapping[str, Any], *, base_dir: Path | None = None) -> str:
        if fixture_providers_enabled() or network_access_disabled() or _is_fixture_source(source):
            return self._fallback_markdown(source)
        source_ref = _source_reference(source, base_dir=base_dir)
        if source_ref is None:
            raise ValueError("source requires a url or path for materialization")

        temp_download: Path | None = None
        active_ref = source_ref
        try:
            if _is_http_url(source_ref) and _is_sec_url(source_ref):
                temp_download = _download_url_to_tempfile(source_ref)
                active_ref = temp_download.resolve().as_uri()
            converter = self._load_converter()
            if hasattr(converter, "convert_uri"):
                result = converter.convert_uri(active_ref)
            elif hasattr(converter, "convert_url"):
                result = converter.convert_url(active_ref)
            else:  # pragma: no cover
                raise AttributeError("MarkItDown converter does not expose convert_uri or convert_url")
            markdown = getattr(result, "markdown", None)
            if markdown is None:
                markdown = str(result)
            return str(markdown)
        finally:
            if temp_download is not None:
                temp_download.unlink(missing_ok=True)


class StructuredSnapshotMaterializer:
    def convert(self, source: Mapping[str, Any], *, base_dir: Path | None = None) -> str:
        _ = base_dir
        descriptor = describe_source(source)
        title = str(source.get("title", "")).strip() or str(source.get("source_id", "")).strip() or "Structured source"
        lines = [f"# {title}", "", "## Metadata", ""]
        lines.extend(
            [
                f"- source_id: `{str(source.get('source_id', '')).strip()}`",
                f"- slot_id: `{str(source.get('slot_id', '')).strip()}`",
                f"- document_family: {descriptor.family}",
                f"- document_type: {descriptor.document_type}",
                f"- source_type: {str(source.get('source_type', '')).strip() or 'unknown'}",
                f"- publisher: {str(source.get('publisher', '')).strip() or 'unknown'}",
                f"- published_at: {str(source.get('published_at', '')).strip() or 'unknown'}",
            ]
        )
        url = str(source.get("url", "")).strip()
        if url:
            lines.append(f"- url: {url}")
        notes = str(source.get("notes", "")).strip()
        if notes:
            lines.append(f"- notes: {notes}")
        lines.extend(["", "## Snapshot", "", "Structured snapshot captured during dossier materialization."])
        return "\n".join(lines).rstrip() + "\n"
