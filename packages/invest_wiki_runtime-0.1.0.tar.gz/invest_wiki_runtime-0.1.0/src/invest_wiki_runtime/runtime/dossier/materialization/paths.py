from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def _slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    return slug or "source"


def slugify_source_id(source: Mapping[str, Any]) -> str:
    for candidate in (
        str(source.get("source_id", "")).replace("::", "-"),
        str(source.get("slot_id", "")).replace(".", "-"),
        str(source.get("title", "")),
    ):
        slug = _slugify(candidate)
        if slug != "source":
            return slug
    return "source"


@dataclass(frozen=True)
class DocumentDescriptor:
    family: str
    document_type: str
    materializer_kind: str


def _normalize_form_hint(source: Mapping[str, Any]) -> str:
    for value in (
        source.get("document_type"),
        source.get("notes"),
        source.get("title"),
    ):
        text = str(value or "").strip().upper()
        if text:
            return text
    return ""


def describe_source(source: Mapping[str, Any]) -> DocumentDescriptor:
    slot_id = str(source.get("slot_id", "")).strip().lower()
    source_type = str(source.get("source_type", "")).strip().lower()
    publisher = str(source.get("publisher", "")).strip().lower()
    form_hint = _normalize_form_hint(source)

    if slot_id == "events.latest_earnings_event_bundle":
        if source_type == "earnings_calendar":
            return DocumentDescriptor("events", "latest-earnings-bundle", "structured")
        return DocumentDescriptor("events", "latest-earnings-bundle", "markitdown")
    if source_type == "earnings_calendar":
        return DocumentDescriptor("events", "earnings-calendar", "structured")
    if source_type == "official_web":
        if slot_id == "official.company_homepage":
            return DocumentDescriptor("official", "company-homepage", "markitdown")
        if slot_id == "official.ir_homepage_or_newsroom":
            return DocumentDescriptor("official", "ir-homepage", "markitdown")
        return DocumentDescriptor("official", "official-web", "markitdown")
    if source_type == "filing" or publisher == "sec_edgar":
        if "10-K" in form_hint:
            return DocumentDescriptor("regulatory", "10-k", "markitdown")
        if "10-Q" in form_hint:
            return DocumentDescriptor("regulatory", "10-q", "markitdown")
        if "8-K" in form_hint:
            return DocumentDescriptor("regulatory", "8-k", "markitdown")
        if "6-K" in form_hint:
            return DocumentDescriptor("regulatory", "6-k", "markitdown")
        if "DEF 14A" in form_hint:
            return DocumentDescriptor("governance", "def-14a", "markitdown")
        if form_hint == "4" or form_hint.startswith("FORM 4"):
            return DocumentDescriptor("ownership", "form-4", "markitdown")
        if "13D" in form_hint:
            return DocumentDescriptor("ownership", "13d", "markitdown")
        if "13G" in form_hint:
            return DocumentDescriptor("ownership", "13g", "markitdown")
    if slot_id.startswith("governance."):
        return DocumentDescriptor("governance", "governance-source", "markitdown")
    if slot_id.startswith("regulatory.ownership"):
        return DocumentDescriptor("ownership", "ownership-source", "markitdown")
    if slot_id.startswith("regulatory.annual_report"):
        return DocumentDescriptor("regulatory", "annual-report", "markitdown")
    if slot_id.startswith("regulatory.periodic"):
        return DocumentDescriptor("regulatory", "periodic-report", "markitdown")
    if slot_id.startswith("regulatory.material"):
        return DocumentDescriptor("regulatory", "material-event", "markitdown")
    if slot_id.startswith("events."):
        return DocumentDescriptor("events", "event-source", "structured")
    return DocumentDescriptor("misc", "source", "markitdown")


def reserve_raw_materialization_path(paths: dict[str, Path], source: Mapping[str, Any], reserved: set[Path]) -> Path:
    descriptor = describe_source(source)
    directory = paths["raw"] / descriptor.family / descriptor.document_type
    candidate = directory / f"{slugify_source_id(source)}.md"
    suffix = 2
    while candidate in reserved:
        candidate = directory / f"{slugify_source_id(source)}-{suffix}.md"
        suffix += 1
    reserved.add(candidate)
    return candidate
