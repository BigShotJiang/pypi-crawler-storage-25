from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.load import load_dossier_archive, load_dossier_registry
from invest_wiki_runtime.runtime.dossier.log_render import read_dossier_log_events
from invest_wiki_runtime.runtime.markdown_contracts import render_dossier_log
from invest_wiki_runtime.runtime.dossier.workspace import (
    dossier_paths,
    relative,
    summary_from_registry,
    write_text_if_changed,
)
from invest_wiki_runtime.runtime.paths import normalize_ticker


def _source_count(sources: object) -> int:
    if isinstance(sources, list):
        return len(sources)
    if isinstance(sources, dict):
        return 1
    return 0


def render_dossier_overview(archive: dict[str, Any], registry: dict[str, Any]) -> str:
    company = archive.get("company", {})
    summary = summary_from_registry(registry)
    ticker = str(company.get("ticker", "")).strip()
    company_name = str(company.get("company_name", "")).strip() or ticker
    market = str(company.get("market", "")).strip() or "unknown"
    source_count = _source_count(archive.get("sources", []))
    filing_count = len(archive.get("filings", []) or [])
    call_record_count = len(archive.get("call_records", []) or [])
    return (
        "# Dossier\n\n"
        f"- ticker: `{ticker}`\n"
        f"- company_name: {company_name}\n"
        f"- market: {market}\n"
        f"- coverage_score: {summary['coverage_score']}\n"
        f"- hard_blocking_missing: {summary['hard_blocking_missing']}\n"
        f"- soft_blocking_missing: {summary['soft_blocking_missing']}\n"
        f"- sources: {source_count}\n"
        f"- filings: {filing_count}\n"
        f"- call_records: {call_record_count}\n"
    )


def render_dossier_index(archive: dict[str, Any], registry: dict[str, Any]) -> str:
    company = archive.get("company", {})
    summary = summary_from_registry(registry)
    ticker = str(company.get("ticker", "")).strip()
    company_name = str(company.get("company_name", "")).strip() or ticker
    return (
        "# Dossier Index\n\n"
        f"- ticker: `{ticker}`\n"
        f"- company_name: {company_name}\n"
        f"- coverage_score: {summary['coverage_score']}\n"
        "- generated_views:\n"
        "  - `dossier.md`\n"
        "  - `index.md`\n"
        "  - `log.md`\n"
        "  - `materialization-report.md`\n"
        "- canonical_truth:\n"
        "  - `archive.json`\n"
        "  - `source_registry.json`\n"
        "  - `materialization-report.json`\n"
        "- compatibility_tree:\n"
        "  - `raw/`\n"
        "  - `dossier/wiki/`\n"
        "  - `wiki/sources/`\n"
        "  - `wiki/events/`\n"
        "  - `wiki/rollups/`\n"
        "  - `wiki/queries/`\n"
    )


def render_dossier_views(
    archive: dict[str, Any],
    registry: dict[str, Any],
    log_events: Sequence[dict[str, Any]],
) -> dict[str, str]:
    return {
        "dossier.md": render_dossier_overview(archive, registry),
        "index.md": render_dossier_index(archive, registry),
        "log.md": render_dossier_log(log_events),
    }


def render_dossier(root: Path, ticker: str) -> dict[str, object]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    if not paths["archive"].exists() or not paths["registry"].exists():
        raise ValueError("canonical dossier files are required before render")

    archive = load_dossier_archive(root_path, normalized_ticker)
    registry = load_dossier_registry(root_path, normalized_ticker)
    changed: list[str] = []
    if not paths["log_jsonl"].exists():
        paths["log_jsonl"].parent.mkdir(parents=True, exist_ok=True)
        paths["log_jsonl"].write_text("", encoding="utf-8")
        changed.append(relative(root_path, paths["log_jsonl"]))
    log_events = read_dossier_log_events(paths["log_jsonl"])
    rendered_views = render_dossier_views(archive, registry, log_events)

    if write_text_if_changed(paths["overview"], rendered_views["dossier.md"]):
        changed.append(relative(root_path, paths["overview"]))
    if write_text_if_changed(paths["index"], rendered_views["index.md"]):
        changed.append(relative(root_path, paths["index"]))
    if write_text_if_changed(paths["log_md"], rendered_views["log.md"]):
        changed.append(relative(root_path, paths["log_md"]))

    return {
        "changed": changed,
        "artifacts": [
            relative(root_path, paths["overview"]),
            relative(root_path, paths["index"]),
            relative(root_path, paths["log_jsonl"]),
            relative(root_path, paths["log_md"]),
        ],
        "summary": summary_from_registry(registry),
    }
