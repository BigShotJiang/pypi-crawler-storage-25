from __future__ import annotations

import json
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import requests

from invest_wiki_runtime.runtime.dossier.providers.base import (
    DEFAULT_SEC_USER_AGENT,
    DiscoveredSource,
    fixture_providers_enabled,
    network_access_disabled,
)
from invest_wiki_runtime.runtime.dossier.providers.fixtures import fixture_sec_sources


SEC_FORM_TYPE_MAP = {
    "10-K": ("annual_report", "年度报告"),
    "10-Q": ("interim_report", "季度报告"),
    "8-K": ("current_report", "临时公告"),
    "6-K": ("current_report", "临时公告"),
    "DEF 14A": ("proxy_statement", "代理声明书"),
    "4": ("insider_transaction", "内部人交易"),
    "13D": ("insider_transaction", "内部人交易"),
    "13G": ("insider_transaction", "内部人交易"),
}


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _default_cache_dir() -> Path:
    configured = str(os.getenv("INVEST_WIKI_CACHE_DIR", "")).strip()
    if configured:
        return Path(configured) / "sec"
    xdg_cache_home = str(os.getenv("XDG_CACHE_HOME", "")).strip()
    if xdg_cache_home:
        return Path(xdg_cache_home) / "invest-llm-wiki" / "sec"
    return Path.home() / ".cache" / "invest-llm-wiki" / "sec"


class SECClient:
    def __init__(
        self,
        user_agent: str,
        rps_limit: int = 3,
        cache_dir: str | Path | None = None,
        ticker_mapping_url: str | None = None,
        ticker_cache_ttl_hours: int | None = None,
    ):
        self.user_agent = user_agent
        self.rps_limit = rps_limit
        self.sec_base_url = "https://data.sec.gov"
        self.min_request_interval = 1.0 / rps_limit
        self.last_request_time = 0.0
        self.ticker_mapping_url = ticker_mapping_url or "https://www.sec.gov/files/company_tickers_exchange.json"
        self.cache_dir = Path(cache_dir) if cache_dir is not None else _default_cache_dir()
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ticker_cache_path = self.cache_dir / "sec_company_tickers_exchange.json"
        self.ticker_cache_ttl_hours = ticker_cache_ttl_hours or int(os.getenv("SEC_TICKER_CACHE_TTL_HOURS", "24"))

    def get(self, url: str) -> requests.Response:
        elapsed = time.time() - self.last_request_time
        if elapsed < self.min_request_interval:
            time.sleep(self.min_request_interval - elapsed)

        response = requests.get(
            url,
            headers={"User-Agent": self.user_agent},
            timeout=20,
        )
        self.last_request_time = time.time()
        response.raise_for_status()
        return response

    def _is_ticker_cache_fresh(self) -> bool:
        if not self.ticker_cache_path.exists():
            return False
        age_seconds = time.time() - self.ticker_cache_path.stat().st_mtime
        return age_seconds < self.ticker_cache_ttl_hours * 3600

    def _read_ticker_cache(self) -> dict[str, Any]:
        return json.loads(self.ticker_cache_path.read_text(encoding="utf-8"))

    def _write_ticker_cache(self, payload: dict[str, Any]) -> None:
        self.ticker_cache_path.write_text(json.dumps(payload), encoding="utf-8")

    def _fetch_ticker_mapping(self) -> dict[str, Any]:
        payload = self.get(self.ticker_mapping_url).json()
        self._write_ticker_cache(payload)
        return payload

    def _load_ticker_mapping(self) -> dict[str, Any]:
        if self._is_ticker_cache_fresh():
            return self._read_ticker_cache()
        try:
            return self._fetch_ticker_mapping()
        except Exception:
            if self.ticker_cache_path.exists():
                return self._read_ticker_cache()
            raise

    @staticmethod
    def _iter_ticker_entries(payload: dict[str, Any]) -> list[dict[str, Any]]:
        fields = payload.get("fields")
        data = payload.get("data")
        if isinstance(fields, list) and isinstance(data, list):
            return [dict(zip(fields, row)) for row in data]
        if all(isinstance(value, dict) for value in payload.values()):
            return list(payload.values())
        raise ValueError("Unsupported SEC ticker mapping payload format")

    def resolve_ticker(self, ticker: str) -> tuple[str, str]:
        entries = self._iter_ticker_entries(self._load_ticker_mapping())
        ticker_upper = ticker.upper()
        for entry in entries:
            if str(entry.get("ticker", "")).upper() == ticker_upper:
                cik_value = entry.get("cik") or entry.get("cik_str")
                title = str(entry.get("name") or entry.get("title") or ticker_upper)
                return str(cik_value).zfill(10), title
        raise ValueError(f"Ticker {ticker} not found in SEC database")

    def fetch_submissions(self, cik: str) -> dict[str, Any]:
        url = f"{self.sec_base_url}/submissions/CIK{cik}.json"
        return self.get(url).json()


def _generate_sec_document_url(cik: str, accession: str, primary_document: str) -> str:
    accession_no_hyphen = accession.replace("-", "")
    return f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{accession_no_hyphen}/{primary_document}"


def _parse_recent_filing_sources(submissions: dict[str, Any]) -> list[DiscoveredSource]:
    recent = submissions.get("filings", {}).get("recent", {})
    forms = recent.get("form", [])
    filing_dates = recent.get("filingDate", [])
    accessions = recent.get("accessionNumber", [])
    primary_docs = recent.get("primaryDocument", [])
    descriptions = recent.get("primaryDocDescription", [])
    report_dates = recent.get("reportDate", [])
    cik = str(submissions.get("cik", "")).strip()
    if not cik:
        return []

    cutoff = datetime.now(timezone.utc) - timedelta(days=365 * 3)
    discovered_at = _iso_now()
    sources: list[DiscoveredSource] = []

    def append_source(slot_id: str, accession: str, form: str, filing_date: str, title: str, primary_document: str) -> None:
        if not accession or not primary_document:
            return
        try:
            parsed_filing_date = datetime.strptime(filing_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            return
        if parsed_filing_date < cutoff:
            return
        sources.append(
            DiscoveredSource(
                source_id=f"{slot_id}::{accession}",
                slot_id=slot_id,
                source_type="filing",
                title=title or form,
                url=_generate_sec_document_url(cik, accession, primary_document),
                publisher="sec_edgar",
                discovered_at=discovered_at,
                published_at=filing_date,
                notes=form,
            )
        )

    for index, form in enumerate(forms):
        form_text = str(form or "").upper()
        filing_date = str(filing_dates[index] if index < len(filing_dates) else "").strip()
        accession = str(accessions[index] if index < len(accessions) else "").strip()
        primary_document = str(primary_docs[index] if index < len(primary_docs) else "").strip()
        report_date = str(report_dates[index] if index < len(report_dates) else "").strip()
        description = str(descriptions[index] if index < len(descriptions) else "").strip() or form_text
        title = description or form_text

        if form_text == "10-K":
            append_source("regulatory.annual_report_latest", accession, form_text, filing_date, title, primary_document)
            append_source("regulatory.periodic_reports_recent", accession, form_text, filing_date, title, primary_document)
        elif form_text == "10-Q":
            append_source("regulatory.periodic_reports_recent", accession, form_text, filing_date or report_date, title, primary_document)
        elif form_text in {"8-K", "6-K"}:
            append_source("regulatory.material_events_recent", accession, form_text, filing_date, title, primary_document)
        elif form_text == "DEF 14A":
            append_source("governance.proxy_or_annual_meeting_materials", accession, form_text, filing_date, title, primary_document)
        elif form_text in {"4", "13D", "13G"}:
            append_source("regulatory.ownership_or_insider_context", accession, form_text, filing_date, title, primary_document)

    return sources


class SecProvider:
    def __init__(
        self,
        *,
        user_agent: str | None = None,
        rps_limit: int = 3,
        cache_dir: str | Path | None = None,
    ):
        self.client = SECClient(
            user_agent=user_agent or os.getenv("SEC_USER_AGENT", DEFAULT_SEC_USER_AGENT),
            rps_limit=rps_limit,
            cache_dir=cache_dir,
        )

    def discover(self, ticker: str) -> list[DiscoveredSource]:
        if fixture_providers_enabled():
            return fixture_sec_sources(ticker)
        if network_access_disabled():
            return []
        try:
            cik, _company_name = self.client.resolve_ticker(ticker)
            submissions = self.client.fetch_submissions(cik)
        except Exception:
            return []
        return _parse_recent_filing_sources(submissions)
