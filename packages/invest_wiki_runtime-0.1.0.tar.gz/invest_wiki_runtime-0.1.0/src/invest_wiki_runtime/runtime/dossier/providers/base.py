from __future__ import annotations

import os
from dataclasses import dataclass

DEFAULT_HTTP_USER_AGENT = "Mozilla/5.0"
DEFAULT_SEC_USER_AGENT = "ResearchBot/1.0 (research@example.com)"


def network_access_disabled() -> bool:
    value = str(os.getenv("INVEST_WIKI_DISABLE_NETWORK", "")).strip().lower()
    return value in {"1", "true", "yes", "on"}


def fixture_providers_enabled() -> bool:
    value = str(os.getenv("INVEST_WIKI_FIXTURE_PROVIDERS", "")).strip().lower()
    return value in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class DiscoveredSource:
    source_id: str
    slot_id: str
    source_type: str
    title: str
    url: str | None
    publisher: str | None
    discovered_at: str
    published_at: str | None = None
    notes: str | None = None
    source_origin: str | None = None
    document_family: str | None = None
    document_type: str | None = None
    materialization_status: str = "pending"
    materialized_paths: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, object]:
        return {
            "source_id": self.source_id,
            "slot_id": self.slot_id,
            "source_type": self.source_type,
            "title": self.title,
            "url": self.url,
            "publisher": self.publisher,
            "discovered_at": self.discovered_at,
            "published_at": self.published_at,
            "notes": self.notes,
            "source_origin": self.source_origin,
            "document_family": self.document_family,
            "document_type": self.document_type,
            "materialization_status": self.materialization_status,
            "materialized_paths": list(self.materialized_paths),
        }
