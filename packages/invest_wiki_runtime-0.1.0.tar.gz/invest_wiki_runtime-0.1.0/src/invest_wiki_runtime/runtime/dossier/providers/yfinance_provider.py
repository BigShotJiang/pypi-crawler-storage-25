from __future__ import annotations

from collections.abc import Mapping

import yfinance as yf

from invest_wiki_runtime.runtime.dossier.providers.base import fixture_providers_enabled, network_access_disabled
from invest_wiki_runtime.runtime.dossier.providers.fixtures import fixture_snapshot


class YFinanceProvider:
    def snapshot(self, ticker: str, market: str) -> dict[str, object]:
        if fixture_providers_enabled():
            return fixture_snapshot(ticker, market)
        if network_access_disabled():
            return {}
        try:
            info = yf.Ticker(ticker).info or {}
        except Exception:
            return {}
        if not isinstance(info, Mapping):
            return {}

        company_name = self._string_value(info, "longName", "shortName", "displayName")
        currency = self._string_value(info, "currency")
        exchange = self._string_value(info, "exchange", "fullExchangeName")
        website = self._string_value(info, "website", "homepage")
        ir_website = self._string_value(info, "irWebsite", "investorRelationsWebsite")

        snapshot: dict[str, object] = {}
        if company_name:
            snapshot["company_name"] = company_name
        if currency:
            snapshot["currency"] = currency
        if exchange:
            snapshot["exchange"] = exchange
        if website:
            snapshot["website"] = website
        if ir_website:
            snapshot["irWebsite"] = ir_website
        return snapshot

    @staticmethod
    def _string_value(payload: Mapping[str, object], *keys: str) -> str:
        for key in keys:
            value = payload.get(key)
            if value is None:
                continue
            text = str(value).strip()
            if text:
                return text
        return ""
