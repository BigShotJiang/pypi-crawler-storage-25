from __future__ import annotations

from collections.abc import Mapping

from invest_wiki_runtime.runtime.dossier.providers.base import DiscoveredSource


_FIXTURE_DISCOVERED_AT = "2026-04-14T00:00:00Z"


def _fixture_company_label(ticker: str) -> str:
    labels = {
        "DEMO": "DEMO",
        "NVDA": "NVIDIA",
    }
    return labels.get(ticker.upper(), ticker.upper())


def _fixture_company_domain(ticker: str) -> str:
    domains = {
        "DEMO": "demo.example.com",
        "NVDA": "investor.nvidia.com",
    }
    return domains.get(ticker.upper(), f"{ticker.lower()}.example.com")


def fixture_snapshot(ticker: str, market: str) -> dict[str, object]:
    if str(market).strip().lower() != "us":
        return {}
    domain = _fixture_company_domain(ticker)
    company_label = _fixture_company_label(ticker)
    return {
        "company_name": company_label,
        "currency": "USD",
        "exchange": "NASDAQ",
        "website": f"https://{domain}",
        "irWebsite": f"https://investors.{domain}",
    }


def fixture_official_sources(
    ticker: str,
    market: str,
    *,
    company_name: str | None = None,
    snapshot: Mapping[str, object] | None = None,
) -> list[DiscoveredSource]:
    if str(market).strip().lower() != "us":
        return []
    snapshot_payload = dict(snapshot) if isinstance(snapshot, Mapping) else fixture_snapshot(ticker, market)
    company_label = str(company_name or snapshot_payload.get("company_name") or _fixture_company_label(ticker)).strip() or ticker
    homepage = str(snapshot_payload.get("website") or "").strip()
    ir_homepage = str(snapshot_payload.get("irWebsite") or "").strip()

    sources: list[DiscoveredSource] = []
    if homepage:
        sources.append(
            DiscoveredSource(
                source_id="official-company-homepage",
                slot_id="official.company_homepage",
                source_type="official_web",
                title=f"{company_label} homepage",
                url=homepage,
                publisher="company",
                discovered_at=_FIXTURE_DISCOVERED_AT,
                source_origin="fixture",
            )
        )
    if ir_homepage:
        sources.append(
            DiscoveredSource(
                source_id="official-ir-homepage",
                slot_id="official.ir_homepage_or_newsroom",
                source_type="official_web",
                title=f"{company_label} investor relations",
                url=ir_homepage,
                publisher="company",
                discovered_at=_FIXTURE_DISCOVERED_AT,
                source_origin="fixture",
            )
        )
    return sources


def fixture_earnings_calendar_sources(ticker: str) -> list[DiscoveredSource]:
    normalized_ticker = ticker.upper()
    return [
        DiscoveredSource(
            source_id="events-earnings-calendar",
            slot_id="events.earnings_calendar_or_results_date",
            source_type="earnings_calendar",
            title=f"{normalized_ticker} earnings calendar",
            url=f"https://finance.yahoo.com/quote/{normalized_ticker}",
            publisher="yfinance",
            discovered_at=_FIXTURE_DISCOVERED_AT,
            published_at="2026-05-28",
            notes="fixture earnings calendar snapshot",
            source_origin="fixture",
        )
    ]


def fixture_sec_sources(ticker: str) -> list[DiscoveredSource]:
    normalized_ticker = ticker.upper()
    filings: list[tuple[str, str, str, str, str, str]] = [
        (
            "regulatory.annual_report_latest",
            "regulatory-annual-report-latest-2026-10k",
            "filing",
            f"{normalized_ticker} 10-K annual report",
            "https://www.sec.gov/Archives/edgar/data/1045810/annual-10k.htm",
            "2026-02-21",
        ),
        (
            "regulatory.periodic_reports_recent",
            "regulatory-periodic-reports-recent-2026-10k",
            "filing",
            f"{normalized_ticker} 10-K annual report",
            "https://www.sec.gov/Archives/edgar/data/1045810/annual-10k.htm",
            "2026-02-21",
        ),
        (
            "regulatory.periodic_reports_recent",
            "regulatory-periodic-reports-recent-2025-q3",
            "filing",
            f"{normalized_ticker} 10-Q quarterly report (Q3)",
            "https://www.sec.gov/Archives/edgar/data/1045810/q3-10q.htm",
            "2025-11-21",
        ),
        (
            "regulatory.periodic_reports_recent",
            "regulatory-periodic-reports-recent-2025-q2",
            "filing",
            f"{normalized_ticker} 10-Q quarterly report (Q2)",
            "https://www.sec.gov/Archives/edgar/data/1045810/q2-10q.htm",
            "2025-08-21",
        ),
        (
            "regulatory.material_events_recent",
            "regulatory-material-events-recent-2026-8k",
            "filing",
            f"{normalized_ticker} 8-K earnings release",
            "https://www.sec.gov/Archives/edgar/data/1045810/earnings-8k.htm",
            "2026-05-28",
        ),
        (
            "governance.proxy_or_annual_meeting_materials",
            "governance-proxy-or-annual-meeting-materials-2026-def14a",
            "filing",
            f"{normalized_ticker} DEF 14A proxy statement",
            "https://www.sec.gov/Archives/edgar/data/1045810/proxy-def14a.htm",
            "2026-03-30",
        ),
        (
            "regulatory.ownership_or_insider_context",
            "regulatory-ownership-or-insider-context-2026-form4",
            "filing",
            f"{normalized_ticker} Form 4 insider filing",
            "https://www.sec.gov/Archives/edgar/data/1045810/form4.htm",
            "2026-04-02",
        ),
    ]
    return [
        DiscoveredSource(
            source_id=source_id,
            slot_id=slot_id,
            source_type=source_type,
            title=title,
            url=url,
            publisher="sec_edgar",
            discovered_at=_FIXTURE_DISCOVERED_AT,
            published_at=published_at,
            notes=title.split()[-1],
            source_origin="fixture",
        )
        for slot_id, source_id, source_type, title, url, published_at in filings
    ]
