from __future__ import annotations

from datetime import datetime, timezone
import math
from typing import Any

import yfinance as yf

from invest_wiki_runtime.runtime.dossier.providers.base import DiscoveredSource, fixture_providers_enabled, network_access_disabled
from invest_wiki_runtime.runtime.dossier.providers.fixtures import fixture_earnings_calendar_sources


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _to_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(parsed):
        return None
    return parsed


def _to_iso_date(value: Any) -> str | None:
    if value is None:
        return None
    if hasattr(value, "to_pydatetime"):
        value = value.to_pydatetime()
    if isinstance(value, datetime):
        return value.date().isoformat()
    if hasattr(value, "strftime"):
        try:
            return value.strftime("%Y-%m-%d")
        except Exception:
            return None
    text = str(value).strip()
    if not text:
        return None
    if len(text) >= 10:
        return text[:10]
    return None


def _extract_calendar_dates(calendar: Any) -> list[str]:
    dates: list[str] = []
    if calendar is None:
        return dates

    raw_dates = None
    if hasattr(calendar, "get"):
        raw_dates = calendar.get("Earnings Date")
    elif hasattr(calendar, "loc"):
        try:
            raw_dates = calendar.loc["Earnings Date"]
        except Exception:
            raw_dates = None

    if raw_dates is None:
        return dates

    if isinstance(raw_dates, (list, tuple)):
        values = raw_dates
    elif hasattr(raw_dates, "tolist"):
        try:
            values = raw_dates.tolist()
        except Exception:
            values = [raw_dates]
    else:
        values = [raw_dates]

    for item in values:
        iso_date = _to_iso_date(item)
        if iso_date and iso_date not in dates:
            dates.append(iso_date)
    return dates


def _extract_calendar_value(calendar: Any, key: str) -> float | None:
    if calendar is None:
        return None

    raw_value = None
    if hasattr(calendar, "get"):
        raw_value = calendar.get(key)
    elif hasattr(calendar, "loc"):
        try:
            raw_value = calendar.loc[key]
        except Exception:
            raw_value = None

    if hasattr(raw_value, "tolist"):
        try:
            values = raw_value.tolist()
        except Exception:
            values = [raw_value]
        if isinstance(values, list):
            for item in values:
                parsed = _to_float(item)
                if parsed is not None:
                    return parsed
            return None

    return _to_float(raw_value)


def _extract_history(earnings_dates: Any) -> list[dict[str, Any]]:
    if earnings_dates is None or not hasattr(earnings_dates, "iterrows"):
        return []

    history: list[dict[str, Any]] = []
    for index, row in earnings_dates.iterrows():
        earnings_date = _to_iso_date(index)
        if not earnings_date:
            continue
        history.append(
            {
                "earnings_date": earnings_date,
                "eps_estimate": _to_float(row.get("EPS Estimate")),
                "reported_eps": _to_float(row.get("Reported EPS")),
                "surprise_percent": _to_float(row.get("Surprise(%)")),
            }
        )

    history.sort(key=lambda item: item["earnings_date"], reverse=True)
    return history


def build_earnings_calendar(yf_ticker: Any) -> dict[str, Any] | None:
    try:
        calendar = yf_ticker.calendar
    except Exception:
        calendar = None

    try:
        earnings_dates = yf_ticker.earnings_dates
    except Exception:
        earnings_dates = None

    calendar_dates = _extract_calendar_dates(calendar)
    history = _extract_history(earnings_dates)

    next_earnings_date = calendar_dates[0] if calendar_dates else (history[0]["earnings_date"] if history else None)
    window_start = calendar_dates[0] if calendar_dates else next_earnings_date
    window_end = calendar_dates[1] if len(calendar_dates) > 1 else next_earnings_date

    if not next_earnings_date and not history:
        return None

    return {
        "provider": "yfinance",
        "fetched_at": _iso_now(),
        "next_earnings_date": next_earnings_date,
        "earnings_time_hint": "unknown",
        "earnings_window_start": window_start,
        "earnings_window_end": window_end,
        "eps_high": _extract_calendar_value(calendar, "Earnings High"),
        "eps_low": _extract_calendar_value(calendar, "Earnings Low"),
        "eps_average": _extract_calendar_value(calendar, "Earnings Average"),
        "revenue_high": _extract_calendar_value(calendar, "Revenue High"),
        "revenue_low": _extract_calendar_value(calendar, "Revenue Low"),
        "revenue_average": _extract_calendar_value(calendar, "Revenue Average"),
        "history": history,
    }


class EarningsCalendarProvider:
    def discover(self, ticker: str) -> list[DiscoveredSource]:
        if fixture_providers_enabled():
            return fixture_earnings_calendar_sources(ticker)
        if network_access_disabled():
            return []
        try:
            calendar = build_earnings_calendar(yf.Ticker(ticker))
        except Exception:
            return []
        if not isinstance(calendar, dict):
            return []

        published_at = (
            str(calendar.get("next_earnings_date", "")).strip()
            or str(calendar.get("earnings_window_start", "")).strip()
            or str(calendar.get("earnings_window_end", "")).strip()
            or None
        )
        return [
            DiscoveredSource(
                source_id="events-earnings-calendar",
                slot_id="events.earnings_calendar_or_results_date",
                source_type="earnings_calendar",
                title=f"{ticker} earnings calendar",
                url=f"https://finance.yahoo.com/quote/{ticker}",
                publisher=str(calendar.get("provider") or "yfinance"),
                discovered_at=_iso_now(),
                published_at=published_at,
                notes="yfinance earnings calendar snapshot",
            )
        ]
