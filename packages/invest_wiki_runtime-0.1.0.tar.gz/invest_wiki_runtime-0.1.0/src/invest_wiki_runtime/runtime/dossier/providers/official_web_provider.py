from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime, timezone
from urllib.parse import urlparse, urlunparse

import requests

from invest_wiki_runtime.runtime.dossier.providers.base import DiscoveredSource, fixture_providers_enabled, network_access_disabled
from invest_wiki_runtime.runtime.dossier.providers.fixtures import fixture_official_sources


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _extract_info_value(payload: Mapping[str, object] | None, *keys: str) -> str | None:
    if not isinstance(payload, Mapping):
        return None
    for key in keys:
        raw_value = payload.get(key)
        if isinstance(raw_value, Mapping):
            raw_value = raw_value.get("value", raw_value.get("url", raw_value.get("href")))
        if raw_value is None:
            continue
        text = str(raw_value).strip()
        if text:
            return text
    return None


def _canonicalize_http_url(value: str | None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if "://" not in text:
        text = f"https://{text}"
    parsed = urlparse(text)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None
    if parsed.scheme == "http":
        parsed = parsed._replace(scheme="https")
    return urlunparse(parsed)


def _derive_newsroom_url(website: str | None) -> str | None:
    canonical = _canonicalize_http_url(website)
    if canonical is None:
        return None
    parsed = urlparse(canonical)
    base_path = parsed.path.rstrip("/")
    newsroom_path = f"{base_path}/newsroom/" if base_path else "/newsroom/"
    return urlunparse(parsed._replace(path=newsroom_path, params="", query="", fragment=""))


def _derive_investors_url(website: str | None) -> str | None:
    canonical = _canonicalize_http_url(website)
    if canonical is None:
        return None
    parsed = urlparse(canonical)
    base_path = parsed.path.rstrip("/")
    investors_path = f"{base_path}/investors/" if base_path else "/investors/"
    return urlunparse(parsed._replace(path=investors_path, params="", query="", fragment=""))


def _derive_investor_subdomain_url(website: str | None, subdomain: str) -> str | None:
    canonical = _canonicalize_http_url(website)
    if canonical is None:
        return None
    parsed = urlparse(canonical)
    hostname = (parsed.hostname or "").strip()
    if hostname.startswith("www."):
        hostname = hostname[4:]
    if not hostname:
        return None
    netloc = f"{subdomain}.{hostname}"
    if parsed.port:
        netloc = f"{netloc}:{parsed.port}"
    return urlunparse(parsed._replace(netloc=netloc, path="/", params="", query="", fragment=""))


def _url_is_reachable(url: str) -> bool:
    try:
        response = requests.get(
            url,
            timeout=15,
            headers={"User-Agent": "Mozilla/5.0"},
            allow_redirects=True,
        )
        return response.status_code < 400
    except Exception:
        return False


def _resolve_preferred_ir_or_newsroom_url(ir_website: str | None, website: str | None) -> str | None:
    candidates: list[str] = []
    for candidate in (
        _canonicalize_http_url(ir_website),
        _derive_investors_url(website),
        _derive_newsroom_url(website),
        _derive_investor_subdomain_url(website, "ir"),
        _derive_investor_subdomain_url(website, "investors"),
    ):
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    if not candidates:
        return None
    for candidate in candidates:
        if _url_is_reachable(candidate):
            return candidate
    return candidates[0]


class OfficialWebProvider:
    def discover(
        self,
        ticker: str,
        market: str,
        *,
        company_name: str | None = None,
        snapshot: Mapping[str, object] | None = None,
    ) -> list[DiscoveredSource]:
        if fixture_providers_enabled():
            return fixture_official_sources(
                ticker,
                market,
                company_name=company_name,
                snapshot=snapshot,
            )
        if network_access_disabled():
            return []
        if str(market).strip().lower() != "us":
            return []

        company_label = str(company_name or ticker).strip() or ticker
        homepage = _canonicalize_http_url(_extract_info_value(snapshot, "website", "homepage"))
        investor_relations = _resolve_preferred_ir_or_newsroom_url(
            _extract_info_value(snapshot, "irWebsite", "investorRelationsWebsite"),
            homepage,
        )

        discovered_at = _iso_now()
        sources: list[DiscoveredSource] = []
        if homepage:
            sources.append(
                DiscoveredSource(
                    source_id="official-company-homepage",
                    slot_id="official.company_homepage",
                    source_type="official_web",
                    title=f"{company_label} homepage",
                    url=homepage,
                    publisher="company",
                    discovered_at=discovered_at,
                )
            )
        if investor_relations:
            sources.append(
                DiscoveredSource(
                    source_id="official-ir-homepage",
                    slot_id="official.ir_homepage_or_newsroom",
                    source_type="official_web",
                    title=f"{company_label} investor relations",
                    url=investor_relations,
                    publisher="company",
                    discovered_at=discovered_at,
                )
            )
        return sources
