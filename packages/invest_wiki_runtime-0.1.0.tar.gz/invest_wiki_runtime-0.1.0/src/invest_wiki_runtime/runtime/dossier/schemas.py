from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from invest_wiki_runtime.runtime.dossier.registry import compute_registry_summary


_ARCHIVE_KEYS = {
    "version",
    "company",
    "run_info",
    "config_snapshot",
    "identity",
    "financials",
    "market_data",
    "people",
    "estimates",
    "text_extracts",
    "earnings_calendar",
    "call_records",
    "filings",
    "sources",
}


def _require_mapping(payload: object, label: str) -> dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} must be a mapping")
    return dict(payload)


def _require_keys(payload: dict[str, Any], keys: set[str], label: str) -> None:
    missing = sorted(key for key in keys if key not in payload)
    if missing:
        raise ValueError(f"{label} missing keys: {', '.join(missing)}")


def _require_company(payload: object, label: str, required_fields: set[str]) -> dict[str, Any]:
    company = _require_mapping(payload, label)
    missing = sorted(key for key in required_fields if key not in company)
    if missing:
        raise ValueError(f"{label} missing required fields: {', '.join(missing)}")
    return company


def _require_non_empty_text(payload: dict[str, Any], key: str, label: str) -> str:
    value = str(payload[key]).strip()
    if not value:
        raise ValueError(f"{label}.{key} is required")
    return value


def _require_list(payload: dict[str, Any], key: str, label: str) -> list[Any]:
    value = payload.get(key)
    if not isinstance(value, list):
        raise ValueError(f"{label}.{key} must be a list")
    return list(value)


def _require_int(payload: dict[str, Any], key: str, label: str) -> int:
    value = payload.get(key)
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label}.{key} must be an integer") from exc


def _validate_registry_slot(payload: object, index: int) -> dict[str, Any]:
    slot = _require_mapping(payload, f"registry.slots[{index}]")
    for key in (
        "slot_id",
        "title",
        "tier",
        "blocking_level",
        "market_scope",
        "cardinality",
    ):
        slot[key] = _require_non_empty_text(slot, key, f"registry.slots[{index}]")
    slot["expected_min"] = _require_int(slot, "expected_min", f"registry.slots[{index}]")
    if slot["expected_min"] < 0:
        raise ValueError(f"registry.slots[{index}].expected_min must be >= 0")
    slot["module_dependencies"] = _require_list(slot, "module_dependencies", f"registry.slots[{index}]")
    slot["accepts"] = _require_list(slot, "accepts", f"registry.slots[{index}]")
    if "source_hints" in slot:
        slot["source_hints"] = _require_list(slot, "source_hints", f"registry.slots[{index}]")
    if "status" in slot:
        slot["status"] = _require_non_empty_text(slot, "status", f"registry.slots[{index}]")
    if "freshness_status" in slot:
        slot["freshness_status"] = _require_non_empty_text(slot, "freshness_status", f"registry.slots[{index}]")
    if "gap_reason" in slot:
        slot["gap_reason"] = str(slot.get("gap_reason", ""))
    if "found_count" in slot:
        slot["found_count"] = _require_int(slot, "found_count", f"registry.slots[{index}]")
    if "materialized_count" in slot:
        slot["materialized_count"] = _require_int(slot, "materialized_count", f"registry.slots[{index}]")
    if "sources" in slot:
        slot["sources"] = _require_list(slot, "sources", f"registry.slots[{index}]")
    if "materializations" in slot:
        slot["materializations"] = _require_list(slot, "materializations", f"registry.slots[{index}]")
    if slot.get("status") == "materialized":
        expected_min = int(slot["expected_min"])
        slot["found_count"] = max(int(slot.get("found_count", 0) or 0), expected_min)
        slot["materialized_count"] = max(int(slot.get("materialized_count", 0) or 0), expected_min)
    return slot


def validate_dossier_archive(payload: Mapping[str, Any]) -> dict[str, Any]:
    archive = _require_mapping(payload, "archive")
    _require_keys(archive, _ARCHIVE_KEYS, "archive")
    archive["company"] = _require_company(
        archive["company"],
        "archive.company",
        {"ticker", "company_name", "market"},
    )
    archive["company"]["ticker"] = _require_non_empty_text(archive["company"], "ticker", "archive.company")
    archive["company"]["company_name"] = _require_non_empty_text(archive["company"], "company_name", "archive.company")
    archive["company"]["market"] = _require_non_empty_text(archive["company"], "market", "archive.company")
    if not isinstance(archive["call_records"], list):
        raise ValueError("archive.call_records must be a list")
    if not isinstance(archive["filings"], list):
        raise ValueError("archive.filings must be a list")
    if not isinstance(archive["sources"], (list, Mapping)):
        raise ValueError("archive.sources must be a list or mapping")
    return archive


def validate_dossier_registry(payload: Mapping[str, Any]) -> dict[str, Any]:
    registry = _require_mapping(payload, "registry")
    _require_keys(
        registry,
        {"registry_version", "template_id", "template_version", "company", "summary", "slots"},
        "registry",
    )
    registry["registry_version"] = _require_non_empty_text(registry, "registry_version", "registry")
    registry["template_id"] = _require_non_empty_text(registry, "template_id", "registry")
    registry["template_version"] = _require_non_empty_text(registry, "template_version", "registry")
    registry["company"] = _require_company(registry["company"], "registry.company", {"ticker", "market"})
    registry["company"]["ticker"] = _require_non_empty_text(registry["company"], "ticker", "registry.company")
    registry["company"]["market"] = _require_non_empty_text(registry["company"], "market", "registry.company")
    if not isinstance(registry["summary"], Mapping):
        raise ValueError("registry.summary must be a mapping")
    registry["summary"] = dict(registry["summary"])
    _require_keys(
        registry["summary"],
        {
            "slots_total",
            "required_total",
            "hard_blocking_missing",
            "soft_blocking_missing",
            "coverage_score",
        },
        "registry.summary",
    )
    if not isinstance(registry["slots"], list):
        raise ValueError("registry.slots must be a list")
    registry["slots"] = [_validate_registry_slot(slot, index) for index, slot in enumerate(registry["slots"])]
    registry["summary"] = compute_registry_summary(registry["slots"])
    return registry


def validate_dossier_report(payload: Mapping[str, Any]) -> dict[str, Any]:
    report = _require_mapping(payload, "report")
    _require_keys(report, {"status", "module", "ticker", "run_id"}, "report")
    status = str(report["status"]).strip().lower()
    if not status:
        raise ValueError("report.status is required")
    report["status"] = status
    report["module"] = _require_non_empty_text(report, "module", "report")
    report["ticker"] = _require_non_empty_text(report, "ticker", "report")
    report["run_id"] = _require_non_empty_text(report, "run_id", "report")
    if status == "failed" and not str(report.get("error", "")).strip():
        raise ValueError("report.error is required when status is failed")
    if status == "ok":
        report_payload = _require_mapping(report.get("payload"), "report.payload")
        _require_keys(
            report_payload,
            {
                "archive_ticker",
                "company_name",
                "actions_run",
                "actions_skipped",
                "decision_reason",
                "artifacts",
                "summary",
                "warnings",
            },
            "report.payload",
        )
        for field in ("actions_run", "actions_skipped", "artifacts", "warnings"):
            if not isinstance(report_payload[field], list):
                raise ValueError(f"report.payload.{field} must be a list")
        if not isinstance(report_payload["summary"], Mapping):
            raise ValueError("report.payload.summary must be a mapping")
        report_payload["summary"] = dict(report_payload["summary"])
        _require_keys(
            report_payload["summary"],
            {
                "slots_total",
                "hard_blocking_missing",
                "soft_blocking_missing",
                "coverage_score",
            },
            "report.payload.summary",
        )
        report["payload"] = report_payload
    if "error" in report:
        report["error"] = str(report["error"])
    return report
