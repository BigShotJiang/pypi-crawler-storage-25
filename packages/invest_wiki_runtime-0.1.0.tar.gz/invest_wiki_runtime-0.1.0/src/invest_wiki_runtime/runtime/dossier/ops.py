from __future__ import annotations

from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.log_render import append_and_render_dossier_log
from invest_wiki_runtime.runtime.paths import company_root, dossier_root, normalize_ticker
from invest_wiki_runtime.runtime.result_contract import ok


def _relative(root: Path, path: Path) -> str:
    root_resolved = root.resolve()
    path_resolved = path.resolve()
    try:
        return path_resolved.relative_to(root_resolved).as_posix()
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def _assert_within_root(root: Path, path: Path) -> None:
    root_resolved = root.resolve()
    path_resolved = path.resolve(strict=False)
    try:
        path_resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def _assert_paths_within_root(root: Path, paths: list[Path]) -> None:
    for path in paths:
        _assert_within_root(root, path)


def _is_bootstrapped_dossier(dossier: Path, company: Path) -> bool:
    required_paths = (
        company / "basic.json",
        company / "calendar.json",
        dossier / "index.md",
        dossier / "raw",
        dossier / "wiki" / "sources",
        dossier / "wiki" / "events",
        dossier / "wiki" / "rollups",
        dossier / "wiki" / "queries",
    )
    return all(path.exists() for path in required_paths)


def log(root: str | Path, ticker: str, payload: dict[str, Any]) -> dict[str, Any]:
    root_path = Path(root)
    company = company_root(root_path, ticker)
    dossier = dossier_root(root_path, ticker)
    log_jsonl = dossier / "log.jsonl"
    log_md = dossier / "log.md"
    _assert_paths_within_root(root_path, [company, dossier, log_jsonl, log_md])
    if not _is_bootstrapped_dossier(dossier, company):
        raise ValueError("workspace is not bootstrapped")
    append_and_render_dossier_log(log_jsonl, log_md, payload)
    return ok(
        "dossier",
        "log",
        normalize_ticker(ticker),
        changed=[
            _relative(root_path, log_jsonl),
            _relative(root_path, log_md),
        ],
    )
