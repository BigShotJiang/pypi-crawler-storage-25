from __future__ import annotations

from pathlib import Path

from invest_wiki_runtime.runtime.paths import company_root, dossier_root, normalize_ticker


def dossier_dir(root: str | Path, ticker: str) -> Path:
    return dossier_root(root, normalize_ticker(ticker))


def dossier_archive_path(root: str | Path, ticker: str) -> Path:
    return dossier_dir(root, ticker) / "archive.json"


def dossier_registry_path(root: str | Path, ticker: str) -> Path:
    return dossier_dir(root, ticker) / "source_registry.json"


def dossier_overview_path(root: str | Path, ticker: str) -> Path:
    return dossier_dir(root, ticker) / "dossier.md"


def dossier_index_path(root: str | Path, ticker: str) -> Path:
    return dossier_dir(root, ticker) / "index.md"


def dossier_log_markdown_path(root: str | Path, ticker: str) -> Path:
    return dossier_dir(root, ticker) / "log.md"


def dossier_log_jsonl_path(root: str | Path, ticker: str) -> Path:
    return dossier_dir(root, ticker) / "log.jsonl"


def dossier_raw_dir(root: str | Path, ticker: str) -> Path:
    return dossier_dir(root, ticker) / "raw"
