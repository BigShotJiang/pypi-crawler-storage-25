from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.dossier.discover import discover_dossier
from invest_wiki_runtime.runtime.dossier.materialize import materialize_dossier
from invest_wiki_runtime.runtime.dossier.render import render_dossier
from invest_wiki_runtime.runtime.dossier.report import dossier_failed_report, dossier_success_report
from invest_wiki_runtime.runtime.dossier.registry import suggest_actions
from invest_wiki_runtime.runtime.dossier.validate import validate_dossier
from invest_wiki_runtime.runtime.dossier.workspace import (
    company_name,
    dossier_paths,
    load_or_build_registry,
    materialize_artifacts_exist,
    render_outputs_are_current,
    resolve_market,
    summary_from_registry,
)
from invest_wiki_runtime.runtime.paths import normalize_ticker


_PIPELINE_ACTIONS = ["discover", "materialize", "enrich", "render", "validate"]


def _suggested_actions_with_materialize(
    suggested_actions: list[str],
    *,
    paths: dict[str, Path],
) -> list[str]:
    actions = list(suggested_actions)
    if materialize_artifacts_exist(paths) or "materialize" in actions:
        return actions

    if "render" in actions:
        insert_at = actions.index("render")
    elif "validate" in actions:
        insert_at = actions.index("validate")
    else:
        insert_at = len(actions)
    actions.insert(insert_at, "materialize")
    return actions


def _run_id() -> str:
    return datetime.now(timezone.utc).strftime("dossier-%Y%m%dT%H%M%SZ")


def inspect(root: Path, ticker: str) -> dict[str, Any]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    resolved_market = resolve_market(paths, normalized_ticker)
    registry = load_or_build_registry(root_path, normalized_ticker, paths, resolved_market)
    archive_exists = paths["archive"].exists()
    overview_exists = paths["overview"].exists()
    registry_exists = paths["registry"].exists()
    render_outputs_current = archive_exists and registry_exists and render_outputs_are_current(paths)
    return {
        "ticker": normalized_ticker,
        "company_name": company_name(paths, normalized_ticker),
        "archive_exists": archive_exists,
        "overview_exists": overview_exists,
        "registry_exists": registry_exists,
        "suggested_actions": _suggested_actions_with_materialize(
            suggest_actions(
                registry,
                archive_exists=archive_exists,
                overview_exists=render_outputs_current,
            ),
            paths=paths,
        ),
        "summary": summary_from_registry(registry),
    }


def discover(root: Path, ticker: str) -> dict[str, Any]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    return discover_dossier(root_path, normalized_ticker, resolve_market(paths, normalized_ticker))


def materialize(root: Path, ticker: str) -> dict[str, Any]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    return materialize_dossier(root_path, normalized_ticker, resolve_market(paths, normalized_ticker))


def enrich(root: Path, ticker: str) -> dict[str, Any]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    registry = load_or_build_registry(
        root_path,
        normalized_ticker,
        paths,
        resolve_market(paths, normalized_ticker),
    )
    return {
        "changed": [],
        "artifacts": [],
        "summary": summary_from_registry(registry),
        "warnings": [],
    }


def render(root: Path, ticker: str) -> dict[str, Any]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    return render_dossier(root_path, normalized_ticker)


def validate(root: Path, ticker: str) -> dict[str, Any]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    return validate_dossier(root_path, normalized_ticker, resolve_market(paths, normalized_ticker))


def run(root: Path, ticker: str) -> dict[str, Any]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    run_id = _run_id()
    actions_run = ["inspect"]
    artifacts: list[str] = []
    warnings: list[str] = []
    inspect_result = inspect(root_path, normalized_ticker)
    suggested = list(inspect_result["suggested_actions"])
    actions_skipped = [action for action in _PIPELINE_ACTIONS if action not in suggested]
    decision_reason = "inspect suggested " + " -> ".join(suggested)
    summary = dict(inspect_result["summary"])
    current_company_name = str(inspect_result.get("company_name", "")).strip()
    stage_handlers = {
        "discover": discover,
        "materialize": materialize,
        "enrich": enrich,
        "render": render,
        "validate": validate,
    }

    try:
        for action in _PIPELINE_ACTIONS:
            if action not in suggested:
                continue
            stage_result = stage_handlers[action](root_path, normalized_ticker)
            actions_run.append(action)
            for artifact in stage_result.get("artifacts", []):
                if artifact not in artifacts:
                    artifacts.append(artifact)
            for warning in stage_result.get("warnings", []):
                if warning not in warnings:
                    warnings.append(warning)
            summary = dict(stage_result.get("summary", summary))

        final_inspect = inspect(root_path, normalized_ticker)
        summary = dict(final_inspect["summary"])
        current_company_name = str(final_inspect.get("company_name", "")).strip()
        return dossier_success_report(
            normalized_ticker,
            run_id,
            actions_run=actions_run,
            actions_skipped=actions_skipped,
            artifacts=artifacts,
            summary=summary,
            company_name=current_company_name,
            warnings=warnings,
            decision_reason=decision_reason,
        )
    except Exception as exc:
        return dossier_failed_report(
            normalized_ticker,
            run_id,
            str(exc),
            actions_run=actions_run,
            actions_skipped=actions_skipped,
            artifacts=artifacts,
            summary=summary,
            company_name=current_company_name,
            warnings=warnings,
            decision_reason=decision_reason,
        )
