from __future__ import annotations

from pathlib import Path

from invest_wiki_runtime.runtime.dossier.load import load_dossier_archive, load_dossier_registry
from invest_wiki_runtime.runtime.dossier.log_render import read_dossier_log_events
from invest_wiki_runtime.runtime.dossier.workspace import dossier_paths, relative, summary_from_registry
from invest_wiki_runtime.runtime.paths import normalize_ticker


def validate_dossier(root: Path, ticker: str, market: str) -> dict[str, object]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    paths = dossier_paths(root_path, normalized_ticker)
    _ = market

    if paths["log_jsonl"].exists():
        read_dossier_log_events(paths["log_jsonl"])

    required = (
        paths["basic"],
        paths["calendar"],
        paths["archive"],
        paths["registry"],
        paths["overview"],
        paths["index"],
        paths["raw"],
        paths["wiki_sources"],
        paths["wiki_events"],
        paths["wiki_rollups"],
        paths["wiki_queries"],
        paths["materialization_report_json"],
        paths["materialization_report_md"],
        paths["log_jsonl"],
        paths["log_md"],
    )
    missing = [path for path in required if not path.exists()]
    if missing:
        missing_paths = ", ".join(relative(root_path, path) for path in missing)
        raise ValueError(f"missing dossier artifacts: {missing_paths}")

    load_dossier_archive(root_path, normalized_ticker)
    registry = load_dossier_registry(root_path, normalized_ticker)
    return {
        "changed": [],
        "artifacts": [relative(root_path, path) for path in required],
        "summary": summary_from_registry(registry),
    }
