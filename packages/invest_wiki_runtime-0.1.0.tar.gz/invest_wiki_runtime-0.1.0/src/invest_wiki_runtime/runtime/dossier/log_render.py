from __future__ import annotations

import json
from datetime import datetime, timezone
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.markdown_contracts import render_dossier_log


def read_dossier_log_events(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    events: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        events.append(json.loads(line))
    return events


def _normalize_paths(paths: object) -> list[str]:
    if paths is None:
        return []
    if isinstance(paths, (str, bytes)):
        return [str(paths)]
    if isinstance(paths, Sequence):
        return [str(path) for path in paths]
    return [str(paths)]


def _normalize_event(payload: Mapping[str, Any], event_no: int) -> dict[str, Any]:
    ts_value = payload.get("ts")
    if ts_value is None or str(ts_value).strip() == "":
        ts_value = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    event = {
        "event_no": event_no,
        "event_type": str(payload.get("event_type", "unknown")),
        "run_id": str(payload.get("run_id", "unknown")),
        "summary": str(payload.get("summary", "")),
        "paths": _normalize_paths(payload.get("paths")),
        "ts": str(ts_value),
    }
    for key in sorted(payload):
        if key in {"event_type", "run_id", "summary", "paths", "ts"}:
            continue
        event[key] = payload[key]
    return event


def append_and_render_dossier_log(log_jsonl: Path, log_md: Path, payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    log_jsonl.parent.mkdir(parents=True, exist_ok=True)
    events = read_dossier_log_events(log_jsonl)
    events.append(_normalize_event(payload, len(events) + 1))
    log_jsonl.write_text(
        "\n".join(json.dumps(event, ensure_ascii=False) for event in events) + "\n",
        encoding="utf-8",
    )
    log_md.write_text(render_dossier_log(events), encoding="utf-8")
    return events


def render_existing_dossier_log(log_jsonl: Path, log_md: Path) -> list[dict[str, Any]]:
    events = read_dossier_log_events(log_jsonl)
    log_md.write_text(render_dossier_log(events), encoding="utf-8")
    return events
