from __future__ import annotations

from collections.abc import Sequence
from typing import Any


def render_dossier_index(ticker: str) -> str:
    ticker = ticker.strip().upper()
    return (
        "# Dossier Index\n\n"
        f"- ticker: `{ticker}`\n"
        "- tree:\n"
        "  - `basic.json`\n"
        "  - `calendar.json`\n"
        "  - `dossier/wiki/`\n"
        "  - `dossier/raw/`\n"
        "  - `dossier/materialization-report.md`\n"
        "  - `dossier/materialization-report.json`\n"
        "  - `dossier/log.md`\n"
    )


def render_dossier_log(events: Sequence[dict[str, Any]]) -> str:
    lines = ["# Dossier Log", ""]
    if not events:
        lines.append("No structured events yet.")
        return "\n".join(lines).rstrip() + "\n"

    for event in events:
        lines.append(f"## Event {event.get('event_no', '?')} · {event.get('event_type', 'unknown')}")
        lines.append(f"- ts: `{event.get('ts', '1970-01-01T00:00:00Z')}`")
        lines.append(f"- run_id: `{event.get('run_id', 'unknown')}`")
        lines.append(f"- summary: {event.get('summary', '')}")
        paths = event.get("paths", [])
        if paths:
            lines.append("- paths:")
            for path in paths:
                lines.append(f"  - `{path}`")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"
