from __future__ import annotations

import os
import sys
from pathlib import Path


def _runtime_home() -> Path:
    override = str(os.getenv("INVEST_WIKI_RUNTIME_HOME", "")).strip()
    if override:
        return Path(override).expanduser()
    xdg_data_home = str(os.getenv("XDG_DATA_HOME", "")).strip()
    data_home = Path(xdg_data_home).expanduser() if xdg_data_home else Path.home() / ".local" / "share"
    return data_home / "invest-llm-wiki"


def _venv_python(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def managed_python_candidates() -> list[Path]:
    candidates: list[Path] = []
    explicit = str(os.getenv("INVEST_WIKI_PYTHON", "")).strip()
    if explicit:
        candidates.append(Path(explicit).expanduser())

    releases_root = _runtime_home() / "releases"
    if releases_root.is_dir():
        for release_dir in sorted(releases_root.iterdir(), reverse=True):
            if release_dir.is_dir():
                candidates.append(_venv_python(release_dir / "venv"))
    return candidates


def resolve_runtime_python() -> str:
    for candidate in managed_python_candidates():
        if candidate.exists():
            return str(candidate)
    return sys.executable
