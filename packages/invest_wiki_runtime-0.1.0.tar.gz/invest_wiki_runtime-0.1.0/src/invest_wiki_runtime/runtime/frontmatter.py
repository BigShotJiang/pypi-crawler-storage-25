from __future__ import annotations

from collections.abc import Mapping, Sequence


def _validate_scalar_text(value: str) -> None:
    if "\n" in value or "\r" in value:
        raise ValueError("frontmatter scalar values must be single-line")
    if "---" in value:
        raise ValueError("frontmatter scalar values must not contain '---'")


def _render_scalar(value: object) -> str:
    if isinstance(value, bool):
        rendered = "true" if value else "false"
        _validate_scalar_text(rendered)
        return rendered
    if value is None:
        return ""
    rendered = str(value)
    _validate_scalar_text(rendered)
    return rendered


def render_frontmatter(fields: Mapping[str, object]) -> str:
    lines = ["---"]
    for key, value in fields.items():
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            lines.append(f"{key}:")
            for item in value:
                lines.append(f"  - {_render_scalar(item)}")
            continue
        lines.append(f"{key}: {_render_scalar(value)}")
    lines.append("---")
    return "\n".join(lines)
