from __future__ import annotations

import json
from datetime import date
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.paths import company_root, normalize_ticker


def _relative(root: Path, path: Path) -> str:
    root_resolved = root.resolve()
    path_resolved = path.resolve()
    try:
        return path_resolved.relative_to(root_resolved).as_posix()
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def _write_text_if_changed(path: Path, content: str) -> bool:
    if path.exists() and path.read_text(encoding="utf-8") == content:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True


def _assert_within_root(root: Path, path: Path) -> None:
    root_resolved = root.resolve()
    resolved_target = path.resolve(strict=False)
    try:
        resolved_target.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def _render_markdown_report(stamp: str, ticker: str, findings: list[dict[str, str]]) -> str:
    lines = [
        f"# Lint Report {stamp}",
        "",
        f"- ticker: `{ticker}`",
        f"- findings: {len(findings)}",
        f"- valid: {'yes' if not findings else 'no'}",
    ]
    if findings:
        lines.extend(["", "## Findings"])
        for finding in findings:
            lines.append(
                f"- `{finding['code']}`: {finding['message']} (`{finding['path']}`)"
            )
    return "\n".join(lines) + "\n"


def _render_index_report(lint_dir: Path) -> str:
    basenames: set[str] = set()
    for path in lint_dir.glob("*.md"):
        if path.name == "index.md":
            continue
        basenames.add(path.stem)
    for path in lint_dir.glob("*.json"):
        basenames.add(path.stem)

    lines = ["# Lint Reports", ""]
    if not basenames:
        lines.append("- (none)")
        return "\n".join(lines) + "\n"

    for base in sorted(basenames):
        md_name = f"{base}.md"
        json_name = f"{base}.json"
        lines.append(f"- `{md_name}` / `{json_name}`")
    return "\n".join(lines) + "\n"


def _collect_findings(root: Path, ticker: str) -> list[dict[str, str]]:
    company = company_root(root, ticker)
    checks = (
        ("missing_dossier_index", company / "dossier" / "index.md", "dossier/index.md is missing"),
        ("missing_article", company / "wiki-article.md", "wiki-article.md is missing"),
        ("missing_refs", company / "wiki-refs.json", "wiki-refs.json is missing"),
        ("missing_claims", company / "wiki-claims.jsonl", "wiki-claims.jsonl is missing"),
    )
    findings: list[dict[str, str]] = []
    for code, path, message in checks:
        if path.exists():
            continue
        findings.append(
            {
                "code": code,
                "message": message,
                "path": _relative(root, path),
            }
        )
    return findings


def run(root: str | Path, ticker: str, *, write_report: bool) -> dict[str, Any]:
    root_path = Path(root)
    normalized_ticker = normalize_ticker(ticker)
    findings = _collect_findings(root_path, normalized_ticker)
    result: dict[str, Any] = {
        "valid": not findings,
        "findings": findings,
        "changed": [],
        "artifacts": [],
    }

    if not write_report:
        return result

    stamp = date.today().isoformat()
    lint_dir = root_path / "lint"
    base_name = f"{stamp}-{normalized_ticker}"
    json_path = lint_dir / f"{base_name}.json"
    md_path = lint_dir / f"{base_name}.md"
    index_path = lint_dir / "index.md"
    for path in (lint_dir, json_path, md_path, index_path):
        _assert_within_root(root_path, path)

    report_payload = {
        "date": stamp,
        "ticker": normalized_ticker,
        "valid": result["valid"],
        "findings": findings,
    }
    json_content = json.dumps(report_payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    md_content = _render_markdown_report(stamp, normalized_ticker, findings)

    changed: list[str] = []
    for path, content in ((json_path, json_content), (md_path, md_content)):
        if _write_text_if_changed(path, content):
            changed.append(_relative(root_path, path))
    index_content = _render_index_report(lint_dir)
    if _write_text_if_changed(index_path, index_content):
        changed.append(_relative(root_path, index_path))

    result["changed"] = changed
    result["artifacts"] = [
        _relative(root_path, json_path),
        _relative(root_path, md_path),
        _relative(root_path, index_path),
    ]
    return result
