from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from invest_wiki_runtime.runtime.frontmatter import render_frontmatter
from invest_wiki_runtime.runtime.paths import dossier_root, normalize_ticker
from invest_wiki_runtime.runtime.result_contract import ok


PAGE_DIRS = {
    "source_note": "sources",
    "event": "events",
    "rollup": "rollups",
    "query": "queries",
}


def _relative(root: Path, path: Path) -> str:
    root_resolved = root.resolve()
    path_resolved = path.resolve()
    try:
        return path_resolved.relative_to(root_resolved).as_posix()
    except ValueError as exc:
        raise ValueError(f"path escapes root: {path}") from exc


def _normalize_slug(value: object) -> str:
    slug = str(value).strip().lower()
    if not slug:
        raise ValueError("slug is required")
    if slug in {".", ".."}:
        raise ValueError("slug contains invalid path components")
    if any(separator in slug for separator in {"/", "\\", os.sep, os.altsep or ""} if separator):
        raise ValueError("slug contains path separators")
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", slug):
        raise ValueError("slug contains invalid characters")
    return slug


def _assert_write_target_within_root(root: Path, path: Path) -> None:
    root_resolved = root.resolve()
    resolved_target = path.resolve(strict=False)
    try:
        resolved_target.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"write target escapes root: {path}") from exc


def _ensure_bootstrapped_dossier(dossier: Path) -> None:
    required = (
        dossier / "index.md",
        dossier / "wiki" / "sources",
        dossier / "wiki" / "events",
        dossier / "wiki" / "rollups",
        dossier / "wiki" / "queries",
    )
    if not all(path.exists() for path in required):
        raise ValueError("workspace is not bootstrapped")


def _write_text_if_changed(path: Path, content: str) -> bool:
    if path.exists() and path.read_text(encoding="utf-8") == content:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True


def _register_index(index_path: Path, relative_entry: str) -> bool:
    entry_line = f"- `{relative_entry}`"
    content = index_path.read_text(encoding="utf-8")
    if entry_line in content:
        return False
    updated = content.rstrip() + "\n" + entry_line + "\n"
    index_path.write_text(updated, encoding="utf-8")
    return True


def _render_page_shell(ticker: str, page_type: str, slug: str, title: str, payload: dict[str, Any]) -> str:
    fields: dict[str, object] = {
        "page_type": page_type,
        "ticker": ticker,
        "slug": slug,
        "status": "active",
    }
    tags = payload.get("tags")
    if isinstance(tags, list):
        fields["tags"] = [str(tag) for tag in tags]
    frontmatter = render_frontmatter(fields)
    return f"{frontmatter}\n\n# {title}\n"


def _unique(values: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped


def _write_page_and_register(
    root_path: Path,
    dossier: Path,
    *,
    subdir: str,
    slug: str,
    content: str,
) -> tuple[list[str], str]:
    page_path = dossier / "wiki" / subdir / f"{slug}.md"
    index_path = dossier / "index.md"
    _assert_write_target_within_root(root_path, page_path)
    _assert_write_target_within_root(root_path, index_path)

    changed: list[str] = []
    if _write_text_if_changed(page_path, content):
        changed.append(_relative(root_path, page_path))

    relative_entry = f"dossier/wiki/{subdir}/{slug}.md"
    if _register_index(index_path, relative_entry):
        changed.append(_relative(root_path, index_path))

    return changed, _relative(root_path, page_path)


def scaffold(root: str | Path, ticker: str, page_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    if page_type not in PAGE_DIRS:
        raise ValueError("unsupported page_type")
    payload_page_type = payload.get("page_type")
    if payload_page_type is not None and str(payload_page_type).strip() != page_type:
        raise ValueError("payload page_type does not match --page-type")

    normalized_ticker = normalize_ticker(ticker)
    root_path = Path(root)
    dossier = dossier_root(root_path, normalized_ticker)
    _ensure_bootstrapped_dossier(dossier)

    slug = _normalize_slug(payload.get("slug", ""))
    title = str(payload.get("title", slug)).strip() or slug
    subdir = PAGE_DIRS[page_type]
    page_content = _render_page_shell(normalized_ticker, page_type, slug, title, payload)
    changed, relative_page = _write_page_and_register(
        root_path,
        dossier,
        subdir=subdir,
        slug=slug,
        content=page_content,
    )

    return ok(
        "ingest",
        "scaffold",
        normalized_ticker,
        changed=changed,
        artifacts=[relative_page],
        extra={"page_type": page_type},
    )


def materialize_query(root: str | Path, ticker: str, payload: dict[str, Any]) -> dict[str, Any]:
    payload_page_type = payload.get("page_type")
    if payload_page_type is not None and str(payload_page_type).strip() != "query":
        raise ValueError("payload page_type does not match --page-type")

    normalized_ticker = normalize_ticker(ticker)
    root_path = Path(root)
    dossier = dossier_root(root_path, normalized_ticker)
    _ensure_bootstrapped_dossier(dossier)
    slug = _normalize_slug(payload.get("slug", ""))

    shell = _render_page_shell(
        normalized_ticker,
        "query",
        slug,
        str(payload.get("title", slug)).strip() or slug,
        payload,
    ).rstrip("\n")
    body = str(payload.get("body", "")).rstrip()
    if body:
        full_content = f"{shell}\n\n{body}\n"
    else:
        full_content = f"{shell}\n"

    changed, relative_page = _write_page_and_register(
        root_path,
        dossier,
        subdir="queries",
        slug=slug,
        content=full_content,
    )
    return ok(
        "query",
        "materialize",
        normalized_ticker,
        changed=_unique(changed),
        artifacts=[relative_page],
        extra={"page_type": "query"},
    )
