from invest_wiki_runtime.cli import main


raise SystemExit(main())
