# invest-llm-wiki

Chinese-first md-first investment research wiki skills for Claude Code, Codex, and OpenClaw.

## What this repo is

`invest-llm-wiki` is a versioned skill-pack repository, not an application SDK. The repository currently contains the canonical skill catalog, agent-facing adapter readmes / manifests, the PyPI package source for `invest-wiki-runtime`, preset/docs scaffolding, and contract tests around those surfaces.

## Compatibility

- Claude Code
- Codex
- OpenClaw

## Language

The main skill authoring language is Chinese-first. This English README exists for open-source discoverability.

## For AI Agents

Use these entry points depending on the task:

- [skills/invest-wiki-dossier/SKILL.md](skills/invest-wiki-dossier/SKILL.md): ticker-first dossier orchestration, discover/materialize/render/validate.
- [skills/invest-wiki-ingest/SKILL.md](skills/invest-wiki-ingest/SKILL.md): scaffold source note / event / rollup / query pages from new material.
- [skills/invest-wiki-right-business/SKILL.md](skills/invest-wiki-right-business/SKILL.md), [skills/invest-wiki-right-people/SKILL.md](skills/invest-wiki-right-people/SKILL.md), [skills/invest-wiki-right-price/SKILL.md](skills/invest-wiki-right-price/SKILL.md): update the three judgment pages.
- [skills/invest-wiki-article/SKILL.md](skills/invest-wiki-article/SKILL.md), [skills/invest-wiki-lint/SKILL.md](skills/invest-wiki-lint/SKILL.md), [skills/invest-wiki-query/SKILL.md](skills/invest-wiki-query/SKILL.md): compose the final article, run maintenance checks, and materialize reusable query output.

Install the packaged skills with:

```bash
npx skills add xdsjs/invest-llm-wiki
```

Or install only what you need:

```bash
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-dossier
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-ingest
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-right-business
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-right-people
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-right-price
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-article
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-lint
npx skills add xdsjs/invest-llm-wiki --skill invest-wiki-query
```

Install the matching runtime version:

```bash
python3 -m pip install -U invest-wiki-runtime==0.1.0
```

Run the runtime directly from the skill:

```bash
python3 -m invest_wiki_runtime config get-root
python3 -m invest_wiki_runtime config set-root --root /absolute/path
python3 -m invest_wiki_runtime dossier run --ticker STZ
```

The runtime root config file still lives at `~/.config/invest-llm-wiki/config.toml`. Skills guide the agent through `config get-root` / `config set-root`, then execute the relevant business command. Repo tags, skill docs, and the PyPI runtime version stay strictly aligned.

For repository maintainers, `scripts/sync/sync_surfaces.py` and `scripts/verify/verify_repo.py` still exist to refresh adapter manifests and verify the committed repo surface; they are not developer installation entrypoints.

The `investment-research` preset is documented here as a contract, not as an installed runtime pack. It describes the file and workflow boundaries that the skill pack should satisfy.

## Planned preset shape

The later `investment-research` preset is intended to cover:

- `invest-wiki-dossier`
- `invest-wiki-ingest`
- `invest-wiki-right-business`
- `invest-wiki-right-people`
- `invest-wiki-right-price`
- `invest-wiki-article`
- `invest-wiki-lint`
- `invest-wiki-query`
