from pathlib import Path
from setuptools import setup, find_packages

BASE_DIR = Path(__file__).parent.resolve()
README = (BASE_DIR / "README.md").read_text(encoding="utf-8")

setup(
    name="Agencia-Viagens-mads", 
    version="1.5.0",                               
    description="Sistema de gestão de viagens",
    long_description=README,
    long_description_content_type="text/markdown",     
    author="Bruna Monteiro, Hélder Monteiro, Liliana Gonçalves, Rácia Atanásio",
    author_email="A045875@ipmaia.pt",
    url="https://github.com/Brunamon-t/Agencia_Viagens_mads",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pandas>=2.0.0",
        "geopy>=2.3.0",
    ],
    python_requires=">=3.8",
)
