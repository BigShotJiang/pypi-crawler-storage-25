"""EDA service helpers."""

