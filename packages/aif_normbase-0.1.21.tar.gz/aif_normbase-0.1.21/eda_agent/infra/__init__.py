"""Infrastructure adapters and builders for EDA agent."""
