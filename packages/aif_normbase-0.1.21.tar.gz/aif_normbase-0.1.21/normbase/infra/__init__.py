"""Normbase infrastructure adapters (non-domain)."""
