"""Process-wide LLM client for Normbase (env-driven; see llm package)."""

from llm.runtime import get_default_llm_provider


def get_llm_provider():
    """Shared LLM from flat env: LLM_PROVIDER, LLM_API_KEY, LLM_MODEL, …"""
    try:
        return get_default_llm_provider()
    except Exception as e:
        raise RuntimeError(
            "Failed to resolve LLM provider for Normbase. "
            "Set LLM_PROVIDER / LLM_API_KEY / LLM_MODEL / LLM_EMBEDDING_MODEL / LLM_BASE_URL "
            "(see .env.example)."
        ) from e
