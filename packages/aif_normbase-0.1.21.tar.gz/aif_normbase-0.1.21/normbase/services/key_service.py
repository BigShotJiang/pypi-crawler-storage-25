"""Business logic for API key lifecycle."""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from normbase.models.norm import APIKey, Field
from security.auth.api_keys import generate_api_key, hash_api_key, verify_api_key_hash

DEFAULT_SCOPES = [
    "retrieval:plan",
    "norms:retrieve",
    "norms:check",
    "norms:report",
]

DEFAULT_FIELD_SCOPES = ["norms:import"]


@dataclass
class IssuedKey:
    record: APIKey
    plain_key: str


class KeyService:
    """Service layer for API key operations."""

    def _utc_now(self) -> datetime:
        return datetime.now(timezone.utc).replace(tzinfo=None)

    def _to_utc(self, dt: datetime) -> datetime:
        if dt.tzinfo is None:
            return dt
        return dt.astimezone(timezone.utc).replace(tzinfo=None)

    def _ensure_not_expired(self, record: APIKey) -> bool:
        if record.expires_at is None:
            return True
        return self._to_utc(record.expires_at) > self._utc_now()

    def normalize_scopes(self, scopes: Optional[List[str]]) -> List[str]:
        normalized: List[str] = []
        for scope in scopes or []:
            text = str(scope).strip()
            if text and text not in normalized:
                normalized.append(text)
        return normalized or list(DEFAULT_SCOPES)

    def normalize_field_scopes(self, scopes: Optional[List[str]]) -> List[str]:
        normalized: List[str] = []
        for scope in scopes or []:
            text = str(scope).strip()
            if text and text not in normalized:
                normalized.append(text)
        return normalized or list(DEFAULT_FIELD_SCOPES)

    def extract_bearer(self, authorization: Optional[str]) -> str:
        if not authorization:
            return ""
        raw = authorization.strip()
        if raw.lower().startswith("bearer "):
            return raw[7:].strip()
        return raw

    def agent_uuid_or_500(self, agent_id_text: Optional[str]) -> uuid.UUID:
        text = (agent_id_text or "").strip()
        if not text:
            raise HTTPException(status_code=500, detail="Stored API key missing agent_id UUID.")
        try:
            return uuid.UUID(text)
        except ValueError as exc:
            raise HTTPException(status_code=500, detail="Stored API key has invalid agent_id UUID.") from exc

    async def _field_org_id(self, db: AsyncSession, field_id: uuid.UUID) -> Optional[uuid.UUID]:
        row = (
            await db.execute(select(Field).where(Field.id == field_id))
        ).scalar_one_or_none()
        if not row:
            return None
        return row.org_id

    async def resolve_api_key_from_plain(
        self,
        db: AsyncSession,
        *,
        plain_api_key: str,
    ) -> APIKey:
        hashed = hash_api_key(plain_api_key)
        row = (
            await db.execute(select(APIKey).where(APIKey.key_hash == hashed))
        ).scalar_one_or_none()
        if not row:
            raise HTTPException(status_code=401, detail="Invalid API key")
        if not row.is_active or not self._ensure_not_expired(row):
            raise HTTPException(status_code=401, detail="API key inactive or expired")
        if not verify_api_key_hash(plain_api_key, row.key_hash):
            raise HTTPException(status_code=401, detail="Invalid API key")
        return row

    async def issue_api_key(
        self,
        db: AsyncSession,
        *,
        agent_id: uuid.UUID,
        name: Optional[str],
        expires_at: Optional[datetime],
        scopes: Optional[List[str]],
    ) -> IssuedKey:
        normalized_scopes = self.normalize_scopes(scopes)
        plain = generate_api_key()
        record = APIKey(
            key_hash=hash_api_key(plain),
            name=name or f"agent:{agent_id}",
            key_kind="agent",
            agent_id=str(agent_id),
            field_id=None,
            scopes=normalized_scopes,
            is_active=True,
            expires_at=expires_at,
        )
        db.add(record)
        await db.commit()
        await db.refresh(record)
        return IssuedKey(record=record, plain_key=plain)

    async def issue_field_api_key(
        self,
        db: AsyncSession,
        *,
        field_id: uuid.UUID,
        name: Optional[str],
        expires_at: Optional[datetime],
        scopes: Optional[List[str]],
    ) -> IssuedKey:
        org_id = await self._field_org_id(db, field_id)
        if org_id is None:
            raise HTTPException(status_code=404, detail="Field not found")
        normalized_scopes = self.normalize_field_scopes(scopes)
        plain = generate_api_key(prefix="aif_fk")
        record = APIKey(
            key_hash=hash_api_key(plain),
            name=name or f"field:{field_id}",
            key_kind="field",
            agent_id=None,
            field_id=field_id,
            scopes=normalized_scopes,
            is_active=True,
            expires_at=expires_at,
        )
        db.add(record)
        await db.commit()
        await db.refresh(record)
        return IssuedKey(record=record, plain_key=plain)

    async def list_api_keys(
        self,
        db: AsyncSession,
        *,
        agent_id: Optional[uuid.UUID],
        field_id: Optional[uuid.UUID],
        include_inactive: bool,
    ) -> List[APIKey]:
        query = select(APIKey).order_by(APIKey.created_at.desc())
        if agent_id is not None:
            query = query.where(
                APIKey.agent_id == str(agent_id),
                APIKey.key_kind == "agent",
            )
        if field_id is not None:
            query = query.where(
                APIKey.field_id == field_id,
                APIKey.key_kind == "field",
            )
        if not include_inactive:
            query = query.where(APIKey.is_active.is_(True))
        return list((await db.execute(query)).scalars().all())

    async def revoke_api_key(self, db: AsyncSession, *, key_id: uuid.UUID) -> APIKey:
        row = (await db.execute(select(APIKey).where(APIKey.id == key_id))).scalar_one_or_none()
        if not row:
            raise HTTPException(status_code=404, detail="API key not found")
        row.is_active = False
        await db.commit()
        await db.refresh(row)
        return row

    def _rotate_plain_for(self, row: APIKey) -> str:
        if row.key_kind == "field":
            return generate_api_key(prefix="aif_fk")
        return generate_api_key()

    async def rotate_api_key(self, db: AsyncSession, *, key_id: uuid.UUID) -> IssuedKey:
        row = (await db.execute(select(APIKey).where(APIKey.id == key_id))).scalar_one_or_none()
        if not row:
            raise HTTPException(status_code=404, detail="API key not found")
        plain = self._rotate_plain_for(row)
        row.key_hash = hash_api_key(plain)
        row.is_active = True
        await db.commit()
        await db.refresh(row)
        return IssuedKey(record=row, plain_key=plain)

    async def resolve_row_metadata(
        self,
        db: AsyncSession,
        *,
        row: APIKey,
    ) -> tuple[Optional[uuid.UUID], Optional[uuid.UUID], Optional[uuid.UUID]]:
        """Return (agent_id, field_id, org_id) for API responses."""
        agent_uuid: Optional[uuid.UUID] = None
        if row.key_kind == "agent" and row.agent_id:
            try:
                agent_uuid = uuid.UUID(str(row.agent_id).strip())
            except ValueError:
                agent_uuid = None
        field_uuid = row.field_id if row.key_kind == "field" else None
        org_uuid: Optional[uuid.UUID] = None
        if field_uuid:
            org_uuid = await self._field_org_id(db, field_uuid)
        return agent_uuid, field_uuid, org_uuid
