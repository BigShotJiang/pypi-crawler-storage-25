"""Background extraction jobs (phase 4: async document extract)."""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from normbase.db.connection import async_session_maker
from normbase.services.extraction_batch_service import ExtractionBatchService


async def run_batch_document_extraction_job(
    batch_id: UUID,
    document_id: UUID,
    *,
    default_lang: str,
    max_norms: int,
    submitter_user_id: Optional[str],
) -> None:
    """Run `extract_document` in a fresh DB session (e.g. after HTTP 202)."""
    async with async_session_maker() as db:
        batch_service = ExtractionBatchService()
        await batch_service.extract_document(
            db,
            batch_id=batch_id,
            document_id=document_id,
            default_lang=default_lang,
            max_norms=max_norms,
            submitter_user_id=submitter_user_id,
        )
