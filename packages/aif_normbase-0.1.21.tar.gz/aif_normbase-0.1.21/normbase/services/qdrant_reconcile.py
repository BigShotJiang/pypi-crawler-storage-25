"""Plan Qdrant point set vs DB active norms (delete orphans, optional backfill)."""
from __future__ import annotations

from typing import FrozenSet, List, Tuple


def plan_norm_qdrant_reconcile(
    active_norm_ids: FrozenSet[str],
    qdrant_point_ids: FrozenSet[str],
    *,
    include_backfill: bool,
) -> Tuple[List[str], List[str]]:
    """
    Compute reconcile actions.

    Returns:
        to_delete: Qdrant point IDs to remove (not in active_norm_ids).
        to_backfill: Active norm IDs that have no Qdrant point (only if include_backfill).
    """
    to_delete = sorted(qdrant_point_ids - active_norm_ids)
    if not include_backfill:
        return to_delete, []
    to_backfill = sorted(active_norm_ids - qdrant_point_ids)
    return to_delete, to_backfill
