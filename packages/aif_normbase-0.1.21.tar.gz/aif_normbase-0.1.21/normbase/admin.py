"""Simple Admin UI entry for Normbase."""
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse

from normbase.config import settings

app = FastAPI()

admin_html = """
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AIF Normbase Admin</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 0; background: #f7f7f8; color: #222; }
    .wrap { max-width: 860px; margin: 40px auto; padding: 24px; background: #fff; border-radius: 8px; border: 1px solid #e8e8ea; }
    h1 { margin: 0 0 12px 0; font-size: 24px; }
    p { line-height: 1.6; margin: 10px 0; }
    code { background: #f1f3f5; padding: 2px 6px; border-radius: 4px; }
    .muted { color: #666; }
    .actions { margin-top: 20px; }
    a.btn {
      display: inline-block;
      text-decoration: none;
      background: #0969da;
      color: #fff;
      padding: 10px 14px;
      border-radius: 6px;
      font-weight: 600;
    }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>AIF Normbase Admin</h1>
    <p>Legacy inline admin form has been retired to avoid old-schema data writes.</p>
    <p>Please use the dedicated dashboard frontend for creating and managing norms.</p>
    <p class="muted">API base: <code>__API_BASE__</code></p>
    <div class="actions">
      <a class="btn" href="__API_BASE__/norms?page_size=20" target="_blank" rel="noopener noreferrer">Open Norms API (sample)</a>
    </div>
  </div>
</body>
</html>
"""


@app.get("/", response_class=HTMLResponse)
async def admin_ui(request: Request):
    del request
    api_base = f"{settings.normbase_base_url}/api/v1"
    return HTMLResponse(content=admin_html.replace("__API_BASE__", api_base))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "normbase.admin:app",
        host=settings.api_host,
        port=settings.ui_port,
        reload=settings.api_debug,
    )
