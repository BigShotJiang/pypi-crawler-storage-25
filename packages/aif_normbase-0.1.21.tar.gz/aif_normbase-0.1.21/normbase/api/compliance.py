"""Compliance check and outcome reporting APIs."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Header
from sqlalchemy.ext.asyncio import AsyncSession

from normbase.db.connection import get_db
from normbase.schemas import (
    ComplianceCheckRequest,
    ComplianceCheckResponse,
    NormOutcomeReportRequest,
    NormOutcomeReportResponse,
)
from normbase.services.compliance_service import ComplianceService

router = APIRouter(prefix="/norms", tags=["norms"])
_compliance_service = ComplianceService()


@router.post("/check_action_compliance", response_model=ComplianceCheckResponse)
async def check_action_compliance(
    request: ComplianceCheckRequest,
    db: AsyncSession = Depends(get_db),
    x_agent_id: str | None = Header(default=None),
    x_key_id: str | None = Header(default=None),
):
    return await _compliance_service.check_action_compliance(
        db,
        request=request,
        x_agent_id=x_agent_id,
        x_key_id=x_key_id,
    )


@router.post("/log-outcome", response_model=NormOutcomeReportResponse)
async def report_norm_outcome(
    request: NormOutcomeReportRequest,
    db: AsyncSession = Depends(get_db),
    x_agent_id: str | None = Header(default=None),
    x_key_id: str | None = Header(default=None),
):
    return await _compliance_service.report_norm_outcome(
        db,
        request=request,
        x_agent_id=x_agent_id,
        x_key_id=x_key_id,
    )
