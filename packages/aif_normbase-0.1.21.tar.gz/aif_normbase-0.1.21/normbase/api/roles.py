"""Role suggestion API routes for retrieval planning."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from normbase.db.connection import get_db
from normbase.schemas import (
    RoleSuggestRequest,
    RoleSuggestResponse,
    RetrievalPlanResponse,
)
from normbase.services.role_service import RoleService

router = APIRouter(prefix="/roles", tags=["roles"])
_role_service = RoleService()


@router.post("/suggest", response_model=RoleSuggestResponse)
async def suggest_roles(
    request: RoleSuggestRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Suggest candidate agent roles based on active norms and context.

    Notes:
    - Uses active norms only.
    - Optionally narrows by field_ids.
    - Treats '*' as fallback role with lower priority.
    """
    plan = await _role_service.build_role_plan(db, request)
    return RoleSuggestResponse(
        candidates=plan.candidates,
        recommended_role=plan.recommended_role,
    )


@router.post("/plan", response_model=RetrievalPlanResponse)
async def plan_retrieval(
    request: RoleSuggestRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Suggest retrieval strategy (role + tag_filters) from active norms and context.
    """
    return await _role_service.build_role_plan(db, request)

