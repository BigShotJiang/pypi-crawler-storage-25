"""
archimate_to_graph
-------------------

Independent utility for importing ArchiMate models into Neo4j.

This module is intentionally isolated under `ontology/archimate_to_graph` and
does not modify or depend on the main AIF runtime modules.
"""

__all__ = ["loader", "mapper", "neo4j_writer"]

