"""External integration adapters (MCP, SDK, etc.)."""

