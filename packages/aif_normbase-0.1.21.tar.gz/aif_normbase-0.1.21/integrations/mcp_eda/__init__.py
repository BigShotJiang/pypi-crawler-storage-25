"""EDA-runtime-first MCP integration package for AIF."""

