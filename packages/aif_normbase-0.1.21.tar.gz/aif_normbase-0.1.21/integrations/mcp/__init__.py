"""MCP integration package for AIF."""

