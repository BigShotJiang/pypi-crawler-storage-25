"""CLI and small tooling entrypoints for the platform."""
