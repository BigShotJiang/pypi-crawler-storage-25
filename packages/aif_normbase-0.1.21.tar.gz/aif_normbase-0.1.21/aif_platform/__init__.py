"""AIF platform product boundary: `server` (Python backend) + `web` (user-facing frontend).

Package name is `aif_platform` (not `platform`) to avoid shadowing the Python standard library.

Prefer importing from `aif_platform.server.*` (e.g. `aif_platform.server.api.deps`).
"""
