"""Platform backend: APIs, auth, orgs, and integration with normbase / eda_agent."""
