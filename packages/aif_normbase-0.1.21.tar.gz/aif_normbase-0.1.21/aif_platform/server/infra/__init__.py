"""Outbound HTTP clients to normbase and eda_agent."""
