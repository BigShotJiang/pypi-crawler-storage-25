"""Password hashing and JWT helpers for the platform server."""
