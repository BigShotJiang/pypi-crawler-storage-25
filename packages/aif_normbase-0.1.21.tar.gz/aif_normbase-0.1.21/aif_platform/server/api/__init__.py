"""HTTP routers for the platform BFF."""
