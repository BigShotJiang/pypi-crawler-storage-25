"""API keys BFF — normbase keys/issue with agent ownership checks."""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Query, status

from aif_platform.server.api.deps import get_eda_client, get_normbase_client, get_org_context
from aif_platform.server.infra.upstream import EdaClient, NormbaseClient
from aif_platform.server.models.persistence import PlatformUser
from aif_platform.server.services.access import require_agent_in_org

router = APIRouter(prefix="/keys", tags=["keys"])


async def _key_belongs_to_agent(nb: NormbaseClient, *, key_id: uuid.UUID, agent_id: uuid.UUID) -> bool:
    rows = await nb.list_keys({"agent_id": str(agent_id), "include_inactive": "true"})
    if not isinstance(rows, list):
        return False
    for row in rows:
        if isinstance(row, dict) and str(row.get("key_id")) == str(key_id):
            return True
    return False


@router.post("/issue", status_code=201)
async def issue_key(
    body: dict[str, Any] = Body(...),
    ctx: tuple[PlatformUser, uuid.UUID] = Depends(get_org_context),
    nb: NormbaseClient = Depends(get_normbase_client),
    eda: EdaClient = Depends(get_eda_client),
):
    _user, org_id = ctx
    aid = body.get("agent_id")
    if not aid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="agent_id is required.",
        )
    agent_uuid = uuid.UUID(str(aid))
    await require_agent_in_org(eda, agent_id=agent_uuid, org_id=org_id)
    return await nb.issue_key(body)


@router.get("")
async def list_keys(
    ctx: tuple[PlatformUser, uuid.UUID] = Depends(get_org_context),
    nb: NormbaseClient = Depends(get_normbase_client),
    eda: EdaClient = Depends(get_eda_client),
    agent_id: uuid.UUID = Query(..., description="List keys for this agent (must be in your org)."),
    include_inactive: bool = Query(False),
):
    _user, org_id = ctx
    await require_agent_in_org(eda, agent_id=agent_id, org_id=org_id)
    return await nb.list_keys(
        {"agent_id": str(agent_id), "include_inactive": include_inactive}
    )


@router.post("/{key_id}/revoke")
async def revoke_key(
    key_id: uuid.UUID,
    ctx: tuple[PlatformUser, uuid.UUID] = Depends(get_org_context),
    nb: NormbaseClient = Depends(get_normbase_client),
    eda: EdaClient = Depends(get_eda_client),
    agent_id: uuid.UUID = Query(...),
):
    _user, org_id = ctx
    await require_agent_in_org(eda, agent_id=agent_id, org_id=org_id)
    if not await _key_belongs_to_agent(nb, key_id=key_id, agent_id=agent_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Key not found for agent.")
    return await nb.revoke_key(key_id)


@router.post("/{key_id}/rotate", status_code=201)
async def rotate_key(
    key_id: uuid.UUID,
    ctx: tuple[PlatformUser, uuid.UUID] = Depends(get_org_context),
    nb: NormbaseClient = Depends(get_normbase_client),
    eda: EdaClient = Depends(get_eda_client),
    agent_id: uuid.UUID = Query(...),
):
    _user, org_id = ctx
    await require_agent_in_org(eda, agent_id=agent_id, org_id=org_id)
    if not await _key_belongs_to_agent(nb, key_id=key_id, agent_id=agent_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Key not found for agent.")
    return await nb.rotate_key(key_id)
