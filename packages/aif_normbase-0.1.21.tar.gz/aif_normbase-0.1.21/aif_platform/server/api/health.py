"""Process health and upstream reachability (no auth)."""

from __future__ import annotations

from fastapi import APIRouter, Request

router = APIRouter(tags=["health"])


async def upstream_health_snapshot(request: Request) -> dict[str, str]:
    nb = request.app.state.normbase_client
    eda = request.app.state.eda_client
    nb_ok = await nb.health_head()
    eda_ok = await eda.health_head()
    overall = "ok" if (nb_ok and eda_ok) else "degraded"
    return {
        "status": overall,
        "normbase": "up" if nb_ok else "down",
        "eda_agent": "up" if eda_ok else "down",
    }


@router.get("/health")
async def health(request: Request) -> dict[str, str]:
    return await upstream_health_snapshot(request)
