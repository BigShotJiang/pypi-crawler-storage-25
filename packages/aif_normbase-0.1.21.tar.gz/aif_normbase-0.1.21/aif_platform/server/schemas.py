"""Pydantic request/response models for platform HTTP API."""

from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=256)
    org_name: str | None = Field(None, max_length=255)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=1, max_length=256)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class OrgBrief(BaseModel):
    id: uuid.UUID
    name: str
    role: str


class UserMeResponse(BaseModel):
    id: uuid.UUID
    email: str
    is_platform_admin: bool
    organizations: list[OrgBrief]


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(..., min_length=1, max_length=256)
    new_password: str = Field(..., min_length=8, max_length=256)


class OkResponse(BaseModel):
    ok: bool = True


class OrgListResponse(BaseModel):
    organizations: list[OrgBrief]


class OrgUpdateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)


class OrgPatchResponse(BaseModel):
    id: uuid.UUID
    name: str
    created_at: datetime


class AdminUserRow(BaseModel):
    id: uuid.UUID
    email: str
    is_active: bool
    is_platform_admin: bool
    created_at: datetime


class AdminOrgRow(BaseModel):
    id: uuid.UUID
    name: str
    created_at: datetime
