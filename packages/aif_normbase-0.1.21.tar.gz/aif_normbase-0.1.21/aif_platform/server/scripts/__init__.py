"""One-off and bootstrap scripts for platform server."""
