"""Extract Field API key material from HTTP headers."""

from __future__ import annotations


def extract_field_api_key(
    authorization: str | None,
    x_field_api_key: str | None,
) -> str:
    """
    Prefer X-Field-API-Key; else Bearer token only when it looks like a field key (aif_fk_).
    """
    raw = (x_field_api_key or "").strip()
    if raw:
        return raw
    auth = (authorization or "").strip()
    if auth.lower().startswith("bearer "):
        token = auth[7:].strip()
        if token.startswith("aif_fk_"):
            return token
    return ""
