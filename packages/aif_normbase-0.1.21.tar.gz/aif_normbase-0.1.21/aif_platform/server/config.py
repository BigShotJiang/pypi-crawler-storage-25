"""Platform server configuration (env / .env)."""

from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Same Postgres as normbase by default; optional override.
    database_url: str = Field(
        validation_alias=AliasChoices(
            "AIF_PLATFORM_DATABASE_URL",
            "NORMBASE_DATABASE_URL",
            "DATABASE_URL",
        ),
    )

    normbase_base_url: str = Field(
        default="http://127.0.0.1:8000",
        validation_alias=AliasChoices("NORMBASE_BASE_URL"),
    )
    eda_base_url: str = Field(
        default="http://127.0.0.1:8001",
        validation_alias=AliasChoices("EDA_BASE_URL"),
    )

    aif_internal_service_token: str | None = Field(
        default=None,
        validation_alias=AliasChoices("AIF_INTERNAL_SERVICE_TOKEN"),
    )

    jwt_secret: str = Field(
        default="dev-change-me",
        validation_alias=AliasChoices("AIF_PLATFORM_JWT_SECRET", "JWT_SECRET"),
    )
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = Field(
        60,
        validation_alias=AliasChoices("AIF_PLATFORM_JWT_EXPIRE_MINUTES"),
    )

    api_host: str = Field(
        default="0.0.0.0",
        validation_alias=AliasChoices("AIF_PLATFORM_API_HOST", "PLATFORM_API_HOST"),
    )
    platform_api_port: int = Field(
        8020,
        validation_alias=AliasChoices("AIF_PLATFORM_API_PORT", "PLATFORM_API_PORT"),
    )
    api_debug: bool = Field(
        default=False,
        validation_alias=AliasChoices("AIF_PLATFORM_API_DEBUG", "PLATFORM_API_DEBUG"),
    )

    http_client_timeout_seconds: float = 60.0


settings = Settings()
