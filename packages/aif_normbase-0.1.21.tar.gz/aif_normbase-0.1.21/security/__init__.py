"""Shared security package for cross-service auth/audit."""

