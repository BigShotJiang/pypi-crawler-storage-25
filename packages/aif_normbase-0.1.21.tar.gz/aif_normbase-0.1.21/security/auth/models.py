"""Auth models used across service boundaries."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Principal:
    """Minimal identity model extracted from auth credentials."""

    subject: str
    auth_type: str
    authenticated: bool
    agent_id: str | None = None
    key_id: str | None = None
    request_id: str | None = None
    caller_id: str | None = None

