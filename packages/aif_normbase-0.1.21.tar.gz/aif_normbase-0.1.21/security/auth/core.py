"""Shared auth core for multi-entry integrations."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Awaitable, Callable, Literal, Sequence
from uuid import UUID
import os

import httpx

from security.auth.api_keys import ResolvedAPIKey, ResolvedIntegrationKey

EntryType = Literal["mcp", "openclaw", "sdk"]
AuthDecision = Literal["allow", "deny"]

REASON_OK = "ok"
REASON_MISSING_API_KEY = "missing_api_key"
REASON_INVALID_API_KEY = "invalid_api_key"
REASON_INACTIVE_KEY = "inactive_key"
REASON_EXPIRED_KEY = "expired_key"
REASON_MISSING_SCOPE = "missing_scope"
REASON_AGENT_MISMATCH = "agent_mismatch"
REASON_FIELD_MISMATCH = "field_mismatch"
REASON_FIELD_KEY_AGENT_TARGET = "field_key_agent_target"


def _normbase_base_url() -> str:
    return os.getenv("NORMBASE_BASE_URL", "http://localhost:8001").rstrip("/")


@dataclass(frozen=True)
class AuthInput:
    """Normalized authorization input across all integration entries."""

    entry_type: EntryType
    api_key: str
    action: str
    required_scopes: list[str]
    resource_agent_id: str | None = None
    resource_field_id: str | None = None
    request_id: str | None = None
    caller_id: str | None = None


@dataclass(frozen=True)
class AuthContext:
    """Authorization decision and resolved identity context."""

    decision: AuthDecision
    reason: str
    key_kind: str
    agent_id: str
    field_id: str
    org_id: str
    key_id: str
    scopes: list[str]
    request_id: str | None
    caller_id: str | None
    action: str


def _normalize_scope_list(value: Sequence[str] | None) -> list[str]:
    scopes: list[str] = []
    for raw in value or []:
        text = str(raw).strip()
        if text and text not in scopes:
            scopes.append(text)
    return scopes


def _normalize_agent_id_or_empty(raw_agent_id: str | None) -> str:
    text = (raw_agent_id or "").strip()
    if not text:
        return ""
    try:
        return str(UUID(text))
    except ValueError:
        return ""


def _normalize_field_id_or_empty(raw_field_id: str | None) -> str:
    text = (raw_field_id or "").strip()
    if not text:
        return ""
    try:
        return str(UUID(text))
    except ValueError:
        return ""


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _normalize_expires_at(value: object) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        candidate = raw.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(candidate)
        except ValueError:
            return None
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    return None


def _has_scope(scopes: Sequence[str], required_scope: str) -> bool:
    normalized = _normalize_scope_list(scopes)
    if "*" in normalized:
        return True
    return required_scope in normalized


Resolver = Callable[[str], Awaitable[ResolvedIntegrationKey | None]]


async def resolve_integration_api_key(api_key: str) -> ResolvedIntegrationKey | None:
    """Resolve any integration API key via Normbase introspect."""
    key = (api_key or "").strip()
    if not key:
        return None
    headers = {"X-API-Key": key}
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.get(
                f"{_normbase_base_url()}/api/v1/keys/introspect",
                headers=headers,
            )
            if resp.status_code >= 400:
                return None
            data = resp.json() or {}
            kind_raw = str(data.get("key_kind", "agent") or "agent").strip()
            kind: Literal["agent", "field"] = "field" if kind_raw == "field" else "agent"
            aid = data.get("agent_id")
            fid = data.get("field_id")
            oid = data.get("org_id")
            agent_id = str(aid).strip() if aid is not None and str(aid).strip() else ""
            field_id = str(fid).strip() if fid is not None and str(fid).strip() else ""
            org_id = str(oid).strip() if oid is not None and str(oid).strip() else ""
            return ResolvedIntegrationKey(
                key_id=str(data.get("key_id", "")).strip(),
                key_kind=kind,
                agent_id=agent_id,
                field_id=field_id,
                org_id=org_id,
                scopes=_normalize_scope_list(data.get("scopes", ["*"])),
                is_active=bool(data.get("is_active", True)),
                expires_at=_normalize_expires_at(data.get("expires_at")),
            )
    except Exception:
        return None


async def resolve_agent_api_key(api_key: str) -> ResolvedIntegrationKey | None:
    """Resolve only per-agent keys (excludes field import keys)."""
    resolved = await resolve_integration_api_key(api_key)
    if resolved is None or resolved.key_kind != "agent":
        return None
    return resolved


def integration_key_to_agent_principal(
    resolved: ResolvedIntegrationKey,
) -> ResolvedAPIKey | None:
    """Narrow to ResolvedAPIKey when the key is agent-scoped."""
    if resolved.key_kind != "agent" or not (resolved.agent_id or "").strip():
        return None
    return ResolvedAPIKey(
        key_id=resolved.key_id,
        agent_id=resolved.agent_id,
        scopes=list(resolved.scopes),
        is_active=resolved.is_active,
        expires_at=resolved.expires_at,
    )


def _empty_context(
    auth_input: AuthInput,
    *,
    reason: str,
    key_id: str = "",
    scopes: list[str] | None = None,
) -> AuthContext:
    return AuthContext(
        decision="deny",
        reason=reason,
        key_kind="agent",
        agent_id="",
        field_id="",
        org_id="",
        key_id=key_id,
        scopes=scopes or [],
        request_id=auth_input.request_id,
        caller_id=auth_input.caller_id,
        action=auth_input.action,
    )


async def authorize(
    auth_input: AuthInput,
    *,
    resolver: Resolver | None = None,
) -> AuthContext:
    """Authorize one integration action with consistent decision semantics."""
    res_fn: Resolver = resolver or resolve_integration_api_key
    api_key = (auth_input.api_key or "").strip()
    if not api_key:
        return _empty_context(auth_input, reason=REASON_MISSING_API_KEY)

    resolved = await res_fn(api_key)
    if resolved is None:
        return _empty_context(auth_input, reason=REASON_INVALID_API_KEY)

    if not resolved.key_id:
        return _empty_context(auth_input, reason=REASON_INVALID_API_KEY)

    if not resolved.is_active:
        return AuthContext(
            decision="deny",
            reason=REASON_INACTIVE_KEY,
            key_kind=resolved.key_kind,
            agent_id=_normalize_agent_id_or_empty(resolved.agent_id),
            field_id=_normalize_field_id_or_empty(resolved.field_id),
            org_id=(resolved.org_id or "").strip(),
            key_id=resolved.key_id,
            scopes=_normalize_scope_list(resolved.scopes),
            request_id=auth_input.request_id,
            caller_id=auth_input.caller_id,
            action=auth_input.action,
        )

    expires_at = _normalize_expires_at(resolved.expires_at)
    if expires_at is not None and expires_at <= _utc_now():
        return AuthContext(
            decision="deny",
            reason=REASON_EXPIRED_KEY,
            key_kind=resolved.key_kind,
            agent_id="",
            field_id="",
            org_id="",
            key_id=resolved.key_id,
            scopes=_normalize_scope_list(resolved.scopes),
            request_id=auth_input.request_id,
            caller_id=auth_input.caller_id,
            action=auth_input.action,
        )

    required_scopes = _normalize_scope_list(auth_input.required_scopes)
    principal_scopes = _normalize_scope_list(resolved.scopes)
    for scope in required_scopes:
        if _has_scope(principal_scopes, scope):
            continue
        return AuthContext(
            decision="deny",
            reason=f"{REASON_MISSING_SCOPE}:{scope}",
            key_kind=resolved.key_kind,
            agent_id=_normalize_agent_id_or_empty(resolved.agent_id),
            field_id=_normalize_field_id_or_empty(resolved.field_id),
            org_id=(resolved.org_id or "").strip(),
            key_id=resolved.key_id,
            scopes=principal_scopes,
            request_id=auth_input.request_id,
            caller_id=auth_input.caller_id,
            action=auth_input.action,
        )

    resource_agent_id = _normalize_agent_id_or_empty(auth_input.resource_agent_id)
    resource_field_id = _normalize_field_id_or_empty(auth_input.resource_field_id)

    if resolved.key_kind == "agent":
        resolved_agent_id = _normalize_agent_id_or_empty(resolved.agent_id)
        if not resolved_agent_id:
            return _empty_context(
                auth_input,
                reason=REASON_INVALID_API_KEY,
                key_id=resolved.key_id,
                scopes=principal_scopes,
            )
        if resource_agent_id and resolved_agent_id != resource_agent_id:
            return AuthContext(
                decision="deny",
                reason=REASON_AGENT_MISMATCH,
                key_kind="agent",
                agent_id=resolved_agent_id,
                field_id="",
                org_id="",
                key_id=resolved.key_id,
                scopes=principal_scopes,
                request_id=auth_input.request_id,
                caller_id=auth_input.caller_id,
                action=auth_input.action,
            )
        return AuthContext(
            decision="allow",
            reason=REASON_OK,
            key_kind="agent",
            agent_id=resolved_agent_id,
            field_id="",
            org_id="",
            key_id=resolved.key_id,
            scopes=principal_scopes,
            request_id=auth_input.request_id,
            caller_id=auth_input.caller_id,
            action=auth_input.action,
        )

    # field key
    if resource_agent_id:
        return AuthContext(
            decision="deny",
            reason=REASON_FIELD_KEY_AGENT_TARGET,
            key_kind="field",
            agent_id="",
            field_id=_normalize_field_id_or_empty(resolved.field_id),
            org_id=(resolved.org_id or "").strip(),
            key_id=resolved.key_id,
            scopes=principal_scopes,
            request_id=auth_input.request_id,
            caller_id=auth_input.caller_id,
            action=auth_input.action,
        )
    resolved_field_id = _normalize_field_id_or_empty(resolved.field_id)
    if not resolved_field_id:
        return _empty_context(
            auth_input,
            reason=REASON_INVALID_API_KEY,
            key_id=resolved.key_id,
            scopes=principal_scopes,
        )
    if resource_field_id and resolved_field_id != resource_field_id:
        return AuthContext(
            decision="deny",
            reason=REASON_FIELD_MISMATCH,
            key_kind="field",
            agent_id="",
            field_id=resolved_field_id,
            org_id=(resolved.org_id or "").strip(),
            key_id=resolved.key_id,
            scopes=principal_scopes,
            request_id=auth_input.request_id,
            caller_id=auth_input.caller_id,
            action=auth_input.action,
        )
    return AuthContext(
        decision="allow",
        reason=REASON_OK,
        key_kind="field",
        agent_id="",
        field_id=resolved_field_id,
        org_id=(resolved.org_id or "").strip(),
        key_id=resolved.key_id,
        scopes=principal_scopes,
        request_id=auth_input.request_id,
        caller_id=auth_input.caller_id,
        action=auth_input.action,
    )
