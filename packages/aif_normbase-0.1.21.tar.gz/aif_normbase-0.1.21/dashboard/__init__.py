"""AIF Technical Dashboard application package."""

