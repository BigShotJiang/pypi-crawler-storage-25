"""Extractor-only settings (same env keys as normbase for one .env)."""
from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ExtractorSettings(BaseSettings):
    """LLM + chunking budgets used by run_raw_extraction."""

    extraction_llm_max_content_chars: int = Field(
        default=36_000,
        ge=4096,
        validation_alias=AliasChoices(
            "NORMBASE_EXTRACTION_LLM_MAX_CONTENT_CHARS",
            "EXTRACTION_LLM_MAX_CONTENT_CHARS",
            "NORM_EXTRACTOR_LLM_MAX_CONTENT_CHARS",
        ),
    )
    extraction_chunk_overlap_chars: int = Field(
        default=800,
        ge=0,
        le=50_000,
        validation_alias=AliasChoices(
            "NORMBASE_EXTRACTION_CHUNK_OVERLAP_CHARS",
            "EXTRACTION_CHUNK_OVERLAP_CHARS",
            "NORM_EXTRACTOR_CHUNK_OVERLAP_CHARS",
        ),
    )
    extraction_artifact_raw_llm_max_chars: int = Field(
        default=120_000,
        ge=10_000,
        validation_alias=AliasChoices(
            "NORMBASE_EXTRACTION_ARTIFACT_RAW_LLM_MAX_CHARS",
            "EXTRACTION_ARTIFACT_RAW_LLM_MAX_CHARS",
            "NORM_EXTRACTOR_ARTIFACT_RAW_LLM_MAX_CHARS",
        ),
    )
    extraction_llm_max_output_tokens: int = Field(
        default=32_768,
        ge=0,
        le=200_000,
        validation_alias=AliasChoices(
            "NORMBASE_EXTRACTION_LLM_MAX_OUTPUT_TOKENS",
            "EXTRACTION_LLM_MAX_OUTPUT_TOKENS",
            "NORM_EXTRACTOR_LLM_MAX_OUTPUT_TOKENS",
        ),
        description="max_tokens for completion; too low → truncated JSON. Provider hard limits apply (e.g. Volces Ark ≤32768).",
    )
    extraction_llm_temperature: float | None = Field(
        default=0.2,
        ge=0.0,
        le=2.0,
        validation_alias=AliasChoices(
            "NORMBASE_EXTRACTION_LLM_TEMPERATURE",
            "EXTRACTION_LLM_TEMPERATURE",
            "NORM_EXTRACTOR_LLM_TEMPERATURE",
        ),
    )

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


def get_extractor_settings() -> ExtractorSettings:
    return ExtractorSettings()
