"""CLI entry (minimal): run extraction and print JSON to stdout."""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from uuid import UUID


def main() -> None:
    p = argparse.ArgumentParser(description="Norm extractor: text → raw norms JSON")
    p.add_argument("--file", "-f", type=Path, help="Input text file (UTF-8)")
    p.add_argument("--max-norms", type=int, default=10)
    p.add_argument("--lang", default="zh-CN")
    p.add_argument("--doc-id", default="cli")
    p.add_argument("--doc-title", default="cli-input")
    p.add_argument(
        "--field-id",
        default=None,
        help="Optional UUID string for default field_id hint",
    )
    args = p.parse_args()
    if args.file:
        text = args.file.read_text(encoding="utf-8")
    else:
        text = sys.stdin.read()

    fid = UUID(args.field_id) if args.field_id else None

    async def _run() -> None:
        from norm_extractor import run_raw_extraction

        out = await run_raw_extraction(
            text,
            default_lang=args.lang,
            field_id=fid,
            created_by=None,
            max_norms=args.max_norms,
            default_authority_level=None,
            default_formality_level=None,
            doc_id=args.doc_id,
            doc_title=args.doc_title,
        )
        payload = {
            "norms_raw": out.norms_raw,
            "chunk_results": out.chunk_results,
            "chunk_count": out.chunk_count,
            "max_content_chars": out.max_content_chars,
            "overlap_chars": out.overlap_chars,
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))

    asyncio.run(_run())


if __name__ == "__main__":
    main()
