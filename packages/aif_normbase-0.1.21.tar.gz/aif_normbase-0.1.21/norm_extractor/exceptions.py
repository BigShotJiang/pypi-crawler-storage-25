"""Errors raised by norm_extractor (no FastAPI / HTTP)."""


class NormExtractorError(Exception):
    """Base class for extraction pipeline failures."""


class LlmExtractionError(NormExtractorError):
    """LLM provider call failed."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class BadExtractionJsonError(NormExtractorError):
    """LLM returned non-JSON or JSON without expected shape."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)
