"""Load norm extraction system prompt from package data.

English prompt ``prompts/norm_extraction_prompt_en.md`` is maintained as a human
reference alongside the Chinese file; only the zh markdown is loaded at runtime.
"""
from __future__ import annotations

import re
from pathlib import Path

_PROMPT_PATH = Path(__file__).resolve().parent / "prompts" / "norm_extraction_prompt_zh.md"


def load_zh_extraction_system_prompt() -> str:
    """Return the system prompt block from prompts/norm_extraction_prompt_zh.md."""
    path = _PROMPT_PATH
    if not path.is_file():
        raise FileNotFoundError(f"Missing prompt file: {path}")
    raw = path.read_text(encoding="utf-8")
    m = re.search(
        r"## System Prompt[^\n]*\n\n(你是 AIF[\s\S]+?)\n---\n\n## User Prompt",
        raw,
    )
    if not m:
        raise ValueError(
            "Could not parse system prompt block in norm_extraction_prompt_zh.md"
        )
    return m.group(1).strip()
