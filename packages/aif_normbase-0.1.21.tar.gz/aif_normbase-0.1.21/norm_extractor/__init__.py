"""Norm extraction: upload text extraction, process JSON artifacts, text → LLM → raw norms (no Normbase DB).

Submodules ``document_text`` and ``artifact_storage`` are stateless helpers used by Normbase orchestration.
"""
from __future__ import annotations

from norm_extractor.agent import RawExtractionOutcome, run_raw_extraction
from norm_extractor.exceptions import (
    BadExtractionJsonError,
    LlmExtractionError,
    NormExtractorError,
)

__all__ = [
    "BadExtractionJsonError",
    "LlmExtractionError",
    "NormExtractorError",
    "RawExtractionOutcome",
    "run_raw_extraction",
]
