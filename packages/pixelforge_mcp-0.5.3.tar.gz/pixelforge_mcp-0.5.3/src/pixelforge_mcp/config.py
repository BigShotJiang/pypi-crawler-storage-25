"""Configuration management for Gemini Imagen MCP Server."""

import os
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field, SecretStr, field_validator


class MaskedStr(SecretStr):
    """A string that masks its value in repr/str.

    Supports equality comparison with plain strings.
    """

    def __eq__(self, other: object) -> bool:
        if isinstance(other, SecretStr):
            return self.get_secret_value() == other.get_secret_value()
        if isinstance(other, str):
            return self.get_secret_value() == other
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self.get_secret_value())


class ImagenConfig(BaseModel):
    """Gemini Imagen CLI configuration."""

    api_key: Optional[MaskedStr] = Field(None, description="Google API key")
    default_model: str = Field(
        "gemini-2.5-flash-image", description="Default image generation model"
    )
    default_aspect_ratio: str = Field("1:1", description="Default aspect ratio")
    default_temperature: float = Field(0.7, description="Default temperature")
    safety_setting: str = Field("preset:strict", description="Safety filter preset")

    @field_validator("default_temperature")
    @classmethod
    def validate_temperature(cls, v: float) -> float:
        """Ensure temperature is between 0 and 2."""
        if not 0 <= v <= 2:
            raise ValueError("Temperature must be between 0 and 2")
        return v


class StorageConfig(BaseModel):
    """Storage configuration."""

    output_dir: Path = Field(
        Path("./generated_images"), description="Directory for generated images"
    )

    @field_validator("output_dir")
    @classmethod
    def create_output_dir(cls, v: Path) -> Path:
        """Create output directory if it doesn't exist."""
        v.mkdir(parents=True, exist_ok=True)
        return v


class ServerConfig(BaseModel):
    """MCP server configuration."""

    name: str = Field("pixelforge-mcp", description="Server name")
    version: str = Field("0.5.3", description="Server version")
    log_level: str = Field("INFO", description="Logging level")


class VertexConfig(BaseModel):
    """Optional Vertex AI configuration for advanced features."""

    project_id: Optional[str] = Field(None, description="Google Cloud project ID")
    location: str = Field("us-central1", description="Vertex AI region")
    enabled: bool = Field(False, description="Whether Vertex AI features are enabled")


class Config(BaseModel):
    """Main configuration."""

    imagen: ImagenConfig = Field(default_factory=ImagenConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    server: ServerConfig = Field(default_factory=ServerConfig)
    vertex: VertexConfig = Field(default_factory=VertexConfig)

    @classmethod
    def load(cls, config_path: Optional[Path] = None) -> "Config":
        """Load configuration from file and environment variables."""
        # Default config path
        if config_path is None:
            config_path = Path("config/config.yaml")

        # Load from file if exists
        config_data = {}
        if config_path.exists():
            with open(config_path) as f:
                config_data = yaml.safe_load(f) or {}

        # Override with environment variables
        # Try multiple common env var names
        api_key = (
            os.getenv("GOOGLE_API_KEY")
            or os.getenv("GOOGLE_GENERATIVE_AI_API_KEY")
            or os.getenv("GEMINI_API_KEY")
        )
        if api_key:
            config_data.setdefault("imagen", {})["api_key"] = api_key

        # Auto-detect Vertex AI
        project_id = os.getenv("GOOGLE_CLOUD_PROJECT")
        if project_id:
            config_data.setdefault("vertex", {})["project_id"] = project_id
            config_data["vertex"]["enabled"] = True

        return cls(**config_data)

    def save(self, config_path: Optional[Path] = None) -> None:
        """Save configuration to file."""
        if config_path is None:
            config_path = Path("config/config.yaml")

        config_path.parent.mkdir(parents=True, exist_ok=True)

        # Convert to dict with proper serialization
        data = self.model_dump()
        # Never persist API keys to disk — they should come from env vars
        if "imagen" in data:
            data["imagen"].pop("api_key", None)
        # Convert Path objects to strings
        if "storage" in data and "output_dir" in data["storage"]:
            data["storage"]["output_dir"] = str(data["storage"]["output_dir"])

        with open(config_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False)


# Global config instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get the global configuration instance."""
    global _config
    if _config is None:
        _config = Config.load()
    return _config


def reload_config() -> None:
    """Reload configuration from file."""
    global _config
    _config = Config.load()
