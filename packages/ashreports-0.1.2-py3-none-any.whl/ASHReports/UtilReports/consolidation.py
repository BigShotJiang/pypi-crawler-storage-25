# ==========================================================================================
# RETAIL STOCK OPTIMIZER V8 (Size Balanced) by Tanmoy Sarkar
#
# First, generate a Combined report with season start till now date range
# then, filter it based on requirement like Season, Carryover or Ramadan, etc.
# after filtering, save filtered combined report data in a new file.
# this new file will be the input for this report.
# ==========================================================================================

import os
import pandas as pd
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox, ttk


def generate_transfers():
    # =========================
    # CONFIG
    # =========================
    MAX_RECEIVE = 4
    MIN_KEEP = int(entry_display.get())
    STORES = []
    COLUMNS = []
    file_path = entry_file.get()
    COUNTRY = selected_item.get()
    SEASON = selected_season.get()
    MERCH_TYPE = selected_types.get()

    # =========================
    # LOAD DATA
    # =========================
    df = pd.read_csv(file_path, dtype={"Item No_": str})

    df = df[["Brand Code","Country","ShortName","Location Type","Status","RefCode","Style Code","Colour Code","Size","Item No_","Season Code","Remarks","Cumm. SaleQty","Closing Stock"]]
    df = df.rename(columns={"Item No_":"ItemNo_", "Cumm. SaleQty":"Sale", "Closing Stock":"Stock"})
    df = df.loc[df["Status"]=="Active"]
    df = df.loc[df["Location Type"]=="Store"]
    df = df.loc[df["Country"]==COUNTRY]
    df = df.loc[df["Season Code"]==SEASON]
    df = df.loc[df["Remarks"]==MERCH_TYPE]

    pivot = pd.pivot_table(df, index=["ItemNo_","Style Code","Colour Code","Size"],
        columns="ShortName",values=["Sale","Stock"],aggfunc="sum",fill_value=0
    )

    pivot = pivot.reset_index()
    # To concatenate multi level column of pivot df
    pivot.columns = [
        f"{col[1]}_{col[0]}" if isinstance(col, tuple) else col
        for col in pivot.columns
    ]
    pivot = pivot.rename(columns={"_ItemNo_":"ItemNo_", "_Style Code":"Style Code", "_Colour Code":"Colour Code", "_Size":"Size"})
    # Populate Global column variables
    STORES = df["ShortName"].unique().tolist()
    COLUMNS = pivot.columns.tolist()

    sale_cols = [c for c in pivot.columns if "_Sale" in c]
    stock_cols = [c for c in pivot.columns if "_Stock" in c]
    stores = [c.replace("_Sale", "") for c in sale_cols]

    # =========================
    # STORE RANKING
    # =========================
    store_sales = {s: pivot[f"{s}_Sale"].sum() for s in stores}
    ranked_stores = sorted(store_sales, key=store_sales.get, reverse=True)

    # =========================
    # TRANSFER RESULT
    # =========================
    transfers = []

    # =========================
    # MAIN LOOP
    # =========================
    for _, row in pivot.iterrows():

        barcode = row["ItemNo_"]

        stock = {s: row[f"{s}_Stock"] for s in stores}
        sale = {s: row[f"{s}_Sale"] for s in stores}

        # Demand score
        demand = {
            s: sale[s] / (max(0, stock[s]) + 1)
            for s in stores
        }

        # Donors
        donors = {s: stock[s] for s in stores if stock[s] > MIN_KEEP}
        donors = dict(sorted(donors.items(), key=lambda x: x[1], reverse=True))

        # Receivers (PASS 1: zero stock)
        zero_receivers = [s for s in stores if stock[s] == 0]

        # Receivers (PASS 2: low stock)
        low_receivers = [s for s in stores if 0 < stock[s] < 2]

        # Sort receivers by demand + rank
        def sort_key(s):
            return (-demand[s], ranked_stores.index(s))

        zero_receivers = sorted(zero_receivers, key=sort_key)
        low_receivers = sorted(low_receivers, key=sort_key)

        used_receivers = set()

        # =========================
        # ALLOCATION FUNCTION
        # =========================
        def allocate(receivers, pass_name):
            for donor, donor_stock in donors.items():
                available = donor_stock - MIN_KEEP
                if available <= 0:
                    continue

                # Variation pattern (4,3,2,1)
                variation = [4, 3, 2, 1]
                v_idx = 0

                for r in receivers:
                    if r in used_receivers:
                        continue

                    if available <= 0:
                        break

                    qty = min(variation[v_idx % len(variation)], available, MAX_RECEIVE)
                    # Prevent multiple donors to same receiver
                    used_receivers.add(r)

                    transfers.append({
                        "ItemNo_": barcode,
                        "Style Code": row["Style Code"],
                        "Colour Code": row["Colour Code"],
                        "Size": row["Size"],
                        "Transfer_From Store": donor,
                        "Transfer_To Store": r,
                        "Transfer Qty": qty,
                        "Transfer_From Store Stock qty": donor_stock,
                        "Transfer_To Store Stock qty": stock[r],
                        "Pass": pass_name
                    })

                    available -= qty
                    v_idx += 1

        # =========================
        # SPECIAL CASE:
        # Few donors → redistribute widely
        # =========================
        if len(donors) <= 2:
            all_receivers = sorted(
                [s for s in stores if stock[s] < 2],
                key=sort_key
            )
            allocate(all_receivers, "Redistribution")

        else:
            # PASS 1: zero stock
            allocate(zero_receivers, "Zero Fill")
            # PASS 2: balance low stock
            allocate(low_receivers, "Balancing")

    # =========================
    # OUTPUT
    # =========================
    os.chdir("C:\\Reports\\Output\\Consolidation")
    output = pd.DataFrame(transfers)

    # Remove duplicates (important rule)
    output.drop_duplicates(
        subset=["ItemNo_", "Transfer_To Store"],
        inplace=True
    )

    output.to_csv("output.csv", index=False)
    print("✅ Stock transfer file generated: output.csv")

    # =========================
    # PREP DATA
    # =========================
    output = pd.DataFrame(transfers)

    output.drop_duplicates(
        subset=["ItemNo_", "Transfer_To Store"],
        inplace=True
    )

    # Sort for readability
    output = output.sort_values(
        by=["Transfer_From Store", "Transfer_To Store", "ItemNo_"]
    )

    # =========================
    # SUMMARY TABLE
    # =========================
    summary_pivot = pd.pivot_table(
        output,
        index="Transfer_From Store",
        columns="Transfer_To Store",
        values="Transfer Qty",
        aggfunc="sum",
        fill_value=0
    ).reset_index()

    # Top SKUs
    top_skus = (
        output.groupby("ItemNo_")["Transfer Qty"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )

    # =========================
    # MASTER FILE
    # =========================
    master_file = "Stock_Transfer_Master.xlsx"

    with pd.ExcelWriter(master_file, engine="xlsxwriter") as writer:
        workbook = writer.book
        # Formats
        header_format = workbook.add_format({
            "bold": True,
            "border": 1,
            "align": "center",
            "valign": "vcenter"
        })

        cell_format = workbook.add_format({
            "border": 1
        })

        highlight_format = workbook.add_format({
            "bg_color": "#C6EFCE"
        })

        # =========================
        # ALL TRANSFERS SHEET
        # =========================
        output.to_excel(writer, sheet_name="All Transfers", index=False)
        ws = writer.sheets["All Transfers"]
        ws.freeze_panes(1, 0)
        for col_num, col_name in enumerate(output.columns):
            ws.write(0, col_num, col_name, header_format)
            ws.set_column(col_num, col_num, 18)

        # Conditional formatting (highlight high qty)
        qty_col = output.columns.get_loc("Transfer Qty")
        ws.conditional_format(1, qty_col, len(output), qty_col, {
            "type": "cell",
            "criteria": ">=",
            "value": 3,
            "format": highlight_format
        })

        # =========================
        # SUMMARY SHEET
        # =========================
        summary_pivot.to_excel(writer, sheet_name="Summary", index=False)
        ws2 = writer.sheets["Summary"]
        ws2.freeze_panes(1, 1)
        for col_num, col_name in enumerate(summary_pivot.columns):
            ws2.write(0, col_num, col_name, header_format)
            ws2.set_column(col_num, col_num, 20)

        # =========================
        # TOP SKU SHEET
        # =========================
        top_skus.to_excel(writer, sheet_name="Top SKUs", index=False)
        ws3 = writer.sheets["Top SKUs"]
        for col_num, col_name in enumerate(top_skus.columns):
            ws3.write(0, col_num, col_name, header_format)
            ws3.set_column(col_num, col_num, 20)

    print(f"✅ Master file created: {master_file}")

    # =========================
    # STORE-WISE FILES
    # =========================
    output_dir = "store_files"
    os.makedirs(output_dir, exist_ok=True)
    for store in output["Transfer_From Store"].unique():
        store_df = output[output["Transfer_From Store"] == store]
        file_path = os.path.join(output_dir, f"{store}_Transfers.xlsx")

        with pd.ExcelWriter(file_path, engine="xlsxwriter") as writer:
            # Group inside by Trf_To (create sheets)
            for trf_to, df_to in store_df.groupby("Transfer_To Store"):
                
                workbook = writer.book
                header_format = workbook.add_format({"bold": True, "border": 1, "align": "center"})
                highlight_format = workbook.add_format({"bg_color": "#FFD966"})

                # Sheet name (Excel limit: 31 chars)
                sheet_name = str(trf_to)[:31]

                # Write data
                df_to.to_excel(writer, sheet_name=sheet_name, index=False)
                ws = writer.sheets[sheet_name]
                ws.freeze_panes(1, 0)

                for col_num, col_name in enumerate(store_df.columns):
                    ws.write(0, col_num, col_name, header_format)
                    ws.set_column(col_num, col_num, 18)

                # Highlight large transfers
                qty_col = df_to.columns.get_loc("Transfer Qty")
                ws.conditional_format(1, qty_col, len(df_to), qty_col, {
                    "type": "cell", "criteria": ">=", "value": 3, "format": highlight_format})

        print(f"📁 Created: {file_path}")

    print("🎉 All store-wise files generated!")

# --------------------------------------------------------------------------------------------------
# FILE PICKER
# --------------------------------------------------------------------------------------------------
def browse_file():
    file_path = filedialog.askopenfilename(filetypes=[("CSV Files","*.csv")])

    if file_path:
        entry_file.delete(0,tk.END)
        entry_file.insert(0,file_path)

# --------------------------------------------------------------------------------------------------
# PREPROCESS SELECTED FILE
# --------------------------------------------------------------------------------------------------
def process_file():
    global countries
    global seasons
    global types
    file_path = entry_file.get()
    df = pd.read_csv(file_path)
    tmpCountryList = df["Country"].unique().tolist()
    tmpSeasonList = df["Season Code"].unique().tolist()
    tmpTypeList = df["Remarks"].unique().tolist()

    countries = tmpCountryList
    seasons = tmpSeasonList
    types = tmpTypeList

    dropdown_display["values"] = countries
    dropdown_display.current(0)
    entry_season["values"] = seasons
    entry_season.current(0)
    entry_type["values"] = types
    entry_type.current(0)
    #print(seasons)

# --------------------------------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------------------------------
root = tk.Tk()
root.title("Stock Optimizer And Size Balance Planner")
root.geometry("450x220")
countries = ["All"]
selected_item = tk.StringVar()
seasons = ["All"]
selected_season = tk.StringVar()
types = ["All"]
selected_types = tk.StringVar()

main = tk.Frame(root,padx=10,pady=5)
main.pack(fill="both",expand=True)

lbl_file = tk.Label(main,text="Combined Report File")
lbl_file.grid(row=0,column=0, sticky="w")

entry_file = tk.Entry(main,width=45)
entry_file.grid(row=1,column=0,sticky="ew")
#---------------------------------------------------------------------
btn_browse = tk.Button(main,text="Browse",command=browse_file)
btn_browse.grid(row=1,column=1,sticky="ew", padx=2)

btn_process = tk.Button(main,text="Process",command=process_file)
btn_process.grid(row=2,column=1,sticky="ew", padx=2)

run_btn = tk.Button(main,text="Run Transfer Optimization",command=generate_transfers)    # ,height=1,width=20
run_btn.grid(row=3,column=1, sticky="ew", pady=2)
#---------------------------------------------------------------------
lbl_display = tk.Label(main,text="Minimum Display Qty")
lbl_display.grid(row=2,column=0,sticky="w",pady=(2,0))

entry_display = tk.Entry(main,width=6)
entry_display.insert(0,"1")
entry_display.grid(row=3,column=0,sticky="w")
#---------------------------------------------------------------------
# Country
lbl_country = tk.Label(main,text="Select Country")
lbl_country.grid(row=4,column=0,sticky="w",pady=(2,0))

dropdown_display = ttk.Combobox(main, textvariable=selected_item, values=countries)
dropdown_display.grid(row=5,column=0,sticky="w")
dropdown_display.current(0)
#---------------------------------------------------------------------
# Season
lbl_season = tk.Label(main,text="Select Season")
lbl_season.grid(row=4,column=1,sticky="w",pady=(2,0))

entry_season = ttk.Combobox(main, textvariable=selected_season, values=seasons)
entry_season.grid(row=5,column=1,sticky="w")
entry_season.current(0)
#---------------------------------------------------------------------
# Type
lbl_type = tk.Label(main,text="Select Type")
lbl_type.grid(row=6,column=0,sticky="w",pady=(2,0))

entry_type = ttk.Combobox(main, textvariable=selected_types, values=types)
entry_type.grid(row=7,column=0,sticky="w")
entry_type.current(0)
#---------------------------------------------------------------------
root.mainloop()