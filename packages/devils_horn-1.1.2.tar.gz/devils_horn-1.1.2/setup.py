from setuptools import setup, find_packages

setup(
    name='devils_horn',
    version='1.1.2',
    packages=find_packages(),
    install_requires=[
        'rich',
    ],
    description='A Python package for encryption and decryption using the Devil\'s Horn method.',
    author='0xP4bl0',
    entry_points={
        'console_scripts': [
            'devils_horn=devils_horn:main',
        ],
    },
)