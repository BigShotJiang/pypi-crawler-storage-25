"""Concrete-owned mapping helpers."""
