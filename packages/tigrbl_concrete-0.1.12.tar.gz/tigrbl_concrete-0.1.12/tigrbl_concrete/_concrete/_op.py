# tigrbl/_concrete/_op.py
from __future__ import annotations

from dataclasses import replace
from typing import Any

from tigrbl_base._base._op_base import OpBase


class Op(OpBase):
    """Declarative operation descriptor with optional engine binding."""

    __slots__ = ()

    def __set_name__(self, owner: type, name: str) -> None:  # noqa: D401
        spec = self
        alias = self.alias or name
        if self.table is not owner or self.alias != alias:
            spec = replace(self, table=owner, alias=alias)
        ops = list(getattr(owner, "__tigrbl_ops__", ()) or [])
        ops.append(spec)
        owner.__tigrbl_ops__ = tuple(ops)

    def install_engines(
        self, *, router: Any | None = None, model: type | None = None
    ) -> None:
        from ._engine import Engine

        m = model if model is not None else self.table
        if m is not None:
            Engine.install_from_objects(router=router, tables=(m,))
