/**
 * @author Ivano Bilenchi
 *
 * @copyright Copyright (c) 2022 Ivano Bilenchi <https://ivanobilenchi.com>
 * @copyright SPDX-License-Identifier: ISC
 */

#ifndef UHASH_TESTS_H
#define UHASH_TESTS_H

void uhash_test_memory(void);
void uhash_test_base(void);
void uhash_test_map(void);
void uhash_test_set(void);
void uhash_test_per_instance(void);

#define UHASH_TESTS                                                                                \
    uhash_test_memory, uhash_test_base, uhash_test_map, uhash_test_set, uhash_test_per_instance

#endif // UHASH_TESTS_H
