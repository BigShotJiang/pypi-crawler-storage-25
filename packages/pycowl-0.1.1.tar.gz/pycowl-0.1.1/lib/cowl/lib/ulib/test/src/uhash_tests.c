/**
 * @author Ivano Bilenchi
 *
 * @copyright Copyright (c) 2019 Ivano Bilenchi <https://ivanobilenchi.com>
 * @copyright SPDX-License-Identifier: ISC
 */

#include "uhash_tests.h"
#include "ulib.h"
#include <stddef.h>
#include <stdint.h>

enum { MAX_VAL = 100 };

UHASH_INIT(IntHash, uint32_t, uint32_t, ulib_hash_int32, ulib_eq)
UHASH_INIT_PI(IntHashPi, uint32_t, uint32_t, NULL, NULL)

static ulib_uint int32_hash(uint32_t num) {
    return ulib_hash_int32(num);
}

static bool int32_eq(uint32_t lhs, uint32_t rhs) {
    return lhs == rhs;
}

void uhash_test_memory(void) {
    UHash(IntHash) set = uhset(IntHash);

    utest_assert_ok(uhash_put(IntHash, &set, 0, NULL));
    utest_assert_uint(uhash_count(IntHash, &set), ==, 1);

    ulib_uint buckets = uhash_size(IntHash, &set);
    utest_assert_ok(uhash_resize(IntHash, &set, 200));
    utest_assert_uint(uhash_size(IntHash, &set), >, buckets);

    buckets = uhash_size(IntHash, &set);
    utest_assert_ok(uhash_resize(IntHash, &set, 100));
    utest_assert_uint(uhash_size(IntHash, &set), <, buckets);

    buckets = uhash_size(IntHash, &set);
    utest_assert_ok(uhash_shrink(IntHash, &set));
    utest_assert_uint(uhash_size(IntHash, &set), <, buckets);

    buckets = uhash_size(IntHash, &set);
    uhash_clear(IntHash, &set);
    utest_assert_uint(uhash_size(IntHash, &set), ==, buckets);
    utest_assert_uint(uhash_count(IntHash, &set), ==, 0);

    UHash(IntHash) oset = set;
    UHash(IntHash) nset = uhash_move(IntHash, &oset);
    utest_assert(set._exp == nset._exp && set._is_map == nset._is_map &&
                 set._count == nset._count && set._flags == nset._flags && set._keys == nset._keys);
    utest_assert(!oset._exp && !oset._is_map && !set._count && !oset._flags && !oset._keys);

    uhash_deinit(IntHash, &set);
}

void uhash_test_base(void) {
    UHash(IntHash) set = uhset(IntHash);

    utest_assert(uhash_get(IntHash, &set, 0) == UHASH_INDEX_MISSING);
    utest_assert_uint(uhash_count(IntHash, &set), ==, 0);

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        utest_assert_ok(uhash_put(IntHash, &set, i, NULL));
    }

    utest_assert_uint(uhash_count(IntHash, &set), ==, MAX_VAL);

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        ulib_uint idx = uhash_get(IntHash, &set, i);
        utest_assert(idx != UHASH_INDEX_MISSING);
        utest_assert(uhash_exists(IntHash, &set, idx));
        utest_assert_uint(uhash_key(IntHash, &set, idx), ==, i);
    }

    utest_assert(uhash_get(IntHash, &set, 200) == UHASH_INDEX_MISSING);

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        ulib_uint idx = uhash_get(IntHash, &set, i);
        uhash_delete(IntHash, &set, idx);
        utest_assert(uhash_get(IntHash, &set, i) == UHASH_INDEX_MISSING);
    }

    utest_assert_uint(uhash_count(IntHash, &set), ==, 0);

    uhash_deinit(IntHash, &set);
}

void uhash_test_map(void) {
    UHash(IntHash) map = uhmap(IntHash);

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        utest_assert_ok(uhmap_set(IntHash, &map, i, i, NULL));
        ulib_uint idx = uhash_get(IntHash, &map, i);
        utest_assert_uint(uhash_key(IntHash, &map, idx), ==, i);
        utest_assert_uint(uhmap_val(IntHash, &map, idx), ==, i);
    }

    uhash_foreach (IntHash, &map, it) {
        utest_assert_uint(uhash_key_idx(IntHash, &map, it.key), ==, it.i);
        utest_assert_uint(uhmap_val_idx(IntHash, &map, it.val), ==, it.i);
    }

    UHash(IntHash) set = uhset(IntHash);
    utest_assert_ok(uhash_copy_as_set(IntHash, &map, &set));
    utest_assert(uhset_equals(IntHash, &set, &map));
    uhash_deinit(IntHash, &set);

    uint32_t existing_val;
    utest_assert_ret(uhmap_set(IntHash, &map, 0, 1, &existing_val), ULIB_NO);
    utest_assert_uint(existing_val, ==, 0);

    utest_assert_ret(uhmap_add(IntHash, &map, 0, 1, &existing_val), ULIB_NO);
    utest_assert_uint(existing_val, ==, 1);

    utest_assert(uhmap_replace(IntHash, &map, 0, 0, &existing_val));
    utest_assert_uint(uhmap_get(IntHash, &map, 0, UINT32_MAX), ==, 0);
    utest_assert_uint(existing_val, ==, 1);

    utest_assert_ok(uhmap_add(IntHash, &map, MAX_VAL, MAX_VAL, &existing_val));
    utest_assert(uhmap_remove(IntHash, &map, MAX_VAL));

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        uint32_t existing_key;
        utest_assert(uhmap_pop(IntHash, &map, i, &existing_key, &existing_val));
        utest_assert_uint(existing_key, ==, i);
        utest_assert_uint(existing_val, ==, i);
    }

    uhash_deinit(IntHash, &map);
}

void uhash_test_set(void) {
    UHash(IntHash) set = uhset(IntHash);

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        utest_assert_ok(uhset_insert(IntHash, &set, i));
    }

    utest_assert_ret(uhset_insert(IntHash, &set, 0), ULIB_NO);
    utest_assert_uint(uhash_count(IntHash, &set), ==, MAX_VAL);

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        uint32_t existing;
        utest_assert_ret(uhset_insert_get_existing(IntHash, &set, i, &existing), ULIB_NO);
        utest_assert_uint(existing, ==, i);
    }

    uint32_t elements[MAX_VAL + 1];
    for (uint32_t i = 0; i < MAX_VAL + 1; ++i) {
        elements[i] = i;
    }

    utest_assert_ok(uhash_populate(IntHash, &set, elements, NULL, MAX_VAL + 1));
    utest_assert(uhash_contains(IntHash, &set, MAX_VAL));
    utest_assert(uhset_remove(IntHash, &set, MAX_VAL));
    utest_assert_false(uhash_contains(IntHash, &set, MAX_VAL));

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        uint32_t existing;
        utest_assert(uhset_pop(IntHash, &set, i, &existing));
        utest_assert_uint(existing, ==, i);
    }

    UHash(IntHash) other_set = uhset(IntHash);
    uhash_populate(IntHash, &set, elements, NULL, MAX_VAL);
    uhash_populate(IntHash, &other_set, elements, NULL, MAX_VAL / 2);

    utest_assert(uhset_is_superset(IntHash, &set, &other_set));
    utest_assert_false(uhset_is_superset(IntHash, &other_set, &set));

    utest_assert_false(uhset_equals(IntHash, &set, &other_set));
    uhash_populate(IntHash, &other_set, elements, NULL, MAX_VAL);
    utest_assert(uhset_equals(IntHash, &set, &other_set));

    uhash_deinit(IntHash, &other_set);
    other_set = uhset(IntHash);
    utest_assert_ok(uhash_copy(IntHash, &set, &other_set));
    utest_assert(uhset_equals(IntHash, &set, &other_set));
    uhash_deinit(IntHash, &other_set);

    other_set = uhset(IntHash);
    UHash(IntHash) temp = uhset(IntHash);

    uhset_insert(IntHash, &other_set, MAX_VAL);
    utest_assert_ok(uhset_union(IntHash, &other_set, &set, &temp));
    utest_assert(uhset_equals(IntHash, &temp, &set));
    utest_assert(uhset_is_superset(IntHash, &other_set, &set));
    utest_assert_false(uhset_is_superset(IntHash, &set, &other_set));

    uhash_clear(IntHash, &temp);
    utest_assert_ok(uhset_diff(IntHash, &other_set, &set, &temp));
    utest_assert(uhash_count(IntHash, &other_set) == 1);
    utest_assert(uhash_count(IntHash, &temp) == MAX_VAL);
    uint32_t element = uhset_get_any(IntHash, &other_set, 0);
    utest_assert_uint(element, ==, MAX_VAL);

    uhash_clear(IntHash, &temp);
    uhset_union(IntHash, &other_set, &set, NULL);
    uhset_intersect(IntHash, &other_set, &set, &temp);
    utest_assert(uhset_equals(IntHash, &other_set, &set));
    utest_assert(uhash_count(IntHash, &temp) == 1);
    element = uhset_get_any(IntHash, &temp, 0);
    utest_assert_uint(element, ==, MAX_VAL);

    uhash_deinit(IntHash, &other_set);
    uhash_deinit(IntHash, &temp);

    element = uhset_get_any(IntHash, &set, MAX_VAL);
    utest_assert_uint(element, !=, MAX_VAL);

    uint32_t replaced;
    utest_assert(uhset_replace(IntHash, &set, element, &replaced));
    utest_assert_uint(replaced, ==, element);

    uhash_clear(IntHash, &set);
    element = uhset_get_any(IntHash, &set, MAX_VAL);
    utest_assert_uint(element, ==, MAX_VAL);

    uhash_deinit(IntHash, &set);
}

void uhash_test_per_instance(void) {
    UHash(IntHashPi) map = uhmap_pi(IntHashPi, int32_hash, int32_eq);

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        utest_assert_ok(uhmap_set(IntHashPi, &map, i, i, NULL));
    }

    uint32_t existing_val;
    utest_assert_ret(uhmap_set(IntHashPi, &map, 0, 1, &existing_val), ULIB_NO);
    utest_assert_uint(existing_val, ==, 0);

    utest_assert_ret(uhmap_add(IntHashPi, &map, 0, 1, &existing_val), ULIB_NO);
    utest_assert_uint(existing_val, ==, 1);

    utest_assert(uhmap_replace(IntHashPi, &map, 0, 0, &existing_val));
    utest_assert_uint(uhmap_get(IntHashPi, &map, 0, UINT32_MAX), ==, 0);
    utest_assert_uint(existing_val, ==, 1);

    utest_assert_ok(uhmap_add(IntHashPi, &map, MAX_VAL, MAX_VAL, &existing_val));
    utest_assert(uhmap_remove(IntHashPi, &map, MAX_VAL));

    for (uint32_t i = 0; i < MAX_VAL; ++i) {
        uint32_t existing_key;
        utest_assert(uhmap_pop(IntHashPi, &map, i, &existing_key, &existing_val));
        utest_assert_uint(existing_key, ==, i);
        utest_assert_uint(existing_val, ==, i);
    }

    uhash_deinit(IntHashPi, &map);
}
