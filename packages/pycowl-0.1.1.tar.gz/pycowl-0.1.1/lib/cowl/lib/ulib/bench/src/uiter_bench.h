/**
 * @author Ivano Bilenchi
 *
 * @copyright Copyright (c) 2025 Ivano Bilenchi <https://ivanobilenchi.com>
 * @copyright SPDX-License-Identifier: ISC
 */

#ifndef UITER_BENCH_H
#define UITER_BENCH_H

#include "uattrs.h"

ULIB_BEGIN_DECLS

void bench_uiter(void);

ULIB_END_DECLS

#endif // UITER_BENCH_H
