/**
 * Defines CowlAxiomFilter and declares its API.
 *
 * @author Ivano Bilenchi
 *
 * @copyright Copyright (c) 2024 SisInf Lab, Polytechnic University of Bari
 * @copyright <http://swot.sisinflab.poliba.it>
 * @copyright SPDX-License-Identifier: EPL-2.0
 *
 * @file
 */

#ifndef COWL_AXIOM_FILTER_H
#define COWL_AXIOM_FILTER_H

#include "cowl_any.h"
#include "cowl_attrs.h"
#include "cowl_axiom_flags.h"
#include "cowl_axiom_type.h"
#include "cowl_iterator.h"
#include "cowl_object.h"
#include "cowl_ret.h"
#include "cowl_vector.h"
#include "ulib.h"

COWL_BEGIN_DECLS

/// Axiom filter.
typedef struct CowlAxiomFilter {

    /// Match axioms of the specified types.
    CowlAxiomFlags types;

    /// Match axioms referencing all the specified primitives.
    UVec(CowlObjectPtr) primitives;

    /// Match axioms based on the specified closure.
    CowlFilter closure;

} CowlAxiomFilter;

/**
 * @defgroup CowlAxiomFilter CowlAxiomFilter API
 * @{
 */

/**
 * Returns a new axiom filter.
 *
 * @param types Axiom types.
 * @return Axiom filter.
 */
COWL_CONST
COWL_INLINE
CowlAxiomFilter cowl_axiom_filter(CowlAxiomFlags types) {
    CowlAxiomFilter ret = { types, uvec(CowlObjectPtr), ulib_zero_init };
    return ret;
}

/**
 * De-initializes an axiom filter previously initialized via @func{cowl_axiom_filter}.
 *
 * @param filter Axiom filter.
 */
COWL_INLINE
void cowl_axiom_filter_deinit(CowlAxiomFilter *filter) {
    uvec_foreach (CowlObjectPtr, &filter->primitives, p) {
        cowl_release(*p.item);
    }
    uvec_deinit(CowlObjectPtr, &filter->primitives);
}

/**
 * Adds the specified axiom type to the filter.
 *
 * @param filter Axiom filter.
 * @param type Axiom type.
 */
COWL_INLINE
void cowl_axiom_filter_add_type(CowlAxiomFilter *filter, CowlAxiomType type) {
    filter->types = cowl_axiom_flags_add_type(filter->types, type);
}

/**
 * Removes the specified axiom type from the filter.
 *
 * @param filter Axiom filter.
 * @param type Axiom type.
 */
COWL_INLINE
void cowl_axiom_filter_remove_type(CowlAxiomFilter *filter, CowlAxiomType type) {
    filter->types = cowl_axiom_flags_remove_type(filter->types, type);
}

/**
 * Adds the specified primitive to the filter.
 *
 * @param filter Axiom filter.
 * @param primitive Primitive.
 * @return Return code.
 */
COWL_INLINE
cowl_ret cowl_axiom_filter_add_primitive(CowlAxiomFilter *filter, CowlAnyPrimitive *primitive) {
    ulib_ret const ret = uvec_push_unique(CowlObjectPtr, &filter->primitives, primitive);
    if (ulib_is_err(ret)) return cowl_ret_from_ulib(ret);
    if (ret == ULIB_OK) cowl_retain(primitive);
    return COWL_OK;
}

/**
 * Removes the specified primitive from the filter.
 *
 * @param filter Axiom filter.
 * @param primitive Primitive.
 */
COWL_INLINE
void cowl_axiom_filter_remove_primitive(CowlAxiomFilter *filter, CowlAnyPrimitive *primitive) {
    if (uvec_unordered_remove(CowlObjectPtr, &filter->primitives, primitive)) {
        cowl_release(primitive);
    }
    uvec_shrink(CowlObjectPtr, &filter->primitives);
}

/**
 * Sets the filter closure.
 *
 * @param filter Axiom filter.
 * @param closure Filter closure.
 */
COWL_INLINE
void cowl_axiom_filter_set_closure(CowlAxiomFilter *filter, CowlFilter closure) {
    filter->closure = closure;
}

/// @}

COWL_END_DECLS

#endif // COWL_AXIOM_FILTER_H
