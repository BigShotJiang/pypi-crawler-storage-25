"""Component behaviour tools for BPA API.

This module provides MCP tools for managing component behaviours
in the BPA API. Component behaviours link determinants to form
components via effects that control component visibility, activation,
and other properties.

The BPA API does NOT have a direct endpoint to list all component
behaviours for a service. This module extracts behaviours from the
service export endpoint.

API Endpoints referenced:
- POST /download_service/{service_id} - Export service with componentBehaviours
- GET /service/{service_id}/behaviour/{component_key} - Get behaviour by component
- GET /behaviour/{id} - Get behaviour by ID
- POST /service/{service_id}/behaviour - Create component behaviour

Architecture (from bpa-determinants-research.md)::

    Form Component
        -> behaviourId -> componentBehaviours[id]
                            -> effects[]
                                -> jsonDeterminants (JSONLogic expression)
                                -> propertyEffects[]
                                    -> name: show|hide|enable|disable|etc.
                                    -> value: "true"|"false"
"""

from __future__ import annotations

import json
import logging
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import AuditLogger
from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    BPANotFoundError,
    translate_error,
)
from mcp_eregistrations_bpa.config import resolve_db_path
from mcp_eregistrations_bpa.tools._determinant_shared import build_determinant_refs
from mcp_eregistrations_bpa.tools._form_shared import parse_form_schema
from mcp_eregistrations_bpa.tools.formio_helpers import find_component
from mcp_eregistrations_bpa.tools.forms import FORM_TYPES
from mcp_eregistrations_bpa.tools.large_response import large_response_handler

logger = logging.getLogger(__name__)

__all__ = [
    "componentbehaviour_list",
    "componentbehaviour_get",
    "componentbehaviour_get_by_component",
    "componentbehaviour_repair_metadata",
    "effect_create",
    "effect_delete",
    "effect_row_delete",
    "register_behaviour_tools",
]

# Valid effect types for property effects
VALID_EFFECT_TYPES = ["activate", "deactivate", "show", "hide", "enable", "disable"]

# Valid logic operators for combining determinants
VALID_LOGIC_OPERATORS = ["AND", "OR"]


@large_response_handler(
    threshold_bytes=50 * 1024,  # 50KB threshold for list tools
    navigation={
        "list_all": "jq '.behaviours'",
        "find_by_key": "jq '.behaviours[] | select(.component_key==\"x\")'",
        "with_effects": "jq '.behaviours[] | select(.effect_count > 0)'",
    },
)
async def componentbehaviour_list(
    service_id: str | int, instance: str | None = None
) -> dict[str, Any]:
    """List component behaviours for a service.

    Extracts behaviours from service export (no direct BPA endpoint exists).
    Large responses (>50KB) are saved to file with navigation hints.

    Args:
        service_id: Service ID to list behaviours for.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with behaviours (id, component_key, effect_count), total, service_id.
    """
    # Validate service_id
    if not service_id or (isinstance(service_id, str) and not service_id.strip()):
        raise ToolError(
            "'service_id' is required. Use 'service_list' to see available services."
        )

    try:
        async with BPAClient.for_instance(instance) as client:
            # First verify service exists
            try:
                await client.get(
                    "/service/{id}",
                    path_params={"id": service_id},
                    resource_type="service",
                    resource_id=service_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Service '{service_id}' not found. "
                    "Use 'service_list' to see available services."
                ) from None

            # Fetch service export to get componentBehaviours
            # Use minimal export options - only need behaviours data
            export_options = {
                "serviceSelected": True,
                "registrationsSelected": True,
                "determinantsSelected": True,
                "guideFormSelected": True,
                "applicantFormSelected": True,
                "sendFileFormSelected": True,
                "paymentFormSelected": True,
                "costsSelected": False,
                "requirementsSelected": False,
                "resultsSelected": False,
                "activityConditionsSelected": False,
                "registrationLawsSelected": False,
                "serviceLocationsSelected": False,
                "serviceTutorialsSelected": False,
                "serviceTranslationsSelected": False,
                "catalogsSelected": False,
                "rolesSelected": False,
                "printDocumentsSelected": False,
                "botsSelected": False,
                "copyService": False,
            }

            try:
                export_data, _ = await client.download_service(
                    str(service_id),
                    options=export_options,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Service '{service_id}' not found. "
                    "Use 'service_list' to see available services."
                ) from None

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="service", resource_id=service_id) from e

    # Extract behaviours from export data
    behaviours = _extract_behaviours_from_export(export_data)

    return {
        "behaviours": behaviours,
        "total": len(behaviours),
        "service_id": str(service_id),
    }


async def componentbehaviour_get(
    behaviour_id: str, instance: str | None = None
) -> dict[str, Any]:
    """Get behaviour configuration with parsed JSONLogic determinants.

    Args:
        behaviour_id: Behaviour UUID.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, component_key, service_id, effects (id, determinants,
        property_effects).
    """
    # Validate behaviour_id
    if not behaviour_id or (isinstance(behaviour_id, str) and not behaviour_id.strip()):
        raise ToolError(
            "'behaviour_id' is required. "
            "Use 'componentbehaviour_list' or 'form_component_get' "
            "to find behaviour IDs."
        )

    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                data = await client.get(
                    "/behaviour/{id}",
                    path_params={"id": behaviour_id},
                    resource_type="behaviour",
                    resource_id=behaviour_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Behaviour '{behaviour_id}' not found. "
                    "Use 'componentbehaviour_list' or 'form_component_get' "
                    "to find behaviour IDs."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="behaviour", resource_id=behaviour_id
        ) from e

    return _transform_behaviour(data)


def _extract_behaviours_from_export(
    export_data: dict[str, Any],
) -> list[dict[str, Any]]:
    """Extract and transform component behaviours from service export.

    Args:
        export_data: Raw service export data from BPA API.

    Returns:
        list: List of behaviour summaries with id, component_key, effect_count.
    """
    behaviours: list[dict[str, Any]] = []

    # Handle nested service structure (live API wraps in 'service' key)
    data = export_data
    if "service" in export_data and isinstance(export_data["service"], dict):
        data = export_data["service"]

    # Get componentBehaviours array
    component_behaviours = data.get("componentBehaviours", [])

    if not isinstance(component_behaviours, list):
        return behaviours

    for behaviour in component_behaviours:
        if not isinstance(behaviour, dict):
            continue

        behaviour_id = behaviour.get("id")
        component_key = behaviour.get("componentKey")
        effects = behaviour.get("effects", [])

        # Count effects
        effect_count = len(effects) if isinstance(effects, list) else 0

        behaviours.append(
            {
                "id": behaviour_id,
                "component_key": component_key,
                "effect_count": effect_count,
            }
        )

    return behaviours


async def componentbehaviour_get_by_component(
    service_id: str | int,
    component_key: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Get behaviour configuration for a component with parsed JSONLogic.

    Args:
        service_id: Service containing the component.
        component_key: Form component key.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, component_key, service_id, effects (id, determinants,
        property_effects).
    """
    # Validate parameters
    if not service_id or (isinstance(service_id, str) and not service_id.strip()):
        raise ToolError(
            "'service_id' is required. Use 'service_list' to see available services."
        )

    comp_key_empty = isinstance(component_key, str) and not component_key.strip()
    if not component_key or comp_key_empty:
        raise ToolError(
            "'component_key' is required. Use 'form_get' to see component keys."
        )

    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                data = await client.get(
                    "/service/{service_id}/behaviour/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="behaviour",
                )
            except BPANotFoundError:
                raise ToolError(
                    f"No behaviour found for component '{component_key}' "
                    f"in service '{service_id}'. The component may not have "
                    "conditional logic configured."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="behaviour") from e

    # Pass service_id to transformer for context (AC1 requirement)
    return _transform_behaviour(data, service_id=service_id)


def _parse_jsonlogic_condition(condition: dict[str, Any]) -> dict[str, Any]:
    """Parse a single JSONLogic condition into readable format.

    Converts conditions like:
        {"==": [{"var": "data.field"}, value]}
    into:
        {"field": "data.field", "operator": "==", "value": value}

    Args:
        condition: A JSONLogic condition object.

    Returns:
        dict: Parsed condition with field, operator, value.
    """
    if not isinstance(condition, dict):
        return {"raw": condition}

    # Check for and/or logic operators (nested conditions)
    for logic_op in ["and", "or"]:
        if logic_op in condition:
            nested = condition[logic_op]
            if isinstance(nested, list):
                parsed_conditions = [_parse_jsonlogic_condition(c) for c in nested]
                return {
                    "logic": logic_op,
                    "conditions": parsed_conditions,
                }
            return {"logic": logic_op, "raw": nested}

    # Check for comparison operators
    comparison_ops = ["==", "!=", ">", "<", ">=", "<=", "in", "===", "!=="]
    for op in comparison_ops:
        if op in condition:
            args = condition[op]
            if isinstance(args, list) and len(args) >= 2:
                # First arg should be {"var": "data.field"}
                var_ref = args[0]
                value = args[1]

                field = None
                if isinstance(var_ref, dict) and "var" in var_ref:
                    field = var_ref["var"]
                elif isinstance(value, dict) and "var" in value:
                    # Swap if var is second
                    field = value["var"]
                    value = var_ref

                if field:
                    return {
                        "field": field,
                        "operator": op,
                        "value": value,
                    }
            return {"operator": op, "raw": args}

    # Check for unary operators (!, !!)
    if "!" in condition:
        arg = condition["!"]
        if isinstance(arg, list) and len(arg) == 1:
            arg = arg[0]
        if isinstance(arg, dict) and "var" in arg:
            return {
                "field": arg["var"],
                "operator": "isEmpty",
                "value": True,
            }
        return {"operator": "not", "raw": arg}

    if "!!" in condition:
        arg = condition["!!"]
        if isinstance(arg, list) and len(arg) == 1:
            arg = arg[0]
        if isinstance(arg, dict) and "var" in arg:
            return {
                "field": arg["var"],
                "operator": "isNotEmpty",
                "value": True,
            }
        return {"operator": "truthy", "raw": arg}

    # Check for 'if' conditions
    if "if" in condition:
        return {"operator": "if", "raw": condition["if"]}

    # Unknown structure - return as raw
    return {"raw": condition}


def _parse_jsonlogic_expression(expr: Any) -> list[dict[str, Any]]:
    """Parse a JSONLogic expression (which may be an array) into readable format.

    The jsonDeterminants field is typically a JSON string containing an array
    of JSONLogic expressions, e.g.:
        '[{"and": [{"==": [{"var": "data.field"}, true]}, ...]}]'

    Args:
        expr: Parsed JSON (list or dict) from jsonDeterminants.

    Returns:
        list: List of parsed determinant conditions.
    """
    if expr is None:
        return []

    # If it's a list, parse each element
    if isinstance(expr, list):
        return [_parse_jsonlogic_condition(item) for item in expr]

    # If it's a single dict, wrap in list
    if isinstance(expr, dict):
        return [_parse_jsonlogic_condition(expr)]

    # Return as raw for unexpected types
    return [{"raw": expr}]


def _parse_json_determinants(
    json_determinants: str | list[dict[str, Any]] | dict[str, Any] | None,
) -> list[dict[str, Any]]:
    """Parse jsonDeterminants field into readable structure.

    Handles:
    - String: Parse JSON first, then parse JSONLogic
    - List: Parse each JSONLogic expression
    - Dict: Parse single JSONLogic expression
    - None: Return empty list

    Args:
        json_determinants: Raw jsonDeterminants value from API.

    Returns:
        list: Parsed determinants with readable structure.
    """
    if json_determinants is None:
        return []

    # Parse string to JSON first
    if isinstance(json_determinants, str):
        if not json_determinants.strip():
            return []
        try:
            parsed = json.loads(json_determinants)
            return _parse_jsonlogic_expression(parsed)
        except json.JSONDecodeError:
            # Return raw string as fallback
            return [{"raw": json_determinants}]

    # Already parsed - process directly
    return _parse_jsonlogic_expression(json_determinants)


def _transform_behaviour(
    data: dict[str, Any], service_id: str | int | None = None
) -> dict[str, Any]:
    """Transform behaviour API response to snake_case format with readable JSONLogic.

    Args:
        data: Raw API response with camelCase keys.
        service_id: Optional service ID to include in response for context.
            If not provided, will attempt to extract from API response.

    Returns:
        dict: Transformed response with:
            - id: Behaviour UUID
            - component_key: Form component key
            - service_id: Service ID for context (if available)
            - effects: List with id, determinants (readable format), property_effects
    """
    effects: list[dict[str, Any]] = []

    raw_effects = data.get("effects", [])
    if isinstance(raw_effects, list):
        for effect in raw_effects:
            if not isinstance(effect, dict):
                continue

            # Parse jsonDeterminants into readable format
            json_determinants = effect.get("jsonDeterminants")
            parsed_determinants = _parse_json_determinants(json_determinants)

            # Transform property effects
            property_effects = []
            for pe in effect.get("propertyEffects", []):
                if isinstance(pe, dict):
                    property_effects.append(
                        {
                            "name": pe.get("name"),
                            "value": pe.get("value"),
                        }
                    )

            effects.append(
                {
                    "id": effect.get("id"),
                    "determinants": parsed_determinants,
                    "property_effects": property_effects,
                }
            )

    # Determine service_id: use provided value, or extract from API response
    resolved_service_id = service_id
    if resolved_service_id is None:
        # Try to extract from API response (may be serviceId or service_id)
        resolved_service_id = data.get("serviceId") or data.get("service_id")

    return {
        "id": data.get("id"),
        "component_key": data.get("componentKey"),
        "service_id": str(resolved_service_id) if resolved_service_id else None,
        "effects": effects,
    }


def _build_property_effects_from_dimensions(
    dims: dict[str, bool],
) -> list[dict[str, str]]:
    """Build propertyEffects array from an explicit dimensions dict.

    Missing keys take UI-effective defaults: activate=True, show=True,
    disabled=False.

    Args:
        dims: Subset of {activate, show, disabled} with bool values.

    Returns:
        3-entry propertyEffects list matching the frontend data contract.
    """
    activate = "true" if dims.get("activate", True) else "false"
    show = "true" if dims.get("show", True) else "false"
    disabled = "true" if dims.get("disabled", False) else "false"
    return [
        {"name": "activate", "type": "boolean", "value": activate},
        {"name": "show", "type": "boolean", "value": show},
        {"name": "disabled", "type": "boolean", "value": disabled},
    ]


def _build_property_effects(
    effect_type: str, effect_value: bool
) -> list[dict[str, str]]:
    """Back-compat shortcut: effect_type + effect_value → propertyEffects.

    Wraps _build_property_effects_from_dimensions. Backend
    (ComponentBehaviourController.ensureCollapsedPropertyEffect) auto-adds
    `collapsed: false` regardless — that is out of scope for this builder.
    """
    dims: dict[str, bool] = {}
    if effect_type == "activate":
        dims["activate"] = effect_value
    elif effect_type == "deactivate":
        dims["activate"] = not effect_value
    elif effect_type == "show":
        dims["show"] = effect_value
    elif effect_type == "hide":
        dims["show"] = not effect_value
    elif effect_type == "enable":
        dims["disabled"] = not effect_value
    elif effect_type == "disable":
        dims["disabled"] = effect_value
    return _build_property_effects_from_dimensions(dims)


# UI-effective defaults for component raw properties. When the raw has the key
# set to None or missing entirely, the BPA frontend treats it as these values
# (verified against BPA-frontend/src/app/components/determinant-triggers/
# determinant-triggers-field/determinant-triggers-field.component.ts:184-190).
_UI_EFFECTIVE_DEFAULTS: dict[str, bool] = {
    "activate": True,
    "hidden": False,
    "disabled": False,
}


def _effective_ui_default(component_raw: dict[str, Any], prop: str) -> bool:
    """Get the UI-effective default for a component's raw property.

    Null or missing values are treated as the UI would render them.

    Args:
        component_raw: The component's raw dict from the form schema.
        prop: One of "activate", "hidden", "disabled".

    Returns:
        The effective boolean value.

    Raises:
        KeyError: If prop is not a known UI dimension.
    """
    if prop not in _UI_EFFECTIVE_DEFAULTS:
        raise KeyError(f"Unknown UI default property: {prop!r}")
    value = component_raw.get(prop)
    if value is None:
        return _UI_EFFECTIVE_DEFAULTS[prop]
    return bool(value)


def _prop_effect_value(
    property_effects: list[dict[str, str]], name: str
) -> bool | None:
    """Extract a boolean propertyEffect value by name, None if absent."""
    for pe in property_effects:
        if pe.get("name") == name:
            v = pe.get("value")
            return v == "true"
    return None


def _detect_noop(
    component_raw: dict[str, Any],
    property_effects: list[dict[str, str]],
) -> dict[str, Any] | None:
    """Detect if an effect is a no-op versus the component's current defaults.

    Uses the compound UI rule from BPA-frontend determinant-triggers-field:
      no-op if (activate effect = "false" AND matches default activate=false)
              OR (all 3 dimensions match their UI-effective defaults)

    Args:
        component_raw: Component's raw dict from the form schema.
        property_effects: The new effect's propertyEffects array (3 entries).

    Returns:
        None if effect is meaningful; dict with conflicting_dimensions and
        suggested_default_flip if no-op.
    """
    eff_activate = _prop_effect_value(property_effects, "activate")
    eff_show = _prop_effect_value(property_effects, "show")
    eff_disabled = _prop_effect_value(property_effects, "disabled")

    # UI-effective component defaults. Note: 'show' dimension in propertyEffects
    # corresponds to !hidden in component raw.
    def_activate = _effective_ui_default(component_raw, "activate")
    def_hidden = _effective_ui_default(component_raw, "hidden")
    def_disabled = _effective_ui_default(component_raw, "disabled")
    def_show = not def_hidden  # UI: show = !hidden

    activate_match = eff_activate is None or eff_activate == def_activate
    show_match = eff_show is None or eff_show == def_show
    disabled_match = eff_disabled is None or eff_disabled == def_disabled

    is_noop = (eff_activate is False and activate_match) or (
        activate_match and show_match and disabled_match
    )
    if not is_noop:
        return None

    conflicting: list[str] = []
    suggested_flip: dict[str, bool] = {}
    if eff_activate is not None and eff_activate == def_activate:
        conflicting.append("activate")
        suggested_flip["activate"] = not def_activate
    if eff_show is not None and eff_show == def_show:
        conflicting.append("show")
        suggested_flip["hidden"] = not def_hidden
    if eff_disabled is not None and eff_disabled == def_disabled:
        conflicting.append("disabled")
        suggested_flip["disabled"] = not def_disabled

    return {
        "conflicting_dimensions": conflicting,
        "suggested_default_flip": suggested_flip,
    }


def _validate_effect_create_params(
    service_id: str | int,
    component_key: str,
    determinant_ids: list[str],
    logic: str,
    effect_type: str,
    effect_value: bool,
) -> None:
    """Validate effect_create parameters (pre-flight validation).

    Args:
        service_id: Service ID (required).
        component_key: Form component key (required).
        determinant_ids: List of determinant IDs (required, non-empty).
        logic: Logic operator (AND or OR).
        effect_type: Effect type (activate, deactivate, show, hide, enable, disable).
        effect_value: Boolean value for the effect.

    Raises:
        ToolError: If validation fails.
    """
    errors = []

    if not service_id or (isinstance(service_id, str) and not service_id.strip()):
        errors.append("'service_id' is required")

    if not component_key or (
        isinstance(component_key, str) and not component_key.strip()
    ):
        errors.append("'component_key' is required")

    if not determinant_ids:
        errors.append("'determinant_ids' must contain at least one determinant ID")
    elif not isinstance(determinant_ids, list):
        errors.append("'determinant_ids' must be a list of determinant IDs")
    elif len(determinant_ids) == 0:
        errors.append("'determinant_ids' must contain at least one determinant ID")

    if logic and logic.upper() not in VALID_LOGIC_OPERATORS:
        errors.append(f"'logic' must be one of: {', '.join(VALID_LOGIC_OPERATORS)}")

    if effect_type and effect_type.lower() not in VALID_EFFECT_TYPES:
        errors.append(f"'effect_type' must be one of: {', '.join(VALID_EFFECT_TYPES)}")

    if not isinstance(effect_value, bool):
        errors.append("'effect_value' must be a boolean (true or false)")

    if errors:
        error_msg = "; ".join(errors)
        raise ToolError(
            f"Cannot create effect: {error_msg}. "
            "Provide valid parameters for effect creation."
        )


async def _fetch_determinant_details(
    client: BPAClient, determinant_id: str
) -> dict[str, Any]:
    """Fetch determinant details from BPA API.

    Args:
        client: BPA client instance.
        determinant_id: ID of the determinant to fetch.

    Returns:
        dict: Determinant data from API.

    Raises:
        ToolError: If determinant not found.
    """
    try:
        return await client.get(
            "/determinant/{id}",
            path_params={"id": determinant_id},
            resource_type="determinant",
            resource_id=determinant_id,
        )
    except BPANotFoundError:
        raise ToolError(
            f"Determinant '{determinant_id}' not found. "
            "Use 'determinant_list' with service_id to see available determinants."
        ) from None


async def _get_existing_behaviour(
    client: BPAClient, service_id: str | int, component_key: str
) -> dict[str, Any] | None:
    """Check if a behaviour already exists for a component.

    Args:
        client: BPA client instance.
        service_id: Service ID.
        component_key: Form component key.

    Returns:
        dict: Existing behaviour data, or None if not found.
    """
    try:
        return await client.get(
            "/service/{service_id}/behaviour/{component_key}",
            path_params={
                "service_id": service_id,
                "component_key": component_key,
            },
            resource_type="behaviour",
        )
    except BPANotFoundError:
        return None


async def _sync_behaviour_metadata_to_form(
    client: Any,
    service_id: str | int,
    component_key: str,
    behaviour_id: str | None,
    effects_ids: list[str],
    form_type: str = "applicant",
    capture_pre_mutation: dict[str, Any] | None = None,
) -> bool:
    """Sync behaviourId and effectsIds to form component.

    The BPA frontend updates these properties via postMessage after saving
    behaviours. MCP must do this explicitly so the form builder shows
    the correct behaviour state.

    Args:
        capture_pre_mutation: Optional mutable dict. If provided, the
            pre-mutation copy of the component is stored under
            capture_pre_mutation["pre_comp"] (deep-copied; None if component
            was not found). Used by effect_create for no-op detection
            without an extra form fetch.

    Best-effort: returns False on any error without raising.
    """
    try:
        form_config = FORM_TYPES.get(form_type)
        if not form_config:
            return False

        form_data = await client.get(
            form_config["get_endpoint"],
            path_params={"id": service_id},
            params={"reusable": "false"},
            resource_type="form",
        )
        form_schema = parse_form_schema(form_data)
        components = form_schema.get("components", [])
        comp_result = find_component(components, component_key)
        if comp_result is None:
            if capture_pre_mutation is not None:
                capture_pre_mutation["pre_comp"] = None
            return False

        comp, _ = comp_result
        if capture_pre_mutation is not None:
            import copy as _copy

            capture_pre_mutation["pre_comp"] = _copy.deepcopy(comp)
        comp["behaviourId"] = behaviour_id or ""
        comp["effectsIds"] = effects_ids
        form_data["formSchema"] = form_schema
        await client.put(
            form_config["put_endpoint"],
            path_params={"form_id": form_data["id"]},
            json=form_data,
            resource_type="form",
        )

        # Post-write verification (defensive fix for #82).
        # Refetches the form to confirm behaviourId + effectsIds persisted.
        # Race limit: verification checks consistency at time of check, not
        # specifically that OUR write succeeded — a concurrent write between
        # our PUT and refetch can produce a false negative.
        try:
            verify_form = await client.get(
                form_config["get_endpoint"],
                path_params={"id": service_id},
                params={"reusable": "false"},
                resource_type="form",
            )
            verify_schema = parse_form_schema(verify_form)
            verify_result = find_component(
                verify_schema.get("components", []), component_key
            )
            if verify_result is None:
                logger.warning(
                    "Post-write verification: component %s not found after PUT",
                    component_key,
                )
                return False
            verify_comp, _ = verify_result
            expected_bid = behaviour_id or ""
            if verify_comp.get("behaviourId") != expected_bid:
                logger.warning(
                    "Post-write verification failed for %s: behaviourId=%r "
                    "(expected %r)",
                    component_key,
                    verify_comp.get("behaviourId"),
                    expected_bid,
                )
                return False
            if verify_comp.get("effectsIds") != effects_ids:
                logger.warning(
                    "Post-write verification failed for %s: effectsIds=%r "
                    "(expected %r)",
                    component_key,
                    verify_comp.get("effectsIds"),
                    effects_ids,
                )
                return False
        except Exception:
            logger.debug(
                "Post-write verification errored (best-effort) for %s/%s",
                service_id,
                component_key,
                exc_info=True,
            )
            return False

        return True
    except Exception:
        logger.debug(
            "Best-effort behaviour metadata sync failed for %s/%s",
            service_id,
            component_key,
            exc_info=True,
        )
        return False


async def _sync_behaviour_metadata_to_role_form(
    client: Any,
    role_id: str,
    component_key: str,
    behaviour_id: str | None,
    effects_ids: list[str],
    capture_pre_mutation: dict[str, Any] | None = None,
) -> bool:
    """Sync behaviourId and effectsIds to a role form component.

    Role forms have independent formSchema stored on the Role entity,
    separate from the applicant form. The frontend reads effectsIds from
    the role form schema to display effect counters and hinting icons.

    Args:
        capture_pre_mutation: Optional mutable dict. If provided, the
            pre-mutation copy of the component is stored under
            capture_pre_mutation["pre_comp"].

    Best-effort: returns False on any error without raising.
    """
    try:
        role_data = await client.get(
            "/role/{role_id}",
            path_params={"role_id": role_id},
            resource_type="role",
            resource_id=role_id,
        )

        form_schema = parse_form_schema(role_data)
        components = form_schema.get("components", [])
        if not components:
            return False

        comp_result = find_component(components, component_key)
        if comp_result is None:
            if capture_pre_mutation is not None:
                capture_pre_mutation["pre_comp"] = None
            return False

        comp, _ = comp_result
        if capture_pre_mutation is not None:
            import copy as _copy

            capture_pre_mutation["pre_comp"] = _copy.deepcopy(comp)
        comp["behaviourId"] = behaviour_id or ""
        comp["effectsIds"] = effects_ids

        # Round-trip: PUT the role object back (matches applicant form pattern)
        role_data["formSchema"] = form_schema
        await client.put(
            "/role",
            json=role_data,
            resource_type="role",
            resource_id=role_data.get("id", role_id),
        )

        # Post-write verification (defensive fix for #82, role form variant).
        try:
            verify_role = await client.get(
                "/role/{role_id}",
                path_params={"role_id": role_id},
                resource_type="role",
                resource_id=role_id,
            )
            verify_schema = parse_form_schema(verify_role)
            verify_result = find_component(
                verify_schema.get("components", []), component_key
            )
            if verify_result is None:
                logger.warning(
                    "Post-write verification (role): component %s not found",
                    component_key,
                )
                return False
            verify_comp, _ = verify_result
            expected_bid = behaviour_id or ""
            if verify_comp.get("behaviourId") != expected_bid:
                logger.warning(
                    "Post-write verification (role) failed for %s: "
                    "behaviourId=%r (expected %r)",
                    component_key,
                    verify_comp.get("behaviourId"),
                    expected_bid,
                )
                return False
            if verify_comp.get("effectsIds") != effects_ids:
                logger.warning(
                    "Post-write verification (role) failed for %s: "
                    "effectsIds=%r (expected %r)",
                    component_key,
                    verify_comp.get("effectsIds"),
                    effects_ids,
                )
                return False
        except Exception:
            logger.debug(
                "Post-write verification (role) errored for %s/%s",
                role_id,
                component_key,
                exc_info=True,
            )
            return False

        return True
    except Exception:
        logger.debug(
            "Best-effort role form metadata sync failed for role %s / %s",
            role_id,
            component_key,
            exc_info=True,
        )
        return False


_VALID_DIMENSION_KEYS = frozenset({"activate", "show", "disabled"})


def _validate_dimensions_param(
    effect_type: str | None,
    dimensions: dict[str, bool] | None,
) -> None:
    """Validate dimensions + effect_type mutual exclusion and key/value types.

    Raises:
        ToolError: With codes EFFECT_DIMENSIONS_CONFLICT or
            EFFECT_INVALID_DIMENSION.
    """
    if dimensions is not None and effect_type is not None:
        raise ToolError(
            "[EFFECT_DIMENSIONS_CONFLICT] Pass either 'dimensions' OR "
            "'effect_type', not both. Use 'dimensions' for explicit control "
            "over activate/show/disabled; use 'effect_type' as a single-dim "
            "shortcut."
        )
    if dimensions is None:
        return
    invalid_keys = set(dimensions.keys()) - _VALID_DIMENSION_KEYS
    if invalid_keys:
        valid = ", ".join(sorted(_VALID_DIMENSION_KEYS))
        raise ToolError(
            f"[EFFECT_INVALID_DIMENSION] Unknown dimension keys: "
            f"{sorted(invalid_keys)}. Valid keys: {valid}."
        )
    for k, v in dimensions.items():
        if not isinstance(v, bool):
            raise ToolError(
                f"[EFFECT_INVALID_DIMENSION] Dimension '{k}' must be a bool "
                f"(True/False), got: {type(v).__name__}."
            )


async def _flip_component_defaults(
    client: Any,
    service_id: str | int,
    component_key: str,
    flip: dict[str, bool],
    role_id: str | None = None,
) -> bool:
    """PATCH the component raw to flip activate/hidden/disabled per `flip`.

    Performs GET form → mutate component → PUT form. Used by
    effect_create's auto_flip_default path.

    Raises:
        BPAClientError: On GET/PUT failure (caller must handle for rollback).

    Returns:
        True on success, False if the component cannot be located.
    """
    if role_id:
        form_data = await client.get(
            "/role/{role_id}",
            path_params={"role_id": role_id},
            resource_type="role",
            resource_id=role_id,
        )
        form_schema = parse_form_schema(form_data)
        comp_result = find_component(form_schema.get("components", []), component_key)
        if comp_result is None:
            return False
        comp, _ = comp_result
        for prop, value in flip.items():
            comp[prop] = value
        form_data["formSchema"] = form_schema
        await client.put(
            "/role",
            json=form_data,
            resource_type="role",
            resource_id=form_data.get("id", role_id),
        )
        return True

    form_config = FORM_TYPES["applicant"]
    form_data = await client.get(
        form_config["get_endpoint"],
        path_params={"id": service_id},
        params={"reusable": "false"},
        resource_type="form",
    )
    form_schema = parse_form_schema(form_data)
    comp_result = find_component(form_schema.get("components", []), component_key)
    if comp_result is None:
        return False
    comp, _ = comp_result
    for prop, value in flip.items():
        comp[prop] = value
    form_data["formSchema"] = form_schema
    await client.put(
        form_config["put_endpoint"],
        path_params={"form_id": form_data["id"]},
        json=form_data,
        resource_type="form",
    )
    return True


async def _fetch_target_component_raw(
    client: Any,
    service_id: str | int,
    component_key: str,
    role_id: str | None = None,
) -> dict[str, Any] | None:
    """Fetch the raw component dict from the form (applicant or role).

    Used for no-op detection preview and post-write verification.
    Returns None if the component cannot be located.
    """
    if role_id:
        form_data = await client.get(
            "/role/{role_id}",
            path_params={"role_id": role_id},
            resource_type="role",
            resource_id=role_id,
        )
    else:
        form_config = FORM_TYPES["applicant"]
        form_data = await client.get(
            form_config["get_endpoint"],
            path_params={"id": service_id},
            params={"reusable": "false"},
            resource_type="form",
        )
    form_schema = parse_form_schema(form_data)
    components = form_schema.get("components", [])
    result = find_component(components, component_key)
    if result is None:
        return None
    comp, _path = result
    return comp


async def effect_create(
    service_id: str | int,
    component_key: str,
    determinant_ids: list[str],
    logic: str = "AND",
    effect_type: str | None = None,
    effect_value: bool = True,
    dimensions: dict[str, bool] | None = None,
    auto_flip_default: bool = False,
    suppress_noop_warnings: bool = False,
    role_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create effect linking determinants to a component. Audited write operation.

    Each call creates ONE effect row under the component's behaviour. If a
    behaviour already exists for this component, a new effect row is
    APPENDED (no dedup; use effect_row_delete to remove individual rows).

    Two calling conventions:
      - Shortcut: effect_type + effect_value (sets one dimension; others
        take UI defaults activate=true, show=true, disabled=false).
      - Explicit: dimensions={"activate"?: bool, "show"?: bool,
        "disabled"?: bool} (any subset; missing keys take UI defaults).
    Pass one OR the other, not both. Unknown dimension keys raise
    [EFFECT_INVALID_DIMENSION].

    Effects override runtime state only when they differ from the
    component's raw defaults (activate/hidden/disabled). A positive-side
    effect against a positive-side default is a visibility no-op: the
    response includes a warning EFFECT_NOOP_VS_DEFAULT with a suggested
    default flip. Set auto_flip_default=True to have this tool atomically
    flip the default for you (rolls back the behaviour on flip failure).
    suppress_noop_warnings=True skips detection entirely.

    Note: the BPA backend auto-adds a `collapsed: false` propertyEffect on
    every create (via ComponentBehaviourController.ensureCollapsedPropertyEffect).
    That is backend behaviour, not controlled here.

    metadata_synced reflects post-write verification: after PUTing the
    form with behaviourId/effectsIds, we refetch and confirm persistence.
    A concurrent write between PUT and verify can produce a false
    negative; callers should treat False as "state inconsistent with
    what we wrote" and may retry via componentbehaviour_repair_metadata.

    Args:
        service_id: Parent service ID.
        component_key: Form component key to apply effect to.
        determinant_ids: Determinant IDs to combine (at least one).
        logic: "AND" (all match) or "OR" (any match). Default: "AND".
        effect_type: activate/deactivate/show/hide/enable/disable. Mutually
            exclusive with `dimensions`. Defaults to "activate" when
            neither is provided.
        effect_value: Boolean value for effect (default: True).
        dimensions: Explicit {activate?, show?, disabled?} → bool dict.
            Mutually exclusive with `effect_type`.
        auto_flip_default: If True and no-op detected, atomically flip the
            component's default on conflicting dimensions (default: False).
        suppress_noop_warnings: If True, skip no-op detection (default: False).
        role_id: Role ID when component is in a role form (syncs effectsIds
            to role).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with behaviour_id, effect_id, component_key, determinant_count,
        effect_type, effect_value, dimensions, logic, service_id, audit_id,
        metadata_synced, warnings (list of {code, message, details}),
        auto_flipped, flipped_dimensions.
    """
    # Pre-flight validation (no audit record for validation failures)
    _validate_dimensions_param(effect_type, dimensions)

    # Resolve effect_type default for back-compat: None + None dimensions → activate
    if effect_type is None and dimensions is None:
        effect_type = "activate"

    _validate_effect_create_params(
        service_id,
        component_key,
        determinant_ids,
        logic,
        effect_type or "activate",  # validator requires a string
        effect_value,
    )

    # Normalize parameters
    logic = logic.upper()
    if effect_type is not None:
        effect_type = effect_type.lower()

    # Get authenticated user for audit (before any API calls)
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    # Use single BPAClient connection for all operations
    try:
        async with BPAClient.for_instance(instance) as client:
            # Verify parent service exists before creating audit record
            try:
                await client.get(
                    "/service/{id}",
                    path_params={"id": service_id},
                    resource_type="service",
                    resource_id=service_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Cannot create effect: Service '{service_id}' not found. "
                    "Use 'service_list' to see available services."
                ) from None

            # Validate all determinants exist (fail fast before creating audit)
            for det_id in determinant_ids:
                await _fetch_determinant_details(client, det_id)

            # Build determinant reference JSON (UI format, not inline JSONLogic)
            json_determinants = build_determinant_refs(determinant_ids, logic)

            # Build property effects following UI visibility hierarchy
            # (from BPA-frontend determinant-triggers-field.component.html)
            #
            # UI semantic hierarchy (each level only visible if parent is true):
            #   Level 1: activate (always visible) - default=true
            #   Level 2: show (only if activate=true) - default=true
            #   Level 3: disabled (only if activate=true AND show=true) - default=false

            # Map effect_type or explicit dimensions to the 3 UI properties
            if dimensions is not None:
                property_effects = _build_property_effects_from_dimensions(dimensions)
            else:
                assert effect_type is not None
                property_effects = _build_property_effects(effect_type, effect_value)

            # Build the new effect
            new_effect = {
                "jsonDeterminants": json_determinants,
                "propertyEffects": property_effects,
            }

            warnings_list: list[dict[str, Any]] = []

            # Check if behaviour already exists for this component
            existing_behaviour = await _get_existing_behaviour(
                client, service_id, component_key
            )

            # Create audit record BEFORE API call (audit-before-write pattern)
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="create",
                object_type="effect",
                params={
                    "service_id": str(service_id),
                    "component_key": component_key,
                    "determinant_ids": determinant_ids,
                    "logic": logic,
                    "effect_type": effect_type,
                    "effect_value": effect_value,
                    "existing_behaviour_id": existing_behaviour.get("id")
                    if existing_behaviour
                    else None,
                },
            )

            try:
                if existing_behaviour:
                    # Add effect to existing behaviour
                    existing_effects = existing_behaviour.get("effects", [])
                    existing_effects.append(new_effect)

                    payload = {
                        "id": existing_behaviour.get("id"),
                        "componentKey": component_key,
                        "effects": existing_effects,
                    }

                    # Update via PUT /behaviour
                    result = await client.put(
                        "/behaviour",
                        json=payload,
                        resource_type="behaviour",
                        resource_id=existing_behaviour.get("id"),
                    )

                    behaviour_id = existing_behaviour.get("id")
                else:
                    # Create new behaviour
                    payload = {
                        "componentKey": component_key,
                        "effects": [new_effect],
                    }

                    result = await client.post(
                        "/service/{service_id}/behaviour",
                        path_params={"service_id": service_id},
                        json=payload,
                        resource_type="behaviour",
                    )

                    behaviour_id = result.get("id")

                # Extract effect ID from result
                effects = result.get("effects", [])
                effect_id = None
                if effects:
                    # The new effect should be the last one
                    effect_id = effects[-1].get("id")

                # Save rollback state
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="effect",
                    object_id=str(effect_id) if effect_id else str(behaviour_id),
                    previous_state={
                        "behaviour_id": behaviour_id,
                        "effect_id": effect_id,
                        "component_key": component_key,
                        "service_id": str(service_id),
                        "was_new_behaviour": existing_behaviour is None,
                        "_operation": "create",
                    },
                )

                # Sync behaviour metadata to form component (best-effort).
                # Capture the pre-mutation component raw for no-op detection,
                # piggy-backing on the sync helper's form fetch (avoids an
                # extra client.get call that would complicate test mocks).
                all_effect_ids = [e.get("id") for e in effects if e.get("id")]
                capture: dict[str, Any] = {}
                if role_id:
                    metadata_synced = await _sync_behaviour_metadata_to_role_form(
                        client,
                        role_id,
                        component_key,
                        behaviour_id,
                        all_effect_ids,
                        capture_pre_mutation=capture,
                    )
                else:
                    metadata_synced = await _sync_behaviour_metadata_to_form(
                        client,
                        service_id,
                        component_key,
                        behaviour_id,
                        all_effect_ids,
                        capture_pre_mutation=capture,
                    )

                # No-op detection against pre-mutation component raw
                # (captured from the sync helper's form fetch — no extra GET).
                auto_flipped = False
                flipped_dimensions: list[str] = []
                pre_comp = capture.get("pre_comp")
                noop_info: dict[str, Any] | None = None
                if pre_comp is not None and not suppress_noop_warnings:
                    try:
                        noop_info = _detect_noop(pre_comp, property_effects)
                    except Exception:
                        noop_info = None
                        logger.debug(
                            "No-op detection errored (best-effort) for %s/%s",
                            service_id,
                            component_key,
                            exc_info=True,
                        )

                if noop_info is not None and auto_flip_default:
                    # Atomic-on-success flip: PATCH component defaults now.
                    # If the flip PUT fails, roll back the behaviour.
                    flip = noop_info["suggested_default_flip"]
                    try:
                        flipped_ok = await _flip_component_defaults(
                            client,
                            service_id,
                            component_key,
                            flip,
                            role_id,
                        )
                        if flipped_ok:
                            auto_flipped = True
                            flipped_dimensions = list(flip.keys())
                    except BPAClientError as flip_err:
                        # Rollback: DELETE the behaviour we just created.
                        try:
                            await client.delete(
                                "/behaviour/{behaviour_id}",
                                path_params={"behaviour_id": behaviour_id},
                                resource_type="behaviour",
                                resource_id=behaviour_id,
                            )
                        except Exception:
                            logger.error(
                                "Auto-flip rollback DELETE failed for behaviour "
                                "%s; caller may be in partial state",
                                behaviour_id,
                                exc_info=True,
                            )
                        await audit_logger.mark_failed(
                            audit_id,
                            f"auto_flip_default PATCH failed: {flip_err}",
                        )
                        raise ToolError(
                            "[EFFECT_AUTO_FLIP_FAILED] auto_flip_default PATCH "
                            f"failed: {flip_err}. Behaviour was rolled back. "
                            "Retry without auto_flip_default or call "
                            "form_component_update separately."
                        ) from flip_err

                # Emit SYNC_VERIFICATION_FAILED warning when the sync helper
                # returned False (post-write verification caught a mismatch).
                if not metadata_synced:
                    warnings_list.append(
                        {
                            "code": "SYNC_VERIFICATION_FAILED",
                            "message": (
                                "The behaviour record was created but the form "
                                "component's behaviourId/effectsIds pointers did "
                                "not persist as expected. Call "
                                "componentbehaviour_repair_metadata to retry the "
                                "sync idempotently."
                            ),
                            "details": {
                                "retry_with": "componentbehaviour_repair_metadata",
                                "behaviour_id": behaviour_id,
                                "component_key": component_key,
                            },
                        }
                    )

                # Emit warning only when no-op + caller did NOT request flip
                if noop_info is not None and not auto_flip_default:
                    flip_hint = ", ".join(
                        f"{k}={v}"
                        for k, v in noop_info["suggested_default_flip"].items()
                    )
                    warnings_list.append(
                        {
                            "code": "EFFECT_NOOP_VS_DEFAULT",
                            "message": (
                                "Effect dimensions match current component "
                                "defaults; runtime behavior will be identical "
                                "to no effect. To make this effect meaningful, "
                                "set auto_flip_default=True or manually flip "
                                f"the component's default on: {flip_hint}."
                            ),
                            "details": noop_info,
                        }
                    )

                # Mark audit as success
                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "behaviour_id": behaviour_id,
                        "effect_id": effect_id,
                        "component_key": component_key,
                        "determinant_count": len(determinant_ids),
                    },
                )

                return {
                    "behaviour_id": behaviour_id,
                    "effect_id": effect_id,
                    "component_key": component_key,
                    "determinant_count": len(determinant_ids),
                    "effect_type": effect_type,
                    "effect_value": effect_value,
                    "dimensions": dimensions,
                    "logic": logic,
                    "service_id": str(service_id),
                    "audit_id": audit_id,
                    "metadata_synced": metadata_synced,
                    "warnings": warnings_list,
                    "auto_flipped": auto_flipped,
                    "flipped_dimensions": flipped_dimensions,
                }

            except BPAClientError as e:
                # Mark audit as failed
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="behaviour") from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="service", resource_id=service_id) from e


def _validate_effect_delete_params(
    behaviour_id: str,
    service_id: str | int,
    form_type: str = "applicant",
) -> None:
    """Validate effect_delete parameters (pre-flight validation).

    Args:
        behaviour_id: Behaviour ID to delete (required).
        service_id: Service containing the component (required).
        form_type: Form type (must be a valid key in FORM_TYPES).

    Raises:
        ToolError: If validation fails.
    """
    errors = []

    if not behaviour_id or (isinstance(behaviour_id, str) and not behaviour_id.strip()):
        errors.append(
            "'behaviour_id' is required. "
            "Use 'componentbehaviour_list' or 'componentbehaviour_get' "
            "to see available behaviours"
        )

    if not service_id or (isinstance(service_id, str) and not service_id.strip()):
        errors.append("'service_id' is required")

    if form_type not in FORM_TYPES:
        valid_types = ", ".join(sorted(FORM_TYPES.keys()))
        errors.append(f"'form_type' must be one of: {valid_types}")

    if errors:
        raise ToolError("; ".join(errors) + ".")


async def effect_delete(
    behaviour_id: str,
    service_id: str | int,
    form_type: str = "applicant",
    role_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a behaviour/effect from a component. Audited write operation.

    Clears stale behaviourId from the form component after deletion (best-effort).

    Args:
        behaviour_id: Behaviour UUID to delete.
        service_id: Service containing the component.
        form_type: Form type (applicant, guide, send_file, payment; default: applicant).
        role_id: Role ID when component is in a role form (clears effectsIds from role).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with deleted (bool), behaviour_id, deleted_behaviour,
        metadata_cleared, audit_id.
    """
    # Pre-flight validation (no audit record for validation failures)
    _validate_effect_delete_params(behaviour_id, service_id, form_type)

    # Get authenticated user for audit
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    # Use single BPAClient connection for all operations
    try:
        async with BPAClient.for_instance(instance) as client:
            # Capture current state for rollback BEFORE making changes
            try:
                previous_state = await client.get(
                    "/behaviour/{id}",
                    path_params={"id": behaviour_id},
                    resource_type="behaviour",
                    resource_id=behaviour_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"[BEHAVIOUR_NOT_FOUND] Behaviour '{behaviour_id}' not found. "
                    "Use 'componentbehaviour_list' or 'componentbehaviour_get' "
                    "to see available behaviours."
                ) from None

            # Create audit record BEFORE API call (audit-before-write pattern)
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type="behaviour",
                object_id=str(behaviour_id),
                params={
                    "service_id": str(service_id),
                    "form_type": form_type,
                },
            )

            # Save rollback state for undo capability
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="behaviour",
                object_id=str(behaviour_id),
                previous_state=previous_state,  # Full state for recreation
            )

            try:
                await client.delete(
                    "/behaviour/{behaviour_id}",
                    path_params={"behaviour_id": behaviour_id},
                    resource_type="behaviour",
                    resource_id=behaviour_id,
                )

                # Clear stale behaviourId and effectsIds from component
                component_key = previous_state.get("componentKey")
                metadata_cleared = False
                if component_key:
                    if role_id:
                        metadata_cleared = await _sync_behaviour_metadata_to_role_form(
                            client,
                            role_id,
                            component_key,
                            behaviour_id=None,
                            effects_ids=[],
                        )
                    else:
                        metadata_cleared = await _sync_behaviour_metadata_to_form(
                            client,
                            service_id,
                            component_key,
                            behaviour_id=None,
                            effects_ids=[],
                            form_type=form_type,
                        )

                # Mark audit as success
                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "deleted": True,
                        "behaviour_id": str(behaviour_id),
                        "metadata_cleared": metadata_cleared,
                    },
                )

                return {
                    "deleted": True,
                    "behaviour_id": str(behaviour_id),
                    "deleted_behaviour": {
                        "id": previous_state.get("id"),
                        "component_key": previous_state.get("componentKey"),
                        "effect_count": len(previous_state.get("effects", [])),
                    },
                    "metadata_cleared": metadata_cleared,
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                # Mark audit as failed
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type="behaviour", resource_id=behaviour_id
                ) from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="behaviour", resource_id=behaviour_id
        ) from e


async def effect_row_delete(
    effect_id: str,
    behaviour_id: str,
    service_id: str | int,
    delete_empty_behaviour: bool = True,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a single effect row from a behaviour. Audited write operation.

    Unlike effect_delete (which removes the entire behaviour), this tool
    removes one effect from the behaviour's effects[] list and updates the
    behaviour via PUT. If the last effect is removed and
    delete_empty_behaviour=True (default), the behaviour is also deleted.

    Args:
        effect_id: Effect row UUID to remove.
        behaviour_id: Parent behaviour UUID.
        service_id: Service containing the behaviour.
        delete_empty_behaviour: If True (default) and this was the last
            effect, also delete the behaviour. Set False to keep an empty
            behaviour shell for adding future effects.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with deleted, effect_id, behaviour_id, remaining_effect_count,
        behaviour_deleted (bool), audit_id.
    """
    if not effect_id or not str(effect_id).strip():
        raise ToolError("'effect_id' is required.")
    if not behaviour_id or not str(behaviour_id).strip():
        raise ToolError("'behaviour_id' is required.")

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                behaviour = await client.get(
                    "/behaviour/{id}",
                    path_params={"id": behaviour_id},
                    resource_type="behaviour",
                    resource_id=behaviour_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"[BEHAVIOUR_NOT_FOUND] Behaviour '{behaviour_id}' not found."
                ) from None

            effects = behaviour.get("effects", []) or []
            remaining = [e for e in effects if e.get("id") != effect_id]
            if len(remaining) == len(effects):
                raise ToolError(
                    f"[EFFECT_NOT_FOUND] Effect '{effect_id}' not found in "
                    f"behaviour '{behaviour_id}'. Use "
                    f"componentbehaviour_get_by_component to list effects."
                )

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type="effect",
                object_id=str(effect_id),
                params={
                    "behaviour_id": behaviour_id,
                    "service_id": str(service_id),
                    "delete_empty_behaviour": delete_empty_behaviour,
                },
            )
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="behaviour",
                object_id=str(behaviour_id),
                previous_state=behaviour,
            )

            behaviour_deleted = False
            metadata_cleared = False
            try:
                if not remaining and delete_empty_behaviour:
                    await client.delete(
                        "/behaviour/{behaviour_id}",
                        path_params={"behaviour_id": behaviour_id},
                        resource_type="behaviour",
                        resource_id=behaviour_id,
                    )
                    behaviour_deleted = True
                    # Clear stale behaviourId + effectsIds from the component
                    # raw (mirrors effect_delete's metadata_cleared step).
                    # Best-effort: sync helper returns False on any failure.
                    component_key = behaviour.get("componentKey")
                    if component_key:
                        metadata_cleared = await _sync_behaviour_metadata_to_form(
                            client,
                            service_id,
                            component_key,
                            behaviour_id=None,
                            effects_ids=[],
                        )
                else:
                    payload = {
                        "id": behaviour_id,
                        "componentKey": behaviour.get("componentKey"),
                        "effects": remaining,
                    }
                    await client.put(
                        "/behaviour",
                        json=payload,
                        resource_type="behaviour",
                        resource_id=behaviour_id,
                    )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "effect_id": effect_id,
                        "behaviour_id": behaviour_id,
                        "remaining_effect_count": len(remaining),
                        "behaviour_deleted": behaviour_deleted,
                        "metadata_cleared": metadata_cleared,
                    },
                )
                return {
                    "deleted": True,
                    "effect_id": effect_id,
                    "behaviour_id": behaviour_id,
                    "remaining_effect_count": len(remaining),
                    "behaviour_deleted": behaviour_deleted,
                    "metadata_cleared": metadata_cleared,
                    "audit_id": audit_id,
                }
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type="behaviour", resource_id=behaviour_id
                ) from e
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="behaviour", resource_id=behaviour_id
        ) from e


async def componentbehaviour_repair_metadata(
    service_id: str | int,
    dry_run: bool = True,
    instance: str | None = None,
) -> dict[str, Any]:
    """Repair missing effectsIds/behaviourId on form components.

    Audited write operation.

    Scans all forms (applicant + roles) for components that have behaviours
    in the backend but missing metadata in the form schema. The frontend
    needs effectsIds to display effect counters and hinting icons.

    Args:
        service_id: Service ID to repair.
        dry_run: If True, report issues without fixing (default: True).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with scanned, issues_found, fixed (if not dry_run), issues list.
    """
    if not service_id or (isinstance(service_id, str) and not service_id.strip()):
        raise ToolError(
            "'service_id' is required. Use 'service_list' to see available services."
        )

    if not dry_run:
        try:
            user_email = get_current_user_email(instance=instance)
        except NotAuthenticatedError as e:
            raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            # Export for behaviours + applicant form (roles have no ID in export)
            export_options = {
                "serviceSelected": True,
                "registrationsSelected": True,
                "determinantsSelected": True,
                "guideFormSelected": True,
                "applicantFormSelected": True,
                "sendFileFormSelected": True,
                "paymentFormSelected": True,
                "rolesSelected": False,  # Export roles have no ID — fetch separately
                "costsSelected": False,
                "requirementsSelected": False,
                "resultsSelected": False,
                "activityConditionsSelected": False,
                "registrationLawsSelected": False,
                "serviceLocationsSelected": False,
                "serviceTutorialsSelected": False,
                "serviceTranslationsSelected": False,
                "catalogsSelected": False,
                "printDocumentsSelected": False,
                "botsSelected": False,
                "copyService": False,
            }

            try:
                export_data, _ = await client.download_service(
                    str(service_id), options=export_options
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Service '{service_id}' not found. "
                    "Use 'service_list' to see available services."
                ) from None

            # Unwrap nested service structure
            data = export_data
            if "service" in export_data and isinstance(export_data["service"], dict):
                data = export_data["service"]

            # Build behaviour map: component_key -> {behaviour_id, effect_ids}
            behaviour_map: dict[str, dict[str, Any]] = {}
            for beh in data.get("componentBehaviours", []):
                if not isinstance(beh, dict):
                    continue
                comp_key = beh.get("componentKey")
                effects = beh.get("effects", [])
                if comp_key and effects:
                    effect_ids = [
                        e.get("id")
                        for e in effects
                        if isinstance(e, dict) and e.get("id")
                    ]
                    if effect_ids:
                        behaviour_map[comp_key] = {
                            "behaviour_id": beh.get("id"),
                            "effect_ids": effect_ids,
                        }

            issues: list[dict[str, Any]] = []
            forms_to_save: dict[str, Any] = {}

            # --- Applicant form ---
            applicant_form = data.get("applicantForm")
            if isinstance(applicant_form, dict):
                schema = parse_form_schema(applicant_form)
                _scan_form_components(schema, behaviour_map, "applicant", None, issues)
                if not dry_run and any(i["form_label"] == "applicant" for i in issues):
                    _apply_fixes_to_schema(schema, behaviour_map)
                    applicant_form["formSchema"] = schema
                    forms_to_save["applicant"] = {
                        "type": "form",
                        "endpoint": "/applicant-form/{form_id}",
                        "form_id": applicant_form.get("id"),
                        "payload": applicant_form,
                    }

            # --- Role forms (fetched individually — export has no role IDs) ---
            role_list = await client.get_list(
                "/service/{service_id}/role",
                path_params={"service_id": service_id},
                resource_type="role",
            )
            for role_summary in role_list:
                if not isinstance(role_summary, dict):
                    continue
                role_id = role_summary.get("id")
                role_name = role_summary.get("name", "Unknown")
                if not role_id:
                    continue

                # Fetch full role to get formSchema
                try:
                    role_data = await client.get(
                        "/role/{role_id}",
                        path_params={"role_id": role_id},
                        resource_type="role",
                        resource_id=role_id,
                    )
                except BPANotFoundError:
                    continue

                role_schema = parse_form_schema(role_data)
                components = role_schema.get("components", [])
                if not components:
                    continue

                label = f"role:{role_name}"
                pre_count = len(issues)
                _scan_form_components(
                    role_schema, behaviour_map, label, role_id, issues
                )

                if not dry_run and len(issues) > pre_count:
                    _apply_fixes_to_schema(role_schema, behaviour_map)
                    role_data["formSchema"] = role_schema
                    forms_to_save[f"role:{role_id}"] = {
                        "type": "role",
                        "role_id": role_id,
                        "role_name": role_name,
                        "payload": role_data,
                    }

            # --- Apply fixes ---
            fixed = 0
            errors: list[str] = []
            if not dry_run and forms_to_save:
                audit_logger = AuditLogger(db_path=resolve_db_path(instance))
                audit_id = await audit_logger.record_pending(
                    user_email=user_email,
                    operation_type="update",
                    object_type="behaviour_metadata_repair",
                    params={
                        "service_id": str(service_id),
                        "forms_to_fix": len(forms_to_save),
                        "issues_found": len(issues),
                    },
                )

                try:
                    for key, save_info in forms_to_save.items():
                        try:
                            if save_info["type"] == "form":
                                await client.put(
                                    save_info["endpoint"],
                                    path_params={"form_id": save_info["form_id"]},
                                    json=save_info["payload"],
                                    resource_type="form",
                                )
                            elif save_info["type"] == "role":
                                await client.put(
                                    "/role",
                                    json=save_info["payload"],
                                    resource_type="role",
                                    resource_id=save_info["role_id"],
                                )
                            fixed += sum(
                                1
                                for i in issues
                                if i.get("role_id") == save_info.get("role_id")
                                or (
                                    save_info["type"] == "form"
                                    and i["form_label"] == "applicant"
                                )
                            )
                        except Exception as e:
                            errors.append(f"{key}: {e}")

                    await audit_logger.mark_success(
                        audit_id,
                        result={
                            "fixed": fixed,
                            "errors": len(errors),
                        },
                    )
                except Exception:
                    await audit_logger.mark_failed(audit_id, "batch repair failed")
                    raise

            return {
                "service_id": str(service_id),
                "behaviours_scanned": len(behaviour_map),
                "issues_found": len(issues),
                "fixed": fixed if not dry_run else None,
                "dry_run": dry_run,
                "issues": issues[:50],  # Cap for readability
                "errors": errors if errors else None,
            }

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="service", resource_id=service_id) from e


def _scan_form_components(
    schema: dict[str, Any],
    behaviour_map: dict[str, dict[str, Any]],
    form_label: str,
    role_id: str | None,
    issues: list[dict[str, Any]],
) -> None:
    """Scan form components for missing/stale effectsIds metadata."""
    components = schema.get("components", [])
    _walk_components(components, behaviour_map, form_label, role_id, issues)


def _walk_components(
    components: list[dict[str, Any]],
    behaviour_map: dict[str, dict[str, Any]],
    form_label: str,
    role_id: str | None,
    issues: list[dict[str, Any]],
) -> None:
    """Recursively walk form.io components checking effectsIds."""
    for comp in components:
        if not isinstance(comp, dict):
            continue
        key = comp.get("key")
        if key and key in behaviour_map:
            expected = behaviour_map[key]
            current_effects = comp.get("effectsIds", [])
            current_behaviour = comp.get("behaviourId", "")

            if (
                set(current_effects) != set(expected["effect_ids"])
                or current_behaviour != expected["behaviour_id"]
            ):
                issues.append(
                    {
                        "component_key": key,
                        "form_label": form_label,
                        "role_id": role_id,
                        "expected_behaviour_id": expected["behaviour_id"],
                        "expected_effects_ids": expected["effect_ids"],
                        "current_behaviour_id": current_behaviour or None,
                        "current_effects_ids": current_effects or None,
                    }
                )

        # Recurse into children
        for child_key in ("components", "columns", "rows", "tabs"):
            children = comp.get(child_key, [])
            if isinstance(children, list):
                for item in children:
                    if isinstance(item, dict):
                        _walk_components(
                            [item], behaviour_map, form_label, role_id, issues
                        )
                    elif isinstance(item, list):
                        _walk_components(
                            item, behaviour_map, form_label, role_id, issues
                        )


def _apply_fixes_to_schema(
    schema: dict[str, Any],
    behaviour_map: dict[str, dict[str, Any]],
) -> None:
    """Apply effectsIds/behaviourId fixes to all matching components in schema."""
    components = schema.get("components", [])
    _apply_fixes_walk(components, behaviour_map)


def _apply_fixes_walk(
    components: list[dict[str, Any]],
    behaviour_map: dict[str, dict[str, Any]],
) -> None:
    """Recursively fix effectsIds on components."""
    for comp in components:
        if not isinstance(comp, dict):
            continue
        key = comp.get("key")
        if key and key in behaviour_map:
            expected = behaviour_map[key]
            comp["behaviourId"] = expected["behaviour_id"]
            comp["effectsIds"] = expected["effect_ids"]

        for child_key in ("components", "columns", "rows", "tabs"):
            children = comp.get(child_key, [])
            if isinstance(children, list):
                for item in children:
                    if isinstance(item, dict):
                        _apply_fixes_walk([item], behaviour_map)
                    elif isinstance(item, list):
                        _apply_fixes_walk(item, behaviour_map)


def register_behaviour_tools(mcp: Any) -> None:
    """Register behaviour tools with the MCP server.

    Args:
        mcp: The FastMCP server instance.
    """
    from mcp_eregistrations_bpa.tools.annotations import DESTRUCTIVE, READ, WRITE

    # Read operations
    mcp.tool(annotations=READ)(componentbehaviour_list)
    mcp.tool(annotations=READ)(componentbehaviour_get)
    mcp.tool(annotations=READ)(componentbehaviour_get_by_component)
    # Write operations
    mcp.tool(annotations=WRITE)(effect_create)
    mcp.tool(annotations=DESTRUCTIVE)(effect_delete)
    mcp.tool(annotations=DESTRUCTIVE)(effect_row_delete)
    mcp.tool(annotations=WRITE)(componentbehaviour_repair_metadata)
