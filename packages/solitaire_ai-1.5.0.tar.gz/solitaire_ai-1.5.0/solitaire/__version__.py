"""Solitaire — Version"""
__version__ = "1.4.1"
