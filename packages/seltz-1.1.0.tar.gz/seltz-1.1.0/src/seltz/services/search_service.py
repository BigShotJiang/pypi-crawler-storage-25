from typing import List, Optional, Union

import grpc

from .._types import OMIT, Omit
from ..exceptions import (
    SeltzAPIError,
    SeltzAuthenticationError,
    SeltzConnectionError,
    SeltzRateLimitError,
    SeltzTimeoutError,
)
from . import SearchRequest, SearchResponse, SeltzServiceStub


class SearchService:
    """Service for performing search operations via gRPC."""

    def __init__(self, channel: grpc.Channel, api_key: Optional[str] = None):
        """Initialize the search service.

        Args:
            channel (grpc.Channel):
                gRPC channel for communication.

            api_key (str, optional, default=None):
                API key for authentication.
        """
        self._stub = SeltzServiceStub(channel)
        self._api_key = api_key

    def search(
        self,
        query: str,
        *,
        max_results: int = 10,
        scope: Union[str, Omit] = OMIT,
        include_domains: Union[List[str], Omit] = OMIT,
        exclude_domains: Union[List[str], Omit] = OMIT,
        from_date: Union[str, Omit] = OMIT,
        to_date: Union[str, Omit] = OMIT,
    ) -> SearchResponse:
        """Perform a search query.

        Args:
            query (str):
                The query string.

            max_results (int, optional, default=10):
                The maximum number of search results to return.

            scope (str, optional):
                Restrict the search to a specific scope.
                Omitted from the request when not provided.

            include_domains (list[str], optional):
                Only include results from these domains (e.g., ["techcrunch.com"]).
                Omitted from the request when not provided.

            exclude_domains (list[str], optional):
                Exclude results from these domains.
                Omitted from the request when not provided.

            from_date (str, optional):
                Only include results published on or after this date (ISO 8601, e.g. "2025-10-28").
                Omitted from the request when not provided.

            to_date (str, optional):
                Only include results published on or before this date (ISO 8601, e.g. "2026-04-29").
                Omitted from the request when not provided.

        Raises:
            SeltzAuthenticationError: If the API key is invalid.
            SeltzConnectionError: If the connection to the API fails.
            SeltzTimeoutError: If the request times out.
            SeltzRateLimitError: If the rate limit is exceeded.
            SeltzAPIError: For other API errors.

        Returns:
            SearchResponse: The response containing the search results.
            Search results have URL and content fields provided as empty strings when not available.
        """
        req = SearchRequest(
            query=query,
            max_results=max_results,
            api_key=self._api_key,
            **({"scope": scope} if not isinstance(scope, Omit) else {}),
            **({"include_domains": include_domains} if not isinstance(include_domains, Omit) else {}),
            **({"exclude_domains": exclude_domains} if not isinstance(exclude_domains, Omit) else {}),
            **({"from_date": from_date} if not isinstance(from_date, Omit) else {}),
            **({"to_date": to_date} if not isinstance(to_date, Omit) else {}),
        )

        metadata = []
        if self._api_key:
            metadata.append(("authorization", f"Bearer {self._api_key}"))

        try:
            return self._stub.Search(req, metadata=metadata, timeout=30)

        except grpc.RpcError as e:
            if e.code() == grpc.StatusCode.UNAUTHENTICATED:
                raise SeltzAuthenticationError(
                    f"Authentication failed: {e.details()}"
                ) from e

            elif e.code() == grpc.StatusCode.UNAVAILABLE:
                raise SeltzConnectionError(f"Connection failed: {e.details()}") from e

            elif e.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
                raise SeltzTimeoutError(f"Request timed out: {e.details()}") from e

            elif e.code() == grpc.StatusCode.RESOURCE_EXHAUSTED:
                raise SeltzRateLimitError(f"Rate limit exceeded: {e.details()}") from e

            else:
                raise SeltzAPIError(
                    f"API error: {e.details()}", e.code(), e.details()
                ) from e
