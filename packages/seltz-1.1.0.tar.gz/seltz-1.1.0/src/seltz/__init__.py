"""Seltz Python SDK for interacting with the Seltz API."""

from .exceptions import (
    SeltzAPIError,
    SeltzAuthenticationError,
    SeltzConfigurationError,
    SeltzConnectionError,
    SeltzError,
    SeltzRateLimitError,
    SeltzTimeoutError,
)
from .seltz import Seltz
from .services import Document, SearchResponse
from ._types import OMIT, Omit

__all__ = [
    # Main client
    "Seltz",
    # Types (protobuf)
    "SearchResponse",
    "Document",
    # Sentinel
    "OMIT",
    "Omit",
    # Exceptions
    "SeltzError",
    "SeltzConfigurationError",
    "SeltzAuthenticationError",
    "SeltzConnectionError",
    "SeltzAPIError",
    "SeltzTimeoutError",
    "SeltzRateLimitError",
]
