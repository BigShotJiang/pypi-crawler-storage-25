import os
from typing import List, Optional, Union

from ._types import OMIT, Omit
from .client import SeltzClient
from .exceptions import SeltzConfigurationError
from .services import SearchResponse
from .services.search_service import SearchService


class Seltz:
    """A client for interacting with Seltz API."""

    _ENDPOINT: str = "grpc.seltz.ai"

    def __init__(
        self,
        api_key: Optional[str] = None,
        endpoint: str = _ENDPOINT,
        insecure: bool = False,
    ):
        """Initialize the Seltz client with the provided API key.

        Args:
            api_key (str, optional, default=None):
                The API key for authenticating with the Seltz API.
                If not provided, the value is read from the `SELTZ_API_KEY` environment variable.

            endpoint (str, optional, default=grpc.seltz.ai):
                The API endpoint for the Seltz API.

            insecure (bool, optional, default=False):
                Whether to use insecure connection.

        Raises:
            SeltzConfigurationError: If no API key is provided
        """

        self.endpoint = endpoint
        self.insecure = insecure

        api_key = api_key or os.environ.get("SELTZ_API_KEY")

        if api_key is None:
            raise SeltzConfigurationError(
                "API key not found. Pass `api_key` or set the `SELTZ_API_KEY` environment variable."
            )

        self._client = SeltzClient(
            endpoint=endpoint, api_key=api_key, insecure=insecure
        )

        self._search = SearchService(self._client.channel, self._client.api_key)

    def search(
        self,
        query: str,
        *,
        max_results: int = 10,
        scope: Union[str, Omit] = OMIT,
        include_domains: Union[List[str], Omit] = OMIT,
        exclude_domains: Union[List[str], Omit] = OMIT,
        from_date: Union[str, Omit] = OMIT,
        to_date: Union[str, Omit] = OMIT,
    ) -> SearchResponse:
        """Perform a search.

        Args:
            query (str):
                The query string.

            max_results (int, optional, default=10):
                The maximum number of search results to return.

            scope (str, optional):
                Restrict the search to a specific scope.
                Must be one of: "news".
                Omitted from the request when not provided.

            include_domains (list[str], optional):
                Only include results from these domains (e.g., ["techcrunch.com"]).
                Omitted from the request when not provided.

            exclude_domains (list[str], optional):
                Exclude results from these domains.
                Omitted from the request when not provided.

            from_date (str, optional):
                Only include results published on or after this date (ISO 8601, e.g. "2025-10-28").
                Omitted from the request when not provided.

            to_date (str, optional):
                Only include results published on or before this date (ISO 8601, e.g. "2026-04-29").
                Omitted from the request when not provided.

        Raises:
            SeltzAuthenticationError: If the API key is invalid.
            SeltzConnectionError: If the connection to the API fails.
            SeltzTimeoutError: If the request times out.
            SeltzRateLimitError: If the rate limit is exceeded.
            SeltzAPIError: For other API errors.

        Returns:
            SearchResponse: The response containing the search results.
            Search results have URL and content fields provided as empty strings when not available.

        Examples:
            response = seltz.search("best ai search engines", max_results=10)
            response = seltz.search("latest news", from_date="2025-01-01")
            response = seltz.search("tech news", include_domains=["techcrunch.com"])
        """

        return self._search.search(
            query=query,
            max_results=max_results,
            scope=scope,
            include_domains=include_domains,
            exclude_domains=exclude_domains,
            from_date=from_date,
            to_date=to_date,
        )
