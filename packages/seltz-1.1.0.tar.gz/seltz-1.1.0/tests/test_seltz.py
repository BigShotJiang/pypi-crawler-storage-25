import os

import pytest
from dotenv import load_dotenv

from seltz import SearchResponse, Seltz
from seltz.exceptions import SeltzConfigurationError

load_dotenv()

HAS_API_KEY = bool(os.environ.get("SELTZ_API_KEY"))
needs_api_key = pytest.mark.skipif(not HAS_API_KEY, reason="SELTZ_API_KEY not set")


# ---------------------------------------------------------------------------
# Unit tests — no network calls
# ---------------------------------------------------------------------------


def test_init_raises_without_api_key(monkeypatch):
    """Raise SeltzConfigurationError when no API key is provided and env var is absent."""
    monkeypatch.delenv("SELTZ_API_KEY", raising=False)
    with pytest.raises(SeltzConfigurationError):
        Seltz()


def test_init_raises_without_api_key_explicit_none(monkeypatch):
    """Raise SeltzConfigurationError when api_key=None is passed explicitly and env var is absent."""
    monkeypatch.delenv("SELTZ_API_KEY", raising=False)
    with pytest.raises(SeltzConfigurationError):
        Seltz(api_key=None)


def test_init_with_explicit_api_key(monkeypatch):
    """Store the API key passed directly to the constructor."""
    monkeypatch.delenv("SELTZ_API_KEY", raising=False)
    client = Seltz(api_key="test-key")
    assert client._client.api_key == "test-key"


def test_init_reads_api_key_from_env(monkeypatch):
    """Read the API key from the SELTZ_API_KEY environment variable when no key is passed."""
    monkeypatch.setenv("SELTZ_API_KEY", "env-key")
    client = Seltz()
    assert client._client.api_key == "env-key"


def test_explicit_api_key_overrides_env(monkeypatch):
    """Use the explicitly passed API key instead of the one in the environment."""
    monkeypatch.setenv("SELTZ_API_KEY", "env-key")
    client = Seltz(api_key="explicit-key")
    assert client._client.api_key == "explicit-key"


def test_default_endpoint():
    """Use grpc.seltz.ai as the default endpoint."""
    client = Seltz(api_key="test-key")
    assert client.endpoint == "grpc.seltz.ai"


def test_init_insecure(monkeypatch):
    """Accept insecure=True without raising."""
    monkeypatch.delenv("SELTZ_API_KEY", raising=False)
    client = Seltz(api_key="test-key", insecure=True)
    assert client._client.api_key == "test-key"


def test_search_service_initialized():
    """Initialize the search service on construction."""
    client = Seltz(api_key="test-key")
    assert client._search is not None


@pytest.mark.parametrize("scope", ["news"])
def test_search_valid_scope_does_not_raise(scope, monkeypatch):
    """Accept valid scope values without raising."""
    monkeypatch.setattr(
        "seltz.services.search_service.SearchService.search", lambda *a, **kw: None
    )
    client = Seltz(api_key="test-key")
    client.search("query", scope=scope)


def test_search_omitted_scope_does_not_raise(monkeypatch):
    """Not passing scope should not raise."""
    monkeypatch.setattr(
        "seltz.services.search_service.SearchService.search", lambda *a, **kw: None
    )
    client = Seltz(api_key="test-key")
    client.search("query")


def test_search_forwards_filter_params(monkeypatch):
    """Filter parameters are forwarded from Seltz.search() to SearchService.search()."""
    captured = {}

    def fake_search(*args, **kwargs):
        captured.update(kwargs)

    monkeypatch.setattr(
        "seltz.services.search_service.SearchService.search", fake_search
    )
    client = Seltz(api_key="test-key")
    client.search(
        "AI news",
        from_date="2026-01-01",
        to_date="2026-05-01",
        include_domains=["techcrunch.com", "wired.com"],
        exclude_domains=["wikipedia.org"],
    )

    assert captured["from_date"] == "2026-01-01"
    assert captured["to_date"] == "2026-05-01"
    assert captured["include_domains"] == ["techcrunch.com", "wired.com"]
    assert captured["exclude_domains"] == ["wikipedia.org"]


def test_search_omitted_filters_use_sentinel(monkeypatch):
    """Omitted filter parameters are passed as OMIT sentinel, not None."""
    from seltz._types import Omit

    captured = {}

    def fake_search(*args, **kwargs):
        captured.update(kwargs)

    monkeypatch.setattr(
        "seltz.services.search_service.SearchService.search", fake_search
    )
    client = Seltz(api_key="test-key")
    client.search("query")

    assert isinstance(captured["include_domains"], Omit)
    assert isinstance(captured["exclude_domains"], Omit)
    assert isinstance(captured["from_date"], Omit)
    assert isinstance(captured["to_date"], Omit)


# ---------------------------------------------------------------------------
# Integration tests — require SELTZ_API_KEY
# ---------------------------------------------------------------------------


@needs_api_key
def test_search_returns_response():
    """Return a SearchResponse instance for a standard query."""
    client = Seltz()
    response = client.search("best ai search engines")
    assert isinstance(response, SearchResponse)


@needs_api_key
def test_search_returns_results():
    """Return at least one document for a non-empty query."""
    client = Seltz()
    response = client.search("best ai search engines", max_results=5)
    assert len(response.documents) > 0


@needs_api_key
def test_search_max_results_respected():
    """Return no more documents than the requested max_results."""
    client = Seltz()
    response = client.search("best ai search engines", max_results=3)
    assert len(response.documents) <= 3


@needs_api_key
def test_search_result_fields():
    """Each document in the response has url and content as strings."""
    client = Seltz()
    response = client.search("best ai search engines")
    for doc in response.documents:
        assert isinstance(doc.url, str)
        assert isinstance(doc.content, str)


@needs_api_key
def test_search_empty_query():
    """Return a SearchResponse without raising for an empty query string."""
    client = Seltz()
    response = client.search("")
    assert isinstance(response, SearchResponse)
    assert len(response.documents) == 0
