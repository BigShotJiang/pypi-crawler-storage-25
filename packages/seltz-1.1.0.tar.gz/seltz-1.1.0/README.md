<div align="center">
  <img src="https://repository-images.githubusercontent.com/1108844600/672f4876-01a4-4fde-8ac2-ecab4c914c98">
</div>

<p align="center">
  <!-- Python -->
  <a href="https://www.python.org" alt="Python"><img src="https://badges.aleen42.com/src/python.svg"></a>
  <!-- Version -->
  <a href="https://pypi.org/project/seltz/"><img src="https://img.shields.io/pypi/v/seltz?color=light-green" alt="PyPI version"></a>
</p>

# Seltz Python SDK

Official Python SDK for [Seltz](https://seltz.ai), the Web search engine for AI agents.

## 💾 Installation

```bash
pip install seltz
```

Requires Python 3.9 or higher.

## ⚡️ Quick Start

```python
from seltz import Seltz

client = Seltz(api_key="your-api-key")

# Search the Web
response = client.search("best ai search engines", max_results=10)

# Access results
for document in response.documents:
    print(f"URL: {document.url}")
    print(f"Content: {document.content}")
```

**Output:**

```
URL: https://www.best-ai-search-engines.com
Content: Generative AI can make finding information faster and more intuitive.
If you’re tired of traditional search, explore some of the best AI-powered
search engines we've tested...
```

## 📚 Documentation

Browse the [documentation](https://docs.seltz.ai) for more details.
