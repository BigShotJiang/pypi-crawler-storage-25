import{w as s}from"./svelte-BqqZEQME.js";const o=s(null);export{o as s};
