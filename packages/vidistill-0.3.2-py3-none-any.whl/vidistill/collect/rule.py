"""Rule DSL: AST-whitelist parser and evaluator.

Grammar (PRD §4.1):
  literals      : int | float | string | true | false
  identifiers   : play | like | coin | favorite | star | share | danmaku |
                  comment | reply | duration | publish_days_ago |
                  title | author
  comparisons   : == != > >= < <=
  boolean       : and | or | not
  grouping      : ( ... )

No attribute access, subscripts, calls, arithmetic, lambdas, comprehensions,
or assignments are allowed. Everything goes through `ast.parse(mode="eval")`
and a strict whitelist visitor.
"""

from __future__ import annotations

import ast
from collections.abc import Callable
from typing import Any

ALLOWED_FIELDS: set[str] = {
    "play",
    "like",
    "coin",
    "favorite",
    "share",
    "danmaku",
    "comment",
    "duration",
    "publish_days_ago",
    "title",
    "author",
}

_ALIASES: dict[str, str] = {
    "star": "favorite",
    "reply": "comment",
}

# `true` / `false` are grammar keywords per PRD §4.1; Python's parser treats
# them as plain Names, so we treat them as boolean literals at both validate
# and evaluate time.
_BOOL_LITERALS: dict[str, bool] = {
    "true": True,
    "false": False,
}

_CMP_OPS: dict[type[ast.cmpop], Callable[[Any, Any], bool]] = {
    ast.Eq: lambda a, b: a == b,
    ast.NotEq: lambda a, b: a != b,
    ast.Gt: lambda a, b: a > b,
    ast.GtE: lambda a, b: a >= b,
    ast.Lt: lambda a, b: a < b,
    ast.LtE: lambda a, b: a <= b,
}


class RuleSyntaxError(ValueError):
    """Raised when a rule expression uses disallowed syntax or names."""


class _MissingField(Exception):
    """Internal sentinel: a referenced field was not provided in the context."""


class _Validator(ast.NodeVisitor):
    """Walk the AST and reject anything outside the whitelist.

    Runs once at parse time so `RuleEvaluator` only sees sanitised trees.
    """

    def visit(self, node: ast.AST) -> None:
        method = f"visit_{type(node).__name__}"
        handler = getattr(self, method, None)
        if handler is None:
            raise RuleSyntaxError(
                f"Unsupported syntax: {type(node).__name__} (rule grammar rejects it)"
            )
        handler(node)

    def visit_Expression(self, node: ast.Expression) -> None:
        self.visit(node.body)

    def visit_BoolOp(self, node: ast.BoolOp) -> None:
        if not isinstance(node.op, (ast.And, ast.Or)):
            raise RuleSyntaxError(
                f"Unsupported boolean operator: {type(node.op).__name__}"
            )
        for value in node.values:
            self.visit(value)

    def visit_UnaryOp(self, node: ast.UnaryOp) -> None:
        if not isinstance(node.op, ast.Not):
            raise RuleSyntaxError(
                f"Unsupported unary operator: {type(node.op).__name__}"
            )
        self.visit(node.operand)

    def visit_Compare(self, node: ast.Compare) -> None:
        for op in node.ops:
            if type(op) not in _CMP_OPS:
                raise RuleSyntaxError(
                    f"Unsupported comparison operator: {type(op).__name__}"
                )
        self.visit(node.left)
        for comparator in node.comparators:
            self.visit(comparator)

    def visit_Name(self, node: ast.Name) -> None:
        if node.id in _BOOL_LITERALS:
            return
        resolved = _ALIASES.get(node.id, node.id)
        if resolved not in ALLOWED_FIELDS:
            raise RuleSyntaxError(f"Unknown identifier: {node.id!r}")

    def visit_Constant(self, node: ast.Constant) -> None:
        if (
            not isinstance(node.value, (int, float, str, bool))
            and node.value is not None
        ):
            raise RuleSyntaxError(f"Unsupported literal: {node.value!r}")


class RuleEvaluator:
    """Evaluate a validated AST expression against a field-value context."""

    def __init__(self, tree: ast.Expression, source: str) -> None:
        self._tree = tree
        self._source = source

    def __call__(self, context: dict[str, Any]) -> bool:
        try:
            return bool(self._eval(self._tree.body, context))
        except _MissingField:
            return False

    def _eval(self, node: ast.AST, ctx: dict[str, Any]) -> Any:
        if isinstance(node, ast.BoolOp):
            if isinstance(node.op, ast.And):
                result: Any = True
                for value in node.values:
                    result = self._eval(value, ctx)
                    if not result:
                        return False
                return bool(result)
            values = [self._eval(v, ctx) for v in node.values]
            return any(values)

        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            return not self._eval(node.operand, ctx)

        if isinstance(node, ast.Compare):
            left = self._eval(node.left, ctx)
            for op, comparator in zip(node.ops, node.comparators, strict=True):
                right = self._eval(comparator, ctx)
                if not _CMP_OPS[type(op)](left, right):
                    return False
                left = right
            return True

        if isinstance(node, ast.Name):
            if node.id in _BOOL_LITERALS:
                return _BOOL_LITERALS[node.id]
            field = _ALIASES.get(node.id, node.id)
            if field not in ctx or ctx[field] is None:
                raise _MissingField(field)
            return ctx[field]

        if isinstance(node, ast.Constant):
            return node.value

        raise RuleSyntaxError(
            f"Unsupported runtime node: {type(node).__name__} in rule {self._source!r}"
        )


def parse_rule(source: str) -> RuleEvaluator:
    """Parse `source` into a RuleEvaluator, raising RuleSyntaxError on failure."""
    if not source or not source.strip():
        raise RuleSyntaxError("Empty rule expression")
    try:
        tree = ast.parse(source, mode="eval")
    except SyntaxError as exc:
        raise RuleSyntaxError(f"Invalid rule syntax: {exc.msg}") from exc

    _Validator().visit(tree)
    return RuleEvaluator(tree, source)
