"""Pydantic models for the collect subcommand."""

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class VideoItem(BaseModel):
    """A single candidate video scraped from a Bilibili page.

    Fields the platform did not expose are left as None so downstream
    rule evaluation and JSON output handle them uniformly.
    """

    url: str
    bvid: str
    aid: int | None = None
    title: str | None = None
    author: str | None = None
    play: int | None = None
    like: int | None = None
    coin: int | None = None
    favorite: int | None = None
    share: int | None = None
    danmaku: int | None = None
    comment: int | None = None
    duration: int | None = None
    publish_time: str | None = None
    publish_days_ago: int | None = None

    def as_rule_context(self) -> dict[str, Any]:
        """Flatten into a field -> value dict for RuleEvaluator."""
        return {
            "play": self.play,
            "like": self.like,
            "coin": self.coin,
            "favorite": self.favorite,
            "share": self.share,
            "danmaku": self.danmaku,
            "comment": self.comment,
            "duration": self.duration,
            "publish_days_ago": self.publish_days_ago,
            "title": self.title,
            "author": self.author,
        }


class CollectResult(BaseModel):
    """Envelope around a list of matched VideoItems."""

    page_path: str
    page_type: str
    rule: str
    num_requested: int
    num_matched: int
    sort: str
    collected_at: datetime
    items: list[VideoItem]
