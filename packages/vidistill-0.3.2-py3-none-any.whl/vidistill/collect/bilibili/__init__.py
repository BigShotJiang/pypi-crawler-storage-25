"""Bilibili page-type detection and scraper dispatch."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal
from urllib.parse import parse_qs, unquote, urlparse

PageType = Literal["user", "search", "channel", "popular", "topic"]


@dataclass(frozen=True)
class PageInfo:
    page_type: PageType
    identifier: str


class UnsupportedPageError(ValueError):
    """Raised when the given URL does not match any supported page type."""


_USER_PATH = re.compile(r"^/(\d+)(?:/.*)?$")
_CHANNEL_PATH = re.compile(r"^/c/([A-Za-z0-9_-]+)/?$")
_POPULAR_PATH = re.compile(r"^/v/popular/([A-Za-z0-9_-]+)/?$")
_TOPIC_PATH = re.compile(r"^/v/topic/detail/?$")


def detect_page_type(url: str) -> PageInfo:
    """Classify a Bilibili URL into one of the supported page types.

    Raises UnsupportedPageError with the detected host on anything else so
    the CLI can point users at the supported forms.
    """
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    path = parsed.path or "/"

    if host == "space.bilibili.com":
        m = _USER_PATH.match(path)
        if m:
            return PageInfo("user", m.group(1))
        raise UnsupportedPageError(
            f"Unrecognised space.bilibili.com path: {path!r}. "
            "Expected /<uid> or /<uid>/video"
        )

    if host == "search.bilibili.com":
        qs = parse_qs(parsed.query)
        keyword = qs.get("keyword", [""])[0]
        if not keyword:
            raise UnsupportedPageError(
                f"search.bilibili.com URL missing 'keyword' query: {url!r}"
            )
        return PageInfo("search", unquote(keyword))

    if host in {"www.bilibili.com", "bilibili.com"}:
        m = _POPULAR_PATH.match(path)
        if m:
            return PageInfo("popular", m.group(1))
        if _TOPIC_PATH.match(path):
            qs = parse_qs(parsed.query)
            topic_id = qs.get("topic_id", [""])[0]
            if not topic_id:
                raise UnsupportedPageError(
                    f"topic URL missing 'topic_id' query: {url!r}"
                )
            return PageInfo("topic", topic_id)
        m = _CHANNEL_PATH.match(path)
        if m:
            return PageInfo("channel", m.group(1))

    raise UnsupportedPageError(
        f"Unsupported URL: {url!r}. Supported forms: "
        "space.bilibili.com/<uid>, search.bilibili.com/all?keyword=..., "
        "www.bilibili.com/c/<channel>, www.bilibili.com/v/popular/<column>, "
        "www.bilibili.com/v/topic/detail?topic_id=..."
    )


def create_scraper(url: str):
    """Dispatch helper returning the scraper instance for `url`."""
    info = detect_page_type(url)
    from vidistill.collect.bilibili.channel import ChannelScraper
    from vidistill.collect.bilibili.popular import PopularScraper
    from vidistill.collect.bilibili.search import SearchScraper
    from vidistill.collect.bilibili.topic import TopicScraper
    from vidistill.collect.bilibili.user import UserScraper

    mapping = {
        "user": UserScraper,
        "search": SearchScraper,
        "channel": ChannelScraper,
        "popular": PopularScraper,
        "topic": TopicScraper,
    }
    scraper_cls = mapping[info.page_type]
    return scraper_cls(page_path=url, identifier=info.identifier)
