"""Bilibili 分区 scraper (www.bilibili.com/c/<channel>).

Shares the `.bili-video-card` markup with space/user pages. Collects every
card on the page, deduplicated by bvid (PRD §5.3).
"""

from __future__ import annotations

from vidistill.collect.bilibili.base import BilibiliScraper
from vidistill.collect.bilibili.user import _extract_cover_card
from vidistill.collect.models import VideoItem


class ChannelScraper(BilibiliScraper):
    page_type = "channel"
    mode = "scroll"

    async def parse_cards(self, page) -> list[VideoItem]:
        cards = await page.query_selector_all(".bili-video-card")
        seen: set[str] = set()
        items: list[VideoItem] = []
        for card in cards:
            item = await _extract_cover_card(card)
            if item is None or item.bvid in seen:
                continue
            seen.add(item.bvid)
            items.append(item)
        return items
