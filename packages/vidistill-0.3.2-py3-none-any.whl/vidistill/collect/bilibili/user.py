"""UP 主主页 scraper (space.bilibili.com/<uid>).

Uses the same `.bili-video-card` markup that search/channel pages use,
plus the `.bili-cover-card__stats` block (3 stat nodes: play, danmaku,
duration).
"""

from __future__ import annotations

from vidistill.collect.bilibili.base import (
    BilibiliScraper,
    absolute_url,
    extract_bvid,
    parse_count,
    parse_duration,
)
from vidistill.collect.models import VideoItem


async def _extract_cover_card(card) -> VideoItem | None:
    link = await card.query_selector("a.bili-cover-card, a[href*='/video/BV']")
    if link is None:
        return None
    href = await link.get_attribute("href") or ""
    bvid = extract_bvid(href)
    if bvid is None:
        return None

    title_el = await card.query_selector(".bili-video-card__title a")
    title = (await title_el.inner_text()).strip() if title_el else None

    stat_els = await card.query_selector_all(".bili-cover-card__stat span")
    stats_text = [(await el.inner_text()).strip() for el in stat_els]
    # Layout from recon: [play, danmaku, duration]
    play = parse_count(stats_text[0]) if len(stats_text) >= 1 else None
    danmaku = parse_count(stats_text[1]) if len(stats_text) >= 2 else None
    duration = parse_duration(stats_text[2]) if len(stats_text) >= 3 else None

    subtitle_el = await card.query_selector(".bili-video-card__subtitle span")
    publish_time = (
        (await subtitle_el.inner_text()).strip() if subtitle_el is not None else None
    )

    author_el = await card.query_selector(".bili-video-card__author")
    author = (await author_el.inner_text()).strip() if author_el else None

    return VideoItem(
        url=absolute_url(href.split("?")[0]),
        bvid=bvid,
        title=title,
        duration=duration,
        play=play,
        danmaku=danmaku,
        publish_time=publish_time,
        author=author,
    )


class UserScraper(BilibiliScraper):
    page_type = "user"
    mode = "scroll"

    async def parse_cards(self, page) -> list[VideoItem]:
        cards = await page.query_selector_all(".bili-video-card")
        seen: set[str] = set()
        items: list[VideoItem] = []
        for card in cards:
            item = await _extract_cover_card(card)
            if item is None or item.bvid in seen:
                continue
            seen.add(item.bvid)
            items.append(item)
        return items
