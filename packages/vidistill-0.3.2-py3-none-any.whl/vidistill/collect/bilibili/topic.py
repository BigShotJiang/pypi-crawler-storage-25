"""Bilibili 话题 scraper (www.bilibili.com/v/topic/detail).

Observed layout (April 2026):
- card     : `a.bili-dyn-card-video` (the <a> itself is the card)
- title    : `.bili-dyn-card-video__title`
- duration : `.duration-time`
- stats    : two `.bili-dyn-card-video__stat__item` spans (play, danmaku)
"""

from __future__ import annotations

from vidistill.collect.bilibili.base import (
    BilibiliScraper,
    absolute_url,
    extract_bvid,
    parse_count,
    parse_duration,
)
from vidistill.collect.models import VideoItem


async def _extract_topic_card(card) -> VideoItem | None:
    href = await card.get_attribute("href") or ""
    bvid = extract_bvid(href)
    if bvid is None:
        return None

    title_el = await card.query_selector(".bili-dyn-card-video__title")
    title = (await title_el.inner_text()).strip() if title_el else None

    dur_el = await card.query_selector(".duration-time")
    duration = parse_duration(await dur_el.inner_text()) if dur_el else None

    stat_els = await card.query_selector_all(".bili-dyn-card-video__stat__item")
    stat_texts: list[str] = []
    for s in stat_els:
        txt = (await s.inner_text()).strip()
        if txt:
            stat_texts.append(txt)
    play = parse_count(stat_texts[0]) if len(stat_texts) >= 1 else None
    danmaku = parse_count(stat_texts[1]) if len(stat_texts) >= 2 else None

    return VideoItem(
        url=absolute_url(href.split("?")[0]),
        bvid=bvid,
        title=title,
        duration=duration,
        play=play,
        danmaku=danmaku,
    )


class TopicScraper(BilibiliScraper):
    page_type = "topic"
    mode = "scroll"

    async def parse_cards(self, page) -> list[VideoItem]:
        cards = await page.query_selector_all("a.bili-dyn-card-video")
        seen: set[str] = set()
        items: list[VideoItem] = []
        for card in cards:
            item = await _extract_topic_card(card)
            if item is None or item.bvid in seen:
                continue
            seen.add(item.bvid)
            items.append(item)
        return items
