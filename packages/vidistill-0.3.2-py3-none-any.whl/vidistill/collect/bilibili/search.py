"""Bilibili 搜索结果 scraper (search.bilibili.com/all).

Observed layout (April 2026):
- cards   : `.bili-video-card`
- title   : `.bili-video-card__info--tit` (clean text in the `title=` attr)
- link    : first `a[href*='/video/BV']` inside the info block
- stats   : three `.bili-video-card__stats--item` spans -> play, danmaku, duration
- author  : `.bili-video-card__info--author`
"""

from __future__ import annotations

from vidistill.collect.bilibili.base import (
    BilibiliScraper,
    absolute_url,
    extract_bvid,
    parse_count,
    parse_duration,
)
from vidistill.collect.models import VideoItem


async def _extract_search_card(card) -> VideoItem | None:
    link = await card.query_selector(".bili-video-card__info a[href*='/video/BV']")
    if link is None:
        link = await card.query_selector("a[href*='/video/BV']")
    if link is None:
        return None
    href = await link.get_attribute("href") or ""
    bvid = extract_bvid(href)
    if bvid is None:
        return None

    title_el = await card.query_selector(".bili-video-card__info--tit")
    title = None
    if title_el is not None:
        title = await title_el.get_attribute("title")
        if not title:
            title = (await title_el.inner_text()).strip() or None

    stat_els = await card.query_selector_all(".bili-video-card__stats--item")
    stat_texts: list[str] = []
    for s in stat_els:
        txt = (await s.inner_text()).strip()
        if txt:
            stat_texts.append(txt)
    play = parse_count(stat_texts[0]) if len(stat_texts) >= 1 else None
    danmaku = parse_count(stat_texts[1]) if len(stat_texts) >= 2 else None

    dur_el = await card.query_selector(
        ".bili-video-card__stats__duration, .bili-video-card__info--duration"
    )
    duration = parse_duration(await dur_el.inner_text()) if dur_el else None

    author_el = await card.query_selector(".bili-video-card__info--author")
    author = (await author_el.inner_text()).strip() if author_el else None

    date_el = await card.query_selector(".bili-video-card__info--date")
    publish_time = (await date_el.inner_text()).strip() if date_el else None

    return VideoItem(
        url=absolute_url(href.split("?")[0]),
        bvid=bvid,
        title=title,
        play=play,
        danmaku=danmaku,
        duration=duration,
        author=author,
        publish_time=publish_time,
    )


class SearchScraper(BilibiliScraper):
    page_type = "search"
    mode = "scroll"

    async def parse_cards(self, page) -> list[VideoItem]:
        cards = await page.query_selector_all(".bili-video-card")
        seen: set[str] = set()
        items: list[VideoItem] = []
        for card in cards:
            item = await _extract_search_card(card)
            if item is None or item.bvid in seen:
                continue
            seen.add(item.bvid)
            items.append(item)
        return items
