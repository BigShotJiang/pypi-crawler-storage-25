"""Bilibili 排行榜 scraper (www.bilibili.com/v/popular/<column>).

Observed layout (April 2026):
- card   : `.video-card`
- title  : `.video-name` (with `title=` attribute)
- author : `.up-name__text`
- play   : `.play-text`
- like   : `.like-text`
- link   : first `a[href*='/video/BV']`
"""

from __future__ import annotations

from vidistill.collect.bilibili.base import (
    BilibiliScraper,
    absolute_url,
    extract_bvid,
    parse_count,
)
from vidistill.collect.models import VideoItem


async def _extract_popular_card(card) -> VideoItem | None:
    link = await card.query_selector("a[href*='/video/BV']")
    if link is None:
        return None
    href = await link.get_attribute("href") or ""
    bvid = extract_bvid(href)
    if bvid is None:
        return None

    title_el = await card.query_selector(".video-name")
    title = None
    if title_el is not None:
        title = await title_el.get_attribute("title")
        if not title:
            title = (await title_el.inner_text()).strip() or None

    play_el = await card.query_selector(".play-text")
    play = parse_count(await play_el.inner_text()) if play_el else None

    like_el = await card.query_selector(".like-text")
    like = parse_count(await like_el.inner_text()) if like_el else None

    up_el = await card.query_selector(".up-name__text, .up-name")
    author = (await up_el.inner_text()).strip() if up_el else None

    return VideoItem(
        url=absolute_url(href.split("?")[0]),
        bvid=bvid,
        title=title,
        play=play,
        like=like,
        author=author,
    )


class PopularScraper(BilibiliScraper):
    page_type = "popular"
    mode = "scroll"

    async def parse_cards(self, page) -> list[VideoItem]:
        cards = await page.query_selector_all(".video-card")
        seen: set[str] = set()
        items: list[VideoItem] = []
        for card in cards:
            item = await _extract_popular_card(card)
            if item is None or item.bvid in seen:
                continue
            seen.add(item.bvid)
            items.append(item)
        return items
