"""Shared Bilibili scraper base class.

Defines the Playwright browser lifecycle and the `iter_candidates()`
generator that wraps both infinite-scroll and numbered-page strategies.

Concrete scrapers override:
- `mode`: either "scroll" or "paged".
- `parse_cards(page)`: scrape the currently-rendered DOM.
- for "paged" mode: `_fetch_page(n)` returns the items for page N.
"""

from __future__ import annotations

import asyncio
import re
from collections.abc import AsyncIterator
from pathlib import Path
from typing import ClassVar, Literal

from vidistill.collect.models import VideoItem

SCROLL_DELAY = 1.0

# WHY: scrub the headless tell-tales Bilibili's anti-bot layer keys off.
# Verified against `api.bilibili.com/x/space/wbi/acc/info` which otherwise
# returns `{"code":-352,"message":"风控校验失败"}` on a vanilla headless Chromium.
_STEALTH_INIT_SCRIPT = """
Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
Object.defineProperty(navigator, 'languages', { get: () => ['zh-CN', 'zh', 'en'] });
Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
window.chrome = { runtime: {} };
"""


class RiskControlError(RuntimeError):
    """Raised when Bilibili's risk-control layer blocks the scrape."""


class BilibiliScraper:
    """Abstract base. Subclasses pick a mode and fill in the hook methods."""

    page_type: ClassVar[str] = "unknown"
    mode: ClassVar[Literal["scroll", "paged"]] = "scroll"
    default_url_template: ClassVar[str | None] = None

    def __init__(self, page_path: str, identifier: str) -> None:
        self.page_path = page_path
        self.identifier = identifier
        self._pw = None
        self._browser = None
        self._context = None
        self._page = None
        self._seen: set[str] = set()
        self._risk_flag: bool = False
        self._has_cookies: bool = False

    async def open(
        self,
        headful: bool = False,
        storage_state_path: Path | None = None,
    ) -> None:
        from playwright.async_api import async_playwright

        self._pw = await async_playwright().start()
        self._browser = await self._pw.chromium.launch(
            headless=not headful,
            args=["--disable-blink-features=AutomationControlled"],
        )

        ctx_kwargs = {
            "viewport": {"width": 1440, "height": 900},
            "user_agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/125.0.0.0 Safari/537.36"
            ),
            "locale": "zh-CN",
        }
        if storage_state_path is not None:
            storage_path = Path(storage_state_path)
            if storage_path.exists():
                ctx_kwargs["storage_state"] = str(storage_path)

        self._context = await self._browser.new_context(**ctx_kwargs)
        self._has_storage_state = storage_state_path is not None
        await self._context.add_init_script(_STEALTH_INIT_SCRIPT)

        self._page = await self._context.new_page()
        self._page.on("response", self._on_response)

        await self._page.goto(
            self.page_path, wait_until="domcontentloaded", timeout=45000
        )
        # WHY: Bilibili's anti-bot layer sniffs dm_img_* payloads built from
        # mouse/scroll interaction; a small nudge before settling reduces false
        # positives from the -352 risk check.
        await self._page.mouse.move(400, 300)
        await self._page.mouse.move(600, 500, steps=5)
        await asyncio.sleep(3.0)

        if self._risk_flag and not self._has_storage_state:
            raise RiskControlError(
                "Bilibili risk control (code -352) blocked the request. "
                "Pass --storage-state <path> with a logged-in Bilibili session "
                "(Playwright storage-state JSON). Run without the flag first to "
                "auto-generate one via login."
            )

    def _on_response(self, response) -> None:
        url = response.url
        if "api.bilibili.com/x/" not in url:
            return

        async def _peek():
            try:
                data = await response.json()
            except Exception:
                return
            if isinstance(data, dict) and data.get("code") == -352:
                self._risk_flag = True

        asyncio.create_task(_peek())

    async def close(self) -> None:
        if self._context is not None:
            await self._context.close()
        if self._browser is not None:
            await self._browser.close()
        if self._pw is not None:
            await self._pw.stop()

    async def parse_cards(self, page) -> list[VideoItem]:
        """Return all video items currently rendered on `page`."""
        raise NotImplementedError

    async def _scroll_once(self) -> list[VideoItem]:
        """Scroll-mode hook: parse the current DOM and scroll for more."""
        assert self._page is not None
        items = await self.parse_cards(self._page)
        await self._page.mouse.wheel(0, 2000)
        await asyncio.sleep(SCROLL_DELAY)
        return items

    async def _fetch_page(self, page_num: int) -> list[VideoItem]:
        """Paged-mode hook: navigate to page N, return that page's items."""
        raise NotImplementedError

    async def iter_candidates(self, max_scrolls: int = 20) -> AsyncIterator[VideoItem]:
        """Yield unique VideoItems until the page plateaus or max_scrolls is reached."""
        if self.mode == "scroll":
            async for item in self._iter_scroll(max_scrolls):
                yield item
        elif self.mode == "paged":
            async for item in self._iter_paged(max_scrolls):
                yield item
        else:  # pragma: no cover - class invariant
            raise ValueError(f"Unknown scraper mode: {self.mode!r}")

    async def _iter_scroll(self, max_scrolls: int) -> AsyncIterator[VideoItem]:
        plateau = 0
        for _ in range(max_scrolls):
            batch = await self._scroll_once()
            new_items = [b for b in batch if b.bvid not in self._seen]
            if not new_items:
                plateau += 1
                if plateau >= 2:
                    return
                continue
            plateau = 0
            for item in new_items:
                self._seen.add(item.bvid)
                yield item

    async def _iter_paged(self, max_scrolls: int) -> AsyncIterator[VideoItem]:
        for n in range(1, max_scrolls + 1):
            batch = await self._fetch_page(n)
            if not batch:
                return
            for item in batch:
                if item.bvid in self._seen:
                    continue
                self._seen.add(item.bvid)
                yield item


_BVID_RE = re.compile(r"(BV[0-9A-Za-z]+)")


def extract_bvid(href: str) -> str | None:
    """Pull the BVID out of a Bilibili video href, or None if not present."""
    m = _BVID_RE.search(href)
    return m.group(1) if m else None


_TIME_RE = re.compile(r"^(\d+):(\d+)(?::(\d+))?$")


def parse_duration(text: str) -> int | None:
    """Parse a duration string like 'MM:SS' or 'HH:MM:SS' into seconds."""
    m = _TIME_RE.match(text.strip())
    if not m:
        return None
    a, b, c = m.groups()
    if c is None:
        return int(a) * 60 + int(b)
    return int(a) * 3600 + int(b) * 60 + int(c)


def parse_count(text: str) -> int | None:
    """Parse a count string like '1,234', '1.2万', or '3.5亿' into int."""
    if text is None:
        return None
    cleaned = text.strip().replace(",", "").replace(" ", "")
    if not cleaned:
        return None
    multiplier = 1
    if cleaned.endswith("亿"):
        multiplier = 100_000_000
        cleaned = cleaned[:-1]
    elif cleaned.endswith("万") or cleaned.endswith("w") or cleaned.endswith("W"):
        multiplier = 10_000
        cleaned = cleaned[:-1]
    elif cleaned.endswith("k") or cleaned.endswith("K"):
        multiplier = 1_000
        cleaned = cleaned[:-1]
    try:
        value = float(cleaned)
    except ValueError:
        return None
    return int(value * multiplier)


def absolute_url(href: str) -> str:
    """Normalise a Bilibili href to an absolute https URL."""
    if href.startswith("//"):
        return "https:" + href
    if href.startswith("/"):
        return "https://www.bilibili.com" + href
    return href
