"""vidistill collect — rule-based video candidate collection."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from rich.console import Console
from rich.panel import Panel

from vidistill.collect.bilibili import create_scraper, detect_page_type
from vidistill.collect.models import CollectResult, VideoItem
from vidistill.collect.rule import parse_rule
from vidistill.collect.writer import write_json

__all__ = ["run_collect", "init_storage_state", "detect_page_type", "create_scraper"]


console = Console()


_SORTABLE_FIELDS = {
    "play",
    "like",
    "favorite",
    "coin",
    "share",
    "danmaku",
    "comment",
    "duration",
}


def _sort_items(items: list[VideoItem], sort_by: str) -> list[VideoItem]:
    if sort_by == "none":
        return items
    if sort_by not in _SORTABLE_FIELDS:
        raise ValueError(f"Unsupported --sort field: {sort_by!r}")
    return sorted(
        items,
        key=lambda item: getattr(item, sort_by) or 0,
        reverse=True,
    )


async def init_storage_state(page_path: str, output_path: Path) -> None:
    """Open a headful browser for login, then save storage state to disk.

    Called when the user tries to collect but no storage_state file exists.
    Opens the browser at `page_path`, shows a prompt, waits for the user to
    complete login and close the browser, then saves the storage state.
    """
    from playwright.async_api import async_playwright

    console.print(
        Panel(
            f"[bold yellow]No storage state found at {output_path}.[/]\n"
            "A browser will open. Log in to Bilibili, then close the browser.",
            title="Login required",
        )
    )

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=False,
            args=["--disable-blink-features=AutomationControlled"],
        )
        context = await browser.new_context(
            viewport={"width": 1440, "height": 900},
            user_agent=(
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/125.0.0.0 Safari/537.36"
            ),
            locale="zh-CN",
        )
        page = await context.new_page()
        await page.goto(page_path, wait_until="domcontentloaded", timeout=90000)

        console.print("[bold yellow]Close the browser window when done.[/]")
        await page.wait_for_event("close")

        await context.storage_state(path=str(output_path))
        await context.close()
        await browser.close()

    console.print(f"[green]Storage state saved:[/] {output_path}")


async def run_collect(
    page_path: str,
    rule: str,
    num: int,
    output_dir: Path,
    max_scrolls: int = 20,
    sort_by: str = "none",
    headful: bool = False,
    storage_state_path: Path | None = None,
) -> Path:
    """Entry point invoked by the CLI.

    Returns the path of the JSON file written.
    """
    evaluator = parse_rule(rule)
    info = detect_page_type(page_path)
    scraper = create_scraper(page_path)

    console.print(
        f"[bold]Collecting[/] page_type={info.page_type} identifier={info.identifier!r}"
    )

    matched: list[VideoItem] = []
    await scraper.open(headful=headful, storage_state_path=storage_state_path)
    try:
        async for item in scraper.iter_candidates(max_scrolls=max_scrolls):
            if evaluator(item.as_rule_context()):
                matched.append(item)
                if len(matched) >= num:
                    break
    finally:
        await scraper.close()

    matched = _sort_items(matched, sort_by)

    result = CollectResult(
        page_path=page_path,
        page_type=info.page_type,
        rule=rule,
        num_requested=num,
        num_matched=len(matched),
        sort=sort_by,
        collected_at=datetime.now(),
        items=matched,
    )
    return write_json(output_dir, result, identifier=info.identifier)
