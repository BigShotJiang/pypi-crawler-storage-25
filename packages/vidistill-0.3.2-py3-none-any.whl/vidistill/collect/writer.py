"""JSON output writer for collect results."""

from __future__ import annotations

import re
from pathlib import Path

from vidistill.collect.models import CollectResult


_SEARCH_SANITIZE = re.compile(r"[^0-9A-Za-z\u4e00-\u9fff]+")
_MAX_SEARCH_LEN = 40


def _sanitize_identifier(page_type: str, identifier: str) -> str:
    """Derive a filesystem-safe identifier per PRD §5.5."""
    if page_type == "search":
        collapsed = _SEARCH_SANITIZE.sub("_", identifier).strip("_")
        if len(collapsed) > _MAX_SEARCH_LEN:
            collapsed = collapsed[:_MAX_SEARCH_LEN]
        return collapsed or "query"
    return identifier


def _identifier_from_result(result: CollectResult) -> str:
    """Re-derive the page identifier from the result's page_path URL."""
    # Lazy import to avoid a cycle with bilibili.__init__ at module load time.
    from vidistill.collect.bilibili import UnsupportedPageError, detect_page_type

    try:
        return detect_page_type(result.page_path).identifier
    except UnsupportedPageError:
        return "unknown"


def build_output_path(
    base_dir: Path, result: CollectResult, identifier: str | None = None
) -> Path:
    """Construct the output JSON path for a CollectResult.

    `identifier` overrides the URL-derived default.
    """
    ident = identifier if identifier is not None else _identifier_from_result(result)
    safe_id = _sanitize_identifier(result.page_type, ident)
    timestamp = result.collected_at.strftime("%Y%m%d_%H%M%S")
    filename = f"collect_{result.page_type}_{safe_id}_{timestamp}.json"
    return base_dir / filename


def write_json(
    base_dir: Path, result: CollectResult, identifier: str | None = None
) -> Path:
    """Write `result` as JSON and return the written path."""
    base_dir.mkdir(parents=True, exist_ok=True)
    path = build_output_path(base_dir, result, identifier)
    path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
    return path
