"""Configuration management."""

from pathlib import Path


DEFAULT_MODEL = "openrouter:anthropic/claude-sonnet-4.6"
DEFAULT_TRANSCRIBER = "doubao"
DEFAULT_OUTPUT_DIR = Path("output")
