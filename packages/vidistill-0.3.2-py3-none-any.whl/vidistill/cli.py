"""CLI entry point for vidistill."""

import asyncio
import json
import re
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel

from vidistill.config import DEFAULT_MODEL, DEFAULT_OUTPUT_DIR, DEFAULT_TRANSCRIBER

console = Console()


def _sanitize_title(title: str) -> str:
    """Sanitize video title for use as directory name."""
    sanitized = re.sub(r'[\\/:*?"<>|]', "_", title)
    sanitized = re.sub(r"[_\s]+", "_", sanitized)
    sanitized = sanitized[:80].strip("_")
    return sanitized or "untitled"


def _build_output_dir(base_dir: Path, title: str) -> Path:
    """Build the output directory path with title and timestamp."""
    sanitized = _sanitize_title(title)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return base_dir / f"{sanitized}_{timestamp}"


def _save_transcript(segments: list, output_dir: Path) -> tuple[Path, Path]:
    """Save transcript as both txt and json files."""
    txt_path = output_dir / "transcript.txt"
    lines = []
    for seg in segments:
        if seg.speaker:
            lines.append(f"[{seg.speaker}] {seg.text}")
        else:
            lines.append(seg.text)
    txt_path.write_text("\n".join(lines), encoding="utf-8")

    json_path = output_dir / "transcript.json"
    data = [seg.model_dump() for seg in segments]
    json_path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    return txt_path, json_path


async def _run_pipeline(
    input_path: str,
    output_dir: Path,
    model: str,
    transcriber_name: str,
    diarize: bool,
) -> None:
    """Run the full vidistill pipeline."""
    from vidistill.analysis.analyze.content import analyze_content
    from vidistill.analysis.audio import extract_audio
    from vidistill.analysis.download import download_video
    from vidistill.analysis.output.markdown import render_report
    from vidistill.analysis.transcribe import create_transcriber

    console.print(Panel("[bold]Vidistill - Video Content Distillation[/]"))
    console.print(f"[bold]Input:[/] {input_path}")
    console.print(f"[bold]Model:[/] {model}")
    console.print(f"[bold]Transcriber:[/] {transcriber_name}")
    console.print(f"[bold]Diarize:[/] {diarize}")
    console.print()

    console.rule("[bold]Step 1: Download Video")
    temp_dir = output_dir / "_temp_download"
    video_path, title = download_video(input_path, temp_dir)

    final_dir = _build_output_dir(output_dir, title)
    final_dir.mkdir(parents=True, exist_ok=True)

    import shutil

    final_video = final_dir / video_path.name
    if not final_video.exists():
        shutil.move(str(video_path), str(final_video))
    if temp_dir.exists():
        shutil.rmtree(temp_dir, ignore_errors=True)
    video_path = final_video

    console.print(f"[bold]Output directory:[/] {final_dir}")
    console.print()

    console.rule("[bold]Step 2: Extract Audio")
    audio_path = final_dir / "audio.wav"
    if audio_path.exists():
        console.print(f"[bold yellow]Skipping:[/] {audio_path} already exists")
    else:
        audio_path = extract_audio(video_path, final_dir)
    console.print()

    console.rule("[bold]Step 3: Transcribe Audio")
    transcript_txt = final_dir / "transcript.txt"
    transcript_json = final_dir / "transcript.json"

    if transcript_txt.exists() and transcript_json.exists():
        console.print("[bold yellow]Skipping:[/] transcript files already exist")
        with open(transcript_json, encoding="utf-8") as f:
            from vidistill.analysis.output.models import TranscriptSegment

            segments_data = json.load(f)
            segments = [TranscriptSegment(**s) for s in segments_data]
    else:
        transcriber = create_transcriber(transcriber_name)
        segments = transcriber.transcribe(audio_path, diarize=diarize)
        _save_transcript(segments, final_dir)
        console.print(f"[bold green]Transcript saved:[/] {len(segments)} segments")
    console.print()

    console.rule("[bold]Step 4: Content Analysis")
    analysis_json = final_dir / "analysis.json"

    if analysis_json.exists():
        console.print("[bold yellow]Skipping:[/] analysis.json already exists")
        from vidistill.analysis.output.models import ContentAnalysis

        with open(analysis_json, encoding="utf-8") as f:
            analysis = ContentAnalysis.model_validate_json(f.read())
    else:
        transcript_text = transcript_txt.read_text(encoding="utf-8")
        console.print("[bold blue]Analyzing content with LLM...[/]")
        analysis = await analyze_content(transcript_text, model)
        analysis_json.write_text(analysis.model_dump_json(indent=2), encoding="utf-8")
        console.print("[bold green]Analysis complete.[/]")
    console.print()

    console.rule("[bold]Step 5: Generate Report")
    report_path = final_dir / "report.md"
    report_content = render_report(analysis)
    report_path.write_text(report_content, encoding="utf-8")
    console.print(f"[bold green]Report saved:[/] {report_path}")
    console.print()

    console.rule("[bold green]Done!")
    console.print(f"[bold]Output directory:[/] {final_dir}")
    console.print("[bold]Files:[/]")
    for f in sorted(final_dir.iterdir()):
        console.print(f"  {f.name}")


@click.group()
def main() -> None:
    """Vidistill - Video content distillation toolset."""


@main.command(name="analyse")
@click.argument("input_path")
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(path_type=Path),
    default=DEFAULT_OUTPUT_DIR,
    help="Base output directory.",
)
@click.option(
    "--model",
    "-m",
    default=DEFAULT_MODEL,
    help="LLM model string (e.g. anthropic:claude-sonnet-4-20250514, openai:gpt-4o).",
)
@click.option(
    "--transcriber",
    "-t",
    default=DEFAULT_TRANSCRIBER,
    help="ASR transcriber backend.",
)
@click.option(
    "--diarize",
    is_flag=True,
    default=False,
    help="Enable speaker diarization.",
)
def analyse(
    input_path: str,
    output_dir: Path,
    model: str,
    transcriber: str,
    diarize: bool,
) -> None:
    """Run the full analysis pipeline on a single video.

    INPUT_PATH can be a video URL (YouTube, Bilibili, etc.) or a local file path.
    """
    try:
        asyncio.run(_run_pipeline(input_path, output_dir, model, transcriber, diarize))
    except KeyboardInterrupt:
        console.print("\n[bold red]Interrupted by user.[/]")
        raise SystemExit(1)
    except Exception as e:
        console.print(f"\n[bold red]Error:[/] {e}")
        raise SystemExit(1)


@main.command(name="collect")
@click.argument("page_path")
@click.option(
    "--rule",
    "-r",
    default="true",
    help="Rule expression (see PRD §4). Matches all when omitted.",
)
@click.option(
    "--num",
    "-n",
    type=int,
    default=30,
    help="Stop once this many videos match.",
)
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(path_type=Path),
    default=DEFAULT_OUTPUT_DIR,
    help="Base output directory.",
)
@click.option(
    "--max-scrolls",
    type=int,
    default=20,
    help="Upper bound on scroll/page-turn iterations.",
)
@click.option(
    "--sort",
    "sort_by",
    type=click.Choice(
        [
            "none",
            "play",
            "like",
            "favorite",
            "coin",
            "share",
            "danmaku",
            "comment",
            "duration",
        ]
    ),
    default="none",
    help="Post-scrape sort of matches (descending).",
)
@click.option(
    "--headful",
    is_flag=True,
    default=False,
    help="Show the browser window (debugging).",
)
@click.option(
    "--storage-state",
    "storage_state_path",
    type=click.Path(path_type=Path, dir_okay=False),
    default="default.storage_state",
    show_default=True,
    help=(
        "Path to a Playwright storage-state JSON (cookies + localStorage). "
        "If missing, a browser opens for login first."
    ),
)
def collect(
    page_path: str,
    rule: str,
    num: int,
    output_dir: Path,
    max_scrolls: int,
    sort_by: str,
    headful: bool,
    storage_state_path: str,
) -> None:
    """Collect candidate videos from a Bilibili page matching a rule."""
    from vidistill.collect import init_storage_state, run_collect

    try:
        storage_state = Path(storage_state_path)
        if not storage_state.exists():
            asyncio.run(init_storage_state(page_path, storage_state))

        result_path = asyncio.run(
            run_collect(
                page_path=page_path,
                rule=rule,
                num=num,
                output_dir=output_dir,
                max_scrolls=max_scrolls,
                sort_by=sort_by,
                headful=headful,
                storage_state_path=storage_state,
            )
        )
        console.print(f"[bold green]Collection saved:[/] {result_path}")
    except KeyboardInterrupt:
        console.print("\n[bold red]Interrupted by user.[/]")
        raise SystemExit(1)
    except Exception as e:
        console.print(f"\n[bold red]Error:[/] {e}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
