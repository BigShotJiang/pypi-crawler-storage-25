"""Volcengine TOS (Tinder Object Storage) upload module."""

import os
import uuid
from pathlib import Path

import dotenv
import tos
from rich.console import Console

console = Console()

TOS_ENDPOINT = "tos-cn-guangzhou.volces.com"
TOS_REGION = "cn-guangzhou"
TOS_BUCKET = "voice-file-for-video-analysis"


class TosStorage:
    """Reusable TOS client with configurable endpoint, region and bucket."""

    def __init__(
        self,
        endpoint: str = TOS_ENDPOINT,
        region: str = TOS_REGION,
        bucket: str = TOS_BUCKET,
    ):
        self.endpoint = endpoint
        self.region = region
        self.bucket = bucket
        self._client: tos.TosClientV2 | None = None

    def _get_client(self) -> tos.TosClientV2:
        if self._client is None:
            env_path: str = dotenv.find_dotenv(
                usecwd=True, raise_error_if_not_found=True
            )
            dotenv.load_dotenv(env_path)
            ak = os.environ.get("TOS_ACCESS_KEY_ID")
            sk = os.environ.get("TOS_SECRET_ACCESS_KEY")
            if not ak or not sk:
                raise RuntimeError(
                    "TOS credentials not set. "
                    "Please set TOS_ACCESS_KEY_ID and TOS_SECRET_ACCESS_KEY."
                )
            self._client = tos.TosClientV2(
                ak=ak,
                sk=sk,
                endpoint=self.endpoint,
                region=self.region,
            )
        return self._client

    def upload(self, file_path: Path, prefix: str = "audio") -> str:
        """Upload a file to TOS and return the public URL.

        Args:
            file_path: Local path to the file.
            prefix: Key prefix in the bucket.

        Returns:
            Public URL of the uploaded file.
        """
        client = self._get_client()

        suffix = file_path.suffix or ".wav"
        key = f"{prefix}/{uuid.uuid4().hex}{suffix}"

        console.print(f"[bold blue]Uploading to TOS:[/] {file_path.name} -> {key}")

        with open(file_path, "rb") as f:
            client.put_object(bucket=self.bucket, key=key, content=f)

        url = f"https://{self.bucket}.{self.endpoint}/{key}"
        console.print(f"[bold green]Upload complete:[/] {url}")
        return url


# Keep backwards-compatible module-level function used by doubao transcriber
_default_storage = None


def _get_default_storage() -> TosStorage:
    global _default_storage
    if _default_storage is None:
        _default_storage = TosStorage()
    return _default_storage


def upload_audio(audio_path: Path) -> str:
    """Upload an audio file to TOS and return the public URL."""
    return _get_default_storage().upload(audio_path, prefix="audio")
