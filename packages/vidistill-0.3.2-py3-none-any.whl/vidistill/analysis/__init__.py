"""Analysis pipeline: download -> audio -> transcribe -> LLM -> report."""
