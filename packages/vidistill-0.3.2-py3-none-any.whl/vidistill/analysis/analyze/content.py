"""LLM content analysis using pydantic-ai."""

import os

import dotenv
from pydantic_ai import Agent
from pydantic_ai.models import Model

from vidistill.analysis.output.models import ContentAnalysis

SYSTEM_PROMPT = """\
你是一个专业的视频内容分析师。你的任务是分析视频的转录文本，提取结构化的内容信息。

请根据提供的转录文本，生成以下分析结果：

1. **标题（title）**：为这段内容拟一个准确概括主题的标题
2. **摘要（summary）**：200-300字的内容摘要，概括核心内容
3. **核心论点（key_points）**：提取3-7个核心论点或关键信息
4. **叙事结构（structure）**：将内容拆解为多个段落，每个段落包含：
   - 标题：段落的小标题
   - 时间范围：大致的时间范围（如 "00:00-02:30"）
   - 摘要：段落的简要描述
   - 功能：该段落在整体叙事中的功能（如：开场钩子、背景介绍、论点展开、案例论证、转折、总结升华等）
5. **话题标签（topics）**：3-5个话题关键词
6. **语言风格分析（language_style）**：
   - 整体基调（tone）：如严肃、轻松、学术、口语化等
   - 用词水平（vocabulary_level）：如通俗易懂、专业术语密集、文学性强等
   - 修辞手法（rhetoric_devices）：列出使用的主要修辞手法
   - 代表性表达（notable_expressions）：摘录2-5个有代表性的表达方式或金句

请确保分析全面且准确，结构化输出要符合指定的格式。所有内容使用中文输出。
"""


def _resolve_model(model: str) -> Model | str:
    """Resolve a model string, handling the openrouter: prefix.

    For 'openrouter:model-name', creates an OpenAI-compatible model
    pointing to Open Router's API endpoint.
    """
    if model.startswith("openrouter:"):
        env_path: str = dotenv.find_dotenv(usecwd=True, raise_error_if_not_found=True)
        dotenv.load_dotenv(env_path)
        api_key = os.environ.get("OPENROUTER_API_KEY")
        if not api_key:
            raise RuntimeError(
                "OPENROUTER_API_KEY not set. "
                "Please set the environment variable with your Open Router API key."
            )

        from pydantic_ai.providers.openai import OpenAIProvider

        provider = OpenAIProvider(
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key,
        )

        model_name = model.removeprefix("openrouter:")

        from pydantic_ai.models.openai import OpenAIChatModel

        return OpenAIChatModel(model_name, provider=provider)

    return model


def create_content_agent(model: str) -> Agent[None, ContentAnalysis]:
    """Create a pydantic-ai agent for content analysis.

    Args:
        model: Model string like 'openrouter:anthropic/claude-sonnet-4.6',
               'anthropic:claude-sonnet-4-20250514', 'openai:gpt-4o'.
    """
    resolved = _resolve_model(model)
    return Agent(
        model=resolved,
        system_prompt=SYSTEM_PROMPT,
        output_type=ContentAnalysis,
        retries=2,
    )


async def analyze_content(transcript_text: str, model: str) -> ContentAnalysis:
    """Analyze transcript text using LLM and return structured analysis.

    Args:
        transcript_text: The full transcript text to analyze.
        model: Model string for pydantic-ai.

    Returns:
        ContentAnalysis with structured analysis results.
    """
    agent = create_content_agent(model)
    result = await agent.run(f"请分析以下视频转录文本：\n\n{transcript_text}")
    return result.output
