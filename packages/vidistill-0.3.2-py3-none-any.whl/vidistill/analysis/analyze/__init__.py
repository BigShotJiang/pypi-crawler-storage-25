"""Content analysis module using LLM."""
