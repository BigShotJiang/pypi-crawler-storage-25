"""Transcription module with pluggable ASR backends."""

from vidistill.analysis.transcribe.protocol import Transcriber


def create_transcriber(name: str = "doubao") -> Transcriber:
    """Factory function to create a transcriber by name."""
    if name == "doubao":
        from vidistill.analysis.transcribe.doubao import DoubaoTranscriber

        return DoubaoTranscriber()
    else:
        raise ValueError(f"Unknown transcriber: {name}. Available: doubao")
