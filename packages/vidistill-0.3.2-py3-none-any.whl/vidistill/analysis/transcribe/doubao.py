"""豆包 (Doubao) ASR transcriber using ByteDance BigModel speech API."""

import os
import time
import uuid
from pathlib import Path

import dotenv
import httpx
from rich.console import Console

from vidistill.analysis.output.models import TranscriptSegment
from vidistill.analysis.storage import upload_audio

console = Console()

SUBMIT_URL = "https://openspeech.bytedance.com/api/v3/auc/bigmodel/submit"
QUERY_URL = "https://openspeech.bytedance.com/api/v3/auc/bigmodel/query"
RESOURCE_ID = "volc.seedasr.auc"

# Status codes
STATUS_SUCCESS = "20000000"
STATUS_PROCESSING = "20000001"
STATUS_QUEUED = "20000002"
STATUS_SILENT = "20000003"

POLL_INTERVAL = 3  # seconds
MAX_POLL_ATTEMPTS = 200  # ~10 minutes max


class DoubaoTranscriber:
    """Transcriber using 豆包录音文件识别模型2.0 (SeedASR)."""

    def transcribe(
        self, audio_path: Path, diarize: bool = False
    ) -> list[TranscriptSegment]:
        """Transcribe audio via 豆包 BigModel ASR API.

        Uploads audio to TOS first, then submits to the ASR API and polls
        for the result.
        """
        console.print(f"[bold blue]Transcribing with 豆包 SeedASR:[/] {audio_path}")

        # Step 1: Upload audio to TOS
        audio_url = upload_audio(audio_path)

        # Step 2: Submit transcription task
        task_id = self._submit_task(audio_url, audio_path, diarize)

        # Step 3: Poll for result
        result = self._poll_result(task_id)

        # Step 4: Parse result
        return self._parse_result(result, diarize)

    @staticmethod
    def _get_api_key(key_name: str) -> str:
        env_path: str = dotenv.find_dotenv(usecwd=True, raise_error_if_not_found=True)
        dotenv.load_dotenv(env_path)
        key = os.environ.get(key_name)
        if not key:
            raise RuntimeError(
                f"{key_name} not set. "
                "Please set the environment variable with your 豆包 API key."
            )
        return key

    def _submit_task(self, audio_url: str, audio_path: Path, diarize: bool) -> str:
        """Submit a transcription task and return the task ID."""
        task_id = str(uuid.uuid4())

        headers = {
            "X-Api-App-Key": self._get_api_key("VOLC_ENGINE_APP_ID"),
            "X-Api-Access-Key": self._get_api_key("VOLC_ENGINE_ACCESS_TOKEN"),
            "X-Api-Resource-Id": RESOURCE_ID,
            "X-Api-Request-Id": task_id,
            "X-Api-Sequence": "-1",
            "Content-Type": "application/json",
        }

        # Determine audio format from file extension
        suffix = audio_path.suffix.lower().lstrip(".")
        format_map = {"wav": "wav", "mp3": "mp3", "ogg": "ogg"}
        audio_format = format_map.get(suffix, "wav")

        body = {
            "user": {"uid": "vidistill-cli"},
            "audio": {
                "format": audio_format,
                "url": audio_url,
            },
            "request": {
                "model_name": "bigmodel",
                "enable_itn": True,
                "enable_punc": True,
                "show_utterances": True,
                "enable_speaker_info": diarize,
            },
        }

        console.print(f"[bold blue]Submitting task:[/] {task_id}")

        resp = httpx.post(SUBMIT_URL, headers=headers, json=body, timeout=30)
        status_code = resp.headers.get("X-Api-Status-Code", "")
        message = resp.headers.get("X-Api-Message", "")

        if status_code != STATUS_SUCCESS:
            raise RuntimeError(
                f"豆包 ASR submit failed: status={status_code}, message={message}"
            )

        console.print(f"[bold green]Task submitted:[/] {task_id}")
        return task_id

    def _poll_result(self, task_id: str) -> dict:
        """Poll for the transcription result until complete."""

        headers = {
            "X-Api-App-Key": self._get_api_key("VOLC_ENGINE_APP_ID"),
            "X-Api-Access-Key": self._get_api_key("VOLC_ENGINE_ACCESS_TOKEN"),
            "X-Api-Resource-Id": RESOURCE_ID,
            "X-Api-Request-Id": task_id,
            "Content-Type": "application/json",
        }

        for attempt in range(MAX_POLL_ATTEMPTS):
            resp = httpx.post(QUERY_URL, headers=headers, json={}, timeout=30)
            status_code = resp.headers.get("X-Api-Status-Code", "")
            message = resp.headers.get("X-Api-Message", "")

            if status_code == STATUS_SUCCESS:
                console.print("[bold green]Transcription complete.[/]")
                return resp.json()

            if status_code in (STATUS_PROCESSING, STATUS_QUEUED):
                if attempt % 5 == 0:
                    status_label = (
                        "processing" if status_code == STATUS_PROCESSING else "queued"
                    )
                    console.print(
                        f"[bold yellow]Status: {status_label}[/] "
                        f"(attempt {attempt + 1})"
                    )
                time.sleep(POLL_INTERVAL)
                continue

            if status_code == STATUS_SILENT:
                console.print("[bold yellow]Warning: silent audio detected.[/]")
                return {"result": {"text": "", "utterances": []}}

            raise RuntimeError(
                f"豆包 ASR query failed: status={status_code}, message={message}"
            )

        raise RuntimeError(
            f"豆包 ASR timed out after {MAX_POLL_ATTEMPTS * POLL_INTERVAL}s"
        )

    def _parse_result(self, data: dict, diarize: bool) -> list[TranscriptSegment]:
        """Parse the 豆包 ASR response into TranscriptSegment list."""
        segments: list[TranscriptSegment] = []

        result = data.get("result", {})
        utterances = result.get("utterances", [])

        if not utterances:
            # Fall back to full text if no utterances
            text = result.get("text", "")
            if text:
                segments.append(TranscriptSegment(start=0.0, end=0.0, text=text))
            return segments

        for utt in utterances:
            text = utt.get("text", "").strip()
            if not text:
                continue

            start_ms = utt.get("start_time", 0)
            end_ms = utt.get("end_time", 0)

            speaker = None
            if diarize:
                additions = utt.get("additions", {})
                speaker_id = additions.get("speaker_id")
                if speaker_id is not None:
                    speaker = f"Speaker {speaker_id}"

            segments.append(
                TranscriptSegment(
                    start=start_ms / 1000.0,
                    end=end_ms / 1000.0,
                    text=text,
                    speaker=speaker,
                )
            )

        return segments
