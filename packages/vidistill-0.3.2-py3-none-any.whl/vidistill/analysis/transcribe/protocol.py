"""Transcriber protocol definition."""

from pathlib import Path
from typing import Protocol

from vidistill.analysis.output.models import TranscriptSegment


class Transcriber(Protocol):
    """Protocol for ASR transcription backends."""

    def transcribe(
        self, audio_path: Path, diarize: bool = False
    ) -> list[TranscriptSegment]:
        """Transcribe an audio file and return a list of segments.

        Args:
            audio_path: Path to the audio file.
            diarize: Whether to enable speaker diarization.

        Returns:
            List of transcript segments with timestamps.
        """
        ...
