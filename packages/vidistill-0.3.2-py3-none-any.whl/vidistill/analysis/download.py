"""Video download module wrapping yt-dlp."""

import re
import shutil
from pathlib import Path

from rich.console import Console

console = Console()

# Patterns that indicate a URL rather than a local path
URL_PATTERNS = [
    re.compile(r"^https?://"),
    re.compile(r"^www\."),
]

# Audio-only file extensions
AUDIO_EXTENSIONS = {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"}


def is_url(input_path: str) -> bool:
    """Check if the input is a URL."""
    return any(p.match(input_path) for p in URL_PATTERNS)


def is_audio_file(path: Path) -> bool:
    """Check if a file is an audio-only file."""
    return path.suffix.lower() in AUDIO_EXTENSIONS


class Downloader:
    """Download or copy media files to a target directory.

    Supports network URLs (via yt-dlp) and local file paths.
    """

    def __init__(self, output_dir: Path):
        self.output_dir = output_dir

    def download(self, uri: str) -> tuple[Path, str]:
        """Download from a URI or copy a local file to the output directory.

        Args:
            uri: A network URL or a local file path.

        Returns:
            Tuple of (local_file_path, title).
        """
        if is_url(uri):
            return self._download_from_url(uri)
        else:
            return self._handle_local_file(uri)

    def _download_from_url(self, url: str) -> tuple[Path, str]:
        """Download video from URL using yt-dlp."""
        import yt_dlp

        self.output_dir.mkdir(parents=True, exist_ok=True)

        # First extract info to get the title
        with yt_dlp.YoutubeDL({"quiet": True}) as ydl:
            info = ydl.extract_info(url, download=False)
            if info is None:
                raise RuntimeError(f"Failed to extract info from URL: {url}")
            title = info.get("title", "untitled")
            assert isinstance(title, str)

        output_template = str(self.output_dir / "video.%(ext)s")

        ydl_opts = {
            "outtmpl": output_template,
            "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
            "merge_output_format": "mp4",
            "quiet": False,
            "no_warnings": False,
        }

        console.print(f"[bold blue]Downloading:[/] {url}")
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:  # type: ignore
            ydl.download([url])

        # Find the downloaded file
        video_path = self.output_dir / "video.mp4"
        if not video_path.exists():
            # Try to find any video file in the output dir
            video_files = list(self.output_dir.glob("video.*"))
            if video_files:
                video_path = video_files[0]
            else:
                raise FileNotFoundError(
                    f"Downloaded video not found in {self.output_dir}"
                )

        console.print(f"[bold green]Downloaded:[/] {video_path}")
        return video_path, title

    def _handle_local_file(self, file_path: str) -> tuple[Path, str]:
        """Handle a local file by copying it to the output directory."""
        source = Path(file_path).resolve()
        if not source.exists():
            raise FileNotFoundError(f"Local file not found: {file_path}")

        title = source.stem
        self.output_dir.mkdir(parents=True, exist_ok=True)

        dest = self.output_dir / source.name
        if dest.resolve() != source.resolve():
            shutil.copy2(source, dest)
            console.print(f"[bold green]Copied:[/] {source} -> {dest}")
        else:
            console.print(f"[bold green]Using local file:[/] {source}")

        return dest, title


# Backwards-compatible module-level function
def download_video(input_path: str, output_dir: Path) -> tuple[Path, str]:
    """Download video from URL or copy local file to output directory.

    Returns:
        Tuple of (local_file_path, video_title).
    """
    return Downloader(output_dir).download(input_path)
