"""Audio extraction module using ffmpeg subprocess."""

import subprocess
from pathlib import Path

from rich.console import Console

console = Console()


def extract_audio(input_file: Path, output_dir: Path) -> Path:
    """Extract audio from a video file to WAV format.

    If the input is already an audio file, copy/convert it to WAV.
    Skips extraction if the output file already exists.

    Returns:
        Path to the extracted WAV audio file.
    """
    output_path = output_dir / "audio.wav"

    if output_path.exists():
        console.print(
            f"[bold yellow]Skipping audio extraction:[/] {output_path} already exists"
        )
        return output_path

    output_dir.mkdir(parents=True, exist_ok=True)

    console.print(f"[bold blue]Extracting audio:[/] {input_file} -> {output_path}")

    cmd = [
        "ffmpeg",
        "-i",
        str(input_file),
        "-vn",  # No video
        "-acodec",
        "pcm_s16le",  # PCM 16-bit little-endian
        "-ar",
        "16000",  # 16kHz sample rate (good for ASR)
        "-ac",
        "1",  # Mono channel
        "-y",  # Overwrite output
        str(output_path),
    ]

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"ffmpeg failed with exit code {result.returncode}:\n{result.stderr}"
        )

    console.print(f"[bold green]Audio extracted:[/] {output_path}")

    _validate_audio(output_path)

    return output_path


def _validate_audio(path: Path) -> None:
    """Validate that the file is a valid audio file using ffprobe."""
    if not path.exists() or path.stat().st_size == 0:
        raise RuntimeError(
            f"Audio extraction produced an empty or missing file: {path}"
        )

    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "a:0",
            "-show_entries",
            "stream=codec_type",
            "-of",
            "csv=p=0",
            str(path),
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0 or "audio" not in result.stdout:
        raise RuntimeError(
            f"Output file is not a valid audio file: {path}\n{result.stderr}"
        )
