"""Vidistill - Video content distillation tool."""
