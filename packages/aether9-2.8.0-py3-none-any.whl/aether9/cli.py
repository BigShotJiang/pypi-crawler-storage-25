#!/usr/bin/env python3
"""aether — Aether-9 Language CLI  v2.0"""

import sys, argparse, datetime
from pathlib import Path
from .compiler  import Aether9Compiler, CompileError, LexError, ParseError
from .repl       import run_shell
from .sandbox    import Sandbox, ASTGuardError
from .signature import SignatureFile
from .core      import VortexSequencer

def _paths(f): p=Path(f); return p, p.with_suffix('.py'), p.with_suffix('.a9s')
def _read(p):
    if not p.exists(): _die(f"file not found: {p}")
    return p.read_text()
def _die(m): print(f"aether: error: {m}", file=sys.stderr); sys.exit(1)

G="\033[32m"; R="\033[31m"; X="\033[0m"
def _ok(m):   print(f"  {G}✓{X}  {m}")
def _fail(m): print(f"  {R}✗{X}  {m}", file=sys.stderr)
def _info(m): print(f"      {m}")

def _compile_source(p, source, py, a9s):
    code, registry = Aether9Compiler().compile(source)
    sig = SignatureFile.generate(source, registry, p.name)
    py.write_text(code)
    SignatureFile.save(sig, str(a9s))
    return code, sig

def cmd_compile(args):
    p, py, a9s = _paths(args.file)
    source = _read(p)
    print(f"⚙️   compiling  {p.name}")
    try:
        code, sig = _compile_source(p, source, py, a9s)
    except (LexError, ParseError, CompileError) as e:
        _fail(str(e)); sys.exit(1)
    _ok(f"{py.name}   — compiled python")
    _ok(f"{a9s.name}  — signature file")
    _info(f"arrays      : {list(sig['arrays'].keys())}")
    _info(f"global seal : {sig.get('global_mac', sig.get('global_seal','—'))[:16]+'...'}")
    if args.verbose:
        for name, info in sig['arrays'].items():
            _info(f"{name:16s}  hmac={info.get('hmac','—')[:16]}...")

def cmd_verify(args):
    p, _, a9s = _paths(args.file)
    source = _read(p)
    if not a9s.exists():
        _die(f"no signature file: {a9s}\n       run 'aether compile {p}' first.")
    print(f"🔍  verifying  {p.name}")
    sig = SignatureFile.load(str(a9s))
    ok, msg = SignatureFile.verify(sig, source)
    if ok:
        _ok("signature valid")
        _info(f"arrays      : {list(sig['arrays'].keys())}")
        _info(f"global seal : {sig.get('global_mac', sig.get('global_seal','—'))[:16]+'...'}")
        if args.verbose:
            for name, info in sig['arrays'].items():
                cur, _ = VortexSequencer(info['data']).compute_seal()
                mark = f"{G}✓{X}" if cur == info['raw_sig'] else f"{R}✗{X}"
                _info(f"{name:16s}  {mark}  hmac={info.get('hmac','—')[:16]}...")
    else:
        _fail(msg); sys.exit(1)

def cmd_run(args):
    p, py, a9s = _paths(args.file)
    source = _read(p)
    if a9s.exists():
        print(f"🔍  verifying  {p.name}")
        sig = SignatureFile.load(str(a9s))
        ok, msg = SignatureFile.verify(sig, source)
        if not ok:
            _fail(msg)
            print(f"\n       re-compile with 'aether compile {p}' if intentional.", file=sys.stderr)
            sys.exit(1)
        _ok(f"signature valid  (global_seal={sig.get('global_mac', sig.get('global_seal','—'))[:16]+'...'})")
        if py.exists() and py.stat().st_mtime >= a9s.stat().st_mtime:
            code = py.read_text()
        else:
            try: code, _ = _compile_source(p, source, py, a9s)
            except (LexError, ParseError, CompileError) as e: _fail(str(e)); sys.exit(1)
    else:
        print(f"⚙️   no .a9s — compiling {p.name}")
        try: code, sig = _compile_source(p, source, py, a9s)
        except (LexError, ParseError, CompileError) as e: _fail(str(e)); sys.exit(1)
        _ok(f"compiled & signed  (global_seal={sig.get('global_mac', sig.get('global_seal','—'))[:16]+'...'})")
    print(f"\n🚀  running    {p.name}\n")
    try:
        exec(compile(code, str(py), 'exec'), {'__name__': '__main__'})
    except RuntimeError as e:
        _fail(str(e)); sys.exit(1)

def cmd_inspect(args):
    p = Path(args.file)
    if not p.exists(): _die(f"file not found: {p}")
    sig = SignatureFile.load(str(p))
    ts  = datetime.datetime.fromtimestamp(sig['created_at']).strftime('%Y-%m-%d %H:%M:%S')
    W = 50
    print(f"\n{'─'*W}\n  Aether-9 Signature  ·  {p.name}\n{'─'*W}")
    print(f"  version      {sig['version']}")
    print(f"  source       {sig['source']}")
    print(f"  created      {ts}")
    print(f"  source hash  {sig['source_hash'][:20]}…")
    print(f"  global seal  {sig.get('global_mac', sig.get('global_seal','—'))[:16]+'...'}")
    print(f"\n  Arrays  ({len(sig['arrays'])})")
    for name, info in sig['arrays'].items():
        print(f"    {name}\n      data     {info['data']}\n      hmac     {info.get('hmac','—')[:20]}...")
    print(f"{'─'*W}\n")

def cmd_shell(args):
    run_shell()

def main():
    parser = argparse.ArgumentParser(
        prog="aether",
        description="Aether-9 Language CLI  v2.0  (compiler edition)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="commands:\n  compile  run  verify  inspect"
    )
    parser.add_argument("command", choices=["compile","run","verify","inspect","shell"])
    parser.add_argument("file", nargs="?", default=None)
    parser.add_argument("-v","--verbose", action="store_true")
    args = parser.parse_args()
    if args.command == "shell":
        cmd_shell(args)
    else:
        if not args.file:
            parser.error(f"command '{args.command}' requires a file argument")
        {"compile":cmd_compile,"run":cmd_run,"verify":cmd_verify,"inspect":cmd_inspect}[args.command](args)

if __name__ == "__main__":
    main()
