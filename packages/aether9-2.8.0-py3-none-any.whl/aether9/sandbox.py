"""
Aether-9 Sandbox — isolated execution layer
─────────────────────────────────────────────
طبقتان من الحماية:
  1. AST Guard — يفحص الكود قبل التنفيذ ويرفض أي شيء خطير
  2. Subprocess Runner — ينفذ الكود في process منفصل محدود
"""

import ast
import sys
import os
import subprocess
import tempfile
import textwrap
import json
from pathlib import Path
from typing import Tuple, Optional

# ── ما هو مسموح به في الكود المُولَّد ──
ALLOWED_BUILTINS = frozenset({
    'print', 'len', 'abs', 'min', 'max',
    'str', 'int', 'float', 'bool', 'range',
    'isinstance', 'type', 'repr',
    'True', 'False', 'None',
})

# ── ما هو محظور دائماً ──
FORBIDDEN_NODES = (
    ast.Import,
    ast.ImportFrom,
    ast.Global,
    ast.Nonlocal,
)

FORBIDDEN_NAMES = frozenset({
    '__import__', '__builtins__', '__class__',
    'eval', 'exec', 'compile', 'open',
    'input',       # مُعاد تعريفها بأمان في runtime
    '__subclasses__', '__mro__', '__bases__',
    'getattr', 'setattr', 'delattr', 'vars', 'dir',
    'globals', 'locals',
})

R = "\033[31m"; Y = "\033[33m"; X = "\033[0m"; BOLD = "\033[1m"


# ══════════════════════════════════════════
# LAYER 1 — AST GUARD
# ══════════════════════════════════════════

class ASTGuardError(Exception):
    pass


class ASTGuard(ast.NodeVisitor):
    """
    يمشي على الـ AST ويرفض أي node خطير
    قبل أن يصل الكود للـ subprocess.
    """

    def visit_Import(self, node):
        raise ASTGuardError(
            f"  {BOLD}{R}[SecurityError]{X}\n"
            f"  'import' is not allowed in Aether-9 programs.\n"
            f"  {Y}hint:{X} use the stdlib functions instead (abs, min, max, dr, ...)\n"
        )

    def visit_ImportFrom(self, node):
        raise ASTGuardError(
            f"  {BOLD}{R}[SecurityError]{X}\n"
            f"  'from ... import' is not allowed in Aether-9 programs.\n"
        )

    def visit_Global(self, node):
        raise ASTGuardError(
            f"  {BOLD}{R}[SecurityError]{X}\n"
            f"  'global' statement is not allowed.\n"
        )

    def visit_Name(self, node):
        if node.id in FORBIDDEN_NAMES:
            raise ASTGuardError(
                f"  {BOLD}{R}[SecurityError]{X}\n"
                f"  '{node.id}' is not allowed in Aether-9 programs.\n"
                f"  {Y}hint:{X} use the Aether-9 stdlib instead.\n"
            )
        self.generic_visit(node)

    def visit_Attribute(self, node):
        # منع dunder attributes الخطيرة
        if isinstance(node.attr, str) and node.attr.startswith('__'):
            dangerous = {'__class__', '__subclasses__', '__mro__',
                         '__globals__', '__builtins__', '__code__'}
            if node.attr in dangerous:
                raise ASTGuardError(
                    f"  {BOLD}{R}[SecurityError]{X}\n"
                    f"  Attribute '{node.attr}' is not allowed.\n"
                )
        self.generic_visit(node)


def guard_check(python_code: str) -> None:
    """
    يُحلل الكود المُولَّد ويرفع ASTGuardError إذا وجد شيئاً خطيراً.
    يُستدعى قبل أي تنفيذ.
    """
    try:
        tree = ast.parse(python_code)
    except SyntaxError as e:
        raise ASTGuardError(f"  [SyntaxError] {e}")
    ASTGuard().visit(tree)


# ══════════════════════════════════════════
# LAYER 2 — SUBPROCESS RUNNER
# ══════════════════════════════════════════

# الـ runtime الآمن الذي يُحقن في كل عملية تنفيذ
_SAFE_RUNTIME_HEADER = '''\
import sys, os, time

# نغلق الوصول للـ builtins الخطيرة
_SAFE = {
    'print':       print,
    'len':         len,
    'abs':         abs,
    'min':         min,
    'max':         max,
    'str':         str,
    'int':         int,
    'float':       float,
    'bool':        bool,
    'range':       range,
    'isinstance':  isinstance,
    'type':        type,
    'repr':        repr,
    'True':        True,
    'False':       False,
    'None':        None,
}

# نحدف __builtins__ الخطيرة
import builtins as _b
_b.eval    = None
_b.exec    = None
_b.compile = None
_b.__import__ = None
del _b

'''


class SandboxResult:
    def __init__(self, stdout: str, stderr: str,
                 returncode: int, timed_out: bool):
        self.stdout     = stdout
        self.stderr     = stderr
        self.returncode = returncode
        self.timed_out  = timed_out

    @property
    def success(self) -> bool:
        return self.returncode == 0 and not self.timed_out


class Sandbox:
    """
    ينفذ الكود المُولَّد في subprocess معزول مع:
    - timeout (افتراضي 30 ثانية)
    - بيئة محدودة (لا PATH خارجي)
    - AST guard قبل التنفيذ
    """

    def __init__(self,
                 timeout: int = 30,
                 workdir: Optional[str] = None):
        self.timeout = timeout
        self.workdir = workdir or os.getcwd()

    def run(self, python_code: str,
            input_data: str = "") -> SandboxResult:
        """
        1. يفحص الكود بـ AST Guard
        2. يكتبه في ملف مؤقت
        3. يُشغّله في subprocess معزول
        4. يُرجع النتيجة
        """

        # Layer 1: AST check
        try:
            guard_check(python_code)
        except ASTGuardError as e:
            return SandboxResult(
                stdout="", stderr=str(e),
                returncode=1, timed_out=False
            )

        # Layer 2: subprocess
        safe_code = _SAFE_RUNTIME_HEADER + python_code

        with tempfile.NamedTemporaryFile(
            mode='w', suffix='.py',
            delete=False, dir=self.workdir
        ) as f:
            f.write(safe_code)
            tmp_path = f.name

        try:
            env = {
                'PATH':       '/usr/bin:/bin',
                'PYTHONPATH': '',
                'HOME':       self.workdir,
            }

            result = subprocess.run(
                [sys.executable, '-I', '-S', tmp_path],
                capture_output=True,
                text=True,
                timeout=self.timeout,
                cwd=self.workdir,
                env=env,
                input=input_data,
            )

            return SandboxResult(
                stdout=result.stdout,
                stderr=result.stderr,
                returncode=result.returncode,
                timed_out=False,
            )

        except subprocess.TimeoutExpired:
            return SandboxResult(
                stdout="",
                stderr=f"  {BOLD}{R}[TimeoutError]{X}\n"
                       f"  Program exceeded {self.timeout}s limit.\n",
                returncode=1,
                timed_out=True,
            )
        finally:
            Path(tmp_path).unlink(missing_ok=True)
