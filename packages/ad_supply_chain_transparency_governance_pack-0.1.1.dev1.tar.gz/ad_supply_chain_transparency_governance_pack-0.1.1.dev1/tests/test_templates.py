from __future__ import annotations

import unittest

from ssot_pack_ad_supply_chain_transparency import (
    __pypi_package_name__,
    __ssot_package_name__,
    load_document_manifest,
    load_pack_manifest,
    load_pack_metadata,
    load_pack_schema_version,
    read_packaged_document_text,
)


class GovernancePackManifestTests(unittest.TestCase):
    def test_pack_metadata_contract_is_exposed(self) -> None:
        metadata = load_pack_metadata()
        self.assertEqual("ad-supply-chain-transparency-governance-pack", __ssot_package_name__)
        self.assertEqual("ad-supply-chain-transparency-governance-pack", __pypi_package_name__)
        self.assertEqual("1.0.0", metadata["schema_version"])
        self.assertEqual("ad-supply-chain-transparency-governance-pack", metadata["ssot_package_name"])
        self.assertEqual("pack:ad-supply-chain-transparency", metadata["origin"]["id"])
        self.assertEqual("ssot_pack_ad_supply_chain_transparency", metadata["origin"]["import_name"])
        self.assertEqual("governance-pack", metadata["origin"]["kind"])
        self.assertEqual("extension-pack", metadata["trust"]["origin"])
        self.assertEqual("extension-pack:ad-supply-chain-transparency-governance-pack", metadata["trust"]["reservation_owner"])
        self.assertFalse(metadata["trust"]["trusted_by_default"])
        self.assertEqual("1.0.0", load_pack_schema_version())

    def test_pack_manifest_contract_is_exposed(self) -> None:
        manifest = load_pack_manifest()
        self.assertEqual("ad-supply-chain-transparency-governance-pack", manifest["metadata"]["origin"]["package_name"])
        self.assertEqual(8, len(manifest["documents"]["adr"]))
        self.assertEqual(12, len(manifest["documents"]["spec"]))

    def test_packaged_documents_are_readable(self) -> None:
        adr_manifest = load_document_manifest("adr")
        spec_manifest = load_document_manifest("spec")
        self.assertEqual("adr:ads-txt-authorized-digital-seller-policy", adr_manifest[0]["id"])
        self.assertEqual("spc:ads-txt-file-discovery-and-parsing-requirements", spec_manifest[0]["id"])
        self.assertIn("Ads.txt Authorized Digital Seller Policy", read_packaged_document_text("adr", adr_manifest[0]["filename"]))
        self.assertIn("Ads.txt File Discovery And Parsing Requirements", read_packaged_document_text("spec", spec_manifest[0]["filename"]))

    def test_packaged_adr_documents_are_downstream_portable(self) -> None:
        forbidden_terms = (
            "pack:",
            "This pack",
            "extension-pack",
            "governance-pack",
            "ssot-pack",
        )
        for entry in load_document_manifest("adr"):
            text = read_packaged_document_text("adr", entry["filename"])
            for term in forbidden_terms:
                self.assertNotIn(term, text)

    def test_packaged_spec_documents_are_downstream_portable(self) -> None:
        forbidden_terms = (
            "pack:",
            "This pack",
            "extension-pack",
            "governance-pack",
            "ssot-pack",
        )
        for entry in load_document_manifest("spec"):
            text = read_packaged_document_text("spec", entry["filename"])
            for term in forbidden_terms:
                self.assertNotIn(term, text)


if __name__ == "__main__":
    unittest.main()
