import atexit
import contextlib
import contextvars
import json
import logging
import os
import queue
import threading
import time
import uuid
from collections import deque
from datetime import UTC, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

LOG_DIR = Path(os.environ.get("BURNR8_LOG_DIR", os.path.expanduser("~/.burnr8/logs")))
LOG_LEVEL = os.environ.get("BURNR8_LOG_LEVEL", "INFO").upper()
USAGE_FILE = LOG_DIR / "usage.json"
CLOUD_MODE = bool(os.environ.get("BURNR8_CLOUD"))

_logger: logging.Logger | None = None
_usage_lock = threading.Lock()
_usage_cache: dict | None = None
_usage_dirty: bool = False
_last_save: float = 0.0
_SAVE_INTERVAL: float = 1.0  # seconds — coalesce writes to at most once per second

# Correlation ID for tracing multi-tool workflows (e.g. quick_audit → 6 GAQL queries)
correlation_id: contextvars.ContextVar[str | None] = contextvars.ContextVar("correlation_id", default=None)

# Cloud user ID — set by the hosted server during credential resolution.
# IMPORTANT: Must be set in the same thread/context that executes the tool call.
# If using a thread pool, use contextvars.copy_context().run() to propagate.
cloud_user_id: contextvars.ContextVar[str | None] = contextvars.ContextVar("cloud_user_id", default=None)

__all__ = ["log_tool_call", "get_usage_stats", "get_recent_errors", "new_correlation_id", "get_correlation_id", "cloud_user_id", "flush"]

# Bounded queue for cloud log writes — single worker thread, max 100 pending items.
# Items beyond the limit are silently dropped (backpressure).
_cloud_queue: queue.Queue | None = None
_cloud_worker: threading.Thread | None = None
_cloud_init_lock = threading.Lock()


def new_correlation_id() -> str:
    """Generate and set a new correlation ID. Returns the ID."""
    cid = uuid.uuid4().hex[:12]
    correlation_id.set(cid)
    return cid


def get_correlation_id() -> str | None:
    """Get the current correlation ID, or None if not set."""
    return correlation_id.get()


class _JsonFormatter(logging.Formatter):
    """JSON log format for cloud deployments — machine-parseable by CloudWatch, Datadog, etc."""

    def format(self, record: logging.LogRecord) -> str:
        import json as _json

        entry = {
            "ts": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "msg": record.getMessage(),
        }
        return _json.dumps(entry)


def get_logger() -> logging.Logger:
    global _logger
    if _logger is None:
        with _usage_lock:
            if _logger is None:  # double-check
                LOG_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
                log_path = LOG_DIR / "burnr8.log"
                # Create log file with restrictive permissions if it doesn't exist
                if not log_path.exists():
                    fd = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                    os.close(fd)
                _logger = logging.getLogger("burnr8")
                _logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
                # Rotating handler: 10MB max, 3 backups
                handler = RotatingFileHandler(log_path, maxBytes=10_000_000, backupCount=3)
                if CLOUD_MODE:
                    handler.setFormatter(_JsonFormatter())
                else:
                    handler.setFormatter(
                        logging.Formatter("%(asctime)s %(levelname)-5s %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
                    )
                _logger.addHandler(handler)
    return _logger


def _load_usage() -> dict[str, Any]:
    """Load today's usage data from disk."""
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    if USAGE_FILE.exists():
        try:
            data: dict[str, Any] = json.loads(USAGE_FILE.read_text())
            if data.get("date") == today:
                data["calls"] = deque(data.get("calls", []), maxlen=50)
                return data
        except (json.JSONDecodeError, OSError, KeyError):
            pass
    return {"date": today, "ops": 0, "errors": 0, "calls": deque(maxlen=50)}


def _save_usage(data: dict) -> None:
    """Atomic write: temp file then replace. Raises OSError on failure."""
    LOG_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    tmp = USAGE_FILE.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with open(fd, "w") as f:
        f.write(json.dumps(data, indent=2))
    tmp.replace(USAGE_FILE)


def _get_usage() -> dict:
    global _usage_cache
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    if _usage_cache is None or _usage_cache.get("date") != today:
        _usage_cache = _load_usage()
    return _usage_cache


def _flush_usage() -> None:
    """Flush any pending dirty usage data to disk. Called by atexit to prevent data loss."""
    with _usage_lock:
        global _usage_dirty, _last_save
        if not _usage_dirty or _usage_cache is None:
            return
        calls = _usage_cache.get("calls", deque(maxlen=50))
        snapshot = {**_usage_cache, "calls": list(calls)}
        try:
            _save_usage(snapshot)
        except OSError:
            return  # Best-effort; process is exiting
        _usage_dirty = False
        _last_save = time.monotonic()


def flush() -> None:
    """Flush all pending log data before shutdown.

    Writes dirty usage counters to disk, then sends a stop sentinel to
    the cloud log worker thread (if running) and waits up to 5 seconds
    for it to drain pending items.  Safe to call multiple times.
    """
    _flush_usage()

    global _cloud_queue, _cloud_worker
    with _cloud_init_lock:
        q = _cloud_queue
        w = _cloud_worker
        if q is None or w is None or not w.is_alive():
            return
        # Detach globals before releasing the lock so _enqueue_cloud_log
        # will create a fresh queue rather than writing to the dying one.
        _cloud_queue = None
        _cloud_worker = None

    # Outside the lock: drain and join.
    try:
        q.put(None, timeout=2)  # sentinel — tells worker to exit
    except queue.Full:
        get_logger().warning("cloud log queue full — pending rows will be lost")
        return
    w.join(timeout=5)
    if w.is_alive():
        get_logger().warning("cloud log worker did not exit within 5s")


atexit.register(flush)


def log_tool_call(tool_name: str, customer_id: str | None, duration: float, status: str, detail: str = "") -> None:
    """Log a tool call and update daily usage counters. Thread-safe."""
    logger = get_logger()
    msg = f"tool={tool_name}"
    cid = get_correlation_id()
    if cid:
        msg += f" cid={cid}"
    if customer_id:
        msg += f" customer={customer_id[:6]}"
    msg += f" duration={duration:.1f}s status={status}"
    if detail:
        msg += f" {detail}"

    if status == "error":
        logger.error(msg)
    else:
        logger.info(msg)

    with _usage_lock:
        global _usage_dirty, _last_save
        usage = _get_usage()
        usage["ops"] += 1
        if status == "error":
            usage["errors"] += 1

        # Keep last 50 calls (deque with maxlen auto-evicts oldest)
        calls = usage.get("calls")
        if calls is None:
            calls = deque(maxlen=50)
            usage["calls"] = calls
        elif not isinstance(calls, deque):
            calls = deque(calls, maxlen=50)
            usage["calls"] = calls
        calls.append(
            {
                "time": datetime.now(UTC).strftime("%H:%M:%S"),
                "tool": tool_name,
                "status": status,
                "duration": round(duration, 1),
            }
        )
        _usage_dirty = True
        # Coalesce writes: flush to disk at most once per second
        now = time.monotonic()
        if now - _last_save >= _SAVE_INTERVAL:
            snapshot = {**usage, "calls": list(calls)}
            try:
                _save_usage(snapshot)
            except OSError:
                pass  # Telemetry write failed; don't crash the tool
            else:
                _usage_dirty = False
                _last_save = now

    # Cloud mode: enqueue async insert to Supabase usage_logs.
    # Reads ContextVars here (calling thread), not in the worker.
    if CLOUD_MODE:
        user_id = cloud_user_id.get()
        if user_id:
            # Normalize status to match CHECK constraint ('ok', 'error')
            db_status = "error" if status in ("error", "warn") else "ok"
            row = {
                "user_id": user_id,  # uuid — must match auth.users.id
                "tool_name": tool_name,
                "customer_id": customer_id,
                "status": db_status,
                "duration_ms": round(duration * 1000),
            }
            _enqueue_cloud_log(row)


def _enqueue_cloud_log(row: dict) -> None:
    """Enqueue a row for the cloud log worker. Non-blocking, drops if queue is full."""
    global _cloud_queue, _cloud_worker
    if _cloud_queue is None:
        with _cloud_init_lock:
            if _cloud_queue is None:
                _cloud_queue = queue.Queue(maxsize=100)
                _cloud_worker = threading.Thread(target=_cloud_log_worker, daemon=True)
                _cloud_worker.start()

    q = _cloud_queue  # local snapshot — immune to flush() nulling the global
    if q is not None:
        with contextlib.suppress(queue.Full):
            q.put_nowait(row)


def _cloud_log_worker() -> None:
    """Single background thread that drains the cloud log queue."""
    assert _cloud_queue is not None
    while True:
        row = _cloud_queue.get()
        if row is None:
            _cloud_queue.task_done()
            break
        _write_cloud_log(row)
        _cloud_queue.task_done()


def _write_cloud_log(row: dict) -> None:
    """Insert a usage log row into Supabase. Called from the cloud worker thread."""
    try:
        import requests
    except ImportError:
        return

    supabase_url = os.environ.get("BURNR8_SUPABASE_URL")
    supabase_key = os.environ.get("BURNR8_SUPABASE_KEY")
    if not supabase_url or not supabase_key:
        return
    if not supabase_url.startswith("https://"):
        return

    with contextlib.suppress(requests.RequestException, OSError, ValueError, TypeError):
        requests.post(
            f"{supabase_url}/rest/v1/usage_logs",
            headers={
                "Authorization": f"Bearer {supabase_key}",
                "apikey": supabase_key,
                "Content-Type": "application/json",
                "Prefer": "return=minimal",
            },
            json=row,
            timeout=5,
        )


def get_usage_stats() -> dict:
    """Get today's usage stats."""
    with _usage_lock:
        data = _get_usage()
    return {
        "date": data["date"],
        "ops_today": data["ops"],
        "ops_limit": 15_000,
        "ops_pct": round(data["ops"] / 15_000 * 100, 1),
        "errors_today": data["errors"],
        "recent_calls": list(data.get("calls", []))[-10:],
        "log_file": str(LOG_DIR / "burnr8.log"),
        "log_level": LOG_LEVEL,
    }


def get_recent_errors(limit: int = 20) -> list[dict]:
    """Read recent ERROR lines from burnr8.log. Uses deque to avoid loading all errors into memory."""
    log_path = LOG_DIR / "burnr8.log"
    if not log_path.exists():
        return []

    try:
        with open(log_path) as f:
            window = deque(
                ({"raw": line.strip()} for line in f if " ERROR " in line),
                maxlen=limit,
            )
        return list(window)
    except OSError:
        return []
