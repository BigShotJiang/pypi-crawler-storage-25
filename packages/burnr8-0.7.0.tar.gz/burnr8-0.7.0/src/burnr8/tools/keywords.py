from __future__ import annotations

from typing import TYPE_CHECKING, Annotated

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from fastmcp import FastMCP

from burnr8.client import get_client
from burnr8.errors import handle_google_ads_errors
from burnr8.helpers import (
    dollars_to_micros,
    micros_to_dollars,
    require_customer_id,
    run_gaql,
    validate_cpc_bid,
    validate_id,
)
from burnr8.reports import save_report


class KeywordInput(BaseModel):
    text: str = Field(description="The keyword text")
    match_type: str = Field(default="BROAD", description="Match type: EXACT, PHRASE, or BROAD")


def register(mcp: FastMCP) -> None:
    @mcp.tool
    @handle_google_ads_errors
    def list_keywords(
        customer_id: Annotated[
            str | None, Field(description="Google Ads customer ID (no dashes). Uses active account if not provided.")
        ] = None,
        ad_group_id: Annotated[str | None, Field(description="Filter by ad group ID")] = None,
    ) -> dict:
        """List keyword inventory — what keywords exist, their config, bids, match types, and quality scores. Filter by ad group."""
        customer_id, cid_err = require_customer_id(customer_id)
        if cid_err:
            return cid_err
        if ad_group_id is not None and (err := validate_id(ad_group_id, "ad_group_id")):
            return {"error": True, "message": err}
        client = get_client()
        query = """
            SELECT
                ad_group_criterion.criterion_id,
                ad_group_criterion.keyword.text,
                ad_group_criterion.keyword.match_type,
                ad_group_criterion.status,
                ad_group_criterion.cpc_bid_micros,
                ad_group_criterion.quality_info.quality_score,
                ad_group_criterion.quality_info.creative_quality_score,
                ad_group_criterion.quality_info.post_click_quality_score,
                ad_group_criterion.quality_info.search_predicted_ctr,
                ad_group_criterion.position_estimates.first_page_cpc_micros,
                ad_group_criterion.position_estimates.top_of_page_cpc_micros,
                ad_group_criterion.tracking_url_template,
                ad_group_criterion.final_url_suffix,
                ad_group_criterion.url_custom_parameters,
                ad_group.id,
                ad_group.name,
                campaign.id,
                campaign.name,
                metrics.impressions,
                metrics.clicks,
                metrics.cost_micros,
                metrics.conversions
            FROM keyword_view
        """
        conditions = []
        if ad_group_id:
            conditions.append(f"ad_group.id = {ad_group_id}")
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY ad_group_criterion.keyword.text"

        rows = run_gaql(client, customer_id, query)
        results = []
        for row in rows:
            cr = row.get("ad_group_criterion", {})
            kw = cr.get("keyword", {})
            qi = cr.get("quality_info", {})
            pe = cr.get("position_estimates", {})
            ag = row.get("ad_group", {})
            c = row.get("campaign", {})
            m = row.get("metrics", {})
            results.append(
                {
                    "criterion_id": cr.get("criterion_id"),
                    "text": kw.get("text"),
                    "match_type": kw.get("match_type"),
                    "status": cr.get("status"),
                    "cpc_bid_dollars": micros_to_dollars(int(cr.get("cpc_bid_micros", 0))),
                    "quality_score": qi.get("quality_score"),
                    "creative_quality": qi.get("creative_quality_score"),
                    "landing_page_quality": qi.get("post_click_quality_score"),
                    "expected_ctr": qi.get("search_predicted_ctr"),
                    "first_page_cpc_dollars": micros_to_dollars(int(pe.get("first_page_cpc_micros", 0))),
                    "top_of_page_cpc_dollars": micros_to_dollars(int(pe.get("top_of_page_cpc_micros", 0))),
                    "tracking_url_template": cr.get("tracking_url_template"),
                    "final_url_suffix": cr.get("final_url_suffix"),
                    "url_custom_parameters": {
                        p["key"]: p["value"] for p in cr.get("url_custom_parameters", []) if "key" in p
                    } or None,
                    "ad_group_id": ag.get("id"),
                    "ad_group_name": ag.get("name"),
                    "campaign_id": c.get("id"),
                    "campaign_name": c.get("name"),
                    "impressions": int(m.get("impressions", 0)),
                    "clicks": int(m.get("clicks", 0)),
                    "cost_dollars": micros_to_dollars(int(m.get("cost_micros", 0))),
                    "conversions": float(m.get("conversions", 0)),
                }
            )

        report = save_report(results, "keywords")
        if report.get("error"):
            return report
        quality_scores = [r["quality_score"] for r in results if r["quality_score"]]
        match_types: dict[str, int] = {}
        for r in results:
            mt = r.get("match_type", "UNKNOWN")
            match_types[mt] = match_types.get(mt, 0) + 1
        report["summary"] = {
            "keyword_count": len(results),
            "avg_quality_score": round(sum(quality_scores) / len(quality_scores), 1) if quality_scores else None,
            "match_type_distribution": match_types,
        }
        return report

    @mcp.tool
    @handle_google_ads_errors
    def add_keywords(
        ad_group_id: Annotated[str, Field(description="Ad group ID to add keywords to")],
        keywords: Annotated[list[KeywordInput], Field(description="List of keywords with text and match_type")],
        confirm: Annotated[bool, Field(description="Must be true to execute.")] = False,
        customer_id: Annotated[
            str | None, Field(description="Google Ads customer ID (no dashes). Uses active account if not provided.")
        ] = None,
    ) -> dict:
        """Add one or more keywords to an ad group."""
        customer_id, cid_err = require_customer_id(customer_id)
        if cid_err:
            return cid_err
        if err := validate_id(ad_group_id, "ad_group_id"):
            return {"error": True, "message": err}
        client = get_client()
        ad_group_criterion_service = client.get_service("AdGroupCriterionService")
        ad_group_service = client.get_service("AdGroupService")

        match_map = {
            "EXACT": client.enums.KeywordMatchTypeEnum.EXACT,
            "PHRASE": client.enums.KeywordMatchTypeEnum.PHRASE,
            "BROAD": client.enums.KeywordMatchTypeEnum.BROAD,
        }

        operations = []
        for kw in keywords:
            operation = client.get_type("AdGroupCriterionOperation")
            criterion = operation.create
            criterion.ad_group = ad_group_service.ad_group_path(customer_id, ad_group_id)
            criterion.status = client.enums.AdGroupCriterionStatusEnum.ENABLED

            criterion.keyword.text = kw.text
            criterion.keyword.match_type = match_map.get(
                kw.match_type.upper(),
                client.enums.KeywordMatchTypeEnum.BROAD,
            )
            operations.append(operation)

        response = ad_group_criterion_service.mutate_ad_group_criteria(customer_id=customer_id, operations=operations, validate_only=not confirm)
        if not confirm:
            return {"warning": True, "validated": True, "message": f"Validation succeeded. This will add {len(keywords)} keyword(s). Set confirm=true to execute."}

        return {
            "added": len(response.results),
            "resource_names": [r.resource_name for r in response.results],
            "keywords": [{"text": kw.text, "match_type": kw.match_type} for kw in keywords],
        }

    @mcp.tool
    @handle_google_ads_errors
    def remove_keyword(
        ad_group_id: Annotated[str, Field(description="Ad group ID containing the keyword")],
        criterion_id: Annotated[str, Field(description="Keyword criterion ID to remove")],
        confirm: Annotated[bool, Field(description="Must be true to execute removal.")] = False,
        customer_id: Annotated[
            str | None, Field(description="Google Ads customer ID (no dashes). Uses active account if not provided.")
        ] = None,
    ) -> dict:
        """Remove a keyword from an ad group. Requires confirm=true."""
        customer_id, cid_err = require_customer_id(customer_id)
        if cid_err:
            return cid_err
        if err := validate_id(ad_group_id, "ad_group_id"):
            return {"error": True, "message": err}
        if err := validate_id(criterion_id, "criterion_id"):
            return {"error": True, "message": err}
        client = get_client()
        ad_group_criterion_service = client.get_service("AdGroupCriterionService")

        resource_name = ad_group_criterion_service.ad_group_criterion_path(customer_id, ad_group_id, criterion_id)
        operation = client.get_type("AdGroupCriterionOperation")
        operation.remove = resource_name

        response = ad_group_criterion_service.mutate_ad_group_criteria(
            customer_id=customer_id, operations=[operation], validate_only=not confirm
        )
        if not confirm:
            return {
                "warning": True,
                "validated": True,
                "criterion_id": criterion_id,
                "ad_group_id": ad_group_id,
                "message": f"Validation succeeded. This will remove keyword criterion {criterion_id} from ad group {ad_group_id}. "
                f"Set confirm=true to execute.",
            }
        return {"removed": response.results[0].resource_name}

    @mcp.tool
    @handle_google_ads_errors
    def update_keyword(
        criterion_id: Annotated[str, Field(description="Keyword criterion ID to update")],
        ad_group_id: Annotated[str, Field(description="Ad group ID containing the keyword")],
        cpc_bid: Annotated[float | None, Field(description="New CPC bid in dollars")] = None,
        final_url_suffix: Annotated[str | None, Field(description="New final URL suffix")] = None,
        confirm: Annotated[bool, Field(description="Must be true to execute.")] = False,
        customer_id: Annotated[
            str | None, Field(description="Google Ads customer ID (no dashes). Uses active account if not provided.")
        ] = None,
    ) -> dict:
        """Update a keyword's CPC bid or final URL suffix."""
        customer_id, cid_err = require_customer_id(customer_id)
        if cid_err:
            return cid_err
        if err := validate_id(ad_group_id, "ad_group_id"):
            return {"error": True, "message": err}
        if err := validate_id(criterion_id, "criterion_id"):
            return {"error": True, "message": err}
        client = get_client()
        ad_group_criterion_service = client.get_service("AdGroupCriterionService")

        operation = client.get_type("AdGroupCriterionOperation")
        criterion = operation.update
        criterion.resource_name = ad_group_criterion_service.ad_group_criterion_path(
            customer_id, ad_group_id, criterion_id
        )

        field_mask = []
        if cpc_bid is not None:
            if err := validate_cpc_bid(cpc_bid):
                return {"error": True, "message": err}
            criterion.cpc_bid_micros = dollars_to_micros(cpc_bid)
            field_mask.append("cpc_bid_micros")
        if final_url_suffix is not None:
            criterion.final_url_suffix = final_url_suffix
            field_mask.append("final_url_suffix")

        if not field_mask:
            return {"error": True, "message": "No fields to update"}

        operation.update_mask.paths.extend(field_mask)

        response = ad_group_criterion_service.mutate_ad_group_criteria(
            customer_id=customer_id, operations=[operation], validate_only=not confirm
        )
        if not confirm:
            return {"warning": True, "validated": True, "message": f"Validation succeeded. This will update keyword '{criterion_id}'. Set confirm=true to execute."}

        return {"resource_name": response.results[0].resource_name, "updated_fields": field_mask}

    @mcp.tool
    @handle_google_ads_errors
    def research_keywords(
        keywords: Annotated[list[str], Field(description="Seed keywords to research")],
        url: Annotated[str | None, Field(description="URL to extract keyword ideas from")] = None,
        language_id: Annotated[str, Field(description="Language criterion ID (1000=English)")] = "1000",
        geo_target_ids: Annotated[list[str] | None, Field(description="Geo target criterion IDs (2840=US)")] = None,
        customer_id: Annotated[
            str | None, Field(description="Google Ads customer ID (no dashes). Uses active account if not provided.")
        ] = None,
    ) -> dict:
        """Get keyword ideas with search volume, competition, and CPC estimates. Saves full report to CSV, returns summary + top rows + file path."""
        customer_id, cid_err = require_customer_id(customer_id)
        if cid_err:
            return cid_err
        if geo_target_ids is None:
            geo_target_ids = ["2840"]
        client = get_client()
        keyword_plan_idea_service = client.get_service("KeywordPlanIdeaService")
        keyword_plan_network = client.enums.KeywordPlanNetworkEnum.GOOGLE_SEARCH

        request = client.get_type("GenerateKeywordIdeasRequest")
        request.customer_id = customer_id
        request.language = f"languageConstants/{language_id}"
        request.keyword_plan_network = keyword_plan_network

        for geo_id in geo_target_ids:
            request.geo_target_constants.append(f"geoTargetConstants/{geo_id}")

        # Use the correct oneof seed field
        if url and keywords:
            request.keyword_and_url_seed.url = url
            request.keyword_and_url_seed.keywords.extend(keywords)
        elif url:
            request.url_seed.url = url
        elif keywords:
            request.keyword_seed.keywords.extend(keywords)

        response = keyword_plan_idea_service.generate_keyword_ideas(request=request)

        results = []
        for idea in response.results:
            metrics = idea.keyword_idea_metrics
            results.append(
                {
                    "keyword": idea.text,
                    "avg_monthly_searches": metrics.avg_monthly_searches if metrics else 0,
                    "competition": metrics.competition.name if metrics else "UNKNOWN",
                    "low_top_of_page_bid_dollars": micros_to_dollars(metrics.low_top_of_page_bid_micros or 0)
                    if metrics
                    else 0,
                    "high_top_of_page_bid_dollars": micros_to_dollars(metrics.high_top_of_page_bid_micros or 0)
                    if metrics
                    else 0,
                }
            )

        report = save_report(results, "keyword_research")
        if report.get("error"):
            return report
        searches = [r["avg_monthly_searches"] for r in results if r["avg_monthly_searches"]]
        cpcs = [r["high_top_of_page_bid_dollars"] for r in results if r["high_top_of_page_bid_dollars"]]
        report["summary"] = {
            "keyword_count": len(results),
            "avg_monthly_searches": round(sum(searches) / len(searches), 1) if searches else 0,
            "avg_cpc_dollars": round(sum(cpcs) / len(cpcs), 2) if cpcs else 0,
        }
        return report
