"""Sequential workflow execution."""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass, field

from aethr.artifacts import StepArtifacts, format_artifact_block, format_step_result_for_prompt
from aethr.config import WorkflowConfig, WorkflowStep
from aethr.agents import OpenCodeAgentClient
from aethr.context import collect_context
from aethr.llm import LLMError, ModelClient, UsageSummary
from aethr.prompts import step_prompt


@dataclass(frozen=True)
class StepResult:
    """In-memory result from one workflow step."""

    step_id: str
    content: str
    metadata: dict[str, str] = field(default_factory=dict)
    artifacts: StepArtifacts | None = None
    usage: UsageSummary | None = None


@dataclass(frozen=True)
class StepPrompt:
    """Exact prompt planned for one workflow step."""

    step_id: str
    prompt: str
    metadata: dict[str, str] = field(default_factory=dict)


class WorkflowStepError(Exception):
    """Raised when a step fails and a resumable checkpoint is available."""

    def __init__(self, step_id: str, completed_results: list[StepResult], cause: Exception) -> None:
        self.step_id = step_id
        self.completed_results = completed_results
        self.cause = cause
        super().__init__(f"Workflow failed at step '{step_id}': {cause}")


StepCallback = Callable[[StepResult], None]
StepChunkCallback = Callable[[str, str], None]
StepStartCallback = Callable[[int, int, StepPrompt], None]


def run_workflow(
    task: str,
    config: WorkflowConfig,
    previous_results: list[StepResult] | None = None,
    on_step_start: StepStartCallback | None = None,
    on_step_chunk: StepChunkCallback | None = None,
    on_step_result: StepCallback | None = None,
) -> list[StepResult]:
    """Run a configured workflow as a simple in-memory sequence."""

    results = list(previous_results or [])
    step_index = workflow_cursor(results, config)

    while step_index < len(config.steps):
        step = config.steps[step_index]
        planned = build_step_prompt(task, step, config, results)
        if on_step_start is not None:
            on_step_start(step_index + 1, len(config.steps), planned)

        try:
            result = run_step(
                task,
                step,
                config,
                results,
                planned=planned,
                on_chunk=on_step_chunk,
            )
        except LLMError as exc:
            raise WorkflowStepError(step.id, results, exc) from exc

        results.append(result)
        if on_step_result is not None:
            on_step_result(result)

        if step.repeat is not None:
            results = run_repeat_block(
                task,
                step_index,
                step,
                config,
                results,
                on_step_start=on_step_start,
                on_step_chunk=on_step_chunk,
                on_step_result=on_step_result,
            )

        step_index += 1

    return results


def build_workflow_prompts(task: str, config: WorkflowConfig, previous_results: list[StepResult] | None = None) -> list[StepPrompt]:
    """Build exact prompts for each step without calling models."""

    prompts: list[StepPrompt] = []
    history = list(previous_results or [])
    step_index = workflow_cursor(history, config)

    for step in config.steps[step_index:]:
        planned = build_step_prompt(task, step, config, history)
        prompts.append(planned)
        history.append(
            StepResult(
                step_id=step.id,
                content=f"[simulated previous output from {step.id}]",
                metadata=planned.metadata,
            )
        )
    return prompts


def run_step(
    task: str,
    step: WorkflowStep,
    config: WorkflowConfig,
    previous_results: list[StepResult],
    planned: StepPrompt | None = None,
    on_chunk: StepChunkCallback | None = None,
) -> StepResult:
    """Run one workflow step."""

    if planned is None:
        planned = build_step_prompt(task, step, config, previous_results)
    chunk_callback = (lambda chunk: on_chunk(step.id, chunk)) if on_chunk is not None else None
    if step.backend == "opencode":
        agent = OpenCodeAgentClient(
            config.models.get(step.role),
            unsafe_permissions=step.unsafe_permissions,
        )
        completion = agent.complete(planned.prompt, on_chunk=chunk_callback)
    else:
        model = ModelClient(config.models.get(step.role))
        completion = model.complete(planned.prompt, on_chunk=chunk_callback)
    return result_from_completion(step.id, planned.metadata, completion)


def build_step_prompt(
    task: str,
    step: WorkflowStep,
    config: WorkflowConfig,
    previous_results: list[StepResult],
) -> StepPrompt:
    """Build one step prompt and metadata."""

    model = ModelClient(config.models.get(step.role))
    backend = step.backend
    previous_context = format_previous_results(previous_results, step.history_visibility)
    implementation_artifact = latest_implementation_artifact_from_results(previous_results)
    explicit_context = collect_context(step.context, latest_diff=latest_diff_from_results(previous_results))
    loop_instruction = repeat_instruction(step)
    prompt = step_prompt(
        task=task,
        step=step,
        previous_context=previous_context,
        explicit_context=explicit_context,
        implementation_artifact=implementation_artifact or "[no implementation artifact]",
        role_description=config.roles.get(step.role, ""),
        loop_instruction=loop_instruction,
    )
    metadata = {
        "role": step.role,
        "model": model.requested_model or "mock",
        "backend": backend,
        "context_sources": str(len(step.context)),
        "history_visibility": step.history_visibility,
    }
    if step.backend == "opencode":
        metadata["permissions"] = "unsafe" if step.unsafe_permissions else "safe"
    return StepPrompt(step_id=step.id, prompt=prompt, metadata=metadata)


def repeat_instruction(step: WorkflowStep) -> str:
    """Render loop control instructions for a repeating step."""

    if step.repeat is None:
        return ""
    if step.repeat.until_review_pass:
        return (
            f"Repeat the workflow slice starting at `{step.repeat.back_to}` until this review has "
            "no findings of severity high or medium. "
            f"Stop after {step.repeat.max_iterations} total pass(es) through the repeated slice. "
            "If the loop is complete, end with the exact line `Review status: pass`. "
            "Otherwise end with the exact line `Review status: revise`."
        )
    return (
        f"Repeat the workflow slice starting at `{step.repeat.back_to}` until this step contains "
        f"`{step.repeat.until_contains}`. "
        f"Stop after {step.repeat.max_iterations} total pass(es) through the repeated slice. "
        "If the loop is complete, end with the exact line `Loop status: done`. "
        "Otherwise end with the exact line `Loop status: continue`."
    )


def format_previous_results(results: list[StepResult], visibility: str = "all") -> str:
    """Format prior in-memory step outputs for the next prompt."""

    if not results:
        return "No previous step output."

    if visibility == "none":
        return "No previous step output."
    if visibility == "latest":
        return format_step_result_for_prompt(results[-1].step_id, results[-1].content, results[-1].artifacts)
    if visibility == "summary":
        return summarize_previous_results(results)
    return "\n\n".join(
        format_step_result_for_prompt(result.step_id, result.content, result.artifacts)
        for result in results
    )


def summarize_previous_results(results: list[StepResult]) -> str:
    """Compress prior results into a compact history summary."""

    lines = ["--- history summary ---"]
    for index, result in enumerate(results, start=1):
        content = first_nonempty_line(result.content)
        if result.artifacts is not None and result.artifacts.changed_files:
            artifact_note = f" files={len(result.artifacts.changed_files)}"
        elif result.artifacts is not None and result.artifacts.git_diff.strip():
            artifact_note = " artifacts=diff"
        else:
            artifact_note = ""
        lines.append(f"{index}. {result.step_id}: {truncate_summary(content)}{artifact_note}")
    return "\n".join(lines)


def first_nonempty_line(content: str) -> str:
    """Return the first non-empty line of content."""

    for line in content.splitlines():
        if line.strip():
            return line.strip()
    return ""


def truncate_summary(text: str, limit: int = 140) -> str:
    """Trim summary text to a readable width."""

    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)].rstrip() + "…"


def latest_diff_from_results(results: list[StepResult]) -> str | None:
    """Return the latest implementation diff as explicit context."""

    for result in reversed(results):
        if result.artifacts is not None and result.artifacts.git_diff.strip():
            return format_artifact_block(result.artifacts)
    return None


def latest_implementation_artifact_from_results(results: list[StepResult]) -> str | None:
    """Return the newest implementation artifact as a dedicated prompt section."""

    preferred = [
        result
        for result in reversed(results)
        if result.metadata.get("role") == "implementer" and has_promptable_artifacts(result.artifacts)
    ]
    if preferred:
        return format_artifact_block(preferred[0].artifacts)

    for result in reversed(results):
        if has_promptable_artifacts(result.artifacts):
            return format_artifact_block(result.artifacts)
    return None


def has_promptable_artifacts(artifacts: StepArtifacts | None) -> bool:
    """Return whether artifacts include content useful for review."""

    if artifacts is None:
        return False
    return bool(artifacts.changed_files or artifacts.diff_stat.strip() or artifacts.git_diff.strip())


def validate_checkpoint(results: list[StepResult], config: WorkflowConfig) -> None:
    """Ensure a resume checkpoint matches the configured workflow prefix."""

    workflow_cursor(results, config)


def workflow_cursor(results: list[StepResult], config: WorkflowConfig) -> int:
    """Validate completed results and return the next workflow step index."""

    if not config.steps:
        return 0

    result_index = 0
    step_index = 0
    while result_index < len(results):
        if step_index >= len(config.steps):
            raise ValueError("resume checkpoint has more step results than the workflow defines")

        step = config.steps[step_index]
        result = results[result_index]
        if result.step_id != step.id:
            raise ValueError(
                f"resume checkpoint does not match workflow order at '{step.id}'"
            )

        result_index += 1
        if step.repeat is None:
            step_index += 1
            continue

        loop_status = result.metadata.get("loop_status")
        if loop_status in {"satisfied", "exhausted"}:
            step_index += 1
            continue
        if repeat_condition_met(result, step.repeat):
            step_index += 1
        else:
            step_index = step_index_of(config, step.repeat.back_to)

    return step_index


def run_repeat_block(
    task: str,
    controller_index: int,
    controller_step: WorkflowStep,
    config: WorkflowConfig,
    results: list[StepResult],
    on_step_start: StepStartCallback | None = None,
    on_step_chunk: StepChunkCallback | None = None,
    on_step_result: StepCallback | None = None,
) -> list[StepResult]:
    """Repeat a contiguous workflow slice until the controller condition is met."""

    repeat = controller_step.repeat
    if repeat is None:
        return results

    start_index = step_index_of(config, repeat.back_to)
    if start_index >= controller_index:
        raise ValueError(
            f"step '{controller_step.id}' repeats from '{repeat.back_to}', which must be earlier"
        )

    iterations = 1
    while not repeat_condition_met(results[-1], repeat):
        if iterations >= repeat.max_iterations:
            break

        for replay_index in range(start_index, controller_index + 1):
            replay_step = config.steps[replay_index]
            planned = build_step_prompt(task, replay_step, config, results)
            if on_step_start is not None:
                on_step_start(replay_index + 1, len(config.steps), planned)

            try:
                replay_result = run_step(
                    task,
                    replay_step,
                    config,
                    results,
                    planned=planned,
                    on_chunk=on_step_chunk,
                )
            except LLMError as exc:
                raise WorkflowStepError(replay_step.id, results, exc) from exc

            results.append(replay_result)
            if on_step_result is not None:
                on_step_result(replay_result)

        iterations += 1

    loop_status = "satisfied" if repeat_condition_met(results[-1], repeat) else "exhausted"
    results[-1] = annotate_loop_result(results[-1], repeat, iterations, loop_status)
    return results


def repeat_condition_met(result: StepResult, repeat: object) -> bool:
    """Check whether a controller step has satisfied its repeat condition."""

    if getattr(repeat, "until_review_pass", False):
        return review_status_from_result(result) == "pass"
    until_contains = getattr(repeat, "until_contains", "")
    return until_contains in result.content if until_contains else False


def annotate_loop_result(
    result: StepResult,
    repeat: object,
    iterations: int,
    loop_status: str,
) -> StepResult:
    """Attach loop outcome metadata to the controller result."""

    metadata = dict(result.metadata)
    metadata["loop_status"] = loop_status
    metadata["loop_iterations"] = str(iterations)
    metadata["loop_back_to"] = getattr(repeat, "back_to", "")
    metadata["loop_until"] = getattr(repeat, "until_contains", "") or (
        "review_pass" if getattr(repeat, "until_review_pass", False) else ""
    )
    metadata["loop_max_iterations"] = str(getattr(repeat, "max_iterations", 0))
    review_status = review_status_from_result(result)
    if review_status is not None:
        metadata["review_status"] = review_status
    return StepResult(
        step_id=result.step_id,
        content=result.content,
        metadata=metadata,
        artifacts=result.artifacts,
        usage=result.usage,
    )


def review_status_from_result(result: StepResult) -> str | None:
    """Extract the reviewer status marker from content or metadata."""

    if result.metadata.get("review_status") in {"pass", "revise"}:
        return result.metadata["review_status"]
    return review_status_from_content(result.content)


def review_status_from_content(content: str) -> str | None:
    """Parse the reviewer status line from step content."""

    for line in reversed(content.splitlines()):
        stripped = line.strip().lower()
        if stripped == "review status: pass":
            return "pass"
        if stripped == "review status: revise":
            return "revise"
    return None


def step_index_of(config: WorkflowConfig, step_id: str) -> int:
    """Return the index of a configured step."""

    for index, step in enumerate(config.steps):
        if step.id == step_id:
            return index
    raise ValueError(f"unknown step referenced in loop: {step_id}")


def serialize_checkpoint(results: list[StepResult]) -> str:
    """Serialize completed step results into a copyable JSON checkpoint."""

    return json.dumps([checkpoint_entry(result) for result in results], indent=2)


def load_checkpoint(raw: str) -> list[StepResult]:
    """Load step results from a JSON checkpoint string."""

    data = json.loads(raw)
    if isinstance(data, dict) and "results" in data:
        data = data["results"]
    if not isinstance(data, list):
        raise ValueError("resume checkpoint must be a JSON array of step results")

    results: list[StepResult] = []
    for item in data:
        if not isinstance(item, dict):
            raise ValueError("resume checkpoint entries must be JSON objects")
        step_id = item.get("step_id")
        content = item.get("content")
        if not isinstance(step_id, str) or not isinstance(content, str):
            raise ValueError("resume checkpoint entries require 'step_id' and 'content'")
        metadata = item.get("metadata") or {}
        if not isinstance(metadata, dict):
            metadata = {}
        artifacts_data = item.get("artifacts")
        artifacts = None
        if isinstance(artifacts_data, dict):
            changed_files = artifacts_data.get("changed_files") or []
            if not isinstance(changed_files, list):
                changed_files = []
            artifacts = StepArtifacts(
                changed_files=[str(value) for value in changed_files],
                diff_stat=str(artifacts_data.get("diff_stat", "") or ""),
                git_diff=str(artifacts_data.get("git_diff", "") or ""),
            )
        usage_data = item.get("usage")
        usage = None
        if isinstance(usage_data, dict):
            usage = UsageSummary(
                prompt_tokens=int(usage_data.get("prompt_tokens", 0) or 0),
                completion_tokens=int(usage_data.get("completion_tokens", 0) or 0),
                total_tokens=int(usage_data.get("total_tokens", 0) or 0),
                cost=float(usage_data.get("cost", 0.0) or 0.0),
            )
        results.append(
            StepResult(
                step_id=step_id,
                content=content,
                metadata={str(key): str(value) for key, value in metadata.items()},
                artifacts=artifacts,
                usage=usage,
            )
        )
    return results


def summarize_results(results: list[StepResult]) -> str:
    """Summarize step count, tokens, and cost for terminal output."""

    prompt_tokens = sum(result.usage.prompt_tokens for result in results if result.usage is not None)
    completion_tokens = sum(
        result.usage.completion_tokens for result in results if result.usage is not None
    )
    total_tokens = sum(result.usage.total_tokens for result in results if result.usage is not None)
    cost = sum(result.usage.cost for result in results if result.usage is not None)
    token_count = total_tokens or (prompt_tokens + completion_tokens)
    return f"{len(results)} steps, {format_token_count(token_count)}, ${cost:.2f}"


def format_token_count(total_tokens: int) -> str:
    """Format token counts with a compact human-readable suffix."""

    if total_tokens < 1_000:
        return f"{total_tokens} tokens"
    if total_tokens < 10_000:
        return f"{total_tokens / 1_000:.1f}k tokens"
    return f"{total_tokens / 1_000:.0f}k tokens"


def checkpoint_entry(result: StepResult) -> dict[str, object]:
    """Convert a step result into a JSON-serializable checkpoint entry."""

    entry: dict[str, object] = {
        "step_id": result.step_id,
        "content": result.content,
        "metadata": result.metadata,
    }
    if result.artifacts is not None:
        entry["artifacts"] = {
            "changed_files": result.artifacts.changed_files,
            "diff_stat": result.artifacts.diff_stat,
            "git_diff": result.artifacts.git_diff,
        }
    if result.usage is not None:
        entry["usage"] = {
            "prompt_tokens": result.usage.prompt_tokens,
            "completion_tokens": result.usage.completion_tokens,
            "total_tokens": result.usage.total_tokens,
            "cost": result.usage.cost,
        }
    return entry


def result_from_completion(step_id: str, metadata: dict[str, str], completion: object) -> StepResult:
    """Convert backend completion objects into workflow results."""

    content = getattr(completion, "content", "")
    usage = getattr(completion, "usage", None)
    artifacts = getattr(completion, "artifacts", None)
    return StepResult(
        step_id=step_id,
        content=content,
        metadata=metadata,
        artifacts=artifacts,
        usage=usage,
    )
