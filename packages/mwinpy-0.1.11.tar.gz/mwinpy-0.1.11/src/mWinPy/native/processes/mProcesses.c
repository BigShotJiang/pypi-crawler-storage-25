#include "mProcesses.h"
#include <stdlib.h>
#include <Psapi.h> //https://learn.microsoft.com/de-de/windows/win32/psapi/psapi-reference

DWORD *getAllProcessesIDs(DWORD *count) {
        if (!count) {
                return NULL;
        }

        DWORD capacity = (*count > 0) ? *count : 1024;
        DWORD *processes = NULL;

        for (;;) {
                DWORD *tmp = (DWORD *)realloc(processes, capacity * sizeof(DWORD));
                if (!tmp) {
                        free(processes);
                        return NULL;
                }
                processes = tmp;

                DWORD bytesNeeded = 0;
                if (!EnumProcesses(processes, capacity * sizeof(DWORD), &bytesNeeded)) {
                        free(processes);
                        return NULL;
                }

                if (bytesNeeded < capacity * sizeof(DWORD)) {
                        *count = bytesNeeded / sizeof(DWORD);
                        return processes;
                }

                if (capacity > (DWORD)(~0u) / 2) {
                        free(processes);
                        return NULL;
                }

                capacity *= 2;
        }

}