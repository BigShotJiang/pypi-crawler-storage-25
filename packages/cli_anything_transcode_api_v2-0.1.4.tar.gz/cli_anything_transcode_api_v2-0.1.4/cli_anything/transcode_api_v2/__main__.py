"""Allow python -m cli_anything.transcode_api_v2."""
from cli_anything.transcode_api_v2.transcode_api_v2_cli import cli

if __name__ == "__main__":
    cli()
