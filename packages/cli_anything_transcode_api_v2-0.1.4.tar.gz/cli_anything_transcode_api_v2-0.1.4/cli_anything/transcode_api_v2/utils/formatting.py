"""Output formatting helpers."""
from __future__ import annotations

import json
from typing import Any


# Task status codes
STATUS_LABELS = {
    0: "queued",
    1: "done",
    2: "failed",
    3: "sending",
    6: "processing",
}


def status_label(code: int | None) -> str:
    if code is None:
        return "?"
    return STATUS_LABELS.get(code, str(code))


def format_result(result: Any, as_json: bool = False) -> str:
    if as_json:
        return json.dumps(result, ensure_ascii=False)
    if isinstance(result, dict):
        lines = []
        for k, v in result.items():
            if k == "status" and isinstance(v, int):
                lines.append(f"  {k}: {v} ({status_label(v)})")
            else:
                lines.append(f"  {k}: {v}")
        return "\n".join(lines) or "{}"
    return str(result)


def format_error(msg: str, as_json: bool = False) -> str:
    if as_json:
        return json.dumps({"errno": -1, "errmsg": msg}, ensure_ascii=False)
    return f"ERR {msg}"


def format_task_table(tasks: list[dict]) -> str:
    if not tasks:
        return "(no tasks)"
    header = f"{'TID':<10}  {'STATUS':<12}  {'PROGRESS':<10}  {'SERVICE'}"
    sep = "-" * 60
    rows = [header, sep]
    for t in tasks:
        tid = t.get("tid", t.get("id", "?"))
        st = status_label(t.get("status"))
        prog = f"{t.get('progress', 0)}%"
        svc = t.get("service", "")
        rows.append(f"{str(tid):<10}  {st:<12}  {prog:<10}  {svc}")
    return "\n".join(rows)
