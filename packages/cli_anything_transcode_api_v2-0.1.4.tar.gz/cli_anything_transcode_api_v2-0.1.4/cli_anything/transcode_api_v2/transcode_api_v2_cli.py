# -*- coding: utf-8 -*-
"""cli-anything-transcode-api-v2 — Click CLI harness for transcode_api_v2.

Usage examples
--------------
One-shot:
    cli-anything-transcode-api-v2 task get 12345
    cli-anything-transcode-api-v2 --json task get 12345
    cli-anything-transcode-api-v2 media call VideoClip '{"sname":"ns","args":{}}'
    cli-anything-transcode-api-v2 monitor health

REPL mode (default with no subcommand):
    cli-anything-transcode-api-v2
    cli-anything-transcode-api-v2 --repl

Environment variables:
    TRANSCODE_API_BASE_URL   — server base URL
    TRANSCODE_API_SNAME      — default sname
    TRANSCODE_API_SECRET     — signing secret
    TRANSCODE_API_MOCK=1     — use mock responses (no live server needed)
"""
from __future__ import annotations

import json
import shlex
import sys
from typing import Any

import click

from cli_anything.transcode_api_v2.core.client import ApiClient, ApiError
from cli_anything.transcode_api_v2.core.session import Session
from cli_anything.transcode_api_v2.utils.formatting import (
    format_error,
    format_result,
    format_task_table,
    status_label,
)

pass_ctx_obj = click.make_pass_decorator(dict, ensure=True)

# ── Shared context helpers ────────────────────────────────────────────────────

def _client(ctx: click.Context) -> ApiClient:
    return ctx.obj["client"]

def _session(ctx: click.Context) -> Session:
    return ctx.obj["session"]

def _as_json(ctx: click.Context) -> bool:
    return ctx.obj.get("as_json", False)

BASE_URL_BUCKET = "https://beijing2.xstore.qihu.com/test2025ttl30"


def _extract_urls(result: dict) -> list[str]:
    """Extract output file URLs from a completed task result."""
    try:
        dargs = result.get("dargs", "")
        if isinstance(dargs, str):
            dargs = json.loads(dargs)
        dst_meta = dargs.get("dst_meta", "[]")
        if isinstance(dst_meta, str):
            dst_meta = json.loads(dst_meta)
        return [f"{BASE_URL_BUCKET}/{list(item.keys())[0]}" for item in dst_meta if item]
    except Exception:
        return []


def _emit(data: Any, ctx: click.Context, *, err: bool = False) -> None:
    if isinstance(data, dict) and data.get("status") == 1:
        urls = _extract_urls(data)
        if _as_json(ctx):
            out = dict(data)
            out["output_urls"] = urls
            click.echo(json.dumps(out, ensure_ascii=False), err=err)
        else:
            click.echo(format_result(data, False), err=err)
            if urls:
                click.echo("output:")
                for url in urls:
                    click.echo(f"  {url}")
    else:
        click.echo(format_result(data, _as_json(ctx)), err=err)


def _handle_error(exc: Exception, ctx: click.Context) -> None:
    click.echo(format_error(str(exc), _as_json(ctx)), err=True)
    sys.exit(1)


# ── Root group ────────────────────────────────────────────────────────────────

@click.group(invoke_without_command=True)
@click.version_option(package_name="cli-anything-transcode-api-v2")
@click.option("--base-url", envvar="TRANSCODE_API_BASE_URL", default="http://localhost",
              help="API base URL.")
@click.option("--sname", envvar="TRANSCODE_API_SNAME", default="default",
              help="Service namespace.")
@click.option("--ak", envvar="TRANSCODE_API_AK", default="",
              help="AccessKey (32-char hex).")
@click.option("--sk", envvar="TRANSCODE_API_SK", default="",
              help="SecretAccessKey.")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Emit machine-readable JSON output.")
@click.option("--repl", is_flag=True, default=False,
              help="Start interactive REPL session.")
@click.pass_context
def cli(ctx: click.Context, base_url: str, sname: str, ak: str, sk: str, as_json: bool, repl: bool) -> None:
    """cli-anything-transcode-api-v2: CLI for the transcode_api_v2 API.

    Wrap POST /intf.php calls for task management, media processing,
    template management, and monitoring.
    """
    ctx.ensure_object(dict)
    ctx.obj["client"] = ApiClient(base_url=base_url, sname=sname, ak=ak, sk=sk)
    ctx.obj["session"] = Session()
    ctx.obj["as_json"] = as_json

    if repl or ctx.invoked_subcommand is None:
        _run_repl(ctx)


# ── task group ────────────────────────────────────────────────────────────────

@cli.group("task")
@click.pass_context
def task_group(ctx: click.Context) -> None:
    """Manage VOD transcoding tasks (Main module)."""


@task_group.command("add")
@click.option("--service", required=True, help="Transcoding service type.")
@click.option("--args", "args_json", required=True, help="Task args as JSON string.")
@click.option("--bucket", default="", help="Output bucket name.")
@click.option("--weight", default="low", type=click.Choice(["low", "normal", "high"]), show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def task_add(ctx: click.Context, service: str, args_json: str, bucket: str, weight: str, save_as: str | None) -> None:
    """Submit a new transcoding task."""
    try:
        args = json.loads(args_json)
    except json.JSONDecodeError as e:
        _handle_error(ValueError(f"Invalid --args JSON: {e}"), ctx)
        return
    try:
        result = _client(ctx).task_add(service=service, args=args, bucket=bucket, weight=weight)
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@task_group.command("stop")
@click.argument("tid", type=int)
@click.pass_context
def task_stop(ctx: click.Context, tid: int) -> None:
    """Stop/cancel task TID."""
    try:
        result = _client(ctx).task_stop(tid)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@task_group.command("get")
@click.argument("tid", type=int)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def task_get(ctx: click.Context, tid: int, save_as: str | None) -> None:
    """Get task detail for TID."""
    try:
        result = _client(ctx).task_get(tid)
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@task_group.command("get-many")
@click.argument("tids", nargs=-1, type=int, required=True)
@click.pass_context
def task_get_many(ctx: click.Context, tids: tuple[int, ...]) -> None:
    """Get task details for multiple TIDs."""
    try:
        result = _client(ctx).task_get_many(list(tids))
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@task_group.command("wait")
@click.argument("tid", type=int)
@click.option("--timeout", default=300, show_default=True, help="Max wait seconds.")
@click.option("--interval", default=5, show_default=True, help="Poll interval seconds.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def task_wait(ctx: click.Context, tid: int, timeout: int, interval: int, save_as: str | None) -> None:
    """Poll task TID until done/failed or timeout."""
    import time
    client = _client(ctx)
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            result = client.task_get(tid)
        except ApiError as e:
            _handle_error(e, ctx)
            return
        status = result.get("status", 0)
        if not _as_json(ctx):
            click.echo(f"  tid={tid} status={status} ({status_label(status)}) progress={result.get('progress', 0)}%")
        if status in (1, 2):  # done or failed
            if save_as:
                _session(ctx).store(save_as, result)
            _emit(result, ctx)
            return
        time.sleep(interval)
    _handle_error(TimeoutError(f"Task {tid} did not finish within {timeout}s"), ctx)


# ── media group ───────────────────────────────────────────────────────────────

@cli.group("media")
@click.option("--service", default="", envvar="TRANSCODE_API_MEDIA_SERVICE", help="Media service name (required by server).")
@click.option("--bucket", default="", envvar="TRANSCODE_API_MEDIA_BUCKET", help="Output bucket name (oss_info.bucket_name).")
@click.option("--oss-host", default="", envvar="TRANSCODE_API_OSS_HOST", help="OSS host URL (oss_info.oss_host).")
@click.option("--oss-ak", default="", envvar="TRANSCODE_API_OSS_AK", help="OSS AccessKey (oss_info.ak).")
@click.option("--oss-sk", default="", envvar="TRANSCODE_API_OSS_SK", help="OSS SecretKey (oss_info.sk).")
@click.option("--oss-region", default="", envvar="TRANSCODE_API_OSS_REGION", help="OSS region (oss_info.region).")
@click.pass_context
def media_group(ctx: click.Context, service: str, bucket: str, oss_host: str, oss_ak: str, oss_sk: str, oss_region: str) -> None:
    """Media processing operations (Media module — AI/advanced)."""
    ctx.ensure_object(dict)
    ctx.obj["media_service"] = service
    ctx.obj["media_bucket"] = bucket
    if bucket or oss_host or oss_ak or oss_sk or oss_region:
        ctx.obj["media_oss_info"] = {
            "bucket_name": bucket,
            "oss_host": oss_host,
            "ak": oss_ak,
            "sk": oss_sk,
            "region": oss_region,
            "type": "aws",
        }
    else:
        ctx.obj["media_oss_info"] = None


MEDIA_ACTIONS = [
    "Snapshot", "AudioExtract", "VideoClip", "ConcatVideo", "PicToVideo",
    "WaterMark", "Subtitles", "AutoSubtitles", "ContentSummary", "VideoAddBgm",
    "PicToSpecialEffectsVideo", "VideoStretch", "AudioConcat", "VideoCutGif",
    "VideoCutByRatio", "VideoFade", "VideoAddMask", "ImageEnlargementToVideo",
    "MediaAdjustVolume", "VideoAddDub", "VideoMute", "AudioCutByTime",
    "VideoReverse", "VideoRotate", "ImageToVideo", "VideoAddAudio",
    "MediaSeparatiVoice", "VideoQualityAssessment", "AudioStretch", "AIRemoveWaterMark",
]


@media_group.command("actions")
@click.pass_context
def media_actions(ctx: click.Context) -> None:
    """List all available Media.* action names."""
    if _as_json(ctx):
        _emit(MEDIA_ACTIONS, ctx)
    else:
        for a in MEDIA_ACTIONS:
            click.echo(f"  Media.{a}")


@media_group.command("call")
@click.argument("action")
@click.argument("body_json", required=False, default="{}")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_call(ctx: click.Context, action: str, body_json: str, save_as: str | None) -> None:
    """Call Media.ACTION with BODY_JSON payload.

    Example:
        media call VideoClip '{"sname":"ns","args":{"video_url":"...","start":1,"end":10}}'
    """
    try:
        body = json.loads(body_json)
    except json.JSONDecodeError as e:
        _handle_error(ValueError(f"Invalid JSON body: {e}"), ctx)
        return
    try:
        result = _client(ctx).media_call(action, body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("stop")
@click.argument("tid", type=int)
@click.pass_context
def media_stop(ctx: click.Context, tid: int) -> None:
    """Stop a media processing task."""
    try:
        result = _client(ctx).media_stop(tid)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("get")
@click.argument("tid", type=int)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_get(ctx: click.Context, tid: int, save_as: str | None) -> None:
    """Get media task status by TID."""
    try:
        result = _client(ctx).media_get(tid)
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


# ── media action subcommands ──────────────────────────────────────────────────

@media_group.command("snapshot")
@click.option("--input", "input_url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--image-divided-count", type=int, default=0, show_default=True)
@click.option("--image-interval", type=int, default=0, show_default=True)
@click.option("--image-starttime", type=int, default=0, show_default=True)
@click.option("--image-endtime", type=int, default=0, show_default=True)
@click.option("--image-last-frame", type=int, default=0, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_snapshot(
    ctx: click.Context,
    input_url: str,
    output: str,
    image_divided_count: int,
    image_interval: int,
    image_starttime: int,
    image_endtime: int,
    image_last_frame: int,
    save_as: str | None,
) -> None:
    """Take snapshots / thumbnails from a video (Media.Snapshot)."""
    body = {"args": {
        "input": input_url,
        "output": output,
        "image_divided_count": image_divided_count,
        "image_interval": image_interval,
        "image_starttime": image_starttime,
        "image_endtime": image_endtime,
        "image_last_frame": image_last_frame,
    }}
    try:
        result = _client(ctx).media_call("Snapshot", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("audio-extract")
@click.option("--input", "input_url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", default="", show_default=True)
@click.option("--sample-rate", type=int, default=1600, show_default=True)
@click.option("--acodec", default="copy", show_default=True,
              type=click.Choice(["copy", "aac", "pcm", "mp3"]))
@click.option("--achannel", type=int, default=1, show_default=True)
@click.option("--abitrate", type=int, default=64, show_default=True)
@click.option("--filmtitle", type=int, default=0, show_default=True)
@click.option("--filmendpoint", type=int, default=0, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_audio_extract(
    ctx: click.Context,
    input_url: str,
    output: str,
    fmt: str,
    sample_rate: int,
    acodec: str,
    achannel: int,
    abitrate: int,
    filmtitle: int,
    filmendpoint: int,
    save_as: str | None,
) -> None:
    """Extract audio track from a video (Media.AudioExtract)."""
    body = {"args": {
        "input": input_url,
        "output": output,
        "format": fmt,
        "sample_rate": sample_rate,
        "acodec": acodec,
        "achannel": achannel,
        "abitrate": abitrate,
        "filmtitle": filmtitle,
        "filmendpoint": filmendpoint,
    }}
    try:
        result = _client(ctx).media_call("AudioExtract", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-clip")
@click.option("--input", "input_url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--filmtitle", type=int, default=0, show_default=True)
@click.option("--filmendpoint", type=int, default=0, show_default=True)
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_clip(
    ctx: click.Context,
    input_url: str,
    output: str,
    fmt: str,
    filmtitle: int,
    filmendpoint: int,
    width: int,
    height: int,
    save_as: str | None,
) -> None:
    """Clip a segment from a video (Media.VideoClip)."""
    body = {"args": {
        "input": input_url,
        "output": output,
        "format": fmt,
        "filmtitle": filmtitle,
        "filmendpoint": filmendpoint,
        "width": width,
        "height": height,
    }}
    try:
        result = _client(ctx).media_call("VideoClip", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("pic-to-video")
@click.option("--datasets", "datasets", multiple=True, required=True,
              help="Image URLs (repeat flag for multiple).")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--duration", type=int, default=10, show_default=True)
@click.option("--width", type=int, required=True)
@click.option("--height", type=int, required=True)
@click.option("--audio", default="", show_default=True)
@click.option("--vbitrate", type=int, default=2500, show_default=True)
@click.option("--abitrate", type=int, default=64, show_default=True)
@click.option("--fps", type=int, default=25, show_default=True)
@click.option("--crf", type=int, default=27, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_pic_to_video(
    ctx: click.Context,
    datasets: tuple[str, ...],
    output: str,
    fmt: str,
    duration: int,
    width: int,
    height: int,
    audio: str,
    vbitrate: int,
    abitrate: int,
    fps: int,
    crf: int,
    save_as: str | None,
) -> None:
    """Convert a sequence of images into a video (Media.PicToVideo)."""
    body = {"args": {
        "datasets": list(datasets),
        "output": output,
        "format": fmt,
        "duration": duration,
        "width": width,
        "height": height,
        "audio": audio,
        "vbitrate": vbitrate,
        "abitrate": abitrate,
        "fps": fps,
        "crf": crf,
    }}
    try:
        result = _client(ctx).media_call("PicToVideo", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("concat-video")
@click.option("--datasets", "datasets", multiple=True, required=True,
              help="Video URLs to concatenate (repeat flag for multiple).")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--vbitrate", type=int, default=2500, show_default=True)
@click.option("--abitrate", type=int, default=64, show_default=True)
@click.option("--fps", type=int, default=25, show_default=True)
@click.option("--crf", type=int, default=27, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_concat_video(
    ctx: click.Context,
    datasets: tuple[str, ...],
    output: str,
    fmt: str,
    width: int,
    height: int,
    vbitrate: int,
    abitrate: int,
    fps: int,
    crf: int,
    save_as: str | None,
) -> None:
    """Concatenate multiple videos into one (Media.ConcatVideo)."""
    body = {"args": {
        "datasets": list(datasets),
        "output": output,
        "format": fmt,
        "width": width,
        "height": height,
        "vbitrate": vbitrate,
        "abitrate": abitrate,
        "fps": fps,
        "crf": crf,
    }}
    try:
        result = _client(ctx).media_call("ConcatVideo", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("watermark")
@click.option("--input", "input_url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--watermark-url", default="", show_default=True,
              help="Watermark image URL.")
@click.option("--drawtext", default="", show_default=True, help="Text overlay string.")
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--vbitrate", type=int, default=2500, show_default=True)
@click.option("--fps", type=int, default=25, show_default=True)
@click.option("--crf", type=int, default=27, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_watermark(
    ctx: click.Context,
    input_url: str,
    output: str,
    fmt: str,
    watermark_url: str,
    drawtext: str,
    width: int,
    height: int,
    vbitrate: int,
    fps: int,
    crf: int,
    save_as: str | None,
) -> None:
    """Burn a watermark image or text overlay into a video (Media.WaterMark)."""
    watermark = {"url": watermark_url} if watermark_url else {}
    body = {"args": {
        "input": input_url,
        "output": output,
        "format": fmt,
        "watermark": watermark,
        "drawtext": drawtext,
        "width": width,
        "height": height,
        "vbitrate": vbitrate,
        "fps": fps,
        "crf": crf,
    }}
    try:
        result = _client(ctx).media_call("WaterMark", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("subtitles")
@click.option("--input", "input_url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--subfile", default="", show_default=True, help="Subtitle file URL.")
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_subtitles(
    ctx: click.Context,
    input_url: str,
    output: str,
    fmt: str,
    subfile: str,
    width: int,
    height: int,
    save_as: str | None,
) -> None:
    """Burn hardcoded subtitles into a video (Media.Subtitles)."""
    subtitles = {"url": subfile} if subfile else {}
    body = {"args": {
        "input": input_url,
        "output": output,
        "format": fmt,
        "subtitles": subtitles,
        "width": width,
        "height": height,
    }}
    try:
        result = _client(ctx).media_call("Subtitles", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("auto-subtitles")
@click.option("--input", "input_url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_auto_subtitles(
    ctx: click.Context,
    input_url: str,
    output: str,
    fmt: str,
    width: int,
    height: int,
    save_as: str | None,
) -> None:
    """Auto-generate and burn subtitles using speech recognition (Media.AutoSubtitles)."""
    body = {"args": {
        "input": input_url,
        "output": output,
        "format": fmt,
        "width": width,
        "height": height,
    }}
    try:
        result = _client(ctx).media_call("AutoSubtitles", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("content-summary")
@click.option("--input", "input_url", required=True, help="Input media URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--type", "summary_type", default="", show_default=True,
              help="Summary type identifier.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_content_summary(
    ctx: click.Context,
    input_url: str,
    output: str,
    summary_type: str,
    save_as: str | None,
) -> None:
    """Generate an AI content summary for a media file (Media.ContentSummary)."""
    body = {"args": {
        "input": input_url,
        "output": output,
        "type": summary_type,
    }}
    try:
        result = _client(ctx).media_call("ContentSummary", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-add-bgm")
@click.option("--input-video", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--audio", default="", show_default=True, help="Background music URL.")
@click.option("--volume", type=int, default=0, show_default=True)
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--vbitrate", type=int, default=2500, show_default=True)
@click.option("--fps", type=int, default=25, show_default=True)
@click.option("--crf", type=int, default=27, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_add_bgm(
    ctx: click.Context,
    input_video: str,
    output: str,
    fmt: str,
    audio: str,
    volume: int,
    width: int,
    height: int,
    vbitrate: int,
    fps: int,
    crf: int,
    save_as: str | None,
) -> None:
    """Add background music to a video (Media.VideoAddBgm)."""
    body = {"args": {
        "input_video": input_video,
        "output": output,
        "format": fmt,
        "audio": audio,
        "volume": volume,
        "width": width,
        "height": height,
        "vbitrate": vbitrate,
        "fps": fps,
        "crf": crf,
    }}
    try:
        result = _client(ctx).media_call("VideoAddBgm", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("pic-to-special-effects-video")
@click.option("--input-pic", required=True, help="Input image URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--audio", default="", show_default=True, help="Background audio URL.")
@click.option("--image-trans-type", type=int, default=1, show_default=True,
              help="Transition/effect type index.")
@click.option("--duration", type=int, default=10, show_default=True)
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_pic_to_special_effects_video(
    ctx: click.Context,
    input_pic: str,
    output: str,
    fmt: str,
    audio: str,
    image_trans_type: int,
    duration: int,
    width: int,
    height: int,
    save_as: str | None,
) -> None:
    """Convert an image to a special-effects video (Media.PicToSpecialEffectsVideo)."""
    body = {"args": {
        "input_pic": input_pic,
        "output": output,
        "format": fmt,
        "audio": audio,
        "image_trans_type": image_trans_type,
        "duration": duration,
        "width": width,
        "height": height,
    }}
    try:
        result = _client(ctx).media_call("PicToSpecialEffectsVideo", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-stretch")
@click.option("--input-video", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--speed-level", type=float, default=0.5, show_default=True,
              help="Playback speed multiplier (e.g. 0.5 = half speed, 2.0 = double).")
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_stretch(
    ctx: click.Context,
    input_video: str,
    output: str,
    fmt: str,
    speed_level: float,
    width: int,
    height: int,
    save_as: str | None,
) -> None:
    """Change video playback speed (slow/fast motion) (Media.VideoStretch)."""
    body = {"args": {
        "input_video": input_video,
        "output": output,
        "format": fmt,
        "speed_level": speed_level,
        "width": width,
        "height": height,
    }}
    try:
        result = _client(ctx).media_call("VideoStretch", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("audio-concat")
@click.option("--datasets", "datasets", multiple=True, required=True,
              help="Audio URLs to concatenate (repeat flag for multiple).")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--abitrate", type=int, default=64, show_default=True)
@click.option("--achannel", type=int, default=1, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_audio_concat(
    ctx: click.Context,
    datasets: tuple[str, ...],
    output: str,
    fmt: str,
    abitrate: int,
    achannel: int,
    save_as: str | None,
) -> None:
    """Concatenate multiple audio files (Media.AudioConcat)."""
    body = {"args": {
        "datasets": list(datasets),
        "output": output,
        "format": fmt,
        "abitrate": abitrate,
        "achannel": achannel,
    }}
    try:
        result = _client(ctx).media_call("AudioConcat", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-cut-gif")
@click.option("--input", "input_url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output GIF filename.")
@click.option("--fps", type=int, default=25, show_default=True)
@click.option("--gif-starttime", type=int, default=0, show_default=True,
              help="Start time in seconds.")
@click.option("--duration", type=int, default=0, show_default=True,
              help="Duration in seconds (0 = full).")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_cut_gif(
    ctx: click.Context,
    input_url: str,
    output: str,
    fps: int,
    gif_starttime: int,
    duration: int,
    save_as: str | None,
) -> None:
    """Convert a video segment to an animated GIF (Media.VideoCutGif)."""
    body = {"args": {
        "input": input_url,
        "output": output,
        "fps": fps,
        "gif_starttime": gif_starttime,
        "duration": duration,
    }}
    try:
        result = _client(ctx).media_call("VideoCutGif", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-cut-by-ratio")
@click.option("--input-video", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--format", "fmt", required=True)
@click.option("--cut-ratio-width", type=int, default=16, show_default=True,
              help="Target aspect ratio width component.")
@click.option("--cut-ratio-height", type=int, default=9, show_default=True,
              help="Target aspect ratio height component.")
@click.option("--width", type=int, default=0, show_default=True)
@click.option("--height", type=int, default=0, show_default=True)
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_cut_by_ratio(
    ctx: click.Context,
    input_video: str,
    output: str,
    fmt: str,
    cut_ratio_width: int,
    cut_ratio_height: int,
    width: int,
    height: int,
    save_as: str | None,
) -> None:
    """Crop a video to a target aspect ratio (Media.VideoCutByRatio)."""
    body = {"args": {
        "input_video": input_video,
        "output": output,
        "format": fmt,
        "cut_ratio_width": cut_ratio_width,
        "cut_ratio_height": cut_ratio_height,
        "width": width,
        "height": height,
    }}
    try:
        result = _client(ctx).media_call("VideoCutByRatio", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-fade")
@click.option("--first-video-url", required=True, help="First input video URL.")
@click.option("--second-video-url", required=True, help="Second input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--transition", default="vertclose", show_default=True,
              help="Transition effect name (e.g. vertclose, circleopen).")
@click.option("--fade-duration", type=int, default=2, show_default=True,
              help="Transition duration in seconds.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_fade(
    ctx: click.Context,
    first_video_url: str,
    second_video_url: str,
    output: str,
    transition: str,
    fade_duration: int,
    save_as: str | None,
) -> None:
    """Join two videos with a transition/fade effect (Media.VideoFade)."""
    body = {"args": {
        "first_video_url": first_video_url,
        "second_video_url": second_video_url,
        "output": output,
        "transition": transition,
        "fade_duration": fade_duration,
    }}
    try:
        result = _client(ctx).media_call("VideoFade", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-add-mask")
@click.option("--video-url", required=True, help="Input video URL.")
@click.option("--webm-url", required=True, help="WebM mask/overlay URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_add_mask(
    ctx: click.Context,
    video_url: str,
    webm_url: str,
    output: str,
    save_as: str | None,
) -> None:
    """Overlay a WebM mask/alpha layer onto a video (Media.VideoAddMask)."""
    body = {"args": {
        "video_url": video_url,
        "webm_url": webm_url,
        "output": output,
    }}
    try:
        result = _client(ctx).media_call("VideoAddMask", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("image-enlargement-to-video")
@click.option("--pic-url", required=True, help="Input image URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--duration", type=int, default=5, show_default=True,
              help="Video duration in seconds.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_image_enlargement_to_video(
    ctx: click.Context,
    pic_url: str,
    output: str,
    duration: int,
    save_as: str | None,
) -> None:
    """Animate a still image with a zoom/pan effect into a video (Media.ImageEnlargementToVideo)."""
    body = {"args": {
        "pic_url": pic_url,
        "output": output,
        "duration": duration,
    }}
    try:
        result = _client(ctx).media_call("ImageEnlargementToVideo", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("media-adjust-volume")
@click.option("--media-url", required=True, help="Input media URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--volume", type=float, default=1.0, show_default=True,
              help="Volume multiplier (1.0 = original, 2.0 = double).")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_adjust_volume(
    ctx: click.Context,
    media_url: str,
    output: str,
    volume: float,
    save_as: str | None,
) -> None:
    """Adjust the volume of an audio or video file (Media.MediaAdjustVolume)."""
    body = {"args": {
        "media_url": media_url,
        "output": output,
        "volume": volume,
    }}
    try:
        result = _client(ctx).media_call("MediaAdjustVolume", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-add-dub")
@click.option("--video-url", required=True, help="Input video URL.")
@click.option("--audio-url", required=True, help="Dubbing audio URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--mix-by-audio", default="", show_default=True,
              help="Optional secondary mix audio URL.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_add_dub(
    ctx: click.Context,
    video_url: str,
    audio_url: str,
    output: str,
    mix_by_audio: str,
    save_as: str | None,
) -> None:
    """Replace or mix a video's audio track with a dubbing file (Media.VideoAddDub)."""
    body = {"args": {
        "video_url": video_url,
        "audio_url": audio_url,
        "output": output,
        "mix_by_audio": mix_by_audio,
    }}
    try:
        result = _client(ctx).media_call("VideoAddDub", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-mute")
@click.option("--video-url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_mute(
    ctx: click.Context,
    video_url: str,
    output: str,
    save_as: str | None,
) -> None:
    """Remove audio from a video (mute) (Media.VideoMute)."""
    body = {"args": {
        "video_url": video_url,
        "output": output,
    }}
    try:
        result = _client(ctx).media_call("VideoMute", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("audio-cut-by-time")
@click.option("--input", "input_url", required=True, help="Input audio URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--filmtitle", type=int, default=0, show_default=True,
              help="Start time in seconds.")
@click.option("--filmendpoint", type=int, default=0, show_default=True,
              help="End time in seconds.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_audio_cut_by_time(
    ctx: click.Context,
    input_url: str,
    output: str,
    filmtitle: int,
    filmendpoint: int,
    save_as: str | None,
) -> None:
    """Cut an audio file to a time range (Media.AudioCutByTime)."""
    body = {"args": {
        "input": input_url,
        "output": output,
        "filmtitle": filmtitle,
        "filmendpoint": filmendpoint,
    }}
    try:
        result = _client(ctx).media_call("AudioCutByTime", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-reverse")
@click.option("--video-url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_reverse(
    ctx: click.Context,
    video_url: str,
    output: str,
    save_as: str | None,
) -> None:
    """Reverse a video (play backwards) (Media.VideoReverse)."""
    body = {"args": {
        "video_url": video_url,
        "output": output,
    }}
    try:
        result = _client(ctx).media_call("VideoReverse", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-rotate")
@click.option("--video-url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--flip", required=True,
              type=click.Choice(["ccw", "cw", "hflip", "vflip"]),
              help="Rotation/flip direction.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_rotate(
    ctx: click.Context,
    video_url: str,
    output: str,
    flip: str,
    save_as: str | None,
) -> None:
    """Rotate or flip a video (Media.VideoRotate)."""
    body = {"args": {
        "video_url": video_url,
        "output": output,
        "flip": flip,
    }}
    try:
        result = _client(ctx).media_call("VideoRotate", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("image-to-video")
@click.option("--pic-url", required=True, help="Input image URL.")
@click.option("--audio-url", required=True, help="Audio track URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--zoompan-view", type=int, default=0, show_default=True,
              help="Ken Burns zoom/pan style index.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_image_to_video(
    ctx: click.Context,
    pic_url: str,
    audio_url: str,
    output: str,
    zoompan_view: int,
    save_as: str | None,
) -> None:
    """Combine a still image and an audio track into a video (Media.ImageToVideo)."""
    body = {"args": {
        "pic_url": pic_url,
        "audio_url": audio_url,
        "output": output,
        "zoompan_view": zoompan_view,
    }}
    try:
        result = _client(ctx).media_call("ImageToVideo", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-add-audio")
@click.option("--video-url", required=True, help="Input video URL.")
@click.option("--audio-url", required=True, help="Audio track URL to mix in.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--audio-adapt", is_flag=True, default=False,
              help="Loop/trim audio to match video duration automatically.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_add_audio(
    ctx: click.Context,
    video_url: str,
    audio_url: str,
    output: str,
    audio_adapt: bool,
    save_as: str | None,
) -> None:
    """Mix an audio track into a video (Media.VideoAddAudio)."""
    body = {"args": {
        "video_url": video_url,
        "audio_url": audio_url,
        "output": output,
        "audio_adapt": audio_adapt,
    }}
    try:
        result = _client(ctx).media_call("VideoAddAudio", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("media-separati-voice")
@click.option("--media-url", required=True, help="Input media URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--is-vocals", is_flag=True, default=True,
              help="Output the vocals track (True) or the instrumental track (False).")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_separati_voice(
    ctx: click.Context,
    media_url: str,
    output: str,
    is_vocals: bool,
    save_as: str | None,
) -> None:
    """Separate vocals from background music in a media file (Media.MediaSeparatiVoice)."""
    body = {"args": {
        "media_url": media_url,
        "output": output,
        "is_vocals": is_vocals,
    }}
    try:
        result = _client(ctx).media_call("MediaSeparatiVoice", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("video-quality-assessment")
@click.option("--media-url", required=True, help="Input media URL to assess.")
@click.option("--bash-url", required=True, help="Baseline/reference media URL.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_video_quality_assessment(
    ctx: click.Context,
    media_url: str,
    bash_url: str,
    save_as: str | None,
) -> None:
    """Compute a video quality score against a reference (Media.VideoQualityAssessment)."""
    body = {"args": {
        "media_url": media_url,
        "bash_url": bash_url,
    }}
    try:
        result = _client(ctx).media_call("VideoQualityAssessment", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("audio-stretch")
@click.option("--audio-url", required=True, help="Input audio URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--speed-level", type=float, required=True,
              help="Playback speed multiplier (e.g. 0.5 = half speed, 2.0 = double).")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_audio_stretch(
    ctx: click.Context,
    audio_url: str,
    output: str,
    speed_level: float,
    save_as: str | None,
) -> None:
    """Change audio playback speed without pitch shift (Media.AudioStretch)."""
    body = {"args": {
        "audio_url": audio_url,
        "output": output,
        "speed_level": speed_level,
    }}
    try:
        result = _client(ctx).media_call("AudioStretch", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@media_group.command("ai-remove-watermark")
@click.option("--video-url", required=True, help="Input video URL.")
@click.option("--output", required=True, help="Output filename.")
@click.option("--detect-type", default="keyword", show_default=True,
              help="Detection method: 'keyword' or 'area'.")
@click.option("--keyword", default="", show_default=True,
              help="Keyword string used for watermark detection.")
@click.option("--detect-area", default="", show_default=True,
              help="Pixel region to scan, e.g. '0,0,100,50'.")
@click.option("--save-as", default=None, metavar="ALIAS")
@click.pass_context
def media_ai_remove_watermark(
    ctx: click.Context,
    video_url: str,
    output: str,
    detect_type: str,
    keyword: str,
    detect_area: str,
    save_as: str | None,
) -> None:
    """AI-powered watermark removal from a video (Media.AIRemoveWaterMark)."""
    body = {"args": {
        "video_url": video_url,
        "output": output,
        "detect_type": detect_type,
        "keyword": keyword,
        "detect_area": detect_area,
    }}
    try:
        result = _client(ctx).media_call("AIRemoveWaterMark", body, service=ctx.obj.get("media_service", ""), bucket=ctx.obj.get("media_bucket", ""), oss_info=ctx.obj.get("media_oss_info"))
        if save_as:
            _session(ctx).store(save_as, result)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


# ── template group ────────────────────────────────────────────────────────────

@cli.group("template")
@click.pass_context
def template_group(ctx: click.Context) -> None:
    """Manage reusable transcoding templates (Template module)."""


@template_group.command("list")
@click.option("--eqid", required=True, help="Main account ID.")
@click.option("--page", default=1, type=int, show_default=True)
@click.option("--rows", default=10, type=int, show_default=True)
@click.pass_context
def template_list(ctx: click.Context, eqid: str, page: int, rows: int) -> None:
    """List templates for account EQID."""
    try:
        result = _client(ctx).template_list(eqid=eqid, page=page, rows=rows)
        if _as_json(ctx):
            _emit(result, ctx)
        else:
            items = result.get("list", [result] if isinstance(result, list) else [])
            click.echo(f"Total: {result.get('total_count', '?')}  Page {result.get('current_page', page)}/{result.get('total_page', '?')}")
            for t in items:
                click.echo(f"  id={t.get('id')}  name={t.get('name')}  type={t.get('type')}")
    except ApiError as e:
        _handle_error(e, ctx)


@template_group.command("get")
@click.option("--eqid", required=True)
@click.argument("template_id", type=int)
@click.pass_context
def template_get(ctx: click.Context, eqid: str, template_id: int) -> None:
    """Get template details."""
    try:
        result = _client(ctx).template_get(eqid=eqid, template_id=template_id)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@template_group.command("add")
@click.option("--eqid", required=True)
@click.option("--uqid", required=True)
@click.option("--name", required=True)
@click.option("--args", "args_json", required=True, help="Template args as JSON.")
@click.option("--des", default="")
@click.pass_context
def template_add(ctx: click.Context, eqid: str, uqid: str, name: str, args_json: str, des: str) -> None:
    """Create a new template."""
    try:
        args = json.loads(args_json)
    except json.JSONDecodeError as e:
        _handle_error(ValueError(f"Invalid --args JSON: {e}"), ctx)
        return
    try:
        result = _client(ctx).template_add(uqid=uqid, eqid=eqid, name=name, args=args, des=des)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@template_group.command("delete")
@click.option("--eqid", required=True)
@click.argument("template_id", type=int)
@click.pass_context
def template_delete(ctx: click.Context, eqid: str, template_id: int) -> None:
    """Delete a template by ID."""
    try:
        result = _client(ctx).template_delete(eqid=eqid, template_id=template_id)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


# ── template-task group ───────────────────────────────────────────────────────

@cli.group("template-task")
@click.pass_context
def template_task_group(ctx: click.Context) -> None:
    """Manage tasks created from templates (TemplateTask module)."""


@template_task_group.command("list")
@click.option("--eqid", required=True)
@click.option("--task-type", default=1, type=int, show_default=True)
@click.option("--page", default=1, type=int, show_default=True)
@click.option("--rows", default=10, type=int, show_default=True)
@click.pass_context
def template_task_list(ctx: click.Context, eqid: str, task_type: int, page: int, rows: int) -> None:
    """List template-based tasks."""
    try:
        result = _client(ctx).template_task_list(eqid=eqid, task_type=task_type, page=page, rows=rows)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@template_task_group.command("get")
@click.option("--eqid", required=True)
@click.argument("task_id", type=int)
@click.pass_context
def template_task_get(ctx: click.Context, eqid: str, task_id: int) -> None:
    """Get template task details."""
    try:
        result = _client(ctx).template_task_get(eqid=eqid, task_id=task_id)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@template_task_group.command("presign")
@click.argument("filename")
@click.pass_context
def template_task_presign(ctx: click.Context, filename: str) -> None:
    """Get a presigned S3 upload URL for FILENAME."""
    try:
        result = _client(ctx).template_task_presign(filename=filename)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@template_task_group.command("download-url")
@click.argument("filename")
@click.pass_context
def template_task_download(ctx: click.Context, filename: str) -> None:
    """Get a presigned S3 download URL for FILENAME."""
    try:
        result = _client(ctx).template_task_download_url(filename=filename)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


# ── live group ────────────────────────────────────────────────────────────────

@cli.group("live")
@click.pass_context
def live_group(ctx: click.Context) -> None:
    """Manage live-stream transcoding tasks (LiveStreamTask module)."""


@live_group.command("list")
@click.pass_context
def live_list(ctx: click.Context) -> None:
    """List active live-stream tasks."""
    try:
        result = _client(ctx).live_task_list()
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@live_group.command("get")
@click.argument("tid")
@click.pass_context
def live_get(ctx: click.Context, tid: str) -> None:
    """Get live task detail for TID (format: sn|cid)."""
    try:
        result = _client(ctx).live_task_get(tid=tid)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


@live_group.command("stop")
@click.option("--cid", required=True)
@click.option("--tid", required=True)
@click.pass_context
def live_stop(ctx: click.Context, cid: str, tid: str) -> None:
    """Stop a live-stream task."""
    try:
        result = _client(ctx).live_task_stop(cid=cid, tid=tid)
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


# ── monitor group ─────────────────────────────────────────────────────────────

@cli.group("monitor")
@click.pass_context
def monitor_group(ctx: click.Context) -> None:
    """Health and monitoring commands (MonitorApi module)."""


@monitor_group.command("health")
@click.pass_context
def monitor_health(ctx: click.Context) -> None:
    """Check API server health (no auth required)."""
    try:
        result = _client(ctx).health()
        _emit(result, ctx)
    except ApiError as e:
        _handle_error(e, ctx)


# ── session group ─────────────────────────────────────────────────────────────

@cli.group("session")
@click.pass_context
def session_group(ctx: click.Context) -> None:
    """Inspect or clear the in-memory session store."""


@session_group.command("list")
@click.pass_context
def session_list(ctx: click.Context) -> None:
    """List stored result aliases."""
    sess = _session(ctx)
    if _as_json(ctx):
        click.echo(json.dumps({"aliases": sess.list_aliases()}))
    else:
        click.echo(sess.summary())


@session_group.command("get")
@click.argument("alias")
@click.pass_context
def session_get(ctx: click.Context, alias: str) -> None:
    """Print stored result for ALIAS."""
    try:
        result = _session(ctx).get(alias)
        _emit(result, ctx)
    except KeyError as e:
        click.echo(format_error(str(e), _as_json(ctx)), err=True)
        sys.exit(1)


@session_group.command("clear")
@click.pass_context
def session_clear(ctx: click.Context) -> None:
    """Clear all stored results."""
    _session(ctx).clear()
    click.echo("Session cleared.")


# ── REPL ──────────────────────────────────────────────────────────────────────

def _run_repl(root_ctx: click.Context) -> None:
    """Interactive REPL."""
    click.echo("transcode-api-v2 REPL — type 'help' or 'exit'.")
    sess = root_ctx.obj["session"]
    as_json = root_ctx.obj["as_json"]

    while True:
        try:
            line = click.prompt("transcode-api-v2", prompt_suffix="> ", default="", show_default=False)
        except (EOFError, KeyboardInterrupt):
            click.echo("\nBye.")
            break

        line = line.strip()
        if not line:
            continue
        if line in ("exit", "quit", "q"):
            click.echo("Bye.")
            break
        if line in ("help", "?"):
            click.echo(cli.get_help(click.Context(cli)))
            continue

        try:
            args = shlex.split(line)
        except ValueError as e:
            click.echo(f"Parse error: {e}", err=True)
            continue

        try:
            ctx = cli.make_context("transcode-api-v2", args, obj=root_ctx.obj)
            cli.invoke(ctx)
        except SystemExit:
            pass
        except click.ClickException as e:
            e.show()
        except Exception as e:
            click.echo(f"Error: {e}", err=True)


if __name__ == "__main__":
    cli()
