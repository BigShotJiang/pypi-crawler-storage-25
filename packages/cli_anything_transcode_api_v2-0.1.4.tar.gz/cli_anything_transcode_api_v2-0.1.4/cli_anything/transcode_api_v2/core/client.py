"""HTTP API client for transcode_api_v2.

All calls go to POST /intf.php?method=Module.Action.

Configuration via environment or constructor:
  TRANSCODE_API_BASE_URL  — server base URL (e.g. http://host:8080)
  TRANSCODE_API_SNAME     — default sname (service namespace)
  TRANSCODE_API_AK        — AccessKey (32-char hex string)
  TRANSCODE_API_SK        — SecretAccessKey

Auth notes
----------
This client supports three auth modes selected by ``auth_mode``:
  "none"     — no Authorization header (MonitorApi)
  "standard" — HMAC-SHA1:
                 auth_string = AK + "\\n" + auth_time + "\\n" + rand_num
                 Authorization = AK + ":" + base64(HMAC-SHA1(auth_string, SK))
                 + Auth-Time / Rand-Num headers
  "media"    — Authorization = md5(json_body + Auth-Time + Rand-Num + API_INNER_SIGN_TOKEN)
  "inner"    — md5(sorted_GET_params + INNER_SIGN_TOKEN), no extra headers

For development/testing without a live server, set TRANSCODE_API_MOCK=1 and the
client will return canned success responses instead of making HTTP calls.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import random
import time
from typing import Any

import requests


class ApiError(Exception):
    """Raised when the API returns errno != 0 or an HTTP error."""

    def __init__(self, errno: int, errmsg: str, raw: dict | None = None):
        super().__init__(f"[{errno}] {errmsg}")
        self.errno = errno
        self.errmsg = errmsg
        self.raw = raw or {}


def _md5(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()


def _hmac_sha1_b64(key: str, message: str) -> str:
    """Return base64-encoded HMAC-SHA1(message, key)."""
    sig = hmac.new(key.encode(), message.encode(), hashlib.sha1).digest()
    return base64.b64encode(sig).decode()


class ApiClient:
    """Thin wrapper around the transcode_api_v2 /intf.php HTTP API."""

    DEFAULT_TIMEOUT = 30

    def __init__(
        self,
        base_url: str | None = None,
        sname: str | None = None,
        ak: str | None = None,
        sk: str | None = None,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self.base_url = (base_url or os.environ.get("TRANSCODE_API_BASE_URL", "http://localhost")).rstrip("/")
        self.sname = sname or os.environ.get("TRANSCODE_API_SNAME", "default")
        self.ak = ak or os.environ.get("TRANSCODE_API_AK", "")
        self.sk = sk or os.environ.get("TRANSCODE_API_SK", "")
        self.timeout = timeout
        self._mock = os.environ.get("TRANSCODE_API_MOCK", "").strip() == "1"

    # ── Core request machinery ────────────────────────────────────────────────

    def _standard_auth_headers(self, auth_time: str, rand_num: str) -> dict[str, str]:
        """Build Authorization / Auth-Time / Rand-Num headers (HMAC-SHA1)."""
        auth_string = self.ak + "\n" + auth_time + "\n" + rand_num
        encrypt = _hmac_sha1_b64(self.sk, auth_string)
        return {
            "Authorization": f"{self.ak}:{encrypt}",
            "Auth-Time": auth_time,
            "Rand-Num": rand_num,
        }

    def _call(
        self,
        method: str,
        get_params: dict[str, Any] | None = None,
        post_params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        auth_mode: str = "standard",
    ) -> dict[str, Any]:
        """Send a request to /intf.php?method=<method>.

        Returns the ``data`` field of the response on success.
        Raises ApiError on errno != 0.
        """
        if self._mock:
            return self._mock_response(method)

        r = str(int(time.time()))
        rand_num = str(random.randint(0, 2**31))
        qs: dict[str, str] = {"method": method, "r": r}
        if get_params:
            qs.update({k: str(v) for k, v in get_params.items()})

        headers: dict[str, str] = {}
        _raw_body: bytes | None = None
        if auth_mode == "standard":
            headers.update(self._standard_auth_headers(r, rand_num))
        elif auth_mode == "media":
            body_str = json.dumps(json_body or {}, ensure_ascii=False, separators=(",", ":"))
            _raw_body = body_str.encode("utf-8")
            media_token = os.environ.get("TRANSCODE_API_MEDIA_TOKEN", "4321e921ea66f3515e445ffc1f793a6f")
            headers["Authorization"] = _md5(body_str + r + rand_num + media_token)
            headers["Auth-Time"] = r
            headers["Rand-Num"] = rand_num
            headers["Content-Type"] = "application/json"
        # auth_mode == "none" → no headers

        url = f"{self.base_url}/intf.php"
        try:
            if _raw_body is not None:
                resp = requests.post(url, params=qs, data=_raw_body, headers=headers, timeout=self.timeout)
            elif json_body is not None:
                headers["Content-Type"] = "application/json"
                resp = requests.post(url, params=qs, json=json_body, headers=headers, timeout=self.timeout)
            elif post_params:
                resp = requests.post(url, params=qs, data=post_params, headers=headers, timeout=self.timeout)
            else:
                resp = requests.get(url, params=qs, headers=headers, timeout=self.timeout)
        except requests.exceptions.RequestException as exc:
            raise ApiError(-1, f"HTTP error: {exc}")

        try:
            data = resp.json()
        except ValueError:
            raise ApiError(-1, f"Non-JSON response: {resp.text[:200]}")

        errno = data.get("errno", 0)
        if errno != 0:
            raise ApiError(errno, data.get("errmsg", "unknown error"), data)

        return data.get("data", data)

    def _mock_response(self, method: str) -> dict[str, Any]:
        """Return a canned success response for testing without a live server."""
        if "getDetail" in method or "getById" in method:
            return {"tid": 1, "status": 1, "progress": 100, "errno": 0}
        if "getList" in method:
            return {"list": [], "total_count": 0, "current_page": 1, "total_page": 1}
        if "Health" in method:
            return {"status": "ok"}
        return {"tid": 42}

    # ── Main module ───────────────────────────────────────────────────────────

    def task_add(self, service: str, args: dict, bucket: str = "", weight: str = "low") -> dict:
        """Submit a transcoding task. Returns {"tid": <int>}."""
        import base64
        encoded_args = base64.b64encode(json.dumps(args, ensure_ascii=False).encode()).decode()
        return self._call(
            "Main.add",
            get_params={"sname": self.sname},
            post_params={"service": service, "bucket": bucket, "args": encoded_args, "weight": weight},
        )

    def task_stop(self, tid: int) -> dict:
        """Stop/cancel a transcoding task."""
        return self._call("Main.stop", get_params={"sname": self.sname}, post_params={"tid": str(tid)})

    def task_get(self, tid: int) -> dict:
        """Get task detail by TID."""
        return self._call("Main.getDetailByTid", get_params={"sname": self.sname}, post_params={"tid": str(tid)})

    def task_get_many(self, tids: list[int]) -> dict:
        """Get task details for multiple TIDs (comma-separated)."""
        return self._call("Main.getDetailByTids", get_params={"sname": self.sname}, post_params={"tid": ",".join(str(t) for t in tids)})

    # ── Media module (AI/advanced operations) ────────────────────────────────

    def media_call(self, action: str, body: dict, service: str = "", bucket: str = "", oss_info: dict | None = None) -> dict:
        """Call a Media.* method with a JSON body."""
        body.setdefault("sname", self.sname)
        if service:
            body["service"] = service
        if bucket:
            body["bucket"] = bucket
        if oss_info:
            body["oss_info"] = oss_info
        return self._call(f"Media.{action}", get_params={"sname": self.sname}, json_body=body, auth_mode="media")

    def media_stop(self, tid: int) -> dict:
        return self.media_call("stop", {"tid": tid})

    def media_get(self, tid: int) -> dict:
        return self.media_call("getDetailByTid", {"tid": tid})

    def media_get_many(self, tids: list[int]) -> dict:
        return self.media_call("getDetailByTids", {"tid": tids[0] if len(tids) == 1 else tids})

    # ── Template module ───────────────────────────────────────────────────────

    def template_list(self, eqid: str, page: int = 1, rows: int = 10) -> dict:
        return self._call(
            "Template.getList",
            post_params={"eqid": eqid, "page": str(page), "row": str(rows)},
            auth_mode="standard",
        )

    def template_get(self, eqid: str, template_id: int) -> dict:
        return self._call(
            "Template.getById",
            post_params={"eqid": eqid, "template_id": str(template_id)},
            auth_mode="standard",
        )

    def template_add(self, uqid: str, eqid: str, name: str, args: dict, template_type: int = 1, des: str = "") -> dict:
        import base64
        encoded = base64.b64encode(json.dumps(args, ensure_ascii=False).encode()).decode()
        return self._call(
            "Template.add",
            post_params={"uqid": uqid, "eqid": eqid, "name": name, "args": encoded, "type": str(template_type), "des": des},
            auth_mode="standard",
        )

    def template_delete(self, eqid: str, template_id: int) -> dict:
        return self._call(
            "Template.delById",
            post_params={"eqid": eqid, "template_id": str(template_id)},
            auth_mode="standard",
        )

    # ── TemplateTask module ───────────────────────────────────────────────────

    def template_task_list(self, eqid: str, task_type: int = 1, page: int = 1, rows: int = 10) -> dict:
        return self._call(
            "TemplateTask.getList",
            post_params={"eqid": eqid, "task_type": str(task_type), "page": str(page), "row": str(rows)},
            auth_mode="standard",
        )

    def template_task_get(self, eqid: str, task_id: int) -> dict:
        return self._call(
            "TemplateTask.getById",
            post_params={"eqid": eqid, "id": str(task_id)},
            auth_mode="standard",
        )

    def template_task_presign(self, filename: str) -> dict:
        return self._call(
            "TemplateTask.getPreSignUrl",
            post_params={"sname": self.sname, "filename": filename},
            auth_mode="standard",
        )

    def template_task_download_url(self, filename: str) -> dict:
        return self._call(
            "TemplateTask.getDownloadUrl",
            post_params={"sname": self.sname, "filename": filename},
            auth_mode="standard",
        )

    # ── Monitor module ────────────────────────────────────────────────────────

    def health(self) -> dict:
        return self._call("MonitorApi.getHealth", auth_mode="none")

    # ── LiveStreamTask module ─────────────────────────────────────────────────

    def live_task_list(self) -> dict:
        return self._call("LiveStreamTask.getTaskList", auth_mode="standard")

    def live_task_get(self, tid: str) -> dict:
        return self._call("LiveStreamTask.getTaskDetail", get_params={"tid": tid}, auth_mode="standard")

    def live_task_stop(self, cid: str, tid: str) -> dict:
        return self._call(
            "LiveStreamTask.stop",
            post_params={"cid": cid, "tid": tid},
            auth_mode="standard",
        )
