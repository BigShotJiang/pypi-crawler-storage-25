"""In-memory session for multi-step workflows."""
from __future__ import annotations

import json
from typing import Any


class Session:
    """Store named task results across REPL commands.

    Results are stored under user-supplied aliases so later commands can
    reference the tid or status of a previous step.
    """

    def __init__(self) -> None:
        self._store: dict[str, dict[str, Any]] = {}
        self._history: list[dict[str, Any]] = []

    def store(self, alias: str, result: dict[str, Any]) -> None:
        self._store[alias] = result
        self._history.append({"alias": alias, "result": result})

    def get(self, alias: str) -> dict[str, Any]:
        if alias not in self._store:
            raise KeyError(
                f"No result stored under {alias!r}. "
                f"Available: {list(self._store)}"
            )
        return self._store[alias]

    def get_tid(self, alias: str) -> int:
        result = self.get(alias)
        tid = result.get("tid")
        if tid is None:
            raise ValueError(
                f"Stored result {alias!r} has no tid. "
                f"Full result: {json.dumps(result)}"
            )
        return int(tid)

    def list_aliases(self) -> list[str]:
        return list(self._store)

    def history(self) -> list[dict[str, Any]]:
        return list(self._history)

    def clear(self) -> None:
        self._store.clear()
        self._history.clear()

    def summary(self) -> str:
        if not self._store:
            return "(empty session)"
        lines = []
        for alias, result in self._store.items():
            tid = result.get("tid", result.get("id", "?"))
            status = result.get("status", "?")
            lines.append(f"  {alias}: tid={tid}  status={status}")
        return "\n".join(lines)
