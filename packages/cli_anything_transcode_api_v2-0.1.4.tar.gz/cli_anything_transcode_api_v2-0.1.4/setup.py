from setuptools import setup, find_namespace_packages

setup(
    name="cli-anything-transcode-api-v2",
    version="0.1.4",
    description="CLI harness for transcode_api_v2 — video/audio transcoding orchestration API",
    packages=find_namespace_packages(
        include=["cli_anything.*"],
        exclude=["cli_anything.transcode_api_v2.tests*"],
    ),
    package_data={
        "cli_anything.transcode_api_v2": ["skills/*.md"],
    },
    install_requires=[
        "click>=8.0",
        "requests>=2.28",
    ],
    entry_points={
        "console_scripts": [
            "cli-anything-transcode-api-v2=cli_anything.transcode_api_v2.transcode_api_v2_cli:cli",
        ],
    },
    python_requires=">=3.10",
)
