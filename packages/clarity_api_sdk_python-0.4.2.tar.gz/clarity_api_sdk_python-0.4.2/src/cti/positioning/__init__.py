"""Shared positioning math used by clarity-server and clarity-engine.

The Targets MVP spec requires that geographic position and SRID-unit
dimensions for a target be derived (not stored) from the parent line's
current nav, bottom track, and sample spacing — and that the engine and
server share one source of truth for that math. This package is that
source of truth.
"""
