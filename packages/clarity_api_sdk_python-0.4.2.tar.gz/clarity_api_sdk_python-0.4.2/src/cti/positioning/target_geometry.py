"""Sample-address → geographic-position math for a single Target.

Given a target's ``(channel, ping, sample)`` address and the parent
line's per-ping nav state at that ping, produce the spec's ``derived``
block: geodetic lat/lon, projected XY in the project SRID, and the
optional SRID-unit width/height/shadow dimensions.

This module is the canonical implementation. Both ``clarity-server``
(read path: GET /targets/{id} populates ``Target.derived``) and
``clarity-engine`` (any internal use that needs target geometry) MUST
import :func:`derive` rather than re-implement it. See
``clarity-docs/designs/spec-targets-mvp.md`` §"Conversion responsibility
split".

Conventions
-----------
- ``channel == 0`` is port (left of vessel track).
- Any other ``channel`` is starboard (right of vessel track).
- Headings are compass bearings: 0° = north, increasing clockwise.
- Vessel position in :class:`LineState` is **projected** in the same
  ``target_srid`` passed to :func:`derive`. Both consumers (server and
  engine) hold per-ping nav in projected coordinates after the
  navigation phase (e.g. clarity-engine writes ``inner_x``/``inner_y``
  in the project SRID), so taking projected input here avoids a
  redundant geodetic round-trip.
- Slant range is corrected to ground range using the bottom-tracked
  altitude when available; without altitude, slant range is used
  directly (acceptable when the seafloor is shallow relative to range).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from functools import lru_cache

import pyproj

from cti.model.target import Target, TargetDerived


_GEODETIC_CRS = "EPSG:4326"


@dataclass(frozen=True)
class LineState:
    """Per-ping line state at a target's ping index.

    Callers (typically the server's derive layer) extract these scalars
    from the parent SidescanPingSource's nav/bottom-track Zarr arrays
    and the sample-spacing computed from sound velocity and sample rate.

    Attributes:
        projected_x: Vessel easting at the target's ping, in the project
            SRID's linear unit (must match ``target_srid`` passed to
            :func:`derive`).
        projected_y: Vessel northing at the target's ping, same SRID.
        heading_deg: Vessel compass heading at the target's ping
            (0 = north, increasing clockwise).
        sample_spacing_units: Across-track distance per sample, in the
            project SRID's linear unit. Caller is responsible for the
            metres-to-SRID-unit conversion before constructing the
            LineState.
        ping_spacing_units: Local along-track distance per ping, in the
            project SRID's linear unit (typically metres for projected
            SRIDs but feet for some state-plane SRIDs). Caller computes
            this from consecutive vessel positions, which are themselves
            already in SRID-projected coordinates, so the result inherits
            the SRID's linear unit rather than being forced to metres.
        altitude_units: Bottom-tracked altitude at the target's ping, in
            SRID linear units, or ``None`` if no bottom track is
            available (slant-to-ground correction is then skipped).
            Caller converts from metres before constructing the LineState.
    """

    projected_x: float
    projected_y: float
    heading_deg: float
    sample_spacing_units: float
    ping_spacing_units: float
    altitude_units: float | None = None


@lru_cache(maxsize=64)
def _transformer_from(target_srid: str) -> pyproj.Transformer:
    """Cached inverse transformer from ``target_srid`` to EPSG:4326."""
    return pyproj.Transformer.from_crs(target_srid, _GEODETIC_CRS, always_xy=True)


@lru_cache(maxsize=64)
def _linear_unit(target_srid: str) -> str:
    """Linear unit name for ``target_srid`` (e.g. ``"metre"`` / ``"meter"``)."""
    crs = pyproj.CRS.from_user_input(target_srid)
    axis = crs.axis_info[0] if crs.axis_info else None
    return axis.unit_name if axis is not None else "meter"


def derive(  # pylint: disable=too-many-locals
    target: Target, line_state: LineState, target_srid: str
) -> TargetDerived:
    """Derive a target's geographic position and SRID-unit dimensions.

    Args:
        target: The target to position. Only ``channel``, ``sample``,
            ``width_samples``, ``height_pings``, and ``shadow_samples``
            are read; ``ping`` is consumed by the caller when
            constructing ``line_state``.
        line_state: Per-ping nav + spacing at ``target.ping``.
        target_srid: Project SRID to project into (e.g. ``"EPSG:32618"``).

    Returns:
        The derived block: geodetic lat/lon, projected XY in
        ``target_srid``, optional SRID-unit width/height/shadow, and the
        SRID's linear-unit name.
    """
    side = -1.0 if target.channel == 0 else 1.0
    slant_range_units = target.sample * line_state.sample_spacing_units
    ground_range_units = (
        math.sqrt(slant_range_units**2 - line_state.altitude_units**2)
        if line_state.altitude_units is not None
        and slant_range_units > line_state.altitude_units
        else slant_range_units
    )
    across_track_units = side * ground_range_units

    perp_rad = math.radians(line_state.heading_deg) + math.pi / 2.0
    target_x = line_state.projected_x + across_track_units * math.sin(perp_rad)
    target_y = line_state.projected_y + across_track_units * math.cos(perp_rad)

    inverse = _transformer_from(target_srid)
    target_lon, target_lat = inverse.transform(target_x, target_y)

    width = (
        target.width_samples * line_state.sample_spacing_units
        if target.width_samples is not None
        else None
    )
    height = (
        target.height_pings * line_state.ping_spacing_units
        if target.height_pings is not None
        else None
    )
    shadow = (
        target.shadow_samples * line_state.sample_spacing_units
        if target.shadow_samples is not None
        else None
    )

    return TargetDerived(
        longitude=target_lon,
        latitude=target_lat,
        projected_x=target_x,
        projected_y=target_y,
        srid=target_srid,
        width=width,
        height=height,
        shadow=shadow,
        linear_unit=_linear_unit(target_srid),
    )
