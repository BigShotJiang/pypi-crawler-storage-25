"""Typed API wrapper around ClarityApiClient.

Provides strongly-typed methods for interacting with the SonarWiz API,
using Pydantic models for request and response validation.
"""

import os
import time
from pathlib import Path
from urllib.parse import urlparse
from uuid import UUID

import httpx

from cti.model.altitude_source import AltitudeSource
from cti.model.altitude_source import AltitudeSourceCreate
from cti.model.altitude_source import AltitudeSourceUpdate
from cti.model.attitude_source import AttitudeSource
from cti.model.attitude_source import AttitudeSourceCreate
from cti.model.attitude_source import AttitudeSourceUpdate
from cti.model.deferred_object_deletion import DeferredObjectDeletion
from cti.model.deferred_object_deletion import DeferredObjectDeletionCreate
from cti.model.depth_source import DepthSource
from cti.model.depth_source import DepthSourceCreate
from cti.model.depth_source import DepthSourceUpdate
from cti.model.device import Device
from cti.model.device import DeviceCreate
from cti.model.device import DeviceUpdate
from cti.model.device_type import DeviceType
from cti.model.device_type import DeviceTypeCreate
from cti.model.device_type import DeviceTypeUpdate
from cti.model.final_product import FinalProduct
from cti.model.final_product import FinalProductCreate
from cti.model.final_product import FinalProductUpdate
from cti.model.layback_algorithm import LaybackAlgorithm
from cti.model.layback_algorithm import LaybackAlgorithmCreate
from cti.model.layback_algorithm import LaybackAlgorithmUpdate
from cti.model.layback_source import LaybackSource
from cti.model.layback_source import LaybackSourceCreate
from cti.model.layback_source import LaybackSourceUpdate
from cti.model.layback_type import LaybackType
from cti.model.layback_type import LaybackTypeCreate
from cti.model.layback_type import LaybackTypeUpdate
from cti.model.organization import Organization
from cti.model.organization import OrganizationCreate
from cti.model.organization import OrganizationUpdate
from cti.model.platform import Platform
from cti.model.platform import PlatformCreate
from cti.model.platform import PlatformUpdate
from cti.model.platform_type import PlatformType
from cti.model.platform_type import PlatformTypeCreate
from cti.model.platform_type import PlatformTypeUpdate
from cti.model.position_source import PositionSource
from cti.model.position_source import PositionSourceCreate
from cti.model.position_source import PositionSourceUpdate
from cti.model.processing_job import JobStatusCallback
from cti.model.processing_job import ProcessingJob
from cti.model.processing_job import ProcessingJobCreate
from cti.model.processing_job import ProcessingJobList
from cti.model.processing_log import ProcessingLog
from cti.model.processing_log import ProcessingLogCreate
from cti.model.processing_log import ProcessingLogUpdate
from cti.model.project import Project
from cti.model.project import ProjectCreate
from cti.model.project import ProjectUpdate
from cti.model.projection_option import ProjectionOption
from cti.model.projection_option import ProjectionOptionCreate
from cti.model.projection_option import ProjectionOptionUpdate
from cti.model.raw_file import RawFile
from cti.model.raw_file import RawFileCreate
from cti.model.raw_file import RawFileFilter
from cti.model.raw_file import RawFileUpdate
from cti.model.raw_file import RawFileWithUpload
from cti.model.raw_file_configuration import RawFileConfiguration
from cti.model.raw_file_configuration import RawFileConfigurationCreate
from cti.model.raw_file_configuration import RawFileConfigurationUpdate
from cti.model.raw_file_device_mapping import RawFileDeviceMapping
from cti.model.raw_file_device_mapping import RawFileDeviceMappingCreate
from cti.model.raw_file_device_mapping import RawFileDeviceMappingFilter
from cti.model.raw_file_device_mapping import RawFileDeviceMappingUpdate
from cti.model.raw_file_state import RawFileState
from cti.model.s3 import CompleteMultipartUploadBody
from cti.model.s3 import MultipartUploadStartResponse
from cti.model.s3 import Part
from cti.model.s3 import PartPresignedURL
from cti.model.sidescan_ping_source import SidescanPingSource
from cti.model.sidescan_ping_source import SidescanPingSourceCreate
from cti.model.sidescan_ping_source import SidescanPingSourceUpdate
from cti.model.source import Source
from cti.model.source import SourceCreate
from cti.model.source import SourceUpdate
from cti.model.source import SourceWithUpload
from cti.model.survey import Survey
from cti.model.survey import SurveyCreate
from cti.model.survey import SurveyUpdate
from cti.model.target import Target
from cti.model.target import TargetCreate
from cti.model.target import TargetUpdate
from cti.model.tow_system import TowSystem
from cti.model.tow_system import TowSystemCreate
from cti.model.tow_system import TowSystemUpdate
from cti.model.user_layer import UserLayer
from cti.model.user_layer import UserLayerCreate
from cti.model.user_layer import UserLayerUpdate
from cti.model.user_layer import UserLayerWithUpload

from .client import ClarityApiClient

from cti.logger import get_logger
from importlib.metadata import version

__version__ = version("clarity-api-sdk-python")

logger = get_logger(__name__)


class SonarWizApi:
    """Typed wrapper around ClarityApiClient for SonarWiz API.

    All methods accept Pydantic models for request bodies and return
    Pydantic models for responses. HTTP errors are allowed to propagate.
    """

    def __init__(self, client: ClarityApiClient | httpx.Client):
        """Initialize API wrapper with an HTTP client.

        Args:
            client: ClarityApiClient or plain httpx.Client (for local dev).
        """
        super().__init__()
        self._client = client

    def get_first_platform(self, survey_id: UUID) -> Platform:
        """Get platform by ID.

        Args:
            survey_id: survey UUID

        Returns:
            Platform instance.
        """
        response = self._client.get(f"/api/v1/surveys/{survey_id}/platform")
        response.raise_for_status()
        return Platform.model_validate(response.json())

    def get_raw_file(self, raw_file_id: UUID) -> RawFile:
        """Fetch a RawFile record from the API.

        Args:
            raw_file_id: RawFile UUID to fetch.

        Returns:
            RawFile instance.

        Raises:
            Exception: If RawFile not found or API error.
        """
        logger.info(
            "fetching_raw_file",
            extra={"raw_file_id": str(raw_file_id)},
        )
        response = self._client.get(f"/api/v1/rawfiles/{raw_file_id}")
        raw_file = RawFile.model_validate(response.json())
        logger.info(
            "raw_file_fetched",
            extra={
                "raw_file_id": str(raw_file_id),
                "file_name": raw_file.file_name,
                "uri": raw_file.uri,
                "state": raw_file.state.value,
            },
        )
        return raw_file

    def create_raw_file(self, raw_file: RawFileCreate) -> RawFile:
        """Create a new raw file.

        Args:
            raw_file: Raw file creation data.

        Returns:
            Created raw file instance.
        """
        response = self._client.post(
            "/api/v1/rawfiles", json=raw_file.model_dump(mode="json")
        )
        response.raise_for_status()
        return RawFile.model_validate(response.json())

    def list_raw_files(self) -> list[RawFile]:
        """List all raw files.

        Returns:
            List of raw file instances.
        """
        response = self._client.get("/api/v1/rawfiles")
        response.raise_for_status()
        return [RawFile.model_validate(item) for item in response.json()]

    def get_raw_files(self, survey_id: UUID) -> list[RawFile]:
        """Get all raw files for a specific survey.

        Args:
            survey_id: Survey UUID to fetch raw files for.

        Returns:
            List of raw file instances for the survey.

        Raises:
            Exception: If survey not found or API error.
        """
        logger.info(
            "fetching_raw_files_for_survey",
            extra={"survey_id": str(survey_id)},
        )
        response = self._client.get(f"/api/v1/surveys/{survey_id}/rawfiles")
        response.raise_for_status()
        raw_files = [RawFile.model_validate(item) for item in response.json()]
        logger.info(
            "raw_files_fetched",
            extra={
                "survey_id": str(survey_id),
                "count": len(raw_files),
            },
        )
        return raw_files

    def update_raw_file(
        self, raw_file_id: UUID | str, raw_file: RawFileUpdate
    ) -> RawFile:
        """Update a raw file.

        Args:
            raw_file_id: Raw file UUID or string identifier.
            raw_file: Raw file update data.

        Returns:
            Updated raw file instance.
        """
        response = self._client.put(
            f"/api/v1/rawfiles/{raw_file_id}",
            json=raw_file.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return RawFile.model_validate(response.json())

    def get_raw_file_configuration(
        self, raw_file_configuration_id: UUID
    ) -> RawFileConfiguration:
        """Fetch a RawFileConfiguration record from the API.

        Args:
            raw_file_configuration_id: RawFileConfiguration UUID to fetch.

        Returns:
            RawFileConfiguration instance.

        Raises:
            Exception: If RawFileConfiguration not found or API error.
        """
        logger.info(
            "fetching_raw_file_configuration",
            extra={
                "raw_file_configuration_id": str(raw_file_configuration_id),
            },
        )
        response = self._client.get(
            f"/api/v1/rawfileconfigurations/{raw_file_configuration_id}"
        )
        raw_file_configuration = RawFileConfiguration.model_validate(response.json())
        logger.info(
            "raw_file_configuration_fetched",
            extra={
                "raw_file_configuration_id": str(raw_file_configuration_id),
            },
        )
        return raw_file_configuration

    def create_raw_file_configuration(
        self, raw_file_configuration: RawFileConfigurationCreate
    ) -> RawFileConfiguration:
        """Create a new raw file configuration.

        Args:
            raw_file_configuration: Raw file configuration creation data.

        Returns:
            Created raw file configuration instance.
        """
        response = self._client.post(
            "/api/v1/rawfileconfigurations",
            json=raw_file_configuration.model_dump(mode="json"),
        )
        response.raise_for_status()
        return RawFileConfiguration.model_validate(response.json())

    def list_raw_file_configurations(self) -> list[RawFileConfiguration]:
        """List all raw file configurations.

        Returns:
            List of raw file configuration instances.
        """
        response = self._client.get("/api/v1/rawfileconfigurations")
        response.raise_for_status()
        return [RawFileConfiguration.model_validate(item) for item in response.json()]

    def update_raw_file_configuration(
        self,
        raw_file_configuration_id: UUID | str,
        raw_file_configuration: RawFileConfigurationUpdate,
    ) -> RawFileConfiguration:
        """Update a raw file configuration.

        Args:
            raw_file_configuration_id: Raw file configuration UUID or string identifier.
            raw_file_configuration: Raw file configuration update data.

        Returns:
            Updated raw file configuration instance.
        """
        response = self._client.put(
            f"/api/v1/rawfileconfigurations/{raw_file_configuration_id}",
            json=raw_file_configuration.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return RawFileConfiguration.model_validate(response.json())

    def create_raw_file_device_mapping(
        self, mapping: RawFileDeviceMappingCreate
    ) -> RawFileDeviceMapping:
        """Create a new raw file device mapping.

        Args:
            mapping: Raw file device mapping creation data.

        Returns:
            Created raw file device mapping instance.
        """
        response = self._client.post(
            "/api/v1/raw-file-device-mappings", json=mapping.model_dump(mode="json")
        )
        response.raise_for_status()
        return RawFileDeviceMapping.model_validate(response.json())

    def get_raw_file_device_mapping(
        self, mapping_id: UUID | str
    ) -> RawFileDeviceMapping:
        """Get raw file device mapping by ID.

        Args:
            mapping_id: Raw file device mapping UUID or string identifier.

        Returns:
            Raw file device mapping instance.
        """
        response = self._client.get(f"/api/v1/raw-file-device-mappings/{mapping_id}")
        response.raise_for_status()
        return RawFileDeviceMapping.model_validate(response.json())

    def get_raw_file_device_mappings(
        self,
        *,
        raw_file_id: UUID | str | None = None,
        device_id: UUID | str | None = None,
    ) -> list[RawFileDeviceMapping]:
        """Get raw file device mappings filtered by raw file or device.

        At least one of ``raw_file_id`` / ``device_id`` must be provided —
        the server requires a filter and returns 400 otherwise.

        Args:
            raw_file_id: Match only mappings for this raw file.
            device_id: Match only mappings for this device.

        Returns:
            List of matching raw file device mappings (empty if none match).

        Raises:
            ValueError: If neither ``raw_file_id`` nor ``device_id`` is given.
        """
        if raw_file_id is None and device_id is None:
            raise ValueError(
                "At least one of raw_file_id or device_id must be provided."
            )
        params: dict[str, str] = {}
        if raw_file_id is not None:
            params["raw_file_id"] = str(raw_file_id)
        if device_id is not None:
            params["device_id"] = str(device_id)
        response = self._client.get("/api/v1/raw-file-device-mappings", params=params)
        response.raise_for_status()
        return [RawFileDeviceMapping.model_validate(item) for item in response.json()]

    def update_raw_file_device_mapping(
        self, mapping_id: UUID | str, mapping: RawFileDeviceMappingUpdate
    ) -> RawFileDeviceMapping:
        """Update a raw file device mapping.

        Args:
            mapping_id: Raw file device mapping UUID or string identifier.
            mapping: Raw file device mapping update data.

        Returns:
            Updated raw file device mapping instance.
        """
        response = self._client.put(
            f"/api/v1/raw-file-device-mappings/{mapping_id}",
            json=mapping.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return RawFileDeviceMapping.model_validate(response.json())

    def create_deferred_object_deletion(
        self, deletion: DeferredObjectDeletionCreate
    ) -> DeferredObjectDeletion:
        """Create a new deferred object deletion.

        Args:
            deletion: Deferred object deletion creation data.

        Returns:
            Created deferred object deletion instance.
        """
        response = self._client.post(
            "/api/v1/deferred-object-deletions", json=deletion.model_dump(mode="json")
        )
        response.raise_for_status()
        return DeferredObjectDeletion.model_validate(response.json())

    def get_deferred_object_deletion(
        self, deletion_id: UUID | str
    ) -> DeferredObjectDeletion:
        """Get deferred object deletion by ID.

        Args:
            deletion_id: Deferred object deletion UUID or string identifier.

        Returns:
            Deferred object deletion instance.
        """
        response = self._client.get(f"/api/v1/deferred-object-deletions/{deletion_id}")
        response.raise_for_status()
        return DeferredObjectDeletion.model_validate(response.json())

    def list_deferred_object_deletions(self) -> list[DeferredObjectDeletion]:
        """List all deferred object deletions.

        Returns:
            List of deferred object deletion instances.
        """
        response = self._client.get("/api/v1/deferred-object-deletions")
        response.raise_for_status()
        return [DeferredObjectDeletion.model_validate(item) for item in response.json()]

    def update_deferred_object_deletion(
        self, deletion_id: UUID | str, deletion: DeferredObjectDeletionCreate
    ) -> DeferredObjectDeletion:
        """Update a deferred object deletion.

        Args:
            deletion_id: Deferred object deletion UUID or string identifier.
            deletion: Deferred object deletion update data.

        Returns:
            Updated deferred object deletion instance.
        """
        response = self._client.put(
            f"/api/v1/deferred-object-deletions/{deletion_id}",
            json=deletion.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return DeferredObjectDeletion.model_validate(response.json())

    def create_project(self, project: ProjectCreate) -> Project:
        """Create a new project.

        Args:
            project: Project creation data.

        Returns:
            Created project instance.
        """
        response = self._client.post(
            "/api/v1/projects", json=project.model_dump(mode="json")
        )
        response.raise_for_status()
        return Project.model_validate(response.json())

    def get_project(self, project_id: UUID | str) -> Project:
        """Get project by ID.

        Args:
            project_id: Project UUID or string identifier.

        Returns:
            Project instance.
        """
        logger.info(
            "fetching_project",
            extra={"project_id": str(project_id)},
        )
        response = self._client.get(f"/api/v1/projects/{project_id}")
        response.raise_for_status()
        project = Project.model_validate(response.json())
        logger.info(
            "project_fetched",
            extra={
                "project_id": str(project_id),
                "organization_id": str(project.organization_id),
            },
        )
        return project

    def update_project(self, project_id: UUID | str, project: ProjectUpdate) -> Project:
        """Update a project.

        Args:
            project_id: Project UUID or string identifier.
            project: Project update data.

        Returns:
            Updated project instance.
        """
        response = self._client.put(
            f"/api/v1/projects/{project_id}",
            json=project.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return Project.model_validate(response.json())

    def list_projects(self) -> list[Project]:
        """List all projects.

        Returns:
            List of project instances.
        """
        response = self._client.get("/api/v1/projects")
        response.raise_for_status()
        return [Project.model_validate(item) for item in response.json()]

    def create_survey(self, survey: SurveyCreate) -> Survey:
        """Create a new survey.

        Args:
            survey: Survey creation data.

        Returns:
            Created survey instance.
        """
        response = self._client.post(
            "/api/v1/surveys", json=survey.model_dump(mode="json")
        )
        response.raise_for_status()
        return Survey.model_validate(response.json())

    def get_survey(self, survey_id: UUID | str) -> Survey:
        """Get survey by ID.

        Args:
            survey_id: Survey UUID or string identifier.

        Returns:
            Survey instance.
        """
        logger.info(
            "fetching_survey",
            extra={"survey_id": str(survey_id)},
        )
        response = self._client.get(f"/api/v1/surveys/{survey_id}")
        response.raise_for_status()
        survey = Survey.model_validate(response.json())
        logger.info(
            "survey_fetched",
            extra={
                "survey_id": str(survey_id),
                "project_id": str(survey.project_id),
            },
        )
        return survey

    def update_survey(self, survey_id: UUID | str, survey: SurveyUpdate) -> Survey:
        """Update a survey.

        Args:
            survey_id: Survey UUID or string identifier.
            survey: Survey update data.

        Returns:
            Updated survey instance.
        """
        response = self._client.put(
            f"/api/v1/surveys/{survey_id}",
            json=survey.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return Survey.model_validate(response.json())

    def list_surveys(self) -> list[Survey]:
        """List all surveys.

        Returns:
            List of survey instances.
        """
        response = self._client.get("/api/v1/surveys")
        response.raise_for_status()
        return [Survey.model_validate(item) for item in response.json()]

    def create_platform(self, platform: PlatformCreate) -> Platform:
        """Create a new platform.

        Args:
            platform: Platform creation data.

        Returns:
            Created platform instance.
        """
        response = self._client.post(
            "/api/v1/platforms", json=platform.model_dump(mode="json")
        )
        response.raise_for_status()
        return Platform.model_validate(response.json())

    def get_platform(self, platform_id: UUID | str) -> Platform:
        """Get platform by ID.

        Args:
            platform_id: Platform UUID or string identifier.

        Returns:
            Platform instance.
        """
        response = self._client.get(f"/api/v1/platforms/{platform_id}")
        response.raise_for_status()
        return Platform.model_validate(response.json())

    def get_first_survey_platform(self, survey_id: UUID | str) -> Platform:
        """Get first platform by survey ID.

        Args:
            survey_id: Survey UUID or string identifier.

        Returns:
            Platform instance.
        """
        response = self._client.get(f"/api/v1/surveys/{survey_id}/platform")
        response.raise_for_status()
        return Platform.model_validate(response.json())

    def update_platform(
        self, platform_id: UUID | str, platform: PlatformUpdate
    ) -> Platform:
        """Update a platform.

        Args:
            platform_id: Platform UUID or string identifier.
            platform: Platform update data.

        Returns:
            Updated platform instance.
        """
        response = self._client.put(
            f"/api/v1/platforms/{platform_id}",
            json=platform.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return Platform.model_validate(response.json())

    def list_platforms(self) -> list[Platform]:
        """List all platforms.

        Returns:
            List of platform instances.
        """
        response = self._client.get("/api/v1/platforms")
        response.raise_for_status()
        return [Platform.model_validate(item) for item in response.json()]

    def create_device(self, device: DeviceCreate) -> Device:
        """Create a new device.

        Args:
            device: Device creation data.

        Returns:
            Created device instance.
        """
        logger.info(
            "creating_device",
            extra={
                "name": device.name,
                "platform_id": str(device.platform_id),
            },
        )
        response = self._client.post(
            "/api/v1/devices", json=device.model_dump(mode="json")
        )
        response.raise_for_status()
        created_device = Device.model_validate(response.json())
        logger.info(
            "device_created",
            extra={
                "device_id": str(created_device.device_id),
                "name": device.name,
            },
        )
        return created_device

    def get_device(self, device_id: UUID | str) -> Device:
        """Get device by ID.

        Args:
            device_id: Device UUID or string identifier.

        Returns:
            Device instance.
        """
        response = self._client.get(f"/api/v1/devices/{device_id}")
        response.raise_for_status()
        return Device.model_validate(response.json())

    def update_device(self, device_id: UUID | str, device: DeviceUpdate) -> Device:
        """Update a device.

        Args:
            device_id: Device UUID or string identifier.
            device: Device update data.

        Returns:
            Updated device instance.
        """
        response = self._client.put(
            f"/api/v1/devices/{device_id}",
            json=device.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return Device.model_validate(response.json())

    def list_devices(self) -> list[Device]:
        """List all devices.

        Returns:
            List of device instances.
        """
        response = self._client.get("/api/v1/devices")
        response.raise_for_status()
        return [Device.model_validate(item) for item in response.json()]

    def get_platform_devices(self, platform_id: UUID | str) -> list[Device]:
        """Get all devices associated with a platform.

        Args:
            platform_id: Platform UUID or string identifier.

        Returns:
            List of device instances associated with the platform.
        """
        logger.info(
            "fetching_platform_devices",
            extra={"platform_id": str(platform_id)},
        )
        response = self._client.get(f"/api/v1/platforms/{platform_id}/devices")
        response.raise_for_status()
        devices = [Device.model_validate(item) for item in response.json()]
        logger.info(
            "platform_devices_fetched",
            extra={
                "platform_id": str(platform_id),
                "count": len(devices),
            },
        )
        return devices

    def get_device_altitude_sources(
        self, device_id: UUID | str
    ) -> list[AltitudeSource]:
        """Get all altitude sources associated with a device.

        Args:
            device_id: Device UUID or string identifier.

        Returns:
            List of altitude source instances associated with the device.
        """
        logger.info(
            "fetching_device_altitude_sources",
            extra={"device_id": str(device_id)},
        )
        response = self._client.get(f"/api/v1/devices/{device_id}/altitude-sources")
        response.raise_for_status()
        sources = [AltitudeSource.model_validate(item) for item in response.json()]
        logger.info(
            "device_altitude_sources_fetched",
            extra={
                "device_id": str(device_id),
                "count": len(sources),
            },
        )
        return sources

    def get_device_attitude_sources(
        self, device_id: UUID | str
    ) -> list[AttitudeSource]:
        """Get all attitude sources associated with a device.

        Args:
            device_id: Device UUID or string identifier.

        Returns:
            List of attitude source instances associated with the device.
        """
        logger.info(
            "fetching_device_attitude_sources",
            extra={"device_id": str(device_id)},
        )
        response = self._client.get(f"/api/v1/devices/{device_id}/attitude-source")
        response.raise_for_status()
        source = AttitudeSource.model_validate(response.json())
        sources = [source]
        logger.info(
            "device_attitude_sources_fetched",
            extra={
                "device_id": str(device_id),
                "count": len(sources),
            },
        )
        return sources

    def get_device_depth_sources(self, device_id: UUID | str) -> list[DepthSource]:
        """Get all depth sources associated with a device.

        Args:
            device_id: Device UUID or string identifier.

        Returns:
            List of depth source instances associated with the device.
        """
        logger.info(
            "fetching_device_depth_sources",
            extra={"device_id": str(device_id)},
        )
        response = self._client.get(f"/api/v1/devices/{device_id}/depth-sources")
        response.raise_for_status()
        sources = [DepthSource.model_validate(item) for item in response.json()]
        logger.info(
            "device_depth_sources_fetched",
            extra={
                "device_id": str(device_id),
                "count": len(sources),
            },
        )
        return sources

    def get_device_layback_sources(self, device_id: UUID | str) -> list[LaybackSource]:
        """Get all layback sources associated with a device.

        Args:
            device_id: Device UUID or string identifier.

        Returns:
            List of layback source instances associated with the device.
        """
        logger.info(
            "fetching_device_layback_sources",
            extra={"device_id": str(device_id)},
        )
        response = self._client.get(f"/api/v1/devices/{device_id}/layback-sources")
        response.raise_for_status()
        sources = [LaybackSource.model_validate(item) for item in response.json()]
        logger.info(
            "device_layback_sources_fetched",
            extra={
                "device_id": str(device_id),
                "count": len(sources),
            },
        )
        return sources

    def get_device_position_sources(
        self, device_id: UUID | str
    ) -> list[PositionSource]:
        """Get all position sources associated with a device.

        Args:
            device_id: Device UUID or string identifier.

        Returns:
            List of position source instances associated with the device.
        """
        logger.info(
            "fetching_device_position_sources",
            extra={"device_id": str(device_id)},
        )
        response = self._client.get(f"/api/v1/devices/{device_id}/position-sources")
        response.raise_for_status()
        sources = [PositionSource.model_validate(item) for item in response.json()]
        logger.info(
            "device_position_sources_fetched",
            extra={
                "device_id": str(device_id),
                "count": len(sources),
            },
        )
        return sources

    def get_device_sidescan_ping_sources(
        self, device_id: UUID | str
    ) -> list[SidescanPingSource]:
        """Get all sidescan ping sources associated with a device.

        Args:
            device_id: Device UUID or string identifier.

        Returns:
            List of sidescan ping source instances associated with the device.
        """
        logger.info(
            "fetching_device_sidescan_ping_sources",
            extra={"device_id": str(device_id)},
        )
        response = self._client.get(
            f"/api/v1/devices/{device_id}/sidescan-ping-sources"
        )
        response.raise_for_status()
        sources = [SidescanPingSource.model_validate(item) for item in response.json()]
        logger.info(
            "device_sidescan_ping_sources_fetched",
            extra={
                "device_id": str(device_id),
                "count": len(sources),
            },
        )
        return sources

    def create_source(self, source: SourceCreate) -> Source:
        """Create a new source.

        Args:
            source: Source creation data.

        Returns:
            Created source instance.
        """
        logger.info(
            "creating_source",
            extra={
                "survey_id": str(source.survey_id),
                "raw_file_id": str(source.raw_file_id) if source.raw_file_id else None,
            },
        )
        response = self._client.post(
            "/api/v1/sources", json=source.model_dump(mode="json")
        )
        response.raise_for_status()
        created_source = Source.model_validate(response.json())
        logger.info(
            "source_created",
            extra={"source_id": str(created_source.source_id)},
        )
        return created_source

    def get_source(self, source_id: UUID | str) -> Source:
        """Get source by ID.

        Args:
            source_id: Source UUID or string identifier.

        Returns:
            Source instance.
        """
        response = self._client.get(f"/api/v1/sources/{source_id}")
        response.raise_for_status()
        return Source.model_validate(response.json())

    def update_source(self, source_id: UUID | str, source: SourceUpdate) -> Source:
        """Update a source.

        Args:
            source_id: Source UUID or string identifier.
            source: Source update data.

        Returns:
            Updated source instance.
        """
        response = self._client.put(
            f"/api/v1/sources/{source_id}",
            json=source.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return Source.model_validate(response.json())

    def list_sources(self) -> list[Source]:
        """List all sources.

        Returns:
            List of source instances.
        """
        response = self._client.get("/api/v1/sources")
        response.raise_for_status()
        return [Source.model_validate(item) for item in response.json()]

    def create_sidescan_source(
        self, sidescan_source: SidescanPingSourceCreate
    ) -> SidescanPingSource:
        """Create a new sidescan ping source.

        Args:
            sidescan_source: Sidescan ping source creation data.

        Returns:
            Created sidescan ping source instance.
        """
        logger.info(
            "creating_sidescan_source",
            extra={
                "device_id": str(sidescan_source.device_id),
                "source_id": str(sidescan_source.source_id),
            },
        )
        response = self._client.post(
            "/api/v1/sidescan-ping-sources",
            json=sidescan_source.model_dump(mode="json"),
        )
        response.raise_for_status()
        created = SidescanPingSource.model_validate(response.json())
        logger.info(
            "sidescan_source_created",
            extra={
                "sidescan_ping_source_id": str(created.sidescan_ping_source_id),
            },
        )
        return created

    def get_sidescan_source(self, sidescan_source_id: UUID | str) -> SidescanPingSource:
        """Get sidescan ping source by ID.

        Args:
            sidescan_source_id: Sidescan ping source UUID or string identifier.

        Returns:
            Sidescan ping source instance.
        """
        response = self._client.get(
            f"/api/v1/sidescan-ping-sources/{sidescan_source_id}"
        )
        response.raise_for_status()
        return SidescanPingSource.model_validate(response.json())

    def update_sidescan_source(
        self,
        sidescan_source_id: UUID | str,
        sidescan_source: SidescanPingSourceUpdate,
    ) -> SidescanPingSource:
        """Update a sidescan ping source.

        Args:
            sidescan_source_id: Sidescan ping source UUID or string identifier.
            sidescan_source: Sidescan ping source update data.

        Returns:
            Updated sidescan ping source instance.
        """
        logger.info(
            "updating_sidescan_source",
            extra={
                "sidescan_source_id": str(sidescan_source_id),
                "zarr_path": sidescan_source.zarr_path,
            },
        )
        response = self._client.put(
            f"/api/v1/sidescan-ping-sources/{sidescan_source_id}",
            json=sidescan_source.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        updated = SidescanPingSource.model_validate(response.json())
        logger.info(
            "sidescan_source_updated",
            extra={
                "sidescan_source_id": str(sidescan_source_id),
            },
        )
        return updated

    def list_sidescan_sources(self) -> list[SidescanPingSource]:
        """List all sidescan ping sources.

        Returns:
            List of sidescan ping source instances.
        """
        response = self._client.get("/api/v1/sidescan-ping-sources")
        response.raise_for_status()
        return [SidescanPingSource.model_validate(item) for item in response.json()]

    def create_position_source(
        self, position_source: PositionSourceCreate
    ) -> PositionSource:
        """Create a new position source.

        Args:
            position_source: Position source creation data.

        Returns:
            Created position source instance.
        """
        logger.info(
            "creating_position_source",
            extra={
                "device_id": str(position_source.device_id),
                "source_id": str(position_source.source_id),
            },
        )
        response = self._client.post(
            "/api/v1/position_sources",
            json=position_source.model_dump(mode="json"),
        )
        response.raise_for_status()
        created = PositionSource.model_validate(response.json())
        logger.info(
            "position_source_created",
            extra={
                "position_source_id": str(created.position_source_id),
            },
        )
        return created

    def get_position_source(self, position_source_id: UUID | str) -> PositionSource:
        """Get position source by ID.

        Args:
            position_source_id: Position source UUID or string identifier.

        Returns:
            Position source instance.
        """
        response = self._client.get(f"/api/v1/position_sources/{position_source_id}")
        response.raise_for_status()
        return PositionSource.model_validate(response.json())

    def update_position_source(
        self,
        position_source_id: UUID | str,
        position_source: PositionSourceUpdate,
    ) -> PositionSource:
        """Update a position source.

        Args:
            position_source_id: Position source UUID or string identifier.
            position_source: Position source update data.

        Returns:
            Updated position source instance.
        """
        response = self._client.put(
            f"/api/v1/position_sources/{position_source_id}",
            json=position_source.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return PositionSource.model_validate(response.json())

    def list_position_sources(self) -> list[PositionSource]:
        """List all position sources.

        Returns:
            List of position source instances.
        """
        response = self._client.get("/api/v1/position_sources")
        response.raise_for_status()
        return [PositionSource.model_validate(item) for item in response.json()]

    def create_attitude_source(
        self, attitude_source: AttitudeSourceCreate
    ) -> AttitudeSource:
        """Create a new attitude source.

        Args:
            attitude_source: Attitude source creation data.

        Returns:
            Created attitude source instance.
        """
        logger.info(
            "creating_attitude_source",
            extra={
                "device_id": str(attitude_source.device_id),
                "source_id": str(attitude_source.source_id),
            },
        )
        response = self._client.post(
            "/api/v1/attitude-sources",
            json=attitude_source.model_dump(mode="json"),
        )
        response.raise_for_status()
        created = AttitudeSource.model_validate(response.json())
        logger.info(
            "attitude_source_created",
            extra={
                "attitude_source_id": str(created.attitude_source_id),
            },
        )
        return created

    def get_attitude_source(self, attitude_source_id: UUID | str) -> AttitudeSource:
        """Get attitude source by ID.

        Args:
            attitude_source_id: Attitude source UUID or string identifier.

        Returns:
            Attitude source instance.
        """
        response = self._client.get(f"/api/v1/attitude-sources/{attitude_source_id}")
        response.raise_for_status()
        return AttitudeSource.model_validate(response.json())

    def update_attitude_source(
        self,
        attitude_source_id: UUID | str,
        attitude_source: AttitudeSourceUpdate,
    ) -> AttitudeSource:
        """Update an attitude source.

        Args:
            attitude_source_id: Attitude source UUID or string identifier.
            attitude_source: Attitude source update data.

        Returns:
            Updated attitude source instance.
        """
        response = self._client.put(
            f"/api/v1/attitude-sources/{attitude_source_id}",
            json=attitude_source.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return AttitudeSource.model_validate(response.json())

    def list_attitude_sources(self) -> list[AttitudeSource]:
        """List all attitude sources.

        Returns:
            List of attitude source instances.
        """
        response = self._client.get("/api/v1/attitude-sources")
        response.raise_for_status()
        return [AttitudeSource.model_validate(item) for item in response.json()]

    def create_depth_source(self, depth_source: DepthSourceCreate) -> DepthSource:
        """Create a new depth source.

        Args:
            depth_source: Depth source creation data.

        Returns:
            Created depth source instance.
        """
        logger.info(
            "creating_depth_source",
            extra={
                "device_id": str(depth_source.device_id),
                "source_id": str(depth_source.source_id),
            },
        )
        response = self._client.post(
            "/api/v1/depth-sources",
            json=depth_source.model_dump(mode="json"),
        )
        response.raise_for_status()
        created = DepthSource.model_validate(response.json())
        logger.info(
            "depth_source_created",
            extra={
                "depth_source_id": str(created.depth_source_id),
            },
        )
        return created

    def get_depth_source(self, depth_source_id: UUID | str) -> DepthSource:
        """Get depth source by ID.

        Args:
            depth_source_id: Depth source UUID or string identifier.

        Returns:
            Depth source instance.
        """
        response = self._client.get(f"/api/v1/depth-sources/{depth_source_id}")
        response.raise_for_status()
        return DepthSource.model_validate(response.json())

    def update_depth_source(
        self, depth_source_id: UUID | str, depth_source: DepthSourceUpdate
    ) -> DepthSource:
        """Update a depth source.

        Args:
            depth_source_id: Depth source UUID or string identifier.
            depth_source: Depth source update data.

        Returns:
            Updated depth source instance.
        """
        response = self._client.put(
            f"/api/v1/depth-sources/{depth_source_id}",
            json=depth_source.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return DepthSource.model_validate(response.json())

    def list_depth_sources(self) -> list[DepthSource]:
        """List all depth sources.

        Returns:
            List of depth source instances.
        """
        response = self._client.get("/api/v1/depth-sources")
        response.raise_for_status()
        return [DepthSource.model_validate(item) for item in response.json()]

    def create_altitude_source(
        self, altitude_source: AltitudeSourceCreate
    ) -> AltitudeSource:
        """Create a new altitude source.

        Args:
            altitude_source: Altitude source creation data.

        Returns:
            Created altitude source instance.
        """
        response = self._client.post(
            "/api/v1/altitude-sources",
            json=altitude_source.model_dump(mode="json"),
        )
        response.raise_for_status()
        return AltitudeSource.model_validate(response.json())

    def get_altitude_source(self, altitude_source_id: UUID | str) -> AltitudeSource:
        """Get altitude source by ID.

        Args:
            altitude_source_id: Altitude source UUID or string identifier.

        Returns:
            Altitude source instance.
        """
        response = self._client.get(f"/api/v1/altitude-sources/{altitude_source_id}")
        response.raise_for_status()
        return AltitudeSource.model_validate(response.json())

    def update_altitude_source(
        self,
        altitude_source_id: UUID | str,
        altitude_source: AltitudeSourceUpdate,
    ) -> AltitudeSource:
        """Update an altitude source.

        Args:
            altitude_source_id: Altitude source UUID or string identifier.
            altitude_source: Altitude source update data.

        Returns:
            Updated altitude source instance.
        """
        response = self._client.put(
            f"/api/v1/altitude-sources/{altitude_source_id}",
            json=altitude_source.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return AltitudeSource.model_validate(response.json())

    def list_altitude_sources(self) -> list[AltitudeSource]:
        """List all altitude sources.

        Returns:
            List of altitude source instances.
        """
        response = self._client.get("/api/v1/altitude-sources")
        response.raise_for_status()
        return [AltitudeSource.model_validate(item) for item in response.json()]

    def create_layback_source(
        self, layback_source: LaybackSourceCreate
    ) -> LaybackSource:
        """Create a new layback source.

        Args:
            layback_source: Layback source creation data.

        Returns:
            Created layback source instance.
        """
        response = self._client.post(
            "/api/v1/layback-sources",
            json=layback_source.model_dump(mode="json"),
        )
        response.raise_for_status()
        return LaybackSource.model_validate(response.json())

    def get_layback_source(self, layback_source_id: UUID | str) -> LaybackSource:
        """Get layback source by ID.

        Args:
            layback_source_id: Layback source UUID or string identifier.

        Returns:
            Layback source instance.
        """
        response = self._client.get(f"/api/v1/layback-sources/{layback_source_id}")
        response.raise_for_status()
        return LaybackSource.model_validate(response.json())

    def update_layback_source(
        self,
        layback_source_id: UUID | str,
        layback_source: LaybackSourceUpdate,
    ) -> LaybackSource:
        """Update a layback source.

        Args:
            layback_source_id: Layback source UUID or string identifier.
            layback_source: Layback source update data.

        Returns:
            Updated layback source instance.
        """
        response = self._client.put(
            f"/api/v1/layback-sources/{layback_source_id}",
            json=layback_source.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return LaybackSource.model_validate(response.json())

    def list_layback_sources(self) -> list[LaybackSource]:
        """List all layback sources.

        Returns:
            List of layback source instances.
        """
        response = self._client.get("/api/v1/layback-sources")
        response.raise_for_status()
        return [LaybackSource.model_validate(item) for item in response.json()]

    def create_device_type(self, device_type: DeviceTypeCreate) -> DeviceType:
        """Create a new device type.

        Args:
            device_type: Device type creation data.

        Returns:
            Created device type instance.
        """
        response = self._client.post(
            "/api/v1/device-types", json=device_type.model_dump(mode="json")
        )
        response.raise_for_status()
        return DeviceType.model_validate(response.json())

    def get_device_type(self, device_type_id: UUID | str) -> DeviceType:
        """Get device type by ID.

        Args:
            device_type_id: Device type UUID or string identifier.

        Returns:
            Device type instance.
        """
        response = self._client.get(f"/api/v1/device-types/{device_type_id}")
        response.raise_for_status()
        return DeviceType.model_validate(response.json())

    def list_device_types(self) -> list[DeviceType]:
        """List all device types.

        Returns:
            List of device type instances.
        """
        logger.info("fetching_device_types", extra={})
        response = self._client.get("/api/v1/device-types")
        response.raise_for_status()
        device_types = [DeviceType.model_validate(item) for item in response.json()]
        logger.info(
            "device_types_fetched",
            extra={"count": len(device_types)},
        )
        return device_types

    def update_device_type(
        self, device_type_id: UUID | str, device_type: DeviceTypeUpdate
    ) -> DeviceType:
        """Update a device type.

        Args:
            device_type_id: Device type UUID or string identifier.
            device_type: Device type update data.

        Returns:
            Updated device type instance.
        """
        response = self._client.put(
            f"/api/v1/device-types/{device_type_id}",
            json=device_type.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return DeviceType.model_validate(response.json())

    def create_platform_type(self, platform_type: PlatformTypeCreate) -> PlatformType:
        """Create a new platform type.

        Args:
            platform_type: Platform type creation data.

        Returns:
            Created platform type instance.
        """
        response = self._client.post(
            "/api/v1/platform-types", json=platform_type.model_dump(mode="json")
        )
        response.raise_for_status()
        return PlatformType.model_validate(response.json())

    def get_platform_type(self, platform_type_id: UUID | str) -> PlatformType:
        """Get platform type by ID.

        Args:
            platform_type_id: Platform type UUID or string identifier.

        Returns:
            Platform type instance.
        """
        response = self._client.get(f"/api/v1/platform-types/{platform_type_id}")
        response.raise_for_status()
        return PlatformType.model_validate(response.json())

    def list_platform_types(self) -> list[PlatformType]:
        """List all platform types.

        Returns:
            List of platform type instances.
        """
        response = self._client.get("/api/v1/platform-types")
        response.raise_for_status()
        return [PlatformType.model_validate(item) for item in response.json()]

    def update_platform_type(
        self, platform_type_id: UUID | str, platform_type: PlatformTypeUpdate
    ) -> PlatformType:
        """Update a platform type.

        Args:
            platform_type_id: Platform type UUID or string identifier.
            platform_type: Platform type update data.

        Returns:
            Updated platform type instance.
        """
        response = self._client.put(
            f"/api/v1/platform-types/{platform_type_id}",
            json=platform_type.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return PlatformType.model_validate(response.json())

    def create_organization(self, organization: OrganizationCreate) -> Organization:
        """Create a new organization.

        Args:
            organization: Organization creation data.

        Returns:
            Created organization instance.
        """
        response = self._client.post(
            "/api/v1/organizations", json=organization.model_dump(mode="json")
        )
        response.raise_for_status()
        return Organization.model_validate(response.json())

    def get_organization(self, organization_id: UUID | str) -> Organization:
        """Get organization by ID.

        Args:
            organization_id: Organization UUID or string identifier.

        Returns:
            Organization instance.
        """
        response = self._client.get(f"/api/v1/organizations/{organization_id}")
        response.raise_for_status()
        return Organization.model_validate(response.json())

    def list_organizations(self) -> list[Organization]:
        """List all organizations.

        Returns:
            List of organization instances.
        """
        response = self._client.get("/api/v1/organizations")
        response.raise_for_status()
        return [Organization.model_validate(item) for item in response.json()]

    def update_organization(
        self, organization_id: UUID | str, organization: OrganizationUpdate
    ) -> Organization:
        """Update an organization.

        Args:
            organization_id: Organization UUID or string identifier.
            organization: Organization update data.

        Returns:
            Updated organization instance.
        """
        response = self._client.put(
            f"/api/v1/organizations/{organization_id}",
            json=organization.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return Organization.model_validate(response.json())

    def create_projection_option(
        self, projection_option: ProjectionOptionCreate
    ) -> ProjectionOption:
        """Create a new projection option.

        Args:
            projection_option: Projection option creation data.

        Returns:
            Created projection option instance.
        """
        response = self._client.post(
            "/api/v1/projection-options",
            json=projection_option.model_dump(mode="json"),
        )
        response.raise_for_status()
        return ProjectionOption.model_validate(response.json())

    def get_projection_option(
        self, projection_option_id: UUID | str
    ) -> ProjectionOption:
        """Get projection option by ID.

        Args:
            projection_option_id: Projection option UUID or string identifier.

        Returns:
            Projection option instance.
        """
        response = self._client.get(
            f"/api/v1/projection-options/{projection_option_id}"
        )
        response.raise_for_status()
        return ProjectionOption.model_validate(response.json())

    def list_projection_options(self) -> list[ProjectionOption]:
        """List all projection options.

        Returns:
            List of projection option instances.
        """
        response = self._client.get("/api/v1/projection-options")
        response.raise_for_status()
        return [ProjectionOption.model_validate(item) for item in response.json()]

    def update_projection_option(
        self,
        projection_option_id: UUID | str,
        projection_option: ProjectionOptionUpdate,
    ) -> ProjectionOption:
        """Update a projection option.

        Args:
            projection_option_id: Projection option UUID or string identifier.
            projection_option: Projection option update data.

        Returns:
            Updated projection option instance.
        """
        response = self._client.put(
            f"/api/v1/projection-options/{projection_option_id}",
            json=projection_option.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return ProjectionOption.model_validate(response.json())

    def create_target(self, target: TargetCreate) -> Target:
        """Create a new target.

        Args:
            target: Target creation data.

        Returns:
            Created target instance.
        """
        response = self._client.post(
            "/api/v1/targets", json=target.model_dump(mode="json")
        )
        response.raise_for_status()
        return Target.model_validate(response.json())

    def get_target(self, target_id: UUID | str) -> Target:
        """Get target by ID.

        Args:
            target_id: Target UUID or string identifier.

        Returns:
            Target instance.
        """
        response = self._client.get(f"/api/v1/targets/{target_id}")
        response.raise_for_status()
        return Target.model_validate(response.json())

    def list_targets(self) -> list[Target]:
        """List all targets.

        Returns:
            List of target instances.
        """
        response = self._client.get("/api/v1/targets")
        response.raise_for_status()
        return [Target.model_validate(item) for item in response.json()]

    def update_target(self, target_id: UUID | str, target: TargetUpdate) -> Target:
        """Update a target.

        Args:
            target_id: Target UUID or string identifier.
            target: Target update data.

        Returns:
            Updated target instance.
        """
        response = self._client.put(
            f"/api/v1/targets/{target_id}",
            json=target.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return Target.model_validate(response.json())

    def create_tow_system(self, tow_system: TowSystemCreate) -> TowSystem:
        """Create a new tow system.

        Args:
            tow_system: Tow system creation data.

        Returns:
            Created tow system instance.
        """
        response = self._client.post(
            "/api/v1/tow-systems", json=tow_system.model_dump(mode="json")
        )
        response.raise_for_status()
        return TowSystem.model_validate(response.json())

    def get_tow_system(self, tow_system_id: UUID | str) -> TowSystem:
        """Get tow system by ID.

        Args:
            tow_system_id: Tow system UUID or string identifier.

        Returns:
            Tow system instance.
        """
        response = self._client.get(f"/api/v1/tow-systems/{tow_system_id}")
        response.raise_for_status()
        return TowSystem.model_validate(response.json())

    def list_tow_systems(self) -> list[TowSystem]:
        """List all tow systems.

        Returns:
            List of tow system instances.
        """
        response = self._client.get("/api/v1/tow-systems")
        response.raise_for_status()
        return [TowSystem.model_validate(item) for item in response.json()]

    def update_tow_system(
        self, tow_system_id: UUID | str, tow_system: TowSystemUpdate
    ) -> TowSystem:
        """Update a tow system.

        Args:
            tow_system_id: Tow system UUID or string identifier.
            tow_system: Tow system update data.

        Returns:
            Updated tow system instance.
        """
        response = self._client.put(
            f"/api/v1/tow-systems/{tow_system_id}",
            json=tow_system.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return TowSystem.model_validate(response.json())

    def create_final_product(self, final_product: FinalProductCreate) -> FinalProduct:
        """Create a new final product.

        Args:
            final_product: Final product creation data.

        Returns:
            Created final product instance.
        """
        response = self._client.post(
            "/api/v1/final-products", json=final_product.model_dump(mode="json")
        )
        response.raise_for_status()
        return FinalProduct.model_validate(response.json())

    def get_final_product(self, final_product_id: UUID | str) -> FinalProduct:
        """Get final product by ID.

        Args:
            final_product_id: Final product UUID or string identifier.

        Returns:
            Final product instance.
        """
        response = self._client.get(f"/api/v1/final-products/{final_product_id}")
        response.raise_for_status()
        return FinalProduct.model_validate(response.json())

    def list_final_products(self) -> list[FinalProduct]:
        """List all final products.

        Returns:
            List of final product instances.
        """
        response = self._client.get("/api/v1/final-products")
        response.raise_for_status()
        return [FinalProduct.model_validate(item) for item in response.json()]

    def update_final_product(
        self, final_product_id: UUID | str, final_product: FinalProductUpdate
    ) -> FinalProduct:
        """Update a final product.

        Args:
            final_product_id: Final product UUID or string identifier.
            final_product: Final product update data.

        Returns:
            Updated final product instance.
        """
        response = self._client.put(
            f"/api/v1/final-products/{final_product_id}",
            json=final_product.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return FinalProduct.model_validate(response.json())

    def create_layback_algorithm(
        self, layback_algorithm: LaybackAlgorithmCreate
    ) -> LaybackAlgorithm:
        """Create a new layback algorithm.

        Args:
            layback_algorithm: Layback algorithm creation data.

        Returns:
            Created layback algorithm instance.
        """
        response = self._client.post(
            "/api/v1/layback-algorithms",
            json=layback_algorithm.model_dump(mode="json"),
        )
        response.raise_for_status()
        return LaybackAlgorithm.model_validate(response.json())

    def get_layback_algorithm(
        self, layback_algorithm_id: UUID | str
    ) -> LaybackAlgorithm:
        """Get layback algorithm by ID.

        Args:
            layback_algorithm_id: Layback algorithm UUID or string identifier.

        Returns:
            Layback algorithm instance.
        """
        response = self._client.get(
            f"/api/v1/layback-algorithms/{layback_algorithm_id}"
        )
        response.raise_for_status()
        return LaybackAlgorithm.model_validate(response.json())

    def list_layback_algorithms(self) -> list[LaybackAlgorithm]:
        """List all layback algorithms.

        Returns:
            List of layback algorithm instances.
        """
        response = self._client.get("/api/v1/layback-algorithms")
        response.raise_for_status()
        return [LaybackAlgorithm.model_validate(item) for item in response.json()]

    def update_layback_algorithm(
        self,
        layback_algorithm_id: UUID | str,
        layback_algorithm: LaybackAlgorithmUpdate,
    ) -> LaybackAlgorithm:
        """Update a layback algorithm.

        Args:
            layback_algorithm_id: Layback algorithm UUID or string identifier.
            layback_algorithm: Layback algorithm update data.

        Returns:
            Updated layback algorithm instance.
        """
        response = self._client.put(
            f"/api/v1/layback-algorithms/{layback_algorithm_id}",
            json=layback_algorithm.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return LaybackAlgorithm.model_validate(response.json())

    def create_layback_type(self, layback_type: LaybackTypeCreate) -> LaybackType:
        """Create a new layback type.

        Args:
            layback_type: Layback type creation data.

        Returns:
            Created layback type instance.
        """
        response = self._client.post(
            "/api/v1/layback-types", json=layback_type.model_dump(mode="json")
        )
        response.raise_for_status()
        return LaybackType.model_validate(response.json())

    def get_layback_type(self, layback_type_id: UUID | str) -> LaybackType:
        """Get layback type by ID.

        Args:
            layback_type_id: Layback type UUID or string identifier.

        Returns:
            Layback type instance.
        """
        response = self._client.get(f"/api/v1/layback-types/{layback_type_id}")
        response.raise_for_status()
        return LaybackType.model_validate(response.json())

    def list_layback_types(self) -> list[LaybackType]:
        """List all layback types.

        Returns:
            List of layback type instances.
        """
        response = self._client.get("/api/v1/layback-types")
        response.raise_for_status()
        return [LaybackType.model_validate(item) for item in response.json()]

    def update_layback_type(
        self, layback_type_id: UUID | str, layback_type: LaybackTypeUpdate
    ) -> LaybackType:
        """Update a layback type.

        Args:
            layback_type_id: Layback type UUID or string identifier.
            layback_type: Layback type update data.

        Returns:
            Updated layback type instance.
        """
        response = self._client.put(
            f"/api/v1/layback-types/{layback_type_id}",
            json=layback_type.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return LaybackType.model_validate(response.json())

    def create_processing_log(
        self, processing_log: ProcessingLogCreate
    ) -> ProcessingLog:
        """Create a new processing log.

        Args:
            processing_log: Processing log creation data.

        Returns:
            Created processing log instance.
        """
        response = self._client.post(
            "/api/v1/processing-logs", json=processing_log.model_dump(mode="json")
        )
        response.raise_for_status()
        return ProcessingLog.model_validate(response.json())

    def get_processing_log(self, processing_log_id: UUID | str) -> ProcessingLog:
        """Get processing log by ID.

        Args:
            processing_log_id: Processing log UUID or string identifier.

        Returns:
            Processing log instance.
        """
        response = self._client.get(f"/api/v1/processing-logs/{processing_log_id}")
        response.raise_for_status()
        return ProcessingLog.model_validate(response.json())

    def list_processing_logs(
        self,
        *,
        raw_file_id: UUID | str | None = None,
        survey_id: UUID | str | None = None,
        processing_step: str | None = None,
    ) -> list[ProcessingLog]:
        """List processing logs, optionally filtered.

        Filters compose: each provided filter narrows the result set.

        Args:
            raw_file_id: Match only logs for this raw file.
            survey_id: Match only logs for this survey.
            processing_step: Match only logs with this processing step
                (e.g. ``"scan"``, ``"ingest"``, ``"products"``).

        Returns:
            List of matching processing logs (empty list if none match).
        """
        params: dict[str, str] = {}
        if raw_file_id is not None:
            params["raw_file_id"] = str(raw_file_id)
        if survey_id is not None:
            params["survey_id"] = str(survey_id)
        if processing_step is not None:
            params["processing_step"] = processing_step
        response = self._client.get("/api/v1/processing-logs", params=params or None)
        response.raise_for_status()
        return [ProcessingLog.model_validate(item) for item in response.json()]

    def update_processing_log(
        self, processing_log_id: UUID | str, processing_log: ProcessingLogUpdate
    ) -> ProcessingLog:
        """Update a processing log.

        Args:
            processing_log_id: Processing log UUID or string identifier.
            processing_log: Processing log update data.

        Returns:
            Updated processing log instance.
        """
        response = self._client.put(
            f"/api/v1/processing-logs/{processing_log_id}",
            json=processing_log.model_dump(mode="json", exclude_unset=True),
        )
        response.raise_for_status()
        return ProcessingLog.model_validate(response.json())

    # ── User Layers ──────────────────────────────────────────────────────

    def create_user_layer(self, user_layer: UserLayerCreate) -> UserLayerWithUpload:
        """Create a new user layer and initiate upload.

        Args:
            user_layer: User layer creation data.

        Returns:
            Created user layer instance with upload information.
        """
        response = self._client.post(
            "/api/v1/user-layers/upload",
            json=user_layer.model_dump(mode="json"),
        )
        response.raise_for_status()
        return UserLayerWithUpload.model_validate(response.json())

    def get_user_layer(self, user_layer_id: UUID) -> UserLayer:
        """Fetch a user layer by ID.

        Args:
            user_layer_id: User layer UUID to fetch.

        Returns:
            UserLayer instance.
        """
        response = self._client.get(f"/api/v1/user-layers/{user_layer_id}")
        response.raise_for_status()
        return UserLayer.model_validate(response.json())

    def list_user_layers(self, project_id: UUID) -> list[UserLayer]:
        """List all user layers for a project.

        Args:
            project_id: Project UUID to filter by.

        Returns:
            List of user layer instances.
        """
        response = self._client.get(
            "/api/v1/user-layers",
            params={"project_id": str(project_id)},
        )
        response.raise_for_status()
        return [UserLayer.model_validate(item) for item in response.json()]

    def update_user_layer(
        self, user_layer_id: UUID, user_layer: UserLayerUpdate
    ) -> UserLayer:
        """Update a user layer.

        Args:
            user_layer_id: User layer UUID to update.
            user_layer: User layer update data.

        Returns:
            Updated user layer instance.
        """
        response = self._client.patch(
            f"/api/v1/user-layers/{user_layer_id}",
            json=user_layer.model_dump(mode="json", exclude_none=True),
        )
        response.raise_for_status()
        return UserLayer.model_validate(response.json())

    def delete_user_layer(self, user_layer_id: UUID) -> None:
        """Delete a user layer.

        Args:
            user_layer_id: User layer UUID to delete.
        """
        response = self._client.delete(f"/api/v1/user-layers/{user_layer_id}")
        response.raise_for_status()

    # ── Processing Jobs ──────────────────────────────────────────────────

    def create_job(self, job_data: ProcessingJobCreate) -> ProcessingJob:
        """Create a new processing job.

        Args:
            job_data: Job creation data with survey_id and job_type.

        Returns:
            Created processing job instance.
        """
        response = self._client.post(
            "/api/v1/jobs",
            json=job_data.model_dump(mode="json"),
        )
        response.raise_for_status()
        return ProcessingJob.model_validate(response.json())

    def get_job(self, job_id: UUID | str) -> ProcessingJob:
        """Get processing job by ID.

        Args:
            job_id: Job UUID or string identifier.

        Returns:
            Processing job instance.
        """
        response = self._client.get(f"/api/v1/jobs/{job_id}")
        response.raise_for_status()
        return ProcessingJob.model_validate(response.json())

    def list_jobs(
        self,
        survey_id: UUID | str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> ProcessingJobList:
        """List processing jobs with optional filters.

        Args:
            survey_id: Optional survey ID filter.
            status: Optional status filter.
            limit: Maximum results to return.
            offset: Pagination offset.

        Returns:
            Paginated list of processing jobs.
        """
        params: dict = {"limit": limit, "offset": offset}
        if survey_id is not None:
            params["survey_id"] = str(survey_id)
        if status is not None:
            params["status"] = status
        response = self._client.get("/api/v1/jobs", params=params)
        response.raise_for_status()
        return ProcessingJobList.model_validate(response.json())

    def update_job_status(
        self, job_id: UUID | str, callback: JobStatusCallback
    ) -> ProcessingJob:
        """Send a phase transition callback for a processing job.

        Args:
            job_id: Job UUID or string identifier.
            callback: Phase transition event data.

        Returns:
            Updated processing job instance.
        """
        response = self._client.post(
            f"/api/v1/jobs/{job_id}/status",
            json=callback.model_dump(mode="json"),
        )
        response.raise_for_status()
        return ProcessingJob.model_validate(response.json())

    # ── High-Level Workflow Methods ──────────────────────────────────────

    def upload_file(
        self,
        survey_id: UUID,
        file_path: str | Path,
        raw_file_configuration_id: UUID | None = None,
        chunk_size: int = 5 * 1024 * 1024,
    ) -> RawFile:
        """Upload a sonar file to a survey via multipart S3 upload.

        Handles the full upload flow: create raw file record, upload parts
        via presigned URLs, and complete the multipart upload.

        Args:
            survey_id: Survey to upload to.
            file_path: Local path to the sonar file (.xtf, .jsf, etc.).
            raw_file_configuration_id: Optional config ID. If None, uses the
                survey's default configuration.
            chunk_size: Size of each upload part in bytes (default 5MB, S3 minimum).

        Returns:
            Completed RawFile with state="ready".
        """
        file_path = Path(file_path)
        file_size = file_path.stat().st_size

        # Look up default raw file configuration if not provided
        if raw_file_configuration_id is None:
            response = self._client.get(
                f"/api/v1/surveys/{survey_id}/rawfileconfigurations"
            )
            response.raise_for_status()
            configs = [RawFileConfiguration.model_validate(c) for c in response.json()]
            if not configs:
                raise ValueError(
                    f"No raw file configuration found for survey {survey_id}"
                )
            raw_file_configuration_id = configs[0].raw_file_configuration_id

        # Initiate multipart upload
        raw_file_create = RawFileCreate(
            survey_id=survey_id,
            raw_file_configuration_id=raw_file_configuration_id,
            file_name=file_path.name,
            file_size=file_size,
        )
        response = self._client.post(
            "/api/v1/rawfiles/upload",
            json=raw_file_create.model_dump(mode="json"),
        )
        response.raise_for_status()
        raw_file = RawFileWithUpload.model_validate(response.json())

        logger.info(
            "upload_started",
            raw_file_id=str(raw_file.raw_file_id),
            file_name=file_path.name,
            file_size=file_size,
        )

        # Upload parts
        parts: list[dict] = []
        part_number = 0
        try:
            with httpx.Client(timeout=120) as s3_client, open(file_path, "rb") as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    part_number += 1

                    # Get presigned URL for this part
                    url_response = self._client.get(
                        f"/api/v1/rawfiles/{raw_file.raw_file_id}/upload-parts/{part_number}/url"
                    )
                    url_response.raise_for_status()
                    presigned_url = PartPresignedURL.model_validate(
                        url_response.json()
                    ).url

                    # The server generates presigned URLs using its S3_ENDPOINT_URL,
                    # which may be a Docker-internal hostname (e.g. minio:9000).
                    # If the client has its own S3_ENDPOINT_URL (e.g. localhost:9000),
                    # rewrite the URL so it's reachable from the client's network.
                    client_s3_endpoint = os.environ.get("S3_ENDPOINT_URL")
                    if client_s3_endpoint:
                        parsed_presigned = urlparse(presigned_url)
                        parsed_client = urlparse(client_s3_endpoint)
                        presigned_url = presigned_url.replace(
                            f"{parsed_presigned.scheme}://{parsed_presigned.netloc}",
                            f"{parsed_client.scheme}://{parsed_client.netloc}",
                            1,
                        )

                    # Upload directly to S3/MinIO (not through API client)
                    put_response = s3_client.put(presigned_url, content=chunk)
                    put_response.raise_for_status()
                    etag = put_response.headers.get("ETag", "").strip('"')

                    parts.append({"ETag": etag, "PartNumber": part_number})
                    logger.debug(
                        "upload_part_complete",
                        part=part_number,
                        etag=etag,
                    )
        except Exception:
            logger.error(
                "upload_failed",
                raw_file_id=str(raw_file.raw_file_id),
                parts_uploaded=part_number,
            )
            raise

        # Complete multipart upload
        complete_body = CompleteMultipartUploadBody(
            parts=[Part(ETag=p["ETag"], PartNumber=p["PartNumber"]) for p in parts]
        )
        complete_response = self._client.post(
            f"/api/v1/rawfiles/{raw_file.raw_file_id}/upload-complete",
            json=complete_body.model_dump(mode="json"),
        )
        complete_response.raise_for_status()
        completed = RawFile.model_validate(complete_response.json())

        logger.info(
            "upload_complete",
            raw_file_id=str(completed.raw_file_id),
            state=completed.state,
            parts=part_number,
        )
        return completed

    def process(self, survey_id: UUID, target_phase: str = "products") -> ProcessingJob:
        """Dispatch a pipeline run for a survey.

        Args:
            survey_id: Survey to process.
            target_phase: Pipeline phase to run up to. Defaults to "products"
                (full pipeline). "scan" runs only setup → scan. The engine's
                pull-chain resolves any required predecessor phases.

        Returns:
            The created ProcessingJob.
        """
        response = self._client.post(
            "/api/v1/process",
            json={"survey_id": str(survey_id), "target_phase": target_phase},
        )
        response.raise_for_status()
        data = response.json()

        # The /process endpoint returns a dict with job_id, not a full
        # ProcessingJob. Fetch the full job record.
        if job_id := data.get("job_id"):
            return self.get_job(job_id)

        return ProcessingJob.model_validate(data)

    def wait_for_job(
        self,
        job_id: UUID | str,
        timeout: float = 300,
        poll_interval: float = 5,
    ) -> ProcessingJob:
        """Poll a processing job until it reaches a terminal state.

        Args:
            job_id: Job UUID to poll.
            timeout: Maximum seconds to wait (default 5 minutes).
            poll_interval: Seconds between polls (default 5).

        Returns:
            The completed or failed ProcessingJob.

        Raises:
            TimeoutError: If the job doesn't reach a terminal state within timeout.
        """
        terminal_states = {"completed", "failed", "cancelled"}
        deadline = time.monotonic() + timeout

        while time.monotonic() < deadline:
            job = self.get_job(job_id)
            if job.status in terminal_states:
                return job

            elapsed = timeout - (deadline - time.monotonic())
            logger.debug(
                "wait_for_job_poll",
                job_id=str(job_id),
                status=job.status,
                phase=job.current_phase,
                progress=job.progress,
                elapsed=round(elapsed, 1),
            )
            time.sleep(poll_interval)

        raise TimeoutError(
            f"Job {job_id} did not complete within {timeout}s (last status: {job.status})"
        )
