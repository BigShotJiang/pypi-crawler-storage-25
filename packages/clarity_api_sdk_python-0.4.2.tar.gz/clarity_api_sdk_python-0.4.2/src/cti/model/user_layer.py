"""Pydantic models for user layer. User-uploaded geospatial layers associated with a project."""

from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class UserLayerState(str, Enum):
    """Status of a user layer."""

    UPLOADING = "uploading"
    READY = "ready"
    ERROR = "error"


class UserLayerType(str, Enum):
    """Supported user layer file types."""

    GEOJSON = "geojson"
    KML = "kml"
    KMZ = "kmz"
    SHAPEFILE = "shapefile"
    GPX = "gpx"
    CSV = "csv"
    GEOTIFF = "geotiff"
    BAG = "bag"
    LAS = "las"
    LAZ = "laz"
    PLY = "ply"
    PCD = "pcd"
    MAGNETOMETRY = "magnetometry"


class UserLayerBase(BaseModel):
    """Base model for user layer data.

    Attributes:
        project_id: Foreign key reference to Project.
        layer_name: Display name for the layer.
        layer_type: Type of the user layer file.
        file_name: Name of the uploaded file.
        file_size: Size of the uploaded file in bytes.
        style: Optional styling configuration for the layer.
        metadata: Optional metadata for the layer.
        sort_order: Display sort order.
    """

    project_id: UUID
    layer_name: str
    layer_type: UserLayerType
    file_name: str | None = None
    file_size: int | None = None
    style: dict | None = None
    metadata: dict | None = None
    sort_order: int = 0


class UserLayerCreate(UserLayerBase):
    """Model for creating a user layer."""


class UserLayerUpdate(BaseModel):
    """Model for updating a user layer.

    Attributes:
        layer_name: Optional updated display name.
        style: Optional updated styling configuration.
        metadata: Optional updated metadata.
        sort_order: Optional updated sort order.
        state: Optional updated state.
    """

    layer_name: str | None = None
    style: dict | None = None
    metadata: dict | None = None
    sort_order: int | None = None
    state: UserLayerState | None = None


class UserLayer(UserLayerBase):
    """Model for user layer data with database fields.

    Attributes:
        user_layer_id: Unique identifier for the user layer.
        user_id: ID of the user who created the layer.
        state: Upload state (uploading, ready, error).
        uri: URI for the layer file storage location.
        upload_id: S3 multipart upload ID (present while uploading, cleared when complete).
        created_date: Timestamp when the layer was created.
        updated_date: Timestamp when the layer was last updated.
        updated_by: ID of the user who last updated the layer.
    """

    user_layer_id: UUID
    user_id: str
    state: UserLayerState = UserLayerState.UPLOADING
    uri: str | None = None
    upload_id: str | None = None
    created_date: datetime
    updated_date: datetime
    updated_by: str

    model_config = ConfigDict(from_attributes=True)


class UserLayerWithUpload(UserLayer):
    """UserLayer response for the create-with-upload endpoint.

    The endpoint initiates an S3 multipart upload before returning, so `uri`
    and `upload_id` are guaranteed to be present. Overrides those fields to
    be non-nullable so callers don't have to defensively check.

    Attributes:
        uri: S3 URI for the layer file storage location. Always populated.
        upload_id: S3 multipart upload ID. Always populated; clients pass it
            to subsequent part-upload and complete-upload calls.
    """

    # Tightening parent's `str | None` to required `str`. Pyright flags the
    # type narrowing as an override issue; Pydantic treats the bare field
    # annotation as required at runtime, which is what we want.
    uri: str  # type: ignore[assignment]
    upload_id: str  # type: ignore[assignment]
