"""Pydantic models for target data.

Mirrors the sample-address shape introduced by clarity-server #119
(see ``clarity-server/src/model/target.py``). The ``derived`` block
required by the Targets MVP spec on every read response is computed by
``cti.positioning.target_geometry.derive`` and surfaced as
``Target.derived``; populating it server-side is clarity-server #120's
job.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


_DEFAULT_NAME = "[unreviewed] [Unknown Object]"


class TargetBase(BaseModel):
    """Sample-address fields shared across create/update/read models.

    Attributes:
        channel: Sonar channel index (port/starboard/…).
        ping: Ping address (along-track).
        sample: Sample address within the ping (across-track, non-negative).
        name: Operator-supplied name.
        description: Optional free-form notes.
        width_samples: Optional bounding-box width in sample addresses.
        height_pings: Optional bounding-box height in ping addresses.
        shadow_samples: Optional acoustic-shadow length in sample addresses.
    """

    channel: int
    ping: int
    sample: int
    name: str = _DEFAULT_NAME
    description: str = ""
    width_samples: int | None = None
    height_pings: int | None = None
    shadow_samples: int | None = None


class TargetCreate(TargetBase):
    """POST body shape — sample-address fields plus the parent FK.

    Attributes:
        sidescan_ping_source_id: FK reference to SidescanPingSource.
    """

    sidescan_ping_source_id: UUID


class TargetUpdate(BaseModel):
    """Partial update body — every field optional.

    Attributes:
        channel: Sonar channel index.
        ping: Ping address.
        sample: Sample address.
        name: Operator-supplied name.
        description: Free-form notes.
        width_samples: Bounding-box width in sample addresses.
        height_pings: Bounding-box height in ping addresses.
        shadow_samples: Acoustic-shadow length in sample addresses.
    """

    channel: int | None = None
    ping: int | None = None
    sample: int | None = None
    name: str | None = None
    description: str | None = None
    width_samples: int | None = None
    height_pings: int | None = None
    shadow_samples: int | None = None


class TargetDerived(BaseModel):
    """Read-only derived block — lat/lon, projected XY, SRID-unit dimensions.

    Computed by :func:`cti.positioning.target_geometry.derive` from a
    target's sample-address fields plus the parent line's current nav,
    bottom track, and sample/ping spacing. Always populated on read
    responses (no opt-in flag) per the Targets MVP spec.

    Attributes:
        longitude: Geodetic longitude (EPSG:4326), decimal degrees.
        latitude: Geodetic latitude (EPSG:4326), decimal degrees.
        projected_x: Easting in the project SRID's linear unit.
        projected_y: Northing in the project SRID's linear unit.
        srid: Project SRID (e.g. ``"EPSG:32618"``).
        width: Bounding-box width in SRID linear units, if width_samples set.
        height: Bounding-box height in SRID linear units, if height_pings set.
        shadow: Acoustic-shadow length in SRID linear units, if shadow_samples set.
        linear_unit: SRID's linear unit name (typically ``"meter"``).
    """

    longitude: float
    latitude: float
    projected_x: float
    projected_y: float
    srid: str
    width: float | None = None
    height: float | None = None
    shadow: float | None = None
    linear_unit: str


class Target(TargetBase):
    """Full read shape with database-managed fields and derived block.

    Attributes:
        target_id: Unique identifier for the target.
        sidescan_ping_source_id: FK reference to SidescanPingSource.
        derived: Derived geographic position and SRID-unit dimensions
            (populated server-side; ``None`` only when the line lacks the
            nav/bottom-track state required to compute it).
        created_by_user_id: Authoring user (nullable until auth wiring lands).
        last_modified_by_user_id: Last-editing user (nullable until auth wiring lands).
        created_at: Row creation timestamp (UTC).
        updated_at: Row last-modification timestamp (UTC).
    """

    target_id: UUID
    sidescan_ping_source_id: UUID
    derived: TargetDerived | None = None
    created_by_user_id: UUID | None = None
    last_modified_by_user_id: UUID | None = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)
