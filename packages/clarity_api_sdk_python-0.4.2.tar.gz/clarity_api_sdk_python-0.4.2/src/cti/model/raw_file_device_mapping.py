"""Pydantic model for mapping a raw file to a device."""

import zoneinfo
from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


class SourceSelection(BaseModel):
    """An ``{available, selected}`` pair.

    Used at both levels of ``StreamIdentifier``: outer source URI and
    inner field-role selection.

    Attributes:
        available: All candidate values produced by the scan.
        selected: The currently chosen value; must be one of ``available``.
    """

    available: list[str]
    selected: str


class StreamIdentifier(BaseModel):
    """Two-level source / field selection persisted on RawFileDeviceMapping.

    Mirrors the shape produced by the engine's manifest serializer for
    one stream descriptor (see clarity-engine
    ``pipeline/ingest/manifest_serializer.py``):

    - ``source`` — which packet-level source within the file feeds this
      device (e.g., ``xtf://sidescan(source=ping_header,pair=0)``).
    - ``fields_by_source`` — for each available source URI, which raw
      field provides each role (``samples``, ``timestamp``, ``position``,
      …).

    Attributes:
        source: Outer source-URI selection.
        fields_by_source: Per-source role → field selection. Outer key is
            the source URI; inner key is the role name.
    """

    source: SourceSelection
    fields_by_source: dict[str, dict[str, SourceSelection]]


class RawFileDeviceMappingBase(BaseModel):
    """Base model for raw file device mapping.

    Attributes:
        raw_file_id: Foreign key reference to RawFile.
        device_id: Foreign key reference to Device.
        source_stream_identifier: Two-level source / field-role selection.
        auto_mapped: True for system-generated mappings, False for user
            overrides. Defaults to True.
        input_srid: Spatial reference ID for the input data.
        input_timezone: IANA timezone name for the input data (e.g. Etc/UTC).
    """

    raw_file_id: UUID
    device_id: UUID
    source_stream_identifier: StreamIdentifier
    auto_mapped: bool = True
    input_srid: int = Field(ge=2000, le=900913)
    input_timezone: str

    @field_validator("input_timezone")
    @classmethod
    def validate_iana_timezone(cls, v: str) -> str:
        """Validate that input_timezone is a valid IANA timezone name."""
        if v not in zoneinfo.available_timezones():
            raise ValueError(f"'{v}' is not a valid IANA timezone name")
        return v


class RawFileDeviceMappingCreate(RawFileDeviceMappingBase):
    """Model for creating raw file device mapping data."""


class RawFileDeviceMappingUpdate(RawFileDeviceMappingBase):
    """Model for updating raw file device mapping data.

    Attributes:
        mapping_id: Unique identifier for the mapping.
        created_date: Date and time when the mapping was created.
        updated_date: Date and time when the mapping was last updated.
        updated_by: User who last updated the mapping.

    """


class RawFileDeviceMapping(RawFileDeviceMappingUpdate):
    """Model for raw file device mapping data with database fields.

    Attributes:
        created_date: Date and time when the mapping was created.
        updated_date: Date and time when the mapping was last updated.
        updated_by: User who last updated the mapping.
    """

    mapping_id: UUID
    created_date: datetime
    updated_date: datetime
    updated_by: str

    model_config = ConfigDict(from_attributes=True)


class RawFileDeviceMappingFilter(BaseModel):
    """Model for filtering raw file device mappings.

    Attributes:
        raw_file_id: Raw file ID filter (required).
        device_id: Device ID filter (required).
    """

    raw_file_id: UUID
    device_id: UUID
