"""Raw file state"""

from enum import Enum


class RawFileState(str, Enum):
    """Status of a raw file through upload, scan, and ingest.

    The legal transition graph is enforced server-side; this enum is a
    passthrough carrying the value over the wire. See clarity-server
    `model.raw_file_state` for the authoritative transition rules.
    """

    UPLOADING = "uploading"
    READY = "ready"
    ERROR_UPLOAD = "error_upload"
    SCANNING = "scanning"
    SCANNED = "scanned"
    SCAN_ERROR = "scan_error"
    ERROR_INGEST = "error_ingest"
    INGEST_COMPLETE = "ingest_complete"
