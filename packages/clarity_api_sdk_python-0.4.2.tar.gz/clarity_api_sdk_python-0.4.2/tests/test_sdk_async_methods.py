"""Tests for SonarWizAsyncApi methods: upload_file, process, wait_for_job."""

from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID

import httpx
import pytest

from cti.api.sonar_wiz_async_api import SonarWizAsyncApi

from .conftest import (
    CONFIG_ID,
    JOB_ID,
    RAW_FILE_ID,
    SURVEY_ID,
    make_job_json,
    make_processing_log_json,
    make_raw_file_device_mapping_json,
    make_raw_file_json,
    make_raw_file_with_upload_json,
)


DEVICE_ID = UUID("00000000-0000-0000-0000-000000000099")


def _mock_response(
    json_data: dict, status_code: int = 200, headers: dict | None = None
) -> MagicMock:
    """Create a mock httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.headers = headers or {"content-type": "application/json"}
    resp.raise_for_status.return_value = None
    return resp


def _async_client_mock() -> AsyncMock:
    """Create a mock async httpx client."""
    client = AsyncMock()
    return client


@pytest.mark.asyncio
async def test_upload_file_full_flow(tmp_path: Path):
    """upload_file calls initiate, get presigned URL, upload part, and complete."""
    test_file = tmp_path / "test.xtf"
    test_file.write_bytes(b"sonar data content")

    client = AsyncMock()

    config_resp = _mock_response(
        [
            {
                "raw_file_configuration_id": str(CONFIG_ID),
                "survey_id": str(SURVEY_ID),
                "name": "default",
                "configuration": {},
                "created_date": "2026-01-01T00:00:00Z",
                "updated_date": "2026-01-01T00:00:00Z",
                "updated_by": "test",
            }
        ]
    )
    upload_resp = _mock_response(make_raw_file_with_upload_json())
    url_resp = _mock_response({"url": "https://s3.example.com/part1"})
    complete_resp = _mock_response(make_raw_file_json(state="ready"))

    client.get.side_effect = [config_resp, url_resp]
    client.post.side_effect = [upload_resp, complete_resp]

    api = SonarWizAsyncApi(client)

    s3_response = MagicMock()
    s3_response.raise_for_status.return_value = None
    s3_response.headers = {"ETag": '"abc123"'}

    mock_s3_client = AsyncMock()
    mock_s3_client.__aenter__ = AsyncMock(return_value=mock_s3_client)
    mock_s3_client.__aexit__ = AsyncMock(return_value=False)
    mock_s3_client.put.return_value = s3_response

    with patch(
        "cti.api.sonar_wiz_async_api.httpx.AsyncClient", return_value=mock_s3_client
    ):
        result = await api.upload_file(survey_id=SURVEY_ID, file_path=test_file)

    assert client.get.call_count == 2
    assert client.post.call_count == 2
    assert str(result.raw_file_id) == str(RAW_FILE_ID)
    assert result.state.value == "ready"


@pytest.mark.asyncio
async def test_create_job():
    """create_job sends POST /api/v1/jobs and returns ProcessingJob."""
    client = AsyncMock()
    client.post.return_value = _mock_response(make_job_json(job_type="process"))

    api = SonarWizAsyncApi(client)
    from cti.model.processing_job import ProcessingJobCreate

    result = await api.create_job(
        ProcessingJobCreate(survey_id=SURVEY_ID, job_type="process")
    )

    client.post.assert_called_once()
    call_args = client.post.call_args
    assert call_args[0][0] == "/api/v1/jobs"
    assert result.job_id == JOB_ID
    assert result.status == "pending"


@pytest.mark.asyncio
async def test_process_fetches_full_job():
    """process fetches full job when /process returns job_id."""
    client = AsyncMock()

    process_resp = _mock_response({"job_id": str(JOB_ID)})
    job_resp = _mock_response(make_job_json(status="pending"))

    client.post.return_value = process_resp
    client.get.return_value = job_resp

    api = SonarWizAsyncApi(client)
    result = await api.process(survey_id=SURVEY_ID)

    assert client.post.call_count == 1
    call_args = client.post.call_args
    assert call_args.args[0] == "/api/v1/process"
    assert call_args.kwargs["json"] == {
        "survey_id": str(SURVEY_ID),
        "target_phase": "products",
    }
    assert result.job_id == JOB_ID
    assert result.status == "pending"


@pytest.mark.asyncio
async def test_process_forwards_target_phase():
    """target_phase is included in the POST body."""
    client = AsyncMock()
    client.post.return_value = _mock_response({"job_id": str(JOB_ID)})
    client.get.return_value = _mock_response(make_job_json(status="pending"))

    api = SonarWizAsyncApi(client)
    await api.process(survey_id=SURVEY_ID, target_phase="scan")

    assert client.post.call_args.kwargs["json"]["target_phase"] == "scan"


@pytest.mark.asyncio
async def test_wait_for_job_returns_on_completed():
    """wait_for_job returns immediately when job is already completed."""
    client = AsyncMock()
    client.get.return_value = _mock_response(make_job_json(status="completed"))

    api = SonarWizAsyncApi(client)
    result = await api.wait_for_job(job_id=JOB_ID, timeout=10)

    assert result.status == "completed"
    assert client.get.call_count == 1


@pytest.mark.asyncio
async def test_wait_for_job_returns_on_failed():
    """wait_for_job returns when job fails."""
    client = AsyncMock()
    client.get.return_value = _mock_response(
        make_job_json(status="failed", error="pipeline error")
    )

    api = SonarWizAsyncApi(client)
    result = await api.wait_for_job(job_id=JOB_ID, timeout=10)

    assert result.status == "failed"
    assert result.error == "pipeline error"


@pytest.mark.asyncio
async def test_wait_for_job_polls_then_completes():
    """wait_for_job polls until terminal state is reached."""
    client = AsyncMock()
    client.get.side_effect = [
        _mock_response(make_job_json(status="pending")),
        _mock_response(make_job_json(status="running", progress=0.5)),
        _mock_response(make_job_json(status="completed", progress=1.0)),
    ]

    api = SonarWizAsyncApi(client)
    with patch("cti.api.sonar_wiz_async_api.asyncio.sleep", new_callable=AsyncMock):
        result = await api.wait_for_job(job_id=JOB_ID, timeout=60, poll_interval=1)

    assert result.status == "completed"
    assert client.get.call_count == 3


@pytest.mark.asyncio
async def test_wait_for_job_raises_on_timeout():
    """wait_for_job raises TimeoutError when deadline expires."""
    client = AsyncMock()
    client.get.return_value = _mock_response(make_job_json(status="running"))

    api = SonarWizAsyncApi(client)

    loop = asyncio.get_running_loop()
    original_time = loop.time

    call_count = 0

    def mock_time():
        nonlocal call_count
        call_count += 1
        if call_count <= 2:
            return 0.0
        return 100.0

    with patch("cti.api.sonar_wiz_async_api.asyncio.sleep", new_callable=AsyncMock):
        with patch.object(loop, "time", side_effect=mock_time):
            with pytest.raises(TimeoutError, match="did not complete"):
                await api.wait_for_job(job_id=JOB_ID, timeout=10)


# ── list_processing_logs filter kwargs (WI-0106 A1) ─────────────────────


@pytest.mark.asyncio
async def test_list_processing_logs_no_filters_omits_params():
    """No kwargs → request sent with params=None (preserves existing behavior)."""
    client = AsyncMock()
    client.get.return_value = _mock_response([make_processing_log_json()])

    api = SonarWizAsyncApi(client)
    logs = await api.list_processing_logs()

    assert len(logs) == 1
    client.get.assert_awaited_once_with("/api/v1/processing-logs", params=None)


@pytest.mark.asyncio
async def test_list_processing_logs_all_filters_passed_as_query_params():
    """All three filters compose into the query string; UUIDs stringified."""
    client = AsyncMock()
    client.get.return_value = _mock_response(
        [make_processing_log_json(processing_step="scan", result='{"streams":[]}')]
    )

    api = SonarWizAsyncApi(client)
    logs = await api.list_processing_logs(
        raw_file_id=RAW_FILE_ID,
        survey_id=SURVEY_ID,
        processing_step="scan",
    )

    client.get.assert_awaited_once_with(
        "/api/v1/processing-logs",
        params={
            "raw_file_id": str(RAW_FILE_ID),
            "survey_id": str(SURVEY_ID),
            "processing_step": "scan",
        },
    )
    assert logs[0].processing_step == "scan"
    assert logs[0].result == '{"streams":[]}'
    assert logs[0].processing_hash == "a" * 64


@pytest.mark.asyncio
async def test_list_processing_logs_partial_filter_only_includes_provided():
    """Unset filters are omitted from the query string."""
    client = AsyncMock()
    client.get.return_value = _mock_response([])

    api = SonarWizAsyncApi(client)
    logs = await api.list_processing_logs(
        raw_file_id=RAW_FILE_ID, processing_step="scan"
    )

    client.get.assert_awaited_once_with(
        "/api/v1/processing-logs",
        params={"raw_file_id": str(RAW_FILE_ID), "processing_step": "scan"},
    )
    assert logs == []


@pytest.mark.asyncio
async def test_list_processing_logs_accepts_string_uuid():
    """String UUIDs are accepted and stringified the same way."""
    client = AsyncMock()
    client.get.return_value = _mock_response([])

    api = SonarWizAsyncApi(client)
    await api.list_processing_logs(raw_file_id=str(RAW_FILE_ID))

    client.get.assert_awaited_once_with(
        "/api/v1/processing-logs",
        params={"raw_file_id": str(RAW_FILE_ID)},
    )


# ── get_raw_file_device_mappings filter kwargs (#23) ────────────────────


@pytest.mark.asyncio
async def test_get_raw_file_device_mappings_requires_a_filter():
    """Calling with neither filter raises ValueError before touching the wire."""
    client = AsyncMock()
    api = SonarWizAsyncApi(client)

    with pytest.raises(ValueError, match="raw_file_id or device_id"):
        await api.get_raw_file_device_mappings()

    client.get.assert_not_called()


@pytest.mark.asyncio
async def test_get_raw_file_device_mappings_filters_by_raw_file_id():
    """raw_file_id filter is sent as a query param; UUID stringified."""
    client = AsyncMock()
    client.get.return_value = _mock_response(
        [make_raw_file_device_mapping_json(device_id=DEVICE_ID)]
    )

    api = SonarWizAsyncApi(client)
    mappings = await api.get_raw_file_device_mappings(raw_file_id=RAW_FILE_ID)

    client.get.assert_awaited_once_with(
        "/api/v1/raw-file-device-mappings",
        params={"raw_file_id": str(RAW_FILE_ID)},
    )
    assert len(mappings) == 1
    assert mappings[0].raw_file_id == RAW_FILE_ID
    assert mappings[0].device_id == DEVICE_ID


@pytest.mark.asyncio
async def test_get_raw_file_device_mappings_filters_by_device_id():
    """device_id filter is sent alone when raw_file_id is omitted."""
    client = AsyncMock()
    client.get.return_value = _mock_response([])

    api = SonarWizAsyncApi(client)
    mappings = await api.get_raw_file_device_mappings(device_id=DEVICE_ID)

    client.get.assert_awaited_once_with(
        "/api/v1/raw-file-device-mappings",
        params={"device_id": str(DEVICE_ID)},
    )
    assert mappings == []


@pytest.mark.asyncio
async def test_get_raw_file_device_mappings_accepts_string_uuids():
    """String UUIDs are accepted and stringified the same way."""
    client = AsyncMock()
    client.get.return_value = _mock_response([])

    api = SonarWizAsyncApi(client)
    await api.get_raw_file_device_mappings(
        raw_file_id=str(RAW_FILE_ID), device_id=str(DEVICE_ID)
    )

    client.get.assert_awaited_once_with(
        "/api/v1/raw-file-device-mappings",
        params={"raw_file_id": str(RAW_FILE_ID), "device_id": str(DEVICE_ID)},
    )
