"""Round-trip tests for the RawFileDeviceMapping SDK Pydantic model.

Phase II Step 10 reshaped ``source_stream_identifier`` from a free-form
string to a nested ``StreamIdentifier``. These tests pin the wire shape
the engine and server already agree on so future drift fails loudly.

See clarity-server#104 / #105 and
designs/spec-file-prescan-stream-mapping.md §lines 489–495, 939–953.
"""

from __future__ import annotations

from uuid import uuid4

import pytest
from pydantic import ValidationError

from cti.model.raw_file_device_mapping import (
    RawFileDeviceMappingCreate,
    SourceSelection,
    StreamIdentifier,
)


_SOURCE_URI = "xtf://sidescan(source=ping_header,pair=0)"
_SAMPLE_IDENTIFIER_DICT = {
    "source": {"available": [_SOURCE_URI], "selected": _SOURCE_URI},
    "fields_by_source": {
        _SOURCE_URI: {
            "samples": {"available": ["samples"], "selected": "samples"},
            "timestamp": {"available": ["timestamp"], "selected": "timestamp"},
        }
    },
}


def test_stream_identifier_round_trips_from_dict() -> None:
    """A dict in the manifest-serializer shape parses and serializes back unchanged."""
    ident = StreamIdentifier.model_validate(_SAMPLE_IDENTIFIER_DICT)

    assert isinstance(ident.source, SourceSelection)
    assert ident.source.selected == _SOURCE_URI
    assert ident.fields_by_source[_SOURCE_URI]["samples"].selected == "samples"

    assert ident.model_dump() == _SAMPLE_IDENTIFIER_DICT


def test_create_payload_round_trips_through_json() -> None:
    """End-to-end: build a Create model, serialize to JSON, parse it back."""
    payload = RawFileDeviceMappingCreate(
        raw_file_id=uuid4(),
        device_id=uuid4(),
        source_stream_identifier=StreamIdentifier.model_validate(
            _SAMPLE_IDENTIFIER_DICT
        ),
        input_srid=4326,
        input_timezone="Etc/UTC",
    )

    parsed = RawFileDeviceMappingCreate.model_validate_json(payload.model_dump_json())
    assert parsed == payload
    assert parsed.auto_mapped is True


def test_auto_mapped_defaults_to_true_when_omitted() -> None:
    """``auto_mapped`` is a system-generated default, not required from clients."""
    payload = RawFileDeviceMappingCreate.model_validate(
        {
            "raw_file_id": str(uuid4()),
            "device_id": str(uuid4()),
            "source_stream_identifier": _SAMPLE_IDENTIFIER_DICT,
            "input_srid": 4326,
            "input_timezone": "Etc/UTC",
        }
    )
    assert payload.auto_mapped is True


def test_auto_mapped_false_persists_for_user_overrides() -> None:
    """User-supplied overrides must round-trip ``auto_mapped: false``."""
    payload = RawFileDeviceMappingCreate.model_validate(
        {
            "raw_file_id": str(uuid4()),
            "device_id": str(uuid4()),
            "source_stream_identifier": _SAMPLE_IDENTIFIER_DICT,
            "auto_mapped": False,
            "input_srid": 4326,
            "input_timezone": "Etc/UTC",
        }
    )
    assert payload.auto_mapped is False


def test_string_source_stream_identifier_is_rejected() -> None:
    """The pre-Phase-II free-form string form must no longer validate.

    Pins the breaking change so a future regression that loosens the type
    back to ``str`` fails this test instead of silently re-allowing
    unstructured identifiers.
    """
    with pytest.raises(ValidationError):
        RawFileDeviceMappingCreate.model_validate(
            {
                "raw_file_id": str(uuid4()),
                "device_id": str(uuid4()),
                "source_stream_identifier": "channel-0",
                "input_srid": 4326,
                "input_timezone": "Etc/UTC",
            }
        )
