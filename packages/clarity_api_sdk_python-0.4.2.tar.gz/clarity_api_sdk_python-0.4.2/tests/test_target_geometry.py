"""Unit tests for cti.positioning.target_geometry.derive.

Covers the math contract that clarity-server #120 will rely on:
slant-to-ground range correction, port/starboard side convention,
heading-rotated displacement, sample-domain dimension conversion,
and lat/lon roundtripping through the project SRID.

Also pins the Pydantic shape for ``TargetDerived`` and the
``Target.derived`` field so a regression that drops the derived block
fails loudly here.
"""

from __future__ import annotations

import math
from datetime import datetime, timezone
from uuid import uuid4

import pyproj
import pytest

from cti.model.target import Target, TargetDerived
from cti.positioning.target_geometry import LineState, derive


_NOW = datetime(2026, 5, 5, tzinfo=timezone.utc)
_SRID = "EPSG:32618"  # UTM zone 18N — covers Chesapeake Bay area
# Approximate UTM 18N projection of (-76.40, 38.95) — round numbers used so the
# math in assertions is easy to follow; tests don't depend on exact projection.
_VESSEL_X = 378_700.0
_VESSEL_Y = 4_312_160.0


def _make_target(
    *,
    channel: int = 1,
    sample: int = 0,
    width_samples: int | None = None,
    height_pings: int | None = None,
    shadow_samples: int | None = None,
) -> Target:
    """Build a Target with sane defaults for tests that vary one field."""
    return Target(
        target_id=uuid4(),
        sidescan_ping_source_id=uuid4(),
        channel=channel,
        ping=1000,
        sample=sample,
        width_samples=width_samples,
        height_pings=height_pings,
        shadow_samples=shadow_samples,
        created_at=_NOW,
        updated_at=_NOW,
    )


def _make_line_state(
    *,
    projected_x: float = _VESSEL_X,
    projected_y: float = _VESSEL_Y,
    heading_deg: float = 0.0,
    sample_spacing_units: float = 0.075,
    ping_spacing_units: float = 0.30,
    altitude_units: float | None = None,
) -> LineState:
    """Build a LineState with sane defaults for tests that vary one field."""
    return LineState(
        projected_x=projected_x,
        projected_y=projected_y,
        heading_deg=heading_deg,
        sample_spacing_units=sample_spacing_units,
        ping_spacing_units=ping_spacing_units,
        altitude_units=altitude_units,
    )


# ──────────────────────────────────────────────────────────────────────────
# Position math


def test_zero_sample_yields_vessel_position() -> None:
    """A target at sample=0 sits at the vessel's projected position exactly."""
    ls = _make_line_state()
    derived = derive(_make_target(sample=0), ls, _SRID)

    assert derived.projected_x == pytest.approx(ls.projected_x, abs=1e-9)
    assert derived.projected_y == pytest.approx(ls.projected_y, abs=1e-9)


def test_port_and_starboard_are_mirror_images() -> None:
    """channel=0 and channel=1 at the same sample land equidistant from vessel,
    on opposite sides."""
    ls = _make_line_state()
    port = derive(_make_target(channel=0, sample=200), ls, _SRID)
    starboard = derive(_make_target(channel=1, sample=200), ls, _SRID)
    vessel_x = (port.projected_x + starboard.projected_x) / 2.0
    vessel_y = (port.projected_y + starboard.projected_y) / 2.0

    # Vessel sits exactly between port and starboard targets
    nadir = derive(_make_target(sample=0), ls, _SRID)
    assert vessel_x == pytest.approx(nadir.projected_x, abs=1e-6)
    assert vessel_y == pytest.approx(nadir.projected_y, abs=1e-6)

    # Port is the negative side of the perpendicular axis
    assert port.projected_x < starboard.projected_x


def test_no_altitude_uses_slant_range_directly() -> None:
    """Without altitude_units, ground_range == slant_range = sample × sample_spacing."""
    ls = _make_line_state(heading_deg=0.0, altitude_units=None)
    derived = derive(_make_target(channel=1, sample=200), ls, _SRID)
    nadir = derive(_make_target(sample=0), ls, _SRID)

    # Heading = 0 (north) → starboard is east → +x displacement
    expected_dx = 200 * 0.075  # 15.0 m
    assert derived.projected_x - nadir.projected_x == pytest.approx(
        expected_dx, abs=1e-6
    )
    assert derived.projected_y == pytest.approx(nadir.projected_y, abs=1e-6)


def test_slant_range_corrected_when_altitude_set() -> None:
    """ground_range = sqrt(slant² - altitude²) when altitude < slant."""
    ls = _make_line_state(heading_deg=0.0, altitude_units=10.0)
    derived = derive(_make_target(channel=1, sample=200), ls, _SRID)
    nadir = derive(_make_target(sample=0), ls, _SRID)

    slant = 200 * 0.075  # 15 m
    expected_ground = math.sqrt(slant**2 - 10.0**2)  # √125 ≈ 11.180
    assert derived.projected_x - nadir.projected_x == pytest.approx(
        expected_ground, abs=1e-6
    )


def test_slant_range_used_when_altitude_exceeds_slant() -> None:
    """If altitude > slant range, the math would go imaginary — fall back to slant."""
    ls = _make_line_state(heading_deg=0.0, altitude_units=50.0)
    derived = derive(_make_target(channel=1, sample=200), ls, _SRID)
    nadir = derive(_make_target(sample=0), ls, _SRID)

    expected_dx = 200 * 0.075  # uncorrected
    assert derived.projected_x - nadir.projected_x == pytest.approx(
        expected_dx, abs=1e-6
    )


def test_heading_east_displaces_starboard_target_southward() -> None:
    """Heading 90° (east) → starboard is south → negative y displacement."""
    ls = _make_line_state(heading_deg=90.0)
    derived = derive(_make_target(channel=1, sample=200), ls, _SRID)
    nadir = derive(_make_target(sample=0), ls, _SRID)

    expected_dy = -200 * 0.075  # 15 m south
    assert derived.projected_y - nadir.projected_y == pytest.approx(
        expected_dy, abs=1e-6
    )
    assert derived.projected_x == pytest.approx(nadir.projected_x, abs=1e-6)


# ──────────────────────────────────────────────────────────────────────────
# Sample-domain → linear-unit dimension conversion


def test_width_height_shadow_convert_using_their_respective_spacings() -> None:
    """width_samples × sample_spacing_units, height_pings × ping_spacing_units,
    shadow_samples × sample_spacing_units."""
    ls = _make_line_state(sample_spacing_units=0.075, ping_spacing_units=0.30)
    target = _make_target(width_samples=10, height_pings=8, shadow_samples=15)
    derived = derive(target, ls, _SRID)

    assert derived.width == pytest.approx(10 * 0.075)
    assert derived.height == pytest.approx(8 * 0.30)
    assert derived.shadow == pytest.approx(15 * 0.075)


def test_unset_dimensions_pass_through_as_none() -> None:
    """If width_samples / height_pings / shadow_samples are None, derived
    width / height / shadow are None — not zero."""
    derived = derive(_make_target(), _make_line_state(), _SRID)

    assert derived.width is None
    assert derived.height is None
    assert derived.shadow is None


# ──────────────────────────────────────────────────────────────────────────
# SRID handling


def test_linear_unit_comes_from_srid_metadata() -> None:
    """EPSG:32618 reports its linear unit as 'metre' (UK English per EPSG)."""
    derived = derive(_make_target(), _make_line_state(), "EPSG:32618")
    assert derived.linear_unit == "metre"


def test_srid_string_round_trips_into_derived_block() -> None:
    """The SRID the caller passed is the SRID the derived block reports."""
    derived = derive(_make_target(), _make_line_state(), "EPSG:32619")
    assert derived.srid == "EPSG:32619"


def test_projected_to_geodetic_inverse_is_consistent() -> None:
    """Projecting vessel position back to geodetic and forward again
    recovers the same projected XY to centimeter precision."""
    ls = _make_line_state()
    derived = derive(_make_target(sample=0), ls, _SRID)

    forward = pyproj.Transformer.from_crs("EPSG:4326", _SRID, always_xy=True)
    rx, ry = forward.transform(derived.longitude, derived.latitude)
    assert rx == pytest.approx(ls.projected_x, abs=1e-2)
    assert ry == pytest.approx(ls.projected_y, abs=1e-2)


# ──────────────────────────────────────────────────────────────────────────
# Pydantic shape pinning


def test_target_derived_round_trips_through_json() -> None:
    """TargetDerived serializes and deserializes losslessly."""
    derived = TargetDerived(
        longitude=-76.123,
        latitude=38.456,
        projected_x=412345.67,
        projected_y=4256789.01,
        srid="EPSG:32618",
        width=4.8,
        height=6.0,
        shadow=3.6,
        linear_unit="metre",
    )
    parsed = TargetDerived.model_validate_json(derived.model_dump_json())
    assert parsed == derived


def test_target_carries_optional_derived_block() -> None:
    """Target.derived is a TargetDerived | None field, defaulting to None."""
    target = _make_target()
    assert target.derived is None

    target_with_derived = target.model_copy(
        update={
            "derived": TargetDerived(
                longitude=0.0,
                latitude=0.0,
                projected_x=0.0,
                projected_y=0.0,
                srid="EPSG:4326",
                linear_unit="degree",
            )
        }
    )
    assert target_with_derived.derived is not None
    assert target_with_derived.derived.srid == "EPSG:4326"
