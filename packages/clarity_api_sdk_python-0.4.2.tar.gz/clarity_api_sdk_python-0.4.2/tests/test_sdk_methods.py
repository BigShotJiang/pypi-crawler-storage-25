"""Tests for SonarWizApi sync methods: upload_file, process, wait_for_job."""

from __future__ import annotations

import time
from pathlib import Path
from unittest.mock import MagicMock, mock_open, patch
from uuid import UUID

import httpx
import pytest

from cti.api.sonar_wiz_api import SonarWizApi
from cti.model.processing_job import ProcessingJob

from .conftest import (
    CONFIG_ID,
    JOB_ID,
    RAW_FILE_ID,
    SURVEY_ID,
    make_job_json,
    make_processing_log_json,
    make_raw_file_device_mapping_json,
    make_raw_file_json,
    make_raw_file_with_upload_json,
)


DEVICE_ID = UUID("00000000-0000-0000-0000-000000000099")


def _mock_response(
    json_data: dict, status_code: int = 200, headers: dict | None = None
) -> MagicMock:
    """Create a mock httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.headers = headers or {"content-type": "application/json"}
    resp.raise_for_status.return_value = None
    return resp


class TestUploadFile:
    """Tests for SonarWizApi.upload_file."""

    def test_upload_file_full_flow(self, tmp_path: Path):
        """upload_file calls initiate, get presigned URL, upload part, and complete."""
        # Create a small test file (< 5MB so it uploads in one chunk)
        test_file = tmp_path / "test.xtf"
        test_file.write_bytes(b"sonar data content")

        client = MagicMock(spec=httpx.Client)

        # 1. GET configs
        config_resp = _mock_response(
            [
                {
                    "raw_file_configuration_id": str(CONFIG_ID),
                    "survey_id": str(SURVEY_ID),
                    "name": "default",
                    "configuration": {},
                    "created_date": "2026-01-01T00:00:00Z",
                    "updated_date": "2026-01-01T00:00:00Z",
                    "updated_by": "test",
                }
            ]
        )

        # 2. POST /rawfiles/upload
        upload_resp = _mock_response(make_raw_file_with_upload_json())

        # 3. GET presigned URL
        url_resp = _mock_response({"url": "https://s3.example.com/part1"})

        # 4. POST /upload-complete
        complete_resp = _mock_response(make_raw_file_json(state="ready"))

        client.get.side_effect = [config_resp, url_resp]
        client.post.side_effect = [upload_resp, complete_resp]

        api = SonarWizApi(client)

        # Mock the S3 client PUT call
        s3_response = MagicMock()
        s3_response.raise_for_status.return_value = None
        s3_response.headers = {"ETag": '"abc123"'}

        with patch("cti.api.sonar_wiz_api.httpx.Client") as mock_s3_cls:
            mock_s3_client = MagicMock()
            mock_s3_client.__enter__ = MagicMock(return_value=mock_s3_client)
            mock_s3_client.__exit__ = MagicMock(return_value=False)
            mock_s3_client.put.return_value = s3_response
            mock_s3_cls.return_value = mock_s3_client

            result = api.upload_file(survey_id=SURVEY_ID, file_path=test_file)

        # Verify the right endpoints were called
        assert client.get.call_count == 2
        assert client.post.call_count == 2

        # Initiate upload
        assert "/api/v1/rawfiles/upload" in str(client.post.call_args_list[0])
        # Complete upload
        assert "/upload-complete" in str(client.post.call_args_list[1])
        # Presigned URL
        assert "/upload-parts/" in str(client.get.call_args_list[1])

        assert str(result.raw_file_id) == str(RAW_FILE_ID)
        assert result.state.value == "ready"

    def test_upload_file_with_explicit_config(self, tmp_path: Path):
        """upload_file skips config lookup when raw_file_configuration_id is provided."""
        test_file = tmp_path / "test.xtf"
        test_file.write_bytes(b"data")

        client = MagicMock(spec=httpx.Client)

        upload_resp = _mock_response(make_raw_file_with_upload_json())
        url_resp = _mock_response({"url": "https://s3.example.com/part1"})
        complete_resp = _mock_response(make_raw_file_json(state="ready"))

        client.get.side_effect = [url_resp]
        client.post.side_effect = [upload_resp, complete_resp]

        api = SonarWizApi(client)

        s3_response = MagicMock()
        s3_response.raise_for_status.return_value = None
        s3_response.headers = {"ETag": '"abc123"'}

        with patch("cti.api.sonar_wiz_api.httpx.Client") as mock_s3_cls:
            mock_s3_client = MagicMock()
            mock_s3_client.__enter__ = MagicMock(return_value=mock_s3_client)
            mock_s3_client.__exit__ = MagicMock(return_value=False)
            mock_s3_client.put.return_value = s3_response
            mock_s3_cls.return_value = mock_s3_client

            result = api.upload_file(
                survey_id=SURVEY_ID,
                file_path=test_file,
                raw_file_configuration_id=CONFIG_ID,
            )

        # Should NOT call configs endpoint — only presigned URL GET
        assert client.get.call_count == 1
        assert "/rawfileconfigurations" not in str(client.get.call_args_list[0])


class TestCreateJob:
    """Tests for SonarWizApi.create_job."""

    def test_create_job(self):
        """create_job sends POST /api/v1/jobs and returns ProcessingJob."""
        client = MagicMock(spec=httpx.Client)
        client.post.return_value = _mock_response(make_job_json(job_type="process"))

        api = SonarWizApi(client)
        from cti.model.processing_job import ProcessingJobCreate

        result = api.create_job(
            ProcessingJobCreate(survey_id=SURVEY_ID, job_type="process")
        )

        client.post.assert_called_once()
        call_args = client.post.call_args
        assert call_args[0][0] == "/api/v1/jobs"
        assert result.job_id == JOB_ID
        assert result.status == "pending"


class TestProcess:
    """Tests for SonarWizApi.process."""

    def test_process_with_job_id_response(self):
        """process fetches full job when /process returns job_id."""
        client = MagicMock(spec=httpx.Client)

        # POST /process returns {job_id: ...}
        process_resp = _mock_response({"job_id": str(JOB_ID)})
        # GET /jobs/{id} returns full job
        job_resp = _mock_response(make_job_json(status="pending"))

        client.post.return_value = process_resp
        client.get.return_value = job_resp

        api = SonarWizApi(client)
        result = api.process(survey_id=SURVEY_ID)

        assert client.post.call_count == 1
        call_args = client.post.call_args
        assert call_args.args[0] == "/api/v1/process"
        assert call_args.kwargs["json"] == {
            "survey_id": str(SURVEY_ID),
            "target_phase": "products",
        }
        assert client.get.call_count == 1  # fetches full job
        assert result.job_id == JOB_ID
        assert result.status == "pending"

    def test_process_forwards_target_phase(self):
        """target_phase is included in the POST body."""
        client = MagicMock(spec=httpx.Client)
        client.post.return_value = _mock_response({"job_id": str(JOB_ID)})
        client.get.return_value = _mock_response(make_job_json(status="pending"))

        api = SonarWizApi(client)
        api.process(survey_id=SURVEY_ID, target_phase="scan")

        assert client.post.call_args.kwargs["json"]["target_phase"] == "scan"


class TestWaitForJob:
    """Tests for SonarWizApi.wait_for_job."""

    def test_wait_for_job_returns_on_completed(self):
        """wait_for_job returns immediately when job is already completed."""
        client = MagicMock(spec=httpx.Client)
        client.get.return_value = _mock_response(make_job_json(status="completed"))

        api = SonarWizApi(client)
        result = api.wait_for_job(job_id=JOB_ID, timeout=10)

        assert result.status == "completed"
        assert client.get.call_count == 1  # Only one poll needed

    def test_wait_for_job_returns_on_failed(self):
        """wait_for_job returns (not raises) when job fails."""
        client = MagicMock(spec=httpx.Client)
        client.get.return_value = _mock_response(
            make_job_json(status="failed", error="pipeline error")
        )

        api = SonarWizApi(client)
        result = api.wait_for_job(job_id=JOB_ID, timeout=10)

        assert result.status == "failed"
        assert result.error == "pipeline error"

    def test_wait_for_job_polls_then_completes(self):
        """wait_for_job polls until terminal state is reached."""
        client = MagicMock(spec=httpx.Client)
        client.get.side_effect = [
            _mock_response(make_job_json(status="pending")),
            _mock_response(make_job_json(status="running", progress=0.5)),
            _mock_response(make_job_json(status="completed", progress=1.0)),
        ]

        api = SonarWizApi(client)
        with patch("cti.api.sonar_wiz_api.time.sleep"):
            result = api.wait_for_job(job_id=JOB_ID, timeout=60, poll_interval=1)

        assert result.status == "completed"
        assert client.get.call_count == 3

    def test_wait_for_job_raises_on_timeout(self):
        """wait_for_job raises TimeoutError when deadline expires."""
        client = MagicMock(spec=httpx.Client)
        client.get.return_value = _mock_response(make_job_json(status="running"))

        api = SonarWizApi(client)

        # Use very short timeout and mock sleep to avoid real delays
        with patch("cti.api.sonar_wiz_api.time.sleep"):
            with patch("cti.api.sonar_wiz_api.time.monotonic") as mock_mono:
                # First call (deadline calc): 0, then loop: 0, 0 (check), 100 (past deadline)
                mock_mono.side_effect = [0.0, 0.0, 0.0, 100.0]
                with pytest.raises(TimeoutError, match="did not complete"):
                    api.wait_for_job(job_id=JOB_ID, timeout=10)


# ── list_processing_logs filter kwargs (WI-0106 A1) ─────────────────────


def test_list_processing_logs_no_filters_omits_params():
    """No kwargs → request sent with params=None."""
    client = MagicMock()
    client.get.return_value = _mock_response([make_processing_log_json()])

    api = SonarWizApi(client)
    logs = api.list_processing_logs()

    assert len(logs) == 1
    client.get.assert_called_once_with("/api/v1/processing-logs", params=None)


def test_list_processing_logs_all_filters_passed_as_query_params():
    """All three filters compose into the query string."""
    client = MagicMock()
    client.get.return_value = _mock_response(
        [make_processing_log_json(processing_step="scan")]
    )

    api = SonarWizApi(client)
    api.list_processing_logs(
        raw_file_id=RAW_FILE_ID,
        survey_id=SURVEY_ID,
        processing_step="scan",
    )

    client.get.assert_called_once_with(
        "/api/v1/processing-logs",
        params={
            "raw_file_id": str(RAW_FILE_ID),
            "survey_id": str(SURVEY_ID),
            "processing_step": "scan",
        },
    )


def test_list_processing_logs_partial_filter_only_includes_provided():
    """Unset filters are omitted from the query string."""
    client = MagicMock()
    client.get.return_value = _mock_response([])

    api = SonarWizApi(client)
    logs = api.list_processing_logs(survey_id=SURVEY_ID)

    client.get.assert_called_once_with(
        "/api/v1/processing-logs",
        params={"survey_id": str(SURVEY_ID)},
    )
    assert logs == []


# ── get_raw_file_device_mappings filter kwargs (#23) ────────────────────


def test_get_raw_file_device_mappings_requires_a_filter():
    """Calling with neither filter raises ValueError before touching the wire."""
    client = MagicMock()
    api = SonarWizApi(client)

    with pytest.raises(ValueError, match="raw_file_id or device_id"):
        api.get_raw_file_device_mappings()

    client.get.assert_not_called()


def test_get_raw_file_device_mappings_filters_by_raw_file_id():
    """raw_file_id filter is sent as a query param; UUID stringified."""
    client = MagicMock()
    client.get.return_value = _mock_response(
        [make_raw_file_device_mapping_json(device_id=DEVICE_ID)]
    )

    api = SonarWizApi(client)
    mappings = api.get_raw_file_device_mappings(raw_file_id=RAW_FILE_ID)

    client.get.assert_called_once_with(
        "/api/v1/raw-file-device-mappings",
        params={"raw_file_id": str(RAW_FILE_ID)},
    )
    assert len(mappings) == 1
    assert mappings[0].raw_file_id == RAW_FILE_ID
    assert mappings[0].device_id == DEVICE_ID


def test_get_raw_file_device_mappings_filters_by_device_id():
    """device_id filter is sent alone when raw_file_id is omitted."""
    client = MagicMock()
    client.get.return_value = _mock_response([])

    api = SonarWizApi(client)
    mappings = api.get_raw_file_device_mappings(device_id=DEVICE_ID)

    client.get.assert_called_once_with(
        "/api/v1/raw-file-device-mappings",
        params={"device_id": str(DEVICE_ID)},
    )
    assert mappings == []


def test_get_raw_file_device_mappings_accepts_string_uuids():
    """String UUIDs are accepted and stringified the same way."""
    client = MagicMock()
    client.get.return_value = _mock_response([])

    api = SonarWizApi(client)
    api.get_raw_file_device_mappings(
        raw_file_id=str(RAW_FILE_ID), device_id=str(DEVICE_ID)
    )

    client.get.assert_called_once_with(
        "/api/v1/raw-file-device-mappings",
        params={"raw_file_id": str(RAW_FILE_ID), "device_id": str(DEVICE_ID)},
    )
