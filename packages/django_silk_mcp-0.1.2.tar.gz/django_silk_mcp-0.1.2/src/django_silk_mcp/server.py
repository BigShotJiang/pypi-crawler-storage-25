from asgiref.sync import sync_to_async
from mcp_server.djangomcp import DjangoMCP

_INSTRUCTIONS = (
    "This is the Silk Profiler MCP server — it exposes django-silk profiling data as tools "
    "for diagnosing and optimizing Django endpoints.\n\n"
    "REQUIRED FIRST STEP — NO EXCEPTIONS: Before calling any other tool from this server, "
    "you MUST read the `silk://guide` MCP resource using the ReadMcpResourceTool "
    "(NOT a silk-mcp tool — it is an MCP resource, accessed via ReadMcpResourceTool with "
    'server="silk-mcp" and uri="silk://guide"). '
    "Do not skip this step even if you believe you already have enough context. "
    "Calling any other silk-mcp tool before reading silk://guide is an error."
)


def create_server() -> DjangoMCP:
    mcp = DjangoMCP(name="silk-mcp", stateless=True, instructions=_INSTRUCTIONS)

    # Imports are deferred because tool/resource modules import silk.models,
    # which requires django.setup() to have run first.
    from django_silk_mcp.tools import (
        analysis,
        discovery,
        explain,
        overfetch,
        profiling,
        prompts,
        resources,
    )

    resources.register(mcp)
    discovery.register(mcp)
    analysis.register(mcp)
    explain.register(mcp)
    overfetch.register(mcp)
    profiling.register(mcp)
    prompts.register(mcp)

    # FastMCP calls sync tool functions directly inside the async event loop created by
    # DjangoMCP, triggering Django's SynchronousOnlyOperation guard. Wrapping them with
    # sync_to_async moves each call to a thread pool, fixing all tools in one place.
    for tool in mcp._tool_manager._tools.values():
        if not tool.is_async:
            tool.fn = sync_to_async(tool.fn)
            tool.is_async = True

    return mcp
