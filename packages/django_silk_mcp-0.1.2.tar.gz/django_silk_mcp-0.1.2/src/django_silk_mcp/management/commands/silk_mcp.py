from django.core.management.base import BaseCommand

from django_silk_mcp.server import create_server


class Command(BaseCommand):
    help = "Start the Silk MCP server"

    def handle(self, *args, **options):
        server = create_server()
        server.run()
