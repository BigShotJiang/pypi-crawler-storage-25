"""
ComfyUI Update System.

Migrated to uv — no raw pip.
Handles:
- ComfyUI core update (git pull)
- Custom nodes update via manifest
- Python dependencies update
- Triton / SageAttention re-install
"""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING

from src import __version__
from src.config import load_dependencies
from src.enums import InstallerFatalError
from src.utils.commands import CommandError, run_and_log
from src.utils.logging import InstallerLogger, setup_logger
from src.utils.packaging import uv_install
from src.utils.prompts import confirm

if TYPE_CHECKING:
    from pathlib import Path


def update_comfyui_core(comfy_path: Path, log: InstallerLogger) -> None:
    """Update ComfyUI core via git pull."""
    log.step("Updating ComfyUI Core")

    if not comfy_path.exists():
        log.error("ComfyUI directory not found!")
        return

    log.item("Pulling latest changes...")
    try:
        run_and_log("git", ["-C", str(comfy_path), "pull", "--ff-only"])
        log.sub("ComfyUI updated.", style="success")
    except CommandError:
        log.warning("Git pull failed. You may have local changes.", level=2)
        log.info("Try: git -C ComfyUI stash && git -C ComfyUI pull")


def update_custom_nodes(
    python_exe: Path,
    comfy_path: Path,
    install_path: Path,
    log: InstallerLogger,
    *,
    node_tier: str = "full",
) -> None:
    """Update bundled custom nodes. User-installed nodes are NEVER touched.

    Merges new nodes from the source manifest (additive-only) so that
    user customizations are preserved while newly added nodes are
    picked up on every update.
    """

    from src.installer.environment import find_source_scripts
    from src.installer.nodes import load_manifest, update_all_nodes

    scripts_dir = install_path / "scripts"
    manifest_path = scripts_dir / "custom_nodes.json"

    # Merge new nodes from source (additive-only — never overwrites user changes)
    source_dir = find_source_scripts()
    if source_dir:
        source_manifest = source_dir / "custom_nodes.json"
        if source_manifest.exists():
            scripts_dir.mkdir(parents=True, exist_ok=True)
            added = _merge_node_manifests(source_manifest, manifest_path, log)
            if added > 0:
                log.item(f"custom_nodes.json: {added} new node(s) added from source.", style="cyan")
            else:
                log.sub("custom_nodes.json is up to date.", style="success")

    if not manifest_path.exists():
        log.skip_step("Custom Nodes — manifest not found")
        return

    custom_nodes_dir = comfy_path / "custom_nodes"
    manifest = load_manifest(manifest_path)

    # Filter by tier so only the selected bundle is installed
    from src.installer.nodes import filter_by_tier
    manifest = filter_by_tier(manifest, node_tier)

    update_all_nodes(manifest, custom_nodes_dir, python_exe, log)

    # Provision nunchaku_versions.json during updates as well
    # (Handles Docker environments where nodes are skipped during initial build)
    nunchaku_src = scripts_dir / "nunchaku_versions.json"
    if not nunchaku_src.exists() and source_dir:
        nunchaku_src = source_dir / "nunchaku_versions.json"

    nunchaku_dst = custom_nodes_dir / "ComfyUI-nunchaku" / "nunchaku_versions.json"
    if nunchaku_src.exists() and nunchaku_dst.parent.exists():
        import shutil
        shutil.copy2(nunchaku_src, nunchaku_dst)
        log.sub("  nunchaku_versions.json provisioned.", style="success")

    # Ensure ComfyUI-Manager uses uv (mirrors PS installer's Set-ManagerUseUv)
    from src.installer.dependencies import configure_manager_uv
    configure_manager_uv(install_path, log)


def update_dependencies(
    python_exe: Path,
    comfy_path: Path,
    install_path: Path,
    log: InstallerLogger,
) -> None:
    """Update Python dependencies via uv."""
    log.step("Updating Python Dependencies")

    deps_file = install_path / "scripts" / "dependencies.json"
    if not deps_file.exists():
        log.warning("dependencies.json not found. Skipping.", level=1)
        return

    deps = load_dependencies(deps_file)

    # Update ComfyUI requirements — filter torch packages to avoid PyPI
    # overwriting the CUDA versions with CPU/generic builds.
    from src.installer.dependencies import _filter_torch_from_requirements

    req_file = comfy_path / deps.pip_packages.comfyui_requirements
    if req_file.exists():
        log.item("Updating ComfyUI requirements...")
        filtered = _filter_torch_from_requirements(req_file)
        uv_install(python_exe, requirements=filtered, upgrade=True)

    # Detect CUDA tag (used by standard packages, wheels, and optional torch update)
    from src.installer.optimizations import _get_cuda_version_from_torch

    cuda_ver = _get_cuda_version_from_torch(python_exe)
    cuda_tag: str | None = None
    if cuda_ver:
        try:
            parts = cuda_ver.split(".")
            from src.utils.gpu import cuda_tag_from_version
            cuda_tag = cuda_tag_from_version((int(parts[0]), int(parts[1])))
        except (ValueError, IndexError):
            pass

    if cuda_tag is None:
        # On macOS, keep None — there is no CUDA at all
        import sys
        if sys.platform != "darwin":
            supported = deps.pip_packages.supported_cuda_tags
            cuda_tag = supported[0] if supported else "cu130"

    # Install/update standard packages (insightface, facexlib, etc.)
    from src.installer.dependencies import install_python_packages, install_wheels
    install_python_packages(python_exe, deps, log, cuda_tag=cuda_tag)

    # Install/update wheel packages (nunchaku)
    install_wheels(python_exe, install_path, deps, log, cuda_tag=cuda_tag)

    # Update torch
    if confirm("Update PyTorch? (Only if there's a new CUDA version)"):
        torch_cfg = deps.pip_packages.get_torch(cuda_tag)
        if torch_cfg:
            torch_pkgs = torch_cfg.packages.split()
            log.item(f"Updating PyTorch [{cuda_tag}]...")
            uv_install(
                python_exe,
                torch_pkgs,
                index_url=torch_cfg.index_url,
                upgrade=True,
            )
        else:
            log.warning(f"No PyTorch config for '{cuda_tag}'. Skipping torch update.", level=1)


def run_update(install_path: Path, *, verbose: bool = False, node_tier: str = "full", gpu_only: bool = False) -> None:
    """
    Run the full update process.

    Args:
        install_path: Root installation directory.
        verbose: Show detailed subprocess output.
        node_tier: Custom nodes bundle tier — 'minimal', 'umeairt', or 'full'.
        gpu_only: If ``True``, skip everything except GPU optimizations.
            Used when only the GPU changed between pod restarts.
    """
    total = 3 if gpu_only else 6
    log = setup_logger(
        log_file=install_path / "logs" / "update_log.txt",
        total_steps=total,
        verbose=verbose,
    )
    log.banner("UmeAiRT", "ComfyUI — Updater", __version__)

    comfy_path = install_path / "ComfyUI"
    scripts_dir = install_path / "scripts"

    # Detect python executable
    python_exe = _detect_python(scripts_dir, log)

    if gpu_only:
        # GPU-only mode: skip git pull, nodes, deps, and model scan.
        # Only reinstall GPU optimizations (SageAttention, Triton, etc.)
        log.step("GPU Optimizations (GPU change detected)")
        log.item("Reinstalling GPU-specific packages for new hardware...", style="cyan")

        # Uninstall old GPU packages first so they get cleanly replaced
        _uninstall_gpu_packages(python_exe, log)

        _install_optimizations(python_exe, comfy_path, install_path, log)

        log.step("GPU Optimization Complete!")
        log.success("GPU packages reinstalled for new hardware.", level=1)
        return

    # --- Full update mode ---
    # Run update steps
    update_comfyui_core(comfy_path, log)
    update_custom_nodes(python_exe, comfy_path, install_path, log, node_tier=node_tier)
    update_dependencies(python_exe, comfy_path, install_path, log)

    # Model security scan (non-blocking)
    _scan_models_warning(install_path, log)

    # Install/update GPU optimizations (SageAttention, Triton, Flash-Attn)
    _install_optimizations(python_exe, comfy_path, install_path, log)

    log.step("Update Complete!")
    log.success("All components have been updated.", level=1)


def _merge_node_manifests(
    source_path: Path,
    dest_path: Path,
    log: InstallerLogger,
) -> int:
    """Merge source manifest into dest (additive-only).

    New nodes (by name) are appended. Existing nodes are never
    modified or removed, preserving user customizations.

    If *dest_path* does not exist, the source is copied as-is.

    Args:
        source_path: Path to the upstream manifest.
        dest_path: Path to the installed manifest (may not exist).
        log: Installer logger.

    Returns:
        Number of new nodes added.
    """
    import json
    import shutil

    if not dest_path.exists():
        shutil.copy2(source_path, dest_path)
        # Count nodes in the source for reporting
        with open(source_path, encoding="utf-8") as f:
            data = json.load(f)
        return len(data.get("nodes", []))

    with open(source_path, encoding="utf-8") as f:
        src_data = json.load(f)
    with open(dest_path, encoding="utf-8") as f:
        dst_data = json.load(f)

    existing_names = {n["name"] for n in dst_data.get("nodes", [])}
    new_nodes = [n for n in src_data.get("nodes", []) if n["name"] not in existing_names]

    if new_nodes:
        dst_data.setdefault("nodes", []).extend(new_nodes)
        with open(dest_path, "w", encoding="utf-8") as f:
            json.dump(dst_data, f, indent=2, ensure_ascii=False)

    return len(new_nodes)


def _detect_python(scripts_dir: Path, log: InstallerLogger) -> Path:
    """Detect the Python executable from the install type."""
    import sys

    install_type_file = scripts_dir / "install_type"

    if install_type_file.exists():
        # Read install type (venv or conda)
        install_type = install_type_file.read_text(encoding="utf-8").strip()

        if install_type == "venv":
            if sys.platform == "win32":
                venv_py = scripts_dir / "venv" / "Scripts" / "python.exe"
            else:
                venv_py = scripts_dir / "venv" / "bin" / "python"

            if venv_py.exists():
                log.item(f"Venv Python detected: {venv_py}", style="cyan")
                return venv_py

        elif install_type == "conda":
            conda_env = scripts_dir / "conda_env"
            if sys.platform == "win32":
                conda_py = conda_env / "python.exe"
            else:
                conda_py = conda_env / "bin" / "python"

            if conda_py.exists():
                log.item(f"Conda Python detected: {conda_py}", style="cyan")
                return conda_py

    log.error("Could not determine venv Python. Is this a valid installation?")
    log.item("Expected 'install_type' file in scripts/ directory.")
    raise InstallerFatalError("Could not determine venv Python. Is this a valid installation?")


def _scan_models_warning(install_path: Path, log: InstallerLogger) -> None:
    """Run a lightweight model security scan and warn about unsafe files.

    Non-blocking — only prints a warning, never halts the update.
    """
    log.step("Model Security Scan")

    models_dir = install_path / "models"
    if not models_dir.exists():
        log.sub("No models directory found. Skipping.", style="dim")
        return

    try:
        from src.utils.model_scanner import scan_models_directory

        summary = scan_models_directory(models_dir)

        if summary.total_scanned == 0:
            log.sub("No pickle-based model files found. All safe! ✅", style="success")
            return

        if summary.unsafe_count > 0:
            log.warning(
                f"{summary.unsafe_count} potentially unsafe model file(s) detected!",
                level=1,
            )
            log.sub(
                "Run 'umeairt-comfyui-installer scan-models' for details.",
                style="cyan",
            )
        else:
            log.sub(
                f"Scanned {summary.total_scanned} pickle-based model(s) — all clean. ✅",
                style="success",
            )
    except Exception:  # noqa: BLE001
        log.sub("Scanner unavailable. Install picklescan for model scanning.", style="dim")


def _install_optimizations(
    python_exe: Path,
    comfy_path: Path,
    install_path: Path,
    log: InstallerLogger,
) -> None:
    """Install/verify GPU optimizations (SageAttention, Triton, Flash-Attn).

    Non-blocking — failures are logged but never halt the update.
    """
    log.step("GPU Optimizations")

    deps_file = install_path / "scripts" / "dependencies.json"
    if not deps_file.exists():
        log.sub("dependencies.json not found. Skipping.", style="dim")
        return

    try:
        deps = load_dependencies(deps_file)
        from src.installer.optimizations import install_optimizations
        install_optimizations(python_exe, comfy_path, install_path, deps, log)
    except Exception as e:  # noqa: BLE001
        log.warning(f"GPU optimization install failed: {e}", level=2)


def _uninstall_gpu_packages(
    python_exe: Path,
    log: InstallerLogger,
) -> None:
    """Uninstall GPU-specific packages before reinstalling for a new GPU.

    Removes packages that are compiled for a specific compute capability
    (e.g. SageAttention wheels are per-SM version). This ensures clean
    replacement when the GPU changes between pod restarts.

    Non-blocking — failures are silently ignored.

    Args:
        python_exe: Path to the venv Python executable.
        log: Installer logger for user-facing messages.
    """
    gpu_packages = [
        "triton",
        "triton-windows",
        "sageattention",
        "sageattn3",
        "flash-attn",
    ]

    for pkg in gpu_packages:
        with contextlib.suppress(CommandError):
            run_and_log(
                str(python_exe), ["-m", "pip", "uninstall", "-y", pkg],
                timeout=30,
            )

    log.sub("Old GPU packages removed.", style="dim")

