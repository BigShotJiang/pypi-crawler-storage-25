import pygame
from pgzero.actor import Actor as BaseActor

class Actor(BaseActor):
    def __init__(self, image, pos=(0,0), size=None):
        super().__init__(image, pos=pos)

        self.original = self._surf.copy()

        if size:
            self.set_size(size)

    def set_size(self, size):
        w, h = size
        self._surf = pygame.transform.scale(self.original, (w, h))
        self.width = w
        self.height = h
