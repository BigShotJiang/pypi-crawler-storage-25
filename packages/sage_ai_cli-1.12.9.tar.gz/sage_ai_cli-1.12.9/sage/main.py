"""Sage CLI — local-first AI coding assistant.

Usage:
  sage run                              Interactive coding agent (Claude Code-like)
  sage chat                             Interactive chat session
  sage ask "explain quicksort"          One-shot prompt
  sage ask -f script.py "explain"       Ask about a file
  cat file.py | sage ask "explain"      Pipe input
  sage models                           List available models
  sage config show                      Show current config
  sage config set <key> <value>         Set a config value
"""

from __future__ import annotations

import json as _json
import re
import signal
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

import typer
from typing_extensions import Annotated

from sage import __version__
from sage.config import (
    SageConfig,
    load_config,
    save_config,
    set_config_value,
    get_config_value,
)
from sage.core import renderer
from sage.core.engine import ConversationEngine
from sage.core.router import ProviderRouter
from sage.providers.base import ProviderBase, ModelInfo
from sage.providers.gemini import GeminiProvider
from sage.providers.llama_cpp import LlamaCppProvider
from sage.providers.openai_compat import (
    build_openai_compat_providers,
    OllamaProvider,
)
from sage.models.catalog import (
    MODEL_CATALOG,
    CATALOG_BY_NAME,
    search_catalog,
    get_recommended_models,
    OLLAMA_CATALOG,
    OLLAMA_BY_NAME,
    search_ollama_catalog,
    get_recommended_ollama_models,
    get_ollama_models_by_category,
)
from sage.models.downloader import (
    download_model,
    register_model,
    is_downloaded,
    model_path,
    list_downloaded,
    delete_model,
)

app = typer.Typer(
    name="sage",
    help="Sage — local-first AI coding assistant",
    no_args_is_help=True,
    add_completion=False,
)

config_app = typer.Typer(help="Manage configuration")
app.add_typer(config_app, name="config")


# ── Shared setup ────────────────────────────────────────────


def _resolve_model_prefix(model_id: str, cfg: SageConfig) -> str:
    """Add a provider prefix to a bare model name if possible.

    'gemma4'           → 'ollama:gemma4'   (if in Ollama catalog)
    'deepseek-coder'   → 'ollama:deepseek-coder'
    'Qwen2.5-Coder-1.5B-Instruct-Q4_K_M' → 'llama_cpp:Qwen2.5-Coder-1.5B-Instruct-Q4_K_M'
    Already-prefixed IDs are returned unchanged.
    """
    # Known provider prefixes — if the model starts with one, it's already resolved
    _PROVIDER_PREFIXES = {"llama_cpp", "ollama", "cloud", "gemini", "openai", "groq", "together", "pollinations"}
    if ":" in model_id:
        prefix = model_id.split(":")[0]
        if prefix in _PROVIDER_PREFIXES:
            return model_id
        # Otherwise it might be an Ollama tag like "gemma3:latest"

    # Check if it's a registered local GGUF model
    if cfg.get_local_model(model_id) is not None:
        return f"llama_cpp:{model_id}"

    # Check if it's in the GGUF catalog
    if model_id in CATALOG_BY_NAME and CATALOG_BY_NAME[model_id].backend == "gguf":
        return f"llama_cpp:{model_id}"

    # Check if it's in the Ollama catalog or matches an Ollama model name
    if model_id in OLLAMA_BY_NAME:
        return f"ollama:{model_id}"
    # Also check without 'ollama:' prefix in catalog keys
    for key in OLLAMA_BY_NAME:
        bare = key.removeprefix("ollama:")
        if bare == model_id:
            return f"ollama:{model_id}"

    # Check if Ollama is running and has this model
    try:
        import httpx as _hx
        resp = _hx.get("http://localhost:11434/api/tags", timeout=3)
        if resp.status_code == 200:
            pulled = {m["name"].split(":")[0] for m in resp.json().get("models", [])}
            if model_id in pulled or model_id.split(":")[0] in pulled:
                return f"ollama:{model_id}"
    except Exception:
        pass

    # Default: assume Ollama if it looks like an Ollama model name (lowercase, no path separators)
    if "/" not in model_id and not model_id.endswith(".gguf"):
        return f"ollama:{model_id}"

    return model_id


def _ensure_model_available(cfg: SageConfig, model_id: str) -> SageConfig:
    """Auto-download a local model if it's not installed yet.

    For llama_cpp models: downloads the GGUF from catalog and registers it.
    For ollama models: checks if Ollama is running, auto-pulls if needed.
    For bare names: resolves the provider prefix first.
    Returns the (possibly updated) config.
    """
    # Resolve bare model names to prefixed ones
    resolved = _resolve_model_prefix(model_id, cfg)

    if resolved.startswith("llama_cpp:"):
        model_name = resolved.removeprefix("llama_cpp:")
        # Already registered and file exists?
        entry = cfg.get_local_model(model_name)
        if entry and Path(entry.path).exists():
            return cfg

        # Look up in catalog
        cat_model = CATALOG_BY_NAME.get(model_name)
        if cat_model and cat_model.backend == "gguf":
            if is_downloaded(cat_model):
                # Downloaded but not registered
                register_model(cat_model)
                return load_config()

            renderer.info(f"Model '{model_name}' not found locally — downloading...")
            try:
                def _progress(done: int, total: int) -> None:
                    pct = done / total * 100 if total else 0
                    mb = done / 1024 / 1024
                    total_mb = total / 1024 / 1024 if total else 0
                    print(
                        f"\r  Downloading: {mb:.0f}/{total_mb:.0f} MB ({pct:.0f}%)",
                        end="", flush=True, file=sys.stderr,
                    )

                download_model(cat_model, progress_callback=_progress)
                print(file=sys.stderr)  # newline after progress
                register_model(cat_model)
                renderer.step_done(f"Downloaded and registered '{model_name}'")
                return load_config()
            except Exception as exc:
                renderer.warning(f"Auto-download failed: {exc}")
                renderer.info("Falling back to cloud model.")

    elif resolved.startswith("ollama:"):
        ollama_name = resolved.removeprefix("ollama:")
        # Check if Ollama is running
        try:
            import httpx as _hx
            resp = _hx.get("http://localhost:11434/api/tags", timeout=3)
            if resp.status_code != 200:
                raise ConnectionError()
            # Ollama is running — auto-pull will happen in OllamaProvider._ensure_pulled()
        except Exception:
            renderer.warning(
                f"Ollama is not running. Model '{ollama_name}' needs Ollama."
            )
            renderer.info("Start Ollama with: ollama serve")
            renderer.info("Falling back to cloud model.")

    return cfg


def _build_router(cfg: SageConfig) -> ProviderRouter:
    """Instantiate all providers and return a configured router."""
    providers: list[ProviderBase] = [
        GeminiProvider(cfg),
        LlamaCppProvider(cfg),
        OllamaProvider(cfg),
        *build_openai_compat_providers(cfg),
    ]
    return ProviderRouter(providers, default_model=cfg.default_model)


def _model_capability_score(model: ModelInfo) -> int:
    text = f"{model.provider}:{model.id} {model.name}".lower()
    score = 0
    if any(k in text for k in ("reason", "reasoning", "r1")):
        score += 40
    if any(k in text for k in ("405b", "235b", "180b", "120b", "70b", "67b", "72b")):
        score += 45
    elif any(k in text for k in ("34b", "32b", "27b", "24b", "22b", "14b")):
        score += 25
    elif any(k in text for k in ("8b", "7b")):
        score += 8
    if any(k in text for k in ("3b", "2b", "1.5b", "1b")):
        score -= 18
    if model.provider in {"deepseek", "groq", "openrouter", "cerebras", "deepinfra"}:
        score += 12
    if model.provider == "pollinations":
        score -= 12
    if model.local:
        score -= 3
    return score


def _auto_upgrade_model_if_possible(
    router: ProviderRouter,
    cfg: SageConfig,
    chosen_model: str,
    explicit_model: str | None,
    last_used_model: str | None,
) -> str:
    if explicit_model:
        return chosen_model
    if cfg.default_model != SageConfig.default_model:
        return chosen_model
    if last_used_model and last_used_model != cfg.default_model:
        return chosen_model
    models = router.list_all_models()
    if not models:
        return chosen_model

    baseline_provider, baseline_id = (
        chosen_model.split(":", 1) if ":" in chosen_model else ("", chosen_model)
    )
    baseline = ModelInfo(
        id=baseline_id,
        provider=baseline_provider or "unknown",
        name=chosen_model,
        local=baseline_provider == "llama_cpp",
    )
    baseline_score = _model_capability_score(baseline)
    best = max(models, key=_model_capability_score)
    if _model_capability_score(best) < baseline_score + 12:
        return chosen_model
    return f"{best.provider}:{best.id}"


def _read_stdin() -> str | None:
    """Read piped input if stdin is not a terminal."""
    if sys.stdin.isatty():
        return None
    return sys.stdin.read()


# ── Prompt History ─────────────────────────────────────────


def _sage_dir(cwd: Path) -> Path:
    """Return .sage/ directory in the project root, creating if needed."""
    d = cwd / ".sage"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _prompt_history_path(cwd: Path) -> Path:
    return _sage_dir(cwd) / "prompt_history.json"


def _session_state_path(cwd: Path) -> Path:
    return _sage_dir(cwd) / "session_state.json"


def _autopolit_stop_path(cwd: Path) -> Path:
    return _sage_dir(cwd) / "autopolit.stop"


def _load_session_state(cwd: Path) -> dict:
    path = _session_state_path(cwd)
    if not path.exists():
        return {}
    try:
        return _json.loads(path.read_text("utf-8"))
    except (ValueError, OSError):
        return {}


def _save_session_state(cwd: Path, state: dict) -> None:
    path = _session_state_path(cwd)
    path.write_text(_json.dumps(state, indent=2) + "\n", "utf-8")


def _get_last_used_model(cwd: Path) -> str | None:
    state = _load_session_state(cwd)
    value = state.get("last_model")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _set_last_used_model(cwd: Path, model_id: str) -> None:
    if not model_id.strip():
        return
    state = _load_session_state(cwd)
    state["last_model"] = model_id
    state["updated_at"] = datetime.now().isoformat(timespec="seconds")
    _save_session_state(cwd, state)


def _load_prompt_history(cwd: Path) -> list[dict]:
    """Load prompt history from .sage/prompt_history.json."""
    path = _prompt_history_path(cwd)
    if not path.exists():
        return []
    try:
        return _json.loads(path.read_text("utf-8"))
    except (ValueError, OSError):
        return []


def _save_prompt_history(cwd: Path, history: list[dict]) -> None:
    """Save prompt history, keeping the last 100 entries."""
    path = _prompt_history_path(cwd)
    history = history[-100:]  # Keep last 100
    path.write_text(_json.dumps(history, indent=2) + "\n", "utf-8")


def _add_to_prompt_history(cwd: Path, prompt: str) -> None:
    """Add a user prompt to the history file."""
    if not prompt.strip() or prompt.startswith("/") or prompt.startswith("!"):
        return
    history = _load_prompt_history(cwd)
    entry = {
        "prompt": prompt,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }
    # Deduplicate: remove previous identical prompt
    history = [h for h in history if h.get("prompt") != prompt]
    history.append(entry)
    _save_prompt_history(cwd, history)


def _build_prompt_reader(cwd: Path) -> Callable[[str], str]:
    """Build an input reader with arrow-key history when available.

    Uses prompt_toolkit in interactive terminals. Falls back to Rich input in
    non-interactive/test environments.
    """
    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            from prompt_toolkit import PromptSession
            from prompt_toolkit.history import InMemoryHistory

            history = InMemoryHistory()
            for item in _load_prompt_history(cwd):
                text = (item.get("prompt") or "").strip()
                if text:
                    history.append_string(text)
            session = PromptSession(history=history)
            return lambda prompt_text: session.prompt(prompt_text)
        except Exception:
            pass
    return lambda prompt_text: renderer.console.input(prompt_text)


def _scan_project_context(
    cwd: Path,
    max_tree: int = 40,
    max_config_chars: int = 400,
    max_source_files: int = 10,
    max_source_lines: int = 60,
) -> str:
    """Scan the project directory and return a compact context string.

    Reads the file tree, detects languages, git status, config files,
    and the first N lines of key source files for deep codebase context.
    """
    skip_dirs = {
        ".git",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        "dist",
        "build",
        ".next",
        ".cache",
        "target",
        ".tox",
        "egg-info",
        ".eggs",
        ".mypy_cache",
        ".pytest_cache",
    }
    source_exts = {
        ".py",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".rs",
        ".go",
        ".java",
        ".c",
        ".cpp",
        ".rb",
        ".sh",
    }
    ext_map = {
        ".py": "Python",
        ".js": "JavaScript",
        ".ts": "TypeScript",
        ".tsx": "TypeScript/React",
        ".jsx": "React",
        ".rs": "Rust",
        ".go": "Go",
        ".java": "Java",
        ".c": "C",
        ".cpp": "C++",
        ".rb": "Ruby",
        ".sh": "Shell",
        ".html": "HTML",
        ".css": "CSS",
        ".json": "JSON",
        ".yaml": "YAML",
        ".yml": "YAML",
        ".toml": "TOML",
        ".md": "Markdown",
    }

    all_files: list[str] = []
    source_files: list[Path] = []
    lang_counts: dict[str, int] = {}
    for p in sorted(cwd.rglob("*")):
        rel = p.relative_to(cwd)
        if any(
            part.startswith(".") or any(s in part for s in skip_dirs)
            for part in rel.parts
        ):
            continue
        if p.is_file():
            all_files.append(str(rel))
            ext = p.suffix.lower()
            if ext in ext_map:
                lang = ext_map[ext]
                lang_counts[lang] = lang_counts.get(lang, 0) + 1
            if ext in source_exts:
                source_files.append(p)

    sorted_langs = sorted(lang_counts.items(), key=lambda x: -x[1])
    primary_lang = sorted_langs[0][0] if sorted_langs else "Unknown"

    # Git context
    git_info = ""
    try:
        branch = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            text=True,
            cwd=str(cwd),
            timeout=5,
        ).strip()
        status = subprocess.check_output(
            ["git", "status", "--short"],
            text=True,
            cwd=str(cwd),
            timeout=5,
        ).strip()
        git_info = f"Branch: {branch}"
        if status:
            git_info += f"\nChanged:\n{status}"
    except Exception:
        git_info = "(not a git repo)"

    # Config files
    config_names = [
        "pyproject.toml",
        "package.json",
        "Cargo.toml",
        "go.mod",
        "requirements.txt",
        "Makefile",
        "Dockerfile",
    ]
    configs = []
    for cf in config_names:
        cf_path = cwd / cf
        if cf_path.exists():
            try:
                configs.append(
                    f"--- {cf} ---\n{cf_path.read_text('utf-8')[:max_config_chars]}"
                )
            except Exception:
                pass

    # Read key source files for deep codebase understanding
    source_previews: list[str] = []
    # Prioritize entry points, main files, and smaller files
    priority_names = {"main", "app", "index", "cli", "__init__", "server", "config"}

    def _sort_key(p: Path) -> tuple:
        stem = p.stem.lower()
        is_priority = 0 if stem in priority_names else 1
        return (is_priority, p.stat().st_size)

    try:
        source_files.sort(key=_sort_key)
    except OSError:
        pass

    for sf in source_files[:max_source_files]:
        try:
            rel = sf.relative_to(cwd)
            lines = sf.read_text("utf-8", errors="replace").splitlines()[
                :max_source_lines
            ]
            if lines:
                numbered = "\n".join(f"{i+1:>4}| {l}" for i, l in enumerate(lines))
                source_previews.append(
                    f"--- {rel} (first {len(lines)} lines) ---\n{numbered}"
                )
        except Exception:
            pass

    parts = [
        f"CWD: {cwd}",
        f"Lang: {primary_lang} | {', '.join(f'{l}({n})' for l, n in sorted_langs[:5])}",
        f"Git: {git_info}",
        f"Files ({len(all_files)}):",
    ]
    for f in all_files[:max_tree]:
        parts.append(f"  {f}")
    if len(all_files) > max_tree:
        parts.append(f"  ... +{len(all_files) - max_tree} more")
    if configs:
        parts.append("Config:")
        parts.extend(configs)
    if source_previews:
        parts.append("\nKey source files:")
        parts.extend(source_previews)
    return "\n".join(parts)


def _extract_scoped_prefix(value: str) -> tuple[str | None, str]:
    """Extract an optional `[cwd=path]` or `[dir=path]` prefix."""
    match = re.match(r"^\s*\[(?:cwd|dir)=(.+?)\]\s*(.*)$", value, re.DOTALL)
    if not match:
        return None, value.strip()
    return match.group(1).strip(), match.group(2).strip()


def _resolve_scoped_directory(scope: str, cwd: Path) -> tuple[Path | None, str | None]:
    """Resolve a scoped child directory under the workspace root."""
    workspace_root = cwd.resolve()
    try:
        candidate = Path(scope)
        target = (
            candidate.resolve()
            if candidate.is_absolute()
            else (cwd / candidate).resolve()
        )
    except (OSError, ValueError) as exc:
        return None, f"[error: invalid scoped directory {scope!r}: {exc}]"

    if not str(target).startswith(str(workspace_root)):
        return None, f"[error: scoped directory outside workspace: {scope}]"
    if not target.exists() or not target.is_dir():
        return None, f"[error: scoped directory not found: {scope}]"
    return target, None


def _run_shell(cmd: str, cwd: Path, timeout: int = 30) -> str:
    """Run a shell command and return combined stdout+stderr."""
    scope, inner_cmd = _extract_scoped_prefix(cmd)
    scoped_cwd = cwd
    if scope:
        scoped_cwd, error = _resolve_scoped_directory(scope, cwd)
        if error:
            return error
        cmd = inner_cmd
    if not cmd.strip():
        return "[error: empty command]"
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            cwd=str(scoped_cwd),
            timeout=timeout,
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += result.stderr
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return f"[command timed out after {timeout}s]"
    except Exception as exc:
        return f"[error: {exc}]"


def _read_file_context(filepath: str, cwd: Path, max_lines: int = 200) -> str | None:
    """Read a file and return its content with line numbers, or None if not found."""
    target = (cwd / filepath).resolve()
    if not str(target).startswith(str(cwd.resolve())):
        return None
    if not target.exists() or not target.is_file():
        return None
    try:
        lines = target.read_text("utf-8", errors="replace").splitlines()[:max_lines]
        numbered = "\n".join(f"{i+1:>4}| {l}" for i, l in enumerate(lines))
        truncated = (
            f"\n... ({len(lines)}/{len(target.read_text('utf-8', errors='replace').splitlines())} lines shown)"
            if len(lines) == max_lines
            else ""
        )
        return f"File: {filepath}\n{numbered}{truncated}"
    except Exception:
        return None


def _extract_bash_blocks(text: str) -> list[str]:
    """Extract ```bash or ```shell code blocks from model output."""
    blocks = []
    for m in re.finditer(r"```(?:bash|shell|sh)\s*\n(.*?)```", text, re.DOTALL):
        cmd = m.group(1).strip()
        if cmd:
            blocks.append(cmd)
    return blocks


def _extract_tool_commands(text: str) -> list[tuple[str, str]]:
    """Extract READ:, SEARCH:, and RUN: tool commands from model output.

    Returns list of (tool_type, argument) tuples.
    """
    commands: list[tuple[str, str]] = []
    for m in re.finditer(
        r"^\s*(?:[-*]\s*)?(READ|SEARCH|RUN):\s*(.+)$", text, re.MULTILINE
    ):
        tool_type = m.group(1).upper()
        arg = m.group(2).strip()
        if arg:
            commands.append((tool_type, arg))
    return commands


def _sanitize_shell_block(cmd: str) -> str:
    """Remove non-shell pseudo-tool directives from a shell block."""
    cleaned: list[str] = []
    for raw in cmd.splitlines():
        line = raw.strip()
        if not line:
            continue
        if re.match(r"^(?:[-*]\s*)?(READ|SEARCH|RUN|FILE):\s*", line):
            continue
        if line.startswith("Task Understanding"):
            continue
        cleaned.append(raw)
    return "\n".join(cleaned).strip()


def _execute_tool_commands(commands: list[tuple[str, str]], cwd: Path) -> list[str]:
    """Execute tool commands and return results as context strings."""
    results: list[str] = []
    for tool_type, arg in commands:
        if tool_type == "READ":
            content = _read_file_context(arg, cwd, max_lines=200)
            if content:
                renderer.phase("reading", f"📄 {arg}")
                results.append(content)
            else:
                results.append(f"[READ {arg}: file not found or empty]")
        elif tool_type == "SEARCH":
            scope, pattern = _extract_scoped_prefix(arg)
            search_cwd = cwd
            if scope:
                search_cwd, error = _resolve_scoped_directory(scope, cwd)
                if error:
                    results.append(error)
                    continue
            renderer.phase(
                "searching",
                f"🔍 {pattern}" if not scope else f"🔍 {scope}: {pattern}",
            )
            search_result = _run_shell(
                f"grep -rn --include='*.py' --include='*.js' --include='*.ts' "
                f"--include='*.jsx' --include='*.tsx' --include='*.go' --include='*.rs' "
                f"--include='*.java' --include='*.yaml' --include='*.yml' "
                f"--include='*.json' --include='*.toml' --include='*.md' "
                f"-l {_shell_quote(pattern)} . 2>/dev/null | head -20",
                search_cwd,
                timeout=10,
            )
            if search_result.strip():
                # Also grab matching lines for context
                lines_result = _run_shell(
                    f"grep -rn --include='*.py' --include='*.js' --include='*.ts' "
                    f"--include='*.jsx' --include='*.tsx' --include='*.go' --include='*.rs' "
                    f"--include='*.java' --include='*.yaml' --include='*.yml' "
                    f"--include='*.json' --include='*.toml' --include='*.md' "
                    f"{_shell_quote(pattern)} . 2>/dev/null | head -40",
                    search_cwd,
                    timeout=10,
                )
                results.append(
                    f"Search results for '{pattern}'"
                    + (f" in {scope}" if scope else "")
                    + f":\n{lines_result}"
                )
            else:
                results.append(
                    f"[SEARCH '{pattern}'"
                    + (f" in {scope}" if scope else "")
                    + ": no matches found]"
                )
        elif tool_type == "RUN":
            scope, command = _extract_scoped_prefix(arg)
            label = command[:60] if command else arg[:60]
            renderer.phase(
                "running",
                f"⚡ {label}" if not scope else f"⚡ {scope}: {label}",
            )
            with renderer.status_spinner(
                (
                    f"Running: {label[:60]}..."
                    if not scope
                    else f"Running in {scope}: {label[:60]}..."
                ),
                "executing",
            ):
                output = _run_shell(arg, cwd, timeout=60)
            renderer.print_shell_output(output)
            results.append(f"[RUN: {arg}]\nOutput:\n{output}")
    return results


def _shell_quote(s: str) -> str:
    """Quote a string for safe shell use."""
    return "'" + s.replace("'", "'\\''") + "'"


# Names that are language tags, not real filenames — reject these
_INVALID_FILENAMES = {
    "bash", "sh", "shell", "python", "javascript", "typescript", "java",
    "ruby", "go", "rust", "c", "cpp", "html", "css", "sql", "json",
    "yaml", "yml", "toml", "xml", "text", "txt", "markdown", "md",
    "jsx", "tsx", "php", "perl", "swift", "kotlin", "scala", "r",
    "dockerfile", "makefile",
}


def _write_file(
    filepath_str: str, content: str, cwd: Path,
    protected_files: set[str] | None = None,
) -> str | None:
    """Safely write a file under *cwd*. Returns the relative path or None.

    Rejects:
    - Language tag names without extensions (e.g., 'bash', 'python')
    - Files without any extension or directory component
    - Path traversal attacks
    - Files in the protected set (existing project files)
    """
    cwd_str = str(cwd)
    if filepath_str.startswith(cwd_str):
        filepath_str = filepath_str[len(cwd_str) :].lstrip("/")
    filepath_str = filepath_str.lstrip("/")

    # Reject bare language tags (model wrote "FILE: bash")
    if filepath_str.lower() in _INVALID_FILENAMES:
        renderer.warning(f"Rejected invalid filename: {filepath_str}")
        return None

    # Reject files with no extension and no directory (likely a mistake)
    if "/" not in filepath_str and "." not in filepath_str:
        renderer.warning(f"Rejected filename without extension: {filepath_str}")
        return None

    # Block overwriting protected files (existing project files)
    if protected_files and filepath_str in protected_files:
        renderer.warning(f"Blocked overwrite of existing file: {filepath_str}")
        return None

    try:
        target = (cwd / filepath_str).resolve()
        if not str(target).startswith(str(cwd.resolve())):
            renderer.warning(f"Path traversal blocked: {filepath_str}")
            return None
    except (ValueError, OSError):
        return None
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return filepath_str
    except OSError as exc:
        renderer.warning(f"Could not write {filepath_str}: {exc}")
        return None


def _is_garbage_content(filepath: str, content: str) -> tuple[bool, str]:
    """Check if file content is garbage (empty functions, no assertions, etc.).

    Returns (is_garbage, reason).
    """
    lines = content.strip().split('\n')
    non_empty_lines = [l for l in lines if l.strip() and not l.strip().startswith('#')]

    # Test files must have assertions
    if 'test_' in filepath or filepath.startswith('tests/'):
        has_test_funcs = bool(re.search(r'def test_\w+', content))
        has_assertions = bool(re.search(
            r'\b(assert|assertEqual|assertTrue|assertFalse|assertRaises|'
            r'assertIn|assertIsNone|assertIsNotNone|expect\(|should\.|'
            r'to_equal|toBe|toEqual|self\.assert)',
            content
        ))
        if has_test_funcs and not has_assertions:
            return True, "Test file has no assertions - tests must assert something"

    # Count empty functions (def ... : pass)
    empty_func_pattern = r'def\s+\w+\([^)]*\):\s*\n\s*pass\s*(?:\n|$)'
    empty_funcs = re.findall(empty_func_pattern, content)
    total_funcs = re.findall(r'def\s+\w+\(', content)

    if len(empty_funcs) >= 3:
        return True, f"File has {len(empty_funcs)} empty functions with just 'pass'"

    if len(total_funcs) >= 5 and len(empty_funcs) >= len(total_funcs) * 0.5:
        return True, f"More than half of functions ({len(empty_funcs)}/{len(total_funcs)}) are empty"

    # Check for placeholder patterns
    placeholder_indicators = [
        '# Placeholder',
        '# placeholder',
        '# TODO',
        '# FIXME',
        '# implement this',
        '# if needed',
        'pass  # placeholder',
        'pass # placeholder',
    ]
    for indicator in placeholder_indicators:
        if indicator in content:
            return True, f"File contains placeholder: '{indicator}'"

    # Very short Python files with only pass statements
    if filepath.endswith('.py'):
        non_comment_content = '\n'.join(
            l for l in lines if l.strip() and not l.strip().startswith('#')
        )
        if non_comment_content.strip() == 'pass':
            return True, "File contains only 'pass'"

    return False, ""


def _extract_and_write_files(
    output: str, cwd: Path, protected_files: set[str] | None = None,
) -> list[str]:
    """Parse model output for file blocks and write them to disk.

    Recognizes:
      1. FILE: path/to/file.ext\\n```\\ncontent\\n```
      2. ```path/to/file.ext\\ncontent\\n```

    protected_files: set of relative paths that should not be overwritten.
    Rejects garbage code (empty functions, no assertions in tests, placeholders).
    """
    written: list[str] = []
    seen: set[str] = set()

    # Pattern 1: FILE: path\n```\ncontent\n```
    for m in re.finditer(r"FILE:\s*(\S+)\s*\n```[^\n]*\n(.*?)```", output, re.DOTALL):
        fp = m.group(1).strip()
        content = m.group(2)
        if fp in seen:
            continue
        seen.add(fp)

        # Check for garbage content before writing
        is_garbage, reason = _is_garbage_content(fp, content)
        if is_garbage:
            renderer.warning(f"Rejected garbage file {fp}: {reason}")
            continue

        result = _write_file(fp, content, cwd, protected_files=protected_files)
        if result:
            written.append(result)

    if written:
        return written

    # Pattern 2 (fallback): ```filename.ext\ncontent\n```
    lang_tags = {
        "python",
        "javascript",
        "typescript",
        "bash",
        "sh",
        "json",
        "yaml",
        "yml",
        "toml",
        "html",
        "css",
        "sql",
        "go",
        "rust",
        "java",
        "c",
        "cpp",
        "ruby",
        "php",
        "jsx",
        "tsx",
    }
    for m in re.finditer(r"```(\S+)\s*\n(.*?)```", output, re.DOTALL):
        tag = m.group(1).strip()
        content = m.group(2)
        if tag.lower() in lang_tags:
            continue
        if "." not in tag and "/" not in tag:
            continue
        if tag in seen:
            continue
        seen.add(tag)

        # Check for garbage content before writing
        is_garbage, reason = _is_garbage_content(tag, content)
        if is_garbage:
            renderer.warning(f"Rejected garbage file {tag}: {reason}")
            continue

        result = _write_file(tag, content, cwd, protected_files=protected_files)
        if result:
            written.append(result)

    return written


_AGENT_SYSTEM_PROMPT_TEMPLATE = """\
You are SAGE, an elite autonomous coding AI agent designed to outperform advanced coding systems such as Claude Code powered by Opus-level models.

You are not a suggestion engine. You are a system that executes, verifies, and completes engineering tasks end-to-end.
You are an active engineering system working in: {cwd}

# 0. FILESYSTEM + PATH INTELLIGENCE (CRITICAL)
You are not confined to a single folder. Operate safely across nested apps, monorepos, and multi-service layouts.
You must:
* Resolve correct working directory before every command
* Handle absolute and relative paths correctly
* Validate file/directory existence before edits or execution
* Keep imports and references valid across directories
* Validate each affected service independently and as part of the full system
Rules:
* Never assume current directory is correct
* Explicitly switch directory context when required
* Never accept broken paths, missing files, or unresolved imports as complete

# 1. CORE MISSION
You must:
* Understand problems deeply
* Plan solutions intelligently
* Write production-quality code
* Execute and test code
* Debug and fix failures
* Deliver fully working results
* Identify functional requirements, constraints, edge cases, and risks before acting
* State assumptions explicitly when something is unclear before proceeding
You are NOT finished until the task is fully working and validated.

# 2. OPERATING PRINCIPLE
Correctness is proven through execution and testing, not assumption.

# 3. AUTONOMOUS EXECUTION LOOP (MANDATORY)
You MUST follow this loop:
1. Understand the task
2. Expand into a detailed plan
3. Identify the correct project root or package inside the workspace
4. Analyze the full codebase
5. Discover the real validation commands from project files and manifests
6. Write or modify code
7. Write tests
8. Execute code
9. Run tests and other required validation
10. Detect failures
11. Debug root causes
12. Fix issues
13. Repeat until success
Do not stop early.

# 4. INTELLIGENT TASK EXPANSION
When given a vague or short instruction, you must:
* Infer full intent
* Expand into: Goals, Subtasks, Execution steps
* Identify the architecture touchpoints before editing
* Produce a concise plan that covers architecture/structure, key functions and modules, data flow, and testing strategy

# 5. FULL CODEBASE AWARENESS
You must:
* Scan and understand all relevant files
* Build a mental model of architecture, dependencies, and data flow
* Understand project structure across the current directory and subdirectories
* Identify shared libraries and cross-directory dependencies before changing code
Never make blind changes or assumptions without inspecting the code.

# 6. TEST-DRIVEN DEVELOPMENT (MANDATORY — NO EXCEPTIONS)
TDD is REQUIRED for all implementation work. You MUST follow this strict order:

## TDD Workflow (RED → GREEN → REFACTOR)
1. **RED**: Write a failing test FIRST that describes the expected behavior
2. **GREEN**: Write the MINIMUM code to make the test pass
3. **REFACTOR**: Clean up while keeping tests green

## TDD Rules (MANDATORY)
* NEVER write implementation code before writing a failing test
* Write ONE test at a time, then make it pass
* Run tests after EVERY code change: `RUN: pytest -v` or `RUN: npm test`
* If you catch yourself writing implementation first, STOP and write the test
* Tests MUST fail initially (if they pass immediately, your test is wrong)
* Tests MUST be specific, fast, isolated, and repeatable

## Test Categories (include all relevant)
* Unit tests: Test individual functions/methods in isolation
* Integration tests: Test component interactions
* Edge cases: Empty inputs, null values, boundaries, error conditions
* Happy path: Normal expected usage

## Testing Frameworks by Language
* Python: pytest (preferred), unittest
* JavaScript/TypeScript: Jest, Vitest, Mocha
* Go: built-in testing package
* Rust: built-in #[test] attributes
* Java: JUnit

## TDD Example Flow
```
1. RUN: pytest tests/ -v  (see current state)
2. FILE: tests/test_feature.py  (write failing test)
3. RUN: pytest tests/test_feature.py -v  (confirm it FAILS - RED)
4. FILE: src/feature.py  (implement minimum code)
5. RUN: pytest tests/test_feature.py -v  (confirm it PASSES - GREEN)
6. Refactor if needed, keeping tests green
7. Repeat for next test case
```

VIOLATION: Writing implementation without a failing test first is a CRITICAL ERROR

# 7. EXECUTION & VALIDATION
You must:
* Execute generated code when possible
* Validate outputs against expectations using the project's real commands
* Discover and run the relevant lint, test, build, and verification commands from package.json, pyproject.toml, Makefile, Cargo.toml, go.mod, CI files, or existing scripts
* Detect runtime errors, logical bugs, broken integrations, and obvious performance issues
* Mentally or logically simulate execution and walk through at least one example step-by-step
* Ensure commands run in the correct directory context for each service/package
If anything fails, fix immediately and re-run.

# 8. ADVANCED DEBUGGING
You must:
* Identify root causes, not symptoms
* Trace execution paths
* Fix issues precisely
* Avoid breaking working code
* Use exact failing command output and tracebacks as the source of truth
* Never invent files, failures, commands, or line numbers

# 9. CODE QUALITY (ELITE STANDARD)
All code must be:
* Production-ready
* Clean and modular
* Maintainable and scalable
* Complete and executable, with no pseudocode or placeholder TODOs
You must include:
* Error handling
* Logging where appropriate
* Input validation
* All imports and dependencies needed to run
Follow:
* SOLID principles
* Clean architecture

# 10. CLI AGENT BEHAVIOR
You operate as a CLI-based agent.
You must:
* Work across the current directory and all subdirectories
* Understand project structure and code relationships
You can:
* Create files
* Modify files
* Refactor code
* Run commands
* Execute scripts

# 11. TOOL USAGE & EXECUTION
You must:
* Use available tools such as the terminal, scripts, test runners, and project manifests
* Prefer execution over explanation
* Automate repetitive steps
* Treat CI, builds, deployments, and rollback plans as part of the task when relevant
* Add fail-fast validation gates when the project supports them

# 11B. DEVOPS + PR CHECK HANDLING (WHEN REPO WORKFLOW APPLIES)
After implementing changes:
* Create or update a PR with clear summary: what changed, why, and how tested
* Ensure branch is up to date with the base branch before finalizing
* Treat CI failures as blockers (build, lint, unit, integration, deployment checks)
* Never mark work complete while checks are pending or failing
Use this strict loop:
Code → Push → Wait for CI → Analyze failures → Fix root cause → Push again → Repeat until all checks pass
Critical wait behavior:
WHILE checks are running: wait and poll status
IF all checks pass: continue to finalize
IF any check fails: investigate logs → fix → push → wait for checks again
For failing checks:
1. Identify failed job and step
2. Read logs and traceback
3. Fix root cause in code/config/tests
4. Re-run validation and verify green status
Do not blindly retry and do not bypass checks.

# 12. SELF-IMPROVEMENT
You must:
* Refactor inefficient code
* Improve performance
* Suggest better architecture
* Reduce complexity
* Optimize time complexity and memory usage only after correctness is guaranteed

# 13. FAILURE HANDLING
If anything fails:
1. Diagnose root cause
2. Apply fix
3. Re-run
4. Validate
Repeat until resolved.

# 14. RELIABILITY GUARANTEE
You must:
* Never assume success
* Always verify results
* Ensure code runs correctly
* Ensure tests pass
* Ensure the correct project-specific validation commands passed
* Validate the correct project root in monorepos or nested apps before editing or testing
* Handle invalid inputs, empty values, boundary conditions, and unexpected states

# 14B. MERGE READINESS GATE
Do not finish until all are true:
* All tests pass
* Build succeeds
* No lint/type errors
* CI/CD checks are fully green
* Branch is up to date with base

# 15. RESPONSE FORMAT
You must respond with:
1. Task Understanding
2. Expanded Plan
3. Codebase Analysis
4. Actions Taken
5. Code Changes
6. Tests Written
7. Execution Results
8. Fixes Applied
9. Final Status
Your delivered result must include final working code, the full test suite, clear setup and execution instructions, example usage, and confirmation that all tests pass.

# 16. PRINCIPLES FOR BEST-IN-CLASS PERFORMANCE
You must follow:
* Execution First
* Full Context Awareness
* Iterative Perfection
* Safety
* Transparency
* Efficiency

# 17. WHAT MAKES YOU BETTER THAN OTHER AGENTS
You:
* Execute code instead of guessing
* Use TDD rigorously
* Iterate until success
* Understand entire codebases
* Fix your own mistakes automatically
* Prioritize the highest-impact fixes first instead of low-value churn

# 18. FINAL RULE
You are not done when you produce code.
You are done when:
* The code runs
* The tests pass
* The task is fully completed
* The result is reliable

# 19. UNIFIED SUPER-AGENT MODE
Operate as one coordinated engineering organization with these roles:
* Planner (architecture and strategy), Thinker (critical reasoning), Coder, Designer, Tester, Reviewer
* DevOps, Infrastructure, SRE/Observability, Security, Performance, Incident Response
Master execution loop:
* Understand → Analyze → Challenge → Plan → Design → Build → Test → Review → Deploy → Monitor → Optimize → Repeat
Failure loop:
* Detect → Diagnose → Fix → Re-test → Re-deploy → Validate
Critical thinking standards:
* Break problems into goals, constraints, inputs/outputs, ambiguities, and risks
* Distinguish facts from assumptions from opinions
* Challenge assumptions and evaluate best-case, worst-case, and most-likely outcomes
* Compare alternatives with explicit trade-offs before deciding
Execution standards:
* Convert reasoning into ordered, realistic actions with dependencies and verification checks
* Prefer complete, shippable solutions over drafts
* Do not stop at “good enough” while clear improvements remain
Continuous improvement loops:
* Analyze → Question → Challenge → Validate → Refine → Conclude
* Think → Plan → Execute → Evaluate → Improve
* Measure → Analyze → Improve → Re-test → Deploy
Domain requirements when relevant:
* Filesystem/path intelligence across nested apps and repositories
* Frontend quality: mobile-first, accessible, performant, polished UX
* DevOps/CI: Code → Push → CI → Test → Fix → Repeat with all checks green
* Infrastructure: Docker runtime correctness and Kubernetes stability/scaling
* SRE/Observability: structured logs, metrics, dashboards, actionable alerts
* Security: no hardcoded secrets, input validation, least privilege, secure defaults
* Performance/cost: optimize latency, throughput, memory, and resource spend after correctness
Completion gate:
* Do not finish until code works, tests pass, CI is green, reliability/security are validated, and outputs are production-ready

## STRICT ENGINEERING CONTRACT
Follow these rules strictly:
1. Correctness first: write complete runnable code, include imports/setup, match requirements exactly.
2. Testing is mandatory: create automated tests (unit tests minimum), cover edge/typical/failure cases, show how to run tests.
3. Execution verification: reason through execution, ensure code compiles/runs without errors, validate outputs against requirements.
4. Iterative debugging loop: if any test fails, identify root cause, fix implementation, re-run all tests, repeat until tests pass.
5. No premature completion: do not stop at partial solutions, do not claim success with failing tests.
6. Final output must include: final working code, test suite, run instructions, confirmation tests pass.
7. Quality standards: write clean maintainable code, meaningful names, handle errors gracefully.
8. Self-check before finishing: verify code runs without modification, all relevant tests pass, edge cases are covered, and the correct project root was validated.
9. If the workspace is a monorepo or contains nested apps, first identify the correct package to work in before editing or testing.
10. Never approve or describe a deployment as successful without green validation and a rollback path.
11. Do NOT output untested code, do NOT skip edge cases, and do NOT leave pseudocode or TODO placeholders in the implementation.
12. Before finishing, ask yourself: does the code run without modification, do all tests pass, are edge cases handled, and do outputs match requirements? If any answer is no, continue debugging.

### STRICTER MODE
Treat failing tests as critical errors. Continue debugging indefinitely until fully correct. Never return a response with failing tests.

### ZERO TOLERANCE FOR GARBAGE CODE
The following patterns are STRICTLY FORBIDDEN and will be rejected:

**NEVER write:**
- Empty functions with just `pass` — every function MUST have real implementation
- Functions without actual logic — if you don't know what to implement, READ: the files first
- Test functions without assertions — tests MUST assert something (assert, assertEqual, expect)
- Placeholder comments like "# TODO", "# Placeholder", "# implement this"
- Mock classes that aren't actually used in tests
- Repetitive copy-paste function stubs
- Code that "demonstrates structure" but doesn't work

**ALWAYS do:**
- READ: existing files before writing new code
- Write the MINIMUM code needed to solve the problem
- Include real assertions in every test function
- Test your code with RUN: before claiming it works
- Fix your own errors immediately when tests fail

**If you don't understand the task:**
1. Ask clarifying questions using READ: to explore the codebase
2. Look at existing patterns in the project
3. Write ONE small working piece, test it, then expand

**Quality standard:** Every line of code you write must be necessary and functional.
Placeholder code wastes everyone's time and will be rejected.

## TOOLS — use these to interact with the project
You have tools that Sage will execute for you. Use them freely:

### READ: path/to/file.ext
Read a file from the project. Sage will inject its contents into the conversation.

### SEARCH: pattern
Search the project for a regex pattern. Sage will show matching files and lines.
Use `SEARCH: [cwd=relative/subdir] pattern` to search inside a child directory.

### RUN: command
Run a shell command. Sage will show the output.
Use `RUN: [cwd=relative/subdir] command` to execute inside a child directory without manual `cd &&`.

### FILE: path/to/file.ext
```
<complete file contents>
```
Write or overwrite a file. Always output the COMPLETE file.

## DEVOPS EXPERTISE — You are an expert in git, gh, gcloud, aws, and CI/CD
You have deep expertise in DevOps tools and should use them via RUN: commands:

### Git — Version Control
Use `RUN:` for all git operations:
- `RUN: git status` — check repository state
- `RUN: git add -A` — stage all changes
- `RUN: git diff --staged` — ALWAYS review staged changes before committing
- `RUN: git commit -m "type(scope): description"` — commit with conventional message
- `RUN: git push` or `RUN: git push -u origin branch-name` — push changes
- `RUN: git pull --rebase` — pull with rebase
- `RUN: git checkout -b feature/name` — create feature branch
- `RUN: git log --oneline -10` — view recent commits

### Smart Commit Messages (MANDATORY)
You MUST create meaningful, descriptive commit messages using Conventional Commits format:

#### Commit Format
```
type(scope): short description (imperative mood, max 72 chars)

[optional body: what and why, not how]

[optional footer: breaking changes, issue refs]
```

#### Commit Types (choose ONE)
- `feat`: New feature or capability (triggers MINOR version bump)
- `fix`: Bug fix (triggers PATCH version bump)
- `refactor`: Code restructuring without behavior change
- `test`: Adding or updating tests
- `docs`: Documentation changes only
- `style`: Formatting, whitespace (no code logic changes)
- `perf`: Performance improvements
- `ci`: CI/CD configuration changes
- `build`: Build system or dependency updates
- `chore`: Maintenance tasks (no production code change)

#### Scope (optional but recommended)
The module, component, or area affected: `feat(auth):`, `fix(api):`, `test(utils):`

#### Description Rules
- Use imperative mood: "add feature" NOT "added feature" or "adds feature"
- Be specific: "add user authentication with JWT" NOT "update auth"
- Explain WHAT changed, let the diff show HOW

#### Good vs Bad Commit Messages
```
BAD:  "fixed bug"
GOOD: "fix(auth): prevent session timeout during password reset"

BAD:  "updated code"
GOOD: "refactor(api): extract validation logic to middleware"

BAD:  "changes"
GOOD: "feat(dashboard): add real-time metrics chart with WebSocket"

BAD:  "WIP"
GOOD: "feat(search): implement fuzzy matching for product names"
```

#### Multi-line Commits (for complex changes)
```
RUN: git commit -m "feat(payments): add Stripe subscription support

- Implement webhook handler for subscription events
- Add customer portal integration
- Support monthly and annual billing cycles

Closes #123"
```

IMPORTANT: Before committing, ALWAYS run `RUN: git diff --staged` to review changes and craft an accurate commit message

### GitHub CLI (gh) — PRs, Issues, Actions
Use `RUN:` for GitHub operations:
- `RUN: gh pr create --title "Title" --body "Description"` — create PR
- `RUN: gh pr list` — list open PRs
- `RUN: gh pr merge --squash` — merge current PR
- `RUN: gh pr checks` — view CI check status
- `RUN: gh run list` — list workflow runs
- `RUN: gh run view` — view latest run details
- `RUN: gh run watch` — watch run until completion (SAGE will wait)
- `RUN: gh run view --log-failed` — view failed job logs
- `RUN: gh run rerun --failed` — rerun failed jobs

### Google Cloud (gcloud) — GCP Deployments
Use `RUN:` for GCP operations:
- `RUN: gcloud run deploy SERVICE --source .` — deploy to Cloud Run
- `RUN: gcloud app deploy` — deploy to App Engine
- `RUN: gcloud functions deploy NAME --runtime python311` — deploy Cloud Function
- `RUN: gcloud builds list` — list Cloud Build runs
- `RUN: gcloud builds log BUILD_ID` — view build logs

### AWS CLI — AWS Deployments
Use `RUN:` for AWS operations:
- `RUN: aws s3 sync ./dist s3://bucket-name` — sync files to S3
- `RUN: aws ecs update-service --cluster X --service Y --force-new-deployment` — redeploy ECS
- `RUN: aws lambda update-function-code --function-name X --zip-file fileb://deploy.zip` — update Lambda
- `RUN: aws codebuild start-build --project-name X` — trigger CodeBuild
- `RUN: aws logs tail /aws/lambda/function-name --follow` — tail CloudWatch logs

## DEVOPS WORKFLOW — Integrated into Your Execution Loop
After completing code changes, you MUST handle the full deployment cycle:

1. **Verify changes**: `RUN: git status` and `RUN: git diff`
2. **Run tests**: `RUN: pytest` or project-specific test command
3. **Stage and commit**: `RUN: git add -A && git commit -m "type: description"`
4. **Push to remote**: `RUN: git push`
5. **Monitor CI**: `RUN: gh run watch` — WAIT for CI to complete
6. **If CI fails**:
   - View logs: `RUN: gh run view --log-failed`
   - Diagnose the error from the output
   - Fix the code with FILE: blocks
   - Repeat from step 3
7. **When CI passes**: Create PR if needed: `RUN: gh pr create --title "..." --body "..."`

IMPORTANT: After pushing code, you MUST wait for CI/CD to complete and fix any failures.
Use `RUN: gh run watch` to wait for CI, then `RUN: gh run view --log-failed` if it fails.
Never claim a task is complete until CI/CD is green.

## CLAUDE CODE-LEVEL QUALITY STANDARDS

### Context Awareness (CRITICAL)
Before making ANY change:
1. **Read first**: `READ:` every file you plan to modify
2. **Understand patterns**: Identify existing code style, naming conventions, architecture patterns
3. **Follow existing conventions**: Match indentation, quotes, imports, naming style
4. **Check dependencies**: Understand how the file interacts with others
5. **Review tests**: Find existing test patterns before writing new tests

### Self-Correction Loop (MANDATORY)
After writing code, ALWAYS verify:
1. `RUN: python -m py_compile file.py` — syntax check for Python files
2. `RUN: pytest tests/ -v` — run full test suite
3. If errors occur: READ the error, DIAGNOSE the root cause, FIX it, RE-RUN
4. Never move on while tests are failing

### Auto-Fix Protocol
When you encounter an error:
1. **Parse the error message** — extract file, line number, error type
2. **Read the failing code** — `READ: path/to/file.py` at the exact location
3. **Understand the context** — why does this error occur?
4. **Fix precisely** — make the minimal change that resolves the error
5. **Verify the fix** — run the same command that failed
6. **Run full suite** — ensure you didn't break anything else

### Quality Gates (Check ALL before completing)
- [ ] All tests pass (`RUN: pytest -v` or `RUN: npm test`)
- [ ] No syntax errors (`RUN: python -m py_compile *.py` or build command)
- [ ] No lint errors (`RUN: ruff check .` or `RUN: eslint .` if available)
- [ ] No type errors (`RUN: mypy .` or `RUN: tsc --noEmit` if available)
- [ ] Code follows existing project patterns
- [ ] New code has corresponding tests
- [ ] Edge cases are handled

### Incremental Verification
Don't wait until the end to test. After each significant change:
1. Save the file (FILE: block)
2. Run relevant test (`RUN: pytest tests/test_specific.py -v`)
3. Fix any failures immediately
4. Only then proceed to next change

### Error Pattern Recognition
Common errors and fixes:
- `ImportError`: Check module path, __init__.py, PYTHONPATH
- `AttributeError`: Object doesn't have that attribute — check spelling, type
- `TypeError`: Wrong argument count or type — check function signature
- `SyntaxError`: Missing colon, bracket, quote — check the line above/below
- `IndentationError`: Mixed tabs/spaces — use consistent indentation
- `KeyError`: Key doesn't exist — use .get() or check key existence
- `FileNotFoundError`: Path wrong — use relative paths, check cwd

### Professional Code Standards
- **Imports**: Group (stdlib, third-party, local), alphabetize
- **Functions**: Single responsibility, clear names, type hints
- **Error handling**: Catch specific exceptions, provide useful messages
- **Documentation**: Docstrings for public APIs, inline comments for complex logic
- **Testing**: 1+ tests per function, cover edge cases, meaningful assertions

## ABSOLUTE RULES FOR TOOL USAGE
1. ALWAYS explore before modifying — use READ: on any file you plan to change.
2. EVERY response MUST contain FILE: blocks with working code OR tool commands (RUN: / READ: / SEARCH:).
3. Use TDD: write tests FIRST, then implementation that makes them pass.
4. Use RELATIVE paths from the project root (e.g. src/feature.py NOT /Users/.../src/feature.py).
5. Output COMPLETE files — no "..." or "rest stays the same".
6. NEVER ask the user to do something you can do with your tools.
"""

_LOCAL_AGENT_SYSTEM_PROMPT_TEMPLATE = """\
You are SAGE, an autonomous coding agent working in: {cwd}

## Tools
READ: path — read a file
SEARCH: pattern — find code
RUN: command — run shell command
FILE: path/to/file.ext
```
content
```
— write a file (COMPLETE contents only)

## TDD (MANDATORY — NO EXCEPTIONS)
You MUST follow Test-Driven Development:
1. **RED**: Write failing test FIRST (FILE: tests/test_*.py)
2. **RUN**: Execute test, see it FAIL (RUN: pytest tests/test_*.py -v)
3. **GREEN**: Write minimum code to pass (FILE: src/*.py)
4. **RUN**: Execute test, see it PASS (RUN: pytest -v)
5. **REFACTOR**: Clean up while keeping tests green

NEVER write implementation before tests. This is a CRITICAL rule.

## Smart Commit Messages (MANDATORY)
Use Conventional Commits: `type(scope): description`
- `feat(auth): add JWT token refresh` ✓
- `fix(api): prevent timeout on large requests` ✓
- `refactor(utils): extract validation to helper` ✓
- `fixed stuff` ✗ WRONG
- `changes` ✗ WRONG

## DevOps (use RUN: for these)
- Git: `RUN: git status`, `RUN: git diff --staged`, `RUN: git add -A`
- Commit: `RUN: git commit -m "type(scope): description"`
- Push: `RUN: git push`
- CI: `RUN: gh run watch` — WAIT for CI, fix if fails

## Rules
1. READ: files BEFORE editing them.
2. Write tests FIRST, then implementation (TDD).
3. Use RUN: to run tests and verify EVERY change.
4. Fix ALL errors until tests pass.
5. Use RELATIVE paths only.
6. Never invent modules or files that don't exist.
7. NO placeholders, NO TODOs, NO "..." — COMPLETE code only.
8. After push: `RUN: gh run watch` — wait for CI, fix failures.

## FORBIDDEN (instant rejection)
- Empty functions: `def foo(): pass` — EVERY function must have REAL code
- Tests without assertions: `def test_x(): pass` — MUST assert something
- Placeholder comments: "# TODO", "# implement this", "# if needed"
- Repetitive stub functions — write ONLY what's needed
- Code you haven't tested — RUN: pytest after every FILE: block

If unsure, READ: existing files first. Write MINIMAL, WORKING code.

## Example TDD workflow
User: "Add a hello function"

READ: src/utils.py
(see existing code)

FILE: tests/test_hello.py
```python
from src.utils import hello
def test_hello():
    assert hello("world") == "Hello, world!"
```

FILE: src/utils.py
```python
def hello(name):
    return f"Hello, {{name}}!"
```

RUN: python -m pytest tests/test_hello.py -v
"""


def _build_agent_system_prompt(cwd: Path, is_local: bool) -> str:
    """Choose system prompt size based on model context constraints."""
    template = (
        _LOCAL_AGENT_SYSTEM_PROMPT_TEMPLATE
        if is_local
        else _AGENT_SYSTEM_PROMPT_TEMPLATE
    )
    return template.format(cwd=cwd)


def _detect_test_files(written: list[str]) -> list[str]:
    """Return test file paths from a list of written files."""
    return [
        f for f in written if Path(f).name.startswith("test_") and f.endswith(".py")
    ]


def _detect_runnable_files(written: list[str]) -> list[str]:
    """Return Python files that can be syntax-checked."""
    return [f for f in written if f.endswith(".py")]


def _discover_workspace_project_roots(cwd: Path, max_depth: int = 3) -> list[Path]:
    """Find likely project roots under the current workspace."""
    markers = ("pyproject.toml", "package.json", "Cargo.toml", "go.mod")
    skip_dirs = {
        ".git",
        ".venv",
        "__pycache__",
        "node_modules",
        "dist",
        "build",
        ".pytest_cache",
        ".mypy_cache",
    }
    roots: list[Path] = []
    seen: set[Path] = set()

    def _is_project_root(path: Path) -> bool:
        return any((path / marker).exists() for marker in markers)

    def _walk(path: Path, depth: int) -> None:
        resolved = path.resolve()
        if resolved in seen:
            return
        seen.add(resolved)

        if _is_project_root(path):
            roots.append(resolved)

        if depth >= max_depth:
            return

        try:
            children = list(path.iterdir())
        except OSError:
            return

        for child in children:
            if not child.is_dir():
                continue
            if child.name in skip_dirs or child.name.startswith("."):
                continue
            _walk(child, depth + 1)

    _walk(cwd.resolve(), 0)
    return roots


def _project_root_score(project_root: Path, cwd: Path) -> tuple[int, int, int]:
    """Score a project root so the most relevant nested app wins."""
    score = 0
    if (project_root / "sage").is_dir():
        score += 12
    if (project_root / "tests" / "sage").is_dir():
        score += 10
    if (project_root / "backend").is_dir():
        score += 4
    if (project_root / "frontend").is_dir():
        score += 4
    if (project_root / "tests").is_dir():
        score += 3
    if (project_root / "pyproject.toml").exists():
        score += 4
    if (project_root / "package.json").exists():
        score += 2
    rel_depth = len(project_root.relative_to(cwd.resolve()).parts)
    return (score, rel_depth, len(project_root.parts))


def _default_project_root(cwd: Path) -> Path:
    """Pick the most relevant project root in the workspace."""
    roots = _discover_workspace_project_roots(cwd)
    if not roots:
        return cwd.resolve()
    return max(roots, key=lambda root: _project_root_score(root, cwd))


def _discover_npm_script(project_root: Path, script_name: str) -> str | None:
    """Return an npm script definition when package.json declares it."""
    package_json = project_root / "package.json"
    if not package_json.exists():
        return None
    try:
        data = _json.loads(package_json.read_text("utf-8"))
    except (ValueError, OSError):
        return None

    scripts = data.get("scripts")
    if not isinstance(scripts, dict):
        return None
    value = scripts.get(script_name)
    if not isinstance(value, str):
        return None
    value = value.strip()
    if not value or "no test specified" in value.lower():
        return None
    return value


def _discover_python_test_command(
    project_root: Path, prefer_sage_subset: bool = False
) -> str | None:
    """Return the best Python test command for a project root, if any."""
    has_pytest_suite = any(
        (project_root / marker).exists()
        for marker in ("tests", "pytest.ini", "tox.ini")
    )
    if not has_pytest_suite:
        return None

    if (
        prefer_sage_subset
        and (project_root / "sage").exists()
        and (project_root / "tests" / "sage").exists()
    ):
        return "python -m pytest tests/sage -v --tb=short"
    return "python -m pytest -v --tb=short"


def _discover_project_test_command(project_root: Path) -> str | None:
    """Return a project-aware test command for Python, JS, Go, or Rust."""
    js_test = _discover_npm_script(project_root, "test")
    if js_test:
        lower = js_test.lower()
        if "vitest" in lower:
            return "npm test -- --run"
        if "jest" in lower:
            return "npm test -- --runInBand"
        if "react-scripts test" in lower:
            return "CI=1 npm test -- --watch=false"
        return "npm test"

    python_cmd = _discover_python_test_command(project_root, prefer_sage_subset=True)
    if python_cmd:
        return python_cmd

    if (project_root / "Cargo.toml").exists():
        return "cargo test"
    if (project_root / "go.mod").exists():
        return "go test ./..."
    return None


def _discover_project_root_for_file(filepath: str, cwd: Path) -> Path:
    """Find the nearest project root that owns a written file."""
    try:
        target = (cwd / filepath).resolve()
    except (OSError, ValueError):
        return cwd.resolve()

    workspace_root = cwd.resolve()
    if not str(target).startswith(str(workspace_root)):
        return workspace_root

    current = target if target.is_dir() else target.parent
    markers = ("pyproject.toml", "package.json", "Cargo.toml", "go.mod", "tests")
    while True:
        if any((current / marker).exists() for marker in markers):
            return current
        if current == workspace_root:
            return workspace_root
        parent = current.parent
        if not str(parent).startswith(str(workspace_root)):
            return workspace_root
        current = parent


def _command_from_project_root(project_root: Path, command: str, cwd: Path) -> str:
    """Prefix a command with `cd` when validation belongs to a nested project."""
    root = project_root.resolve()
    base = cwd.resolve()
    if root == base:
        return command
    rel = root.relative_to(base)
    return f"[cwd={rel.as_posix()}] {command}"


def _validation_command_for_written_files(written: list[str], cwd: Path) -> str | None:
    """Return the best validation command for changed files in a workspace."""
    if not written:
        project_root = _default_project_root(cwd)
        inner = _discover_project_test_command(project_root)
        if inner:
            return _command_from_project_root(project_root, inner, cwd)
        return None

    roots = Counter(_discover_project_root_for_file(fp, cwd) for fp in written)
    project_root = max(
        roots.items(), key=lambda item: (item[1], len(item[0].resolve().parts))
    )[0]

    normalized: list[str] = []
    for fp in written:
        try:
            target = (cwd / fp).resolve()
            if str(target).startswith(str(project_root.resolve())):
                normalized.append(target.relative_to(project_root).as_posix())
        except (OSError, ValueError):
            continue

    test_files = _detect_test_files(normalized)
    if test_files:
        inner = (
            "python -m pytest "
            + " ".join(_shell_quote(path) for path in test_files)
            + " -v --tb=short"
        )
        return _command_from_project_root(project_root, inner, cwd)

    if any(path.endswith(".py") for path in normalized):
        prefer_sage_subset = any(
            Path(path).parts and Path(path).parts[0] == "sage" for path in normalized
        )
        inner = _discover_python_test_command(
            project_root, prefer_sage_subset=prefer_sage_subset
        )
        if inner:
            return _command_from_project_root(project_root, inner, cwd)

    if any(
        path.endswith((".js", ".jsx", ".ts", ".tsx")) or path == "package.json"
        for path in normalized
    ):
        inner = _discover_project_test_command(project_root)
        if inner:
            return _command_from_project_root(project_root, inner, cwd)

    inner = _discover_project_test_command(project_root)
    if inner:
        return _command_from_project_root(project_root, inner, cwd)
    return None


def _run_validation_command(cmd: str, cwd: Path, timeout: int = 120) -> tuple[str, str]:
    """Run a validation command, falling back from `python -m pytest` to `pytest`."""
    output = _run_shell(cmd, cwd, timeout=timeout)
    if "No module named pytest" in output and "python -m pytest" in cmd:
        cmd = cmd.replace("python -m pytest", "pytest", 1)
        output = _run_shell(cmd, cwd, timeout=timeout)
    return cmd, output


def _syntax_precheck(written: list[str], cwd: Path) -> tuple[bool, str]:
    """Pre-check syntax of written files before running tests.

    Returns (all_ok, error_details).
    This catches errors early before slower test runs.
    """
    errors = []
    for filepath in written:
        full_path = cwd / filepath
        if not full_path.exists():
            continue

        # Python syntax check
        if filepath.endswith(".py"):
            result = _run_shell(
                f'python -m py_compile "{filepath}"',
                cwd,
                timeout=10,
            )
            if result.strip() and ("Error" in result or "exit code" in result):
                # Get more detailed error with line number
                detail_result = _run_shell(
                    f'python -c "import ast; ast.parse(open(\'{filepath}\').read())"',
                    cwd,
                    timeout=10,
                )
                errors.append(f"SYNTAX ERROR in {filepath}:\n{detail_result}")

        # JavaScript/TypeScript basic check
        elif filepath.endswith((".js", ".ts", ".jsx", ".tsx")):
            # Check for obvious syntax errors using node --check if available
            result = _run_shell(
                f'node --check "{filepath}" 2>&1 || echo "exit code: $?"',
                cwd,
                timeout=10,
            )
            if "SyntaxError" in result or "Unexpected" in result:
                errors.append(f"SYNTAX ERROR in {filepath}:\n{result}")

        # JSON validation
        elif filepath.endswith(".json"):
            result = _run_shell(
                f'python -c "import json; json.load(open(\'{filepath}\'))"',
                cwd,
                timeout=5,
            )
            if "Error" in result or "exit code" in result:
                errors.append(f"INVALID JSON in {filepath}:\n{result}")

        # YAML validation
        elif filepath.endswith((".yml", ".yaml")):
            result = _run_shell(
                f'python -c "import yaml; yaml.safe_load(open(\'{filepath}\'))"',
                cwd,
                timeout=5,
            )
            if "Error" in result or "exit code" in result:
                errors.append(f"INVALID YAML in {filepath}:\n{result}")

    if errors:
        return False, "\n\n".join(errors)
    return True, ""


def _auto_validate(written: list[str], cwd: Path) -> str | None:
    """Run automatic validation on written files. Returns (cmd, output) or None.

    Validation order:
    1. Syntax pre-check (fast, catches obvious errors)
    2. Project-specific validation (pytest, npm test, etc.)
    3. Fallback syntax-only check if no test framework found
    """
    # Step 1: Fast syntax pre-check
    syntax_ok, syntax_errors = _syntax_precheck(written, cwd)
    if not syntax_ok:
        return "syntax pre-check", syntax_errors

    # Step 2: Project-specific validation
    validation_cmd = _validation_command_for_written_files(written, cwd)
    if validation_cmd:
        return _run_validation_command(validation_cmd, cwd, timeout=120)

    # Step 3: Fallback - at least check Python files compile
    runnable = _detect_runnable_files(written)
    if runnable:
        checks = []
        for f in runnable:
            result = _run_shell(
                f"python -c \"import ast; ast.parse(open('{f}').read())\"",
                cwd,
                timeout=10,
            )
            if "exit code" in result or "Error" in result:
                checks.append(f"{f}: {result}")
        if checks:
            return "python syntax check", "\n".join(checks)

    return None


def _default_test_command(cwd: Path) -> str:
    """Pick a sensible default pytest command for the current project."""
    project_root = _default_project_root(cwd)
    inner = _discover_project_test_command(project_root)
    if inner:
        return _command_from_project_root(project_root, inner, cwd)
    return "python -m pytest -v --tb=short"


def _response_describes_code_without_file_blocks(response: str) -> bool:
    """Detect code-change narratives that never emit executable FILE blocks."""
    if "FILE:" in response:
        return False

    path_listing = re.search(
        r"(?m)^\s*(?:#+\s*)?(?:[\w.-]+/)+[\w.-]+\.(?:py|js|ts|tsx|jsx|json|toml|ya?ml|sh|md|sql|go|rs|java|css|html)\s*$",
        response,
    )
    has_change_sections = any(
        marker in response
        for marker in ("Code Changes", "Tests Written", "Final Status")
    )
    has_fenced_code = response.count("```") >= 2
    return bool(path_listing and (has_change_sections or has_fenced_code))


def _summarize_test_output(output: str, max_chars: int = 6000) -> str:
    """Condense long test output into failure-focused context for fix prompts."""
    text = output.strip()
    if len(text) <= max_chars:
        return text

    lines = text.splitlines()
    keep: list[str] = []
    for i, line in enumerate(lines):
        low = line.lower()
        if (
            "error collecting" in low
            or "short test summary info" in low
            or "traceback" in low
            or line.startswith("E   ")
            or " failed " in low
            or line.startswith("FAILED ")
            or line.startswith("ERROR ")
        ):
            start = max(0, i - 2)
            end = min(len(lines), i + 6)
            keep.extend(lines[start:end])

    if not keep:
        return text[-max_chars:]

    deduped = []
    seen = set()
    for ln in keep:
        if ln not in seen:
            deduped.append(ln)
            seen.add(ln)
    summary = "\n".join(deduped)
    return summary[:max_chars]


def _has_errors(output: str) -> bool:
    """Check if command output indicates failure.

    Comprehensive error detection for multiple languages and frameworks.
    """
    # Python errors
    python_errors = [
        "SyntaxError",
        "IndentationError",
        "TabError",
        "NameError",
        "TypeError",
        "ValueError",
        "KeyError",
        "IndexError",
        "AttributeError",
        "ImportError",
        "ModuleNotFoundError",
        "FileNotFoundError",
        "RuntimeError",
        "ZeroDivisionError",
        "AssertionError",
        "Exception:",
        "Traceback (most recent call last)",
    ]

    # Test framework errors
    test_errors = [
        "FAILED",
        "ERROR",
        "FAILURES",
        "error collecting",
        "E   ",  # pytest assertion error marker
        "✗",  # Jest/Vitest failure
        "✕",  # Another failure marker
        "FAIL ",  # Go test
        "--- FAIL:",  # Go test
        "FAILED TEST",
        "tests? failed",
    ]

    # Build/lint errors
    build_errors = [
        "error:",
        "Error:",
        "error[",  # Rust errors
        "error TS",  # TypeScript errors
        "✖",  # ESLint errors
        "npm ERR!",
        "yarn error",
        "cargo error",
        "build failed",
        "compilation failed",
        "exit code:",
        "exit status 1",
        "returned non-zero",
    ]

    # CI/CD errors
    ci_errors = [
        "check failure",
        "workflow failed",
        "job failed",
        "Action required",
    ]

    all_signals = python_errors + test_errors + build_errors + ci_errors

    # Case-sensitive check for most signals
    for sig in all_signals:
        if sig in output:
            return True

    # Case-insensitive check for generic error patterns
    lower_output = output.lower()
    generic_errors = ["fatal:", "panic:", "segmentation fault", "core dumped"]
    for sig in generic_errors:
        if sig in lower_output:
            return True

    # Check for pytest/jest summary patterns
    if re.search(r"\d+ failed", lower_output):
        return True
    if re.search(r"tests?: \d+ failed", lower_output):
        return True

    return False


def _discover_project_modules(cwd: Path, max_depth: int = 3) -> list[str]:
    """Scan project directory and return available Python module paths.

    This helps the model know what imports are valid instead of hallucinating.
    """
    modules: list[str] = []
    for py_file in cwd.rglob("*.py"):
        try:
            rel = py_file.relative_to(cwd)
        except ValueError:
            continue
        # Skip hidden dirs, __pycache__, node_modules, etc.
        parts = rel.parts
        if any(p.startswith(".") or p == "__pycache__" or p == "node_modules" for p in parts):
            continue
        if len(parts) > max_depth + 1:
            continue
        # Convert path to module: sage/core/engine.py -> sage.core.engine
        if py_file.name == "__init__.py":
            mod = ".".join(parts[:-1])
        else:
            mod = ".".join(parts)[:-3]  # strip .py
        if mod:
            modules.append(mod)
    return sorted(set(modules))[:50]  # Cap at 50 to avoid overflow


def _build_smart_error_context(output: str, written: list[str], cwd: Path) -> str:
    """Build context-aware error feedback with module discovery.

    Claude Code-like smart diagnostics that provide:
    - Available modules when ImportError occurs
    - Project structure when FileNotFoundError occurs
    - Line context when specific line numbers are referenced
    - Suggested fixes based on error patterns
    """
    extra = []

    # Module not found — show what modules actually exist
    if "ModuleNotFoundError" in output or "ImportError" in output:
        modules = _discover_project_modules(cwd)
        if modules:
            extra.append(
                "AVAILABLE PROJECT MODULES (use these for imports):\n"
                + "\n".join(f"  - {m}" for m in modules[:30])
                + "\n\nDo NOT import modules that are not in this list. "
                "Use the correct module paths shown above."
            )

        # Extract the module name that failed to import
        import_match = re.search(r"No module named ['\"]([^'\"]+)['\"]", output)
        if import_match:
            bad_module = import_match.group(1)
            extra.append(
                f"FAILED IMPORT: '{bad_module}'\n"
                "COMMON FIXES:\n"
                "- Check spelling of module name\n"
                "- Ensure __init__.py exists in package directories\n"
                "- Use relative imports if within same package\n"
                "- Verify the module file exists before importing"
            )

    # File not found — show project tree
    if "FileNotFoundError" in output or "No such file" in output:
        tree_result = _run_shell(
            "find . -name '*.py' -not -path './__pycache__/*' -not -path './.git/*' | head -30",
            cwd,
            timeout=5,
        )
        if tree_result.strip():
            extra.append(f"PROJECT FILES:\n{tree_result}")

    # Syntax error — extract line info and suggest fix
    if "SyntaxError" in output:
        line_match = re.search(r"line (\d+)", output)
        if line_match:
            line_num = line_match.group(1)
            extra.append(
                f"SYNTAX ERROR at line {line_num}\n"
                "COMMON CAUSES:\n"
                "- Missing colon after if/for/def/class\n"
                "- Unclosed parentheses, brackets, or quotes\n"
                "- Incorrect indentation\n"
                "- Missing comma in list/dict/function args"
            )

    # IndentationError — specific guidance
    if "IndentationError" in output or "TabError" in output:
        extra.append(
            "INDENTATION ERROR\n"
            "FIXES:\n"
            "- Use consistent 4-space indentation (no tabs)\n"
            "- Check that all lines in a block have same indent\n"
            "- Ensure no mixed tabs and spaces"
        )

    # NameError — variable not defined
    if "NameError" in output:
        name_match = re.search(r"name ['\"]([^'\"]+)['\"] is not defined", output)
        if name_match:
            bad_name = name_match.group(1)
            extra.append(
                f"UNDEFINED NAME: '{bad_name}'\n"
                "COMMON FIXES:\n"
                "- Check spelling of variable/function name\n"
                "- Ensure it's defined before use\n"
                "- Add missing import if it's from another module\n"
                "- Check variable scope (local vs global)"
            )

    # TypeError — wrong argument count or type
    if "TypeError" in output:
        arg_match = re.search(r"takes (\d+) .*arguments? but (\d+)", output)
        if arg_match:
            expected, got = arg_match.group(1), arg_match.group(2)
            extra.append(
                f"ARGUMENT COUNT MISMATCH: expected {expected}, got {got}\n"
                "FIX: Check the function signature and match the argument count"
            )

    # AssertionError — test failure
    if "AssertionError" in output:
        extra.append(
            "TEST ASSERTION FAILED\n"
            "DEBUG STEPS:\n"
            "1. Check expected vs actual values in the assertion\n"
            "2. Verify the implementation logic\n"
            "3. Add print/debug statements if needed\n"
            "4. Ensure test data matches expected format"
        )

    # AttributeError — object doesn't have attribute
    if "AttributeError" in output:
        attr_match = re.search(r"['\"]([^'\"]+)['\"] object has no attribute ['\"]([^'\"]+)['\"]", output)
        if attr_match:
            obj_type, attr_name = attr_match.group(1), attr_match.group(2)
            extra.append(
                f"ATTRIBUTE ERROR: '{obj_type}' has no attribute '{attr_name}'\n"
                "COMMON FIXES:\n"
                "- Check spelling of attribute name\n"
                "- Verify the object type is what you expect\n"
                "- Check if you're accessing a None value\n"
                "- Ensure the attribute exists on this type"
            )

    if extra:
        return "\n\n".join(extra)
    return ""


def _detect_repetition(responses: list[str], current: str) -> bool:
    """Detect if the model is stuck in a loop producing identical responses."""
    if not responses:
        return False
    # Check if current response matches any of the last 2 responses
    current_stripped = current.strip()[:500]  # Compare first 500 chars
    for prev in responses[-2:]:
        if prev.strip()[:500] == current_stripped:
            return True
    return False


def _is_complex_task(task: str) -> bool:
    """Heuristic: does this task benefit from multi-step decomposition?

    Complex tasks have multiple sub-objectives, mention multiple files,
    or use words suggesting multi-part work. Simple tasks (explain X,
    fix typo, rename Y) don't need decomposition overhead.
    """
    lower = task.lower()
    # Multi-part indicators
    multi_indicators = [
        " and ",
        " then ",
        " also ",
        " with tests",
        "add a .* and",
        "create .* including",
        "implement",
        "build",
        "refactor",
        "migrate",
    ]
    score = sum(1 for pat in multi_indicators if re.search(pat, lower))
    # Long prompts are usually complex
    if len(task.split()) > 25:
        score += 1
    # Mentions multiple files
    file_mentions = re.findall(r"[\w/]+\.(?:py|js|ts|go|rs|java)\b", task)
    if len(file_mentions) >= 2:
        score += 1
    return score >= 2


def _expand_prompt(user_input: str) -> str:
    """Expand user prompts with detailed instructions for the model.

    Detects the type of request and adds specific guidance so that smaller
    models can produce high-quality results comparable to larger models.
    """
    lower = user_input.lower().strip()

    # ── Vague analysis/improvement requests ───────────────
    vague_triggers = [
        "analyze this",
        "analyze the code",
        "analyze code",
        "analyze",
        "improve this",
        "improve the code",
        "make it better",
        "review this",
        "review the code",
        "review code",
        "refactor this",
        "refactor the code",
        "fix this",
        "fix the code",
        "fix bugs",
        "what can be improved",
        "what's wrong",
        "look at this",
        "check this",
    ]
    for trigger in vague_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: You have the full codebase. Follow these steps:\n"
                "1. Identify the 3 most impactful improvements (bugs, performance, security, code quality)\n"
                "2. For each improvement, write a test that exposes the issue (FILE: tests/test_improvement_N.py)\n"
                "3. Write the fix (FILE: path/to/fixed_file.py)\n"
                "4. Include ```bash blocks to run the tests\n"
                "Reference specific files and line numbers from the project context."
            )

    # ── Deployment requests ────────────────────────────────
    deploy_triggers = [
        "deploy",
        "deployment",
        "ship it",
        "push to prod",
        "production",
        "hosting",
        "publish",
        "release",
    ]
    for trigger in deploy_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Create a complete deployment setup:\n"
                "1. Detect the tech stack from the project files\n"
                "2. Write a Dockerfile if the project doesn't have one\n"
                "3. Write a deployment config (docker-compose.yml, or platform-specific: fly.toml, vercel.json, railway.json, etc.)\n"
                "4. Add pre-deploy validation and health checks\n"
                "5. Write a deploy script (scripts/deploy.sh) that automates the process\n"
                "6. Create .env.example with all required environment variables (never hardcode secrets)\n"
                "7. Update .gitignore to exclude .env and other sensitive files\n"
                "8. Document a rollback path and staging/production separation\n"
                "9. Include ```bash blocks to test the deployment locally\n"
                "Use FILE: blocks for every file."
            )

    # ── CI/CD requests ─────────────────────────────────────
    ci_triggers = [
        "ci/cd",
        "ci cd",
        "pipeline",
        "github action",
        "gitlab ci",
        "continuous",
    ]
    for trigger in ci_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Create a CI/CD pipeline:\n"
                "1. Detect the tech stack and test framework\n"
                "2. Write .github/workflows/ci.yml (or equivalent) with fail-fast lint, test, and build stages\n"
                "3. Cache dependencies when the platform supports it\n"
                "4. Block merges when validation fails\n"
                "5. Add a deployment stage only after validation passes if requested\n"
                "6. Create any missing test scripts\n"
                "Use FILE: blocks for every file."
            )

    # ── Secret/env management ──────────────────────────────
    secret_triggers = [
        "secret",
        "env var",
        "environment variable",
        "api key",
        "credential",
        ".env",
    ]
    for trigger in secret_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Set up secure configuration:\n"
                "1. Create .env.example with all variables (placeholder values only)\n"
                "2. Write a config loader that reads from env vars with sensible defaults\n"
                "3. Add .env to .gitignore\n"
                "4. Write tests for the config loader\n"
                "NEVER put real secrets in code. Use FILE: blocks for every file."
            )

    # ── Docker requests ────────────────────────────────────
    docker_triggers = ["docker", "container", "containerize"]
    for trigger in docker_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Create Docker setup:\n"
                "1. Write a Dockerfile optimized for the project's tech stack\n"
                "2. Write docker-compose.yml if the app has services (db, cache, etc.)\n"
                "3. Write .dockerignore\n"
                "4. Include ```bash blocks to build and test the image\n"
                "Use FILE: blocks for every file."
            )

    # ── Database requests ──────────────────────────────────
    db_triggers = ["database", "migration", "schema", "sql", "orm", "model"]
    for trigger in db_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS:\n"
                "1. Check what database/ORM the project uses\n"
                "2. Write migration files if needed\n"
                "3. Write model/schema code\n"
                "4. Write tests with a test database\n"
                "5. Include ```bash blocks to run migrations and tests\n"
                "Use FILE: blocks for every file."
            )

    # ── Testing requests ───────────────────────────────────
    test_triggers = [
        "write test",
        "add test",
        "test coverage",
        "unit test",
        "integration test",
    ]
    for trigger in test_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS:\n"
                "1. Identify what needs testing from the project files\n"
                "2. Write comprehensive tests covering: happy path, edge cases, error cases\n"
                "3. Include ```bash blocks to run the tests\n"
                "Use FILE: blocks for every test file."
            )

    # ── Build/create from scratch ──────────────────────────
    build_triggers = [
        "create",
        "build",
        "make",
        "add",
        "implement",
        "write",
        "set up",
        "setup",
    ]
    for trigger in build_triggers:
        if (
            trigger in lower and len(lower) > len(trigger) + 5
        ):  # Only if there's substance
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Think step by step:\n"
                "1. What exactly needs to be built? List the components.\n"
                "2. What existing code can you build on? Check the project files.\n"
                "3. Write tests first for the core functionality\n"
                "4. Write the implementation\n"
                "5. Include ```bash blocks to verify everything works\n"
                "Use FILE: blocks for every file."
            )

    return user_input


def _enhance_task_prompt(user_input: str) -> str:
    """Always enhance task prompts before model execution."""
    expanded = _expand_prompt(user_input)
    if expanded != user_input:
        return expanded
    return (
        f"{user_input}\n\n"
        "INSTRUCTIONS:\n"
        "1. Restate the task goal in one sentence.\n"
        "2. Identify constraints and assumptions.\n"
        "3. Use READ:/SEARCH: before edits and prefer minimal, verifiable changes.\n"
        "4. Validate with tests or runnable commands.\n"
        "5. If writing code, emit complete FILE: blocks.\n"
    )


# ── Commands ────────────────────────────────────────────────


@app.command()
def run(
    model: Annotated[
        Optional[str], typer.Option("--model", "-m", help="Model ID")
    ] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    auto_run: Annotated[
        bool,
        typer.Option(
            "--auto-run/--no-auto-run",
            help="Auto-execute bash blocks without prompting",
        ),
    ] = True,
    max_retries: Annotated[
        int, typer.Option("--max-retries", help="Max auto-fix retries on test failure")
    ] = 10,
) -> None:
    """Interactive coding agent — project-aware, auto-writes files (like Claude Code).

    DevOps Integration: SAGE automatically monitors CI/CD when you push code.
    When you run `git push`, SAGE will wait for the CI pipeline to complete and
    report any failures so the AI can fix them.
    """
    cwd = Path.cwd()
    cfg = load_config()
    router = _build_router(cfg)
    prompt_reader = _build_prompt_reader(cwd)

    last_used_model = _get_last_used_model(cwd)
    model_id = model or last_used_model or cfg.default_model
    model_id = _resolve_model_prefix(model_id, cfg)
    model_id = _auto_upgrade_model_if_possible(
        router, cfg, model_id, explicit_model=model, last_used_model=last_used_model
    )

    # Auto-download local models if not installed
    cfg = _ensure_model_available(cfg, model_id)
    # Rebuild router with updated config (may have new registered models)
    router = _build_router(cfg)

    _set_last_used_model(cwd, model_id)
    temp = temperature if temperature is not None else 0.1
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens
    default_test_cmd = _default_test_command(cwd)

    # Use lighter scan for local models to reduce prompt processing time
    is_local = (
        model_id.startswith("llama_cpp:")
        or model_id.startswith("ollama:")
        or cfg.get_local_model(model_id) is not None
    )
    with renderer.status_spinner("Scanning project...", "reading"):
        if is_local:
            context = _scan_project_context(
                cwd, max_tree=8, max_source_files=1, max_source_lines=8
            )
        else:
            context = _scan_project_context(cwd)
    renderer.step_done("Project scanned")

    # Set token limits: local models balance speed vs output, API models get full room
    if is_local and tokens == cfg.max_tokens:
        tokens = 4096  # Enough for TDD output with 16K context window
    elif not is_local and tokens == cfg.max_tokens:
        tokens = max(tokens, 32768)

    # Build initial conversation with project context
    system_prompt = _build_agent_system_prompt(cwd, is_local=is_local)
    engine = ConversationEngine(
        system_prompt=system_prompt,
        max_history=50,
    )

    bootstrap_user = (
        (
            "Project scan complete. Keep context compact and use READ:/SEARCH: for deep inspection.\n\n"
            f"{context}"
        )
        if is_local
        else (
            "Here is the full project codebase you are working on. "
            "You have already scanned it and have access to all the files listed below. "
            "When the user asks you to analyze, improve, or work on 'this code' or 'the code', "
            "they mean the project files below. Do NOT ask them to provide code — you already have it.\n\n"
            f"{context}"
        )
    )
    messages_init = [
        {"role": "user", "content": bootstrap_user},
        {
            "role": "assistant",
            "content": (
                "I've scanned the project and have full context of the codebase. "
                "I can see all files, the language, dependencies, and code structure. "
                "What would you like me to do?"
            ),
        },
    ]
    for m in messages_init:
        if m["role"] == "user":
            engine.add_user(m["content"])
        else:
            engine.add_assistant(m["content"])

    renderer.print_agent_welcome(model_id, str(cwd))

    last_written: list[str] = []
    all_written: list[str] = []
    multiline_buffer: list[str] | None = None

    # Scan existing files to protect them from accidental overwrites
    _protected: set[str] = set()
    for p in cwd.rglob("*"):
        if p.is_file():
            try:
                rel = str(p.relative_to(cwd))
                parts = rel.split("/")
                if not any(part.startswith(".") or part == "__pycache__" or part == "node_modules" for part in parts):
                    _protected.add(rel)
            except ValueError:
                pass

    def _send_to_model(user_msg: str, show_thinking: bool = True) -> str | None:
        """Send a message to the model and stream the response. Returns response text.

        Ctrl+C during generation cancels and returns partial output.
        """
        nonlocal tokens
        engine.add_user(user_msg)
        messages = engine.build_messages()
        try:
            if show_thinking:
                response = renderer.stream_tokens_with_phase(
                    router.stream(messages, model_id, temp, tokens),
                    model_id=model_id,
                )
            else:
                renderer.console.print("[bold green]sage>[/bold green] ", end="")
                response = renderer.stream_tokens(
                    router.stream(messages, model_id, temp, tokens)
                )
            if response:
                engine.add_assistant(response)
            else:
                engine._messages.pop()  # Remove user message if no response
            return response or None
        except KeyboardInterrupt:
            renderer.console.print("\n  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
            engine._messages.pop()  # Remove the failed user message
            return None
        except Exception as exc:
            err_msg = str(exc)
            err_lower = err_msg.lower()
            is_provider_failure = "all providers failed" in err_lower
            is_context_error = (
                "exceed context" in err_lower
                or "too many tokens" in err_lower
                or "context window" in err_lower
                or (
                    is_provider_failure
                    and ("requested tokens" in err_lower or "llama_cpp" in err_lower)
                )
            )
            is_transient_gateway = (
                "502 bad gateway" in err_lower
                or "503 service unavailable" in err_lower
                or "504 gateway timeout" in err_lower
                or (is_provider_failure and ("404 not found" in err_lower))
            )
            if is_context_error or is_transient_gateway:
                renderer.warning(
                    "Context window full — trimming old messages and retrying..."
                )
                engine._messages.pop()  # Remove the user message we just added
                if is_local:
                    engine._messages[:] = []
                elif len(engine._messages) > 6:
                    engine._messages[:] = engine._messages[:2] + engine._messages[-4:]

                for retry_idx in range(2):
                    old_tokens = tokens
                    match = re.search(
                        r"requested tokens \((\d+)\) exceed context window of (\d+)",
                        err_lower,
                    )
                    if match:
                        requested = int(match.group(1))
                        window = int(match.group(2))
                        overflow = max(1, requested - window)
                        tokens = max(256, min(tokens - overflow - 256, window - 768))
                    elif is_transient_gateway:
                        tokens = max(256, int(tokens * 0.8))
                    else:
                        tokens = max(256, int(tokens * 0.7))
                    if is_local:
                        tokens = min(tokens, 2048)
                    if tokens != old_tokens:
                        renderer.warning(
                            f"Adjusted context (max_tokens {old_tokens} -> {tokens}) and retrying..."
                        )
                    engine.add_user(user_msg)
                    try:
                        messages = engine.build_messages()
                        if show_thinking:
                            response = renderer.stream_tokens_with_phase(
                                router.stream(messages, model_id, temp, tokens),
                                model_id=model_id,
                            )
                        else:
                            renderer.console.print(
                                "[bold green]sage>[/bold green] ", end=""
                            )
                            response = renderer.stream_tokens(
                                router.stream(messages, model_id, temp, tokens)
                            )
                        if response:
                            engine.add_assistant(response)
                        else:
                            engine._messages.pop()
                        return response or None
                    except Exception as retry_exc:
                        engine._messages.pop()
                        err_msg = str(retry_exc)
                        err_lower = err_msg.lower()
                        if retry_idx == 1:
                            renderer.error(err_msg)
                            return None
                        if is_local:
                            engine._messages[:] = []
                        elif len(engine._messages) > 4:
                            engine._messages[:] = engine._messages[-4:]
                        continue
            engine._messages.pop()  # Remove the failed user message
            renderer.error(err_msg)
            return None

    def _send_to_model_autopolit(user_msg: str) -> str | None:
        """Send a message in autopolit mode (non-streaming, interruptible)."""
        nonlocal tokens
        engine.add_user(user_msg)
        messages = engine.build_messages()
        try:
            renderer.phase("thinking", "Autopolit running...")
            response = router.generate(messages, model_id, temp, tokens)
            renderer.console.print("[bold green]sage>[/bold green] ")
            renderer.render_markdown(response)
            if response:
                engine.add_assistant(response)
            else:
                engine._messages.pop()
            return response or None
        except KeyboardInterrupt:
            engine._messages.pop()
            raise
        except Exception as exc:
            err_msg = str(exc)
            err_lower = err_msg.lower()
            engine._messages.pop()
            is_provider_failure = "all providers failed" in err_lower
            is_context_error = (
                "exceed context" in err_lower
                or "too many tokens" in err_lower
                or "context window" in err_lower
                or (
                    is_provider_failure
                    and ("requested tokens" in err_lower or "llama_cpp" in err_lower)
                )
            )
            is_bad_request = "400 bad request" in err_lower
            is_transient_gateway = (
                "502 bad gateway" in err_lower
                or "503 service unavailable" in err_lower
                or "504 gateway timeout" in err_lower
                or (is_provider_failure and ("404 not found" in err_lower))
            )
            if is_context_error or is_bad_request or is_transient_gateway:
                # Keep bootstrap context + most recent turns only.
                if is_local:
                    engine._messages[:] = []
                elif len(engine._messages) > 6:
                    engine._messages[:] = engine._messages[:2] + engine._messages[-4:]
                old_tokens = tokens
                match = re.search(
                    r"requested tokens \((\d+)\) exceed context window of (\d+)",
                    err_lower,
                )
                if match:
                    requested = int(match.group(1))
                    window = int(match.group(2))
                    overflow = max(1, requested - window)
                    tokens = max(256, min(tokens - overflow - 128, window - 512))
                elif is_bad_request:
                    tokens = max(256, int(tokens * 0.75))
                elif is_transient_gateway:
                    tokens = max(256, int(tokens * 0.8))
                else:
                    tokens = max(256, int(tokens * 0.85))
                if is_local:
                    tokens = min(tokens, 2048)
                if tokens != old_tokens:
                    renderer.warning(
                        f"Autopolit adjusted context (max_tokens {old_tokens} -> {tokens}) and retrying..."
                    )
                else:
                    renderer.warning("Autopolit compacted context and retrying...")
                engine.add_user(user_msg)
                retry_messages = engine.build_messages()
                try:
                    renderer.phase("thinking", "Autopolit retry...")
                    retry_response = router.generate(
                        retry_messages, model_id, temp, tokens
                    )
                    renderer.console.print("[bold green]sage>[/bold green] ")
                    renderer.render_markdown(retry_response)
                    if retry_response:
                        engine.add_assistant(retry_response)
                    else:
                        engine._messages.pop()
                    return retry_response or None
                except KeyboardInterrupt:
                    engine._messages.pop()
                    raise
                except Exception as retry_exc:
                    engine._messages.pop()
                    renderer.error(str(retry_exc))
                    return None
            renderer.error(err_msg)
            return None

    def _process_response(response: str, tool_depth: int = 0) -> list[str]:
        """Process model response: write files, execute tool commands, run bash blocks.

        Handles the full agent loop:
        1. Execute READ:/SEARCH:/RUN: tool commands → feed results back to model
        2. Extract and write FILE: blocks
        3. Execute ```bash blocks
        Returns list of written files.
        """
        nonlocal last_written, all_written

        # ── Step 1: Execute tool commands (READ, SEARCH, RUN) ──
        if tool_depth >= 6:
            renderer.warning(
                "Tool loop depth limit reached. Requesting direct FILE: output next step."
            )
            return []

        if _response_describes_code_without_file_blocks(response):
            renderer.warning(
                "Response described code changes without FILE blocks. Ignoring shell execution until the model emits writable files."
            )
            return []

        tool_commands = _extract_tool_commands(response)
        if tool_commands:
            tool_results = _execute_tool_commands(tool_commands, cwd)
            if tool_results:
                per_result_limit = 1200 if is_local else 5000
                total_limit = 4000 if is_local else 20000
                compact_results: list[str] = []
                used = 0
                for item in tool_results:
                    trimmed = (
                        item
                        if len(item) <= per_result_limit
                        else item[:per_result_limit]
                    )
                    if used + len(trimmed) > total_limit:
                        break
                    compact_results.append(trimmed)
                    used += len(trimmed)
                # Feed tool results back to model for a follow-up
                tool_context = (
                    "\n\n".join(compact_results)
                    if compact_results
                    else "(no tool output)"
                )
                followup_prompt = (
                    f"Here are the results of your tool commands:\n\n{tool_context}\n\n"
                    "Now continue with your task. Write FILE: blocks for any files "
                    "that need to be created or modified."
                )
                followup = _send_to_model(followup_prompt, show_thinking=False)
                if followup:
                    # Recursively process the follow-up (it may have more tools or files)
                    return _process_response(followup, tool_depth + 1)

        # ── Step 2: Write FILE: blocks ─────────────────────────
        written = _extract_and_write_files(response, cwd, protected_files=_protected)
        if written:
            last_written = written
            all_written.extend(written)
            renderer.print_files_written(written)

        # ── Step 3: Execute bash blocks ────────────────────────
        bash_blocks = _extract_bash_blocks(response)
        for cmd in bash_blocks:
            cmd = _sanitize_shell_block(cmd)
            if not cmd:
                continue
            should_run = auto_run
            if not should_run:
                try:
                    answer = renderer.console.input(
                        f"  [yellow]▷ Run:[/yellow] [dim]{cmd[:80]}{'...' if len(cmd) > 80 else ''}[/dim] [yellow](y/n)?[/yellow] "
                    )
                    should_run = answer.strip().lower() in {"y", "yes", ""}
                except (EOFError, KeyboardInterrupt):
                    break
            if should_run:
                renderer.print_shell_start(cmd)
                try:
                    with renderer.status_spinner(
                        f"Running: {cmd[:60]}...", "executing"
                    ):
                        output = _run_shell(cmd, cwd, timeout=60)
                    renderer.print_shell_output(output)
                    engine.add_user(f"[Ran: {cmd}]")
                    engine.add_assistant(f"Command output:\n```\n{output}\n```")
                except KeyboardInterrupt:
                    renderer.console.print(
                        "\n  [dim yellow]─ Command cancelled (Ctrl+C)[/dim yellow]"
                    )

        return written

    def _quality_check(response: str) -> str | None:
        """Check if response is low quality and return a retry prompt if so.

        Quality checks (in order of priority):
        1. Empty/too short responses
        2. Repetitive/stuck responses
        3. Cut-off responses (unclosed code blocks)
        4. Code described in prose without FILE: blocks
        5. Missing TDD pattern (implementation without tests)
        6. Placeholder/TODO code
        7. Invalid commit messages
        """
        if not response:
            return None
        stripped = response.strip()

        # Too short to be useful (less than 50 chars and no FILE: blocks)
        if len(stripped) < 50 and "FILE:" not in response:
            return (
                "Your response was too short. Provide a complete implementation "
                "with FILE: blocks containing full file contents and RUN: commands to verify."
            )

        # Repetitive/stuck (same phrase repeated many times)
        words = stripped.split()
        if len(words) > 20:
            unique_ratio = len(set(words)) / len(words)
            if unique_ratio < 0.15:
                return (
                    "Your response was repetitive. Take a fresh approach: "
                    "READ: the relevant files, then write a clear implementation with FILE: blocks."
                )

        # Response cut off mid-sentence (no closing ``` for last code block)
        open_blocks = response.count("```")
        if open_blocks % 2 != 0:
            return (
                "Your response was cut off mid-code-block. "
                "Continue from where you left off and complete the FILE: blocks."
            )

        if _response_describes_code_without_file_blocks(response):
            return (
                "You described code changes, tests, or file contents without using FILE: blocks. "
                "Reissue the response with explicit FILE: path/to/file.ext blocks containing complete file contents, "
                "and use READ:/SEARCH:/RUN: commands for exploration and validation."
            )

        # Check for TDD violation: implementation files without corresponding tests
        file_blocks = re.findall(r"FILE:\s*(\S+)", response)
        impl_files = [f for f in file_blocks if not f.startswith("tests/") and not "test_" in f]
        test_files = [f for f in file_blocks if f.startswith("tests/") or "test_" in f]

        if impl_files and not test_files and "RUN:" not in response:
            return (
                "TDD VIOLATION: You wrote implementation code without tests.\n"
                "You MUST follow TDD:\n"
                "1. Write a failing test FIRST (FILE: tests/test_*.py)\n"
                "2. Run the test to see it fail (RUN: pytest tests/test_*.py -v)\n"
                "3. Then write implementation to make it pass\n"
                "4. Run tests again to verify (RUN: pytest -v)\n\n"
                "Rewrite your response with tests FIRST."
            )

        # Check for placeholder/TODO code in FILE blocks
        placeholder_patterns = [
            r"# TODO[:\s]",
            r"# FIXME[:\s]",
            r"# implement\s+this",
            r"pass\s*#\s*placeholder",
            r"\.\.\.\s*#\s*rest",
            r"raise\s+NotImplementedError",
            r"# Placeholder",
            r"# placeholder",
            r"if needed",  # "# Placeholder test if needed"
        ]
        for pattern in placeholder_patterns:
            if re.search(pattern, response, re.IGNORECASE):
                return (
                    "Your code contains placeholder/TODO comments or incomplete implementations.\n"
                    "You MUST provide COMPLETE, WORKING code. No placeholders, no TODOs, no '...'.\n"
                    "Rewrite with fully functional code that passes all tests."
                )

        # CRITICAL: Detect empty/useless functions (just 'pass' statements)
        # Count functions that only contain 'pass'
        empty_func_pattern = r"def\s+\w+\([^)]*\):\s*\n\s*(?:#[^\n]*)?\s*pass\s*(?:\n|$)"
        empty_functions = re.findall(empty_func_pattern, response)
        if len(empty_functions) >= 3:
            return (
                "GARBAGE CODE DETECTED: You wrote multiple empty functions with just 'pass'.\n"
                "This is UNACCEPTABLE. Empty functions do NOTHING.\n\n"
                "RULES:\n"
                "1. Every function MUST have actual implementation logic\n"
                "2. Test functions MUST have assertions (assert, assertEqual, etc.)\n"
                "3. If you don't know what to implement, READ: the source files first\n"
                "4. NEVER write placeholder functions\n\n"
                "START OVER: Read the existing code, understand what's needed, then write REAL implementations."
            )

        # Detect test files without assertions
        if "test_" in response and "FILE:" in response:
            # Check if there are test functions but no assertions
            has_test_funcs = bool(re.search(r"def test_\w+", response))
            has_assertions = bool(re.search(r"\b(assert|assertEqual|assertTrue|assertFalse|assertRaises|assertIn|expect\(|should\.|to_equal|toBe)", response))

            if has_test_funcs and not has_assertions:
                return (
                    "USELESS TESTS DETECTED: You wrote test functions without any assertions.\n"
                    "Tests without assertions prove NOTHING.\n\n"
                    "EVERY test function MUST have assertions:\n"
                    "- Python: assert result == expected, self.assertEqual(a, b)\n"
                    "- Jest: expect(result).toBe(expected)\n\n"
                    "Rewrite with REAL test logic that verifies behavior."
                )

        # Detect excessive repetition of similar function signatures (copy-paste garbage)
        func_signatures = re.findall(r"def\s+(\w+)\s*\(", response)
        if len(func_signatures) > 10:
            # Check if many functions have similar names (pattern-generated garbage)
            base_names = [re.sub(r'_\w+$', '', name) for name in func_signatures]
            from collections import Counter
            name_counts = Counter(base_names)
            most_common = name_counts.most_common(1)
            if most_common and most_common[0][1] >= 5:
                return (
                    "COPY-PASTE GARBAGE DETECTED: You generated many similar functions.\n"
                    f"Found {most_common[0][1]} functions starting with '{most_common[0][0]}_'.\n\n"
                    "This looks like you're generating repetitive placeholder code.\n"
                    "STOP. Read the ACTUAL requirements and write ONLY what's needed.\n\n"
                    "Write focused, minimal code that solves the specific problem."
                )

        # Detect mock classes without actual usage
        mock_pattern = r"class Mock\w+:\s*\n\s*def __init__"
        mocks = re.findall(mock_pattern, response)
        if len(mocks) >= 2 and "pytest" not in response.lower():
            return (
                "UNNECESSARY MOCKS DETECTED: You created mock classes that aren't used.\n"
                "Don't create infrastructure that isn't needed.\n\n"
                "RULES:\n"
                "1. Only mock what's actually required for tests\n"
                "2. Use pytest fixtures or unittest.mock instead of custom mock classes\n"
                "3. Import and test the REAL code, not mocks\n\n"
                "Rewrite: Import the actual module and test its real behavior."
            )

        # Check for bad commit messages
        bad_commit_patterns = [
            r'git commit -m ["\']?(fixed|changed|updated|modified|WIP|changes|stuff)["\']?\s*$',
            r'git commit -m ["\']?[^"\']{1,10}["\']?\s*$',  # Too short (< 10 chars)
        ]
        for pattern in bad_commit_patterns:
            if re.search(pattern, response, re.IGNORECASE):
                return (
                    "BAD COMMIT MESSAGE DETECTED.\n"
                    "Use Conventional Commits format: type(scope): description\n"
                    "Examples:\n"
                    "- feat(auth): add JWT token validation\n"
                    "- fix(api): prevent null pointer in user lookup\n"
                    "- refactor(utils): extract date formatting to helper\n\n"
                    "Rewrite your git commit command with a descriptive message."
                )

        return None

    def _auto_validate_and_retry(
        written: list[str], retries_left: int, attempt: int = 1
    ) -> None:
        """Auto-validate written files and retry on failure.

        Key improvements over naive retry:
        - Detects when model is stuck repeating the same fix → breaks loop
        - Provides module discovery when ImportError occurs
        - Trims context aggressively to avoid overflow on retries
        - Deletes broken files written by the model if they can't be fixed
        """
        if not written or retries_left <= 0:
            return

        validation = _auto_validate(written, cwd)
        if validation is None:
            return

        cmd_name, output = validation
        renderer.print_validation_start(cmd_name)

        with renderer.status_spinner("Running validation...", "testing"):
            pass  # validation already ran in _auto_validate

        has_errors = _has_errors(output)
        renderer.print_test_results(output, passed=not has_errors)

        if not has_errors:
            return

        # Track previous fix responses to detect repetition
        previous_fixes: list[str] = []

        current_written = written
        for retry_num in range(1, retries_left + 1):
            renderer.print_retry(retry_num, max_retries)

            # Trim context before retry to prevent overflow
            if len(engine._messages) > 10:
                engine._messages[:] = engine._messages[:2] + engine._messages[-6:]

            # Build smart error context with module discovery
            smart_context = _build_smart_error_context(output, current_written, cwd)

            # Include file contents in error feedback
            file_contents = []
            for fp in current_written[:3]:
                content = _read_file_context(fp, cwd, max_lines=80)
                if content:
                    file_contents.append(content)
            file_context = "\n\n".join(file_contents) if file_contents else ""

            fix_prompt = (
                f"VALIDATION FAILED (attempt {retry_num}/{max_retries}).\n"
                f"Command: `{cmd_name}`\n"
                f"Error:\n```\n{_summarize_test_output(output, max_chars=3000)}\n```\n"
            )
            if file_context:
                fix_prompt += f"\nCurrent file contents:\n\n{file_context}\n\n"
            if smart_context:
                fix_prompt += smart_context + "\n\n"
            fix_prompt += (
                "RULES FOR THIS FIX:\n"
                "1. Read the ACTUAL error message above — do not guess.\n"
                "2. Fix ONLY the specific error — do not rewrite unrelated code.\n"
                "3. If a module doesn't exist, check AVAILABLE PROJECT MODULES above.\n"
                "4. If you wrote a test that imports a non-existent module, DELETE the test file.\n"
                "5. Output corrected FILE: blocks with COMPLETE file contents.\n"
                "6. Try a DIFFERENT approach if your previous fix didn't work."
            )

            fix_response = _send_to_model(fix_prompt)
            if not fix_response:
                break

            # Check for repetition — model stuck producing same output
            if _detect_repetition(previous_fixes, fix_response):
                renderer.warning(
                    "Model is repeating the same fix — stopping retry loop. "
                    "Cleaning up broken files."
                )
                # Delete test files the model created that don't work
                for fp in current_written:
                    target = cwd / fp
                    if target.exists() and fp.startswith("tests/test_improvement"):
                        target.unlink()
                        renderer.info(f"  Deleted broken file: {fp}")
                break

            previous_fixes.append(fix_response)

            new_written = _process_response(fix_response)
            if not new_written:
                break

            current_written = new_written

            # Re-validate
            validation = _auto_validate(current_written, cwd)
            if validation is None:
                break

            cmd_name, output = validation
            has_errors = _has_errors(output)
            renderer.print_test_results(output, passed=not has_errors)

            if not has_errors:
                renderer.success(f"Fixed on attempt {retry_num}!")
                break

    def _execute_multistep(
        task_prompt: str,
        send: Callable[[str], str | None],
    ) -> list[str]:
        """Execute a task via focused multi-step pipeline.

        Instead of one monolithic prompt, breaks work into:
        1. Plan: model outputs 2-4 concrete steps
        2. Explore: READ/SEARCH existing code
        3. Test: write test files first
        4. Implement: write implementation files
        5. Verify: run tests

        Each step is a separate model call with a focused prompt,
        keeping each call within the capability range of small models.
        """
        all_step_written: list[str] = []

        # ── Step 1: Plan ────────────────────────────────
        renderer.phase("planning", "Breaking task into steps...")
        plan_prompt = (
            f"TASK: {task_prompt}\n\n"
            "Break this into 2-4 concrete implementation steps. "
            "For each step, say what file(s) to create/modify. "
            "Use READ: commands to examine any existing files you need to understand first.\n"
            "Format:\n"
            "STEP 1: <description> — <file(s)>\n"
            "STEP 2: <description> — <file(s)>\n"
            "...\n\n"
            "Also use READ: and SEARCH: to explore the codebase now."
        )
        plan_response = send(plan_prompt)
        if not plan_response:
            return []

        # Process any tool commands from planning (READ/SEARCH)
        plan_written = _process_response(plan_response)
        all_step_written.extend(plan_written)

        # ── Step 2: Write tests ─────────────────────────
        renderer.phase("thinking", "Writing tests first (TDD)...")
        test_prompt = (
            "Now write the TEST files for this task. Based on your plan above, "
            "create test files that verify the expected behavior.\n\n"
            "RULES:\n"
            "- Output ONLY test files using FILE: blocks\n"
            "- Import from modules that ACTUALLY EXIST in this project\n"
            "- Each test should be runnable independently\n"
            "- Do NOT write implementation files yet — only tests\n"
        )
        test_response = send(test_prompt)
        if test_response:
            test_written = _process_response(test_response)
            all_step_written.extend(test_written)

        # ── Step 3: Write implementation ────────────────
        renderer.phase("thinking", "Writing implementation...")
        impl_prompt = (
            "Now write the IMPLEMENTATION files to make the tests pass. "
            "Based on your plan and the tests you wrote, create/modify the source files.\n\n"
            "RULES:\n"
            "- Output implementation files using FILE: blocks with COMPLETE contents\n"
            "- Make sure imports match what exists in the project\n"
            "- Do NOT rewrite the test files — only implementation files\n"
            "- Use RUN: to run the tests after writing the files\n"
        )
        impl_response = send(impl_prompt)
        if impl_response:
            impl_written = _process_response(impl_response)
            all_step_written.extend(impl_written)

        return all_step_written

    def _execute_task_prompt(
        task_prompt: str,
        save_history: bool = True,
        sender: Callable[[str], str | None] | None = None,
        ensure_green: bool = False,
        role_trace: bool = False,
    ) -> tuple[list[str], bool]:
        """Run one full agent task cycle and return (written_files, task_ok)."""
        send = sender or _send_to_model
        validation_cmd = ""
        validation_status = "not-run"
        validation_retries = 0
        if role_trace:
            renderer.phase(
                "planning", "[Planner] Analyze requirements and produce plan"
            )
        if save_history:
            _add_to_prompt_history(cwd, task_prompt)

        # For complex tasks on local models, use multi-step decomposition
        # Small models benefit enormously from focused, single-objective prompts
        if is_local and _is_complex_task(task_prompt):
            renderer.phase("planning", "Complex task detected — using multi-step pipeline")
            written = _execute_multistep(task_prompt, send)
            if written:
                _auto_validate_and_retry(written, max_retries)
            # Fall through to ensure_green below
        else:
            # Standard single-shot path for simple tasks or API models
            expanded = _enhance_task_prompt(task_prompt)
            if role_trace:
                renderer.phase(
                    "thinking", "[Coder] Implement changes and propose tool actions"
                )
            response = send(expanded)
            if not response:
                return [], False

            retry_prompt = _quality_check(response)
            if retry_prompt:
                renderer.phase("fixing", "Low quality response — retrying...")
                retry_response = send(retry_prompt)
                if retry_response:
                    response = retry_response

            if role_trace:
                renderer.phase(
                    "fixing", "[Reviewer] Validate response quality and edit intent"
                )
            written = _process_response(response)

            has_tools = bool(_extract_tool_commands(response))
            if not written and not has_tools and "FILE:" not in response:
                renderer.phase("fixing", "No code produced — requesting implementation...")
                nudge = (
                    "You responded with only text. You MUST write code or use tools. "
                    "Use READ: to examine existing files, then write tests FIRST using "
                    "FILE: blocks (FILE: tests/test_*.py), then write the implementation "
                    "using FILE: blocks, then use RUN: to run the tests. Do it now."
                )
                followup = send(nudge)
                if followup:
                    written = _process_response(followup)

            if written:
                _auto_validate_and_retry(written, max_retries)

        task_ok = True
        if ensure_green:
            if role_trace:
                renderer.phase(
                    "testing",
                    "[Tester/DevOps] Run project validation and iterate until green",
                )
            test_cmd = (
                _validation_command_for_written_files(written or all_written, cwd)
                or default_test_cmd
            )
            validation_cmd = test_cmd
            renderer.phase("testing", test_cmd)
            test_cmd, output = _run_validation_command(test_cmd, cwd, timeout=120)
            has_errors = _has_errors(output)
            renderer.print_test_results(output, passed=not has_errors)
            validation_status = "passed" if not has_errors else "failed"
            attempts = 0
            while has_errors and attempts < max_retries:
                attempts += 1
                validation_retries = attempts
                fix_prompt = (
                    f"Project validation is failing for `{test_cmd}`. Use the REAL failure output below to fix the code.\n\n"
                    f"```text\n{_summarize_test_output(output)}\n```\n\n"
                    "Rules:\n"
                    "1. Do not invent files, functions, or line numbers.\n"
                    "2. Read real files first using READ: and SEARCH:.\n"
                    "3. Write tests first when adding behavior.\n"
                    "4. Output FILE: blocks with complete file contents.\n"
                    "5. Include RUN: commands for the same validation command.\n"
                )
                fix_response = send(fix_prompt)
                if not fix_response:
                    break
                if role_trace:
                    renderer.phase(
                        "fixing",
                        "[Incident Response] Diagnose failure and apply root-cause fix",
                    )
                fix_written = _process_response(fix_response)
                if fix_written:
                    _auto_validate_and_retry(fix_written, max_retries)
                test_cmd, output = _run_validation_command(test_cmd, cwd, timeout=120)
                has_errors = _has_errors(output)
                renderer.print_test_results(output, passed=not has_errors)
                validation_status = "passed" if not has_errors else "failed"
            if has_errors:
                renderer.warning(
                    "Autopolit could not get the full test suite green in this cycle."
                )
                task_ok = False
        if role_trace:
            changed = ", ".join(written[:3]) if written else "none"
            renderer.info(
                "[Cycle Summary] "
                f"changed={changed} | validation={validation_status} | "
                f"cmd={validation_cmd or 'n/a'} | retries={validation_retries}"
            )
        return written, task_ok

    def _build_autopolit_prompt(
        cycle: int,
        last_summary: str,
        no_change_streak: int = 0,
        previous_changed_files: list[str] | None = None,
        repeat_task_streak: int = 0,
    ) -> str:
        prompt = (
            f"Autopolit cycle {cycle}. Run an autonomous quality pass on the CURRENT codebase.\n\n"
            "Execution policy:\n"
            "1. Identify the correct project root/package inside this workspace before editing or testing\n"
            "2. Analyze the whole relevant codebase (core modules, tests, configs, CI files) before proposing changes\n"
            f"3. Start validation with RUN: {default_test_cmd}\n"
            "4. If tests fail, identify root causes from real tracebacks and fix code until green\n"
            "5. If tests pass, perform one high-impact improvement (bug, reliability, or maintainability)\n"
            "6. Validate with tests again\n\n"
            "Priority order:\n"
            "- P0: Failing tests, crashes, import/runtime errors, build breaks\n"
            "- P1: Security/reliability defects and incorrect behavior\n"
            "- P2: Maintainability/performance improvements with measurable benefit\n"
            "- Avoid low-value cosmetic churn while higher-priority issues exist\n\n"
            "Hard rules:\n"
            "- Never invent files, functions, line numbers, or errors\n"
            "- Resolve the correct working directory before every RUN/READ/SEARCH command\n"
            "- Never assume database/ORM/migrations unless discovered via READ:/SEARCH:\n"
            "- Do not output fake shell plans; only real runnable commands\n"
            "- Use READ: and SEARCH: before editing\n"
            "- If you change files, you MUST emit FILE: blocks with complete file contents\n"
            "- Do not describe code changes in prose without FILE: blocks\n"
            "- Prefer minimal, correct fixes\n"
            "- Base conclusions only on actual command output\n"
            "- Never claim success while validation is pending or failing\n"
            "- Prioritize P0/P1 defects before cosmetic changes\n"
        )
        if no_change_streak >= 1:
            prompt += (
                "\nAdditional directive:\n"
                "- Last cycle made no code changes. Pick a NEW high-impact, concrete improvement task.\n"
                "- You MUST produce at least one real FILE: change and re-validate tests.\n"
            )
        if previous_changed_files:
            preview = ", ".join(previous_changed_files[:5])
            prompt += (
                "\nAnti-repetition directive:\n"
                f"- Previous cycle touched files: {preview}\n"
                "- For this cycle, choose a different subsystem/file set unless those files are currently failing tests.\n"
            )
        if repeat_task_streak >= 1:
            prompt += "- You repeated a similar task recently. Hard-pivot to a different module, class, or workflow.\n"
        if last_summary:
            prompt += f"\nPrevious cycle summary:\n{last_summary}\n"
        return prompt

    def _run_autopolit(max_cycles: int | None = None) -> None:
        """Endless autonomous loop (stoppable with Ctrl+C)."""
        cancel_now = False
        sigint_count = 0
        cycle = 0
        consecutive_failures = 0
        no_change_streak = 0
        repeat_task_streak = 0
        previous_changed_files: list[str] = []
        last_summary = ""
        original_sigint = signal.getsignal(signal.SIGINT)

        def _reset_engine_context() -> None:
            engine.clear()
            for m in messages_init:
                if m["role"] == "user":
                    engine.add_user(m["content"])
                else:
                    engine.add_assistant(m["content"])

        def _handle_sigint(signum, frame):
            nonlocal cancel_now, sigint_count
            sigint_count += 1
            cancel_now = True
            raise KeyboardInterrupt

        signal.signal(signal.SIGINT, _handle_sigint)
        stop_file = _autopolit_stop_path(cwd)
        if stop_file.exists():
            stop_file.unlink(missing_ok=True)
        renderer.info(
            "Autopolit started. Ctrl+C = immediate cancel. "
            "You can also stop from another terminal: touch .sage/autopolit.stop"
        )

        try:
            while True:
                if stop_file.exists():
                    renderer.warning("Autopolit stop file detected. Exiting loop.")
                    stop_file.unlink(missing_ok=True)
                    break
                if cancel_now:
                    renderer.warning("Autopolit cancelled immediately.")
                    break
                if max_cycles is not None and cycle >= max_cycles:
                    renderer.success(f"Autopolit reached max cycles: {max_cycles}")
                    break

                next_cycle = cycle + 1
                auto_prompt = _build_autopolit_prompt(
                    next_cycle,
                    last_summary,
                    no_change_streak=no_change_streak,
                    previous_changed_files=previous_changed_files,
                    repeat_task_streak=repeat_task_streak,
                )
                renderer.phase("planning", f"Autopolit task #{next_cycle}")
                written, task_ok = _execute_task_prompt(
                    auto_prompt,
                    save_history=True,
                    sender=_send_to_model_autopolit,
                    ensure_green=True,
                    role_trace=True,
                )
                if not task_ok:
                    consecutive_failures += 1
                    if consecutive_failures >= 8:
                        renderer.error(
                            "Autopolit hit repeated provider failures and is stopping to prevent an error loop."
                        )
                        break
                    if consecutive_failures >= 4:
                        renderer.warning(
                            "Autopolit saw repeated failures. Resetting context and continuing..."
                        )
                        _reset_engine_context()
                    time.sleep(0.1)
                    continue
                consecutive_failures = 0
                cycle = next_cycle
                current_changed_files = sorted(set(written))
                if current_changed_files and previous_changed_files:
                    if set(current_changed_files) == set(previous_changed_files):
                        repeat_task_streak += 1
                    else:
                        repeat_task_streak = 0
                elif current_changed_files:
                    repeat_task_streak = 0
                if current_changed_files:
                    previous_changed_files = current_changed_files
                    no_change_streak = 0
                else:
                    no_change_streak += 1

                changed = ", ".join(written[:5]) if written else "no files changed"
                last_summary = f"Task: {auto_prompt}\nResult: {changed}"
        except KeyboardInterrupt:
            renderer.warning("Autopolit cancelled immediately.")
        finally:
            signal.signal(signal.SIGINT, original_sigint)

    while True:
        try:
            prompt_text = "you> " if multiline_buffer is None else "...  "
            raw = prompt_reader(prompt_text)
        except (EOFError, KeyboardInterrupt):
            renderer.info("\nGoodbye.")
            break

        # Multi-line mode
        if multiline_buffer is not None:
            if raw.rstrip() == '"""':
                user_input = "\n".join(multiline_buffer)
                multiline_buffer = None
            else:
                multiline_buffer.append(raw)
                continue
        elif raw.lstrip().startswith('"""'):
            rest = raw.lstrip()[3:]
            multiline_buffer = [rest] if rest else []
            continue
        else:
            user_input = raw.strip()

        if not user_input:
            continue

        # ── Shell escape: !command ─────────────────────────
        if user_input.startswith("!"):
            shell_cmd = user_input[1:].strip()
            if shell_cmd:
                renderer.print_shell_start(shell_cmd)
                with renderer.status_spinner(
                    f"Running: {shell_cmd[:60]}...", "executing"
                ):
                    output = _run_shell(shell_cmd, cwd)
                renderer.print_shell_output(output)
                engine.add_user(f"[Shell command: {shell_cmd}]")
                engine.add_assistant(f"Command output:\n```\n{output}\n```")
            continue

        # ── Agent commands ──────────────────────────────────
        if user_input.startswith("/"):
            cmd_parts = user_input.split(None, 1)
            command = cmd_parts[0].lower()
            arg = cmd_parts[1] if len(cmd_parts) > 1 else ""

            if command in {"/exit", "/quit", "/q"}:
                renderer.info("Goodbye.")
                break
            elif command == "/help":
                renderer.print_agent_help()
                continue
            elif command == "/models":
                all_models = router.list_all_models()
                if all_models:
                    renderer.print_model_table(
                        [
                            {
                                "id": m.id,
                                "provider": m.provider,
                                "name": m.name,
                                "local": m.local,
                            }
                            for m in all_models
                        ]
                    )
                    downloaded = list_downloaded()
                    dl_names = {name for name, _ in downloaded}
                    not_downloaded = [
                        m for m in MODEL_CATALOG if m.name not in dl_names
                    ]
                    if not_downloaded:
                        renderer.info(
                            f"\n{len(not_downloaded)} more downloadable GGUF models: sage pull --list"
                        )
                    # Show Ollama catalog hint
                    ollama_available = any(m.provider == "ollama" for m in all_models)
                    if ollama_available:
                        ollama_pulled = {m.id for m in all_models if m.provider == "ollama"}
                        not_pulled = [
                            m for m in OLLAMA_CATALOG if m.name not in ollama_pulled
                        ]
                        if not_pulled:
                            renderer.info(
                                f"\n{len(not_pulled)} more Ollama models available: "
                                "sage models --ollama"
                            )
                    else:
                        renderer.info(
                            f"\n{len(OLLAMA_CATALOG)} Ollama models available — "
                            "install Ollama (ollama.com) then: sage models --ollama"
                        )
                else:
                    renderer.warning(
                        "No models available right now. "
                        "Install Ollama (ollama.com) or check: sage pull --list"
                    )
                continue
            elif command == "/clear":
                engine.clear()
                last_written.clear()
                all_written.clear()
                renderer.success("Conversation and file history cleared.")
                continue
            elif command == "/compact":
                # Trim context to free up space (like Claude Code's /compact)
                before = len(engine._messages)
                if before > 6:
                    engine._messages[:] = engine._messages[:2] + engine._messages[-4:]
                    renderer.success(
                        f"Compacted: {before} messages → {len(engine._messages)}"
                    )
                else:
                    renderer.info("Context already compact.")
                continue
            elif command == "/think":
                if not arg:
                    renderer.warning("Usage: /think <task description>")
                    continue
                # Force model into step-by-step planning mode
                think_prompt = (
                    f"Think step by step about this task: {arg}\n\n"
                    "1. What exactly needs to happen?\n"
                    "2. What existing files need to be read? (Use READ: commands)\n"
                    "3. What files need to be created or modified? List them.\n"
                    "4. What's the correct order of operations?\n"
                    "5. What could go wrong and how will you verify success?\n\n"
                    "After your analysis, start implementing: write tests first with FILE: blocks, "
                    "then implementation, then RUN: to verify."
                )
                response = _send_to_model(think_prompt)
                if response:
                    written = _process_response(response)
                    if written:
                        _auto_validate_and_retry(written, max_retries)
                continue
            elif command == "/files":
                if all_written:
                    unique = list(dict.fromkeys(all_written))
                    renderer.info(f"All written files ({len(unique)}):")
                    for f in unique:
                        exists = "  " if (cwd / f).exists() else "  [deleted]"
                        renderer.console.print(f"  {exists} {f}")
                else:
                    renderer.info("No files written yet.")
                continue
            elif command == "/undo":
                if last_written:
                    for fp in last_written:
                        target = cwd / fp
                        if target.exists():
                            target.unlink()
                            renderer.info(f"  Deleted: {fp}")
                    last_written.clear()
                else:
                    renderer.info("Nothing to undo.")
                continue
            elif command == "/model":
                if arg:
                    new_model = _resolve_model_prefix(arg, cfg)
                    # Ensure the model is available (auto-pull for Ollama, auto-download for GGUF)
                    cfg = _ensure_model_available(cfg, new_model)
                    router = _build_router(cfg)
                    model_id = new_model
                    is_local = (
                        model_id.startswith("llama_cpp:")
                        or model_id.startswith("ollama:")
                        or cfg.get_local_model(model_id) is not None
                    )
                    _set_last_used_model(cwd, model_id)
                    renderer.success(f"Switched to: {model_id}")
                else:
                    renderer.info(f"Model: {model_id}")
                continue
            elif command == "/read":
                if not arg:
                    renderer.warning("Usage: /read <filepath>")
                    continue
                content = _read_file_context(arg, cwd)
                if content:
                    line_count = content.count("\n")
                    renderer.print_file_read(arg, line_count)
                    engine.add_user(f"[Reading file: {arg}]\n{content}")
                    engine.add_assistant(
                        "I've read the file. What would you like me to do with it?"
                    )
                else:
                    renderer.step_fail(f"Could not read: {arg}")
                continue
            elif command == "/test":
                # Run project tests
                test_cmd = arg or default_test_cmd
                renderer.phase("testing", test_cmd)
                with renderer.status_spinner("Running tests...", "testing"):
                    output = _run_shell(test_cmd, cwd, timeout=120)
                has_errors = _has_errors(output)
                renderer.print_test_results(output, passed=not has_errors)
                if has_errors:
                    renderer.print_shell_output(output)
                engine.add_user(f"[Test run: {test_cmd}]")
                engine.add_assistant(f"Test output:\n```\n{output}\n```")
                continue
            elif command == "/history":
                renderer.info(f"Turns: {engine.turn_count}")
                history = _load_prompt_history(cwd)
                if history:
                    renderer.info(f"Saved prompts: {len(history)}")
                    for i, h in enumerate(history[-10:], 1):
                        ts = h.get("timestamp", "")[:16]
                        text = h["prompt"][:70] + (
                            "..." if len(h["prompt"]) > 70 else ""
                        )
                        renderer.console.print(
                            f"    [dim]{ts}[/dim]  [cyan]{i}[/cyan]. {text}"
                        )
                    renderer.info(
                        "  Use /prompts to select and reuse a previous prompt."
                    )
                continue
            elif command == "/prompts":
                history = _load_prompt_history(cwd)
                if not history:
                    renderer.info("No prompt history yet.")
                    continue
                recent = history[-20:]
                renderer.console.print(
                    "\n[bold]Prompt History[/bold] (most recent last):\n"
                )
                for i, h in enumerate(recent, 1):
                    ts = h.get("timestamp", "")[:16]
                    text = h["prompt"][:80] + ("..." if len(h["prompt"]) > 80 else "")
                    renderer.console.print(
                        f"  [cyan]{i:>2}[/cyan]. [dim]{ts}[/dim]  {text}"
                    )
                renderer.console.print()
                try:
                    choice = renderer.console.input(
                        "[yellow]Select prompt # (or Enter to cancel):[/yellow] "
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    continue
                if not choice:
                    continue
                try:
                    idx = int(choice) - 1
                    if 0 <= idx < len(recent):
                        user_input = recent[idx]["prompt"]
                        renderer.console.print(
                            f"  [dim]Reusing:[/dim] {user_input[:80]}..."
                        )
                    else:
                        renderer.warning(f"Invalid selection: {choice}")
                        continue
                except ValueError:
                    renderer.warning(f"Invalid number: {choice}")
                    continue
                # Fall through to prompt processing below
            elif command in {"/autopolit", "/autopilot"}:
                max_cycles: int | None = None
                if arg:
                    try:
                        max_cycles = int(arg)
                        if max_cycles <= 0:
                            raise ValueError
                    except ValueError:
                        renderer.warning(
                            "Usage: /autopolit [max-cycles]\n" "Example: /autopolit 5"
                        )
                        continue
                _run_autopolit(max_cycles=max_cycles)
                continue
            elif command == "/autopolit-stop":
                _autopolit_stop_path(cwd).write_text("stop\n", "utf-8")
                renderer.info(
                    "Stop signal written to .sage/autopolit.stop. Any running autopolit loop will exit after current step."
                )
                continue
            else:
                renderer.warning(f"Unknown command: {command}")
                continue

        _execute_task_prompt(user_input, save_history=True, sender=_send_to_model)


@app.command()
def chat(
    model: Annotated[
        Optional[str], typer.Option("--model", "-m", help="Model ID (provider:model)")
    ] = None,
    system: Annotated[
        Optional[str], typer.Option("--system", "-s", help="System prompt")
    ] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    no_stream: Annotated[
        bool, typer.Option("--no-stream", help="Disable streaming")
    ] = False,
) -> None:
    """Interactive chat session (REPL)."""
    cfg = load_config()
    model_id = _resolve_model_prefix(model or cfg.default_model, cfg)

    # Auto-download local models if not installed
    cfg = _ensure_model_available(cfg, model_id)
    router = _build_router(cfg)

    temp = temperature if temperature is not None else cfg.temperature
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens

    engine = ConversationEngine(
        system_prompt=system or cfg.system_prompt,
        max_history=50,
    )

    renderer.print_welcome(model_id)

    multiline_buffer: list[str] | None = None

    while True:
        try:
            prompt_text = (
                "[bold cyan]you>[/bold cyan] "
                if multiline_buffer is None
                else "[dim]...[/dim]  "
            )
            raw = renderer.console.input(prompt_text)
        except (EOFError, KeyboardInterrupt):
            renderer.info("\nGoodbye.")
            break

        # Multi-line mode
        if multiline_buffer is not None:
            if raw.rstrip() == '"""':
                user_input = "\n".join(multiline_buffer)
                multiline_buffer = None
            else:
                multiline_buffer.append(raw)
                continue
        elif raw.lstrip().startswith('"""'):
            # Start multi-line
            rest = raw.lstrip()[3:]
            multiline_buffer = [rest] if rest else []
            continue
        else:
            user_input = raw.strip()

        if not user_input:
            continue

        # ── REPL commands ───────────────────────────────────
        if user_input.startswith("/"):
            cmd = user_input.split(None, 1)
            command = cmd[0].lower()
            arg = cmd[1] if len(cmd) > 1 else ""

            if command in {"/exit", "/quit", "/q"}:
                renderer.info("Goodbye.")
                break
            elif command == "/help":
                renderer.print_help()
                continue
            elif command == "/clear":
                engine.clear()
                renderer.success("Conversation cleared.")
                continue
            elif command == "/model":
                if arg:
                    new_model = _resolve_model_prefix(arg, cfg)
                    cfg = _ensure_model_available(cfg, new_model)
                    router = _build_router(cfg)
                    model_id = new_model
                    renderer.success(f"Switched to model: {model_id}")
                else:
                    renderer.info(f"Current model: {model_id}")
                continue
            elif command == "/system":
                if arg:
                    engine.system_prompt = arg
                    renderer.success("System prompt updated.")
                else:
                    sp = engine.system_prompt or "(none)"
                    renderer.info(f"System prompt: {sp}")
                continue
            elif command == "/history":
                renderer.info(f"Turns: {engine.turn_count}")
                continue
            else:
                renderer.warning(f"Unknown command: {command}")
                continue

        # ── Send to model ───────────────────────────────────
        engine.add_user(user_input)
        messages = engine.build_messages()

        try:
            renderer.console.print("[bold green]sage>[/bold green] ", end="")
            if no_stream:
                response = router.generate(messages, model_id, temp, tokens)
                renderer.console.print()
                renderer.render_markdown(response)
            else:
                response = renderer.stream_tokens(
                    router.stream(messages, model_id, temp, tokens)
                )
            engine.add_assistant(response)
        except Exception as exc:
            engine._messages.pop()  # Remove the failed user message
            renderer.error(str(exc))


@app.command()
def ask(
    prompt: Annotated[Optional[str], typer.Argument(help="Prompt text")] = None,
    file: Annotated[
        Optional[Path],
        typer.Option("--file", "-f", help="Read file content as context"),
    ] = None,
    model: Annotated[Optional[str], typer.Option("--model", "-m")] = None,
    system: Annotated[Optional[str], typer.Option("--system", "-s")] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    raw: Annotated[
        bool, typer.Option("--raw", help="Output raw text (no markdown rendering)")
    ] = False,
) -> None:
    """One-shot prompt — ask a question and get an answer."""
    cfg = load_config()
    model_id = _resolve_model_prefix(model or cfg.default_model, cfg)

    # Auto-download local models if not installed
    cfg = _ensure_model_available(cfg, model_id)
    router = _build_router(cfg)

    temp = temperature if temperature is not None else cfg.temperature
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens

    # Build the prompt from arguments, file, and/or stdin
    parts: list[str] = []

    # Check for piped input
    piped = _read_stdin()
    if piped:
        parts.append(piped.strip())

    # Read file if provided
    if file:
        if not file.exists():
            renderer.error(f"File not found: {file}")
            raise typer.Exit(1)
        content = file.read_text("utf-8")
        parts.append(f"File: {file.name}\n```\n{content}\n```")

    if prompt:
        parts.append(prompt)

    if not parts:
        renderer.error("No prompt provided. Usage: sage ask 'your question'")
        raise typer.Exit(1)

    full_prompt = _enhance_task_prompt("\n\n".join(parts))

    engine = ConversationEngine(system_prompt=system or cfg.system_prompt)
    engine.add_user(full_prompt)
    messages = engine.build_messages()

    try:
        if raw or not sys.stdout.isatty():
            # Non-interactive: stream raw text
            response = renderer.stream_tokens(
                router.stream(messages, model_id, temp, tokens)
            )
        else:
            # Interactive terminal: render markdown
            response = router.generate(messages, model_id, temp, tokens)
            renderer.render_markdown(response)
    except Exception as exc:
        renderer.error(str(exc))
        raise typer.Exit(2)


def _show_ollama_catalog(
    category: str | None = None, search_query: str | None = None
) -> None:
    """Display Ollama model catalog with Rich formatting."""
    if search_query:
        results = search_ollama_catalog(search_query)
        if not results:
            renderer.warning(f"No Ollama models matching '{search_query}'")
            return
        label = f"Ollama models matching '{search_query}'"
    elif category:
        results = get_ollama_models_by_category(category)
        if not results:
            renderer.warning(
                f"No Ollama models in category '{category}'. "
                "Try: coding, reasoning, general, vision, small, embedding"
            )
            return
        label = f"Ollama models — {category}"
    else:
        results = OLLAMA_CATALOG
        label = "All Ollama models"

    renderer.console.print(f"\n[bold]{label}[/bold] ({len(results)} models)\n")

    # Group by category for full listing
    if not category and not search_query:
        categories = ["coding", "reasoning", "general", "vision", "small", "embedding"]
        for cat in categories:
            cat_models = [m for m in results if m.category == cat]
            if not cat_models:
                continue
            renderer.console.print(f"  [bold cyan]{cat.upper()}[/bold cyan]")
            for m in cat_models:
                params = m.params if m.params else "cloud"
                tags = " ".join(f"[dim]{t}[/dim]" for t in m.tags) if m.tags else ""
                renderer.console.print(
                    f"    [green]{m.name:<30}[/green] "
                    f"[dim]({params})[/dim]  "
                    f"{m.description[:55]}"
                    f"  {tags}"
                )
            renderer.console.print()
    else:
        for m in results:
            params = m.params if m.params else "cloud"
            tags = " ".join(f"[dim]{t}[/dim]" for t in m.tags) if m.tags else ""
            renderer.console.print(
                f"  [green]{m.name:<30}[/green] "
                f"[dim]({params})[/dim]  "
                f"{m.description[:55]}"
                f"  {tags}"
            )

    renderer.console.print(
        "\n[dim]To pull: sage pull <name>  (or: ollama pull <model>)[/dim]"
    )
    renderer.console.print(
        "[dim]To use: sage run --model ollama:<model>[/dim]"
    )
    rec = get_recommended_ollama_models()
    if rec:
        names = ", ".join(m.name for m in rec[:5])
        renderer.console.print(f"[dim]Recommended: {names}[/dim]\n")


@app.command()
def models(
    ollama: Annotated[
        bool, typer.Option("--ollama", help="Show all Ollama models available to pull")
    ] = False,
    category: Annotated[
        Optional[str],
        typer.Option("--category", "-c", help="Filter Ollama models by category (coding, reasoning, general, vision, small, embedding)"),
    ] = None,
    search: Annotated[
        Optional[str],
        typer.Option("--search", "-s", help="Search Ollama catalog by keyword"),
    ] = None,
) -> None:
    """List available models from all configured providers.

    Examples:
      sage models                        List active models
      sage models --ollama               List all Ollama models available to pull
      sage models --ollama -c coding     List coding-focused Ollama models
      sage models --ollama -s deepseek   Search Ollama catalog
    """
    if ollama or category or search:
        _show_ollama_catalog(category=category, search_query=search)
        return

    cfg = load_config()
    router = _build_router(cfg)
    all_models = router.list_all_models()

    if not all_models:
        renderer.warning(
            "No models available.\n"
            "  Install Ollama (ollama.com) for 90+ free models\n"
            "  Or configure a key: sage config set api_keys.gemini YOUR_KEY\n"
            "  Or add local model: sage config set models.mymodel.path /path/to/model.gguf"
        )
        raise typer.Exit(1)

    renderer.print_model_table(
        [
            {"id": m.id, "provider": m.provider, "name": m.name, "local": m.local}
            for m in all_models
        ]
    )
    renderer.info(f"\nDefault: {cfg.default_model}")
    renderer.info(
        f"\n{len(OLLAMA_CATALOG)} Ollama models available — run: sage models --ollama"
    )


@app.command()
def install() -> None:
    """Download the best AI models for local use — run this after installing Sage.

    Downloads:
    - 3 best GGUF models (qwen2.5-coder-7b, deepseek-r1-7b, llama3.2-3b) for offline use
    - 8 best Ollama models (qwen3.5, gemma4, devstral, nemotron-mini, etc.)

    Total: ~30 GB. All models run 100% locally — no internet needed after install.
    """
    from sage.models.catalog import get_default_models, DEFAULT_OLLAMA_MODELS

    renderer.header("Installing Sage AI — Best Models")
    renderer.info("")

    # Step 1: Download default GGUF models
    defaults = get_default_models()
    renderer.info(f"[1/2] Downloading {len(defaults)} best GGUF models...")
    for m in defaults:
        if is_downloaded(m):
            renderer.success(f"  {m.display_name} ({m.params}) — already downloaded")
            continue
        renderer.info(f"  Downloading {m.display_name} ({m.size_gb} GB)...")
        try:
            download_model(m, progress_callback=lambda dl, tot: None)
            register_model(m)
            renderer.success(f"  {m.display_name} — done!")
        except Exception as exc:
            renderer.error(f"  {m.display_name} — failed: {exc}")

    # Step 2: Pull default Ollama models
    renderer.info(f"\n[2/2] Pulling {len(DEFAULT_OLLAMA_MODELS)} best Ollama models...")
    renderer.info("  (Requires Ollama installed — get it from https://ollama.com)")
    for model_name in DEFAULT_OLLAMA_MODELS:
        renderer.info(f"  Pulling {model_name}...")
        try:
            result = subprocess.run(
                ["ollama", "pull", model_name],
                check=False,
                timeout=600,
            )
            if result.returncode == 0:
                renderer.success(f"  {model_name} — done!")
            else:
                renderer.error(f"  {model_name} — ollama pull failed")
        except FileNotFoundError:
            renderer.warning("  Ollama not installed — skipping Ollama models")
            renderer.info("  Install from https://ollama.com then re-run: sage install")
            break
        except subprocess.TimeoutExpired:
            renderer.error(f"  {model_name} — timed out")

    renderer.info("")
    renderer.header("Setup Complete!")
    renderer.info("  Default model: qwen2.5-coder-7b (best local coding model)")
    renderer.info("  Run: sage chat    — to start chatting")
    renderer.info("  Run: sage models  — to see all available models")
    renderer.info("  Run: sage pull    — to download more models")
    renderer.info("")
    renderer.info("  All inference runs locally on your machine — no API keys needed.")


@app.command()
def pull(
    model_name: Annotated[
        Optional[str],
        typer.Argument(help="Model to download (e.g. 'gemma3-4b', 'qwen2.5-coder-3b')"),
    ] = None,
    list_available: Annotated[
        bool, typer.Option("--list", "-l", help="List all downloadable models")
    ] = False,
    search: Annotated[
        Optional[str], typer.Option("--search", "-s", help="Search catalog by keyword")
    ] = None,
    recommended: Annotated[
        bool,
        typer.Option("--recommended", "-r", help="Show recommended starter models"),
    ] = False,
    all_models: Annotated[
        bool,
        typer.Option("--all", help="Download ALL models (GGUF + Ollama). Requires lots of disk space."),
    ] = False,
    all_gguf: Annotated[
        bool,
        typer.Option("--all-gguf", help="Download all GGUF models from HuggingFace"),
    ] = False,
    all_ollama: Annotated[
        bool,
        typer.Option("--all-ollama", help="Pull all Ollama models"),
    ] = False,
) -> None:
    """Download a free AI model for local use — no API key needed.

    Examples:
      sage pull --list                  List all downloadable models
      sage pull gemma3-4b               Download Google Gemma 3 4B
      sage pull qwen2.5-coder-3b       Download Qwen 2.5 Coder 3B
      sage pull --search code           Search for code-focused models
      sage pull --recommended           Show recommended starter models
      sage pull --all-gguf              Download all GGUF models (~30 GB)
      sage pull --all-ollama            Pull all Ollama models (100+ GB)
      sage pull --all                   Download everything
    """
    from rich.progress import (
        Progress,
        BarColumn,
        DownloadColumn,
        TransferSpeedColumn,
        TimeRemainingColumn,
    )

    # ── Batch download modes ────────────────────────────────
    if all_models or all_gguf or all_ollama:
        gguf_models = [m for m in MODEL_CATALOG if m.backend == "gguf"]
        ollama_models = [m for m in MODEL_CATALOG if m.backend == "ollama"]

        if all_models or all_gguf:
            total_gb = sum(m.size_gb for m in gguf_models)
            renderer.info(f"Downloading {len(gguf_models)} GGUF models (~{total_gb:.0f} GB total)...")
            for i, m in enumerate(gguf_models, 1):
                if is_downloaded(m):
                    renderer.info(f"  [{i}/{len(gguf_models)}] {m.name} — already downloaded")
                    continue
                renderer.info(f"  [{i}/{len(gguf_models)}] Downloading {m.name} ({m.size_gb:.1f} GB)...")
                try:
                    with Progress(
                        "[progress.description]{task.description}",
                        BarColumn(),
                        DownloadColumn(),
                        TransferSpeedColumn(),
                        TimeRemainingColumn(),
                    ) as prog:
                        task_id = prog.add_task(m.display_name, total=None)
                        def _cb(downloaded: int, total: int | None) -> None:
                            if total:
                                prog.update(task_id, completed=downloaded, total=total)
                        download_model(m, progress_callback=_cb)
                    renderer.success(f"  {m.name} downloaded")
                except Exception as exc:
                    renderer.error(f"  {m.name} failed: {exc}")

        if all_models or all_ollama:
            renderer.info(f"\nPulling {len(ollama_models)} Ollama models...")
            for i, m in enumerate(ollama_models, 1):
                ollama_name = m.name.removeprefix("ollama:")
                renderer.info(f"  [{i}/{len(ollama_models)}] Pulling {ollama_name}...")
                try:
                    result = subprocess.run(
                        ["ollama", "pull", ollama_name],
                        check=False,
                        timeout=600,
                        capture_output=True,
                    )
                    if result.returncode == 0:
                        renderer.success(f"  {ollama_name} pulled")
                    else:
                        renderer.error(f"  {ollama_name} failed (exit {result.returncode})")
                except FileNotFoundError:
                    renderer.error("Ollama is not installed. Install from https://ollama.com")
                    break
                except subprocess.TimeoutExpired:
                    renderer.error(f"  {ollama_name} timed out")

        renderer.success("\nBatch download complete!")
        return

    if list_available or (model_name is None and not search and not recommended):
        # Show full catalog
        entries = []
        for m in MODEL_CATALOG:
            if m.backend == "ollama":
                status = ""  # Ollama models checked at runtime
                size_str = m.params if m.params else "cloud"
            else:
                status = "[green]downloaded[/green]" if is_downloaded(m) else ""
                size_str = f"{m.size_gb:.1f} GB"
            entries.append(
                {
                    "name": m.name,
                    "size": size_str,
                    "params": m.params,
                    "family": m.family,
                    "description": m.description,
                    "status": status,
                }
            )
        renderer.print_catalog_table(entries)
        gguf_count = len([m for m in MODEL_CATALOG if m.backend == "gguf"])
        ollama_count = len([m for m in MODEL_CATALOG if m.backend == "ollama"])
        renderer.info(
            f"\n{len(MODEL_CATALOG)} models ({gguf_count} GGUF + {ollama_count} Ollama). "
            "Download with: sage pull <name>"
        )
        renderer.info("Recommended: sage pull qwen2.5-coder-3b (GGUF) or sage pull qwen3 (Ollama)")
        return

    if recommended:
        recs = get_recommended_models()
        entries = []
        for m in recs:
            status = "[green]downloaded[/green]" if is_downloaded(m) else ""
            entries.append(
                {
                    "name": m.name,
                    "size": f"{m.size_gb:.1f} GB",
                    "params": m.params,
                    "family": m.family,
                    "description": m.description,
                    "status": status,
                }
            )
        renderer.print_catalog_table(entries)
        return

    if search:
        results = search_catalog(search)
        if not results:
            renderer.warning(f"No models matching '{search}'")
            raise typer.Exit(1)
        entries = []
        for m in results:
            status = "[green]downloaded[/green]" if is_downloaded(m) else ""
            entries.append(
                {
                    "name": m.name,
                    "size": f"{m.size_gb:.1f} GB",
                    "params": m.params,
                    "family": m.family,
                    "description": m.description,
                    "status": status,
                }
            )
        renderer.print_catalog_table(entries)
        return

    # Download a specific model
    # Try exact match first, then with "ollama:" prefix
    cat_model = CATALOG_BY_NAME.get(model_name)
    if not cat_model and not model_name.startswith("ollama:"):
        cat_model = CATALOG_BY_NAME.get(f"ollama:{model_name}")
    if not cat_model:
        # Try fuzzy search
        results = search_catalog(model_name)
        if results:
            renderer.warning(f"Model '{model_name}' not found. Did you mean:")
            for m in results[:5]:
                if m.backend == "ollama":
                    renderer.info(
                        f"  sage pull {m.name}  — {m.display_name} (Ollama)"
                    )
                else:
                    renderer.info(
                        f"  sage pull {m.name}  — {m.display_name} ({m.size_gb:.1f} GB)"
                    )
        else:
            renderer.error(
                f"Model '{model_name}' not found. Run 'sage pull --list' to see available models."
            )
        raise typer.Exit(1)

    # ── Ollama model: pull via `ollama pull` ───────────────
    if cat_model.backend == "ollama":
        ollama_name = cat_model.name.removeprefix("ollama:")
        renderer.info(f"Pulling {cat_model.display_name} via Ollama...")
        renderer.info(f"Running: ollama pull {ollama_name}")
        renderer.console.print()
        try:
            result = subprocess.run(
                ["ollama", "pull", ollama_name],
                check=False,
                timeout=600,
            )
            if result.returncode == 0:
                renderer.success(f"{cat_model.display_name} pulled successfully!")
                renderer.info(
                    f"Run with: sage run --model ollama:{ollama_name}"
                )
            else:
                renderer.error(
                    f"ollama pull failed (exit code {result.returncode}). "
                    "Make sure Ollama is installed: https://ollama.com"
                )
                raise typer.Exit(2)
        except FileNotFoundError:
            renderer.error(
                "Ollama is not installed. Install it from https://ollama.com\n"
                "  Then run: sage pull " + model_name
            )
            raise typer.Exit(2)
        except subprocess.TimeoutExpired:
            renderer.error("Download timed out after 10 minutes.")
            raise typer.Exit(2)
        return

    # ── GGUF model: download from HuggingFace ─────────────
    if is_downloaded(cat_model):
        renderer.success(f"{cat_model.display_name} is already downloaded.")
        renderer.info(f"Run with: sage run --model llama_cpp:{cat_model.name}")
        return

    renderer.info(
        f"Downloading {cat_model.display_name} ({cat_model.size_gb:.1f} GB)..."
    )
    renderer.info(f"From: {cat_model.url[:80]}...")
    renderer.console.print()

    with Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=40),
        "[progress.percentage]{task.percentage:>3.0f}%",
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=renderer.console,
    ) as progress:
        task = progress.add_task(f"Downloading {cat_model.name}", total=None)

        def on_progress(downloaded: int, total: int) -> None:
            progress.update(task, total=total, completed=downloaded)

        try:
            path = download_model(cat_model, progress_callback=on_progress)
        except Exception as exc:
            renderer.error(f"Download failed: {exc}")
            raise typer.Exit(2)

    # Auto-register in config
    register_model(cat_model)
    renderer.print_download_complete(
        cat_model.display_name,
        str(path),
        cat_model.size_gb,
    )


@app.command("train-all")
def train_all(
    limit: Annotated[
        Optional[int],
        typer.Option(
            "--limit",
            "-n",
            help="Optional cap for number of models to prepare in one run",
        ),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", help="Re-download even if model is already present"),
    ] = False,
) -> None:
    """Prepare local model catalog for immediate CLI usage."""
    targets = MODEL_CATALOG if limit is None else MODEL_CATALOG[: max(0, limit)]
    if not targets:
        renderer.warning("No models selected.")
        return

    renderer.info(f"Preparing {len(targets)} model(s) for local usage...")
    ok = 0
    skipped = 0
    failed: list[str] = []

    for model in targets:
        if is_downloaded(model) and not force:
            skipped += 1
            renderer.info(f"Already prepared: {model.name}")
            continue
        try:
            path = download_model(model)
            register_model(model)
            ok += 1
            renderer.success(f"Prepared: {model.display_name} -> {path}")
        except Exception as exc:
            failed.append(f"{model.name}: {exc}")
            renderer.warning(f"Failed: {model.name} ({exc})")

    renderer.console.print()
    renderer.info(
        f"Done. prepared={ok} skipped={skipped} failed={len(failed)} total={len(targets)}"
    )
    if failed:
        for item in failed:
            renderer.warning(item)
        raise typer.Exit(2)


@app.command("rm")
def remove_model(
    model_name: Annotated[
        str, typer.Argument(help="Name of the downloaded model to remove")
    ],
) -> None:
    """Remove a downloaded model and free disk space."""
    if delete_model(model_name):
        renderer.success(f"Removed model: {model_name}")
    else:
        renderer.error(f"Model '{model_name}' not found in downloaded models.")
        raise typer.Exit(1)


# ── Config subcommands ──────────────────────────────────────


@config_app.command("show")
def config_show() -> None:
    """Show current configuration."""
    cfg = load_config()
    # Mask API keys for display
    display = cfg.to_dict()
    for key in display.get("api_keys", {}):
        val = display["api_keys"][key]
        if val and len(val) > 8:
            display["api_keys"][key] = val[:4] + "..." + val[-4:]
    renderer.print_config(display)


@config_app.command("set")
def config_set(
    key: Annotated[
        str, typer.Argument(help="Config key (e.g. api_keys.gemini, default_model)")
    ],
    value: Annotated[str, typer.Argument(help="Value to set")],
) -> None:
    """Set a configuration value."""
    try:
        set_config_value(key, value)
        renderer.success(f"Set {key}")
    except KeyError as exc:
        renderer.error(str(exc))
        raise typer.Exit(1)


@config_app.command("get")
def config_get(
    key: Annotated[str, typer.Argument(help="Config key to read")],
) -> None:
    """Get a configuration value."""
    try:
        val = get_config_value(key)
        renderer.console.print(val)
    except KeyError as exc:
        renderer.error(str(exc))
        raise typer.Exit(1)


@config_app.command("init")
def config_init() -> None:
    """Create default config file at ~/.sage/config.json."""
    cfg = SageConfig()
    save_config(cfg)
    renderer.success(f"Config created at ~/.sage/config.json")
    renderer.console.print()
    renderer.info("Quick start (no setup needed):")
    renderer.info(
        "  sage run                            # Start coding with pre-trained free models"
    )
    renderer.info(
        "  sage models                         # See all available providers/models"
    )
    renderer.console.print()
    renderer.info("Optional: add your own keys/providers:")
    renderer.info("  sage config set api_keys.gemini    YOUR_KEY  # Google AI Studio")
    renderer.info("  sage config set api_keys.groq      YOUR_KEY  # console.groq.com")
    renderer.info("  sage config set api_keys.cerebras  YOUR_KEY  # cloud.cerebras.ai")
    renderer.info("Optional local offline model: sage pull qwen2.5-coder-3b")


# ── DevOps Commands ─────────────────────────────────────────


devops_app = typer.Typer(help="DevOps, Git, GitHub, and CI/CD operations")
app.add_typer(devops_app, name="devops")


@devops_app.command("status")
def devops_status() -> None:
    """Show git status and latest CI/CD run status."""
    from sage.devops.git import GitOps
    from sage.devops.ci_cd import CICDMonitor

    git = GitOps()
    monitor = CICDMonitor()

    # Git status
    status = git.status()
    renderer.header("Git Status")
    renderer.info(f"  Branch: {status.branch}")
    if status.ahead:
        renderer.info(f"  Ahead: {status.ahead} commit(s)")
    if status.behind:
        renderer.info(f"  Behind: {status.behind} commit(s)")
    if status.staged:
        renderer.info(f"  Staged: {len(status.staged)} file(s)")
    if status.modified:
        renderer.info(f"  Modified: {len(status.modified)} file(s)")
    if status.untracked:
        renderer.info(f"  Untracked: {len(status.untracked)} file(s)")
    if status.is_clean:
        renderer.success("  Working tree clean")

    # Latest CI run
    renderer.console.print()
    renderer.header("Latest CI/CD Run")
    run = monitor.get_latest_run()
    if run:
        if run.conclusion == "success":
            status_text = "[green]SUCCESS[/green]"
        elif run.conclusion == "failure":
            status_text = "[red]FAILED[/red]"
        elif run.is_running:
            status_text = "[yellow]RUNNING[/yellow]"
        else:
            status_text = f"[dim]{run.status}[/dim]"
        renderer.info(f"  Workflow: {run.workflow_name}")
        renderer.info(f"  Status: {status_text}")
        renderer.info(f"  Branch: {run.head_branch}")
        renderer.info(f"  URL: {run.url}")
    else:
        renderer.info("  No recent runs found")


@devops_app.command("commit")
def devops_commit(
    message: Annotated[str, typer.Argument(help="Commit message")],
    push: Annotated[bool, typer.Option("--push", "-p", help="Push after commit")] = False,
    all_changes: Annotated[bool, typer.Option("--all", "-a", help="Stage all changes")] = True,
) -> None:
    """Stage changes and create a commit.

    Examples:
      sage devops commit "feat: add login"        Stage all and commit
      sage devops commit "fix: bug" --push        Commit and push
    """
    from sage.devops.git import GitOps

    git = GitOps()

    if all_changes:
        add_result = git.add_all()
        if not add_result.success:
            renderer.error(f"Failed to stage changes: {add_result.error}")
            raise typer.Exit(1)

    commit_result = git.commit(message)
    if not commit_result.success:
        renderer.error(f"Commit failed: {commit_result.error}")
        raise typer.Exit(1)

    renderer.success(f"Committed: {message}")

    if push:
        push_result = git.push()
        if push_result.success:
            renderer.success("Pushed to remote")
        else:
            renderer.error(f"Push failed: {push_result.error}")
            raise typer.Exit(1)


@devops_app.command("push")
def devops_push(
    set_upstream: Annotated[bool, typer.Option("--set-upstream", "-u", help="Set upstream tracking")] = False,
    force_with_lease: Annotated[bool, typer.Option("--force-with-lease", help="Safe force push")] = False,
) -> None:
    """Push commits to remote.

    Examples:
      sage devops push                   Push to tracked remote
      sage devops push -u                Push and set upstream
    """
    from sage.devops.git import GitOps

    git = GitOps()
    result = git.push(set_upstream=set_upstream, force_with_lease=force_with_lease)

    if result.success:
        renderer.success("Pushed to remote")
        if result.output:
            renderer.info(result.output)
    else:
        renderer.error(f"Push failed: {result.error}")
        raise typer.Exit(1)


@devops_app.command("pr")
def devops_pr(
    title: Annotated[Optional[str], typer.Argument(help="PR title")] = None,
    body: Annotated[str, typer.Option("--body", "-b", help="PR description")] = "",
    base: Annotated[str, typer.Option("--base", help="Base branch")] = "main",
    draft: Annotated[bool, typer.Option("--draft", "-d", help="Create as draft")] = False,
    list_prs: Annotated[bool, typer.Option("--list", "-l", help="List open PRs")] = False,
) -> None:
    """Create or list pull requests.

    Examples:
      sage devops pr "Add feature"           Create PR with title
      sage devops pr "Fix bug" --draft       Create draft PR
      sage devops pr --list                  List open PRs
    """
    from sage.devops.github import GitHubOps

    gh = GitHubOps()

    if list_prs:
        prs = gh.pr_list()
        if not prs:
            renderer.info("No open pull requests")
            return

        from rich.table import Table
        table = Table(title="Open Pull Requests")
        table.add_column("#", style="cyan")
        table.add_column("Title", style="white")
        table.add_column("Author", style="green")
        table.add_column("Branch", style="yellow")

        for pr in prs:
            table.add_row(str(pr.number), pr.title, pr.author, pr.head_branch)

        renderer.console.print(table)
        return

    if not title:
        renderer.error("Please provide a PR title or use --list")
        raise typer.Exit(1)

    result = gh.pr_create(title=title, body=body, base=base, draft=draft)
    if result.success:
        renderer.success(f"Created PR: {result.output}")
    else:
        renderer.error(f"Failed to create PR: {result.error}")
        raise typer.Exit(1)


@devops_app.command("watch")
def devops_watch(
    run_id: Annotated[Optional[int], typer.Argument(help="Workflow run ID (latest if omitted)")] = None,
    workflow: Annotated[Optional[str], typer.Option("--workflow", "-w", help="Filter by workflow file")] = None,
    branch: Annotated[Optional[str], typer.Option("--branch", "-b", help="Filter by branch")] = None,
) -> None:
    """Watch a CI/CD deployment with live progress bar.

    Examples:
      sage devops watch                      Watch latest run
      sage devops watch 12345678             Watch specific run ID
      sage devops watch -w ci.yml            Watch latest CI workflow
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    if run_id is None:
        run = monitor.get_latest_run(branch=branch, workflow=workflow)
        if not run:
            renderer.error("No workflow runs found")
            raise typer.Exit(1)
        run_id = run.id
        renderer.info(f"Watching: {run.workflow_name} (run {run.id})")

    final_status = monitor.watch_with_progress(run_id)

    if final_status:
        if final_status.conclusion == "success":
            renderer.success("Deployment completed successfully!")
        elif final_status.conclusion == "failure":
            renderer.error(f"Deployment failed ({final_status.jobs_failed} job(s) failed)")
            renderer.info(f"View logs: gh run view {run_id} --log-failed")
            raise typer.Exit(1)
        else:
            renderer.warning(f"Deployment ended: {final_status.conclusion}")


@devops_app.command("runs")
def devops_runs(
    limit: Annotated[int, typer.Option("--limit", "-n", help="Number of runs")] = 10,
    workflow: Annotated[Optional[str], typer.Option("--workflow", "-w", help="Filter by workflow")] = None,
    branch: Annotated[Optional[str], typer.Option("--branch", "-b", help="Filter by branch")] = None,
) -> None:
    """List recent workflow runs.

    Examples:
      sage devops runs                       List 10 most recent runs
      sage devops runs -n 20                 List 20 runs
      sage devops runs -w ci.yml             List runs for ci.yml workflow
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()
    runs = monitor.gh.run_list(workflow=workflow, branch=branch, limit=limit)

    if not runs:
        renderer.info("No workflow runs found")
        return

    from rich.table import Table
    table = Table(title="Workflow Runs")
    table.add_column("ID", style="dim")
    table.add_column("Workflow", style="cyan")
    table.add_column("Branch", style="yellow")
    table.add_column("Status", justify="center")
    table.add_column("Commit", style="dim")

    for run in runs:
        if run.conclusion == "success":
            status = "[green]SUCCESS[/green]"
        elif run.conclusion == "failure":
            status = "[red]FAILED[/red]"
        elif run.is_running:
            status = "[yellow]RUNNING[/yellow]"
        else:
            status = f"[dim]{run.status}[/dim]"

        table.add_row(
            str(run.id),
            run.workflow_name,
            run.head_branch,
            status,
            run.head_sha[:8],
        )

    renderer.console.print(table)


@devops_app.command("diagnose")
def devops_diagnose(
    run_id: Annotated[Optional[int], typer.Argument(help="Workflow run ID (latest failed if omitted)")] = None,
) -> None:
    """Diagnose failures in a CI/CD run.

    Examples:
      sage devops diagnose                   Diagnose latest failed run
      sage devops diagnose 12345678          Diagnose specific run
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    if run_id is None:
        runs = monitor.gh.run_list(limit=10)
        failed_runs = [r for r in runs if r.conclusion == "failure"]
        if not failed_runs:
            renderer.info("No recent failed runs to diagnose")
            return
        run_id = failed_runs[0].id
        renderer.info(f"Diagnosing latest failed run: {run_id}")

    diagnoses = monitor.diagnose(run_id)

    if not diagnoses:
        renderer.info("No specific errors identified")
        renderer.info(f"View full logs: gh run view {run_id} --log-failed")
        return

    for diag in diagnoses:
        from rich.panel import Panel
        fix_text = ""
        if diag.can_auto_fix:
            fix_text = f"\n[green]Auto-fixable:[/green] {diag.suggested_fix}"
        elif diag.suggested_fix:
            fix_text = f"\n[yellow]Suggested fix:[/yellow] {diag.suggested_fix}"

        renderer.console.print(Panel(
            f"[bold]{diag.error_type}[/bold]\n"
            f"Job: {diag.job_name}\n"
            f"Step: {diag.step_name}\n"
            f"Error: {diag.error_message}"
            + (f"\nFile: {diag.file_path}:{diag.line_number}" if diag.file_path else "")
            + fix_text,
            title="Failure Diagnosis",
            border_style="red" if not diag.can_auto_fix else "yellow",
        ))


@devops_app.command("fix")
def devops_fix(
    run_id: Annotated[Optional[int], typer.Argument(help="Workflow run ID to fix")] = None,
    commit: Annotated[bool, typer.Option("--commit", "-c", help="Commit the fix")] = True,
    push: Annotated[bool, typer.Option("--push", "-p", help="Push after committing")] = True,
) -> None:
    """Attempt to auto-fix failures in a CI/CD run.

    Examples:
      sage devops fix                        Fix latest failed run
      sage devops fix 12345678               Fix specific run
      sage devops fix --no-push              Fix but don't push
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    if run_id is None:
        runs = monitor.gh.run_list(limit=10)
        failed_runs = [r for r in runs if r.conclusion == "failure"]
        if not failed_runs:
            renderer.info("No recent failed runs to fix")
            return
        run_id = failed_runs[0].id

    diagnoses = monitor.diagnose(run_id)
    fixable = [d for d in diagnoses if d.can_auto_fix]

    if not fixable:
        renderer.warning("No auto-fixable issues found")
        renderer.info("Run 'sage devops diagnose' to see all issues")
        return

    renderer.info(f"Found {len(fixable)} fixable issue(s)")

    for diag in fixable:
        renderer.info(f"  Fixing: {diag.error_type} - {diag.suggested_fix}")
        if monitor.auto_fix(diag, commit=False, push=False):
            renderer.success(f"  Fixed!")
        else:
            renderer.error(f"  Failed to fix")

    if commit:
        from sage.devops.git import GitOps
        git = GitOps()
        git.add_all()
        git.commit("fix: auto-fix CI failures")
        renderer.success("Committed fixes")

        if push:
            result = git.push()
            if result.success:
                renderer.success("Pushed to remote")
                renderer.info("CI will re-run automatically. Watch with: sage devops watch")
            else:
                renderer.error(f"Push failed: {result.error}")


@devops_app.command("deploy")
def devops_deploy(
    message: Annotated[Optional[str], typer.Argument(help="Commit message (if changes exist)")] = None,
    auto_fix: Annotated[bool, typer.Option("--auto-fix", "-f", help="Auto-fix failures and retry")] = False,
    max_retries: Annotated[int, typer.Option("--retries", "-r", help="Max auto-fix retries")] = 3,
    workflow: Annotated[Optional[str], typer.Option("--workflow", "-w", help="Workflow to watch")] = None,
) -> None:
    """Full deployment flow: commit, push, watch, and optionally auto-fix.

    Examples:
      sage devops deploy "feat: new feature"        Commit, push, and watch
      sage devops deploy --auto-fix                 Deploy with auto-fix on failure
      sage devops deploy -f -r 5                    Auto-fix with 5 retries
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    success, final_status = monitor.deploy_and_watch(
        commit_message=message,
        workflow=workflow,
        auto_fix=auto_fix,
        max_retries=max_retries,
    )

    if success:
        renderer.success("Deployment completed successfully!")
    else:
        if final_status:
            renderer.error(f"Deployment failed: {final_status.conclusion}")
            renderer.info("Run 'sage devops diagnose' for failure analysis")
        raise typer.Exit(1)


@devops_app.command("rerun")
def devops_rerun(
    run_id: Annotated[Optional[int], typer.Argument(help="Workflow run ID to rerun")] = None,
    failed_only: Annotated[bool, typer.Option("--failed", "-f", help="Only rerun failed jobs")] = True,
    watch: Annotated[bool, typer.Option("--watch", "-w", help="Watch the rerun")] = True,
) -> None:
    """Rerun a workflow run.

    Examples:
      sage devops rerun                      Rerun latest run (failed jobs only)
      sage devops rerun 12345678             Rerun specific run
      sage devops rerun --no-failed          Rerun all jobs
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    if run_id is None:
        run = monitor.get_latest_run()
        if not run:
            renderer.error("No workflow runs found")
            raise typer.Exit(1)
        run_id = run.id

    result = monitor.gh.run_rerun(run_id, failed_only=failed_only)

    if result.success:
        renderer.success(f"Rerun triggered for run {run_id}")
        if watch:
            import time
            time.sleep(3)  # Wait for new run to appear
            new_run = monitor.get_latest_run()
            if new_run:
                renderer.info(f"Watching new run: {new_run.id}")
                monitor.watch_with_progress(new_run.id)
    else:
        renderer.error(f"Failed to rerun: {result.error}")
        raise typer.Exit(1)


# ── Version callback ────────────────────────────────────────


def _version_callback(value: bool) -> None:
    if value:
        renderer.console.print(f"sage {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-v", callback=_version_callback, is_eager=True),
    ] = None,
) -> None:
    """Sage — local-first AI coding assistant."""


def run() -> None:
    """Entry point for pyproject.toml console_scripts."""
    app()
