from typing import Any

from systemrdl.component import Field
from systemrdl.node import Node
from systemrdl.udp import UDPDefinition


class IsSigned(UDPDefinition):
    name = "is_signed"
    valid_components = {Field}
    valid_type = bool
    default_assignment = True

    def validate(self, node: "Node", value: Any) -> None:
        # "counter" fields can not be signed
        if value and node.get_property("counter"):
            self.msg.error(
                "The property is_signed=true is not supported for counter fields.",
                node.property_src_ref.get("is_signed", node.inst_src_ref)
            )

        # incompatible with "encode" fields
        if value and node.get_property("encode") is not None:
            self.msg.error(
                "The property is_signed=true is not supported for fields encoded as an enum.",
                node.property_src_ref.get("is_signed", node.inst_src_ref)
            )

    def get_unassigned_default(self, node: "Node") -> Any:
        """
        No unassigned default.

        VHDL treats no sign (std_logic_vector) different than unsigned (unsigned).
        """
        return None
