"""Unit tests for the Litestar auth plugin orchestrator helpers."""

from __future__ import annotations

import asyncio
import importlib
import warnings
from dataclasses import dataclass
from datetime import timedelta
from functools import partial
from typing import Any, Literal, cast
from unittest.mock import AsyncMock, patch
from uuid import UUID, uuid4

import pytest
from cryptography.fernet import Fernet
from litestar.config.app import AppConfig
from litestar.config.csrf import CSRFConfig
from litestar.exceptions import ClientException
from litestar.middleware import DefineMiddleware

import litestar_auth.plugin as plugin_module
from litestar_auth._plugin import (
    DEFAULT_BACKENDS_DEPENDENCY_KEY,
    DEFAULT_CONFIG_DEPENDENCY_KEY,
    DEFAULT_CSRF_COOKIE_NAME,
    DEFAULT_USER_MANAGER_DEPENDENCY_KEY,
    DEFAULT_USER_MODEL_DEPENDENCY_KEY,
)
from litestar_auth._plugin.dependencies import DependencyProviders, register_dependencies
from litestar_auth.authentication import Authenticator, LitestarAuthMiddleware
from litestar_auth.authentication.backend import AuthenticationBackend
from litestar_auth.authentication.strategy.db import DatabaseTokenStrategy
from litestar_auth.authentication.strategy.jwt import JWTStrategy
from litestar_auth.authentication.transport.bearer import BearerTransport
from litestar_auth.authentication.transport.cookie import CookieTransport
from litestar_auth.manager import require_password_length
from litestar_auth.oauth_encryption import get_oauth_encryption_key_callable, oauth_token_encryption_scope
from litestar_auth.password import PasswordHelper
from litestar_auth.plugin import LitestarAuth, LitestarAuthConfig, OAuthConfig, TotpConfig
from litestar_auth.ratelimit import AuthRateLimitConfig, EndpointRateLimit, InMemoryRateLimiter, RedisRateLimiter
from litestar_auth.totp import InMemoryUsedTotpCodeStore, SecurityWarning
from tests.integration.test_orchestrator import (
    DummySession,
    DummySessionMaker,
    ExampleUser,
    InMemoryTokenStrategy,
    InMemoryUserDatabase,
    PluginUserManager,
)

pytestmark = pytest.mark.unit


def test_plugin_module_executes_under_coverage() -> None:
    """Reload the module in-test so coverage records the module body."""
    reloaded_module = importlib.reload(plugin_module)

    assert reloaded_module.LitestarAuth.__name__ == LitestarAuth.__name__
    assert reloaded_module.LitestarAuthConfig.__name__ == LitestarAuthConfig.__name__
    assert reloaded_module.__all__ == ("LitestarAuth", "LitestarAuthConfig", "OAuthConfig", "TotpConfig")


def _minimal_config(
    *,
    backends: list[AuthenticationBackend[ExampleUser, UUID]] | None = None,
    include_users: bool = False,
    user_manager_class: type[Any] | None = None,
    login_identifier: Literal["email", "username"] = "email",
) -> LitestarAuthConfig[ExampleUser, UUID]:
    """Build a minimal plugin config for orchestrator-focused tests.

    Returns:
        Configured plugin settings suitable for isolated orchestrator tests.
    """
    user_db = InMemoryUserDatabase([])
    configured_backends = backends or [
        AuthenticationBackend[ExampleUser, UUID](
            name="primary",
            transport=BearerTransport(),
            strategy=cast("Any", InMemoryTokenStrategy(token_prefix="plugin-orchestrator")),
        ),
    ]
    return LitestarAuthConfig[ExampleUser, UUID](
        backends=configured_backends,
        session_maker=cast("Any", DummySessionMaker()),
        user_model=ExampleUser,
        user_manager_class=user_manager_class or PluginUserManager,
        user_db_factory=lambda _session: user_db,
        user_manager_kwargs={
            "verification_token_secret": "verify-secret-12345678901234567890",
            "reset_password_token_secret": "reset-secret-123456789012345678901",
            "id_parser": UUID,
        },
        include_users=include_users,
        login_identifier=login_identifier,
    )


def test_litestar_auth_init_delegates_to_validate_config() -> None:
    """Plugin construction keeps validation ownership inside the facade."""
    config = _minimal_config()

    with patch("litestar_auth.plugin.validate_config") as validate_config_mock:
        LitestarAuth(config)

    validate_config_mock.assert_called_once_with(config)


def test_on_app_init_runs_lifecycle_steps_in_order(monkeypatch: pytest.MonkeyPatch) -> None:
    """App init runs startup warnings, key validation, and registration steps in order."""
    plugin = LitestarAuth(_minimal_config())
    app_config = AppConfig()
    calls: list[str] = []

    monkeypatch.setattr(
        "litestar_auth.plugin.warn_insecure_plugin_startup_defaults",
        lambda _config: calls.append("warn"),
    )
    monkeypatch.setattr(
        "litestar_auth.plugin.require_oauth_token_encryption_for_configured_providers",
        lambda **_kwargs: calls.append("require-oauth-key"),
    )
    monkeypatch.setattr(
        "litestar_auth.plugin.warn_if_insecure_oauth_redirect_in_production",
        lambda **_kwargs: calls.append("warn-oauth-redirect"),
    )
    monkeypatch.setattr(plugin, "_register_dependencies", lambda _app_config: calls.append("dependencies"))
    monkeypatch.setattr(plugin, "_register_middleware", lambda _app_config: calls.append("middleware"))
    monkeypatch.setattr(plugin, "_register_controllers", lambda _app_config: calls.append("controllers"))
    monkeypatch.setattr(plugin, "_register_exception_handlers", lambda _app_config: calls.append("exceptions"))

    result = plugin.on_app_init(app_config)

    assert result is app_config
    assert calls == [
        "warn",
        "require-oauth-key",
        "warn-oauth-redirect",
        "dependencies",
        "middleware",
        "controllers",
        "exceptions",
    ]


def test_on_app_init_registers_middleware_controllers_dependencies_and_exceptions() -> None:
    """App init mutates AppConfig with the orchestrator's core wiring."""
    backend = AuthenticationBackend[ExampleUser, UUID](
        name="cookie",
        transport=CookieTransport(cookie_name="authcookie", path="/auth", secure=False, samesite="strict"),
        strategy=cast("Any", InMemoryTokenStrategy(token_prefix="cookie-plugin")),
    )
    config = _minimal_config(backends=[backend], include_users=True)
    config.csrf_secret = "c" * 32
    plugin = LitestarAuth(config)
    app_config = AppConfig()

    result = plugin.on_app_init(app_config)

    assert result is app_config
    assert DEFAULT_CONFIG_DEPENDENCY_KEY in result.dependencies
    assert DEFAULT_USER_MANAGER_DEPENDENCY_KEY in result.dependencies
    assert DEFAULT_BACKENDS_DEPENDENCY_KEY in result.dependencies
    assert DEFAULT_USER_MODEL_DEPENDENCY_KEY in result.dependencies
    assert "db_session" in result.dependencies
    assert result.route_handlers
    assert result.exception_handlers[ClientException]
    assert isinstance(result.csrf_config, CSRFConfig)
    assert result.csrf_config.cookie_name == DEFAULT_CSRF_COOKIE_NAME
    assert result.csrf_config.cookie_path == "/auth"
    assert result.csrf_config.cookie_secure is False
    assert result.csrf_config.cookie_samesite == "strict"

    middleware = result.middleware[0]
    assert isinstance(middleware, DefineMiddleware)
    assert getattr(middleware.middleware, "__name__", "") == LitestarAuthMiddleware.__name__
    assert middleware.kwargs["authenticator_factory"] == plugin._build_authenticator
    assert middleware.kwargs["auth_cookie_names"] == frozenset({b"authcookie", b"authcookie_refresh"})

    session_getter = middleware.kwargs["get_request_session"]
    assert isinstance(session_getter, partial)
    assert session_getter.func.__name__ == "get_or_create_scoped_session"


def test_on_app_init_warns_for_nondurable_jwt_strategy_when_acknowledged() -> None:
    """Lifecycle startup still surfaces the JWT durability warning after explicit opt-in."""
    backend = AuthenticationBackend[ExampleUser, UUID](
        name="jwt-backend",
        transport=CookieTransport(),
        strategy=cast("Any", JWTStrategy(secret="a" * 32, algorithm="HS256")),
    )
    config = _minimal_config(backends=[backend])
    config.allow_nondurable_jwt_revocation = True
    config.csrf_secret = "c" * 32
    plugin = LitestarAuth(config)

    with pytest.warns(SecurityWarning, match="process-local in-memory denylist"):
        plugin.on_app_init(AppConfig())


def test_on_app_init_warns_security_warning_for_inmemory_rate_limiter_in_production() -> None:
    """Production app init emits SecurityWarning when rate-limit state is process-local."""
    config = _minimal_config()
    config.rate_limit_config = AuthRateLimitConfig(
        login=EndpointRateLimit(
            backend=InMemoryRateLimiter(max_attempts=3, window_seconds=60),
            scope="ip",
            namespace="login",
        ),
    )
    plugin = LitestarAuth(config)

    with pytest.warns(SecurityWarning, match="process-local in-memory backend"):
        plugin.on_app_init(AppConfig())


def test_on_app_init_does_not_warn_for_redis_rate_limiter() -> None:
    """Shared Redis-backed rate limiting stays silent during app init."""

    class _RedisStub:
        async def delete(self, *names: str) -> int:
            return len(names)

        async def eval(self, script: str, numkeys: int, *keys_and_args: object) -> int:
            del script, numkeys, keys_and_args
            return 0

    config = _minimal_config()
    config.rate_limit_config = AuthRateLimitConfig(
        login=EndpointRateLimit(
            backend=RedisRateLimiter(redis=_RedisStub(), max_attempts=3, window_seconds=60),
            scope="ip",
            namespace="login",
        ),
    )
    plugin = LitestarAuth(config)

    with warnings.catch_warnings(record=True) as records:
        warnings.simplefilter("always")
        plugin.on_app_init(AppConfig())

    assert not any(issubclass(record.category, SecurityWarning) for record in records)


def test_on_app_init_does_not_warn_for_inmemory_rate_limiter_in_testing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Testing-mode lifecycle suppresses the in-memory rate-limit startup warning."""
    monkeypatch.setenv("LITESTAR_AUTH_TESTING", "1")
    monkeypatch.setenv("PYTEST_CURRENT_TEST", "tests/unit/test_plugin_orchestrator.py::test_example")
    config = _minimal_config()
    config.rate_limit_config = AuthRateLimitConfig(
        login=EndpointRateLimit(
            backend=InMemoryRateLimiter(max_attempts=3, window_seconds=60),
            scope="ip",
            namespace="login",
        ),
    )
    plugin = LitestarAuth(config)

    with warnings.catch_warnings(record=True) as records:
        warnings.simplefilter("always")
        plugin.on_app_init(AppConfig())

    assert not any(issubclass(record.category, SecurityWarning) for record in records)


def test_on_app_init_rejects_mismatched_cookie_transport_settings() -> None:
    """Lifecycle middleware registration still rejects incompatible cookie transport shapes."""
    first_backend = AuthenticationBackend[ExampleUser, UUID](
        name="cookie-primary",
        transport=CookieTransport(path="/auth"),
        strategy=cast("Any", InMemoryTokenStrategy(token_prefix="cookie-primary")),
    )
    second_backend = AuthenticationBackend[ExampleUser, UUID](
        name="cookie-secondary",
        transport=CookieTransport(path="/other-auth"),
        strategy=cast("Any", InMemoryTokenStrategy(token_prefix="cookie-secondary")),
    )
    config = _minimal_config(backends=[first_backend, second_backend])
    config.csrf_secret = "c" * 32
    plugin = LitestarAuth(config)

    with pytest.raises(ValueError, match="must share path, domain, secure, and samesite"):
        plugin.on_app_init(AppConfig())


def test_on_app_init_accepts_multiple_matching_cookie_transports() -> None:
    """Matching cookie transports share one orchestrator-managed CSRF config."""
    backends = [
        AuthenticationBackend[ExampleUser, UUID](
            name=f"cookie-{index}",
            transport=CookieTransport(path="/auth", secure=False, samesite="strict"),
            strategy=cast("Any", InMemoryTokenStrategy(token_prefix=f"cookie-{index}")),
        )
        for index in range(3)
    ]
    config = _minimal_config(backends=backends)
    config.csrf_secret = "c" * 32
    plugin = LitestarAuth(config)

    result = plugin.on_app_init(AppConfig())

    assert result.csrf_config is not None
    assert result.csrf_config.cookie_path == "/auth"
    assert result.csrf_config.cookie_samesite == "strict"


def test_on_app_init_requires_oauth_token_encryption_key_for_oauth_providers() -> None:
    """OAuth-enabled startup fails closed without an encryption key in non-test runtime."""
    config = _minimal_config()
    config.oauth_config = OAuthConfig(oauth_providers=[("github", object())])
    plugin = LitestarAuth(config)

    with (
        pytest.warns(SecurityWarning, match="oauth_token_encryption_key is not set"),
        pytest.raises(Exception, match=r"Fernet\.generate_key\(\)") as exc_info,
    ):
        plugin.on_app_init(AppConfig())

    assert type(exc_info.value).__name__ == "ConfigurationError"


def test_on_app_init_allows_oauth_providers_when_encryption_key_is_configured() -> None:
    """Configured OAuth encryption keys keep app-init startup guard silent."""
    config = _minimal_config()
    config.oauth_config = OAuthConfig(
        oauth_providers=[("github", object())],
        oauth_token_encryption_key="a" * 44,
    )
    plugin = LitestarAuth(config)

    with warnings.catch_warnings(record=True) as records:
        warnings.simplefilter("always")
        result = plugin.on_app_init(AppConfig())

    assert result is not None
    assert not any(issubclass(record.category, SecurityWarning) for record in records)


def test_on_app_init_warns_security_warning_for_inmemory_totp_used_store(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Production startup warns when the TOTP replay store is process-local."""
    monkeypatch.delenv("LITESTAR_AUTH_TESTING", raising=False)
    config = _minimal_config()
    config.totp_config = TotpConfig(
        totp_pending_secret="x" * 32,
        totp_used_tokens_store=InMemoryUsedTotpCodeStore(),
    )
    config.user_manager_kwargs["totp_secret_key"] = Fernet.generate_key().decode()
    plugin = LitestarAuth(config)

    with pytest.warns(SecurityWarning, match="InMemoryUsedTotpCodeStore"):
        plugin.on_app_init(AppConfig())


def test_on_app_init_allows_missing_oauth_token_encryption_key_in_testing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Testing mode bypasses the OAuth token-encryption startup guard."""
    monkeypatch.setenv("LITESTAR_AUTH_TESTING", "1")
    config = _minimal_config()
    config.oauth_config = OAuthConfig(oauth_providers=[("github", object())])
    plugin = LitestarAuth(config)

    with warnings.catch_warnings(record=True) as records:
        warnings.simplefilter("always")
        result = plugin.on_app_init(AppConfig())

    assert result is not None
    assert not any(issubclass(record.category, SecurityWarning) for record in records)


def test_register_dependencies_delegates_with_bound_provider_methods() -> None:
    """Dependency registration passes the plugin's bound provider methods through unchanged."""
    plugin = LitestarAuth(_minimal_config())
    app_config = AppConfig()

    with patch("litestar_auth.plugin.register_dependencies") as register_dependencies_mock:
        plugin._register_dependencies(app_config)

    register_dependencies_mock.assert_called_once()
    _, config_arg = register_dependencies_mock.call_args.args
    providers = cast("DependencyProviders", register_dependencies_mock.call_args.kwargs["providers"])

    assert config_arg is plugin.config
    assert cast("Any", providers.config)() is plugin.config
    assert providers.user_manager is plugin._provide_user_manager
    assert providers.backends is plugin._provide_request_backends
    assert cast("Any", providers.user_model)() is plugin.config.user_model
    assert providers.oauth_associate_user_manager is plugin._provide_oauth_associate_user_manager
    assert providers.oauth_associate_user_manager is not providers.user_manager


def test_register_dependencies_registers_db_session_when_using_builtin_session_maker() -> None:
    """Dependency helpers publish the plugin-owned DB session provider when needed."""
    app_config = AppConfig()
    app_config.dependencies = {}
    config = _minimal_config()
    config.db_session_dependency_key = "my_db_session"

    async def _provide_config() -> object:
        await asyncio.sleep(0)
        return config

    async def _provide_user_manager() -> object:
        await asyncio.sleep(0)
        yield object()

    async def _provide_backends() -> object:
        await asyncio.sleep(0)
        return ()

    async def _provide_user_model() -> object:
        await asyncio.sleep(0)
        return ExampleUser

    async def _provide_oauth_associate() -> object:
        await asyncio.sleep(0)
        yield object()

    register_dependencies(
        app_config,
        config,
        providers=DependencyProviders(
            config=_provide_config,
            user_manager=_provide_user_manager,
            backends=_provide_backends,
            user_model=_provide_user_model,
            oauth_associate_user_manager=_provide_oauth_associate,
        ),
    )

    assert "my_db_session" in app_config.dependencies


def test_register_dependencies_skips_builtin_db_session_when_external_declared() -> None:
    """Dependency helpers avoid registering a conflicting DB-session provider."""
    app_config = AppConfig()
    app_config.dependencies = {}
    config = _minimal_config()
    config.db_session_dependency_provided_externally = True

    async def _provide_config() -> object:
        await asyncio.sleep(0)
        return config

    async def _provide_user_manager() -> object:
        await asyncio.sleep(0)
        yield object()

    async def _provide_backends() -> object:
        await asyncio.sleep(0)
        return ()

    async def _provide_user_model() -> object:
        await asyncio.sleep(0)
        return ExampleUser

    async def _provide_oauth_associate() -> object:
        await asyncio.sleep(0)
        yield object()

    register_dependencies(
        app_config,
        config,
        providers=DependencyProviders(
            config=_provide_config,
            user_manager=_provide_user_manager,
            backends=_provide_backends,
            user_model=_provide_user_model,
            oauth_associate_user_manager=_provide_oauth_associate,
        ),
    )

    assert config.db_session_dependency_key not in app_config.dependencies


def test_register_exception_handlers_delegates_to_shared_registration_function() -> None:
    """Exception-handler registration goes through the shared dependency helper."""
    plugin = LitestarAuth(_minimal_config())
    app_config = AppConfig()

    with patch("litestar_auth.plugin.register_exception_handlers") as register_handlers_mock:
        plugin._register_exception_handlers(app_config)

    register_handlers_mock.assert_called_once_with(app_config)


def test_register_controllers_extends_route_handlers() -> None:
    """Controller registration appends the shared controller set onto AppConfig."""
    plugin = LitestarAuth(_minimal_config())
    app_config = AppConfig()
    app_config.route_handlers.append(cast("Any", "existing"))

    with patch("litestar_auth.plugin.build_controllers", return_value=["new-controller"]) as build_controllers_mock:
        plugin._register_controllers(app_config)

    assert app_config.route_handlers == ["existing", "new-controller"]
    build_controllers_mock.assert_called_once_with(plugin.config)


@dataclass(slots=True)
class _ScopedProxyRecorder:
    user_db: object
    oauth_scope: object


@dataclass(slots=True)
class _FakeSessionBoundBackend:
    strategy: object
    bound_session: object | None = None

    def with_session(self, session: object) -> _FakeSessionBoundBackend:
        self.bound_session = session
        return self


@dataclass(slots=True)
class _InvalidationStrategy:
    invalidate_all_tokens: AsyncMock

    def with_session(self, _session: object) -> _InvalidationStrategy:
        return self


EXPECTED_BOUND_BACKEND_COUNT = 2


def test_build_user_manager_wraps_user_db_and_passes_bound_backends(monkeypatch: pytest.MonkeyPatch) -> None:
    """User-manager construction wraps the user DB and forwards session-bound backends."""
    plugin = LitestarAuth(_minimal_config())
    session = object()
    raw_user_db = object()
    captured: dict[str, object] = {}

    plugin.config.user_db_factory = lambda configured_session: raw_user_db if configured_session is session else None  # ty:ignore[invalid-assignment]
    monkeypatch.setattr("litestar_auth.plugin.ScopedUserDatabaseProxyImpl", _ScopedProxyRecorder)
    monkeypatch.setattr(
        plugin,
        "_session_bound_backends",
        lambda configured_session: [f"backend-for-{id(configured_session)}"],
    )

    def _factory(**kwargs: object) -> object:
        captured.update(kwargs)
        return "manager"

    plugin._user_manager_factory = _factory

    manager = plugin._build_user_manager(cast("Any", session))

    assert manager == "manager"
    assert captured["session"] is session
    assert captured["config"] is plugin.config
    assert captured["user_db"] == _ScopedProxyRecorder(user_db=raw_user_db, oauth_scope=plugin)
    assert captured["backends"] == (f"backend-for-{id(session)}",)


def test_build_user_manager_attaches_session_bound_backends() -> None:
    """Built managers receive request-local backends bound to the active session."""
    config = _minimal_config(
        backends=[
            cast("AuthenticationBackend[ExampleUser, UUID]", _FakeSessionBoundBackend(strategy=object())),
            cast("AuthenticationBackend[ExampleUser, UUID]", _FakeSessionBoundBackend(strategy=object())),
        ],
    )
    plugin = LitestarAuth(config)

    session = object()
    manager = plugin._build_user_manager(cast("Any", session))

    assert len(manager.backends) == EXPECTED_BOUND_BACKEND_COUNT
    assert all(getattr(backend, "bound_session", None) is session for backend in manager.backends)


def test_build_user_manager_passes_login_identifier_from_config() -> None:
    """Session-bound manager construction forwards login_identifier from plugin config."""
    plugin = LitestarAuth(_minimal_config(login_identifier="username"))

    manager = plugin._build_user_manager(cast("Any", object()))

    assert manager.login_identifier == "username"


def test_build_user_manager_uses_explicit_password_validator_factory() -> None:
    """Session-bound manager construction respects explicit password-validator factories."""
    config = _minimal_config()
    config.password_validator_factory = lambda _config: lambda password: require_password_length(password, 10)
    plugin = LitestarAuth(config)

    manager = plugin._build_user_manager(cast("Any", object()))

    with pytest.raises(ValueError, match="at least 10"):
        manager.password_validator("short")


def test_build_user_manager_preserves_legacy_manager_without_password_validator_parameter() -> None:
    """Compatibility builder still supports legacy manager constructors."""

    class LegacyManagerWithoutPasswordValidator(PluginUserManager):
        def __init__(
            self,
            user_db: object,
            *,
            verification_token_secret: str,
            reset_password_token_secret: str,
            backends: tuple[object, ...] = (),
        ) -> None:
            super().__init__(
                cast("Any", user_db),
                verification_token_secret=verification_token_secret,
                reset_password_token_secret=reset_password_token_secret,
                backends=backends,
            )

    config = _minimal_config(user_manager_class=LegacyManagerWithoutPasswordValidator)
    config.user_manager_kwargs.pop("id_parser")
    plugin = LitestarAuth(config)

    manager = plugin._build_user_manager(cast("Any", object()))

    assert isinstance(manager, LegacyManagerWithoutPasswordValidator)
    assert manager.password_validator is None


@pytest.mark.asyncio
async def test_session_bound_user_manager_update_triggers_strategy_invalidation_on_email_change() -> None:
    """Session-bound managers revoke backend sessions after sensitive updates."""
    user = ExampleUser(
        id=uuid4(),
        email="user@example.com",
        hashed_password=PasswordHelper().hash("correct-password"),
    )
    user_db = InMemoryUserDatabase([user])
    invalidate_mock = AsyncMock()
    backend = _FakeSessionBoundBackend(strategy=_InvalidationStrategy(invalidate_all_tokens=invalidate_mock))
    config = LitestarAuthConfig[ExampleUser, UUID](
        backends=[cast("AuthenticationBackend[ExampleUser, UUID]", backend)],
        user_model=ExampleUser,
        user_manager_class=PluginUserManager,
        session_maker=cast("Any", DummySessionMaker()),
        user_db_factory=lambda _session: user_db,
        user_manager_kwargs={
            "verification_token_secret": "x" * 32,
            "reset_password_token_secret": "y" * 32,
        },
    )
    plugin = LitestarAuth(config)

    manager = plugin._build_user_manager(cast("Any", DummySession()))
    await manager.update({"email": "updated@example.com"}, user)

    invalidate_mock.assert_awaited_once()


def test_session_bound_user_manager_uses_explicit_account_state_validator_contract() -> None:
    """Session-bound managers preserve the configured account-state validator contract."""
    calls: list[tuple[ExampleUser, bool]] = []

    class _TrackingManager(PluginUserManager):
        def require_account_state(self, user: ExampleUser, *, require_verified: bool = False) -> None:
            del self
            calls.append((user, require_verified))

    plugin = LitestarAuth(_minimal_config(user_manager_class=_TrackingManager))
    user = ExampleUser(
        id=uuid4(),
        email="user@example.com",
        hashed_password=PasswordHelper().hash("correct-password"),
    )

    manager = plugin._build_user_manager(cast("Any", DummySession()))
    manager.require_account_state(user, require_verified=True)

    assert calls == [(user, True)]


def test_session_bound_backends_rebinds_each_backend_to_current_session() -> None:
    """Configured backends are rebound against the request-local session."""

    @dataclass(slots=True)
    class _BackendRecorder:
        name: str
        seen_sessions: list[object]

        def with_session(self, session: object) -> str:
            self.seen_sessions.append(session)
            return f"{self.name}-{id(session)}"

    first_backend = _BackendRecorder(name="first", seen_sessions=[])
    second_backend = _BackendRecorder(name="second", seen_sessions=[])
    plugin = LitestarAuth(_minimal_config(backends=cast("Any", [first_backend, second_backend])))
    session = object()

    rebound_backends = plugin._session_bound_backends(cast("Any", session))

    assert rebound_backends == [f"first-{id(session)}", f"second-{id(session)}"]
    assert first_backend.seen_sessions == [session]
    assert second_backend.seen_sessions == [session]


def test_session_bound_backends_rebinds_database_token_backends_in_order_and_preserves_names() -> None:
    """Canonical DB bearer backends keep public names/order while rebinding strategies per request."""
    first_backend = AuthenticationBackend[ExampleUser, UUID](
        name="primary",
        transport=BearerTransport(),
        strategy=cast(
            "Any",
            DatabaseTokenStrategy(
                session=cast("Any", object()),
                token_hash_secret="a" * 40,
                max_age=timedelta(minutes=10),
            ),
        ),
    )
    second_strategy = DatabaseTokenStrategy(
        session=cast("Any", object()),
        token_hash_secret="b" * 40,
        refresh_max_age=timedelta(days=14),
        accept_legacy_plaintext_tokens=True,
    )
    second_backend = AuthenticationBackend[ExampleUser, UUID](
        name="secondary",
        transport=BearerTransport(),
        strategy=cast("Any", second_strategy),
    )
    config = _minimal_config(backends=[first_backend, second_backend])
    config.allow_legacy_plaintext_tokens = True
    plugin = LitestarAuth(config)
    active_session = object()

    rebound_backends = plugin._session_bound_backends(cast("Any", active_session))

    assert [backend.name for backend in rebound_backends] == ["primary", "secondary"]
    assert rebound_backends[0] is not first_backend
    assert rebound_backends[1] is not second_backend
    assert rebound_backends[0].transport is first_backend.transport
    assert rebound_backends[1].transport is second_backend.transport
    assert isinstance(rebound_backends[0].strategy, DatabaseTokenStrategy)
    assert isinstance(rebound_backends[1].strategy, DatabaseTokenStrategy)
    assert rebound_backends[0].strategy.session is active_session
    assert rebound_backends[1].strategy.session is active_session
    assert rebound_backends[1].strategy.refresh_max_age == second_strategy.refresh_max_age
    assert rebound_backends[1].strategy.accept_legacy_plaintext_tokens is True


def test_session_bound_backends_realizes_database_token_preset_from_request_session() -> None:
    """The DB bearer preset resolves request-scoped backends without a startup session template."""
    config = LitestarAuthConfig[ExampleUser, UUID].with_database_token_auth(
        database_token_auth=plugin_module._plugin_config.DatabaseTokenAuthConfig(
            token_hash_secret="a" * 40,
            max_age=timedelta(minutes=10),
            refresh_max_age=timedelta(days=14),
            accept_legacy_plaintext_tokens=True,
        ),
        user_model=ExampleUser,
        user_manager_class=PluginUserManager,
        session_maker=cast("Any", DummySessionMaker()),
        user_db_factory=lambda _session: InMemoryUserDatabase([]),
        user_manager_kwargs={
            "verification_token_secret": "x" * 32,
            "reset_password_token_secret": "y" * 32,
        },
        enable_refresh=True,
    )
    config.allow_legacy_plaintext_tokens = True
    plugin = LitestarAuth(config)
    active_session = type("_ActiveSession", (), {"marker": "request-session"})()

    rebound_backends = plugin._session_bound_backends(cast("Any", active_session))
    template_backend = config.backends[0]
    template_strategy = cast("Any", template_backend.strategy)
    rebound_strategy = cast("Any", rebound_backends[0].strategy)

    assert [backend.name for backend in rebound_backends] == ["database"]
    assert rebound_backends[0] is not template_backend
    assert type(rebound_strategy) is type(template_strategy)
    assert rebound_strategy.session is active_session
    assert template_strategy.session.marker == "request-session"
    assert rebound_strategy.refresh_max_age == timedelta(days=14)
    assert rebound_strategy.accept_legacy_plaintext_tokens is True


def test_build_authenticator_uses_session_bound_backends_and_manager(monkeypatch: pytest.MonkeyPatch) -> None:
    """Authenticator construction reuses the session-bound backends and manager instance."""
    plugin = LitestarAuth(_minimal_config())
    session = object()
    expected_backends = ["backend"]
    manager = object()

    monkeypatch.setattr(
        plugin,
        "_session_bound_backends",
        lambda configured_session: expected_backends if configured_session is session else [],
    )
    monkeypatch.setattr(
        plugin,
        "_build_user_manager",
        lambda configured_session, *, backends=None: (
            manager if configured_session is session and backends == expected_backends else None
        ),
    )

    authenticator = plugin._build_authenticator(cast("Any", session))

    assert isinstance(authenticator, Authenticator)
    assert authenticator.backends is expected_backends
    assert authenticator.user_manager is manager


def test_register_middleware_without_cookie_transports_skips_csrf_registration() -> None:
    """Bearer-only setups still register middleware without creating CSRF config."""
    plugin = LitestarAuth(_minimal_config())
    app_config = AppConfig()

    plugin._register_middleware(app_config)

    assert app_config.csrf_config is None
    middleware = app_config.middleware[0]
    assert isinstance(middleware, DefineMiddleware)
    assert middleware.kwargs["auth_cookie_names"] == frozenset()


def test_resolve_account_state_validator_returns_manager_method() -> None:
    """The plugin exposes the configured manager-class account-state validator."""
    plugin = LitestarAuth(_minimal_config())

    validator = plugin._resolve_account_state_validator()

    assert validator is PluginUserManager.require_account_state


def test_resolve_account_state_validator_raises_for_missing_callable() -> None:
    """Manager classes without a callable validator fail with a contract error."""

    class _MissingValidatorManager(PluginUserManager):
        require_account_state = None

    plugin = LitestarAuth(_minimal_config())
    plugin.config.user_manager_class = _MissingValidatorManager

    with pytest.raises(TypeError, match="require_account_state"):
        plugin._resolve_account_state_validator()


def test_provider_helpers_return_configured_objects() -> None:
    """Provider helpers expose the config values used by dependency registration."""
    plugin = LitestarAuth(_minimal_config())

    assert plugin._provide_backends() is plugin.config.backends
    assert plugin._provide_config() is plugin.config
    assert plugin._provide_user_model() is plugin.config.user_model


@pytest.mark.asyncio
async def test_provide_user_manager_respects_custom_db_session_key() -> None:
    """Provider wrapper parameter names follow db_session_dependency_key."""
    config = _minimal_config()
    config.db_session_dependency_key = "custom_db"
    plugin = LitestarAuth(config)
    session = DummySession()

    gen = cast("Any", plugin._provide_user_manager(custom_db=session))
    try:
        manager = await anext(gen)
        assert manager is not None
    finally:
        await gen.aclose()


def test_provide_request_backends_respects_custom_db_session_key() -> None:
    """Backends DI resolves request-scoped backends through the configured session key."""

    @dataclass(slots=True)
    class _BackendRecorder:
        seen_sessions: list[object]

        def with_session(self, session: object) -> str:
            self.seen_sessions.append(session)
            return f"bound-{id(session)}"

    recorder = _BackendRecorder(seen_sessions=[])
    config = _minimal_config(backends=cast("Any", [recorder]))
    config.db_session_dependency_key = "custom_db"
    plugin = LitestarAuth(config)
    session = object()

    rebound_backends = cast("Any", plugin._provide_request_backends)(custom_db=session)

    assert rebound_backends == [f"bound-{id(session)}"]
    assert recorder.seen_sessions == [session]


def test_provide_request_backends_accepts_positional_session_argument() -> None:
    """Backends DI also supports the direct positional session-provider path."""

    @dataclass(slots=True)
    class _BackendRecorder:
        seen_sessions: list[object]

        def with_session(self, session: object) -> str:
            self.seen_sessions.append(session)
            return f"bound-{id(session)}"

    recorder = _BackendRecorder(seen_sessions=[])
    plugin = LitestarAuth(_minimal_config(backends=cast("Any", [recorder])))
    session = object()

    rebound_backends = cast("Any", plugin._provide_request_backends)(session)

    assert rebound_backends == [f"bound-{id(session)}"]
    assert recorder.seen_sessions == [session]


def test_provide_request_backends_rejects_positional_and_keyword_session() -> None:
    """Backends DI fails closed when both positional and keyword session inputs are provided."""
    plugin = LitestarAuth(_minimal_config())
    session = object()

    with pytest.raises(TypeError, match="got multiple values for argument 'db_session'"):
        cast("Any", plugin._provide_request_backends)(session, db_session=session)


def test_provide_request_backends_validates_dependency_inputs() -> None:
    """Backends DI rejects missing or unexpected dependency arguments before building backends."""
    plugin = LitestarAuth(_minimal_config())

    with pytest.raises(TypeError, match="missing 1 required argument: 'db_session'"):
        cast("Any", plugin._provide_request_backends)()

    with pytest.raises(TypeError, match=r"got unexpected keyword argument\(s\): 'other'"):
        cast("Any", plugin._provide_request_backends)(other=object())


def test_provide_request_backends_realizes_database_token_preset_from_request_session() -> None:
    """Preset backends DI returns a backend bound to the active request-local session."""
    config = LitestarAuthConfig[ExampleUser, UUID].with_database_token_auth(
        database_token_auth=plugin_module._plugin_config.DatabaseTokenAuthConfig(
            token_hash_secret="a" * 40,
            max_age=timedelta(minutes=10),
            refresh_max_age=timedelta(days=14),
            accept_legacy_plaintext_tokens=True,
        ),
        user_model=ExampleUser,
        user_manager_class=PluginUserManager,
        session_maker=cast("Any", DummySessionMaker()),
        user_db_factory=lambda _session: InMemoryUserDatabase([]),
        user_manager_kwargs={
            "verification_token_secret": "x" * 32,
            "reset_password_token_secret": "y" * 32,
        },
        enable_refresh=True,
    )
    config.allow_legacy_plaintext_tokens = True
    plugin = LitestarAuth(config)
    active_session = type("_ActiveSession", (), {"marker": "request-session"})()
    template_backend = config.backends[0]

    rebound_backends = cast("Any", plugin._provide_request_backends)(db_session=active_session)

    assert [backend.name for backend in rebound_backends] == ["database"]
    assert type(rebound_backends[0].strategy) is type(template_backend.strategy)
    assert rebound_backends[0].strategy.session is active_session


@pytest.mark.asyncio
async def test_provide_user_manager_yields_request_scoped_manager() -> None:
    """Provider wrappers yield one session-bound manager for each injected session."""
    plugin = LitestarAuth(_minimal_config())
    session = DummySession()

    gen = cast("Any", plugin._provide_user_manager(session))
    try:
        manager = await anext(gen)
        assert manager is not None
        assert isinstance(manager, PluginUserManager)
    finally:
        await gen.aclose()


@pytest.mark.asyncio
async def test_provide_oauth_associate_user_manager_yields_manager() -> None:
    """OAuth associate provider wrappers share the same request-scoped manager behavior."""
    plugin = LitestarAuth(_minimal_config())
    session = DummySession()

    gen = cast("Any", plugin._provide_oauth_associate_user_manager(session))
    try:
        manager = await anext(gen)
        assert manager is not None
    finally:
        await gen.aclose()


def test_totp_backend_returns_configured_named_backend() -> None:
    """The plugin exposes the same TOTP backend selected by the configured helper rules."""
    primary_backend = AuthenticationBackend[ExampleUser, UUID](
        name="primary",
        transport=BearerTransport(),
        strategy=cast("Any", InMemoryTokenStrategy(token_prefix="primary")),
    )
    secondary_backend = AuthenticationBackend[ExampleUser, UUID](
        name="secondary",
        transport=BearerTransport(),
        strategy=cast("Any", InMemoryTokenStrategy(token_prefix="secondary")),
    )
    plugin = LitestarAuth(
        _minimal_config(
            backends=[primary_backend, secondary_backend],
        ),
    )
    plugin.config.totp_config = TotpConfig(
        totp_pending_secret="p" * 32,
        totp_backend_name="secondary",
    )

    assert plugin._totp_backend() is secondary_backend


def test_public_aliases_reexport_nested_config_types() -> None:
    """Plugin module re-exports nested config dataclasses for public callers."""
    assert OAuthConfig.__name__ == "OAuthConfig"
    assert TotpConfig.__name__ == "TotpConfig"


def test_plugins_hold_distinct_oauth_encryption_keys() -> None:
    """Separate plugin instances keep independent OAuth encryption-key scopes."""
    key_provider = get_oauth_encryption_key_callable()
    first_config = _minimal_config()
    second_config = _minimal_config()
    first_config.oauth_config = OAuthConfig(oauth_token_encryption_key="a" * 44)
    second_config.oauth_config = OAuthConfig(oauth_token_encryption_key="b" * 44)

    first_plugin = LitestarAuth(first_config)
    second_plugin = LitestarAuth(second_config)

    with oauth_token_encryption_scope(first_plugin):
        assert key_provider() == "a" * 44

    with oauth_token_encryption_scope(second_plugin):
        assert key_provider() == "b" * 44
