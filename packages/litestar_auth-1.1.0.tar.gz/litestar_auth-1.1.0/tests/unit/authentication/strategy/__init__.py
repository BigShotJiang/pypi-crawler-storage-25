"""Strategy unit tests."""
