"""Authentication-related unit tests."""
