"""Declarative bot framework for Bulletins integrations."""

import asyncio
import logging
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from typing import Any

from bulletins.client import BulletinsClient
from bulletins.types import Event, _from_dict

log = logging.getLogger(__name__)

type EventHandler = Callable[[Event, BulletinsClient], Coroutine[Any, Any, None]]


@dataclass
class EventTypeSpec:
    """Declares a custom event type the bot will register on start."""

    name: str
    content_schema: dict = field(default_factory=dict)
    display_hint: dict | None = None


class Bot:
    """Declarative bot that auto-registers event types and dispatches SSE events.

    Usage::

        bot = Bot("YouTube DJ", event_types=[
            EventTypeSpec("bot:now_playing", {"title": {"type": "string"}}),
        ])

        @bot.on("message")
        async def handle(event: Event, client: BulletinsClient):
            if event.content.get("body", "").startswith("!ping"):
                await client.send_message(event.thread_id, "pong")

        await bot.start(api_key="bk_...", base_url="...")
    """

    def __init__(
        self,
        name: str,
        *,
        description: str | None = None,
        event_types: list[EventTypeSpec] | None = None,
    ):
        self.name = name
        self.description = description
        self.event_types = event_types or []
        self._handlers: dict[str, EventHandler] = {}
        self._client: BulletinsClient | None = None
        self._stop = asyncio.Event()

    def on(self, event_type: str) -> Callable[[EventHandler], EventHandler]:
        """Register a handler for an event type.

        The handler receives ``(event, client)`` and should be async.
        """

        def decorator(fn: EventHandler) -> EventHandler:
            self._handlers[event_type] = fn
            return fn

        return decorator

    @property
    def client(self) -> BulletinsClient:
        """The underlying client. Available after ``start()``."""
        if self._client is None:
            raise RuntimeError("Bot not started")
        return self._client

    async def start(
        self,
        *,
        api_key: str,
        base_url: str = "https://bulletins.no",
    ) -> None:
        """Connect, register event types, and start the dispatch loop.

        Only needs an API key — party and integration are resolved
        automatically via ``/api/auth/me``.

        Blocks until ``stop()`` is called or the process is interrupted.
        """
        self._stop.clear()
        self._client = BulletinsClient(api_key, base_url=base_url)

        try:
            await self._client.resolve()
            await self._sync_event_types()
            log.info(
                "Bot '%s' started — base=%s party=%s integration=%s",
                self.name,
                base_url,
                self._client.party_id,
                self._client.integration_name,
            )
            await self._dispatch_loop()
        finally:
            await self._client.close()
            self._client = None

    def stop(self) -> None:
        """Signal the dispatch loop to stop."""
        self._stop.set()
        log.info("Bot '%s' stopping", self.name)

    # ─── Auto-registration ───────────────────────────────────

    async def _sync_event_types(self) -> None:
        """Ensure all declared event types are registered."""
        if not self.event_types:
            return

        integration_id = self.client.integration_id
        detail = await self.client.get_integration_detail(integration_id)
        existing = {et["name"] for et in detail.get("eventTypes", [])}

        for spec in self.event_types:
            if spec.name in existing:
                log.debug("Event type '%s' already registered", spec.name)
                continue
            await self.client.create_event_type(
                integration_id,
                spec.name,
                spec.content_schema,
                display_hint=spec.display_hint,
            )
            log.info("Registered event type: %s", spec.name)

    # ─── SSE dispatch loop ───────────────────────────────────

    async def _dispatch_loop(self) -> None:
        """Listen to the party SSE stream and dispatch to handlers."""
        while not self._stop.is_set():
            try:
                log.info("SSE connecting...")
                async with self.client.stream_party() as stream:
                    async for raw in stream:
                        if self._stop.is_set():
                            break
                        await self._handle(raw)
                log.warning("SSE stream ended, reconnecting...")
            except Exception as e:
                if self._stop.is_set():
                    break
                log.error("SSE error: %s, reconnecting in 5s", e)
                await asyncio.sleep(5)

    async def _handle(self, raw: dict) -> None:
        """Dispatch a single event to the matching handler."""
        if not isinstance(raw, dict):
            return

        event_type = raw.get("type", "")
        handler = self._handlers.get(event_type)

        if handler is None:
            return

        try:
            event = _from_dict(Event, raw)
            await handler(event, self.client)
        except Exception:
            log.exception(
                "Handler error for %s in thread %s",
                event_type,
                raw.get("threadId", "?"),
            )
