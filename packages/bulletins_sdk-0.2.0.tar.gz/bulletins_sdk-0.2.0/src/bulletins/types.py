"""Response types for the Bulletins API."""

from dataclasses import dataclass


def _snake(name: str) -> str:
    """camelCase → snake_case."""
    out: list[str] = []
    for i, c in enumerate(name):
        if c.isupper() and i > 0:
            out.append("_")
        out.append(c.lower())
    return "".join(out)


def _convert(data: dict) -> dict:
    """Recursively convert camelCase keys to snake_case."""
    return {
        _snake(k): _convert(v) if isinstance(v, dict) else v for k, v in data.items()
    }


def _from_dict[T](cls: type[T], data: dict) -> T:
    """Construct a frozen dataclass from a camelCase API dict."""
    converted = _convert(data)
    # Only pass keys that the dataclass accepts
    fields = {f.name for f in cls.__dataclass_fields__.values()}
    return cls(**{k: v for k, v in converted.items() if k in fields})


# ─── Auth ────────────────────────────────────────────────────


@dataclass(frozen=True)
class User:
    id: str
    email: str
    name: str


@dataclass(frozen=True)
class Party:
    id: str
    name: str
    org_number: str | None = None


# ─── Threads ─────────────────────────────────────────────────


@dataclass(frozen=True)
class Thread:
    id: str
    name: str
    status: str
    created_at: str
    unread_count: int = 0
    active_call: bool = False
    branch_count: int = 0
    last_message: dict | None = None
    participants: list[dict] | None = None
    branches: list[dict] | None = None


@dataclass(frozen=True)
class Event:
    type: str
    thread_id: str = ""
    id: str = ""
    content: dict | None = None
    channel: str = ""
    created_at: str = ""
    sender_id: str | None = None
    sender_name: str | None = None
    party_id: str | None = None
    client: dict | None = None


@dataclass(frozen=True)
class EventPage:
    events: list[Event]
    has_more: bool


@dataclass(frozen=True)
class ThreadDetail:
    id: str
    name: str
    status: str
    active_call: bool
    created_at: str
    participants: list[dict]
    events: list[Event]
    parent_thread_id: str | None = None
    branches: list[dict] | None = None


# ─── Integrations ────────────────────────────────────────────


@dataclass(frozen=True)
class IntegrationInfo:
    id: str
    name: str
    created_at: str
    description: str | None = None
    avatar_url: str | None = None


@dataclass(frozen=True)
class ApiKeyCreated:
    id: str
    integration_id: str
    name: str
    scopes: list[str]
    key: str
    created_at: str


@dataclass(frozen=True)
class EventType:
    id: str
    integration_id: str
    name: str
    content_schema: dict
    created_at: str
    display_hint: dict | None = None
