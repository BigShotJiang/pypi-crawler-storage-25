"""Async HTTP client for the Bulletins API."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any, Self

import httpx

from bulletins.sse import sse_events
from bulletins.types import (
    ApiKeyCreated,
    Event,
    EventPage,
    EventType,
    IntegrationInfo,
    Thread,
    ThreadDetail,
    _from_dict,
)


class BulletinsError(Exception):
    """Non-2xx response from the Bulletins API."""

    def __init__(self, status_code: int, message: str, body: dict | None = None):
        self.status_code = status_code
        self.body = body
        super().__init__(f"HTTP {status_code}: {message}")


def _raise_for_status(response: httpx.Response) -> None:
    if response.is_success:
        return
    try:
        body = response.json()
        message = body.get("error", response.reason_phrase)
    except Exception:
        body = None
        message = response.reason_phrase or "Unknown error"
    raise BulletinsError(response.status_code, message, body)


class BulletinsClient:
    """Async client for the Bulletins REST + SSE API.

    Create an instance with an API key::

        client = BulletinsClient("bk_...", base_url="https://bulletins.no")

    Party and integration are resolved automatically from the key
    via ``/api/auth/me`` on first use, or call ``resolve()`` explicitly.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://bulletins.no",
    ):
        self._http = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "X-Api-Key": api_key,
                "Accept": "application/json",
            },
        )
        self._party_id: str | None = None
        self._integration_id: str | None = None
        self._integration_name: str | None = None
        self._scopes: list[str] | None = None
        self._resolved = False

    async def resolve(self) -> None:
        """Resolve identity from the API key via ``GET /api/auth/me``.

        Called automatically before the first API call. Sets party_id,
        integration_id, and scopes from the server.
        """
        if self._resolved:
            return
        data = await self._get("/api/auth/me")
        self._party_id = data["partyId"]
        self._integration_id = data["integrationId"]
        self._integration_name = data["integrationName"]
        self._scopes = data["scopes"]
        self._http.headers["X-Party-Id"] = self._party_id
        self._resolved = True

    @property
    def party_id(self) -> str | None:
        return self._party_id

    @property
    def integration_id(self) -> str | None:
        return self._integration_id

    @property
    def integration_name(self) -> str | None:
        return self._integration_name

    @property
    def scopes(self) -> list[str] | None:
        return self._scopes

    # ─── Lifecycle ───────────────────────────────────────────

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    # ─── Internal ────────────────────────────────────────────

    async def _get(self, path: str, **params: Any) -> Any:
        resp = await self._http.get(path, params=params or None)
        _raise_for_status(resp)
        return resp.json()

    async def _post(self, path: str, body: dict | None = None) -> Any:
        resp = await self._http.post(path, json=body)
        _raise_for_status(resp)
        return resp.json()

    async def _patch(self, path: str, body: dict) -> Any:
        resp = await self._http.patch(path, json=body)
        _raise_for_status(resp)
        return resp.json()

    async def _delete(self, path: str) -> None:
        resp = await self._http.delete(path)
        _raise_for_status(resp)

    # ─── Threads ─────────────────────────────────────────────

    async def list_threads(self) -> list[Thread]:
        data = await self._get("/api/threads")
        return [_from_dict(Thread, t) for t in data]

    async def get_thread(self, thread_id: str) -> ThreadDetail:
        data = await self._get(f"/api/threads/{thread_id}")
        events = [_from_dict(Event, e) for e in data.get("events", [])]
        detail = _from_dict(ThreadDetail, {**data, "events": []})
        # Replace with parsed events
        return ThreadDetail(
            id=detail.id,
            name=detail.name,
            status=detail.status,
            active_call=detail.active_call,
            created_at=detail.created_at,
            participants=detail.participants,
            events=events,
            parent_thread_id=detail.parent_thread_id,
            branches=detail.branches,
        )

    async def create_thread(
        self,
        name: str,
        *,
        to_party_id: str,
        body: str,
        formatted_body: str | None = None,
        channel: str = "api",
    ) -> str:
        """Create a thread with an initial message. Returns the thread ID."""
        content: dict[str, Any] = {"body": body}
        if formatted_body is not None:
            content["format"] = "html"
            content["formatted_body"] = formatted_body
        data = await self._post(
            "/api/threads",
            {
                "name": name,
                "toPartyId": to_party_id,
                "message": content,
                "channel": channel,
            },
        )
        return data["id"]

    # ─── Events ──────────────────────────────────────────────

    async def list_events(
        self,
        thread_id: str,
        *,
        before: str | None = None,
        limit: int = 100,
    ) -> EventPage:
        params: dict[str, Any] = {"limit": str(limit)}
        if before:
            params["before"] = before
        data = await self._get(f"/api/threads/{thread_id}/events", **params)
        events = [_from_dict(Event, e) for e in data["events"]]
        return EventPage(events=events, has_more=data["hasMore"])

    async def create_event(
        self,
        thread_id: str,
        type: str,
        content: dict,
    ) -> str:
        """Create an event in a thread. Returns the event ID."""
        data = await self._post(
            f"/api/threads/{thread_id}/events",
            {
                "type": type,
                "content": content,
            },
        )
        return data["id"]

    async def send_message(
        self,
        thread_id: str,
        body: str,
        *,
        formatted_body: str | None = None,
    ) -> str:
        """Send a text message to a thread. Returns the event ID."""
        content: dict[str, Any] = {"body": body}
        if formatted_body is not None:
            content["format"] = "html"
            content["formatted_body"] = formatted_body
        return await self.create_event(thread_id, "message", content)

    # ─── SSE Streams ─────────────────────────────────────────

    @asynccontextmanager
    async def stream_party(self) -> AsyncIterator[AsyncIterator[dict]]:
        """Open the party-wide SSE stream.

        Usage::

            async with client.stream_party() as stream:
                async for event in stream:
                    print(event)
        """
        async with self._http.stream(
            "GET",
            "/api/stream",
            headers={"Accept": "text/event-stream"},
            timeout=httpx.Timeout(connect=10, read=35, write=10, pool=10),
        ) as response:
            _raise_for_status(response)
            yield sse_events(response)

    @asynccontextmanager
    async def stream_thread(self, thread_id: str) -> AsyncIterator[AsyncIterator[dict]]:
        """Open an SSE stream for a specific thread."""
        async with self._http.stream(
            "GET",
            f"/api/threads/{thread_id}/stream",
            headers={"Accept": "text/event-stream"},
            timeout=httpx.Timeout(connect=10, read=35, write=10, pool=10),
        ) as response:
            _raise_for_status(response)
            yield sse_events(response)

    # ─── Integrations ────────────────────────────────────────

    async def list_integrations(self) -> list[IntegrationInfo]:
        data = await self._get("/api/party/integrations")
        return [_from_dict(IntegrationInfo, i) for i in data]

    async def get_integration_detail(self, integration_id: str) -> dict:
        """Get integration with all child resources (apiKeys, eventTypes, webhooks, actions)."""
        return await self._get(f"/api/party/integrations/{integration_id}/detail")

    async def create_event_type(
        self,
        integration_id: str,
        name: str,
        content_schema: dict,
        *,
        display_hint: dict | None = None,
    ) -> EventType:
        """Register a custom event type for an integration."""
        body: dict[str, Any] = {"name": name, "contentSchema": content_schema}
        if display_hint is not None:
            body["displayHint"] = display_hint
        data = await self._post(
            f"/api/party/integrations/{integration_id}/event-types", body
        )
        return _from_dict(EventType, data)

    async def create_action(
        self,
        integration_id: str,
        name: str,
        url_template: str,
        *,
        icon: str | None = None,
        method: str | None = None,
        requested_schema: dict | None = None,
        connection_provider: str | None = None,
    ) -> dict:
        """Create an action for an integration."""
        body: dict[str, Any] = {"name": name, "urlTemplate": url_template}
        if icon is not None:
            body["icon"] = icon
        if method is not None:
            body["method"] = method
        if requested_schema is not None:
            body["requestedSchema"] = requested_schema
        if connection_provider is not None:
            body["connectionProvider"] = connection_provider
        return await self._post(
            f"/api/party/integrations/{integration_id}/actions", body
        )

    async def create_webhook(
        self,
        integration_id: str,
        url: str,
        *,
        event_types: list[str] | None = None,
    ) -> dict:
        """Create a webhook for an integration."""
        body: dict[str, Any] = {"url": url}
        if event_types is not None:
            body["eventTypes"] = event_types
        return await self._post(
            f"/api/party/integrations/{integration_id}/webhooks", body
        )

    async def create_api_key(
        self,
        integration_id: str,
        name: str,
        *,
        scopes: list[str] | None = None,
    ) -> ApiKeyCreated:
        """Create an API key for an integration. The key is shown once."""
        body: dict[str, Any] = {"name": name}
        if scopes is not None:
            body["scopes"] = scopes
        data = await self._post(
            f"/api/party/integrations/{integration_id}/api-keys", body
        )
        return _from_dict(ApiKeyCreated, data)

    # ─── Calling ─────────────────────────────────────────────

    async def get_agent_token(self, thread_id: str) -> dict:
        """Get a LiveKit token for joining a call as an agent.

        Returns ``{"token": "...", "url": "..."}``
        """
        return await self._post(f"/api/threads/{thread_id}/agent-token")
