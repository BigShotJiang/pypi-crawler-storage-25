"""Bulletins Python SDK — async client, SSE streaming, and bot framework."""

from bulletins.bot import Bot, EventTypeSpec
from bulletins.client import BulletinsClient, BulletinsError
from bulletins.types import (
    ApiKeyCreated,
    Event,
    EventPage,
    EventType,
    IntegrationInfo,
    Party,
    Thread,
    ThreadDetail,
    User,
)

__all__ = [
    "Bot",
    "BulletinsClient",
    "BulletinsError",
    "EventTypeSpec",
    "IntegrationInfo",
    "ApiKeyCreated",
    "Event",
    "EventPage",
    "EventType",
    "Party",
    "Thread",
    "ThreadDetail",
    "User",
]
