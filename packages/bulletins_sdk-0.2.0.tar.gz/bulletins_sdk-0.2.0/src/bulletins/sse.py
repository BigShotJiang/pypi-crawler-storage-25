"""SSE parser for httpx async streaming responses."""

import json
from collections.abc import AsyncIterator

import httpx


async def sse_events(response: httpx.Response) -> AsyncIterator[dict]:
    """Yield parsed JSON from SSE ``data:`` lines.

    Skips SSE comments (``: ping``, ``: connected``) and non-data fields.
    Handles multi-line ``data:`` payloads by joining before parse.
    """
    data_buf: list[str] = []
    async for line in response.aiter_lines():
        if line.startswith("data:"):
            data_buf.append(line[5:].lstrip())
        elif line == "":
            if data_buf:
                payload = "\n".join(data_buf)
                data_buf = []
                try:
                    yield json.loads(payload)
                except json.JSONDecodeError:
                    pass
        # Comments (": ping", ": connected") and other fields silently skipped
    # Flush remaining buffer on stream end
    if data_buf:
        payload = "\n".join(data_buf)
        try:
            yield json.loads(payload)
        except json.JSONDecodeError:
            pass
