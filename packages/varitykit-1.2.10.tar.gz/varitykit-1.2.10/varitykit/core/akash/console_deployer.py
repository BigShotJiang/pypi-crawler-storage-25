"""
Akash Console API Client

Deploys applications to Akash Network using the Console Managed Wallet API.
No local CLI, wallet, or AKT tokens required.

API: https://console-api.akash.network/v1
Auth: x-api-key header
"""

from __future__ import annotations

import json
import os
import time
import urllib.request
import urllib.error
from typing import Any, Dict, Optional

from .types import AkashError


BASE_URL = "https://console-api.akash.network/v1"
BID_POLL_INTERVAL = 3  # seconds (per official docs)
BID_MAX_ATTEMPTS = 10


class AkashConsoleDeployer:
    """Akash Console Managed Wallet API client."""

    def __init__(self, api_key: Optional[str] = None):
        if api_key:
            self.api_key = api_key
        else:
            try:
                from varitykit.services.credential_fetcher import fetch_akash_credentials
                self.api_key = fetch_akash_credentials()
            except ImportError:
                self.api_key = os.getenv("AKASH_CONSOLE_API_KEY")

        if not self.api_key:
            raise AkashError(
                "Dynamic hosting credentials not found. "
                "Run 'varitykit login' to authenticate."
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def deploy(self, sdl: str, deposit: int = 5) -> Dict[str, Any]:
        """
        Create deployment, wait for bids, select cheapest, create lease.

        Returns dict with keys: dseq, provider, url
        """
        # 1. Create deployment
        resp = self._post("/deployments", {"data": {"sdl": sdl, "deposit": deposit}})
        data = resp.get("data", resp)
        dseq = data.get("dseq")
        manifest = data.get("manifest")
        if not dseq:
            raise AkashError(f"No deployment ID returned: {resp}")

        # 2. Wait for bids
        bids = self.wait_for_bids(dseq)
        if not bids:
            raise AkashError("No provider bids received")

        # 3. Select cheapest bid
        best = min(bids, key=lambda b: float(b["bid"]["price"].get("amount", "0")))

        # 4. Create lease
        lease_resp = self.create_lease(dseq, manifest, best)

        # 5. Wait for URL (provider needs time to start the container)
        url = self._extract_url(lease_resp)
        if not url:
            for _ in range(10):
                time.sleep(3)
                status_resp = self.get_status(str(dseq))
                url = self._extract_url(status_resp)
                if url:
                    break

        return {"dseq": str(dseq), "provider": best["bid"]["id"]["provider"], "url": url or ""}

    def wait_for_bids(self, dseq: str) -> list:
        """
        Poll GET /v1/bids?dseq=X until bids arrive.

        Returns list of raw bid objects from the API.
        """
        for _ in range(BID_MAX_ATTEMPTS):
            resp = self._get("/bids", params={"dseq": dseq})
            bids = resp.get("data", [])
            if bids:
                return bids
            time.sleep(BID_POLL_INTERVAL)
        return []

    def create_lease(self, dseq: str, manifest: str, provider_bid: dict) -> Dict[str, Any]:
        """
        Accept a bid and create a lease.

        Args:
            dseq: Deployment sequence number
            manifest: Manifest string from deployment creation
            provider_bid: Raw bid object from wait_for_bids
        """
        bid_id = provider_bid.get("bid", {}).get("id", {})
        return self._post("/leases", {
            "manifest": manifest,
            "leases": [{
                "dseq": dseq,
                "gseq": bid_id.get("gseq", 1),
                "oseq": bid_id.get("oseq", 1),
                "provider": bid_id.get("provider", ""),
            }],
        })

    def get_status(self, dseq: str) -> Dict[str, Any]:
        """GET /v1/deployments/{dseq}"""
        return self._get(f"/deployments/{dseq}")

    def close(self, dseq: str) -> None:
        """DELETE /v1/deployments/{dseq}"""
        self._request("DELETE", f"/deployments/{dseq}")

    # ------------------------------------------------------------------
    # HTTP helpers (stdlib only)
    # ------------------------------------------------------------------

    def _get(self, path: str, params: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        if params:
            qs = "&".join(f"{k}={v}" for k, v in params.items())
            path = f"{path}?{qs}"
        return self._request("GET", path)

    def _post(self, path: str, body: dict) -> Dict[str, Any]:
        return self._request("POST", path, body)

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> Dict[str, Any]:
        url = f"{BASE_URL}{path}"
        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(
            url,
            data=data,
            method=method,
            headers={
                "Content-Type": "application/json",
                "x-api-key": self.api_key or "",
                "User-Agent": "Varity/1.0",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                raw = resp.read().decode()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = json.loads(e.read().decode()).get("message", str(e))
            except Exception:
                detail = str(e)
            raise AkashError(f"API error ({e.code}): {detail}")
        except urllib.error.URLError as e:
            raise AkashError(f"Request failed: {e.reason}")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_url(response: Dict[str, Any]) -> Optional[str]:
        """
        Extract URL from response.data.leases[0].status.services[NAME].uris[0]
        """
        data = response.get("data", response)

        # Try leases path first
        leases = data.get("leases", [])
        if leases:
            services = leases[0].get("status", {}).get("services", {})
            for svc in services.values():
                uris = svc.get("uris", [])
                if uris:
                    return uris[0]

        # Fallback: top-level services
        services = data.get("services", {})
        if isinstance(services, dict):
            for svc in services.values():
                if isinstance(svc, dict):
                    uris = svc.get("uris", [])
                    if uris:
                        return uris[0]

        return None
