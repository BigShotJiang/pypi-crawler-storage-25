"""Akash deployment types."""

from dataclasses import dataclass


class AkashError(Exception):
    """Akash deployment error."""
    pass


@dataclass
class AkashDeploymentResult:
    """Result from an Akash deployment."""
    success: bool
    dseq: str = ""
    url: str = ""
    provider: str = ""
    estimated_monthly_cost: float = 0.0
    error_message: str = ""
