"""
Akash Network Deployment — Console Managed Wallet API

Deploys apps to Akash via REST API. No Docker, no wallet, no AKT tokens.
Docs: https://akash.network/docs/api-documentation/console-api/
"""

from .console_deployer import AkashConsoleDeployer
from .types import AkashDeploymentResult, AkashError

__all__ = [
    "AkashConsoleDeployer",
    "AkashDeploymentResult",
    "AkashError",
]
