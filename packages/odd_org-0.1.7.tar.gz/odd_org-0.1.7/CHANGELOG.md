# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.7] - 2026-04-04

### Changed
- `SprintEngine` split into three files: `engine.py` (orchestrator, 524 LOC),
  `context.py` (project context / agent resolution, 195 LOC), and
  `execution.py` (QA / phase / task execution, 448 LOC)
- Removed ~70 lines of delegation shims from `SprintEngine` — CLI and tests
  now call collaborator objects directly (`se.planner.plan_sprint()`,
  `se.wrapup.demo()`, `se.tdd.should_surface_escalation()`, etc.)
- Cleaned up dead imports (`_tprint`, `VacationPausedError`) and stale
  `# noqa: F401` from `engine.py`; trimmed `__init__.py` re-exports to
  only `SprintEngine` and `TDDGate`
- Architectural test enforces no source file exceeds 1000 lines
- Cancel signal now checks between each tool in a multi-tool batch, not just
  between iterations — CEO kill response time drops from "after all tools finish"
  to "after the current tool finishes"
- `run_command` uses `Popen` with 2-second polling instead of blocking
  `subprocess.run` — subprocesses are killed immediately on War Room cancel
- `_CancelledDuringTool` exception propagates from tool layer to
  `AgentKilledError` for clean shutdown logging

### Fixed
- `load_pricing()` and `refresh_pricing()` shallow-copied `_DEFAULT_PRICING`,
  so mutating the returned dict's inner values corrupted module-level defaults —
  now deep-copies inner dicts
- `ensure_patterns` gitignore dedup was one-directional — incoming patterns
  with leading `/` were not normalized, causing duplicates

### Added
- Architectural invariant test suite (`test_architectural_invariants.py`) — 38
  tests enforcing structural rules: SDK import containment, conversation history
  immutability, tool result type safety, wire format containment, DirectRunner
  freshness, config immutability, concurrent engine isolation, and TDD phase
  ordering
- Pricing cache staleness warning — `load_pricing()` warns when the cached
  pricing file is older than 30 days and suggests `odd refresh-pricing`
- Date-stamped hardcoded fallback pricing with last-verified comment

## [0.1.6] - 2026-04-04

### Added
- Ecosystem-aware `.gitignore` seeding during `odd init` — detects Python/JS
  markers and adds appropriate patterns (`.venv/`, `node_modules/`, etc.)
- Auto-update `.gitignore` when CEO approves dependency installs — ensures
  ecosystem artifact dirs (e.g. `node_modules/` for npm) are ignored before
  they can be committed
- `SharedRateLimiter` for coordinating concurrent API calls across parallel agents
  (semaphore-based concurrency cap + shared backoff on 429 responses)
- Task-level checkpointing within sprint phases — saves after each completed task,
  skips already-completed tasks on resume
- `TaskResult` model for preserving per-task completion state across crashes
- Warning logs when pricing scraping fails and when parser fallback paths activate
- Configurable model tier-to-ID mapping via `.odd/config.json` (`provider.model_map`)

### Fixed
- UnicodeDecodeError on Windows when subprocess output contains UTF-8 (e.g. JS test
  runner output with checkmarks/emojis) — all `subprocess.run` calls now use
  `encoding="utf-8"` with `errors="replace"` instead of defaulting to cp1252

### Changed
- Decomposed 5 large files into focused subpackages:
  - `git.py` (769 lines) → `git/` subpackage (manager, worktrees, diff)
  - `tools/execution.py` (720 lines) → execution + file_ops + git_checks
  - `sprint/tdd_gate.py` (836 lines) → `tdd/` top-level subpackage (testing as
    a cross-cutting capability, not sprint-owned)
  - `sprint/wrapup.py` (1005 lines) → `sprint/wrapup/` subpackage (core,
    demo/retro, hiring, test review)
  - `sprint/engine.py` (1080 lines) → engine + callbacks + standup
- Moved `_console.py` to top-level `odd._console` to break circular import
  between `tdd/` and `sprint/` packages
- Thread-safe `save_sprint`/`load_sprint` and `save_config`/`load_config` in
  `StateManager` (targeted locks for operations called from worktree threads)

### Security
- Block `find -exec` and `find -execdir` flags (arbitrary command execution vector)
- Restrict `cp` and `mv` to stay within the project root directory
- Block shell metacharacters (`>`, `|`, `&`) on Windows where `shell=True`
  allows cmd.exe interpretation

### Fixed
- Replaced last bare `except: pass` in `git.py` with `logger.debug()`;
  re-enabled Bandit B110 rule

## [0.1.5] - 2026-04-03

### Fixed
- Bandit security scan failures

## [0.1.4] - 2026-04-03

### Fixed
- Windows shell compatibility (`shlex` backslash handling, `posix=False`)
- Smarter test detection and better error escalation in sprints

## [0.1.3] - 2026-04-03

### Changed
- Sprint lifecycle improvements
- Updated Anthropic SDK dependency

## [0.1.2] - 2026-04-03

### Fixed
- CI failures: git config, value parsing, war room callbacks
- Updated Pygments dependency

## [0.1.1] - 2026-04-02

### Changed
- Moved worktree location to be within the project (`.odd/worktrees/`)

## [0.1.0] - 2026-04-01

### Added
- Initial release
- CLI commands: `odd init`, `odd sprint`, `odd standup`, `odd team`, `odd hire`, `odd status`
- Agent architecture with strict persona isolation
- Anthropic provider (default) with Provider protocol for extensibility
- TDD quality gate: QA writes tests first, agents implement to pass
- Sprint lifecycle engine with scope-boxed sprints
- CFO (deterministic cost tracking with phase-based budget envelopes)
- Git integration with worktree-based parallelism
- War room display for real-time agent monitoring
- Security: symlink-aware path validation, API key scrubbing, git command hardening,
  homoglyph attack prevention for consultant names

[Unreleased]: https://github.com/ThePoetCoder/ODD/compare/v0.1.7...HEAD
[0.1.7]: https://github.com/ThePoetCoder/ODD/compare/v0.1.7...v0.1.7
[0.1.6]: https://github.com/ThePoetCoder/ODD/compare/v0.1.6...v0.1.6
[0.1.5]: https://github.com/ThePoetCoder/ODD/compare/v0.1.4...v0.1.5
[0.1.4]: https://github.com/ThePoetCoder/ODD/compare/v0.1.3...v0.1.4
[0.1.3]: https://github.com/ThePoetCoder/ODD/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/ThePoetCoder/ODD/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/ThePoetCoder/ODD/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/ThePoetCoder/ODD/releases/tag/v0.1.0
