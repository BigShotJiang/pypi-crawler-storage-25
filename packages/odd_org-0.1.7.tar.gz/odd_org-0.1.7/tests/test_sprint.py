"""Tests for odd.sprint - task parsing, agent resolution, project context, and full lifecycle."""

from unittest.mock import MagicMock, patch

import pytest

from odd.models import (
    CEOGate,
    CEOStyle,
    ModelTier,
    Persona,
    ProjectConfig,
    RoleType,
    Sprint,
    SprintStatus,
    SprintTask,
)
from odd.parsers import parse_hire_suggestions, parse_tasks
from odd.sprint import SprintEngine, TDDGate
from odd.state import StateManager


@pytest.fixture
def state(tmp_path):
    s = StateManager(tmp_path)
    config = ProjectConfig(name="TestProject", description="Testing")
    s.init(config)
    return s


@pytest.fixture
def team():
    return {
        "lead_dev": Persona(role_type=RoleType.LEAD_DEV, name="Lead Developer", title="Lead Dev"),
        "qa": Persona(role_type=RoleType.QA, name="Glitch Hunter", title="QA"),
        "recruiter": Persona(role_type=RoleType.RECRUITER, name="Recruiter", title="Recruiter"),
        "secretary": Persona(role_type=RoleType.SECRETARY, name="Secretary", title="Secretary"),
    }


@pytest.fixture
def mock_engine():
    engine = MagicMock()
    engine.invoke.return_value = "Mock response"
    engine.get_escalations.return_value = []
    engine.pop_submissions.return_value = []
    # Real submissions list + pop_submissions so tests can populate it
    engine.submissions = []

    def _pop_submissions(tool_name):
        matched = [s for s in engine.submissions if s["tool"] == tool_name]
        engine.submissions = [s for s in engine.submissions if s["tool"] != tool_name]
        return matched

    engine.pop_submissions = _pop_submissions
    # fork() returns the same mock so all invoke calls are tracked together
    engine.fork.return_value = engine
    return engine


# ---------------------------------------------------------------------------
# _parse_tasks
# ---------------------------------------------------------------------------

class TestParseTasks:
    def test_parses_structured_plan(self):
        plan = (
            "Here's the plan:\n\n"
            "TASK: Build authentication module\n"
            "ASSIGN: Lead Developer\n\n"
            "TASK: Write auth tests\n"
            "ASSIGN: QA\n\n"
            "TASK: Set up CI pipeline\n"
            "ASSIGN: DevOps Consultant\n"
        )
        tasks = parse_tasks(plan, sprint_number=1)
        assert len(tasks) == 3
        assert tasks[0].description == "Build authentication module"
        assert tasks[0].assigned_to == "Lead Developer"
        assert tasks[0].id == "s1_t1"
        assert tasks[1].assigned_to == "QA"
        assert tasks[2].id == "s1_t3"

    def test_fallback_on_unstructured_plan(self):
        plan = "Just do everything, it'll be fine. Trust me."
        tasks = parse_tasks(plan, sprint_number=2)
        assert len(tasks) == 1
        assert tasks[0].assigned_to == "Lead Developer"
        assert tasks[0].id == "s2_t1"

    def test_handles_mixed_case(self):
        plan = "task: Do the thing\nassign: Someone\n"
        tasks = parse_tasks(plan, sprint_number=1)
        assert len(tasks) == 1

    def test_ignores_assign_without_task(self):
        plan = "ASSIGN: Nobody\nTASK: Real task\nASSIGN: Lead Dev\n"
        tasks = parse_tasks(plan, sprint_number=1)
        assert len(tasks) == 1
        assert tasks[0].description == "Real task"

    def test_sprint_number_in_task_ids(self):
        plan = "TASK: A\nASSIGN: X\nTASK: B\nASSIGN: Y\n"
        tasks = parse_tasks(plan, sprint_number=7)
        assert all(t.id.startswith("s7_") for t in tasks)

    def test_empty_plan(self):
        tasks = parse_tasks("", sprint_number=1)
        assert len(tasks) == 1  # Fallback single task

    def test_task_with_extra_whitespace(self):
        plan = "TASK:   Build the feature   \nASSIGN:   Lead Dev   \n"
        tasks = parse_tasks(plan, sprint_number=1)
        assert tasks[0].description == "Build the feature"
        assert tasks[0].assigned_to == "Lead Dev"

    def test_many_tasks(self):
        plan = ""
        for i in range(10):
            plan += f"TASK: Task {i}\nASSIGN: Agent {i}\n"
        tasks = parse_tasks(plan, sprint_number=1)
        assert len(tasks) == 10
        assert tasks[9].id == "s1_t10"


# ---------------------------------------------------------------------------
# _resolve_agent
# ---------------------------------------------------------------------------

class TestResolveAgent:
    def _engine(self, state):
        return SprintEngine(engine=None, state=state)

    def test_resolve_by_key(self, state, team):
        se = self._engine(state)
        agent = se.context.resolve_agent("lead_dev", team)
        assert agent is not None
        assert agent.name == "Lead Developer"

    def test_resolve_by_name(self, state, team):
        se = self._engine(state)
        agent = se.context.resolve_agent("Lead Developer", team)
        assert agent is not None
        assert agent.role_type == RoleType.LEAD_DEV

    def test_resolve_qa(self, state, team):
        se = self._engine(state)
        agent = se.context.resolve_agent("Glitch Hunter", team)
        assert agent is not None
        assert agent.role_type == RoleType.QA

    def test_resolve_partial_match(self, state, team):
        se = self._engine(state)
        # "qa" is in the team dict keys
        agent = se.context.resolve_agent("qa engineer", team)
        assert agent is not None

    def test_resolve_consultant(self, state, team):
        se = self._engine(state)
        # Add a consultant to state
        consultant = Persona(
            role_type=RoleType.CONSULTANT,
            name="Alice Security",
            title="Security Expert",
        )
        state.save_persona(consultant)

        agent = se.context.resolve_agent("Alice Security", team)
        assert agent is not None
        assert agent.name == "Alice Security"

    def test_resolve_unknown_returns_none(self, state, team):
        se = self._engine(state)
        agent = se.context.resolve_agent("Nonexistent Person", team)
        assert agent is None

    def test_resolve_case_insensitive(self, state, team):
        se = self._engine(state)
        agent = se.context.resolve_agent("LEAD_DEV", team)
        assert agent is not None


# ---------------------------------------------------------------------------
# _build_project_context
# ---------------------------------------------------------------------------

class TestBuildProjectContext:
    def test_includes_project_name(self, state, team):
        se = SprintEngine(engine=None, state=state)
        ctx = se.context.build_project_context(1)
        assert "TestProject" in ctx

    def test_includes_sprint_number(self, state, team):
        se = SprintEngine(engine=None, state=state)
        ctx = se.context.build_project_context(3)
        assert "3" in ctx

    def test_includes_consultants(self, state, team):
        se = SprintEngine(engine=None, state=state)
        consultant = Persona(
            role_type=RoleType.CONSULTANT,
            name="Bob Expert",
            title="Database Wizard",
        )
        state.save_persona(consultant)
        ctx = se.context.build_project_context(1)
        assert "Bob Expert" in ctx

    def test_includes_backlog_summary(self, state, team):
        from odd.backlog import Backlog, Priority
        se = SprintEngine(engine=None, state=state)
        backlog = Backlog(state.odd_dir)
        backlog.add("Important feature", priority=Priority.HIGH)
        ctx = se.context.build_project_context(1)
        assert "Important feature" in ctx

    def test_includes_description(self, state):
        se = SprintEngine(engine=None, state=state)
        ctx = se.context.build_project_context(1)
        assert "Testing" in ctx


# ---------------------------------------------------------------------------
# plan_sprint - mocked API
# ---------------------------------------------------------------------------

class TestPlanSprint:
    def test_creates_sprint_with_tasks(self, mock_engine, state, team):
        mock_engine.invoke.return_value = (
            "TASK: Build login page\n"
            "ASSIGN: Lead Developer\n\n"
            "TASK: Write login tests\n"
            "ASSIGN: QA\n"
        )
        se = SprintEngine(mock_engine, state)
        sprint = se.planner.plan_sprint(
            lead_dev=team["lead_dev"],
            qa=team["qa"],
            ceo_input="Build user authentication",
            sprint_number=1,
        )

        assert sprint.number == 1
        assert sprint.goal == "Build user authentication"
        assert sprint.status == SprintStatus.PLANNING
        assert len(sprint.tasks) == 2
        assert sprint.tasks[0].description == "Build login page"

    def test_plan_sprint_does_not_save_until_caller_does(self, mock_engine, state, team):
        mock_engine.invoke.return_value = "TASK: Do it\nASSIGN: Lead Dev\n"
        se = SprintEngine(mock_engine, state)
        sprint = se.planner.plan_sprint(team["lead_dev"], team["qa"], "Goal", 1)

        # plan_sprint no longer saves - caller saves after CEO approval
        import pytest
        with pytest.raises(FileNotFoundError):
            state.load_sprint(1)

        # But once saved explicitly, it's loadable
        state.save_sprint(sprint)
        loaded = state.load_sprint(1)
        assert loaded.goal == "Goal"

    def test_invokes_lead_dev_not_qa(self, mock_engine, state, team):
        mock_engine.invoke.return_value = "TASK: X\nASSIGN: Y\n"
        se = SprintEngine(mock_engine, state)
        se.planner.plan_sprint(team["lead_dev"], team["qa"], "Goal", 1)

        # Only lead dev should be invoked for planning
        assert mock_engine.invoke.call_count == 1
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["persona"].role_type == RoleType.LEAD_DEV
        assert call_kwargs["tools"] is False

    def test_ceo_input_in_prompt(self, mock_engine, state, team):
        mock_engine.invoke.return_value = "TASK: X\nASSIGN: Y\n"
        se = SprintEngine(mock_engine, state)
        se.planner.plan_sprint(team["lead_dev"], team["qa"], "Build a REST API", 1)

        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert "Build a REST API" in call_kwargs["user_message"]

    def test_unstructured_plan_fallback(self, mock_engine, state, team):
        mock_engine.invoke.return_value = "I'll just figure it out as I go."
        se = SprintEngine(mock_engine, state)
        sprint = se.planner.plan_sprint(team["lead_dev"], team["qa"], "Vague goal", 1)

        assert len(sprint.tasks) == 1
        assert sprint.tasks[0].assigned_to == "Lead Developer"


# ---------------------------------------------------------------------------
# run_sprint - mocked API
# ---------------------------------------------------------------------------

class TestRunSprint:
    @pytest.fixture(autouse=True)
    def _bypass_tdd_gate(self, monkeypatch):
        """Bypass the mechanical TDD gate so existing tests don't need real pytest."""
        monkeypatch.setattr(TDDGate, "run_tests", lambda self, cwd=None: (True, "all passed"))
        monkeypatch.setattr(TDDGate, "discover_test_files", lambda self, cwd=None: [])

    @pytest.fixture(autouse=True)
    def _mock_git_available(self, monkeypatch):
        """Mark git as available so parallel phase execution doesn't bail out."""
        from odd.git import GitManager
        monkeypatch.setattr(GitManager, "available", property(lambda self: True))
        monkeypatch.setattr(GitManager, "create_task_worktree", lambda self, sprint, task_id: None)
        monkeypatch.setattr(GitManager, "commit_task_worktree", lambda self, task_id, msg: None)
        monkeypatch.setattr(GitManager, "merge_task_branches", lambda self, sprint, task_ids: [])
        monkeypatch.setattr(GitManager, "cleanup_task_branches", lambda self, sprint, task_ids: None)

    def _make_sprint(self, tasks=None):
        if tasks is None:
            tasks = [
                SprintTask(id="s1_t1", description="Build feature", assigned_to="Lead Developer"),
                SprintTask(id="s1_t2", description="Write tests", assigned_to="QA"),
            ]
        return Sprint(number=1, goal="Ship it", tasks=tasks, status=SprintStatus.PLANNING)

    def test_sets_status_to_in_progress_then_review(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        result = se.run_sprint(sprint, team)

        assert result.status == SprintStatus.REVIEW

    def test_qa_writes_tests_first(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        se.run_sprint(sprint, team)

        # First invoke should be QA writing tests
        first_call = mock_engine.invoke.call_args_list[0]
        assert first_call.kwargs["persona"].role_type == RoleType.QA
        assert "test" in first_call.kwargs["user_message"].lower()

    def test_each_task_assigned_to_correct_agent(self, mock_engine, state, team):
        tasks = [
            SprintTask(id="s1_t1", description="Code it", assigned_to="Lead Developer"),
        ]
        sprint = self._make_sprint(tasks)
        se = SprintEngine(mock_engine, state)

        se.run_sprint(sprint, team)

        # Second call (after QA) should be lead dev
        impl_call = mock_engine.invoke.call_args_list[1]
        assert impl_call.kwargs["persona"].name == "Lead Developer"

    def test_unresolved_agent_falls_back_to_lead_dev(self, mock_engine, state, team):
        tasks = [
            SprintTask(id="s1_t1", description="Mystery task", assigned_to="Unknown Person"),
        ]
        sprint = self._make_sprint(tasks)
        se = SprintEngine(mock_engine, state)

        se.run_sprint(sprint, team)

        # Implementation call should fall back to lead dev
        impl_call = mock_engine.invoke.call_args_list[1]
        assert impl_call.kwargs["persona"].name == "Lead Developer"

    def test_tasks_marked_done(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        result = se.run_sprint(sprint, team)

        for task in result.tasks:
            assert task.status == "done"

    def test_sprint_saved_after_completion(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        se.run_sprint(sprint, team)

        loaded = state.load_sprint(1)
        assert loaded.status == SprintStatus.REVIEW

    def test_blocker_escalation_prompts_ceo(self, mock_engine, state, team):
        tasks = [SprintTask(id="s1_t1", description="Task", assigned_to="Lead Developer")]
        sprint = self._make_sprint(tasks)
        se = SprintEngine(mock_engine, state)

        escalation = [{"severity": "blocker", "reason": "Can't access database"}]
        mock_engine.get_escalations.return_value = escalation

        with patch("odd.sprint.Prompt.ask", return_value="Use SQLite instead"):
            se.run_sprint(sprint, team)

        # Extra invoke for CEO's blocker response
        # QA test writing + task impl + blocker follow-up = 3
        assert mock_engine.invoke.call_count == 3

    def test_needs_decision_escalation_skip(self, mock_engine, state, team):
        tasks = [SprintTask(id="s1_t1", description="Task", assigned_to="Lead Developer")]
        sprint = self._make_sprint(tasks)
        se = SprintEngine(mock_engine, state)

        escalation = [{"severity": "needs_decision", "reason": "REST or GraphQL?"}]
        mock_engine.get_escalations.return_value = escalation

        with patch("odd.sprint.Prompt.ask", return_value="skip"):
            se.run_sprint(sprint, team)

        # CEO skipped - no extra invoke
        # QA test writing + task impl = 2
        assert mock_engine.invoke.call_count == 2

    def test_needs_decision_escalation_with_response(self, mock_engine, state, team):
        tasks = [SprintTask(id="s1_t1", description="Task", assigned_to="Lead Developer")]
        sprint = self._make_sprint(tasks)
        se = SprintEngine(mock_engine, state)

        escalation = [{"severity": "needs_decision", "reason": "REST or GraphQL?"}]
        mock_engine.get_escalations.return_value = escalation

        with patch("odd.sprint.Prompt.ask", return_value="Use REST"):
            se.run_sprint(sprint, team)

        # Extra invoke for CEO's decision response
        assert mock_engine.invoke.call_count == 3

    def test_heads_up_escalation_no_prompt(self, mock_engine, state, team):
        tasks = [SprintTask(id="s1_t1", description="Task", assigned_to="Lead Developer")]
        sprint = self._make_sprint(tasks)
        se = SprintEngine(mock_engine, state)

        escalation = [{"severity": "heads_up", "reason": "FYI: tests are slow"}]
        mock_engine.get_escalations.return_value = escalation

        se.run_sprint(sprint, team)

        # No extra invoke for heads_up
        assert mock_engine.invoke.call_count == 2

    def test_empty_sprint_no_tasks(self, mock_engine, state, team):
        sprint = self._make_sprint(tasks=[])
        se = SprintEngine(mock_engine, state)

        result = se.run_sprint(sprint, team)

        assert result.status == SprintStatus.REVIEW
        # Only QA writing tests, no implementation tasks
        assert mock_engine.invoke.call_count == 1


# ---------------------------------------------------------------------------
# TDD gate - mechanical test verification
# ---------------------------------------------------------------------------

class TestTDDGate:
    def _make_sprint(self, tasks=None):
        if tasks is None:
            tasks = [
                SprintTask(id="s1_t1", description="Build feature", assigned_to="Lead Developer"),
            ]
        return Sprint(number=1, goal="Ship it", tasks=tasks, status=SprintStatus.PLANNING)

    def test_task_done_when_tests_pass(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        with patch.object(se.tdd, "run_tests", return_value=(True, "all passed")), \
             patch.object(se.tdd, "discover_test_files", return_value=["tests/test_foo.py"]), \
             patch.object(se.tdd, "collect_test_names", return_value=[]):
            result = se.run_sprint(sprint, team)

        assert result.tasks[0].status == "done"

    def test_task_failed_when_tests_never_pass(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        # Always fails - baseline + impl + retries; CEO prompted at threshold
        with patch.object(se.tdd, "run_tests", return_value=(False, "FAILED test_foo")), \
             patch.object(se.tdd, "discover_test_files", return_value=["tests/test_foo.py"]), \
             patch.object(se.tdd, "collect_test_names", return_value=[]), \
             patch("odd.sprint.Prompt.ask", return_value="fail"):
            result = se.run_sprint(sprint, team)

        assert result.tasks[0].status == "failed"

    def test_retries_on_failure_then_passes(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        # baseline (after QA) + first post-impl (fail) + retry post-impl (pass) + phase briefing
        results = iter([
            (False, "baseline failures"),   # after QA - expected
            (False, "FAILED test_foo"),      # after first implementation
            (True, "all passed"),            # after retry
            (True, "all passed"),            # phase transition briefing
        ])

        with patch.object(se.tdd, "run_tests", side_effect=lambda cwd=None: next(results)), \
             patch.object(se.tdd, "discover_test_files", return_value=["tests/test_foo.py"]), \
             patch.object(se.tdd, "collect_test_names", return_value=[]):
            result = se.run_sprint(sprint, team)

        assert result.tasks[0].status == "done"
        # QA + implementation + 1 retry = 3 invocations
        assert mock_engine.invoke.call_count == 3

    def test_retry_prompt_includes_test_output(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        results = iter([
            (True, "baseline ok"),                                # after QA
            (False, "AssertionError: expected 42 got 0"),         # after impl
            (True, "passed"),                                     # after retry
            (True, "passed"),                                     # phase transition briefing
        ])

        with patch.object(se.tdd, "run_tests", side_effect=lambda cwd=None: next(results)), \
             patch.object(se.tdd, "discover_test_files", return_value=[]), \
             patch.object(se.tdd, "collect_test_names", return_value=[]):
            se.run_sprint(sprint, team)

        # The retry invoke should contain the failure output
        retry_call = mock_engine.invoke.call_args_list[2]
        assert "AssertionError" in retry_call.kwargs["user_message"]
        assert "Do NOT modify the test files" in retry_call.kwargs["user_message"]

    def test_test_context_injected_into_impl_prompt(self, mock_engine, state, team):
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        # _run_tests called for baseline + post-impl + phase briefing
        with patch.object(se.tdd, "run_tests", return_value=(True, "1 passed")), \
             patch.object(se.tdd, "discover_test_files", return_value=["tests/test_auth.py"]), \
             patch.object(se.tdd, "collect_test_names", return_value=["tests/test_auth.py::test_login"]):
            se.run_sprint(sprint, team)

        # Implementation prompt should include the test file info
        impl_call = mock_engine.invoke.call_args_list[1]
        assert "test_auth.py" in impl_call.kwargs["user_message"]


# ---------------------------------------------------------------------------
# run_standup - mocked API
# ---------------------------------------------------------------------------

class TestRunStandup:
    """Tests for the mechanical status dashboard (no LLM calls)."""

    def test_no_llm_calls(self, mock_engine, state, team):
        """Mechanical standup should not invoke any agents."""
        sprint = Sprint(number=1, goal="Goal", tasks=[], status=SprintStatus.IN_PROGRESS)
        se = SprintEngine(mock_engine, state)

        with patch.object(se.tdd, "run_tests", return_value=(True, "1 passed")):
            se.run_standup(sprint)

        assert mock_engine.invoke.call_count == 0

    def test_returns_status_summary(self, mock_engine, state, team):
        tasks = [
            SprintTask(id="s1_t1", description="Build auth", assigned_to="Cody", status="done"),
            SprintTask(id="s1_t2", description="Build API", assigned_to="Cody", status="failed"),
            SprintTask(id="s1_t3", description="Build UI", assigned_to="Cody", status="pending"),
        ]
        sprint = Sprint(number=1, goal="Ship it", tasks=tasks, status=SprintStatus.IN_PROGRESS)
        se = SprintEngine(mock_engine, state)

        with patch.object(se.tdd, "run_tests", return_value=(True, "3 passed")):
            summary = se.run_standup(sprint)

        assert "Sprint 1 Status" in summary
        assert "1 done" in summary
        assert "1 failed" in summary
        assert "1 remaining" in summary

    def test_includes_test_results(self, mock_engine, state, team):
        sprint = Sprint(number=1, goal="Goal", tasks=[], status=SprintStatus.IN_PROGRESS)
        se = SprintEngine(mock_engine, state)

        with patch.object(se.tdd, "run_tests", return_value=(False, "2 failed, 1 passed")):
            summary = se.run_standup(sprint)

        assert "failing" in summary
        assert "2 failed, 1 passed" in summary

    def test_includes_task_markers(self, mock_engine, state, team):
        tasks = [
            SprintTask(id="s1_t1", description="Done task", assigned_to="Cody", status="done"),
            SprintTask(id="s1_t2", description="Failed task", assigned_to="Cody", status="failed"),
        ]
        sprint = Sprint(number=1, goal="Goal", tasks=tasks, status=SprintStatus.IN_PROGRESS)
        se = SprintEngine(mock_engine, state)

        with patch.object(se.tdd, "run_tests", return_value=(True, "ok")):
            summary = se.run_standup(sprint)

        assert "✓" in summary
        assert "✗" in summary


# ---------------------------------------------------------------------------
# demo - mocked API
# ---------------------------------------------------------------------------

class TestDemo:
    def test_returns_demo_text(self, mock_engine, state, team):
        sprint = Sprint(number=1, goal="Goal", tasks=[], status=SprintStatus.REVIEW)
        state.save_sprint(sprint)
        se = SprintEngine(mock_engine, state)

        result = se.wrapup.demo(sprint, team["lead_dev"])
        assert result == "Mock response"

    def test_sets_status_to_demo(self, mock_engine, state, team):
        sprint = Sprint(number=1, goal="Goal", tasks=[], status=SprintStatus.REVIEW)
        state.save_sprint(sprint)
        se = SprintEngine(mock_engine, state)

        se.wrapup.demo(sprint, team["lead_dev"])
        assert sprint.status == SprintStatus.DEMO

    def test_invokes_lead_dev(self, mock_engine, state, team):
        sprint = Sprint(number=1, goal="Build auth", tasks=[], status=SprintStatus.REVIEW)
        state.save_sprint(sprint)
        se = SprintEngine(mock_engine, state)

        se.wrapup.demo(sprint, team["lead_dev"])

        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["persona"].role_type == RoleType.LEAD_DEV

    def test_demo_prompt_includes_goal(self, mock_engine, state, team):
        sprint = Sprint(number=1, goal="Build auth", tasks=[], status=SprintStatus.REVIEW)
        state.save_sprint(sprint)
        se = SprintEngine(mock_engine, state)

        se.wrapup.demo(sprint, team["lead_dev"])

        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert "Build auth" in call_kwargs["user_message"]

    def test_sprint_saved_with_demo_status(self, mock_engine, state, team):
        sprint = Sprint(number=1, goal="Goal", tasks=[], status=SprintStatus.REVIEW)
        state.save_sprint(sprint)
        se = SprintEngine(mock_engine, state)

        se.wrapup.demo(sprint, team["lead_dev"])
        loaded = state.load_sprint(1)
        assert loaded.status == SprintStatus.DEMO


# ---------------------------------------------------------------------------
# _parse_hire_suggestions
# ---------------------------------------------------------------------------

class TestParseHireSuggestions:
    def test_parses_hire_and_model(self):
        response = (
            "HIRE: Data Architect\n"
            "MODEL: opus - needs deep reasoning for schema design\n"
        )
        results = parse_hire_suggestions(response)
        assert len(results) == 1
        assert results[0]["description"] == "Data Architect"
        assert results[0]["model"] == "opus"
        assert results[0]["reasoning"] == "needs deep reasoning for schema design"

    def test_parses_multiple_suggestions(self):
        response = (
            "HIRE: Security Expert\n"
            "MODEL: opus - complex threat modeling\n\n"
            "HIRE: CSS Specialist\n"
            "MODEL: haiku - simple styling tasks\n"
        )
        results = parse_hire_suggestions(response)
        assert len(results) == 2
        assert results[0]["model"] == "opus"
        assert results[1]["model"] == "haiku"
        assert results[1]["description"] == "CSS Specialist"

    def test_defaults_to_sonnet_without_model(self):
        response = "HIRE: Generic Developer\n"
        results = parse_hire_suggestions(response)
        assert len(results) == 1
        assert results[0]["model"] == "sonnet"
        assert results[0]["reasoning"] == ""

    def test_defaults_to_sonnet_for_invalid_model(self):
        response = (
            "HIRE: Some Expert\n"
            "MODEL: gpt4 - wrong model name\n"
        )
        results = parse_hire_suggestions(response)
        assert len(results) == 1
        assert results[0]["model"] == "sonnet"

    def test_model_with_dash_separator(self):
        response = (
            "HIRE: API Designer\n"
            "MODEL: sonnet - solid implementation work\n"
        )
        results = parse_hire_suggestions(response)
        assert len(results) == 1
        assert results[0]["model"] == "sonnet"
        assert results[0]["reasoning"] == "solid implementation work"

    def test_model_without_reasoning(self):
        response = (
            "HIRE: Quick Helper\n"
            "MODEL: haiku\n"
        )
        results = parse_hire_suggestions(response)
        assert len(results) == 1
        assert results[0]["model"] == "haiku"
        assert results[0]["reasoning"] == ""

    def test_empty_response(self):
        results = parse_hire_suggestions("")
        assert results == []

    def test_hire_without_model_then_hire_with_model(self):
        response = (
            "HIRE: First Developer\n"
            "HIRE: Second Developer\n"
            "MODEL: opus - important\n"
        )
        results = parse_hire_suggestions(response)
        assert len(results) == 2
        assert results[0]["description"] == "First Developer"
        assert results[0]["model"] == "sonnet"  # default, no MODEL line
        assert results[1]["description"] == "Second Developer"
        assert results[1]["model"] == "opus"

    def test_mixed_case_labels(self):
        response = "hire: Lowercase Expert\nmodel: OPUS - reason\n"
        results = parse_hire_suggestions(response)
        assert len(results) == 1
        assert results[0]["description"] == "Lowercase Expert"
        assert results[0]["model"] == "opus"


# ---------------------------------------------------------------------------
# _suggest_hires - mocked API
# ---------------------------------------------------------------------------

class TestSuggestHires:
    def test_returns_structured_suggestions(self, mock_engine, state, team):
        mock_engine.invoke.return_value = (
            "HIRE: Database Expert\n"
            "MODEL: opus - complex schema design\n"
        )
        se = SprintEngine(mock_engine, state)
        results = se.wrapup.suggest_hires(team["lead_dev"], "retro summary", team)
        assert len(results) == 1
        assert results[0]["description"] == "Database Expert"
        assert results[0]["model"] == "opus"

    def test_returns_empty_on_none(self, mock_engine, state, team):
        mock_engine.invoke.return_value = "NONE - the team is complete."
        se = SprintEngine(mock_engine, state)
        results = se.wrapup.suggest_hires(team["lead_dev"], "retro", team)
        assert results == []

    def test_prompt_includes_model_tier_guidance(self, mock_engine, state, team):
        mock_engine.invoke.return_value = "NONE"
        se = SprintEngine(mock_engine, state)
        se.wrapup.suggest_hires(team["lead_dev"], "retro", team)
        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert "MODEL:" in call_kwargs["user_message"]
        assert "opus" in call_kwargs["user_message"]
        assert "sonnet" in call_kwargs["user_message"]
        assert "haiku" in call_kwargs["user_message"]


# ===========================================================================
# Phase 2 - Hardening tests
# ===========================================================================

# ---------------------------------------------------------------------------
# 2a: _merge_sprint_branch returns status strings
# ---------------------------------------------------------------------------

class TestMergeSprintBranch:
    def test_returns_no_git_when_unavailable(self, mock_engine, state, team):
        se = SprintEngine(mock_engine, state)
        se.git = MagicMock()
        se.git.available = False

        result = se.wrapup.merge_sprint_branch(1, team["lead_dev"])
        assert result == "no_git"

    def test_returns_merged_on_success(self, mock_engine, state, team):
        se = SprintEngine(mock_engine, state)
        se.git = MagicMock()
        se.git.available = True
        se.git.merge_sprint.return_value = None  # no exception = success

        result = se.wrapup.merge_sprint_branch(1, team["lead_dev"])
        assert result == "merged"

    def test_returns_merged_after_conflict_resolution(self, mock_engine, state, team):
        from odd.git import MergeConflictError

        se = SprintEngine(mock_engine, state)
        se.git = MagicMock()
        se.git.available = True
        se.git.merge_sprint.side_effect = MergeConflictError(["file.py"])
        se.git.resolve_conflicts_and_commit.return_value = True

        state.save_config(ProjectConfig(name="P", description="D"))
        result = se.wrapup.merge_sprint_branch(1, team["lead_dev"])
        assert result == "merged"

    def test_returns_deferred_on_unresolved_conflict(self, mock_engine, state, team):
        from odd.git import MergeConflictError

        se = SprintEngine(mock_engine, state)
        se.git = MagicMock()
        se.git.available = True
        se.git.merge_sprint.side_effect = MergeConflictError(["file.py"])
        se.git.resolve_conflicts_and_commit.return_value = False

        state.save_config(ProjectConfig(name="P", description="D"))
        result = se.wrapup.merge_sprint_branch(1, team["lead_dev"])
        assert result == "deferred"
        se.git.abort_merge.assert_called_once()


# ---------------------------------------------------------------------------
# 2c: KeyboardInterrupt saves cancelled status
# ---------------------------------------------------------------------------

class TestKeyboardInterruptProtection:
    def test_sprint_saved_as_cancelled_on_interrupt(self, mock_engine, state, team):
        mock_engine.cfo = None
        se = SprintEngine(mock_engine, state)
        se.git = MagicMock()
        se.git.available = True
        se.git.create_sprint_branch.return_value = "sprint-1"

        # Make run_sprint raise KeyboardInterrupt
        se.run_sprint = MagicMock(side_effect=KeyboardInterrupt)

        sprint = Sprint(number=1, goal="Goal", tasks=[], status=SprintStatus.PLANNING)
        state.save_sprint(sprint)
        config = ProjectConfig(name="P", description="D")
        state.save_config(config)

        with patch("odd.sprint.Prompt") as mock_prompt:
            mock_prompt.ask.return_value = "y"
            se.plan_sprint = MagicMock(return_value=sprint)
            result = se.run_full_sprint(team, "goal", 1)

        assert result.status == SprintStatus.CANCELLED
        saved = state.load_sprint(1)
        assert saved.status == SprintStatus.CANCELLED


# ---------------------------------------------------------------------------
# 2f: demo() guards git.available
# ---------------------------------------------------------------------------

class TestDemoGitGuard:
    def test_demo_skips_diff_when_git_unavailable(self, mock_engine, state, team):
        sprint = Sprint(number=1, goal="Goal", tasks=[], status=SprintStatus.REVIEW)
        state.save_sprint(sprint)
        se = SprintEngine(mock_engine, state)
        se.git = MagicMock()
        se.git.available = False

        se.wrapup.demo(sprint, team["lead_dev"])
        se.git.get_sprint_diff_summary.assert_not_called()


# ---------------------------------------------------------------------------
# 2g: _resolve_agent caches consultant list
# ---------------------------------------------------------------------------

class TestResolveAgentCache:
    def test_consultant_cache_reused_across_calls(self, state, team):
        se = SprintEngine(engine=None, state=state)
        consultant = Persona(
            role_type=RoleType.CONSULTANT, name="Zack Expert", title="Expert",
        )
        state.save_persona(consultant)

        # First call populates cache
        se.context.resolve_agent("Zack Expert", team)
        assert se.context._consultant_cache is not None

        # Spy on list_consultants to verify it's not called again
        state.list_consultants = MagicMock(return_value=se.context._consultant_cache)
        se.context.resolve_agent("Zack Expert", team)
        state.list_consultants.assert_not_called()

    def test_cache_cleared_on_run_sprint(self, mock_engine, state, team):
        se = SprintEngine(mock_engine, state)
        se.context._consultant_cache = [MagicMock()]  # pretend it's populated

        sprint = Sprint(number=1, goal="Goal", tasks=[], status=SprintStatus.PLANNING)
        state.save_sprint(sprint)

        # run_sprint will fail eventually but cache should be cleared early
        try:
            se.run_sprint(sprint, team)
        except Exception:
            pass
        assert se.context._consultant_cache is None


# ---------------------------------------------------------------------------
# Phase 4 - Test Review Feedback Loop
# ---------------------------------------------------------------------------

class TestFormatReviewFeedback:
    """Unit tests for TDDGate.format_review_feedback."""

    def test_empty_outcomes_returns_empty_string(self):
        assert TDDGate.format_review_feedback([]) == ""

    def test_accepted_tests_pass(self):
        outcomes = [{"verdict": "accept", "reason": "test was wrong", "test_file": "tests/test_foo.py", "tests_pass": True}]
        result = TDDGate.format_review_feedback(outcomes)
        assert "accepted" in result
        assert "tests/test_foo.py" in result
        assert "passing" in result

    def test_accepted_tests_still_failing(self):
        outcomes = [{"verdict": "accept", "reason": "spec changed", "test_file": "tests/test_bar.py", "tests_pass": False}]
        result = TDDGate.format_review_feedback(outcomes)
        assert "accepted" in result
        assert "still failing" in result
        assert "spec changed" in result

    def test_rejected(self):
        outcomes = [{"verdict": "reject", "reason": "test is correct", "test_file": "tests/test_baz.py", "tests_pass": False}]
        result = TDDGate.format_review_feedback(outcomes)
        assert "rejected" in result
        assert "test is correct" in result
        assert "Fix your implementation" in result

    def test_multiple_outcomes(self):
        outcomes = [
            {"verdict": "accept", "reason": "ok", "test_file": "a.py", "tests_pass": True},
            {"verdict": "reject", "reason": "nope", "test_file": "b.py", "tests_pass": False},
        ]
        result = TDDGate.format_review_feedback(outcomes)
        assert "a.py" in result
        assert "b.py" in result
        assert "QA" in result


class TestHandleTestChangeRequests:
    """Tests for _handle_test_change_requests returning structured outcomes."""

    def test_no_requests_returns_empty(self, mock_engine, state, team):
        se = SprintEngine(mock_engine, state)
        sprint = Sprint(number=1, goal="Ship", tasks=[], status=SprintStatus.IN_PROGRESS)
        mock_engine.submissions = []

        outcomes = se.wrapup.handle_test_change_requests(sprint, team, "ctx")
        assert outcomes == []

    def test_non_test_change_submissions_preserved(self, mock_engine, state, team):
        se = SprintEngine(mock_engine, state)
        sprint = Sprint(number=1, goal="Ship", tasks=[], status=SprintStatus.IN_PROGRESS)
        # pop_submissions only removes matching tool; others stay untouched
        mock_engine.submissions = [
            {"tool": "submit_dependency_request", "data": {"package": "numpy"}},
        ]

        outcomes = se.wrapup.handle_test_change_requests(sprint, team, "ctx")
        assert outcomes == []
        # Non-matching submission stays in the list
        assert len(mock_engine.submissions) == 1
        assert mock_engine.submissions[0]["tool"] == "submit_dependency_request"

    def test_vera_accept_verdict_returned(self, mock_engine, state, team):
        se = SprintEngine(mock_engine, state)
        sprint = Sprint(number=1, goal="Ship", tasks=[], status=SprintStatus.IN_PROGRESS)

        # Initial submissions contain the change request
        mock_engine.submissions = [
            {"tool": "submit_test_change_request", "data": {
                "test_file": "tests/test_foo.py",
                "reason": "wrong expected value",
                "proposed_change": "change 42 to 43",
            }},
        ]

        # Vera's invoke adds her decision to submissions
        def vera_invoke(*args, **kwargs):
            mock_engine.submissions.append({"tool": "submit_test_review_decision", "data": {
                "verdict": "accept",
                "reason": "expected value was indeed wrong",
                "test_file": "tests/test_foo.py",
            }})
            return "Reviewed"

        mock_engine.invoke.side_effect = vera_invoke

        with patch.object(se.tdd, "run_tests", return_value=(True, "all passed")):
            outcomes = se.wrapup.handle_test_change_requests(sprint, team, "ctx")

        assert len(outcomes) == 1
        assert outcomes[0]["verdict"] == "accept"
        assert outcomes[0]["tests_pass"] is True
        assert outcomes[0]["test_file"] == "tests/test_foo.py"

    def test_vera_reject_verdict_returned(self, mock_engine, state, team):
        se = SprintEngine(mock_engine, state)
        sprint = Sprint(number=1, goal="Ship", tasks=[], status=SprintStatus.IN_PROGRESS)

        mock_engine.submissions = [
            {"tool": "submit_test_change_request", "data": {
                "test_file": "tests/test_foo.py",
                "reason": "too strict",
                "proposed_change": "loosen assertion",
            }},
        ]

        def vera_invoke(*args, **kwargs):
            mock_engine.submissions.append({"tool": "submit_test_review_decision", "data": {
                "verdict": "reject",
                "reason": "test is correct, fix your code",
                "test_file": "tests/test_foo.py",
            }})
            return "Rejected"

        mock_engine.invoke.side_effect = vera_invoke

        outcomes = se.wrapup.handle_test_change_requests(sprint, team, "ctx")

        assert len(outcomes) == 1
        assert outcomes[0]["verdict"] == "reject"
        assert outcomes[0]["tests_pass"] is False

    def test_no_qa_returns_empty(self, mock_engine, state):
        se = SprintEngine(mock_engine, state)
        sprint = Sprint(number=1, goal="Ship", tasks=[], status=SprintStatus.IN_PROGRESS)
        team_no_qa = {"lead_dev": Persona(role_type=RoleType.LEAD_DEV, name="Dev", title="Dev")}

        mock_engine.submissions = [
            {"tool": "submit_test_change_request", "data": {
                "test_file": "t.py", "reason": "bad", "proposed_change": "fix",
            }},
        ]

        outcomes = se.wrapup.handle_test_change_requests(sprint, team_no_qa, "ctx")
        assert outcomes == []

    def test_vera_invoked_with_review_decision_tool(self, mock_engine, state, team):
        """Vera should receive SUBMIT_TEST_REVIEW_DECISION as extra_tools."""
        se = SprintEngine(mock_engine, state)
        sprint = Sprint(number=1, goal="Ship", tasks=[], status=SprintStatus.IN_PROGRESS)

        mock_engine.submissions = [
            {"tool": "submit_test_change_request", "data": {
                "test_file": "t.py", "reason": "wrong", "proposed_change": "fix",
            }},
        ]
        # Vera's invoke doesn't add a decision (no formal decision)
        mock_engine.invoke.return_value = "Reviewed"

        outcomes = se.wrapup.handle_test_change_requests(sprint, team, "ctx")

        # Check that invoke was called with SUBMIT_TEST_REVIEW_DECISION
        invoke_call = mock_engine.invoke.call_args
        extra_tools = invoke_call.kwargs.get("extra_tools", [])
        tool_names = [t["name"] for t in extra_tools]
        assert "submit_test_review_decision" in tool_names

        # Missing decision defaults to reject
        assert outcomes[0]["verdict"] == "reject"

    def test_no_formal_decision_defaults_to_reject(self, mock_engine, state, team):
        se = SprintEngine(mock_engine, state)
        sprint = Sprint(number=1, goal="Ship", tasks=[], status=SprintStatus.IN_PROGRESS)

        mock_engine.submissions = [
            {"tool": "submit_test_change_request", "data": {
                "test_file": "t.py", "reason": "wrong", "proposed_change": "fix",
            }},
        ]
        # Vera's invoke doesn't add a decision
        mock_engine.invoke.return_value = "Reviewed"

        outcomes = se.wrapup.handle_test_change_requests(sprint, team, "ctx")
        assert outcomes[0]["verdict"] == "reject"
        assert "defaulting" in outcomes[0]["reason"].lower()


class TestTDDGateFeedbackLoop:
    """Tests for review feedback threading through TDDGate.execute."""

    def _make_sprint(self):
        return Sprint(
            number=1, goal="Ship it",
            tasks=[SprintTask(id="s1_t1", description="Build feature", assigned_to="Lead Developer")],
            status=SprintStatus.IN_PROGRESS,
        )

    def test_review_feedback_included_in_retry_prompt(self, mock_engine, state, team):
        """When Vera rejects a change request, the rejection feeds into the retry prompt."""
        sprint = self._make_sprint()
        se = SprintEngine(mock_engine, state)

        # Sequence: initial invoke → test fail → retry invoke → test pass
        test_results = iter([
            (False, "FAILED test_foo"),   # after initial impl
            (True, "all passed"),         # after retry
        ])

        # invoke sequence: [initial_impl, vera_review, retry_impl]
        # initial_impl adds the change request to submissions
        # vera_review adds the rejection decision
        invoke_count = [0]

        def staged_invoke(*args, **kwargs):
            invoke_count[0] += 1
            if invoke_count[0] == 1:
                # Initial impl agent submits a change request
                mock_engine.submissions.append({"tool": "submit_test_change_request", "data": {
                    "test_file": "t.py", "reason": "wrong", "proposed_change": "fix",
                }})
            elif invoke_count[0] == 2:
                # Vera's review adds rejection
                mock_engine.submissions.append({"tool": "submit_test_review_decision", "data": {
                    "verdict": "reject",
                    "reason": "test is correct",
                    "test_file": "t.py",
                }})
            return "Mock response"

        mock_engine.invoke.side_effect = staged_invoke
        mock_engine.submissions = []

        with patch.object(se.tdd, "run_tests", side_effect=lambda cwd=None: next(test_results)):
            se.tdd.execute(
                engine=mock_engine,
                agent=team["lead_dev"],
                task=sprint.tasks[0],
                sprint=sprint,
                impl_prompt="Implement the feature",
                project_context="ctx",
                team=team,
                interactive=True,
                on_test_change_requests=se.wrapup.handle_test_change_requests,
                on_dependency_requests=se.wrapup.handle_dependency_requests,
            )

        # The retry invoke should include the rejection feedback
        assert mock_engine.invoke.call_count >= 2
        retry_prompts = [
            c.kwargs["user_message"]
            for c in mock_engine.invoke.call_args_list
            if "Test Review Feedback" in c.kwargs.get("user_message", "")
        ]
        assert len(retry_prompts) >= 1
        assert "rejected" in retry_prompts[0]
        assert "test is correct" in retry_prompts[0]


# ---------------------------------------------------------------------------
# CEO Style Gates (Phase 5)
# ---------------------------------------------------------------------------


class TestCEOStyleEscalationFiltering:
    """5a: Escalation filtering based on CEO style."""

    def _make_engine(self, mock_engine, state, ceo_style):
        config = state.load_config()
        config.ceo_style = ceo_style
        state.save_config(config)
        se = SprintEngine(mock_engine, state, git=MagicMock())
        return se

    def test_hands_on_surfaces_all_severities(self, mock_engine, state):
        se = self._make_engine(mock_engine, state, CEOStyle.HANDS_ON)
        assert se.tdd.should_surface_escalation("heads_up") is True
        assert se.tdd.should_surface_escalation("needs_decision") is True
        assert se.tdd.should_surface_escalation("blocker") is True

    def test_balanced_filters_info(self, mock_engine, state):
        se = self._make_engine(mock_engine, state, CEOStyle.BALANCED)
        assert se.tdd.should_surface_escalation("heads_up") is False
        assert se.tdd.should_surface_escalation("needs_decision") is True
        assert se.tdd.should_surface_escalation("blocker") is True

    def test_delegator_only_blockers(self, mock_engine, state):
        se = self._make_engine(mock_engine, state, CEOStyle.DELEGATOR)
        assert se.tdd.should_surface_escalation("heads_up") is False
        assert se.tdd.should_surface_escalation("needs_decision") is False
        assert se.tdd.should_surface_escalation("blocker") is True

    def test_handle_escalations_filters_by_style(self, mock_engine, state, team):
        """BALANCED mode should skip heads_up escalations."""
        se = self._make_engine(mock_engine, state, CEOStyle.BALANCED)
        mock_engine.get_escalations.return_value = [
            {"severity": "heads_up", "reason": "FYI"},
            {"severity": "blocker", "reason": "Stuck"},
        ]

        with patch("odd.sprint.Prompt.ask", return_value="keep going") as mock_ask:
            se.tdd._handle_escalations(
                team["lead_dev"], "context", task_description="task",
            )
            # Only blocker should have triggered a CEO prompt
            assert mock_ask.call_count == 1

    def test_drain_escalations_filters_noninteractive(self, mock_engine, state, team):
        """Non-interactive drain should filter out non-surfaced escalations."""
        se = self._make_engine(mock_engine, state, CEOStyle.DELEGATOR)

        forked = MagicMock()
        forked.escalations = [
            {"severity": "heads_up", "reason": "Info"},
            {"severity": "needs_decision", "reason": "Choose"},
            {"severity": "blocker", "reason": "Stuck"},
        ]

        se.tdd.drain_escalations(forked, team["lead_dev"], "ctx", "task", interactive=False)

        # Only blocker should be re-queued in delegator mode
        assert len(forked.escalations) == 1
        assert forked.escalations[0]["severity"] == "blocker"


class TestCEOStyleStreamCallback:
    """5b: Phase output gating via streaming callback."""

    def _make_engine(self, mock_engine, state, ceo_style):
        config = state.load_config()
        config.ceo_style = ceo_style
        state.save_config(config)
        return SprintEngine(mock_engine, state, git=MagicMock())

    def test_hands_on_streams_text(self, mock_engine, state):
        se = self._make_engine(mock_engine, state, CEOStyle.HANDS_ON)
        cb = se._make_stream_callback("Agent")
        assert cb is not None

    def test_balanced_streams_summary_only(self, mock_engine, state):
        from odd.provider import StreamEvent, StreamEventType
        se = self._make_engine(mock_engine, state, CEOStyle.BALANCED)
        cb = se._make_stream_callback("Agent")
        assert cb is not None
        # Balanced callback should not print TEXT_DELTA events
        # (no error calling it with tool use events)
        event = StreamEvent(event_type=StreamEventType.TOOL_USE_START, tool_name="write_file")
        cb(event)  # should not raise

    def test_delegator_no_stream(self, mock_engine, state):
        se = self._make_engine(mock_engine, state, CEOStyle.DELEGATOR)
        cb = se._make_stream_callback("Agent")
        assert cb is None


class TestCEOStylePlanApproval:
    """5b: Plan approval gate - DELEGATOR auto-proceeds."""

    def test_delegator_skips_plan_approval(self, mock_engine, state, team):
        config = state.load_config()
        config.ceo_style = CEOStyle.DELEGATOR
        state.save_config(config)

        mock_engine.cfo = None  # No CFO for this test
        se = SprintEngine(mock_engine, state, git=MagicMock())

        mock_engine.invoke.return_value = "TASK: Build it\nASSIGN: Lead Developer"
        sprint = se.planner.plan_sprint(team["lead_dev"], team["qa"], "Build it", 1)

        with patch.object(se, "run_sprint", return_value=sprint), \
             patch.object(se.wrapup, "post_implementation"), \
             patch("odd.sprint.Prompt.ask") as mock_ask:
            se.run_full_sprint(team, "Build it", 1)
            # Delegator should NOT have been asked about plan approval
            plan_asks = [
                c for c in mock_ask.call_args_list
                if "Proceed" in str(c)
            ]
            assert len(plan_asks) == 0

    def test_hands_on_asks_plan_approval(self, mock_engine, state, team):
        config = state.load_config()
        config.ceo_style = CEOStyle.HANDS_ON
        state.save_config(config)

        mock_engine.cfo = None
        se = SprintEngine(mock_engine, state, git=MagicMock())

        mock_engine.invoke.return_value = "TASK: Build it\nASSIGN: Lead Developer"
        sprint = se.planner.plan_sprint(team["lead_dev"], team["qa"], "Build it", 1)

        with patch.object(se, "run_sprint", return_value=sprint), \
             patch.object(se.wrapup, "post_implementation"), \
             patch("odd.sprint.Prompt.ask", return_value="y") as mock_ask:
            se.run_full_sprint(team, "Build it", 1)
            # Hands-on should have been asked about plan approval
            plan_asks = [
                c for c in mock_ask.call_args_list
                if "Proceed" in str(c)
            ]
            assert len(plan_asks) == 1


class TestCEOStyleCodeReview:
    """5c: Code review gating - review_passes as default, style controls prompting."""

    def _make_state(self, review_passes=1):
        state = MagicMock()
        config = ProjectConfig(name="Test", review_passes=review_passes)
        state.load_config.return_value = config
        return state

    def test_delegator_runs_at_default(self):
        """Delegator auto-runs at configured pass count, no prompt."""
        from odd.review import offer_code_review
        state = self._make_state(review_passes=2)
        lead = Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev")

        with patch("odd.review.should_nudge_review", return_value=(False, "")):
            result = offer_code_review(state, 1, lead, ceo_style=CEOStyle.DELEGATOR)
        assert result == 2

    def test_delegator_skips_when_zero(self):
        """Delegator with 0 passes skips review."""
        from odd.review import offer_code_review
        state = self._make_state(review_passes=0)
        lead = Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev")

        with patch("odd.review.should_nudge_review", return_value=(False, "")):
            result = offer_code_review(state, 1, lead, ceo_style=CEOStyle.DELEGATOR)
        assert result == 0

    def test_delegator_bumps_to_one_on_nudge(self):
        """Delegator with 0 passes bumps to 1 when nudge fires."""
        from odd.review import offer_code_review
        state = self._make_state(review_passes=0)
        lead = Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev")

        with patch("odd.review.should_nudge_review", return_value=(True, "Overdue")):
            result = offer_code_review(state, 1, lead, ceo_style=CEOStyle.DELEGATOR)
        assert result == 1

    def test_balanced_auto_runs_non_milestone(self):
        """Balanced auto-runs at default without prompting on non-milestones."""
        from odd.review import offer_code_review
        state = self._make_state(review_passes=1)
        lead = Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev")

        with patch("odd.review.should_nudge_review", return_value=(False, "")):
            result = offer_code_review(
                state, 1, lead,
                ceo_style=CEOStyle.BALANCED, is_milestone=False,
            )
        assert result == 1

    def test_balanced_asks_on_milestone(self):
        """Balanced prompts CEO on milestones, suggesting at least 2."""
        from odd.review import offer_code_review
        state = self._make_state(review_passes=1)
        lead = Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev")

        with patch("odd.review.should_nudge_review", return_value=(False, "")), \
             patch("odd.review.Prompt.ask", return_value="3") as mock_ask:
            result = offer_code_review(
                state, 1, lead,
                ceo_style=CEOStyle.BALANCED, is_milestone=True,
            )
        assert result == 3
        # Default suggestion should be at least 2 for milestones
        assert mock_ask.call_args[1]["default"] == "2"

    def test_hands_on_always_asks(self):
        """Hands-on always prompts CEO with current default."""
        from odd.review import offer_code_review
        state = self._make_state(review_passes=1)
        lead = Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev")

        with patch("odd.review.should_nudge_review", return_value=(False, "")), \
             patch("odd.review.Prompt.ask", return_value="4"):
            result = offer_code_review(
                state, 1, lead,
                ceo_style=CEOStyle.HANDS_ON, is_milestone=False,
            )
        assert result == 4

    def test_hands_on_ceo_skips_with_zero(self):
        """Hands-on CEO can enter 0 to skip review."""
        from odd.review import offer_code_review
        state = self._make_state(review_passes=1)
        lead = Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev")

        with patch("odd.review.should_nudge_review", return_value=(False, "")), \
             patch("odd.review.Prompt.ask", return_value="0"):
            result = offer_code_review(
                state, 1, lead,
                ceo_style=CEOStyle.HANDS_ON, is_milestone=False,
            )
        assert result == 0


class TestCEOStyleCLI:
    """5d: CLI integration - config style command."""

    def test_config_style_changes_style(self, tmp_path, monkeypatch):
        from click.testing import CliRunner
        from odd.cli import main

        monkeypatch.chdir(tmp_path)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", ceo_style=CEOStyle.BALANCED)
        state.init(config)

        runner = CliRunner()
        result = runner.invoke(main, ["config", "style", "delegator"])
        assert result.exit_code == 0
        assert "Delegator" in result.output

        updated = state.load_config()
        assert updated.ceo_style == CEOStyle.DELEGATOR

    def test_status_shows_style(self, tmp_path, monkeypatch):
        from click.testing import CliRunner
        from odd.cli import main

        monkeypatch.chdir(tmp_path)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", ceo_style=CEOStyle.HANDS_ON)
        state.init(config)

        runner = CliRunner()
        result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "Hands-on" in result.output

    def test_config_style_gate_override(self, tmp_path, monkeypatch):
        from click.testing import CliRunner
        from odd.cli import main

        monkeypatch.chdir(tmp_path)
        state = StateManager(tmp_path)
        config = ProjectConfig(name="Test", ceo_style=CEOStyle.BALANCED)
        state.init(config)

        runner = CliRunner()
        result = runner.invoke(main, ["config", "style", "war-room", "hands-on"])
        assert result.exit_code == 0
        assert "Hands-on" in result.output

        updated = state.load_config()
        assert updated.ceo_overrides[CEOGate.WAR_ROOM] == CEOStyle.HANDS_ON
        assert updated.ceo_style == CEOStyle.BALANCED  # default unchanged

    def test_config_style_gate_reset(self, tmp_path, monkeypatch):
        from click.testing import CliRunner
        from odd.cli import main

        monkeypatch.chdir(tmp_path)
        state = StateManager(tmp_path)
        config = ProjectConfig(
            name="Test", ceo_style=CEOStyle.BALANCED,
            ceo_overrides={CEOGate.WAR_ROOM: CEOStyle.HANDS_ON},
        )
        state.init(config)

        runner = CliRunner()
        result = runner.invoke(main, ["config", "style", "war-room", "--reset"])
        assert result.exit_code == 0
        assert "cleared" in result.output

        updated = state.load_config()
        assert CEOGate.WAR_ROOM not in updated.ceo_overrides


class TestCEOStyleHiring:
    """5b: Hiring gate - DELEGATOR auto-approves, BALANCED confirms."""

    def _make_engine(self, mock_engine, state, ceo_style):
        config = state.load_config()
        config.ceo_style = ceo_style
        state.save_config(config)
        return SprintEngine(mock_engine, state, git=MagicMock())

    @patch("odd.processes.generate_onboarding_brief")
    @patch("odd.roles.recruit_consultant")
    def test_delegator_auto_hires(self, mock_recruit, mock_onboard, mock_engine, state, team):
        se = self._make_engine(mock_engine, state, CEOStyle.DELEGATOR)
        mock_recruit.return_value = Persona(
            role_type=RoleType.CONSULTANT, name="AutoHire", title="Specialist",
        )

        with patch.object(se.wrapup, "suggest_hires", return_value=[
            {"description": "DB Expert", "model": "sonnet", "reasoning": "Need DB help"},
        ]), patch("odd.sprint.Prompt.ask") as mock_ask:
            se.wrapup.handle_hire_suggestions(team["lead_dev"], team["secretary"], "retro", team)
            # DELEGATOR should not prompt the CEO
            assert mock_ask.call_count == 0
            mock_recruit.assert_called_once()

    @patch("odd.processes.generate_onboarding_brief")
    @patch("odd.roles.recruit_consultant")
    def test_balanced_confirms(self, mock_recruit, mock_onboard, mock_engine, state, team):
        se = self._make_engine(mock_engine, state, CEOStyle.BALANCED)
        mock_recruit.return_value = Persona(
            role_type=RoleType.CONSULTANT, name="ConfHire", title="Specialist",
        )

        with patch.object(se.wrapup, "suggest_hires", return_value=[
            {"description": "DB Expert", "model": "sonnet", "reasoning": "Need DB help"},
        ]), patch("odd.sprint.Prompt.ask", return_value="y") as mock_ask:
            se.wrapup.handle_hire_suggestions(team["lead_dev"], team["secretary"], "retro", team)
            # BALANCED prompts with y/n only (not model tier choices)
            assert mock_ask.call_count == 1
            choices = mock_ask.call_args.kwargs.get("choices", [])
            assert choices == ["y", "n"]


class TestCEOGateOverrides:
    """Per-gate CEO style overrides."""

    def _make_engine(self, mock_engine, state, ceo_style, overrides=None):
        config = state.load_config()
        config.ceo_style = ceo_style
        config.ceo_overrides = overrides or {}
        state.save_config(config)
        return SprintEngine(mock_engine, state, git=MagicMock())

    def test_gate_returns_default_without_override(self, mock_engine, state):
        se = self._make_engine(mock_engine, state, CEOStyle.BALANCED)
        assert se.gate(CEOGate.STREAMING) == CEOStyle.BALANCED
        assert se.gate(CEOGate.WAR_ROOM) == CEOStyle.BALANCED
        assert se.gate(CEOGate.HIRING) == CEOStyle.BALANCED

    def test_gate_returns_override_when_set(self, mock_engine, state):
        se = self._make_engine(mock_engine, state, CEOStyle.BALANCED, {
            CEOGate.WAR_ROOM: CEOStyle.HANDS_ON,
            CEOGate.HIRING: CEOStyle.DELEGATOR,
        })
        assert se.gate(CEOGate.WAR_ROOM) == CEOStyle.HANDS_ON
        assert se.gate(CEOGate.HIRING) == CEOStyle.DELEGATOR
        # Non-overridden gates still use default
        assert se.gate(CEOGate.STREAMING) == CEOStyle.BALANCED
        assert se.gate(CEOGate.PLAN_APPROVAL) == CEOStyle.BALANCED

    def test_streaming_override_affects_callback(self, mock_engine, state):
        """Delegator default but hands-on streaming → full callback."""
        se = self._make_engine(mock_engine, state, CEOStyle.DELEGATOR, {
            CEOGate.STREAMING: CEOStyle.HANDS_ON,
        })
        se.streaming = True
        cb = se._make_stream_callback("Agent")
        assert cb is not None  # would be None without the override

    def test_war_room_override_independent(self, mock_engine, state):
        """Balanced default but delegator war room → no war room."""
        se = self._make_engine(mock_engine, state, CEOStyle.BALANCED, {
            CEOGate.WAR_ROOM: CEOStyle.DELEGATOR,
        })
        se.streaming = True
        # War room gate is delegator, so should return None
        from odd.display import AgentOutputStream
        stream = AgentOutputStream("Dev")
        cb = se._make_war_room_callback(stream)
        assert cb is None

    def test_escalation_override(self, mock_engine, state):
        """Delegator default but hands-on escalations → surface everything."""
        se = self._make_engine(mock_engine, state, CEOStyle.DELEGATOR, {
            CEOGate.ESCALATIONS: CEOStyle.HANDS_ON,
        })
        assert se.tdd.should_surface_escalation("heads_up") is True
        assert se.tdd.should_surface_escalation("needs_decision") is True
        assert se.tdd.should_surface_escalation("blocker") is True
