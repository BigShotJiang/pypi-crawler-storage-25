"""Tests for odd.rate_limiter - shared concurrency and backoff coordination."""

from __future__ import annotations

import threading
import time

from odd.rate_limiter import SharedRateLimiter


class TestSharedRateLimiter:
    def test_acquire_release_basic(self):
        rl = SharedRateLimiter(max_concurrent=2)
        rl.acquire()
        rl.acquire()
        rl.release()
        rl.release()

    def test_throttled_context_manager(self):
        rl = SharedRateLimiter(max_concurrent=1)
        with rl.throttled():
            pass  # should not deadlock

    def test_semaphore_limits_concurrency(self):
        rl = SharedRateLimiter(max_concurrent=2)
        active = threading.Semaphore(0)
        max_active = []
        count_lock = threading.Lock()
        active_count = [0]

        def worker():
            with rl.throttled():
                with count_lock:
                    active_count[0] += 1
                    max_active.append(active_count[0])
                time.sleep(0.05)
                with count_lock:
                    active_count[0] -= 1

        threads = [threading.Thread(target=worker) for _ in range(6)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert max(max_active) <= 2

    def test_signal_rate_limit_causes_backoff(self):
        rl = SharedRateLimiter(max_concurrent=4)
        rl.signal_rate_limit(retry_after=0.1)
        start = time.monotonic()
        rl.acquire()
        elapsed = time.monotonic() - start
        rl.release()
        assert elapsed >= 0.05  # should have waited ~0.1s

    def test_concurrent_signals_use_max(self):
        rl = SharedRateLimiter(max_concurrent=4)
        # Two signals: 0.05s and 0.15s from now
        rl.signal_rate_limit(retry_after=0.05)
        rl.signal_rate_limit(retry_after=0.15)
        start = time.monotonic()
        rl.acquire()
        elapsed = time.monotonic() - start
        rl.release()
        # Should wait for the longer backoff
        assert elapsed >= 0.1

    def test_no_backoff_when_not_signaled(self):
        rl = SharedRateLimiter(max_concurrent=4)
        start = time.monotonic()
        rl.acquire()
        elapsed = time.monotonic() - start
        rl.release()
        assert elapsed < 0.05


class TestStateManagerLocks:
    """Verify that save_sprint and save_config are protected by locks."""

    def test_sprint_lock_exists(self):
        from odd.state import StateManager
        sm = StateManager()
        assert hasattr(sm, "_sprint_lock")
        assert isinstance(sm._sprint_lock, type(threading.Lock()))

    def test_config_lock_exists(self):
        from odd.state import StateManager
        sm = StateManager()
        assert hasattr(sm, "_config_lock")
        assert isinstance(sm._config_lock, type(threading.Lock()))

    def test_concurrent_sprint_saves(self, tmp_path):
        """Concurrent save_sprint calls should not corrupt the file."""
        from odd.models import Sprint
        from odd.state import StateManager

        odd_dir = tmp_path / ".odd"
        odd_dir.mkdir()
        (odd_dir / "sprints").mkdir()
        sm = StateManager(project_root=tmp_path)

        sprint = Sprint(number=1, goal="test goal")
        errors = []

        def save_many(n):
            try:
                for _ in range(20):
                    sm.save_sprint(sprint)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=save_many, args=(i,)) for i in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        # Should be loadable after concurrent writes
        loaded = sm.load_sprint(1)
        assert loaded.goal == "test goal"
