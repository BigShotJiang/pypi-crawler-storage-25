"""Tests for Phase 7: Structured outputs via tool_use submission tools.

Tests cover:
- Submission tool definitions in tools.py
- extra_tools param and submission interception in agent.py
- Structured data path in all parsers (with string fallback)
- Wiring in sprint.py, roles.py, cli.py, processes.py
"""

from unittest.mock import MagicMock, patch

import pytest

from odd.agent import AgentEngine
from odd.models import (
    Persona,
    ProjectConfig,
    RoleType,
    Sprint,
    SprintStatus,
    SprintTask,
)
from odd.provider import AgentResponse, ToolCall, Usage
from odd.parsers import (
    parse_candidate,
    parse_consultant_specs,
    parse_hire_suggestions,
    parse_roadmap,
    parse_tasks,
    parse_tester_specs,
)
from odd.sprint import SprintEngine
from odd.state import StateManager
from odd.tools import (
    SUBMISSION_TOOL_NAMES,
    SUBMIT_CANDIDATE,
    SUBMIT_CONSULTANT_SPECS,
    SUBMIT_HIRE_SUGGESTION,
    SUBMIT_ROADMAP,
    SUBMIT_SPRINT_PLAN,
    SUBMIT_TESTER_SPECS,
)


# ---------------------------------------------------------------------------
# Submission tool definitions
# ---------------------------------------------------------------------------

class TestSubmissionToolDefinitions:
    def test_all_submission_tools_have_name_and_schema(self):
        for tool in [
            SUBMIT_SPRINT_PLAN, SUBMIT_HIRE_SUGGESTION, SUBMIT_CANDIDATE,
            SUBMIT_CONSULTANT_SPECS, SUBMIT_ROADMAP, SUBMIT_TESTER_SPECS,
        ]:
            assert "name" in tool
            assert "parameters" in tool
            assert "description" in tool

    def test_submission_tool_names_set_matches(self):
        expected = {
            "submit_sprint_plan", "submit_phase_plan", "submit_hire_suggestion",
            "submit_candidate", "submit_consultant_specs", "submit_roadmap",
            "submit_tester_specs", "submit_code_review", "submit_test_change_request",
            "submit_dependency_request", "submit_test_review_decision",
        }
        assert SUBMISSION_TOOL_NAMES == expected

    def test_sprint_plan_schema_requires_tasks(self):
        schema = SUBMIT_SPRINT_PLAN["parameters"]
        assert "tasks" in schema["properties"]
        assert "tasks" in schema["required"]

    def test_hire_suggestion_schema_requires_suggestions(self):
        schema = SUBMIT_HIRE_SUGGESTION["parameters"]
        assert "suggestions" in schema["properties"]
        assert "suggestions" in schema["required"]

    def test_candidate_schema_requires_name_title_resume(self):
        schema = SUBMIT_CANDIDATE["parameters"]
        assert set(schema["required"]) == {"name", "title", "resume"}

    def test_roadmap_schema_requires_sprints(self):
        schema = SUBMIT_ROADMAP["parameters"]
        assert "sprints" in schema["required"]


# ---------------------------------------------------------------------------
# AgentEngine: extra_tools + submission interception
# ---------------------------------------------------------------------------

def _make_response(text_blocks, tool_calls=None, stop_reason="end_turn"):
    return AgentResponse(
        text_blocks=text_blocks,
        tool_calls=tool_calls or [],
        stop_reason=stop_reason,
        usage=Usage(input_tokens=100, output_tokens=50),
    )


def _make_mock_provider():
    mock_provider = MagicMock()
    mock_provider.wrap_tool_results.return_value = (
        {"role": "assistant", "content": []},
        {"role": "user", "content": []},
    )
    return mock_provider


def _lead_dev():
    return Persona(
        role_type=RoleType.LEAD_DEV,
        name="Cody",
        title="Lead Developer",
        job_description="Build things",
    )


class TestExtraTools:
    def test_extra_tools_added_to_kwargs(self):
        """extra_tools should be appended to the tool definitions."""
        mock_provider = _make_mock_provider()
        mock_provider.create_message.return_value = _make_response(["OK"])
        engine = AgentEngine(provider=mock_provider)

        engine.invoke(
            persona=_lead_dev(),
            user_message="Plan",
            tools=True,
            extra_tools=[SUBMIT_SPRINT_PLAN],
        )

        call_kwargs = engine.provider.create_message.call_args.kwargs
        tool_names = [t["name"] for t in call_kwargs["tools"]]
        assert "submit_sprint_plan" in tool_names
        assert "read_file" in tool_names  # standard tools still there

    def test_extra_tools_only_no_standard_tools(self):
        """When tools=False but extra_tools provided, only extra tools sent."""
        mock_provider = _make_mock_provider()
        mock_provider.create_message.return_value = _make_response(["OK"])
        engine = AgentEngine(provider=mock_provider)

        engine.invoke(
            persona=_lead_dev(),
            user_message="Plan",
            tools=False,
            extra_tools=[SUBMIT_SPRINT_PLAN],
        )

        call_kwargs = engine.provider.create_message.call_args.kwargs
        tool_names = [t["name"] for t in call_kwargs["tools"]]
        assert "submit_sprint_plan" in tool_names
        assert "read_file" not in tool_names

    def test_no_tools_no_extra_tools(self):
        """When tools=False and no extra_tools, no tools in kwargs."""
        mock_provider = _make_mock_provider()
        mock_provider.create_message.return_value = _make_response(["OK"])
        engine = AgentEngine(provider=mock_provider)

        engine.invoke(persona=_lead_dev(), user_message="Think", tools=False)

        call_kwargs = engine.provider.create_message.call_args.kwargs
        assert call_kwargs.get("tools") is None


class TestSubmissionInterception:
    def test_submission_tool_intercepted_not_executed(self):
        """Submission tools should be intercepted, not passed to _execute_tool."""
        mock_provider = _make_mock_provider()

        first_response = _make_response(
            ["Here's the plan."],
            tool_calls=[ToolCall(name="submit_sprint_plan", input={"tasks": [{"description": "Build it", "assigned_to": "Cody"}]}, id="t1")],
            stop_reason="tool_use",
        )
        second_response = _make_response(["Done."])

        mock_provider.create_message.side_effect = [first_response, second_response]
        engine = AgentEngine(provider=mock_provider)

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="ok") as mock_exec:
            engine.invoke(
                persona=_lead_dev(),
                user_message="Plan the sprint",
                extra_tools=[SUBMIT_SPRINT_PLAN],
            )

        # _execute_tool should NOT have been called for the submission tool
        mock_exec.assert_not_called()

    def test_submission_data_stored(self):
        """Submission tool data should be stored on engine.submissions."""
        task_data = {"tasks": [{"description": "Build it", "assigned_to": "Cody"}]}
        mock_provider = _make_mock_provider()

        first_response = _make_response(
            ["Plan"],
            tool_calls=[ToolCall(name="submit_sprint_plan", input=task_data, id="t1")],
            stop_reason="tool_use",
        )
        second_response = _make_response(["Done."])

        mock_provider.create_message.side_effect = [first_response, second_response]
        engine = AgentEngine(provider=mock_provider)

        engine.invoke(
            persona=_lead_dev(),
            user_message="Plan",
            extra_tools=[SUBMIT_SPRINT_PLAN],
        )

        subs = engine.get_submissions()
        assert len(subs) == 1
        assert subs[0]["tool"] == "submit_sprint_plan"
        assert subs[0]["data"] == task_data

    def test_get_submissions_clears(self):
        """get_submissions should return and clear the list."""
        mock_provider = _make_mock_provider()
        engine = AgentEngine(provider=mock_provider)
        engine.submissions.append({"tool": "test", "data": {}})
        result = engine.get_submissions()
        assert len(result) == 1
        assert engine.submissions == []

    def test_regular_tool_still_executed(self):
        """Non-submission tools should still be executed normally."""
        mock_provider = _make_mock_provider()

        first_response = _make_response(
            ["Reading..."],
            tool_calls=[ToolCall(name="read_file", input={"path": "test.py"}, id="t1")],
            stop_reason="tool_use",
        )
        second_response = _make_response(["Done."])

        mock_provider.create_message.side_effect = [first_response, second_response]
        engine = AgentEngine(provider=mock_provider)

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="file content") as mock_exec:
            engine.invoke(
                persona=_lead_dev(),
                user_message="Read file",
                extra_tools=[SUBMIT_SPRINT_PLAN],
            )

        mock_exec.assert_called_once_with("read_file", {"path": "test.py"}, agent_name="Cody", sprint=None, cancel_check=None)

    def test_submission_and_regular_tool_in_same_response(self):
        """Both submission and regular tools can appear in the same response."""
        mock_provider = _make_mock_provider()

        first_response = _make_response(
            ["Planning..."],
            tool_calls=[
                ToolCall(name="read_file", input={"path": "x.py"}, id="t1"),
                ToolCall(name="submit_sprint_plan", input={"tasks": [{"description": "A", "assigned_to": "B"}]}, id="t2"),
            ],
            stop_reason="tool_use",
        )
        second_response = _make_response(["Done."])

        mock_provider.create_message.side_effect = [first_response, second_response]
        engine = AgentEngine(provider=mock_provider)

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="content"):
            engine.invoke(
                persona=_lead_dev(),
                user_message="Plan",
                extra_tools=[SUBMIT_SPRINT_PLAN],
            )

        assert len(engine.submissions) == 1
        assert engine.submissions[0]["tool"] == "submit_sprint_plan"


# ---------------------------------------------------------------------------
# Parsers: structured data path + string fallback
# ---------------------------------------------------------------------------

class TestParseTasksStructured:
    def test_structured_data_used(self):
        structured = {
            "tasks": [
                {"description": "Build API", "assigned_to": "Cody"},
                {"description": "Write tests", "assigned_to": "QA"},
            ]
        }
        tasks = parse_tasks("ignored text", sprint_number=1, structured_data=structured)
        assert len(tasks) == 2
        assert tasks[0].description == "Build API"
        assert tasks[0].assigned_to == "Cody"
        assert tasks[0].id == "s1_t1"
        assert tasks[1].id == "s1_t2"

    def test_string_fallback_when_no_structured(self):
        text = "TASK: Build it\nASSIGN: Lead Dev\n"
        tasks = parse_tasks(text, sprint_number=1, structured_data=None)
        assert len(tasks) == 1
        assert tasks[0].description == "Build it"

    def test_string_fallback_on_empty_structured(self):
        text = "TASK: Build it\nASSIGN: Lead Dev\n"
        tasks = parse_tasks(text, sprint_number=1, structured_data={"tasks": []})
        assert len(tasks) == 1
        assert tasks[0].description == "Build it"


class TestParseRoadmapStructured:
    def test_structured_data_used(self):
        structured = {
            "sprints": [
                {"number": 1, "deliverables": "Foundation", "is_milestone": True},
                {"number": 2, "deliverables": "Features", "is_milestone": False},
            ]
        }
        sprints = parse_roadmap("ignored", current_sprint=5, structured_data=structured)
        assert len(sprints) == 2
        assert sprints[0].number == 6  # 1 + 5
        assert sprints[0].deliverables == "Foundation"
        assert sprints[0].is_milestone is True
        assert sprints[1].number == 7

    def test_string_fallback(self):
        text = "SPRINT 1: Build base\nMILESTONE: yes\n"
        sprints = parse_roadmap(text, current_sprint=0, structured_data=None)
        assert len(sprints) == 1


class TestParseHireSuggestionsStructured:
    def test_structured_data_used(self):
        structured = {
            "suggestions": [
                {"description": "DB Expert", "model": "opus", "reasoning": "Complex schema"},
                {"description": "CSS Guru", "model": "haiku"},
            ]
        }
        results = parse_hire_suggestions("ignored", structured_data=structured)
        assert len(results) == 2
        assert results[0]["description"] == "DB Expert"
        assert results[0]["model"] == "opus"
        assert results[0]["reasoning"] == "Complex schema"
        assert results[1]["model"] == "haiku"
        assert results[1]["reasoning"] == ""

    def test_empty_suggestions_returns_empty(self):
        structured = {"suggestions": []}
        results = parse_hire_suggestions("HIRE: ignored", structured_data=structured)
        assert results == []

    def test_invalid_model_defaults_to_sonnet(self):
        structured = {"suggestions": [{"description": "Expert", "model": "gpt4"}]}
        results = parse_hire_suggestions("", structured_data=structured)
        assert results[0]["model"] == "sonnet"

    def test_string_fallback(self):
        text = "HIRE: DB Expert\nMODEL: opus - schema design\n"
        results = parse_hire_suggestions(text, structured_data=None)
        assert len(results) == 1


class TestParseCandidateStructured:
    def test_structured_data_used(self):
        structured = {
            "name": "Rex",
            "title": "Security Architect",
            "resume": "10 years of security experience...",
        }
        name, title, resume = parse_candidate("ignored", structured_data=structured)
        assert name == "Rex"
        assert title == "Security Architect"
        assert resume == "10 years of security experience..."

    def test_string_fallback(self):
        text = "NAME: Rex\nTITLE: Security Architect\nResume body..."
        name, title, resume = parse_candidate(text, structured_data=None)
        assert name == "Rex"
        assert title == "Security Architect"
        assert resume == text

    def test_structured_missing_resume_uses_text(self):
        structured = {"name": "Rex", "title": "Arch"}
        name, title, resume = parse_candidate("fallback text", structured_data=structured)
        assert name == "Rex"
        assert resume == "fallback text"


class TestParseConsultantSpecsStructured:
    def test_structured_data_used(self):
        structured = {
            "consultants": [
                {"name": "DB Expert", "job_description": "Database work", "model": "opus"},
                {"name": "CSS Guru", "job_description": "Styling"},
            ]
        }
        specs = parse_consultant_specs("ignored", structured_data=structured)
        assert len(specs) == 2
        assert specs[0] == ("DB Expert", "Database work", "opus")
        assert specs[1] == ("CSS Guru", "Styling", "sonnet")  # default model

    def test_string_fallback(self):
        text = "CONSULTANT: Expert\nJD: Do things\n"
        specs = parse_consultant_specs(text, structured_data=None)
        assert len(specs) == 1


class TestParseTesterSpecsStructured:
    def test_structured_data_used(self):
        structured = {
            "testers": [
                {"name": "Alice", "profile": "Designer", "instructions": "Test the UI"},
            ]
        }
        specs = parse_tester_specs("ignored", structured_data=structured)
        assert len(specs) == 1
        assert specs[0] == ("Alice", "Designer", "Test the UI")

    def test_string_fallback(self):
        text = "TESTER: Alice\nPROFILE: Designer\nINSTRUCTIONS: Test UI\n"
        specs = parse_tester_specs(text, structured_data=None)
        assert len(specs) == 1


# ---------------------------------------------------------------------------
# Wiring: sprint.py passes extra_tools and reads submissions
# ---------------------------------------------------------------------------

@pytest.fixture
def state(tmp_path):
    s = StateManager(tmp_path)
    config = ProjectConfig(name="TestProject", description="Testing")
    s.init(config)
    return s


@pytest.fixture
def team():
    return {
        "lead_dev": Persona(role_type=RoleType.LEAD_DEV, name="Cody", title="Lead Dev"),
        "qa": Persona(role_type=RoleType.QA, name="Vera", title="QA"),
        "recruiter": Persona(role_type=RoleType.RECRUITER, name="Scout", title="Recruiter"),
        "secretary": Persona(role_type=RoleType.SECRETARY, name="Paige", title="Secretary"),
    }


class TestSprintPlanSubmissionWiring:
    def test_plan_sprint_passes_extra_tools(self, state, team):
        mock_engine = MagicMock()
        mock_engine.invoke.return_value = "TASK: X\nASSIGN: Y\n"
        mock_engine.pop_submissions.return_value = []

        se = SprintEngine(mock_engine, state)
        se.planner.plan_sprint(team["lead_dev"], team["qa"], "Build it", 1)

        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["extra_tools"] == [SUBMIT_SPRINT_PLAN]

    def test_plan_sprint_uses_structured_submission(self, state, team):
        mock_engine = MagicMock()
        mock_engine.invoke.return_value = "Here's my plan..."
        mock_engine.submissions = [
            {"tool": "submit_sprint_plan", "data": {
                "tasks": [
                    {"description": "Build API", "assigned_to": "Cody"},
                    {"description": "Test API", "assigned_to": "Vera"},
                ],
            }},
        ]

        def _pop(tool_name):
            matched = [s for s in mock_engine.submissions if s["tool"] == tool_name]
            mock_engine.submissions = [s for s in mock_engine.submissions if s["tool"] != tool_name]
            return matched

        mock_engine.pop_submissions = _pop

        se = SprintEngine(mock_engine, state)
        sprint = se.planner.plan_sprint(team["lead_dev"], team["qa"], "Build it", 1)

        assert len(sprint.tasks) == 2
        assert sprint.tasks[0].description == "Build API"
        assert sprint.tasks[1].assigned_to == "Vera"


class TestSuggestHiresSubmissionWiring:
    def test_suggest_hires_passes_extra_tools(self, state, team):
        mock_engine = MagicMock()
        mock_engine.invoke.return_value = "NONE"
        mock_engine.pop_submissions.return_value = []

        se = SprintEngine(mock_engine, state)
        se.wrapup.suggest_hires(team["lead_dev"], "retro", team)

        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["extra_tools"] == [SUBMIT_HIRE_SUGGESTION]

    def test_suggest_hires_uses_structured_submission(self, state, team):
        mock_engine = MagicMock()
        mock_engine.invoke.return_value = "Some text"
        mock_engine.submissions = [
            {"tool": "submit_hire_suggestion", "data": {
                "suggestions": [
                    {"description": "DB Expert", "model": "opus", "reasoning": "Schema work"},
                ],
            }},
        ]

        def _pop(tool_name):
            matched = [s for s in mock_engine.submissions if s["tool"] == tool_name]
            mock_engine.submissions = [s for s in mock_engine.submissions if s["tool"] != tool_name]
            return matched

        mock_engine.pop_submissions = _pop

        se = SprintEngine(mock_engine, state)
        results = se.wrapup.suggest_hires(team["lead_dev"], "retro", team)

        assert len(results) == 1
        assert results[0]["description"] == "DB Expert"

    def test_suggest_hires_empty_structured_returns_empty(self, state, team):
        mock_engine = MagicMock()
        mock_engine.invoke.return_value = "Some text"
        mock_engine.submissions = [
            {"tool": "submit_hire_suggestion", "data": {"suggestions": []}},
        ]

        def _pop(tool_name):
            matched = [s for s in mock_engine.submissions if s["tool"] == tool_name]
            mock_engine.submissions = [s for s in mock_engine.submissions if s["tool"] != tool_name]
            return matched

        mock_engine.pop_submissions = _pop

        se = SprintEngine(mock_engine, state)
        results = se.wrapup.suggest_hires(team["lead_dev"], "retro", team)

        assert results == []


class TestRecruitConsultantSubmissionWiring:
    def test_recruit_passes_extra_tools(self):
        from odd.roles import recruit_consultant

        mock_engine = MagicMock()
        mock_engine.invoke.return_value = "NAME: Rex\nTITLE: Expert\nResume..."
        mock_engine.pop_submissions.return_value = []

        recruiter = Persona(
            role_type=RoleType.RECRUITER, name="Scout",
            title="Recruiter", job_description="Find talent",
        )
        recruit_consultant(mock_engine, recruiter, "Security expert needed")

        call_kwargs = mock_engine.invoke.call_args.kwargs
        assert call_kwargs["extra_tools"] == [SUBMIT_CANDIDATE]

    def test_recruit_uses_structured_submission(self):
        from odd.roles import recruit_consultant

        mock_engine = MagicMock()
        mock_engine.invoke.return_value = "Here's the candidate..."
        # First pop_submissions (recruit): structured candidate
        # Second pop_submissions (refinement): no update
        mock_engine.pop_submissions = MagicMock(side_effect=[
            [{"tool": "submit_candidate", "data": {
                "name": "Rex",
                "title": "Security Architect",
                "resume": "10 years in security...",
            }}],
            [],  # refinement - no improved resume
        ])

        recruiter = Persona(
            role_type=RoleType.RECRUITER, name="Scout",
            title="Recruiter", job_description="Find talent",
        )
        result = recruit_consultant(mock_engine, recruiter, "Security JD")

        assert result.name == "Rex"
        assert result.title == "Security Architect"
        assert result.resume == "10 years in security..."
