"""Architectural invariant tests - enforce structural rules beyond behavior.

These tests verify design decisions that prevent entire classes of bugs.
They complement test_isolation.py (which covers persona isolation) with
broader architectural constraints: import boundaries, immutability,
type safety, concurrency isolation, and phase ordering.
"""

from __future__ import annotations

import ast
import copy
import importlib
import sys
import threading
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from odd.agent import AgentEngine, build_system_prompt
from odd.models import ModelTier, Persona, RoleType
from odd.provider import AgentResponse, Usage


SRC_DIR = Path(__file__).resolve().parent.parent / "src" / "odd"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_engine() -> AgentEngine:
    provider = MagicMock()
    provider.create_message.return_value = AgentResponse(
        text_blocks=["OK"],
        tool_calls=[],
        stop_reason="end_turn",
        usage=Usage(input_tokens=10, output_tokens=5),
    )
    return AgentEngine(provider=provider)


def _persona(role: RoleType = RoleType.LEAD_DEV, name: str = "Agent") -> Persona:
    return Persona(
        role_type=role,
        name=name,
        title=name,
        job_description="test",
        resume="test",
    )


# ---------------------------------------------------------------------------
# 1. SDK import containment - core modules never import SDK packages
# ---------------------------------------------------------------------------

class TestSDKImportContainment:
    """Core modules must only reach LLM SDKs through the Provider protocol.

    If agent.py, sprint/, or tools/ import anthropic or openai directly,
    the Provider abstraction boundary is violated.
    """

    # Modules that must NEVER import SDK packages directly
    CORE_MODULES = [
        "agent.py",
        "middleware.py",
        "models.py",
        "config.py",
        "sprint/engine.py",
        "sprint/phase_runner.py",
        "sprint/planner.py",
        "sprint/tdd_gate.py",
        "sprint/briefing.py",
        "sprint/standup.py",
        "tools/__init__.py",
        "tools/definitions.py",
        "tools/execution.py",
        "tools/schemas.py",
    ]

    # SDK packages that should only appear in providers/
    SDK_PACKAGES = {"anthropic", "openai"}

    @pytest.mark.parametrize("module_path", CORE_MODULES)
    def test_no_direct_sdk_import(self, module_path: str):
        """Core module must not import SDK packages directly."""
        source = (SRC_DIR / module_path).read_text(encoding="utf-8")
        tree = ast.parse(source)

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root_pkg = alias.name.split(".")[0]
                    assert root_pkg not in self.SDK_PACKAGES, (
                        f"{module_path} directly imports '{alias.name}' — "
                        f"SDK access must go through the Provider protocol"
                    )
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    root_pkg = node.module.split(".")[0]
                    assert root_pkg not in self.SDK_PACKAGES, (
                        f"{module_path} imports from '{node.module}' — "
                        f"SDK access must go through the Provider protocol"
                    )


# ---------------------------------------------------------------------------
# 2. Conversation history immutability
# ---------------------------------------------------------------------------

class TestConversationHistoryImmutability:
    """Passing conversation_history to invoke() must not mutate the caller's list."""

    def test_invoke_does_not_mutate_history(self):
        """The history list passed in must be identical after invoke returns."""
        engine = _make_engine()
        persona = _persona()
        history = [
            {"role": "user", "content": "prior question"},
            {"role": "assistant", "content": "prior answer"},
        ]
        snapshot = copy.deepcopy(history)

        engine.invoke(persona, "Follow-up", conversation_history=history)

        assert history == snapshot, (
            "invoke() mutated the caller's conversation_history list"
        )

    def test_invoke_does_not_mutate_history_dicts(self):
        """Individual message dicts inside history must not be modified."""
        engine = _make_engine()
        persona = _persona()
        history = [
            {"role": "user", "content": "original"},
        ]
        original_dict_id = id(history[0])
        original_content = history[0]["content"]

        engine.invoke(persona, "New message", conversation_history=history)

        assert history[0]["content"] == original_content, (
            "invoke() modified a dict inside the caller's conversation_history"
        )


# ---------------------------------------------------------------------------
# 3. Tool results are always strings
# ---------------------------------------------------------------------------

class TestToolResultsAreStrings:
    """execute_tool must always return a plain string, never provider-specific types."""

    def test_known_tools_return_strings(self, tmp_path: Path):
        """Every supported tool returns a str result."""
        from odd.tools.execution import execute_tool

        # Create a test file so read_file has something to read
        test_file = tmp_path / "hello.txt"
        test_file.write_text("hello world", encoding="utf-8")

        cases = [
            ("read_file", {"path": "hello.txt"}),
            ("write_file", {"path": "output.txt", "content": "test"}),
            ("list_directory", {"path": "."}),
            ("edit_file", {"path": "hello.txt", "old_string": "hello", "new_string": "goodbye"}),
        ]

        for tool_name, tool_input in cases:
            result = execute_tool(tool_name, tool_input, cwd=tmp_path, agent_name="test")
            assert isinstance(result, str), (
                f"execute_tool('{tool_name}') returned {type(result).__name__}, "
                f"expected str"
            )

    def test_unknown_tool_returns_string(self):
        """Even unknown tool names must return a string error, not raise."""
        from odd.tools.execution import execute_tool

        result = execute_tool("nonexistent_tool", {}, agent_name="test")
        assert isinstance(result, str)
        assert "Error" in result or "Unknown" in result

    def test_tool_error_returns_string(self, tmp_path: Path):
        """Tool errors (e.g. file not found) must return a string, not raise."""
        from odd.tools.execution import execute_tool

        result = execute_tool(
            "read_file", {"path": "does_not_exist.txt"},
            cwd=tmp_path, agent_name="test",
        )
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# 4. Wire format stays in providers/
# ---------------------------------------------------------------------------

class TestWireFormatContainment:
    """SDK-specific types must only appear in providers/ files.

    Types like anthropic.types.ContentBlock or openai ChatCompletionMessage
    must never leak into core code.
    """

    # Modules outside providers/ that must not reference wire types
    CORE_MODULES = [
        "agent.py",
        "middleware.py",
        "sprint/engine.py",
        "sprint/phase_runner.py",
        "fallback/runner.py",
        "tools/execution.py",
    ]

    # Strings that indicate SDK wire format types in source code
    WIRE_FORMAT_MARKERS = [
        "ContentBlock",
        "TextBlock",
        "ToolUseBlock",
        "ToolResultBlock",
        "ChatCompletionMessage",
        "ChatCompletionMessageToolCall",
        "FunctionCall",
    ]

    @pytest.mark.parametrize("module_path", CORE_MODULES)
    def test_no_wire_format_types(self, module_path: str):
        """Core module must not reference SDK wire format types."""
        source = (SRC_DIR / module_path).read_text(encoding="utf-8")

        for marker in self.WIRE_FORMAT_MARKERS:
            assert marker not in source, (
                f"{module_path} references '{marker}' — "
                f"SDK wire format types must stay inside providers/"
            )


# ---------------------------------------------------------------------------
# 5. DirectRunner freshness - no cached/pooled runners
# ---------------------------------------------------------------------------

class TestDirectRunnerFreshness:
    """Each invoke() must create a fresh DirectRunner, not reuse/pool them."""

    def test_invoke_creates_new_runner_each_call(self):
        """Successive invoke() calls must create distinct DirectRunner instances."""
        engine = _make_engine()
        persona = _persona()
        runners_seen: list[int] = []

        # Patch DirectRunner.__init__ to track instances
        from odd.fallback.runner import DirectRunner
        original_init = DirectRunner.__init__

        def tracking_init(self_runner, *args, **kwargs):
            runners_seen.append(id(self_runner))
            original_init(self_runner, *args, **kwargs)

        DirectRunner.__init__ = tracking_init
        try:
            engine.invoke(persona, "Task 1")
            engine.invoke(persona, "Task 2")
        finally:
            DirectRunner.__init__ = original_init

        assert len(runners_seen) == 2, (
            f"Expected 2 DirectRunner instances, got {len(runners_seen)}"
        )
        assert runners_seen[0] != runners_seen[1], (
            "invoke() reused the same DirectRunner instance"
        )

    def test_no_lru_cache_on_runner_creation(self):
        """agent.py must not cache DirectRunner creation."""
        source = (SRC_DIR / "agent.py").read_text(encoding="utf-8")
        assert "lru_cache" not in source, (
            "agent.py uses lru_cache — DirectRunner must be created fresh each invoke()"
        )
        assert "functools.cache" not in source, (
            "agent.py uses functools.cache — DirectRunner must be created fresh"
        )

    def test_runner_not_stored_on_engine(self):
        """AgentEngine must not store a DirectRunner as an instance attribute."""
        source = (SRC_DIR / "agent.py").read_text(encoding="utf-8")
        tree = ast.parse(source)

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "__init__":
                # Check if we're inside the AgentEngine class
                # by looking for self.runner or self._runner assignments
                for stmt in ast.walk(node):
                    if isinstance(stmt, ast.Assign):
                        for target in stmt.targets:
                            if (
                                isinstance(target, ast.Attribute)
                                and isinstance(target.value, ast.Name)
                                and target.value.id == "self"
                                and "runner" in target.attr.lower()
                            ):
                                pytest.fail(
                                    f"AgentEngine.__init__ stores self.{target.attr} — "
                                    f"runners must be created fresh per invoke()"
                                )


# ---------------------------------------------------------------------------
# 6. Config immutability - constants must not be mutated at runtime
# ---------------------------------------------------------------------------

class TestConfigImmutability:
    """Config constants must not be silently mutable in ways that affect all agents."""

    def test_model_tiers_are_frozen(self):
        """ModelTier enum values must not be reassignable."""
        original = ModelTier.HIGH.value
        with pytest.raises((AttributeError, TypeError)):
            ModelTier.HIGH.value = "fast"
        # Even if the assignment doesn't raise, verify value unchanged
        assert ModelTier.HIGH.value == original

    def test_role_types_are_frozen(self):
        """RoleType enum values must not be reassignable."""
        original = RoleType.LEAD_DEV.value
        with pytest.raises((AttributeError, TypeError)):
            RoleType.LEAD_DEV.value = "intern"
        assert RoleType.LEAD_DEV.value == original

    def test_tool_definitions_not_shared_by_reference(self):
        """TOOL_DEFINITIONS must be copied before use, not passed by reference.

        If multiple agents share the same list object, one agent's extra_tools
        could pollute another's.
        """
        from odd.tools import TOOL_DEFINITIONS

        engine = _make_engine()
        persona = _persona()

        engine.invoke(persona, "Task 1", extra_tools=[{
            "name": "custom_tool",
            "description": "test",
            "parameters": {"type": "object", "properties": {}},
        }])

        # TOOL_DEFINITIONS must not have been modified
        tool_names = [t["name"] for t in TOOL_DEFINITIONS]
        assert "custom_tool" not in tool_names, (
            "extra_tools polluted the shared TOOL_DEFINITIONS list"
        )

    def test_default_pricing_not_mutated(self):
        """Mutating the returned pricing dict must not affect the defaults."""
        from odd.config import _DEFAULT_PRICING, load_pricing

        snapshot = {k: dict(v) for k, v in _DEFAULT_PRICING.items()}
        pricing = load_pricing(odd_dir=None)
        # Mutate the returned dict
        for model in pricing:
            pricing[model]["input"] = 999.99
            break
        # Defaults must be untouched
        assert _DEFAULT_PRICING == snapshot, (
            "Mutating load_pricing() return value affected _DEFAULT_PRICING"
        )


# ---------------------------------------------------------------------------
# 7. Concurrent engine isolation
# ---------------------------------------------------------------------------

class TestConcurrentEngineIsolation:
    """Forked engines running concurrently must not share escalation/submission state."""

    def test_concurrent_forks_isolated_escalations(self):
        """Escalations appended in one fork must not appear in another."""
        engine = _make_engine()
        fork_a = engine.fork()
        fork_b = engine.fork()

        errors: list[str] = []

        def worker_a():
            fork_a.escalations.append({"reason": "from A", "severity": "heads_up"})
            if any(e["reason"] == "from B" for e in fork_a.escalations):
                errors.append("Fork A saw Fork B's escalation")

        def worker_b():
            fork_b.escalations.append({"reason": "from B", "severity": "heads_up"})
            if any(e["reason"] == "from A" for e in fork_b.escalations):
                errors.append("Fork B saw Fork A's escalation")

        t_a = threading.Thread(target=worker_a)
        t_b = threading.Thread(target=worker_b)
        t_a.start()
        t_b.start()
        t_a.join()
        t_b.join()

        assert not errors, errors
        assert len(fork_a.escalations) == 1
        assert len(fork_b.escalations) == 1
        assert fork_a.escalations[0]["reason"] == "from A"
        assert fork_b.escalations[0]["reason"] == "from B"

    def test_concurrent_forks_isolated_submissions(self):
        """Submissions appended in one fork must not appear in another."""
        engine = _make_engine()
        fork_a = engine.fork()
        fork_b = engine.fork()

        def worker_a():
            fork_a.submissions.append({"tool": "from_a", "data": {}})

        def worker_b():
            fork_b.submissions.append({"tool": "from_b", "data": {}})

        t_a = threading.Thread(target=worker_a)
        t_b = threading.Thread(target=worker_b)
        t_a.start()
        t_b.start()
        t_a.join()
        t_b.join()

        assert len(fork_a.submissions) == 1
        assert len(fork_b.submissions) == 1
        assert fork_a.submissions[0]["tool"] == "from_a"
        assert fork_b.submissions[0]["tool"] == "from_b"

    def test_parent_engine_unaffected_by_forks(self):
        """Escalations/submissions on forks must not appear on the parent."""
        engine = _make_engine()
        fork = engine.fork()

        fork.escalations.append({"reason": "fork only", "severity": "heads_up"})
        fork.submissions.append({"tool": "fork_tool", "data": {}})

        assert len(engine.escalations) == 0
        assert len(engine.submissions) == 0


# ---------------------------------------------------------------------------
# 8. Sprint phase ordering - QA before implementation
# ---------------------------------------------------------------------------

class TestSprintPhaseOrdering:
    """The sprint lifecycle must run QA (test-writing) before implementation.

    This is the TDD-as-quality-gate invariant: tests are written first,
    then agents implement to pass them. The architectural test verifies
    this ordering is enforced in the code structure, not just by convention.
    """

    def test_run_sprint_calls_qa_before_implementation(self):
        """run_sprint must call run_qa_phase before run_implementation_phases."""
        source = (SRC_DIR / "sprint" / "engine.py").read_text(encoding="utf-8")
        tree = ast.parse(source)

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "run_sprint":
                # Collect method call names in order
                call_order: list[str] = []
                for child in ast.walk(node):
                    if isinstance(child, ast.Call):
                        if isinstance(child.func, ast.Attribute):
                            call_order.append(child.func.attr)

                assert "run_qa_phase" in call_order, (
                    "run_sprint does not call run_qa_phase"
                )
                assert "run_implementation_phases" in call_order, (
                    "run_sprint does not call run_implementation_phases"
                )

                qa_idx = call_order.index("run_qa_phase")
                impl_idx = call_order.index("run_implementation_phases")
                assert qa_idx < impl_idx, (
                    f"run_sprint calls run_implementation_phases (index {impl_idx}) "
                    f"BEFORE run_qa_phase (index {qa_idx}) — TDD requires tests first"
                )
                break
        else:
            pytest.fail("Could not find run_sprint method in sprint/engine.py")

    def test_qa_checkpoint_saved_before_implementation(self):
        """run_sprint must save a QA checkpoint between QA and implementation."""
        source = (SRC_DIR / "sprint" / "engine.py").read_text(encoding="utf-8")
        tree = ast.parse(source)

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "run_sprint":
                # Walk the function body in order to find the sequence:
                # 1. run_qa_phase
                # 2. save_sprint (checkpoint)
                # 3. run_implementation_phases
                body_calls: list[str] = []
                for stmt in ast.walk(node):
                    if isinstance(stmt, ast.Call) and isinstance(stmt.func, ast.Attribute):
                        body_calls.append(stmt.func.attr)

                assert "run_qa_phase" in body_calls
                assert "save_sprint" in body_calls
                assert "run_implementation_phases" in body_calls

                qa_idx = body_calls.index("run_qa_phase")
                # Find the first save_sprint AFTER qa
                save_indices = [
                    i for i, c in enumerate(body_calls)
                    if c == "save_sprint" and i > qa_idx
                ]
                assert save_indices, (
                    "No save_sprint call found after run_qa_phase"
                )
                impl_idx = body_calls.index("run_implementation_phases")
                assert save_indices[0] < impl_idx, (
                    "save_sprint (QA checkpoint) must happen before "
                    "run_implementation_phases"
                )
                break

    def test_resume_does_not_skip_qa(self):
        """resume_sprint must not skip QA phase — if QA hasn't run, restart from QA."""
        source = (SRC_DIR / "sprint" / "engine.py").read_text(encoding="utf-8")
        tree = ast.parse(source)

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "resume_sprint":
                # The function should handle the "planning" checkpoint by
                # calling run_sprint (which includes QA), not by jumping
                # straight to implementation
                source_lines = ast.get_source_segment(source, node) or ""
                # Verify that when checkpoint.stage == "planning", it calls run_sprint
                assert "run_sprint" in source_lines, (
                    "resume_sprint must call run_sprint for incomplete QA, "
                    "not skip directly to implementation"
                )
                break
        else:
            pytest.fail("Could not find resume_sprint method in sprint/engine.py")


# ---------------------------------------------------------------------------
# File size limits
# ---------------------------------------------------------------------------

class TestFileSizeLimits:
    """No source file should exceed 1000 lines.

    Large files become hard to navigate and review. When a file approaches
    this limit it's a signal to extract a collaborator.
    """

    MAX_LINES = 1000

    def test_no_source_file_exceeds_max_lines(self):
        for py_file in SRC_DIR.rglob("*.py"):
            lines = py_file.read_text(encoding="utf-8").splitlines()
            assert len(lines) <= self.MAX_LINES, (
                f"{py_file.relative_to(SRC_DIR.parent.parent)} is {len(lines)} lines "
                f"(max {self.MAX_LINES})"
            )
