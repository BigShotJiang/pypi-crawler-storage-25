"""Tests for Phase 7 - War Room Integration.

Covers:
- 7a: Agent loop cancellation checkpoint
- 7b: AgentOutputStream wired into sprint engine parallel tasks
- 7c: CEO style controls War Room / progress bar / none
- 7d: End-to-end integration of War Room + sprint engine
"""

import threading
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from odd.agent import (
    AgentEngine,
    AgentKilledError,
)
from odd.display import AgentOutputStream, AgentStatus, WarRoom
from odd.models import (
    CEOGate,
    CEOStyle,
    Persona,
    ProjectConfig,
    RoleType,
    Sprint,
    SprintStatus,
    SprintTask,
)
from odd.provider import AgentResponse, StreamEvent, StreamEventType, ToolCall, Usage
from odd.sprint import SprintEngine
from odd.state import StateManager


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_response(text_blocks=None, tool_calls=None, stop_reason="end_turn",
                   input_tokens=100, output_tokens=50):
    return AgentResponse(
        text_blocks=text_blocks or [],
        tool_calls=tool_calls or [],
        stop_reason=stop_reason,
        usage=Usage(input_tokens=input_tokens, output_tokens=output_tokens),
    )


def _lead_dev():
    return Persona(
        role_type=RoleType.LEAD_DEV,
        name="Lead Developer",
        title="Lead Developer",
        job_description="Build things",
    )


# ---------------------------------------------------------------------------
# 7a - Agent loop cancellation checkpoint
# ---------------------------------------------------------------------------


class TestAgentCancellation:
    """Verify that cancel_check aborts the agent loop between tool calls."""

    def test_cancel_check_raises_agent_killed_error(self):
        """When cancel_check returns True after tool call, AgentKilledError is raised."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        # First response: tool use (triggers cancel check)
        first_response = _make_response(
            text_blocks=["Working..."],
            tool_calls=[ToolCall(name="read_file", input={"path": "/tmp/x"}, id="t1")],
            stop_reason="tool_use",
        )
        mock_provider.create_message.return_value = first_response
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="ok"):
            with pytest.raises(AgentKilledError, match="cancelled"):
                engine.invoke(
                    persona=_lead_dev(),
                    user_message="Do something",
                    cancel_check=lambda: True,  # always cancelled
                )

    def test_cancel_between_tools_in_batch(self):
        """Cancel is checked between each tool in a multi-tool batch.

        With 3 tool calls and cancel set after the 1st executes, only 1
        tool should run — the check fires before tool 2 starts.
        """
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        first_response = _make_response(
            text_blocks=["Working..."],
            tool_calls=[
                ToolCall(name="read_file", input={"path": "/a"}, id="t1"),
                ToolCall(name="read_file", input={"path": "/b"}, id="t2"),
                ToolCall(name="read_file", input={"path": "/c"}, id="t3"),
            ],
            stop_reason="tool_use",
        )
        mock_provider.create_message.return_value = first_response

        exec_count = [0]
        cancelled = [False]

        def mock_execute(tool_name, tool_input, *, agent_name, sprint=None, cancel_check=None):
            exec_count[0] += 1
            cancelled[0] = True  # cancel after every execution
            return "ok"

        with patch("odd.fallback.runner.DirectRunner._execute_tool", side_effect=mock_execute):
            with pytest.raises(AgentKilledError, match="cancelled"):
                engine.invoke(
                    persona=_lead_dev(),
                    user_message="Do three things",
                    cancel_check=lambda: cancelled[0],
                )

        # Only 1 tool executed; cancel caught before tool 2
        assert exec_count[0] == 1

    def test_cancel_during_command_raises_killed(self):
        """Cancel during a run_command subprocess raises AgentKilledError."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        first_response = _make_response(
            text_blocks=["Running..."],
            tool_calls=[ToolCall(name="run_command", input={"command": "echo hi"}, id="t1")],
            stop_reason="tool_use",
        )
        mock_provider.create_message.return_value = first_response

        # Simulate _CancelledDuringTool from tool execution layer
        from odd.tools.execution import _CancelledDuringTool

        def raise_cancelled(*args, **kwargs):
            raise _CancelledDuringTool("cancelled mid-command")

        with patch("odd.fallback.runner.DirectRunner._execute_tool", side_effect=raise_cancelled):
            with pytest.raises(AgentKilledError, match="cancelled"):
                engine.invoke(
                    persona=_lead_dev(),
                    user_message="Run something",
                    cancel_check=lambda: True,
                )

    def test_cancel_check_not_called_without_tool_use(self):
        """cancel_check is not checked when agent returns without tool use."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        mock_provider.create_message.return_value = _make_response(
            text_blocks=["Done!"],
        )

        check_calls = []
        result = engine.invoke(
            persona=_lead_dev(),
            user_message="Hi",
            cancel_check=lambda: (check_calls.append(1) or False),
        )
        assert result == "Done!"
        assert len(check_calls) == 0  # no tool use, no check

    def test_cancel_check_false_allows_continuation(self):
        """When cancel_check returns False, agent loop continues normally."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        first = _make_response(
            text_blocks=["step 1"],
            tool_calls=[ToolCall(name="read_file", input={"path": "/x"}, id="t1")],
            stop_reason="tool_use",
        )
        second = _make_response(text_blocks=["step 2"])
        mock_provider.create_message.side_effect = [first, second]
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="ok"):
            result = engine.invoke(
                persona=_lead_dev(),
                user_message="Go",
                cancel_check=lambda: False,
            )
        assert "step 2" in result

    def test_agent_killed_error_is_exception(self):
        assert issubclass(AgentKilledError, Exception)

    def test_cancel_via_agent_output_stream(self):
        """AgentOutputStream.cancelled integrates as cancel_check."""
        mock_provider = MagicMock()
        engine = AgentEngine(provider=mock_provider)

        stream = AgentOutputStream("Dev")

        first = _make_response(
            text_blocks=["Working"],
            tool_calls=[ToolCall(name="read_file", input={"path": "/x"}, id="t1")],
            stop_reason="tool_use",
        )
        mock_provider.create_message.return_value = first
        mock_provider.wrap_tool_results.return_value = (
            {"role": "assistant", "content": []},
            {"role": "user", "content": []},
        )

        # Cancel the stream before invoke
        stream.cancel()

        with patch("odd.fallback.runner.DirectRunner._execute_tool", return_value="ok"):
            with pytest.raises(AgentKilledError):
                engine.invoke(
                    persona=_lead_dev(),
                    user_message="Go",
                    cancel_check=lambda: stream.cancelled,
                )

        assert stream.status == AgentStatus.KILLED


# ---------------------------------------------------------------------------
# 7b - War Room callback creation
# ---------------------------------------------------------------------------


@pytest.fixture
def state(tmp_path):
    s = StateManager(tmp_path)
    config = ProjectConfig(name="TestProject", description="Testing")
    s.init(config)
    return s


@pytest.fixture
def mock_engine():
    engine = MagicMock()
    engine.invoke.return_value = "Mock response"
    engine.get_escalations.return_value = []
    engine.pop_submissions.return_value = []
    engine.fork.return_value = engine
    return engine


class TestMakeWarRoomCallback:
    """Test _make_war_room_callback creates correct callbacks per CEO style."""

    def _make_sprint_engine(self, state, mock_engine, style=CEOStyle.HANDS_ON):
        with patch.object(type(state), "load_config", return_value=ProjectConfig(
            name="Test", description="Test", ceo_style=style,
        )):
            return SprintEngine(
                engine=mock_engine,
                state=state,
                streaming=True,
            )

    def test_hands_on_returns_full_callback(self, state, mock_engine):
        se = self._make_sprint_engine(state, mock_engine, CEOStyle.HANDS_ON)
        stream = AgentOutputStream("Dev")
        cb = se._make_war_room_callback(stream)
        assert cb is not None

        # Full streaming: TEXT_DELTA populates buffer
        cb(StreamEvent(event_type=StreamEventType.TEXT_DELTA, text="hello\n"))
        assert stream.full() == ["hello"]

    def test_balanced_returns_summary_callback(self, state, mock_engine):
        se = self._make_sprint_engine(state, mock_engine, CEOStyle.BALANCED)
        stream = AgentOutputStream("Dev")
        cb = se._make_war_room_callback(stream)
        assert cb is not None

        # Summary mode: TEXT_DELTA is ignored
        cb(StreamEvent(event_type=StreamEventType.TEXT_DELTA, text="hello\n"))
        assert stream.full() == []

        # BALANCED stream callback handles MESSAGE_STOP (flush) but not
        # TOOL_USE_END - tool activity now comes from on_tool_result instead.
        cb(StreamEvent(event_type=StreamEventType.MESSAGE_STOP))
        # Nothing to flush since no text was appended
        assert stream.full() == []

    def test_balanced_tool_result_callback(self, state, mock_engine):
        """BALANCED mode: tool results surface in the War Room via on_tool_result."""
        se = self._make_sprint_engine(state, mock_engine, CEOStyle.BALANCED)
        stream = AgentOutputStream("Dev")
        tool_cb = se._make_tool_result_callback(stream)
        assert tool_cb is not None

        # Simulate a successful write_file execution result
        tool_cb("write_file", {"path": "src/main.py", "content": "x = 1"}, "Successfully wrote 5 characters to 'src/main.py'.")
        stream.flush()
        log = stream.full()
        assert any("Write" in line and "src/main.py" in line for line in log)

        # Simulate a successful read_file
        tool_cb("read_file", {"path": "src/utils.py"}, "contents here")
        stream.flush()
        log = stream.full()
        assert any("Read" in line and "src/utils.py" in line for line in log)

    def test_delegator_returns_none(self, state, mock_engine):
        se = self._make_sprint_engine(state, mock_engine, CEOStyle.DELEGATOR)
        stream = AgentOutputStream("Dev")
        cb = se._make_war_room_callback(stream)
        assert cb is None


# ---------------------------------------------------------------------------
# 7c - CEO style determines War Room visibility
# ---------------------------------------------------------------------------


class TestCEOStyleWarRoom:
    """Verify that _run_phase_parallel uses War Room, progress bar, or nothing."""

    def _make_sprint_engine(self, state, mock_engine, style=CEOStyle.HANDS_ON):
        with patch.object(type(state), "load_config", return_value=ProjectConfig(
            name="Test", description="Test", ceo_style=style,
        )):
            return SprintEngine(
                engine=mock_engine,
                state=state,
                streaming=True,
            )

    def test_hands_on_uses_war_room(self, state, mock_engine):
        se = self._make_sprint_engine(state, mock_engine, CEOStyle.HANDS_ON)
        assert se.gate(CEOGate.WAR_ROOM) == CEOStyle.HANDS_ON
        # War Room should be used when not DELEGATOR and streaming is on
        use_war_room = se.gate(CEOGate.WAR_ROOM) != CEOStyle.DELEGATOR and se.streaming
        assert use_war_room is True

    def test_balanced_uses_war_room(self, state, mock_engine):
        se = self._make_sprint_engine(state, mock_engine, CEOStyle.BALANCED)
        use_war_room = se.gate(CEOGate.WAR_ROOM) != CEOStyle.DELEGATOR and se.streaming
        assert use_war_room is True

    def test_delegator_no_war_room(self, state, mock_engine):
        se = self._make_sprint_engine(state, mock_engine, CEOStyle.DELEGATOR)
        use_war_room = se.gate(CEOGate.WAR_ROOM) != CEOStyle.DELEGATOR and se.streaming
        assert use_war_room is False

    def test_streaming_off_no_war_room(self, state, mock_engine):
        with patch.object(type(state), "load_config", return_value=ProjectConfig(
            name="Test", description="Test", ceo_style=CEOStyle.HANDS_ON,
        )):
            se = SprintEngine(
                engine=mock_engine,
                state=state,
                streaming=False,
            )
        use_war_room = se.gate(CEOGate.WAR_ROOM) != CEOStyle.DELEGATOR and se.streaming
        assert use_war_room is False


# ---------------------------------------------------------------------------
# 7d - Integration: War Room lifecycle with agent streams
# ---------------------------------------------------------------------------


class TestWarRoomLifecycle:
    """Test that War Room starts, receives stream updates, and stops cleanly."""

    def test_war_room_tracks_agent_completion(self):
        """War Room reflects stream status changes from agent execution."""
        streams = [AgentOutputStream("Dev1"), AgentOutputStream("Dev2")]
        for s in streams:
            s.status = AgentStatus.WORKING

        wr = WarRoom(streams)
        assert wr.is_running is False

        # Simulate agent completion
        streams[0].status = AgentStatus.DONE
        streams[0].append("All done\n")

        assert streams[0].status == AgentStatus.DONE
        assert streams[1].status == AgentStatus.WORKING

    def test_war_room_kill_sets_cancelled_and_status(self):
        """Killing an agent via War Room sets cancelled flag for cancel_check."""
        stream = AgentOutputStream("Dev")
        stream.status = AgentStatus.WORKING
        wr = WarRoom([stream])

        wr.kill(stream)

        assert stream.cancelled is True
        assert stream.status == AgentStatus.KILLED

    def test_war_room_context_manager_cleans_up(self):
        """War Room cleans up Live display on exit, even after exceptions."""
        streams = [AgentOutputStream("Dev")]
        try:
            with WarRoom(streams) as wr:
                assert wr.is_running
                raise ValueError("simulated error")
        except ValueError:
            pass
        assert wr.is_running is False

    def test_stream_callback_feeds_war_room_display(self):
        """AgentOutputStream.as_stream_callback() bridges text events to War Room.

        Tool calls are NOT shown via the stream callback - they come
        through on_tool_result with ✓/✗ status instead.
        """
        stream = AgentOutputStream("Dev")
        cb = stream.as_stream_callback()

        # Simulate streaming events
        cb(StreamEvent(event_type=StreamEventType.TEXT_DELTA, text="Hello "))
        cb(StreamEvent(event_type=StreamEventType.TEXT_DELTA, text="world\n"))
        tc = ToolCall(name="Write", input={"file_path": "out.py", "content": "x"}, id="t1")
        cb(StreamEvent(event_type=StreamEventType.TOOL_USE_END, tool_call=tc))
        cb(StreamEvent(event_type=StreamEventType.MESSAGE_STOP))

        log = stream.full()
        assert "Hello world" in log[0]
        # Tool call should NOT appear - it comes via on_tool_result instead
        assert not any("Write" in line and "out.py" in line for line in log)

    def test_multiple_streams_independent(self):
        """Multiple AgentOutputStreams don't cross-contaminate."""
        s1 = AgentOutputStream("Dev1")
        s2 = AgentOutputStream("Dev2")

        s1.append("from dev1\n")
        s2.append("from dev2\n")

        assert "from dev1" in s1.full()[0]
        assert "from dev2" in s2.full()[0]
        assert "dev2" not in " ".join(s1.full())
        assert "dev1" not in " ".join(s2.full())

    def test_cancelled_stream_as_cancel_check(self):
        """A cancelled stream's .cancelled property works as cancel_check lambda."""
        stream = AgentOutputStream("Dev")
        cancel_fn = lambda: stream.cancelled

        assert cancel_fn() is False
        stream.cancel()
        assert cancel_fn() is True

    def test_war_room_kill_all_during_execution(self):
        """kill_all cancels all working agents, skips done ones."""
        working = [AgentOutputStream(f"W{i}") for i in range(3)]
        done = AgentOutputStream("D1")
        done.status = AgentStatus.DONE

        for s in working:
            s.status = AgentStatus.WORKING

        all_streams = working + [done]
        wr = WarRoom(all_streams)
        wr.kill_all()

        for s in working:
            assert s.cancelled is True
            assert s.status == AgentStatus.KILLED
        assert done.cancelled is False
        assert done.status == AgentStatus.DONE


class TestWarRoomWithThreads:
    """Verify thread safety of War Room + AgentOutputStream under concurrency."""

    def test_concurrent_stream_writes(self):
        """Multiple threads writing to separate streams don't crash."""
        streams = [AgentOutputStream(f"Agent{i}") for i in range(4)]

        def writer(stream, n):
            for i in range(50):
                stream.append(f"line {i}\n")
            stream.flush()
            stream.status = AgentStatus.DONE

        threads = [
            threading.Thread(target=writer, args=(s, i))
            for i, s in enumerate(streams)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        for s in streams:
            assert s.status == AgentStatus.DONE
            assert len(s.full()) == 50

    def test_concurrent_write_and_cancel(self):
        """Cancelling a stream while it's being written to is safe."""
        stream = AgentOutputStream("Dev")
        stream.status = AgentStatus.WORKING

        def writer():
            for i in range(100):
                stream.append(f"line {i}\n")
                if stream.cancelled:
                    break

        t = threading.Thread(target=writer)
        t.start()
        # Cancel midway
        stream.cancel()
        t.join()

        assert stream.cancelled is True
        assert stream.status == AgentStatus.KILLED
