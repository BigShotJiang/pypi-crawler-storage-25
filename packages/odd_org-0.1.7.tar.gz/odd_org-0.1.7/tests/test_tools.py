"""Tests for odd.tools - file ops, shell execution, escalation handling."""

import os

import pytest

from odd.tools import TOOL_DEFINITIONS
from odd.tools.execution import (
    _check_command_team_access,
    _check_team_path_access,
    _sanitize_error,
    _validate_command,
    execute_tool,
)
from odd.tools.isolation import (
    check_cp_mv_paths,
    check_find_dangerous_flags,
    check_shell_metacharacters,
)



# ---------------------------------------------------------------------------
# TOOL_DEFINITIONS
# ---------------------------------------------------------------------------

class TestToolDefinitions:
    def test_all_tools_present(self):
        names = {t["name"] for t in TOOL_DEFINITIONS}
        assert names == {"read_file", "write_file", "edit_file", "list_directory", "run_command", "escalate", "request_command"}

    def test_each_tool_has_parameters(self):
        for tool in TOOL_DEFINITIONS:
            assert "parameters" in tool
            assert tool["parameters"]["type"] == "object"


# ---------------------------------------------------------------------------
# File Operations (using tmp_path)
# ---------------------------------------------------------------------------

class TestReadFile:
    def test_read_existing_file(self, tmp_path):
        f = tmp_path / "hello.txt"
        f.write_text("Hello, world!", encoding="utf-8")
        result = execute_tool("read_file", {"path": "hello.txt"}, cwd=tmp_path)
        assert result == "Hello, world!"

    def test_read_nonexistent(self, tmp_path):
        result = execute_tool("read_file", {"path": "nope.txt"}, cwd=tmp_path)
        assert "Error" in result
        assert "does not exist" in result

    def test_read_directory_errors(self, tmp_path):
        (tmp_path / "subdir").mkdir()
        result = execute_tool("read_file", {"path": "subdir"}, cwd=tmp_path)
        assert "Error" in result

    def test_read_path_traversal_blocked(self, tmp_path):
        result = execute_tool("read_file", {"path": "../../etc/passwd"}, cwd=tmp_path)
        assert "Error" in result
        assert "escapes project root" in result


class TestWriteFile:
    def test_write_new_file(self, tmp_path):
        result = execute_tool("write_file", {"path": "out.txt", "content": "data"}, cwd=tmp_path)
        assert "Successfully" in result
        assert (tmp_path / "out.txt").read_text() == "data"

    def test_write_creates_parents(self, tmp_path):
        execute_tool("write_file", {"path": "a/b/c.txt", "content": "deep"}, cwd=tmp_path)
        assert (tmp_path / "a" / "b" / "c.txt").read_text() == "deep"

    def test_write_overwrites(self, tmp_path):
        (tmp_path / "out.txt").write_text("old")
        execute_tool("write_file", {"path": "out.txt", "content": "new"}, cwd=tmp_path)
        assert (tmp_path / "out.txt").read_text() == "new"

    def test_write_path_traversal_blocked(self, tmp_path):
        result = execute_tool("write_file", {"path": "../../evil.txt", "content": "pwned"}, cwd=tmp_path)
        assert "Error" in result
        assert "escapes project root" in result


class TestEditFile:
    def test_simple_replacement(self, tmp_path):
        f = tmp_path / "code.py"
        f.write_text("def foo():\n    return 1\n", encoding="utf-8")
        result = execute_tool("edit_file", {
            "path": "code.py",
            "old_string": "return 1",
            "new_string": "return 42",
        }, cwd=tmp_path)
        assert "Successfully" in result
        assert "return 42" in f.read_text()

    def test_edit_nonexistent_file(self, tmp_path):
        result = execute_tool("edit_file", {
            "path": "nope.py",
            "old_string": "x",
            "new_string": "y",
        }, cwd=tmp_path)
        assert "Error" in result

    def test_edit_string_not_found(self, tmp_path):
        f = tmp_path / "code.py"
        f.write_text("hello", encoding="utf-8")
        result = execute_tool("edit_file", {
            "path": "code.py",
            "old_string": "goodbye",
            "new_string": "hey",
        }, cwd=tmp_path)
        assert "Error" in result
        assert "Could not find" in result

    def test_edit_ambiguous_match(self, tmp_path):
        f = tmp_path / "code.py"
        f.write_text("aaa bbb aaa", encoding="utf-8")
        result = execute_tool("edit_file", {
            "path": "code.py",
            "old_string": "aaa",
            "new_string": "ccc",
        }, cwd=tmp_path)
        assert "Error" in result
        assert "2 occurrences" in result


class TestListDirectory:
    def test_list_empty_dir(self, tmp_path):
        d = tmp_path / "empty"
        d.mkdir()
        result = execute_tool("list_directory", {"path": "empty"}, cwd=tmp_path)
        assert result == "(empty directory)"

    def test_list_with_contents(self, tmp_path):
        (tmp_path / "file.txt").write_text("x")
        (tmp_path / "subdir").mkdir()
        result = execute_tool("list_directory", {"path": "."}, cwd=tmp_path)
        assert "f file.txt" in result
        assert "d subdir" in result

    def test_list_nonexistent(self, tmp_path):
        result = execute_tool("list_directory", {"path": "nope"}, cwd=tmp_path)
        assert "Error" in result

    def test_list_defaults_to_dot(self):
        # Just verify it doesn't crash with default path
        result = execute_tool("list_directory", {})
        assert result  # Should return something


class TestRunCommand:
    def test_simple_command(self, tmp_path):
        result = execute_tool("run_command", {"command": "echo hello"}, cwd=tmp_path)
        assert "hello" in result

    def test_failing_command(self, tmp_path):
        result = execute_tool("run_command", {"command": "grep --nonexistent-flag xyz"}, cwd=tmp_path)
        assert "command failed" in result

    def test_no_output_command(self, tmp_path):
        result = execute_tool("run_command", {"command": "mkdir testdir"}, cwd=tmp_path)
        assert result == "(no output)"

    def test_disallowed_command_blocked(self):
        result = execute_tool("run_command", {"command": "curl http://evil.com"})
        assert "Error" in result
        assert "not allowed" in result

    def test_python_blocked(self):
        """python is fully blocked - it's a universal sandbox escape."""
        result = execute_tool("run_command", {"command": "python -c \"print('pwned')\""})
        assert "Error" in result
        assert "not allowed" in result

    def test_python_file_blocked(self):
        """Even python <file> is blocked - write-then-exec bypasses all guards."""
        result = execute_tool("run_command", {"command": "python app.py"})
        assert "Error" in result
        assert "not allowed" in result

    def test_node_blocked(self):
        result = execute_tool("run_command", {"command": "node app.js"})
        assert "Error" in result
        assert "not allowed" in result

    def test_pip_blocked(self):
        result = execute_tool("run_command", {"command": "pip install requests"})
        assert "Error" in result
        assert "not allowed" in result

    def test_npm_blocked(self):
        result = execute_tool("run_command", {"command": "npm install lodash"})
        assert "Error" in result
        assert "not allowed" in result

    def test_npx_blocked(self):
        result = execute_tool("run_command", {"command": "npx cowsay hello"})
        assert "Error" in result
        assert "not allowed" in result

    def test_uv_blocked(self):
        result = execute_tool("run_command", {"command": "uv pip install requests"})
        assert "Error" in result
        assert "not allowed" in result

    def test_pytest_blocked(self):
        """pytest is a Python interpreter (conftest.py = arbitrary code)."""
        result = execute_tool("run_command", {"command": "pytest tests/"})
        assert "Error" in result
        # Blocked by either the command allowlist or the test-file-write guard
        assert "not allowed" in result or "Access denied" in result

    def test_py_test_blocked(self):
        result = execute_tool("run_command", {"command": "py.test -x"})
        assert "Error" in result
        assert "not allowed" in result


# ---------------------------------------------------------------------------
# Command Allowlist (_validate_command)
# ---------------------------------------------------------------------------

class TestValidateCommand:
    def test_allowed_command_passes(self, tmp_path):
        _validate_command(["ls", "-la"], tmp_path)

    def test_disallowed_command_raises(self, tmp_path):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["curl", "http://evil.com"], tmp_path)

    def test_strips_path_from_executable(self, tmp_path):
        _validate_command(["/usr/bin/ls", "-la"], tmp_path)

    def test_unsafe_shell_bypass_for_allowlist(self, tmp_path):
        """--unsafe-shell bypasses the allowlist for non-blocked commands."""
        import odd.tools.execution as _tools_exec
        original = _tools_exec._unsafe_shell
        try:
            _tools_exec._unsafe_shell = True
            _validate_command(["curl", "http://evil.com"], tmp_path)  # should not raise
        finally:
            _tools_exec._unsafe_shell = original

    def test_unsafe_shell_does_not_bypass_blocked(self, tmp_path):
        """--unsafe-shell does NOT bypass the hard-blocked commands."""
        import odd.tools.execution as _tools_exec
        original = _tools_exec._unsafe_shell
        try:
            _tools_exec._unsafe_shell = True
            with pytest.raises(PermissionError, match="not allowed"):
                _validate_command(["python", "evil.py"], tmp_path)
            with pytest.raises(PermissionError, match="not allowed"):
                _validate_command(["node", "evil.js"], tmp_path)
            with pytest.raises(PermissionError, match="not allowed"):
                _validate_command(["npm", "install"], tmp_path)
            with pytest.raises(PermissionError, match="not allowed"):
                _validate_command(["uv", "run", "evil"], tmp_path)
        finally:
            _tools_exec._unsafe_shell = original

    def test_python_fully_blocked(self, tmp_path):
        """python is unconditionally blocked - sandbox escape via write-then-exec."""
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["python", "app.py"], tmp_path)

    def test_python3_fully_blocked(self, tmp_path):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["python3", "app.py"], tmp_path)

    def test_node_fully_blocked(self, tmp_path):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["node", "app.js"], tmp_path)

    def test_npm_fully_blocked(self, tmp_path):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["npm", "install"], tmp_path)

    def test_npx_fully_blocked(self, tmp_path):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["npx", "cowsay"], tmp_path)

    def test_uv_fully_blocked(self, tmp_path):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["uv", "pip", "install", "requests"], tmp_path)

    def test_pip_fully_blocked(self, tmp_path):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["pip", "install", "requests"], tmp_path)

    def test_pip3_fully_blocked(self, tmp_path):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(["pip3", "install", "requests"], tmp_path)


# ---------------------------------------------------------------------------
# Security: find -exec, cp/mv path restriction, shell metacharacters
# ---------------------------------------------------------------------------

class TestFindExecBlocked:
    def test_find_exec_blocked(self):
        result = check_find_dangerous_flags(["find", ".", "-exec", "rm", "{}", ";"])
        assert result is not None
        assert "-exec" in result

    def test_find_execdir_blocked(self):
        result = check_find_dangerous_flags(["find", ".", "-execdir", "cat", "{}", ";"])
        assert result is not None
        assert "-execdir" in result

    def test_find_name_allowed(self):
        result = check_find_dangerous_flags(["find", ".", "-name", "*.py"])
        assert result is None

    def test_non_find_ignored(self):
        result = check_find_dangerous_flags(["ls", "-exec"])
        assert result is None

    def test_find_exec_via_execute_tool(self, tmp_path):
        result = execute_tool("run_command", {"command": "find . -exec rm {} ;"}, cwd=tmp_path)
        assert "Error" in result
        assert "not allowed" in result


class TestCpMvPathRestriction:
    def test_cp_within_project_allowed(self, tmp_path):
        result = check_cp_mv_paths(["cp", "src/a.py", "src/b.py"], tmp_path)
        assert result is None

    def test_mv_within_project_allowed(self, tmp_path):
        result = check_cp_mv_paths(["mv", "old.txt", "new.txt"], tmp_path)
        assert result is None

    def test_cp_escaping_project_blocked(self, tmp_path):
        result = check_cp_mv_paths(["cp", "../../etc/passwd", "."], tmp_path)
        assert result is not None
        assert "escapes project root" in result

    def test_mv_escaping_project_blocked(self, tmp_path):
        result = check_cp_mv_paths(["mv", "file.txt", "../../outside"], tmp_path)
        assert result is not None
        assert "escapes project root" in result

    def test_cp_flags_skipped(self, tmp_path):
        result = check_cp_mv_paths(["cp", "-r", "src", "dst"], tmp_path)
        assert result is None

    def test_non_cp_mv_ignored(self, tmp_path):
        result = check_cp_mv_paths(["ls", "../../outside"], tmp_path)
        assert result is None

    def test_cp_escape_via_execute_tool(self, tmp_path):
        result = execute_tool("run_command", {"command": "cp ../../etc/passwd ."}, cwd=tmp_path)
        assert "Error" in result
        assert "escapes project root" in result


class TestShellMetacharacters:
    def test_redirect_blocked(self):
        result = check_shell_metacharacters("echo hello > file.txt")
        assert result is not None
        assert "shell operators" in result

    def test_pipe_blocked(self):
        result = check_shell_metacharacters("cat file.txt | grep secret")
        assert result is not None

    def test_ampersand_blocked(self):
        result = check_shell_metacharacters("echo hello & echo world")
        assert result is not None

    def test_normal_command_allowed(self):
        result = check_shell_metacharacters("echo hello world")
        assert result is None

    def test_find_name_pattern_allowed(self):
        result = check_shell_metacharacters("find . -name '*.py'")
        assert result is None


# ---------------------------------------------------------------------------
# Error Sanitization (_sanitize_error)
# ---------------------------------------------------------------------------

class TestSanitizeError:
    def test_strips_env_var_values(self, monkeypatch):
        monkeypatch.setenv("SECRET_TOKEN", "super_secret_value_123")
        error = "connection failed at super_secret_value_123:5432"
        result = _sanitize_error(error)
        assert "super_secret_value_123" not in result
        assert "$SECRET_TOKEN" in result

    def test_ignores_short_values(self, monkeypatch):
        monkeypatch.setenv("X", "ab")
        error = "ab is fine"
        result = _sanitize_error(error)
        assert result == "ab is fine"  # len <= 3, not stripped

    def test_no_env_match_unchanged(self):
        error = "generic error message"
        result = _sanitize_error(error)
        assert result == "generic error message"


# ---------------------------------------------------------------------------
# Escalation Tool (response messages only - queue lives on AgentEngine now)
# ---------------------------------------------------------------------------

class TestEscalations:
    def test_escalate_blocker(self):
        result = execute_tool("escalate", {"reason": "stuck", "severity": "blocker"})
        assert "STOP" in result

    def test_escalate_needs_decision(self):
        result = execute_tool("escalate", {"reason": "which DB?", "severity": "needs_decision"})
        assert "best judgment" in result

    def test_escalate_heads_up(self):
        result = execute_tool("escalate", {"reason": "FYI", "severity": "heads_up"})
        assert "Continue" in result

    def test_default_severity(self):
        result = execute_tool("escalate", {"reason": "hmm"})
        assert "best judgment" in result


# ---------------------------------------------------------------------------
# Unknown Tool
# ---------------------------------------------------------------------------

class TestUnknownTool:
    def test_unknown_tool_returns_error(self):
        result = execute_tool("does_not_exist", {})
        assert "Error" in result
        assert "Unknown tool" in result


# ---------------------------------------------------------------------------
# Persona Isolation (_check_team_path_access, _check_command_team_access)
# ---------------------------------------------------------------------------

class TestPersonaIsolation:
    # --- File path checks: core team uses role dirs (lead_dev, qa, etc.) ---

    def test_cody_can_access_own_dir(self):
        # Cody's dir is .odd/team/lead_dev/ (role-based, not name-based)
        _check_team_path_access(".odd/team/lead_dev/persona.json", "Cody")

    def test_vera_can_access_own_dir(self):
        _check_team_path_access(".odd/team/qa/notes/qa.md", "Vera")

    def test_cody_cannot_access_qa_dir(self):
        with pytest.raises(PermissionError, match="Access denied"):
            _check_team_path_access(".odd/team/qa/persona.json", "Cody")

    def test_vera_cannot_access_lead_dev_dir(self):
        with pytest.raises(PermissionError, match="Access denied"):
            _check_team_path_access(".odd/team/lead_dev/persona.json", "Vera")

    def test_cody_cannot_access_consultant(self):
        with pytest.raises(PermissionError, match="Access denied"):
            _check_team_path_access(".odd/team/consultants/alice_chen/resume.md", "Cody")

    def test_consultant_can_access_own_dir(self):
        _check_team_path_access(".odd/team/consultants/alice_chen/notes/onboarding.md", "Alice Chen")

    def test_consultant_cannot_access_other_consultant(self):
        with pytest.raises(PermissionError, match="Access denied"):
            _check_team_path_access(".odd/team/consultants/bob_smith/resume.md", "Alice Chen")

    def test_consultant_cannot_access_core_team(self):
        with pytest.raises(PermissionError, match="Access denied"):
            _check_team_path_access(".odd/team/lead_dev/persona.json", "Alice Chen")

    def test_secretary_can_access_any_agent(self):
        _check_team_path_access(".odd/team/lead_dev/persona.json", "Paige")
        _check_team_path_access(".odd/team/qa/notes/qa.md", "Paige")
        _check_team_path_access(".odd/team/consultants/alice_chen/resume.md", "Paige")

    def test_non_team_paths_unrestricted(self):
        _check_team_path_access("src/main.py", "Cody")
        _check_team_path_access(".odd/sprints/sprint_1/sprint.json", "Cody")
        _check_team_path_access("tests/test_auth.py", "Alice Chen")

    def test_backslash_paths_normalized(self):
        with pytest.raises(PermissionError, match="Access denied"):
            _check_team_path_access(".odd\\team\\qa\\persona.json", "Cody")

    # --- Command checks ---

    def test_command_accessing_own_dir_allowed(self):
        _check_command_team_access("cat .odd/team/lead_dev/notes.md", "Cody")

    def test_command_accessing_other_dir_blocked(self):
        with pytest.raises(PermissionError, match="Access denied"):
            _check_command_team_access("cat .odd/team/qa/resume.md", "Cody")

    def test_command_without_team_path_unrestricted(self):
        _check_command_team_access("pytest tests/", "Cody")
        _check_command_team_access("grep -r 'def' src/", "Alice Chen")

    def test_secretary_command_unrestricted(self):
        _check_command_team_access("cat .odd/team/qa/resume.md", "Paige")

    # --- Integration: execute_tool enforces isolation ---

    def test_execute_read_file_blocked(self, tmp_path):
        team_dir = tmp_path / ".odd" / "team" / "qa"
        team_dir.mkdir(parents=True)
        (team_dir / "secret.md").write_text("QA secrets")

        result = execute_tool(
            "read_file", {"path": ".odd/team/qa/secret.md"},
            cwd=tmp_path, agent_name="Cody",
        )
        assert "Access denied" in result

    def test_execute_read_file_allowed_own(self, tmp_path):
        team_dir = tmp_path / ".odd" / "team" / "lead_dev"
        team_dir.mkdir(parents=True)
        (team_dir / "notes.md").write_text("my notes")

        result = execute_tool(
            "read_file", {"path": ".odd/team/lead_dev/notes.md"},
            cwd=tmp_path, agent_name="Cody",
        )
        assert result == "my notes"


# ---------------------------------------------------------------------------
# Symlink TOCTOU prevention
# ---------------------------------------------------------------------------

class TestSymlinkPrevention:
    def test_symlink_read_blocked(self, tmp_path):
        """Reading through a symlink is blocked to prevent TOCTOU attacks."""
        import os
        secret = tmp_path / "secret.txt"
        secret.write_text("top secret")
        link = tmp_path / "innocent.txt"
        try:
            os.symlink(secret, link)
        except OSError:
            pytest.skip("Symlinks not supported on this platform")
        result = execute_tool("read_file", {"path": "innocent.txt"}, cwd=tmp_path)
        assert "Error" in result
        assert "Symlink" in result

    def test_symlink_write_blocked(self, tmp_path):
        """Writing through a symlink is blocked."""
        import os
        target = tmp_path / "target.txt"
        target.write_text("original")
        link = tmp_path / "link.txt"
        try:
            os.symlink(target, link)
        except OSError:
            pytest.skip("Symlinks not supported on this platform")
        result = execute_tool(
            "write_file", {"path": "link.txt", "content": "pwned"}, cwd=tmp_path,
        )
        assert "Error" in result
        assert "Symlink" in result
        assert target.read_text() == "original"  # unchanged

    def test_symlink_directory_in_path_blocked(self, tmp_path):
        """A symlink directory component is caught even when the file itself isn't a link."""
        import os
        # Create a real dir with a secret file
        real_dir = tmp_path / "real_team"
        real_dir.mkdir()
        (real_dir / "persona.json").write_text("secret persona")
        # Create a symlink directory pointing to it
        link_dir = tmp_path / "fake_dir"
        try:
            os.symlink(real_dir, link_dir)
        except OSError:
            pytest.skip("Symlinks not supported on this platform")
        # Try to read through the symlink directory
        result = execute_tool(
            "read_file", {"path": "fake_dir/persona.json"}, cwd=tmp_path,
        )
        assert "Error" in result
        assert "Symlink" in result

    def test_normal_file_not_affected(self, tmp_path):
        """Normal files (no symlinks) work fine."""
        (tmp_path / "normal.txt").write_text("data")
        result = execute_tool("read_file", {"path": "normal.txt"}, cwd=tmp_path)
        assert result == "data"


# ---------------------------------------------------------------------------
# Test file write protection (non-QA agents)
# ---------------------------------------------------------------------------

class TestTestFileProtection:
    def test_consultant_cannot_write_test_file(self, tmp_path):
        tests_dir = tmp_path / "tests"
        tests_dir.mkdir()
        (tests_dir / "test_auth.py").write_text("assert True")
        result = execute_tool(
            "write_file",
            {"path": "tests/test_auth.py", "content": "# pwned"},
            cwd=tmp_path, agent_name="Alice Chen",
        )
        assert "Access denied" in result
        assert (tests_dir / "test_auth.py").read_text() == "assert True"

    def test_vera_can_write_test_file(self, tmp_path):
        tests_dir = tmp_path / "tests"
        tests_dir.mkdir()
        result = execute_tool(
            "write_file",
            {"path": "tests/test_new.py", "content": "def test_it(): pass"},
            cwd=tmp_path, agent_name="Vera",
        )
        assert "Successfully" in result

    def test_consultant_cannot_write_conftest(self, tmp_path):
        """conftest.py is a code execution vector - non-QA agents can't write it."""
        result = execute_tool(
            "write_file",
            {"path": "conftest.py", "content": "import os; os.system('evil')"},
            cwd=tmp_path, agent_name="Alice Chen",
        )
        assert "Access denied" in result
        assert "conftest" in result

    def test_consultant_cannot_write_nested_conftest(self, tmp_path):
        """conftest.py at any depth is blocked - pytest auto-discovers them."""
        (tmp_path / "src").mkdir()
        result = execute_tool(
            "write_file",
            {"path": "src/conftest.py", "content": "import os"},
            cwd=tmp_path, agent_name="Cody",
        )
        assert "Access denied" in result

    def test_vera_can_write_conftest(self, tmp_path):
        """QA (Vera) can legitimately write conftest.py for test fixtures."""
        result = execute_tool(
            "write_file",
            {"path": "conftest.py", "content": "import pytest"},
            cwd=tmp_path, agent_name="Vera",
        )
        assert "Successfully" in result


# ---------------------------------------------------------------------------
# Git command wrapper
# ---------------------------------------------------------------------------

class TestGitCommandWrapper:
    def test_git_log_allowed(self, tmp_path):
        """Read-only git commands pass through without extra checks."""
        from odd.tools.execution import _check_git_command
        # Should not raise - log is not a write subcommand
        _check_git_command(["git", "log", "--oneline"], "Alice Chen", tmp_path)

    def test_git_rm_test_file_blocked_for_consultant(self, tmp_path):
        """git rm on a test file is blocked for non-QA agents."""
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="only QA"):
            _check_git_command(
                ["git", "rm", "tests/test_auth.py"],
                "Alice Chen", tmp_path,
            )

    def test_git_rm_test_file_allowed_for_vera(self, tmp_path):
        from odd.tools.execution import _check_git_command
        # Should not raise - Vera is QA
        _check_git_command(
            ["git", "rm", "tests/test_auth.py"],
            "Vera", tmp_path,
        )

    def test_git_checkout_team_file_blocked(self, tmp_path):
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="Access denied"):
            _check_git_command(
                ["git", "checkout", "--", ".odd/team/qa/persona.json"],
                "Alice Chen", tmp_path,
            )

    def test_git_mv_test_file_blocked(self, tmp_path):
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="only QA"):
            _check_git_command(
                ["git", "mv", "tests/old.py", "tests/new.py"],
                "Cody", tmp_path,
            )

    def test_git_push_blocked(self, tmp_path):
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="not allowed"):
            _check_git_command(["git", "push"], "Cody", tmp_path)

    def test_git_remote_blocked(self, tmp_path):
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="not allowed"):
            _check_git_command(
                ["git", "remote", "add", "exfil", "https://evil.com/repo"],
                "Alice Chen", tmp_path,
            )

    def test_git_config_blocked(self, tmp_path):
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="not allowed"):
            _check_git_command(
                ["git", "config", "core.symlinks", "true"],
                "Cody", tmp_path,
            )

    def test_git_clean_blocked(self, tmp_path):
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="not allowed"):
            _check_git_command(["git", "clean", "-fd"], "Alice Chen", tmp_path)

    def test_git_add_test_file_blocked_for_consultant(self, tmp_path):
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="only QA"):
            _check_git_command(
                ["git", "add", "tests/test_auth.py"],
                "Alice Chen", tmp_path,
            )

    def test_git_add_test_file_allowed_for_vera(self, tmp_path):
        from odd.tools.execution import _check_git_command
        # Should not raise - Vera is QA
        _check_git_command(
            ["git", "add", "tests/test_auth.py"],
            "Vera", tmp_path,
        )

    def test_git_add_all_enumerates_staged_files(self, tmp_path):
        """git add -A uses --dry-run to enumerate files and check each one."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        # Mock git add --dry-run returning a test file
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="add 'tests/test_auth.py'\nadd 'src/main.py'\n",
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result):
            with pytest.raises(PermissionError, match="only QA"):
                _check_git_command(["git", "add", "-A"], "Alice Chen", tmp_path)

    def test_git_add_all_safe_files_allowed(self, tmp_path):
        """git add -A with only safe files passes through."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="add 'src/main.py'\nadd 'src/utils.py'\n",
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result):
            _check_git_command(["git", "add", "-A"], "Alice Chen", tmp_path)

    def test_git_commit_checks_staged_files(self, tmp_path):
        """git commit inspects the index and blocks if test files are staged."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="tests/test_auth.py\nsrc/main.py\n",
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result):
            with pytest.raises(PermissionError, match="only QA"):
                _check_git_command(["git", "commit", "-m", "sneaky"], "Alice Chen", tmp_path)

    def test_git_commit_allowed_for_safe_staged_files(self, tmp_path):
        """git commit with only safe staged files passes through."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="src/main.py\nsrc/utils.py\n",
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result):
            _check_git_command(["git", "commit", "-m", "ok"], "Alice Chen", tmp_path)

    def test_git_commit_vera_can_commit_test_files(self, tmp_path):
        """Vera can commit test files."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="tests/test_new.py\n",
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result):
            _check_git_command(["git", "commit", "-m", "add tests"], "Vera", tmp_path)

    def test_git_cherry_pick_bad_ref_blocked(self, tmp_path):
        """If git can't determine affected files, command is blocked."""
        from odd.tools.execution import _check_git_command
        # cherry-pick with no ref → fail-closed
        with pytest.raises(PermissionError, match="Cannot determine"):
            _check_git_command(
                ["git", "cherry-pick"],
                "Alice Chen", tmp_path,
            )

    def test_git_commit_a_checks_dirty_files(self, tmp_path):
        """git commit -a must also check modified tracked files, not just the index."""
        import subprocess
        from unittest.mock import patch, call
        from odd.tools.execution import _check_git_command
        cached_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="src/main.py\n",  # index is clean of test files
        )
        dirty_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="tests/test_auth.py\nsrc/utils.py\n",  # dirty worktree has test file
        )
        with patch("odd.tools.execution.subprocess.run", side_effect=[cached_result, dirty_result]):
            with pytest.raises(PermissionError, match="only QA"):
                _check_git_command(["git", "commit", "-a", "-m", "sneaky"], "Alice Chen", tmp_path)

    def test_git_commit_all_flag_checks_dirty_files(self, tmp_path):
        """git commit --all is equivalent to -a."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        cached_result = subprocess.CompletedProcess(
            args=[], returncode=0, stdout="",
        )
        dirty_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="tests/test_sneaky.py\n",
        )
        with patch("odd.tools.execution.subprocess.run", side_effect=[cached_result, dirty_result]):
            with pytest.raises(PermissionError, match="only QA"):
                _check_git_command(["git", "commit", "--all", "-m", "sneaky"], "Alice Chen", tmp_path)

    def test_git_commit_without_a_ignores_dirty(self, tmp_path):
        """Plain git commit without -a only checks the index, not dirty files."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        cached_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="src/main.py\n",  # index has no test files
        )
        with patch("odd.tools.execution.subprocess.run", return_value=cached_result):
            # Should not raise - dirty files aren't checked without -a
            _check_git_command(["git", "commit", "-m", "ok"], "Alice Chen", tmp_path)

    def test_git_stash_pop_checks_stash_files(self, tmp_path):
        """git stash pop checks the stash entry's files."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="tests/test_auth.py\nsrc/main.py\n",
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result):
            with pytest.raises(PermissionError, match="only QA"):
                _check_git_command(["git", "stash", "pop"], "Alice Chen", tmp_path)

    def test_git_stash_apply_with_ref(self, tmp_path):
        """git stash apply stash@{2} checks the correct stash entry."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="tests/test_secret.py\n",
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result) as mock_run:
            with pytest.raises(PermissionError, match="only QA"):
                _check_git_command(
                    ["git", "stash", "apply", "stash@{2}"],
                    "Alice Chen", tmp_path,
                )
            # Verify it passed the ref to git stash show
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            assert "stash@{2}" in call_args

    def test_git_stash_list_allowed(self, tmp_path):
        """git stash list is read-only and should pass through."""
        from odd.tools.execution import _check_git_command
        # Should not raise
        _check_git_command(["git", "stash", "list"], "Alice Chen", tmp_path)

    def test_git_apply_symlink_blocked(self, tmp_path):
        """git apply with a patch that creates symlinks is blocked."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        # Mock --stat --summary output that includes symlink mode
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout=(
                " src/main.py | 3 +++\n"
                " create mode 120000 src/evil_link\n"
            ),
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result):
            with pytest.raises(PermissionError, match="symlink"):
                _check_git_command(
                    ["git", "apply", "evil.patch"],
                    "Alice Chen", tmp_path,
                )

    def test_git_apply_normal_patch_allowed(self, tmp_path):
        """git apply with a normal patch (no symlinks) is allowed."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        mock_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout=" src/main.py | 3 +++\n",
        )
        with patch("odd.tools.execution.subprocess.run", return_value=mock_result):
            _check_git_command(
                ["git", "apply", "fix.patch"],
                "Alice Chen", tmp_path,
            )

    def test_git_c_flag_blocked(self, tmp_path):
        """git -c is a code execution vector via config hooks (fsmonitor, pager)."""
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="not allowed"):
            _check_git_command(
                ["git", "-c", "core.fsmonitor=curl evil.com", "status"],
                "Alice Chen", tmp_path,
            )

    def test_git_c_equals_flag_blocked(self, tmp_path):
        """git -c=key=val form is also blocked."""
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="not allowed"):
            _check_git_command(
                ["git", "-c=core.pager=malicious", "log"],
                "Cody", tmp_path,
            )

    def test_git_exec_path_blocked(self, tmp_path):
        from odd.tools.execution import _check_git_command
        with pytest.raises(PermissionError, match="not allowed"):
            _check_git_command(
                ["git", "--exec-path=/tmp/evil", "status"],
                "Cody", tmp_path,
            )

    def test_git_commit_am_combined_flag_detected(self, tmp_path):
        """git commit -am must detect the -a in combined short flags."""
        import subprocess
        from unittest.mock import patch
        from odd.tools.execution import _check_git_command
        cached_result = subprocess.CompletedProcess(
            args=[], returncode=0, stdout="src/main.py\n",
        )
        dirty_result = subprocess.CompletedProcess(
            args=[], returncode=0,
            stdout="tests/test_auth.py\n",
        )
        with patch("odd.tools.execution.subprocess.run", side_effect=[cached_result, dirty_result]):
            with pytest.raises(PermissionError, match="only QA"):
                _check_git_command(
                    ["git", "commit", "-am", "sneaky combined flags"],
                    "Alice Chen", tmp_path,
                )


# ---------------------------------------------------------------------------
# Blocked commands (interpreters & package managers)
# ---------------------------------------------------------------------------

class TestBlockedCommands:
    """All interpreters and package managers are fully blocked.

    Agents cannot install dependencies or run arbitrary code.
    Dependencies are requested via submit_dependency_request and
    approved by the CEO.
    """

    @pytest.mark.parametrize("cmd", [
        ["python", "app.py"],
        ["python3", "app.py"],
        ["python", "-c", "pass"],
        ["python", "-m", "http.server"],
        ["node", "app.js"],
        ["node", "-e", "console.log('hi')"],
        ["npm", "install", "lodash"],
        ["npm", "run", "build"],
        ["npm", "test"],
        ["npx", "cowsay"],
        ["uv", "pip", "install", "requests"],
        ["uv", "run", "evil"],
        ["pip", "install", "requests"],
        ["pip3", "install", "requests"],
        ["pytest"],
        ["pytest", "tests/"],
        ["py.test", "-x"],
    ])
    def test_blocked_command(self, tmp_path, cmd):
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command(cmd, tmp_path)

    @pytest.mark.parametrize("cmd", [
        ["python", "app.py"],
        ["node", "app.js"],
        ["npm", "install"],
        ["uv", "sync"],
        ["pip", "install", "x"],
        ["pytest"],
        ["py.test"],
    ])
    def test_blocked_even_with_unsafe_shell(self, tmp_path, cmd):
        """--unsafe-shell does NOT bypass hard-blocked commands."""
        import odd.tools.execution as _tools_exec
        original = _tools_exec._unsafe_shell
        try:
            _tools_exec._unsafe_shell = True
            with pytest.raises(PermissionError, match="not allowed"):
                _validate_command(cmd, tmp_path)
        finally:
            _tools_exec._unsafe_shell = original

    @pytest.mark.parametrize("exe", [
        "python.exe", "python3.exe", "node.exe", "npm.cmd",
        "pytest.exe", "pip.exe", "pip3.exe",
    ])
    def test_windows_exe_extension_blocked(self, tmp_path, exe):
        """Windows .exe/.cmd extensions must not bypass the block list."""
        with pytest.raises(PermissionError, match="not allowed"):
            _validate_command([exe, "arg"], tmp_path)

    def test_windows_exe_extension_blocked_with_unsafe_shell(self, tmp_path):
        """python.exe must be blocked even with --unsafe-shell on Windows."""
        import odd.tools.execution as _tools_exec
        original = _tools_exec._unsafe_shell
        try:
            _tools_exec._unsafe_shell = True
            with pytest.raises(PermissionError, match="not allowed"):
                _validate_command(["python.exe", "evil.py"], tmp_path)
        finally:
            _tools_exec._unsafe_shell = original
