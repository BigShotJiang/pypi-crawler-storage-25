"""Tests for odd.config - pricing parsing, caching, refresh, constants."""

import json
from unittest.mock import MagicMock, patch

import pytest

from odd.config import (
    DEFAULT_MAX_TOKENS,
    HAIKU_MODEL,
    MODEL_PRICING,
    OPUS_MODEL,
    SHELL_COMMAND_TIMEOUT,
    SONNET_MODEL,
    _DEFAULT_PRICING,
    _parse_pricing_table,
    _pricing_cache_path,
    _resolve_model_pricing,
    load_pricing,
    refresh_pricing,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_model_ids_are_strings(self):
        assert isinstance(OPUS_MODEL, str)
        assert isinstance(SONNET_MODEL, str)
        assert isinstance(HAIKU_MODEL, str)

    def test_model_ids_start_with_claude(self):
        for model in [OPUS_MODEL, SONNET_MODEL, HAIKU_MODEL]:
            assert model.startswith("claude-")

    def test_default_max_tokens(self):
        assert DEFAULT_MAX_TOKENS == 16384

    def test_shell_timeout(self):
        assert SHELL_COMMAND_TIMEOUT == 120

    def test_default_pricing_has_all_models(self):
        assert OPUS_MODEL in _DEFAULT_PRICING
        assert SONNET_MODEL in _DEFAULT_PRICING
        assert HAIKU_MODEL in _DEFAULT_PRICING

    def test_default_pricing_has_input_output(self):
        for model, pricing in _DEFAULT_PRICING.items():
            assert "input" in pricing
            assert "output" in pricing
            assert pricing["input"] > 0
            assert pricing["output"] > 0

    def test_opus_most_expensive(self):
        assert _DEFAULT_PRICING[OPUS_MODEL]["output"] > _DEFAULT_PRICING[SONNET_MODEL]["output"]
        assert _DEFAULT_PRICING[SONNET_MODEL]["output"] > _DEFAULT_PRICING[HAIKU_MODEL]["output"]

    def test_module_level_model_pricing_matches_defaults(self):
        assert MODEL_PRICING == _DEFAULT_PRICING


# ---------------------------------------------------------------------------
# _pricing_cache_path
# ---------------------------------------------------------------------------

class TestPricingCachePath:
    def test_returns_none_when_no_dir(self):
        assert _pricing_cache_path(None) is None

    def test_returns_path_in_financials(self, tmp_path):
        result = _pricing_cache_path(tmp_path)
        assert result == tmp_path / "financials" / "pricing.json"

    def test_path_includes_json_extension(self, tmp_path):
        result = _pricing_cache_path(tmp_path)
        assert str(result).endswith(".json")


# ---------------------------------------------------------------------------
# _parse_pricing_table
# ---------------------------------------------------------------------------

class TestParsePricingTable:
    """Test HTML/markdown pricing table parsing."""

    SAMPLE_TABLE = (
        "| Model | Input | Batch | Output |\n"
        "|-------|-------|-------|--------|\n"
        "| Claude Opus 4.6 | $5 / MTok | $2.50 / MTok | $25 / MTok |\n"
        "| Claude Sonnet 4.6 | $3 / MTok | $1.50 / MTok | $15 / MTok |\n"
        "| Claude Haiku 4.5 | $1 / MTok | $0.50 / MTok | $5 / MTok |\n"
    )

    def test_parses_all_models(self):
        result = _parse_pricing_table(self.SAMPLE_TABLE)
        assert len(result) == 3

    def test_parses_opus(self):
        result = _parse_pricing_table(self.SAMPLE_TABLE)
        assert "opus-4.6" in result
        assert result["opus-4.6"]["input"] == 5.0
        assert result["opus-4.6"]["output"] == 25.0

    def test_parses_sonnet(self):
        result = _parse_pricing_table(self.SAMPLE_TABLE)
        assert "sonnet-4.6" in result
        assert result["sonnet-4.6"]["input"] == 3.0
        assert result["sonnet-4.6"]["output"] == 15.0

    def test_parses_haiku(self):
        result = _parse_pricing_table(self.SAMPLE_TABLE)
        assert "haiku-4.5" in result
        assert result["haiku-4.5"]["input"] == 1.0
        assert result["haiku-4.5"]["output"] == 5.0

    def test_empty_html_returns_empty(self):
        assert _parse_pricing_table("") == {}

    def test_no_matching_rows(self):
        html = "| Model | Price |\n| GPT-4 | $10 / MTok |\n"
        assert _parse_pricing_table(html) == {}

    def test_partial_table_missing_output(self):
        # Only one price column - regex needs both input and output
        html = "| Claude Opus 4.6 | $5 / MTok |\n"
        assert _parse_pricing_table(html) == {}

    def test_decimal_prices(self):
        html = "| Claude Haiku 4.5 | $0.80 / MTok | $0.40 / MTok | $4.00 / MTok |\n"
        result = _parse_pricing_table(html)
        if "haiku-4.5" in result:
            assert result["haiku-4.5"]["input"] == 0.80
            assert result["haiku-4.5"]["output"] == 4.00

    def test_model_with_parenthetical(self):
        html = "| Claude Sonnet 4.5 (legacy) | $3 / MTok | $1.50 / MTok | $15 / MTok |\n"
        result = _parse_pricing_table(html)
        assert "sonnet-4.5 (legacy)" in result or "sonnet-4.5" in result


# ---------------------------------------------------------------------------
# _resolve_model_pricing
# ---------------------------------------------------------------------------

class TestResolveModelPricing:
    def test_resolves_opus(self):
        parsed = {"opus-4.6": {"input": 5.0, "output": 25.0}}
        result = _resolve_model_pricing(parsed)
        assert OPUS_MODEL in result
        assert result[OPUS_MODEL]["input"] == 5.0

    def test_resolves_sonnet(self):
        parsed = {"sonnet-4.6": {"input": 3.0, "output": 15.0}}
        result = _resolve_model_pricing(parsed)
        assert SONNET_MODEL in result

    def test_resolves_haiku(self):
        # Haiku has extra version suffix: claude-haiku-4-5-20251001
        parsed = {"haiku-4.5": {"input": 1.0, "output": 5.0}}
        result = _resolve_model_pricing(parsed)
        assert HAIKU_MODEL in result

    def test_empty_parsed_returns_empty(self):
        assert _resolve_model_pricing({}) == {}

    def test_unrecognized_model_ignored(self):
        parsed = {"gemini-1.5": {"input": 1.0, "output": 2.0}}
        result = _resolve_model_pricing(parsed)
        assert len(result) == 0

    def test_partial_match(self):
        """Only some models in parsed data."""
        parsed = {"opus-4.6": {"input": 5.0, "output": 25.0}}
        result = _resolve_model_pricing(parsed)
        assert OPUS_MODEL in result
        assert SONNET_MODEL not in result
        assert HAIKU_MODEL not in result


# ---------------------------------------------------------------------------
# load_pricing
# ---------------------------------------------------------------------------

class TestLoadPricing:
    def test_no_cache_returns_defaults(self, tmp_path):
        result = load_pricing(tmp_path)
        assert result == _DEFAULT_PRICING

    def test_none_dir_returns_defaults(self):
        result = load_pricing(None)
        assert result == _DEFAULT_PRICING

    def test_loads_from_cache(self, tmp_path):
        cache_dir = tmp_path / "financials"
        cache_dir.mkdir(parents=True)
        cached = {OPUS_MODEL: {"input": 99.0, "output": 99.0}}
        (cache_dir / "pricing.json").write_text(json.dumps(cached))

        result = load_pricing(tmp_path)
        assert result[OPUS_MODEL]["input"] == 99.0

    def test_corrupt_cache_returns_defaults(self, tmp_path):
        cache_dir = tmp_path / "financials"
        cache_dir.mkdir(parents=True)
        (cache_dir / "pricing.json").write_text("NOT VALID JSON {{{")

        result = load_pricing(tmp_path)
        assert result == _DEFAULT_PRICING

    def test_returns_copy_not_reference(self):
        r1 = load_pricing(None)
        r2 = load_pricing(None)
        assert r1 is not r2

    def test_stale_cache_logs_warning(self, tmp_path, caplog):
        """Cache older than PRICING_CACHE_MAX_AGE_DAYS triggers a warning."""
        import os
        import time

        cache_dir = tmp_path / "financials"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "pricing.json"
        cached = {OPUS_MODEL: {"input": 99.0, "output": 99.0}}
        cache_file.write_text(json.dumps(cached))

        # Backdate the file to 60 days ago
        old_time = time.time() - (60 * 86400)
        os.utime(cache_file, (old_time, old_time))

        with caplog.at_level("WARNING", logger="odd.config"):
            result = load_pricing(tmp_path)

        assert result[OPUS_MODEL]["input"] == 99.0
        assert "days old" in caplog.text
        assert "odd refresh-pricing" in caplog.text

    def test_fresh_cache_no_warning(self, tmp_path, caplog):
        """Recently-written cache should not trigger a staleness warning."""
        cache_dir = tmp_path / "financials"
        cache_dir.mkdir(parents=True)
        cached = {OPUS_MODEL: {"input": 99.0, "output": 99.0}}
        (cache_dir / "pricing.json").write_text(json.dumps(cached))

        with caplog.at_level("WARNING", logger="odd.config"):
            load_pricing(tmp_path)

        assert "days old" not in caplog.text


# ---------------------------------------------------------------------------
# refresh_pricing
# ---------------------------------------------------------------------------

class TestRefreshPricing:
    def test_network_failure_returns_defaults(self, tmp_path):
        """When the HTTP request fails, fall back to defaults."""
        with patch("urllib.request.urlopen", side_effect=Exception("network error")):
            result = refresh_pricing(tmp_path)
        assert result == _DEFAULT_PRICING

    def test_successful_fetch_caches_result(self, tmp_path):
        """When fetch succeeds and parses, result is cached to disk."""
        fake_html = (
            "| Claude Opus 4.6 | $5 / MTok | $2.50 / MTok | $25 / MTok |\n"
            "| Claude Sonnet 4.6 | $3 / MTok | $1.50 / MTok | $15 / MTok |\n"
        )
        mock_resp = MagicMock()
        mock_resp.read.return_value = fake_html.encode("utf-8")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            result = refresh_pricing(tmp_path)

        # Should have parsed at least Opus
        if OPUS_MODEL in result:
            assert result[OPUS_MODEL]["input"] == 5.0
            # Check cache file was written
            cache_path = tmp_path / "financials" / "pricing.json"
            assert cache_path.exists()

    def test_no_odd_dir_still_returns_result(self):
        """When odd_dir is None, still returns pricing (just doesn't cache)."""
        with patch("urllib.request.urlopen", side_effect=Exception("no net")):
            result = refresh_pricing(None)
        assert result == _DEFAULT_PRICING

    def test_empty_parse_result_returns_defaults(self, tmp_path):
        """When HTML doesn't match any models, fall back to defaults."""
        fake_html = "No pricing table here"
        mock_resp = MagicMock()
        mock_resp.read.return_value = fake_html.encode("utf-8")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            result = refresh_pricing(tmp_path)
        assert result == _DEFAULT_PRICING

    def test_timeout_returns_defaults(self):
        """urllib timeout should be handled gracefully."""
        import urllib.error
        with patch("urllib.request.urlopen", side_effect=urllib.error.URLError("timeout")):
            result = refresh_pricing(None)
        assert result == _DEFAULT_PRICING
