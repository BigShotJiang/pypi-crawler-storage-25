"""LLM provider implementations."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from odd.providers.anthropic import AnthropicProvider

if TYPE_CHECKING:
    from odd.models import ProviderConfig
    from odd.provider import Provider

__all__ = ["AnthropicProvider", "OpenAICompatProvider", "OpenWebUIProvider", "resolve_provider"]


def __getattr__(name: str):
    """Lazy-load optional providers to avoid hard dependency on requests."""
    if name == "OpenAICompatProvider":
        from odd.providers.openai_compat import OpenAICompatProvider
        return OpenAICompatProvider
    if name == "OpenWebUIProvider":
        from odd.providers.openwebui import OpenWebUIProvider
        return OpenWebUIProvider
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def resolve_provider(config: ProviderConfig) -> Provider:
    """Instantiate the right provider from a ProviderConfig.

    Reads the API key from the environment variable named in config.api_key_env.
    """
    api_key = os.environ.get(config.api_key_env, "")

    if config.name == "openwebui":
        try:
            from odd.providers.openwebui import OpenWebUIProvider, OPENWEBUI_DEFAULT_BASE_URL
        except ImportError:
            raise ImportError(
                "The openwebui provider requires the 'requests' package. "
                "Install it with: pip install odd-org[openai-compat]"
            )
        return OpenWebUIProvider(
            api_key=api_key,
            base_url=config.base_url or OPENWEBUI_DEFAULT_BASE_URL,
            model_map=config.model_map if config.model_map else None,
        )

    if config.name == "openai-compat":
        try:
            from odd.providers.openai_compat import OpenAICompatProvider
        except ImportError:
            raise ImportError(
                "The openai-compat provider requires the 'requests' package. "
                "Install it with: pip install odd-org[openai-compat]"
            )
        if not config.base_url:
            raise ValueError(
                "openai-compat provider requires a base_url. "
                "Set it in .odd/config.json or pass --base-url."
            )
        return OpenAICompatProvider(
            api_key=api_key,
            base_url=config.base_url,
            model_map=config.model_map if config.model_map else None,
        )

    # Default: Anthropic
    # AnthropicProvider uses the SDK which reads ANTHROPIC_API_KEY itself,
    # but we pass through if explicitly set.
    return AnthropicProvider(
        api_key=api_key if api_key else None,
        model_map=config.model_map if config.model_map else None,
    )
