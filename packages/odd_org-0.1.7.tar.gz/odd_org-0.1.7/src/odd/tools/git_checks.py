"""Git command validation - structural checks for worktree-modifying git commands."""

from __future__ import annotations

import subprocess
from pathlib import Path

from odd.tools.isolation import (
    GIT_BLOCKED_GLOBAL_FLAGS,
    GIT_BLOCKED_SUBCOMMANDS,
    GIT_WRITE_SUBCOMMANDS,
    check_team_path_access as _check_team_path_access_policy,
    check_test_file_write as _check_test_file_write_policy,
)


# ── Local policy wrappers ─────────────────────────────────────────────
# These duplicate the pattern in execution.py but import directly from
# isolation to avoid circular imports (execution.py imports from us).

def _check_team_path_access(path: str, agent_name: str) -> None:
    reason = _check_team_path_access_policy(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_test_file_write(path: str, agent_name: str) -> None:
    reason = _check_test_file_write_policy(path, agent_name)
    if reason:
        raise PermissionError(reason)


# Git subcommands where file arguments appear directly in argv.
_GIT_EXPLICIT_FILE_SUBCMDS = {"rm", "mv", "checkout", "restore"}


def _get_git_affected_files(argv: list[str], base: Path) -> list[str] | None:
    """Ask git which files a worktree-modifying command would touch.

    Returns a list of file paths, or **None** if we could not determine the
    affected files (git command failed, ref not found, etc.).  Callers must
    treat None as "unknown - fail closed".
    """
    subcmd = argv[1]

    # For 'git apply': use --stat to list affected files.
    # Also check for symlink creation in the patch (mode 120000).
    if subcmd == "apply":
        # First, reject patches that create symlinks - these bypass our
        # path validation since git would create the symlink directly.
        try:
            check_argv = list(argv) + ["--stat", "--summary"]
            summary_result = subprocess.run(
                check_argv, capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=10, cwd=base,
            )
            if summary_result.returncode != 0:
                return None  # couldn't determine
            # --summary shows mode changes; reject any symlink mode (120000)
            for line in summary_result.stdout.splitlines():
                if "120000" in line or "symlink" in line.lower():
                    raise PermissionError(
                        "git apply: patch creates symlinks - blocked to prevent "
                        "path traversal attacks"
                    )
            # --stat output: " path/to/file | 3 +++"
            return [
                line.split("|")[0].strip()
                for line in summary_result.stdout.splitlines()
                if "|" in line and line.strip()
            ]
        except PermissionError:
            raise  # re-raise our own symlink block
        except Exception:
            return None

    # For 'git stash': determine affected files based on the sub-subcommand.
    # Read-only operations (list, show) don't modify the worktree.
    # Write operations (pop, apply, drop, push) need file-level checks.
    if subcmd == "stash":
        # Parse the stash sub-subcommand (e.g. pop, apply, show, list, push)
        stash_subcmd = None
        stash_ref = None
        for arg in argv[2:]:
            if not arg.startswith("-"):
                if stash_subcmd is None:
                    stash_subcmd = arg
                else:
                    stash_ref = arg
                    break
        # Bare 'git stash' is equivalent to 'git stash push'
        if stash_subcmd is None:
            stash_subcmd = "push"
        # Read-only stash operations don't modify files
        if stash_subcmd in ("list", "show"):
            return []
        # drop doesn't modify the worktree
        if stash_subcmd == "drop":
            return []
        # For pop/apply, check the specific stash entry's files
        if stash_subcmd in ("pop", "apply"):
            show_cmd = ["git", "stash", "show", "--name-only"]
            if stash_ref:
                show_cmd.append(stash_ref)
            try:
                result = subprocess.run(
                    show_cmd,
                    capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=10, cwd=base,
                )
                if result.returncode != 0:
                    return None
                return [l.strip() for l in result.stdout.splitlines() if l.strip()]
            except Exception:
                return None
        # For push/create and anything else, check dirty files that would be stashed
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only"],
                capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=10, cwd=base,
            )
            if result.returncode != 0:
                return None
            return [l.strip() for l in result.stdout.splitlines() if l.strip()]
        except Exception:
            return None

    # For 'git cherry-pick', 'git revert', 'git merge': diff against HEAD
    if subcmd in ("cherry-pick", "revert", "merge"):
        # Extract the ref (skip flags)
        ref = None
        for arg in argv[2:]:
            if not arg.startswith("-"):
                ref = arg
                break
        if not ref:
            return None  # can't determine without a ref
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", "HEAD", ref],
                capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=10, cwd=base,
            )
            if result.returncode != 0:
                return None
            return [l.strip() for l in result.stdout.splitlines() if l.strip()]
        except Exception:
            return None

    # For 'git reset': diff against the target
    if subcmd == "reset":
        ref = "HEAD"
        for arg in argv[2:]:
            if not arg.startswith("-"):
                ref = arg
                break
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", "HEAD", ref],
                capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=10, cwd=base,
            )
            if result.returncode != 0:
                return None
            return [l.strip() for l in result.stdout.splitlines() if l.strip()]
        except Exception:
            return None

    # For commands with explicit file arguments (checkout, restore, rm, mv):
    # extract non-flag arguments after '--' or all non-flag args after subcmd
    files = []
    past_separator = False
    for arg in argv[2:]:
        if arg == "--":
            past_separator = True
            continue
        if past_separator or not arg.startswith("-"):
            files.append(arg)
    return files


def _extract_git_subcmd(argv: list[str]) -> tuple[str | None, int]:
    """Find the real git subcommand, skipping global flags.

    Returns (subcommand, index) or (None, -1) if no subcommand found.
    Also blocks dangerous global flags like -c.
    """
    i = 1
    while i < len(argv):
        arg = argv[i]
        # Check for blocked global flags
        if arg in GIT_BLOCKED_GLOBAL_FLAGS or any(
            arg.startswith(f"{flag}=") or arg.startswith(f"{flag} ")
            for flag in GIT_BLOCKED_GLOBAL_FLAGS
        ):
            raise PermissionError(
                f"git {arg.split('=')[0]} is not allowed for agents - "
                f"it can be used to execute arbitrary commands via config hooks"
            )
        # Skip known global flags that take a value
        if arg in ("-C", "--git-dir", "--work-tree", "--namespace"):
            i += 2  # skip the flag and its argument
            continue
        # Skip global boolean flags
        if arg.startswith("-") and not arg.startswith("--"):
            # Single-char flags like -p, -P; but -c is caught above
            i += 1
            continue
        if arg.startswith("--"):
            # Long flags like --bare, --no-pager
            i += 1
            continue
        # First non-flag argument is the subcommand
        return arg, i
    return None, -1


def _check_git_command(argv: list[str], agent_name: str, base: Path) -> None:
    """For git commands that modify the worktree, check affected files.

    Uses git's own tools (--stat, diff --name-only) to determine which
    files would be touched, then runs the standard access checks on each.
    Fails closed: if we cannot determine which files are affected, the
    command is blocked rather than allowed unchecked.
    """
    if len(argv) < 2:
        return

    # Extract the real subcommand, blocking dangerous global flags (e.g. -c)
    subcmd, _subcmd_idx = _extract_git_subcmd(argv)
    if subcmd is None:
        return

    # Block dangerous subcommands outright - agents should never use these.
    if subcmd in GIT_BLOCKED_SUBCOMMANDS:
        raise PermissionError(
            f"git {subcmd} is not allowed for agents"
        )

    if subcmd not in GIT_WRITE_SUBCOMMANDS:
        return

    # For 'git add': check the explicit file args for test-file / team access.
    # Broad adds (-A, --all, .) are resolved via git itself so that file-level
    # policy is always enforced - there is no "downstream" check to fall back on.
    if subcmd == "add":
        files = []
        past_separator = False
        is_broad = False
        for arg in argv[2:]:
            if arg == "--":
                past_separator = True
                continue
            if arg in ("-A", "--all", "."):
                is_broad = True
                continue
            if past_separator or not arg.startswith("-"):
                files.append(arg)
        if is_broad:
            # Enumerate what git *would* stage and check each file.
            try:
                result = subprocess.run(
                    ["git", "add", "--dry-run", "-A"],
                    capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=10, cwd=base,
                )
                if result.returncode == 0:
                    # dry-run output: "add 'path/to/file'" per line
                    for line in result.stdout.splitlines():
                        line = line.strip()
                        if line.startswith("add '") and line.endswith("'"):
                            files.append(line[5:-1])
                        elif line.startswith("remove '") and line.endswith("'"):
                            files.append(line[8:-1])
                else:
                    raise PermissionError(
                        "Cannot determine which files 'git add -A' would stage - "
                        "command blocked (fail-closed)."
                    )
            except subprocess.TimeoutExpired:
                raise PermissionError(
                    "Cannot determine which files 'git add -A' would stage - "
                    "command blocked (fail-closed)."
                )
        for path in files:
            _check_team_path_access(path, agent_name)
            _check_test_file_write(path, agent_name)
        return

    # For 'git commit': inspect staged files AND any files that auto-staging
    # flags (-a/--all/--include) would pull in.  Without this, an agent can
    # bypass the index check by committing with -a to auto-stage dirty files.
    if subcmd == "commit":
        # Detect auto-staging flags - must handle combined short flags like
        # -am (which is -a -m combined).  Check if 'a' appears in any short
        # flag cluster, or if --all/--include are present.
        has_auto_stage = any(
            arg == "--all"
            or arg.startswith("--include")
            or (arg.startswith("-") and not arg.startswith("--") and "a" in arg[1:])
            for arg in argv[2:]
        )
        try:
            # Always check the current index
            result = subprocess.run(
                ["git", "diff", "--cached", "--name-only"],
                capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=10, cwd=base,
            )
            if result.returncode != 0:
                raise PermissionError(
                    "Cannot determine staged files for 'git commit' - "
                    "command blocked (fail-closed)."
                )
            staged = [l.strip() for l in result.stdout.splitlines() if l.strip()]

            # If -a/--all, also check modified tracked files (what -a would stage)
            if has_auto_stage:
                dirty_result = subprocess.run(
                    ["git", "diff", "--name-only"],
                    capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=10, cwd=base,
                )
                if dirty_result.returncode != 0:
                    raise PermissionError(
                        "Cannot determine dirty files for 'git commit -a' - "
                        "command blocked (fail-closed)."
                    )
                dirty = [l.strip() for l in dirty_result.stdout.splitlines() if l.strip()]
                staged.extend(dirty)
        except subprocess.TimeoutExpired:
            raise PermissionError(
                "Cannot determine staged files for 'git commit' - "
                "command blocked (fail-closed)."
            )
        for path in staged:
            _check_team_path_access(path, agent_name)
            _check_test_file_write(path, agent_name)
        return

    affected = _get_git_affected_files(argv, base)
    if affected is None:
        raise PermissionError(
            f"Cannot determine which files 'git {subcmd}' would modify - "
            f"command blocked (fail-closed). Verify the ref/arguments are valid."
        )
    for path in affected:
        _check_team_path_access(path, agent_name)
        _check_test_file_write(path, agent_name)
