"""File operation implementations - read, write, edit, list."""

from __future__ import annotations

import os
from pathlib import Path


def _validate_path(path: str, base: Path) -> Path:
    """Resolve path and ensure it doesn't escape the project root."""
    p = Path(path)
    if p.is_absolute():
        resolved = p.resolve()
    else:
        resolved = (base / path).resolve()
    if not resolved.is_relative_to(base.resolve()):
        raise PermissionError(f"Path escapes project root: {path}")
    return resolved


def _validate_path_no_symlinks(path: str, base: Path) -> Path:
    """Resolve path, ensure it stays in the project root, and reject symlinks.

    Walks the *unresolved* path components (using lstat via Path.is_symlink)
    so that symlinks are detected before they are followed.  The previous
    implementation checked the *resolved* path - which never contains
    symlinks because .resolve() already followed them.

    Note: There is a narrow TOCTOU gap between this check and the actual
    file I/O.  We mitigate this by (a) keeping the check-to-use window as
    small as possible, (b) using O_NOFOLLOW in _write_file_safe, and (c)
    noting that agents don't have fine-grained timing control and symlink
    creation itself goes through this same validation.
    """
    resolved = _validate_path(path, base)

    # Build the unresolved absolute path, then collapse . / .. without
    # following symlinks (os.path.normpath is purely lexical).
    p = Path(path)
    if not p.is_absolute():
        p = base / path
    normalized = Path(os.path.normpath(p))

    # Walk root → leaf; is_symlink() uses lstat so it sees the link itself.
    current = Path(normalized.anchor)
    for part in normalized.parts[1:]:
        current = current / part
        if not current.exists():
            break  # remaining components don't exist yet - no symlinks possible
        if current.is_symlink():
            raise PermissionError(
                f"Symlink detected in path: {current} - symlinks are not allowed "
                f"in file operations to prevent path traversal attacks"
            )
    return resolved


def _read_file(path: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    p = _validate_path_no_symlinks(path, b)
    if not p.exists():
        return f"Error: File '{path}' does not exist."
    if not p.is_file():
        return f"Error: '{path}' is not a file."
    return p.read_text(encoding="utf-8")


def _write_file(path: str, content: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    p = _validate_path_no_symlinks(path, b)
    p.parent.mkdir(parents=True, exist_ok=True)
    _write_file_safe(p, content.encode("utf-8"))
    return f"Successfully wrote {len(content)} characters to '{path}'."


def _write_file_safe(p: Path, content_bytes: bytes) -> None:
    """Write to a file with O_NOFOLLOW TOCTOU mitigation.

    Shared by _write_file and _edit_file to prevent symlink-swap attacks
    between validation and the actual write.
    """
    o_nofollow = getattr(os, "O_NOFOLLOW", 0)
    if o_nofollow:
        flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | o_nofollow
        try:
            fd = os.open(str(p), flags, 0o644)
        except OSError as exc:
            if exc.errno == 40:  # errno.ELOOP - target is a symlink
                raise PermissionError(
                    f"Symlink detected at write time: {p} - refusing to follow"
                )
            raise
        try:
            os.write(fd, content_bytes)
        finally:
            os.close(fd)
    else:
        p.write_bytes(content_bytes)


def _edit_file(path: str, old_string: str, new_string: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    p = _validate_path_no_symlinks(path, b)
    if not p.exists():
        return f"Error: File '{path}' does not exist."
    content = p.read_text(encoding="utf-8")
    if old_string not in content:
        return f"Error: Could not find the specified string in '{path}'."
    count = content.count(old_string)
    if count > 1:
        return (
            f"Error: Found {count} occurrences of the string in '{path}'. "
            "Please provide a more specific string to replace."
        )
    new_content = content.replace(old_string, new_string, 1)
    # Use O_NOFOLLOW write to prevent TOCTOU symlink-swap attacks
    _write_file_safe(p, new_content.encode("utf-8"))
    return f"Successfully edited '{path}'."


def _list_directory(path: str, base: Path | None = None) -> str:
    b = base or Path.cwd()
    p = _validate_path(path, b)
    if not p.exists():
        return f"Error: Directory '{path}' does not exist."
    if not p.is_dir():
        return f"Error: '{path}' is not a directory."
    entries = sorted(p.iterdir())
    lines = []
    for entry in entries:
        prefix = "d " if entry.is_dir() else "f "
        lines.append(f"{prefix}{entry.name}")
    return "\n".join(lines) if lines else "(empty directory)"
