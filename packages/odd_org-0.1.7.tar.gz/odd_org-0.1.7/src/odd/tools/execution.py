"""Tool execution engine - dispatch, command execution, escalation handling."""

from __future__ import annotations

import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Callable

from odd.config import SHELL_COMMAND_TIMEOUT
from odd.tools.isolation import (
    ALLOWED_COMMANDS,
    BLOCKED_COMMANDS,
    check_command_hidden_odd_dirs as _check_command_hidden_odd_dirs_policy,
    check_command_team_access as _check_command_team_access_policy,
    check_command_test_write as _check_command_test_write_policy,
    check_cp_mv_paths,
    check_find_dangerous_flags,
    check_read_access,
    check_shell_metacharacters,
    check_test_file_write as _check_test_file_write_policy,
    check_team_path_access as _check_team_path_access_policy,
    check_write_access,
)

class _CancelledDuringTool(Exception):
    """Raised when a tool execution is interrupted by a War Room cancel."""
    pass


# ── Imports from submodules ───────────────────────────────────────────
from odd.tools.file_ops import (  # noqa: F401 - re-exported
    _edit_file,
    _list_directory,
    _read_file,
    _validate_path,
    _validate_path_no_symlinks,
    _write_file,
    _write_file_safe,
)
from odd.tools.git_checks import (  # noqa: F401 - re-exported
    _GIT_EXPLICIT_FILE_SUBCMDS,
    _check_git_command,
    _extract_git_subcmd,
    _get_git_affected_files,
)


def _audit_log(agent: str, tool: str, tool_input: dict[str, Any], result: str, duration_ms: int, exit_code: int | None = None, sprint: int | None = None) -> None:
    """Log a tool invocation to the unified activity log."""
    from odd.tracing import log_tool_use

    log_tool_use(
        agent=agent,
        tool=tool,
        tool_input=tool_input,
        result=result,
        duration_ms=duration_ms,
        exit_code=exit_code,
        sprint=sprint,
    )


# ── Policy wrappers ────────────────────────────────────────────────────
# DirectRunner uses PermissionError exceptions. These thin wrappers
# convert the policy's string-or-None return into raise-or-return.


def _check_team_path_access(path: str, agent_name: str) -> None:
    reason = _check_team_path_access_policy(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_test_file_write(path: str, agent_name: str) -> None:
    reason = _check_test_file_write_policy(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_read_access(path: str, agent_name: str) -> None:
    reason = check_read_access(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_write_access(path: str, agent_name: str) -> None:
    reason = check_write_access(path, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_command_team_access(command: str, agent_name: str) -> None:
    reason = _check_command_team_access_policy(command, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_command_test_write(command: str, agent_name: str) -> None:
    reason = _check_command_test_write_policy(command, agent_name)
    if reason:
        raise PermissionError(reason)


def _check_command_hidden_odd_dirs(command: str, agent_name: str) -> None:
    reason = _check_command_hidden_odd_dirs_policy(command, agent_name)
    if reason:
        raise PermissionError(reason)


def execute_tool(
    tool_name: str,
    tool_input: dict[str, Any],
    cwd: Path | None = None,
    agent_name: str = "unknown",
    sprint: int | None = None,
    cancel_check: Callable[[], bool] | None = None,
) -> str:
    """Execute a tool and return the result string.

    If cwd is provided, file and command tools operate relative to that
    directory instead of the process cwd (used for worktree isolation).
    """
    base = cwd or Path.cwd()
    start = time.monotonic()
    exit_code = None
    try:
        match tool_name:
            case "read_file":
                _check_read_access(tool_input["path"], agent_name)
                result = _read_file(tool_input["path"], base)
            case "write_file":
                _check_write_access(tool_input["path"], agent_name)
                result = _write_file(tool_input["path"], tool_input["content"], base)
            case "edit_file":
                _check_write_access(tool_input["path"], agent_name)
                result = _edit_file(
                    tool_input["path"],
                    tool_input["old_string"],
                    tool_input["new_string"],
                    base,
                )
            case "list_directory":
                path = tool_input.get("path", ".")
                _check_read_access(path, agent_name)
                result = _list_directory(path, base)
            case "run_command":
                cmd_argv = _split_command(tool_input["command"])
                if cmd_argv and Path(cmd_argv[0]).stem.lower() == "git":
                    # Git commands: use structural file-level checks
                    _check_git_command(cmd_argv, agent_name, base)
                # Always run regex-based checks as a fallback layer
                _check_command_team_access(tool_input["command"], agent_name)
                _check_command_test_write(tool_input["command"], agent_name)
                _check_command_hidden_odd_dirs(tool_input["command"], agent_name)
                result = _run_command(tool_input["command"], base, cancel_check=cancel_check)
            case "escalate":
                result = _escalate(tool_input["reason"], tool_input.get("severity", "needs_decision"))
            case "request_command":
                result = (
                    "Command request registered. STOP working on this task - "
                    "wait for CEO approval."
                )
            case _:
                result = f"Error: Unknown tool '{tool_name}'"
        duration_ms = int((time.monotonic() - start) * 1000)
        # Detect exit code from run_command results
        if tool_name == "run_command" and "(command failed)" in result:
            exit_code = 1
        elif tool_name == "run_command":
            exit_code = 0
        _audit_log(agent_name, tool_name, tool_input, result, duration_ms, exit_code, sprint=sprint)
        return result
    except Exception as e:
        duration_ms = int((time.monotonic() - start) * 1000)
        _audit_log(agent_name, tool_name, tool_input, str(e), duration_ms, exit_code=-1, sprint=sprint)
        return f"Error: {e}"


def _escalate(reason: str, severity: str) -> str:
    """Return the escalation response message."""
    if severity == "blocker":
        return "Escalation registered. STOP working on this task - wait for CEO direction."
    elif severity == "needs_decision":
        return "Escalation registered. Continue with your best judgment for now, but the CEO will review."
    else:
        return "Heads-up noted. The CEO will be informed. Continue your work."


# No restricted commands - interpreters and package managers are fully blocked.
RESTRICTED_COMMANDS: set[str] = set()

# Set via --unsafe-shell CLI flag to bypass the command allowlist.
_unsafe_shell: bool = False


def _validate_command(argv: list[str], base: Path) -> None:
    """Ensure the command executable is on the allowlist.

    Interpreters and package managers are unconditionally blocked - even
    with --unsafe-shell - because they are universal sandbox escapes:
    an agent can write a malicious file and then execute it, bypassing
    every file-level permission check.
    """
    # Strip Windows extensions (.exe, .cmd, .bat) so "python.exe" matches
    # "python" in the block list.  But check the full name first so that
    # names like "py.test" (where .test looks like an extension) are matched.
    raw_name = Path(argv[0]).name.lower()
    exe = raw_name
    # Only strip known Windows executable extensions, not arbitrary dots
    _WIN_EXE_SUFFIXES = {".exe", ".cmd", ".bat", ".com"}
    if any(raw_name.endswith(suffix) for suffix in _WIN_EXE_SUFFIXES):
        exe = Path(raw_name).stem
    # Hard block - never allow, not even with --unsafe-shell
    if exe in BLOCKED_COMMANDS:
        raise PermissionError(
            f"Command not allowed: {exe}. Agents cannot run interpreters or "
            f"package managers directly. Use submit_dependency_request to "
            f"propose new dependencies."
        )
    if _unsafe_shell:
        return
    if exe not in ALLOWED_COMMANDS:
        raise PermissionError(f"Command not allowed: {exe}")
    # Command-specific restrictions on allowed commands
    reason = check_find_dangerous_flags(argv)
    if reason:
        raise PermissionError(reason)
    reason = check_cp_mv_paths(argv, base)
    if reason:
        raise PermissionError(reason)


# Env vars whose values are safe to expose or too short/common to redact.
# We only sanitize secret-like variables, not PATH, APPDATA, etc.
_SENSITIVE_ENV_PREFIXES = {"API_KEY", "SECRET", "TOKEN", "PASSWORD", "CREDENTIAL"}


def _sanitize_error(error: str) -> str:
    """Strip sensitive env var values from error output before returning to agents.

    Only redacts variables whose names suggest they hold secrets.
    Redacting common vars like PATH or APPDATA would corrupt normal output.
    """
    for key, val in os.environ.items():
        if len(val) <= 3:
            continue
        upper_key = key.upper()
        if any(prefix in upper_key for prefix in _SENSITIVE_ENV_PREFIXES):
            error = error.replace(val, f"${key}")
    return error


def _split_command(command: str) -> list[str]:
    """Split a command string into argv, respecting the current platform.

    On Windows, shlex.split(posix=True) treats backslashes as escape
    characters, mangling paths like ``src\\odd\\cli.py``. We use
    posix=False to keep backslashes literal, then strip the residual
    outer quotes that posix=False preserves on each token.
    """
    if sys.platform == "win32":
        tokens = shlex.split(command, posix=False)
        # posix=False keeps surrounding quotes - strip them so subprocess
        # sees the actual argument value.
        return [t.strip('"').strip("'") for t in tokens]
    return shlex.split(command)


def _run_command(
    command: str,
    base: Path | None = None,
    cancel_check: Callable[[], bool] | None = None,
) -> str:
    b = base or Path.cwd()
    argv = _split_command(command)
    _validate_command(argv, b)
    # On Windows, shell=True means cmd.exe interprets metacharacters.
    # Block redirection/piping to prevent file writes bypassing validation.
    if sys.platform == "win32":
        reason = check_shell_metacharacters(command)
        if reason:
            raise PermissionError(reason)

    proc = subprocess.Popen(
        argv,
        shell=(sys.platform == "win32"),  # nosec B602 - argv is validated by _validate_command
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        cwd=b,
    )
    try:
        # Poll for cancellation every 2 seconds instead of blocking
        deadline = time.monotonic() + SHELL_COMMAND_TIMEOUT
        while proc.poll() is None:
            if cancel_check and cancel_check():
                proc.kill()
                proc.wait(timeout=5)
                raise _CancelledDuringTool("Command cancelled via War Room")
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                proc.kill()
                proc.wait(timeout=5)
                raise subprocess.TimeoutExpired(argv, SHELL_COMMAND_TIMEOUT)
            try:
                proc.wait(timeout=min(2, remaining))
            except subprocess.TimeoutExpired:
                pass  # loop back to check cancel and deadline
    except BaseException:
        proc.kill()
        proc.wait(timeout=5)
        raise

    stdout = proc.stdout.read() if proc.stdout else ""
    stderr = proc.stderr.read() if proc.stderr else ""
    output = ""
    if stdout:
        output += stdout
    if stderr:
        output += ("\n" if output else "") + _sanitize_error(stderr)
    if proc.returncode != 0:
        output += f"\n(command failed)"
    return output or "(no output)"
