"""Implementation of 'odd init' - project initialization."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt


from odd.agent import AgentEngine
from odd.cfo import CFO
from odd.config import DEFAULT_SPRINT_BUDGET, DEFAULT_TOTAL_BUDGET, MAX_REVIEW_PASSES, refresh_pricing
from odd.labels import compensation_quip, format_model_choices, model_tier_label, role_label, resolve_model_choice
from odd.processes import _multiline_input
from odd.models import CEOStyle, ModelTier, ProjectConfig, RoleType
from odd.parsers import parse_consultant_specs
from odd.roles import create_core_team, recruit_consultant
from odd.state import StateManager
from odd.tools import EXPLORE_TOOLS, SUBMIT_CONSULTANT_SPECS, WRITE_NOTES_TOOL
from odd.values import CompanyValues


console = Console()


def run_init(
    state: StateManager,
    get_engine: Callable[..., Any],
    get_cfo: Callable[..., Any],
) -> None:
    """Full init flow: gather info, create team, recruit consultants."""
    if state.is_initialized():
        console.print("[yellow]This project is already initialized.[/yellow]")
        console.print("Use 'odd sprint' to start a new sprint.")
        return

    console.print(Panel(
        "[bold]Welcome to ODD - Organization Driven Development[/bold]\n\n"
        "You are the CEO. Let's get your organization set up.\n"
        "Your Lead Developer, Cody, will ask you some questions about the project.",
        style="bold blue",
    ))

    # Gather project basics
    project_name = Prompt.ask("\n[bold]What's the project name?[/bold]")

    # Git check - sprints need git for branching, worktrees, and merging
    _ensure_git(state.root)

    # Model configuration
    model_overrides = _configure_models()

    # CEO style
    ceo_style = _configure_ceo_style()

    # Review passes
    review_passes = _configure_review_passes()

    # Initialize state
    config = ProjectConfig(
        name=project_name,
        model_overrides=model_overrides,
        ceo_style=ceo_style,
        review_passes=review_passes,
    )
    state.init(config)

    # Fetch latest pricing from Anthropic
    console.print("[dim]Fetching latest model pricing from Anthropic...[/dim]")
    pricing = refresh_pricing(state.odd_dir)
    if pricing:
        console.print("[green]Pricing updated.[/green]")

    # Set budget (interactive)
    cfo = get_cfo(state)
    existing_budget = cfo._load_budget()
    if "sprint_budget" not in existing_budget and "total_budget" not in existing_budget:
        sprint_budget, total_budget = _configure_budget()
        cfo.set_budget(sprint_budget=sprint_budget, total_budget=total_budget)
        console.print(
            f"[green]Budget set:[/green] "
            f"${sprint_budget:.2f}/sprint, ${total_budget:.2f} total. "
            f"Change anytime with [bold]odd budget[/bold]."
        )

    # Create and save core team
    team = create_core_team(model_overrides)
    for persona in team.values():
        state.save_persona(persona)

    console.print("\n[green]Organization created![/green]")
    console.print("Core team is ready:")
    for key, persona in team.items():
        console.print(f"  • {persona.name} - {persona.title} ({model_tier_label(persona.effective_model())})")

    # Lead dev conversation + consultant recruitment
    engine = get_engine(state)
    lead_dev = team["lead_dev"]

    conversation_history = _lead_dev_conversation(engine, lead_dev, project_name)
    _propose_values(engine, lead_dev, state, conversation_history)
    _recruit_consultants(engine, lead_dev, team, state, conversation_history)

    # Update config with project description
    description = engine.invoke(
        persona=lead_dev,
        user_message=(
            "Based on our conversation, write a one-paragraph project description "
            "that captures what we're building, who it's for, and what success looks like. "
            "Just the description, nothing else."
        ),
        conversation_history=conversation_history,
        tools=False,
    )
    config.description = description
    state.save_config(config)

    # CFO reports on initialization costs
    cfo = get_cfo(state)
    console.print(Panel(Markdown(cfo.financial_report()), title="Bill the CFO - Initialization Costs", style="yellow"))

    console.print(Panel(
        f"[bold green]Project '{project_name}' is ready![/bold green]\n\n"
        f"{description}\n\n"
        "Run [bold]odd sprint[/bold] to start your first sprint.",
        style="green",
    ))


def _ensure_git(project_root: Path) -> None:
    """Check for a git repo and offer to initialize one if missing.

    Sprints depend on git for branching, worktrees, and merging.
    Without it, parallel tasks fail and sprint history is lost.
    """
    if not shutil.which("git"):
        console.print(
            "[yellow]Warning:[/yellow] git is not installed. "
            "Sprints require git for branching and parallel tasks. "
            "Install git and run [bold]git init[/bold] before starting a sprint."
        )
        return

    has_git = False
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=5, cwd=project_root,
        )
        if result.returncode == 0:
            has_git = True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    if not has_git:
        console.print(
            "\n[yellow]No git repository found.[/yellow] "
            "ODD uses git for sprint branches, parallel tasks, and change tracking."
        )
        init_git = Prompt.ask("Initialize a git repo now?", choices=["y", "n"], default="y")

        if init_git == "y":
            try:
                subprocess.run(
                    ["git", "init"], capture_output=True, text=True,
                    encoding="utf-8", errors="replace",
                    timeout=10, cwd=project_root, check=True,
                )
                # Create initial commit so branches work
                subprocess.run(
                    ["git", "add", "-A"], capture_output=True, text=True,
                    encoding="utf-8", errors="replace",
                    timeout=10, cwd=project_root,
                )
                subprocess.run(
                    ["git", "commit", "-m", "Initial commit (odd init)", "--allow-empty"],
                    capture_output=True, text=True,
                    encoding="utf-8", errors="replace",
                    timeout=10, cwd=project_root,
                )
                console.print("[green]Git repository initialized with initial commit.[/green]")
                has_git = True
            except subprocess.CalledProcessError as exc:
                console.print(f"[red]git init failed:[/red] {exc.stderr or exc}")
        else:
            console.print(
                "[dim]You can initialize git later with: "
                "git init && git add -A && git commit -m 'init'[/dim]"
            )

    if has_git:
        _ensure_gitignore(project_root)


def _ensure_gitignore(project_root: Path) -> None:
    """Seed .gitignore with ecosystem-appropriate patterns."""
    from odd.git.gitignore import seed_gitignore

    groups, created_fresh = seed_gitignore(project_root)
    if groups:
        label = ", ".join(groups)
        if created_fresh:
            console.print(f"[green]Created .gitignore ({label} patterns)[/green]")
        else:
            console.print(f"[green]Updated .gitignore ({label} patterns)[/green]")


def _configure_models() -> dict[RoleType, ModelTier]:
    """Interactive model tier configuration."""
    console.print("\n[bold]Model Configuration[/bold]")
    console.print("Defaults: Premium (Opus) for Lead Dev & QA, Standard (Sonnet) for others.")
    customize = Prompt.ask("Customize model assignments?", choices=["y", "n"], default="n")

    model_overrides: dict[RoleType, ModelTier] = {}
    if customize == "y":
        console.print(format_model_choices())
        for role in RoleType:
            if role == RoleType.CONSULTANT:
                continue
            from odd.models import DEFAULT_MODEL_MAP
            default_tier = DEFAULT_MODEL_MAP[role]
            default_num = {"HIGH": "1", "STANDARD": "2", "FAST": "3"}[default_tier.name]
            choice = Prompt.ask(
                f"  {role_label(role)}",
                choices=["1", "2", "3"],
                default=default_num,
            )
            model_key = resolve_model_choice(choice)
            tier = ModelTier.from_name(model_key)
            model_overrides[role] = tier
            quip = compensation_quip(tier)
            if quip:
                console.print(f"    [dim italic]{quip}[/dim italic]")

    return model_overrides


def _configure_budget() -> tuple[float, float]:
    """Interactive budget configuration with sensible defaults."""
    console.print("\n[bold]Budget[/bold]")
    console.print(
        f"  Default: ${DEFAULT_SPRINT_BUDGET:.0f} per sprint, "
        f"${DEFAULT_TOTAL_BUDGET:.0f} total cap."
    )
    customize = Prompt.ask("Customize budget?", choices=["y", "n"], default="n")

    if customize == "y":
        sprint_input = Prompt.ask(
            f"  Max spend per sprint (USD)",
            default=str(DEFAULT_SPRINT_BUDGET),
        )
        total_input = Prompt.ask(
            f"  Total budget cap (USD)",
            default=str(DEFAULT_TOTAL_BUDGET),
        )
        try:
            sprint_budget = max(float(sprint_input), 0.01)
        except ValueError:
            sprint_budget = DEFAULT_SPRINT_BUDGET
        try:
            total_budget = max(float(total_input), sprint_budget)
        except ValueError:
            total_budget = DEFAULT_TOTAL_BUDGET
        return sprint_budget, total_budget

    return DEFAULT_SPRINT_BUDGET, DEFAULT_TOTAL_BUDGET


def _configure_ceo_style() -> CEOStyle:
    """Interactive CEO style configuration."""
    console.print("\n[bold]Management Style[/bold]")
    console.print(
        "  [bold]1.[/bold] Hands-on  - see everything, approve everything\n"
        "  [bold]2.[/bold] Balanced  - summaries + milestone check-ins (default)\n"
        "  [bold]3.[/bold] Delegator - blockers only, team runs autonomously"
    )
    choice = Prompt.ask("Your style", choices=["1", "2", "3"], default="2")
    return {"1": CEOStyle.HANDS_ON, "2": CEOStyle.BALANCED, "3": CEOStyle.DELEGATOR}[choice]


def _configure_review_passes() -> int:
    """Interactive review pass count configuration."""
    console.print("\n[bold]Code Review[/bold]")
    console.print(
        "After each sprint, an anonymous reviewer scores the code and Cody\n"
        "fixes any issues found. More passes = more thorough.\n"
        "  [bold]0[/bold] = skip review\n"
        "  [bold]1[/bold] = quick (one pass, default)\n"
        "  [bold]2[/bold] = standard (review → fix → re-review → fix)\n"
        "  [bold]3+[/bold] = thorough"
    )
    choice = Prompt.ask("Default review passes per sprint", default="1")
    try:
        n = int(choice)
        return min(max(n, 0), MAX_REVIEW_PASSES)
    except ValueError:
        return 1


def _propose_values(
    engine: AgentEngine,
    lead_dev,
    state: StateManager,
    conversation_history: list[dict],
) -> None:
    """Have the Lead Dev propose company values based on the init conversation."""
    console.print(Panel(
        "Based on your conversation, your Lead Dev will propose company values.\n"
        "These guide every agent's decisions and priorities.",
        style="blue",
    ))

    proposal = engine.invoke(
        persona=lead_dev,
        user_message=(
            "Based on our conversation, propose 3-5 company values that capture "
            "the principles and priorities the CEO seems to care about. "
            "Respond with ONLY a JSON array of short, actionable strings. "
            'Example: ["Ship early and iterate", "Simplicity over cleverness"]'
        ),
        conversation_history=conversation_history,
        tools=False,
    )

    # Parse JSON array from response
    proposed: list[str] = []
    try:
        parsed = json.loads(proposal.strip())
        if isinstance(parsed, list):
            proposed = [str(v).strip() for v in parsed if str(v).strip()]
    except json.JSONDecodeError:
        # Fallback: try to extract JSON array from within the response
        match = re.search(r"\[.*\]", proposal, re.DOTALL)
        if match:
            try:
                parsed = json.loads(match.group())
                proposed = [str(v).strip() for v in parsed if str(v).strip()]
            except json.JSONDecodeError:
                pass

    # Final fallback: parse as plain-text lines (with optional numbering)
    if not proposed:
        for line in proposal.strip().splitlines():
            cleaned = re.sub(r"^\d+[\.\)]\s*", "", line.strip())
            if cleaned:
                proposed.append(cleaned)

    cv = CompanyValues(state.odd_dir)

    if proposed:
        cv.set_values(proposed)
        console.print(Panel("[bold]Proposed Company Values[/bold]", style="blue"))
        for i, v in enumerate(proposed, 1):
            console.print(f"  {i}. {v}")

    console.print(
        "\nEdit these values (or 'done' to accept, 'remove N' to remove, "
        "type text to add):"
    )

    while True:
        inp = Prompt.ask("[bold yellow]CEO[/bold yellow]")
        stripped = inp.strip()
        if stripped.lower() == "done":
            break
        elif stripped.lower().startswith("remove "):
            try:
                idx = int(stripped.split()[1]) - 1
                removed = cv.remove_value(idx)
                if removed:
                    console.print(f"[yellow]Removed: {removed}[/yellow]")
                else:
                    console.print("[red]Invalid index.[/red]")
            except (ValueError, IndexError):
                console.print("[red]Usage: remove N[/red]")
        elif stripped:
            cv.add_value(stripped)
            console.print(f"[green]Added: {stripped}[/green]")

    final = cv.get_values()
    if final:
        console.print(Panel("[bold]Company Values[/bold]", style="green"))
        for i, v in enumerate(final, 1):
            console.print(f"  {i}. {v}")
        console.print("\n[dim]These values will guide every agent's decisions.[/dim]")
    else:
        console.print("[dim]No values set. You can add them later with 'odd values'.[/dim]")


def _lead_dev_conversation(
    engine: AgentEngine,
    lead_dev,
    project_name: str,
) -> list[dict]:
    """Run the initial CEO–Lead Dev conversation."""
    console.print(Panel(
        "Your Lead Developer would like to understand the project.\n"
        "Have a conversation - they'll ask about goals, scope, and what\n"
        "expertise you might need. Type 'done' when ready to proceed.",
        style="blue",
    ))

    conversation_history: list[dict] = []

    init_tools = EXPLORE_TOOLS + [WRITE_NOTES_TOOL]

    with engine.conversation(persona=lead_dev, tools=False, extra_tools=init_tools) as conv:
        console.print("[bold blue]Lead Developer:[/bold blue]")
        opening = conv.send(
            "You've just been hired as the Lead Developer for a new project called "
            f"'{project_name}'. The CEO is here to tell you about it. Introduce "
            "yourself briefly, then ask the CEO to describe the project - what they "
            "want to build, who it's for, and what success looks like. Be conversational "
            "and enthusiastic.\n\n"
            "You have read-only access to the project directory. Feel free to explore "
            "existing files with list_directory and read_file to understand what's "
            "already here as it becomes relevant to the conversation.\n\n"
            "IMPORTANT: As you learn about the project, maintain a file at .odd/goal.md "
            "with high-level notes about the project vision, goals, target users, success "
            "criteria, and key decisions. Update it as the conversation progresses using "
            "write_file. This serves as the project's north star document."
        )
        conversation_history.append({"role": "assistant", "content": opening})

        while True:
            ceo_input = _multiline_input()
            if ceo_input.lower().strip() == "done":
                break

            conversation_history.append({"role": "user", "content": ceo_input})

            console.print("[bold blue]Lead Developer:[/bold blue]")
            response = conv.send(ceo_input)
            conversation_history.append({"role": "assistant", "content": response})

    return conversation_history


def _recruit_consultants(
    engine: AgentEngine,
    lead_dev,
    team: dict,
    state: StateManager,
    conversation_history: list[dict],
) -> None:
    """Ask lead dev for consultant recommendations and recruit them."""
    console.print("[bold blue]Recommended Consultants:[/bold blue]")

    consult_response = engine.invoke(
        persona=lead_dev,
        user_message=(
            "Based on our conversation about the project, what specialized consultants "
            "would benefit this project? Use the submit_consultant_specs tool to submit "
            "your recommendations.\n\n"
            "Fallback format (if you can't use the tool):\n"
            "CONSULTANT: <descriptive name/title>\n"
            "JD: <job description - what specific expertise and tasks they'd handle>\n\n"
            "Only recommend consultants whose expertise would genuinely add a different "
            "perspective. Don't recommend someone for something you can handle yourself."
        ),
        conversation_history=conversation_history,
        tools=False,
        extra_tools=[SUBMIT_CONSULTANT_SPECS],
    )

    submissions = engine.pop_submissions("submit_consultant_specs")
    structured = submissions[0]["data"] if submissions else None
    consultant_specs = parse_consultant_specs(consult_response, structured_data=structured)

    if consultant_specs:
        console.print(f"\n[bold]Recruiting {len(consultant_specs)} consultant(s)...[/bold]")
        recruiter = team["recruiter"]

        tier_map = {"opus": ModelTier.HIGH, "sonnet": ModelTier.STANDARD, "haiku": ModelTier.FAST}
        for name, jd, model_tier in consultant_specs:
            console.print(f"  Recruiting: {name} ({model_tier})...")
            consultant = recruit_consultant(
                engine, recruiter, jd, name,
                model_tier=tier_map.get(model_tier, ModelTier.STANDARD),
            )
            state.save_persona(consultant)
            console.print(f"  [green]✓ {name} is on board![/green]")
