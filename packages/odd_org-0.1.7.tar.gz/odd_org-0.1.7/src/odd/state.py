"""Manages the .odd/ directory - the organization's persistent state."""

from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any

from odd.config import (
    ARCHIVED_DIR_NAME,
    CODE_REVIEW_FILE,
    CONFIG_FILE,
    CONSULTANTS_DIR_NAME,
    CORE_TEAM_ROLES,
    JOB_DESCRIPTION_FILE,
    PERSONA_FILE,
    RATINGS_FILE,
    RESUME_FILE,
    ROADMAP_FILE,
    SPRINT_FILE,
    VACATION_PLAN_FILE,
    VACATION_REPORT_FILE,
)
from odd.models import (
    ConsultantRecord,
    Persona,
    ProjectConfig,
    Roadmap,
    Sprint,
    TaskOutcome,
    VacationPlan,
    VacationReport,
)


class StateManager:
    """Reads and writes org state to the .odd/ directory."""

    def __init__(self, project_root: Path | None = None):
        self.root = (project_root or Path.cwd()).resolve()
        self.odd_dir = self.root / ".odd"
        self._record_lock = threading.Lock()
        self._sprint_lock = threading.Lock()
        self._config_lock = threading.Lock()

    @property
    def config_path(self) -> Path:
        return self.odd_dir / CONFIG_FILE

    @property
    def team_dir(self) -> Path:
        return self.odd_dir / "team"

    @property
    def sprints_dir(self) -> Path:
        return self.odd_dir / "sprints"

    @property
    def notes_dir(self) -> Path:
        return self.odd_dir / "notes"

    def is_initialized(self) -> bool:
        return self.config_path.exists()

    def init(self, config: ProjectConfig) -> None:
        """Initialize the .odd/ directory structure."""
        self.odd_dir.mkdir(exist_ok=True)
        if os.name != "nt":
            os.chmod(self.odd_dir, 0o700)  # Owner-only on Unix
        self.team_dir.mkdir(exist_ok=True)
        self.sprints_dir.mkdir(exist_ok=True)
        self.notes_dir.mkdir(exist_ok=True)

        # Create subdirs for core team personal folders
        for role in CORE_TEAM_ROLES:
            (self.team_dir / role).mkdir(exist_ok=True)

        (self.team_dir / CONSULTANTS_DIR_NAME).mkdir(exist_ok=True)

        self.save_config(config)

    def save_config(self, config: ProjectConfig) -> None:
        with self._config_lock:
            self.config_path.write_text(config.model_dump_json(indent=2), encoding="utf-8")

    def load_config(self) -> ProjectConfig:
        with self._config_lock:
            return ProjectConfig.model_validate_json(self.config_path.read_text(encoding="utf-8"))

    def save_persona(self, persona: Persona) -> None:
        """Save a persona to the team directory."""
        if persona.role_type.value == "consultant":
            persona_dir = self.team_dir / CONSULTANTS_DIR_NAME / _slugify(persona.name)
        else:
            persona_dir = self.team_dir / persona.role_type.value

        persona_dir.mkdir(parents=True, exist_ok=True)
        (persona_dir / PERSONA_FILE).write_text(persona.model_dump_json(indent=2), encoding="utf-8")

        # Write human-readable files too
        if persona.job_description:
            (persona_dir / JOB_DESCRIPTION_FILE).write_text(persona.job_description, encoding="utf-8")
        if persona.resume:
            (persona_dir / RESUME_FILE).write_text(persona.resume, encoding="utf-8")

    def load_persona(self, role_type: str, name: str | None = None) -> Persona:
        """Load a persona from the team directory."""
        if role_type == "consultant" and name:
            persona_path = self.team_dir / CONSULTANTS_DIR_NAME / _slugify(name) / PERSONA_FILE
        else:
            persona_path = self.team_dir / role_type / PERSONA_FILE
        return Persona.model_validate_json(persona_path.read_text(encoding="utf-8"))

    def list_consultants(self) -> list[Persona]:
        """List all active consultant personas (excludes archived)."""
        consultants_dir = self.team_dir / CONSULTANTS_DIR_NAME
        if not consultants_dir.exists():
            return []
        personas = []
        for d in consultants_dir.iterdir():
            if d.is_dir() and d.name != ARCHIVED_DIR_NAME and (d / PERSONA_FILE).exists():
                personas.append(Persona.model_validate_json((d / PERSONA_FILE).read_text(encoding="utf-8")))
        return personas

    def archive_consultant(self, name: str) -> None:
        """Archive a consultant - move their folder to _archived/."""
        slug = _slugify(name)
        source = self.team_dir / CONSULTANTS_DIR_NAME / slug
        if not source.exists():
            raise FileNotFoundError(f"Consultant '{name}' not found.")
        archive_dir = self.team_dir / CONSULTANTS_DIR_NAME / ARCHIVED_DIR_NAME
        archive_dir.mkdir(exist_ok=True)
        dest = archive_dir / slug
        source.rename(dest)

    def save_sprint(self, sprint: Sprint) -> None:
        with self._sprint_lock:
            sprint_dir = self.sprints_dir / f"sprint_{sprint.number}"
            sprint_dir.mkdir(exist_ok=True)
            (sprint_dir / SPRINT_FILE).write_text(sprint.model_dump_json(indent=2), encoding="utf-8")

    def load_sprint(self, number: int) -> Sprint:
        with self._sprint_lock:
            sprint_path = self.sprints_dir / f"sprint_{number}" / SPRINT_FILE
            return Sprint.model_validate_json(sprint_path.read_text(encoding="utf-8"))

    def sprint_notes_dir(self, sprint_number: int) -> Path:
        """Get the notes directory for a specific sprint's agent reflections."""
        d = self.sprints_dir / f"sprint_{sprint_number}" / "notes"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def save_code_review(self, sprint_number: int, review: Any) -> None:
        """Save code review results for a sprint."""
        sprint_dir = self.sprints_dir / f"sprint_{sprint_number}"
        sprint_dir.mkdir(exist_ok=True)
        (sprint_dir / CODE_REVIEW_FILE).write_text(review.model_dump_json(indent=2), encoding="utf-8")

    def load_code_review(self, sprint_number: int) -> Any:
        """Load code review results for a sprint."""
        from odd.models import CodeReview
        path = self.sprints_dir / f"sprint_{sprint_number}" / CODE_REVIEW_FILE
        return CodeReview.model_validate_json(path.read_text(encoding="utf-8"))

    def load_sprint_notes(self, sprint_number: int) -> dict[str, str]:
        """Load all agent notes from a sprint. Returns {agent_name: note_text}."""
        notes_dir = self.sprints_dir / f"sprint_{sprint_number}" / "notes"
        if not notes_dir.exists():
            return {}
        notes = {}
        for f in sorted(notes_dir.glob("*.md")):
            notes[f.stem] = f.read_text(encoding="utf-8")
        return notes

    # --- Roadmap persistence ---

    @property
    def roadmap_path(self) -> Path:
        return self.odd_dir / ROADMAP_FILE

    def save_roadmap(self, roadmap: Roadmap) -> None:
        self.roadmap_path.write_text(roadmap.model_dump_json(indent=2), encoding="utf-8")

    def load_roadmap(self) -> Roadmap:
        return Roadmap.model_validate_json(self.roadmap_path.read_text(encoding="utf-8"))

    def has_active_roadmap(self) -> bool:
        if not self.roadmap_path.exists():
            return False
        roadmap = self.load_roadmap()
        return roadmap.status == "active"

    def clear_roadmap(self) -> None:
        if self.roadmap_path.exists():
            roadmap = self.load_roadmap()
            roadmap.status = "abandoned"
            self.save_roadmap(roadmap)

    # --- Vacation persistence ---

    @property
    def vacation_plan_path(self) -> Path:
        return self.odd_dir / VACATION_PLAN_FILE

    @property
    def vacation_report_path(self) -> Path:
        return self.odd_dir / VACATION_REPORT_FILE

    def save_vacation_plan(self, plan: VacationPlan) -> None:
        self.vacation_plan_path.write_text(plan.model_dump_json(indent=2), encoding="utf-8")

    def load_vacation_plan(self) -> VacationPlan:
        return VacationPlan.model_validate_json(self.vacation_plan_path.read_text(encoding="utf-8"))

    def save_vacation_report(self, report: VacationReport) -> None:
        self.vacation_report_path.write_text(report.model_dump_json(indent=2), encoding="utf-8")

    def load_vacation_report(self) -> VacationReport:
        return VacationReport.model_validate_json(self.vacation_report_path.read_text(encoding="utf-8"))

    def has_active_vacation(self) -> bool:
        if not self.vacation_plan_path.exists():
            return False
        if self.vacation_report_path.exists():
            report = self.load_vacation_report()
            # Active if report exists but vacation didn't finish
            return report.stopped_reason == "paused"
        return True  # Plan exists but no report yet - vacation hasn't started

    def clear_vacation(self) -> None:
        if self.vacation_plan_path.exists():
            self.vacation_plan_path.unlink()
        if self.vacation_report_path.exists():
            self.vacation_report_path.unlink()

    def get_persona_notes_dir(self, persona: Persona) -> Path:
        """Get the personal notes directory for an agent."""
        if persona.role_type.value == "consultant":
            d = self.team_dir / CONSULTANTS_DIR_NAME / _slugify(persona.name) / "notes"
        else:
            d = self.team_dir / persona.role_type.value / "notes"
        d.mkdir(parents=True, exist_ok=True)
        return d


    # --- Consultant ratings ---

    def _ratings_path(self, name: str) -> Path:
        return self.team_dir / CONSULTANTS_DIR_NAME / _slugify(name) / RATINGS_FILE

    def load_consultant_record(self, name: str) -> ConsultantRecord:
        """Load a consultant's lifetime performance record."""
        path = self._ratings_path(name)
        if path.exists():
            return ConsultantRecord.model_validate_json(path.read_text(encoding="utf-8"))
        return ConsultantRecord(name=name)

    def save_consultant_record(self, record: ConsultantRecord) -> None:
        """Save a consultant's performance record."""
        path = self._ratings_path(record.name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(record.model_dump_json(indent=2), encoding="utf-8")

    def record_task_outcome(
        self,
        name: str,
        sprint_number: int,
        task_id: str,
        task_description: str,
        passed: bool,
        retries: int = 0,
    ) -> ConsultantRecord:
        """Record a task outcome for a consultant and return the updated record.

        Thread-safe: the load-modify-save cycle is serialized to prevent
        lost updates when multiple worktree threads record concurrently.
        """
        with self._record_lock:
            record = self.load_consultant_record(name)
            record.record(TaskOutcome(
                sprint_number=sprint_number,
                task_id=task_id,
                task_description=task_description,
                passed=passed,
                retries=retries,
            ))
            self.save_consultant_record(record)
            return record

    def all_consultant_records(self) -> dict[str, ConsultantRecord]:
        """Load performance records for all active consultants."""
        records: dict[str, ConsultantRecord] = {}
        for persona in self.list_consultants():
            records[persona.name] = self.load_consultant_record(persona.name)
        return records



def _slugify(name: str) -> str:
    return name.lower().replace(" ", "_").replace("-", "_")
