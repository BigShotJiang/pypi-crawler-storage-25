"""Shared console and thread-safe printing for the ODD package."""

from __future__ import annotations

import threading
from typing import Any

from rich.console import Console

console = Console()
_console_lock = threading.Lock()


def _tprint(*args: Any, **kwargs: Any) -> None:
    """Thread-safe wrapper around console.print.

    Rich Console is not fully thread-safe for interleaved writes - output
    can garble when multiple threads print concurrently.
    """
    with _console_lock:
        console.print(*args, **kwargs)
