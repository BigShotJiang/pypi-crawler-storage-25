"""Shared rate limiter for coordinating concurrent API calls.

When multiple agents run in parallel (e.g., worktree-based task execution),
they share a single provider instance.  This module provides:

- A concurrency cap via semaphore (prevents flooding the API)
- Shared backoff state so one 429 response slows all callers
"""

from __future__ import annotations

import threading
import time
from contextlib import contextmanager
from typing import Iterator


class SharedRateLimiter:
    """Cross-instance rate limiter for API calls.

    Thread-safe: all state is protected by locks.
    """

    def __init__(self, max_concurrent: int = 4):
        self._semaphore = threading.Semaphore(max_concurrent)
        self._backoff_until: float = 0.0
        self._backoff_lock = threading.Lock()

    def acquire(self) -> None:
        """Block until a slot is available and any shared backoff has passed."""
        self._semaphore.acquire()
        with self._backoff_lock:
            wait = self._backoff_until - time.monotonic()
        if wait > 0:
            time.sleep(wait)

    def release(self) -> None:
        """Release one concurrency slot."""
        self._semaphore.release()

    def signal_rate_limit(self, retry_after: float = 5.0) -> None:
        """Record a rate-limit response.  All callers will wait.

        Uses max() so concurrent 429s extend rather than stack the backoff.
        """
        with self._backoff_lock:
            new_until = time.monotonic() + retry_after
            self._backoff_until = max(self._backoff_until, new_until)

    @contextmanager
    def throttled(self) -> Iterator[None]:
        """Context manager: acquire a slot, yield, then release."""
        self.acquire()
        try:
            yield
        finally:
            self.release()
