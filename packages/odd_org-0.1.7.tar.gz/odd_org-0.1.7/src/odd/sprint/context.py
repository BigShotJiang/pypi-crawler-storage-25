"""Sprint context building - project context, ecosystem detection, agent resolution.

SprintContext assembles the contextual information that agents receive
during a sprint: project metadata, tech stack, consultant roster, backlog,
and roadmap summaries.  It also resolves assignment strings to Persona objects.
"""

from __future__ import annotations

import json
import re
from typing import Any

from odd.backlog import Backlog
from odd.git import GitManager
from odd.models import Persona
from odd.state import StateManager
from odd.tdd.ecosystem import detect_ecosystem


class SprintContext:
    """Read-only context builder for sprint agents."""

    def __init__(
        self,
        state: StateManager,
        git: GitManager,
    ):
        self.state = state
        self.git = git
        self._consultant_cache: list[Persona] | None = None

    def reset_cache(self) -> None:
        """Clear the consultant cache (called at sprint start)."""
        self._consultant_cache = None

    # --- Ecosystem detection ---

    def detect_ecosystem(self) -> dict[str, Any]:
        """Detect the target project's tech ecosystem from its root files.

        Returns a dict with:
          language: "python" | "javascript" | "typescript" | "unknown"
          framework: detected framework name or None
          test_framework: recommended test runner or None
          test_directive: ready-to-use instruction string for QA

        Delegates ecosystem detection to ``odd.tdd.ecosystem.detect_ecosystem``
        and enriches the result with language/framework/directive metadata
        needed by sprint planning.
        """
        root = self.state.root
        eco = detect_ecosystem(root)
        test_fw = eco["test_framework"]

        # --- JavaScript / TypeScript ---
        pkg_path = root / "package.json"
        if pkg_path.exists():
            try:
                pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pkg = {}

            deps = {
                *pkg.get("dependencies", {}),
                *pkg.get("devDependencies", {}),
            }
            lang = "typescript" if "typescript" in deps or (root / "tsconfig.json").exists() else "javascript"

            framework = None
            for name in ("next", "react", "vue", "svelte", "angular", "express"):
                if name in deps:
                    framework = name
                    break

            test_dir = "__tests__" if test_fw == "jest" else "tests"
            return {
                "language": lang,
                "framework": framework,
                "test_framework": test_fw,
                "test_directive": (
                    f"Use {test_fw}. "
                    f"Create test files in the {test_dir}/ directory."
                ),
            }

        # --- Python ---
        is_python = any(
            (root / f).exists()
            for f in ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt")
        )
        if is_python:
            return {
                "language": "python",
                "framework": None,
                "test_framework": test_fw,
                "test_directive": f"Use {test_fw}. Create test files in the tests/ directory.",
            }

        # --- Fallback ---
        return {
            "language": "unknown",
            "framework": None,
            "test_framework": None,
            "test_directive": (
                "Choose the appropriate test framework for this project. "
                "Create test files in a tests/ directory."
            ),
        }

    # --- Project context ---

    def build_project_context(self, sprint_number: int) -> str:
        """Build shared project context for agents."""
        config = self.state.load_config()
        parts = [
            f"Project: {config.name}",
            f"Description: {config.description}",
            f"Current Sprint: {sprint_number}",
        ]

        # Include tech stack so agents know the ecosystem
        eco = self.detect_ecosystem()
        tech_parts = []
        if eco["language"] != "unknown":
            tech_parts.append(eco["language"])
        if eco["framework"]:
            tech_parts.append(eco["framework"])
        if eco["test_framework"]:
            tech_parts.append(f"tests: {eco['test_framework']}")
        if tech_parts:
            parts.append(f"Tech stack: {', '.join(tech_parts)}")

        consultants = self.state.list_consultants()
        if consultants:
            parts.append("Available consultants:")
            for c in consultants:
                reason = f" - {c.hire_reason}" if c.hire_reason else ""
                sprint_tag = f" (Sprint {c.hired_sprint})" if c.hired_sprint else ""
                record = self.state.load_consultant_record(c.name)
                track = f" [{record.summary()}]" if record.outcomes else ""
                parts.append(f"  - {c.name}: {c.title}{reason}{sprint_tag}{track}")

        backlog = Backlog(self.state.odd_dir)
        backlog_summary = backlog.summary_for_agent()
        if backlog_summary != "Backlog is empty.":
            parts.append(f"\n{backlog_summary}")

        if self.state.has_active_roadmap():
            roadmap = self.state.load_roadmap()
            parts.append(f"\nRoadmap goal: {roadmap.goal}")
            for rs in roadmap.sprints:
                marker = "→" if rs.status == "in_progress" else "✓" if rs.status == "complete" else " "
                parts.append(f"  [{marker}] Sprint {rs.number}: {rs.deliverables}")

        return "\n".join(parts)

    @staticmethod
    def build_phase_context(project_context, briefing, agent_name):
        """Build agent-scoped project context with filtered briefing."""
        briefing_text = briefing.render_for_agent(agent_name)
        if briefing_text:
            return project_context + "\n\n" + briefing_text
        return project_context

    # --- Agent resolution ---

    def resolve_agent(self, assigned_to, team):
        """Resolve an assignment string to a persona."""
        assigned_lower = assigned_to.lower()

        for key, persona in team.items():
            if key == assigned_lower or persona.name.lower() == assigned_lower:
                return persona

        for key, persona in team.items():
            if re.search(r'\b' + re.escape(key) + r'\b', assigned_lower):
                return persona
            if re.search(r'\b' + re.escape(persona.name.lower()) + r'\b', assigned_lower):
                return persona

        if self._consultant_cache is None:
            self._consultant_cache = self.state.list_consultants()
        for c in self._consultant_cache:
            if c.name.lower() == assigned_lower:
                return c
        for c in self._consultant_cache:
            if re.search(r'\b' + re.escape(c.name.lower()) + r'\b', assigned_lower):
                return c

        return None

    def get_lead_dev(self):
        """Load the lead dev persona from state."""
        return self.state.load_persona("lead_dev")
