"""Mechanical sprint status dashboard.

Extracted from SprintEngine to keep the engine focused on orchestration.
"""

from __future__ import annotations

from typing import Any, Callable

from odd.models import Sprint, TaskStatus


def run_standup(
    sprint: Sprint,
    run_tests: Callable[[], tuple[bool, str]],
    get_phase_diff_stat: Callable[[int], str],
) -> str:
    """Mechanical sprint status dashboard - no LLM calls.

    Parameters
    ----------
    sprint : Sprint
        The sprint to report on.
    run_tests : callable
        Callable that returns (passed: bool, output: str).
    get_phase_diff_stat : callable
        Callable that takes a sprint number and returns diff stat string.
    """
    task_lines: list[str] = []
    done = failed = pending = 0
    for t in sprint.tasks:
        marker = {
            TaskStatus.DONE: "\u2713",
            TaskStatus.FAILED: "\u2717",
            TaskStatus.IN_PROGRESS: "\u29d6",
        }.get(t.status, "\u25cb")
        task_lines.append(f"  {marker} {t.id}: {t.description} ({t.status.value})")
        if t.status == TaskStatus.DONE:
            done += 1
        elif t.status == TaskStatus.FAILED:
            failed += 1
        else:
            pending += 1

    test_passed, test_output = run_tests()
    test_summary = ""
    if test_output.strip():
        test_summary = test_output.strip().splitlines()[-1]

    diff_stat = get_phase_diff_stat(sprint.number)

    parts = [
        f"# Sprint {sprint.number} Status",
        f"**Goal**: {sprint.goal}",
        f"\n**Tasks**: {done} done, {failed} failed, {pending} remaining",
    ]
    if task_lines:
        parts.append("\n".join(task_lines))
    if test_summary:
        status_label = "passing" if test_passed else "failing"
        parts.append(f"\n**Tests** ({status_label}): {test_summary}")
    if diff_stat:
        parts.append(f"\n**Changes**:\n```\n{diff_stat}\n```")

    return "\n".join(parts)
