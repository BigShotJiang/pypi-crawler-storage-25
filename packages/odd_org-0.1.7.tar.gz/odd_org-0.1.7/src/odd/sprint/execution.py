"""Sprint execution - QA phase, implementation phases, task dispatch.

SprintExecutor runs the inner machinery of a sprint: the QA test-writing
phase, sequential implementation phases (with parallel tasks within each),
escalation handling, and checkpoint persistence.
"""

from __future__ import annotations

import datetime
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, TYPE_CHECKING

from rich.panel import Panel

from odd.config import PHASE_TOKEN_DEFAULTS
from odd.display import AgentOutputStream
from odd.labels import escalation_label, escalation_style
from odd.models import (
    Persona,
    RoleType,
    Sprint,
    SprintCheckpoint,
    SprintPhase,
    TaskResult,
    TaskStatus,
)
from odd.provider import StreamCallback
from odd.sprint._console import console
from odd.sprint.briefing import SprintBriefing

if TYPE_CHECKING:
    from odd.agent import AgentEngine
    from odd.git import GitManager
    from odd.sprint.context import SprintContext
    from odd.sprint.phase_runner import PhaseRunner
    from odd.sprint.planner import SprintPlanner
    from odd.sprint.wrapup import SprintWrapup
    from odd.state import StateManager
    from odd.tdd import TDDGate


class SprintExecutor:
    """Runs QA and implementation phases within a sprint."""

    def __init__(
        self,
        *,
        engine: AgentEngine,
        state: StateManager,
        git: GitManager,
        tdd: TDDGate,
        phase_runner: PhaseRunner,
        planner: SprintPlanner,
        wrapup: SprintWrapup,
        context: SprintContext,
        make_stream_callback: Callable[[str], StreamCallback | None],
        make_war_room_callback: Callable[[AgentOutputStream], StreamCallback | None],
        make_tool_result_callback: Callable[[AgentOutputStream | None], Any],
        war_room_context: Callable,
        get_phase_diff_stat: Callable[[int], str],
    ):
        self.engine = engine
        self.state = state
        self.git = git
        self.tdd = tdd
        self.phase_runner = phase_runner
        self.planner = planner
        self.wrapup = wrapup
        self.context = context
        self._make_stream_callback = make_stream_callback
        self._make_war_room_callback = make_war_room_callback
        self._make_tool_result_callback = make_tool_result_callback
        self._war_room_context = war_room_context
        self._get_phase_diff_stat = get_phase_diff_stat

    # --- QA phase ---

    def run_qa_phase(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        notes_path: str,
        briefing: SprintBriefing,
    ) -> tuple[Sprint, str]:
        """QA writes tests, optionally concurrent with phase planning."""
        qa = team["qa"]
        lead_dev = team["lead_dev"]

        console.print(Panel("QA is writing tests (TDD)...", style="red"))

        task_count = len(sprint.tasks)
        eco = self.context.detect_ecosystem()
        test_prompt = (
            f"Sprint {sprint.number} goal: {sprint.goal}\n\n"
            f"Here are the planned tasks:\n"
        )
        for task in sprint.tasks:
            test_prompt += f"- {task.description} (assigned to: {task.assigned_to})\n"
        test_prompt += (
            "\nWrite focused tests for these features BEFORE they are "
            f"implemented. {eco['test_directive']} "
            "The tests should define what 'done' looks like for each task.\n\n"
            "SCOPE CONSTRAINTS - stay lean:\n"
            f"- Write at most {max(1, task_count)} test file(s) \u2014 "
            "group related tasks into a single file when possible.\n"
            "- Each file should be under 100 lines. Focus on the core "
            "contract: happy path + 1-2 critical edge cases per task.\n"
            "- Do NOT exhaustively test every permutation, error path, or "
            "boundary condition. You can expand coverage in later sprints.\n"
            "- Prefer simple, readable assertions over elaborate fixtures.\n\n"
            f"When you're done writing all the tests, write a brief note about "
            f"what you tested, your coverage strategy, and any concerns to "
            f"{notes_path}/qa.md"
        )

        if not sprint.phases:
            qa_engine = self.engine.fork()
            phase_engine = self.engine.fork()
            with self._war_room_context([qa.name, lead_dev.name]) as streams:
                qa_cb = self._make_war_room_callback(streams[qa.name]) if streams else None
                ld_cb = self._make_war_room_callback(streams[lead_dev.name]) if streams else None
                qa_tool_cb = self._make_tool_result_callback(streams.get(qa.name)) if streams else None
                ld_tool_cb = self._make_tool_result_callback(streams.get(lead_dev.name)) if streams else None
                with ThreadPoolExecutor(max_workers=2) as pool:
                    qa_future = pool.submit(
                        qa_engine.invoke,
                        persona=qa, user_message=test_prompt,
                        project_context=project_context,
                        max_tokens=PHASE_TOKEN_DEFAULTS["qa"],
                        stream=qa_cb, phase="qa",
                        on_tool_result=qa_tool_cb,
                    )
                    phase_future = pool.submit(
                        self.planner.plan_phases_with_engine, phase_engine, lead_dev, sprint,
                        stream=ld_cb,
                    )
                    qa_future.result()
                    sprint = phase_future.result()
            self.engine.escalations.extend(qa_engine.get_escalations())
            self.engine.escalations.extend(phase_engine.get_escalations())
            self.engine.submissions.extend(qa_engine.get_submissions())
            self.engine.submissions.extend(phase_engine.get_submissions())
        else:
            with self._war_room_context([qa.name]) as streams:
                if streams:
                    qa_stream = self._make_war_room_callback(streams[qa.name])
                    qa_tool_cb = self._make_tool_result_callback(streams[qa.name])
                else:
                    qa_stream = self._make_stream_callback(qa.name)
                    qa_tool_cb = None
                self.engine.invoke(
                    persona=qa, user_message=test_prompt,
                    project_context=project_context,
                    max_tokens=PHASE_TOKEN_DEFAULTS["qa"],
                    stream=qa_stream, phase="qa",
                    on_tool_result=qa_tool_cb,
                )

        console.print("[red]QA has written the test suite.[/red]")

        briefing.after_planning(sprint.tasks, sprint.phases)

        test_files = self.tdd.discover_test_files()
        test_names = self.tdd.collect_test_names()
        test_passed, test_output = self.tdd.run_tests()
        if test_files:
            console.print(f"[dim]  Test files: {', '.join(test_files)}[/dim]")
            if test_names:
                console.print(f"[dim]  Tests collected: {len(test_names)}[/dim]")
            status = "[green]passing[/green]" if test_passed else "[yellow]failing (expected - TDD)[/yellow]"
            console.print(f"[dim]  Baseline: {status}[/dim]")

        briefing.after_qa(test_files, test_names, test_output)

        test_context = ""
        if test_files:
            test_context = (
                f"\n\nQA has written these test files:\n"
                + "\n".join(f"  - {f}" for f in test_files)
            )
            if test_names:
                test_context += "\n\nTest names (via pytest --collect-only):\n"
                test_context += "\n".join(f"  - {n}" for n in test_names)
            test_context += f"\n\nBaseline test output:\n```\n{test_output[:2000]}\n```"

        return sprint, test_context

    # --- Implementation phases ---

    def run_implementation_phases(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        notes_path: str,
        test_context: str,
        briefing: SprintBriefing,
    ) -> None:
        """Execute implementation phases sequentially, with parallel tasks within each."""
        self.run_implementation_phases_subset(
            sprint, team, project_context, notes_path,
            test_context, briefing, sprint.phases,
        )

    def run_implementation_phases_subset(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        notes_path: str,
        test_context: str,
        briefing: SprintBriefing,
        phases: list[SprintPhase],
    ) -> None:
        """Execute a subset of implementation phases (used by resume)."""
        lead_dev = team["lead_dev"]
        task_map = {t.id: t for t in sprint.tasks}
        completed_ids = set(sprint.checkpoint.completed_task_ids) if sprint.checkpoint else set()

        for phase in phases:
            phase_tasks = [task_map[tid] for tid in phase.task_ids if tid in task_map]
            if not phase_tasks:
                continue

            console.print(Panel(
                f"[bold]Phase {phase.number}[/bold]: {phase.description}",
                style="green",
            ))

            parallel_engines: dict[str, Any] | None = None
            if len(phase_tasks) == 1:
                task = phase_tasks[0]
                if task.id in completed_ids:
                    console.print(f"[dim]Skipping already-completed task: {task.description}[/dim]")
                else:
                    agent = self.context.resolve_agent(task.assigned_to, team) or team["lead_dev"]
                    phase_context = self.context.build_phase_context(
                        project_context, briefing, agent.name,
                    )
                    self.run_task(
                        task, sprint, team, phase_context, notes_path,
                        test_context=test_context,
                    )
                    # Task-level checkpoint: save after each completed task
                    self.save_task_checkpoint(sprint, phase, test_context)
            else:
                # Filter out already-completed tasks from parallel execution
                remaining = [t for t in phase_tasks if t.id not in completed_ids]
                if remaining:
                    parallel_engines = self.phase_runner.run_phase_parallel(
                        remaining, sprint, team, project_context, notes_path,
                        test_context=test_context,
                        briefing=briefing,
                    )
                    conflicts = self.git.merge_task_branches(
                        sprint.number, [t.id for t in remaining],
                    )
                    merge_context = self.context.build_phase_context(
                        project_context, briefing, lead_dev.name,
                    )
                    if conflicts:
                        self.phase_runner.resolve_phase_conflicts(
                            lead_dev, sprint, phase, conflicts, merge_context,
                        )
                    self.git.cleanup_task_branches(
                        sprint.number, [t.id for t in remaining],
                    )
                    self.wrapup.handle_test_change_requests(sprint, team, merge_context)
                    self.wrapup.handle_dependency_requests(team, merge_context)

                    # Surface any escalations that were queued during parallel execution
                    self.handle_post_phase_escalations(
                        phase, team, project_context, briefing,
                    )

            self.capture_phase_results(phase, phase_tasks, sprint, team, briefing)

            sprint.checkpoint = SprintCheckpoint(
                stage=f"phase_{phase.number}",
                completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                completed_task_ids=[t.id for t in sprint.tasks if t.status == TaskStatus.DONE],
                task_results=self.build_task_results(sprint),
                test_context=test_context,
            )
            self.state.save_sprint(sprint)

    # --- Escalation handling ---

    def handle_post_phase_escalations(
        self,
        phase: SprintPhase,
        team: dict[str, Persona],
        project_context: str,
        briefing: SprintBriefing,
    ) -> None:
        """Interactively handle escalations queued during parallel execution.

        Called on the main thread after a parallel phase completes.
        Escalations were forwarded to self.engine.escalations by the
        PhaseRunner - now the CEO gets to act on them.
        """
        import odd.sprint as _sprint_pkg
        _Prompt = _sprint_pkg.Prompt

        escalations = self.engine.get_escalations()
        if not escalations:
            return

        console.print(Panel(
            f"[bold]Phase {phase.number} complete[/bold] \u2014 "
            f"{len(escalations)} escalation(s) need your attention.",
            style="yellow",
        ))

        for esc in escalations:
            agent_name = esc.get("agent_name", "Unknown")
            severity = esc["severity"]
            reason = esc["reason"]

            console.print(Panel(
                f"[bold]{agent_name}[/bold] - {escalation_label(severity)}:\n\n{reason}",
                title="Escalation",
                style=escalation_style(severity),
            ))

            if severity == "command_request":
                command = esc.get("command", "")
                console.print(f"\n  [bold]Command:[/bold] [cyan]{command}[/cyan]")
                ceo_response = _Prompt.ask(
                    "[bold yellow]CEO[/bold yellow]",
                    choices=["approve", "deny"],
                    default="approve",
                )
                if ceo_response == "approve":
                    from odd.tdd.test_infra import _run_approved_command
                    output = _run_approved_command(command, self.state.root)
                    console.print(Panel(
                        output[:2000] + ("..." if len(output) > 2000 else ""),
                        title=f"Output: {command}",
                        style="dim",
                    ))
                else:
                    console.print("[yellow]Denied.[/yellow]")

            elif severity == "needs_decision":
                ceo_response = _Prompt.ask(
                    "[bold yellow]CEO[/bold yellow]",
                    choices=["skip", "noted"],
                    default="noted",
                )

            elif severity == "blocker":
                ceo_response = _Prompt.ask(
                    "[bold yellow]CEO[/bold yellow] (your input needed)"
                )

    # --- Task execution ---

    def run_task(
        self, task, sprint, team, project_context, notes_path, test_context="",
    ) -> None:
        """Run a single task on the current branch (no worktree)."""
        task.status = TaskStatus.IN_PROGRESS
        agent = self.context.resolve_agent(task.assigned_to, team)
        if not agent:
            console.print("[dim]Cody is picking this one up.[/dim]")
            agent = team["lead_dev"]

        console.print(Panel(f"{agent.name} is working on: {task.description}", style="green"))

        impl_prompt = self.tdd.build_impl_prompt(
            sprint.number, task.description, test_context, notes_path, agent.name,
        )

        with self._war_room_context([agent.name]) as streams:
            if streams:
                stream_cb = self._make_war_room_callback(streams[agent.name])
                tool_cb = self._make_tool_result_callback(streams[agent.name])
            else:
                stream_cb = self._make_stream_callback(agent.name)
                tool_cb = None
            self.tdd.execute(
                engine=self.engine, agent=agent, task=task, sprint=sprint,
                impl_prompt=impl_prompt, project_context=project_context,
                team=team, stream_cb=stream_cb, interactive=True,
                on_test_change_requests=self.wrapup.handle_test_change_requests,
                on_dependency_requests=self.wrapup.handle_dependency_requests,
                on_tool_result=tool_cb,
            )

    # --- Checkpoints & results ---

    def save_task_checkpoint(
        self, sprint: Sprint, phase: SprintPhase, test_context: str,
    ) -> None:
        """Save a checkpoint after a single task completes within a phase."""
        sprint.checkpoint = SprintCheckpoint(
            stage=f"phase_{phase.number}",
            completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            completed_task_ids=[t.id for t in sprint.tasks if t.status == TaskStatus.DONE],
            task_results=self.build_task_results(sprint),
            test_context=test_context,
        )
        self.state.save_sprint(sprint)

    @staticmethod
    def build_task_results(sprint: Sprint) -> list[TaskResult]:
        """Build TaskResult list from current sprint task statuses."""
        return [
            TaskResult(
                task_id=t.id,
                status=t.status.value if hasattr(t.status, "value") else str(t.status),
                output_summary=t.description[:200],
            )
            for t in sprint.tasks
            if t.status in (TaskStatus.DONE, TaskStatus.FAILED)
        ]

    def capture_phase_results(
        self, phase, phase_tasks, sprint, team, briefing,
    ) -> None:
        """Run post-phase tests and capture results into the briefing."""
        consultant_tasks = []
        core_outcomes = []
        for t in phase_tasks:
            agent = self.context.resolve_agent(t.assigned_to, team)
            if agent and agent.role_type == RoleType.CONSULTANT:
                consultant_tasks.append((t, agent))
            else:
                core_outcomes.append((t.id, t.description, t.status))

        phase_passed, phase_test_output = self.tdd.run_tests()
        phase_test_summary = ""
        if phase_test_output.strip():
            phase_test_summary = phase_test_output.strip().splitlines()[-1]
        phase_diff = self._get_phase_diff_stat(sprint.number)

        briefing.after_phase(phase.number, core_outcomes, phase_test_summary, phase_diff)

        for t, agent in consultant_tasks:
            task_diff = self.git.get_task_diff_stat(sprint.number, t.id)
            briefing.after_consultant_task(
                agent.name, t.description, t.status, task_diff or phase_diff,
            )

        self.state.save_sprint(sprint)
