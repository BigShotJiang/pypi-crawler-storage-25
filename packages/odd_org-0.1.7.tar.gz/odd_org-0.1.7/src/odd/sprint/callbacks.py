"""Streaming and War Room callback factories.

Extracted from SprintEngine to keep the engine focused on orchestration.
"""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from typing import Any, Callable

from odd.display import (
    AgentOutputStream, AgentStatus, WarRoom,
    format_tool_result_line,
)
from odd.models import CEOGate, CEOStyle
from odd.provider import StreamCallback, StreamEvent, StreamEventType
from odd.sprint._console import console


def make_stream_callback(
    agent_name: str,
    style: CEOStyle,
    streaming: bool,
) -> StreamCallback | None:
    """Build a Rich-based streaming callback for an agent, or None if disabled."""
    if not streaming:
        return None

    if style == CEOStyle.DELEGATOR:
        return None

    if style == CEOStyle.BALANCED:
        def _on_summary_event(event: StreamEvent) -> None:
            if event.event_type == StreamEventType.TOOL_USE_START:
                console.print(
                    f"[dim]  ↳ {agent_name} → {event.tool_name}[/dim]",
                    highlight=False,
                )
        return _on_summary_event

    # HANDS_ON: full streaming
    _last_was_text = False

    def _on_event(event: StreamEvent) -> None:
        nonlocal _last_was_text
        if event.event_type == StreamEventType.TEXT_DELTA:
            console.print(event.text, end="", highlight=False)
            _last_was_text = True
        elif event.event_type == StreamEventType.TOOL_USE_START:
            prefix = "\n" if _last_was_text else ""
            console.print(
                f"{prefix}[dim]  ↳ {agent_name} → {event.tool_name}[/dim]",
                highlight=False,
            )
            _last_was_text = False
        elif event.event_type == StreamEventType.MESSAGE_STOP:
            console.print()
            _last_was_text = False

    return _on_event


def make_war_room_callback(
    stream: AgentOutputStream,
    style: CEOStyle,
) -> StreamCallback | None:
    """Build a StreamCallback that feeds into an AgentOutputStream."""
    if style == CEOStyle.DELEGATOR:
        return None

    if style == CEOStyle.BALANCED:
        # BALANCED: suppress text output, tool activity comes
        # through on_tool_result callback instead.
        return stream.as_summary_callback()

    # HANDS_ON: full streaming (text deltas only - tool calls
    # are shown via the on_tool_result callback with ✓/✗ status)
    return stream.as_stream_callback()


def make_tool_result_callback(
    stream: AgentOutputStream | None,
    style: CEOStyle,
) -> Callable[[str, dict, str], None] | None:
    """Build an on_tool_result callback that feeds the War Room.

    Shows what actually happened on disk after each tool execution,
    e.g. '✓ Write src/app.py (312 chars)' or '✗ Write ../../evil - blocked'.
    """
    if stream is None:
        return None
    if style == CEOStyle.DELEGATOR:
        return None

    def _on_result(tool_name: str, tool_input: dict, result: str) -> None:
        line = format_tool_result_line(tool_name, tool_input, result)
        stream.append(line + "\n")

    return _on_result


@contextmanager
def war_room_context(
    display_streaming: bool,
    style: CEOStyle,
    agent_names: list[str],
) -> Generator[dict[str, AgentOutputStream], None, None]:
    """Context manager that starts/stops a War Room for the given agents.

    Parameters
    ----------
    display_streaming : bool
        Whether streaming display is enabled (SprintEngine.streaming).
    style : CEOStyle
        The resolved CEO style for the WAR_ROOM gate.
    agent_names : list[str]
        Names of agents to create output streams for.
    """
    active = (
        style != CEOStyle.DELEGATOR
        and display_streaming
    )
    streams: dict[str, AgentOutputStream] = {}
    war_room: WarRoom | None = None

    if active:
        stream_list: list[AgentOutputStream] = []
        for name in agent_names:
            aos = AgentOutputStream(name)
            aos.status = AgentStatus.WORKING
            streams[name] = aos
            stream_list.append(aos)
        war_room = WarRoom(stream_list, console=console)
        war_room.start()

    try:
        yield streams
    finally:
        if active:
            for aos in streams.values():
                if aos.status == AgentStatus.WORKING:
                    aos.status = AgentStatus.DONE
        if war_room:
            war_room.stop()
