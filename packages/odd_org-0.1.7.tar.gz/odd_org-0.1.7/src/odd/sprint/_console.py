"""Backward-compatible re-export from odd._console."""

from odd._console import Console, _console_lock, _tprint, console  # noqa: F401

__all__ = ["Console", "_console_lock", "_tprint", "console"]
