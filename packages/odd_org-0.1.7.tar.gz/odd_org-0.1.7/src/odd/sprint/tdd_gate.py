"""Compatibility shim - TDDGate has moved to odd.tdd.

All imports are re-exported so existing ``from odd.sprint.tdd_gate import ...``
paths continue to work.
"""

from odd.tdd.gate import TDDGate  # noqa: F401
from odd.tdd.test_infra import (  # noqa: F401
    _resolve_argv,
    _run_approved_command,
    _extract_cd_prefix,
)
